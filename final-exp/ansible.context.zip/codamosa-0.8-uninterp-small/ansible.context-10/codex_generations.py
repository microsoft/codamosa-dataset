

# Generated at 2022-06-24 18:36:09.481236
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert 0 == 0


# Global context unit test

# Generated at 2022-06-24 18:36:15.787180
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    args = {}

    num_repetitions = 10
    # List of expected return values
    expected_values = [
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        ]

    for i in range(num_repetitions):
        value = cliargs_deferred_get(args)

        # Check return value
        assert value == expected_values[i]


# Generated at 2022-06-24 18:36:18.717837
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = dict()
    _init_global_context(cli_args)
    try:
        test_case_0()
    except NameError:
        fail("Missing global fixture: cliargs_deferred_get")

# Generated at 2022-06-24 18:36:21.564300
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Unit test for function cliargs_deferred_get
    res = cliargs_deferred_get(cliargs_deferred_get(CLIARGS))
    assert res == 'cliargs_deferred_get'



# Generated at 2022-06-24 18:36:28.765967
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function for function cliargs_deferred_get."""
    var_0 = cliargs_deferred_get(0, shallowcopy=True)
    assert var_0() == 0, var_0()
    var_1 = cliargs_deferred_get(1, default='abc')
    assert var_1() == 'abc', var_1()
    var_2 = cliargs_deferred_get(1)
    assert var_2() == 1, var_2()
    var_3 = cliargs_deferred_get(2, default='abc')
    assert var_3() == 'abc', var_3()
    var_4 = cliargs_deferred_get(2, default=1)
    assert var_4() == 1, var_4()
    var_5 = cliargs

# Generated at 2022-06-24 18:36:33.027326
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    assert var_0 is not None


if __name__ == "__main__":
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-24 18:36:42.461398
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_native
    from ansible.errors import AnsibleError

    if PY3:
        try:
            cliargs_deferred_get(float_0)
        except NameError as e:
            assert e.args[0] == "global name 'float_0' is not defined"
        else:
            raise AssertionError('AnsibleError not raised')
    else:
        assert cliargs_deferred_get(float_0) == None
        assert cliargs_deferred_get(str(float_0)) == None

    # set up the context to test with

# Generated at 2022-06-24 18:36:50.976967
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(0)
    assert var_0 == 'Test str'
    var_1 = cliargs_deferred_get(1)
    assert var_1 == None
    var_2 = cliargs_deferred_get(2)
    assert var_2 == 'Test str'
    var_3 = cliargs_deferred_get(3)
    assert var_3 == cliargs_deferred_get(3)
    var_4 = cliargs_deferred_get(4)
    assert var_4 == cliargs_deferred_get(4)
    var_5 = cliargs_deferred_get(5)
    assert var_5 == 'Test str'
    var_6 = cliargs_deferred_get(6)
    assert var

# Generated at 2022-06-24 18:36:56.381270
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    var_1 = cliargs_deferred_get(float_0)
    var_2 = cliargs_deferred_get(float_0)
    var_3 = cliargs_deferred_get(float_0)
    test_case_0()


# End: ansible/context.py

# Generated at 2022-06-24 18:37:01.578791
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    import unittest
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    var_1 = is_sequence(var_0)



# Generated at 2022-06-24 18:37:08.177518
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    assert var_0() == -519.6603
    assert var_0() == -519.6603
    assert var_0() == -519.6603

# Generated at 2022-06-24 18:37:13.299611
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import ansible.constants as C
    import ansible.utils.display as Display
    import collections
    import copy
    import datetime
    import os
    import sys

    test_case_0()
    try:
        assert True
    except AssertionError:
        Display.error('AssertionError:  in test_case_0()')

test_cliargs_deferred_get()

# Generated at 2022-06-24 18:37:19.772611
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Make sure we have the expected types for objects
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    float_1 = float_0
    # Verify the expected type of the variable we get back
    assert(isinstance(var_0, float))
    # Verify we get the expected value back
    assert(var_0 == float_1)
    int_0 = -519460
    var_1 = cliargs_deferred_get(int_0)
    int_1 = int_0
    # Verify the expected type of the variable we get back
    assert(isinstance(var_1, int))
    # Verify we get the expected value back
    assert(var_1 == int_1)
    # Make sure we did not get a reference to a global var

# Generated at 2022-06-24 18:37:21.154336
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)

# Generated at 2022-06-24 18:37:31.475335
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:37:35.663150
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Now, test the function
    assert cliargs_deferred_get(float_0) is var_0

    # Test with a string
    assert cliargs_deferred_get('foo')



if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-24 18:37:44.240898
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    assert var_0() == -519.6603
    bool_0 = False
    var_1 = cliargs_deferred_get(bool_0)
    assert var_1() == False
    str_0 = 'fq3.5'
    var_2 = cliargs_deferred_get(str_0)
    assert var_2() == 'fq3.5'
    int_0 = -278
    var_3 = cliargs_deferred_get(int_0)
    assert var_3() == -278
    dict_0 = dict()
    dict_0['tuple_0'] = (0,)
    dict_0['bool_0'] = False
    dict

# Generated at 2022-06-24 18:37:48.253553
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = -519.6603
    assert cliargs_deferred_get(var_0)



# Generated at 2022-06-24 18:37:51.856181
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    assert var_0 == -519.6603

# Generated at 2022-06-24 18:38:01.499292
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = ".k~p"
    var_0 = cliargs_deferred_get(float_0)
    print(var_0)
    print(var_0())
    float_1 = "n?5"
    var_1 = cliargs_deferred_get(float_1, default=())
    print(var_1)
    print(var_1())
    float_2 = 'P'
    var_2 = cliargs_deferred_get(float_2, shallowcopy=True)
    print(var_2)
    print(var_2())
    float_3 = "d7"
    var_3 = cliargs_deferred_get(float_3, shallowcopy=True)
    print(var_3)
    print(var_3())

# Generated at 2022-06-24 18:38:08.667116
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # group 1 of 1
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)


# Generated at 2022-06-24 18:38:12.247269
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)

test_cliargs_deferred_get()

# Generated at 2022-06-24 18:38:17.235047
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    #    NOTE: THIS IS A GENERATED FILE: Do not modify it directly
    #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    
    assert var_0() == float_0, var_0()


# Generated at 2022-06-24 18:38:23.876306
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    var_1 = var_0()
    #assert var_1 == float_0
    assert var_1 is None
    var_2 = cliargs_deferred_get(var_1)
    var_3 = var_2()
    assert var_3 is None
    var_4 = cliargs_deferred_get(var_3)
    var_5 = var_4()
    assert var_5 is None
    var_6 = cliargs_deferred_get(var_5)
    var_7 = var_6()
    assert var_7 is None
    var_8 = cliargs_deferred_get(var_7)
    var_9 = var_8()


# Generated at 2022-06-24 18:38:27.672843
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    float_1 = float_0
    cli_args = {}
    _init_global_context(cli_args)
    var_0_after_init = var_0()
    assert float_1 == var_0_after_init, 'Expected different values'

# Generated at 2022-06-24 18:38:28.714391
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 18:38:31.458850
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_a = '0.5'
    float_a = -519.6603
    var_b = cliargs_deferred_get(float_a)


# Generated at 2022-06-24 18:38:35.759905
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # var = cliargs_deferred_get( key_0 )
    # assert not var, "This code should trigger a key error"
    var = cliargs_deferred_get(True)
    assert var is True, "This code should trigger a key error"
    var = cliargs_deferred_get("")
    assert var == "", "This should return a default value"

# Variable $__playbook_dir is a list
# Variable $__playbook_dir set to []

# Variable $__playbook_command is a list
# Variable $__playbook_command set to []

# Generated at 2022-06-24 18:38:42.272788
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    var_1 = cliargs_deferred_get(float_0, shallowcopy=True)
    var_2 = cliargs_deferred_get(float_0, default=float_0)
    var_3 = cliargs_deferred_get(float_0, default=float_0, shallowcopy=True)
    var_4 = cliargs_deferred_get(float_0, shallowcopy=True, default=float_0)



# Generated at 2022-06-24 18:38:43.452053
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert CLIARGS.get(float_0, default=float_0) == var_0()


# Generated at 2022-06-24 18:39:01.053522
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import random
    import types

    def get_random_int():
        return random.randint(0, 9)

    try:
        import builtins
        builtin_module = 'builtins'
    except ImportError:
        import __builtin__
        builtin_module = '__builtin__'

    for i in range(100):
        int_0 = get_random_int()
        int_1 = get_random_int()
        int_2 = get_random_int()
        int_3 = get_random_int()
        int_list_0 = []
        int_list_1 = []
        for x in range(10):
            int_list_1.append(get_random_int())
        for x in range(5):
            int_list_0.append(int_list_1)

# Generated at 2022-06-24 18:39:04.573217
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Random number used to simulate a dictionary key
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    assert var_0() is None



# Generated at 2022-06-24 18:39:10.206553
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'name': 'toshio', 'verbosity': 1}

    assert cliargs_deferred_get('name', default='default')() == 'default'
    _init_global_context(cli_args)
    assert cliargs_deferred_get('name', default='default')() == 'toshio'

    assert cliargs_deferred_get('verbosity', default=0)() == 0
    _init_global_context(cli_args)
    assert cliargs_deferred_get('verbosity', default=0)() == 1

    assert cliargs_deferred_get('somename', default=True)() is True

# Generated at 2022-06-24 18:39:13.631954
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # these tests are just to get code coverage on the function
    assert cliargs_deferred_get('abc') == cliargs_deferred_get('abc')
    assert cliargs_deferred_get('abc') is cliargs_deferred_get('abc')

# Generated at 2022-06-24 18:39:18.410397
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True
    # These calls are only needed for mypy. They don't work at runtime.
    test_case_0()


global_context_args = {
    'test': 'case',
    'so': 'much case',
    'case': 'so many cases',
}



# Generated at 2022-06-24 18:39:19.653878
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get == 'cliargs_deferred_get'

# Generated at 2022-06-24 18:39:20.180862
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert True

# Generated at 2022-06-24 18:39:30.289080
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    cli_args = {'a': 'b'}
    _init_global_context(cli_args)
    assert CLIARGS == cli_args
    assert cliargs_deferred_get('a') == 'b'
    assert cliargs_deferred_get('a', shallowcopy=True) == 'b'
    assert cliargs_deferred_get('b') is None
    assert cliargs_deferred_get('b', 'a') == 'a'
    assert cliargs_deferred_get('b', 'a', shallowcopy=True) == 'a'

    assert cliargs_deferred_get('b', [1, 2]) == [1, 2]

# Generated at 2022-06-24 18:39:32.564409
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)

    assert callable(var_0())


# Generated at 2022-06-24 18:39:33.584989
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert callable(cliargs_deferred_get)

# Generated at 2022-06-24 18:39:57.404125
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common import get_ansible_version
    from ansible.module_utils.six import PY3

    # Ensure we're running at least Ansible 2.0
    assert get_ansible_version() >= (2, 0)

    # Test with a variable type that's always the same in both Python 2 and 3
    # Also test that we're getting the non-singleton version of CliArgs back
    # instead of the singleton
    assert CLIARGS.__class__.__name__ == 'CLIArgs'

    inner_0 = cliargs_deferred_get('ANSIBLE_ROLES_PATH')
    assert inner_0.__class__.__name__ == 'function'

    # Test with a variable type that's a different type in Python 2 and 3

    # Test CliArgs.get with

# Generated at 2022-06-24 18:40:05.172564
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Input parameters for function
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    # Output from module function
    assert (var_0 == None)
    test_case_0()


if __name__ == "__main__":
    # Unit test begins
    import sys
    import json

    if len(sys.argv) < 2:
        print("This module is a library, it requires an argument to run the test cases:")
        print("\tpython {} <test-case-module>".format(sys.argv[0]))
        sys.exit(0)

    test_case_module = sys.argv[1]
    test_case_module = __import__(test_case_module)

# Generated at 2022-06-24 18:40:10.291744
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get()


if __name__ == '__main__':
    CLIARGS.update({'foo': 'bar'})
    test_case_0()
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:40:16.406665
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(0.01)
    cliargs_deferred_get(0.02)
    cliargs_deferred_get(0.03)
    cliargs_deferred_get(0.04)
    cliargs_deferred_get(0.05)
    cliargs_deferred_get(0.06)
    cliargs_deferred_get(0.07)
    cliargs_deferred_get(0.08)
    cliargs_deferred_get(0.09)
    cliargs_deferred_get(0.1)
    cliargs_deferred_get(0.11)
    cliargs_deferred_get(0.12)
    cliargs_deferred_get(0.13)
    cliargs

# Generated at 2022-06-24 18:40:19.162631
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(var_0)
    var_1 = cliargs_deferred_get(var_1)



# Generated at 2022-06-24 18:40:21.173178
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    out = cliargs_deferred_get(float_0)
    assert out == -519.6603


#test_case_0()

# Generated at 2022-06-24 18:40:25.366342
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert check_function_definition(test_case_0) == True


# Generated at 2022-06-24 18:40:33.569651
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    assert var_0() == -519.6603
    int_0 = -527
    var_1 = cliargs_deferred_get(int_0)
    assert var_1 == -527
    str_0 = '54.48.13.181'
    var_2 = cliargs_deferred_get(str_0)
    assert var_2 == '54.48.13.181'
    str_1 = '-0.656.80'
    var_3 = cliargs_deferred_get(str_1)
    assert var_3 == '-0.656.80'
    str_2 = '-213.2.89'
    var_4 = cl

# Generated at 2022-06-24 18:40:39.461061
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cliargs_deferred_get(float=float_0, var=var_0)
    assert var_0 == b'\x5a\x89\x79\x15\xd9\x62\xad{Y\xc2\x06\x8a\x80\x00\x00\x00\x8f\x08\xe6\x0e'

# Generated at 2022-06-24 18:40:41.229693
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get('some_key', default='some_value')
    assert var_0 is not None

# Generated at 2022-06-24 18:41:19.775391
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    pass

# Generated at 2022-06-24 18:41:20.919438
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    test_case_0()



# Generated at 2022-06-24 18:41:23.925623
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    # Test with a parameter
    assert cliargs_deferred_get("foo", "bar")() == "bar"

    # Test without a parameter
    assert cliargs_deferred_get("foo")() == None


# Generated at 2022-06-24 18:41:29.987735
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Get the current value of cliargs_deferred_get for unit tests
    old_value = cliargs_deferred_get
    try:
        # Setup test environment
        temp_var = 'fake'
        # Assert that the function behaves as expected
        assert test_case_0() == temp_var
    finally:
        # Teardown test environment
        del temp_var
        cliargs_deferred_get = old_value

# Generated at 2022-06-24 18:41:42.578805
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    try:
        cliargs_deferred_get
    except NameError:
        cliargs_deferred_get = str
    try:
        float_0
    except NameError:
        float_0 = 0.0

    cliargs_deferred_get('__dict__', default='__doc__')
    assert cliargs_deferred_get('__dict__', default='__doc__') == '__doc__'
    assert cliargs_deferred_get('__dict__', '__doc__') == '__doc__'
    assert cliargs_deferred_get('__dict__', default='__doc__') == '__doc__'
    assert cliargs_deferred_get('__dict__', '__doc__') == '__doc__'


# Generated at 2022-06-24 18:41:46.464310
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False
    # Test type
    assert isinstance(var_0, types.FunctionType)



# Generated at 2022-06-24 18:41:56.104893
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import tempfile, shutil
    from ansible.parsing.vault import VaultLib, VaultSecret, get_file_vault_secret, get_vault_secret
    from ansible.inventory.vault import VaultInventory, get_file_vault_password
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    import os
    import os.path
    import tempfile
    import shutil
    from ansible.cli import CLI
    from ansible.errors import AnsibleError, AnsibleConnectionFailure
    temp_cwd = tempfile.mkdtemp()
    os.chdir(temp_cwd)
    assert temp_cwd == os.getcwd()

# Generated at 2022-06-24 18:41:58.307820
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    expected = -519.6603
    actual = cliargs_deferred_get(expected)
    assert actual == expected



# Generated at 2022-06-24 18:42:01.311748
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # These tests are not testing the real value.  They are only testing whether or not the value
    # could be retrieved without an exception
    assert callable(cliargs_deferred_get)
    assert callable(cliargs_deferred_get(float(-519.6603), float(-519.6603), True))

# Generated at 2022-06-24 18:42:09.515628
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():

    assert callable(cliargs_deferred_get)

    float_0 = 'asdf'
    try:
        test_cliargs_deferred_get(float_0)
    except SystemExit:
        pass



# Generated at 2022-06-24 18:43:28.445605
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert var_0() == -519.6603

# Generated at 2022-06-24 18:43:29.069565
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 18:43:29.912045
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert False, "No tests for this function"

# Generated at 2022-06-24 18:43:37.334654
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    number_0 = -800
    var_0 = cliargs_deferred_get(number_0)
    assert CLIARGS.get(number_0) == var_0
    list_0 = [82, 'fhb.w', -841, 'jhO5Gt']
    list_0_copy = list_0[:]
    var_1 = cliargs_deferred_get(list_0, shallowcopy=True)
    assert var_1 == list_0_copy
    list_0[2] = -608
    assert var_1 == list_0_copy
    assert CLIARGS.get(list_0) == list_0

# Generated at 2022-06-24 18:43:47.347206
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-24 18:43:48.352012
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(var_0)
    var_0()


# Generated at 2022-06-24 18:43:51.855854
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    var_0 = cliargs_deferred_get(float_0)
    value = CLIARGS.get(key, default=default)
    if not shallowcopy:
        return value
    elif is_sequence(value):
        return value[:]
    elif isinstance(value, (Mapping, Set)):
        return value.copy()
    return value
    var_1 = inner()
    return var_1

# Generated at 2022-06-24 18:43:55.093152
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    _test_case_0(test_case_0)


# Generated at 2022-06-24 18:43:58.662978
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    print('Test: test_cliargs_deferred_get - start')
    test_case_0()
    print('Test: test_cliargs_deferred_get - done')

if __name__ == "__main__":
    test_cliargs_deferred_get()

# Generated at 2022-06-24 18:44:00.730587
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    float_0 = -519.6603
    var_0 = cliargs_deferred_get(float_0)
    assert var_0() == float_0

