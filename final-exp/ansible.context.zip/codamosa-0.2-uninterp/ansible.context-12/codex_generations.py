

# Generated at 2022-06-16 20:44:17.292409
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    from ansible.module_utils.common.collections import is_sequence

    # Test that it returns the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that it returns the value from CLIARGS
    _init_global_context({'foo': 'baz'})
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that it returns a shallow copy of the value from CLIARGS
    _init_global_context({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['bar', 'baz']
    assert cliargs_deferred

# Generated at 2022-06-16 20:44:25.367706
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_list
    from ansible.module_utils.common.validation import check_type_set
    from ansible.module_utils.common.validation import check_type_string
    from ansible.module_utils.common.validation import check_type_string_or_list
    from ansible.module_utils.common.validation import check_type_

# Generated at 2022-06-16 20:44:34.964083
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    @pytest.fixture
    def cliargs(request):
        """Create a CLIArgs object for the test"""
        cliargs = CLIArgs({})
        cliargs['foo'] = 'bar'
        cliargs['baz'] = [1, 2, 3]
        cliargs['qux'] = {'a': 'b'}
        cliargs['quux'] = {'a', 'b'}

# Generated at 2022-06-16 20:44:46.609304
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': set([1, 2, 3])})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('quux')() == set([1, 2, 3])
    assert cliargs_deferred_get('quuz')() is None
    assert cliargs_deferred_get

# Generated at 2022-06-16 20:44:56.600790
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIAR

# Generated at 2022-06-16 20:45:07.638722
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:45:16.734302
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    CLIARGS = CLI

# Generated at 2022-06-16 20:45:25.688812
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='foo')() == 'foo'

# Generated at 2022-06-16 20:45:36.577594
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    # Test that the closure works
    def test_closure(cli_args, key, default, shallowcopy, expected):
        global CLIARGS
        CLIARGS = CLIArgs(cli_args)

# Generated at 2022-06-16 20:45:48.203104
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=False)() == [1, 2, 3]
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})

# Generated at 2022-06-16 20:46:00.752918
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=False)() is CLIARGS['baz']

# Generated at 2022-06-16 20:46:12.582334
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:46:24.149543
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:46:34.151217
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': ['a', 'b', 'c']})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == ['a', 'b', 'c']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['a', 'b', 'c']
    assert cliargs_deferred_get('baz', shallowcopy=True)() != CLIARGS['baz']

# Generated at 2022-06-16 20:46:40.716510
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'
    assert cliargs_deferred_get('baz', default='qux', shallowcopy=True)() == 'qux'
    CLIARGS = CLI

# Generated at 2022-06-16 20:46:47.610693
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
    assert cl

# Generated at 2022-06-16 20:46:58.042850
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import copy
    from ansible.module_utils.common.collections import is_sequence

    def test_get(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()

    # Test that the function works with CLIARGS being replaced
    global CLIARGS
    old_cliargs = CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert test_get('foo') == 'bar'
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert test_get('foo') == 'baz'
    CLIARGS = old_cliargs

    # Test that the function works with the default
    assert test_get('foo', default='default') == 'bar'
    assert test_get

# Generated at 2022-06-16 20:47:07.527179
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 'b'}, 'quux': {1, 2, 3}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 'b'}
    assert cliargs_deferred_get('quux')() == {1, 2, 3}
    assert cliargs_deferred_get('not_there')() is None
    assert cliargs_deferred_get('not_there', 'default')() == 'default'
    assert cliargs_deferred

# Generated at 2022-06-16 20:47:13.165272
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}

# Generated at 2022-06-16 20:47:19.544622
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_list
    from ansible.module_utils.common.validation import check_type_set
    from ansible.module_utils.common.validation import check_type_string
    from ansible.module_utils.common.validation import check_type_string_or_list
    from ansible.module_utils.common.validation import check_type_string

# Generated at 2022-06-16 20:47:30.733002
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    def test_get_default(mocker):
        """Test that the default value is returned when the key is not present"""
        mocker.patch.object(CLIARGS, 'get', return_value=None)
        assert cliargs_deferred_get('key', default='default')() == 'default'

    def test_get_value(mocker):
        """Test that the value is returned when the key is present"""
        mocker.patch.object(CLIARGS, 'get', return_value='value')
        assert cliargs_deferred_get

# Generated at 2022-06-16 20:47:41.157179
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with no default
    cliargs = CLIArgs({'foo': 'bar'})
    get_foo = cliargs_deferred_get('foo')
    assert get_foo() == 'bar'

    # Test with default
    get_bar = cliargs_deferred_get('bar', default='baz')
    assert get_bar() == 'baz'

    # Test with shallow copy
    cliargs = CLIArgs({'foo': 'bar', 'baz': ['qux', 'quux']})
    get_foo = cliargs_deferred_get('foo', shallowcopy=True)
    get_baz = cliargs_deferred_get('baz', shallowcopy=True)
    assert get_foo() == 'bar'
    assert get_baz() == ['qux', 'quux']

# Generated at 2022-06-16 20:47:53.716760
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence

    # Test with no CLIARGS
    assert cliargs_deferred_get('foo')() is None

    # Test with CLIARGS
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test with CLIARGS and default
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'

    # Test with CLIARGS and shallowcopy
    CLIARGS['foo'] = 'bar'
    assert cliargs_def

# Generated at 2022-06-16 20:48:05.100128
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get

# Generated at 2022-06-16 20:48:13.273589
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4}, 'e': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4}
    assert cliargs_deferred_get('e')() == {1, 2, 3}
    assert cliargs_deferred_get('f')() is None
    assert cliargs_deferred_get('f', default=5)() == 5

    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cli

# Generated at 2022-06-16 20:48:24.483735
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that the closure works
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    # Test that the closure works with a different context object
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_

# Generated at 2022-06-16 20:48:36.417594
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:48:45.392677
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')

# Generated at 2022-06-16 20:48:48.910968
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', default='qux')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', default='qux', shallowcopy=True)() == ['bar', 'baz']

# Generated at 2022-06-16 20:48:58.411081
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that we can get a value from CLIARGS
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we can get a default value
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    # Test that we can get a shallow copy of a list
    CLIARGS['list'] = [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]

    # Test that we can get a shallow copy of a set
    CLIARGS['set'] = {1, 2, 3}
    assert cliargs_deferred_get('set', shallowcopy=True)() == {1, 2, 3}

   

# Generated at 2022-06-16 20:49:09.116785
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'
    assert cliargs_deferred_get('baz', default='qux', shallowcopy=True)() == 'qux'

    CLIARGS = CLI

# Generated at 2022-06-16 20:49:18.913302
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs

# Generated at 2022-06-16 20:49:29.684924
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    CLIARGS = CLI

# Generated at 2022-06-16 20:49:40.070627
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs(CLIArgs):
        def __init__(self, *args, **kwargs):
            super(TestCliArgs, self).__init__(*args, **kwargs)
            self.__dict__['test_key'] = 'test_value'

    global CLIARGS
    CLIARGS = TestCliArgs({})
    assert cliargs_deferred_get('test_key')() == 'test_value'
    assert cliargs_deferred_get('test_key', default='default_value')() == 'test_value'
    assert cliargs_deferred_get('test_key2', default='default_value')() == 'default_value'
    assert cliargs_deferred_get('test_key', shallowcopy=True)() == 'test_value'
    assert cli

# Generated at 2022-06-16 20:49:45.811228
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that we get the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that we get the value from CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that we get a shallow copy of the value
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:49:52.844251
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4}, 'e': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4}

# Generated at 2022-06-16 20:50:02.288544
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:50:13.707037
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text_if_native
    from ansible.module_utils.common.text.converters import to_bytes_if_text

# Generated at 2022-06-16 20:50:20.431904
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=protected-access
    # pylint: disable=unused-argument
    # pylint: disable=unused-variable
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list

# Generated at 2022-06-16 20:50:27.872050
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    # Test with a default value
    cliargs_deferred_get_default = cliargs_deferred_get('foo', default='bar')
    assert to_text(cliargs_deferred_get_default()) == 'bar'

    # Test with a value set
    CLIARGS['foo'] = 'baz'
    assert to_text(cliargs_deferred_get_default()) == 'baz'

    # Test with a value set and shallow copy
    cliargs_deferred_get_shallow_copy = cliargs_deferred_get('foo', shallowcopy=True)

# Generated at 2022-06-16 20:50:45.593752
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'

# Generated at 2022-06-16 20:50:57.256000
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:51:06.945911
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_bytes

    def _test_value(value, expected):
        """Test that cliargs_deferred_get returns the correct value"""
        _init_global_context(ImmutableDict(foo=value))
        assert cliargs_deferred_get('foo')() == expected
        assert cliargs_deferred_get('foo', shallowcopy=True)() == expected

    _test_value(None, None)
    _test_value(1, 1)
    _test_value('foo', 'foo')


# Generated at 2022-06-16 20:51:14.567453
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:51:25.723138
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

# Generated at 2022-06-16 20:51:40.727966
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']

# Generated at 2022-06-16 20:51:47.477362
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-import
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

# Generated at 2022-06-16 20:51:58.070216
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:52:08.301410
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # pylint: disable=protected-access
    def _init_global_context(cli_args):
        """Initialize the global context objects"""
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    def test_get_default():
        _init_global_context({})
        assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    def test_get_value():
        _init_global_context({'foo': 'baz'})
        assert cliargs_deferred_get('foo', default='bar')() == 'baz'


# Generated at 2022-06-16 20:52:19.647808
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cli

# Generated at 2022-06-16 20:52:38.896786
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'
    assert cliargs_deferred_get('baz', default='qux', shallowcopy=True)() == 'qux'

    # Test that the closure works when the global is replaced
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

# Generated at 2022-06-16 20:52:50.537446
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:52:54.854041
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_func(key, default, shallowcopy, expected):
        _init_global_context({})
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == expected

    test_func('foo', 'bar', False, 'bar')
    test_func('foo', 'bar', True, 'bar')
    test_func('foo', ['bar'], False, ['bar'])
    test_func('foo', ['bar'], True, ['bar'])
    test_func('foo', {'bar': 'baz'}, False, {'bar': 'baz'})
    test_func('foo', {'bar': 'baz'}, True, {'bar': 'baz'})
    test_func('foo', {'bar'}, False, {'bar'})
   

# Generated at 2022-06-16 20:53:05.145113
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None

# Generated at 2022-06-16 20:53:15.222834
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default if the key is not present
    assert cliargs_deferred_get('foo', default=1)() == 1

    # Test that the function returns the value if the key is present
    CLIARGS['foo'] = 2
    assert cliargs_deferred_get('foo', default=1)() == 2

    # Test that the function returns a shallow copy of the value if the key is present
    CLIARGS['foo'] = [1, 2, 3]
    assert cliargs_deferred_get('foo', default=1, shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', default=1, shallowcopy=True)() is not CLIARGS['foo']

    # Test that the function returns a shallow copy of the value if the key is

# Generated at 2022-06-16 20:53:25.802810
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    @pytest.fixture
    def cliargs(request):
        """Create a CLIArgs object for testing"""
        cliargs = CLIArgs({})
        request.addfinalizer(lambda: setattr(sys.modules[__name__], 'CLIARGS', cliargs))
        return cliargs

    def test_get_default(cliargs):
        """Test that we get the default value"""
        cliargs.update({'foo': 'bar'})
        assert cliargs_deferred_get('baz', default='baz')() == 'baz'


# Generated at 2022-06-16 20:53:34.874803
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLI

# Generated at 2022-06-16 20:53:45.793997
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that we can get a value from CLIARGS
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we can get a default value
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    # Test that we can get a shallow copy of a value
    CLIARGS['list'] = ['a', 'b', 'c']

# Generated at 2022-06-16 20:53:58.224799
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

# Generated at 2022-06-16 20:54:09.398656
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # pylint: disable=protected-access
    def _init_global_context(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    def cliargs_deferred_get(key, default=None, shallowcopy=False):
        def inner():
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value
            elif is_sequence(value):
                return value[:]