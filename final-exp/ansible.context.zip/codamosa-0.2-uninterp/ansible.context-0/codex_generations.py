

# Generated at 2022-06-16 20:44:17.365827
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    import copy
    from ansible.module_utils.common.collections import is_sequence

    # Test that it works with CLIARGS being a GlobalCLIArgs
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that it works with CLIARGS being a CLIArgs
    CLIARGS.update({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'

    # Test that it works with CLIARGS being a CLIArgs and the default being used
    CLIARGS.update({'foo': 'baz'})
    assert cliargs_deferred_get('bar', default='qux')() == 'qux'

# Generated at 2022-06-16 20:44:25.395461
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}


# Generated at 2022-06-16 20:44:34.998263
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    # Test the default value
    cliargs = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test the value from the cliargs
    cliargs = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test the shallow copy of a list

# Generated at 2022-06-16 20:44:46.656660
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    @pytest.fixture
    def cliargs(request):
        # pylint: disable=redefined-outer-name
        """Fixture to create a CLIArgs object with some values"""
        cliargs = CLIArgs({'foo': 'bar', 'baz': ['a', 'b', 'c'], 'qux': {'a': 'b', 'c': 'd'}})
        request.addfinalizer(lambda: setattr(__builtins__, 'CLIARGS', CLIARGS))

# Generated at 2022-06-16 20:44:56.634193
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:45:07.684491
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:45:16.799661
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # Test that we can get a value from the CLIARGS
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we can get a default value
    assert cliargs_deferred_get('bar')() == None
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'

    # Test that we can get a shallow copy of a value
    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-16 20:45:24.680124
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4}, 'e': {1, 2, 3}})

    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4}
    assert cliargs_deferred_get('e')() == {1, 2, 3}
    assert cliargs_deferred_get('f')() is None
    assert cliargs_deferred_get('f', default=5)() == 5


# Generated at 2022-06-16 20:45:31.457019
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:45:38.560945
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    def test_inner(key, default, shallowcopy, expected):
        """Test the inner function"""
        inner = cliargs_deferred_get(key, default, shallowcopy)
        assert inner() == expected

    # Test the inner function
    test_inner('foo', 'bar', False, 'bar')
    test_inner('foo', 'bar', True, 'bar')
    test_inner('foo', 'bar', False, 'bar')
    test_inner('foo', 'bar', True, 'bar')

    # Test the outer function
    CLIARGS['foo'] = 'baz'
    test_

# Generated at 2022-06-16 20:45:50.417744
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test default value
    _init_global_context({})
    assert cliargs_deferred_get('foo', default=42) == 42

    # Test value from CLIARGS
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default=42) == 'bar'

    # Test shallow copy
    _init_global_context({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo', shallowcopy=True) == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True) is not CLIARGS['foo']

    # Test shallow copy of non-sequence
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get

# Generated at 2022-06-16 20:46:00.518015
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:46:12.437205
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
   

# Generated at 2022-06-16 20:46:24.001157
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    # Test that we can get a value from CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we can get a default value from CLIARGS

# Generated at 2022-06-16 20:46:36.009566
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'
    assert cliargs_deferred_get('baz', default='qux', shallowcopy=True)() == 'qux'
    CLIARGS = CLI

# Generated at 2022-06-16 20:46:46.119111
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']

# Generated at 2022-06-16 20:46:57.728603
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test the default value
    cliargs = CLIArgs({})
    assert cliargs_deferred_get('foo')(), None

    # Test the default value with a shallow copy
    cliargs = CLIArgs({})
    assert cliargs_deferred_get('foo', shallowcopy=True)(), None

    # Test the default value with a shallow copy
    cliargs = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)(), 'bar'

    # Test the default value with a shallow copy
    cliargs = CLIArgs({})

# Generated at 2022-06-16 20:47:07.370804
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs

    # Test that the default is returned when the key is not present
    cliargs = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the value is returned when the key is present
    cliargs = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the default is returned when the key is present but the value is None
    cliargs = CLI

# Generated at 2022-06-16 20:47:13.079702
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    def test_closure():
        cliargs_deferred_get('foo')()

    # Test that the closure works when the global is replaced
    def test_closure_with_global_replaced():
        global CLIARGS
        CLIARGS = CLIArgs({'foo': 'bar'})
        cliargs_deferred_get('foo')()

    # Test that the closure works when the global is replaced
    def test_closure_with_global_replaced_and_key_missing():
        global CLIARGS
        CLIARGS = CLIArgs({})
        cliargs_deferred_get('foo', default='bar')()

    # Test that the closure works when the global is replaced

# Generated at 2022-06-16 20:47:17.458675
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    # Test that the function works with CLIARGS being a GlobalCLIArgs
    #

# Generated at 2022-06-16 20:47:30.759896
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:47:41.158551
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    def test_closure():
        # pylint: disable=unused-variable
        # pylint: disable=cell-var-from-loop
        for key in ('foo', 'bar', 'baz'):
            assert cliargs_deferred_get(key)() is None

    # Test that the closure works with a default
    def test_closure_with_default():
        # pylint: disable=unused-variable
        # pylint: disable=cell-var-from-loop
        for key in ('foo', 'bar', 'baz'):
            assert cliargs_deferred_get(key, default='default')() == 'default'

    # Test that the closure works with a default and shallow copy

# Generated at 2022-06-16 20:47:53.716767
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}

# Generated at 2022-06-16 20:48:05.131206
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']

# Generated at 2022-06-16 20:48:13.294927
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with CLIARGS being a CLIArgs object
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS.update({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']
    CLIARGS.update({'foo': {'bar': 'baz'}})

# Generated at 2022-06-16 20:48:24.483466
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test the default value
    default = 'default'
    assert cliargs_deferred_get('key', default=default)() == default

    # Test the default value with shallow copy
    default = ['default']
    assert cliargs_deferred_get('key', default=default, shallowcopy=True)() == default
    assert cliargs_deferred_get('key', default=default, shallowcopy=True)() is not default

    # Test the default value with shallow copy
    default = {'default': 'default'}

# Generated at 2022-06-16 20:48:36.417666
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    def _test_cliargs_deferred_get(key, default, shallowcopy, expected):
        """Test that cliargs_deferred_get returns the correct value"""
        global CLIARGS
        CLIARGS = CLIArgs({'test': 'value'})
        assert cliargs_deferred_get(key, default, shallowcopy)() == expected

    _test_cliargs_deferred_get('test', 'default', False, 'value')
    _test_cliargs_deferred_get('test', 'default', True, 'value')
    _test_cliargs_deferred_get('test2', 'default', False, 'default')
    _test_cliargs_deferred_get('test2', 'default', True, 'default')
    _

# Generated at 2022-06-16 20:48:45.388616
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function works with a non-singleton CLIARGS
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    # Test that the function works with a singleton CLIARGS
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

# Generated at 2022-06-16 20:48:55.095061
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs

    # Test that it returns the default value
    cli_args = CLIArgs({})
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    # Test that it returns the value from CLIARGS
    cli_args = CLIArgs({'foo': 'baz'})
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo', 'bar')() == 'baz'

    # Test that

# Generated at 2022-06-16 20:49:01.779211
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default value when the key is not present
    assert cliargs_deferred_get('not_a_key', default='default_value')() == 'default_value'

    # Test that the function returns the value when the key is present
    CLIARGS['key'] = 'value'
    assert cliargs_deferred_get('key', default='default_value')() == 'value'

    # Test that the function returns a shallow copy of the value when the key is present and shallowcopy is True
    CLIARGS['key'] = ['value']
    assert cliargs_deferred_get('key', default='default_value', shallowcopy=True)() == ['value']

# Generated at 2022-06-16 20:49:20.443320
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    import copy
    import sys

    # pylint: disable=unused-variable
    def _test_deferred_get(key, default, shallowcopy, expected):
        """Test that cliargs_deferred_get returns the expected value"""
        # pylint: disable=protected-access
        # pylint: disable=no-member
        # pylint: disable=unused-variable
        # pylint: disable=redefined-outer-name
        # pylint: disable=redefined-variable

# Generated at 2022-06-16 20:49:31.230132
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # Test that the function returns the default if the key is not present
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value if the key is present
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that the function returns a shallow copy of the value if the key is present
    # and shallowcopy is True
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
   

# Generated at 2022-06-16 20:49:41.012878
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True, default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True, default='baz')() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:49:50.854584
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('quux')() == {1, 2, 3}
    assert cliargs_deferred_get('quuz')() is None
    assert cliargs_deferred_get('quuz', default='quuz')() == 'quuz'
   

# Generated at 2022-06-16 20:50:01.429982
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS
    CLIARGS = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = GlobalCLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = GlobalCLIArgs({'foo': {'bar': 'baz'}})

# Generated at 2022-06-16 20:50:13.208400
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    # pylint: disable=protected-access
    # We need to access the _data attribute to set up the test
    CLIARGS._data = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('baz', 'baz')() == 'baz'
    assert cliargs_deferred_get('baz', 'baz', shallowcopy=True)() == 'baz'
    CLIARGS._data = {'foo': ['bar']}
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get

# Generated at 2022-06-16 20:50:22.655058
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:50:34.162743
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]

# Generated at 2022-06-16 20:50:43.114143
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']

# Generated at 2022-06-16 20:50:47.753354
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS
    CLIARGS = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = Global

# Generated at 2022-06-16 20:51:13.947231
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_bytes_or_string
    from ansible.module_utils.common.text.converters import to_text_or_bytes
    from ansible.module_utils.common.text.converters import to_bytes_or_unicode

# Generated at 2022-06-16 20:51:20.020455
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'
    assert cliargs_deferred_get('baz', default='qux', shallowcopy=True)() == 'qux'
    CLIARGS = CLI

# Generated at 2022-06-16 20:51:39.251139
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the function works with the global CLIARGS
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the function works with a different CLIARGS
    cliargs = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')(cliargs=cliargs) == 'bar'

    # Test that the function works with a different CLIARGS and a default
    cliargs = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_

# Generated at 2022-06-16 20:51:51.289937
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4}, 'e': set([1, 2, 3])})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4}
    assert cliargs_deferred_get('e')() == set([1, 2, 3])
    assert cliargs_deferred_get('f')() is None
    assert cliargs_deferred_get('f', default=5)() == 5

    assert cliargs_deferred_get('a', shallowcopy=True)() == 1

# Generated at 2022-06-16 20:52:02.505568
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=too-few-public-methods
    class TestClass(object):
        """Test class for cliargs_deferred_get"""
        def __init__(self, value):
            self.value = value

    # Test that the default is returned if the key is not in the CLIARGS
    assert cliargs_deferred_get('not_a_key', default='default')() == 'default'

    # Test that the value is returned if the key is in the CLIARGS
    CLIARGS['key'] = 'value'
    assert cliargs_deferred_get('key', default='default')() == 'value'

    # Test that the value is returned if the key is in the CLIARGS and there is no default
    CLIARGS

# Generated at 2022-06-16 20:52:10.796489
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 20:52:21.535919
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']

    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}

# Generated at 2022-06-16 20:52:31.553201
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    import copy
    import sys

    # Test that we get the default value if the key is not present
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    # Test that we get the value if the key is present
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', 'bar')() == 'baz'

    # Test that we get the default value if the key is present but None
    CLIARGS

# Generated at 2022-06-16 20:52:40.721274
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:52:52.401661
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that we get the default
    CLIARGS.clear()
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that we get the value
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    # Test that we get the default when the value is None
    CLIARGS['foo'] = None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that we get the default when the value is False
    CLIARGS['foo'] = False
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that we get the value when the value is False

# Generated at 2022-06-16 20:53:37.146977
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs

    def test_get(key, default=None, shallowcopy=False):
        """Test the get function"""
        value = CLIARGS.get(key, default=default)
        if not shallowcopy:
            return value
        elif is_sequence(value):
            return value[:]
        elif isinstance(value, (Mapping, Set)):
            return value.copy()
        return value

    # Test that the function returns the same value as the CLIARGS.get function
   

# Generated at 2022-06-16 20:53:42.011638
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:53:46.830768
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    assert cliargs_deferred_get('foo')() is None

    # Test that the closure works with CLIARGS being replaced
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the closure works with CLIARGS being replaced
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']

    # Test that the closure works with CLIARGS being replaced
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}

   

# Generated at 2022-06-16 20:53:59.338633
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:54:10.326117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default when the key is not present
    assert cliargs_deferred_get('not_present', default=True)() is True
    # Test that the function returns the value when the key is present
    CLIARGS['present'] = True
    assert cliargs_deferred_get('present', default=False)() is True
    # Test that the function returns a shallow copy of the value when the key is present and shallowcopy is True
    CLIARGS['present'] = [1, 2, 3]
    assert cliargs_deferred_get('present', default=False, shallowcopy=True)() == [1, 2, 3]
    # Test that the function returns a shallow copy of the value when the key is present and shallowcopy is True