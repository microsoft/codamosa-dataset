

# Generated at 2022-06-16 20:44:15.621199
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the closure works with CLIARGS being replaced
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the closure works with CLIARGS being replaced with a different object
    class TestCliArgs(object):
        def get(self, key, default=None):
            return 'baz'
    CLIARGS = TestCliArgs()
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the closure works with CLIARGS being replaced with a different object
    # that doesn't have

# Generated at 2022-06-16 20:44:24.801935
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']

# Generated at 2022-06-16 20:44:34.481165
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'quux': {'a': 'b'}})

    # Test getting a value
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('quux')() == {'a': 'b'}

    # Test getting a value with a default
    assert cliargs_deferred_get('foo', default='quux')() == 'bar'
    assert cliargs_deferred_get('baz', default='quux')() == [1, 2, 3]
   

# Generated at 2022-06-16 20:44:46.420602
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:44:56.461429
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    def _test_closure(key, default=None, shallowcopy=False):
        value = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()
        assert value == default
        return value

    # Test that the closure works with CLIARGS being replaced
    def _test_closure_with_replaced_cliargs(key, default=None, shallowcopy=False):
        global CLIARGS
        old_cliargs = CLIARGS
        CLIARGS = CLIArgs({})
        value = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()
        assert value == default
        CLIARGS = old_cliargs
        return value

    # Test that the closure works with CLIARGS being replaced

# Generated at 2022-06-16 20:45:07.471956
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def test_get(key, default, shallowcopy, expected):
        """Test the get function"""
        # pylint: disable=protected-access
        cliargs = CLIArgs({key: expected})
        getter = cliargs_deferred_get(key, default, shallowcopy)
        assert getter() == expected
        if shallowcopy:
            if is_sequence(expected):
                assert getter() is not expected
            elif isinstance(expected, (Mapping, Set)):
                assert getter() is not expected
        else:
            assert getter() is expected


# Generated at 2022-06-16 20:45:16.550956
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    # Test with a default value
    default_value = to_text(u'foo')
    default_value_func = cliargs_deferred_get('foo', default=default_value)
    assert default_value == default_value_func()

    # Test with a value that is not a shallow copy
    cli_args = ImmutableDict({'foo': to_text(u'bar')})
    _init_global_context(cli_args)
    value = cliargs_deferred_get('foo')()
    assert value == to_text(u'bar')

    # Test with a

# Generated at 2022-06-16 20:45:20.592286
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def test_get(key, default, shallowcopy, expected):
        """Test that the closure returns the expected value"""
        value = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()
        assert value == expected

    # Test that the closure returns the default value
    test_get('foo', 'bar', False, 'bar')
    test_get('foo', 'bar', True, 'bar')

    # Test that the closure returns the value from CLIARGS
    CLIARGS['foo'] = 'baz'

# Generated at 2022-06-16 20:45:27.716746
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    import copy

    # Test that the function returns the default when the key is not present
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value when the key is present
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that the function returns the

# Generated at 2022-06-16 20:45:37.616798
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins

    # Test that we can get the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that we can get a value from CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that we can get a value

# Generated at 2022-06-16 20:45:50.147597
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.six import PY3
    import pytest

    class GlobalCLIArgs(dict):
        """A class that mimics the GlobalCLIArgs class"""
        def __init__(self, *args, **kwargs):
            super

# Generated at 2022-06-16 20:46:00.314106
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works with a non-singleton
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() is None
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'

    # Test that it works with a singleton
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:46:12.284452
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    # pylint: disable=redefined-builtin
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip

# Generated at 2022-06-16 20:46:23.886446
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:46:35.932237
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    def test_get(key, default, shallowcopy, expected):
        """Test function cliargs_deferred_get"""
        # pylint: disable=unused-argument
        # pylint: disable=protected-access
        # pylint: disable=no-member
        # pylint: disable=unsubscriptable-object
        # pylint: disable=unsupported-membership-test
        # pylint: disable=unsupported-assignment-operation
        # pylint: disable=unsupported-delete-operation
        # pylint: disable=unsupported-not-implemented-operation
        # pylint: disable=unsupported-unary-operation
        # pylint:

# Generated at 2022-06-16 20:46:46.118777
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get

# Generated at 2022-06-16 20:46:57.729111
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    CLIARGS = CLI

# Generated at 2022-06-16 20:47:07.371180
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict, ImmutableList, ImmutableSet
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import format_value
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_native
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.formatters import to_unicode

# Generated at 2022-06-16 20:47:16.041233
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)

# Generated at 2022-06-16 20:47:27.810480
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'


# Generated at 2022-06-16 20:47:41.790594
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default value when CLIARGS is empty
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value when CLIARGS is not empty
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that the function returns the default value when CLIARGS is not empty but the key is not present
    assert cliargs_deferred_get('foo2', default='baz')() == 'baz'

    # Test that the function returns a shallow copy of the value when shallowcopy is True
    CLIARGS['foo'] = ['bar', 'baz']

# Generated at 2022-06-16 20:47:54.279865
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import string_types

# Generated at 2022-06-16 20:48:05.463256
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}

# Generated at 2022-06-16 20:48:16.012973
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the function returns the value from CLIARGS
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the function returns the default value when the key is not in CLIARGS
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    # Test that the function returns a shallow copy of the value when shallowcopy=True
    CLIARGS['list'] = [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]
    assert cliargs

# Generated at 2022-06-16 20:48:25.930407
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    # Test that the function returns the default if the key is not set
    assert cliargs_deferred_get('not_a_key', default='default')() == 'default'

    # Test that the function returns the value if the key is set
    CLIARGS['key'] = 'value'
    assert cliargs_deferred_get('key')() == 'value'

    # Test that the function returns the value if the key is set and the default is None
    CLIARGS['key'] = 'value'
    assert cliargs_deferred_get('key', default=None)() == 'value'

# Generated at 2022-06-16 20:48:36.695226
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    # Test that the function returns the default value when the key is not present
    cliargs = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value when the key is present
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that the function

# Generated at 2022-06-16 20:48:45.573930
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that we can get a value from CLIARGS
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we can get a default value
    assert cliargs_deferred_get('nonexistent', default='baz')() == 'baz'

    # Test that we can get a shallow copy of a list
    CLIARGS['list'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('list', shallowcopy=True)() == ['a', 'b', 'c']

    # Test that we can get a shallow copy of a dict
    CLIARGS['dict'] = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 20:48:51.426774
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})

# Generated at 2022-06-16 20:49:00.266915
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default value if the key is not present
    assert cliargs_deferred_get('not_present')(None) is None
    assert cliargs_deferred_get('not_present', default='default')(None) == 'default'

    # Test that the function returns the value if the key is present
    CLIARGS['present'] = 'value'
    assert cliargs_deferred_get('present')(None) == 'value'
    assert cliargs_deferred_get('present', default='default')(None) == 'value'

    # Test that the function returns a shallow copy of the value if the key is present
    # and shallowcopy is True
    CLIARGS['present'] = ['value']

# Generated at 2022-06-16 20:49:08.089351
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:49:24.441517
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:49:29.080115
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # Test that it works with a default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that it works with a value in the dict
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    # Test that it works with a shallow copy
    CLIARGS['foo'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['a', 'b', 'c']
    # Test that it works with a deep copy
    CLIARGS['foo'] = ['a', 'b', 'c']

# Generated at 2022-06-16 20:49:39.814245
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs

    cli_args = CLIArgs({'a': 'b', 'c': [1, 2, 3], 'd': {'e': 'f'}, 'g': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('c')() == [1, 2, 3]
    assert cliargs_deferred_get('d')() == {'e': 'f'}
    assert cliargs_deferred_get('g')() == {1, 2, 3}
    assert cliargs_deferred

# Generated at 2022-06-16 20:49:50.259449
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text_if_native
    from ansible.module_utils.common.text.converters import to_bytes_if_native
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-16 20:50:01.211753
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works when CLIARGS is a GlobalCLIArgs
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='foo')() == 'foo'
    assert cliargs_

# Generated at 2022-06-16 20:50:13.021722
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'b'})
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('a', default='c')() == 'b'
    assert cliargs_deferred_get('b', default='c')() == 'c'
    assert cliargs_deferred_get('b', default='c', shallowcopy=True)() == 'c'
    assert cliargs_deferred_get('b', default=['c'], shallowcopy=True)() == ['c']
    assert cliargs_deferred_get('b', default=['c'], shallowcopy=False)() == ['c']
    assert cliargs_deferred

# Generated at 2022-06-16 20:50:22.475385
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_dict
    from ansible.module_utils.common.text.converters import to_bytes_or_string_or_unicode
    from ansible.module_utils.common.text.converters import to_text_or_bytes

# Generated at 2022-06-16 20:50:34.004959
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test that we get the default value back
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that we get the value back
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that we get the default value back
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'

    # Test that we get the value back
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we get the shallow

# Generated at 2022-06-16 20:50:42.963164
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    import copy
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test that the closure works
    def test_closure():
        """Test that the closure works"""
        cliargs_deferred_get('foo')()

    with pytest.raises(AttributeError):
        test_closure()

    # Test that the closure works with a real CLIArgs object
    def test_closure_with_cliargs():
        """Test that the closure works with a real CLIArgs object"""
        global CLIARGS
        CLIARGS = CLIArgs({'foo': 'bar'})
        assert cliargs_deferred_get('foo')() == 'bar'

    test_closure_with_cliargs()

    # Test that the closure works with

# Generated at 2022-06-16 20:50:55.161433
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_inner(key, default, shallowcopy, expected):
        """Test that cliargs_deferred_get works as expected"""
        global CLIARGS
        CLIARGS = CLIArgs({key: expected})
        assert cliargs_deferred_get(key, default, shallowcopy)() == expected

    # Test with no default
    test_inner('foo', None, False, 'bar')
    # Test with default
    test_inner('foo', 'baz', False, 'bar')
    # Test with no default and shallow copy
    test_inner('foo', None, True, 'bar')
    # Test with default and shallow copy
   

# Generated at 2022-06-16 20:51:18.790500
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works with a default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that it works with a value in the dict
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that it works with a shallow copy
    CLIARGS['foo'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['a', 'b', 'c']

    # Test that it works with a shallow copy of a mapping
    CLIARGS['foo'] = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 20:51:40.120440
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=protected-access
    cli_args = {'foo': 'bar', 'baz': [1, 2, 3]}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not CLIARGS._cache['baz']
    assert cliargs_deferred_get('baz', shallowcopy=False)() is CLIARGS._cache['baz']

# Generated at 2022-06-16 20:51:52.030074
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'

# Generated at 2022-06-16 20:52:03.312414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default value when the key is not present
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value when the key is present
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that the function returns the default value when the key is present but
    # the value is None
    CLIARGS['foo'] = None
    assert cliargs_deferred_get('foo', default='baz')() == 'baz'

    # Test that the function returns a shallow copy of the value when the key is present
    # and the value is a list
    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_

# Generated at 2022-06-16 20:52:11.254778
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    @pytest.fixture
    def cli_args():
        return {'foo': 'bar', 'baz': 'qux'}

    @pytest.fixture
    def cli_args_obj(cli_args):
        return CLIArgs(cli_args)

    @pytest.fixture
    def global_cli_args_obj(cli_args):
        return GlobalCLIArgs.from_options(cli_args)


# Generated at 2022-06-16 20:52:22.110196
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_inner(mocker, monkeypatch):
        """Test the inner function"""
        # pylint: disable=unused-variable
        # pylint: disable=unused-argument
        # pylint: disable=redefined-outer-name
        # pylint: disable=redefined-builtin
        # pylint: disable=protected-access
        # pylint: disable=too-many-locals
        # pylint: disable=too-many-statements
        # pylint: disable=too-many-branches
        # pylint: disable=too-many-nested-blocks
        # pylint:

# Generated at 2022-06-16 20:52:31.966267
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    # Test that the function works with a non-singleton CLIARGS
    cli_args = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the function works with a singleton CLIARGS

# Generated at 2022-06-16 20:52:41.067048
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:52:52.487299
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}

# Generated at 2022-06-16 20:53:04.420753
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=protected-access
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    # Test that the function works when the CLIARGS is a CLIArgs object
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs

# Generated at 2022-06-16 20:53:47.965714
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs(CLIArgs):
        def __init__(self, *args, **kwargs):
            super(TestCliArgs, self).__init__(*args, **kwargs)
            self.set('foo', 'bar')

    global CLIARGS
    CLIARGS = TestCliArgs({})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    CLIARGS = TestCliArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'

# Generated at 2022-06-16 20:53:59.958087
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'

# Generated at 2022-06-16 20:54:10.868880
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import format_value
    from ansible.module_utils.common.text.utils import to_bytes
    from ansible.module_utils.common.validation import check_type_str
    from ansible.module_utils.six import PY3

    # Test that we can get a value from CLIARGS
    CLIARGS.set('foo', 'bar')
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we can get a default value from CLIARGS
    assert cl