

# Generated at 2022-06-16 20:44:11.400690
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def _test_value(value, shallowcopy=False):
        # pylint: disable=redefined-outer-name
        CLIARGS.set('test', value)
        assert cliargs_deferred_get('test', shallowcopy=shallowcopy)() == value

    CLIARGS.set('test', 'foo')
    assert cliargs_deferred_get('test')() == 'foo'
    assert cliargs_deferred_get('test', default='bar')() == 'foo'
    assert cliargs_deferred_get('test', default='bar', shallowcopy=True)()

# Generated at 2022-06-16 20:44:20.392534
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def test_get(key, default=None, shallowcopy=False):
        """Closure over getting a key from CLIARGS with shallow copy functionality"""
        def inner():
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value
            elif is_sequence(value):
                return value[:]

# Generated at 2022-06-16 20:44:27.164874
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils.six.moves import builtins
    import ansible.module_utils.six.moves.urllib.parse as urlparse
    import ansible.module_utils.six.moves

# Generated at 2022-06-16 20:44:35.933752
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'

# Generated at 2022-06-16 20:44:47.250291
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works with the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that it works with CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that it works with shallow copy
    CLIARGS['foo'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']

    # Test that it works with shallow copy of a dict
    CLIARGS['foo'] = {'a': 'b'}
   

# Generated at 2022-06-16 20:44:56.952461
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-16 20:45:01.077340
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-import
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-import
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-wildcard-import
    # p

# Generated at 2022-06-16 20:45:10.908727
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:45:16.065768
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 'b'}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 'b'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('qux', shallowcopy=True)()

# Generated at 2022-06-16 20:45:23.462050
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 'b'}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 'b'}

    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:45:36.547626
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 'b'}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 'b'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:45:48.204728
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

# Generated at 2022-06-16 20:45:58.801822
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    # Test with a non-singleton CLIArgs
    cli_args = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar', shallowcopy=True)() is None
    assert cli

# Generated at 2022-06-16 20:46:10.488970
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip

# Generated at 2022-06-16 20:46:17.176675
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:46:25.664200
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with a default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test with a value in the CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    # Test with a shallow copy
    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['bar']
    # Test with a deep copy
    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=False)() == ['bar']

# Generated at 2022-06-16 20:46:36.600468
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs

    # Test that the closure works
    def test_closure(value):
        def inner():
            return value
        return inner

    assert test_closure(1)() == 1

    # Test that the closure works with a class
    class TestClass(object):
        def __init__(self, value):
            self.value = value
        def __call__(self):
            return self.value

    assert TestClass(1)() == 1

    # Test that the closure works with a class that is a singleton
    class TestSingleton(object):
        def __init__(self, value):
            self.value = value
        def __call__(self):
            return self.value

    TestSingleton = Test

# Generated at 2022-06-16 20:46:46.144273
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works with a default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that it works with a value in the dict
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that it works with a shallow copy
    CLIARGS['foo'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['a', 'b', 'c']

    # Test that it works with a shallow copy of a dict
    CLIARGS['foo'] = {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 20:46:57.727583
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:47:07.371750
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    import pytest
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    @pytest.fixture
    def cli_args():
        return {'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}}

    @pytest.fixture
    def cliargs(cli_args):
        return CLIArgs(cli_args)


# Generated at 2022-06-16 20:47:18.438934
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    @pytest.fixture
    def cli_args():
        return {'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}}

    @pytest.fixture
    def cli_args_copy(cli_args):
        return cli_args.copy()

    def test_get_value(cli_args, cli_args_copy):
        global CLIARGS
        CLIARGS = CLIArgs(cli_args)
        assert cliargs_deferred_get('foo')() == 'bar'
        assert cliargs_deferred

# Generated at 2022-06-16 20:47:28.822142
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    @pytest.fixture
    def cliargs():
        """Create a CLIArgs object for testing"""
        return CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 1, 'e': 2}, 'f': {1, 2, 3}})

    def test_default(cliargs):
        """Test that the default value is returned when the key is not present"""
        assert cliargs_deferred_get('g')(cliargs) is None
        assert cliargs_deferred_get('g', default=1)(cliargs) == 1


# Generated at 2022-06-16 20:47:39.698192
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.utils import to_native
    from ansible.module_utils.six import PY3

    # Test that we get the default value
    default_value = 'default'
    assert cliargs_deferred_get('key', default=default_value)() == default_value

    # Test that we get the value from the CLIARGS
    cli_args = ImmutableDict({'key': 'value'})
    _init_global_context(cli_args)


# Generated at 2022-06-16 20:47:52.400915
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('baz', 'baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': ['baz']})
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['baz']
    assert cliargs_deferred_get('baz', shallowcopy=False)() == ['baz']

# Generated at 2022-06-16 20:48:03.489053
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 'b'}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 'b'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:48:12.438749
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'

# Generated at 2022-06-16 20:48:18.373321
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=protected-access
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    @pytest.fixture
    def cli_args():
        return {'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}}


# Generated at 2022-06-16 20:48:26.280934
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:48:36.870770
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text

    # Test default
    assert cliargs_deferred_get('foo')() is None

    # Test shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() is None

    # Test shallow copy with a value
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    # Test shallow copy with a list
    CLIARGS['foo'] = ['bar', 'baz']
    assert cl

# Generated at 2022-06-16 20:48:45.668109
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import GlobalCLIArgs

    # Test that the default is returned if the key is not found
    cli_args = GlobalCLIArgs({})
    assert cliargs_deferred_get('foo', default=42)() == 42

    # Test that the value is returned if the key is found
    cli_args = GlobalCLIArgs({'foo': 42})
    assert cliargs_deferred_get('foo', default=43)() == 42

    # Test that the value is returned if the key is found and the default is None

# Generated at 2022-06-16 20:49:01.935627
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    # Test that the function returns the correct value
    CLIARGS.update(dict(foo='bar', baz=dict(qux='quux')))
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == dict(qux='quux')

    # Test that the function returns the default value
    assert cliargs_deferred_get('does_not_exist')() is None


# Generated at 2022-06-16 20:49:08.762724
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:49:18.664171
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with no args
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test with args
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test with shallow copy
    CLIARGS.update({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']

    CLIARGS.update

# Generated at 2022-06-16 20:49:29.487840
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get
    from ansible.utils.context_objects import _init_global_context
    from ansible.utils.context_objects import CLIARGS

    # Test that the function works with the global CLIARGS
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the function works with a local CLIARGS
    cli_args = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')(cli_args) == 'bar'

    # Test that the function works with a local GlobalCLIArgs

# Generated at 2022-06-16 20:49:39.979590
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIAR

# Generated at 2022-06-16 20:49:50.328096
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}


# Generated at 2022-06-16 20:50:01.244385
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    def _test_shallowcopy(value, expected_type):
        """Test that the shallowcopy works as expected"""
        cliargs_deferred_get_value = cliargs_deferred_get('key', default=value, shallowcopy=True)
        assert isinstance(cliargs_deferred_get_value, expected_type)
        assert cliargs_deferred_get_value is not value

    def _test_no_shallowcopy(value, expected_type):
        """Test that the shallowcopy works as expected"""
        cliargs_deferred_get_value = cliargs_def

# Generated at 2022-06-16 20:50:13.058342
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:50:19.925689
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:50:27.588548
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    @pytest.fixture
    def cliargs_deferred_get_fixture():
        """Fixture for cliargs_deferred_get"""
        # pylint: disable=redefined-outer-name
        from ansible.utils.context_objects import CLIArgs
        from ansible.utils.context import cliargs_deferred_get
        cli_args = CLIArgs({'foo': 'bar', 'baz': {'a': 'b'}, 'qux': ['a', 'b']})
        return cliargs_deferred_get, cli_args


# Generated at 2022-06-16 20:50:55.821828
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'

# Generated at 2022-06-16 20:51:07.377456
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)

# Generated at 2022-06-16 20:51:15.029682
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default value when the key is not set
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value when the key is set
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the function returns a shallow copy of the value when the key is set
    CLIARGS['foo'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() is not CLIARGS['foo']

    # Test that

# Generated at 2022-06-16 20:51:26.161645
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 1, 'e': 2}, 'f': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 1, 'e': 2}
    assert cliargs_deferred_get('f')() == {1, 2, 3}
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2, 3]
    assert cli

# Generated at 2022-06-16 20:51:46.956503
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cli

# Generated at 2022-06-16 20:51:57.520333
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the value is returned as is
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the value is shallow copied
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS['foo'] = ['bar']

# Generated at 2022-06-16 20:52:07.950818
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value from CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the function returns a shallow copy of the value from CLIARGS
    CLIARGS['foo'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['a', 'b', 'c']
    CLIARGS['foo'].append('d')

# Generated at 2022-06-16 20:52:19.997833
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    # Test with a default value
    cliargs = CLIArgs({'foo': 'bar'})
    getter = cliargs_deferred_get('foo', default='baz')
    assert getter() == 'bar'
    getter = cliargs_deferred_get('bar', default='baz')
    assert getter() == 'baz'

    # Test with shallow copy
    cliargs = CLIArgs({'foo': 'bar'})
   

# Generated at 2022-06-16 20:52:25.469609
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function works with a non-singleton
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the function works with a singleton
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

# Generated at 2022-06-16 20:52:35.149272
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'
    assert cliargs_deferred_get('baz', default='qux', shallowcopy=True)() == 'qux'
    CLIARGS = CLI

# Generated at 2022-06-16 20:53:16.699498
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    assert cliargs_deferred_get('foo')() is None

    # Test that the closure works with a default
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the closure works with a shallow copy
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default=['bar'], shallowcopy=True)() == ['bar']
    assert cliargs_deferred_get('foo', default={'bar': 'baz'}, shallowcopy=True)() == {'bar': 'baz'}

# Generated at 2022-06-16 20:53:26.782876
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'

# Generated at 2022-06-16 20:53:32.836261
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    @pytest.fixture
    def cliargs():
        """Fixture to create a CLIArgs object"""
        return CLIArgs({'foo': 'bar', 'baz': ['qux', 'quux'], 'corge': {'grault': 'garply'}})

    @pytest.fixture
    def cliargs_default():
        """Fixture to create a CLIArgs object with a default"""

# Generated at 2022-06-16 20:53:43.918915
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the default case
    assert cliargs_deferred_get('foo')() is None

    # Test the default case with a default
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test the default case with a default that is a list
    assert cliargs_deferred_get('foo', default=['bar'])() == ['bar']

    # Test the default case with a default that is a list and shallowcopy
    assert cliargs_deferred_get('foo', default=['bar'], shallowcopy=True)() == ['bar']

    # Test the default case with a default that is a dict
    assert cliargs_deferred_get('foo', default={'bar': 'baz'})() == {'bar': 'baz'}

    # Test the default case with

# Generated at 2022-06-16 20:53:50.773275
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:54:02.082498
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    cliargs_deferred_get('foo')()

    # Test that the closure works when CLIARGS is replaced
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the closure works when CLIARGS is replaced
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the closure works when CLIARGS is replaced
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the closure works when CLIARGS is replaced