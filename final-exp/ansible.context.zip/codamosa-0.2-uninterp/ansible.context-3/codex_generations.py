

# Generated at 2022-06-16 20:44:11.281701
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.context_objects import CLIArgs, GlobalCLIArgs

    @pytest.fixture
    def cli_args():
        return {'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}}

    @pytest.fixture
    def cli_args_obj(cli_args):
        return CLIArgs(cli_args)

    @pytest.fixture
    def cli_args_global_obj(cli_args):
        return Global

# Generated at 2022-06-16 20:44:20.333236
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that we can get a value from CLIARGS
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we can get a default value from CLIARGS
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    # Test that we can get a value from CLIARGS with a shallow copy
    CLIARGS['foo'] = ImmutableDict({'bar': 'baz'})

# Generated at 2022-06-16 20:44:27.139893
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:44:35.904284
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-import
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    # Test that the function works with CLIARGS

# Generated at 2022-06-16 20:44:47.253237
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with no default
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=False)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=False)() == 'bar'

    # Test with default
    assert cliargs_deferred_get('bar')() is None
    assert cli

# Generated at 2022-06-16 20:44:56.952650
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import GlobalCLIArgs

    # Test that the function works with a non-singleton CLIARGS
    cli_args = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None

# Generated at 2022-06-16 20:45:07.938028
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def _init_global_context(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    def _test_get(key, default, shallowcopy, expected):
        _init_global_context({})
        getter = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
        assert getter() == expected


# Generated at 2022-06-16 20:45:16.992815
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:45:25.790891
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # Test that we can get the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that we can get a value from the CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that we can get a value from the CLIARGS and shallow copy it
    CLIARGS['foo'] = 'baz'
    assert cliargs

# Generated at 2022-06-16 20:45:36.638197
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'


# Generated at 2022-06-16 20:45:49.630299
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_func(mocker, cli_args):
        """Test function"""
        # pylint: disable=unused-variable
        # pylint: disable=unused-import
        from ansible.utils.context_objects import CLIArgs
        # pylint: enable=unused-variable
        # pylint: enable=unused-import
        global CLIARGS
        CLIARGS = CLIArgs(cli_args)

        def check_value(key, value):
            """Check that the value is correct"""
            assert cliargs_deferred_get(key)() == value

# Generated at 2022-06-16 20:45:59.909279
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    # Test with a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:46:12.024807
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4}, 'e': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4}
    assert cliargs_deferred_get('e')() == {1, 2, 3}
    assert cliargs_deferred_get('f')() is None
    assert cliargs_deferred_get('f', default=5)() == 5

    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cli

# Generated at 2022-06-16 20:46:22.558405
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it returns the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that it returns the value in CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that it returns a shallow copy of the value in CLIARGS
    CLIARGS['foo'] = ['baz']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['baz']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() is not CLIARGS['foo']

# Generated at 2022-06-16 20:46:29.337545
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']

# Generated at 2022-06-16 20:46:38.662734
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-argument
    def _init_global_context(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    # Test that the closure works
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the closure works with the global being replaced
    _init_global_context({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'

    # Test that the closure works with the global being replaced
    _init_global_context({'foo': 'baz'})

# Generated at 2022-06-16 20:46:46.778789
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    class TestCliArgs(object):
        def __init__(self, d):
            self.d = d

        def get(self, key, default=None):
            return self.d.get(key, default)

    def test_get_default():
        cliargs = TestCliArgs({})
        assert cliargs_deferred_get('foo')(cliargs) is None

    def test_get_default_with_default():
        cliargs = TestCliArgs({})
        assert cliargs_deferred_get('foo', default='bar')(cliargs) == 'bar'

    def test_get_value():
        cliargs = TestCliArgs({'foo': 'bar'})
        assert cliargs_deferred_get('foo')(cliargs) == 'bar'


# Generated at 2022-06-16 20:46:58.007784
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the closure works
    def _test_closure(value):
        def _inner():
            return value
        return _inner

    _test_closure_value = _test_closure(1)
    assert _test_closure_value() == 1

    # Test that the closure works with a sequence
    def _test_closure_seq(value):
        def _inner():
            return value
        return _inner

    _test_closure_seq_value = _test_closure_seq([1, 2, 3])
    assert _test_closure_seq_value() == [1, 2, 3]

    # Test that the closure works with a mapping

# Generated at 2022-06-16 20:47:07.502543
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that the cliargs_deferred_get function works"""
    # pylint: disable=redefined-outer-name
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('quux')() == {1, 2, 3}

# Generated at 2022-06-16 20:47:16.132271
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test with no default
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=False)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

# Generated at 2022-06-16 20:47:29.882715
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:47:40.704878
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

    # Test that the default is returned if the key is not set
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the value is returned if the key is set
    CLIARGS['foo'] = 'bar'

# Generated at 2022-06-16 20:47:53.265246
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4}, 'e': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4}
    assert cliargs_deferred_get('e')() == {1, 2, 3}
    assert cliargs_deferred_get('f')() is None
    assert cliargs_deferred_get('f', default=5)() == 5

# Generated at 2022-06-16 20:48:04.117443
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default when the key is not present
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value when the key is present
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the function returns the default when the key is present but None
    CLIARGS['foo'] = None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns a shallow copy of the value when the key is present
    CLIARGS['foo'] = ['a', 'b', 'c']

# Generated at 2022-06-16 20:48:12.843982
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    def test_closure(value):
        def inner():
            return value
        return inner

    assert test_closure(1)() == 1
    assert test_closure(2)() == 2

    # Test that the closure works with the function
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('baz', 'baz')() == 'baz'
    assert cliargs_deferred_get('baz', 'baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:48:24.271626
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.utils.context_objects import CLIArgs
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that it works with a default value
    cliargs = CLIArgs({})
    cliargs['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'

    # Test that it works with a default value and shallow copy
    cliargs['foo'] = ['bar']

# Generated at 2022-06-16 20:48:36.284681
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that we get the default if the key is not in CLIARGS
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that we get the value from CLIARGS if the key is in CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that we get a shallow copy of the value if shallowcopy is True
    CLIARGS['foo'] = ['a', 'b', 'c']
    assert cliargs_def

# Generated at 2022-06-16 20:48:45.319030
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the function returns the default when there is no CLIARGS
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the default when there is no key in CLIARGS
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value when there is a key in CLIARGS
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get

# Generated at 2022-06-16 20:48:55.041924
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text_if_native
    from ansible.module_utils.common.text.converters import to

# Generated at 2022-06-16 20:49:02.688931
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS.update({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']

# Generated at 2022-06-16 20:49:20.406930
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the function returns the default value if the key is not in the CLIARGS
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    # Test that the function returns the value if the key is in the CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', 'bar')() == 'baz'

    # Test that the function returns a shallow copy of the value if the key is in the CLIARGS
    # and shallowcopy is True


# Generated at 2022-06-16 20:49:31.188277
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    def test_closure(value):
        def inner():
            return value
        return inner

    assert test_closure(1)() == 1

    # Test that the closure works with CLIARGS
    def test_cliargs_closure(value):
        def inner():
            return CLIARGS.get('foo', default=value)
        return inner

    # Test that the closure works with CLIARGS
    def test_cliargs_deferred_closure(value):
        def inner():
            return cliargs_deferred_get('foo', default=value)()
        return inner

    # Test that the closure works with CLIARGS

# Generated at 2022-06-16 20:49:40.991472
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    CLIARGS = CLI

# Generated at 2022-06-16 20:49:50.854301
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that it works with CLIARGS being a CLIArgs object
    CLIARGS.update({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs

# Generated at 2022-06-16 20:50:01.429423
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.utils.context_objects import CLIArgs

    # Test that the function works with CLIARGS being replaced
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() is None

    # Test that the function works with CLIARGS being replaced
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the function works with CLIARGS being replaced

# Generated at 2022-06-16 20:50:13.208315
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    @pytest.fixture
    def cliargs():
        """Create a CLIArgs object for testing"""
        return CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 'b'}})

    def test_get(cliargs):
        """Test getting a value from the CLIArgs object"""
        assert cliargs_deferred_get('foo')() == 'bar'
        assert cliargs_deferred_get('baz')() == [1, 2, 3]

# Generated at 2022-06-16 20:50:22.650760
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True, default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True, default='baz')() == 'baz'

# Generated at 2022-06-16 20:50:34.152414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=False)()

# Generated at 2022-06-16 20:50:43.082559
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:50:55.298750
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=True)() != CLIARGS['baz']
    assert cliargs_

# Generated at 2022-06-16 20:51:24.012899
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_func(key, default, shallowcopy, expected):
        """Helper function to test the cliargs_deferred_get function"""
        def inner():
            """Closure over the test_func function"""
            return cliargs_deferred_get(key, default, shallowcopy)()
        return inner

    # Test with no default
    def test_no_default():
        """Test with no default"""
        return cliargs_deferred_get('foo')()
    assert test_no_default() is None

    # Test with default
    def test_default():
        """Test with default"""

# Generated at 2022-06-16 20:51:39.233715
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_inner(key, default, shallowcopy, expected):
        """Test the inner function"""
        # pylint: disable=protected-access
        CLIARGS._options = {key: 'value'}
        inner = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
        assert inner() == expected

    test_inner('key', 'default', False, 'value')
    test_inner('key', 'default', True, 'value')
    test_inner('key2', 'default', False, 'default')
    test_inner('key2', 'default', True, 'default')

# Generated at 2022-06-16 20:51:51.378349
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import format
    from ansible.module_utils.common.text.formatters import format_value
    from ansible.module_utils.common.text.formatters import jsonify
    from ansible.module_utils.common.text.formatters import safe_dump
    from ansible.module_utils.common.text.formatters import safe_load

# Generated at 2022-06-16 20:52:02.615780
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import boolean
    from ansible.module_utils.common.text.formatters import to_bool
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_float
    from ansible.module_utils.common.text.formatters import to

# Generated at 2022-06-16 20:52:10.884348
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    def test_closure(value):
        def inner():
            return value
        return inner

    assert test_closure(1)() == 1
    assert test_closure('foo')() == 'foo'

    # Test that the function works
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    # Test that the shallow copy works
    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    assert cliargs_deferred_

# Generated at 2022-06-16 20:52:21.535795
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works with the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that it works with a value in the dict
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    # Test that it works with a value in the dict and shallowcopy=True
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'baz'
    CLIARGS['foo'] = ['baz']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['baz']

# Generated at 2022-06-16 20:52:31.553306
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the function returns the default value if CLIARGS is not set
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the default value if the key is not set
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value if the key is set
    CLIARGS = CLIArgs({'foo': 'baz'})

# Generated at 2022-06-16 20:52:40.722330
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    import pytest
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    # Test that the function works with a non-singleton CLIArgs
    cli_args = CLIArgs({})
    cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function works with a singleton CLIArgs

# Generated at 2022-06-16 20:52:47.309827
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function works with a non-singleton CLIARGS
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:52:55.351194
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo', default='qux')() == 'baz'
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='qux')() == 'qux'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})

# Generated at 2022-06-16 20:53:36.825601
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-outer-name
    # pylint: disable=red

# Generated at 2022-06-16 20:53:47.292027
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def test_get(key, default=None, shallowcopy=False):
        """Closure over getting a key from CLIARGS with shallow copy functionality

        Primarily used in ``FieldAttribute`` where we need to defer setting the default
        until after the CLI arguments have been parsed

        This function is not directly bound to ``CliArgs`` so that it works with
        ``CLIARGS`` being replaced
        """
        def inner():
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value
            elif is_sequence(value):
                return value[:]
            el

# Generated at 2022-06-16 20:53:59.877521
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    # pylint: disable=redefined-builtin
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import PY3, binary_type, string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import quote