

# Generated at 2022-06-16 20:44:12.781802
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    import copy
    import pytest

    # Test that the function returns the default value if the key is not set
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    # Test that the function returns the value if the key is set
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', 'bar')() == 'baz'

    # Test that the function returns a shallow copy of the value if shallowcopy is set
    CLIARGS['foo'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', 'bar', shallowcopy=True)() == ['a', 'b', 'c']

# Generated at 2022-06-16 20:44:21.738866
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    def test_get(key, default=None, shallowcopy=False):
        """Closure over getting a key from CLIARGS with shallow copy functionality

        Primarily used in ``FieldAttribute`` where we need to defer setting the default
        until after the CLI arguments have been parsed

        This function is not directly bound to ``CliArgs`` so that it works with
        ``CLIARGS`` being replaced
        """
        value = CLIARGS.get(key, default=default)
        if not shallowcopy:
            return value
        elif is_sequence(value):
            return value[:]
        elif isinstance(value, (Mapping, Set)):
            return value.copy()
        return value

    # pylint: disable=protected-access

# Generated at 2022-06-16 20:44:27.882267
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-16 20:44:36.261929
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:44:47.598718
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': 'qux'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == 'qux'
    assert cliargs_deferred_get('quux')() is None
    assert cliargs_deferred_get('quux', default='quuz')() == 'quuz'

    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']

# Generated at 2022-06-16 20:44:57.209936
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test with no default
    def_get = cliargs_deferred_get('foo')
    assert def_get() is None

    # Test with default
    def_get = cliargs_deferred_get('foo', default='bar')
    assert def_get() == 'bar'

    # Test with shallow copy
    def_get = cliargs_deferred_get('foo', default='bar', shallowcopy=True)
    assert def_get() == 'bar'

    # Test with shallow copy of list
    def_get = cl

# Generated at 2022-06-16 20:45:01.817856
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins

    # Test with a default value
    default = 'default'
    assert cliargs_deferred_get('key', default=default)() == default

    # Test with a value in CLIARGS
    value = 'value'
    CLIARGS['key'] = value
    assert cliargs_deferred_get('key')() == value

    # Test with a value in CLIARGS and a default value
    assert cliargs_deferred_get('key', default=default)

# Generated at 2022-06-16 20:45:11.420885
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=False)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'bar': 'baz'}
    assert cliargs_deferred_get('foo', shallowcopy=False)() == {'bar': 'baz'}


# Generated at 2022-06-16 20:45:22.736503
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_inner(mocker, cli_args, key, default, shallowcopy, expected):
        """Test the inner function"""
        global CLIARGS
        CLIARGS = CLIArgs(cli_args)
        inner = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
        assert inner() == expected

    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_outer(mocker, cli_args, key, default, shallowcopy, expected):
        """Test the outer function"""
        global CLIARGS
        CLIARGS = CLIArgs(cli_args)
        assert cliargs_deferred

# Generated at 2022-06-16 20:45:35.310373
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:45:48.795465
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct values"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_inner(key, default, shallowcopy, expected):
        """Inner function to test cliargs_deferred_get"""
        global CLIARGS
        CLIARGS = CLIArgs({'key': 'value'})
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == expected

    test_inner('key', None, False, 'value')
    test_inner('key', None, True, 'value')
    test_inner('key', 'default', False, 'value')
    test_inner('key', 'default', True, 'value')

# Generated at 2022-06-16 20:45:59.277513
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:46:11.413514
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:46:22.931414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    def _test_value(value, shallowcopy=False):
        """Test that cliargs_deferred_get returns the correct value"""
        global CLIARGS
        CLIARGS = CLIArgs({'foo': value})
        assert cliargs_deferred_get('foo', shallowcopy=shallowcopy)() == value

    def _test_value_copy(value):
        """Test that cliargs_deferred_get returns a copy of the value"""
        global CLIARGS
        CLIARGS = CLIArgs({'foo': value})

# Generated at 2022-06-16 20:46:29.541373
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test with no default
    cliargs_deferred_get_no_default = cliargs_deferred_get('foo')
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get_no_default() == 'bar'
    del CLIARGS['foo']
    assert cliargs_deferred_get_no_default() is None

    # Test with default
    cliargs_deferred_get_with_default = cliargs_deferred_get('foo', default='baz')

# Generated at 2022-06-16 20:46:38.763732
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the closure works with the global CLIARGS being replaced
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'

    # Test that the closure works with a default value
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'

    # Test that the closure works with a default value and the global CLIARGS being replaced
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_

# Generated at 2022-06-16 20:46:46.819631
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    import pytest

    @pytest.fixture
    def cliargs(mocker):
        cliargs = CLIArgs({})
        cliargs._options = {'foo': 'bar'}
        return cliargs

    def test_get_value_from_cliargs(cliargs):
        getter = cliargs_deferred_get('foo')
        assert getter() == 'bar'

    def test_get_value_from_cliargs_with_default(cliargs):
        getter = cliargs_deferred_get('bar', default='baz')
        assert getter() == 'baz'


# Generated at 2022-06-16 20:46:58.007692
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    # Test that the default is returned if the key is not set
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that the value is returned if the key is set
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    # Test that the value is returned if the key is set and there is no default
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo')() == 'baz'
    # Test that the value is returned if the key is set and there is no default
    # and the value is a list
    CLIARGS['foo'] = ['baz']

# Generated at 2022-06-16 20:47:07.499583
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the function returns the default when the key is not present
    default = 'default'
    assert cliargs_deferred_get('missing', default=default)() == default

    # Test that the function returns the value when the key is present
    value = 'value'
    CLIARGS['key'] = value
    assert cliargs_deferred_get('key')() == value

    # Test that the function returns a shallow copy of the value when the key is present
    # and shallowcopy=True
    value = ['value']


# Generated at 2022-06-16 20:47:16.103883
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar', shallowcopy=True)() is None
    assert cliargs_deferred_get('bar', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_

# Generated at 2022-06-16 20:47:28.711081
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the closure works
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'

    # Test that the closure works with a default
    assert cliargs_deferred_get('baz')() is None

# Generated at 2022-06-16 20:47:39.614740
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import quote as urlquote

# Generated at 2022-06-16 20:47:52.303289
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': ['qux', 'quux']})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == ['qux', 'quux']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['qux', 'quux']
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == CLIARGS['baz']

# Generated at 2022-06-16 20:48:03.342291
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_func(key, default, shallowcopy, expected):
        """Test function for cliargs_deferred_get"""
        def inner():
            """Closure over getting a key from CLIARGS with shallow copy functionality"""
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value
            elif is_sequence(value):
                return value[:]
            elif isinstance(value, (Mapping, Set)):
                return value.copy()
            return value
        return inner

    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    #

# Generated at 2022-06-16 20:48:12.305942
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None

# Generated at 2022-06-16 20:48:18.309213
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:48:26.254251
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs

    cli_args = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs

# Generated at 2022-06-16 20:48:36.841765
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:48:45.668092
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence

    # Test that the closure works
    def test_closure(key, default, shallowcopy, expected):
        """Test that the closure works"""
        cliargs_deferred_get(key, default, shallowcopy)() == expected

    # Test that the closure works with a default value
    test_closure('foo', 'bar', False, 'bar')

    # Test that the closure works with a default value and shallow copy
    test_closure('foo', 'bar', True, 'bar')

    # Test that the closure works with a default value and shallow copy
    test_closure('foo', 'bar', True, 'bar')

    # Test that the closure works with a default value and shallow copy

# Generated at 2022-06-16 20:48:51.096539
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'b'})
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('a', default='c')() == 'b'
    assert cliargs_deferred_get('b', default='c')() == 'c'
    assert cliargs_deferred_get('b', default='c', shallowcopy=True)() == 'c'
    assert cliargs_deferred_get('a', shallowcopy=True)() == 'b'
    CLIARGS = CLIArgs({'a': [1, 2, 3]})
    assert cliargs_deferred_get('a')() == [1, 2, 3]

# Generated at 2022-06-16 20:49:01.687346
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works with a non-singleton CLIARGS
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    assert cliargs_deferred_get('bar', default='baz', shallowcopy=True)() == 'baz'

    # Test that it works with a singleton CLIARGS
    _init_global_context({'foo': 'bar'})

# Generated at 2022-06-16 20:49:08.668947
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-variable
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice

# Generated at 2022-06-16 20:49:18.580829
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence

    def test_get(key, default=None, shallowcopy=False):
        """Closure over getting a key from CLIARGS with shallow copy functionality"""
        def inner():
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value
            elif is_sequence(value):
                return value[:]
            elif isinstance(value, (Mapping, Set)):
                return value.copy()
            return value
        return inner

    # Test that the function returns the default value if the key is not present
    CLIARGS = CLIArgs({})
    assert test_get('foo', default='bar')() == 'bar'

    # Test that the function returns

# Generated at 2022-06-16 20:49:25.775499
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

# Generated at 2022-06-16 20:49:38.294998
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3]})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() is None
    assert cliargs_deferred_get('c', default=1)() == 1
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('c', shallowcopy=True)() is None

# Generated at 2022-06-16 20:49:49.856882
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=protected-access
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    def test_func(key, default, shallowcopy, expected):
        """Test the cliargs_deferred_get function"""
        global CLIARGS
        CLIARGS = CLIArgs({})
        assert cliargs_deferred_get(key, default, shallowcopy)() == expected
        CLIARGS = GlobalCLIArgs.from_options({})

# Generated at 2022-06-16 20:50:00.955898
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:50:12.824259
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test with no CLIARGS
    # pylint: disable=global-statement
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo', default=['bar'])() == ['bar']

    # Test with CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cli

# Generated at 2022-06-16 20:50:22.288816
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable,expression-not-assigned
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    @pytest.fixture
    def cli_args():
        return {'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 'b'}, 'quux': {1, 2, 3}}


# Generated at 2022-06-16 20:50:33.849414
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text

    # Test that the closure works
    def test_closure(key, default, shallowcopy, expected):
        value = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()
        assert value == expected

    # Test that the closure works with the global CLIARGS
    def test_global_closure(key, default, shallowcopy, expected):
        global CLIARGS
        CLIARGS = CLIArgs({})
        test_closure(key, default, shallowcopy, expected)

    # Test that the closure works with a local CLIARGS

# Generated at 2022-06-16 20:50:48.876824
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import GlobalCLIArgs

    # Test that the closure works
    def _test_closure(key, value, shallowcopy):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options({key: value})
        assert cliargs_deferred_get(key, shallowcopy=shallowcopy)() == value

    # Test that the closure works with a list
    _test_closure('list', [1, 2, 3], False)
    _test_closure('list', [1, 2, 3], True)

    # Test that the closure works with a set

# Generated at 2022-06-16 20:50:58.507371
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:51:07.951183
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS['foo'] = {'bar': 'baz'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'bar': 'baz'}

# Generated at 2022-06-16 20:51:15.009471
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:51:32.832294
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # Test that it returns the default when the key is not present
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that it returns the default when the key is present but empty
    CLIARGS['foo'] = ''
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that it returns the value when the key is present and not empty
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    # Test that it returns a shallow copy of the value when the key is present and not empty
    CLIARGS['foo'] = ['baz']
    assert cliargs_deferred_

# Generated at 2022-06-16 20:51:37.180848
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='quux')() == 'quux'

# Generated at 2022-06-16 20:51:45.169991
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cli

# Generated at 2022-06-16 20:51:56.270463
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}

# Generated at 2022-06-16 20:52:07.134303
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct values"""
    cli_args = {'foo': 'bar', 'baz': ['qux', 'quux']}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == ['qux', 'quux']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['qux', 'quux']
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not cliargs_deferred_get('baz')()

# Generated at 2022-06-16 20:52:18.454603
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=False)() is CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=False)() is CLIARGS['baz']
    assert cliargs_

# Generated at 2022-06-16 20:52:32.864283
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_

# Generated at 2022-06-16 20:52:41.771907
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with a simple value
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    # Test with a list
    CLIARGS['foo'] = ['bar', 'baz']
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', default='baz')() == ['bar', 'baz']
    assert cliargs_deferred_

# Generated at 2022-06-16 20:52:52.649598
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get

# Generated at 2022-06-16 20:53:04.515450
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

# Generated at 2022-06-16 20:53:14.734916
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:53:25.356928
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    cli_args = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]

# Generated at 2022-06-16 20:53:34.617877
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    # Test that the function works when CLIARGS is a GlobalCLIArgs
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    # Test that the function works when CLIARGS is a CLIArgs
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred

# Generated at 2022-06-16 20:53:45.585622
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs

    # Test that the function returns the default value when the key is not in the dict
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('baz')(), None
    assert cliargs_deferred_get('baz', default='qux')(), 'qux'

    # Test that the function returns the value when the key is in the dict
    assert cliargs_deferred_get('foo')(), 'bar'

# Generated at 2022-06-16 20:53:57.902475
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the default is returned if the key is not found
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the default is returned if the key is not found
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the value is returned if the key is found
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the value is returned if the key is found
   

# Generated at 2022-06-16 20:54:05.667573
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_text
    from ansible.module_utils.common.text.formatters import to_nice_path