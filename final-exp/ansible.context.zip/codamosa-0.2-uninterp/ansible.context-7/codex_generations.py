

# Generated at 2022-06-16 20:44:15.574179
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # Test that we get the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that we get the value from CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that we get a shallow copy of the value
    CLIARGS['foo'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['a', 'b', 'c']

    # Test that we get a shallow copy of the value
    CLIARGS['foo'] = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 20:44:24.766619
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=invalid-name
    # pylint: disable=missing-docstring
    # pylint: disable=no-self-use
    # pylint: disable=too-few-public-methods

    class TestCliArgs(object):
        def __init__(self, data):
            self.data = data

        def get(self, key, default=None):
            return self.data.get(key, default)

    class TestGlobalCliArgs(object):
        def __init__(self, data):
            self.data = data


# Generated at 2022-06-16 20:44:34.442916
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the closure works
    def test_closure(value):
        """Test that the closure works"""
        cliargs_deferred_get('foo', default=value)()

    test_closure(1)
    test_closure('foo')
    test_closure(['foo'])
    test_closure({'foo': 'bar'})
    test_closure(set('foo'))

    # Test that the closure returns the default value

# Generated at 2022-06-16 20:44:46.319084
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('baz', 'baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:44:56.389100
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:45:07.423055
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:45:16.516146
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
   

# Generated at 2022-06-16 20:45:23.901822
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence

    # Test the default value
    _init_global_context({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test the default value with shallow copy
    _init_global_context({})
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'

    # Test the default value with shallow copy
    _init_global_context({})
    assert cliargs_deferred_get('foo', default=['bar'], shallowcopy=True)() == ['bar']

    # Test the default value with shallow copy
    _init_global_context({})
    assert cliargs_deferred

# Generated at 2022-06-16 20:45:35.825760
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # Test that we get the default value when the key is not in CLIARGS
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    # Test that we get the value from CLIARGS when the key is in CLIARGS
    CLIARGS._options['foo'] = 'baz'
    assert cliargs_deferred_get('foo', 'bar')() == 'baz'
    # Test that we get a shallow copy of the value from CLIARGS when the key is in CLIARGS
    CLIARGS._options['foo'] = ['baz']
    assert cliargs_deferred_get('foo', 'bar', shallowcopy=True)() == ['baz']
    # Test that we get a shallow copy of the value from CLIARGS when the key

# Generated at 2022-06-16 20:45:47.370808
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:45:59.948954
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo')() == [1, 2, 3]
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
   

# Generated at 2022-06-16 20:46:10.268462
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:46:17.062756
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # Test the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test the default value with shallow copy
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'

    # Test the default value with shallow copy of a list
    assert cliargs_deferred_get('foo', default=['bar'], shallowcopy=True)() == ['bar']

    # Test the default value with shallow copy of a dict
    assert cliargs_deferred_get('foo', default={'bar': 'baz'}, shallowcopy=True)() == {'bar': 'baz'}

    # Test the default value with shallow copy of a set
    assert cliargs_def

# Generated at 2022-06-16 20:46:26.114186
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # Test that the default is returned
    default = object()
    assert cliargs_deferred_get('foo', default=default)() is default

    # Test that the default is returned when the key is not present
    assert cliargs_deferred_get('foo')() is None

    # Test that the value is returned when the key is present
    value = object()
    CLIARGS['foo'] = value
    assert cliargs_deferred_get('foo')() is value

    # Test that the value is returned when

# Generated at 2022-06-16 20:46:36.903041
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test that the closure works
    def test_closure(key, default, shallowcopy, expected):
        """Test that the closure works"""
        def inner():
            """Inner function to test the closure"""
            value = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()
            assert value == expected
        inner()

    test_closure('foo', 'bar', False, 'bar')
    test_closure('foo', 'bar', True, 'bar')
    test_closure('foo', 'bar', False, 'bar')
    test_closure('foo', 'bar', True, 'bar')

# Generated at 2022-06-16 20:46:46.269138
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:46:57.852389
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='foo')() == 'foo'

# Generated at 2022-06-16 20:47:07.400170
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # pylint: disable=unused-variable
    def test_get(key, default, shallowcopy, expected):
        # pylint: disable=unused-variable
        def inner():
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value
            elif is_sequence(value):
                return value[:]
            elif isinstance(value, (Mapping, Set)):
                return value.copy()
            return value
        return inner

    # pylint: disable=unused-variable

# Generated at 2022-06-16 20:47:13.101393
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cli

# Generated at 2022-06-16 20:47:17.480040
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:47:30.553012
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=protected-access
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.context_objects import GlobalCLIArgs
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes

    # Test the function with CLIARGS being a GlobalCLIArgs object
    # pylint

# Generated at 2022-06-16 20:47:40.775200
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:47:53.307715
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args._data['foo'] == 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='foo')() == 'foo'

# Generated at 2022-06-16 20:48:04.146368
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_bytes_or_unicode
    from ansible.module_utils.common.text.converters import to_text_or_bytes

# Generated at 2022-06-16 20:48:12.870874
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    @pytest.fixture
    def cliargs_mock(mocker):
        """Mock the CLIARGS object"""
        cliargs_mock = mocker.MagicMock()
        cliargs_mock.get.return_value = 'test'
        return cliargs_mock

    def test_get(cliargs_mock):
        """Test the get functionality"""
        global CLIARGS
        CLIARGS = cliargs_mock
        assert cliargs_deferred_get('key')() == 'test'
        cliargs_mock.get.assert_called

# Generated at 2022-06-16 20:48:24.311131
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with CLIARGS being a GlobalCLIArgs
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('baz', default=['baz'])() == ['baz']

# Generated at 2022-06-16 20:48:36.287322
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'


# Generated at 2022-06-16 20:48:48.019349
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('quux')() == {1, 2, 3}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_

# Generated at 2022-06-16 20:48:57.671253
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_

# Generated at 2022-06-16 20:49:06.715341
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    # pylint: disable=protected-access
    # We need to access the _options dict directly to test this
    CLIARGS._options['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS._options['foo'] = ['bar', 'baz']
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_

# Generated at 2022-06-16 20:49:23.654052
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence

    # pylint: disable=protected-access
    CLIARGS._options = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    CLIARGS._options = {'foo': ['bar', 'baz']}

# Generated at 2022-06-16 20:49:36.000600
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    def _test_get(key, default, shallowcopy, expected):
        """Test that the closure returns the expected value"""
        # pylint: disable=protected-access
        assert CLIARGS._options == {}
        assert CLIARGS._defaults == {}
        assert CLIARGS._default_getters == {}
        assert CLIARGS._default_getters_shallowcopy == {}

        # pylint: disable=unused-variable
        getter = cliargs_deferred_get(key, default, shallowcopy)
        assert CLIARGS._default_getters == {key: getter}

# Generated at 2022-06-16 20:49:42.912625
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=protected-access
    import pytest

    # Test that the function returns the default if the key is not set
    def test_default(mocker):
        """Test that the function returns the default if the key is not set"""
        mocker.patch.object(CLIARGS, 'get', return_value=None)
        assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value if the key is set

# Generated at 2022-06-16 20:49:51.787117
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with CLIARGS as a CLIArgs object
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    # Test with CLIARGS as a GlobalCLIArgs object
    CLIARGS.update({'foo': 'bar'})

# Generated at 2022-06-16 20:50:01.866042
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that we can get a value from CLIARGS
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we can get a default value
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    # Test that we can get a shallow copy of a list
    CLIARGS['list'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('list', shallowcopy=True)() == ['a', 'b', 'c']
    assert cliargs_deferred_get('list', shallowcopy=True)() is not CLIARGS['list']

    # Test that we can get a shallow copy of a set

# Generated at 2022-06-16 20:50:13.522250
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']

# Generated at 2022-06-16 20:50:20.308545
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=False)() == ['bar', 'baz']

# Generated at 2022-06-16 20:50:27.425629
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    assert cliargs_deferred_get('foo')() is None
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS['foo'] = {'bar': 'baz'}
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'bar': 'baz'}

# Generated at 2022-06-16 20:50:36.718689
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:50:48.934016
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})

# Generated at 2022-06-16 20:51:14.912966
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=protected-access
    # pylint: disable=no-member
    # pylint: disable=unused-import
    # pylint: disable=import-error
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    def _init_global_context(cli_args):
        """Initialize the global context objects"""
        global CLIARGS
        CLIARGS = Global

# Generated at 2022-06-16 20:51:40.829780
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4}, 'e': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4}
    assert cliargs_deferred_get('e')() == {1, 2, 3}
    assert cliargs_deferred_get('f')() is None
    assert cliargs_deferred_get('f', default=5)() == 5
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cli

# Generated at 2022-06-16 20:51:47.549322
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import GlobalCLIArgs

    # Test that the default value is returned when the key is not present
    default_value = 'default'
    cli_args = ImmutableDict()
    _init_global_context(cli_args)
    assert default_value == cliargs_deferred_get('key', default=default_value)()

   

# Generated at 2022-06-16 20:51:58.123140
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    import copy
    import random

    def test_value(value):
        """Test that the value is returned correctly"""
        # Test that the value is returned correctly
        assert value == CLIARGS.get('foo')
        # Test that the value is not a shallow copy
        assert value is CLIARGS.get('foo')
        # Test that the value is a shallow copy
        assert value == cliargs_deferred_get('foo', shallowcopy=True)()
        # Test that the value is a shallow copy
        assert value is not cliargs_deferred_get('foo', shallowcopy=True)()


# Generated at 2022-06-16 20:52:08.344747
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_

# Generated at 2022-06-16 20:52:19.691212
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:52:29.073771
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins

    # Test that we can get a value from CLIARGS
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo') == 'bar'

    # Test that we can get a default value
    assert cliargs_deferred_get('baz', default='qux') == 'qux'

    # Test that we can get a

# Generated at 2022-06-16 20:52:38.692747
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']

# Generated at 2022-06-16 20:52:45.390505
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

# Generated at 2022-06-16 20:52:54.430886
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='foo')() == 'foo'

# Generated at 2022-06-16 20:53:37.409462
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_bytes_or_unicode_or_raw

# Generated at 2022-06-16 20:53:47.365818
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the function returns the default value if the key is not present
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value if the key is present
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that the function returns a shallow copy of the value if the key is present
    # and shallowcopy is True
    CLIARGS['foo'] = ['bar']

# Generated at 2022-06-16 20:53:59.916810
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    def _test_value(value, shallowcopy=False):
        """Test that the value is correct"""
        if not shallowcopy:
            assert value == 'foo'
        elif is_sequence(value):
            assert value == ['foo']
        elif isinstance(value, (Mapping, Set)):
            assert value == {'foo': 'bar'}
        else:
            assert value == 'foo'

    def _test_value_default(value, shallowcopy=False):
        """Test that the value is correct"""
        if not shallowcopy:
            assert value == 'bar'