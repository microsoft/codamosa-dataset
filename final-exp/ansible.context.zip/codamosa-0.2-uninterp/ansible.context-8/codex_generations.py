

# Generated at 2022-06-16 20:44:12.839812
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_inner(mocker, cli_args, key, default, shallowcopy, expected):
        """Test the inner function"""
        global CLIARGS
        CLIARGS = CLIArgs(cli_args)
        inner = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)
        assert inner() == expected

    def test_inner_default(mocker, cli_args, key, expected):
        """Test the inner function with default"""
        global CLIARGS
        CLIARGS = CLIArgs(cli_args)
        inner = cliargs_deferred_get(key)
        assert inner() == expected



# Generated at 2022-06-16 20:44:21.789217
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that it returns the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that it returns the value from CLIARGS
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that it returns a shallow copy of the value from CLIARGS
    _init_global_context({'foo': ['bar']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    assert cl

# Generated at 2022-06-16 20:44:32.163392
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': ['qux', 'quux']})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == ['qux', 'quux']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['qux', 'quux']
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == CLIARGS['baz']

# Generated at 2022-06-16 20:44:43.314888
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # We need to access the _options attribute to test this
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None

# Generated at 2022-06-16 20:44:54.591266
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test the default
    assert cliargs_deferred_get('foo')() is None

    # Test the default with shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() is None

    # Test a value that is not a sequence, mapping, or set
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test a value that is not a sequence, mapping, or set with shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'



# Generated at 2022-06-16 20:45:06.596224
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:45:13.773062
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_str
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins

    # Test that the function returns the default if the key is not present
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value if the key is present
    cliargs = ImmutableDict({'foo': 'bar'})
    _init_global_context(cliargs)
    assert cliargs_deferred_get

# Generated at 2022-06-16 20:45:24.035213
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:45:35.860382
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-import
    # pylint: disable=unused-wildcard-import
    # pylint: disable=redefined-builtin
    # pylint: disable=wildcard-import
    # pylint: disable=unused-expression
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 20:45:47.457373
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    # Test that the closure works with a shallow copy
    _init_global_context({'foo': 'bar', 'baz': [1, 2, 3]})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

    # Test that the closure works with a shallow copy of a dict

# Generated at 2022-06-16 20:46:00.096499
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-variable
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def test_default(mocker):
        """Test that the default value is returned when the key is not present"""
        mocker.patch.object(CLIARGS, 'get', return_value=None)
        default = object()
        assert cliargs_deferred_get('key', default=default)() is default

    def test_value(mocker):
        """Test that the value is returned when the key is present"""
        value = object()
        mocker.patch.object

# Generated at 2022-06-16 20:46:12.166301
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the default is returned when the key is not present
    assert cliargs_deferred_get('not_present', default='default')() == 'default'

    # Test that the default is returned when the key is not present and no default is specified
    assert cliargs_deferred_get('not_present')() is None

    # Test that the value is returned when the key is present
    CLIARGS['present'] = 'value'
    assert cliargs_deferred_get('present')() == 'value'

    # Test that the value is returned when the key is present and no default is specified
   

# Generated at 2022-06-16 20:46:23.770537
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:46:35.895675
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs

    cli_args = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}

# Generated at 2022-06-16 20:46:46.120675
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    def test_closure(value):
        def inner():
            return value
        return inner

    assert test_closure(1)() == 1
    assert test_closure(2)() == 2

    # Test that the closure works with the function
    assert cliargs_deferred_get('foo')() == None
    assert cliargs_deferred_get('foo', default=1)() == 1
    assert cliargs_deferred_get('foo', default=2)() == 2
    assert cliargs_deferred_get('foo', default=3, shallowcopy=True)() == 3

    # Test that the closure works with the global variable
    CLIARGS['foo'] = 4
    assert cliargs_deferred_get('foo')() == 4
    assert cliargs_deferred_get

# Generated at 2022-06-16 20:46:57.727568
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='foo')() == 'foo'
    assert cliargs_deferred_get('baz', default='foo', shallowcopy=True)()

# Generated at 2022-06-16 20:47:07.369756
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})

# Generated at 2022-06-16 20:47:18.648823
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    cli_args = {'foo': 'bar', 'baz': ['a', 'b', 'c']}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == ['a', 'b', 'c']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['a', 'b', 'c']
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not cliargs_deferred_get('baz')()

# Generated at 2022-06-16 20:47:24.143946
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')

# Generated at 2022-06-16 20:47:35.699509
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test with a non-shallow copy
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test with a shallow copy
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    # Test with a shallow copy of a list
    cli_args = {'foo': ['bar']}

# Generated at 2022-06-16 20:47:52.947633
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=protected-access
    cli_args = CLIArgs({'foo': 'bar'})
    cli_args._global_context = True
    global CLIARGS
    CLIARGS = cli_args
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_

# Generated at 2022-06-16 20:48:03.876290
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the closure works
    def test_closure(value):
        """Test that the closure works"""
        def inner():
            """Inner function"""
            return value
        return inner

    assert test_closure(1)() == 1
    assert test_closure([1, 2, 3])() == [1, 2, 3]
    assert test_closure({'a': 1})() == {'a': 1}
    assert test_closure(set([1, 2, 3]))() == set([1, 2, 3])

    # Test that the closure works with the deferred get

# Generated at 2022-06-16 20:48:12.701871
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'
    assert cliargs_deferred_get('baz', default='qux', shallowcopy=True)() == 'qux'
    CLIARGS = CLI

# Generated at 2022-06-16 20:48:24.234712
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    import copy

    # Test that we can get a default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that we can get a value from CLIARGS
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we can get a value from CLIARGS and shallow copy it
    CLIARGS['foo'] = ['bar']
    assert cliargs_def

# Generated at 2022-06-16 20:48:36.248089
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs

    # Test that the function works with CLIARGS being replaced
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'

    # Test that the function works with CLIARGS being replaced with a different type
    class Foo(object):
        def __init__(self, value):
            self.value = value

# Generated at 2022-06-16 20:48:45.285167
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with no value
    global CLIARGS
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default=1)() == 1
    assert cliargs_deferred_get('foo', default=1, shallowcopy=True)() == 1

    # Test with a value
    CLIARGS = CLIArgs({'foo': 2})
    assert cliargs_deferred_get('foo')() == 2
    assert cliargs_deferred_get('foo', default=1)() == 2
    assert cliargs_deferred_get('foo', default=1, shallowcopy=True)() == 2

    # Test with a value and shallowcopy

# Generated at 2022-06-16 20:48:54.998108
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with CLIARGS being a normal dict
    global CLIARGS
    CLIARGS = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('baz', 'baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

    # Test with CLIARGS being a CLIArgs object
    CLIARGS = CLI

# Generated at 2022-06-16 20:49:05.919327
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'b'})
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('b')() is None
    assert cliargs_deferred_get('b', default='c')() == 'c'
    CLIARGS = CLIArgs({'a': [1, 2, 3]})
    assert cliargs_deferred_get('a', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('a', shallowcopy=False)() == [1, 2, 3]
    CLIARGS = CLIArgs({'a': {'b': 'c'}})
    assert cliargs_def

# Generated at 2022-06-16 20:49:17.426539
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:49:28.917166
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:49:49.153790
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('baz', 'baz')() == 'baz'
    assert cliargs_deferred_get('baz', 'baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']

# Generated at 2022-06-16 20:50:00.630788
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:50:12.583185
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:50:22.101708
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it returns the default if the key is not in the CLIARGS
    assert cliargs_deferred_get('key', default=1)() == 1
    # Test that it returns the value if the key is in the CLIARGS
    CLIARGS['key'] = 2
    assert cliargs_deferred_get('key', default=1)() == 2
    # Test that it returns a shallow copy of the value if the key is in the CLIARGS
    CLIARGS['key'] = [1, 2, 3]
    assert cliargs_deferred_get('key', default=1, shallowcopy=True)() == [1, 2, 3]
    # Test that it returns a shallow copy of the value if the key is in the CLIARGS

# Generated at 2022-06-16 20:50:33.723740
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    """Test that cliargs_deferred_get returns the correct value"""
    import pytest

    # Test that the default value is returned when the key is not set
    cli_args = {}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the value is returned when the key is set
    cli_args = {'foo': 'baz'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the value is returned when the key is set and the default is None
    cli_args = {'foo': 'baz'}

# Generated at 2022-06-16 20:50:46.386504
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_get(key, default=None, shallowcopy=False):
        return cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()

    # Test that it returns the default when the key is not present
    assert test_get('not_present', default='default') == 'default'
    assert test_get('not_present', default=['default']) == ['default']
    assert test_get('not_present', default={'default': 'default'}) == {'default': 'default'}

    # Test that it returns the value when the key is present
    CLIARGS._options['present'] = 'present'
    assert test

# Generated at 2022-06-16 20:50:57.749829
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    def _init_global_context(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    def cliargs_deferred_get(key, default=None, shallowcopy=False):
        def inner():
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value
           

# Generated at 2022-06-16 20:51:07.516850
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.context_objects import CLIArgs, GlobalCLIArgs
    from ansible.module_utils.common.context_objects import cliargs_deferred_get
   

# Generated at 2022-06-16 20:51:15.151015
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'
    assert cliargs_deferred_get('baz', default='qux', shallowcopy=True)() == 'qux'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})

# Generated at 2022-06-16 20:51:31.806900
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    CLIARGS = CLI

# Generated at 2022-06-16 20:51:59.341508
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='foo')() == 'foo'

# Generated at 2022-06-16 20:52:09.240423
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs

    # pylint: disable=protected-access
    # Test that the closure works
    cliargs = CLIArgs({'foo': 'bar'})
    _init_global_context(cliargs)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    # Test that the shallow copy works
    cliargs = CLI

# Generated at 2022-06-16 20:52:20.608520
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get
    from ansible.utils.context_objects import _init_global_context

    # Test that the function works with the global CLIARGS
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the function works with a local CLIARGS
    cli_args = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')(cli_args) == 'bar'

    # Test that the function works with a global CLIARGS that has been replaced

# Generated at 2022-06-16 20:52:30.092125
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test that we can get a value from the CLIARGS
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we can get a default value
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    # Test that we can get a shallow copy of a value
    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']

# Generated at 2022-06-16 20:52:36.961601
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-16 20:52:44.274376
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    from ansible.utils.context_objects import CliArgs
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIARGS
    from ansible.utils.context_objects import cliargs_deferred_get
    from ansible.utils.context_objects import _init_global_context
    from ansible.module_utils.common.collections import is_sequence


# Generated at 2022-06-16 20:52:53.917529
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:53:05.066843
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that the function returns the default value when CLIARGS is empty
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the default value when the key is not in CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('bar', default='bar')() == 'bar'

    # Test that the function returns the value when the key is in CLIARGS

# Generated at 2022-06-16 20:53:15.153868
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not cliargs_deferred_get('baz', shallowcopy=True)()
    assert cliargs_deferred_get('baz', shallowcopy=True)() == cli

# Generated at 2022-06-16 20:53:25.728712
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cli

# Generated at 2022-06-16 20:54:10.800707
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type