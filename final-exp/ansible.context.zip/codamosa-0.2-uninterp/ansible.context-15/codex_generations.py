

# Generated at 2022-06-16 20:44:11.250653
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with CLIARGS being a CLIArgs object
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    # Test with CLIARGS being a GlobalCLIArgs object
    cliargs = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert cli

# Generated at 2022-06-16 20:44:20.306261
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']

# Generated at 2022-06-16 20:44:31.315855
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('quux')() == {1, 2, 3}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:44:35.677820
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('baz', 'baz')() == 'baz'
    assert cliargs_deferred_get('baz', 'baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']

# Generated at 2022-06-16 20:44:47.134967
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    from ansible.utils.context_objects import *
    from ansible.utils.context_objects import _CLIARGS
    from ansible.utils.context_objects import cliargs_deferred_get
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import test_cliargs_deferred_get
    from ansible.utils.context_objects import _init_global

# Generated at 2022-06-16 20:44:56.895125
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']

# Generated at 2022-06-16 20:45:07.895038
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that the default is returned if the key is not set
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the value is returned if the key is set
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the default is returned if the key is set to None
    CLIARGS['foo'] = None

# Generated at 2022-06-16 20:45:16.960772
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that the closure works
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the closure works with a default
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    # Test that the closure works with a shallow copy
    CLIARGS = CLIArgs({'foo': ImmutableDict({'bar': 'baz'})})
    assert cliargs

# Generated at 2022-06-16 20:45:24.727213
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_

# Generated at 2022-06-16 20:45:31.482970
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get
    import copy
    import sys

    # Test that the function works with a non-singleton version of CLIARGS
    # pylint: disable=protected-access

# Generated at 2022-06-16 20:45:39.376335
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_func(key, default, shallowcopy):
        """Test function for cliargs_deferred_get"""
        # pylint: disable=unused-argument
        return cliargs_deferred_get(key, default, shallowcopy)

    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    def test_func_with_closure(key, default, shallowcopy):
        """Test function for cliargs_deferred_get"""
        # pylint: disable=unused-argument
        return cliargs_deferred_get(key, default, shallowcopy)

    # pylint: disable=unused-variable
    # pylint

# Generated at 2022-06-16 20:45:49.960051
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=protected-access
    # We need to access the _data dict to set the values
    CLIARGS._data = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS._data['baz'] = ['a', 'b', 'c']

# Generated at 2022-06-16 20:46:00.171321
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get() works as expected"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_func(key, default, shallowcopy, expected):
        """Test that cliargs_deferred_get() works as expected"""
        # pylint: disable=protected-access
        # pylint: disable=unused-variable
        # pylint: disable=unused-argument
        global CLIARGS
        CLIARGS = CLIArgs({'key': 'value'})
        assert cliargs_deferred_get(key, default, shallowcopy)() == expected

    # Test that we can get a key from CLIARGS
    test_func('key', 'default', False, 'value')
    # Test that we can get

# Generated at 2022-06-16 20:46:12.206249
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_dict

# Generated at 2022-06-16 20:46:23.809152
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function works with the global CLIARGS
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the function works with a new CLIARGS
    new_cliargs = CLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo')(new_cliargs) == 'baz'

    # Test that the function works with a new CLIARGS that doesn't have the key
    assert cliargs_deferred_get('foo', default='qux')(new_cliargs) == 'qux'

    # Test that the function works with a new CLIARGS that doesn't have the key
    # and that the default is not shallow copied

# Generated at 2022-06-16 20:46:35.893096
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})

# Generated at 2022-06-16 20:46:46.120593
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    # Note: this is not the singleton version.  The Singleton is only created once the program has
    # actually parsed the args
    CLIARGS = CLIArgs({})

    # This should be called immediately after cli_args are processed (parsed, validated, and any
    # normalization performed on them).  No other code should call it
    def _init_global_context(cli_args):
        """Initialize the global context objects"""
        global CLIARGS

# Generated at 2022-06-16 20:46:57.728262
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:47:07.370779
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def _test_get(key, default=None, shallowcopy=False):
        """Closure over getting a key from CLIARGS with shallow copy functionality

        Primarily used in ``FieldAttribute`` where we need to defer setting the default
        until after the CLI arguments have been parsed

        This function is not directly bound to ``CliArgs`` so that it works with
        ``CLIARGS`` being replaced
        """
        def inner():
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value

# Generated at 2022-06-16 20:47:16.041112
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:47:24.093831
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'

# Generated at 2022-06-16 20:47:31.548710
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test getting a value that is not in the dict
    assert cliargs_deferred_get('not_in_dict')() is None

    # Test getting a value that is in the dict
    CLIARGS['in_dict'] = 'value'
    assert cliargs_deferred_get('in_dict')() == 'value'

    # Test getting a value that is in the dict with a default
    CLIARGS['in_dict_with_default'] = 'value'
    assert cliargs_deferred_get('in_dict_with_default', default='default')() == 'value'

# Generated at 2022-06-16 20:47:41.556522
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:47:52.532856
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    def test_func(key, default, shallowcopy, expected):
        # pylint: disable=unused-argument
        def inner():
            return expected
        CLIARGS.get = inner
        assert cliargs_deferred_get(key, default, shallowcopy)() == expected

    test_func('foo', 'bar', False, 'baz')
    test_func('foo', 'bar', True, 'baz')
    test_func('foo', 'bar', True, ['baz'])
    test_func('foo', 'bar', True, {'baz': 'qux'})
    test_func('foo', 'bar', True, {'baz'})

# Generated at 2022-06-16 20:48:03.525734
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4}
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1
    assert cliargs_deferred_get('b', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('c', shallowcopy=True)() == {'d': 4}
    assert cliargs_deferred_get('a', default=2)() == 1

# Generated at 2022-06-16 20:48:12.469114
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    def test_get(key, default, shallowcopy, expected):
        """Test the cliargs_deferred_get function"""
        # pylint: disable=protected-access
        CLIARGS._options = {'foo': 'bar', 'baz': 'qux'}
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == expected

    # Test getting a key that exists
    test_get('foo', None, False, 'bar')
    test_get('foo', None, True, 'bar')
    test_get('baz', None, False, 'qux')
    test_get('baz', None, True, 'qux')

    # Test getting a key that doesn't exist

# Generated at 2022-06-16 20:48:18.372440
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test function
    def test_func(key, default, shallowcopy, expected):
        """Test function for cliargs_deferred_get"""
        global CLIARGS
        CLIARGS = CLIArgs({'key': 'value'})
        assert cliargs_deferred_get(key, default, shallowcopy)() == expected

    # Test cases
    test_func('key', None, False, 'value')
    test_func('key', None, True, 'value')
    test_func('key', 'default', False, 'value')
    test_func('key', 'default', True, 'value')
    test_func('key2', None, False, None)
    test_func('key2', None, True, None)
    test_func('key2', 'default', False, 'default')

# Generated at 2022-06-16 20:48:26.281761
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins
    from ansible.utils.context_objects import GlobalCLIArgs

    # Test that the function works with the global CLIARGS
    CLIARGS.set('foo', 'bar')
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the function works with a different CLIARGS
    cliargs = GlobalCLIArgs.from_options({'foo': 'baz'})
    assert cliargs_def

# Generated at 2022-06-16 20:48:36.870790
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

    # Test that we can get a value from the CLIARGS object
    cliargs = CLIArgs({'foo': 'bar'})
    _init_global_context(cliargs)
    assert cliargs_deferred_get('foo') == 'bar'

    # Test that we can get a default value
    assert cliargs_deferred_get('baz', default='qux') == 'qux'

    # Test that we can get a shallow copy of a list
    cliargs = CLIArgs({'foo': [1, 2, 3]})
    _init_global

# Generated at 2022-06-16 20:48:48.554772
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest

    @pytest.fixture
    def cliargs(request):
        """Fixture to set up CLIARGS"""
        old_cliargs = CLIARGS
        CLIARGS = CLIArgs({'key': 'value'})
        request.addfinalizer(lambda: setattr(sys.modules[__name__], 'CLIARGS', old_cliargs))

    def test_get_value(cliargs):
        """Test that we can get a value from CLIARGS"""
        assert cliargs_deferred_get('key')() == 'value'

    def test_get_default(cliargs):
        """Test that we can get a default value"""
        assert cliargs_def

# Generated at 2022-06-16 20:49:01.422114
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    # pylint: disable=redefined-builtin
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

# Generated at 2022-06-16 20:49:10.371383
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with a default value
    default_value = 'default'
    cliargs_deferred_get_default = cliargs_deferred_get('key', default=default_value)
    assert cliargs_deferred_get_default() == default_value
    # Test with no default value
    cliargs_deferred_get_no_default = cliargs_deferred_get('key')
    assert cliargs_deferred_get_no_default() is None
    # Test with a shallow copy
    cliargs_deferred_get_shallow_copy = cliargs_deferred_get('key', shallowcopy=True)
    assert cliargs_deferred_get_shallow_copy() is None
    # Test with a shallow copy and a default value
    cliargs_deferred_get_sh

# Generated at 2022-06-16 20:49:15.088580
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default value when CLIARGS is empty
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that the function returns the value from CLIARGS when it is set
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

# Generated at 2022-06-16 20:49:23.398892
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS
    CLIARGS = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = GlobalCLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = GlobalCLIArgs({'foo': {'bar': 'baz'}})

# Generated at 2022-06-16 20:49:35.769536
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def test_get(key, default=None, shallowcopy=False):
        """Closure over getting a key from CLIARGS with shallow copy functionality"""
        def inner():
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value
            elif is_sequence(value):
                return value[:]
            elif isinstance(value, (Mapping, Set)):
                return value.copy()
            return value
        return inner

    # Test with no default
    CLIARGS = CLIArgs({'foo': 'bar'})

# Generated at 2022-06-16 20:49:42.770885
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CliArgs
    from ansible.utils.context_objects import cliargs_deferred_get
    from ansible.utils.context_objects import _init_global_context

    # Test that the closure works
    cli_args = CliArgs({'foo': 'bar'})
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the closure works with a GlobalCLIArgs
    cli_args = GlobalCLIArgs.from_options({'foo': 'bar'})
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test

# Generated at 2022-06-16 20:49:51.726602
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works when CLIARGS is a GlobalCLIArgs
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_

# Generated at 2022-06-16 20:50:01.841066
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    import copy

    def test_get(key, default, shallowcopy, expected):
        """Test that cliargs_deferred_get returns the expected value"""
        global CLIARGS
        CLIARGS = CLIArgs({key: default})
        value = cliargs_deferred_get(key, default, shallowcopy)()
        assert value == expected, '{} != {}'.format(value, expected)

    def test_get_default(key, default, shallowcopy, expected):
        """Test that cliargs_deferred_get returns the expected value when the key is not present"""
        global CLIARGS

# Generated at 2022-06-16 20:50:13.512259
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get

# Generated at 2022-06-16 20:50:20.313206
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_inner(key, default, shallowcopy, expected):
        """Helper function to test the inner function"""
        def inner():
            """Inner function to test"""
            return CLIARGS.get(key, default=default)
        return inner

    # Test the inner function
    CLIARGS = CLIArgs({'key': 'value'})
    assert test_inner('key', None, False)() == 'value'
    assert test_inner('key', 'default', False)() == 'value'
    assert test_inner('key', 'default', True)() == 'value'

# Generated at 2022-06-16 20:50:38.083441
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test that it works with a default
    default = 'default'
    getter = cliargs_deferred_get('key', default=default)
    assert getter() == default

    # Test that it works with a value
    value = 'value'
    CLIARGS['key'] = value
    assert getter() == value

    # Test that it works with a shallow copy
    value = ['value']
    CLIARGS['key'] = value
    assert getter(shallowcopy=True) == value
    assert getter(shallowcopy=True) is not value

    # Test that it works with

# Generated at 2022-06-16 20:50:49.702188
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test that the closure works
    def test_closure(key, default, shallowcopy, expected):
        """Test that the closure works"""
        # pylint: disable=redefined-outer-name
        # pylint: disable=unused-argument
        def inner():
            """Inner function to test that the closure works"""
            return expected
        # pylint: enable=unused-argument
        # pylint: enable=redefined-outer-name
        assert cliargs_deferred_get(key, default, shallowcopy)() == expected

    # Test that the closure works
    test_

# Generated at 2022-06-16 20:50:59.017137
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    def _init_global_context(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    # pylint: enable=protected-access
    # pylint: enable=unused-variable

    # Test the default
    _init_global_context({})
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    # Test getting a value from the CLIARGS
    _init_global

# Generated at 2022-06-16 20:51:08.271474
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    global CLIARGS
    cli_args = {'foo': 'bar', 'baz': ['qux', 'quux']}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == ['qux', 'quux']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['qux', 'quux']
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not cliargs_deferred_get('baz')()

# Generated at 2022-06-16 20:51:15.033781
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:51:40.008802
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    import pytest
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the closure works
    def _init_global_context(cli_args):
        """Initialize the global context objects"""
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)


# Generated at 2022-06-16 20:51:52.029722
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import GlobalCLIArgs

    # Test that the closure works
    CLIARGS = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the closure works when the CLIARGS is replaced
    CLIARGS = GlobalCLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo')() == 'baz'

    # Test that the closure works when the CLIARGS is replaced

# Generated at 2022-06-16 20:52:03.331438
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4}, 'e': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4}
    assert cliargs_deferred_get('e')() == {1, 2, 3}
    assert cliargs_deferred_get('f')() is None
    assert cliargs_deferred_get('f', default=5)() == 5

# Generated at 2022-06-16 20:52:11.524008
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # Test that the function returns the default when the key is not present
    default = object()
    assert cliargs_deferred_get('foo', default)() is default

    # Test that the function returns the value when the key is present
    value = object()
    CLIARGS['foo'] = value
    assert cliargs_deferred_get('foo')() is value

    # Test that the function returns a shallow copy of the value when the key is present
    # and shallowcopy is True

# Generated at 2022-06-16 20:52:21.744093
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
    assert cl

# Generated at 2022-06-16 20:52:51.511797
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-argument
    def test_func(key, default=None, shallowcopy=False):
        """Test function for cliargs_deferred_get"""
        return cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)

    # Test that the default is returned when the key is not found
    assert test_func('not_found', default='default')() == 'default'

    # Test that the value is returned when the key is found
    CLIARGS['found'] = 'value'
    assert test_func('found')() == 'value'

    # Test that the default is returned when the key is found but the value is None
    CLIARGS['found'] = None

# Generated at 2022-06-16 20:52:57.821128
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None

# Generated at 2022-06-16 20:53:04.657447
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-import
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

# Generated at 2022-06-16 20:53:14.814323
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with a non-existent key
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test with a key that exists
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test with a key that exists and shallow copy
    CLIARGS['foo'] = [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']

   

# Generated at 2022-06-16 20:53:25.432649
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'


# Generated at 2022-06-16 20:53:34.617834
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default value when the key is not present
    # in the CLIARGS
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    # Test that the function returns the value when the key is present in the CLIARGS
    # and the shallowcopy flag is not set
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', 'bar')() == 'baz'

    # Test that the function returns a shallow copy of the value when the key is present
    # in the CLIARGS and the shallowcopy flag is set
    CLIARGS['foo'] = ['baz']
    assert cliargs_deferred_get('foo', 'bar', shallowcopy=True)() == ['baz']

    # Test that the function returns a shallow copy

# Generated at 2022-06-16 20:53:45.541791
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:53:57.860477
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('qux', shallowcopy=True)() == {'a': 1, 'b': 2}
   

# Generated at 2022-06-16 20:54:05.629154
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)()