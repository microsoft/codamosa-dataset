

# Generated at 2022-06-16 20:44:16.947339
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    def test_get(key, default=None, shallowcopy=False):
        """Closure over getting a key from CLIARGS with shallow copy functionality"""
        value = CLIARGS.get(key, default=default)
        if not shallowcopy:
            return value
        elif is_sequence(value):
            return value[:]
        elif isinstance(value, (Mapping, Set)):
            return value.copy()
        return value

    def test_deferred_get(key, default=None, shallowcopy=False):
        """Closure over getting a key from CLIARGS with shallow copy functionality"""

# Generated at 2022-06-16 20:44:25.172843
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
   

# Generated at 2022-06-16 20:44:34.817692
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-16 20:44:46.516645
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test with a default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test with a value in CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test with a value in CLIARGS and shallowcopy=True
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'baz'

    # Test with a value in

# Generated at 2022-06-16 20:44:56.568475
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def _test_shallowcopy(value):
        """Test that the shallow copy works for the given value"""
        cliargs_get = cliargs_deferred_get('key', default=value, shallowcopy=True)
        cliargs_get_no_copy = cliargs_deferred_get('key', default=value, shallowcopy=False)

        # Test that the value is the same
        assert cliargs_get() == value
        assert cliargs_get_no_copy() == value

        # Test that the value is not the same object
        assert cliargs_get() is not value

# Generated at 2022-06-16 20:45:07.635919
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:45:16.734065
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'

# Generated at 2022-06-16 20:45:25.262412
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:45:36.328563
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.utils.context_objects import GlobalCLIArgs

    # Test that the default value is returned if the key is not present
    CLIARGS = GlobalCLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the value is returned if the key is present
    CLIARGS = GlobalCLIArgs({'foo': 'baz'})
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the value is returned if the key is present and the default is None
    CLIARGS = GlobalCLIArgs({'foo': 'baz'})


# Generated at 2022-06-16 20:45:47.952822
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # Test that the default is returned when the key is not present
    cliargs = CLIArgs({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the value is returned when the key is present
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that the default is returned when the key is present but the value is None
    cliargs = CLI

# Generated at 2022-06-16 20:46:00.349582
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_bytes_or_string
    from ansible.module_utils.common.text.converters import to_text_or_bytes
    from ansible.module_utils.common.text.converters import to_native_or_raw


# Generated at 2022-06-16 20:46:12.285070
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test with no CLIARGS
    assert cliargs_deferred_get('foo')() is None

    # Test with CLIARGS
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test with CLIARGS and default
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'

    # Test with CLIARGS and shallowcopy=True

# Generated at 2022-06-16 20:46:23.886095
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:46:35.933179
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the function returns the correct value
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the function returns the default value
    assert cliargs_deferred_get('not_foo', default='bar')() == 'bar'

    # Test that the function returns a shallow copy
    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS['foo'] = {'bar': 'baz'}
    assert cl

# Generated at 2022-06-16 20:46:46.118958
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:46:57.728020
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works with a default
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that it works with a value
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    # Test that it works with a shallow copy
    CLIARGS['foo'] = ['a', 'b', 'c']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['a', 'b', 'c']
    # Test that it works with a shallow copy of a dict
    CLIARGS['foo'] = {'a': 'b'}

# Generated at 2022-06-16 20:47:07.370577
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test that it works with the default value
    cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that it works with CLIARGS
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that it works with CLIARGS and a default
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that it works with CLIARGS and a default and shallowcopy
    CLIARGS['foo'] = 'bar'
    assert cliargs_def

# Generated at 2022-06-16 20:47:13.079209
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_str
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_list

# Generated at 2022-06-16 20:47:19.489266
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})

# Generated at 2022-06-16 20:47:29.470251
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS

# Generated at 2022-06-16 20:47:42.548591
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:47:54.808401
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:48:06.506740
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence

    # Test that the closure works
    def test_closure():
        """Test that the closure works"""
        # pylint: disable=unused-variable
        # pylint: disable=cell-var-from-loop
        for key in ('foo', 'bar', 'baz'):
            value = cliargs_deferred_get(key)
            assert value() == CLIARGS.get(key)
    test_closure()

    # Test that the closure works with a default
    def test_closure_default():
        """Test that the closure works with a default"""
        # pylint: disable=unused-variable
        # pylint: disable=cell-var-from-loop
       

# Generated at 2022-06-16 20:48:13.850857
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    cli_args = {'a': 1, 'b': [1, 2, 3], 'c': {'d': 1}, 'd': set([1, 2, 3])}
    _init_global_context(cli_args)

    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 1}
    assert cliargs_deferred_get('d')() == set([1, 2, 3])
    assert cliargs_deferred_get('e')() is None

# Generated at 2022-06-16 20:48:24.651576
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default=['baz'])() == ['baz']
    assert cliargs_deferred_get('baz', default={'baz': 'baz'})() == {'baz': 'baz'}

# Generated at 2022-06-16 20:48:36.512305
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_str
    from ansible.module_utils.six import string_types

    # Test that the function returns the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the function returns the value from CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the function returns a shallow copy of the value from CLIARGS
    CLIARGS['foo']

# Generated at 2022-06-16 20:48:45.463082
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    def _init_global_context(cli_args):
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    def cliargs_deferred_get(key, default=None, shallowcopy=False):
        def inner():
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value

# Generated at 2022-06-16 20:48:55.170139
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs
    from ansible.utils.context_objects import cliargs_deferred_get

    # Test that the default value is returned if the key is not present

# Generated at 2022-06-16 20:49:02.773510
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'

# Generated at 2022-06-16 20:49:07.789936
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test that the closure works
    def test_closure(key, default, expected):
        """Test that the closure works"""
        inner = cliargs_deferred_get(key, default)
        assert inner() == expected

    test_closure('foo', 'bar', 'bar')

    # Test that the closure works with CLIARGS being replaced
    def test_closure_with_cliargs_replaced(key, default, expected):
        """Test that the closure works with CLIARGS being replaced"""
        global CLIARGS
        CLIARGS = CLIArgs({'foo': 'baz'})

# Generated at 2022-06-16 20:49:24.239524
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works with the default value
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'
    # Test that it works with a value in the dict
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', 'bar')() == 'baz'
    # Test that it works with a value in the dict and a shallow copy
    CLIARGS['foo'] = ['baz']
    assert cliargs_deferred_get('foo', 'bar', shallowcopy=True)() == ['baz']
    # Test that it works with a value in the dict and a deep copy
    CLIARGS['foo'] = ['baz']
    assert cliargs_deferred_get('foo', 'bar', shallowcopy=False)() == ['baz']

# Generated at 2022-06-16 20:49:36.638181
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:49:43.229223
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # Test that the closure works
    def test_closure(value):
        def inner():
            return value
        return inner

    assert test_closure(1)() == 1
    assert test_closure('foo')() == 'foo'
    assert test_closure(['foo'])() == ['foo']
    assert test_closure({'foo': 'bar'})() == {'foo': 'bar'}
    assert test_closure(set(['foo']))() == set(['foo'])

    # Test that the closure works with the cliargs_deferred_get function

# Generated at 2022-06-16 20:49:51.900636
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    # pylint: disable=unused-wildcard-import
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    # pylint: disable=unused-wildcard-import
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

# Generated at 2022-06-16 20:50:01.917455
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:50:13.579258
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_inner(key, default, shallowcopy, expected):
        """Test that cliargs_deferred_get works as expected"""
        global CLIARGS
        CLIARGS = CLIArgs({key: expected})
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == expected
        CLIARGS = CLIArgs({})
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == default

    test_inner('foo', 'bar', False, 'baz')
    test_inner('foo', 'bar', True, 'baz')
    test

# Generated at 2022-06-16 20:50:20.365317
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_func(key, default, shallowcopy, expected):
        """Test that cliargs_deferred_get returns the correct value"""
        global CLIARGS
        CLIARGS = CLIArgs({key: expected})
        assert cliargs_deferred_get(key, default, shallowcopy)() == expected

    # Test that we get the default value if the key is not in the dict
    test_func('key', 'default', False, 'default')
    test_func('key', 'default', True, 'default')

    # Test that we get the value if the key is in the dict

# Generated at 2022-06-16 20:50:25.571222
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works with the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that it works with CLIARGS being a dict
    CLIARGS = {'foo': 'bar'}
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that it works with CLIARGS being a CLIArgs object
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that it works with CLIARGS being a GlobalCLIArgs object
    CLIARGS = GlobalCLIArgs.from_options({'foo': 'bar'})

# Generated at 2022-06-16 20:50:36.033100
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def _test_value(value, shallowcopy):
        """Test that the value is returned correctly"""
        assert value == cliargs_deferred_get('key', default=value, shallowcopy=shallowcopy)()
        assert value == cliargs_deferred_get('key', shallowcopy=shallowcopy)()
        assert value == cliargs_deferred_get('key', default=value)()
        assert value == cliargs_deferred_get('key')()


# Generated at 2022-06-16 20:50:48.683273
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('quux')() == {1, 2, 3}
    assert cliargs_deferred_get('quux', shallowcopy=True)() == {1, 2, 3}
   

# Generated at 2022-06-16 20:51:13.770427
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_dict

# Generated at 2022-06-16 20:51:19.903192
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=protected-access
    import pytest

    # Test the default value
    def test_default():
        """Test the default value"""
        # pylint: disable=unused-variable
        # pylint: disable=redefined-outer-name
        # pylint: disable=unused-argument
        # pylint: disable=protected-access
        import pytest

        def inner():
            """Inner function to test the default"""
            # pylint: disable=unused-variable
            # pylint: disable=redefined-outer-name
            #

# Generated at 2022-06-16 20:51:39.115846
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 1, 'e': 2}, 'f': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 1, 'e': 2}
    assert cliargs_deferred_get('f')() == {1, 2, 3}
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1

# Generated at 2022-06-16 20:51:46.956708
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:51:57.529865
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    # Test that the closure works
    def test_closure(key, default, shallowcopy, expected):
        """Test that the closure works"""
        # pylint: disable=unused-argument
        def inner():
            """Inner function to test closure"""
            return CLIARGS.get(key, default=default)
        inner.__name__ = 'inner'
        inner.__doc__ = 'Inner function to test closure'
        closure = cliargs_deferred_get(key, default, shallowcopy)
        assert closure.__name__ == 'inner'

# Generated at 2022-06-16 20:52:07.948544
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})

# Generated at 2022-06-16 20:52:19.867689
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs
    from ansible.utils.context import cliargs_deferred_

# Generated at 2022-06-16 20:52:29.180685
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:52:38.776236
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that we can get a value from the CLIARGS
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that we can get a default value
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    # Test that we can get a shallow copy of a list
    CLIARGS.update({'list': [1, 2, 3]})
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]

    # Test that we can get a shallow copy of a set
    CLIARGS.update({'set': {1, 2, 3}})
    assert cliargs_deferred_get('set', shallowcopy=True)()

# Generated at 2022-06-16 20:52:45.436598
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    import copy

    # Test with no default
    cliargs_deferred_get_no_default = cliargs_deferred_get('no_default')
    assert cliargs_deferred_get_no_default() is None

    # Test with default
    cliargs_deferred_get_default = cliargs_deferred_get('no_default', default='default')
    assert cliargs_deferred_get_default() == 'default'

    # Test with shallow copy
    cliargs_deferred_get_shallowcopy = cliargs_deferred_get('shallowcopy', shallowcopy=True)
    assert cliargs_deferred

# Generated at 2022-06-16 20:53:28.430138
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'b'})
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('b')() is None
    assert cliargs_deferred_get('b', default='c')() == 'c'
    assert cliargs_deferred_get('a', shallowcopy=True)() == 'b'
    assert cliargs_deferred_get('b', shallowcopy=True)() is None
    assert cliargs_deferred_get('b', default='c', shallowcopy=True)() == 'c'
    CLIARGS = CLIArgs({'a': [1, 2, 3]})
    assert cliargs_deferred_get('a')() == [1, 2, 3]
   

# Generated at 2022-06-16 20:53:36.670074
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_

# Generated at 2022-06-16 20:53:47.181679
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the function returns the default when the key is not in CLIARGS
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    default = 'baz'
    assert cliargs_deferred_get('not_foo', default=default)() == default

    # Test that the function returns the value when the key is in CLIARGS
    assert cliargs_deferred_get('foo', default=default)() == 'bar'

    # Test that the function returns a

# Generated at 2022-06-16 20:53:59.754771
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:54:10.705497
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    # Test with no args
    assert cliargs_deferred_get('foo')() is None

    # Test with default
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test with shallowcopy
    assert cliargs_deferred_get('foo', shallowcopy=True)() is None

    # Test with default and shallowcopy
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'

    # Test with a value
    CLIARGS['foo'] = 'bar'
    assert cliargs_def