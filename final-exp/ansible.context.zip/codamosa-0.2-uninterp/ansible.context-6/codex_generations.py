

# Generated at 2022-06-16 20:44:16.827320
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
   

# Generated at 2022-06-16 20:44:25.072692
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    CLIARGS = CLIArgs({})
    assert cliargs_deferred_get('foo', default='baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIAR

# Generated at 2022-06-16 20:44:34.745844
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    import copy

    # Test default
    assert cliargs_deferred_get('not_a_key', default='default')() == 'default'

    # Test shallow copy
    assert cliargs_deferred_get('not_a_key', default='default', shallowcopy=True)() == 'default'
    assert cliargs_deferred_get('not_a_key', default=['default'], shallowcopy=True)() == ['default']
    assert cliargs_deferred_get('not_a_key', default={'default': 'default'}, shallowcopy=True)() == {'default': 'default'}
    assert cliargs_deferred_

# Generated at 2022-06-16 20:44:46.516004
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})

# Generated at 2022-06-16 20:44:56.573492
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:45:07.635313
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function works with a non-singleton CLIARGS
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    # Test that the function works

# Generated at 2022-06-16 20:45:14.217014
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=False)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=False)() == 'bar'

# Generated at 2022-06-16 20:45:24.173492
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_dict
    from ansible.module_utils.common.text.converters import to_bytes_or_unicode

# Generated at 2022-06-16 20:45:35.895875
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('baz', shallowcopy=True)() is not CLIARGS['baz']
    assert cliargs_deferred_get('baz', shallowcopy=False)() is CLIARGS['baz']

# Generated at 2022-06-16 20:45:44.580087
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with no value set
    assert cliargs_deferred_get('foo')() is None

    # Test with value set
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test with default set
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    # Test with shallow copy
    CLIARGS['baz'] = ['qux']
    assert cliargs_deferred_get('baz', shallowcopy=True)() == ['qux']

# Generated at 2022-06-16 20:45:57.615940
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range

# Generated at 2022-06-16 20:46:04.119227
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    assert cliargs_deferred_get('foo')() is None

    # Test that the closure works with CLIARGS being replaced
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the closure works with CLIARGS being replaced
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'

    # Test that the closure works with CLIARGS being replaced
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'

    # Test that the closure

# Generated at 2022-06-16 20:46:13.986576
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:46:24.681078
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    # Test that it returns the correct value
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    # Test that it returns a shallow copy
    CLIARGS.update({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    assert cliargs_def

# Generated at 2022-06-16 20:46:30.583278
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}


# Generated at 2022-06-16 20:46:39.221115
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('qux', shallowcopy=True)() == {'a': 1, 'b': 2}
   

# Generated at 2022-06-16 20:46:46.950679
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]

# Generated at 2022-06-16 20:46:58.006560
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import CLIArgs
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    cli_args = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')(cli_args) == 'bar'
    assert cliargs_deferred_get('foo', default='baz')(cli_args) == 'bar'
    assert cliargs_deferred_get('baz', default='baz')(cli_args) == 'baz'

    cli_args = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')(cli_args) == ['bar', 'baz']

# Generated at 2022-06-16 20:47:07.499711
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:47:16.103310
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that it works with the default value
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that it works with a value in the dict
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    # Test that it works with a value in the dict and shallowcopy=True
    CLIARGS['foo'] = ['baz']
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == ['baz']
    # Test that it works with a value in the dict and shallowcopy=True
    CLIARGS['foo'] = {'baz': 'bam'}

# Generated at 2022-06-16 20:47:30.030566
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # Test that the closure works
    CLIARGS._options = {'foo': 'bar'}
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    # Test that the shallow copy works
    CLIARGS._options = {'foo': 'bar'}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS._options = {'foo': ['bar']}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    CLIARGS._

# Generated at 2022-06-16 20:47:40.704118
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with no default
    assert cliargs_deferred_get('foo')() is None

    # Test with default
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test with shallow copy
    assert cliargs_deferred_get('foo', default=[1, 2, 3], shallowcopy=True)() == [1, 2, 3]

    # Test with shallow copy of a set
    assert cliargs_deferred_get('foo', default=set([1, 2, 3]), shallowcopy=True)() == set([1, 2, 3])

    # Test with shallow copy of a dict
    assert cliargs_deferred_get('foo', default={'a': 1, 'b': 2}, shallowcopy=True)() == {'a': 1, 'b': 2}

# Generated at 2022-06-16 20:47:53.271304
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:48:04.113661
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with no CLIARGS
    assert cliargs_deferred_get('foo')() is None
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    assert cliargs_deferred_get('foo', default=['bar'])() == ['bar']
    assert cliargs_deferred_get('foo', default=['bar'], shallowcopy=True)() == ['bar']
    assert cliargs_deferred_get('foo', default={'bar': 'baz'})() == {'bar': 'baz'}
    assert cliargs_deferred_get('foo', default={'bar': 'baz'}, shallowcopy=True)() == {'bar': 'baz'}

# Generated at 2022-06-16 20:48:12.844809
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test the default value
    _init_global_context({})
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test the shallow copy
    _init_global_context({'foo': 'bar'})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    _init_global_context({'foo': ['bar']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']
    _init_global_context({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'bar': 'baz'}
    _init_global_context({'foo': {'bar'}})

# Generated at 2022-06-16 20:48:24.307797
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

# Generated at 2022-06-16 20:48:36.284773
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence

    @pytest.fixture
    def cliargs():
        return CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}})

    def test_get_value(cliargs):
        """Test that we can get a value from the CLIARGS"""
        assert cliargs_deferred_get('foo')() == 'bar'


# Generated at 2022-06-16 20:48:45.319946
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test with CLIARGS being a CLIArgs object
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('baz')() is None

    # Test with CLIARGS being a GlobalCLIArgs object
    CLI

# Generated at 2022-06-16 20:48:51.202335
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the closure works
    assert cliargs_deferred_get('foo')() is None

    # Test that the closure works with a default
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the closure works with a shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() is None

    # Test that the closure works with a default and a shallow copy
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'

    # Test that the closure

# Generated at 2022-06-16 20:49:00.120756
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('bar')() is None
    assert cliargs_deferred_get('bar', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']

# Generated at 2022-06-16 20:49:18.870714
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def _test_inner(key, default=None, shallowcopy=False):
        value = CLIARGS.get(key, default=default)
        if not shallowcopy:
            return value
        elif is_sequence(value):
            return value[:]
        elif isinstance(value, (Mapping, Set)):
            return value.copy()
        return value

    # Test with a default
    cliargs_deferred_get_default = cliargs_deferred_get('foo', default='bar')
    assert cliargs_deferred_get_default() == 'bar'

    #

# Generated at 2022-06-16 20:49:29.588852
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    # Test that the closure works
    def test_closure(value):
        """Test that the closure works"""
        def inner():
            """Inner function"""
            return value
        return inner

    assert test_closure(1)() == 1
    assert test_closure('foo')() == 'foo'

    # Test that the closure works with the deferred get
    def test_closure_deferred_get(value):
        """Test that the closure works with the deferred get"""
        return cliargs_deferred_get('foo', default=value)


# Generated at 2022-06-16 20:49:40.041184
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import json
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_yaml
    from ansible.module_utils.common.text.formatters import to_nice_text
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.formatters import to_

# Generated at 2022-06-16 20:49:50.329302
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None

# Generated at 2022-06-16 20:50:01.245509
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    @pytest.fixture
    def cliargs():
        return CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4}, 'e': {1, 2, 3}})

    def test_get_default(cliargs):
        assert cliargs_deferred_get('f')(cliargs) is None
        assert cliargs_deferred_get('f', default=1)(cliargs) == 1

    def test_get_value(cliargs):
        assert cliargs_deferred_get('a')(cliargs) == 1

# Generated at 2022-06-16 20:50:13.060067
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.utils.context_objects import CLIArgs
    # Test with no default
    cliargs = CLIArgs({'foo': 'bar'})
    get_foo = cliargs_deferred_get('foo')
    assert get_foo() == 'bar'
    # Test with default
    get_bar = cliargs_deferred_get('bar', default='baz')
    assert get_bar() == 'baz'
    # Test with shallow copy
    cliargs = CLIArgs({'foo': 'bar', 'baz': ['qux', 'quux']})
    get_foo = cliargs_deferred_get('foo', shallowcopy=True)
    assert get_foo() == 'bar'
    get_baz = cliargs_deferred

# Generated at 2022-06-16 20:50:19.925833
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test the default
    assert cliargs_deferred_get('foo')() is None

    # Test the default with shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() is None

    # Test the default with shallow copy on a sequence
    assert cliargs_deferred_get('foo', default=[1, 2, 3], shallowcopy=True)() == [1, 2, 3]

    # Test the default with shallow copy on a mapping
    assert cliargs_deferred_get('foo', default={'a': 1, 'b': 2}, shallowcopy=True)

# Generated at 2022-06-16 20:50:27.588310
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)

# Generated at 2022-06-16 20:50:36.796287
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:50:48.972293
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the function returns the default value when CLIARGS is empty
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'
    # Test that the function returns the default value when CLIARGS is empty
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'

    # Test that the function returns the value when CLIARGS is not empty
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'baz'

    # Test that the function returns a shallow copy of the value when CLIARGS is not empty

# Generated at 2022-06-16 20:51:14.319995
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)

# Generated at 2022-06-16 20:51:20.325811
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    @pytest.fixture
    def cliargs(request):
        """Create a CLIArgs object and return it"""
        cliargs = CLIArgs({})
        request.addfinalizer(lambda: setattr(sys.modules[__name__], 'CLIARGS', cliargs))
        return cliargs

    def test_get_default(cliargs):
        """Test that the default value is returned when the key is not present"""
        cliargs['foo'] = 'bar'
        assert cliargs_deferred_get('foo', default='baz')() == 'bar'
        assert cliargs

# Generated at 2022-06-16 20:51:25.195518
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLI

# Generated at 2022-06-16 20:51:47.360100
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

# Generated at 2022-06-16 20:51:57.911961
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test(key, default, shallowcopy, expected):
        """Test the cliargs_deferred_get function"""
        global CLIARGS
        CLIARGS = CLIArgs({'key': 'value'})
        assert cliargs_deferred_get(key, default, shallowcopy)() == expected
        CLIARGS = CLIArgs({})
        assert cliargs_deferred_get(key, default, shallowcopy)() == expected

    test('key', 'default', False, 'value')
    test('key', 'default', True, 'value')
    test('other', 'default', False, 'default')

# Generated at 2022-06-16 20:52:08.197889
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() is not CLIARGS['foo']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})


# Generated at 2022-06-16 20:52:20.473208
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'
    assert cliargs_deferred_get('baz', 'baz')() == 'baz'
    assert cliargs_deferred_get('baz', 'baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': [1, 2, 3]})
    assert cliargs_deferred_get('foo')() == [1, 2, 3]

# Generated at 2022-06-16 20:52:29.990292
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes_or_unicode

# Generated at 2022-06-16 20:52:39.431485
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}


# Generated at 2022-06-16 20:52:43.294640
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cli

# Generated at 2022-06-16 20:53:28.186491
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cli

# Generated at 2022-06-16 20:53:36.514532
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 'b', 'c': ['d', 'e']})
    assert cliargs_deferred_get('a')() == 'b'
    assert cliargs_deferred_get('c')() == ['d', 'e']
    assert cliargs_deferred_get('c', shallowcopy=True)() == ['d', 'e']
    assert cliargs_deferred_get('c', shallowcopy=True)() is not CLIARGS['c']
    assert cliargs_deferred_get('d')() is None
    assert cliargs_deferred_get('d', 'f')() == 'f'
    CLIARGS = CLIArgs({'a': {'b': 'c'}})

# Generated at 2022-06-16 20:53:47.068717
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    def _test_value(value, shallowcopy):
        """Test that the value is returned correctly"""
        cliargs_deferred_get_value = cliargs_deferred_get('key', value, shallowcopy)
        assert cliargs_deferred_get_value() == value

    # Test that the default value is returned
    _test_value('value', False)
    _test_value('value', True)

    # Test that the value is returned from CLIARGS
    CLIARGS.update({'key': 'value'})
    _test_value('value', False)
    _test_value('value', True)

    # Test that the value is returned from CLIARGS even if it is a

# Generated at 2022-06-16 20:53:59.628308
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest

    @pytest.fixture
    def cliargs(request):
        """Fixture to create a CLIArgs object"""
        cliargs = CLIArgs({})
        request.addfinalizer(lambda: setattr(sys.modules[__name__], 'CLIARGS', cliargs))
        return cliargs

    def test_get_default(cliargs):
        """Test that the default value is returned when the key is not present"""
        cliargs['foo'] = 'bar'
        assert cliargs_deferred_get('bar', 'baz')() == 'baz'


# Generated at 2022-06-16 20:54:10.621895
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import itervalues