

# Generated at 2022-06-16 20:44:11.456949
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs

    # Test that the function works with the global CLIARGS
    CLIARGS.update({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the function works with a CLIArgs object
    cliargs = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')(cliargs=cliargs) == 'bar'

    # Test that the function works with a GlobalCLIArgs object
    cliargs = GlobalCLIArgs({'foo': 'bar'})

# Generated at 2022-06-16 20:44:20.448901
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    @pytest.fixture
    def cliargs_mock(mocker):
        """Mock the CLIARGS object"""
        cliargs_mock = mocker.MagicMock()
        cliargs_mock.get.return_value = 'foo'
        cliargs_mock.__contains__.return_value = True
        return cliargs_mock

    def test_get_value(cliargs_mock):
        """Test getting a value from the CLIARGS object"""
        global CLIARGS
        CLIARGS = cliargs_mock
        assert cliargs

# Generated at 2022-06-16 20:44:31.495012
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'

    # Test that the closure works with a different CLIARGS
    CLI

# Generated at 2022-06-16 20:44:38.087666
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_text
    from ansible.module_utils.common.text.formatters import to_nice_path
    from ansible.module_utils.common.text.formatters import to_nice_path_output
    from ansible.module_utils.common.text.formatters import to_nice_url

# Generated at 2022-06-16 20:44:49.594345
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that it works with a default
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    # Test that it works with a value
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', 'baz')() == 'bar'

    # Test that it works with a shallow copy
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo', 'baz', shallowcopy=True)() == 'bar'
    CLIARGS['foo'] = ['bar']

# Generated at 2022-06-16 20:44:58.129077
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    def test_func(key, default=None, shallowcopy=False):
        """Closure over getting a key from CLIARGS with shallow copy functionality

        Primarily used in ``FieldAttribute`` where we need to defer setting the default
        until after the CLI arguments have been parsed

        This function is not directly bound to ``CliArgs`` so that it works with
        ``CLIARGS`` being replaced
        """
        def inner():
            value = CLIARGS.get(key, default=default)
            if not shallowcopy:
                return value
            elif is_sequence(value):
                return value[:]

# Generated at 2022-06-16 20:45:08.836003
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar']})
    assert cliargs_deferred

# Generated at 2022-06-16 20:45:17.696787
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test cliargs_deferred_get"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument

    # Test that the function returns a function
    def _test_func_returned(key, default=None, shallowcopy=False):
        """Test that the function returns a function"""
        func = cliargs_deferred_get(key, default, shallowcopy)
        assert callable(func)
        return func

    # Test that the function returned by cliargs_deferred_get returns the default value

# Generated at 2022-06-16 20:45:24.997307
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

# Generated at 2022-06-16 20:45:36.199730
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    def test_get(key, default, shallowcopy, expected):
        """Test the cliargs_deferred_get function"""
        # pylint: disable=redefined-outer-name
        global CLIARGS
        CLIARGS = CLIArgs({key: expected})
        assert cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)() == expected

    def test_get_default(key, default, shallowcopy, expected):
        """Test the cliargs_deferred_get function"""
        # pylint: disable=redefined-outer-name
        global CLIARGS
        CLIARGS = CLIArgs({})
        assert cli

# Generated at 2022-06-16 20:45:49.496400
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import bytes_to_human
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_kilobytes
    from ansible.module_utils.common.text.formatters import kilobytes_to_human

# Generated at 2022-06-16 20:45:59.834208
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get returns the correct value"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)()

# Generated at 2022-06-16 20:46:11.932286
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}

# Generated at 2022-06-16 20:46:23.436834
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    cli_args = {'foo': 'bar'}
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('baz', default=['baz'])() == ['baz']

# Generated at 2022-06-16 20:46:35.851676
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import format_value
    from ansible.module_utils.common.text.utils import to_bytes
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native
    from ansible.module_utils.parsing.convert_bool import boolean

# Generated at 2022-06-16 20:46:41.463706
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    import pytest
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    def test_get_default(mocker):
        """Test that the default is returned when the key is not present"""
        mocker.patch.object(CLIARGS, 'get', return_value=None)
        assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    def test_get_value(mocker):
        """Test that the value is returned when the key is present"""

# Generated at 2022-06-16 20:46:53.339565
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import is_sequence

    # Test with no args
    assert cliargs_deferred_get('foo')() is None

    # Test with default
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test with shallow copy
    assert cliargs_deferred_get('foo', shallowcopy=True)() is None

    # Test with shallow copy and default
    assert cliargs_deferred_get('foo', default='bar', shallowcopy=True)() == 'bar'

    # Test with shallow copy and default that is a list
    assert cliargs_deferred_get('foo', default=['bar'], shallowcopy=True)() == ['bar']

    # Test with shallow

# Generated at 2022-06-16 20:47:03.083337
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    assert cliargs_deferred_get('foo')() is None
    CLIARGS.update(foo='bar')
    assert cliargs_deferred_get('foo')() == 'bar'
    # Test that the shallow copy works
    CLIARGS.update(bar=['a', 'b', 'c'])
    assert cliargs_deferred_get('bar')() == ['a', 'b', 'c']
    assert cliargs_deferred_get('bar', shallowcopy=True)() == ['a', 'b', 'c']
    CLIARGS['bar'].append('d')
    assert cliargs_deferred_get('bar')() == ['a', 'b', 'c', 'd']
    assert cliargs_deferred_get('bar', shallowcopy=True)

# Generated at 2022-06-16 20:47:10.446031
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import BOOLEANS_TRUE
    from ansible.module_utils.common.text.formatters import BOOLEANS_FALSE
    from ansible.module_utils.common.text.formatters import to_bool
    from ansible.module_utils.common.text.formatters import to_bytes

# Generated at 2022-06-16 20:47:17.854143
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=redefined-builtin
    # pylint: disable=unused-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import quote as urlquote
    from ansible.module_utils.urls import open

# Generated at 2022-06-16 20:47:30.951762
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the default value is returned
    assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    # Test that the default value is returned when the key is not in CLIARGS
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('bar', default='bar')() == 'bar'

    # Test that the value is returned when the key is in CLIARGS
    assert cliargs_deferred_get('foo', default='bar')() == 'baz'

    # Test that the value is returned when the key is in

# Generated at 2022-06-16 20:47:41.246108
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})

# Generated at 2022-06-16 20:47:53.716165
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    # Test the closure
    def test_closure(key, default, shallowcopy, expected):
        """Test the closure"""
        # pylint: disable=missing-docstring
        # pylint: disable=unused-argument
        # pylint: disable=redefined-outer-name
        # pylint: disable=unused-variable
        #

# Generated at 2022-06-16 20:48:05.099552
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    # pylint: disable=unused-wildcard-import
    # pylint: disable=redefined-builtin
    # pylint: disable=wildcard-import
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

# Generated at 2022-06-16 20:48:13.271633
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs

# Generated at 2022-06-16 20:48:24.484777
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:48:36.420359
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # Test that the closure works
    assert cliargs_deferred_get('foo')() is None

    # Test that the closure returns the correct value
    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'

    # Test that the closure returns the correct default
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

    # Test that the closure returns a shallow copy
    CLIARGS['list'] = [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('list', shallowcopy=True)() is not CLIARGS['list']

    # Test that the closure returns a shallow copy
   

# Generated at 2022-06-16 20:48:48.227780
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    from ansible.utils.context_objects import GlobalCLIArgs
    global CLIARGS
    CLIARGS = GlobalCLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = Global

# Generated at 2022-06-16 20:48:57.861563
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4}, 'e': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 4}
    assert cliargs_deferred_get('e')() == {1, 2, 3}
    assert cliargs_deferred_get('f')() is None
    assert cliargs_deferred_get('f', default=5)() == 5

# Generated at 2022-06-16 20:49:04.520836
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Unit test for function cliargs_deferred_get"""
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-boolean-expressions
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-import
    # pylint: disable=unused-wildcard-import
    # pylint: disable=wildcard-import
    # pylint: disable=

# Generated at 2022-06-16 20:49:22.628449
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test that cliargs_deferred_get works as expected"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'
    assert cliargs_deferred_get('baz', default='baz', shallowcopy=True)() == 'baz'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']

# Generated at 2022-06-16 20:49:34.749848
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='foo')() == 'foo'
    assert cliargs_deferred_get('baz', default='foo', shallowcopy=True)()

# Generated at 2022-06-16 20:49:42.334610
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence

    def test_get(key, default, shallowcopy, expected):
        """Test the cliargs_deferred_get function"""
        global CLIARGS
        CLIARGS = CLIArgs({'key': 'value'})
        result = cliargs_deferred_get(key, default=default, shallowcopy=shallowcopy)()
        assert result == expected

    # Test that we can get a value from the CLIARGS
    test_get('key', None, False, 'value')

    # Test that we can get a default value
    test_get('key2', 'default', False, 'default')

    # Test that we can get a shallow copy of a list

# Generated at 2022-06-16 20:49:51.494109
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=False)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo', shallowcopy=True)() == {'bar': 'baz'}
    assert cliargs_deferred_get('foo', shallowcopy=False)() == {'bar': 'baz'}


# Generated at 2022-06-16 20:50:01.708410
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', default='bar')() == 'bar'
    assert cliargs_deferred_get('baz', default='bar', shallowcopy=True)() == 'bar'

# Generated at 2022-06-16 20:50:13.439284
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    CLIARGS['foo'] = 'bar'
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('baz', default='baz')() == 'baz'

    CLIARGS['foo'] = ['bar']
    assert cliargs_deferred_get('foo')() == ['bar']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar']


# Generated at 2022-06-16 20:50:22.849557
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    def test_get(key, default, expected):
        """Test getting a key from CLIARGS"""
        assert cliargs_deferred_get(key, default)() == expected

    def test_get_shallowcopy(key, default, expected):
        """Test getting a key from CLIARGS with shallow copy"""
        assert cliargs_deferred_get(key, default, shallowcopy=True)() == expected

    def test_get_shallowcopy_sequence(key, default, expected):
        """Test getting a key from CLIARGS with shallow copy"""

# Generated at 2022-06-16 20:50:34.331579
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    CLIARGS.update({'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('baz')() == [1, 2, 3]
    assert cliargs_deferred_get('qux')() == {'a': 1, 'b': 2}
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz', shallowcopy=True)() == [1, 2, 3]
    assert cliargs_deferred_get('qux', shallowcopy=True)() == {'a': 1, 'b': 2}
   

# Generated at 2022-06-16 20:50:46.423347
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('foo', default='baz')() == 'bar'
    assert cliargs_deferred_get('foo', default='baz', shallowcopy=True)() == 'bar'
    assert cliargs_deferred_get('baz')() is None
    assert cliargs_deferred_get('baz', shallowcopy=True)() is None
    assert cliargs_deferred_get('baz', default='qux')() == 'qux'

# Generated at 2022-06-16 20:50:57.780873
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=protected-access
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.context_objects import CliArgs
    from ansible.module_utils.common.context_objects import GlobalCLIArgs
    from ansible.module_utils.common.context_objects import CLIARGS
    from ansible.module_utils.common.context_objects import cliargs_deferred_get

    # Test that the function returns the default value when the key is not present
    cli_args = CliArgs({})
    _init_global_context(cli_args)
    assert cliargs_deferred_get('foo', 'bar')

# Generated at 2022-06-16 20:51:27.065323
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_text

# Generated at 2022-06-16 20:51:46.082642
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=redefined-outer-name
    import pytest

    @pytest.fixture
    def cliargs():
        """Fixture to create a CLIARGS object"""
        return CLIArgs({'key': 'value'})

    def test_get_value(cliargs):
        """Test getting a value from the CLIARGS object"""
        global CLIARGS
        CLIARGS = cliargs
        assert cliargs_deferred_get('key')() == 'value'

    def test_get_default(cliargs):
        """Test getting a default value from the CLIARGS object"""
        global CLIARGS
        CLIARGS = cliargs

# Generated at 2022-06-16 20:51:56.965999
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 1, 'e': 2}, 'f': {1, 2, 3}})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 1, 'e': 2}
    assert cliargs_deferred_get('f')() == {1, 2, 3}
    assert cliargs_deferred_get('g')() is None
    assert cliargs_deferred_get('g', default=1)() == 1

# Generated at 2022-06-16 20:52:07.862499
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test function cliargs_deferred_get"""
    # pylint: disable=redefined-outer-name
    import pytest

    def test_get_default():
        """Test getting a default value"""
        assert cliargs_deferred_get('foo', default='bar')() == 'bar'

    def test_get_value():
        """Test getting a value"""
        global CLIARGS
        CLIARGS = CLIArgs({'foo': 'bar'})
        assert cliargs_deferred_get('foo')() == 'bar'

    def test_get_value_shallowcopy():
        """Test getting a value with shallow copy"""
        global CLIARGS
        CLIARGS = CLIArgs({'foo': 'bar'})

# Generated at 2022-06-16 20:52:19.278908
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test for function cliargs_deferred_get"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
   

# Generated at 2022-06-16 20:52:28.819778
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    global CLIARGS
    CLIARGS = CLIArgs({'foo': 'bar'})
    assert cliargs_deferred_get('foo')() == 'bar'
    assert cliargs_deferred_get('foo', shallowcopy=True)() == 'bar'
    CLIARGS = CLIArgs({'foo': ['bar', 'baz']})
    assert cliargs_deferred_get('foo')() == ['bar', 'baz']
    assert cliargs_deferred_get('foo', shallowcopy=True)() == ['bar', 'baz']
    CLIARGS = CLIArgs({'foo': {'bar': 'baz'}})
    assert cliargs_deferred_get('foo')() == {'bar': 'baz'}
   

# Generated at 2022-06-16 20:52:38.529257
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Set
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.context_objects import CLIArgs, GlobalCLIArgs

    @pytest.fixture
    def cli_args():
        return {'foo': 'bar', 'baz': [1, 2, 3], 'qux': {'a': 1, 'b': 2}, 'quux': {1, 2, 3}}


# Generated at 2022-06-16 20:52:45.283889
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test that the function returns the default value when CLIARGS is empty
    assert cliargs_deferred_get('foo', 'bar')() == 'bar'

    # Test that the function returns the value from CLIARGS when CLIARGS is not empty
    CLIARGS['foo'] = 'baz'
    assert cliargs_deferred_get('foo', 'bar')() == 'baz'

    # Test that the function returns the default value when CLIARGS is not empty but the key is not present
    assert cliargs_deferred_get('foo2', 'bar')() == 'bar'

   

# Generated at 2022-06-16 20:52:54.378277
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-argument
    import pytest

    def _init_global_context(cli_args):
        """Initialize the global context objects"""
        global CLIARGS
        CLIARGS = GlobalCLIArgs.from_options(cli_args)

    @pytest.fixture
    def cli_args():
        return {'foo': 'bar'}

    @pytest.fixture
    def cli_args_with_default():
        return {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-16 20:53:05.093576
# Unit test for function cliargs_deferred_get

# Generated at 2022-06-16 20:53:50.704948
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    """Test the cliargs_deferred_get function"""
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping, Set

    # Test with a default value
    cliargs_deferred_get_default = cliargs_deferred_get('test_key', default='test_default')
    assert cliargs_deferred_get_default() == 'test_default'

    # Test with a value in the CLIARGS
    CLIARGS['test_key'] = 'test_value'
    assert cliargs_deferred_get('test_key')() == 'test_value'

    # Test with a value in the CLIARGS and a default value

# Generated at 2022-06-16 20:54:02.040304
# Unit test for function cliargs_deferred_get
def test_cliargs_deferred_get():
    global CLIARGS
    CLIARGS = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 1}, 'd': set([1, 2, 3])})
    assert cliargs_deferred_get('a')() == 1
    assert cliargs_deferred_get('b')() == [1, 2, 3]
    assert cliargs_deferred_get('c')() == {'d': 1}
    assert cliargs_deferred_get('d')() == set([1, 2, 3])
    assert cliargs_deferred_get('e')() is None
    assert cliargs_deferred_get('e', default=1)() == 1
    assert cliargs_deferred_get('a', shallowcopy=True)() == 1