

# Generated at 2022-06-23 03:48:02.020040
# Unit test for function main

# Generated at 2022-06-23 03:48:05.676677
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', 'abc', True)
    assert rule == ['abc']
    rule = []
    append_match_flag(rule, 'negate', 'abc', True)
    assert rule == ['!', 'abc']
    rule = []
    append_match_flag(rule, 'negate', 'abc', False)
    assert rule == []



# Generated at 2022-06-23 03:48:08.954045
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        chain = 'chain',
        table = 'table'
    )
    args = dict(
        command = 'iptables',
        module = 'module',
        params = params,
        iptables_path = 'path'
    )
    import mock

# Generated at 2022-06-23 03:48:15.000530
# Unit test for function append_rule
def test_append_rule():
  module = AnsibleModule()
  params = {'chain':'INPUT','match':'tcp','jump':'ACCEPT','ip_version':'ipv4','table':'mangle','in_interface':'eth0','protocol':'tcp','destination_port':'22'}
  append_rule('/usr/sbin/iptables',module, params)


# Generated at 2022-06-23 03:48:25.059000
# Unit test for function push_arguments

# Generated at 2022-06-23 03:48:29.923321
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("/bin/true", "INPUT") == "ACCEPT"
    assert get_chain_policy("/bin/true", "FORWARD") == "ACCEPT"
    assert get_chain_policy("/bin/true", "OUTPUT") == "ACCEPT"


# Generated at 2022-06-23 03:48:41.164679
# Unit test for function remove_rule
def test_remove_rule():
    print("Testing function remove_rule")
    import ansible.module_utils.basic as module_basic
    import ansible.module_utils.netaddr as module_netaddr
    import ansible.module_utils.six as module_six
    import os
    import unittest

    class TestIptables(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            module = [module_basic, module_netaddr, module_six]
            setattr(sys.modules['ansible.module_utils.basic'], 'AnsibleModule', FakeAnsibleModule)
            setattr(sys.modules['ansible.module_utils.basic'], 'get_distribution', FakeDistribution)

# Generated at 2022-06-23 03:48:44.330757
# Unit test for function append_wait
def test_append_wait():
    rule = ['test']
    append_wait(rule, '60', 'test')
    assert rule == ['test', 'test', '60']
    rule = ['test']
    append_wait(rule, None, 'test')
    assert rule == ['test']



# Generated at 2022-06-23 03:48:50.296896
# Unit test for function append_match
def test_append_match():
    rule = []
    param = True
    match = 'foo'
    append_match(rule, param, match)
    assert rule == ['-m', 'foo']
    rule = []
    param = False
    match = 'bar'
    append_match(rule, param, match)
    assert rule == []


# Generated at 2022-06-23 03:48:55.382387
# Unit test for function remove_rule
def test_remove_rule():
    # Function mock_run_command must be available
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec = dict())
    iptables_path = ''

# Generated at 2022-06-23 03:49:05.941213
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], 'match', '', True) == ['match']
    assert append_match_flag(['iptables', '-P', 'INPUT', 'DROP'], 'negate', '--syn', True) == ['iptables', '-P', 'INPUT', 'DROP', '!', '--syn']
    assert append_match_flag(['iptables', '-P', 'INPUT', 'DROP'], 'test', '--syn', True) == ['iptables', '-P', 'INPUT', 'DROP']
    assert append_match_flag(['iptables', '-P', 'INPUT', 'DROP'], 'test', '--syn', False) == ['iptables', '-P', 'INPUT', 'DROP']

# Generated at 2022-06-23 03:49:13.583267
# Unit test for function get_iptables_version
def test_get_iptables_version():
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec=dict())
    iptables_version = get_iptables_version(iptables_path, module)
    expected_min_version = '1.4.20'
    assert iptables_version >= expected_min_version



# Generated at 2022-06-23 03:49:24.810948
# Unit test for function main

# Generated at 2022-06-23 03:49:29.128394
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'ACCEPT'
    param2 = 'DROP'
    append_jump(rule, param, 'jump')
    print(rule)
    append_jump(rule, param2, 'jump')
    print(rule)




# Generated at 2022-06-23 03:49:30.615028
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', 'v1.4.20') == '1.4.20'
    assert get_iptables_version('iptables', 'v1.6.0') == '1.6.0'


# Generated at 2022-06-23 03:49:37.502345
# Unit test for function flush_table
def test_flush_table():
    cmd = push_arguments('iptables', '-F', params, make_rule=False)
    print ("Test flush_table : command is : ")
    print (cmd)
    assert cmd == 'iptables -t filter -F INPUT'
    params = { 'table':'filter', 'chain':'INPUT'}


# Generated at 2022-06-23 03:49:41.772799
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, None, '--tcp-flags', True)
    assert len(rule) == 0

    rule = []
    append_match_flag(rule, 'match', '--tcp-flags', True)
    assert rule == ['--tcp-flags']
    rule = []
    append_match_flag(rule, 'negate', '--tcp-flags', True)
    assert rule == ['!', '--tcp-flags']

    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == ['--syn']


# Generated at 2022-06-23 03:49:50.464168
# Unit test for function construct_rule
def test_construct_rule():
    params = {
        'protocol': 'tcp',
        'source': '8.8.8.8',
        'jump': 'DROP',
        'ip_version': 'ipv4',
        'chain': '',
        'table': 'filter',
        'comment': '',
        }
    assert construct_rule(params) == ['iptables',
                                      '-p', 'tcp',
                                      '-s', '8.8.8.8',
                                      '-j', 'DROP'], "construct_rule error"


# Generated at 2022-06-23 03:49:58.174969
# Unit test for function get_iptables_version
def test_get_iptables_version():
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.check_mode = False
            self.fail_json = False
            self.fail_json_args = None
            self.run_command = self.mock_run_command
        def mock_run_command(self, arg, check_rc=True):
            out = 'iptables v1.6.0'
            return 0,out,None
    module = MockModule()
    version = get_iptables_version(None,module)
    assert version == '1.6.0'

# Generated at 2022-06-23 03:49:58.665247
# Unit test for function append_rule
def test_append_rule():
    pass



# Generated at 2022-06-23 03:50:00.864892
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, False, "accept")
    assert rule == []
    append_jump(rule, "accept", "accept")
    assert rule == ['-j', 'accept']
    append_jump(rule, "drop", "accept")
    assert rule == ['-j', 'accept', '-j', 'drop']


# Generated at 2022-06-23 03:50:05.964500
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--match-flag', False)
    assert rule == ['--match-flag']
    rule = []
    append_match_flag(rule, 'negate', '--match-flag', True)
    assert rule == ['!', '--match-flag']


# Generated at 2022-06-23 03:50:07.625793
# Unit test for function main
def test_main():
    result = {}
    main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:50:11.622456
# Unit test for function append_match
def test_append_match():
    rule = []
    param = True
    match = 'tcp'
    append_match(rule, param, match)
    assert rule == ['-m', 'tcp']



# Generated at 2022-06-23 03:50:20.676619
# Unit test for function push_arguments

# Generated at 2022-06-23 03:50:30.012304
# Unit test for function append_param
def test_append_param():
    assert append_param([], None, 'flag', False) == []
    assert append_param([], 'test', 'flag', False) == ['flag', 'test']
    assert append_param([], [], 'flag', True) == []
    assert append_param([], ['test', 'test2'], 'flag', True) == ['flag', 'test', 'flag', 'test2']
    assert append_param([], '!test', 'flag', False) == ['!', 'flag', 'test']



# Generated at 2022-06-23 03:50:37.657947
# Unit test for function remove_rule
def test_remove_rule():
    module = AnsibleModule(argument_spec={})
    module.params = dict(
        wait='1',
        table='filter',
        chain='INPUT',
        protocol='tcp',
        match='none',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
        action='insert',
        ip_tables_path='iptables'
    )
    cmd = push_arguments('iptables', '-D', module.params)
    print(cmd)
    # module.run_command(cmd, check_rc=True)
test_remove_rule()


# Generated at 2022-06-23 03:50:39.996023
# Unit test for function flush_table
def test_flush_table():
    cmd = ['iptables', '-t', 'filter', '-F', 'test_chain']
    return (cmd)



# Generated at 2022-06-23 03:50:52.002060
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic

    class FakeModule(object):
        def run_command(self, cmd, check_rc=False):  # pylint: disable=unused-argument
            return 0, b"", b""

        def get_bin_path(self, *args, **kwargs):  # pylint: disable=unused-argument
            return to_bytes("/usr/sbin/iptables")

    module = FakeModule()


# Generated at 2022-06-23 03:50:58.850771
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = "/sbin/iptables"
    module = AnsibleModule(
        argument_spec = dict(
            action = dict(type='str', default="append", choices=["append", "insert", "remove"]),
            chain = dict(type='str'),
            ip_version = dict(type='str', default="ipv4", choices=["ipv4", "ipv6"]),
            jump = dict(type='str'),
            protocol = dict(type='str'),
            src_range = dict(type='str'),
            ctstate = dict(type='list'),
            table = dict(type='str', default="filter"),
            policy = dict(type='str'),
        )
    )

# Generated at 2022-06-23 03:51:02.188994
# Unit test for function append_match_flag
def test_append_match_flag():
    test_rule=[]
    append_match_flag(test_rule, 'match', '--syn', True)
    assert test_rule == ['--syn']
    test_rule=[]
    append_match_flag(test_rule, 'negate', '--syn', True)
    assert test_rule == ['!', '--syn']
    test_rule=[]
    append_match_flag(test_rule, 'ignore', '--syn', True)
    assert test_rule == []


# Generated at 2022-06-23 03:51:11.590365
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables',None,{'chain': 'INPUT', 'jump': 'DROP', 'source': '8.8.8.8', 'table': 'filter'}) == False
    assert check_present('iptables',None,{'chain': 'INPUT', 'jump': 'DROP', 'source': '8.8.8.8', 'table': 'filter'}) == False



# Generated at 2022-06-23 03:51:17.266660
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num="5",
    )
    assert insert_rule(iptables_path, module, params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT'
    ]



# Generated at 2022-06-23 03:51:21.954489
# Unit test for function set_chain_policy
def test_set_chain_policy():
    opts = {
        'table': 'filter',
        'chain': 'INPUT',
        'policy': 'DROP',
        'wait': '10'
    }
    iptables_path = 'iptables'
    set_chain_policy(iptables_path, None, opts)



# Generated at 2022-06-23 03:51:23.164917
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule(iptables_path, module, params) == True



# Generated at 2022-06-23 03:51:25.499362
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert construct_rule(dict(policy='ACCETP')) == []
    assert construct_rule(dict(policy='DROP')) == []
    assert construct_rule(dict(policy='ACCEPT')) == []



# Generated at 2022-06-23 03:51:30.275080
# Unit test for function check_present
def test_check_present():
    iptables_path = '/usr/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    # Check a rule exists.
    params = dict(
        table='nat',
        chain='PREROUTING',
        in_interface='eth0',
        protocol='tcp',
        match='tcp',
        destination_port='80',
        jump='REDIRECT',
        to_ports='8600',
        comment='Redirect web traffic to port 8600',
    )
    assert check_present(iptables_path, module, params)
    # Check a non-existent rule exists.
    params['jump'] = 'ACCEPT'
    assert not check_present(iptables_path, module, params)



# Generated at 2022-06-23 03:51:34.209000
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = FakeModule()
    iptables_path = 'iptables'
    version = get_iptables_version(iptables_path, module)
    assert version == '1.4.21'



# Generated at 2022-06-23 03:51:35.360911
# Unit test for function flush_table
def test_flush_table():
    module = DummyModule()
    flush_table(module)
    assert module.run_command.call_count == 1



# Generated at 2022-06-23 03:51:41.088663
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['FIN', 'SYN', 'RST', 'ACK', 'URG', 'PSH', 'ALL'], 'flags_set': ['FIN', 'SYN', 'RST', 'ACK', 'ALL']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'FIN,SYN,RST,ACK,URG,PSH,ALL', 'FIN,SYN,RST,ACK,ALL']



# Generated at 2022-06-23 03:51:48.262942
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', 'foo', True)
    assert rule == ['foo']
    rule = []
    append_match_flag(rule, 'negate', 'foo', True)
    assert rule == ['!', 'foo']
    rule = []
    append_match_flag(rule, 'unknown', 'foo', True)
    assert rule == []
    rule = []
    append_match_flag(rule, 'negate', 'foo', False)
    assert rule == []



# Generated at 2022-06-23 03:51:57.477887
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('/sbin/iptables', module, params) == ['/sbin/iptables', '-t', 'filter', '-D', 'INPUT', '-p', 'tcp', '-s', '192.168.122.0/24', '-d', '192.168.122.0/24', '-m', 'limit', '--limit', '2/second', '--limit-burst', '20', '-j', '--log-prefix', 'IPTABLES:INFO: ', '--log-level', 'info', '-m', 'comment', '--comment', 'Test comment']



# Generated at 2022-06-23 03:52:08.939840
# Unit test for function push_arguments

# Generated at 2022-06-23 03:52:09.588276
# Unit test for function append_rule
def test_append_rule():
    print("Testing append rule")
    pass



# Generated at 2022-06-23 03:52:16.400406
# Unit test for function append_rule
def test_append_rule():
    from ansible.module_utils import basic

# Generated at 2022-06-23 03:52:18.279453
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/bin/iptables'
    args = dict(iptables_path=iptables_path, module=None, params=None)
    assert append_rule(**args) is None


# Generated at 2022-06-23 03:52:21.824452
# Unit test for function append_rule
def test_append_rule():
    import subprocess
    from ansible.modules.network.iptables import subprocess_check_output as check_output
    module = {}
    module['run_command'] = lambda cmd, check_rc=True: subprocess.call(cmd) == 0
    module['check_rc'] = False
    iptables_path = "/sbin/iptables"
    params = {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp'}
    append_rule(iptables_path, module, params)



# Generated at 2022-06-23 03:52:25.390524
# Unit test for function check_present
def test_check_present():
    module = make_module(dict(ip_version='ipv4',
                              table='filter',
                              chain='INPUT',
                              source='127.0.0.1',
                              jump='ACCEPT'))
    result = check_present('iptables', module, module.params)
    assert(result == True)
# End of unit tests



# Generated at 2022-06-23 03:52:34.322351
# Unit test for function construct_rule
def test_construct_rule():
    # Test that wait is included
    param = dict(
        protocol='tcp',
        wait='1s',
        )
    rule = construct_rule(param)
    assert rule == ['-w', '1s', '-p', 'tcp']

    # Test that protocol is included
    param = dict(
        protocol='tcp',
        )
    rule = construct_rule(param)
    assert rule == ['-p', 'tcp']

    # Test that protocol is excluded
    param = dict(
        )
    rule = construct_rule(param)
    assert rule == []

    # Test that source is included
    param = dict(
        protocol='tcp',
        source='10.1.1.1',
        )
    rule = construct_rule(param)

# Generated at 2022-06-23 03:52:43.390445
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/bin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {
    "chain": "INPUT",
    "ip_version": "ipv4",
    "table": "filter"
    }
    result = remove_rule(iptables_path, module, params)
    expected_result = '/bin/iptables -t filter -D INPUT'.split()
    assert result == expected_result


# Generated at 2022-06-23 03:52:48.205106
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule(dict(
        chain="INPUT",
        ip_version='ipv4',
        protocol="udp",
        source="8.8.8.8",
        destination="1.1.1.1",
        destination_port="80",
        match="tcp",
        jump="ACCEPT",
        comment="My rule"
    )) == [
        '-w', '-p', 'udp', '-s', '8.8.8.8', '-d', '1.1.1.1', '-m', 'tcp', '--dport',
        '80', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'My rule'
    ]


# Generated at 2022-06-23 03:52:51.258569
# Unit test for function flush_table
def test_flush_table():
    assert flush_table(iptables_path, module, params) != None


# Generated at 2022-06-23 03:52:59.845634
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, "600", "--wait")
    assert rule == ["--wait", "600"]

    rule = []
    append_wait(rule, "-600", "--wait")
    assert rule == ["--wait", "-600"]

    rule = []
    append_wait(rule, "600", "--wait")
    assert rule == ["--wait", "600"]

    rule = []
    append_wait(rule, "600", "--wait")
    assert rule == ["--wait", "600"]



# Generated at 2022-06-23 03:53:02.556299
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = '2'
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule == ['--wait', '2']

# Generated at 2022-06-23 03:53:06.209746
# Unit test for function append_jump
def test_append_jump():
    rule = ['iptables', '-t', 'filter']
    param = 'RETURN'
    jump = 'RETURN'
    append_jump(rule, param, jump)
    assert rule == ['iptables', '-t', 'filter', '-j', 'RETURN']



# Generated at 2022-06-23 03:53:12.550167
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = 10
    flag = "-w"
    append_wait(rule, param, flag)
    assert (rule == ["-w", "10"])
    rule = []
    param = None
    flag = "-w"
    append_wait(rule, param, flag)
    assert (rule == [])


# Generated at 2022-06-23 03:53:13.945592
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = "DROP"
    jump = "LOG"
    append_jump(rule, param, jump)
    print(rule)
    assert rule == ['-j', 'LOG']


# Generated at 2022-06-23 03:53:26.133600
# Unit test for function main
def test_main():
    class module_mock:
        def __init__(self, params, iptables_path='/usr/bin/iptables'):
            self.params = params
            self.iptables_path = iptables_path
        def get_bin_path(self, bin, required=False):
            return self.iptables_path

    class ansible_module_mock(module_mock):
        class ModuleExit:
            class AnsibleModuleFailure(Exception):
                def __init__(self, r):
                    pass

        def __init__(self, params, iptables_path='/usr/bin/iptables'):
            super(ansible_module_mock, self).__init__(params, iptables_path)
            self.fail_json = self.ModuleExit.AnsibleModuleFailure
            self

# Generated at 2022-06-23 03:53:35.326633
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--tcp-flags', True)
    assert rule == ['--tcp-flags']
    append_match_flag(rule, 'negate', '--tcp-flags', True)
    assert rule == ['!', '--tcp-flags']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-23 03:53:43.914979
# Unit test for function append_param
def test_append_param():
    data_true = [
        [['--src-range', '192.168.100.100-192.168.100.200'],
            '--src-range', ['192.168.100.100-192.168.100.200']],
        [['--src-range', '192.168.100.100-192.168.100.200', '--src-range', '192.168.200.100-192.168.200.200'],
            '--src-range', ['192.168.100.100-192.168.100.200', '192.168.200.100-192.168.200.200']],
        [[], '--src-range', []],
        [['--src-range', None], '--src-range', []],
        [None, '--src-range', None]]


# Generated at 2022-06-23 03:53:47.291149
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['a', 'b', 'c'] 
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert(rule == ['--ctstate', 'a,b,c'])


# Generated at 2022-06-23 03:53:49.360412
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path='/sbin/iptables'
    module = None
    params = {
                "chain": "INPUT",
                "policy": "DROP",
                "table": "filter"
            }
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-23 03:54:00.756401
# Unit test for function insert_rule
def test_insert_rule():
  iptables_path = '/sbin/iptables'
  chain = 'INPUT'
  action = 'insert'
  protocol = 'tcp'
  destination_port = '8080'
  jump = 'ACCEPT'
  rule_num = '5'
  params = {
    'chain': chain,
    'action': action,
    'protocol': protocol,
    'destination_port': destination_port,
    'jump': jump,
    'rule_num': rule_num,
    'table': 'filter'
  }
  assert insert_rule(iptables_path, TestModule(), params)



# Generated at 2022-06-23 03:54:13.025991
# Unit test for function append_param
def test_append_param():
    rule = list()
    param = 'test'
    flag = 'flag'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['flag', 'test']

    rule = list()
    param = ['test', 'test2']
    flag = 'flag'
    is_list = True
    append_param(rule, param, flag, is_list)
    assert rule == ['flag', 'test', 'flag', 'test2']

    rule = list()
    param = '!test'
    flag = 'flag'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['!', 'flag', 'test']



# Generated at 2022-06-23 03:54:15.706914
# Unit test for function append_wait
def test_append_wait():
    assert append_wait(["iptables", "-A"], "INPUT", "-w") == ["iptables", "-A", "-w", "INPUT"]
    assert append_wait(["iptables", "-I"], "5", "-w") == ["iptables", "-I", "-w", "5"]



# Generated at 2022-06-23 03:54:17.580971
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, 'ACCEPT', 'ACCEPT')
    assert rule == ['-j', 'ACCEPT']



# Generated at 2022-06-23 03:54:30.615374
# Unit test for function insert_rule
def test_insert_rule():
    module = object()
    iptables_path = 'iptables'
    params = {
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': '5',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
    }
    cmd = ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']
    module.run_command = lambda a, check_rc=True: (0, '', '') if a == cmd else (1, '', '')
    insert_rule(iptables_path, module, params)




# Generated at 2022-06-23 03:54:39.950978
# Unit test for function insert_rule

# Generated at 2022-06-23 03:54:53.923869
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils._text import to_bytes

    ipv4_path = BINS['ipv4']
    module = MockModule()

# Generated at 2022-06-23 03:54:57.166262
# Unit test for function get_iptables_version
def test_get_iptables_version():
    class MockModule(object):
        def __init__(self, version):
            self.version = version
            self.called_commands = []

        def run_command(self, cmd, check_rc=True):
            self.called_commands.append({'cmd': cmd, 'check_rc': check_rc})
            return (0, 'v' + self.version, '')

    module = MockModule('1.4.20')

    assert get_iptables_version('/sbin/iptables', module) == '1.4.20'
    assert module.called_commands



# Generated at 2022-06-23 03:55:06.197882
# Unit test for function remove_rule
def test_remove_rule():
    params = dict(
        chain='iface',
        ip_version='ipv4',
        match=None,
        match_set_flags=None,
        out_interface=None,
        policy=None,
        protocol=None,
        source=None,
        source_port=None,
        table='filter',
    )
    assert remove_rule('/usr/bin/iptables', params) == '/usr/bin/iptables -t filter -D iface'



# Generated at 2022-06-23 03:55:17.070977
# Unit test for function push_arguments
def test_push_arguments():
    """
    Unit test for function push_arguments
    """
    iptables_path = "/path/iptables"
    action = "-A"
    params = dict(
        chain="OUTPUT",
        destination_port="22",
        destination="8.8.8.8",
        in_interface="eth0",
        protocol="tcp",
        source="127.0.0.1",
        jump="ACCEPT",
        table="filter",
        ctstate="ESTABLISHED",
        rule_num="1",
        match_set="",
        limit="2/hour",
        limit_burst="3",
        ip_version="ipv4",
    )

# Generated at 2022-06-23 03:55:25.951361
# Unit test for function append_param
def test_append_param():
    assert append_param(['iptables'], None, '-j', False) == []
    assert append_param(['iptables'], 'DROP', '-j', False) == ['-j', 'DROP']
    assert append_param(['iptables'], ['DROP', 'ACCEPT'], '-j', True) == ['-j', 'DROP', '-j', 'ACCEPT']
    assert append_param(['iptables'], ['DROP', '!ACCEPT'], '-j', True) == ['-j', 'DROP', '!', '-j', 'ACCEPT']



# Generated at 2022-06-23 03:55:28.581983
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    flags = {
        'flags': ['ACK', 'RST', 'SYN', 'FIN'],
        'flags_set': ['ACK', 'RST', 'SYN', 'FIN']
    }
    append_tcp_flags(rule, flags, '--tcp-flags')
    assert rule[0], '--tcp-flags'



# Generated at 2022-06-23 03:55:33.727629
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    my_rule_list = []
    tcp_flags = {'flags': ["SYN", "ACK"], 'flags_set': ["ACK", "SYN", "FIN"]}
    append_tcp_flags(my_rule_list, tcp_flags, "--tcp-flags")
    assert my_rule_list == ["--tcp-flags", "SYN,ACK", "ACK,SYN,FIN"]


# Generated at 2022-06-23 03:55:38.250608
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, 'tcp', 'tcp')
    assert rule == ['-m', 'tcp']



# Generated at 2022-06-23 03:55:43.643305
# Unit test for function set_chain_policy
def test_set_chain_policy():
    ansible_module_args = {
        'ip_version': 'ipv4',
        'chain': 'INPUT',
        'policy': 'DROP'
    }

# Generated at 2022-06-23 03:55:48.458597
# Unit test for function append_csv
def test_append_csv():
    rule1 = []
    param1 = ['one', 'two', 'three']
    assert append_csv(rule1, param1, 'testflag') == ['testflag', 'one,two,three']
    rule2 = ['ex']
    param2 = ['one', 'two', 'three']
    assert append_csv(rule2, param2, 'testflag') == ['ex', 'testflag', 'one,two,three']


# Generated at 2022-06-23 03:55:54.859012
# Unit test for function push_arguments

# Generated at 2022-06-23 03:55:55.880775
# Unit test for function append_rule
def test_append_rule():
    pass



# Generated at 2022-06-23 03:56:04.146346
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, dict(flags=['ACK', 'FIN', 'SYN'], flags_set=['URG', 'PSH']), '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,FIN,SYN', 'URG,PSH']
    assert append_tcp_flags(rule, dict(flags_set=['FIN', 'SYN']), '--tcp-flags') == [
        '--tcp-flags', 'ACK,FIN,SYN', 'URG,PSH']



# Generated at 2022-06-23 03:56:17.825217
# Unit test for function construct_rule
def test_construct_rule():
    ipv4_result = ['-w', '-p', 'tcp', '-s', '8.8.8.8', '-d', '8.8.8.0/24', '-j', 'DROP', '-m', 'comment', '--comment', 'test']
    params = dict(
        wait='0',
        protocol='tcp',
        source="8.8.8.8",
        destination="8.8.8.0/24",
        jump="DROP",
        comment="test",
        ip_version='ipv4'
    )
    assert (construct_rule(params)==ipv4_result)

# Generated at 2022-06-23 03:56:25.690480
# Unit test for function main

# Generated at 2022-06-23 03:56:27.450648
# Unit test for function append_jump
def test_append_jump():
    r = []
    append_jump(r, "ACCEPT", "ACCEPT")
    print(r)



# Generated at 2022-06-23 03:56:34.866874
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule(dict())
    version = get_iptables_version('/sbin/iptables', module)
    assert re.match(r'[0-9]{1,2}\.[0-9]{1,2}', version)
    version = get_iptables_version('/sbin/iptables', module)
    assert re.match(r'[0-9]{1,2}\.[0-9]{1,2}', version)



# Generated at 2022-06-23 03:56:43.235621
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule
    params = dict(
        ip_version=['ipv4'],
        table=['filter'],
        chain='INPUT',
        log_prefix='string',
        log_level='ERROR',
        rule_num='1',
        protocol='tcp',
        wait='3',
    )
    assert push_arguments(iptables_path, '-A', params) == ['/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-w', '3', '-p', 'tcp', '-m', 'limit', '--set-log-prefix', 'string', '--log-level', 'ERROR']



# Generated at 2022-06-23 03:56:52.457769
# Unit test for function insert_rule
def test_insert_rule():
    print("\nRunning insert_rule test...")
    iptables_path = '/sbin/iptables'
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': '5',
        'comment': 'test',
        'wait': '0',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'ip_version': 'ipv4'
    }

# Generated at 2022-06-23 03:56:55.314534
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert(get_iptables_version('iptables', None) == '1.6.2')


# Generated at 2022-06-23 03:57:01.067079
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('/usr/sbin/iptables', module, {'table': 'filter', 'chain': 'INPUT', 'policy': 'ACCEPT'})



# Generated at 2022-06-23 03:57:02.868885
# Unit test for function append_match
def test_append_match():
    rule = []
    param = 'match'
    match = 'match'
    append_match(rule, param, match)
    if rule == ['-m', match]:
        print('append_match() test passed')
    else:
        print('append_match() test failed')


# Generated at 2022-06-23 03:57:05.708895
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert (set_chain_policy('iptables', None, {'policy':'ACCEPT', 'chain':'INPUT', 'table':'filter'})) == ['iptables', '-t', 'filter', '-P', 'INPUT', 'ACCEPT']



# Generated at 2022-06-23 03:57:09.287161
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = '5'
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule == ['--wait', '5']
    param = '10'
    append_wait(rule, param, flag)
    assert rule == ['--wait', '10']


# Unit tests for function append_jump

# Generated at 2022-06-23 03:57:14.941547
# Unit test for function append_csv
def test_append_csv():
    test_rule_list = ["iptables"]
    test_param_list = ["test1", "test2", "test3"]
    test_flag = 'test_flag'
    append_csv(test_rule_list,test_param_list,test_flag)
    assert test_rule_list == ["iptables", "test_flag", "test1,test2,test3"]


# Generated at 2022-06-23 03:57:26.493583
# Unit test for function check_present
def test_check_present():
    mock_module = Mock(check_rc=False)
    # Invalid command
    mock_module.run_command.return_value = (127, '', '')

# Generated at 2022-06-23 03:57:30.440281
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['SYN', 'ACK'], flags_set=['RST', 'ACK'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'SYN,ACK', 'RST,ACK']


# Generated at 2022-06-23 03:57:38.125617
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    a = []
    append_tcp_flags(a, {'flags': ['SYN', 'ACK', 'RST', 'FIN'], 'flags_set': ['SYN', 'RST']}, '--tcp-flags')
    assert a == ['--tcp-flags', 'SYN,ACK,RST,FIN', 'SYN,RST']



# Generated at 2022-06-23 03:57:43.264507
# Unit test for function append_wait
def test_append_wait():
    # wait without seconds
    rule = []
    append_wait(rule, '30', '-w')
    assert rule == ['-w', '30']
    # wait with seconds
    rule = []
    append_wait(rule, '30s', '-w')
    assert rule == ['-w', '30']
    # invalid wait. Fail?


# Generated at 2022-06-23 03:57:58.238912
# Unit test for function main