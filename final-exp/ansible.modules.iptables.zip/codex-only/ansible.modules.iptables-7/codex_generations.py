

# Generated at 2022-06-23 03:48:00.565887
# Unit test for function remove_rule
def test_remove_rule():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    iptables_path = 'iptables'
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    cmd = push_arguments(iptables_path, '-D', params)
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-23 03:48:05.594371
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=4,
        ip_version='ipv4',
        protocol='tcp',
        destination_port=80,
        jump="DROP",
    )
    assert('iptables' == BINS[params['ip_version']])
    assert(['-t', 'filter', '-I', 'INPUT', '4', '-p', 'tcp', '--destination-port', '80', '-j', 'DROP'] == construct_rule(params))



# Generated at 2022-06-23 03:48:10.602063
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    flag = 'match'
    negatable = True
    assert append_match_flag(rule, param, flag, negatable) == ['match']
    param = 'negate'
    assert append_match_flag(rule, param, flag, negatable) == ['!', 'match']


# Generated at 2022-06-23 03:48:14.145034
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'negate'
    negatable = True
    flag = '--sport'
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['!', flag]
    rule = []
    param = 'match'
    negatable = True
    flag = '--sport'
    append_match_flag(rule, param, flag, negatable)
    assert rule == [flag]


# Generated at 2022-06-23 03:48:18.621883
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', '1.4.20') == '1.4.20'
    assert get_iptables_version('iptables', '1.6.0') == '1.6.0'



# Generated at 2022-06-23 03:48:24.311623
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'ACCEPT'
    jump = 'ACCEPT'
    expected = ['-j', 'ACCEPT']
    append_jump(rule, param, jump)
    assert rule == expected


# Generated at 2022-06-23 03:48:25.709444
# Unit test for function get_iptables_version
def test_get_iptables_version():
    version = get_iptables_version('/sbin/iptables', None)
    assert version == '1.6.1'


# Generated at 2022-06-23 03:48:31.405103
# Unit test for function append_csv
def test_append_csv():
    rule = ['iptables', '-A', 'INPUT']
    append_csv(rule, None, '--source')
    assert rule == ['iptables', '-A', 'INPUT']

    rule = ['iptables', '-A', 'INPUT']
    append_csv(rule, '10.0.0.1', '--source')
    assert rule == ['iptables', '-A', 'INPUT', '--source', '10.0.0.1']

    rule = ['iptables', '-A', 'INPUT']
    append_csv(rule, ['10.0.0.1', '10.0.0.2'], '--source')

# Generated at 2022-06-23 03:48:39.492159
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    flag = '--some-flag'
    negatable = True
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['--some-flag'], (
            'Rule is: %s' % rule)

    rule = []
    param = 'negate'
    flag = '--some-flag'
    negatable = True
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['!', '--some-flag'], (
            'Rule is: %s' % rule)



# Generated at 2022-06-23 03:48:44.640627
# Unit test for function flush_table
def test_flush_table():
    params = dict(
        table='filter',
        chain='INPUT',
    )
    cmd = push_arguments('iptables', '-F', params, make_rule=False)
    print(cmd)



# Generated at 2022-06-23 03:48:46.782740
# Unit test for function append_wait
def test_append_wait():
    rule = []
    wait='2'
    flag='--wait'
    append_wait(rule, wait, flag)
    assert(rule==['--wait','2'])


# Generated at 2022-06-23 03:48:52.610375
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule
    rule = []
    append_match_flag(rule, 'something', '--syn', True)
    assert rule == []


# Generated at 2022-06-23 03:49:03.161386
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST'])
    append_tcp_flags(rule, param, '-m tcp')
    assert rule == ['-m tcp', 'ACK,RST,SYN,FIN', 'ACK,RST']

    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK'])
    append_tcp_flags(rule, param, '-m tcp')
    assert rule == ['-m tcp', 'ACK,RST,SYN,FIN', 'ACK']

    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=[])
    append_

# Generated at 2022-06-23 03:49:06.746083
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        chain='ACCEPT',
        destination='8.8.8.8',
        jump='DROP',
        table='filter',
        ip_version='ipv4',
    )
    assert push_arguments('iptables', '-A', params) == [
        'iptables', '-t', 'filter', '-A', 'ACCEPT', '-d', '8.8.8.8', '-j', 'DROP']



# Generated at 2022-06-23 03:49:13.126753
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['80', '443', '8081:8083']
    flag = '--destination-port'
    append_csv(rule, param, flag)
    assert(rule == [flag, '80,443,8081:8083'])



# Generated at 2022-06-23 03:49:24.650174
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        ip_version='ipv4',
        chain='INPUT',
        rule_num=3,
        protocol='tcp',
        source='192.168.0.55',
        destination='192.168.0.12',
        jump=None,
        to_destination='10.0.0.1',
        destination_port='80',
        in_interface='eth0',
        log_prefix='TEST: ',
        limit='2/minute',
        limit_burst='5',
        comment='Allow port 80',
        reject_with='icmp-port-unreachable',
        ctstate=['NEW'],
    )
    cmd = push_arguments('/sbin/iptables', '-I', params)

# Generated at 2022-06-23 03:49:26.180865
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == None


# Generated at 2022-06-23 03:49:29.201362
# Unit test for function append_jump
def test_append_jump():
    rule=[]
    param = 'ACCEPT'
    append_jump(rule, param, 'ACCEPT')
    assert rule == ['-j', 'ACCEPT']


# Generated at 2022-06-23 03:49:33.752126
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy("iptables", None, {'chain':"INPUT", 'policy':"DROP", 'table':"filter"}) == True



# Generated at 2022-06-23 03:49:36.002579
# Unit test for function append_jump
def test_append_jump():
    rule = []
    params = [None, 'ACCEPT']
    for param in params:
        append_jump(rule, param, 'ACCEPT')
        assert(rule == ['-j', 'ACCEPT'])


# Generated at 2022-06-23 03:49:39.422515
# Unit test for function append_match
def test_append_match():
    rule = []
    param = True
    match = 'match'
    output = ['-m', match]
    append_match(rule, param, match)
    assert rule == output



# Generated at 2022-06-23 03:49:41.625002
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', module, params) == "cmd = iptables -P INPUT DROP"


# Generated at 2022-06-23 03:49:47.763766
# Unit test for function append_match_flag
def test_append_match_flag():
    for item in ['match', 'negate', 'ignore']:
        rule = list()
        append_match_flag(rule, item, 'flag', True)
        assert len(rule) == 1, 'Append "flag" to rule failed'
        assert rule[0] == 'flag' if item == 'match' else ('!flag' if item == 'negate' else ''), 'Append "flag" to rule failed'



# Generated at 2022-06-23 03:49:53.371835
# Unit test for function append_match
def test_append_match():
    for param, match in [ ('tcp', 'tcp'), ('tcpudp', 'tcpudp') ]:
        assert append_match([], param, match) == ['-m', match]
    assert append_match([], '', None) == []



# Generated at 2022-06-23 03:49:59.898350
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/usr/bin/iptables'
    ansible_module = AnsibleModule(
        argument_spec={
            'chain': dict(required=False, type='str'),
            'table': dict(required=False, type='str', default='filter'),
        },
        supports_check_mode=True,
        mutually_exclusive=[],
        required_together=[],
        required_one_of=[],
        add_file_common_args=True,
        supports_tags=False,
    )
    params = ansible_module.params
    flush_table(iptables_path, ansible_module, params)



# Generated at 2022-06-23 03:50:05.548891
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule({'protocol': 'tcp', 'destination_port': '80'}) == ['-p', 'tcp', '--dport', '80']
    assert construct_rule({'protocol': 'tcp', 'destination_port': '80', 'uid_owner': 'root'}) == ['-p', 'tcp', '--dport', '80', '-m', 'owner', '-m', 'uid-owner', 'root', '--uid-owner', 'root']
    assert construct_rule({'protocol': 'tcp', 'destination_port': '80', 'limit': '5/second'}) == ['-p', 'tcp', '--dport', '80', '-m', 'limit', '--limit', '5/second']



# Generated at 2022-06-23 03:50:12.318505
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule(BINS['ipv4'], None, dict(
            chain='INPUT',
            rule_num='3',
            protocol='tcp',
            destination_port=8080,
            jump='ACCEPT')) == [
                '/sbin/iptables', '-t', 'filter', '-I', 'INPUT',
                '3', '-p', 'tcp',
                '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-23 03:50:14.032814
# Unit test for function append_jump
def test_append_jump():
  param = "ACCEPT"
  rule = []
  jump = "ACCEPT"
  append_jump(rule, param, jump)
  return rule


# Generated at 2022-06-23 03:50:22.473955
# Unit test for function append_match_flag
def test_append_match_flag():
    # Case 1: param == negate
    rule_1 = []
    param_1 = 'negate'
    flag_1 = '--not-syn'
    negatable_1 = True
    append_match_flag(rule_1, param_1, flag_1, negatable_1)
    assert rule_1 == ['!', '--not-syn']
    # Case 2: param == match
    rule_2 = []
    param_2 = 'match'
    flag_2 = '--syn'
    negatable_2 = False
    append_match_flag(rule_2, param_2, flag_2, negatable_2)
    assert rule_2 == ['--syn']
    # Case 3: param == negatable
    rule_3 = []
    param_3 = 'negatable'

# Generated at 2022-06-23 03:50:25.111451
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    in_ = dict(flags='ALL', flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    out = [ '--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN' ]
    assert append_tcp_flags([], in_, '--tcp-flags') == out



# Generated at 2022-06-23 03:50:32.160054
# Unit test for function append_csv
def test_append_csv():
    rule = [ ]
    assert append_csv(rule, ['numbers', 'text', 'spaces'], '--csv') == rule.extend(['--csv', 'numbers,text,spaces'])
    assert append_csv(rule, ['1,2'], '--csv') == rule.extend(['--csv', '1,2'])
    assert append_csv(rule, [], '--csv') == rule.extend(['--csv'])


# Generated at 2022-06-23 03:50:43.526441
# Unit test for function main
def test_main():
    args = dict(
        rule='-A INPUT -s 192.168.1.1/32 -p tcp -m comment --comment "test" -j DROP',
        table='filter',
        chain='INPUT',
        state='present'
    )
    args = dict(
        rule='-A INPUT -s 192.168.1.1/32 -p tcp -m comment --comment "test" -j DROP',
        table='filter',
        chain='INPUT'
    )
    args = dict(
        rule='-A INPUT -s 192.168.1.1/32 -p tcp -m comment --comment "test" -j DROP',
        table='filter',
        chain='INPUT',
        ip_version='ipv4'
    )

# Generated at 2022-06-23 03:50:58.039580
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('', '-A', dict(table=None, chain=None,
        rule_num=None)) == []
    assert push_arguments('', '-D', dict(table=None, chain=None,
        rule_num=None)) == []
    assert push_arguments('', '-I', dict(table=None, chain=None,
        rule_num=None)) == []
    assert push_arguments('', '-F', dict(table=None, chain=None,
        rule_num=None)) == ['', '-t', None, '-F', None]


# Generated at 2022-06-23 03:51:02.750372
# Unit test for function append_param
def test_append_param():
    assert append_param([], 'any', '--key', True) == append_param([], ['any'], '--key', True)
    assert append_param([], 'any', '--key', False) == ['--key', 'any']
    assert append_param([], '!any', '--key', False) == ['!', '--key', 'any']



# Generated at 2022-06-23 03:51:04.563211
# Unit test for function set_chain_policy
def test_set_chain_policy():
    pass


# Generated at 2022-06-23 03:51:09.700646
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['A', 'B', 'C']
    flag = '--test'
    append_csv(rule, param, flag)
    assert rule == ['--test', 'A,B,C']

    rule = []
    param = None
    flag = '--test'
    append_csv(rule, param, flag)
    assert rule == []

    rule = []
    param = 'A,B,C'
    flag = '--test'
    append_csv(rule, param, flag)
    assert rule == []



# Generated at 2022-06-23 03:51:11.563425
# Unit test for function set_chain_policy
def test_set_chain_policy():
    print(set_chain_policy("iptables",None,{"chain":"INPUT","policy":"DROP"}))

# Generated at 2022-06-23 03:51:23.289068
# Unit test for function set_chain_policy
def test_set_chain_policy():
    import_module = mock.MagicMock()
    import_module.run_command.return_value = 0, '', ''
    from ansible.module_utils.basic import AnsibleModule
    params = dict(
        command='set_chain_policy',
        chain='INPUT',
        policy='DROP',
        table='filter',
        ip_version='ipv4',
        ip_bin='iptables',
    )
    module = AnsibleModule(argument_spec=dict())
    set_chain_policy(params['ip_bin'],module,params)
    module.run_command.assert_called_with([
        'iptables',
        '-t',
        'filter',
        '-P',
        'INPUT',
        'DROP',
    ], check_rc=True)



# Generated at 2022-06-23 03:51:28.605313
# Unit test for function get_iptables_version
def test_get_iptables_version():
    m = AnsibleModule({})
    setattr(m, 'run_command', lambda cmd: (0, 'v1.4.20 (legacy)\n', ''))
    assert get_iptables_version('/usr/bin/iptables', m) == '1.4.20 (legacy)'



# Generated at 2022-06-23 03:51:40.568655
# Unit test for function push_arguments

# Generated at 2022-06-23 03:51:46.957302
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['ESTABLISHED', 'RELATED']
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert(rule == ['--ctstate', 'ESTABLISHED,RELATED'])
    rule = []
    param = None
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert(rule == [])
test_append_csv()

# Generated at 2022-06-23 03:51:48.530341
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = ['iptables', '-P', 'INPUT', 'DROP']
    assert set_chain_policy('iptables', None, dict(table='filter', chain='INPUT', policy='DROP')) == cmd



# Generated at 2022-06-23 03:51:52.828773
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = '10'
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule == ['--wait','10']



# Generated at 2022-06-23 03:52:01.445441
# Unit test for function check_present
def test_check_present():
    iptables_path = '/sbin/iptables'
    ansible_module = AnsibleModule()
    params = {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp',
              'destination_port': '22', 'ctstate': ['NEW'], 'syn': 'match', 'jump': 'ACCEPT',
              'comment': 'Accept new SSH connections.', 'ip_version': 'ipv4'}
    assert check_present(iptables_path, ansible_module, params) is False



# Generated at 2022-06-23 03:52:12.368636
# Unit test for function set_chain_policy
def test_set_chain_policy():
    ins = 'ansible.builtin.iptables'

# Generated at 2022-06-23 03:52:17.488861
# Unit test for function append_csv
def test_append_csv():
    rule = ['iptables']
    params = ['ESTABLISHED', 'RELATED']
    append_csv(rule, params, '-m')
    assert rule == ['iptables']
    append_csv(rule, params, '-m conntrack')
    assert rule == ['iptables', '-m conntrack', '-m conntrack', 'ctstate', 'ESTABLISHED,RELATED']



# Generated at 2022-06-23 03:52:30.803090
# Unit test for function remove_rule
def test_remove_rule():
    from ansible.module_utils.basic import AnsibleModule
    params = dict(
        ip_version = 'ipv4',
        chain = 'INPUT',
        protocol = 'tcp',
        jump = 'ACCEPT',
        table = 'filter'
    )
    iptables_path = '/sbin/iptables'
    module = AnsibleModule({}, supports_check_mode=False)
    assert remove_rule(iptables_path, module, params) is not None # Ensure that the function returns a value
    iptables_path = '/bin/iptables'
    assert remove_rule(iptables_path, module, params) is not None # Ensure that the function returns a value
    iptables_path = '/fake/bin/iptables'

# Generated at 2022-06-23 03:52:37.147606
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    with pytest.raises(SystemExit) as execinfo:
        append_match_flag(rule, 'badvalue', '--syn', True)
    assert execinfo.value.code == 1



# Generated at 2022-06-23 03:52:39.953358
# Unit test for function main
def test_main():
    if not (len(sys.argv) == 2 and sys.argv[1] == 'test'):
        sys.exit(1)

    import json
    def setup_params():
        # Load parameters and return dict
        with open('params.json') as f:
            return json.load(f)

    mock_module, params = Mock(), setup_params()
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:52:44.014028
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!--syn']



# Generated at 2022-06-23 03:52:46.502124
# Unit test for function append_wait
def test_append_wait():
    test_rule = []
    append_wait(test_rule, '1', '--wait')
    assert ['--wait', '1'] == test_rule



# Generated at 2022-06-23 03:53:00.211945
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments(
        '/usr/bin/iptables',
        '-I',
        dict(
            table='filter',
            chain='INPUT',
            rule_num=5,
            protocol='tcp',
        ),
        make_rule=False,
    ) == [
        '/usr/bin/iptables', '-t', 'filter',
        '-I', 'INPUT', '5',
    ]


# Generated at 2022-06-23 03:53:03.112200
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'ignore', '--syn', True)
    assert rule == []



# Generated at 2022-06-23 03:53:07.906175
# Unit test for function check_present
def test_check_present():
    cmd = push_arguments('iptables', '-C', {'chain': 'INPUT', 'protocol': 'tcp', 'jump': 'ACCEPT', 'destination_port': '22', 'ip_version': 'ipv4'})
    assert cmd == ['iptables', '-t', 'filter', '-C', 'INPUT', '-p', 'tcp', '--dport', '22', '-j', 'ACCEPT']



# Generated at 2022-06-23 03:53:08.874874
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', 'module', 'params') is None


# Generated at 2022-06-23 03:53:10.041898
# Unit test for function get_chain_policy
def test_get_chain_policy():
    get_chain_policy(None, None, {'table': 'filter', 'chain': 'INPUT'})



# Generated at 2022-06-23 03:53:14.401699
# Unit test for function append_csv
def test_append_csv():
    assert append_csv([], ['ESTABLISHED', 'RELATED'], '--ctstate') == ['--ctstate', 'ESTABLISHED,RELATED']



# Generated at 2022-06-23 03:53:23.502464
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule({})
    iptables_path = '/sbin/iptables'
    params = {
        'table': 'filter',
        'chain': 'FORWARD',
        'watch_ip': '99.99.99.99',
        'jump': 'ACCEPT',
        'rule_num': '4',
        'ip_version': 'ipv4',
    }
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'FORWARD', '4', '-s', '99.99.99.99', '-j', 'ACCEPT']



# Generated at 2022-06-23 03:53:30.855186
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(['iptables', '-I', 'INPUT'], 'match', '--syn', True) == ['iptables', '-I', 'INPUT', '--syn']
    assert append_match_flag(['iptables', '-I', 'INPUT'], 'negate', '--syn', True) == ['iptables', '-I', 'INPUT', '!', '--syn']


# Generated at 2022-06-23 03:53:39.650224
# Unit test for function flush_table
def test_flush_table():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import MagicMock, patch
    iptables_path = '/sbin/iptables'
    module = MagicMock()
    params = {'table': 'filter', 'chain': 'INPUT'}
    module.run_command = MagicMock()
    flush_table(iptables_path, module, params)
    module.run_command.assert_called_with(['/sbin/iptables', '-t', 'filter', '-F', 'INPUT'], check_rc=True)

test_flush_table()



# Generated at 2022-06-23 03:53:40.495378
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', module) == "1.6.1"



# Generated at 2022-06-23 03:53:48.867673
# Unit test for function remove_rule
def test_remove_rule():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    module = type('', (), dict(
        run_command=lambda self, cmd, check_rc=False: (0, '', ''),
        params=dict(table='nat', chain='OUTPUT', protocol='tcp', comment='1.1.1.1')))()
    params = dict(table='nat', chain='OUTPUT', protocol='tcp', comment='1.1.1.1')
    iptables_path='/sbin/iptables'
    a = remove_rule(iptables_path, module, params)
    assert a != None


# Generated at 2022-06-23 03:53:58.077220
# Unit test for function get_iptables_version
def test_get_iptables_version():
    params = dict(
        action='insert',
        table='filter',
        chain='INPUT',
        source='8.8.8.8',
        jump='DROP',
    )
    m = AnsibleModule(argument_spec={}, supports_check_mode=True)
    iptables_path = '/sbin/iptables'
    version = get_iptables_version(iptables_path, m)
    assert version == '1.6.1'



# Generated at 2022-06-23 03:54:09.462195
# Unit test for function append_param
def test_append_param():
    list_param = ['80', '443', '8081:8083']
    rule = []
    append_param(rule, ['!80', '443', '8081'], '--dport', True)
    assert rule == ['!', '--dport', '80', '--dport', '443', '--dport', '8081']

    rule = []
    append_param(rule, list_param, '--dport', True)
    assert rule == ['--dport', '80', '--dport', '443', '--dport', '8081:8083']

    rule = []
    append_param(rule, '80', '--dport', False)
    assert rule == ['--dport', '80']

    rule = []

# Generated at 2022-06-23 03:54:10.461132
# Unit test for function append_rule
def test_append_rule():
    pass



# Generated at 2022-06-23 03:54:15.083298
# Unit test for function flush_table
def test_flush_table():
    table = "filter"
    chain = "INPUT"
    ipv4 = "iptables"
    params = dict(
        table=table,
        chain=chain,
        ip_version="ipv4",
        iptables_path=ipv4,
    )
    flush_table(ipv4, module, params)
    return



# Generated at 2022-06-23 03:54:16.383890
# Unit test for function append_csv
def test_append_csv():
    assert append_csv(list(), ['a', 'b'], '-f') == ['-f', 'a,b']



# Generated at 2022-06-23 03:54:18.209679
# Unit test for function append_rule
def test_append_rule():
    cmd = "iptables -A INPUT -j ACCEPT"
    assert append_rule('iptables',module, params) == cmd



# Generated at 2022-06-23 03:54:31.770958
# Unit test for function construct_rule

# Generated at 2022-06-23 03:54:35.704862
# Unit test for function append_match
def test_append_match():
    test_rule = []
    append_match(test_rule,'test_rule', 'match')
    assert test_rule == ['-m', 'match']


# Generated at 2022-06-23 03:54:38.933103
# Unit test for function set_chain_policy
def test_set_chain_policy():
    set_chain_policy('/usr/bin/iptables', None, {"table": "filter",
                                                 "chain": "INPUT",
                                                 "policy": "DROP"})



# Generated at 2022-06-23 03:54:50.172079
# Unit test for function get_iptables_version
def test_get_iptables_version():
    iptables_paths = dict(
        ipv4='iptables',
        ipv6='ip6tables',
    )
    module_args = dict(
        ip_version='ipv4',
        state='present',
        chain='INPUT',
    )
    module = AnsibleModule(argument_spec=module_args)
    version = get_iptables_version(iptables_paths[module_args['ip_version']],
                                   module)
    assert version == '1.8.2'



# Generated at 2022-06-23 03:54:51.639538
# Unit test for function append_rule
def test_append_rule():
    append_rule('iptables -I', module, params)

# Generated at 2022-06-23 03:54:52.946337
# Unit test for function append_match
def test_append_match():
    assert append_match.__name__ == "append_match"



# Generated at 2022-06-23 03:54:55.209691
# Unit test for function append_jump
def test_append_jump():
    assert append_jump(['-i', 'eth0'], 'ACCEPT', 'ACCEPT') == ['-i', 'eth0', '-j', 'ACCEPT']



# Generated at 2022-06-23 03:54:57.184927
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '1', '-w')
    assert rule == ['-w', '1']
    append_wait(rule, None, '-w')
    assert rule == ['-w', '1']

# Function to convert ports to iptables format

# Generated at 2022-06-23 03:55:11.089183
# Unit test for function append_param
def test_append_param():
    l = []
    append_param(l, 'hello', '-s', False)
    assert l == ['-s', 'hello']
    append_param(l, 'hello,world', '-s', False)
    assert l == ['-s', 'hello', '-s', 'world']
    l = []
    append_param(l, ['hello', 'world'], '-s', True)
    assert l == ['-s', 'hello', '-s', 'world']
    l = []
    append_param(l, '!hello', '-s', False)
    assert l == ['!', '-s', 'hello']
    l = []
    append_param(l, None, '-s', False)
    assert l == []
    l = []

# Generated at 2022-06-23 03:55:18.468709
# Unit test for function append_csv
def test_append_csv():
    rule = []
    test_param = ['ACCEPT', 'DROP']
    test_flag = '-j'
    append_csv(rule, test_param, test_flag)
    assert rule == [test_flag, ','.join(test_param)]


# Generated at 2022-06-23 03:55:20.113149
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables',None,dict()) == False



# Generated at 2022-06-23 03:55:25.241844
# Unit test for function check_present
def test_check_present():
    module = FakeAnsibleModule()
    assert check_present("iptables", module, {"table": "filter", "chain": "INPUT"}) is False
    module.run_command_rc = 0
    assert check_present("iptables", module, {"table": "filter", "chain": "INPUT"}) is True



# Generated at 2022-06-23 03:55:34.612960
# Unit test for function set_chain_policy
def test_set_chain_policy():
    testmod = AnsibleModule({})
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        table='filter',
        policy='ACCEPT'
    )
    cmd = set_chain_policy('iptables', testmod, params)
    assert cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'ACCEPT']
    params['chain'] = 'FORWARD'
    params['policy'] = 'DROP'
    cmd = set_chain_policy('iptables', testmod, params)
    assert cmd == ['iptables', '-t', 'filter', '-P', 'FORWARD', 'DROP']
    params['ip_version'] = 'ipv6'
    params['chain'] = 'INPUT'
    params['policy'] = 'ACCEPT'


# Generated at 2022-06-23 03:55:41.367400
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = '/usr/sbin/iptables'
    module = None
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'policy': '',
    }
    assert get_chain_policy(iptables_path, module, params) == 'DROP'



# Generated at 2022-06-23 03:55:45.323284
# Unit test for function append_csv
def test_append_csv():
    for param, result in [
        [['ESTABLISHED', 'NEW'], ['--ctstate', 'ESTABLISHED,NEW']],
        [[], ['--ctstate']]
    ]:
        rule = []
        append_csv(rule, param, '--ctstate')
        assert rule == result



# Generated at 2022-06-23 03:55:46.573951
# Unit test for function check_present
def test_check_present():
    assert check_present(True, True, {}) == True


# Generated at 2022-06-23 03:55:50.797736
# Unit test for function append_csv
def test_append_csv():
    rule = [ 'test' ]
    append_csv(rule, ['A','B'], 'testflag')
    assert rule[1] == 'testflag'
    assert rule[2] == 'A,B'



# Generated at 2022-06-23 03:55:56.288627
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = None
    iptables_path = '/sbin/iptables'
    params_false = dict(
        policy='',
        table='filter',
        chain='INPUT',
    )
    params_true = dict(
        policy='DROP',
        table='filter',
        chain='INPUT',
    )
    assert get_chain_policy(iptables_path, module, params_false) is None
    assert get_chain_policy(iptables_path, module, params_true) == 'DROP'



# Generated at 2022-06-23 03:56:00.992891
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == None
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-23 03:56:12.329888
# Unit test for function append_param
def test_append_param():
    rule = []
    param = 'test'
    flag = '--test'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['--test', 'test']

    param = ['test1', 'test2']
    is_list = True
    rule = []
    append_param(rule, param, flag, is_list)
    assert rule == ['--test', 'test1', '--test', 'test2']

    param = '!test'
    rule = []
    append_param(rule, param, flag, is_list)
    assert rule == ['!', '--test', 'test']



# Generated at 2022-06-23 03:56:16.219311
# Unit test for function get_iptables_version
def test_get_iptables_version():
    version = 'iptables v1.6.0'
    result = get_iptables_version(version, 1)
    assert result == '1.6.0'

# Generated at 2022-06-23 03:56:18.611713
# Unit test for function flush_table
def test_flush_table():
    assert flush_table('iptables', None, dict(table='mangle', chain=None)) == ['iptables', '-t', 'mangle', '-F']


# Generated at 2022-06-23 03:56:22.110772
# Unit test for function append_jump
def test_append_jump():
    rule_list=['-A','INPUT']
    string='ACCEPT'
    append_jump(rule_list,string,'jump')
    assert rule_list == ['-A','INPUT', '-j', 'ACCEPT']
    assert type(rule_list) is list



# Generated at 2022-06-23 03:56:24.476851
# Unit test for function append_param
def test_append_param():
    rule = []
    param = 'tcp'
    flag = '-p'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['-p', 'tcp']


# Generated at 2022-06-23 03:56:30.767633
# Unit test for function push_arguments
def test_push_arguments():
    result = push_arguments('cmd', '-I', {
        'table': 'raw',
        'chain': 'PREROUTING',
        'rule_num': '4',
        'protocol': 'icmp',
        'jump': 'DROP',
        'ip_version': 'ipv4'
    })
    assert result == ['cmd', '-t', 'raw', '-I', 'PREROUTING', '4', '-p', 'icmp', '-j', 'DROP']



# Generated at 2022-06-23 03:56:34.425593
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    assert append_tcp_flags(['iptables'], dict(flags=['ALL',], flags_set=['ACK']), '--tcp-flags') == ['iptables', '--tcp-flags', 'ALL', 'ACK']



# Generated at 2022-06-23 03:56:38.843042
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = 'testparam'

    append_csv(rule, param, 'testflag')

    assert(rule == ['testflag', 'testparam'])



# Generated at 2022-06-23 03:56:45.636280
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path="/usr/bin/sudo /sbin/iptables"
    params={}
    params['table']="filter"
    params['rule_num']="1"
    params['chain']="INPUT"
    params['protocol']="tcp"
    params['destination_port']="80"
    params['jump']="ACCEPT"
    params['comment']=None
    module=AnsibleModule('')
    insert_rule(iptables_path, module, params)



# Generated at 2022-06-23 03:56:50.334356
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert_params = {
        'table': 'filter',
        'chain': 'INPUT',
        'policy': 'DROP',
        'ip_version': 'ipv4'
    }
    assert_cmd = ['/sbin/iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']
    assert push_arguments('/sbin/iptables', '-P', assert_params, False) == assert_cmd
# End unit test



# Generated at 2022-06-23 03:57:03.021476
# Unit test for function insert_rule
def test_insert_rule():
    assert push_arguments("/sbin/iptables", '-I', {'chain':'INPUT', 'protocol':'tcp', 'destination_port':'80', 'jump':'ACCEPT', 'action':'insert', 'rule_num':'5'}) == ["/sbin/iptables", "-I", "INPUT", "5", "-p", "tcp", "--dport", "80", "-j", "ACCEPT"]

# Generated at 2022-06-23 03:57:14.797543
# Unit test for function insert_rule
def test_insert_rule():
    cmd = push_arguments('iptables', '-I', {'table': 'nat', 'chain': 'PREROUTING', 'protocol': 'tcp', 'match': 'tcp', 'destination_port': '80', 'jump': 'REDIRECT', 'to_ports': '8600', 'comment': 'Redirect web traffic to port 8600'})
    print(cmd)
    assert cmd == ['iptables', '-t', 'nat', '-I', 'PREROUTING', '-p', 'tcp', '-m', 'tcp', '--dport', '80', '-j', 'REDIRECT', '--to-ports', '8600', '--comment', 'Redirect web traffic to port 8600']



# Generated at 2022-06-23 03:57:19.920157
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = "ACCEPT"

    append_jump(rule, param, True)
    assert rule == ['-j', 'ACCEPT']

    rule = []
    append_jump(rule, '', False)
    assert rule == []



# Generated at 2022-06-23 03:57:29.303828
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, dict(flags=['SYN'], flags_set=['SYN']), '--tcp-flags')
    if rule[1] != 'SYN':
        raise AssertionError('Invalid flag.')
    if rule[2] != 'SYN':
        raise AssertionError('Invalid flag_set.')
    rule = []
    append_tcp_flags(rule, dict(flags=['ACK'], flags_set=['ACK','RST','PSH','FIN','SYN','URG']), '--tcp-flags')
    if rule[1] != 'ACK':
        raise AssertionError('Invalid flag.')

# Generated at 2022-06-23 03:57:38.403527
# Unit test for function check_present
def test_check_present():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(chain="INPUT", ip_version="ipv4", table="filter", protocol="tcp", dest_port="443", jump="ACCEPT")
    assert check_present(iptables_path, module, params) == True

#! /usr/bin/python3

import sys

sys.path.insert(0, ".")



# Generated at 2022-06-23 03:57:46.623608
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", None, {"policy" : "ACCEPT", "chain" : "FORWARD"}) == "ACCEPT"
    assert get_chain_policy("iptables", None, {"policy" : "DROP", "chain" : "FORWARD"}) == "DROP"
    assert get_chain_policy("iptables", None, {"policy" : "QUEUE", "chain" : "FORWARD"}) == "QUEUE"
    assert get_chain_policy("iptables", None, {"policy" : "RETURN", "chain" : "FORWARD"}) == "RETURN"
test_get_chain_policy()



# Generated at 2022-06-23 03:57:49.476922
# Unit test for function append_rule
def test_append_rule():
  return (push_arguments, 'ansible.builtin.iptables', '-A', params)


# Generated at 2022-06-23 03:57:58.353638
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec={})