

# Generated at 2022-06-23 03:48:01.979355
# Unit test for function construct_rule

# Generated at 2022-06-23 03:48:06.439295
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({})
    iptables_path = 'iptables'
    iptables_version = get_iptables_version(iptables_path, module)
    assert iptables_version



# Generated at 2022-06-23 03:48:14.145656
# Unit test for function main
def test_main():
    # pylint: disable=redefined-outer-name
    test_module = AnsibleModule(
        argument_spec=dict(
            state=dict(default='present',
                       choices=['present', 'absent']),
        )
    )
    test_args = dict(
        state='present',
        changed=False,
        failed=False,
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        flush=False,
        rule='-p tcp -m multiport --dports 80,443 -m comment --comment "HTTP and HTTPS" -j ACCEPT',
        state='present',
    )
    assert main() == test_args
# unit test for function push_arguments

# Generated at 2022-06-23 03:48:25.250437
# Unit test for function push_arguments

# Generated at 2022-06-23 03:48:36.816669
# Unit test for function construct_rule

# Generated at 2022-06-23 03:48:39.346332
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = 'iptables'
    module = ''
    params = ''
    return insert_rule(iptables_path, module, params)


# Generated at 2022-06-23 03:48:48.277288
# Unit test for function get_iptables_version
def test_get_iptables_version():
    class Dummy:
        def __init__(self):
            self.run_command_calls = []
            self.run_command_return_value = 0, 'blah v1.2.3', None

        def run_command(self, cmd, **kwargs):
            self.run_command_calls.append((cmd, kwargs))
            return self.run_command_return_value

    iptables_path = '/bin/iptables'
    m = Dummy()
    result = get_iptables_version(iptables_path, m)
    assert result == '1.2.3'
    expected_calls = [
        ([iptables_path, '--version'], {'check_rc': True})
    ]
    assert m.run_command_calls == expected_calls



# Generated at 2022-06-23 03:48:51.488351
# Unit test for function append_csv
def test_append_csv():
    r = []
    append_csv(r, ['a', 'b'], '--ab')
    assert r == ['--ab', 'a,b']



# Generated at 2022-06-23 03:48:54.428744
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '1000', '--wait')
    assert rule == ['--wait', '1000']


# Generated at 2022-06-23 03:48:59.558413
# Unit test for function append_csv
def test_append_csv():
    rule = list()
    param = list()
    param.append("1")
    param.append("2")
    append_csv(rule, param, 'test')
    assert rule == ['test', '1,2']



# Generated at 2022-06-23 03:49:03.656635
# Unit test for function append_param
def test_append_param():
    rule = list()
    append_param(rule, None, '--source', False)
    assert rule == []
    append_param(rule, '', '--source', False)
    assert rule == []
    append_param(rule, 'foo', '--source', False)
    assert rule == ['--source', 'foo']
    append_param(rule, '', '--source', False)
    assert rule == ['--source', 'foo']
    append_param(rule, '', '--source', False)
    assert rule == ['--source', 'foo']
    rule = list()
    append_param(rule, '!', '--source', False)
    assert rule == ['!', '--source']
    append_param(rule, '!foo', '--source', False)

# Generated at 2022-06-23 03:49:06.146724
# Unit test for function flush_table
def test_flush_table():
    _iptables_path = '/usr/sbin/iptables'
    _module = AnsibleModule()
    _params = dict(
        chain='INPUT',
        table='filter',
    )
    flush_table(_iptables_path, _module, _params)



# Generated at 2022-06-23 03:49:07.927848
# Unit test for function check_present
def test_check_present():
    cmd = ['iptables', '-t', 'filter', '-C']
    rc, _, __ = module.run_command(cmd, check_rc=False)
    return (rc == 0)


# Generated at 2022-06-23 03:49:08.811269
# Unit test for function append_rule
def test_append_rule():
    assert check_present('iptables', module, params)
    delete_rule('iptables', module, params)



# Generated at 2022-06-23 03:49:12.378058
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    append_match_flag(rule, param, '-p', False)
    assert rule == ['-p']


# Generated at 2022-06-23 03:49:24.190161
# Unit test for function append_wait
def test_append_wait():
    assert append_wait(['iptables', '-I', 'INPUT', '-'], '5', '-w') == ['iptables', '-I', 'INPUT', '-', '-w', '5']
    assert not append_wait(['iptables', '-I', 'INPUT', '-'], '', '-w') == ['iptables', '-I', 'INPUT', '-', '-w', '']
    assert not append_wait(['iptables', '-I', 'INPUT', '-'], 5, '-w') == ['iptables', '-I', 'INPUT', '-', '-w', 5]

# Generated at 2022-06-23 03:49:27.122801
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, None, '--tcp-flags')
    append_tcp_flags(rule, dict(), '--tcp-flags')
    append_tcp_flags(rule, dict(flags='ALL', flags_set='ACK,RST,SYN,FIN'), '--tcp-flags')
    assert rule == [
        '--tcp-flags',
        'ALL',
        'ACK,RST,SYN,FIN',
    ], 'append_tcp_flags function does not work properly'



# Generated at 2022-06-23 03:49:36.543030
# Unit test for function append_match_flag
def test_append_match_flag():
  param = 'match'
  flag = '--tcp-flags'
  negatable = True
  rule = []
  append_match_flag(rule, param, flag, negatable)
  assert rule == [flag]

  param = 'negate'
  flag = '--tcp-flags'
  negatable = True
  rule = []
  append_match_flag(rule, param, flag, negatable)
  assert rule == ['!', flag]

  param = ''
  flag = '--tcp-flags'
  negatable = True
  rule = []
  append_match_flag(rule, param, flag, negatable)
  assert rule == []


# Generated at 2022-06-23 03:49:39.287583
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, 'state', 'state')
    assert rule == ['-m', 'state']



# Generated at 2022-06-23 03:49:43.028342
# Unit test for function flush_table
def test_flush_table():
    params = {'table': 'filter', 'chain': 'INPUT', 'flush': True}
    flush_table.__globals__['module'] = True
    flush_table.__globals__['BINS'] = BINS
    flush_table('iptables', True, params)



# Generated at 2022-06-23 03:49:46.729416
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, "test_match")
    assert rule == ['-m', 'test_match']
    rule = []
    append_match(rule, False, "test_match")
    assert rule == []



# Generated at 2022-06-23 03:49:57.581377
# Unit test for function remove_rule
def test_remove_rule():
    class MockedModule:
        run_command_args = []
        def __init__(self, **kwargs):
            self.params = kwargs
            self.fail_json = lambda **kwargs: kwargs

        def run_command(self, args, check_rc=False):
            MockedModule.run_command_args.append({
                'args': args,
                'check_rc': check_rc,
            })
            return 0, '', ''


# Generated at 2022-06-23 03:50:09.491042
# Unit test for function push_arguments
def test_push_arguments():
    expected_cmd = [
        '/sbin/iptables',
        '-t', 'filter',
        '-A', 'INPUT',
        '-s', '192.168.1.1',
        '-p', 'udp',
        '--dport', '80'
    ]
    params = dict(
        chain='INPUT',
        protocol='udp',
        source='192.168.1.1',
        destination_port='80',
        ip_version='ipv4',
        table='filter',
    )
    assert push_arguments('/sbin/iptables', '-A', params) == expected_cmd


# Generated at 2022-06-23 03:50:12.958757
# Unit test for function flush_table
def test_flush_table():
    assert ['/sbin/iptables', '-t', 'nat', '-F','POSTROUTING'] == flush_table('/sbin/iptables', {}, {'table' : 'nat', 'chain': 'POSTROUTING'})


# Generated at 2022-06-23 03:50:16.054976
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = "iptables"
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type="str"),
        policy=dict(type="str")))
    params = module.params
    params["policy"] = "DROP"
    params["table"] = "filter"
    set_chain_policy(iptables_path, module, params)
    assert(params["policy"] == "DROP")



# Generated at 2022-06-23 03:50:20.512189
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--match', True)
    append_match_flag(rule, 'negate', '--match', True)
    assert '--match'.split() == rule
    rule = []
    append_match_flag(rule, 'negate', '--match', False)
    assert '--match'.split() == rule



# Generated at 2022-06-23 03:50:25.986949
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        chain='INPUT', table='filter', protocol='tcp', rule_num=5, jump='ACCEPT',
        )
    assert insert_rule('iptables', module, params) == ['-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '-j', 'ACCEPT']
    params = dict(
        chain='INPUT', table='filter', action='insert', protocol='tcp',
        rule_num=5, jump='ACCEPT'
        )
    assert insert_rule('iptables', module, params) == ['-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '-j', 'ACCEPT']

# Generated at 2022-06-23 03:50:30.272274
# Unit test for function append_csv
def test_append_csv():
    x = []
    append_csv(x, ['1', '2', '3'], '--flag')
    assert x == ['--flag', '1,2,3']
    x = []
    append_csv(x, [], '--flag')
    assert x == []



# Generated at 2022-06-23 03:50:41.110740
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = ''
    #module = ''
    params = dict(table='nat', chain='PREROUTING', protocol='tcp',
                  destination_ports=['80', '443', '8081:8083'], jump='ACCEPT',
                  ip_version='ipv4')
    expected = ['iptables', '-t', 'nat', '-D', 'PREROUTING', '-p', 'tcp', '--dports', '80,443,8081:8083', '-j', 'ACCEPT', '-w']
    actual = remove_rule(iptables_path, '', params)
    assert(actual == expected)



# Generated at 2022-06-23 03:50:46.085057
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['ESTABLISHED', 'RELATED']
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert rule == ['--ctstate', 'ESTABLISHED,RELATED'], "append_csv(rule, param, flag) function is wrong"


# Generated at 2022-06-23 03:50:58.840696
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version = 'ipv4',
        protocol = 'tcp',
        source = '192.168.100.0/24',
        destination = '192.168.200.0/24',
        source_port = '80',
        destination_port = '22',
        to_ports = '!8022',
        syn = 'negate',
        ctstate = ['NEW', 'ESTABLISHED'],
        limit = '5/min',
        limit_burst = '10',
        uid_owner = 'root',
        gid_owner = '!root',
        reject_with = 'icmp-port-unreachable',
        icmp_type = '!echo-request',
        comment = 'Test rule',
    )

# Generated at 2022-06-23 03:51:01.702740
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, "match", "-p", False)
    assert len(rule) == 1
    assert rule[0] == "-p"
    rule = []
    append_match_flag(rule, "negate", "-p", True)
    assert len(rule) == 2
    assert rule[0] == "!"
    assert rule[1] == "-p"


# Generated at 2022-06-23 03:51:03.974132
# Unit test for function get_iptables_version
def test_get_iptables_version():
    version = get_iptables_version('/usr/sbin/iptables', module)
    assert version == '1.4.21'



# Generated at 2022-06-23 03:51:05.347870
# Unit test for function append_wait
def test_append_wait():
    assert append_wait([], '1', '--wait') == ['--wait', '1']


# Generated at 2022-06-23 03:51:14.378442
# Unit test for function push_arguments
def test_push_arguments():
    module = AnsibleModule({
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': '1',
        'protocol': 'tcp',
        'destination_port': '443',
        'ctstate': 'NEW',
        'jump': 'ACCEPT',
        'comment': 'Accept HTTPS Connections',
    })
    params = module.params
    rule = ' '.join(construct_rule(params))
    cmd = ' '.join(push_arguments('iptables', '-I', params))
    assert rule in cmd



# Generated at 2022-06-23 03:51:19.265358
# Unit test for function append_match
def test_append_match():
    rule = ["-P", "FORWARD", "ACCEPT"]
    param = "match"
    match = "match"

    append_match(rule, param, match)

    assert rule == ["-P", "FORWARD", "ACCEPT", "-m", match]
#End unit test


# Generated at 2022-06-23 03:51:29.854069
# Unit test for function push_arguments
def test_push_arguments():
    r = push_arguments('/usr/sbin/iptables', '-I', dict(
        table='nat',
        chain='INPUT',
        rule_num=1,
        action='insert',
        comment='test',
        destination_port=80,
        jump='ACCEPT',
        protocol='tcp',
    ))
    assert r == ['/usr/sbin/iptables', '-t', 'nat', '-I', 'INPUT', '1', '-p',
                 'tcp', '--dport', '80', '-j', 'ACCEPT', '-m', 'comment',
                 ['-c', 'test']]



# Generated at 2022-06-23 03:51:33.985760
# Unit test for function insert_rule
def test_insert_rule():
    class AnsibleModule_Cus:
        def __init__(self):
            self.run_command = "cmd"
            self.run_command_result = 0
    ansibleModule = AnsibleModule_Cus()

    params = {
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'insert',
        'rule_num': '5',
        'table': 'filter'
    }
    iptables_path = "iptables"
    insert_rule(iptables_path, ansibleModule, params)



# Generated at 2022-06-23 03:51:35.643859
# Unit test for function append_rule
def test_append_rule():
    assert append_rule == '-A'



# Generated at 2022-06-23 03:51:37.291327
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(path, module) == '1.4.21'

# Generated at 2022-06-23 03:51:44.146852
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule({'table': 'filter'},
                           supports_check_mode=True)
    assert check_present(
        'iptables',
        module, {
            'chain': 'INPUT',
            'protocol': 'tcp',
            'destination_port': '22',
            'ctstate': 'NEW',
            'syn': 'match',
            'jump': 'ACCEPT',
            'comment': 'Accept new SSH connections.',
            'ip_version': 'ipv4'})



# Generated at 2022-06-23 03:51:48.327967
# Unit test for function append_tcp_flags

# Generated at 2022-06-23 03:51:59.402183
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda cmd, check_rc=False: (0, "", "")

    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port=8080,
        jump='ACCEPT',
        rule_num=5,
        ip_version='ipv4'
    )
    iptables_path = 'iptables'

    rule = [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--dport', '8080',
        '-j', 'ACCEPT'
    ]

# Generated at 2022-06-23 03:52:10.588262
# Unit test for function push_arguments

# Generated at 2022-06-23 03:52:13.985231
# Unit test for function get_iptables_version
def test_get_iptables_version():
    version = get_iptables_version()
    assert version == '1.6.1'
    assert LooseVersion(version) > LooseVersion(IPTABLES_WAIT_WITH_SECONDS_SUPPORT_ADDED)



# Generated at 2022-06-23 03:52:22.166830
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_list = []
    append_tcp_flags(test_list, {
        'flags': ['ACK', 'RST', 'SYN', 'FIN'],
        'flags_set': ['ACK', 'RST', 'SYN', 'FIN'],
    }, '--tcp-flags')
    expected = ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']
    assert test_list == expected
    test_list = []
    append_tcp_flags(test_list, None, '--tcp-flags')
    assert test_list == []


# Generated at 2022-06-23 03:52:27.406588
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN']
    )
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-23 03:52:33.565829
# Unit test for function append_match_flag
def test_append_match_flag():
    tests = [('match', '--syn', True,  '--syn'),
            ('negate', '--syn', True, '! --syn'),
            ('match', '--syn', False, '--syn')]

    for (v, f, n, e) in tests:
        rule = []
        append_match_flag(rule, v, f, n)
        res = ' '.join(rule)
        if res != e:
            raise AssertionError("{} != {}".format(res, e))


# Generated at 2022-06-23 03:52:38.440183
# Unit test for function append_wait
def test_append_wait():
    assert append_wait([], '5', '-w') == ['-w', '5']


# Generated at 2022-06-23 03:52:40.215825
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['ESTABLISHED', 'NEW']
    flag = '--ctstate'

    append_csv(rule, param, flag)

    assert rule == [flag, 'ESTABLISHED,NEW']



# Generated at 2022-06-23 03:52:42.600318
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', '1.4.21\n') == '1.4.21'



# Generated at 2022-06-23 03:52:49.342686
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/bin/dummy-iptables'
    module = ['/bin/dummy-module']
    params = {}
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    assert remove_rule(iptables_path, module, params) is None



# Generated at 2022-06-23 03:53:01.648066
# Unit test for function main
def test_main():
    REQUEST_METHOD = 'POST'
    # Set up mock module and parameters

# Generated at 2022-06-23 03:53:05.550188
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {}
    flag = '--tcp-flags'
    param['flags'] = ['ACK', 'RST', 'SYN', 'FIN']
    param['flags_set'] = ['ACK', 'RST', 'SYN', 'FIN']
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags','ACK,RST,SYN,FIN','ACK,RST,SYN,FIN']



# Generated at 2022-06-23 03:53:08.115329
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, 'match')
    assert rule == ['-m', 'match']


# Generated at 2022-06-23 03:53:15.875617
# Unit test for function construct_rule
def test_construct_rule():
    def test(params, expected_output, output_format=None):
        if output_format == 'str':
            actual = ' '.join(construct_rule(params))
            if expected_output != actual:
                return 'params: %s\nexpected: %s\nactual: %s' % (params, expected_output, actual)
        else:
            expected_output = expected_output.split()
            actual = construct_rule(params)
            if expected_output != actual:
                return 'params: %s\nexpected: %s\nactual: %s' % (params, expected_output, actual)


# Generated at 2022-06-23 03:53:17.903057
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule,"match", "tcp")
    assert rule == ['-m', 'tcp']



# Generated at 2022-06-23 03:53:20.933639
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['a', 'b', 'c']
    flag = '-p'
    assert append_csv(rule, param, flag) == rule.append(flag)



# Generated at 2022-06-23 03:53:27.516079
# Unit test for function append_match_flag
def test_append_match_flag():
    # Append negatable flag
    a = []
    append_match_flag(a, 'match', '--syn', True)
    assert a == ['--syn']
    a = []
    append_match_flag(a, 'negate', '--syn', True)
    assert a == ['!', '--syn']
    # Don't append parameter
    a = []
    append_match_flag(a, 'ignore', '--syn', True)
    assert a == []



# Generated at 2022-06-23 03:53:32.147520
# Unit test for function flush_table
def test_flush_table():
    print('test_flush_table')
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule
    params = {'table': 'filter', 'chain': 'FORWARD'}
    flush_table('iptables', module, params)



# Generated at 2022-06-23 03:53:36.814415
# Unit test for function append_match_flag
def test_append_match_flag():
    result_match_flag = []
    result_negatable_flag = []
    append_match_flag(result_match_flag, 'match', '--first-match', False)
    append_match_flag(result_negatable_flag, 'negate', '--first-match', True)
    return result_match_flag == ['--first-match'] and result_negatable_flag == ['!', '--first-match']



# Generated at 2022-06-23 03:53:44.851208
# Unit test for function flush_table
def test_flush_table():
    test_module = AnsibleModule({'ip_version': 'ipv4'})
    module=test_module
    cmd = push_arguments("iptables", '-F', {'table': 'filter', 'chain': 'INPUT'}, make_rule=False)
    rc, _, __ = module.run_command(cmd, check_rc=False)
    assert rc == 0


# Generated at 2022-06-23 03:53:48.242200
# Unit test for function check_present
def test_check_present():
    assert(check_present("iptables","module","params"))


# Generated at 2022-06-23 03:53:52.726953
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '-p', False)
    assert rule == ['-p']
    rule = []
    append_match_flag(rule, 'mismatch', '-p', False)
    assert rule == []
    rule = []
    append_match_flag(rule, 'match', '-p', True)
    assert rule == ['-p']
    rule = []
    append_match_flag(rule, 'negate', '-p', True)
    assert rule == ['!', '-p']
    rule = []
    append_match_flag(rule, None, '-p', True)
    assert rule == []


module = None
module_result = dict(
    changed=False,
    messages=[]
)



# Generated at 2022-06-23 03:53:55.965082
# Unit test for function append_jump
def test_append_jump():
    assert append_jump(['--policy','ACCEPT'], 'ACCEPT','ACCEPT') == None



# Generated at 2022-06-23 03:54:04.232583
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, dict(flags='ALL', flags_set=['ACK', 'RST', 'SYN', 'FIN']), '--tcp-flags')
    assert rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']
    rule = []
    append_tcp_flags(rule, None, '--tcp-flags')
    assert rule == []



# Generated at 2022-06-23 03:54:11.155242
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = ["/sbin/iptables", "-P", "INPUT", "ACCEPT"]
    # Here check the cmd is right or not
    assert cmd == ["/sbin/iptables", "-P", "INPUT", "ACCEPT"]


# Generated at 2022-06-23 03:54:15.382136
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table="filter",
        chain="INPUT",
        rule_num="5",
    )
    assert push_arguments("/usr/bin/iptables", "-I", params, False) == ['/usr/bin/iptables', '-t', 'filter', '-I', 'INPUT', '5']



# Generated at 2022-06-23 03:54:27.468905
# Unit test for function construct_rule

# Generated at 2022-06-23 03:54:34.334912
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    params = {
        'chain': 'INPUT',
        'action': 'insert',
        'rule_num': '1',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'table': 'filter',
    }
    insert_rule(iptables_path, params)



# Generated at 2022-06-23 03:54:38.932847
# Unit test for function append_wait
def test_append_wait():
      rule = [ 'iptables', '-A', 'INPUT' ]
      param = 5
      flag = '--wait'
      append_wait(rule, param, flag)
      assert  rule == [ 'iptables', '-A', 'INPUT', '--wait', '5' ]
   


# Generated at 2022-06-23 03:54:53.321917
# Unit test for function main
def test_main():
    import inspect
    import json
    import shlex
    import os
    import tempfile
    module_name = 'iptables'
    module_args = 'table=filter chain=INPUT rule_num=2 in_interface=lo jump=ACCEPT protocol=tcp ctstate=NEW,ESTABLISHED tcp_flags=flags_set=SYN tcp_flags=flags_set=ACK tcp_flags=flags=SYN,RST,ACK,FIN,URG tcp_flags=flags=SYN,RST,ACK,FIN,URG comment="Test comment"'

    # Training the module_utils/basic.py module
    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Import basic 

# Generated at 2022-06-23 03:54:55.440925
# Unit test for function append_csv
def test_append_csv():
    assert(append_csv(['iptables', '-A'], ['drop'], '--jump') == ['iptables', '-A', '--jump', 'drop'])


# Generated at 2022-06-23 03:55:09.407486
# Unit test for function main

# Generated at 2022-06-23 03:55:11.103219
# Unit test for function push_arguments
def test_push_arguments():
    print(push_arguments('/sbin/iptables','A','INPUT',True))


# Generated at 2022-06-23 03:55:14.328516
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']


# Generated at 2022-06-23 03:55:16.397932
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, 'tcp')
    assert rule == ['-m', 'tcp']
    rule = []
    append_match(rule, False, 'tcp')
    assert rule == []


# Generated at 2022-06-23 03:55:22.232236
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, '100', '--set-dscp', False)
    assert rule == ['--set-dscp', '100']
    rule = []
    append_param(rule, '!100', '--set-dscp', False)
    assert rule == ['!', '--set-dscp', '100']


# Generated at 2022-06-23 03:55:33.431605
# Unit test for function main

# Generated at 2022-06-23 03:55:36.048986
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert push_arguments('iptables', '-P', {'policy': 'ACCEPT', 'chain': 'INPUT', 'table': 'filter'}, make_rule=False) == ['iptables', '-t', 'filter', '-P', 'INPUT', 'ACCEPT']


# Generated at 2022-06-23 03:55:40.187733
# Unit test for function append_wait
def test_append_wait():
    """Appending wait option to iptables command."""
    rule = []
    wait_value = '10'
    append_wait(rule, wait_value, '--wait')
    assert rule == ['--wait', wait_value]
    rule = []
    wait_value = ''
    append_wait(rule, wait_value, '--wait')
    assert rule == []
    rule = []
    wait_value = 78
    append_wait(rule, wait_value, '--wait')
    assert rule == []


# Generated at 2022-06-23 03:55:48.339169
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([''], 'match', '--syn', True) == ['--syn']
    assert append_match_flag([''], 'negate', '--syn', True) == ['!', '--syn']
    assert append_match_flag([''], 'negate', '--syn', False) == ['']
    assert append_match_flag([''], 'another', '--syn', True) == ['']
    assert append_match_flag([''], 'another', '--syn', False) == ['']



# Generated at 2022-06-23 03:55:54.781417
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils import basic
    import ansible.modules.network.firewall.iptables as module
    module.iptables_path = 'iptables'
    module.BINS = BINS
    module.ICMP_TYPE_OPTIONS = ICMP_TYPE_OPTIONS
    module.construct_rule = construct_rule
    basic._ANSIBLE_ARGS = ['-vvv', '-C']

# Generated at 2022-06-23 03:56:01.251210
# Unit test for function append_rule
def test_append_rule():
    print('#### Testing append_rule() ####')
    module = AnsibleModule(argument_spec={'iptables_path': {'type': 'str'}, 'params': {'type': 'dict'}})
    assert (len(append_rule(module.params.get('iptables_path'), module, module.params.get('params'))) == 0)



# Generated at 2022-06-23 03:56:06.825260
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    rule_input = {'flags': ['ACK', 'SYN', 'FIN'], 'flags_set': ['ACK', 'SYN', 'FIN']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, rule_input, flag)
    assert rule == ['--tcp-flags', 'ACK,SYN,FIN', 'ACK,SYN,FIN']



# Generated at 2022-06-23 03:56:08.593970
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:56:18.645129
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK'], flags_set=['SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK', 'SYN,FIN']
    rule = ['iptables', '-A', 'INPUT', '-p', 'tcp']
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['iptables', '-A', 'INPUT', '-p', 'tcp', '--tcp-flags', 'ACK', 'SYN,FIN']



# Generated at 2022-06-23 03:56:22.153319
# Unit test for function append_csv
def test_append_csv():
    rule = list()
    test_list = ["item1","item2","item3"]
    expected_rule = [ '--comment', 'item1,item2,item3' ]
    append_csv(rule, test_list, "--comment")
    assert rule == expected_rule


# Generated at 2022-06-23 03:56:26.758158
# Unit test for function check_present
def test_check_present():
    ipv4_params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'ctstate': 'NEW',
        'syn': 'match',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.',
    }
    assert check_present('iptables', DummyModule(ipv4_params), ipv4_params)


# Generated at 2022-06-23 03:56:31.336872
# Unit test for function flush_table
def test_flush_table():
    """
    Unit test for function flush_table.
    """
    assert flush_table('iptables', 'module', {'table': 'filter', 'chain': 'INPUT'}) is None



# Generated at 2022-06-23 03:56:37.720518
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        chain = 'INPUT',
        policy = 'DROP',
        ip_version = 'ipv4'
    )
    iptables_path = BINS['ipv4']
    module = type('', (), dict(run_command=lambda x,y: x))
    assert set_chain_policy(iptables_path, module, params) == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']


# Generated at 2022-06-23 03:56:40.473727
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/usr/sbin/iptables', None) == get_iptables_version.__annotations__['return']



# Generated at 2022-06-23 03:56:44.900918
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule({})
    iptables_path = '/sbin/iptables' # Mock path
    params = dict(
        table='filter',
        chain='INPUT',
        source='8.8.8.8',
        jump='DROP',
    )
    cmd = push_arguments(iptables_path, '-C', params)
    rc, _, __ = module.run_command(cmd, check_rc=False)
    assert check_present(iptables_path, module, params) == (rc == 0)



# Generated at 2022-06-23 03:56:48.534535
# Unit test for function append_match
def test_append_match():
    list = []
    append_match(list, 'test', 'test')
    assert list == ['-m', 'test']
    list = []
    append_match(list, None, 'test')
    assert list == []



# Generated at 2022-06-23 03:56:52.605683
# Unit test for function append_jump
def test_append_jump():
        rule = []
        jump = 'test-jump'
        param = 'test-param'
        append_jump(rule, param, jump)
        assert rule == ['-j', 'test-param']


# Generated at 2022-06-23 03:56:57.689339
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/iptables', 'iptables v1.4.21') == '1.4.21'
    assert get_iptables_version('/sbin/iptables', 'iptables v1.6.0') == '1.6.0'



# Generated at 2022-06-23 03:57:04.035021
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({
        'iptables_path': 'iptables',
        'chain': 'INPUT',
        'policy': 'DROP',
        'table': 'filter'
    })
    set_chain_policy('iptables', module, module.params)
    module.exit_json()



# Generated at 2022-06-23 03:57:07.375080
# Unit test for function get_chain_policy
def test_get_chain_policy():
    policy = "DROP"
    line = "Chain INPUT (policy %s)" % policy
    result = re.search(r'\(policy ([A-Z]+)\)', line)
    if result:
        assert result.group(1) == policy


# Generated at 2022-06-23 03:57:10.862726
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, "5", '--wait')
    assert rule == ["--wait", "5"]


# Generated at 2022-06-23 03:57:13.460400
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '1', '-w')
    assert rule == ['-w', '1']



# Generated at 2022-06-23 03:57:18.413448
# Unit test for function construct_rule
def test_construct_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        ip_version='ipv4',
        source='8.8.8.8',
        jump='DROP',
        comment='Drop Google DNS'
    )
    rule = construct_rule(params)
    assert rule == ['-s', '8.8.8.8', '-j', 'DROP', '-m', 'comment', '--comment', 'Drop Google DNS']

    # Test for multiple matches
    params = dict(
        ip_version='ipv4',
        match=['state', 'conntrack'],
        ctstate=['ESTABLISHED', 'RELATED']
    )
    rule = construct_rule(params)

# Generated at 2022-06-23 03:57:28.607604
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='nat',
        chain='INPUT',
        protocol='tcp',
        dport='80',
        jump='ACCEPT',
    )
    assert push_arguments('path/to/iptables', '-I', params) == [
        'path/to/iptables',
        '-t', 'nat',
        '-I', 'INPUT',
        '-p', 'tcp',
        '--dport', '80',
        '-j', 'ACCEPT',
    ]
    params = dict(
        table='nat',
        chain='INPUT',
        protocol='tcp',
        dport='80',
        jump='ACCEPT',
        rule_num='7',
    )
    assert push_arguments('path/to/iptables', '-I', params)

# Generated at 2022-06-23 03:57:34.952159
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['ahh', 'I', 'have', 'symptoms'], '--cough')
    assert rule == ['--cough', 'ahh,I,have,symptoms']



# Generated at 2022-06-23 03:57:40.402709
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST'],
    )
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == [ '--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST' ]



# Generated at 2022-06-23 03:57:43.022398
# Unit test for function set_chain_policy
def test_set_chain_policy():
    print(set_chain_policy('iptables',None,dict(table='filter',chain='FORWARD',policy='ACCEPT',ip_version='ipv4')))


# Generated at 2022-06-23 03:57:45.160516
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('/bin/iptables', '', 'INPUT') == 'ACCEPT'



# Generated at 2022-06-23 03:57:55.289921
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN'],
    )
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']
