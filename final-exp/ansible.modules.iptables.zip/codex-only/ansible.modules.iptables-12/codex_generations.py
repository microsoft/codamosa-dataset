

# Generated at 2022-06-23 03:48:00.123561
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = 'iptables'
    module = module_args = dict(
        chain='INPUT', policy='DROP', rule_num=None
    )
    cmd = set_chain_policy(iptables_path, module, module_args)
    print('ok')
# test_set_chain_policy()



# Generated at 2022-06-23 03:48:02.963076
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, "test", "--test", False)
    assert rule == ['--test', 'test']

    rule = []
    append_param(rule, ["test", "test2"], "--test", True)
    assert rule == ['--test', 'test', '--test', 'test2']

    rule = []
    append_param(rule, ["test", "!test2"], "--test", True)
    assert rule == ['--test', 'test', '!', '--test', 'test2']



# Generated at 2022-06-23 03:48:08.038655
# Unit test for function construct_rule

# Generated at 2022-06-23 03:48:18.771709
# Unit test for function push_arguments
def test_push_arguments():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.compat.version import LooseVersion
    iptables_path = '/bin/iptables'
    action = '-I'

# Generated at 2022-06-23 03:48:24.691540
# Unit test for function append_jump
def test_append_jump():
    rule = []
    output = []
    param = "ACCEPT"
    jump = "ACCEPT"
    append_jump(rule, param, jump)
    output = rule
    assert output == ['-j', 'ACCEPT']



# Generated at 2022-06-23 03:48:35.751508
# Unit test for function append_wait
def test_append_wait():
    # Test with wait seconds specified
    rule = []
    param = '1'
    flag = '--wait'
    assert append_wait(rule, param, flag) == None
    assert len(rule) == 2
    assert rule == [flag, param]
    # Test with wait seconds not specified
    rule = []
    param = '0'
    flag = '--wait'
    assert append_wait(rule, param, flag) == None
    assert len(rule) == 0
    assert rule == []
    # Test when parameter is None
    rule = []
    param = None
    flag = '--wait'
    assert append_wait(rule, param, flag) == None
    assert len(rule) == 0
    assert rule == []


# Generated at 2022-06-23 03:48:40.860215
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], 'match', '-p', False) == ['-p']
    assert append_match_flag([], 'negate', '-p', True) == ['!', '-p']
    assert append_match_flag([], 'negate', '-p', False) == []
    assert append_match_flag([], None, '-p', False) == []


# Generated at 2022-06-23 03:48:51.109370
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.six import StringIO
    import sys

    class MockModule(object):
        def __init__(self):
            self.run_command = None
            self.params = None
            self.exit_json = None
            self.fail_json = None

        def fail_json_forcefully(self, msg):
            raise Exception("intentionally fail without fail_json")

    class MockAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            kwargs = kwargs.copy()

# Generated at 2022-06-23 03:48:55.295247
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version("/usr/sbin/iptables", "") == "1.4.21"
    assert get_iptables_version("/usr/sbin/iptables", "") != "1.4.22"


# Generated at 2022-06-23 03:48:58.955822
# Unit test for function get_chain_policy
def test_get_chain_policy():
    policy = get_chain_policy(None, None, {'table': 'filter', 'chain': 'INPUT'})
    assert policy == 'ACCEPT'
    return "OK"



# Generated at 2022-06-23 03:49:00.404481
# Unit test for function append_param
def test_append_param():
    rule = []
    param = "1234"
    flag = "--test"
    res = append_param(rule, param, flag, False)
    assert res == None
    assert rule == [flag, param]


# Generated at 2022-06-23 03:49:05.591333
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        chain='INPUT',
        policy='DROP',
        ip_version='ipv4',
    )
    cmd = push_arguments(
        'iptables',
        '-P',
        params,
        make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']


    params = dict(
        chain='INPUT',
        policy='DROP',
        ip_version='ipv6',
    )
    cmd = push_arguments(
        'ip6tables',
        '-P',
        params,
        make_rule=False)
    cmd.append(params['policy'])

# Generated at 2022-06-23 03:49:08.306061
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, '!123', '--destination-port', False)
    assert rule == ['!', '--destination-port', '123']
    append_param(rule, ['1', '!2'], '--destination-port', True)
    assert rule == ['!', '--destination-port', '123',
                    '--destination-port', '1',
                    '!', '--destination-port', '2']


# Generated at 2022-06-23 03:49:19.602001
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec = dict())
    it = 'iptables'
    params = dict()
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['protocol'] = 'tcp'
    params['destination_port'] = 21
    params['jump'] = 'DROP'
    params['match'] = 'comment'
    params['comment'] = 'FTP'
    params['rule_num'] = 4
    params_updated = construct_rule(params)
    params_updated.extend(['-I','INPUT','4'])
    params_updated.insert(0,it)
    params_updated.insert(1,'-t')
    params_updated.insert(2,'filter')
    assert push_arguments(it, '-I', params) == params

# Generated at 2022-06-23 03:49:26.580252
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = list()
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'SYN']
    )
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,SYN']



# Generated at 2022-06-23 03:49:30.949040
# Unit test for function append_wait
def test_append_wait():
    rule = []
    expected = ["--wait", "test"]
    param = "test"
    flag = "--wait"
    append_wait(rule, param, flag)
    assert(rule) == expected
    return True



# Generated at 2022-06-23 03:49:33.406223
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = "DROP"
    jump = "ACCEPT"
    append_jump(rule,param,jump)
    print(rule)


# Generated at 2022-06-23 03:49:39.464465
# Unit test for function append_csv
def test_append_csv():
    assert append_csv(['iptables'], ['new', 'established', 'related'], '--ctstate') == ['iptables', '--ctstate', 'new,established,related']
    assert append_csv(['iptables'], ['new'], '--ctstate') == ['iptables', '--ctstate', 'new']
    assert append_csv(['iptables'], None, '--ctstate') == ['iptables']



# Generated at 2022-06-23 03:49:39.862962
# Unit test for function flush_table
def test_flush_table():
    pass



# Generated at 2022-06-23 03:49:47.073427
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []

    append_match_flag(rule, 'match', '--syn', True)
    assert_equal(rule, ['--syn'])

    append_match_flag(rule, 'negate', '--syn', True)
    assert_equal(rule, ['!', '--syn'])

    # Test negative case
    append_match_flag(rule, 'unknown', '--syn', True)
    assert_equal(rule, ['!', '--syn'])



# Generated at 2022-06-23 03:49:54.358994
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('/sbin/iptables', 'module', {'policy':'DROP', 'chain':'INPUT'}), "-P INPUT DROP"
    assert not set_chain_policy('/sbin/iptables', 'module', {'policy':'DROP', 'chain':'INPUT'}), "-P INPUT DROP"



# Generated at 2022-06-23 03:50:01.830947
# Unit test for function construct_rule
def test_construct_rule():
    module = basic_module('INPUT', '', '8.8.8.8', 'DROP', '', '', '')
    assert construct_rule(module.params) == ['-j DROP']
    module = basic_module('INPUT', '', '8.8.8.8', 'DROP', '', '', '')
    assert construct_rule(module.params) == ['-j DROP']
    module = basic_module('INPUT', '', '8.8.8.8', 'DROP', '', '', '')
    assert construct_rule(module.params) == ['-j DROP']
    module = basic_module('INPUT', '', '8.8.8.8', 'DROP', '', '', '')
    assert construct_rule(module.params) == ['-j DROP']

# Generated at 2022-06-23 03:50:05.934246
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = "ACCEPT"
    jump = "ACCEPT"
    append_jump(rule, param, jump)
    assert rule[0] == '-j' and rule[1] == 'ACCEPT'



# Generated at 2022-06-23 03:50:10.475103
# Unit test for function append_match
def test_append_match():
    rule1 = []
    rule2 = []
    append_match(rule1, True, 'match')
    append_match(rule2, False, 'match')
    assert rule1 == [ '-m', 'match']
    assert rule2 == []



# Generated at 2022-06-23 03:50:12.122591
# Unit test for function append_rule
def test_append_rule():
    return 0



# Generated at 2022-06-23 03:50:21.139827
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from test_iptables import main as test_main_iptables


# Generated at 2022-06-23 03:50:25.446621
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(ip_version='ipv4',
                  chain='test_chain',
                  policy='test_policy',
                  table='test_table'
                 )
    iptables_path='/usr/bin/iptables'
    assert(set_chain_policy(iptables_path, AnsibleModule(), params) == '-P test_table test_chain test_policy')



# Generated at 2022-06-23 03:50:27.534359
# Unit test for function append_csv
def test_append_csv():
    assert append_csv([], ['A'], '--test') == ['--test', 'A']
    assert append_csv([], ['A', 'B'], '--test') == ['--test', 'A,B']
    assert append_csv([], [], '--test') == []



# Generated at 2022-06-23 03:50:29.654422
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, 'tcp')
    assert rule == ['-m', 'tcp']



# Generated at 2022-06-23 03:50:41.327259
# Unit test for function check_present
def test_check_present():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {'chain': 'INPUT',
              'table': 'filter',
              'ip_version': 'ipv4',
              'protocol': 'tcp',
              'destination_port': '22',
              'ctstate': None,
              'syn': None,
              'jump': None,
              'reject_with': 'tcp-reset',
              'icmp_type': None,
              'flush': False,
              'policy': None,
              'wait': None
              }
    assert check_present(iptables_path, module, params) == True

# Generated at 2022-06-23 03:50:42.460103
# Unit test for function append_jump
def test_append_jump():
  rule = []
  jump = 'test'
  append_jump(rule, True, jump)
  assert (rule == ['-j', 'test'])



# Generated at 2022-06-23 03:50:53.207074
# Unit test for function flush_table
def test_flush_table():
    test_params = dict(
        table='filter',
        ip_version='ipv4',
        chain='INPUT',
    )
    # test args
    cmd = push_arguments('fake_bin', 'fake_module', '-F', test_params, make_rule=False)
    assert cmd == ['fake_bin', '-t', 'filter', '-F', 'INPUT']



# Generated at 2022-06-23 03:50:56.118595
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule=rule, param='match', flag='-s', negatable=True)
    assert rule == ['-s']
    rule = []  # reset rule
    append_match_flag(rule=rule, param='negate', flag='-s', negatable=True)
    assert rule == ['!', '-s']
    rule = []  # reset rule
    append_match_flag(rule=rule, param='no', flag='-s', negatable=True)
    assert rule == []



# Generated at 2022-06-23 03:51:05.781747
# Unit test for function append_param
def test_append_param():
    rule = list()
    append_param(rule, '192.168.1.1', '--source', False)
    append_param(rule, None, '--source', False)
    append_param(rule, '!192.168.1.1', '--source', False)
    assert rule == ['--source', '192.168.1.1']
    append_param(rule, '192.168.1.1', '--destination', False)
    append_param(rule, ['192.168.1.1', '10.0.0.1'], '--destination', True)
    append_param(rule, ['192.168.1.1', '!10.0.0.1'], '--destination', True)

# Generated at 2022-06-23 03:51:16.453037
# Unit test for function push_arguments
def test_push_arguments():
    for ip_version in ['ipv4', 'ipv6']:
        iptables_path = BINS[ip_version]
        for action in ['-A', '-I']:
            for table in ['filter', 'nat']:
                for chain in ['INPUT', 'OUTPUT', 'FORWARD']:
                    module = dict(
                        chain=chain,
                        table=table)
                    args = push_arguments(iptables_path, action, module, False)
                    assert args[:2] == [iptables_path, '-t', table], "Invalid output: %s" % ' '.join(args)
                    assert args[2] == action, "Invalid output: %s" % ' '.join(args)
                    assert args[3] == chain, "Invalid output: %s" % ' '.join(args)


# Generated at 2022-06-23 03:51:20.713424
# Unit test for function insert_rule
def test_insert_rule():
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': 5,
        'protocol': 'tcp',
        'destination_port': 8080,
        'jump': 'ACCEPT',
        'comment': 'Accept new foo connections.',
    }
    cmd = push_arguments('/usr/bin/iptables', '-I', params)
    assert cmd == ['/usr/bin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new foo connections.']


# Generated at 2022-06-23 03:51:28.045658
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK'], flags_set=['ACK', 'RST'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK', 'ACK,RST']
    rule = []
    param = dict(flags=[], flags_set=['ACK', 'RST'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', '', 'ACK,RST']
    rule = []
    param = dict(flags=[], flags_set=[])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == []
    rule = []

# Generated at 2022-06-23 03:51:39.624647
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test1', 'test2', False)
    assert 'test2' in rule
    assert 'test1' in rule
    assert '!test2test1' not in rule
    rule = []
    append_param(rule, 'test1', 'test2', True)
    assert 'test2' in rule
    assert 'test1' in rule
    assert '!test2test1' not in rule
    rule = []
    append_param(rule, '!test1', 'test2', False)
    assert 'test2' in rule
    assert '!test1' in rule
    assert '!test2test1' not in rule
    rule = []
    append_param(rule, '!test1', 'test2', True)
    assert 'test2' in rule

# Generated at 2022-06-23 03:51:52.157542
# Unit test for function append_rule
def test_append_rule():

    # Arrange
    import tempfile
    module_name = 'ansible.builtin.iptables'

# Generated at 2022-06-23 03:51:55.298186
# Unit test for function main
def test_main():
    return

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:52:02.635937
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = "/usr/bin/iptables"
    module = ""

# Generated at 2022-06-23 03:52:13.293521
# Unit test for function push_arguments

# Generated at 2022-06-23 03:52:19.073288
# Unit test for function flush_table
def test_flush_table():
    iptables_path = 'iptables'
    module = AnsibleModule({})
    params = dict(
        table = 'filter',
        chain = 'INPUT',
    )
    flush_table(iptables_path, module, params)



# Generated at 2022-06-23 03:52:25.355255
# Unit test for function get_iptables_version
def test_get_iptables_version():
    iptables_path="iptables"
    module=AnsibleModule(argument_spec=dict(
        waittime=dict(required=False, type=int),
    )

    )
    assert (LooseVersion(get_iptables_version(iptables_path, module))) == (LooseVersion('1.8.0'))



# Generated at 2022-06-23 03:52:29.684716
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, 'tcp', 'tcp')
    assert rule == [ '-m', 'tcp' ]
    rule = []
    append_match(rule, None, 'tcp')
    assert rule == []



# Generated at 2022-06-23 03:52:35.130428
# Unit test for function push_arguments
def test_push_arguments():
    result = push_arguments('/sbin/iptables', '-A', {
        'table': 'filter',
        'chain': 'INPUT',
        'source': '1.1.1.1',
        'jump': 'ACCEPT'})
    assert result == [
        '/sbin/iptables',
        '-t', 'filter',
        '-A', 'INPUT',
        '-s', '1.1.1.1',
        '-j', 'ACCEPT',
    ]



# Generated at 2022-06-23 03:52:47.565532
# Unit test for function push_arguments
def test_push_arguments():
    cmd = []

# Generated at 2022-06-23 03:53:00.220082
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = "/sbin/iptables"
    module = "/sbin/module"
    params = {"table": "nat", "chain": "PREROUTING", "in_interface": "eth0", "protocol": "tcp", "match": "tcp", "destination_port": "80", "jump": "REDIRECT", "to_ports": "8600", "comment": "Redirect web traffic to port 8600"}
    cmd = push_arguments(iptables_path, '-I', params)
    rc, out, err = module.run_command(cmd, check_rc=False)
    module.exit_json(changed=True, msg="Success")




# Generated at 2022-06-23 03:53:01.683428
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = '5'
    flag = '-w'
    assert append_wait(rule, param, flag) == rule.extend([flag, param])


# Generated at 2022-06-23 03:53:03.566862
# Unit test for function append_wait
def test_append_wait():
    assert append_wait(rule, param, flag) == rule.extend([flag, param])

# Generated at 2022-06-23 03:53:07.682433
# Unit test for function get_iptables_version
def test_get_iptables_version():
    iptables_path = 'iptables'
    iptables_version = get_iptables_version(iptables_path, module)
    assert (len(iptables_version) > 0)



# Generated at 2022-06-23 03:53:19.608605
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_rule = []
    test_param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    test_flag = '--tcp-flags'
    append_tcp_flags(test_rule, test_param, test_flag)

    if test_rule != ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']:
        raise Exception("Failed: test_rule was not ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']")



# Generated at 2022-06-23 03:53:22.568795
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = "DROP"
    ret = append_jump(rule, param, "DROP")
    assert rule == ['-j', 'DROP']


# Generated at 2022-06-23 03:53:28.006026
# Unit test for function append_jump
def test_append_jump():
    rule = ["-A", "INPUT", "-j", "ACCEPT"]
    append_jump(rule, "test", "ACCEPT")
    assert rule == ['-A', 'INPUT', '-j', 'test']



# Generated at 2022-06-23 03:53:39.061277
# Unit test for function remove_rule
def test_remove_rule():
    params = dict()
    params['table'] = 'table'
    params['chain'] = 'chain'
    params['protocol'] = 'protocol'
    params['source'] = 'source'
    params['destination'] = 'destination'
    params['match'] = 'match'
    params['tcp_flags'] = 'tcp_flags'
    params['jump'] = 'jump'
    params['to_destination'] = 'to_destination'
    params['destination_ports'] = 'destination_ports'
    params['to_source'] = 'to_source'
    params['goto'] = 'goto'
    params['in_interface'] = 'in_interface'
    params['out_interface'] = 'out_interface'
    params['fragment'] = 'fragment'

# Generated at 2022-06-23 03:53:44.491813
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({
        'table': 'filter',
        'chain': 'INPUT',
        'policy': 'ACCEPT',
    })
    iptables_path = '/sbin/iptables'
    set_chain_policy(iptables_path, module, module.params)



# Generated at 2022-06-23 03:53:50.194362
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = 'y'
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule == ['--wait', 'y']


# Generated at 2022-06-23 03:54:01.378959
# Unit test for function construct_rule

# Generated at 2022-06-23 03:54:11.467225
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = list()
    assert(append_match_flag(rule, "match", "--flag", True) == None)
    assert(rule == ['--flag'])
    rule = list()
    assert(append_match_flag(rule, "negate", "--flag", True) == None)
    assert(rule == ['!', '--flag'])
    rule = list()
    assert(append_match_flag(rule, "match", "--flag", False) == None)
    assert(rule == ['--flag'])


# Generated at 2022-06-23 03:54:15.668393
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--tcp-flags', True)
    assert rule == ['--tcp-flags']
    rule = []
    append_match_flag(rule, 'negate', '--tcp-flags', True)
    assert rule == ['!', '--tcp-flags']


# Generated at 2022-06-23 03:54:20.968788
# Unit test for function get_chain_policy
def test_get_chain_policy():
    chain = 'INPUT'
    chain_header = "Chain %s (policy ACCEPT)" % chain
    assert get_chain_policy(chain_header, chain) == 'ACCEPT'
    chain_header = "Chain INPUT (policy )"
    assert get_chain_policy(chain_header, chain) is None



# Generated at 2022-06-23 03:54:30.014626
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=[ 'ALL', 'NONE'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ALL,NONE', 'ACK,RST,SYN,FIN']
    param = None
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ALL,NONE', 'ACK,RST,SYN,FIN']
    param = dict(flags=[], flags_set=[])
    append_tcp_flags(rule, param, flag)

# Generated at 2022-06-23 03:54:41.414013
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert ['--syn'] == rule
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert ['!', '--syn'] == rule
    rule = []
    append_match_flag(rule, 'ignore', '--syn', True)
    assert [] == rule
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert ['--syn'] == rule
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert [] == rule
    rule = []
    append_match_flag(rule, 'ignore', '--syn', False)
    assert [] == rule



# Generated at 2022-06-23 03:54:54.644097
# Unit test for function remove_rule

# Generated at 2022-06-23 03:55:04.873020
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule({
        'table': 'filter',
        'chain': 'INPUT',
    })
    flush_table('iptables', module, {
        'table': 'filter',
        'chain': 'INPUT',
    })
    (rc, out, err) = module.run_command('iptables -t filter -L INPUT -n')
    assert rc == 0
    assert len(out.split('\n')) == 3



# Generated at 2022-06-23 03:55:06.904333
# Unit test for function append_match
def test_append_match():
    rule = []
    match_set = {}
    append_match(rule, match_set, "set")
    return rule
# Unit test complete



# Generated at 2022-06-23 03:55:17.578696
# Unit test for function remove_rule
def test_remove_rule():
    ret = {}
    ret['ansible_facts'] = {}
    iptables_path = "iptables"

# Generated at 2022-06-23 03:55:25.464691
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.iptables_common import \
        get_iptables_version

    module = AnsibleModule({
        'ip_version': 'ipv4',
        'table': 'filter',
        'state': 'present',
        'action': 'append',
        'chain': 'INPUT',
        'rule': '-s 1.2.3.4 -j ACCEPT',
    })

    rule_is_present = False
    should_be_present = True
    rule_is_present != should_be_present
    rule_is_present
    should_be_present

# Generated at 2022-06-23 03:55:34.767611
# Unit test for function set_chain_policy
def test_set_chain_policy():
    from ansible.modules.network.firewall import iptables
    import ansible.module_utils.basic
    import ansible.module_utils.netcmd_utils

    x = ansible.module_utils.basic.AnsibleModule(
        argument_spec=iptables.argspec,
        supports_check_mode=True
    )
    #table: filter
    #in_interface: lo
    #jump: ACCEPT

# Generated at 2022-06-23 03:55:36.896776
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({})
    assert(get_iptables_version('iptables', module) == '1.6.0')



# Generated at 2022-06-23 03:55:45.322908
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    for s in ['match', 'negate']:
        append_match_flag(rule, s, '--some-flag', True)
    # If 'match' or 'negate' are passed to the function, we expect them to be
    # appended to the rule.
    assert rule == ['--some-flag', '--some-flag']
    # If 'ignore', which is a valid input but not a flag, is passed we expect
    # no flag to be appended to the rule.
    append_match_flag(rule, 'ignore', '--some-flag', True)
    assert rule == ['--some-flag', '--some-flag']


# Generated at 2022-06-23 03:55:56.022431
# Unit test for function insert_rule

# Generated at 2022-06-23 03:56:00.308805
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['a', 'b', 'c']
    flag = '-a'
    append_csv(rule, param, flag)
    assert rule == [flag, 'a,b,c']



# Generated at 2022-06-23 03:56:04.057418
# Unit test for function get_iptables_version
def test_get_iptables_version():
    iptables_path = '/sbin/ip6tables'
    module = AnsibleModule(argument_spec=dict())
    iptables_version = get_iptables_version(iptables_path, module)
    assert iptables_version != ''



# Generated at 2022-06-23 03:56:10.978133
# Unit test for function append_csv
def test_append_csv():
    r = []
    append_csv(r, ['a', 'b'], '--test')
    assert r == ['--test', 'a,b']
    r = []
    append_csv(r, [], '--test')
    assert r == ['--test', '']
    r = []
    append_csv(r, None, '--test')
    assert r == []



# Generated at 2022-06-23 03:56:22.407860
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule(dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
    )) == ['-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP']
    assert construct_rule(dict(
        protocol='tcp',
        source='8.8.8.8',
        match='tcp',
        jump='DROP',
    )) == ['-p', 'tcp', '-s', '8.8.8.8', '-m', 'tcp', '-j', 'DROP']

# Generated at 2022-06-23 03:56:27.162144
# Unit test for function append_csv
def test_append_csv():
    test_rule = []
    test_csv = ['a', 'b', 'c']
    append_csv(test_rule, test_csv, '-m')
    assert test_rule == ['-m', 'a,b,c']



# Generated at 2022-06-23 03:56:36.794679
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['SYN', 'ACK', 'RST'], 'flags_set': ['SYN', 'RST']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'SYN,ACK,RST', 'SYN,RST']
    rule = []
    param = {}
    append_tcp_flags(rule, param, flag)
    assert rule == []
    rule = []
    append_tcp_flags(rule, None, flag)
    assert rule == []



# Generated at 2022-06-23 03:56:49.247095
# Unit test for function append_param
def test_append_param():
    def _test_single_param(param, flag):
        rule = []
        append_param(rule, param, flag, False)
        return rule

    def _test_append(param, expected):
        assert _test_single_param(param, '--flag') == expected

    _test_append('', [])
    _test_append(None, [])
    _test_append('abc', ['--flag', 'abc'])
    _test_append('!abc', ['!', '--flag', 'abc'])

    assert _test_single_param(['', ''], '--flag') == []
    assert _test_single_param(['abc'], '--flag') == ['--flag', 'abc']

# Generated at 2022-06-23 03:57:01.741864
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        action='-A',
        rule_num='1',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
    )
    path = '/sbin/iptables'
    assert push_arguments(path, '-A', params, True) == [
        '/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-s', '8.8.8.8',
        '-p', 'tcp', '-j', 'DROP'
    ]
    params['action'] = '-I'
    params['rule_num'] = '4'

# Generated at 2022-06-23 03:57:06.405340
# Unit test for function insert_rule
def test_insert_rule():
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'insert',
        'rule_num': '5',
        'ip_version': 'ipv4'
    }
    assert [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp',
        '--dport', '8080', '-j', 'ACCEPT'
    ] == insert_rule('iptables', None, params)
    params['ip_version'] = 'ipv6'

# Generated at 2022-06-23 03:57:19.974718
# Unit test for function check_present
def test_check_present():
    mock_module = MockModule()

# Generated at 2022-06-23 03:57:22.196132
# Unit test for function append_param
def test_append_param():
    rule = [ ]
    param = ['!ipset', 'ipset']
    flag = '--match-set'
    is_list = False
    append_param(rule,param,flag,is_list)
    assert rule[0] == '!' and rule[1] == flag and rule[2] == 'ipset'
    assert rule[3] == flag and rule[4] == 'ipset'


# Generated at 2022-06-23 03:57:24.771336
# Unit test for function append_wait
def test_append_wait():
    test_rule=[]
    param='10'
    append_wait(test_rule,param,'-w')
    assert test_rule==['-w','10']

# Generated at 2022-06-23 03:57:29.209612
# Unit test for function flush_table
def test_flush_table():
    assert flush_table('iptables', {'run_command': lambda x,y: (0, None, None)}, {'table': 'filter', 'chain': 'INPUT'}) is None



# Generated at 2022-06-23 03:57:36.276255
# Unit test for function flush_table
def test_flush_table():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.community.general.plugins.module_utils.shell import HAS_PYTHON26, HAS_PYTHON27, HAS_PYTHON3
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils._text import to_bytes
    import shlex
    import sys

    HAS_PYTHON26 = True
    HAS_PYTHON27 = True
    HAS_PYTHON3 = True
    PY3 = (sys.version_info[0] == 3)
    if PY3:
        import subprocess
        from subprocess import getstatusoutput as getso
    else:
        import commands as subprocess
        from commands import getstatusoutput as getso



# Generated at 2022-06-23 03:57:45.778243
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK']
    param = dict(flags=[], flags_set=['ACK'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK']



# Generated at 2022-06-23 03:57:55.438501
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-t', 'filter', '-C', 'INPUT', '-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP') == True
    assert check_present('iptables', '-t', 'filter', '-C', 'INPUT', '-p', 'udp', '-s', '8.8.8.8', '-j', 'DROP') == False