

# Generated at 2022-06-23 03:47:57.547932
# Unit test for function remove_rule
def test_remove_rule():
    for k,v in BINS.items():
        print(v)



# Generated at 2022-06-23 03:48:00.668813
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({})
    assert get_iptables_version('/bin/iptables', module) == \
        '1.6.0'



# Generated at 2022-06-23 03:48:02.168512
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-23 03:48:06.677906
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert(push_arguments('/sbin/iptables', '-P', 
        dict(
            table='filter',
            chain='INPUT',
            policy='ACCEPT'
        ), make_rule=False) == [
            '/sbin/iptables',
            '-t', 'filter',
            '-P', 'INPUT',
            'ACCEPT'
        ])



# Generated at 2022-06-23 03:48:08.526724
# Unit test for function insert_rule
def test_insert_rule():
    actual = insert_rule("/sbin/iptables", "module", "params")
    expected = "/sbin/iptables -t params[table] -I params[chain] params[rule_num]" + " " + construct_rule("params")
    return actual == expected


# Generated at 2022-06-23 03:48:14.885677
# Unit test for function main

# Generated at 2022-06-23 03:48:26.201651
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/bin/iptables'
    module = AnsibleModule(argument_spec=dict(
        table='filter',
        chain='INPUT',
        action='insert',
        rule_num='5',
        protocol='tcp',
        destination_port='8081',
        jump='ACCEPT'),
        params=dict(
        table='filter',
        chain='INPUT',
        action='insert',
        rule_num='5',
        protocol='tcp',
        destination_port='8081',
        jump='ACCEPT'))
    insert_rule(iptables_path, module, module.params)

# Generated at 2022-06-23 03:48:27.619087
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', 0, 0) == False


# Generated at 2022-06-23 03:48:38.405621
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        source='8.8.8.8',
        jump='DROP',
    )
    construct_rule(params)
    # Test ctstate
    params = dict(
        ctstate='ESTABLISHED',
        match='conntrack',
        jump='ACCEPT',
    )
    construct_rule(params)
    # Test src_range
    params = dict(
        src_range='192.168.1.100-192.168.1.199',
        jump='ACCEPT',
    )
    construct_rule(params)
    # Test dst_range
    params = dict(
        dst_range='10.0.0.1-10.0.0.50',
        jump='ACCEPT',
    )
    construct_rule(params)
    # Test match_set

# Generated at 2022-06-23 03:48:44.905022
# Unit test for function append_match
def test_append_match():
    rule = []
    match = 'match'
    append_match(rule, True, match)
    assert rule == ['-m', match]
    rule = []
    append_match(rule, False, match)
    assert rule == []


# Generated at 2022-06-23 03:48:50.733502
# Unit test for function append_match
def test_append_match():
    r = []
    param = []
    match = []
    append_match(r, param, match)
    assert r == []
    #
    param = 'hello'
    match = 'world'
    append_match(r, param, match)
    assert r == ['-m', 'world']

# Generated at 2022-06-23 03:48:54.762989
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version.__name__ == 'get_iptables_version'
    module = AnsibleModule({})
    assert get_iptables_version('/sbin/iptables', module) is not None


# Generated at 2022-06-23 03:48:58.901707
# Unit test for function check_present
def test_check_present():
    assert (check_present((BINS['ipv4']), ipt_module, ipt_params) == True)



# Generated at 2022-06-23 03:49:00.723477
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, "ACCEPT", "ACCEPT")
    assert rule == ['-j', 'ACCEPT']



# Generated at 2022-06-23 03:49:07.146622
# Unit test for function flush_table
def test_flush_table():
    module =  AnsibleModule(argument_spec={
        'chain': {'required': True, 'aliases': ['name']},
        'table': {'default': 'filter', 'required': False, 'aliases': ['table']},
        'ip_version': {'default': 'ipv4', 'required': False, 'aliases': ['ip_version']},
        'wait': {'default': None, 'required': False, 'aliases': ['wait']},
        })
    module.params = {
            'chain': 'INPUT',
            'table': 'filter',
            'ip_version': 'ipv4',
            'wait': None,
            }
    flush_table(BINS[module.params['ip_version']], module, module.params)



# Generated at 2022-06-23 03:49:09.300471
# Unit test for function append_match
def test_append_match():
    rule = list()
    rule_expected = ['-m', 'comment']
    append_match(rule, True, 'comment')
    assert rule == rule_expected
    rule = list()
    append_match(rule, False, 'comment')
    assert rule == []



# Generated at 2022-06-23 03:49:10.540146
# Unit test for function append_rule
def test_append_rule():
    iptables_path = "/sbin/iptables"
    module = ''
    params = ''
    return append_rule(iptables_path, module, params)



# Generated at 2022-06-23 03:49:11.731484
# Unit test for function main
def test_main():
    main()



# Generated at 2022-06-23 03:49:13.351766
# Unit test for function set_chain_policy
def test_set_chain_policy():
  params = dict(
    chain = 'INPUT',
    policy = 'DROP',
  )
  assert(set_chain_policy('iptables',None,params)==['iptables', '-P', 'INPUT', 'DROP'])


# Generated at 2022-06-23 03:49:25.176771
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--test-flag', True)
    assert rule == ['--test-flag']
    rule = []
    append_match_flag(rule, 'negate', '--test-flag', True)
    assert rule == ['!', '--test-flag']
    rule = []
    append_match_flag(rule, 'no match', '--test-flag', True)
    assert rule == []
    rule = []
    append_match_flag(rule, 'ignore', '--test-flag', True)
    assert rule == []
    rule = []
    append_match_flag(rule, 'negate', '--test-flag', False)
    assert rule == []
    rule = []

# Generated at 2022-06-23 03:49:38.357174
# Unit test for function main

# Generated at 2022-06-23 03:49:40.683440
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    tcp_flags = dict(
        flags=['ALL', 'NONE'],
        flags_set=['ACK', 'RST']
    )
    append_tcp_flags(rule, tcp_flags, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ALL,NONE', 'ACK,RST']

# Generated at 2022-06-23 03:49:42.552376
# Unit test for function flush_table
def test_flush_table():
  if __name__ == '__main__':
    flush_table('iptables', 'module', 'test_params')



# Generated at 2022-06-23 03:49:45.223931
# Unit test for function flush_table
def test_flush_table():
    values={'any': None, 'chain': 'testname', 'table': 'filter', 'ip_version': 'ipv4'}
    assert flush_table('/sbin/iptables', None, values) == ['/sbin/iptables', '-t', 'filter', '-F', 'testname']



# Generated at 2022-06-23 03:49:47.646621
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, "admin", "! --uid-owner", False)
    append_param(rule, None, "--gid-owner", False)
    append_param(rule, ["2", "3"], "--dport", True)
    assert rule == ["!", "--uid-owner", "admin", "--dport", "2", "--dport", "3"]



# Generated at 2022-06-23 03:49:58.214434
# Unit test for function append_rule
def test_append_rule():
    result = append_rule(
        '/sbin/iptables',
        {'run_command': run_command},
        {
            'table': 'filter',
            'chain': 'OUTPUT',
            'jump': 'LOG',
            'log_level': 'info',
            'log_prefix': 'RULE_HIT:',
            'source': '8.8.8.8',
        }
    )
    assert result == ['/sbin/iptables', '-t', 'filter', '-A', 'OUTPUT', '-s', '8.8.8.8', '-j', 'LOG', '--log-level', 'info', '--log-prefix', 'RULE_HIT:']



# Generated at 2022-06-23 03:50:06.052751
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = "/usr/bin/iptables"
    module = AnsibleModule(argument_spec=dict(chain='test', action='test',
        table='test', ip_version='test', state='test'))
    params = dict(
        chain='test',
        action='test',
        table='test',
        ip_version='test',
        state='test'
    )
    cmd = remove_rule(iptables_path, module, params)
    return cmd



# Generated at 2022-06-23 03:50:10.756481
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACCEPT'], flags_set=['ACK', 'SYN'])
    append_tcp_flags(rule, param, 'flag')
    assert rule == ['flag', 'ACCEPT', 'ACK,SYN']



# Generated at 2022-06-23 03:50:12.896674
# Unit test for function append_csv
def test_append_csv():
    assert append_csv([], ['test1', 'test2'], '--test-flag') == ['--test-flag', 'test1,test2']



# Generated at 2022-06-23 03:50:15.338360
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, "ACCEPT", "ACCEPT")
    assert rule == ['-j', 'ACCEPT']
    append_jump(rule, None, "ACCEPT")
    assert rule == ['-j', 'ACCEPT']



# Generated at 2022-06-23 03:50:18.876094
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        table='filter',
        chain='ACCEPT',
        rule_num=1,
        wait='3',
        protocol='tcp',
        source='8.8.8.8',
        destination='8.8.8.9',
        jump='ACCEPT',
        ctstate='NEW',
    )
    iptables_path='/sbin/iptables'
    cmd = push_arguments(iptables_path, '-I', params)
    print(cmd)


# Generated at 2022-06-23 03:50:25.509376
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = "iptables"
    module = "ansible.builtin.iptables"
    # mock module.run_command
    def run_cmd(cmd, check_rc=False):
        cmd_list = cmd.split(' ')
        rule = construct_rule(params)
        if cmd_list[-1] == rule:
            return 0, None, None
        return 1, None, None
    module.run_command = run_cmd

    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        jump='ACCEPT',
        source='1.1.1.1',
        source_port='22',
        action="delete",
        state="",
        wait='',
        log_level=''
    )

# Generated at 2022-06-23 03:50:29.521955
# Unit test for function remove_rule
def test_remove_rule():
    remove_rule('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'jump': 'ACCEPT', 'protocol': 'tcp', 'destination_port': 80})

# Generated at 2022-06-23 03:50:32.876648
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') is not None



# Generated at 2022-06-23 03:50:43.952013
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='nat',
        chain='INPUT',
        rule_num='5',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        comment='just a comment'
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == ['iptables',
                   '-t',
                   params['table'],
                   '-I',
                   params['chain'],
                   '5',
                   '-p',
                   params['protocol'],
                   '--dport',
                   params['destination_port'],
                   '-j',
                   params['jump'],
                   '-m',
                   'comment',
                   '--comment',
                   'just a comment']



# Generated at 2022-06-23 03:50:57.620257
# Unit test for function insert_rule
def test_insert_rule():
    test_module = AnsibleModule({
        'insert_rule': {'chain': 'FORWARD',
                        'destination': '10.10.10.0/24',
                        'destination_port': '80',
                        'goto': 'ACCEPT',
                        'icmp_type': '',
                        'ip_version': 'ipv6',
                        'jump': '',
                        'limit': '',
                        'match': ['', ''],
                        'reject_with': '',
                        'set_counters': '',
                        'table': 'filter',
                        'wait': ''}})
    result = insert_rule('ip6tables', test_module, test_module.params['insert_rule'])
    assert result is None


# Generated at 2022-06-23 03:51:01.163911
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], None, '--syn', True) == []
    assert append_match_flag([], 'match', '--syn', True) == ['--syn']
    assert append_match_flag([], 'negate', '--syn', True) == ['!', '--syn']
    assert append_match_flag([], 'foo', '--syn', True) == []



# Generated at 2022-06-23 03:51:15.300441
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = type('', (), {})()
    setattr(module, 'run_command', lambda x: [0, 'Chain INPUT (policy ACCEPT)\n', ''])
    assert get_chain_policy('iptables', module, dict(table='filter', chain='INPUT')) == 'ACCEPT'
    setattr(module, 'run_command', lambda x: [0, 'Chain INPUT (policy DROP)\n', ''])
    assert get_chain_policy('iptables', module, dict(table='filter', chain='INPUT')) == 'DROP'
    setattr(module, 'run_command', lambda x: [0, 'Chain INPUT (policy RETURN)\n', ''])
    assert get_chain_policy('iptables', module, dict(table='filter', chain='INPUT')) == 'RETURN'
   

# Generated at 2022-06-23 03:51:20.552997
# Unit test for function get_chain_policy
def test_get_chain_policy():
    # Testing single policy
    h1 = "(policy ACCEPT)".rstrip()
    assert get_chain_policy(None, None, h1) == "ACCEPT"
    # Testing multiple policies
    h2 = "(policy ACCEPT DROP)\n"
    assert get_chain_policy(None, None, h2) == "ACCEPT"



# Generated at 2022-06-23 03:51:32.174469
# Unit test for function main

# Generated at 2022-06-23 03:51:43.681956
# Unit test for function push_arguments
def test_push_arguments():
    test_rule = {
        'comment': 'test comment',
        'state': 'present',
        'table': 'nat',
        'chain': 'OUTPUT',
        'ip_version': 'ipv4'
    }
    cmd = push_arguments('/sbin/iptables', '-A',
        test_rule, make_rule=False)
    assert cmd == [
        u'/sbin/iptables',
        u'-t', u'nat',
        u'-A', u'OUTPUT']

    # Test special case where action is -I and rule_num is set

# Generated at 2022-06-23 03:51:48.802545
# Unit test for function construct_rule
def test_construct_rule():
    # construct_rule is not the simplest function but we should have the
    # confidence to write a unit test for it.
    params = {
        'table': 'nat',
        'chain': 'PREROUTING',
        'jump': 'REDIRECT',
        'protocol': 'tcp',
        'destination_port': 80,
        'to_ports': 8600,
        'comment': 'Redirect HTTP traffic',
        'ip_version': 'ipv4'
    }
    rule = construct_rule(params)
    assert len(rule) == 12
    assert rule[0:3] == ['-t', 'nat', '-A', 'PREROUTING']
    assert rule[3:6] == ['-p', 'tcp', '-m', 'multiport']
    assert rule[6:8]

# Generated at 2022-06-23 03:51:57.609274
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port=8080,
        syn='negate',
        jump='ACCEPT',
        rule_num='5',
    )
    answer = ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp',
              '--destination-port', '8080', '!', '--syn', '-j', 'ACCEPT']
    assert push_arguments('iptables', '-I', params) == answer



# Generated at 2022-06-23 03:52:03.939158
# Unit test for function append_csv
def test_append_csv():
    r1=[1,2,3]
    append_csv(r1,'tcp','--protocol')
    if r1 != [1,2,3,'--protocol','tcp']:
         print("Error in append_csv")
    else:
         print("Correct in append_csv")


# Generated at 2022-06-23 03:52:09.897219
# Unit test for function append_rule
def test_append_rule():
    iptables_path = "iptables"
    module = AnsibleModule(argument_spec={})
    params = {"table": "filter", "chain": "INPUT", "protocol": "tcp", "destination_port": "80", "jump": "ACCEPT" }
    append_rule(iptables_path, module, params)



# Generated at 2022-06-23 03:52:21.227260
# Unit test for function push_arguments
def test_push_arguments():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert push_arguments('iptables', '-I', {'chain': 'INPUT'})\
        == ['iptables', '-t', 'filter', '-I', 'INPUT']

# Generated at 2022-06-23 03:52:33.418964
# Unit test for function insert_rule
def test_insert_rule():
  # test case 1
  iptables_path = 'ip6tables'

# Generated at 2022-06-23 03:52:35.392726
# Unit test for function append_csv
def test_append_csv():
    assert append_csv([], ['A', 'B'], '--option') == ['--option', 'A,B']
    assert append_csv([], [], '--option') == []



# Generated at 2022-06-23 03:52:40.594116
# Unit test for function insert_rule
def test_insert_rule():
    rule1 = construct_rule({
        'chain': 'OUTPUT',
        'protocol': 'tcp',
        'destination_port': '5678',
        'jump': None,
        'action': 'insert',
        'rule_num': "5",
        'table': 'filter',
        'ip_version': 'ipv4'
    })
    rule2 = construct_rule({
        'chain': 'OUTPUT',
        'protocol': 'tcp',
        'destination_port': '5678',
        'jump': None,
        'action': 'insert',
        'rule_num': "5",
        'table': 'filter',
        'ip_version': 'ipv4'
    })
    rule2.extend(['-I', 'OUTPUT', '5'])


# Generated at 2022-06-23 03:52:44.625666
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path="/sbin/iptables"
    module = "test"
    params={'chain': 'test', 'table': 'test', 'ip_version': 'ipv4'}
    remove_rule(iptables_path, module, params)


# Generated at 2022-06-23 03:52:52.666018
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ["ESTABLISHED", "RELATED"], "--ctstate")
    assert rule == [ "--ctstate", "ESTABLISHED,RELATED" ]

    rule = []
    append_csv(rule, ["80", "443", "8081:8083"], "--destination-port")
    assert rule == [ "--destination-port", "80,443,8081:8083" ]



# Generated at 2022-06-23 03:52:54.952599
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/iptables', None) == '1.6.0'


# Generated at 2022-06-23 03:53:05.358778
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'ip_version': dict(type='str', default='ipv4', choices=['ipv4', 'ipv6'])})

# Generated at 2022-06-23 03:53:10.774361
# Unit test for function get_chain_policy
def test_get_chain_policy():
    passed = True
    # This is the result of command 'sudo ip6tables -L OUTPUT' on test system
    module = AnsibleModule({})
    assert get_chain_policy('/sbin/ip6tables', module, {'chain': 'OUTPUT'}) == 'DROP'
    # This is the result of command 'sudo ip6tables -L INPUT' on test system
    assert get_chain_policy('/sbin/ip6tables', module, {'chain': 'INPUT'}) == 'DROP'
    if not passed:
        raise AssertionError('test_get_chain_policy has failed')


# Generated at 2022-06-23 03:53:11.144453
# Unit test for function append_rule
def test_append_rule():
    assert True



# Generated at 2022-06-23 03:53:12.131082
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, "5", "--wait")
    assert rule == ["--wait", "5"]

# Generated at 2022-06-23 03:53:16.827725
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter', ip_version='ipv4')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter', ip_version='ipv6')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='FORWARD', table='filter', ip_version='ipv4')) == 'DROP'
    assert get_chain_policy(None, None, dict(chain='FORWARD', table='filter', ip_version='ipv6')) == 'DROP'
    assert get_chain_policy(None, None, dict(chain='OUTPUT', table='filter', ip_version='ipv4')) == 'ACCEPT'

# Generated at 2022-06-23 03:53:27.222464
# Unit test for function construct_rule
def test_construct_rule():
    test_params = dict(
        table='mangle',
        chain='PREROUTING',
        jump='DSCP',
        protocol='tcp',
        ip_version='ipv4',
        set_dscp_mark='0x3',
    )
    expected_rule = [
        '-t', 'mangle',
        '-A', 'PREROUTING',
        '-j', 'DSCP',
        '-p', 'tcp',
        '--set-dscp', '0x3',
    ]
    assert construct_rule(test_params) == expected_rule



# Generated at 2022-06-23 03:53:38.450542
# Unit test for function append_match_flag
def test_append_match_flag():
    #Test for non-negatable, no match
    res = []
    append_match_flag(res, None, '--some-flag', False)
    assert res == []
    #Test for non-negatable and match
    res = []
    append_match_flag(res, 'match', '--some-flag', False)
    assert res == ['--some-flag']
    #Test for non-negatable, invalid value
    res = []
    append_match_flag(res, 'other', '--some-flag', False)
    assert res == []
    #Test for negatable and negate
    res = []
    append_match_flag(res, 'negate', '--some-flag', True)
    assert res == ['!', '--some-flag']
    #Test for negatable, no match
    res = []

# Generated at 2022-06-23 03:53:46.407909
# Unit test for function remove_rule
def test_remove_rule():
    for i in range(0,10):
        rule = []
        append_param(rule, 'tcp', '-p', False)
        append_param(rule, '8.8.8.8', '-s', False)
        append_param(rule, 'tcp', '-m', True)
        append_param(rule, 'DROP', '-j', False)
        # print(rule)
#        module.run_command(cmd, check_rc=True)



# Generated at 2022-06-23 03:53:53.382298
# Unit test for function check_present
def test_check_present():
    assert not check_present('iptables', '-C', dict(
        chain='INPUT',
        protocol='udp',
        destination_port=58,
        jump='ACCEPT'))
    assert check_present('iptables', '-C', dict(
        chain='INPUT',
        protocol='udp',
        destination_port=58,
        jump='DROP'))


# Generated at 2022-06-23 03:53:56.737396
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/bin/echo', None) == '1.4.20'



# Generated at 2022-06-23 03:53:59.098774
# Unit test for function flush_table
def test_flush_table():
    assert(flush_table("iptables", "iptables -t filter -F INPUT") == "iptables -t filter -F INPUT")



# Generated at 2022-06-23 03:54:07.757006
# Unit test for function append_jump
def test_append_jump():

    rule=[]
    param=['DROP']
    jump=['DROP']
    append_jump(rule, param, jump)
    assert rule==['-j', 'DROP']

    rule=[]
    param=['ACCEPT']
    jump=['ACCEPT']
    append_jump(rule, param, jump)
    assert rule==['-j', 'ACCEPT']

    rule=[]
    param=['ACCEPT']
    jump=['DROP']
    append_jump(rule, param, jump)
    assert rule==['-j', 'ACCEPT']


# Generated at 2022-06-23 03:54:11.288193
# Unit test for function append_match
def test_append_match():
    rule=['iptables']
    append_match(rule, "", "")
    assert rule == ['iptables']
    rule=['iptables']
    append_match(rule, 'test', 'test')
    assert rule == ['iptables', '-m', 'test']



# Generated at 2022-06-23 03:54:13.313161
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'RETURN'
    jump = 'RETURN'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'RETURN']


# Generated at 2022-06-23 03:54:14.613994
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, 0, 0)
    assert rule == []

    rule = []
    append_wait(rule, 1, '--wait')
    assert rule == ['--wait']


# Generated at 2022-06-23 03:54:15.992407
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, 'ACCEPT', 'ACCEPT')
    assert rule == ['-j', 'ACCEPT']


# Generated at 2022-06-23 03:54:23.248515
# Unit test for function append_match_flag

# Generated at 2022-06-23 03:54:26.715142
# Unit test for function append_match
def test_append_match():
    rule = []
    param = 'match'
    match = 'match'
    append_match(rule, param, match)
    assert rule == ['-m', match]



# Generated at 2022-06-23 03:54:37.710729
# Unit test for function main
def test_main():
    test_table = dict(
        changed=False,
        failed=False,
        ip_version='ipv4',
        table='filter',
        chain=None,
        flush=False,
        rule='',
        state='present'
    )
    test_module.params['ip_version'] = 'ipv4'
    test_module.params['state'] = 'absent'
    with patch.object(os.path, 'isfile', return_value=True):
        test_module.params['flush'] = False
        with patch.object(test_module, 'run_command') as run_command:
            assert main() == test_table
            test_module.params['chain'] = 'INPUT'
            test_module.params['rule_num'] = '1'
            assert main() == test_table
           

# Generated at 2022-06-23 03:54:46.544359
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({'table': 'filter', 'chain': 'INPUT', 'policy': 'DROP'})
    assert set_chain_policy('iptables', module, {'table': 'filter', 'chain': 'INPUT', 'policy': 'DROP'}) == ('iptables', ['-t', 'filter', '-P', 'INPUT', 'DROP'])



# Generated at 2022-06-23 03:54:53.633376
# Unit test for function main

# Generated at 2022-06-23 03:54:59.726566
# Unit test for function append_param
def test_append_param():
    rule = []

    append_param(rule, ['80', '443'], '--destination-port', True)
    append_param(rule, '80', '--destination-port', False)
    append_param(rule, '!80', '--destination-port', False)
    assert rule == ['--destination-port', '80', '--destination-port', '443', '--destination-port', '80', '!', '--destination-port', '80']



# Generated at 2022-06-23 03:55:06.419894
# Unit test for function append_param
def test_append_param():
    rule = []
    param = '8080'
    flag = '-p'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['-p', '8080']
    rule = []
    param = None
    flag = '-p'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == []


# Generated at 2022-06-23 03:55:09.035604
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    iptables_path = BINS['ipv4']
    version = get_iptables_version(iptables_path, module)
    module.debug('iptables version {}'.format(version))


# Generated at 2022-06-23 03:55:13.364719
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(rule, param, flag, negatable) == [ '--some-flag' ]
    assert append_match_flag(rule, param, flag, negatable) != [ '!', '--some-flag' ]
    assert append_match_flag(rule, param, flag, negatable) == [ '!', '--some-flag' ]



# Generated at 2022-06-23 03:55:18.760639
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], 'match', '--match-sync', True) == []
    assert append_match_flag([], 'negate', '--match-sync', True) == ['!', '--match-sync']
    assert append_match_flag([], None, '--match-sync', True) == []
    assert append_match_flag([], 'match', '--match-sync', False) == ['--match-sync']
    assert append_match_flag([], 'negate', '--match-sync', False) == []
    assert append_match_flag([], 'negate', '--match-sync', False) == []


# Generated at 2022-06-23 03:55:22.356322
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy("iptables", None, {"policy": "DROP"}) == ["iptables", "-P", "DROP"]
    assert set_chain_policy("iptables", None, {"policy": "ACCEPT"}) == ["iptables", "-P", "ACCEPT"]



# Generated at 2022-06-23 03:55:29.734247
# Unit test for function append_csv
def test_append_csv():
    # Module under test
    from ansible.module_utils import iptables as ipt
    # Unit test tools
    from nose.tools import assert_equals

    # Arrange
    rule = []
    flag = '--some-flag'
    param = ['a', 'b', 'c']

    # Do
    ipt.append_csv(rule, param, flag)

    # Assert
    assert_equals(rule, ['--some-flag', 'a,b,c'])



# Generated at 2022-06-23 03:55:39.181844
# Unit test for function main

# Generated at 2022-06-23 03:55:49.544956
# Unit test for function main

# Generated at 2022-06-23 03:55:57.299382
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    flush_table('iptables', module, { 'chain': 'INPUT', 'table': 'mangle' })
    flush_table('iptables', module, { 'chain': 'OUTPUT', 'table': 'mangle' })
    flush_table('iptables', module, { 'chain': 'FORWARD', 'table': 'mangle' })
    flush_table('iptables', module, { 'chain': 'INPUT', 'table': 'nat' })
    flush_table('iptables', module, { 'chain': 'OUTPUT', 'table': 'nat' })
    flush_table('iptables', module, { 'chain': 'PREROUTING', 'table': 'nat' })

# Generated at 2022-06-23 03:56:04.757509
# Unit test for function append_param
def test_append_param():
    assert append_param(['-t', 'nat'], None, '--src-range', False) == ['!', '--src-range']
    assert append_param(['-t', 'nat'], '!abc', '--src-range', False) == ['!', '--src-range', 'abc']
    assert append_param(['-t', 'nat'], ['abc', 'def'], '--src-range', True) == ['!', '--src-range', 'abc', '!', '--src-range', 'def']



# Generated at 2022-06-23 03:56:14.249195
# Unit test for function insert_rule
def test_insert_rule():
  module = AnsibleModule()
  params = {
    "table" : "nat",
    "chain" : "PREROUTING",
    "in_interface" : "eth0",
    "protocol" : "tcp",
    "match" : "tcp",
    "destination_port" : "80",
    "jump" : "REDIRECT",
    "to_ports" : "8600",
    "comment" : "Redirect web traffic to port 8600"
  }
  iptables_path = "iptables"
  cmd = push_arguments(iptables_path, '-I', params)



# Generated at 2022-06-23 03:56:22.477145
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, None, "match")
    assert rule == []
    append_match(rule, "", "match")
    assert rule == []
    append_match(rule, "match", "match")
    assert rule == ["-m", "match"]
    rule = []
    append_match(rule, 0, "match")
    assert rule == ["-m", "match"]
    rule = []
    append_match(rule, 1, "match")
    assert rule == ["-m", "match"]
    rule = []
    append_match(rule, True, "match")
    assert rule == ["-m", "match"]


# Generated at 2022-06-23 03:56:25.036049
# Unit test for function append_wait
def test_append_wait():
    assert append_wait(rule, param, flag) == rule.extend([flag, param])


# Generated at 2022-06-23 03:56:28.962362
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, 'ACCEPT', 'accept')
    assert rule == ['-j', 'accept']



# Generated at 2022-06-23 03:56:35.056449
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '1', '--wait1')
    assert rule == ['--wait1', '1']
    rule = []
    append_wait(rule, '10s', '--wait1')
    assert rule == ['--wait1', '10s']
    rule = []
    append_wait(rule, None, '--wait1')
    assert rule == []



# Generated at 2022-06-23 03:56:39.433246
# Unit test for function append_csv
def test_append_csv():
    rule_test = []
    append_csv(rule_test, ['INVALID', 'NEW'], '--ctstate')
    return rule_test



# Generated at 2022-06-23 03:56:47.922755
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = 'iptables'
    module = AnsibleModule()
    params = {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp',
        'destination_port': '22', 'ctstate': ['NEW'], 'syn': 'match',
        'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.', 'ip_version': 'ipv4',
        'rule_num': '5'}
    cmd = push_arguments(iptables_path, '-D', params)
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-23 03:57:01.326771
# Unit test for function construct_rule

# Generated at 2022-06-23 03:57:09.939669
# Unit test for function main

# Generated at 2022-06-23 03:57:15.513951
# Unit test for function get_chain_policy
def test_get_chain_policy():
    # Valid chain policy
    assert get_chain_policy("iptables", "module", "params", "Chain INPUT (policy DROP)") == "DROP"
    # Invalid chain policy
    assert get_chain_policy("iptables", "module", "params", "Chain INPUT (policy ACCEPT)") == None
# End of unit test


# Generated at 2022-06-23 03:57:17.439332
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', {}, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-23 03:57:23.417052
# Unit test for function append_match
def test_append_match():
    rule = ['iptables','-A','INPUT']
    append_match(rule, True, 'tcp')
    assert rule == ['iptables','-A','INPUT','-m','tcp']
    rule = ['iptables','-A','INPUT']
    append_match(rule, False, 'tcp')
    assert rule == ['iptables','-A','INPUT']



# Generated at 2022-06-23 03:57:31.115158
# Unit test for function append_param
def test_append_param():

    iptables_rule = ['iptables', '-t', 'filter', '-A' , 'INPUT']
    append_param(iptables_rule, ['A','B','C','D','E','F','G','H','I'], '--state', True)
    assert iptables_rule == ['iptables', '-t', 'filter', '-A' , 'INPUT', '--state', 'A', '--state', 'B', '--state', 'C', '--state', 'D', '--state', 'E', '--state', 'F', '--state', 'G', '--state', 'H', '--state', 'I']
    iptables_rule = ['iptables', '-t', 'filter', '-A' , 'INPUT']

# Generated at 2022-06-23 03:57:36.245538
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = "1"
    flag = "--wait"
    append_wait(rule, param, flag)
    assert rule == ['--wait', '1']


# Generated at 2022-06-23 03:57:47.251742
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('/bin/iptables', None, dict(table='filter', chain='INPUT')) == 'ACCEPT'
    assert get_chain_policy('/bin/iptables', None, dict(table='filter', chain='FORWARD')) == 'ACCEPT'
    assert get_chain_policy('/bin/iptables', None, dict(table='filter', chain='OUTPUT')) == 'ACCEPT'
    assert get_chain_policy('/bin/iptables', None, dict(table='nat', chain='PREROUTING')) == 'ACCEPT'
    assert get_chain_policy('/bin/iptables', None, dict(table='nat', chain='POSTROUTING')) == 'ACCEPT'

# Generated at 2022-06-23 03:58:00.098776
# Unit test for function get_iptables_version
def test_get_iptables_version():
    # inject module_utils
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic

    reload(sys)
    sys.setdefaultencoding('utf8')

    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        """ run command with the arguments passed """
        rc = 0
        stdout = ''
        stderr = ''

        if  '/sbin/iptables --version' in ''.join(args):
            return rc, 'iptables v1.6.0', stderr
