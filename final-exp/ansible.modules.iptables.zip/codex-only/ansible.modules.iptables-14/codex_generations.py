

# Generated at 2022-06-23 03:47:58.754421
# Unit test for function flush_table
def test_flush_table():
    module = MagicMock()

# Generated at 2022-06-23 03:48:04.098770
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, "42", "--wait")
    assert rule == ["--wait", "42"]



# Generated at 2022-06-23 03:48:06.709744
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = '1'
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule == ['--wait', '1']



# Generated at 2022-06-23 03:48:18.130867
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(
        argument_spec=dict(
            ip_version=dict(type='str'),
            table=dict(type='str', default='filter'),
            chain=dict(type='str'),
            rule=dict(type='dict')
        )
    )
    test_module.params['rule']['ip_version'] = 'ipv4'
    test_module.params['rule']['chain'] = 'INPUT'
    test_module.params['rule']['jump'] = 'ACCEPT'
    status = check_present('iptables', test_module, test_module.params['rule'])
    assert(status is True)

# Generated at 2022-06-23 03:48:19.527450
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule({})
    params = dict(chain="INPUT", policy="DROP")
    assert get_chain_policy("iptables", module, params) == params["policy"]



# Generated at 2022-06-23 03:48:23.834073
# Unit test for function append_rule
def test_append_rule():
    assert ['iptables', '-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP'] == push_arguments('iptables', '-A', dict(chain='INPUT', source='8.8.8.8', jump='DROP'))



# Generated at 2022-06-23 03:48:30.186290
# Unit test for function append_match_flag
def test_append_match_flag():
    assert(append_match_flag(['rule'], None, None, True) == ['rule'], 'append_match_flag return incorrect result')
    assert(append_match_flag(['rule'], 'match', None, True) == ['rule', '--syn'], 'append_match_flag return incorrect result')
    assert(append_match_flag(['rule'], 'negate', None, True) == ['rule', '!', '--syn'], 'append_match_flag return incorrect result')
    assert(append_match_flag(['rule'], 'random', None, True) == ['rule'], 'append_match_flag return incorrect result')
    assert(append_match_flag(['rule'], 'match', None, False) == ['rule'], 'append_match_flag return incorrect result')

# Generated at 2022-06-23 03:48:34.969945
# Unit test for function append_match_flag
def test_append_match_flag():
    """
    Test that we can call the function correctly
    """
    rule = []
    append_match_flag(rule, 'match', '-j ACCEPT', False)
    assert rule == ['-j ACCEPT']



# Generated at 2022-06-23 03:48:38.106664
# Unit test for function append_rule
def test_append_rule():
    a = push_arguments('iptables', '-A', params)
    assert a == ['iptables', '-t', 'filter', '-A', 'INPUT']



# Generated at 2022-06-23 03:48:48.713802
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule({
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT'
    })
    assert flush_table('iptables', module, {
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        '_ansible_check_mode': False,
        '_ansible_no_log': False
    },) is None



# Generated at 2022-06-23 03:49:01.681676
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module_args = dict(table='filter', chain="INPUT", state="present")

# Generated at 2022-06-23 03:49:05.552734
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, "2", '-w')
    print(rule)
    assert rule == ['-w', '2']
    rule = []
    append_wait(rule, None, '-w')
    print(rule)
    assert rule == []


# Generated at 2022-06-23 03:49:08.938247
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/iptables', None) == '1.6.1'



# Generated at 2022-06-23 03:49:22.115526
# Unit test for function push_arguments

# Generated at 2022-06-23 03:49:24.069762
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', 'module', dict(table='filter', chain='FORWARD')) == 'DROP'



# Generated at 2022-06-23 03:49:33.408124
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule({})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': 80,
        'jump': 'ACCEPT'
    }
    append_rule('iptables', module, params)
    assert module.run_command.call_count == 1
    (cmd, args, kwargs) = module.run_command.call_args
    assert cmd == [
        'iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '--dport', '80', '-j', 'ACCEPT'
    ]
    assert args == ()
    assert kwargs == {'check_rc': True}



# Generated at 2022-06-23 03:49:43.379812
# Unit test for function construct_rule
def test_construct_rule():
    '''
    Test for construct_rule method.
    '''
    module = AnsibleModule(
        argument_spec=dict(
            ip_version=dict(default='ipv4', type='str', choices=[
                'ipv4', 'ipv6']),
        )
    )
    rule = [
        'iptables', '-A', 'INPUT', '-p', 'tcp', '-m', 'iprange',
        '--src-range', '192.168.1.100-192.168.1.199', '-m', 'iprange',
        '--dst-range', '10.0.0.1-10.0.0.50', '-j', 'ACCEPT',
    ]

# Generated at 2022-06-23 03:49:47.799613
# Unit test for function append_param
def test_append_param():
    rule_list = []
    rule_str = ' '

    append_param(rule_list, None, '-p', False)
    assert rule_list == []

    append_param(rule_str, None, '-p', False)
    assert rule_str == ' '

    append_str = '--protocol tcp'
    append_param(rule_list, 'tcp', '--protocol', False)
    assert rule_list == append_str.split(" ")

    append_param(rule_str, 'tcp', '--protocol', False)
    assert rule_str == (' %s ' % append_str)

    append_param(rule_list, 'tcp', '--protocol', True)
    assert rule_list == append_str.split(" ")


# Generated at 2022-06-23 03:49:49.132054
# Unit test for function insert_rule
def test_insert_rule():
    cmd = push_arguments(iptables_path, '-I', params)
    print ("test_insert_rule")
    print (cmd)
    print ("test_insert_rule")



# Generated at 2022-06-23 03:49:55.821062
# Unit test for function push_arguments
def test_push_arguments():
    cmd = push_arguments('iptables', '-I', params={'table':'filter',
                                                   'chain':'INPUT',
                                                   'rule_num':'1',
                                                   'protocol':'tcp',
                                                   'destination_port':80})
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '1', '-p', 'tcp', '--destination-port', '80']


# Generated at 2022-06-23 03:49:57.496506
# Unit test for function check_present
def test_check_present():
    assert check_present('/bin/false', '-C', 'test_chain')
    assert not check_present('/bin/true', '-C', 'test_chain')
# End unit test for function check_present



# Generated at 2022-06-23 03:49:57.893649
# Unit test for function insert_rule
def test_insert_rule():
    pass


# Generated at 2022-06-23 03:50:00.294256
# Unit test for function append_jump
def test_append_jump():
    append_jump(['-A INPUT'], 'ACCEPT', 'ACCEPT')
    append_jump(['-A INPUT'], 'DROP', 'DROP')
    append_jump(['-A INPUT'], 'QUEUE', 'QUEUE')
    append_jump(['-A INPUT'], 'RETURN', 'RETURN')


# Generated at 2022-06-23 03:50:02.019135
# Unit test for function flush_table
def test_flush_table():
    cmd = push_arguments(iptables_path, '-F', params, make_rule=False)
    module.run_command(cmd, check_rc=True)


# Generated at 2022-06-23 03:50:05.846607
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.ansible_collections.ansible.builtin.plugins.module_utils import IPTABLESModule
    module_args = dict(
        ip_version='ipv4',
    )
    module = IPTABLESModule(argument_spec=module_args)
    iptables_version = get_iptables_version(module, 'iptables')
    assert iptables_version
    assert re.match(r'(\d+)\.(\d+)\.(\d+)', iptables_version)



# Generated at 2022-06-23 03:50:15.081254
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {}
    param['flags'] = 'ALL'
    param['flags_set'] = ['ACK', 'RST', 'SYN', 'FIN']
    append_tcp_flags(rule, param, '--tcp-flags')
    assert len(rule) == 2
    assert rule == ['--tcp-flags', 'ALL,ACK,RST,SYN,FIN']
    param['flags'] = 'ACK,RST'
    param['flags_set'] = 'ACK,SYN,FIN'
    rule = []
    append_tcp_flags(rule, param, '--tcp-flags')
    assert len(rule) == 2
    assert rule == ['--tcp-flags', 'ACK,RST,ACK,SYN,FIN']
# End unit test for function append_tcp_flags


# Generated at 2022-06-23 03:50:18.532673
# Unit test for function append_match
def test_append_match():
    rule_1 = []
    append_match(rule_1, ['test'], 'test')
    assert rule_1 == ['-m', 'test']
    rule_2 = []
    append_match(rule_2, '', 'test')
    assert rule_2 == []



# Generated at 2022-06-23 03:50:25.311588
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('/bin/iptables', '-A', dict(
            chain='INPUT',
            table='mangle',
        ), False) == ['/bin/iptables', '-t', 'mangle', '-A', 'INPUT']
    assert push_arguments('/bin/iptables', '-I', dict(
            chain='INPUT',
            table='mangle',
            rule_num='2',
        ), False) == ['/bin/iptables', '-t', 'mangle', '-I', 'INPUT', '2']

# Generated at 2022-06-23 03:50:27.021283
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/iptables', '1.6.2') == '1.6.2'



# Generated at 2022-06-23 03:50:30.355256
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = 2
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule[0] == '--wait'
    assert rule[1] == '2'



# Generated at 2022-06-23 03:50:35.809621
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path='iptables'
    module='module'
    params= 'params'
    assert set_chain_policy(iptables_path, module, params)==' params -P iptables '

# Generated at 2022-06-23 03:50:37.240809
# Unit test for function append_wait
def test_append_wait():
    rule = list()
    wait = 10
    expected = ['--wait', '10']
    append_wait(rule, wait, '--wait')
    assert rule == expected


# Generated at 2022-06-23 03:50:40.307311
# Unit test for function main
def test_main():
    # Test module arguments and exit_json.
    #
    # The exit_json and fail_json magic variables are used by the ansible test
    # framework to communicate results back to the test script.
    assert True == True

# Generated at 2022-06-23 03:50:41.643735
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(rule=[], param='match', flag='-m', negatable=True) == ['-m']
    

# Generated at 2022-06-23 03:50:53.101998
# Unit test for function construct_rule

# Generated at 2022-06-23 03:50:58.424586
# Unit test for function append_match
def test_append_match():
    rule = []
    match = 'match'
    param = True
    append_match( rule, param, match)
    assert rule == ['-m', 'match']
    param = False
    append_match( rule, param, match)
    assert rule == []


# Generated at 2022-06-23 03:51:03.174987
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule,['SYN','ACK','PSH','FIN','RST','URG','ALL'],'--tcp-flags')
    print(rule)
    assert rule == ['--tcp-flags','SYN,ACK,PSH,FIN,RST,URG,ALL']


# Generated at 2022-06-23 03:51:10.488407
# Unit test for function main

# Generated at 2022-06-23 03:51:11.708076
# Unit test for function main
def test_main():
    main()



# Generated at 2022-06-23 03:51:17.634911
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/bin/iptables', None) == '1.6.1'
    assert get_iptables_version('/usr/bin/iptables', None) == '1.4.21'
    assert get_iptables_version('/usr/sbin/iptables', None) == '1.4.21'



# Generated at 2022-06-23 03:51:30.116068
# Unit test for function main
def test_main():
    import sys
    import ansible.utils
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    BIN_PATH = 'tests/iptables'
    BIN_PY2_PATH = 'tests/iptables_py2'

# Generated at 2022-06-23 03:51:34.070054
# Unit test for function remove_rule
def test_remove_rule():
    params = {'ip_version': 'ipv4',
             'chain': 'Test',
             'table': 'filter',
             'protocol': 'tcp',
             'destination': '10.10.10.10',
             'destination_port': '80'
             }
    # Expected command
    expectedcmd = ['iptables', '-t', 'filter', '-D', 'Test', '-p', 'tcp', '-d', '10.10.10.10', '--destination-port', '80']
    actualcmd = remove_rule('iptables',None,params)
    assert actualcmd == expectedcmd
    print('Test Passed')


# Generated at 2022-06-23 03:51:45.953359
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = 'iptables'
    ipv6_path = 'ip6tables'
    action = '-I'
    rule_num = '1'

# Generated at 2022-06-23 03:51:50.055237
# Unit test for function append_wait
def test_append_wait():
    result_rule = []
    param = "wait"
    flag = param
    append_wait(result_rule, wait, flag)
    assert result_rule == ["wait"]



# Generated at 2022-06-23 03:51:55.631416
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={
      'count': {'type': 'int', 'default': -1}
    })
    params = {
        'ip_version': 'ipv4',
        'chain': 'INPUT',
        'table': 'filter'
    }
    remove_rule(iptables_path, module, params)


# Generated at 2022-06-23 03:52:00.226249
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule({'source': '8.8.8.8', 'jump': 'DROP'}) == \
           ['!', '-s', '8.8.8.8', '-j', 'DROP']
    assert construct_rule({'syn': 'match', 'jump': 'ACCEPT'}) == \
           ['--syn', '-j', 'ACCEPT']
    assert construct_rule({
        'destination_ports': ['80', '443'], 'source': '10.0.0.0/24',
        'jump': 'ACCEPT'
    }) == [
        '-m', 'multiport', '-s', '10.0.0.0/24', '--dports', '80,443', '-j',
        'ACCEPT'
    ]

# Generated at 2022-06-23 03:52:09.937469
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    assert append_tcp_flags([], dict(flags='Ack', flags_set='SYN', tcp_flags_match='!ACK'), '--tcp-flags') == ['--tcp-flags', 'Ack', 'SYN']
    assert append_tcp_flags([], dict(flags='Ack', flags_set='SYN'), '--tcp-flags') == ['--tcp-flags', 'Ack', 'SYN']
    assert append_tcp_flags([], dict(flags_set='SYN', tcp_flags_match='!ACK'), '--tcp-flags') == ['--tcp-flags', 'SYN']
    assert append_tcp_flags([], dict(flags='Ack', tcp_flags_match='!ACK'), '--tcp-flags') == ['--tcp-flags', 'Ack']


# Generated at 2022-06-23 03:52:16.886789
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param1 = '1'
    param2 = '2'
    flag = '--wait'
    append_wait(rule,param1,flag)
    assert rule == ['--wait','1']
    append_wait(rule,param2,flag)
    assert rule == ['--wait','1','--wait','2']

# Generated at 2022-06-23 03:52:18.439500
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('', '', dict(chain='INPUT', ip_version='ipv4', table='filter')) == 'ACCEPT'



# Generated at 2022-06-23 03:52:24.102838
# Unit test for function append_csv
def test_append_csv():
    list1 = []
    list2 = ['test1', 'test2', 'test3']
    assert append_csv(list1, list2, '--test') == ['--test', 'test1,test2,test3']



# Generated at 2022-06-23 03:52:31.998209
# Unit test for function append_wait
def test_append_wait():
    assert len(append_wait(rule=['test'], param=1, flag='--wait')) == 2
    assert append_wait(rule=['test'], param=1, flag='--wait') == ['test', '--wait', 1]
    assert len(append_wait(rule=['test', 'test2'], param=1, flag='--wait')) == 3
    assert append_wait(rule=['test', 'test2'], param=1, flag='--wait') == ['test', 'test2', '--wait', 1]



# Generated at 2022-06-23 03:52:37.679288
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, "match", '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, "negate", '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, "invalid", '--syn', True)
    assert rule == []
    rule = []
    append_match_flag(rule, "match", '--syn', False)
    assert rule == []
    rule = []
    append_match_flag(rule, "negate", '--syn', False)
    assert rule == []
    rule = []
    append_match_flag(rule, "invalid", '--syn', False)
    assert rule == []
test_append_match_

# Generated at 2022-06-23 03:52:42.590065
# Unit test for function construct_rule

# Generated at 2022-06-23 03:52:55.992124
# Unit test for function main
def test_main():
    from ansible.modules.network.iptables import main
    from ansible.module_utils.ansible_modlib.common.utils import AnsibleModule

    # iptables -t filter -I INPUT -p tcp --dport 8888 -j ACCEPT

# Generated at 2022-06-23 03:53:05.916731
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test', '--test', False)
    assert rule == ['--test', 'test'], 'Failed to append single value to rule'
    rule = []
    append_param(rule, '!test', '--test', False)
    assert rule == ['!', '--test', 'test'], 'Failed to append negated single value to rule'
    rule = []
    append_param(rule, ['test', 'test2'], '--test', True)
    assert rule == ['--test', 'test', '--test', 'test2'], 'Failed to append list to rule'
    rule = []
    append_param(rule, ['!test', 'test2'], '--test', True)

# Generated at 2022-06-23 03:53:10.582121
# Unit test for function get_iptables_version
def test_get_iptables_version():
    # Mock the module object
    module_obj = AnsibleModule(argument_spec={})
    module_obj.run_command = MagicMock(return_value=(0, 'iptables v1.6.0\n', ''))

    assert get_iptables_version('/usr/sbin/iptables', module_obj) == '1.6.0'



# Generated at 2022-06-23 03:53:22.129814
# Unit test for function flush_table
def test_flush_table():
    params = dict(
        chain= 'INPUT',
        table= 'filter',
        wait= '120',
        action= 'flush',
        flush= True,
        state= 'present',
        )
    assert flush_table('iptables', 'module', params) == ['iptables', '-t', 'filter', '-F', 'INPUT', '-w', '120']
    params_2 = dict(
        chain= 'INPUT',
        table= 'mangle',
        wait= '120',
        action= 'flush',
        flush= True,
        state= 'present',
        )
    assert flush_table('iptables', 'module', params) == ['iptables', '-t', 'mangle', '-F', 'INPUT', '-w', '120']



# Generated at 2022-06-23 03:53:24.251063
# Unit test for function append_jump
def test_append_jump():
    rule = []
    jump = "ACCEPT"
    append_jump(rule, jump, jump)
    assert rule == ['-j', 'ACCEPT']

test_append_jump()



# Generated at 2022-06-23 03:53:36.327037
# Unit test for function push_arguments
def test_push_arguments():
    assert(push_arguments('iptables', '-I', {
                'protocol': 'tcp',
                'table': 'filter',
                'chain': 'INPUT',
                'rule_num': 2,
                'destination_port': 80,
                'jump': 'ACCEPT',
                'comment': 'Test comment',
                }) == [
                    'iptables',
                    '-t', 'filter',
                    '-I', 'INPUT',
                    '2',
                    '-p', 'tcp',
                    '--dport', '80',
                    '-j', 'ACCEPT',
                    '-m', 'comment',
                    '--comment', 'Test comment',
                ])

# Generated at 2022-06-23 03:53:48.775354
# Unit test for function flush_table
def test_flush_table():
    params = {
        'table': 'nat',
        'chain': 'INPUT',
    }
    module = None
    # Mocking os.path.exists so that iptables exists in this case
    import __builtin__
    __builtin__.__dict__['os'] = __dict__['os']
    import os
    import mock
    mocked_path = mock.MagicMock(spec=os.path)
    mocked_path.exists = mock.MagicMock(return_value=True)
    mocked_path.realpath = mock.MagicMock(return_value='/sbin/iptables')
    __builtin__.__dict__['os'] = mocked_path
    # Mocking module
    __builtin__.__dict__['AnsibleModule'] = AnsibleModule
    mocked_module = mock

# Generated at 2022-06-23 03:53:52.923849
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', 'iptables v1.6.0') == "1.6.0"
    assert get_iptables_version('ip6tables', 'ip6tables v1.4.20') == "1.4.20"


# Generated at 2022-06-23 03:53:57.355177
# Unit test for function flush_table
def test_flush_table():
    assert(flush_table(None, None, {'table': 'nat', 'chain': 'INPUT'}) == ['-t', 'nat', '-F', 'INPUT'])



# Generated at 2022-06-23 03:54:07.644341
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = ['iptables', '-A', 'INPUT', '-p', 'tcp', '--dport', '80']
    flags = {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK']}
    assert append_tcp_flags(rule, flags, '--tcp-flags') == None
    assert rule == ['iptables', '-A', 'INPUT', '-p', 'tcp', '--dport', '80', '--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK']
    assert append_tcp_flags(rule, None, '--tcp-flags') == None


# Generated at 2022-06-23 03:54:18.214548
# Unit test for function push_arguments

# Generated at 2022-06-23 03:54:21.610657
# Unit test for function append_param
def test_append_param():
    param = ['A', 'B', 'C', '!D']
    rule = []
    append_param(rule, param, '--flag', True)
    assert rule == ['--flag', 'A', '--flag', 'B', '--flag', 'C', '!', '--flag', 'D']



# Generated at 2022-06-23 03:54:33.894206
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        destination_port='80',
        jump=None,
    )
    assert construct_rule(params) == [
        '-p', 'tcp', '--destination-port', '80', '-j', 'REJECT',
    ]
    params = dict(
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
    )
    assert construct_rule(params) == [
        '-p', 'tcp', '--destination-port', '80', '-j', 'ACCEPT',
    ]
    params = dict(
        protocol='tcp',
        destination_port='80',
        jump=None,
        reject_with='tcp-reset',
    )

# Generated at 2022-06-23 03:54:35.592686
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables',1,1) == None



# Generated at 2022-06-23 03:54:43.104528
# Unit test for function get_iptables_version
def test_get_iptables_version():
    print("Function: get_iptables_version")
    print("result: %s" % get_iptables_version("iptables", "1.4.20"))
    print("result: %s" % get_iptables_version("iptables", "1.6.0"))
    print("result: %s" % get_iptables_version("iptables", "1.8.0"))
    print("result: %s" % get_iptables_version("iptables", "1.8.1"))
    print("result: %s" % get_iptables_version("iptables", "2.0.0"))

# Generated at 2022-06-23 03:54:47.600757
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/ip4/iptables'
    module = AnsibleModule({})
    flush_table(iptables_path, module, params={})



# Generated at 2022-06-23 03:54:50.036136
# Unit test for function flush_table
def test_flush_table():
    iptables_path = "iptables"
    module = "module"
    params = {
        'chain': 'INPUT',
	'table': 'nat'
    }
    flush_table(iptables_path, module, params)



# Generated at 2022-06-23 03:54:54.829674
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(dict())
    assert check_present("/usr/bin/iptables", module, dict(table="mangle", chain="INPUT", ip_version="ipv4", source_port="123", destination_port="123", destination="10.1.1.1", syn="match"))
    assert not check_present("/usr/bin/iptables", module, dict(table="mangle", chain="INPUT", ip_version="ipv4", source_port="123", destination_port="321", destination="10.1.1.1", syn="match"))



# Generated at 2022-06-23 03:55:05.608529
# Unit test for function flush_table
def test_flush_table():
    ipv4_module = AnsibleModule(
        argument_spec=dict(
            wait=dict(),
            table=dict(default='filter'),
            chain=dict(default=None),
            ip_version=dict(default='ipv4'),
            flush=dict(default=False),
        ),
    )
    ipv4_params = dict(
        wait = '1',
        table = 'INPUT',
    )  
    flush_table('iptables', ipv4_module, ipv4_params)



# Generated at 2022-06-23 03:55:11.611226
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = "port1,port2"
    flag = "--port"
    append_csv(rule,param,flag)
    assert rule == ["--port","port1,port2"]
    rule = []
    param = []
    flag = "--port"
    append_csv(rule,param,flag)
    assert rule == []


# Generated at 2022-06-23 03:55:13.090707
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(iptables_path, module) == '1.6.2'



# Generated at 2022-06-23 03:55:21.082544
# Unit test for function append_jump
def test_append_jump():
    assert append_jump(['iptables', '-A'], 'ACCEPT', 'ACCEPT') == ['iptables', '-A', '-j', 'ACCEPT']
    assert append_jump(['iptables', '-I', 'INPUT', '1'], 'DROP', 'DROP') == ['iptables', '-I', 'INPUT', '1', '-j', 'DROP']



# Generated at 2022-06-23 03:55:24.542525
# Unit test for function append_wait
def test_append_wait():
    # On platforms without wait support, this will fail
    rule = []
    append_wait(rule, '5', '--wait')
    assert(rule == ['--wait', '5'])



# Generated at 2022-06-23 03:55:25.962956
# Unit test for function append_match
def test_append_match():
  rule = []
  append_match(rule, True, 'tcp')
  assert rule == ['-m', 'tcp']


# Generated at 2022-06-23 03:55:27.402123
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:55:29.301595
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables',None)=='1.5.5'



# Generated at 2022-06-23 03:55:37.105800
# Unit test for function push_arguments

# Generated at 2022-06-23 03:55:41.243483
# Unit test for function construct_rule

# Generated at 2022-06-23 03:55:44.507781
# Unit test for function append_param
def test_append_param():
    assert(append_param([], "test", "-t", False) == ["-t", "test"])
    assert(append_param([], "test", "--test", False) == ["--test", "test"])
    assert(append_param([], ["test", "test2"], "--test", True) == ["--test", "test", "--test", "test2"])
    assert(append_param([], ["test", "!test2"], "--test", True) == ["--test", "test", "!", "--test", "test2"])


# Generated at 2022-06-23 03:55:48.013397
# Unit test for function append_wait
def test_append_wait():
    rule = list()
    param = '1'
    flag = '--wait'
    append_wait(rule,param,flag)
    assert rule == ['--wait','1']
    param = None
    append_wait(rule,param,flag)
    assert rule == ['--wait','1']
    return True


# Generated at 2022-06-23 03:55:50.924530
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert 'DROP' == get_chain_policy(None, None, dict(chain='INPUT', table='filter'))
    assert 'ACCEPT' == get_chain_policy(None, None, dict(chain='FORWARD', table='filter'))
    assert 'ACCEPT' == get_chain_policy(None, None, dict(chain='OUTPUT', table='filter'))
    assert None == get_chain_policy(None, None, dict(chain='test', table='filter'))



# Generated at 2022-06-23 03:55:58.472520
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-23 03:56:06.132524
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = list()
    append_match_flag(rule, 'match', '--syn', True)
    append_match_flag(rule, 'negate', '--syn', True)
    append_match_flag(rule, None, '--syn', True)
    assert rule == ['--syn', '!', '--syn']



# Generated at 2022-06-23 03:56:19.775779
# Unit test for function remove_rule
def test_remove_rule():
    print('Test case')
    class ModuleStub(object):
        def run_command(self, cmd, check_rc=False):
            return 0, "", ""
    params = dict(
        action='remove',
        chain='INPUT',
        ip_version='ipv4',
        table='filter',
        protocol='tcp',
    )
    iptables_path = 'iptables'
    module = ModuleStub()
    expected_output = ['iptables', '-t', 'filter','-D', 'INPUT', '-p', 'tcp']
    cmd = push_arguments(iptables_path, '-D', params)
    remove_rule(iptables_path, module, params)
    assert cmd == expected_output
    print('Done')



# Generated at 2022-06-23 03:56:24.089082
# Unit test for function get_iptables_version
def test_get_iptables_version():
    """
    Testing function to get iptables version
    """
    module = AnsibleModule({})
    iptables_path = 'iptables'
    iptables_version = get_iptables_version(iptables_path, module)
    assert isinstance(iptables_version, str)
    # validate iptables version is valid
    LooseVersion(iptables_version)


# Generated at 2022-06-23 03:56:29.561675
# Unit test for function push_arguments
def test_push_arguments():
    for ipversion in ('ipv4', 'ipv6'):
        cmd = push_arguments(BINS[ipversion], '-I', dict(table='filter', protocol='tcp', chain='INPUT', jump='ACCEPT', destination_port='80,443', destination='8.8.8.0/24', ip_version=ipversion, comment='Test'))
        assert cmd == [BINS[ipversion], '-t', 'filter', '-I', 'INPUT', '-p', 'tcp', '-s', '8.8.8.0/24', '-d', '80,443', '-m', 'comment', '--comment', 'Test', '-j', 'ACCEPT']

# Generated at 2022-06-23 03:56:41.533516
# Unit test for function append_csv
def test_append_csv():
    import sys
    rule = []

    append_csv(rule, [], flag='TestFlag')

    append_csv(rule, [1, 2, 3], flag='TestFlag')

    append_csv(rule, ['1', '2', '3'], flag='TestFlag')

    assert(len(rule) == 0)

    print("All tests passed")


# Generated at 2022-06-23 03:56:42.772636
# Unit test for function set_chain_policy
def test_set_chain_policy():
    set_chain_policy("/sbin/iptables", "/path/to/file", "ACCEPT")

# Generated at 2022-06-23 03:56:50.858463
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['single']
    flag = '--single'
    append_csv(rule, param, flag)
    assert(rule == ['--single', 'single'])
    rule = []
    param = ['multiple', 'values']
    flag = '--multiple'
    append_csv(rule, param, flag)
    assert(rule == ['--multiple', 'multiple,values'])
    rule = []
    param = None
    flag = '--none'
    append_csv(rule, param, flag)
    assert(rule == [])



# Generated at 2022-06-23 03:57:03.795141
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination='10.0.0.1',
        jump='DROP',
        ip_version="ipv4",
    )
    expected = ['-s', '10.0.0.1', '-p', 'tcp', '-j', 'DROP']
    assert construct_rule(params) == expected

    params = dict(
        chain='FORWARD',
        ip_version="ipv4",
        source_port="1:65535",
        destination_port="80",
        jump="ACCEPT",
    )

# Generated at 2022-06-23 03:57:14.747822
# Unit test for function append_param
def test_append_param():
    assert (append_param([], None, '--dport', False) == [])
    assert (append_param([], '!22', '--dport', False) == ['!', '--dport', '22'])
    assert (append_param([], '22', '--dport', False) == ['--dport', '22'])
    assert (append_param([], ['22', '23'], '--dport', True) == ['--dport', '22', '--dport', '23'])
    assert (append_param([], ['22','!23'], '--dport', True) == ['--dport', '22', '!', '--dport', '23'])



# Generated at 2022-06-23 03:57:26.365900
# Unit test for function push_arguments
def test_push_arguments():
    IP_VERSION = 'ipv4'
    MODULE_PARAMS = dict(
        ip_version=IP_VERSION,
        chain='INPUT',
        source='1.2.3.4',
        destination_port='80',
        in_interface='eth0',
        jump='DROP',
        action='append',
        table='filter',
        state='present',
        wait="10",
    )
    IPTABLES_PATH = BINS[IP_VERSION]
    assert push_arguments(IPTABLES_PATH, '-A', MODULE_PARAMS, False) == [IPTABLES_PATH, '-t', 'filter', '-A', 'INPUT']

# Generated at 2022-06-23 03:57:35.045016
# Unit test for function construct_rule
def test_construct_rule():
  import json
  import pprint
  result = construct_rule({'protocol': 'tcp', 'destination_port': '22', 'jump': 'ACCEPT', 'icmp_type': 'echo-request', 'ip_version': 'ipv4', 'comment': 'test comment'})
  assert result == ['--protocol', 'tcp', '--destination-port', '22', '-j', 'ACCEPT', '--icmp-type', 'echo-request', '-m', 'comment', '--comment', 'test comment']

  result = construct_rule({'protocol': 'tcp', 'destination_ports': ['22', '80'], 'jump': 'ACCEPT', 'icmp_type': 'echo-request', 'ip_version': 'ipv4', 'comment': 'test comment'})

# Generated at 2022-06-23 03:57:38.403516
# Unit test for function append_csv
def test_append_csv():
    rule = []
    csv = [u'src', u'dst']
    append_csv(rule, csv, '--match-set')
    assert(rule == ['--match-set', 'src,dst'])



# Generated at 2022-06-23 03:57:39.496098
# Unit test for function append_rule
def test_append_rule():
    assert append_rule("pth", module, params) == True



# Generated at 2022-06-23 03:57:54.107057
# Unit test for function main