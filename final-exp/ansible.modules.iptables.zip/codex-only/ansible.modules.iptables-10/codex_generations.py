

# Generated at 2022-06-23 03:47:54.207069
# Unit test for function append_rule
def test_append_rule():
    assert append_rule() == true


# Generated at 2022-06-23 03:48:03.264365
# Unit test for function construct_rule

# Generated at 2022-06-23 03:48:05.900920
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', 'iptables v1.3.3') == '1.3.3'



# Generated at 2022-06-23 03:48:08.570360
# Unit test for function append_param
def test_append_param():
    for is_list in [True, False]:
        for param in [None, '!test', 'test']:
            if param is None:
                assert append_param([], param, 'a', is_list) == []
            elif param[0] == '!':
                assert append_param([], param, 'a', is_list) == ['!', 'a', param[1:]]
            else:
                assert append_param([], param, 'a', is_list) == ['a', param]



# Generated at 2022-06-23 03:48:18.803668
# Unit test for function push_arguments

# Generated at 2022-06-23 03:48:24.838041
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    if 'flags' in param and 'flags_set' in param:
        rule.extend([flag, ','.join(param['flags']), ','.join(param['flags_set'])])
    assert len(rule) == 3


# Generated at 2022-06-23 03:48:27.232509
# Unit test for function append_match
def test_append_match():
    expected = ['-m', 'match']
    actual = []
    append_match(actual, True, 'match')
    assert actual == expected
    actual = []
    append_match(actual, False, 'match')
    assert actual == []



# Generated at 2022-06-23 03:48:31.873078
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, {'flags': 'ALL', 'flags_set': ['SYN','ACK','FIN','RST','URG','PSH','ECE','CWR','NS']}, "--tcp-flags")
    assert rule == [ '--tcp-flags', 'ALL', 'SYN,ACK,FIN,RST,URG,PSH,ECE,CWR,NS']

    rule = []
    append_tcp_flags(rule, {'flags': 'NONE', 'flags_set': ['SYN']}, "--tcp-flags")
    assert rule == [ '--tcp-flags', 'NONE', 'SYN']

    rule = []

# Generated at 2022-06-23 03:48:35.495908
# Unit test for function get_iptables_version
def test_get_iptables_version():
    class FakeModule(object):

        def run_command(self, cmd, check_rc=True):
            return 0, 'v1.4.21', ''

    assert get_iptables_version('', FakeModule()) == '1.4.21'



# Generated at 2022-06-23 03:48:37.770312
# Unit test for function append_match
def test_append_match():
    rule = []
    match = 'tcp'
    append_match(rule, True, match)
    assert rule == ['-m', match]
    rule = []
    append_match(rule, False, match)
    assert rule == []
    rule = []
    append_match(rule, 'test', match)
    assert rule == []



# Generated at 2022-06-23 03:48:39.573374
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', None, dict(table='filter', chain='INPUT'))



# Generated at 2022-06-23 03:48:40.043494
# Unit test for function get_chain_policy
def test_get_chain_policy():
    pass



# Generated at 2022-06-23 03:48:45.778841
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, None, '--foo')
    assert rule == []
    rule = []
    append_csv(rule, ['bar', 'baz'], '--foo')
    assert rule == ['--foo', 'bar,baz']


# Generated at 2022-06-23 03:48:48.172870
# Unit test for function append_jump
def test_append_jump():
    rule=[]
    param="param"
    jump="ACCEPT"
    append_jump(rule, param, jump)
    assert rule==['-j', 'ACCEPT']
    param=None
    append_jump(rule, param, jump)
    assert rule==['-j', 'ACCEPT']
    jump=None
    append_jump(rule, param, jump)
    assert rule==['-j', 'ACCEPT']



# Generated at 2022-06-23 03:49:00.891386
# Unit test for function main

# Generated at 2022-06-23 03:49:07.507577
# Unit test for function flush_table
def test_flush_table():
    iptables_path = "iptables"
    action = "-F"

# Generated at 2022-06-23 03:49:17.234282
# Unit test for function append_match_flag
def test_append_match_flag():
    # negatable is false, param is false,we only append flag to rule
    rule = []
    param = False
    flag = '--syn'
    negatable = False
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['--syn']

    # negatable is true, param is match, we append '--syn' to rule
    rule = []
    param = 'match'
    flag = '--syn'
    negatable = True
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['--syn']

    # negatable is true, param is negate, we append '! --syn' to rule
    rule = []
    param = 'negate'
    flag = '--syn'
    negatable = True

# Generated at 2022-06-23 03:49:22.542424
# Unit test for function get_iptables_version
def test_get_iptables_version():
    import sys
    import subprocess
    iptables_path = BINS[sys.version_info.major]
    # fake module object
    class MoModule(object):
        def run_command(self, cmd, check_rc=False):
            rc = subprocess.call(cmd)
            if rc:
                raise Exception('fail to run command: {}'.format(cmd))
            return rc, 'iptables v1.4.21', None
    module = MoModule()
    version = get_iptables_version(iptables_path, module)
    assert version == '1.4.21'


# Generated at 2022-06-23 03:49:29.550837
# Unit test for function append_match
def test_append_match():
    r = ['-A', 'INPUT']
    append_match(r, 'state', 'state')
    assert r == ['-A', 'INPUT', '-m', 'state']
    r = ['-I', 'INPUT', '4']
    append_match(r, 'state', 'state')
    assert r == ['-I', 'INPUT', '4', '-m', 'state']



# Generated at 2022-06-23 03:49:38.980292
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT')) is None
    assert get_chain_policy(None, None, dict(chain='INPUT', ip_version='ipv4')) is None
    assert get_chain_policy(None, None, dict(chain='INPUT', ip_version='ipv6')) is None
    assert get_chain_policy(None, None, dict(chain='INPUT', ip_version='ipv4', policy='ACCEPT')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='INPUT', ip_version='ipv6', policy='ACCEPT')) == 'ACCEPT'



# Generated at 2022-06-23 03:49:46.946035
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []
    rule = []
    append_match_flag(rule, None, '--syn', False)
    assert rule == []


# Generated at 2022-06-23 03:49:55.908613
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='ACCEPT')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='DROP')) == 'DROP'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='RETURN')) == 'RETURN'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='QUEUE')) == 'QUEUE'
    assert not get_chain_policy(None, None, dict(chain='INPUT', policy=None))



# Generated at 2022-06-23 03:49:56.945196
# Unit test for function remove_rule
def test_remove_rule():
    return (None, None, None)



# Generated at 2022-06-23 03:50:03.513461
# Unit test for function flush_table

# Generated at 2022-06-23 03:50:08.429505
# Unit test for function construct_rule

# Generated at 2022-06-23 03:50:10.784801
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", "", "", "") == None



# Generated at 2022-06-23 03:50:17.346090
# Unit test for function push_arguments
def test_push_arguments():
    actual_result = push_arguments(
        '/sbin/iptables',
        '-A',
        dict(
            ip_version='ipv4',
            table='nat',
            chain='INPUT',
            in_interface='eth0',
            protocol='tcp',
            match='tcp',
            destination_port=80,
            jump='REDIRECT',
            to_ports=8600,
            comment='Redirect web traffic to port 8600',
            args=[],
        )
    )

# Generated at 2022-06-23 03:50:23.885305
# Unit test for function check_present
def test_check_present():
    assert check_present('./iptables', {}, {'chain': None, 'table': 'filter', 'ip_version': 'ipv4'}) == True
    assert check_present('./iptables', {}, {'chain': 'INPUT', 'table': 'filter', 'ip_version': 'ipv4'}) == False


# Generated at 2022-06-23 03:50:26.374591
# Unit test for function append_rule
def test_append_rule():
    assert(append_rule('iptables', {}, {'table':'aaa', 'chain':'bbb'}) == ['iptables', '-t', 'aaa', '-A', 'bbb'])


# Generated at 2022-06-23 03:50:35.809406
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = ['iptables', '-A', 'INPUT']
    param = dict(flags=['ALL', 'FIN', 'SYN', 'RST'], flags_set=['ACK', 'FIN'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['iptables', '-A', 'INPUT', '--tcp-flags', 'ALL,FIN,SYN,RST', 'ACK,FIN']
    return True


# Generated at 2022-06-23 03:50:36.416320
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy() == None



# Generated at 2022-06-23 03:50:43.113415
# Unit test for function set_chain_policy
def test_set_chain_policy():
    test_iptables_path = "/usr/sbin/iptables"
    test_module = AnsibleModule(argument_spec={})
    test_params = dict(
        ip_version = 'ipv4',
        table = 'filter',
        ip_version = 'ipv4',
        chain = 'INPUT',
        state = 'present',
        jump = 'ACCEPT',
        policy = 'DROP'
    )
    set_chain_policy(test_iptables_path, test_module, test_params)



# Generated at 2022-06-23 03:50:51.417307
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {}
    param['flags'] = ['ALL', 'INVALID']
    param['flags_set'] = ['ACK', 'RST', 'SYN', 'FIN']
    append_tcp_flags(rule, param, '-m tcp --tcp-flags')
    assert rule == ['-m', 'tcp', '--tcp-flags', 'ALL,INVALID', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-23 03:50:57.521578
# Unit test for function push_arguments
def test_push_arguments():
    module_args = dict(
        chain="filter",
        action="append",
        table="filter",
        src_range="192.168.1.100-192.168.1.199",
        dst_range="10.0.0.1-10.0.0.50",
        jump="ACCEPT",
        ip_version="ipv4"
    )

# Generated at 2022-06-23 03:51:03.280843
# Unit test for function set_chain_policy
def test_set_chain_policy():
    result = set_chain_policy('iptables', None, {
        'table': 'filter',
        'ip_version': 'ipv4',
        'chain': 'INPUT',
        'policy': 'DROP',
    })
    assert result == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-23 03:51:12.750697
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/bin/ip6tables'
    module = 'thisisatest'
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': 56789,
        'jump': 'ACCEPT',
        'rule_num': '1',
    }
    cmd = push_arguments(iptables_path, '-I', params)
    print(cmd)



# Generated at 2022-06-23 03:51:20.538755
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'],flags_set=['ACK', 'RST'])
    append_tcp_flags(rule, param, '--tcp-flags')
    expected = ['--tcp-flags', ','.join(param['flags']), ','.join(param['flags_set'])]
    assert rule == expected


# Generated at 2022-06-23 03:51:28.200292
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        chain='INPUT',
        table='filter',
        ip_version='ipv4',
    ))
    print(get_chain_policy('iptables', module, dict(chain='INPUT', table='filter', ip_version='ipv4')))
    print(get_chain_policy('iptables', module, dict(chain='FOO', table='filter', ip_version='ipv4')))


# Generated at 2022-06-23 03:51:32.003866
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', dict(run_command= (0, 'iptables -C INPUT -j DROP')), dict(ip_version='ipv4', chain='INPUT', jump='DROP')) is True
    assert check_present('iptables', dict(run_command= (1, 'iptables -C INPUT -j DROP')), dict(ip_version='ipv4', chain='INPUT', jump='DROP')) is False



# Generated at 2022-06-23 03:51:43.472728
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test_ipv4_params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
    )
    test_ipv6_params = dict(
        ip_version='ipv6',
        table='filter',
        chain='INPUT',
    )
    test_ipv4_chain = r'Chain INPUT (policy DROP)'
    test_ipv4_out = r"%(chain)s\n\n\n" % dict(chain=test_ipv4_chain)
    test_ipv6_chain = r'Chain INPUT (policy DROP)'
    test_ipv6_out = r"%(chain)s\n\n\n" % dict(chain=test_ipv6_chain)

# Generated at 2022-06-23 03:51:50.170821
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = "iptables"
    module = "AnsibleModule"
    args = dict(
        chain="FORWARD",
        ip_version="ipv4",
        table="filter"
    )
    remove_rule(iptables_path, module, args)



# Generated at 2022-06-23 03:51:55.023775
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None,None,{'chain':'FORWARD'}) == 'DROP'
    assert get_chain_policy(None,None,{'chain':'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None,None,{'chain':'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-23 03:51:59.147279
# Unit test for function append_param
def test_append_param():
    for pair in [
        (["aa", "bb", "cc"], ["aa", "bb", "cc"]),
        (["aa", "bb", "cc"], ["aa", "bb", ["cc"]]),
        (["aa", "bb", "cc", "dd", "cc", "dd", "ee"], ["aa", "bb", ["cc", "dd"], ["cc", "dd"], ["ee"]]),
        (["aa", "bb", "!cc", "dd", "!ee"], ["aa", "bb", ["cc", "dd"], ["ee"]]),
    ]:
        rule = []
        param = pair[1]
        append_param(rule, param, "flag", True)
        assert rule == pair[0]


# Generated at 2022-06-23 03:52:07.242201
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', 'hello', True)
    assert rule == ['hello']
    rule = []
    append_match_flag(rule, 'negate', 'hello', True)
    assert rule == ['!', 'hello']
    rule = []
    append_match_flag(rule, None, 'hello', True)
    assert rule == []
    rule = []
    append_match_flag(rule, 'ignore', 'hello', True)
    assert rule == []



# Generated at 2022-06-23 03:52:13.811689
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['ESTABLISHED', 'RELATED']
    flag = '--ctstate'
    expected = ['--ctstate', 'ESTABLISHED,RELATED']
    append_csv(rule, param, flag)
    assert rule == expected


# Generated at 2022-06-23 03:52:20.181412
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/ip6tables'
    parameters = {
        'chain': 'LOGGING',
        'table': 'mangle',
        'log_prefix': 'IPTABLES:INFO: ',
        'log_level': 'info'
    }
    remove_rule(iptables_path, module, parameters)



# Generated at 2022-06-23 03:52:21.860613
# Unit test for function set_chain_policy
def test_set_chain_policy():
    print(set_chain_policy('1', '2', {'table': 'filter', 'chain': 'INPUT', 'policy': 'DROP'}))



# Generated at 2022-06-23 03:52:29.132841
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    flags = dict()
    flags['flags'] = ['ACK', 'RST', 'SYN', 'FIN']
    flags['flags_set'] = ['ACK', 'SYN']
    temp_dict = dict()
    for key, value in flags.items():
        if key in temp_dict and isinstance(temp_dict[key], list):
            temp_dict[key].extend(value)
        else:
            temp_dict[key] = value
    rule = []
    append_tcp_flags(rule, temp_dict, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,SYN']



# Generated at 2022-06-23 03:52:31.752435
# Unit test for function append_wait
def test_append_wait():
    rule = ['iptables']
    append_wait(rule, param='1s', flag='--wait')
    assert rule == ['iptables', '--wait', '1s']



# Generated at 2022-06-23 03:52:33.260004
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C',
          dict(chain='INPUT',
               source='8.8.8.8',
               jump='DROP',
               table='filter')) == True



# Generated at 2022-06-23 03:52:37.992210
# Unit test for function get_chain_policy
def test_get_chain_policy():
    policy = get_chain_policy('iptables', 'module', 'params')
    assert policy == None



# Generated at 2022-06-23 03:52:42.047164
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(['x'], 'x', '--x', False)
    assert rule == ['--x', 'x']
    append_param(rule, 'x', '--x', False)
    assert rule == ['--x', 'x']
    append_param(rule, ['x'], '--x', True)
    assert rule == ['--x', 'x']
    assert append_param(['x'], ['x'], '--x', True) == ['--x', 'x']
    assert append_param(['x'], ['x'], '--x', False) == ['--x', 'x']

import ast

# Generated at 2022-06-23 03:52:48.373147
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, ['foo','bar'], '-m','placeholder')
    assert rule == ['-m','placeholder','foo','-m','placeholder','bar']


# Generated at 2022-06-23 03:53:01.561497
# Unit test for function check_present
def test_check_present():
    test_params = [{
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080'
    }, {
        'table': 'mangle',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'tcp_flags': { 'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'SYN'] }
    }]
    test_iptables_paths = { 'ipv4': '/usr/sbin/iptables', 'ipv6': '/usr/sbin/ip6tables' }

# Generated at 2022-06-23 03:53:09.634395
# Unit test for function check_present

# Generated at 2022-06-23 03:53:15.636977
# Unit test for function append_csv
def test_append_csv():
    assert append_csv([], [], 'flag') == []
    assert append_csv([], ['a'], 'flag') == ['flag', 'a']
    assert append_csv([], ['a', 'b'], 'flag') == ['flag', 'a,b']



# Generated at 2022-06-23 03:53:26.856047
# Unit test for function insert_rule
def test_insert_rule():
    params = {}
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['rule_num'] = '5'

    c = construct_rule(params)
    params['protocol'] = 'tcp'
    # params['source'] = '192.168.1.0/24'
    params['jump'] = 'ACCEPT'
    params['destination_port'] = '8080'
    # params['in_interface'] = 'eth0'
    # params['out_interface'] = 'eth1'

    assert c == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--destination-port', '8080', '-j', 'ACCEPT']
    params['protocol'] = 'udp'
   

# Generated at 2022-06-23 03:53:32.038992
# Unit test for function append_wait
def test_append_wait():
    rule = []

    for param in [1, 10, '1', '10', 1.5, '1day', '1day']:
        append_wait(rule, param, '-w')
        assert rule[-1] == '-w'
        assert rule[-2] == param



# Generated at 2022-06-23 03:53:36.979408
# Unit test for function insert_rule
def test_insert_rule():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5')
    result = insert_rule('iptables', module, params)
    #result = None
    #assert result == None



# Generated at 2022-06-23 03:53:46.235179
# Unit test for function get_chain_policy
def test_get_chain_policy():
    class MockModule(object):
        def __init__(self):
            self.run_command_result = (0, "Chain OUTPUT (policy ACCEPT)")

        def run_command(self, cmd, check_rc=True):
            return self.run_command_result

    iptables_path = "/bin/iptables"
    params = dict(
        chain = "OUTPUT",
        table = "filter",
    )
    get_chain_policy(iptables_path, MockModule(), params)



# Generated at 2022-06-23 03:53:50.539237
# Unit test for function append_match
def test_append_match():
  assert append_match([], 1,'test') == ['-m','test']
  assert append_match([], 0, 'test') == []


# Generated at 2022-06-23 03:53:52.158174
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == LooseVersion('1.4.21')



# Generated at 2022-06-23 03:54:03.935636
# Unit test for function append_param
def test_append_param():
    p1 = ['-s', '8.8.8.8']
    p2 = ['-s', '!8.8.8.8']
    p3 = ['-s', '!8.8.8.8', '-s', '10.10.10.10']
    p4 = ['-m', 'comment', '--comment', 'test']
    p5 = ['-m', 'comment', '!', '--comment', 'test']

    rule = []
    append_param(rule, None, '-s', False)
    assert not rule

    rule = []
    append_param(rule, [], '-s', True)
    assert not rule

    rule = []
    append_param(rule, '8.8.8.8', '-s', False)
    assert rule == p1

    rule

# Generated at 2022-06-23 03:54:09.153086
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('/usr/sbin/iptables', 'iptables', 'INPUT', 'DROP') == None


# Generated at 2022-06-23 03:54:16.105912
# Unit test for function remove_rule
def test_remove_rule():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from module_utils.basic import AnsibleModule
    IPTABLES_PATH = '/sbin/iptables'
    module = AnsibleModule(check_invalid_arguments=False)
    module.run_command = lambda cmd, check, warn: (0, '', '')
    remove_rule(IPTABLES_PATH, module, {'chain': 'INPUT', 'table': 'filter'})
    assert module.run_command.called
    assert module.run_command.call_args[0][0] == [IPTABLES_PATH, '-t', 'filter', '-D', 'INPUT']


# Generated at 2022-06-23 03:54:20.945933
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, '10.0.0.1/24', '--source', False)
    assert rule == ['--source', '10.0.0.1/24']
    rule = []
    append_param(rule, '8088', '--destination-port', False)
    assert rule == ['--destination-port', '8088']
    rule = []
    append_param(rule, '!8088', '--destination-port', False)
    assert rule == ['!--destination-port', '8088']
    rule = []
    append_param(rule, ['8088', '5500:5555'], '--destination-port', True)
    assert rule == ['--destination-port', '8088', '--destination-port', '5500:5555']



# Generated at 2022-06-23 03:54:24.885945
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, 'True', 'match')
    assert rule == ['-m', 'match']
    rule = []
    append_match(rule, 'False', 'match')
    assert rule == []



# Generated at 2022-06-23 03:54:25.587573
# Unit test for function remove_rule
def test_remove_rule():
    pass



# Generated at 2022-06-23 03:54:27.418957
# Unit test for function insert_rule
def test_insert_rule():
    assert(insert_rule('iptables', 0, 0) == 0)



# Generated at 2022-06-23 03:54:38.317366
# Unit test for function construct_rule
def test_construct_rule():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-23 03:54:41.475258
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'policy': 'DROP'}) == 'DROP'



# Generated at 2022-06-23 03:54:44.118832
# Unit test for function main
def test_main():
    assert 'ACCEPT' in POLICIES



# Generated at 2022-06-23 03:54:51.960380
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    import re
    module = AnsibleModule(argument_spec=dict())
    assert re.match(r'\d+\.\d+\.\d+', get_iptables_version('iptables', module))
    assert re.match(r'\d+\.\d+\.\d+', get_iptables_version('ip6tables', module))



# Generated at 2022-06-23 03:54:57.750088
# Unit test for function main

# Generated at 2022-06-23 03:55:11.164316
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        source='localhost',
        protocol='tcp',
        destination_port='22',
        comment='SSH'
    )
    assert (push_arguments('iptables', '-A', params) ==
            [
                'iptables',
                '-t',
                'filter',
                '-A',
                'INPUT',
                '-s',
                'localhost',
                '-p',
                'tcp',
                '--dport',
                '22',
                '-m',
                'comment',
                '--comment',
                'SSH'
            ]
            )

# Generated at 2022-06-23 03:55:20.004743
# Unit test for function get_iptables_version
def test_get_iptables_version():
    out = '''
iptables v1.4.21
'''
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = lambda *_, **__: (0, out, None)
    assert get_iptables_version('/sbin/iptables', module) == '1.4.21'



# Generated at 2022-06-23 03:55:22.385693
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert LooseVersion('1.6.0') == LooseVersion(get_iptables_version('iptables', module))



# Generated at 2022-06-23 03:55:26.296982
# Unit test for function check_present
def test_check_present():
    import sys
    import os

    test_chain = "FORWARD"
    test_table = "filter"
    test_protocol = "tcp"
    test_destination_port = "22"
    test_ctstate = ["NEW"]
    test_syn = "match"
    test_jump = "ACCEPT"
    test_comment = "Accept new SSH connections."

    test_parameters = dict(chain = test_chain, table = test_table, protocol = test_protocol, destination_port = test_destination_port, ctstate = test_ctstate, syn = test_syn, jump = test_jump, comment = test_comment)

    print (check_present("/sbin/iptables", None, test_parameters))


# Generated at 2022-06-23 03:55:29.438103
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule,{'flags':'SYN','flags_set':'ACK'}, '--tcp-flags')
    assert rule == ['--tcp-flags','SYN','ACK']


# Generated at 2022-06-23 03:55:37.175105
# Unit test for function set_chain_policy
def test_set_chain_policy():
    xtables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={
        'table': {'type': 'str', 'required': True},
        'chain': {'type': 'str', 'required': True},
        'policy': {'type': 'str', 'required': True}
        })
    class AnsibleRunCommand(object):
        def __init__(self, module):
            self.module = module
            self._module_name = os.path.basename(module._name)
            self.set_common = True
            self.user = None
            self.prefix = ''

        def run_command(self, cmd, check_rc=False):
            cmd = ['/bin/true']
            args = shlex.split(' '.join(cmd))
            p = subprocess.P

# Generated at 2022-06-23 03:55:41.840437
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ["23/tcp", "80/udp"], '-p')
    assert rule == ['-p', '23/tcp,80/udp']
    rule = []
    append_csv(rule, [], '-p')
    assert rule == []



# Generated at 2022-06-23 03:55:53.028719
# Unit test for function get_chain_policy

# Generated at 2022-06-23 03:55:54.151006
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(None, None) == '1.6.1'



# Generated at 2022-06-23 03:55:57.861598
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", None, dict(table='filter', chain="INPUT", policy="ACCEPT",)) == "ACCEPT"



# Generated at 2022-06-23 03:56:01.354285
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        chain='INPUT',
        policy='DROP',
        table='filter',
    )
    assert set_chain_policy('/sbin/iptables', 'module', params)



# Generated at 2022-06-23 03:56:06.604341
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_rule = []
    test_param = dict(flags=["ALL"], flags_set=["ACK", "RST", "SYN", "FIN"])
    append_tcp_flags(test_rule, test_param, '--tcp-flags')
    assert test_rule == ['--tcp-flags', "ALL", "ACK,RST,SYN,FIN"]



# Generated at 2022-06-23 03:56:19.985668
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/some/iptables/path'
    check_rc = False
    rule_num = '3'
    table = 'nat'
    chain = 'OUTPUT'
    ip_version = 'ipv4'
    source = '1.1.1.1'
    destination = '2.2.2.2'
    in_interface = 'eth0'
    out_interface = 'eth1'
    jump = 'ACCEPT'

# Generated at 2022-06-23 03:56:23.252609
# Unit test for function append_jump
def test_append_jump():
    test_cases = [["", "", ""],
                  ["", "", "DROP"]]
    for param, jump, expected in test_cases:
        rule = []
        append_jump(rule, param, jump)
        assert rule == expected
    return None



# Generated at 2022-06-23 03:56:24.889837
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:56:35.937905
# Unit test for function flush_table
def test_flush_table():
    command_output = u'Jan 22 21:03:10 localhost kernel: [0.000000] Command line:'
    mock_module = MockModule(command_output)
    mock_module.run_command = Mock(return_value=[0,'','',''])
    flush_table('/sbin/iptables',mock_module,{'chain':'INPUT','flush':True,'ip_version':'ipv4'})

# Generated at 2022-06-23 03:56:40.299824
# Unit test for function append_match_flag
def test_append_match_flag():
    list = []
    append_match_flag(list, 'match', "flag", True)
    assert list == ["flag"]
    list = []
    append_match_flag(list, 'negate', "flag", True)
    assert list == ["!", "flag"]



# Generated at 2022-06-23 03:56:43.315787
# Unit test for function append_wait
def test_append_wait():
    rule = ['/sbin/iptables', '-I', 'INPUT', '1']
    param = '10'
    flag = '-w'
    append_wait(rule, param, flag)
    assert rule == ['/sbin/iptables', '-I', 'INPUT', '1', '-w', '10']


# Generated at 2022-06-23 03:56:52.507218
# Unit test for function append_match_flag
def test_append_match_flag():
    rule  = []
    append_match_flag(rule, 'match', 'test', False)
    assert rule == ['test']
    append_match_flag(rule, 'match', 'test', True)
    assert rule == ['test']
    append_match_flag(rule, 'negate', 'test', True)
    assert rule == ['test', '!', 'test']
    append_match_flag(rule, 'negate', 'test', False)
    assert rule == ['test', '!', 'test']
    append_match_flag(rule, '', 'test', True)
    assert rule == ['test', '!', 'test']
    append_match_flag(rule, 'match', 'test', False)
    assert rule == ['test', '!', 'test', 'test']

# Generated at 2022-06-23 03:57:02.071872
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'admin', '--uid-owner', False)
    assert rule == ['--uid-owner', 'admin']
    rule = []
    append_param(rule, ['admin', 'root'], '--uid-owner', True)
    assert rule == ['--uid-owner', 'admin', '--uid-owner', 'root']
    rule = []
    append_param(rule, ['!admin', 'root'], '--uid-owner', True)
    assert rule == ['!', '--uid-owner', 'admin', '--uid-owner', 'root']



# Generated at 2022-06-23 03:57:08.145670
# Unit test for function push_arguments
def test_push_arguments():
    params = {
        'table': 'nat',
        'chain': 'PREROUTING',
        'protocol': 'tcp',
        'jump': 'REDIRECT',
        'to_ports': '8600',
    }
    assert push_arguments('iptables', '-A', params) == [
        'iptables', '-t', 'nat', '-A', 'PREROUTING',
        '-p', 'tcp', '-j', 'REDIRECT', '--to-ports', '8600'
    ]



# Generated at 2022-06-23 03:57:13.410888
# Unit test for function append_wait
def test_append_wait():
    test_rule = []
    append_wait(test_rule, 'test', '--wait')
    assert test_rule == ['--wait', 'test']
    append_wait(test_rule, None, '--wait')
    assert test_rule == ['--wait', 'test']



# Generated at 2022-06-23 03:57:25.259839
# Unit test for function push_arguments

# Generated at 2022-06-23 03:57:36.503675
# Unit test for function main

# Generated at 2022-06-23 03:57:42.371361
# Unit test for function flush_table
def test_flush_table():
    params = dict(
        chain='INPUT',
        table='mangle',
        flush=True,
        ip_version='ipv4',
    )
    iptables_path = 'iptables'
    cmd = push_arguments(iptables_path, '-F', params, make_rule=False)
    assert cmd == [iptables_path, '-t', 'mangle', '-F', 'INPUT']



# Generated at 2022-06-23 03:57:52.673474
# Unit test for function push_arguments
def test_push_arguments():
    test_param = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        to_destination='anywhere',
        destination='10.0.0.0/24',
        source='10.0.0.0/24',
        protocol='tcp',
        wait='2',
    )
    expected_cmd = [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-w', '2',
        '-s', '10.0.0.0/24',
        '-d', '10.0.0.0/24',
        '--to-destination', 'anywhere',
        '-p', 'tcp'
    ]

# Generated at 2022-06-23 03:57:58.944565
# Unit test for function append_jump
def test_append_jump():
    rule = ['iptables', '-I', 'INPUT', '1']
    append_jump(rule, 'ACCEPT', 'ACCEPT')
    
    expected_rule = ['iptables', '-I', 'INPUT', '1', '-j', 'ACCEPT']
    assert rule == expected_rule
    print("Success: append_jump returns correct rule list")
