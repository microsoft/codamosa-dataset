

# Generated at 2022-06-23 03:48:00.653086
# Unit test for function remove_rule
def test_remove_rule():
    ansible_module = MockAnsibleModuleArgs(ip_version='ipv4', chain='INPUT',
                table='filter', jump='DROP', state='absent')
    remove_rule('iptables', ansible_module, ansible_module.params)
    assert ansible_module.run_command_called
    assert ansible_module.run_command_kwargs['check_rc']



# Generated at 2022-06-23 03:48:12.050622
# Unit test for function main
def test_main():
    module = AnsibleModule({
        "table": "filter",
        "state": "present",
        "action": "insert",
        "ip_version": "ipv4",
        "chain": "INPUT",
        "rule_num": "1",
        "protocol": "tcp",
        "source": "8.8.8.0/24",
        "destination": "192.168.0.0/24",
        "match": ["multiport" , "tcp"],
        "destination_ports": [ "22", "80" , "443" ],
        "jump": "ACCEPT",
        "comment": "test comment",
    })
    main()

main()

# Generated at 2022-06-23 03:48:14.414356
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']


# Generated at 2022-06-23 03:48:23.666479
# Unit test for function set_chain_policy
def test_set_chain_policy():
    import os
    os.system("iptables -P INPUT ACCEPT")
    iptables_path = '/sbin/iptables'
    chain = 'INPUT'
    policy = 'DROP'
    params = dict(
            chain = chain,
            policy = policy,
            )
    try:
        set_chain_policy(iptables_path, module, params)
        assert check_present(iptables_path, module, params) == True
        assert remove_rule(iptables_path, module, params) == None
    except AssertionError:
        pass
    finally:
        os.system("iptables -P INPUT ACCEPT")


# Generated at 2022-06-23 03:48:25.679312
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['foo', 'bar'], 'test')
    assert 'test' in rule
    assert 'foo,bar' in rule



# Generated at 2022-06-23 03:48:33.219781
# Unit test for function get_chain_policy
def test_get_chain_policy():
    class Module:
        def run_command(self, command, check_rc):
            return 0, "Chain INPUT (policy ACCEPT)\nChain FORWARD (policy ACCEPT)\n", None
    module = Module()
    assert get_chain_policy('iptables', module, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-23 03:48:40.152230
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = "/sbin/iptables"
    module = AnsibleModule({})
    params = {
        'chain': 'INPUT',
        'policy': 'DROP',
    }
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert(cmd == ["/sbin/iptables", "-t", "filter", "-P", "INPUT", "DROP"])



# Generated at 2022-06-23 03:48:43.346708
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, dict(chain='INPUT', table='filter', ctstate='ESTABLISHED,RELATED,NEW', match=['conntrack'], ip_version='ipv4', jump='ACCEPT')) == True


# Generated at 2022-06-23 03:48:56.955801
# Unit test for function push_arguments
def test_push_arguments():
    params = {
        'chain' : 'INPUT',
        'table': 'filter',
        'ip_version': 'ipv4',
        'jump': None
    }
    cmd = push_arguments('/usr/sbin/iptables', '-I', params, True)
    assert cmd[0] == '/usr/sbin/iptables'
    assert cmd[1] == '-t'
    assert cmd[2] == 'filter'
    assert cmd[3] == '-I'
    assert cmd[4] == 'INPUT'
    assert cmd[5] == '-j'
    assert cmd[6] == 'REJECT'

# Generated at 2022-06-23 03:49:03.141157
# Unit test for function append_match_flag
def test_append_match_flag():

    x = []

    append_match_flag(x, 'match', '--syn', True)
    assert x == ['--syn']
    append_match_flag(x, 'negate', '--syn', True)
    assert x == ['--syn', '!', '--syn']
    append_match_flag(x, 'match', '-m', True)
    assert x == ['--syn', '!', '--syn', '-m']


# Generated at 2022-06-23 03:49:09.273956
# Unit test for function check_present

# Generated at 2022-06-23 03:49:16.207956
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    tcp_flags = dict(
        flags='ACK,RST,SYN,FIN',
        flags_set='ACK,SYN',
    )
    append_tcp_flags(rule, tcp_flags, '-m tcp')
    assert rule == ['-m', 'tcp', '-m', 'tcp', 'ACK,RST,SYN,FIN', 'ACK,SYN']



# Generated at 2022-06-23 03:49:22.639282
# Unit test for function construct_rule

# Generated at 2022-06-23 03:49:24.591754
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module=AnsibleModule({'chain':'INPUT', 'table':'filter', 'params':'policy', 'policy':'DROP'})
    assert set_chain_policy('iptables', module, {'chain':'INPUT', 'table':'filter', 'params':'policy', 'policy':'DROP'})==None



# Generated at 2022-06-23 03:49:28.142040
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        policy='ACCEPT',
    )
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    assert cmd == ['iptables', '-t', params['table'], '-P', params['chain'], params['policy']]


# Generated at 2022-06-23 03:49:35.262056
# Unit test for function insert_rule
def test_insert_rule():
    cmd = push_arguments('iptables', '-I', ['-w', '60', '-p', 'tcp', '-s', '91.226.212.0/24', '-d', '80.241.219.143', '-j', 'DROP'])
    print(cmd)
    return cmd


# Generated at 2022-06-23 03:49:39.803178
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    assert append_tcp_flags([], {'flags': ['RST'], 'flags_set': ['ACK', 'RST']}, '-m tcp --tcp-flags') == ['-m tcp --tcp-flags', 'RST', 'ACK,RST']
    assert append_tcp_flags([], {'flags': ['RST'], 'flags_set': []}, '-m tcp --tcp-flags') == ['-m tcp --tcp-flags', 'RST']
    assert append_tcp_flags([], {'flags': ['RST'], 'flags_set': None}, '-m tcp --tcp-flags') == ['-m tcp --tcp-flags']
    assert append_tcp_flags([], {'flags': None, 'flags_set': None}, '-m tcp --tcp-flags') == []

# Generated at 2022-06-23 03:49:49.934046
# Unit test for function get_chain_policy
def test_get_chain_policy():
    expected = 'ACCEPT'
    # ipv4
    iptables_path = BINS['ipv4']
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        table='filter',
        policy=None,
    )
    assert get_chain_policy(iptables_path, AnsibleModule(argument_spec={}), params) == expected
    # ipv6
    iptables_path = BINS['ipv6']
    params = dict(
        ip_version='ipv6',
        chain='INPUT',
        table='filter',
        policy=None,
    )
    assert get_chain_policy(iptables_path, AnsibleModule(argument_spec={}), params) == expected



# Generated at 2022-06-23 03:49:54.270099
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/bin/iptables'
    table = 'filter'
    chain = 'INPUT'
    policy = 'DROP'
    params = [iptables_path, table, chain, policy]
    return params
# End unit test



# Generated at 2022-06-23 03:49:59.280341
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/sbin/iptables'
    action = '-F'
    params = dict(
        table='filter',
        chain='INPUT',
        flush=True,
        ip_version='ipv4',
        )
    cmd = push_arguments(iptables_path, action, params, make_rule=False)
    assert(cmd==['/sbin/iptables', '-t', 'filter', '-F', 'INPUT'])



# Generated at 2022-06-23 03:50:12.033518
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-23 03:50:18.090379
# Unit test for function append_jump
def test_append_jump():

    # Check if it only appends the -j if there is a parameter given
    # Create a list to append to
    rule = []
    # Parameter given
    param = 'ACCEPT'
    # Jump given
    jump = 'ACCEPT'
    # Call the function
    append_jump(rule, param, jump)
    # Check if the rule has the "correct" length
    assert len(rule) == 2
    # Check if the rule is the expected rule
    assert rule[0] == '-j'
    assert rule[1] == 'ACCEPT'

    # Check if it doesn't append when there is no parameter given
    # Create a list to append to
    rule = []
    # Parameter None
    param = None
    # Jump given
    jump = 'ACCEPT'
    # Call the function

# Generated at 2022-06-23 03:50:23.105720
# Unit test for function insert_rule

# Generated at 2022-06-23 03:50:33.500093
# Unit test for function remove_rule
def test_remove_rule():
    # Test 1
    module = MockModule()
    module.run_command = mock_run_command
    module.run_command.return_value = 0, '', ''
    ipv4_path = '/sbin/iptables'
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        source='192.168.1.100',
        destination='192.168.1.200',
        match='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        to_destination='192.168.1.200',
        state='absent'
        )
    remove_rule(ipv4_path, module, params)

    # Test 2
    module = MockModule()

# Generated at 2022-06-23 03:50:35.756281
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(iptables_path, module, params) == 1


# Generated at 2022-06-23 03:50:40.932840
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(
        argument_spec=dict(
            command=dict(type='str', required=True),
            table=dict(type='str', required=True),
            chain=dict(type='str'),
        ),
    )
    flush_table('iptables', module,
              {'command': 'flush', 'chain': 'INPUT', 'table': 'filter'})



# Generated at 2022-06-23 03:50:47.489497
# Unit test for function flush_table
def test_flush_table():
    xtables_lock_path = '/usr/libexec/xtables.lock'
    iptables_path = '/usr/sbin/iptables'
    table_name = 'filter'
    chain_name = 'filter'
    flush_table(iptables_path, module, {'table': table_name, 'chain': chain_name})


# Generated at 2022-06-23 03:50:51.930430
# Unit test for function append_match
def test_append_match():
    
    rule1 = []
    rule2 = []

    append_match(rule1,True,'test')
    append_match(rule2,False,'test')
    
    if (rule1 != ['-m', 'test']) or (rule2 != []):
        return False
    else:
        return True


# Generated at 2022-06-23 03:50:58.810781
# Unit test for function main
def test_main():
    for ip_version in ['ipv4', 'ipv6']:
        iptables_path = module.get_bin_path(BINS[ip_version], True)

# Generated at 2022-06-23 03:51:03.473941
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags = ['ACK', 'RST', 'SYN', 'FIN'],
        flags_set = ['ACK', 'RST', 'SYN', 'FIN']
        )
    flag = '--tcp-flags'
    return append_tcp_flags(rule, param, flag)



# Generated at 2022-06-23 03:51:12.793559
# Unit test for function insert_rule
def test_insert_rule():
    params = \
        {"chain": "INPUT", "protocol": "tcp", "destination_port": "8080", "jump": "ACCEPT", "action": "insert",
        "rule_num": 5}
    insert_rule("iptables", module, params)
    assert params == {"chain": "INPUT", "protocol": "tcp", "destination_port": "8080", "jump": "ACCEPT", "action": "insert",
        "rule_num": 5}


# Generated at 2022-06-23 03:51:18.818649
# Unit test for function get_iptables_version
def test_get_iptables_version():
    # given
    module = mock.MagicMock()
    module.run_command.return_value = (0, 'IPTables v1.6.1', '')
    # expect
    assert get_iptables_version("/usr/bin/iptables", module) == '1.6.1'



# Generated at 2022-06-23 03:51:27.306524
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, None, 'param', False)
    assert(rule) == []

    rule = []
    append_param(rule, '', 'param', False)
    assert(rule) == []

    rule = []
    append_param(rule, 'value', '', False)
    assert(rule) == []

    rule = []
    append_param(rule, 'value', 'param', False)
    assert(rule) == ['param', 'value']

    rule = []
    append_param(rule, '!value', 'param', False)
    assert(rule) == ['!', 'param', 'value']

    rule = []
    append_param(rule, ['value1', '!value2'], 'param', True)

# Generated at 2022-06-23 03:51:39.440530
# Unit test for function append_rule
def test_append_rule():
    class exeception_mgr():
        def __enter__(self):
            self.test_params = {
                'table': 'filter',
                'chain': 'INPUT',
                'protocol': 'tcp',
                'destination_port': None,
                'jump': 'ACCEPT',
                'wait': None,
                'comment': 'my_comment'
            }
            self.module = AnsibleModule
            self.module.run_command = MagicMock(return_value=0)

        def __exit__(self, exc_type, exc_value, exc_traceback):
            pass

    with exeception_mgr() as emgr:
        emgr.iptables_path = '/usr/bin/iptables'

# Generated at 2022-06-23 03:51:46.183865
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='OUTPUT',
        ip_version='ipv4',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    rule = construct_rule(params)
    assert rule == [
        '-p',
        'tcp',
        '--dport',
        '22',
        '-m',
        'conntrack',
        '--ctstate',
        'NEW',
        '--syn',
        '-j',
        'ACCEPT',
        '-m',
        'comment',
        '--comment',
        'Accept new SSH connections.',
    ]



# Generated at 2022-06-23 03:51:49.055164
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/usr/sbin/iptables'
    dummy_mod = type('DummyModule', (object,), {'run_command': False})()
    params = dict(
        table="filter", chain="INPUT", policy="DROP",
    )
    expected_command = '/usr/sbin/iptables -t filter -P INPUT DROP'
    actual_command = set_chain_policy(iptables_path, dummy_mod, params)
    assert actual_command == expected_command



# Generated at 2022-06-23 03:51:50.687621
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', None, {'table': 'filter', 'chain':'INPUT', 'policy':'DROP'}) == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']


# Generated at 2022-06-23 03:51:55.044957
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {"flags": ["ACK", "SYN", "FIN", "RST"], "flags_set": ["ACK", "SYN"]}
    append_tcp_flags(rule, param, "-m tcp --tcp-flags")
    assert rule == ['-m', 'tcp', '--tcp-flags', 'ACK,SYN,FIN,RST', 'ACK,SYN']



# Generated at 2022-06-23 03:52:02.498921
# Unit test for function main

# Generated at 2022-06-23 03:52:08.387973
# Unit test for function remove_rule
def test_remove_rule():
    remove_rule('iptables', {}, {'ip_version': 'ipv4', 'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '80', 'jump': 'ACCEPT', 'action': 'remove', 'state': 'present', 'comment': None})


# Generated at 2022-06-23 03:52:15.716125
# Unit test for function check_present
def test_check_present():
    mock_module = AnsibleModule({})
    mock_module.run_command = lambda *args, **kwargs: (0, "", "")

# Generated at 2022-06-23 03:52:20.272870
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'SYN'])
    append_tcp_flags(rule, param, ' --tcp-flags')
    assert rule == [' --tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,SYN']


# Generated at 2022-06-23 03:52:28.914500
# Unit test for function append_param
def test_append_param():
    assert append_param([], 'foo', '-j', False) == ['-j', 'foo']
    assert append_param([], 'bar', '-j', False) == ['-j', 'bar']
    assert append_param([], '!', '-j', False) == ['!', '-j']
    assert append_param([], '!bar', '-j', False) == ['!', '-j', 'bar']



# Generated at 2022-06-23 03:52:34.948733
# Unit test for function push_arguments
def test_push_arguments():
    module = AnsibleModule(argument_spec={})
    args = dict(
        chain='INPUT',
        ip_version='ipv4',
        source='198.51.100.0/25',
        jump='ACCEPT',
        )
    cmd = push_arguments('iptables', '-A', args, True)
    assert cmd == ['iptables', '-t', 'filter', '-A', 'INPUT', '-s', '198.51.100.0/25', '-j', 'ACCEPT']



# Generated at 2022-06-23 03:52:44.534146
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        policy='DROP',
        flush=False,
    )
    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda params, check_rc=True: (0, 'v1.2.3', None)
    version = get_iptables_version(module, params)
    assert version == '1.2.3'


# Generated at 2022-06-23 03:52:47.857235
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(
        argument_spec=dict(
            table=dict(default='filter', choices=['filter', 'mangle', 'nat', 'raw', 'security']),
            chain=dict(default='INPUT'),
            ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
        ),
        supports_check_mode=False,
    )
    flush_table('iptables', module, module.params)
    # ..assert something



# Generated at 2022-06-23 03:52:56.149349
# Unit test for function flush_table
def test_flush_table():
    command = 'iptables -F INPUT'
    my_module = AnsibleModule(argument_spec=dict())
    flush_table('iptables', my_module, dict(table='filter', chain='INPUT', ip_version='ipv4'))
    args, _ = my_module.run_command.call_args
    assert args[0] == command.split()



# Generated at 2022-06-23 03:53:06.045141
# Unit test for function set_chain_policy

# Generated at 2022-06-23 03:53:07.139999
# Unit test for function flush_table
def test_flush_table():
    assert flush_table('iptables', module, params)



# Generated at 2022-06-23 03:53:11.369478
# Unit test for function append_rule
def test_append_rule():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text

    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = Mock()

        def run_command(self, cmd):
            # For the sake of the test, we'll just check the last item in the command
            # to see if it's the expected iptables rule.
            if PY3:
                last_item = cmd[-1]
            else:
                last_item = cmd[-1].encode('utf-8')

# Generated at 2022-06-23 03:53:18.157567
# Unit test for function check_present
def test_check_present():
    test_params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': 22
    }
    cmd = push_arguments('iptables', '-C', test_params)
    assert cmd == ['iptables', '-t', 'filter', '-C', 'INPUT', '-p', 'tcp', '--dport', '22']
    return


# Generated at 2022-06-23 03:53:31.465033
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    flag = '--some_flag'
    negatable = True
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['--some_flag']
    rule = []
    param = 'negate'
    flag = '--some_flag'
    negatable = True
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['!', '--some_flag']
    rule = []
    param = 'somethingelse'
    flag = '--some_flag'
    negatable = True
    append_match_flag(rule, param, flag, negatable)
    assert rule == []
    rule = []
    param = 'somethingelse'
    flag = '--some_flag'
    negatable = False
    append

# Generated at 2022-06-23 03:53:41.495122
# Unit test for function push_arguments
def test_push_arguments():
    args = dict(
        action='-A',
        chain='INPUT',
        comment='Ansible iptables module test rule',
        destination='127.0.0.1',
        destination_port='80',
        jump='ACCEPT',
        limit='1',
        limit_burst='2',
        log_level='info',
        log_prefix='IPTABLES:INFO: ',
        match=['tcp'],
        protocol='tcp',
        rule_num=None,
        source='192.168.0.1',
        source_port='8080',
        table='filter',
    )
    cmd = push_arguments('iptables', args['action'], args)

# Generated at 2022-06-23 03:53:45.634997
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['test','test2','test3']
    flag = '--test'
    append_csv(rule, param, flag)
    assert(rule) == ['--test','test,test2,test3']



# Generated at 2022-06-23 03:53:57.464715
# Unit test for function append_param
def test_append_param():
    rule = []
    param = 'foo'
    flag = '-f'
    is_list = False
    expected = ['-f', 'foo']

    append_param(rule, param, flag, is_list)
    assert rule == expected

    rule = []
    param = '!foo'
    flag = '-f'
    is_list = False
    expected = ['!', '-f', 'foo']

    append_param(rule, param, flag, is_list)
    assert rule == expected

    rule = []
    param = ['foo', 'bar']
    flag = '-f'
    is_list = True
    expected = ['-f', 'foo', '-f', 'bar']

    append_param(rule, param, flag, is_list)
    assert rule == expected

    rule = []


# Generated at 2022-06-23 03:54:02.989428
# Unit test for function append_param
def test_append_param():
    rule = []
    test = ['80', '81', '82']
    append_param(rule, test, '--dport', True)
    assert rule == ['--dport', '80', '--dport', '81', '--dport', '82']
    rule = []
    append_param(rule, test, '!', True)
    assert rule == ['!', '!', '80', '!', '!', '81', '!', '!', '82']



# Generated at 2022-06-23 03:54:12.045289
# Unit test for function push_arguments

# Generated at 2022-06-23 03:54:15.450339
# Unit test for function remove_rule
def test_remove_rule():
  assert remove_rule(iptables_path, module, params) == ['/sbin/iptables', '-t', 'filter', '-D', 'INPUT', '-s', '1.1.1.1', '-j', 'ACCEPT']


# Generated at 2022-06-23 03:54:20.571871
# Unit test for function append_csv
def test_append_csv():
    sample = dict(
        rule = [],
        param = ['test1', 'test2'],
        flag = '--test'
    )
    append_csv(sample['rule'], sample['param'], sample['flag'])
    assert ','.join(sample['param']) in sample['rule']



# Generated at 2022-06-23 03:54:27.530221
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_rule = []
    test_params = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK']
    )
    append_tcp_flags(test_rule, test_params, '--tcp-flags')
    test_rule.extend(['--tcp-flags', ','.join(test_params['flags']), ','.join(test_params['flags_set'])])
    assert test_rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK']


# Generated at 2022-06-23 03:54:38.400526
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        chain='FORWARD',
        table='filter',
        source='1.2.3.4',
        match=['match', '!match'],
        source_port='1234',
        protocol='tcp',
        ctstate='NEW',
        syn='match',
        reject_with='reject_with',
        comment=['comment', '!comment'],
        wait='wait',
    )
    assert (
        push_arguments('iptables', '-A', params, False) ==
        ['iptables', '-t', 'filter', '-A', 'FORWARD'])

# Generated at 2022-06-23 03:54:42.340623
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST'], flags_set=['ACK', 'RST'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST', 'ACK,RST']


# Generated at 2022-06-23 03:54:54.889588
# Unit test for function get_chain_policy
def test_get_chain_policy():
    # parameters
    ip_version = 'ipv4'
    table = 'filter'
    chain = 'INPUT'
    policy = 'DROP'
    # mock
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False, bypass_checks=True)
    iptables_path = "iptables"
    module.run_command = Mock(return_value=(0, 'Chain INPUT (policy DROP)', ''))
    # call
    policy_retrieved = get_chain_policy(iptables_path, module, {
        'ip_version': ip_version,
        'table': table,
        'chain': chain,
        'policy': policy,
    })
    # asserts
    assert_equals(policy_retrieved, policy)

# Generated at 2022-06-23 03:54:55.863808
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("", "", "") == None



# Generated at 2022-06-23 03:54:57.141569
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = '2'
    flag = '-w'
    append_wait(rule, param, flag)
    assert rule == ['-w', '2']



# Generated at 2022-06-23 03:55:03.556891
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test_name = 'test_host'
    set_chain_policy(test_name, 'INPUT', 'DROP')
    assert get_chain_policy(test_name, 'INPUT') == 'DROP'



# Generated at 2022-06-23 03:55:14.234022
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test', '--flag', False)
    assert rule == ['--flag', 'test']
    rule = []
    append_param(rule, '!test', '--flag', False)
    assert rule == ['!', '--flag', 'test']
    rule = []
    append_param(rule, ['test', 'test2'], '--flag', True)
    assert rule == ['--flag', 'test', '--flag', 'test2' ]
    rule = []
    append_param(rule, ['!test', '!test2'], '--flag', True)
    assert rule == ['!', '--flag', 'test', '!', '--flag', 'test2' ]


# Generated at 2022-06-23 03:55:21.840739
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'iptables'

# Generated at 2022-06-23 03:55:24.748270
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'params'


# Generated at 2022-06-23 03:55:34.421747
# Unit test for function append_csv
def test_append_csv():
    testlist = [
        {'rule': [], 'param': [], 'flag': '--ctstate', 'expected': []},
        {'rule': [], 'param': ['NEW'], 'flag': '--ctstate', 'expected': ['--ctstate', 'NEW']},
        {'rule': [], 'param': ['NEW', 'ESTABLISHED'], 'flag': '--ctstate', 'expected': ['--ctstate', 'NEW,ESTABLISHED']},
        {'rule': [], 'param': ['NEW', 'ESTABLISHED', 'RELATED'], 'flag': '--ctstate', 'expected': ['--ctstate', 'NEW,ESTABLISHED,RELATED']},
    ]

    for test in testlist:
        append_csv(test['rule'], test['param'], test['flag'])

# Generated at 2022-06-23 03:55:40.623842
# Unit test for function flush_table
def test_flush_table():
    params = dict(table='raw',chain='OUTPUT')
    params['ip_version']='ipv4'
    assert(flush_table('iptables',None,params) == ['iptables','-t', 'raw','-F','OUTPUT'])


# Generated at 2022-06-23 03:55:43.877601
# Unit test for function append_match
def test_append_match():
    assert ["-m", "match"] == append_match([], True, "match")



# Generated at 2022-06-23 03:55:48.080251
# Unit test for function push_arguments
def test_push_arguments():
    result = push_arguments('iptables', '-I', { 'table': 'nat', 'chain': 'PREROUTING', 'rule_num': '1', 'protocol': 'tcp' })
    assert result == ['iptables', '-t', 'nat', '-I', 'PREROUTING', '1', '-p', 'tcp']


# Generated at 2022-06-23 03:55:49.970273
# Unit test for function append_match
def test_append_match():
    assert append_match([], True, 'match') == ['-m', 'match']

# Generated at 2022-06-23 03:56:02.596216
# Unit test for function append_jump
def test_append_jump():
    result = []
    append_jump(result, "ACCEPT", "ACCEPT")
    assert result == ['-j', 'ACCEPT']
    result = []
    append_jump(result, "DROP", "DROP")
    assert result == ['-j', 'DROP']
    result = []
    append_jump(result, "QUEUE", "QUEUE")
    assert result == ['-j', 'QUEUE']
    result = []
    append_jump(result, "RETURN", "RETURN")
    assert result == ['-j', 'RETURN']
    result = []
    append_jump(result, "DNAT", "DNAT")
    assert result == ['-j', 'DNAT']
    result = []
    append_jump(result, "SNAT", "SNAT")

# Generated at 2022-06-23 03:56:16.711342
# Unit test for function main

# Generated at 2022-06-23 03:56:24.389203
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule(dict(ip_version='ipv4')) == []
    assert construct_rule(dict(
        ip_version='ipv4', protocol='tcp',
        jump=None)) == ['-p', 'tcp', '-j', 'REJECT']
    assert construct_rule(dict(
        ip_version='ipv4', protocol='tcp',
        source_port=80, jump=None)) == ['--protocol-match', 'tcp', '--dport', '80', '-j', 'REJECT']
    assert construct_rule(dict(
        ip_version='ipv4', protocol='tcp',
        source_port=80, jump='ACCEPT')) == ['--protocol-match', 'tcp', '--dport', '80', '-j', 'ACCEPT']

# Generated at 2022-06-23 03:56:25.744410
# Unit test for function flush_table
def test_flush_table():
    result = flush_table('/usr/sbin/iptables',None,{'table':'raw'})
    assert result == 0


# Generated at 2022-06-23 03:56:28.268332
# Unit test for function append_wait
def test_append_wait():
    rule = []
    wait = '20'
    flag = '--wait'
    append_wait(rule, wait, flag)
    assert rule == [flag, wait]



# Generated at 2022-06-23 03:56:39.968752
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-23 03:56:42.142286
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert_equal(get_iptables_version('./iptables', None), '1.4.20')


# Generated at 2022-06-23 03:56:48.641335
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['testparam1', 'testparam2', 'testparam3']
    flag = '--testflag'
    append_csv(rule, param, flag)
    assert rule == ['--testflag', 'testparam1,testparam2,testparam3'], \
        "csv param is not set properly"



# Generated at 2022-06-23 03:56:51.281313
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = object()
    module.run_command = lambda cmd, check_rc: (0, 'v1.4.21', None)
    assert '1.4.21' == get_iptables_version('/sbin/iptables', module)



# Generated at 2022-06-23 03:56:56.274135
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({})
    version = get_iptables_version('/bin/true', module)
    assert version == ''
    version = get_iptables_version('/bin/echo', module)
    assert version == '1.4.21'



# Generated at 2022-06-23 03:56:59.912952
# Unit test for function append_jump
def test_append_jump():
    test_rule = []
    append_jump(test_rule, 'test_param', 'test_jump')
    assert test_rule == ['-j', 'test_jump']


# Generated at 2022-06-23 03:57:00.785202
# Unit test for function append_match
def test_append_match():
    output=append_match([], True, 'test')
    assert output == ['-m', 'test']



# Generated at 2022-06-23 03:57:09.729229
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = ['-i', 'lo', '-p', 'all', '-m', 'comment', '--comment', 'test comment']
    append_match_flag(rule, 'match', '-m', True)
    assert rule == ['-i', 'lo', '-p', 'all', '-m', 'comment', '--comment', 'test comment', '-m']
    append_match_flag(rule, 'negate', '-m', True)
    assert rule == ['-i', 'lo', '-p', 'all', '-m', 'comment', '--comment', 'test comment', '-m', '!', '-m']
    append_match_flag(rule, 'match', '-m', False)

# Generated at 2022-06-23 03:57:20.639170
# Unit test for function append_rule

# Generated at 2022-06-23 03:57:24.589578
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(['iptables'], 'match', '--syn', True) == ['iptables', '--syn']
    assert append_match_flag(['iptables'], 'negate', '--syn', True) == ['iptables', '!', '--syn']
    assert append_match_flag(['iptables'], 'match', '--syn', False) == ['iptables', '--syn']



# Generated at 2022-06-23 03:57:27.817779
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, param=None, jump='jump')
    assert rule == []

    rule = []
    append_jump(rule, param='Foobar', jump='jump')
    assert rule == ['-j', 'Foobar']



# Generated at 2022-06-23 03:57:28.948184
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', params) is True


# Generated at 2022-06-23 03:57:34.308422
# Unit test for function insert_rule
def test_insert_rule():
    insert_rule("/usr/bin/iptables", AnsibleModule(argument_spec=dict()), {"table":"nat", "chain":"test", "rule_num":"1"})
    insert_rule("/usr/bin/iptables", AnsibleModule(argument_spec=dict()), {"table":"nat", "chain":"test", "rule_num":"2"})
    insert_rule("/usr/bin/iptables", AnsibleModule(argument_spec=dict()), {"table":"nat", "chain":"test", "rule_num":"1"})
    insert_rule("/usr/bin/iptables", AnsibleModule(argument_spec=dict()), {"table":"nat", "chain":"test", "rule_num":"3"})

# Generated at 2022-06-23 03:57:36.274603
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = '10'
    flag = '-w'
    append_wait(rule, param, flag)
    assert(rule == ['-w', '10'])


# Generated at 2022-06-23 03:57:40.884536
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(
        argument_spec=dict(
            table='nat',
            chain='POSTROUTING',

        ),
    )
    params = module.params.copy()
    iptables_path = '/usr/sbin/iptables'
    flush_table(iptables_path, module, params)
    


# Generated at 2022-06-23 03:57:48.010133
# Unit test for function append_csv
def test_append_csv():
    param = ['a', 'b', 'c', 'd']
    rule = []
    flag = '--flag'
    append_csv(rule, param, flag)
    assert rule == ['--flag', 'a,b,c,d']
    rule = []
    param = []
    append_csv(rule, param, flag)
    assert rule == []


# Generated at 2022-06-23 03:57:51.423744
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, "DROP", "DROP")
    assert rule == ['-j', 'DROP']


# Generated at 2022-06-23 03:57:54.163388
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(BINS['ipv4'], None) == '1.6.2'

