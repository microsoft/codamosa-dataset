

# Generated at 2022-06-23 03:47:56.736270
# Unit test for function append_jump
def test_append_jump():
    assert append_jump([ ], 'ACCEPT', 'ACCEPT') == ['-j', 'ACCEPT']
    assert append_jump([ ], None, 'ACCEPT') == [ ]


# Generated at 2022-06-23 03:48:01.007612
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = "/sbin/iptables"
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4',
        policy='ACCEPT',
    )
    set_chain_policy(iptables_path, module, params)
# End of unit test



# Generated at 2022-06-23 03:48:01.550750
# Unit test for function append_rule
def test_append_rule():
    return True


# Generated at 2022-06-23 03:48:06.863746
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule()
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'comment': 'Redirect web traffic to port 8600',
    }
    result = check_present(
        BINS['ipv4'],
        module,
        params)
    assert result is True
# End of unit test



# Generated at 2022-06-23 03:48:10.136254
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables',None,{
        'chain'     : 'INPUT'
    }) == 'DROP'
# Unit test end



# Generated at 2022-06-23 03:48:19.325811
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = param = dict(flags=['ALL'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']
    rule = []
    param = dict(flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == []


# Generated at 2022-06-23 03:48:23.929187
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['a','b','c'],'--abc')
    assert rule == ['--abc','a,b,c']


# Generated at 2022-06-23 03:48:35.150485
# Unit test for function main

# Generated at 2022-06-23 03:48:41.065312
# Unit test for function remove_rule
def test_remove_rule():
    # Arrange
    iptables_path = "/sbin/iptables"
    class module:
        def run_command(cmd, check_rc=True):
            assert cmd == [iptables_path, '-D', 'CHAIN']
            return 0, "", ""
    params = {'chain': 'CHAIN'}
    # Act
    remove_rule(iptables_path, module, params)
    # Assert



# Generated at 2022-06-23 03:48:44.904974
# Unit test for function append_jump
def test_append_jump():
    rule = []
    rule.extend(['-j', 'ACCEPT'])
    assert rule == append_jump(rule, 'ACCEPT', '-j')


# Generated at 2022-06-23 03:48:58.571272
# Unit test for function push_arguments

# Generated at 2022-06-23 03:49:01.346865
# Unit test for function append_match
def test_append_match():
    testrule = []
    append_match(testrule, True, 'match')
    assert testrule == ['-m', 'match']
    append_match(testrule, False, 'match')
    assert testrule == ['-m', 'match']



# Generated at 2022-06-23 03:49:04.668913
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_list = []
    append_tcp_flags(test_list, {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'SYN']}, '--tcp-flags')
    assert test_list == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,SYN']



# Generated at 2022-06-23 03:49:06.396458
# Unit test for function append_csv
def test_append_csv():
    assert append_csv(['iptables'], ['ACCEPT', 'DROP'], '--jump') == \
           ['iptables', '--jump', 'ACCEPT,DROP']



# Generated at 2022-06-23 03:49:11.518202
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, "1", '--wait')
    assert rule == ["--wait", "1"]
    assert append_wait(rule) == None



# Generated at 2022-06-23 03:49:13.646132
# Unit test for function flush_table
def test_flush_table():
    assert flush_table == 'test_iptables_path' 'test_module' 'test_params'



# Generated at 2022-06-23 03:49:16.773631
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['a', 'b']
    flag = '-d'
    rule.extend([flag, ','.join(param)])
    assert rule == ['-d', 'a,b']


# Generated at 2022-06-23 03:49:21.152400
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule(argument_spec=dict())
    major = get_iptables_version('iptables', module).split('.')[0]
    assert major in ('1', '2'), 'Major version should be 1 or 2'



# Generated at 2022-06-23 03:49:25.483597
# Unit test for function construct_rule
def test_construct_rule():
    '''
    Test that construct_rule returns correct rule object
    '''
    input = dict(
        chain="INPUT",
        protocol="tcp",
        destination_port="22",
        ctstate="NEW",
        syn="match",
        jump="ACCEPT",
        ip_version="ipv4",
        comment="Accept new SSH connections.",
    )
    output = ['-p', 'tcp', '--destination-port', '22', '-m', 'conntrack',
              '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT',
              '-m', 'comment', '--comment', 'Accept new SSH connections.']
    assert construct_rule(input) == output



# Generated at 2022-06-23 03:49:33.987992
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'policy': 'ACCEPT', 'chain': 'INPUT'})\
        == 'ACCEPT'
    assert get_chain_policy(None, None, {'policy': 'DROP', 'chain': 'FORWARD'})\
        == 'DROP'
    assert get_chain_policy(None, None, {'policy': 'REJECT', 'chain': 'OUTPUT'})\
        == 'REJECT'



# Generated at 2022-06-23 03:49:37.410880
# Unit test for function set_chain_policy
def test_set_chain_policy():
    print(set_chain_policy('/sbin/iptables',
      AnsibleModule(argument_spec={}), {'table': 'filter', 'chain': 'INPUT', 'policy': 'ACCEPT'}))



# Generated at 2022-06-23 03:49:48.388924
# Unit test for function main
def test_main():
    """
    This is a unit test skeleton for function main
    """
    # Replace these statements

# Generated at 2022-06-23 03:49:56.611826
# Unit test for function get_iptables_version
def test_get_iptables_version():
    test_version = '1.4.20'
    test_object = {
        'version': test_version,
    }

    def mock_run_command(cmd, check_rc):
        assert (cmd==['iptables', '--version'])
        return 0, "Foo v%s" % test_version, ''

    test_module = type('', (), {
        'run_command': mock_run_command,
    })

    result = get_iptables_version("iptables",test_module)
    assert (test_version == result)



# Generated at 2022-06-23 03:49:57.848198
# Unit test for function flush_table
def test_flush_table():
    """
    function test
    """
    pass



# Generated at 2022-06-23 03:50:01.735352
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        action='insert',
        chain='INPUT',
        ip_version='ipv4',
        rule_num=1,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        table='filter'
    )
    cmd = push_arguments('iptables', module, params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '1', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']
# END



# Generated at 2022-06-23 03:50:03.114933
# Unit test for function flush_table
def test_flush_table():
    cmd = flush_table('iptables', 'module', {})
    assert cmd == ['iptables', '-t', 'filter', '-F']



# Generated at 2022-06-23 03:50:06.044377
# Unit test for function check_present
def test_check_present():
    assert True == check_present('iptables','module','params')



# Generated at 2022-06-23 03:50:06.822621
# Unit test for function append_rule
def test_append_rule():
    pass



# Generated at 2022-06-23 03:50:11.762428
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('/sbin/iptables', 'INPUT', 'DROP') == 'DROP'
    assert get_chain_policy('/sbin/iptables', 'INPUT', 'ACCEPT') == 'ACCEPT'


# Generated at 2022-06-23 03:50:15.394523
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(required=True),
        policy=dict(required=True, choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        ip_version=dict(required=False, choices=['ipv4', 'ipv6'], default='ipv4'),
    ))
    set_chain_policy(BINS[module.params['ip_version']], module, module.params)
    assert True



# Generated at 2022-06-23 03:50:22.348882
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', None, {'chain': 'INPUT', 'jump': 'ACCEPT', 'source': '8.8.8.8'})


# Generated at 2022-06-23 03:50:23.915090
# Unit test for function check_present
def test_check_present():
    rc, _, __ = check_present('iptables', 'filter', 'OUTPUT', '-o', 'eth0')
    if rc == 0:
        return True


# Generated at 2022-06-23 03:50:25.113076
# Unit test for function set_chain_policy
def test_set_chain_policy():
    set_chain_policy(None,None,{'policy':'ACCEPT',
        'chain':'INPUT',
        'table':'filter'})


# Generated at 2022-06-23 03:50:37.598518
# Unit test for function flush_table

# Generated at 2022-06-23 03:50:42.887288
# Unit test for function check_present
def test_check_present():
    sys.modules['ansible.module_utils.basic'] = Mock()
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='9090',
        jump='ACCEPT',
        ip_version='ipv4',
    )
    if check_present('iptables', None, params):
        assert True
    else:
        assert False



# Generated at 2022-06-23 03:50:57.982335
# Unit test for function get_chain_policy

# Generated at 2022-06-23 03:51:06.462466
# Unit test for function append_wait
def test_append_wait():
    rule = ['iptables']
    append_wait(rule, '5', '-w')
    assert(rule == ['iptables', '-w', '5'])

# Metaparameters.

# Generated at 2022-06-23 03:51:17.811056
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-23 03:51:30.116061
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, None, '-p', False)
    append_param(rule, None, '-p', True)
    append_param(rule, '', '-p', False)
    append_param(rule, '', '-p', True)
    assert rule == []

    rule = []
    append_param(rule, 'tcp', '-p', False)
    assert rule == ['-p', 'tcp']

    rule = []
    append_param(rule, [], '-p', True)
    assert rule == []

    rule = []
    append_param(rule, ['tcp'], '-p', True)
    assert rule == ['-p', 'tcp']

    rule = []

# Generated at 2022-06-23 03:51:41.569492
# Unit test for function get_iptables_version
def test_get_iptables_version():
    ansible_module = AnsibleModule(
        argument_spec = dict(
            ),
        supports_check_mode = True)
    ansible_module.check_mode = False

    result = {'changed': False}

    ipv4_path = 'iptables'
    ipv6_path = 'ip6tables'

    result['iptables_version_ipv4'] = get_iptables_version(ipv4_path,
        ansible_module)
    result['iptables_version_ipv6'] = get_iptables_version(ipv6_path,
        ansible_module)

    result['msg'] = "Successfully executed get_iptables_version."

    ansible_module.exit_json(**result)



# Generated at 2022-06-23 03:51:44.248641
# Unit test for function append_match
def test_append_match():
    r = []
    append_match(r, True, 'test')
    assert r == ['-m', 'test']
    append_match(r, False, 'test')
    assert r == []



# Generated at 2022-06-23 03:51:54.436570
# Unit test for function insert_rule
def test_insert_rule():
    import ansible.module_utils.basic

# Generated at 2022-06-23 03:51:58.299491
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], 'match', '--syn', True) == ['--syn']
    assert append_match_flag([], 'negate', '--syn', True) == ['!', '--syn']
    assert append_match_flag([], 'negate', '--syn', False) == []



# Generated at 2022-06-23 03:52:00.870308
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        table='filter',
        chain='INPUT',
        policy='DROP'
    )
    set_chain_policy('iptables', None, params)



# Generated at 2022-06-23 03:52:04.121452
# Unit test for function append_rule
def test_append_rule():
    assert(True)

# Generated at 2022-06-23 03:52:11.671485
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, '-k', '--foo', False)
    assert rule == [ '--foo', '-k' ]
    append_param(rule, '!-k', '--foo', False)
    assert rule == [ '--foo', '-k', '!', '--foo', '-k' ]
    append_param(rule, ['-k', '-l'], '--foo', True)
    assert rule == [ '--foo', '-k', '!', '--foo', '-k', '--foo', '-k', '--foo', '-l' ]



# Generated at 2022-06-23 03:52:14.828282
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    params = {}
    params['table'] = 'nat'
    params['chain'] = 'DOCKER'
    params['action'] = 'insert'
    params['rule_num'] = '3'
    insert_rule(iptables_path, 'module', params)
    return



# Generated at 2022-06-23 03:52:23.476427
# Unit test for function append_param
def test_append_param():
    test_rule = []
    append_param(test_rule, 'test', '-i', False)
    assert test_rule == ['-i', 'test']
    test_rule = []
    append_param(test_rule, 'test', '-i', True)
    assert test_rule == ['-i', 'test']
    test_rule = []
    append_param(test_rule, '!test', '-i', False)
    assert test_rule == ['!', '-i', 'test']
    test_rule = []
    append_param(test_rule, ['test1', 'test2', '!test3'], '-i', True)
    assert test_rule == ['-i', 'test1', '-i', 'test2', '!', '-i', 'test3']


# Generated at 2022-06-23 03:52:30.006411
# Unit test for function remove_rule
def test_remove_rule():
    test_param = dict(
        table='filter',
        chain='INPUT',
        source='1.1.1.1',
        jump='DROP',
    )
    remove_rule('/sbin/iptables', None, test_param)
    retrun_list = ['/sbin/iptables', '-t', 'filter', '-D', 'INPUT', '-s', '1.1.1.1', '-j', 'DROP']
    assert(test_param == retrun_list)



# Generated at 2022-06-23 03:52:36.717303
# Unit test for function remove_rule

# Generated at 2022-06-23 03:52:42.750561
# Unit test for function insert_rule
def test_insert_rule():
    params = {'rule_num': '1', 'table': 'filter'}
    cmd = ['iptables', '-t', 'filter', '-I', 'INPUT', '1']
    if params['rule_num']:
        cmd.extend([params['rule_num']])
    assert cmd == push_arguments('iptables', '-I', params)


# Generated at 2022-06-23 03:52:44.206755
# Unit test for function append_rule
def test_append_rule():
    append_rule(iptables_path, module, params)



# Generated at 2022-06-23 03:52:49.148406
# Unit test for function append_tcp_flags
def test_append_tcp_flags():

    # flags and flags_set is set
    param = {'flags': ['SYN', 'ACK', 'FIN', 'RST', 'URG'], 'flags_set': ['SYN', 'ACK']}
    rule = []
    append_tcp_flags(rule, param, '--tcp-flags')

    assert len(rule) == 2
    assert rule[0] == '--tcp-flags'
    assert rule[1] == 'SYN,ACK,FIN,RST,URG,SYN,ACK'

    # flags is not set, flags_set is set
    param = {'flags_set': ['ACK', 'RST']}
    rule = []
    append_tcp_flags(rule, param, '--tcp-flags')

    assert len(rule) == 2

# Generated at 2022-06-23 03:52:51.642209
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, {
        'flags' : 'ALL',
        'flags_set' : ['ACK', 'RST', 'SYN', 'FIN']
        }, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN'], "test append_tcp_flags function failed"


# Generated at 2022-06-23 03:52:56.279760
# Unit test for function append_wait
def test_append_wait():
    rule=[]
    append_wait(rule, '10', '-w')
    assert rule == ['-w', '10']
    rule=[]
    append_wait(rule, '', '-w')
    assert rule == []



# Generated at 2022-06-23 03:52:57.901470
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:53:11.022294
# Unit test for function construct_rule
def test_construct_rule():
    """
    test construct_rule
    """

# Generated at 2022-06-23 03:53:15.582283
# Unit test for function append_param
def test_append_param():
    rule = []
    param = ['test1', 'test2']
    flag = '--protocol'
    is_list = True
    assert append_param(rule, param, flag, is_list) is None
    assert rule == ['--protocol', 'test1', '--protocol', 'test2']
    rule = []
    param = 'test'
    flag = '--protocol'
    is_list = False
    assert append_param(rule, param, flag, is_list) is None
    assert rule == ['--protocol', 'test']
    rule = []
    param = '!test'
    flag = '--protocol'
    is_list = False
    assert append_param(rule, param, flag, is_list) is None
    assert rule == ['!', '--protocol', 'test']



# Generated at 2022-06-23 03:53:24.003732
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(
        argument_spec=dict(
            table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw', 'security']),
            chain=dict(),
        )
    )

    flush_table(BINS['ipv4'], module, module.params)
    chain = module.params['chain']
    module.assertEqual(module.run_command(["iptables", "-t", module.params['table'], "-L", chain]), (0, "Chain " + chain + " (policy ACCEPT 0 packets, 0 bytes)\n pkts bytes target     prot opt in     out     source               destination          \n", ""))


# Generated at 2022-06-23 03:53:26.995315
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '10', '--wait')
    assert rule == [ '--wait', '10' ]



# Generated at 2022-06-23 03:53:34.636701
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = "path/to/iptables"
    module = True
    params = dict(
            policy = "DROP",
            chain = "INPUT"
    )
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['path/to/iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']
    return True


# Generated at 2022-06-23 03:53:41.412307
# Unit test for function main
def test_main():
    sys.argv = [
        os.path.join(os.path.dirname(os.path.realpath(__file__)), 'iptables-save'),
        '-j', 'filter',
        '-t', 'filter',
        '-n'
    ]

    with open(os.devnull, 'w') as f:
        with mock.patch.object(sys, 'stdout', f):
            with pytest.raises(SystemExit):
                 main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:53:46.118437
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    list = []
    append_tcp_flags(list, {'flags': ['SYN'], 'flags_set': ['ACK', 'RST']}, '!')
    assert list == ['!', '--tcp-flags', 'SYN', 'ACK,RST']

    list = []
    append_tcp_flags(list, {'flags': ['SYN'], 'flags_set': []}, '!')
    assert list == ['!', '--tcp-flags', 'SYN', '']

    list = []
    append_tcp_flags(list, {'flags': [], 'flags_set': []}, '!')
    assert list == []



# Generated at 2022-06-23 03:53:58.347133
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/bin/some/path/iptables'
    module = None
    params = dict(table='filter',
                  chain='INPUT',
                  protocol='tcp',
                  destination_port='22',
                  ctstate='NEW',
                  syn='match',
                  jump='ACCEPT',
                  comment='Accept new SSH connections.'
                  )
    rule = ['/usr/bin/some/path/iptables', '-t', 'filter', '-D', 'INPUT', '-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '--comment', 'Accept new SSH connections.']
    assert remove_rule(iptables_path, module, params) == rule



# Generated at 2022-06-23 03:54:11.200288
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(
        argument_spec=dict(
            chain=dict(required=True),
            ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
            table=dict(default='filter', choices=['filter',
                                                  'nat', 'mangle', 'raw',
                                                  'security']),
        ),
        supports_check_mode=True,
    )

# Generated at 2022-06-23 03:54:19.653142
# Unit test for function get_chain_policy
def test_get_chain_policy():
    import sys
    import os
    import re
    script_path = os.path.dirname(__file__)
    sys.path.insert(0, script_path + '/../../../lib/')

    mock_params = dict(chain='INPUT', table='filter', ip_version='ipv4')
    mock_iptables_path = '/sbin/iptables'
    mock_out = '(policy ACCEPT)'

    def mock_run_command_check_true(cmd, check_rc):
        return 0, mock_out, ''

    def mock_run_command_check_false(cmd, check_rc):
        return 256, '', ''

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 03:54:32.356241
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule({'reject_with': 'tcp-reset'}) == [
        '-m', 'conntrack', '--ctstate', 'NEW', '-p', 'tcp', '-j', 'REJECT',
        '--reject-with', 'tcp-reset'
    ]
    assert construct_rule({'reject_with': 'icmp-port-unreachable'}) == [
        '-m', 'conntrack', '--ctstate', 'NEW', '-p', 'tcp', '-j', 'REJECT',
        '--reject-with', 'icmp-port-unreachable'
    ]

# Generated at 2022-06-23 03:54:36.865878
# Unit test for function append_csv
def test_append_csv():
    param = ["A", "B", "C"]
    flag = "--flags"
    rule = []
    append_csv(rule, param, flag)
    assert rule == ["--flags", "A,B,C"]



# Generated at 2022-06-23 03:54:43.603049
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    rule_match = []
    rule_negate = []

    append_match_flag(rule, 'match', '--tcp-flags', False)
    append_match_flag(rule_match, 'match', '--tcp-flags', True)
    append_match_flag(rule_negate, 'negate', '--tcp-flags', True)

    assert rule == ['--tcp-flags']
    assert rule_match == ['--tcp-flags']
    assert rule_negate == ['!', '--tcp-flags']

test_append_match_flag()



# Generated at 2022-06-23 03:54:52.820623
# Unit test for function append_rule
def test_append_rule():
    test_params = {"table": "filter", "chain": "INPUT", "protocol": "tcp", "destination_port": "80", "jump": "ACCEPT", "action": "append", "state": "present", "ip_version": "ipv4", "flush": False, "policy": "", "comment": ""}
    test_iptables_path = "iptables"
    test_module = "AnsibleModule"
    append_rule(test_iptables_path, test_module, test_params)



# Generated at 2022-06-23 03:54:56.596258
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['ESTABLISHED']
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert rule == ['--ctstate', 'ESTABLISHED']
    param = None
    append_csv(rule, param, flag)
    assert rule == ['--ctstate', 'ESTABLISHED']


# Generated at 2022-06-23 03:55:04.966210
# Unit test for function flush_table
def test_flush_table():
    iptables_path = "/usr/sbin/iptables"
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    params = {
        'chain': 'INPUT',
        'ip_version': 'ipv4',
        'table': 'filter'
    }
    flush_table(iptables_path, module, params)



# Generated at 2022-06-23 03:55:10.819055
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert push_arguments('iptables', '-P', {'table': 'filter', 'chain': 'INPUT', 'policy': 'ACCEPT'}, make_rule=False) == [
        'iptables', '-t', 'filter', '-P', 'INPUT', 'ACCEPT']



# Generated at 2022-06-23 03:55:19.838372
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    params = {'flags': ['ACK', 'SYN', 'FIN', 'RST'],
              'flags_set': ['ACK', 'RST']}
    exp_out = ['--syn', 'ACK,SYN,FIN,RST', 'ACK,RST']
    rule = []
    append_tcp_flags(rule, params, '--syn')
    assert rule == exp_out



# Generated at 2022-06-23 03:55:27.171135
# Unit test for function get_iptables_version
def test_get_iptables_version():
    # Mock out module and get iptables version
    mock_module = MagicMock()
    mock_module.run_command = Mock(return_value=[0, 'foo v1.4.20', ''])
    iptables_version = get_iptables_version('iptables', mock_module)
    # Assert that run_command was called as expected
    expected_cmd = [
        'iptables',
        '--version'
    ]
    mock_module.run_command.assert_called_with(expected_cmd, check_rc=True)
    # Assert that iptables version was returned as expected
    assert iptables_version == '1.4.20'
    # Mock out module and get iptables version
    mock_module = MagicMock()

# Generated at 2022-06-23 03:55:29.889175
# Unit test for function append_jump
def test_append_jump():
    assert append_jump(['-I','INPUT'], "ACCEPT", 'ACCEPT') == ['-I', 'INPUT', '-j', 'ACCEPT']


# Generated at 2022-06-23 03:55:33.931290
# Unit test for function flush_table
def test_flush_table():
    from ansible.module_utils.basic import AnsibleModule
    params = dict(
        table='filter',
        chain='INPUT'
    )
    test = dict(
        cmd = ['/sbin/iptables', '-t', 'filter', '-F', 'INPUT'],
        rc = 0
    )
    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda x, **kwargs : (test['cmd'], '', 0)
    flush_table('/sbin/iptables', module, params)
    assert module.run_command.call_args[0][0] == test['cmd']



# Generated at 2022-06-23 03:55:38.621469
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = ['iptables']
    param = dict(flags=['ALL'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['iptables', '--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-23 03:55:43.236696
# Unit test for function append_match_flag
def test_append_match_flag():
    list = []
    append_match_flag(list, "match", "--destination-port", True)
    assert list == ['--destination-port']
    list = []
    append_match_flag(list, "negate", "--dport", True)
    assert list == ['!', '--dport']
    list = []
    append_match_flag(list, "negate", "--dport", False)
    # append nothing if not negatable
    assert list == []
    list = []
    append_match_flag(list, "match", "--dport", False)
    # append nothing if not negatable
    assert list == []


# Generated at 2022-06-23 03:55:48.954885
# Unit test for function insert_rule
def test_insert_rule():
    rule = construct_rule(params)
    assert rule == ['-w','-t', 'mangle', '-I', 'LOGGING', '5', '-w','-p','tcp', '-m','tcp', '--tcp-flags','ALL','ACK,RST,SYN,FIN', '--log-prefix','IPTABLES:INFO: ','--log-level','info','--match-set','admin_hosts','src','--limit','2/second','--limit-burst','20','-j','ACCEPT']



# Generated at 2022-06-23 03:55:52.046700
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/sbin/iptables'
    module = ''
    params = dict(
        table='filter',
        chain='INPUT',
        source='8.8.8.8',
        jump='DROP'
    )
    remove_rule(iptables_path, module, params)



# Generated at 2022-06-23 03:55:59.089970
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, None, '--tcp-flags')
    assert rule == []
    rule = []
    append_tcp_flags(rule, [], '--tcp-flags')
    assert rule == []
    rule = []
    append_tcp_flags(rule, dict(flags=['ALL'], flags_set=[]), '--tcp-flags')
    assert rule == ['--tcp-flags', 'ALL']
    rule = []
    append_tcp_flags(rule, dict(flags=['ALL'], flags_set=['ACK','RST','SYN','FIN']), '--tcp-flags')
    assert rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']
    rule = []
    append_tcp_flags

# Generated at 2022-06-23 03:56:03.154168
# Unit test for function get_iptables_version
def test_get_iptables_version():
    test_version = "1.4.21"
    test_out = "v" + test_version
    module = None
    iptables_path = "iptables"
    assert get_iptables_version(iptables_path, module) == test_version


# Generated at 2022-06-23 03:56:14.398369
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(
        argument_spec=dict(
            chain=dict(default='INPUT', required=True),
            table=dict(default='filter', required=True),
            ip_version=dict(default='ipv4', required=True),
            protocol=dict(default='tcp', required=True),
        )
    )
    iptables_path = 'iptables'
    params = {
            'chain': 'INPUT',
            'table': 'filter',
            'ip_version': 'ipv4',
            'protocol': 'tcp',
        }
    res = check_present(iptables_path, module, params)
    assert res == False
# End of unit test



# Generated at 2022-06-23 03:56:21.597113
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(
        argument_spec=dict(
            table=dict(default='filter'),
            chain=dict(required=True),
            ip_version=dict(default='ipv4'),
            policy=dict(required=True, choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        )
    )
    params = dict(table='filter', chain='INPUT',
                  ip_version='ipv4', policy='DROP')
    set_chain_policy('/usr/sbin/iptables', module, params)



# Generated at 2022-06-23 03:56:25.801472
# Unit test for function append_jump
def test_append_jump():
    rule = ['test']
    jump = 'jump'
    append_jump(rule, jump, jump)
    assert '-j' in rule


# Generated at 2022-06-23 03:56:32.137283
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = "1"
    flag = "wait"
    append_wait(rule, param, flag)
    assert rule == ["wait", param]
    rule2 = []
    param2 = ""
    append_wait(rule2, param2, flag)
    assert rule2 == []



# Generated at 2022-06-23 03:56:34.053125
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--tcp-flags', False)
    assert rule == ['--tcp-flags']
    rule = []
    append_match_flag(rule, 'negate', '--tcp-flags', True)
    assert rule == ['!', '--tcp-flags']


# Generated at 2022-06-23 03:56:46.480064
# Unit test for function push_arguments
def test_push_arguments():
    params = dict()
    params['ip_version'] = 'ipv4'
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['comment'] = 'test_entry'
    params['gid_owner'] = '!test_owner'
    params['jump'] = 'ACCEPT'
    params['protocol'] = 'tcp'
    params['source'] = '127.0.0.1'
    params['destination'] = '1.1.1.1'
    params['in_interface'] = 'lo'
    params['out_interface'] = 'eth0'
    params['fragment'] = 'yes'
    params['source_port'] = '8000'
    params['destination_port'] = '80'
    params['to_ports'] = '8080'

# Generated at 2022-06-23 03:56:52.391813
# Unit test for function append_rule
def test_append_rule():
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port=22,
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    cmd = push_arguments(BINS['ipv4'], '-A', params)

# Generated at 2022-06-23 03:56:58.304890
# Unit test for function push_arguments
def test_push_arguments():
    assert(push_arguments('/sbin/iptables', '-I', {'table':'raw','chain':'PREROUTING','rule_num':'1','jump':'ACCEPT'}) ==
           ['/sbin/iptables', '-t', 'raw', '-I', 'PREROUTING', '1', '-j', 'ACCEPT'])


# Generated at 2022-06-23 03:57:04.512342
# Unit test for function append_wait
def test_append_wait():
    rule = []
    timeout = 5
    append_wait(rule, timeout, '--wait')
    if '--wait' not in rule:
        raise AssertionError("append_wait did not append 5")
    if not rule[-1]:
        raise AssertionError("append_wait did not append the correct value")


# Generated at 2022-06-23 03:57:07.458946
# Unit test for function push_arguments
def test_push_arguments():
    arg_push = push_arguments(iptables_path="iptables", action="test", params=dict(table='test'))
    assert arg_push == ['iptables', '-t', 'test', 'test']



# Generated at 2022-06-23 03:57:20.670081
# Unit test for function construct_rule

# Generated at 2022-06-23 03:57:22.312959
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({})
    params = {'ip_version': 'ipv4', 'table': 'filter', 'chain': 'INPUT', 'policy': 'DROP'}
    set_chain_policy('/usr/bin/iptables', module, params)



# Generated at 2022-06-23 03:57:30.544949
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule(['iptables'], module, params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '-p', 'tcp', '--dport', '22', '-j', 'ACCEPT', '--comment', 'Test Rule'
    ]
    assert insert_rule(['iptables'], module, params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '-p', 'tcp', '--dport', '22', '-j', 'ACCEPT', '--comment', 'Test Rule'
    ]

# Generated at 2022-06-23 03:57:33.787617
# Unit test for function insert_rule
def test_insert_rule():
    '''
    Returns True if Exception is raised
    Returns False if Exception is not raised
    '''
    params = {
    'table': 'nat',
    'chain': 'INPUT',
    'protocol': 'tcp',
    'destination_port': '8080',
    'jump': 'ACCEPT',
    'action': 'insert',
    'rule_num': '1'
    }
    try:
        insert_rule('/sbin/iptables', '/sbin/iptables', params)
    except Exception as e:
        return False
    return True



# Generated at 2022-06-23 03:57:36.048276
# Unit test for function flush_table
def test_flush_table():
    print(flush_table('/sbin/iptables', None, {'table':'mangle'}))


# Generated at 2022-06-23 03:57:48.505466
# Unit test for function main
def test_main():
    # Set up mock
    module = mock.MagicMock()
    module.get_bin_path.return_value = 'iptables'
    module.run_command.return_value = (0, '', '')

# Generated at 2022-06-23 03:57:54.797015
# Unit test for function append_rule
def test_append_rule():
    cmd = push_arguments("/sbin/iptables", '-A', {"ip_version" :"ipv4", "table": "filter", "chain": "INPUT", "protocol" :"tcp", "destination_port" :"80"})
    print(cmd)
