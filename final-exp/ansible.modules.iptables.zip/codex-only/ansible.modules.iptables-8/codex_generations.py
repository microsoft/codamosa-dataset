

# Generated at 2022-06-23 03:48:00.581950
# Unit test for function append_rule
def test_append_rule():
    from ansible.modules.network.firewall import iptables
    from mock import Mock
    params = {'table': 'filter', 'chain': 'INPUT', 'jump': 'ACCEPT', 'ip_version': 'ipv4'}
    module = Mock()
    command = push_arguments(iptables.BINS['ipv4'], '-A', params)
    module.run_command.return_value = 0, '', ''
    iptables.append_rule(iptables.BINS['ipv4'], module, params)
    module.run_command.assert_called_once_with(command, check_rc=True)



# Generated at 2022-06-23 03:48:09.118290
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '-m', True)
    append_match_flag(rule, 'negate', '-m', True)
    append_match_flag(rule, 'test', '-m', False)
    assert rule == ['-m', '-m', '!', '-m']


# Generated at 2022-06-23 03:48:18.836181
# Unit test for function check_present

# Generated at 2022-06-23 03:48:24.173006
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = mock.MagicMock()
    module.run_command.return_value = (0, 'v1.4.12', None)
    version = get_iptables_version('/bin/iptables', module)
    module.run_command.assert_called_once_with(['/bin/iptables', '--version'], check_rc=True)
    assert version == '1.4.12'



# Generated at 2022-06-23 03:48:29.030061
# Unit test for function append_wait
def test_append_wait():
    rule = []
    flag = '-w'
    param = '1'
    append_wait(rule, param, flag)
    assert(rule == ['-w', '1'])

    rule = []
    flag = '-w'
    param = None
    append_wait(rule, param, flag)
    assert(rule == [])


# Generated at 2022-06-23 03:48:31.338575
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, '', 'ACCEPT')
    assert not rule
    append_jump(rule, None, 'ACCEPT')
    assert not rule
    append_jump(rule, 'ACCEPT', 'ACCEPT')
    assert rule == ['-j', 'ACCEPT']



# Generated at 2022-06-23 03:48:37.057019
# Unit test for function insert_rule
def test_insert_rule():
    text = iptables_save()
    module = AnsibleModule({})
    params = {
    'chain': 'LOGGING',
    'action': 'insert',
    'state': 'present',
    'table': 'mangle',
    'priority': '0',
    'iptables_save': text,
    }
    assert insert_rule('/sbin/iptables', module, params) == text


# Generated at 2022-06-23 03:48:45.309955
# Unit test for function construct_rule

# Generated at 2022-06-23 03:48:51.997422
# Unit test for function append_match_flag
def test_append_match_flag():
    test_1 = []
    append_match_flag(test_1, 'match', '', False)
    assert test_1 == ['match']

    test_2 = []
    append_match_flag(test_2, 'negate', '', True)
    assert test_2 == ['!match']

    test_3 = []
    append_match_flag(test_3, 'mismatch', '', False)
    assert test_3 == []



# Generated at 2022-06-23 03:48:56.243399
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        comment='test',
        chain='INPUT',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['--comment', 'test']

    params = dict(
        chain='INPUT',
        destination_port=22,
        destination='192.168.99.0/24',
        ip_version='ipv4',
        jump='ACCEPT',
    )
    rule = construct_rule(params)
    assert rule == ['-d', '192.168.99.0/24', '--dport', '22', '-j', 'ACCEPT']


# Generated at 2022-06-23 03:48:58.741502
# Unit test for function append_param
def test_append_param():
    rules = []
    append_param(rules, ['A','B','C','D'], 'test', True)
    assert rules == ['test', 'A', 'test', 'B', 'test', 'C', 'test', 'D']
    rules = []
    append_param(rules, None, 'test', True)
    assert rules == []
    rules = []
    append_param(rules, 'C', 'test', True)
    assert rules == ['test', 'C']


# Generated at 2022-06-23 03:49:00.840064
# Unit test for function append_jump
def test_append_jump():
    testRule = []
    append_jump(testRule, "ACCEPT", "ACCEPT")
    assert(testRule == ['-j', 'ACCEPT'])


# Generated at 2022-06-23 03:49:02.123584
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule(iptables_path, module, params)


# Generated at 2022-06-23 03:49:07.212100
# Unit test for function append_rule
def test_append_rule():
    # create iptables module mock
    iptables_mock = MockIptables()
    # test append
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        source='1.2.3.4',
        jump='ACCEPT'
    )
    append_rule('/usr/bin/iptables', iptables_mock, params)
    assert iptables_mock.argv[0] == '/usr/bin/iptables'
    assert iptables_mock.argv[1] == '-t'
    assert iptables_mock.argv[2] == 'filter'
    assert iptables_mock.argv[3] == '-A'

# Generated at 2022-06-23 03:49:15.824751
# Unit test for function append_csv
def test_append_csv():
    assert append_csv(['iptables'], [], '') == ['iptables']
    assert append_csv(['iptables'], ['a', 'b'], '-m') == ['iptables', '-m', 'a,b']
    assert append_csv(['iptables'], ['a', 'b'], '!') == ['iptables', '!', 'a,b']


# Generated at 2022-06-23 03:49:19.859952
# Unit test for function append_param
def test_append_param():
    expected = ['iptables', '-A', 'INPUT', '-s', '192.168.1.100']
    rule = ['iptables', '-A', 'INPUT']
    append_param(rule, '192.168.1.100', '-s', False)
    assert(rule == expected)
    assert(rule != None)

    expected = ['iptables', '-A', 'INPUT', '!', '-s', '!192.168.1.100']
    rule = ['iptables', '-A', 'INPUT']
    append_param(rule, '!192.168.1.100', '-s', False)
    assert(rule == expected)
    assert(rule != None)


# Generated at 2022-06-23 03:49:30.639217
# Unit test for function insert_rule
def test_insert_rule():
    ansible_command= "ansible.builtin.iptables"
    ansible_params={
        "chain":"INPUT",
        "protocol":"tcp",
        "destination_port":"8080",
        "jump":"ACCEPT",
        "action":"insert",
        "rule_num":"5",
    }
    if ansible_params['action']=="append":
        append_rule(iptables_path,module,ansible_params)
    elif ansible_params['action']=="insert":
        insert_rule(iptables_path,module,ansible_params)
    else:
        module.fail_json(msg="Invalid action '%s' specified" % ansible_params['action'])


# Generated at 2022-06-23 03:49:34.661592
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'return'
    jump = 'RETURN'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'RETURN']
    param = []
    append_jump(rule, param, jump)
    assert rule == ['-j', 'RETURN']



# Generated at 2022-06-23 03:49:35.872041
# Unit test for function main
def test_main():
    assert True


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:49:38.936057
# Unit test for function get_iptables_version
def test_get_iptables_version():
    '''Testing function get_iptables_version'''
    assert get_iptables_version('/usr/sbin/iptables', None).startswith('1.')



# Generated at 2022-06-23 03:49:43.441780
# Unit test for function append_wait
def test_append_wait():
    rule = ['-t', 'filter', 'A']
    flag = '--wait'
    param = '60'
    assert append_wait(rule, param, flag) == ['-t', 'filter', 'A', '--wait', '60']



# Generated at 2022-06-23 03:49:49.389321
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/bin/iptables'
    cmd = push_arguments(iptables_path, '-F', params, make_rule=False)
    module.run_command(cmd, check_rc=True)


# Generated at 2022-06-23 03:49:53.416133
# Unit test for function set_chain_policy
def test_set_chain_policy():
    pass


# def main():
#     try:
#         set_chain_policy()
#         print(0)
#     except:
#         print(1)


# if __name__ == '__main__':
#     main()



# Generated at 2022-06-23 03:49:58.114720
# Unit test for function check_present
def test_check_present():
    import os
    import sys

    # Load and execute the module
    module = sys.modules[__name__]
    exec(open(os.path.join(os.path.dirname(__file__), 'module_utils',
                           'basic.py')).read())
    exec(open(os.path.join(os.path.dirname(__file__), 'module_utils',
                           'firewall.py')).read())

    # Create a fake module
    params = dict(
        src_range='192.168.1.100-192.168.1.199',
        dst_range='10.0.0.1-10.0.0.50',
        comment="fake_rule",
        ip_version="ipv4",
    )

# Generated at 2022-06-23 03:50:10.262216
# Unit test for function push_arguments
def test_push_arguments():
    assert (push_arguments('/sbin/iptables', '-I', dict(
        chain='INPUT',
        rule_num='1',
        table='filter',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )) == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '1', '-p', 'tcp', '--destination-port', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.'])

# Generated at 2022-06-23 03:50:11.064462
# Unit test for function insert_rule
def test_insert_rule():
    pass



# Generated at 2022-06-23 03:50:12.371518
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path='/sbin/iptables'
    print ('calling set_chain_policy for testing')

# Generated at 2022-06-23 03:50:21.277447
# Unit test for function append_match_flag
def test_append_match_flag():
    rule_1 = []
    rule_2 = []
    rule_3 = []
    rule_4 = []
    append_match_flag(rule_1, 'match', '--ipopt-flag', False)
    append_match_flag(rule_2, 'negate', '--tcp-flag', True)
    append_match_flag(rule_3, '--ipopt-flag', '--tcp-flag', False)
    append_match_flag(rule_4, 'negate', '--ipopt-flag', True)
    assert rule_1 == ['--ipopt-flag']
    assert rule_2 == ['!', '--tcp-flag']
    assert rule_3 == ['--tcp-flag']
    assert rule_4 == ['!', '--ipopt-flag']
       


# Generated at 2022-06-23 03:50:24.298956
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    tcp_flags = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['SYN']
    )
    append_tcp_flags(rule, tcp_flags, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'SYN']



# Generated at 2022-06-23 03:50:25.166531
# Unit test for function main
def test_main():
    assert True


# unit test for function push_arguments

# Generated at 2022-06-23 03:50:29.118481
# Unit test for function append_rule
def test_append_rule():
    if skip_unit_test:
        return
    cmd = push_arguments(iptables_path, '-A', params)
    print (cmd)
    assert cmd == '/sbin/iptables -A INPUT -s 10.1.1.1', "append a rule failed"

# Generated at 2022-06-23 03:50:31.726241
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = '1'
    append_wait(rule, param, 'IPTABLES_WAIT')
    assert rule == ['IPTABLES_WAIT', '1']


# Generated at 2022-06-23 03:50:37.685711
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        policy='DROP',
        table='filter',
        chain='INPUT',
        ip_version='ipv4'
    )
    assert set_chain_policy('iptables',None, params) == [ 'iptables', '-t', 'filter', '-P', 'INPUT', 'DROP' ]


# Generated at 2022-06-23 03:50:38.947157
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'table':'filter', 'chain':'INPUT'}) == 'ACCEPT'


# Generated at 2022-06-23 03:50:50.974195
# Unit test for function construct_rule
def test_construct_rule():
    import tempfile

# Generated at 2022-06-23 03:50:54.745673
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'red', '--color', False)
    assert rule == ['--color', 'red']


# Generated at 2022-06-23 03:50:57.873277
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', 'MATCH', True)
    assert rule == ['MATCH']
    rule = []
    append_match_flag(rule, 'negate', 'MATCH', True)
    assert rule == ['!', 'MATCH']
    rule = []
    append_match_flag(rule, 'match', 'MATCH', False)
    assert rule == ['MATCH']
    rule = []
    append_match_flag(rule, 'negate', 'MATCH', False)
    assert rule == []


# Generated at 2022-06-23 03:51:03.219577
# Unit test for function push_arguments
def test_push_arguments():
    ip_version = 'ipv4'
    iptables_path = 'iptables'
    action = '-A'
    basic_params = dict(
        chain='INPUT',
        table='filter',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT'
    )

    result = push_arguments(iptables_path, action, basic_params)

# Generated at 2022-06-23 03:51:05.282736
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '-s', True)
    append_match_flag(rule, 'negate', '-s', True)
    append_match_flag(rule, 'ignore', '-s', True)
    assert rule == ['-s', '--syn', '!', '--syn']



# Generated at 2022-06-23 03:51:06.648501
# Unit test for function append_match
def test_append_match():
    rule = []
    param = ''
    assert append_match(rule, param, "test-match") == None
    assert rule == []


# Generated at 2022-06-23 03:51:10.409909
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(dict())
    module.run_command = lambda a, b: (0, '', '')
    params = {'ip_version': 'ipv4', 'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '8080', 'jump': 'ACCEPT', 'action': 'insert', 'rule_num': '5'}
    assert push_arguments('iptables', '-I', params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-23 03:51:11.755605
# Unit test for function append_wait
def test_append_wait():
    rule = []
    rule = append_wait(rule, "0", "--wait")
    assert( rule==["--wait", "0"])


# Generated at 2022-06-23 03:51:23.449854
# Unit test for function main

# Generated at 2022-06-23 03:51:31.789404
# Unit test for function append_csv
def test_append_csv():
    rule1 = []
    append_csv(rule1, [], "--destination-ports")
    assert "[]", rule1
    rule1 = []
    append_csv(rule1, ["80"], "--destination-ports")
    assert ["--destination-ports", "80"], rule1
    rule1 = []
    append_csv(rule1, ["80", "443", "8081:8083"], "--destination-ports")
    assert ["--destination-ports", "80,443,8081:8083"], rule1



# Generated at 2022-06-23 03:51:38.333361
# Unit test for function append_param
def test_append_param():
    param1 = '--some-option'
    flag1 = '-o'
    param2 = '!--some-other-option'
    flag2 = '-t'
    rule = []
    append_param(rule, param1, flag1, False)
    assert(rule == [flag1, param1])
    append_param(rule, [param1, param2], flag2, True)
    assert(rule == [flag1, param1, flag2, param1, flag2, '!', param2])



# Generated at 2022-06-23 03:51:43.256675
# Unit test for function get_chain_policy
def test_get_chain_policy():
    ipv4_tests = [
        ("Chain INPUT (policy ACCEPT)\n", "ACCEPT"),
        ("Chain OUTPUT (policy DROP)\n", "DROP"),
        ("Chain OUTPUT (policy REJECT)\n", "REJECT")
    ]
    for test in ipv4_tests:
        assert get_chain_policy('', None, {'chain':'INPUT', 'table':'filter'}) == test[1]


# Generated at 2022-06-23 03:51:47.080786
# Unit test for function append_param
def test_append_param():
    #use append_param() to append parameter to list
    rule=[]
    append_param(rule,1, '', False)
    assert rule == [1]


# Generated at 2022-06-23 03:51:58.491499
# Unit test for function main
def test_main():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 03:52:01.716887
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({
    })
    module._verbosity = True
    params = {'chain': 'INPUT', 'policy': 'DROP', 'table': 'filter'}
    set_chain_policy('iptables', module, params)



# Generated at 2022-06-23 03:52:04.154498
# Unit test for function append_jump
def test_append_jump():
    assert 1 == 1


# Generated at 2022-06-23 03:52:09.553284
# Unit test for function flush_table
def test_flush_table():
    expected_cmd = ['/usr/sbin/iptables', '-t', 'filter', '-F', 'INPUT']
    params = {'table': 'filter', 'chain': 'INPUT'}
    assert flush_table("/usr/sbin/iptables", None, params) == expected_cmd



# Generated at 2022-06-23 03:52:19.208820
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, ['1', '2', '3'], '--protocol', True)
    assert rule == ['-p', '!', '--protocol', '1', '-p', '--protocol', '2', '-p', '--protocol', '3']
    rule = []
    append_param(rule, '1', '--protocol', False)
    assert rule == ['-p', '!', '--protocol', '1']
    rule = []
    append_param(rule, '!1', '--protocol', False)
    assert rule == ['!', '--protocol', '1']


# Generated at 2022-06-23 03:52:24.462697
# Unit test for function get_iptables_version
def test_get_iptables_version():
    iptables_path = 'iptables'
    module = mock.Mock()
    module.run_command.return_value = 0, "iptables v1.4.21", None
    assert get_iptables_version(iptables_path, module) == "1.4.21"
    module.run_command.return_value = 1, "iptables v1.4.21", "error"
    assert get_iptables_version(iptables_path, module) == "1.4.21"
    module.run_command.assert_called_with(
            [iptables_path, '--version'], check_rc=True)


# Generated at 2022-06-23 03:52:33.932631
# Unit test for function check_present
def test_check_present():
    from ansible.modules.network.iptables import (
        check_present,
        push_arguments,
        construct_rule,
    )
    params = dict(
        iptables_path='/sbin/iptables',
        action='-C',
        params=dict(
            table='filter',
            chain='INPUT',
            ip_version='ipv4',
            protocol='tcp',
            destination_port='22',
            ctstate='NEW',
            syn='match',
            jump='ACCEPT',
            comment='Accept new SSH connections.'
        ),
        make_rule=True,
    )
    module = None
    cmd = push_arguments(params['iptables_path'], '-C', params['params'])
    print(cmd)

# Generated at 2022-06-23 03:52:39.687329
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(iptables_path='iptables', module=module, params={
        'chain': 'INPUT',
        'policy': 'DROP'
    }) == None



# Generated at 2022-06-23 03:52:52.019884
# Unit test for function set_chain_policy
def test_set_chain_policy():
    # test for incorrect chain
    with pytest.raises(SystemExit) as e_info:
        set_chain_policy('/sbin/iptables', module=AnsibleModule, params={'table':'filter', 'chain':'people', 'ip_version':'ipv4', 'policy':'ACCEPT', 'binary':'iptables'}, make_rule=False)
    assert e_info.type == SystemExit
    assert e_info.value.code == 1

    # test for correct chain
    # need to use a mock to get assert instead of SystemExit
    #m = MagicMock()
    #m.run_command.return_value = [0]
    #set_chain_policy('/sbin/iptables', module=m, params={'table':'filter', 'chain':'INPUT', 'ip_version

# Generated at 2022-06-23 03:52:54.396667
# Unit test for function check_present
def test_check_present():
    print('hi')
    assert not check_present('iptables', 'module', 'a')



# Generated at 2022-06-23 03:52:58.107924
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = 'a,b'
    flag = 'f'
    append_csv(rule, param, flag)
    assert rule == ['f', 'a,b']
    

# Generated at 2022-06-23 03:53:09.186133
# Unit test for function append_csv
def test_append_csv():
    cmd_list = []
    cmd_list_expected = []

    cmd_list_expected.extend(['--ctstate', ','.join(['ESTABLISHED'])])
    append_csv(cmd_list, ['ESTABLISHED'], '--ctstate')

    cmd_list_expected.extend(['--ctstate', ','.join(['INVALID', 'UNTRACKED'])])
    append_csv(cmd_list, ['INVALID', 'UNTRACKED'], '--ctstate')

    assert cmd_list_expected == cmd_list




# Generated at 2022-06-23 03:53:18.205151
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {}
    param['flags'] = ['ACK', 'RST', 'SYN', 'FIN']
    param['flags_set'] = ['ACK', 'RST', 'SYN', 'FIN']
    append_tcp_flags(rule, param, '--tcp-flags')
    expected_rule = ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']
    assert rule == expected_rule


# Generated at 2022-06-23 03:53:29.071058
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec={'ip_version': {'required': True, 'choices': ['ipv4', 'ipv6']}, 'chain': {'required': True}, 'jump': {'required': True}, 'table': {'required': False, 'choices': ['filter', 'nat', 'mangle', 'raw', 'security']}})
    params = module.params
    iptables_path = BINS[params['ip_version']]
    class Args(object):
        pass
    args = Args()
    args.table = 'filter'
    args.chain = 'INPUT'
    args.jump = 'ACCEPT'
    args.protocol = 'tcp'
    args.destination_port = '22'
    args.ctstate = ['NEW']

# Generated at 2022-06-23 03:53:34.578892
# Unit test for function insert_rule
def test_insert_rule():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({
        'table': 'filter',
        'chain': 'INPUT',
    })
    cmd = push_arguments('iptables', '-I', module, params)
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-23 03:53:43.499591
# Unit test for function check_present
def test_check_present():
    #Test for a rule without fragment and limit parameters
    params = {
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'ctstate': 'NEW',
        'syn': 'match',
        'jump': 'ACCEPT',
        'comment': 'Accept new HTTP connections.',
        'table': 'filter',
        'ip_version': 'ipv4'
    }

    #Test for a rule with fragment and limit parameters

# Generated at 2022-06-23 03:53:46.998619
# Unit test for function flush_table
def test_flush_table():
    iptables_path = BINS['ipv4']
    chain = "test"
    cmd = push_arguments(iptables_path, '-F', {'table':"filter", 'chain': chain}, make_rule=False)
    print (cmd)

# Generated at 2022-06-23 03:53:49.789896
# Unit test for function flush_table
def test_flush_table():
    # Test case1:
    path = '/bin/iptables'
    test_obj = {}
    test_obj['chain'] = 'INPUT'
    test_obj['table'] = 'nat'
    test_obj['ip_version'] = 'ipv4'
    output = flush_table(path,test_obj,test_obj)
    if(output != None):
        print("success")
    else:
        print("failure")


# Generated at 2022-06-23 03:53:53.530821
# Unit test for function append_param
def test_append_param():
    rule = []
    param = None
    flag = "flag"
    append_param(rule, param, flag, False)
    assert len(rule) == 0

    rule = [None]
    param = ""
    append_param(rule, param, flag, False)
    assert len(rule) == 2

    rule = [None]
    param = "!"
    append_param(rule, param, flag, False)
    assert rule == [None, '!', 'flag']

    rule = [None]
    param = "test"
    append_param(rule, param, flag, False)
    assert rule == [None, 'flag', 'test']


# Generated at 2022-06-23 03:54:04.519300
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        chain='INPUT',
        table='filter',
    )
    assert get_chain_policy(iptables_path, module, params) == 'ACCEPT'
    params = dict(
        chain='OUTPUT',
        table='filter',
    )
    assert get_chain_policy(iptables_path, module, params) == 'ACCEPT'
    params = dict(
        chain='FORWARD',
        table='filter',
    )
    assert get_chain_policy(iptables_path, module, params) == 'ACCEPT'
    params = dict(
        chain='FORWARD',
        table='nat',
    )

# Generated at 2022-06-23 03:54:06.265055
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/usr/bin/iptables', {}) == '1.6.0'



# Generated at 2022-06-23 03:54:12.308501
# Unit test for function append_match
def test_append_match():
    result = []
    append_match(result, 'match_param', 'match')
    assert result == ['-m', 'match']
    result = []
    append_match(result, '', 'match')
    assert result == []


# Generated at 2022-06-23 03:54:20.957120
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        action='-A',
        chain='INPUT',
        comment='ANSIBLE: TEST',
        destination='8.8.8.8',
        destination_port=22,
        jump='ACCEPT',
        protocol='tcp',
        source='192.168.1.1',
        src_range='192.168.1.50-192.168.1.99',
        table='filter',
        dscp_set=6,
        uid_owner='root',
        synchronize=True,
        wait=10,
        rule_num=5,
    )
    cmd = push_arguments('iptables', '-A', params)
    # -w 10 is supported since iptables version 1.6.0

# Generated at 2022-06-23 03:54:24.651156
# Unit test for function append_match_flag
def test_append_match_flag():
    assert ['--match-set', 'set', 'dst'] == append_match_flag(['--match-set', 'set'], 'match', 'dst', False)
    assert ['--match-set', 'set', '!', 'dst'] == append_match_flag(['--match-set', 'set'], 'negate', 'dst', True)
    assert ['--match-set', 'set'] == append_match_flag(['--match-set', 'set'], 'ignore', 'dst', False)



# Generated at 2022-06-23 03:54:28.715433
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {}
    param['flags'] = ['ACK', 'RST', 'SYN', 'FIN']
    param['flags_set'] = ['SYN', 'RST']
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == [ '--tcp-flags', 'ACK,RST,SYN,FIN', 'SYN,RST' ]



# Generated at 2022-06-23 03:54:38.828845
# Unit test for function push_arguments
def test_push_arguments():
    for ip_version in ('ipv4', 'ipv6'):
        for action in ('-A', '-D', '-I', '-R'):
            for table in ('filter', 'nat', 'mangle'):
                for chain in ('INPUT', 'FORWARD', 'OUTPUT'):
                    for i in range(0, 10):
                        params = dict(
                            ip_version=ip_version,
                            action=action,
                            table=table,
                            chain=chain,
                            rule_num=str(i),
                        )
                        cmd = push_arguments(
                            BINS[ip_version],
                            action,
                            params,
                        )

# Generated at 2022-06-23 03:54:46.093092
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(
        argument_spec=dict(
            table=dict(required=True, type='str'),
            chain=dict(required=True, type='str'),
            ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
        )
    )
    ip_version = 'ipv4'
    table = 'filter'
    chain = 'INPUT'
    params = dict(
        table=table,
        chain=chain,
        ip_version=ip_version,
    )
    iptables_path = BINS[params['ip_version']]
    flush_table(iptables_path, module, params)



# Generated at 2022-06-23 03:54:49.617305
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_iptables_version('iptables', module)



# Generated at 2022-06-23 03:54:56.006713
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule(dict(ip_version='ipv4', source='8.8.8.8', jump='DROP')) == \
        ['iptables', '-s', '8.8.8.8', '-j', 'DROP']
    assert construct_rule(
        dict(ip_version='ipv6', source='2001:db8::1', jump='DROP')) == \
        ['ip6tables', '-s', '2001:db8::1', '-j', 'DROP']
    assert construct_rule(
        dict(ip_version='ipv4', protocol='tcp', destination_port=80, jump='ACCEPT')) == \
        ['iptables', '-p', 'tcp', '--dport', '80', '-j', 'ACCEPT']
    assert construct_rule

# Generated at 2022-06-23 03:54:57.759745
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'ACCEPT'
    jump = 'ACCEPT'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'ACCEPT']

# Generated at 2022-06-23 03:55:11.163814
# Unit test for function main

# Generated at 2022-06-23 03:55:13.643152
# Unit test for function append_match
def test_append_match():
    try:
        rule = []
        param = True
        match = 'state'
        append_match(rule, param, match)
        assert rule == ['-m', 'state']
    except Exception:
        print('Test error in append_match()')



# Generated at 2022-06-23 03:55:16.608230
# Unit test for function get_iptables_version
def test_get_iptables_version():
    '''Returns iptables version'''
    iptables_path = '/sbin/iptables'
    module = {
        'run_command': lambda x: True
    }
    expected_output = '1.4.20'
    assert expected_output == get_iptables_version(iptables_path, module)



# Generated at 2022-06-23 03:55:21.765357
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert ['iptables', '-C', 'INPUT', '-s', '12.12.12.12', '-j', 'ACCEPT'] == construct_rule({"chain": "INPUT", "source": "12.12.12.12", "jump": "ACCEPT"})
    assert  False == check_present("iptables", "fake_module", {"chain": "INPUT", "source": "12.12.12.12", "jump": "ACCEPT"})


# Generated at 2022-06-23 03:55:33.179725
# Unit test for function construct_rule

# Generated at 2022-06-23 03:55:44.760338
# Unit test for function remove_rule
def test_remove_rule():
    params = {}
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['source'] = '8.8.8.8'
    params['jump'] = 'DROP'
    iptables_path = '/sbin/iptables'
    module = AnsibleModule()
    rule = construct_rule(params)
    cmd = push_arguments(iptables_path, '-D', params)
    assert rule == ['-w', '-p', '-s', '8.8.8.8', '-j', 'DROP']
    assert cmd == [iptables_path, '-t', params['table'], '-D', params['chain'], '-w', '-p', '-s', '8.8.8.8', '-j', 'DROP']




# Generated at 2022-06-23 03:55:45.853105
# Unit test for function append_rule
def test_append_rule():
    assert True == False
    



# Generated at 2022-06-23 03:55:52.465563
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, param=True, match='match')
    # output = ['-m', 'match']
    if rule != ['-m', 'match']:
        raise AssertionError()
    rule = []
    append_match(rule, param=False, match='match')
    if rule != []:
        raise AssertionError()


# Generated at 2022-06-23 03:56:06.252869
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(table='filter', chain='INPUT', source='8.8.8.8', jump='DROP')
    cmd = push_arguments('iptables', '-A', params)
    assert cmd == ['iptables', '-t', 'filter', '-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP']
    # Test that append action is supported
    cmd = push_arguments('iptables', '-A', params)
    assert cmd == ['iptables', '-t', 'filter', '-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP']

# Generated at 2022-06-23 03:56:19.859393
# Unit test for function main

# Generated at 2022-06-23 03:56:24.423290
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '1', '--wait')
    assert rule == ['--wait', '1']



# Generated at 2022-06-23 03:56:32.782084
# Unit test for function append_param
def test_append_param():
    # Test list of strings
    assert append_param([], ["one", "two", "three"], "--test", True) == ["--test", "one", "--test", "two", "--test", "three"]
    # Test list of regexp and strings
    assert append_param([], ["^one", "^two", "three"], "--test", True) == ["--test", "^one", "--test", "^two", "--test", "three"]
    # Test list of regexp and strings prefixed with "!"
    assert append_param([], ["^one", "^two", "!three"], "--test", True) == ["--test", "^one", "--test", "^two", "!", "--test", "three"]


# Generated at 2022-06-23 03:56:46.184364
# Unit test for function push_arguments
def test_push_arguments():
    ip_version = 'ipv4'
    table = 'filter'
    chain = 'INPUT'
    action = '-A'

# Generated at 2022-06-23 03:56:51.623533
# Unit test for function append_wait
def test_append_wait():
    r1 = []
    append_wait(r1, '7s', '-w')
    assert r1 == ['-w', '7s']
    r2 = []
    append_wait(r2, '', '-w')
    assert r2 == []



# Generated at 2022-06-23 03:57:01.660478
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule(dict(
        protocol='tcp',
        source='1.1.1.0/24',
        destination='2.2.2.0/24',
        in_interface='eth0',
        syn='match',
        jump='ACCEPT',
        log_prefix='foobar'
    )) == ['-p', 'tcp', '-s', '1.1.1.0/24', '-d', '2.2.2.0/24', '-i', 'eth0', '--syn',
           '-j', 'ACCEPT', '--log-prefix', 'foobar']



# Generated at 2022-06-23 03:57:10.046653
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = "/sbin/iptables"
    action = "-I"
    chain = "INPUT"
    rule_num = "3"
    table = "nat"
    params = dict(
        ip_version="ipv4",
        chain=chain,
        action=action,
        rule_num=rule_num,
        table=table,
        protocol="tcp",
        destination_port="80",
        ctstate="ESTABLISHED,RELATED",
        jump="ACCEPT",
        comment="Accept new SSH connections.",
    )
    cmd = push_arguments(iptables_path, action, params)

# Generated at 2022-06-23 03:57:14.944475
# Unit test for function insert_rule
def test_insert_rule():
    result = insert_rule("test_iptables_path", "test_module", "test_params")
    assert result == 'test_module.run_command(["test_iptables_path", "-t", "test_params", "-A", "test_params"], check_rc=True)'



# Generated at 2022-06-23 03:57:17.554605
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    res = flush_table("iptables", module, {'table':'nat', 'chain':'INPUT'})
    assert res == None



# Generated at 2022-06-23 03:57:19.486135
# Unit test for function append_jump
def test_append_jump():
    rule = []
    rule.extend(['-j', jump])


# Generated at 2022-06-23 03:57:23.312751
# Unit test for function append_jump
def test_append_jump():
  rule=list()
  param="ACCEPT"
  jump="ACCEPT"
  expected_rule=['-j', 'ACCEPT']

  append_jump(rule, param, jump)
  assert rule == expected_rule


# Generated at 2022-06-23 03:57:28.946671
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/sbin/iptables'
    action = '-A'
    params = dict()
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['protocol'] = 'tcp'
    expected_result = \
        ['/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp']
    assert push_arguments(iptables_path, action, params) == expected_result



# Generated at 2022-06-23 03:57:33.951061
# Unit test for function set_chain_policy
def test_set_chain_policy():
    set_chain_policy(None, None, {
        "chain": "INPUT",
        "table": "filter",
        "policy": "DROP"})


# Generated at 2022-06-23 03:57:44.440128
# Unit test for function remove_rule

# Generated at 2022-06-23 03:57:53.089229
# Unit test for function check_present
def test_check_present():
    assert check_present("./iptables", "module",
                         dict(chain="INPUT", jump="DROP",
                              table="filter", ip_version="ipv4")) == True
    assert check_present("./iptables", "module",
                         dict(chain="INPUT", jump="ACCEPT",
                              table="filter", ip_version="ipv4")) == False

