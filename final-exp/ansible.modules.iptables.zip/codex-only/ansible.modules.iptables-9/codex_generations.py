

# Generated at 2022-06-23 03:48:02.276870
# Unit test for function construct_rule
def test_construct_rule():
    assert (construct_rule(dict(
        jump='DROP',
        protocol='tcp',
        destination_port='8080',
        action='insert',
        rule_num='5',
    )) ==
        [
            '-w',
            '-p', 'tcp',
            '--destination-port', '8080',
            '-j', 'DROP',
            '-w',
        ]
    )

# Generated at 2022-06-23 03:48:08.390178
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    version = get_iptables_version(module, 'iptables')
    assert version in ['1.4.20', '1.6.0']



# Generated at 2022-06-23 03:48:15.044286
# Unit test for function remove_rule
def test_remove_rule():
    params = {
            'chain': 'LOGGING'
            }
    iptables_path = '/sbin/iptables'
    action = '-D'
    cmd = push_arguments(iptables_path, action, params)
    print(cmd)
    module = AnsibleModule
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-23 03:48:17.973781
# Unit test for function flush_table
def test_flush_table():
    assert ['iptables', '-t', 'mangle', '-F', 'PREROUTING'] == flush_table('iptables', 'module', dict(table='mangle', chain='PREROUTING', flush=True))



# Generated at 2022-06-23 03:48:24.312750
# Unit test for function append_match
def test_append_match():
    rule= []
    append_match(rule, "", "")
    assert rule == []
    append_match(rule, "", "match")
    assert rule == []
    append_match(rule, "match", "match")
    assert rule == ['-m','match']



# Generated at 2022-06-23 03:48:27.260924
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']


# Generated at 2022-06-23 03:48:29.097281
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, 'connmark', 'connmark')
    assert rule == ['-m', 'connmark']
    rule = []
    append_match(rule, None, 'connmark')
    assert rule == []



# Generated at 2022-06-23 03:48:33.376030
# Unit test for function append_param
def test_append_param():
    rule = []
    param = None
    append_param(rule, param, '--tcp-flags', False)
    assert rule == []
    rule = []
    param = '!ACK'
    append_param(rule, param, '--tcp-flags', False)
    assert rule == ['!', '--tcp-flags', 'ACK']
    rule = []
    param = 'ACK'
    append_param(rule, param, '--tcp-flags', False)
    assert rule == ['--tcp-flags', 'ACK']
    rule = []
    param = ['ACK', '!SYN']
    append_param(rule, param, '--tcp-flags', True)
    assert rule == ['--tcp-flags', 'ACK', '!', '--tcp-flags', 'SYN']



# Generated at 2022-06-23 03:48:35.422319
# Unit test for function append_jump
def test_append_jump():
    rule = []
    jump = 'ACCEPT'
    append_jump(rule, jump, jump)
    assert rule == ['-j', 'ACCEPT']


# Generated at 2022-06-23 03:48:36.998281
# Unit test for function append_jump
def test_append_jump():
    rule = []
    jump = 'ACCEPT'
    param = 'ACCEPT'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'ACCEPT']



# Generated at 2022-06-23 03:48:45.284109
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule({
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'jump': 'ACCEPT',
        'destination_port': '8080',
        'action':'insert',
        'rule_num': '5'
    })
    iptables_path = 'iptables'
    params = module.params
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['iptables', '-t', params['table'], '-I', params['chain'], params['rule_num'], '-p', params['protocol'], '--dport', params['destination_port'], '-j', params['jump']]



# Generated at 2022-06-23 03:48:58.777704
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-23 03:49:01.799045
# Unit test for function append_tcp_flags
def test_append_tcp_flags():  # pragma: no cover
    rule = []
    param = dict(flags=['ACK', 'SYN'], flags_set=['SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    print(rule)



# Generated at 2022-06-23 03:49:07.059497
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.params = dict(
        chain='INPUT',
        table='filter',
        to_source='192.168.1.0/24',
        jump='ACCEPT',
        ipv4_bin='iptables',
        ipv6_bin='ip6tables',
    )

    iptables_path = module.params['ipv4_bin']
    assert(check_present(iptables_path, module, module.params))
# End of unit test


# Generated at 2022-06-23 03:49:11.363820
# Unit test for function construct_rule

# Generated at 2022-06-23 03:49:23.445887
# Unit test for function append_match_flag
def test_append_match_flag():
    test_rule = []

    append_match_flag(test_rule, 'match', '--match', True)
    assert test_rule == ['--match']
    test_rule = []
    append_match_flag(test_rule, 'negate', '--match', True)
    assert test_rule == ['!', '--match']
    test_rule = []
    append_match_flag(test_rule, 'nonmatch', '--match', True)
    assert test_rule == []
    test_rule = []
    append_match_flag(test_rule, 'nonmatch', '--match', False)
    assert test_rule == []

    try:
        append_match_flag(test_rule, 'nonmatch', '--match', True)
    except TypeError:
        pass
    else:
        raise TypeError

# Generated at 2022-06-23 03:49:35.795469
# Unit test for function main
def test_main():
    # Initialize iptables params for testing.
    module_args = dict(
        table='nat',
        ip_version='ipv4',
        chain='OUTPUT',
        action='append',
        protocol='tcp',
        destination='192.168.0.2',
        destination_port='22',
        in_interface='eth0',
        jump='ACCEPT',
        match='state',
        src_range='10.1.1.1-192.168.0.100'
    )


# Generated at 2022-06-23 03:49:38.302629
# Unit test for function append_param
def test_append_param():
    rule = []
    the_param = '--dport'
    the_flag = '22'
    append_param(rule, the_param, the_flag, False)
    assert rule == ['--dport', '22']
    rule = []
    the_param = '22'
    the_flag = '--dport'
    append_param(rule, the_param, the_flag, False)
    assert rule == ['--dport', '22']


# Generated at 2022-06-23 03:49:45.256713
# Unit test for function get_chain_policy
def test_get_chain_policy():
    mg = get_chain_policy(None, None, dict(table='filter', chain='INPUT'))
    assert mg == 'ACCEPT'
    mg = get_chain_policy(None, None, dict(table='filter', chain='new'))
    assert mg is None
    mg = get_chain_policy(None, None, dict(table='filter', chain='FORWARD'))
    assert mg == 'ACCEPT'



# Generated at 2022-06-23 03:49:53.913090
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = [{"flags": "ALL", "flags_set": ["ACK","RST","SYN","FIN"]}, "AND", {"flags": "ALL", "flags_set": ["SYN","RST"]}]
    flag = "--tcp-flags"
    append_tcp_flags(rule,param,flag)
    print("The result is " + str(rule))


# Generated at 2022-06-23 03:49:55.211246
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    assert append_tcp_flags(rule, "test", "test") == true



# Generated at 2022-06-23 03:49:59.258184
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, '80', '--dport', False)
    assert ['--dport', '80'] == rule
    append_param(rule, '80', '--d', False)
    assert ['--dport', '80', '--d', '80'] == rule
    append_param(rule, '!80', '--dport', False)
    assert ['--dport', '80', '--d', '80', '!', '--dport', '80'] == rule
    append_param(rule, ['80','81','82'], '--dport', True)

# Generated at 2022-06-23 03:50:04.764908
# Unit test for function append_param
def test_append_param():
    rule = []
    item_list = ['tcp', 'udp', 'sctp']
    append_param(rule, item_list, '-p', True)
    assert(rule == ['-p', 'tcp', '-p', 'udp', '-p', 'sctp'])


# Generated at 2022-06-23 03:50:06.828911
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '1', 'test')
    assert rule == ['test', '1']


# Generated at 2022-06-23 03:50:11.761650
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, 'm')
    assert rule == ['-m', 'm']
    rule = []
    append_match(rule, False, 'm')
    assert rule == []


# Generated at 2022-06-23 03:50:16.903879
# Unit test for function insert_rule

# Generated at 2022-06-23 03:50:28.237333
# Unit test for function construct_rule
def test_construct_rule():
    '''
    Unit test for function construct_rule
    '''
    params = {
        'ip_version': 'ipv4',
        'protocol': 'tcp',
        'destination': '203.0.113.5',
        'destination_port': '8080',
        'jump': 'ACCEPT',
    }
    rule = construct_rule(params)
    expected_rule = ['-p', 'tcp', '-d', '203.0.113.5', '--dport', '8080', '-j', 'ACCEPT']
    assert rule == expected_rule

    params.update({
        'limit': '10/sec',
        'limit_burst': '100',
        'syn': 'match',
        'comment': 'test',
    })
    rule = construct_rule(params)

# Generated at 2022-06-23 03:50:29.539425
# Unit test for function remove_rule
def test_remove_rule():
    module = AnsibleModule({})
    params = {
        'table': 'filter'
    }
    assert remove_rule("iptables", module, params) is None


# Generated at 2022-06-23 03:50:42.453140
# Unit test for function main

# Generated at 2022-06-23 03:50:57.836172
# Unit test for function check_present
def test_check_present():
    test_dict = {
        'chain': 'test_chain',
        'protocol': '',
        'source': '',
        'destination': '',
        'match': '',
        'jump': '',
        'table': 'filter',
        'in_interface': '',
        'out_interface': '',
        'destination_port': '',
        'uid_owner': '',
        'gid_owner': '',
        'set_dscp_mark': '',
        'set_dscp_mark_class': '',
        'ctstate': '',
        'source_port': '',
        'limit': '',
        'limit_burst': '',
        'syn': ''}
    return check_present('iptables', '', test_dict)


# Generated at 2022-06-23 03:50:58.641412
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(None, None) == ("1.4.21\n")



# Generated at 2022-06-23 03:51:03.129266
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    iptables_path = 'iptables'
    iptables_version = get_iptables_version(iptables_path, module)
    assert iptables_version != None



# Generated at 2022-06-23 03:51:04.531138
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = 5
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule == ['--wait', '5']
    return rule


# Generated at 2022-06-23 03:51:12.682541
# Unit test for function main
def test_main():
    ipv4_result = dict(
        changed=False,
        failed=False,
        ip_version='ipv4',
        table='filter',
        chain='test',
        flush=False,
        rule='-A test',
        state='present',
    )
    ipv6_result = dict(
        changed=False,
        failed=False,
        ip_version='ipv6',
        table='filter',
        chain='test',
        flush=False,
        rule='-A test',
        state='present',
    )

    # Update
    ipv4_result_update = ipv4_result.copy()
    ipv4_result_update['changed'] = True
    ipv6_result_update = ipv6_result.copy()
    ipv6_result_update['changed']

# Generated at 2022-06-23 03:51:17.370081
# Unit test for function set_chain_policy
def test_set_chain_policy():
    print("Running test case for set_chain_policy")
    assert set_chain_policy("iptables", module=Mock("module"), params="params")
    print("Test case for set_chain_policy successful")


# Generated at 2022-06-23 03:51:22.093902
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = 1
    flag = '-w'
    append_wait(rule, param, flag)
    assert rule == ['-w', param]
test_append_wait()



# Generated at 2022-06-23 03:51:25.480137
# Unit test for function append_wait
def test_append_wait():
    temp_rule = []
    append_wait(temp_rule, '1', '-w')
    assert temp_rule == ['-w', '1']


# Generated at 2022-06-23 03:51:28.479023
# Unit test for function append_match
def test_append_match():
    assert(append_match('iptables -v -I INPUT -p tcp -m tcp') == 'iptables -v -I INPUT -p tcp')


# Generated at 2022-06-23 03:51:32.845728
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'ACCEPT'
    jump = 'accept'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'accept']


# Generated at 2022-06-23 03:51:36.714256
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/my/iptables'
    module = object()
    params = {'table': 'nat', 'chain': 'OUTPUT'}
    flush_table(iptables_path, module, params)
    assert module.run_command.call_args[0] == [
        iptables_path, '-t', params['table'], '-F', params['chain']
    ]



# Generated at 2022-06-23 03:51:37.676717
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', None, {'ip_version': 'ipv4', 'chain': 'test'}) == None



# Generated at 2022-06-23 03:51:40.537953
# Unit test for function flush_table
def test_flush_table():
    expected_cmd = ['iptables', '-F', 'test_chain']
    params = dict(chain='test_chain')
    assert flush_table('iptables', '', params) == expected_cmd



# Generated at 2022-06-23 03:51:43.159420
# Unit test for function main
def test_main():
  class Args:
    check_mode = False
    debug = False
  module = AnsibleModule(argument_spec={})
  module.params = {}
  args = Args()
  main()


# Generated at 2022-06-23 03:51:47.782686
# Unit test for function append_csv
def test_append_csv():
    append_csv(['iptables','-A', 'INPUT'], ['2','3','4','5'], '--protocol')
    assert ['iptables','-A', 'INPUT','--protocol','2,3,4,5']



# Generated at 2022-06-23 03:51:58.965177
# Unit test for function append_param
def test_append_param():
    cases = dict(
        positive=[['--foo', 'bar'], '!', '--foo', ['bar', 'baz']],
        positive_edge=[['--foo', 'bar'], '!', '--foo', ['bar', '!baz']],
        negative=[['--foo', 'bar'], '!', '--foo', ['!bar', 'baz']],
        negative_edge=[['--foo', 'bar'], '!', '--foo', ['!bar', '!baz']],
    )

    for case_name, case in cases.items():
        for retries in range(10):
            test_rule = list(case[:2])
            append_param(test_rule, case[3], case[2], is_list=True)

# Generated at 2022-06-23 03:52:02.487418
# Unit test for function append_csv
def test_append_csv():
    assert append_csv([], None, '--flag') == []
    assert append_csv([], [], '--flag') == []
    assert append_csv([], ['a', 'b'], '--flag') == ['--flag', 'a,b']


# Generated at 2022-06-23 03:52:08.108736
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, None, '--syn', True)
    assert rule == []

# Get the version of the iptables CLI.

# Generated at 2022-06-23 03:52:15.557167
# Unit test for function check_present
def test_check_present():
    module = MagicMock()
    module.run_command.return_value = (0, "", "")
    params = dict(
        chain = 'RH-Firewall-1-INPUT',
        ip_version = 'ipv4',
        protocol = 'tcp',
        destination_port = [80],
        table = 'filter',
        jump = 'ACCEPT',
    )
    iptables_path= '/sbin/iptables'
    assert check_present(iptables_path, module, params)

# Generated at 2022-06-23 03:52:18.340039
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = DummyModule()
    print("The version of iptables is " + get_iptables_version("/usr/sbin/iptables", module))


# Generated at 2022-06-23 03:52:19.357734
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', 'INPUT') == 'ACCEPT'



# Generated at 2022-06-23 03:52:23.951444
# Unit test for function push_arguments
def test_push_arguments():
    import shlex
    params = dict(chain='INPUT',
                  table='filter',
                  in_interface='eth0',
                  source='1.2.3.4',
                  protocol='tcp',
                  destination_port=22,
                  ctstate='NEW',
                  syn='match'
                  )
    expected_cmd = dict(
        ipv4='iptables -t filter -I INPUT -i eth0 -p tcp -s 1.2.3.4 --dport 22 -m conntrack --ctstate NEW --syn -j ACCEPT',
        ipv6='ip6tables -t filter -I INPUT -i eth0 -p tcp -s 1.2.3.4 --dport 22 -m conntrack --ctstate NEW --syn -j ACCEPT',
    )

# Generated at 2022-06-23 03:52:33.432127
# Unit test for function check_present
def test_check_present():
    module = MockAnsibleModule()
    iptables_path = 'iptables'

# Generated at 2022-06-23 03:52:39.134964
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({})
    version = get_iptables_version(None, module)
    assert version
# End of test_get_iptables_version



# Generated at 2022-06-23 03:52:51.146953
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = ['test',
            'test',
            'test']
    param = "match"
    flag = "test"
    negatable = False
    # result = append_match_flag(rule, param, flag, negatable)
    # assert result == [ 'test', 'test', 'test', 'test']
    rule = ['test',
            'test',
            'test']
    param = "match"
    flag = "test"
    negatable = True
    # result = append_match_flag(rule, param, flag, negatable)
    # assert result == [ 'test', 'test', 'test', 'test', 'test']
    rule = ['test',
            'test',
            'test']
    param = "negate"
    flag = "test"
    negatable = True
    # result = append_

# Generated at 2022-06-23 03:53:02.640917
# Unit test for function main

# Generated at 2022-06-23 03:53:04.556087
# Unit test for function append_jump
def test_append_jump():
    assert ['-j', 'DROP'] == append_jump([], 'DROP', 'DROP')


# Generated at 2022-06-23 03:53:07.620016
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], None, '', True) == []
    assert append_match_flag([], 'match', '', True) == ['match']
    assert append_match_flag([], 'negate', '', True) == ['!', 'match']



# Generated at 2022-06-23 03:53:12.001481
# Unit test for function push_arguments

# Generated at 2022-06-23 03:53:13.439259
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy("", ["-P", "filter", "DROP"], {"policy": "DROP"}) == ["-P", "filter", "DROP"]
# Unit testing for function flush_table

# Generated at 2022-06-23 03:53:15.314279
# Unit test for function check_present
def test_check_present():
    assert check_present(1,1,1) == False


# Generated at 2022-06-23 03:53:19.460687
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = '1,2,3'
    flag = '-A'
    result=['-A', '1,2,3']
    append_csv(rule, param, flag)
    assert rule == result, 'append_csv fail!'


# Generated at 2022-06-23 03:53:22.983851
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule()
    params = {'chain' : 'INPUT', 'table' : 'filter'}
    append_rule(iptables_path, module, params)



# Generated at 2022-06-23 03:53:35.815067
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        source='192.168.0.0/24',
        destination='192.168.0.0/24',
        protocol='tcp',
        in_interface='eth0',
        out_interface='eth1',
        source_port='53',
        destination_port='53',
        jump='ACCEPT',
        comment='Allow DNS lookups'
    )

# Generated at 2022-06-23 03:53:44.162513
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.network.firewall.ansible_firewall import check_present

# Generated at 2022-06-23 03:53:57.207305
# Unit test for function append_wait
def test_append_wait():
   #Currently it only supports two types of tests, add more if needed.
   #First: Iptables module doesn't support --wait flag at all.
   rule = ['iptables', '-A', 'INPUT', '-i', 'eth0', '-p', 'tcp', '-m', 'multiport', '--dport', '61155:61159,61160:61164', '-j', 'ACCEPT']
   ans1=append_wait(rule,'5', '--wait')
   expected_output_ans1=['iptables', '-A', 'INPUT', '-i', 'eth0', '-p', 'tcp', '-m', 'multiport', '--dport', '61155:61159,61160:61164', '-j', 'ACCEPT']


# Generated at 2022-06-23 03:54:10.036072
# Unit test for function push_arguments
def test_push_arguments():

    params = dict(
        ip_version = 'ipv4',
        table = 'filter',
        chain = 'INPUT',
        protocol = 'tcp',
        destination_port = '80',
        ctstate = 'NEW',
        syn = 'match',
        jump = 'ACCEPT',
        comment = 'Accept new SSH connections.'
    )
    command_1 = push_arguments(iptables_path = 'iptables', action = '-A', params = params, make_rule = True)


# Generated at 2022-06-23 03:54:14.129275
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']

    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']



# Generated at 2022-06-23 03:54:17.019476
# Unit test for function append_rule
def test_append_rule():
  module=AnsibleModule()
  assert check_present(BINS[params['ip_version']], module, params) == False
  assert append_rule(BINS[params['ip_version']], module, params) == 0


# Generated at 2022-06-23 03:54:26.159460
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = None
    module = None
    params = {
        'ip_version': 'ipv4',
        'chain': 'INPUT',
        'table': 'filter',
    }
    test_data = """Chain INPUT (policy DROP)
target     prot opt source               destination
ACCEPT     all  --  anywhere             anywhere             ctstate RELATED,ESTABLISHED
ACCEPT     icmp --  anywhere             anywhere
"""
    assert get_chain_policy(iptables_path, module, params) == 'DROP'



# Generated at 2022-06-23 03:54:30.382186
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN'],
    )
    append_tcp_flags(rule, param, "--tcp-flags")
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-23 03:54:39.823216
# Unit test for function main

# Generated at 2022-06-23 03:54:53.838404
# Unit test for function append_match_flag

# Generated at 2022-06-23 03:54:58.378302
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ["ACCEPT", "DROP"]
    flag = "--jump"
    append_csv(rule, param, flag)
    assert rule == ['--jump', 'ACCEPT,DROP']


# Generated at 2022-06-23 03:55:03.957060
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(['iptables'],False, 'test',True) == ['iptables']
    assert append_match_flag(['iptables'], 'match', 'test', True) == ['iptables','test']


# Generated at 2022-06-23 03:55:10.016559
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['NEW', 'RELATED', 'ESTABLISHED'], '--ctstate')
    assert rule == ['--ctstate', 'NEW,RELATED,ESTABLISHED']



# Generated at 2022-06-23 03:55:23.926633
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = 1
    append_wait(rule, param, '--wait')
    assert rule == ['--wait', '1']
    rule = []
    param = '1'
    append_wait(rule, param, '--wait')
    assert rule == ['--wait', '1']
    rule = []
    param = '1/second'
    append_wait(rule, param, '--wait')
    assert rule == ['--wait', '1/second']
    rule = []
    param = '1/s'
    append_wait(rule, param, '--wait')
    assert rule == ['--wait', '1/second']
    rule = []
    param = '1/minute'
    append_wait(rule, param, '--wait')
    assert rule == ['--wait', '1/minute']

# Generated at 2022-06-23 03:55:34.161816
# Unit test for function set_chain_policy

# Generated at 2022-06-23 03:55:37.105495
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({})
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        policy='DROP'
    )
    assert set_chain_policy('iptables', module, params) == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-23 03:55:49.028100
# Unit test for function main

# Generated at 2022-06-23 03:55:53.530061
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = 'iptables'
    module = 'AnsibleModule'
    params = dict(
        table='filter',
        chain='INPUT'
        )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT'], cmd


# Generated at 2022-06-23 03:55:59.001874
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, 'test')
    assert rule == ['-m', 'test']
    rule = []
    append_match(rule, False, 'test')
    assert rule == []



# Generated at 2022-06-23 03:56:05.930891
# Unit test for function append_csv
def test_append_csv():
    test_rule = []
    test_param = ['udp','tcp','sctp']
    test_flag = '-p'
    append_csv(test_rule, test_param, test_flag)
    assert test_rule == ['-p','udp,tcp,sctp']



# Generated at 2022-06-23 03:56:12.956720
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, None, '--syn', True)
    assert len(rule) == 0
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']


# Generated at 2022-06-23 03:56:20.316477
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/usr/bin/iptables', '1.4.7') == '1.4.7'
    assert get_iptables_version('/sbin/iptables', '1.4.7') == '1.4.7'
    assert get_iptables_version('/usr/sbin/iptables', '1.4.7') == '1.4.7'
    assert get_iptables_version('/bin/iptables', '1.4.7') == '1.4.7'



# Generated at 2022-06-23 03:56:25.962601
# Unit test for function append_jump
def test_append_jump():
    rule = []
    jump = 'ACCEPT'
    append_jump(rule,jump,jump)
    assert rule == ['-j','ACCEPT']


# Generated at 2022-06-23 03:56:38.311366
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict()
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['protocol'] = 'tcp'
    params['source'] = '188.0.0.6'
    params['destination'] = None
    params['jump'] = None
    params['log_prefix'] = None
    params['log_level'] = None
    params['to_destination'] = None
    params['destination_ports'] = None
    params['to_source'] = None
    params['goto'] = None
    params['in_interface'] = None
    params['out_interface'] = None
    params['fragment'] = None
    params['source_port']

# Generated at 2022-06-23 03:56:49.990739
# Unit test for function construct_rule

# Generated at 2022-06-23 03:56:51.735461
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('/sbin/iptables', module, params) == None


# Generated at 2022-06-23 03:56:56.723951
# Unit test for function append_jump
def test_append_jump():
    ''' assert append_jump function'''
    rule = []
    param = 'ACCEPT'
    jump = 'ACCEPT'
    result = ['-j', 'ACCEPT']
    append_jump(rule, param, jump)
    assert rule == result
    return 0



# Generated at 2022-06-23 03:57:09.051983
# Unit test for function get_iptables_version
def test_get_iptables_version():
    import sys
    import os
    import ansible.module_utils.ansible_release
    import ansible.module_utils.basic
    import ansible.module_utils.network.common.utils
    class FakeModule():
        def __init__(self, check=False):
            self.check_mode = check
            self.exit_json = \
                            ansible.module_utils.basic.AnsibleModule.exit_json
            self.fail_json = \
                            ansible.module_utils.basic.AnsibleModule.fail_json
            self.run_command = run_command
            self.params = {}
    class FakeResult():
        def __init__(self, returncode, out, err):
            self.returncode = returncode
            self.stdout = out
            self.stderr = err

# Generated at 2022-06-23 03:57:10.409569
# Unit test for function flush_table
def test_flush_table():
    command = ["/sbin/iptables","-t","nat","-F","--","an_unknown_flag"]
    return command



# Generated at 2022-06-23 03:57:22.901066
# Unit test for function insert_rule
def test_insert_rule():
    module = "AnsibleModule"
    params = {
        'chain':'OUTPUT',
        'destination':'192.168.1.1',
        'destination_port':'22',
        'ip_version':'ipv4',
        'jump':'ACCEPT',
        'match':'tcp',
        'reject_with':'',
        'state':'present',
        'table':'filter',
        'rule_num':'1',
        'protocol':'tcp'
        }
    iptables_path = 'iptables'
    cmd = [iptables_path]
    cmd.extend(['-t', params['table']])
    cmd.extend(['-I', params['chain']])

# Generated at 2022-06-23 03:57:29.785647
# Unit test for function flush_table
def test_flush_table():
    assert(push_arguments('iptables', '-F',
                          {'table': 'filter',
                           'chain': 'INPUT'}, make_rule=False)
           == ['iptables', '-t', 'filter', '-F', 'INPUT'])



# Generated at 2022-06-23 03:57:33.963763
# Unit test for function append_csv
def test_append_csv():
    assert append_csv(['test rule'], ['hello', 'world'], 'testflag') == ['test rule', 'testflag', 'hello,world']

    assert append_csv(['test rule'], ['hello'], 'testflag') == ['test rule', 'testflag', 'hello']

    assert append_csv(['test rule'], [], 'testflag') == ['test rule']


# Generated at 2022-06-23 03:57:36.585964
# Unit test for function append_jump
def test_append_jump():
    rule = []
    jump = 'DROP'
    append_jump(rule, True, jump)
    assert rule == ['-j', jump]


# Generated at 2022-06-23 03:57:47.510971
# Unit test for function insert_rule
def test_insert_rule():
    params = {'table':'filter', 'chain':'INPUT', 'protocol':'tcp', 'destination_port':'8080', 'jump':'ACCEPT', 'rule_num':'5'}
    iptables_path = "iptables"
    module = AnsibleModule(argument_spec = {'table':{'required':False,'default':'filter'},
                                            'chain':{'required':True},
                                            'protocol':{'required':False,'default':None},
                                            'destination_port':{'required':False,'default':None},
                                            'jump':{'required':True},
                                            'rule_num':{'required':True},
                                            },
                           supports_check_mode=False)    

# Generated at 2022-06-23 03:57:55.290761
# Unit test for function append_csv
def test_append_csv():
    test_rules = []
    append_csv(test_rules, ['NEW'], '--ctstate')
    assert test_rules == ['--ctstate', 'NEW']
    test_rules = []
    append_csv(test_rules, ['NEW', 'ESTABLISHED'], '--ctstate')
    assert test_rules == ['--ctstate', 'NEW,ESTABLISHED']
