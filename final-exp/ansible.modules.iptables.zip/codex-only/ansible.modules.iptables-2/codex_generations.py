

# Generated at 2022-06-23 03:48:00.752061
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # Access params passed to module
    module.params['ip_version'] = 'ipv4'
    module.params['table'] = 'filter'
    module.params['flush'] = True

    # Access function main
    flush_table = module.get_bin_path('iptables', True)
    rc, out, err = module.run_command([flush_table, '-F', '-t', module.params['table']], check_rc=False)
    assert rc == 0, "iptables flush command should return 0"

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:48:08.593781
# Unit test for function get_iptables_version
def test_get_iptables_version():
    out = u'iptables v1.4.21\n'
    test_module = object()
    test_module.run_command = lambda *args, **kwargs: (0, out, '')
    assert get_iptables_version(None, test_module) == '1.4.21'



# Generated at 2022-06-23 03:48:20.516323
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    m = AnsibleModule(argument_spec={})
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['SYN', 'FIN'])
    append_tcp_flags(rule, param, '-m', 'tcp', '--tcp-flags')
    assert rule == ['-m', 'tcp', '--tcp-flags', 'ACK,RST,SYN,FIN', 'SYN,FIN']

    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['!SYN', 'FIN'])
    append_tcp_flags(rule, param, '-m', 'tcp', '--tcp-flags')

# Generated at 2022-06-23 03:48:25.875454
# Unit test for function append_jump
def test_append_jump():
    assert append_jump(['iptables', '-I', 'INPUT'], 'ACCEPT', 'ACCEPT') == ['iptables', '-I', 'INPUT', '-j', 'ACCEPT']
    assert append_jump(['iptables', '-I', 'INPUT'], None, 'ACCEPT') == ['iptables', '-I', 'INPUT']



# Generated at 2022-06-23 03:48:29.973739
# Unit test for function append_param
def test_append_param():
    rule1 = []
    rule2 = []
    param = '80'
    flag = '--dport'
    expected1 = ['--dport', '80']

    append_param(rule1, None, flag, False)
    append_param(rule2, param, flag, False)
    assert rule1 == []
    assert rule2 == expected1

    param = ['80', '443']
    rule1 = []
    rule2 = []
    append_param(rule1, None, flag, True)
    append_param(rule2, param, flag, True)
    expected1 = ['--dport', '80', '--dport', '443']
    assert rule1 == []
    assert rule2 == expected1

    param = '!80'
    rule1 = []
    rule2 = []

# Generated at 2022-06-23 03:48:40.329062
# Unit test for function construct_rule
def test_construct_rule():

    params = {}
    args = construct_rule(params)
    assert args == []

    params = dict(
        chain="INPUT",
        protocol="tcp",
        destination="8.8.8.8",
        jump="DROP",
    )
    args = construct_rule(params)
    assert args == ['-p', 'tcp', '-d', '8.8.8.8', '-j', 'DROP']

    params = dict(
        chain="INPUT",
        protocol="tcp",
        destination_port="80",
        jump="ACCEPT",
    )
    args = construct_rule(params)
    assert args == ['-p', 'tcp', '--dport', '80', '-j', 'ACCEPT']


# Generated at 2022-06-23 03:48:41.561822
# Unit test for function append_jump
def test_append_jump():
    rule = ['-A']
    append_jump(rule, 'ACCEPT', 'ACCEPT')
    assert rule == ['-A', '-j', 'ACCEPT']



# Generated at 2022-06-23 03:48:42.777677
# Unit test for function check_present
def test_check_present():
    assert False, check_present(None, None, None)


# Generated at 2022-06-23 03:48:48.037469
# Unit test for function append_jump
def test_append_jump():
    rule=['-A', 'INPUT']
    param='ACCEPT'
    append_jump(rule, param, param)
    expected=['-A', 'INPUT', '-j', 'ACCEPT']
    assert rule == expected



# Generated at 2022-06-23 03:48:49.273963
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = ''
    module = ''
    params = ''
    remove_rule(iptables_path, module, params)



# Generated at 2022-06-23 03:48:53.725446
# Unit test for function check_present
def test_check_present():
    module_mock = AnsibleModule({
        'insert_rule': '-A',
        'state': 'present',
        'chain': 'INPUT',
        'match': 'comment',
        'comment': 'Created by Ansible',
    })
    module_mock.run_command = lambda _, check_rc=True: [0, '', '']
    rc = check_present('iptables', module_mock, dict(
        insert_rule='-A',
        state='present',
        chain='INPUT',
        match='comment',
        comment='Created by Ansible',
    ))
    assert rc



# Generated at 2022-06-23 03:49:03.873946
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    # for both flags and flags_set
    param = dict(flags=['ack'],
                 flags_set=['ack'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK', 'ACK']
    rule = []
    # for only flags_set
    param = dict(flags_set=['ack'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', '', 'ACK']
    rule = []
    # for only flags
    param = dict(flags=['ack'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK', '']



# Generated at 2022-06-23 03:49:05.586264
# Unit test for function append_jump
def test_append_jump():
    rule = list()
    append_jump(rule, 'ACCEPT', 'ACCEPT')
    assert rule == ['-j', 'ACCEPT']


# Generated at 2022-06-23 03:49:08.523631
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:49:17.241733
# Unit test for function main
def test_main():
    with patch('ansible.modules.network.iptables.iptables_raw'):
        with patch('ansible.modules.network.iptables_raw.AnsibleModule'):
            with patch('ansible.modules.network.iptables_raw.get_bin_path'):
                import ansible.modules.network.iptables_raw as iptables_raw
                mod = ansible.modules.network.iptables_raw.AnsibleModule
                iptables_raw.main()


# Generated at 2022-06-23 03:49:24.176511
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', 'module', {
        'table': 'nat',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '443',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.'
    }) == False



# Generated at 2022-06-23 03:49:28.540038
# Unit test for function get_chain_policy
def test_get_chain_policy():
  if get_chain_policy('/bin/iptables', '', {
    'chain': 'INPUT'
  }) is None:
    return False
  return True



# Generated at 2022-06-23 03:49:35.343965
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--some-flag', True)
    assert rule == ['--some-flag']

    rule = []
    append_match_flag(rule, 'negate', '--some-flag', True)
    assert rule == ['!', '--some-flag']

    rule = []
    append_match_flag(rule, 'negate', '--some-flag', False)
    assert rule == []



# Generated at 2022-06-23 03:49:39.074500
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', test_module) == '1.4.21'
    assert get_iptables_version('ip6tables', test_module) == '1.4.21'

# Generated at 2022-06-23 03:49:42.166608
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule,"10","-w")
    assert rule == ["-w","10"]


# Generated at 2022-06-23 03:49:45.995400
# Unit test for function append_param
def test_append_param():
    assert append_param(['iptables'], 'test', '--test', False) == ['iptables', '--test', 'test']
    assert append_param(['iptables'], '!test', '--test', False) == ['iptables', '!', '--test', 'test']
    assert append_param(['iptables'], ['test1', 'test2'], '--test', True) == ['iptables', '--test', 'test1', '--test', 'test2']
    assert append_param(['iptables'], ['test1', 'test2'], '--test', True) == ['iptables', '--test', 'test1', '--test', 'test2']



# Generated at 2022-06-23 03:49:58.536873
# Unit test for function set_chain_policy
def test_set_chain_policy():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO
    class MockModule:
        def __init__(self):
            self.version_added = IPTABLES_WAIT_WITH_SECONDS_SUPPORTED_ADDED
            self.run_command = lambda x, check_rc=False: (0, "", "")
        def exit_json(self, **kwargs):
            return
        def fail_json(self, **kwargs):
            return
        def run_command(self, cmd, check_rc=True, **kwargs):
            return (0, "", "")

# Generated at 2022-06-23 03:50:04.861120
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = object()
    iptables_path = 'iptables'
    version_string = '1.4.21'
    setattr(module, 'run_command', lambda x, y=None: (0, 'v' + version_string, ''))
    assert(get_iptables_version(iptables_path, module) == version_string)



# Generated at 2022-06-23 03:50:07.668190
# Unit test for function append_param
def test_append_param():
    assert append_param([], '-m state --state NEW', '-m', False) == ['-m', 'state', '--state', 'NEW']
    assert append_param([], ['NEW', 'ESTABLISHED'], '-m', True) == ['-m', 'state', '--state', 'NEW', '-m', 'state', '--state', 'ESTABLISHED']
    assert append_param([], '!NEW', '-m', False) == ['-m', '!', 'state', '--state', 'NEW']



# Generated at 2022-06-23 03:50:13.378201
# Unit test for function insert_rule
def test_insert_rule():
    print(insert_rule('iptables', 'module', {'table':'nat', 'chain':'PREROUTING', 'in_interface':'eth0', 'protocol':'tcp', 'match':'tcp', 'destination_port':'80', 'jump':'REDIRECT', 'to_ports':'8600', 'comment':'Redirect web traffic to port 8600'}))



# Generated at 2022-06-23 03:50:22.008193
# Unit test for function push_arguments
def test_push_arguments():
  params = {
    'ip_version': 'ipv4',
    'chain': 'INPUT',
    'protocol': 'tcp',
    'destination_port': '22',
    'ctstate': 'NEW',
    'syn': 'match',
    'jump': 'ACCEPT',
    'comment': 'Accept new SSH connections.'
  }
  expected_rule = ['-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']
  assert(construct_rule(params) == expected_rule)


# Generated at 2022-06-23 03:50:27.418945
# Unit test for function append_rule

# Generated at 2022-06-23 03:50:36.336443
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, None, '--ctstate')
    assert rule == []
    rule = []
    append_csv(rule, [], '--ctstate')
    assert rule == []
    rule = []
    append_csv(rule, ['NEW'], '--ctstate')
    assert rule == ['--ctstate', 'NEW']
    rule = []
    append_csv(rule, ['NEW', 'ESTABLISHED', 'RELATED'], '--ctstate')
    assert rule == ['--ctstate', 'NEW,ESTABLISHED,RELATED']
    rule = []
    append_csv(rule, ['NEW', '!', 'ESTABLISHED', 'RELATED'], '--ctstate')
    assert rule == ['--ctstate', 'NEW,!ESTABLISHED,RELATED']


# Generated at 2022-06-23 03:50:39.236561
# Unit test for function get_chain_policy
def test_get_chain_policy():
    get_chain_policy('iptables', 'dummy', {'table': 'filter', 'chain': 'INPUT'})
    get_chain_policy('iptables', 'dummy', {'table': 'filter', 'chain': 'FORWARD'})
    get_chain_policy('iptables', 'dummy', {'table': 'filter', 'chain': 'OUTPUT'})
    


# Generated at 2022-06-23 03:50:51.257799
# Unit test for function main
def test_main():
    """
    Unit test for function main
    This function is called during test execution.
    """

# Generated at 2022-06-23 03:51:05.962391
# Unit test for function construct_rule
def test_construct_rule():
    import pytest
    # test with IPV4
    rule = construct_rule(
        {
            'ip_version': 'ipv4',
            'protocol': 'tcp',
            'source': '8.8.8.8',
            'jump': 'DROP',
            'comment': 'Test comment',
        }
    )

    assert rule == ['-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP', '--comment',
                    'Test comment']

    # test with IPV6

# Generated at 2022-06-23 03:51:07.730267
# Unit test for function append_match
def test_append_match():
    params = dict(port_range='client 123')
    rule = []
    append_match(rule, params, 'tcp')
    assert rule == '-m tcp --dport 123'.split()



# Generated at 2022-06-23 03:51:12.575571
# Unit test for function append_param
def test_append_param():
    rule = []
    param = ['-m', 'comment', '-m', 'comment']
    flag = '-m'
    is_list = True
    append_param(rule, param, flag, is_list)
    assert rule == ['-m', 'comment', '-m', 'comment']



# Generated at 2022-06-23 03:51:13.801401
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = list()
    append_match_flag(rule, 'match', '--syn', True)
    assert rule[0] == '--syn'



# Generated at 2022-06-23 03:51:21.395799
# Unit test for function set_chain_policy
def test_set_chain_policy():
    x=set_chain_policy("ipv4",None,"DROP")
    y=set_chain_policy("ipv4",None,"ACCEPT")
    z=set_chain_policy("ipv4",None,"QUEUE")
    if x == y:
        print("test_set_chain_policy: Ok")
    else:
        print("test_set_chain_policy: Failed")
#test_set_chain_policy()

# Generated at 2022-06-23 03:51:28.505038
# Unit test for function main

# Generated at 2022-06-23 03:51:39.790533
# Unit test for function construct_rule

# Generated at 2022-06-23 03:51:46.630057
# Unit test for function construct_rule

# Generated at 2022-06-23 03:51:57.127360
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        comment='testing rule',
        protocol='tcp',
        destination_port=8080,
        jump='ACCEPT',
        state='present',
        action='insert',
        rule_num=5,
    )
    assert push_arguments('iptables', '-I', params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT', '-m',
        'comment', '--comment', 'testing rule']



# Generated at 2022-06-23 03:52:08.619134
# Unit test for function append_rule
def test_append_rule():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.ansible_iptables
    # AnsibleModule.run_command() takes optional argument "check_rc=False" to
    # avoid throwing exception when command returns non-zero.
    # The problem is AnsibleModule class does not define this argument, so the
    # example code in the documentation does not even compile.
    #
    # The fix was to add this argument to the module class definition:
    #
    # def run_command(self, cmd, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None):
    #         # used by all modules that need command line tools run
    #         return run

# Generated at 2022-06-23 03:52:18.742139
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec=dict(ip_version=dict(required=True, choices=['ipv4', 'ipv6'])))

# Generated at 2022-06-23 03:52:21.226439
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.4.21'

# Generated at 2022-06-23 03:52:31.997241
# Unit test for function append_param
def test_append_param():
    assert append_param([], 'foo', 'foo', False) == ['foo', 'foo']
    assert append_param([], '!foo', 'foo', False) == ['!', 'foo', 'foo']
    assert append_param([], ['foo', 'bar'], 'foo', True) == ['foo', 'foo', 'foo', 'bar']
    assert append_param([], [], 'foo', True) == []
    assert append_param([], None, 'foo', True) == []
    assert append_param([], ['!foo', '!bar'], 'foo', True) == ['!', 'foo', 'foo', '!', 'foo', 'bar']



# Generated at 2022-06-23 03:52:38.403958
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/sbin/iptables'
    action = '-A'

# Generated at 2022-06-23 03:52:46.589767
# Unit test for function append_rule
def test_append_rule():
    import unittest.mock as mock
    with mock.patch('ansible.module_utils.basic.AnsibleModule') as mod:
        mod.return_value = mod
        obj = IptablesModule(mod)
    cmd = obj.push_arguments('iptables', '-A', obj.params)
    assert '-I' not in cmd
    assert '-t' in cmd
    assert '-A' in cmd
    assert 'INPUT' in cmd
    assert '-s' in cmd
    assert '8.8.8.8' in cmd
    assert '-j' in cmd
    assert 'DROP' in cmd



# Generated at 2022-06-23 03:52:51.449568
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['ACK', 'RST'], 'flags_set': ['SYN', 'FIN']}
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST', 'SYN,FIN']
    param = {'flags': ['ACK', 'RST'], 'flags_set': []}
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST', 'SYN,FIN', '--tcp-flags', 'ACK,RST']
    param = {}
    append_tcp_flags(rule, param, '--tcp-flags')

# Generated at 2022-06-23 03:52:57.083349
# Unit test for function insert_rule
def test_insert_rule():
    # init params
    iptables_path = ''
    class module(object):
        def run_command(self, cmd, check_rc=True):
            return(0,1,2)
    params = dict(
        table = 'filter',
        chain = 'INPUT',
        protocol = 'tcp',
        jump = 'ACCEPT',
        destination_port = 80,
        action = 'insert',
        rule_num = 5,
    ) 
    assert 0 == insert_rule(iptables_path, module, params)


# Generated at 2022-06-23 03:53:03.137024
# Unit test for function construct_rule

# Generated at 2022-06-23 03:53:13.175162
# Unit test for function construct_rule
def test_construct_rule():
    params = {
        'ip_version': 'ipv4',
        'jump': 'reject',
        'protocol': 'tcp',
        'destination_port': '8080'
    }
    iptables_bin = 'iptables'
    params['chain'] = 'INPUT'
    params['jump'] = None
    rule = construct_rule(params)
    assert rule == ['iptables', '-w', '-p', 'tcp', '--dport', '8080', '-j', 'REJECT']
    # --reject-with option
    params['jump'] = 'reject'
    rule = construct_rule(params)

# Generated at 2022-06-23 03:53:14.245903
# Unit test for function append_jump
def test_append_jump():
    expected_rule = ['-j', 'ACCEPT']
    assert append_jump([], 'ACCEPT', None) == expected_rule
# Test End


# Generated at 2022-06-23 03:53:16.512509
# Unit test for function append_jump
def test_append_jump():
    assert append_jump([], 'ACCEPT', 'ACCEPT') == ['-j', 'ACCEPT']



# Generated at 2022-06-23 03:53:29.289132
# Unit test for function construct_rule

# Generated at 2022-06-23 03:53:33.629931
# Unit test for function append_jump
def test_append_jump():
    assert append_jump([], 'ACCEPT', 'ACCEPT') == ['-j', 'ACCEPT']
    assert append_jump([], 'DROP', 'DROP') == ['-j', 'DROP']



# Generated at 2022-06-23 03:53:37.673109
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda *args, **kwargs: (0, 'iptables v1.4.20', '')
    assert '1.4.20' == get_iptables_version('iptables', module)



# Generated at 2022-06-23 03:53:43.373773
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule=[]
#    rule=append_tcp_flags(rule, {'flags':'ACK','flags_set':'ACK'})
#    assert rule == ['--match','tcp','--tcp-flags','ACK','ACK']
    rule=append_tcp_flags(rule, {'flags': 'ALL','flags_set': ['ACK','RST','SYN','FIN']}, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']
    return


# Generated at 2022-06-23 03:53:50.719747
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/ip6tables', None) == '1.4.21'
    assert get_iptables_version('/sbin/iptables', None) == '1.4.21'



# Generated at 2022-06-23 03:53:59.953118
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain':'INPUT', 'policy': 'DROP'}) == 'DROP'
    assert get_chain_policy(None, None, {'chain':'OUTPUT', 'policy': 'ACCEPT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain':'OUTPUT', 'policy': 'FORWARD'}) == None



# Generated at 2022-06-23 03:54:10.590497
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['ESTABLISHED'], '--ctstate')
    assert rule == ['--ctstate', 'ESTABLISHED'], \
        "Expected, ['--ctstate', 'ESTABLISHED']; got %s" % rule

######################################################################
# This function serves as a template for sub-class functions to allow
# handling of modules for both IPv4 and IPv6.
# --------------------------------------------------------------------
# Inputs:
#    module   - AnsibleModule object
#    bin_name - The name of the associated executable
#    icmp_type_option - The option name used to specify "icmp-type"
# --------------------------------------------------------------------
# Returns:
#    rc       - 0 if successful, non-zero otherwise
######################################################################

# Generated at 2022-06-23 03:54:18.866910
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = 'iptables-save'
    module = mock.Mock()
    params = dict(
    chain='INPUT',
    protocol='tcp',
    source='10.10.10.10',
    destination='20.20.20.20',
    jump='DROP',
    table='filter')
    expected_cmd = ['iptables', '-t', 'filter', '-D', 'INPUT', '-p', 'tcp', '-s', '10.10.10.10', '-d', '20.20.20.20', '-j', 'DROP']
    assert remove_rule(iptables_path, module, params) == None
    assert module.run_command.call_args[0][0] == expected_cmd


# Generated at 2022-06-23 03:54:32.253633
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'iptables'

# Generated at 2022-06-23 03:54:38.475151
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP'
    )
    assert(check_present('iptables', module, params) == False)


# Generated at 2022-06-23 03:54:48.577838
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    flag = '--syn'
    negatable = True
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['--syn']
    rule = []
    param = 'negate'
    flag = '--syn'
    negatable = True
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['!', '--syn']



# Generated at 2022-06-23 03:54:51.465441
# Unit test for function append_match
def test_append_match():
    test_rule = []
    assert test_rule == append_match(test_rule, False, "match")
    assert test_rule == []
    test_rule = []
    assert test_rule == append_match(test_rule, True, "match")
    assert test_rule == ['-m', 'match']



# Generated at 2022-06-23 03:54:52.443467
# Unit test for function append_wait
def test_append_wait():
    result = []
    append_wait(result, '1', '--wait')
    assert result == ['--wait', '1']



# Generated at 2022-06-23 03:54:56.935273
# Unit test for function append_csv
def test_append_csv():
    assert ['a', 'b', 'c'] == append_csv([], ['a', 'b', 'c'], 'test')
    assert ['test', 'a,b,c'] == append_csv([], 'a,b,c', 'test')
    assert ['test', 'a'] == append_csv([], 'a', 'test')
    assert ['test', 'a,b,c'] == append_csv([], 'a,b,c', 'test')
    assert ['test', 'a', 'b', 'c'] == append_csv([], 'a,b,c', 'test', True)



# Generated at 2022-06-23 03:55:03.454372
# Unit test for function check_present
def test_check_present():
    assert(check_present('iptables', None, {'chain': 'INPUT', 'table': 'filter', 'protocol': 'tcp', 'destination_port': '22'}) == False)
test_check_present()



# Generated at 2022-06-23 03:55:11.106421
# Unit test for function append_jump
def test_append_jump():
    args = ['INPUT', 'tcp', '80', 'ACCEPT']
    # execute the function
    result = []
    append_jump_result = append_jump(result, args[3], 'ACCEPT')
    # assert that append_jump_result equals to the expected value
    assert (append_jump_result == None)
    assert (result == ['-j', 'ACCEPT'])

# Generated at 2022-06-23 03:55:19.492278
# Unit test for function main

# Generated at 2022-06-23 03:55:22.904772
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = [ "--protocol" , "tcp"]
    append_match_flag(rule, 'match' , "--syn" , True)
    assert rule == ["--protocol", "tcp", "--syn"]


# Generated at 2022-06-23 03:55:33.699102
# Unit test for function check_present
def test_check_present():
    def _run_command(cmd, check_rc=True):
        if cmd[-1] == 'good':
            return 0, ''
        else:
            return 1, ''

    module = type('AnsibleModule', (object,), {'run_command': _run_command})
    params = {
        'action': 'append',
        'chain': 'INPUT',
        'comment': 'Ansible',
        'destination': '1.1.1.1',
        'jump': 'ACCEPT',
        'protocol': None,
        'table': 'filter',
        'rule_num': None,
    }
    assert check_present('iptables', module, params)
    params['chain'] = 'BAD'
    assert not check_present('iptables', module, params)



# Generated at 2022-06-23 03:55:38.073054
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/sbin/iptables'
    module = AnsibleModule(argument_spec={'test': {'required': True}})
    params = dict(table='filter', chain='INPUT', ip_version='ipv4')
    remove_rule(iptables_path, module, params)


# Generated at 2022-06-23 03:55:41.624576
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], 'match', '-p', True) == ['-p']
    assert append_match_flag([], 'negate', '-p', True) == ['!', '-p']


# Generated at 2022-06-23 03:55:47.690342
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        reject_with='tcp-reset'
    )
    cmd = push_arguments('iptables', '-I', params)
    assert set(cmd) == {'iptables', '-t', 'filter', '-I', 'INPUT', '-p', 'tcp', '-j', 'REJECT', '--reject-with', 'tcp-reset'}



# Generated at 2022-06-23 03:55:52.634181
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec={'chain': {'type': 'str'}, 'table': {'type': 'str'},
                       'ip_version': {'type': 'str'}})
    params = dict(chain='FORWARD', table='filter', ip_version='ipv4')
    if not check_present('iptables', module, params):
        module.fail_json(msg='Unit test failed: Function check_present failed')
    module.exit_json(changed=False)



# Generated at 2022-06-23 03:55:59.851524
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, dict(flags=['ACK', 'RST'], flags_set=['ACK', 'SYN']), '--tcp-flags')
    assert(rule == ['--tcp-flags', 'ACK,RST', 'ACK,SYN'])



# Generated at 2022-06-23 03:56:05.024366
# Unit test for function append_csv
def test_append_csv():
  rule = []
  param = ['ESTABLISHED', 'RELATED']
  flag = '--match'
  append_csv(rule, param, flag)
  assert rule == ['--match', 'ESTABLISHED,RELATED']


# Generated at 2022-06-23 03:56:07.389017
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, "10", '--wait')
    assert rule == ['--wait', '10']



# Generated at 2022-06-23 03:56:20.617524
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/usr/bin/iptables'
    action = '-A'
    params = dict(chain='INPUT', ip_version='ipv4')
    cmd = push_arguments(iptables_path, action, params)
    assert cmd == [iptables_path, '-t', 'filter', action, 'INPUT']
    params = dict(chain='INPUT', ip_version='ipv4', rule_num='1')
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == [iptables_path, '-t', 'filter', '-I', 'INPUT', '1']
    params = dict(chain='INPUT', ip_version='ipv6', rule_num='1')

# Generated at 2022-06-23 03:56:27.493050
# Unit test for function append_param
def test_append_param():
    rule = []
    param = ['!foo', 'bar']
    flag = '--foo'
    is_list = True
    assert append_param(rule, param, flag, is_list) == rule.extend(['!', flag, param[0][1:], flag, param[1]])


# Generated at 2022-06-23 03:56:39.637009
# Unit test for function set_chain_policy

# Generated at 2022-06-23 03:56:51.353372
# Unit test for function insert_rule

# Generated at 2022-06-23 03:56:57.105057
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path='/usr/sbin/iptables'
    module=AnsibleModule
    params={'table': 'filter', 'chain': 'INPUT', 'source': '8.8.8.8', 'jump': 'DROP'}
    assert remove_rule(iptables_path, module, params)=='No match'


# Generated at 2022-06-23 03:57:05.071357
# Unit test for function flush_table
def test_flush_table():
    params = dict(table='nat', chain='PREROUTING', flush=False)
    assert flush_table('iptables', None, params) == 'iptables -t nat -F PREROUTING'
    params = dict(table='nat', chain='PREROUTING', flush=True)
    assert flush_table('iptables', None, params) == 'iptables -t nat -F'



# Generated at 2022-06-23 03:57:07.717384
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', {'run_command': run_command}, {'protocol': 'tcp'}) == True



# Generated at 2022-06-23 03:57:09.287282
# Unit test for function append_wait
def test_append_wait():
    rule=[]
    append_wait(rule, '10', '--wait')
    assert rule == ['--wait', '10']



# Generated at 2022-06-23 03:57:11.934310
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, 'match')
    assert rule == ['-m', 'match']



# Generated at 2022-06-23 03:57:24.175595
# Unit test for function main

# Generated at 2022-06-23 03:57:31.458235
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/usr/bin/iptables'
    table = 'filter'
    chain = 'INPUT'
    params = dict(table=table, chain=chain)
    cmd = push_arguments(iptables_path, '-F', params, make_rule=False)
    assert cmd == ['/usr/bin/iptables', '-t', table, '-F', chain]



# Generated at 2022-06-23 03:57:43.547137
# Unit test for function main
def test_main():
    '''Unit test for main'''
    # Create the module object

# Generated at 2022-06-23 03:57:44.914336
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', object, object, object) is None



# Generated at 2022-06-23 03:57:49.556329
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['1', '2', '3'], '-p')
    assert rule == ['-p', '1,2,3']



# Generated at 2022-06-23 03:58:01.056223
# Unit test for function push_arguments
def test_push_arguments():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        log_prefix='[IPTABLES-TEST]',
        log_level='info',
        ip_version='ipv4',
    )
    cmd = push_arguments('/usr/sbin/iptables', '-A', params)