

# Generated at 2022-06-17 04:44:44.019880
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']


# Generated at 2022-06-17 04:44:47.822693
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:44:58.348448
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:03.356519
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', '-C', {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == True


# Generated at 2022-06-17 04:45:04.186936
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:45:14.412760
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []
    rule = []
    append_match_flag(rule, '', '--syn', True)
    assert rule == []
    rule = []
    append_match_flag(rule, '', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:45:22.146105
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str', required=True),
        policy=dict(type='str', required=True),
        table=dict(type='str', default='filter'),
        ip_version=dict(type='str', default='ipv4'),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    set_chain_policy(iptables_path, module, params)
    assert True



# Generated at 2022-06-17 04:45:31.922536
# Unit test for function push_arguments

# Generated at 2022-06-17 04:45:38.859214
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments('iptables', module, params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--dport', '8080',
        '-j', 'ACCEPT',
    ]



# Generated at 2022-06-17 04:45:49.379620
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:46:10.367712
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:21.897047
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:26.484042
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']


# Generated at 2022-06-17 04:46:32.838416
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5'
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--destination-port', '8080', '-j', 'ACCEPT']


# Generated at 2022-06-17 04:46:40.368739
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='Block specific IP',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == [
        '-p', 'tcp',
        '-s', '8.8.8.8',
        '-j', 'DROP',
        '-m', 'comment',
        '--comment', 'Block specific IP',
    ]



# Generated at 2022-06-17 04:46:52.956857
# Unit test for function main

# Generated at 2022-06-17 04:47:02.966914
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'LOGGING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FOO'}) is None



# Generated at 2022-06-17 04:47:08.815540
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:47:10.996292
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-17 04:47:16.308610
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(iptables_path, module, params) == cmd



# Generated at 2022-06-17 04:47:50.355242
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:02.334505
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'foo', '--foo', False)
    assert rule == ['--foo', 'foo']
    rule = []
    append_param(rule, '!foo', '--foo', False)
    assert rule == ['!', '--foo', 'foo']
    rule = []
    append_param(rule, ['foo', 'bar'], '--foo', True)
    assert rule == ['--foo', 'foo', '--foo', 'bar']
    rule = []
    append_param(rule, ['!foo', '!bar'], '--foo', True)
    assert rule == ['!', '--foo', 'foo', '!', '--foo', 'bar']



# Generated at 2022-06-17 04:48:11.587276
# Unit test for function main

# Generated at 2022-06-17 04:48:16.006125
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(iptables_path, module, params) == cmd



# Generated at 2022-06-17 04:48:28.114193
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:28.851518
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True



# Generated at 2022-06-17 04:48:34.728921
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:40.034137
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == ['iptables', '-t', 'filter', '-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP']



# Generated at 2022-06-17 04:48:47.791407
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        ip_version='ipv4',
    )
    assert construct_rule(params) == [
        '-w', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT', '-I', 'INPUT', '5']



# Generated at 2022-06-17 04:48:51.265985
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='Block specific IP',
    )
    rule = construct_rule(params)
    assert rule == ['-s', '8.8.8.8', '-p', 'tcp', '-j', 'DROP', '-m', 'comment', '--comment', 'Block specific IP']



# Generated at 2022-06-17 04:49:18.895828
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', '-A', 'INPUT') == 'iptables -A INPUT'
    assert append_rule('iptables', '-A', 'INPUT', '-s', '192.168.1.1') == 'iptables -A INPUT -s 192.168.1.1'
    assert append_rule('iptables', '-A', 'INPUT', '-s', '192.168.1.1', '-j', 'DROP') == 'iptables -A INPUT -s 192.168.1.1 -j DROP'

# Generated at 2022-06-17 04:49:22.351398
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(None, None, {'policy': 'ACCEPT', 'chain': 'INPUT'}) == [None, '-t', 'filter', '-P', 'INPUT', 'ACCEPT']



# Generated at 2022-06-17 04:49:25.952594
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/sbin/iptables'
    module = AnsibleModule({})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '22',
        'ctstate': 'NEW',
        'syn': 'match',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.'
    }
    remove_rule(iptables_path, module, params)



# Generated at 2022-06-17 04:49:37.251860
# Unit test for function construct_rule

# Generated at 2022-06-17 04:49:38.358948
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:49:48.215732
# Unit test for function main

# Generated at 2022-06-17 04:49:57.621975
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'table': 'nat', 'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'table': 'nat', 'chain': 'POSTROUTING'}) == 'ACCEPT'

# Generated at 2022-06-17 04:50:00.877515
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:50:07.793802
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict(
        table=dict(default='filter'),
        chain=dict(default='INPUT'),
        flush=dict(default=False),
        policy=dict(default=None),
        wait=dict(default=None),
    ))
    params = module.params
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:50:21.616775
# Unit test for function main

# Generated at 2022-06-17 04:51:14.600413
# Unit test for function main

# Generated at 2022-06-17 04:51:23.729718
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:31.005816
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:51:33.526850
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:51:41.131515
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(required=True, type='str'),
        policy=dict(required=True, type='str', choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        table=dict(required=False, type='str', default='filter'),
        ip_version=dict(required=False, type='str', default='ipv4'),
        wait=dict(required=False, type='str'),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-17 04:51:41.825072
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None


# Generated at 2022-06-17 04:51:53.751945
# Unit test for function main

# Generated at 2022-06-17 04:52:01.297394
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--destination-port', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:52:10.003816
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate='NEW',
        jump='ACCEPT',
        in_interface='eth0',
        out_interface='eth1',
        source_port='80',
        destination_port='8080',
        comment='This is a test rule',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:52:21.617839
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'policy': 'ACCEPT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'policy': 'DROP'}) == 'DROP'
    assert get_chain_policy(None, None, {'policy': 'QUEUE'}) == 'QUEUE'
    assert get_chain_policy(None, None, {'policy': 'RETURN'}) == 'RETURN'
    assert get_chain_policy(None, None, {'policy': 'ACCEPT'}) != 'DROP'
    assert get_chain_policy(None, None, {'policy': 'DROP'}) != 'ACCEPT'
    assert get_chain_policy(None, None, {'policy': 'QUEUE'}) != 'RETURN'
    assert get_chain_policy