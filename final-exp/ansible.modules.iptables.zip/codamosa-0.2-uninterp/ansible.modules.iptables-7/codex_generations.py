

# Generated at 2022-06-17 04:44:43.904368
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        rule_num=5,
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--dport', '80',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.',
    ]



# Generated at 2022-06-17 04:44:53.756480
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:45:05.702889
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:15.871291
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:24.723815
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:45:30.185416
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', 'iptables v1.6.0') == '1.6.0'
    assert get_iptables_version('iptables', 'iptables v1.4.20') == '1.4.20'
    assert get_iptables_version('iptables', 'iptables v1.4.19') == '1.4.19'



# Generated at 2022-06-17 04:45:36.548098
# Unit test for function push_arguments

# Generated at 2022-06-17 04:45:38.116386
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', {'chain':'INPUT', 'table':'filter'}) == True


# Generated at 2022-06-17 04:45:45.350882
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:45:51.896034
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:09.327534
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--destination-port', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:46:15.924175
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)


# Generated at 2022-06-17 04:46:24.068692
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-17 04:46:28.604860
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == True
    assert check_present('iptables', '-C', {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == True

# Generated at 2022-06-17 04:46:29.762096
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:46:35.527202
# Unit test for function main

# Generated at 2022-06-17 04:46:41.404420
# Unit test for function main

# Generated at 2022-06-17 04:46:44.084715
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == [
        'iptables',
        '-t',
        'filter',
        '-A',
        'INPUT',
        '-p',
        'tcp',
        '-s',
        '8.8.8.8',
        '-j',
        'DROP',
        '--comment',
        'Block specific IP'
    ]



# Generated at 2022-06-17 04:46:49.518374
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 04:46:55.143314
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:47:14.895262
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN']
    )
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:47:19.674430
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-17 04:47:27.878618
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='OUTPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='FORWARD', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='INPUT', table='nat')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='OUTPUT', table='nat')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='PREROUTING', table='nat')) == 'ACCEPT'

# Generated at 2022-06-17 04:47:33.307561
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'ACCEPT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'DROP'}) == 'DROP'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'QUEUE'}) == 'QUEUE'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'RETURN'}) == 'RETURN'



# Generated at 2022-06-17 04:47:46.131009
# Unit test for function main

# Generated at 2022-06-17 04:47:49.347002
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:48:02.550348
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate='NEW',
        jump='ACCEPT',
        comment='Accept new TCP connections',
    )
    assert construct_rule(params) == [
        '-p', 'tcp',
        '-s', '192.168.1.1',
        '-d', '192.168.1.2',
        '-m', 'tcp',
        '-m', 'state',
        '--state', 'NEW',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new TCP connections',
    ]



# Generated at 2022-06-17 04:48:12.799542
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'

# Generated at 2022-06-17 04:48:15.147708
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('/sbin/iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:48:26.706321
# Unit test for function construct_rule

# Generated at 2022-06-17 04:49:08.282281
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='remove',
        rule_num=5
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)


# Generated at 2022-06-17 04:49:18.445663
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:49:27.428418
# Unit test for function construct_rule

# Generated at 2022-06-17 04:49:28.575015
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', 'module', 'params') == '-A INPUT -p tcp -s 8.8.8.8 -j DROP'



# Generated at 2022-06-17 04:49:42.251433
# Unit test for function construct_rule

# Generated at 2022-06-17 04:49:43.758115
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:49:54.242535
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:01.397733
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        chain='INPUT',
        policy='DROP',
    )
    cmd = push_arguments('iptables', '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:50:10.523583
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'

# Generated at 2022-06-17 04:50:23.175096
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:30.571958
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'

# Generated at 2022-06-17 04:51:40.757800
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:49.533659
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)


# Generated at 2022-06-17 04:51:55.862399
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule(iptables_path, module, params) == [iptables_path, '-t', params['table'], '-I', params['chain'], params['rule_num'], '-p', params['protocol'], '-s', params['source'], '-d', params['destination'], '-m', 'conntrack', '--ctstate', ','.join(params['ctstate']), '-j', params['jump'], '--to-ports', params['to_ports'], '-m', 'comment', '--comment', params['comment']]



# Generated at 2022-06-17 04:52:05.843970
# Unit test for function main

# Generated at 2022-06-17 04:52:07.166345
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:52:11.091844
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:52:20.404384
# Unit test for function main

# Generated at 2022-06-17 04:52:30.008875
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '--dport', '80', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-17 04:52:40.796031
# Unit test for function construct_rule

# Generated at 2022-06-17 04:53:44.199462
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        flush=True,
    )
    iptables_path = 'iptables'
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:53:45.109018
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -P params'



# Generated at 2022-06-17 04:53:55.854493
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        ip_version='ipv4',
    )
    assert construct_rule(params) == ['-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP']

    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        ip_version='ipv6',
    )
    assert construct_rule(params) == ['-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP']


# Generated at 2022-06-17 04:54:04.347133
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'nat', 'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'nat', 'chain': 'POSTROUTING'}) == 'ACCEPT'