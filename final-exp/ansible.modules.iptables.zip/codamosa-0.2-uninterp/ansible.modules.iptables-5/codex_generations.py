

# Generated at 2022-06-17 04:44:31.638280
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=1,
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    assert push_arguments('iptables', '-I', params) == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '1',
        '-p', 'tcp',
        '--destination-port', '80',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.'
    ]



# Generated at 2022-06-17 04:44:40.391472
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    assert construct_rule(params) == ['-w', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:44:44.180588
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', 'iptables v1.4.21') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.6.0') == '1.6.0'



# Generated at 2022-06-17 04:44:51.770790
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:45:02.686431
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'foo', '--foo', False)
    assert rule == ['--foo', 'foo']
    rule = []
    append_param(rule, '!foo', '--foo', False)
    assert rule == ['!', '--foo', 'foo']
    rule = []
    append_param(rule, ['foo', 'bar'], '--foo', True)
    assert rule == ['--foo', 'foo', '--foo', 'bar']
    rule = []
    append_param(rule, ['!foo', '!bar'], '--foo', True)
    assert rule == ['!', '--foo', 'foo', '!', '--foo', 'bar']



# Generated at 2022-06-17 04:45:06.958231
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:45:19.167250
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test', '--test', False)
    assert rule == ['--test', 'test']
    rule = []
    append_param(rule, '!test', '--test', False)
    assert rule == ['!', '--test', 'test']
    rule = []
    append_param(rule, ['test1', 'test2'], '--test', True)
    assert rule == ['--test', 'test1', '--test', 'test2']
    rule = []
    append_param(rule, ['!test1', '!test2'], '--test', True)
    assert rule == ['!', '--test', 'test1', '!', '--test', 'test2']



# Generated at 2022-06-17 04:45:27.694157
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:45:34.702763
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ALL'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:45:39.129263
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP') == True
    assert check_present('iptables', '-C', 'INPUT', '-s', '8.8.8.8', '-j', 'ACCEPT') == False


# Generated at 2022-06-17 04:46:21.008468
# Unit test for function main

# Generated at 2022-06-17 04:46:32.026419
# Unit test for function main

# Generated at 2022-06-17 04:46:35.254994
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-w', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:46:39.821904
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:46:40.996159
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:46:53.564204
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:47:03.940119
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:47:11.749190
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='remove',
        rule_num=5,
        ip_version='ipv4',
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)
    #module.run_command(cmd, check_rc=True)



# Generated at 2022-06-17 04:47:21.764545
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str', required=True),
        policy=dict(type='str', required=True, choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        table=dict(type='str', default='filter'),
        ip_version=dict(type='str', default='ipv4', choices=['ipv4', 'ipv6']),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-17 04:47:32.775706
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:12.484777
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', 'module', 'params') == True



# Generated at 2022-06-17 04:48:21.084950
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)


# Generated at 2022-06-17 04:48:30.758969
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:31.874592
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:48:33.015593
# Unit test for function append_rule
def test_append_rule():
    assert append_rule(iptables_path, module, params) == cmd



# Generated at 2022-06-17 04:48:37.472821
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:48:44.545810
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='remove',
        rule_num=5
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)
    #module.run_command(cmd, check_rc=True)


# Generated at 2022-06-17 04:48:48.070751
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:48:57.381815
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
        wait=None,
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)


# Generated at 2022-06-17 04:49:06.712170
# Unit test for function main

# Generated at 2022-06-17 04:50:22.361676
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={
        'chain': {'required': True},
        'table': {'default': 'filter'},
        'ip_version': {'default': 'ipv4'},
    })
    params = module.params
    iptables_path = BINS[params['ip_version']]
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:50:34.631816
# Unit test for function main

# Generated at 2022-06-17 04:50:38.918714
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:50:48.868629
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:49.860883
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:50:53.128744
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:51:03.911409
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Allow established and related connections',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:51:13.122805
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:21.924947
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:31.039890
# Unit test for function main