

# Generated at 2022-06-17 04:44:43.661081
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num='5',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='Test comment',
    )
    assert push_arguments('iptables', '-I', params) == [
        'iptables',
        '-t',
        'filter',
        '-I',
        'INPUT',
        '5',
        '-p',
        'tcp',
        '--destination-port',
        '8080',
        '-j',
        'ACCEPT',
        '-m',
        'comment',
        '--comment',
        'Test comment',
    ]



# Generated at 2022-06-17 04:44:50.312887
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate='NEW',
        jump='ACCEPT',
        comment='Accept new TCP connections',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:44:55.274736
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:45:00.146871
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('/sbin/iptables', '-I', dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port=8080,
        jump='ACCEPT',
    )) == [
        '/sbin/iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--destination-port', '8080',
        '-j', 'ACCEPT',
    ]



# Generated at 2022-06-17 04:45:06.833882
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:45:15.675133
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        rule_num='1',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='Block specific IP',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '1',
        '-p', 'tcp',
        '-s', '8.8.8.8',
        '-j', 'DROP',
        '-m', 'comment',
        '--comment', 'Block specific IP',
    ]



# Generated at 2022-06-17 04:45:17.197265
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:45:18.010420
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:45:25.614576
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        table='filter',
        chain='INPUT',
        policy='DROP',
        ip_version='ipv4',
    )
    iptables_path = BINS[params['ip_version']]
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:45:31.031009
# Unit test for function append_rule

# Generated at 2022-06-17 04:45:44.179213
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', {'chain': 'INPUT', 'table': 'filter'}) == True


# Generated at 2022-06-17 04:45:46.022188
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:45:55.869125
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:45:57.831076
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'ACCEPT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:46:08.244605
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:21.612945
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Allow established connections',
    )

# Generated at 2022-06-17 04:46:32.636652
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:37.413038
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:46:45.504876
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'remove',
        'rule_num': '5',
    }
    cmd = push_arguments(iptables_path, '-D', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-D', 'INPUT', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:46:53.555509
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:47:45.667564
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='OUTPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='FORWARD', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='INPUT', table='nat')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='OUTPUT', table='nat')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='PREROUTING', table='nat')) == 'ACCEPT'

# Generated at 2022-06-17 04:47:55.765884
# Unit test for function remove_rule
def test_remove_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
        wait=None,
    )
    iptables_path = '/sbin/iptables'
    cmd = push_arguments(iptables_path, '-D', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-D', 'INPUT', '-p', 'tcp', '--dport', '80', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-17 04:48:07.381231
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:21.892506
# Unit test for function main

# Generated at 2022-06-17 04:48:31.441040
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['NEW', 'ESTABLISHED'],
        jump='ACCEPT',
        comment='This is a test',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:48:39.860466
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        chain='INPUT',
        policy='DROP',
        table='filter',
    )
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:48:41.545479
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:48:42.785859
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:48:47.243349
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:48:54.193885
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={
        'table': {'required': True, 'type': 'str'},
        'chain': {'required': True, 'type': 'str'},
        'ip_version': {'required': True, 'type': 'str'},
    })
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'ip_version': 'ipv4',
    }
    flush_table('iptables', module, params)



# Generated at 2022-06-17 04:49:21.772186
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'DROP'
    assert get_chain_policy(None, None, {'chain': 'FOO'}) is None



# Generated at 2022-06-17 04:49:30.431170
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', '-A', 'INPUT') == 'iptables -A INPUT'
    assert append_rule('iptables', '-A', 'INPUT', '-p', 'tcp') == 'iptables -A INPUT -p tcp'
    assert append_rule('iptables', '-A', 'INPUT', '-p', 'tcp', '-s', '192.168.1.1') == 'iptables -A INPUT -p tcp -s 192.168.1.1'

# Generated at 2022-06-17 04:49:42.412052
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:49:53.575388
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:00.452497
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:50:09.557198
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:50:12.395546
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    insert_rule(iptables_path, module, params)



# Generated at 2022-06-17 04:50:20.005383
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        chain='INPUT',
        policy='DROP',
    )
    cmd = push_arguments('iptables', '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:50:24.604321
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:28.372865
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', 'module', 'params') == True


# Generated at 2022-06-17 04:51:32.847998
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:51:35.272892
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'INPUT', 'policy': 'DROP'}) == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:51:37.735368
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:51:44.363270
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:51:48.881989
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FOO'}) == None



# Generated at 2022-06-17 04:51:51.480395
# Unit test for function append_rule
def test_append_rule():
    assert append_rule(1,2,3) == None


# Generated at 2022-06-17 04:51:59.955368
# Unit test for function main

# Generated at 2022-06-17 04:52:07.422386
# Unit test for function main

# Generated at 2022-06-17 04:52:15.475759
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', '-A', 'INPUT', '-s', '192.168.1.1', '-j', 'DROP') == ['iptables', '-A', 'INPUT', '-s', '192.168.1.1', '-j', 'DROP']



# Generated at 2022-06-17 04:52:25.683701
# Unit test for function construct_rule

# Generated at 2022-06-17 04:53:19.102773
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-17 04:53:29.027314
# Unit test for function main

# Generated at 2022-06-17 04:53:39.234520
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Allow established and related connections',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:53:40.318091
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:53:45.642581
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '80', 'jump': 'ACCEPT'}) == False
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '80', 'jump': 'ACCEPT', 'rule_num': '5'}) == False
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '80', 'jump': 'ACCEPT', 'rule_num': '5', 'source': '8.8.8.8'}) == False

# Generated at 2022-06-17 04:53:46.520405
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:53:56.607917
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', 'iptables v1.4.21') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.4.21 (nf_tables)') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.4.21 (nf_tables)\n') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.4.21 (nf_tables)\n\n') == '1.4.21'



# Generated at 2022-06-17 04:54:00.591631
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:54:06.534216
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw', 'security']),
        chain=dict(required=True),
        ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
        wait=dict(type='str'),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    flush_table(iptables_path, module, params)

