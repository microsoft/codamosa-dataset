

# Generated at 2022-06-17 04:44:38.731583
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port=8080,
        jump='ACCEPT',
        comment='Test rule',
    )
    assert push_arguments('iptables', '-I', params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp',
        '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment',
        'Test rule'
    ]



# Generated at 2022-06-17 04:44:41.073787
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('iptables', 'module', 'params') == '-I'



# Generated at 2022-06-17 04:44:46.616648
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:44:50.190773
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:44:58.070875
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        chain='INPUT',
        policy='DROP',
        table='filter',
        ip_version='ipv4',
    )
    iptables_path = BINS[params['ip_version']]
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:45:02.975099
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        ip_version='ipv4',
    )
    expected = ['-w', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']
    assert construct_rule(params) == expected



# Generated at 2022-06-17 04:45:12.829282
# Unit test for function main

# Generated at 2022-06-17 04:45:24.559723
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:45:25.926741
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:45:38.412832
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']
    rule = []
    param = {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'RST', 'SYN']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)

# Generated at 2022-06-17 04:45:57.017502
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        chain='INPUT',
        policy='DROP',
        table='filter',
    )
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:45:57.992898
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', 'INPUT') == True


# Generated at 2022-06-17 04:46:05.572801
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num='5',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='test comment',
        ip_version='ipv4',
    )
    assert push_arguments('iptables', '-I', params) == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--destination-port', '8080',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'test comment',
    ]



# Generated at 2022-06-17 04:46:13.102422
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []


# Generated at 2022-06-17 04:46:21.108414
# Unit test for function main

# Generated at 2022-06-17 04:46:22.935736
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('/sbin/iptables', 'module', 'params') == None


# Generated at 2022-06-17 04:46:32.523340
# Unit test for function main

# Generated at 2022-06-17 04:46:38.183677
# Unit test for function main

# Generated at 2022-06-17 04:46:48.858668
# Unit test for function main

# Generated at 2022-06-17 04:46:57.839252
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:47:16.308302
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == [
        'iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP', '--comment', 'Block specific IP'
    ]



# Generated at 2022-06-17 04:47:27.081722
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(type='str', required=True),
        chain=dict(type='str', required=True),
        ip_version=dict(type='str', required=True),
        wait=dict(type='str'),
    ))
    module.params['table'] = 'filter'
    module.params['chain'] = 'INPUT'
    module.params['ip_version'] = 'ipv4'
    module.params['wait'] = '10'
    iptables_path = BINS[module.params['ip_version']]
    flush_table(iptables_path, module, module.params)



# Generated at 2022-06-17 04:47:28.099347
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:47:35.348731
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        ip_version='ipv4',
    )
    assert construct_rule(params) == [
        '-A', 'INPUT', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT'
    ]

    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        ip_version='ipv6',
    )

# Generated at 2022-06-17 04:47:39.685903
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', '1.4.21') == '1.4.21'
    assert get_iptables_version('iptables', '1.4.21\n') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.4.21\n') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.4.21') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.4.21\n\n') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.4.21\n\n\n') == '1.4.21'
    assert get_ipt

# Generated at 2022-06-17 04:47:40.343102
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:47:47.818149
# Unit test for function append_rule

# Generated at 2022-06-17 04:47:51.269789
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '--dport', '80', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-17 04:48:04.264753
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:08.012592
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:48:34.389361
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:48:42.341105
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict(
        chain=dict(required=True, type='str'),
        policy=dict(required=True, type='str'),
    ))
    params = dict(
        chain='INPUT',
        policy='DROP',
    )
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-17 04:48:48.447613
# Unit test for function main

# Generated at 2022-06-17 04:48:59.892075
# Unit test for function construct_rule

# Generated at 2022-06-17 04:49:09.715582
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='test comment',
        ip_version='ipv4',
    )
    assert construct_rule(params) == [
        '-p', 'tcp',
        '-s', '8.8.8.8',
        '-j', 'DROP',
        '-m', 'comment',
        '--comment', 'test comment',
    ]

    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='test comment',
        ip_version='ipv6',
    )

# Generated at 2022-06-17 04:49:15.445572
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FOO'}) is None



# Generated at 2022-06-17 04:49:25.236352
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['NEW', 'ESTABLISHED'],
        jump='ACCEPT',
        comment='Test rule',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:49:36.654548
# Unit test for function main

# Generated at 2022-06-17 04:49:38.174354
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('iptables', 'module', 'params') == '-I'



# Generated at 2022-06-17 04:49:48.062475
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:50:42.881867
# Unit test for function main

# Generated at 2022-06-17 04:50:53.623507
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == False
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == False

# Generated at 2022-06-17 04:50:58.249630
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
    )
    flush_table('iptables', module, params)



# Generated at 2022-06-17 04:51:01.178739
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'


# Generated at 2022-06-17 04:51:07.760685
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str', required=True),
        policy=dict(type='str', required=True),
        table=dict(type='str', default='filter'),
        ip_version=dict(type='str', default='ipv4'),
        wait=dict(type='str'),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-17 04:51:17.228675
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw', 'security']),
        chain=dict(required=True),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:51:22.377537
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec={})
    assert check_present('iptables', module, {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.',
    }) == False



# Generated at 2022-06-17 04:51:31.352046
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:37.351056
# Unit test for function main

# Generated at 2022-06-17 04:51:43.830262
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'append',
        'rule_num': '5',
    }
    append_rule(iptables_path, module, params)



# Generated at 2022-06-17 04:53:23.176939
# Unit test for function construct_rule

# Generated at 2022-06-17 04:53:33.316279
# Unit test for function main

# Generated at 2022-06-17 04:53:41.984516
# Unit test for function construct_rule

# Generated at 2022-06-17 04:53:48.651936
# Unit test for function main

# Generated at 2022-06-17 04:53:58.064188
# Unit test for function main

# Generated at 2022-06-17 04:54:06.360625
# Unit test for function construct_rule