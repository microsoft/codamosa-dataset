

# Generated at 2022-06-17 04:44:25.158100
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('/sbin/iptables', '-I', dict(
        table='filter',
        chain='INPUT',
        rule_num='5',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
    )) == [
        '/sbin/iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--destination-port', '8080',
        '-j', 'ACCEPT',
    ]



# Generated at 2022-06-17 04:44:36.229914
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', '-A', 'INPUT', '-p', 'tcp', '-m', 'multiport', '--dports', '80,443', '-j', 'ACCEPT') == ['iptables', '-A', 'INPUT', '-p', 'tcp', '-m', 'multiport', '--dports', '80,443', '-j', 'ACCEPT']

# Generated at 2022-06-17 04:44:46.160989
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'foo', '--foo', False)
    assert rule == ['--foo', 'foo']
    rule = []
    append_param(rule, '!foo', '--foo', False)
    assert rule == ['!', '--foo', 'foo']
    rule = []
    append_param(rule, ['foo', 'bar'], '--foo', True)
    assert rule == ['--foo', 'foo', '--foo', 'bar']
    rule = []
    append_param(rule, ['!foo', '!bar'], '--foo', True)
    assert rule == ['!', '--foo', 'foo', '!', '--foo', 'bar']



# Generated at 2022-06-17 04:44:57.103378
# Unit test for function push_arguments

# Generated at 2022-06-17 04:45:06.816313
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:09.481149
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('iptables', 'module', 'params') == '-I INPUT -p tcp --dport 80 -j ACCEPT'



# Generated at 2022-06-17 04:45:19.489540
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('iptables', '-I', dict(
        table='filter',
        chain='INPUT',
        rule_num='1',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )) == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '1',
        '-p', 'tcp',
        '--dport', '80',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.',
    ]



# Generated at 2022-06-17 04:45:30.343411
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='Test comment',
        ip_version='ipv4',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--destination-port', '8080',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Test comment',
    ]



# Generated at 2022-06-17 04:45:36.088700
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='test',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--destination-port', '8080',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'test',
    ]



# Generated at 2022-06-17 04:45:40.014032
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'DROP'}) == 'DROP'



# Generated at 2022-06-17 04:46:12.725041
# Unit test for function append_rule

# Generated at 2022-06-17 04:46:23.505124
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:31.871404
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:40.464876
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:46:41.715115
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:46:54.474378
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:55.852020
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/usr/sbin/iptables', None) == '1.4.21'


# Generated at 2022-06-17 04:47:03.459860
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN']
    )
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:47:14.333852
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='FORWARD', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='OUTPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='PREROUTING', table='nat')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='POSTROUTING', table='nat')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='OUTPUT', table='nat')) == 'ACCEPT'

# Generated at 2022-06-17 04:47:15.206263
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(iptables_path, module, params) == cmd



# Generated at 2022-06-17 04:47:50.724495
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:03.448532
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        ip_version='ipv4',
    )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:48:07.457871
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == [
        'iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP', '--comment', 'Block specific IP'
    ]



# Generated at 2022-06-17 04:48:15.356433
# Unit test for function main

# Generated at 2022-06-17 04:48:17.994493
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(iptables_path, module, params) == cmd



# Generated at 2022-06-17 04:48:28.199499
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:48:29.646476
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:48:41.036740
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == False
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == False

# Generated at 2022-06-17 04:48:44.525560
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:48:55.117099
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.'
    }
    cmd = push_arguments(iptables_path, '-A', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '--dport', '80', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-17 04:49:26.368741
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'nat', 'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'nat', 'chain': 'POSTROUTING'}) == 'ACCEPT'

# Generated at 2022-06-17 04:49:37.280469
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'PREROUTING', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:49:43.751081
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', 'INPUT') == True
    assert check_present('iptables', '-C', 'OUTPUT') == True
    assert check_present('iptables', '-C', 'FORWARD') == True
    assert check_present('iptables', '-C', 'INPUT') == True
    assert check_present('iptables', '-C', 'OUTPUT') == True
    assert check_present('iptables', '-C', 'FORWARD') == True



# Generated at 2022-06-17 04:49:53.550073
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'LOGGING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:50:05.293545
# Unit test for function main

# Generated at 2022-06-17 04:50:06.967991
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:50:08.569285
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', '1.4.20') == '1.4.20'
    assert get_iptables_version('iptables', '1.6.0') == '1.6.0'



# Generated at 2022-06-17 04:50:12.068111
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == [
        'iptables', '-t', 'filter', '-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP'
    ]



# Generated at 2022-06-17 04:50:23.911425
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'LOGGING'}) == 'ACCEPT'
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'LOGGING_DROP'}) == 'DROP'

# Generated at 2022-06-17 04:50:28.372273
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'


# Generated at 2022-06-17 04:51:26.094535
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', 'module', 'params') == '-A INPUT -p tcp -s 8.8.8.8 -j DROP'


# Generated at 2022-06-17 04:51:34.108887
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:40.521952
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:52.797156
# Unit test for function main

# Generated at 2022-06-17 04:51:58.830481
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    assert check_present('iptables', module, params) == False


# Generated at 2022-06-17 04:52:07.855510
# Unit test for function construct_rule

# Generated at 2022-06-17 04:52:15.146698
# Unit test for function construct_rule

# Generated at 2022-06-17 04:52:23.123717
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:52:32.980027
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'nat', 'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'nat', 'chain': 'POSTROUTING'}) == 'ACCEPT'

# Generated at 2022-06-17 04:52:43.530814
# Unit test for function construct_rule