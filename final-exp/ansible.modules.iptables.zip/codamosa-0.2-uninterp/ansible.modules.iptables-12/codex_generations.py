

# Generated at 2022-06-17 04:44:45.495018
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []


# Generated at 2022-06-17 04:44:52.895404
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='Test rule',
    )
    cmd = push_arguments('/sbin/iptables', '-I', params)
    assert cmd == [
        '/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp',
        '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment',
        'Test rule'
    ]



# Generated at 2022-06-17 04:45:00.753134
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        chain='INPUT',
        policy='DROP',
        table='filter',
        ip_version='ipv4',
    )
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-17 04:45:06.975859
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='Test rule',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--destination-port', '8080',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Test rule',
    ]



# Generated at 2022-06-17 04:45:18.923756
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:28.684643
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port=8080,
        jump='ACCEPT',
        comment='test',
    )
    assert push_arguments('iptables', '-I', params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp',
        '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'test']



# Generated at 2022-06-17 04:45:38.363536
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str', required=True),
        policy=dict(type='str', required=True, choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        table=dict(type='str', default='filter'),
        ip_version=dict(type='str', default='ipv4', choices=['ipv4', 'ipv6']),
        wait=dict(type='str'),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-17 04:45:49.234132
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:54.045055
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'ACCEPT',
        'ip_version': 'ipv4',
    }
    iptables_path = BINS[params['ip_version']]
    cmd = push_arguments(iptables_path, '-A', params)
    assert cmd == [iptables_path, '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '--dport', '80', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:46:00.233084
# Unit test for function construct_rule

# Generated at 2022-06-17 04:47:01.183043
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:47:02.146211
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:47:03.069947
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None


# Generated at 2022-06-17 04:47:04.171766
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == '-P INPUT DROP'



# Generated at 2022-06-17 04:47:08.335158
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str', required=True),
        policy=dict(type='str', required=True, choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        table=dict(type='str', default='filter'),
        ip_version=dict(type='str', default='ipv4', choices=['ipv4', 'ipv6']),
        wait=dict(type='str'),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-17 04:47:10.918541
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:47:16.924332
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:47:28.487853
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str', required=True),
        table=dict(type='str', default='filter'),
        ip_version=dict(type='str', default='ipv4'),
        flush=dict(type='bool', default=False),
        policy=dict(type='str', choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        wait=dict(type='str'),
    ))
    params = dict(
        chain='INPUT',
        table='filter',
        ip_version='ipv4',
        flush=True,
        policy=None,
        wait=None,
    )
    flush_table(iptables_path, module, params)

# Generated at 2022-06-17 04:47:30.522203
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == False


# Generated at 2022-06-17 04:47:34.820593
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:48:07.971224
# Unit test for function remove_rule
def test_remove_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='remove',
        rule_num=5,
        ip_version='ipv4'
    )
    iptables_path = BINS[params['ip_version']]
    cmd = push_arguments(iptables_path, '-D', params)
    assert cmd == [iptables_path, '-t', 'filter', '-D', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:48:22.007831
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:48:23.170759
# Unit test for function flush_table
def test_flush_table():
    assert flush_table('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:48:32.116055
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:38.467607
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FOOBAR'}) is None



# Generated at 2022-06-17 04:48:48.255344
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:48:59.617246
# Unit test for function append_rule

# Generated at 2022-06-17 04:49:00.844064
# Unit test for function flush_table
def test_flush_table():
    assert flush_table('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:49:05.404695
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='append',
        rule_num='5',
    )
    append_rule(iptables_path, module, params)



# Generated at 2022-06-17 04:49:13.793918
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Test rule',
        ip_version='ipv4',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:49:55.680732
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', {'chain': 'INPUT', 'table': 'filter'}) == True
    assert check_present('iptables', '-C', {'chain': 'INPUT', 'table': 'filter', 'protocol': 'tcp'}) == True
    assert check_present('iptables', '-C', {'chain': 'INPUT', 'table': 'filter', 'protocol': 'tcp', 'destination_port': '80'}) == True
    assert check_present('iptables', '-C', {'chain': 'INPUT', 'table': 'filter', 'protocol': 'tcp', 'destination_port': '80', 'jump': 'ACCEPT'}) == True

# Generated at 2022-06-17 04:49:57.384760
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:50:09.464166
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:10.408862
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:50:11.086240
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:50:23.462041
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:25.213018
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == [
        'iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP'
    ]


# Generated at 2022-06-17 04:50:29.263397
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:50:41.351784
# Unit test for function main

# Generated at 2022-06-17 04:50:46.030408
# Unit test for function insert_rule

# Generated at 2022-06-17 04:51:15.861029
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.'
    )
    rule = construct_rule(params)
    assert rule == [
        '-p', 'tcp',
        '--dport', '80',
        '-m', 'conntrack',
        '--ctstate', 'NEW',
        '--syn',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.'
    ]



# Generated at 2022-06-17 04:51:18.369440
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:51:27.862107
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='remove',
        rule_num=5,
        ip_version='ipv4'
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)


# Generated at 2022-06-17 04:51:35.126398
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:44.667798
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:47.361612
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:51:50.650519
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:51:57.071554
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['state', 'iprange'],
        ctstate=['ESTABLISHED', 'RELATED'],
        src_range='192.168.1.100-192.168.1.199',
        dst_range='10.0.0.1-10.0.0.50',
        jump='ACCEPT',
        comment='Allow connections to 10.0.0.1-10.0.0.50 from 192.168.1.100-192.168.1.199',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:51:58.730038
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('/sbin/iptables', module, params) == ['/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP']



# Generated at 2022-06-17 04:52:04.336864
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule(argument_spec={})
    module.run_command = mock.Mock(return_value=(0, 'iptables v1.4.21\n', ''))
    assert get_iptables_version('iptables', module) == '1.4.21'
    module.run_command = mock.Mock(return_value=(0, 'iptables v1.6.0\n', ''))
    assert get_iptables_version('iptables', module) == '1.6.0'



# Generated at 2022-06-17 04:52:26.260720
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:52:27.923683
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('iptables', 'module', 'params') == '-I'



# Generated at 2022-06-17 04:52:29.176245
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:52:32.242449
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:52:36.714274
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='ACCEPT')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='DROP')) == 'DROP'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='ACCEPT')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='DROP')) == 'DROP'



# Generated at 2022-06-17 04:52:39.814071
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec={})
    params = dict(
        chain='INPUT',
        policy='DROP',
        table='filter',
        ip_version='ipv4',
    )
    set_chain_policy('iptables', module, params)
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:52:46.834036
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:52:50.404743
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:52:58.522453
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        table='filter',
        ip_version='ipv4',
    )
    cmd = push_arguments('iptables', module, params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--dport', '8080',
        '-j', 'ACCEPT'
    ]



# Generated at 2022-06-17 04:53:09.539723
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:53:45.734651
# Unit test for function main

# Generated at 2022-06-17 04:53:56.504348
# Unit test for function main

# Generated at 2022-06-17 04:54:04.900173
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='Block specific IP',
    )
    assert construct_rule(params) == ['-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP', '-m', 'comment', '--comment', 'Block specific IP']

    params = dict(
        table='nat',
        chain='PREROUTING',
        in_interface='eth0',
        protocol='tcp',
        match='tcp',
        destination_port='80',
        jump='REDIRECT',
        to_ports='8600',
        comment='Redirect web traffic to port 8600',
    )

# Generated at 2022-06-17 04:54:11.501805
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING', 'table': 'nat'}) == 'ACCEPT'