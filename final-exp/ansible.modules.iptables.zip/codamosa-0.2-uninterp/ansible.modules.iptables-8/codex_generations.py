

# Generated at 2022-06-17 04:44:30.623113
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT'}) == True


# Generated at 2022-06-17 04:44:37.358299
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({})
    params = dict(
        chain='INPUT',
        policy='DROP',
    )
    cmd = push_arguments('iptables', '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:44:40.478847
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', 'INPUT') == True
    assert check_present('iptables', '-C', 'OUTPUT') == True
    assert check_present('iptables', '-C', 'FORWARD') == True


# Generated at 2022-06-17 04:44:42.891203
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:44:48.195867
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Allow established and related connections',
    )

# Generated at 2022-06-17 04:44:54.252612
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:44:57.014978
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', 'INPUT') == True


# Generated at 2022-06-17 04:45:01.209303
# Unit test for function append_rule

# Generated at 2022-06-17 04:45:09.069620
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5'
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:45:14.691540
# Unit test for function remove_rule
def test_remove_rule():
    params = dict(
        table='filter',
        chain='INPUT',
        source='8.8.8.8',
        jump='DROP',
        ip_version='ipv4',
    )
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec=dict())
    remove_rule(iptables_path, module, params)



# Generated at 2022-06-17 04:45:30.511909
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']


# Generated at 2022-06-17 04:45:40.702414
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test', '--test', False)
    assert rule == ['--test', 'test']
    rule = []
    append_param(rule, ['test', 'test2'], '--test', True)
    assert rule == ['--test', 'test', '--test', 'test2']
    rule = []
    append_param(rule, '!test', '--test', False)
    assert rule == ['!', '--test', 'test']
    rule = []
    append_param(rule, ['!test', '!test2'], '--test', True)
    assert rule == ['!', '--test', 'test', '!', '--test', 'test2']



# Generated at 2022-06-17 04:45:44.479437
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec={})
    assert check_present('iptables', module, {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '22',
        'ctstate': 'NEW',
        'syn': 'match',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.',
        'ip_version': 'ipv4',
    }) is False



# Generated at 2022-06-17 04:45:45.874043
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -P params'



# Generated at 2022-06-17 04:45:51.484111
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5'
    )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:45:58.219129
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN'],
    )
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:46:02.597332
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    cmd = push_arguments('iptables', module, params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-A', 'INPUT',
        '-p', 'tcp',
        '--destination-port', '80',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.'
    ]



# Generated at 2022-06-17 04:46:14.200039
# Unit test for function main

# Generated at 2022-06-17 04:46:24.051292
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['NEW', 'ESTABLISHED'],
        jump='ACCEPT',
        comment='test rule',
        ip_version='ipv4',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:46:26.858229
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:46:47.029298
# Unit test for function main

# Generated at 2022-06-17 04:46:54.284809
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=None,
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        wait=None,
        ip_version='ipv4',
    )
    cmd = push_arguments('iptables', '-A', params)
    assert cmd == ['iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP']



# Generated at 2022-06-17 04:47:04.621312
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:47:15.704819
# Unit test for function construct_rule

# Generated at 2022-06-17 04:47:21.409624
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(type='str', default='filter'),
        chain=dict(type='str', default='INPUT'),
        ip_version=dict(type='str', default='ipv4', choices=['ipv4', 'ipv6']),
        wait=dict(type='str'),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:47:23.264911
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        flush=True,
    )
    flush_table('iptables', module, params)



# Generated at 2022-06-17 04:47:31.629144
# Unit test for function remove_rule
def test_remove_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    cmd = push_arguments('iptables', '-D', params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-D', 'INPUT',
        '-p', 'tcp',
        '--destination-port', '80',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.',
    ]



# Generated at 2022-06-17 04:47:40.785684
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'LOGGING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:47:46.689579
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:47:53.739247
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)



# Generated at 2022-06-17 04:48:11.178930
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == False


# Generated at 2022-06-17 04:48:16.118767
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict(
        table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw', 'security']),
        chain=dict(default='INPUT'),
        flush=dict(default=False, type='bool'),
        policy=dict(default=None, choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
        wait=dict(default=None),
    ))
    params = module.params
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:48:25.986474
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    rule = construct_rule(params)
    assert rule == [
        '-p', 'tcp',
        '--dport', '80',
        '-m', 'conntrack',
        '--ctstate', 'NEW',
        '--syn',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.',
    ]



# Generated at 2022-06-17 04:48:31.169866
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-17 04:48:41.129733
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'LOGGING'}) == 'ACCEPT'
    assert get_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'LOGGING_DROP'}) == 'DROP'

# Generated at 2022-06-17 04:48:42.645809
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:48:45.621387
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == [
        'iptables', '-t', 'filter', '-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP']



# Generated at 2022-06-17 04:48:46.735217
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:48:47.819613
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'


# Generated at 2022-06-17 04:48:52.913501
# Unit test for function construct_rule

# Generated at 2022-06-17 04:49:05.799210
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -P params'



# Generated at 2022-06-17 04:49:11.201137
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:49:13.897848
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:49:23.602567
# Unit test for function construct_rule

# Generated at 2022-06-17 04:49:26.611243
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'remove',
        'rule_num': '5'
    }
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)


# Generated at 2022-06-17 04:49:27.630832
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -P params'



# Generated at 2022-06-17 04:49:28.637302
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -P params'



# Generated at 2022-06-17 04:49:42.027739
# Unit test for function construct_rule

# Generated at 2022-06-17 04:49:49.358914
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec={})
    params = dict(
        chain='INPUT',
        policy='DROP',
    )
    cmd = push_arguments('iptables', '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:49:51.428697
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(iptables_path, module, params) == ['/sbin/iptables', '-t', 'filter', '-P', 'INPUT', 'ACCEPT']


# Generated at 2022-06-17 04:50:18.282913
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == 0



# Generated at 2022-06-17 04:50:23.417324
# Unit test for function main

# Generated at 2022-06-17 04:50:24.466214
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -P params'



# Generated at 2022-06-17 04:50:28.848316
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.4.21'



# Generated at 2022-06-17 04:50:34.557568
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
    )
    flush_table('iptables', module, params)



# Generated at 2022-06-17 04:50:43.772003
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:44.766151
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:50:45.787552
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:50:48.178418
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('/sbin/iptables', None, dict(table='filter', chain='INPUT', ip_version='ipv4')) == ['/sbin/iptables', '-t', 'filter', '-D', 'INPUT']



# Generated at 2022-06-17 04:50:50.216233
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('/sbin/iptables', 'module', 'params') == '-P INPUT DROP'



# Generated at 2022-06-17 04:51:41.087079
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:51:49.776537
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:51.543436
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:52:01.845264
# Unit test for function main

# Generated at 2022-06-17 04:52:07.864394
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == True
    assert check_present('iptables', '-C', {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == True

# Generated at 2022-06-17 04:52:19.409275
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Allow new SSH connections.',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:52:31.635945
# Unit test for function construct_rule

# Generated at 2022-06-17 04:52:42.588775
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='1.2.3.4',
        destination='5.6.7.8',
        match=['tcp', 'state'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:52:51.806483
# Unit test for function main

# Generated at 2022-06-17 04:52:59.040153
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5'
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']

