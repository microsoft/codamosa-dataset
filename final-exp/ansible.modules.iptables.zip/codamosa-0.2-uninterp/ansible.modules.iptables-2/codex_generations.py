

# Generated at 2022-06-17 04:44:46.198550
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:44:56.983469
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'

# Generated at 2022-06-17 04:45:00.013791
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        flush=True,
    )
    flush_table('iptables', module, params)



# Generated at 2022-06-17 04:45:06.149976
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:45:16.050137
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:25.641945
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []
    rule = []
    append_match_flag(rule, '', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:45:33.868327
# Unit test for function main

# Generated at 2022-06-17 04:45:43.206429
# Unit test for function main

# Generated at 2022-06-17 04:45:49.811111
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.'
    )
    assert push_arguments('iptables', '-A', params) == [
        'iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '--dport', '80', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-17 04:45:55.963752
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:46:12.522488
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', module) == '1.6.1'


# Generated at 2022-06-17 04:46:23.475211
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:30.314862
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str', required=True),
        table=dict(type='str', default='filter'),
        ip_version=dict(type='str', default='ipv4'),
        flush=dict(type='bool', default=False),
        policy=dict(type='str', choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        wait=dict(type='str'),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    flush_table(iptables_path, module, params)


# Generated at 2022-06-17 04:46:33.955952
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        ip_version='ipv4',
    )
    cmd = push_arguments('/sbin/iptables', '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:46:39.624216
# Unit test for function main

# Generated at 2022-06-17 04:46:51.617460
# Unit test for function main

# Generated at 2022-06-17 04:46:58.310275
# Unit test for function main

# Generated at 2022-06-17 04:47:02.544919
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='Block specific IP',
    )
    assert construct_rule(params) == [
        '-p', 'tcp',
        '-s', '8.8.8.8',
        '-j', 'DROP',
        '-m', 'comment',
        '--comment', 'Block specific IP',
    ]

    params = dict(
        table='nat',
        chain='PREROUTING',
        in_interface='eth0',
        protocol='tcp',
        match='tcp',
        destination_port='80',
        jump='REDIRECT',
        to_ports='8600',
        comment='Redirect web traffic to port 8600',
    )

# Generated at 2022-06-17 04:47:06.262124
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test', '--test', False)
    assert rule == ['--test', 'test']
    rule = []
    append_param(rule, '!test', '--test', False)
    assert rule == ['!', '--test', 'test']
    rule = []
    append_param(rule, ['test1', 'test2'], '--test', True)
    assert rule == ['--test', 'test1', '--test', 'test2']
    rule = []
    append_param(rule, ['!test1', '!test2'], '--test', True)
    assert rule == ['!', '--test', 'test1', '!', '--test', 'test2']



# Generated at 2022-06-17 04:47:15.892077
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'insert',
        'rule_num': '5'
    }
    iptables_path = 'iptables'
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--destination-port', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:47:34.222823
# Unit test for function construct_rule

# Generated at 2022-06-17 04:47:43.396938
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('iptables', '-A', dict(
        table='filter',
        chain='INPUT',
        rule_num=None,
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        wait=None,
        ip_version='ipv4',
    )) == [
        'iptables',
        '-t', 'filter',
        '-A', 'INPUT',
        '-p', 'tcp',
        '-s', '8.8.8.8',
        '-j', 'DROP',
    ]



# Generated at 2022-06-17 04:47:44.441420
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(iptables_path, module, params) == cmd



# Generated at 2022-06-17 04:47:50.955206
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-17 04:48:04.257122
# Unit test for function insert_rule

# Generated at 2022-06-17 04:48:13.392061
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:48:21.686309
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str'),
        table=dict(type='str', default='filter'),
        ip_version=dict(type='str', default='ipv4'),
    ))
    params = dict(
        chain='INPUT',
        table='filter',
        ip_version='ipv4',
    )
    flush_table('iptables', module, params)



# Generated at 2022-06-17 04:48:26.453049
# Unit test for function main

# Generated at 2022-06-17 04:48:28.907142
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:48:40.657254
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:59.108161
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept new SSH connections.'
    )
    cmd = push_arguments('iptables', '-A', params)
    assert cmd == ['iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '--dport', '80', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']


# Generated at 2022-06-17 04:49:00.673752
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:49:04.591129
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:49:13.689488
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:49:20.912202
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        flush=True,
    )
    cmd = push_arguments(iptables_path, '-F', params, make_rule=False)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-F', 'INPUT']



# Generated at 2022-06-17 04:49:29.332719
# Unit test for function construct_rule

# Generated at 2022-06-17 04:49:38.973959
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw', 'security']),
        chain=dict(default='INPUT'),
        ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:49:45.156635
# Unit test for function main

# Generated at 2022-06-17 04:49:47.534285
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', 'module', 'params') == True


# Generated at 2022-06-17 04:49:57.126843
# Unit test for function main

# Generated at 2022-06-17 04:50:39.964425
# Unit test for function main

# Generated at 2022-06-17 04:50:49.428350
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['NEW', 'ESTABLISHED'],
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:50:57.529256
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:00.690224
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', 'module', 'params') == '-A'



# Generated at 2022-06-17 04:51:11.689782
# Unit test for function main

# Generated at 2022-06-17 04:51:15.840373
# Unit test for function flush_table
def test_flush_table():
    assert flush_table('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:51:23.990220
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:29.411106
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='test',
        ip_version='ipv4',
    )
    assert construct_rule(params) == [
        '-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP', '-m', 'comment', '--comment', 'test'
    ]



# Generated at 2022-06-17 04:51:37.959052
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    rule = construct_rule(params)
    assert rule == [
        '-p', 'tcp',
        '--dport', '80',
        '-m', 'conntrack',
        '--ctstate', 'NEW',
        '--syn',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.',
    ]



# Generated at 2022-06-17 04:51:44.940254
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:52:22.177549
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:52:23.961331
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'


# Generated at 2022-06-17 04:52:32.739564
# Unit test for function main

# Generated at 2022-06-17 04:52:42.532086
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == [
        '-p', 'tcp',
        '--dport', '80',
        '-m', 'conntrack',
        '--ctstate', 'NEW',
        '--syn',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.',
    ]



# Generated at 2022-06-17 04:52:45.033495
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -P params'



# Generated at 2022-06-17 04:52:57.919821
# Unit test for function construct_rule

# Generated at 2022-06-17 04:52:59.639764
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', 'INPUT') == True


# Generated at 2022-06-17 04:53:10.569241
# Unit test for function construct_rule

# Generated at 2022-06-17 04:53:17.278810
# Unit test for function construct_rule

# Generated at 2022-06-17 04:53:18.595453
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == None

