

# Generated at 2022-06-17 04:44:33.475108
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -t table -P chain policy'



# Generated at 2022-06-17 04:44:44.483184
# Unit test for function construct_rule

# Generated at 2022-06-17 04:44:54.246302
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='test comment',
        ip_version='ipv4',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables',
        '-t',
        'filter',
        '-I',
        'INPUT',
        '5',
        '-p',
        'tcp',
        '--destination-port',
        '8080',
        '-j',
        'ACCEPT',
        '-m',
        'comment',
        '--comment',
        'test comment',
    ]



# Generated at 2022-06-17 04:45:05.783744
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:12.888732
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='OUTPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='FORWARD', table='filter')) == 'ACCEPT'



# Generated at 2022-06-17 04:45:20.196477
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('iptables', '-I', dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
    )) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp',
        '--dport', '8080', '-j', 'ACCEPT'
    ]



# Generated at 2022-06-17 04:45:30.179501
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:37.692197
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:49.158419
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:54.230377
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:46:14.236842
# Unit test for function main

# Generated at 2022-06-17 04:46:21.198327
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:46:26.510309
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:46:35.063349
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:46:40.786684
# Unit test for function main

# Generated at 2022-06-17 04:46:50.342227
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:46:57.711746
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        comment='test comment',
    )
    rule = construct_rule(params)
    assert rule == [
        '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT',
        '-m', 'comment', '--comment', 'test comment',
    ]



# Generated at 2022-06-17 04:46:59.866616
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == False


# Generated at 2022-06-17 04:47:06.367555
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:47:20.379201
# Unit test for function main

# Generated at 2022-06-17 04:47:36.031623
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5'
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:47:43.110268
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        chain='INPUT',
        table='filter',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:47:47.849726
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:47:49.243840
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:47:52.459104
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:48:00.048225
# Unit test for function insert_rule
def test_insert_rule():
    # Test case 1
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:48:10.810096
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:48:21.709835
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '--dport', '80', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-17 04:48:26.843258
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == '-P INPUT ACCEPT'



# Generated at 2022-06-17 04:48:37.474054
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:57.441731
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    assert construct_rule(params) == ['-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:48:59.186734
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:49:08.495209
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='Test rule',
    )
    cmd = push_arguments('/sbin/iptables', '-I', params)
    assert cmd == [
        '/sbin/iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--dport', '8080',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Test rule',
    ]



# Generated at 2022-06-17 04:49:18.546400
# Unit test for function insert_rule

# Generated at 2022-06-17 04:49:26.951384
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    assert construct_rule(params) == [
        '-p', 'tcp',
        '--dport', '80',
        '-m', 'conntrack',
        '--ctstate', 'NEW',
        '--syn',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.',
        '--icmp-type', 'any',
    ]



# Generated at 2022-06-17 04:49:37.309681
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='ACCEPT')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='DROP')) == 'DROP'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='QUEUE')) == 'QUEUE'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='RETURN')) == 'RETURN'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='ACCEPT')) != 'DROP'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='ACCEPT')) != 'QUEUE'

# Generated at 2022-06-17 04:49:43.859746
# Unit test for function main

# Generated at 2022-06-17 04:49:54.619856
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == False
    assert check_present('iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == False

# Generated at 2022-06-17 04:49:56.519377
# Unit test for function flush_table
def test_flush_table():
    assert flush_table('iptables', 'module', 'params') == None


# Generated at 2022-06-17 04:50:01.086820
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
    )
    flush_table('iptables', module, params)



# Generated at 2022-06-17 04:50:50.129269
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:50:58.287014
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(required=True, type='str'),
        chain=dict(required=True, type='str'),
    ))
    params = dict(
        table='filter',
        chain='INPUT',
    )
    flush_table('iptables', module, params)
    assert True



# Generated at 2022-06-17 04:51:03.377103
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    rule = construct_rule(params)
    assert rule == ['-w', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:51:06.822214
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({
        'chain': 'INPUT',
        'policy': 'DROP',
        'table': 'filter',
        'ip_version': 'ipv4',
        'wait': None,
    })
    set_chain_policy('iptables', module, module.params)



# Generated at 2022-06-17 04:51:20.048881
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        comment='Test comment',
    )
    rule = construct_rule(params)
    assert rule == [
        '-p', 'tcp',
        '--dport', '8080',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Test comment',
    ]



# Generated at 2022-06-17 04:51:22.642031
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:51:31.503539
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='ACCEPT')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='DROP')) == 'DROP'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='QUEUE')) == 'QUEUE'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='RETURN')) == 'RETURN'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='ACCEPT')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='DROP')) == 'DROP'

# Generated at 2022-06-17 04:51:35.414958
# Unit test for function append_rule
def test_append_rule():
    assert append_rule(iptables_path, module, params) == ['/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP']


# Generated at 2022-06-17 04:51:36.338102
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:51:45.906504
# Unit test for function construct_rule

# Generated at 2022-06-17 04:52:33.517710
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/iptables', None) == '1.4.21'



# Generated at 2022-06-17 04:52:36.808299
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'FORWARD'}) == 'ACCEPT'



# Generated at 2022-06-17 04:52:37.577025
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:52:40.236204
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule({})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.'
    }
    append_rule(iptables_path, module, params)



# Generated at 2022-06-17 04:52:44.076693
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw', 'security']),
        chain=dict(default='INPUT'),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:52:46.974166
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
    )
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:52:48.490952
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:52:58.574323
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:53:09.541136
# Unit test for function main

# Generated at 2022-06-17 04:53:21.023337
# Unit test for function remove_rule