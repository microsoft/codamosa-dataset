

# Generated at 2022-06-17 04:45:23.713557
# Unit test for function main

# Generated at 2022-06-17 04:45:33.153729
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5'
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--destination-port', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:45:41.192586
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='Test rule',
    )
    assert push_arguments('iptables', '-I', params) == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--destination-port', '8080',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Test rule',
    ]



# Generated at 2022-06-17 04:45:46.957923
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('/sbin/iptables', 'module', 'params') == ['/sbin/iptables', '-t', 'params', '-I', 'params', 'params']



# Generated at 2022-06-17 04:45:57.002698
# Unit test for function main

# Generated at 2022-06-17 04:46:06.908955
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:20.672109
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test', '--test', False)
    assert rule == ['--test', 'test']
    rule = []
    append_param(rule, '!test', '--test', False)
    assert rule == ['!', '--test', 'test']
    rule = []
    append_param(rule, ['test', 'test2'], '--test', True)
    assert rule == ['--test', 'test', '--test', 'test2']
    rule = []
    append_param(rule, ['!test', '!test2'], '--test', True)
    assert rule == ['!', '--test', 'test', '!', '--test', 'test2']



# Generated at 2022-06-17 04:46:21.652826
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(iptables_path, module, params) == cmd



# Generated at 2022-06-17 04:46:26.560980
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:46:31.692342
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
    )
    assert push_arguments('iptables', '-I', params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp',
        '--dport', '8080', '-j', 'ACCEPT'
    ]



# Generated at 2022-06-17 04:47:32.943675
# Unit test for function main

# Generated at 2022-06-17 04:47:45.712522
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '--dport', '80', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']

# Generated at 2022-06-17 04:47:49.519431
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []


# Generated at 2022-06-17 04:48:00.358811
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:48:10.515514
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:11.481578
# Unit test for function flush_table
def test_flush_table():
    assert flush_table('iptables', 'module', 'params') == 'iptables -t table -F chain'



# Generated at 2022-06-17 04:48:23.142005
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:32.186586
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:36.719044
# Unit test for function main

# Generated at 2022-06-17 04:48:43.828210
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:49:43.274595
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:49:52.145750
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-17 04:49:55.771005
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='remove',
        rule_num=5,
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)


# Generated at 2022-06-17 04:49:59.117294
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None


# Generated at 2022-06-17 04:50:10.218464
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:19.408237
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FOO'}) is None



# Generated at 2022-06-17 04:50:20.783949
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', {'chain': 'INPUT', 'table': 'filter'}) == True


# Generated at 2022-06-17 04:50:26.370190
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str', required=True),
        policy=dict(type='str', required=True, choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        table=dict(type='str', default='filter'),
        ip_version=dict(type='str', default='ipv4', choices=['ipv4', 'ipv6']),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    set_chain_policy(iptables_path, module, params)


# Generated at 2022-06-17 04:50:36.288899
# Unit test for function main

# Generated at 2022-06-17 04:50:41.094190
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        flush=True,
    )
    flush_table('iptables', module, params)



# Generated at 2022-06-17 04:52:46.734848
# Unit test for function construct_rule

# Generated at 2022-06-17 04:52:58.120462
# Unit test for function construct_rule

# Generated at 2022-06-17 04:52:59.716836
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:53:08.630697
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:53:13.860503
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='remove',
        rule_num=5,
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-17 04:53:17.540434
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        chain='INPUT',
        policy='DROP',
        table='filter',
        ip_version='ipv4',
    )
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-17 04:53:19.115159
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == '-P INPUT DROP'



# Generated at 2022-06-17 04:53:20.009815
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:53:21.090935
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/usr/sbin/iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:53:28.619624
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['NEW', 'ESTABLISHED'],
        jump='ACCEPT',
        comment='This is a test',
        log_prefix='IPTABLES:INFO: ',
        log_level='info',
        limit='2/second',
        limit_burst='20',
        uid_owner='root',
        gid_owner='root',
        reject_with='tcp-reset',
        icmp_type='echo-request',
        ip_version='ipv4',
        wait='5',
    )
    rule = construct_rule(params)