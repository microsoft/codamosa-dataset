

# Generated at 2022-06-17 04:44:36.551628
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']


# Generated at 2022-06-17 04:44:46.322086
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--dport', '8080',
        '-j', 'ACCEPT',
    ]



# Generated at 2022-06-17 04:44:52.508546
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    assert construct_rule(params) == [
        '-p', 'tcp',
        '--dport', '80',
        '-m', 'conntrack',
        '--ctstate', 'NEW',
        '--syn',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.',
    ]



# Generated at 2022-06-17 04:44:56.820713
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN'],
    )
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:45:05.374845
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num='5',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='Test rule',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--dport', '8080',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Test rule',
    ]



# Generated at 2022-06-17 04:45:15.493067
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    assert construct_rule(params) == [
        '-p', 'tcp',
        '--dport', '80',
        '-m', 'conntrack',
        '--ctstate', 'NEW',
        '--syn',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.',
    ]

# Generated at 2022-06-17 04:45:26.533049
# Unit test for function construct_rule

# Generated at 2022-06-17 04:45:34.500611
# Unit test for function main

# Generated at 2022-06-17 04:45:44.231266
# Unit test for function main

# Generated at 2022-06-17 04:45:45.897193
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:46:09.058941
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:46:16.709265
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw', 'security']),
        chain=dict(default='INPUT'),
        ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
        flush=dict(default=False, type='bool'),
        policy=dict(default=None, choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        wait=dict(default=None),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:46:23.755062
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:46:30.034323
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []


# Generated at 2022-06-17 04:46:40.368705
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.0/24',
        destination='192.168.2.0/24',
        match=['state', 'conntrack'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Allow established and related connections',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:46:52.858642
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:53.523437
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', 'module', 'params') == True



# Generated at 2022-06-17 04:47:02.334611
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:47:04.596212
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-17 04:47:12.335272
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
    }
    flush_table('iptables', module, params)
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['iptables', '-t', 'filter', '-F', 'INPUT']
    assert module.run_command.call_args[1] == {'check_rc': True}



# Generated at 2022-06-17 04:47:28.134423
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:47:35.425128
# Unit test for function main

# Generated at 2022-06-17 04:47:48.641090
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:01.813150
# Unit test for function main

# Generated at 2022-06-17 04:48:11.375027
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='remove',
        rule_num=5,
    )
    cmd = push_arguments(iptables_path, '-D', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-D', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:48:23.054684
# Unit test for function main

# Generated at 2022-06-17 04:48:29.545395
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', 'module', 'params') == None
    assert get_chain_policy('iptables', 'module', 'params') == 'ACCEPT'
    assert get_chain_policy('iptables', 'module', 'params') == 'DROP'
    assert get_chain_policy('iptables', 'module', 'params') == 'QUEUE'
    assert get_chain_policy('iptables', 'module', 'params') == 'RETURN'



# Generated at 2022-06-17 04:48:40.975764
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/sbin/iptables'

# Generated at 2022-06-17 04:48:47.162711
# Unit test for function main

# Generated at 2022-06-17 04:48:49.209139
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:49:10.340096
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:49:22.400431
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test', '-t', False)
    assert rule == ['-t', 'test']
    rule = []
    append_param(rule, '!test', '-t', False)
    assert rule == ['!', '-t', 'test']
    rule = []
    append_param(rule, ['test1', 'test2'], '-t', True)
    assert rule == ['-t', 'test1', '-t', 'test2']
    rule = []
    append_param(rule, ['!test1', '!test2'], '-t', True)
    assert rule == ['!', '-t', 'test1', '!', '-t', 'test2']


# Generated at 2022-06-17 04:49:24.906177
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:49:27.248040
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == '-D'



# Generated at 2022-06-17 04:49:37.334814
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:49:43.750542
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
    )
    iptables_path = '/sbin/iptables'
    flush_table(iptables_path, module, params)
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['/sbin/iptables', '-t', 'filter', '-F', 'INPUT']



# Generated at 2022-06-17 04:49:54.242100
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='OUTPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='FORWARD', table='filter')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='INPUT', table='nat')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='OUTPUT', table='nat')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(chain='PREROUTING', table='nat')) == 'ACCEPT'

# Generated at 2022-06-17 04:49:55.687023
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('iptables', 'module', 'params') == '-I INPUT -p tcp --dport 8080 -j ACCEPT'



# Generated at 2022-06-17 04:50:05.459767
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Allow established and related connections',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:50:07.049685
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('/sbin/iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:50:34.305098
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)


# Generated at 2022-06-17 04:50:35.639584
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:50:44.742496
# Unit test for function main

# Generated at 2022-06-17 04:50:50.117329
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy("iptables", "module", "params") == "iptables -P params params"


# Generated at 2022-06-17 04:50:58.104935
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:03.459788
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(required=True, type='str'),
        chain=dict(required=True, type='str'),
        ip_version=dict(required=True, type='str'),
    ))
    params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4',
    )
    flush_table('iptables', module, params)



# Generated at 2022-06-17 04:51:12.757059
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='test',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP', '-m', 'comment', '--comment', 'test']

    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='test',
        ip_version='ipv6',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:51:21.935080
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:31.037939
# Unit test for function main

# Generated at 2022-06-17 04:51:32.015099
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:52:16.489343
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    assert construct_rule(params) == [
        '-w', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT', '-I', 'INPUT', '5']



# Generated at 2022-06-17 04:52:24.500965
# Unit test for function main

# Generated at 2022-06-17 04:52:33.244878
# Unit test for function main

# Generated at 2022-06-17 04:52:38.801688
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'DROP'}) == 'DROP'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'ACCEPT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'QUEUE'}) == 'QUEUE'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'RETURN'}) == 'RETURN'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'NONE'}) == None



# Generated at 2022-06-17 04:52:48.471675
# Unit test for function main

# Generated at 2022-06-17 04:52:59.079666
# Unit test for function construct_rule

# Generated at 2022-06-17 04:53:06.888760
# Unit test for function append_rule

# Generated at 2022-06-17 04:53:09.540695
# Unit test for function flush_table
def test_flush_table():
    assert flush_table('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:53:12.139717
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -P params'



# Generated at 2022-06-17 04:53:21.209674
# Unit test for function main