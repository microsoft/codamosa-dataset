

# Generated at 2022-06-17 04:45:31.061312
# Unit test for function main

# Generated at 2022-06-17 04:45:35.138836
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -P params'



# Generated at 2022-06-17 04:45:42.142387
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test', '--test', False)
    assert rule == ['--test', 'test']
    rule = []
    append_param(rule, '!test', '--test', False)
    assert rule == ['!', '--test', 'test']
    rule = []
    append_param(rule, ['test1', 'test2'], '--test', True)
    assert rule == ['--test', 'test1', '--test', 'test2']
    rule = []
    append_param(rule, ['!test1', '!test2'], '--test', True)
    assert rule == ['!', '--test', 'test1', '!', '--test', 'test2']



# Generated at 2022-06-17 04:45:49.725255
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:45:51.907516
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
    )
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:45:58.054285
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']


# Generated at 2022-06-17 04:46:01.911396
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:46:08.999879
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST']



# Generated at 2022-06-17 04:46:16.428432
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:46:24.546755
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:47:46.641860
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num='5',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='test rule',
    )
    cmd = push_arguments('/sbin/iptables', '-I', params)
    assert cmd == [
        '/sbin/iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '--destination-port', '8080',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'test rule',
    ]



# Generated at 2022-06-17 04:47:47.620875
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:47:55.941091
# Unit test for function main

# Generated at 2022-06-17 04:47:58.261589
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:48:00.629093
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == '-P INPUT DROP'



# Generated at 2022-06-17 04:48:11.608566
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        rule_num='5',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        wait='10',
        comment='Test comment',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-w', '10',
        '-p', 'tcp',
        '--destination-port', '8080',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Test comment',
    ]

# Generated at 2022-06-17 04:48:22.145682
# Unit test for function insert_rule

# Generated at 2022-06-17 04:48:28.798980
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FOO'}) is None



# Generated at 2022-06-17 04:48:40.713536
# Unit test for function main

# Generated at 2022-06-17 04:48:46.349080
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='remove',
        rule_num='5',
        ip_version='ipv4',
    )
    cmd = push_arguments(iptables_path, '-D', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-D', 'INPUT', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']


# Generated at 2022-06-17 04:50:09.901776
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:17.589846
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['NEW', 'ESTABLISHED'],
        jump='ACCEPT',
        comment='Test comment',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '-s', '192.168.1.1', '-d', '192.168.1.2',
                    '-m', 'tcp', '-m', 'state', '--ctstate', 'NEW,ESTABLISHED',
                    '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Test comment']




# Generated at 2022-06-17 04:50:26.412061
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:50:28.728176
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:50:37.198482
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='remove',
        rule_num=5
    )
    remove_rule(iptables_path, module, params)



# Generated at 2022-06-17 04:50:46.704141
# Unit test for function main

# Generated at 2022-06-17 04:50:53.182928
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        comment='test',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-w', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'test']



# Generated at 2022-06-17 04:51:04.033322
# Unit test for function main

# Generated at 2022-06-17 04:51:13.363808
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:18.313472
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:52:29.054273
# Unit test for function main

# Generated at 2022-06-17 04:52:34.281679
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:52:38.838479
# Unit test for function append_rule

# Generated at 2022-06-17 04:52:48.537727
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:52:53.866888
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -P params'



# Generated at 2022-06-17 04:52:55.379679
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:53:03.486259
# Unit test for function main

# Generated at 2022-06-17 04:53:11.601935
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:53:21.960605
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:53:23.226300
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'

