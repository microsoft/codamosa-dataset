

# Generated at 2022-06-17 04:44:47.677961
# Unit test for function push_arguments

# Generated at 2022-06-17 04:44:54.430642
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:45:05.784192
# Unit test for function main

# Generated at 2022-06-17 04:45:09.069607
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:45:11.819733
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        policy='DROP',
    )
    iptables_path = 'iptables'
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:45:22.121027
# Unit test for function main

# Generated at 2022-06-17 04:45:22.938561
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:45:25.826777
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:45:34.743132
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:45:40.623309
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Allow established and related connections',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:45:55.468794
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec={})
    params = {
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        'policy': 'DROP',
    }
    set_chain_policy('iptables', module, params)



# Generated at 2022-06-17 04:46:00.082540
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.',
    }
    cmd = push_arguments(iptables_path, '-A', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '--destination-port', '80', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-17 04:46:04.051695
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:46:13.323228
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num='5',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='test comment',
        ip_version='ipv4',
    )
    assert push_arguments('iptables', '-I', params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp',
        '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment',
        'test comment'
    ]



# Generated at 2022-06-17 04:46:21.131298
# Unit test for function main

# Generated at 2022-06-17 04:46:32.245069
# Unit test for function main

# Generated at 2022-06-17 04:46:33.325574
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:46:35.028649
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:46:42.594690
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:46:54.644322
# Unit test for function main

# Generated at 2022-06-17 04:47:28.500557
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'

# Generated at 2022-06-17 04:47:29.421751
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:47:31.146365
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', 'module', 'params') == '-A INPUT -s 8.8.8.8 -j DROP'



# Generated at 2022-06-17 04:47:35.951512
# Unit test for function main

# Generated at 2022-06-17 04:47:48.253126
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:48:01.281564
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'state'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Test rule',
        ip_version='ipv4',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:48:08.210500
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FOO'}) == None



# Generated at 2022-06-17 04:48:22.093772
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:27.230666
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    params = {'table': 'filter', 'chain': 'INPUT'}
    flush_table('iptables', module, params)
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['iptables', '-t', 'filter', '-F', 'INPUT']
    assert module.run_command.call_args[1]['check_rc'] == True



# Generated at 2022-06-17 04:48:38.164661
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='test comment',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP', '-m', 'comment', '--comment', 'test comment']

    params = dict(
        chain='INPUT',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='test comment',
        ip_version='ipv6',
    )
    rule = construct_rule(params)

# Generated at 2022-06-17 04:48:58.604292
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:49:07.947068
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    cmd = push_arguments('iptables', '-A', params)

# Generated at 2022-06-17 04:49:10.648507
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec={})
    params = dict(
        chain='INPUT',
        policy='DROP',
    )
    assert set_chain_policy('iptables', module, params) == ['iptables', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:49:22.833485
# Unit test for function main

# Generated at 2022-06-17 04:49:27.837277
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str', required=True),
        table=dict(type='str', default='filter'),
        ip_version=dict(type='str', default='ipv4'),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:49:34.656460
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={
        'table': {'required': True, 'type': 'str'},
        'chain': {'required': True, 'type': 'str'},
        'ip_version': {'required': True, 'type': 'str'},
        'wait': {'required': False, 'type': 'str'},
    })
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'ip_version': 'ipv4',
        'wait': '5',
    }
    iptables_path = '/sbin/iptables'
    cmd = push_arguments(iptables_path, '-F', params, make_rule=False)

# Generated at 2022-06-17 04:49:37.412515
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-17 04:49:42.254269
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'ACCEPT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'DROP'}) == 'DROP'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'QUEUE'}) == 'QUEUE'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'RETURN'}) == 'RETURN'



# Generated at 2022-06-17 04:49:53.428885
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:02.167192
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:50:34.846107
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'filter', 'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'nat', 'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'table': 'nat', 'chain': 'INPUT'}) == 'ACCEPT'

# Generated at 2022-06-17 04:50:36.619553
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('/sbin/iptables', 'module', 'params') == None


# Generated at 2022-06-17 04:50:41.276732
# Unit test for function insert_rule
def test_insert_rule():
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'insert',
        'rule_num': '5'
    }
    iptables_path = '/sbin/iptables'
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:50:42.619693
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:50:44.644632
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == 'iptables -P params ACCEPT'



# Generated at 2022-06-17 04:50:53.647623
# Unit test for function insert_rule
def test_insert_rule():
    params = {
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'insert',
        'rule_num': 5,
        'table': 'filter'
    }
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:51:00.830164
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:11.815548
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:21.811377
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:25.444297
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '80', 'jump': 'ACCEPT'}) == True


# Generated at 2022-06-17 04:52:14.147354
# Unit test for function main

# Generated at 2022-06-17 04:52:19.949434
# Unit test for function construct_rule

# Generated at 2022-06-17 04:52:31.948653
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'LOGGING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT_ZONES'}) == 'ACCEPT'
   

# Generated at 2022-06-17 04:52:34.043984
# Unit test for function flush_table
def test_flush_table():
    assert flush_table('iptables', None, {'table': 'filter', 'chain': 'INPUT'}) == ['iptables', '-t', 'filter', '-F', 'INPUT']



# Generated at 2022-06-17 04:52:40.391319
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
    )
    assert flush_table('iptables', module, params) == ['iptables', '-t', 'filter', '-F', 'INPUT']



# Generated at 2022-06-17 04:52:51.207091
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:52:59.999217
# Unit test for function main

# Generated at 2022-06-17 04:53:04.474864
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'


# Generated at 2022-06-17 04:53:12.283282
# Unit test for function main

# Generated at 2022-06-17 04:53:21.234752
# Unit test for function main