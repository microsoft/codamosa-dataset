

# Generated at 2022-06-17 04:44:47.259987
# Unit test for function main

# Generated at 2022-06-17 04:44:57.088046
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-17 04:45:06.814259
# Unit test for function push_arguments

# Generated at 2022-06-17 04:45:13.561040
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'test_chain'}) is None



# Generated at 2022-06-17 04:45:22.254494
# Unit test for function main

# Generated at 2022-06-17 04:45:26.863529
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []



# Generated at 2022-06-17 04:45:27.662267
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:45:29.456471
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:45:37.022343
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        ip_version=dict(type='str', required=True),
        table=dict(type='str', required=True),
        chain=dict(type='str', required=True),
    ))
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
    )
    flush_table('iptables', module, params)



# Generated at 2022-06-17 04:45:40.412853
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP') == True
    assert check_present('iptables', '-C', 'INPUT', '-s', '8.8.8.8', '-j', 'ACCEPT') == False


# Generated at 2022-06-17 04:45:53.693561
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:45:58.155893
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']


# Generated at 2022-06-17 04:46:06.207467
# Unit test for function main

# Generated at 2022-06-17 04:46:13.177456
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'ACCEPT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'DROP'}) == 'DROP'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'QUEUE'}) == 'QUEUE'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'RETURN'}) == 'RETURN'



# Generated at 2022-06-17 04:46:19.440682
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == [
        'iptables',
        '-t',
        'filter',
        '-A',
        'INPUT',
        '-w',
        '-p',
        'tcp',
        '-s',
        '8.8.8.8',
        '-j',
        'DROP',
        '-m',
        'comment',
        '--comment',
        '"Block specific IP"'
    ]



# Generated at 2022-06-17 04:46:22.638948
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:46:26.590543
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    assert construct_rule(params) == ['-w', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:46:29.247832
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:46:33.934051
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        rule_num='1',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='test',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '1',
        '-s', '8.8.8.8',
        '-p', 'tcp',
        '-j', 'DROP',
        '-m', 'comment',
        '--comment', 'test',
    ]



# Generated at 2022-06-17 04:46:42.974867
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'remove',
        'rule_num': '5'
    }
    cmd = push_arguments(iptables_path, '-D', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-D', 'INPUT', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:47:01.118924
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = {
        'chain': 'INPUT',
        'policy': 'DROP',
        'table': 'filter',
    }
    assert set_chain_policy('iptables', None, params) == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:47:06.852014
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:47:18.327492
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'LOGGING'}) == 'ACCEPT'

# Generated at 2022-06-17 04:47:28.653331
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:47:34.673533
# Unit test for function construct_rule

# Generated at 2022-06-17 04:47:47.813454
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:00.782420
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:48:04.561546
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', 'module', {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '8080', 'jump': 'ACCEPT'}) == True


# Generated at 2022-06-17 04:48:14.915854
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:17.467149
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:48:34.602099
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.'
    )
    rule = construct_rule(params)
    assert rule == [
        '-p', 'tcp',
        '--dport', '22',
        '-m', 'conntrack',
        '--ctstate', 'NEW',
        '--syn',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.'
    ]



# Generated at 2022-06-17 04:48:36.282327
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', module, params) == True


# Generated at 2022-06-17 04:48:43.208823
# Unit test for function main

# Generated at 2022-06-17 04:48:48.065507
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='test comment',
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp',
        '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment',
        'test comment'
    ]



# Generated at 2022-06-17 04:48:48.951623
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.0'



# Generated at 2022-06-17 04:48:56.865168
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, dict(table='filter', chain='INPUT')) == 'ACCEPT'
    assert get_chain_policy('iptables', None, dict(table='filter', chain='FORWARD')) == 'ACCEPT'
    assert get_chain_policy('iptables', None, dict(table='filter', chain='OUTPUT')) == 'ACCEPT'



# Generated at 2022-06-17 04:49:05.696548
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == True
    assert check_present('/sbin/iptables', None, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == True

# Generated at 2022-06-17 04:49:16.594575
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='8.8.8.8',
        destination='192.168.1.1',
        jump='DROP',
        comment='Block specific IP',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '-s', '8.8.8.8', '-d', '192.168.1.1', '-j', 'DROP', '--comment', 'Block specific IP']


# Generated at 2022-06-17 04:49:25.995125
# Unit test for function main

# Generated at 2022-06-17 04:49:33.892276
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-17 04:49:54.488967
# Unit test for function main

# Generated at 2022-06-17 04:50:06.804191
# Unit test for function main

# Generated at 2022-06-17 04:50:21.374121
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:28.683099
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:40.899873
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:50:47.618951
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='remove',
        rule_num=None,
        ip_version='ipv4',
    )
    cmd = push_arguments(iptables_path, '-D', params)
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-17 04:50:51.952045
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5'
    )
    assert insert_rule('iptables', 'module', params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT'
    ]



# Generated at 2022-06-17 04:51:03.669583
# Unit test for function construct_rule

# Generated at 2022-06-17 04:51:07.964747
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'

# Generated at 2022-06-17 04:51:21.716654
# Unit test for function main

# Generated at 2022-06-17 04:51:43.492229
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', params) == True


# Generated at 2022-06-17 04:51:54.028681
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    expected = [
        '-p', 'tcp',
        '--dport', '80',
        '-m', 'conntrack',
        '--ctstate', 'NEW',
        '--syn',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept new SSH connections.',
    ]
    assert construct_rule(params) == expected



# Generated at 2022-06-17 04:52:00.969500
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:52:10.858532
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('iptables', '-A', {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'ACCEPT',
        'comment': 'Allow http',
    }) == [
        'iptables',
        '-t', 'filter',
        '-A', 'INPUT',
        '-p', 'tcp',
        '--dport', '80',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Allow http',
    ]



# Generated at 2022-06-17 04:52:18.453040
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('iptables', 'module', 'params') == 'iptables -t table -I chain rule_num protocol -s source -d destination -m match tcp_flags jump log_prefix log_level to_destination destination_ports to_source goto in_interface out_interface fragment set_counters source_port destination_port to_ports set_dscp_mark set_dscp_mark_class syn ctstate src_range dst_range match_set match_set_flags limit limit_burst uid_owner gid_owner reject_with icmp_type comment'



# Generated at 2022-06-17 04:52:26.058025
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', '1.4.21') == '1.4.21'
    assert get_iptables_version('iptables', '1.4.21\n') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.4.21\n') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.4.21') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.4.21\n\n') == '1.4.21'
    assert get_iptables_version('iptables', 'iptables v1.4.21\n\n\n') == '1.4.21'
    assert get_ipt

# Generated at 2022-06-17 04:52:27.368326
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:52:33.410933
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4',
    )
    assert get_chain_policy('iptables', module, params) == 'ACCEPT'



# Generated at 2022-06-17 04:52:39.520993
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:52:46.666395
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'table': 'nat', 'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'table': 'nat', 'chain': 'POSTROUTING'}) == 'ACCEPT'

# Generated at 2022-06-17 04:54:01.375441
# Unit test for function insert_rule

# Generated at 2022-06-17 04:54:09.212899
# Unit test for function main