

# Generated at 2022-06-17 04:44:47.040858
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:44:51.615205
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FOO'}) is None



# Generated at 2022-06-17 04:44:53.718059
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == '-D'



# Generated at 2022-06-17 04:45:02.546905
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == []


# Generated at 2022-06-17 04:45:06.842624
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-17 04:45:11.728455
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(argument_spec={})
    params = dict(
        chain='INPUT',
        table='filter',
        ip_version='ipv4',
    )
    assert get_chain_policy('iptables', module, params) == 'ACCEPT'



# Generated at 2022-06-17 04:45:17.862262
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-17 04:45:21.279191
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        comment='test rule',
    )
    rule = construct_rule(params)
    assert rule == ['-w', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'test rule']



# Generated at 2022-06-17 04:45:31.351052
# Unit test for function push_arguments

# Generated at 2022-06-17 04:45:41.591982
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port=8080,
        jump='ACCEPT',
        comment='Test rule',
    )
    assert push_arguments('iptables', '-I', params) == [
        'iptables',
        '-t',
        'filter',
        '-I',
        'INPUT',
        '5',
        '-p',
        'tcp',
        '--destination-port',
        '8080',
        '-j',
        'ACCEPT',
        '-m',
        'comment',
        '--comment',
        'Test rule',
    ]



# Generated at 2022-06-17 04:46:12.878925
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:23.561192
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:26.492377
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw', 'security']),
        chain=dict(default='INPUT'),
    ))
    params = module.params
    flush_table('iptables', module, params)



# Generated at 2022-06-17 04:46:33.300458
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:38.930585
# Unit test for function main

# Generated at 2022-06-17 04:46:40.790809
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        flush=True,
    )
    flush_table(iptables_path, module, params)



# Generated at 2022-06-17 04:46:53.402755
# Unit test for function construct_rule

# Generated at 2022-06-17 04:46:59.236429
# Unit test for function main

# Generated at 2022-06-17 04:47:10.550832
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='Block specific IP',
    )
    assert construct_rule(params) == [
        '-A', 'INPUT', '-s', '8.8.8.8', '-p', 'tcp', '-j', 'DROP', '-m',
        'comment', '--comment', 'Block specific IP',
    ]

    params = dict(
        chain='INPUT',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='Block specific IP',
        ip_version='ipv6',
    )

# Generated at 2022-06-17 04:47:12.180852
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:47:40.056655
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', module, params) == True


# Generated at 2022-06-17 04:47:43.926408
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
        table='filter',
        ip_version='ipv4',
    )
    iptables_path = 'iptables'
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:47:45.268338
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('iptables', 'module', 'params') == None



# Generated at 2022-06-17 04:47:54.592968
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-17 04:48:06.613165
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:16.892053
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FOO'}) is None



# Generated at 2022-06-17 04:48:28.721852
# Unit test for function construct_rule

# Generated at 2022-06-17 04:48:36.322121
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-17 04:48:37.126178
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'



# Generated at 2022-06-17 04:48:44.007471
# Unit test for function main

# Generated at 2022-06-17 04:49:37.434220
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda cmd, check_rc=False: (0, '', '')
    assert check_present('iptables', module, {'table': 'filter', 'chain': 'INPUT', 'jump': 'ACCEPT'})
    module.run_command = lambda cmd, check_rc=False: (1, '', '')
    assert not check_present('iptables', module, {'table': 'filter', 'chain': 'INPUT', 'jump': 'ACCEPT'})



# Generated at 2022-06-17 04:49:43.941710
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.1.2',
        match=['tcp', 'conntrack'],
        ctstate=['ESTABLISHED', 'RELATED'],
        jump='ACCEPT',
        comment='Allow new SSH connections.',
        syn='match',
        limit='2/second',
        limit_burst='20',
        uid_owner='root',
        gid_owner='root',
        reject_with='tcp-reset',
        icmp_type='echo-request',
        wait='10',
    )

# Generated at 2022-06-17 04:49:54.703463
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:04.830784
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:07.009327
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter')) == 'ACCEPT'



# Generated at 2022-06-17 04:50:11.535939
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str'),
        policy=dict(type='str', choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
    ))
    params = module.params
    iptables_path = BINS['ipv4']
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-17 04:50:23.728049
# Unit test for function main

# Generated at 2022-06-17 04:50:32.696575
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'insert',
        'rule_num': '5'
    }
    cmd = push_arguments(iptables_path, '-I', params)
    print(cmd)


# Generated at 2022-06-17 04:50:42.657465
# Unit test for function construct_rule

# Generated at 2022-06-17 04:50:43.632701
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-17 04:51:40.796150
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw', 'security']),
        chain=dict(default=None),
        ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
        flush=dict(default=False, type='bool'),
        policy=dict(default=None, choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        wait=dict(default=None),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    flush_table(iptables_path, module, params)


# Generated at 2022-06-17 04:51:49.610321
# Unit test for function append_rule

# Generated at 2022-06-17 04:51:58.722479
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    assert insert_rule('iptables', module, params) == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-17 04:52:04.204053
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', 'module', {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.'}) == True


# Generated at 2022-06-17 04:52:10.523018
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'policy': 'DROP',
    }
    iptables_path = '/sbin/iptables'
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-17 04:52:21.426484
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str', required=True),
        policy=dict(type='str', required=True, choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        table=dict(type='str', default='filter'),
        ip_version=dict(type='str', default='ipv4', choices=['ipv4', 'ipv6']),
    ))
    params = module.params
    iptables_path = BINS[params['ip_version']]
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    print(cmd)


# Generated at 2022-06-17 04:52:32.814788
# Unit test for function construct_rule

# Generated at 2022-06-17 04:52:43.406348
# Unit test for function main

# Generated at 2022-06-17 04:52:49.457389
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'



# Generated at 2022-06-17 04:52:59.324453
# Unit test for function main