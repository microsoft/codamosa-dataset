

# Generated at 2022-06-25 02:44:11.055314
# Unit test for function push_arguments
def test_push_arguments():
    print('testing function push_arguments')

# Generated at 2022-06-25 02:44:16.850329
# Unit test for function append_rule
def test_append_rule():
    try:
        test_case_0()
    except:
        print("test case 0 failed")


# Generated at 2022-06-25 02:44:20.892407
# Unit test for function check_present
def test_check_present():
    # Merge with testcases for function append_rule
    # TODO: Write additional unit tests for function check_present
    float_0 = 3403.1
    bool_0 = False
    str_0 = 'bd\n>6rtq=+tvcX=\ry`~t'
    var_0 = check_present(float_0, bool_0, str_0)


# Generated at 2022-06-25 02:44:31.367001
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = "/etc/iptables/rules.v4"
    action = "-I"
    chain = "INPUT"
    rule_num = 5
    protocol = "tcp"
    source = "8.8.8.8"
    jump = "DROP"
    comment = "Redirect web traffic to port 8600"
    table = "nat"
    params = {}
    params["iptables_path"] = iptables_path
    params["action"] = action
    params["chain"] = chain
    params["rule_num"] = rule_num
    params["protocol"] = protocol
    params["source"] = source
    params["jump"] = jump
    params["comment"] = comment
    params["table"] = table
    make_rule = True

# Generated at 2022-06-25 02:44:37.409768
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    api_0 = BINS
    int_0 = 32768
    str_0 = 'hOA0Dd"\x13\xa0\x17\x1d\x7f'
    str_1 = '\x0cIW7\x1d'
    str_2 = '\x1c1\r\r\x04\x19\x16\x01\x1a'
    str_3 = '\x1f,\r\r\x04\x19\x16\x01\x1a'
    str_4 = '\x12\x01\x14\x0c\x03\x7f\x16\x0c\x01\x19\x1e'

# Generated at 2022-06-25 02:44:40.104256
# Unit test for function flush_table
def test_flush_table():
    float_0 = 3403.1
    bool_0 = False
    dict_0 = dict(bool_0=bool_0)
    float_0 = float_0
    var_0 = flush_table(float_0, dict_0)


# Generated at 2022-06-25 02:44:42.883271
# Unit test for function set_chain_policy
def test_set_chain_policy():
    float_0 = 6.6
    bool_0 = True
    str_0 = 'N_6=X)Kq3;*h[[W'
    var_0 = set_chain_policy(float_0, bool_0, str_0)


# Generated at 2022-06-25 02:44:43.663561
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments(0, 0) == 0


# Generated at 2022-06-25 02:44:49.117170
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(
        argument_spec = dict(
            module = dict(default='', type='str'),
            params = dict(default='', type='str'),
            iptables_path = dict(default='', type='str'),
        )
    )
    module.params = dict(
        module = './ansible_collections/community/general/plugins/modules/iptables.py',
        params = '',
        iptables_path = 'ip6tables',
    )
    result = get_chain_policy(module.params['iptables_path'], module, module.params)
    print(result)


# Generated at 2022-06-25 02:44:56.365058
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    option_str = '--tcp-flags'
    # CASE0
    param = dict(flags=['ALL'], flags_set=['SYN', 'RST'])
    expected = [option_str, 'ALL,SYN,RST']

    result = []
    append_tcp_flags(result, param, option_str)
    assert result == expected

    # CASE1
    param = dict(flags=['FIN'], flags_set=['PSH', 'ACK', 'URG'])
    expected = [option_str, 'FIN,PSH,ACK,URG']

    result = []
    append_tcp_flags(result, param, option_str)
    assert result == expected


# Generated at 2022-06-25 02:45:50.449142
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = "/usr/sbin/iptables"
    module = AnsibleModule()
    params = {'table':"filter", 'chain':"INPUT"}
    result = get_chain_policy(iptables_path, module, params)
    print('get_chain_policy result is ', result)



# Generated at 2022-06-25 02:45:58.891537
# Unit test for function main
def test_main():
    ip_vers = 'ipv4'
    ip_vers = 'ipv6'
    print("Checking " + ip_vers + " chain test_chain")
    chain_name = 'test_chain'
    chain_name = 'INPUT'
    flush = True
    table_name = 'filter'
    if ip_vers == 'ipv4' and table_name in ['filter', 'nat', 'mangle', 'raw']:
        if chain_name in FILTER_CHAINS:
            print("Adding chain " + chain_name + " to " + table_name + " table")
            module.check_mode = True
            check_present(iptables_path, module, params)
        else:
            print("Test skipped: " + chain_name + " is not in " + table_name + " table")

# Generated at 2022-06-25 02:46:01.733753
# Unit test for function flush_table
def test_flush_table():
    var_0 = main()


# Generated at 2022-06-25 02:46:07.472468
# Unit test for function construct_rule
def test_construct_rule():
    assert True == False
    # assert construct_rule({"in_interface": "lo", "flush": True, "chain": "test"}) == ["-w", "iptables", "--flush", "test"]
    # assert construct_rule({"table": "raw", "chain": "test", "wait": "1", "flush": True}) == ["-w", "iptables", "--flush", "test"]


# Generated at 2022-06-25 02:46:20.436654
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/sbin/iptables'
    action = '-I'

# Generated at 2022-06-25 02:46:22.377842
# Unit test for function append_param
def test_append_param():
    rule_0 = []
    param_0 = []
    flag_0 = '--destination-port'
    is_list_0 = False
    append_param(rule_0, param_0, flag_0, is_list_0)
    assert rule_0 == ['--destination-port', '']



# Generated at 2022-06-25 02:46:28.213819
# Unit test for function flush_table

# Generated at 2022-06-25 02:46:29.059688
# Unit test for function main
def test_main():
    assert 'ERROR' not in main()


# Generated at 2022-06-25 02:46:29.752124
# Unit test for function append_rule
def test_append_rule():
    test_append_rule_0()


# Generated at 2022-06-25 02:46:41.081696
# Unit test for function construct_rule
def test_construct_rule():
    # Check that rules are constructed correctly
    params1 = dict(
        protocol='tcp',
        destination_ports='80,443,8081:8083',
        jump='ACCEPT',
        wait='2',
    )
    params2 = dict(
        protocol='tcp',
        destination_ports='80,443,8081:8083',
        jump='ACCEPT',
        wait='2',
        ip_version='ipv4',
    )
    params3 = dict(
        protocol='tcp',
        destination_ports='80,443,8081:8083',
        jump='ACCEPT',
        wait='2',
        ip_version='ipv6',
    )
    rule1 = construct_rule(params1)
    rule2 = construct_rule(params2)

# Generated at 2022-06-25 02:47:44.050726
# Unit test for function construct_rule
def test_construct_rule():
    rule = construct_rule(dict(
        chain='INPUT',
        comment='test comment',
        policy='ACCEPT',
        protocol='tcp',
        destination_port='22'
    ))
    assert rule == ['-j', 'ACCEPT', '-m', 'comment', '--comment', 'test comment']


# Generated at 2022-06-25 02:47:50.511556
# Unit test for function append_param
def test_append_param():
    rule = []
    param = "'8.8.8.8'"
    flag = '--source'
    is_list = True
    append_param(rule, param, flag, is_list)
    assert rule == ['--source', "'8.8.8.8'"]


# Generated at 2022-06-25 02:48:01.274552
# Unit test for function remove_rule
def test_remove_rule():
    list_0 = ["/usr/sbin/iptables", "-D", "INPUT", "-p", "tcp", "-s", "192.168.1.2", "--destination-port", "22", "-j", "ACCEPT", "2", "-m", "comment", "--comment", "\"Accept new SSH connections.\""]

# Generated at 2022-06-25 02:48:03.527374
# Unit test for function main
def test_main():
    print("test_main")
    r = main()
    print("test_main: ", r)
    print("Return value: ", r)


# Generated at 2022-06-25 02:48:09.241734
# Unit test for function get_chain_policy
def test_get_chain_policy():
    params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4',
    )
    assert get_chain_policy(params) == None



# Generated at 2022-06-25 02:48:10.330603
# Unit test for function get_chain_policy
def test_get_chain_policy():
    
    var_0 = main()
    # Module ansible.builtin.iptables has no attribute get_chain_policy
    pass
    

# Generated at 2022-06-25 02:48:12.101387
# Unit test for function set_chain_policy
def test_set_chain_policy():
    var_0 = set_chain_policy()
    try:
        assert var_0 == 3
    except:
        return var_0


# Generated at 2022-06-25 02:48:15.087189
# Unit test for function main
def test_main():
    # Run a test case for function main
    # <insert a test case here>
    # test_case_0()
    # test_case_1()
    # ...
    # test_case_N()
    # Now call main
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:48:23.999254
# Unit test for function construct_rule
def test_construct_rule():
    params = {
        'timeout':  30,
        'state': 'present',
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
    }
    expected = ['-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']
    rule = construct_rule(params)
    assert (rule == expected)



# Generated at 2022-06-25 02:48:30.305750
# Unit test for function construct_rule

# Generated at 2022-06-25 02:50:10.117709
# Unit test for function main
def test_main():
    # Test case main

    # setup
    class AnsibleModule(object):

        def __init__(self, supports_check_mode=True, argument_spec=dict()):
            self.supports_check_mode = supports_check_mode
            self.argument_spec = argument_spec

        def get_bin_path(self, name, required=False):
            self.name = name
            self.required = required
            return "iptables"

        def exit_json(self, **kwargs):
            self.kwargs = kwargs

        def fail_json(self, msg):
            self.msg = msg

        def run_command(self, cmd, check_rc=True):
            self.cmd = cmd
            self.check_rc = check_rc
            if self.cmd[3] == "-F":
                return

# Generated at 2022-06-25 02:50:11.509619
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = get_chain_policy()
    var_1 = get_chain_policy()
    return var_0 or var_1


# Generated at 2022-06-25 02:50:16.315386
# Unit test for function append_match_flag
def test_append_match_flag():
    # Input parameters
    rule = ['-A', 'INPUT', '-i', 'eth0', '-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '-m', 'tcp', '--syn', '-m', 'comment']
    param = 'negate'
    flag = '--syn'
    negatable = True

    # Expected output
    expected = ['-A', 'INPUT', '-i', 'eth0', '-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '-m', 'tcp', '!', '--syn', '-m', 'comment']

    # Actual output

# Generated at 2022-06-25 02:50:18.381989
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'iptables'
    module = 1
    params = {'chain': 'INPUT', 'source': '8.8.8.8', 'jump': 'DROP', 'table': 'mangle'}
    append_rule(iptables_path, module, params)


# Generated at 2022-06-25 02:50:24.571381
# Unit test for function set_chain_policy
def test_set_chain_policy():
    # Defines value for the variables
    var_0 = "iptables"
    var_1 = {}
    var_2 = "iptables"
    var_1["table"] = var_2
    var_1["chain"] = var_2
    var_1["policy"] = var_2
    var_1["action"] = var_2
    var_1["state"] = var_2
    var_1["chain_policy"] = var_2
    var_1["flush"] = var_2
    var_1["rule_num"] = var_2
    var_1["protocol"] = var_2
    var_1["source"] = var_2
    var_1["destination"] = var_2
    var_1["source_port"] = var_2

# Generated at 2022-06-25 02:50:30.081617
# Unit test for function append_rule

# Generated at 2022-06-25 02:50:31.263761
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = main()
    assert var_0 == 0


# Generated at 2022-06-25 02:50:36.770590
# Unit test for function construct_rule

# Generated at 2022-06-25 02:50:45.753521
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = main()
    var_1 = BINS.get("ipv4")
    var_2 = var_0.get("params")
    var_3 = var_2.get("table")
    var_4 = var_2.get("chain")
    var_5 = get_chain_policy(var_1,var_0,var_2)


# Generated at 2022-06-25 02:50:55.983154
# Unit test for function push_arguments
def test_push_arguments():
    # var_args = []
    # var_kwargs = {"action": None, "iptables_path": None, "make_rule": None, "params": -1716443614}
    # var_1 = push_arguments(*var_args, **var_kwargs)

    var_1 = push_arguments(
        '-1716443614',
        '-1716443614',
        -724776432,
        -1716443614)
    test_assert(-1716443614, var_1)

    var_2 = push_arguments(
        '-1716443614',
        '-1716443614',
        -1716443614,
        '-1716443614')
    test_assert(-1716443614, var_2)



# Generated at 2022-06-25 02:51:46.372550
# Unit test for function flush_table
def test_flush_table():
    iptables_path = 'iptables'
    module = AnsibleModule()
    params = {'rule_num': None, 'table': 'table', 'chain': 'chain', 'state': 'present', 'flush': 'flush'}
    flush_table(iptables_path, module, params)


# Generated at 2022-06-25 02:51:55.509868
# Unit test for function insert_rule
def test_insert_rule():
    var_0 = 'iptables'

# Generated at 2022-06-25 02:51:59.856804
# Unit test for function check_present
def test_check_present():
    ip_version = 'ipv4'
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(
                default='present',
                choices=['absent', 'present']
            ),
            ip_version=dict(
                default=ip_version,
                choices=['ipv4', 'ipv6']
            ),
        )
    )
    module.params['ip_version'] = 'ipv4'
    module.params['state'] = 'present'
    iptables_path = 'iptables'

# Generated at 2022-06-25 02:52:10.425109
# Unit test for function push_arguments
def test_push_arguments():

    # Format the variables
    iptables_path = 'iptables'
    action = '-I'
    params = {'table': 'nat', 'chain': 'PREROUTING', 'jump': 'REDIRECT', 'ip_version': 'ipv4', 'to_ports': '8600', 'destination_port': '80', 'action': 'insert', 'in_interface': 'eth0'}

    # Execute the module method
    ret_obj = push_arguments(iptables_path, action, params, False)

    # Print the result
    print("\n")
    print("Result returned by push_arguments() is:\n")
    print("=========================================================")
    print("\n")
    print(ret_obj)
    print("\n")
    print("=========================================================")
    print

# Generated at 2022-06-25 02:52:11.631791
# Unit test for function insert_rule
def test_insert_rule():
    var_1 = construct_rule()
    this_0 = main()
    insert_rule(var_1, this_0)


# Generated at 2022-06-25 02:52:22.378534
# Unit test for function construct_rule
def test_construct_rule():
    main()

# Generated at 2022-06-25 02:52:31.896323
# Unit test for function append_rule
def test_append_rule():
    var_0 = main()
    var_1 = append_rule(var_0[0], var_0[1], var_0[2])
    var_2 = push_arguments(var_0[0], '-A', var_0[2])
    var_2 = var_2.split(' ')
    var_2[var_2.index('-t')] = var_0[2]['table']
    var_2[var_2.index('-C')] = '-A'
    var_2 = ' '.join(var_2)
    var_3 = module.run_command(var_2, var_3)
    var_3 = (var_3 == 0)
    return var_3
    pass


# Generated at 2022-06-25 02:52:33.422453
# Unit test for function append_rule
def test_append_rule():
    msg = 'Check append rule'
    assert test_append_rule(append_rule) == msg


# Generated at 2022-06-25 02:52:43.665632
# Unit test for function main
def test_main():
    # Testing function 'get_iptables_version'
    class mock_get_iptables_version:
        def __call__(self, iptables_path, module):
            return None
    # Assigning mocked function to a variable
    get_iptables_version = mock_get_iptables_version()
    # Assigning mocked variable to a new variable
    var_0 = get_iptables_version
    # Testing function 'get_chain_policy'
    class mock_get_chain_policy:
        def __call__(self, iptables_path, module, params):
            return None
    # Assigning mocked function to a variable
    get_chain_policy = mock_get_chain_policy()
    # Assigning mocked variable to a new variable
    var_1 = get_chain_policy
    # Testing function 'flush_table

# Generated at 2022-06-25 02:52:51.317500
# Unit test for function push_arguments
def test_push_arguments():
    var_0 = 'iptables'
    var_1 = '-I'
    var_2 = dict()
    var_2[u'jump'] = 'ACCEPT'
    var_2[u'table'] = 'filter'
    var_2[u'chain'] = 'INPUT'
    var_3 = True
    var_4 = bool()
    var_5 = bool()
    var_6 = bool()
    var_7 = bool()
    var_8 = bool()
    var_9 = bool()
    var_10 = bool()
    var_11 = bool()
    var_12 = bool()
    var_13 = bool()
    var_14 = bool()
    var_15 = bool()
    var_16 = bool()
    var_17 = bool()
    var_18 = bool()
