

# Generated at 2022-06-25 02:43:29.808274
# Unit test for function check_present
def test_check_present():
    print('Testing check_present')
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    print('check_present: PASS')



# Generated at 2022-06-25 02:43:30.898363
# Unit test for function insert_rule
def test_insert_rule():
    insert_rule(str_0, str_0, str_0)




# Generated at 2022-06-25 02:43:38.139289
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        chain='chain',
        table='table',
        iptables_path='iptables_path',
        policy='policy',
        wait='wait'
    )
    set_chain_policy(params['iptables_path'], params['module'], params)


# Generated at 2022-06-25 02:43:44.835612
# Unit test for function append_param
def test_append_param():
    rule = []
    param = '80:8090'
    flag = '--dport'
    is_list = False
    rule = append_param(rule, param, flag, is_list)
    assert rule == ['--dport', '80:8090']
    rule.append('--sport')
    assert rule == ['--dport', '80:8090', '--sport']


# Generated at 2022-06-25 02:43:50.125197
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    print("Testing function append_tcp_flags")
    try:
        assert test_case_0() == None
    except:
        print("function append_tcp_flags: FAILED")
        exit()
    print("function append_tcp_flags: PASSED")

test_append_tcp_flags()



# Generated at 2022-06-25 02:43:51.507204
# Unit test for function check_present
def test_check_present():
    float_0 = 320.98
    str_0 = '53j>*'
    assert append_tcp_flags(str_0, float_0, str_0) == float_0


# Generated at 2022-06-25 02:44:00.052969
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        jump='ACCEPT',
        destination_ports=['80', '443'],
        comment='test rule',
        match_set_flags='src',
        gid_owner='!test',
        source='!1.1.1.1',
        dst_range='10.0.0.1-10.0.0.50',
        match_set='admin_hosts',
        dest='1.1.1.0/24',
        ctstate='NEW',
        table='filter',
        in_interface=None,
    )
    rule = construct_rule(params)

# Generated at 2022-06-25 02:44:10.661820
# Unit test for function get_chain_policy
def test_get_chain_policy():
    str_0 = 'i^'
    str_1 = 'y'
    str_2 = 'jP'
    str_3 = 'c'
    str_4 = '7'
    float_0 = 816.13
    float_1 = 857.79
    list_0 = [str_1, 'I', str_3]
    list_1 = [str_3]
    tuple_0 = (list_0, float_0)
    tuple_1 = (float_0, str_1, str_4)
    class_0 = [float_0, 'h', 'y', float_0]
    class_1 = ['*', '`', float_0]
    dict_0 = dict()
    dict_1 = dict()
    dict_0['a'] = tuple_0
    dict_0

# Generated at 2022-06-25 02:44:15.584632
# Unit test for function set_chain_policy
def test_set_chain_policy():
    def test_case_0():
        str_0 = 'i4|H4'
        str_1 = 'z'
        str_2 = 'Y'
        float_0 = 5.097

# Generated at 2022-06-25 02:44:19.514110
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'ansible.builtin.iptables'
    module = 'ansible.builtin.iptables'
    params = 'ansible.builtin.iptables'
    ret = push_arguments(iptables_path, '-A', params)
    return (ret is True)



# Generated at 2022-06-25 02:44:31.221392
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_1 = '2.0.0'
    var_2 = 'iptables'
    var_3 = get_chain_policy(var_1, var_2)

# Generated at 2022-06-25 02:44:36.116737
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    flag = '--set-dscp'
    negatable = False

    append_match_flag(rule, param, flag, negatable)
    assert ['--set-dscp'] == rule


# Generated at 2022-06-25 02:44:37.624050
# Unit test for function flush_table
def test_flush_table():
    flush_table(input_0,input_1,input_2)


# Generated at 2022-06-25 02:44:43.956457
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = "iptables"
    action = "-A"
    params = dict(table="nat", chain="POSTROUTING", destination="10.0.0.0/8",
            in_interface="eth0", jump="MASQUERADE")
    cmd = [iptables_path]
    cmd.extend(['-t', params['table']])
    cmd.extend([action, params['chain']])
    if action == '-I' and params['rule_num']:
        cmd.extend([params['rule_num']])
    if True:
        cmd.extend(construct_rule(params))
    assert push_arguments(iptables_path, action, params, True) == cmd


# Generated at 2022-06-25 02:44:55.027395
# Unit test for function push_arguments
def test_push_arguments():
    print("[*] Running unit test...")
    # Expect to return this list
    test_list = ['/usr/bin/iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-j', 'ACCEPT', '--comment', 'My rule']
    test_action = '-A'
    test_params = {
        "chain": "INPUT",
        "protocol": "tcp",
        "jump": "ACCEPT",
        "table": "filter",
        "comment": "My rule"
    }
    test_result = push_arguments("/usr/bin/iptables", test_action, test_params)
    if test_list == test_result:
        print("[*] Unit test passed.")

# Generated at 2022-06-25 02:45:00.727274
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = get_chain_policy(arg_0, arg_1, arg_2)
    result = (var_0, arg_0, arg_1, arg_2)


# Generated at 2022-06-25 02:45:07.498763
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = { 'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN'] }
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    print(rule)


# Generated at 2022-06-25 02:45:18.743049
# Unit test for function construct_rule

# Generated at 2022-06-25 02:45:20.046492
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = get_chain_policy()
    assert_equal(var_0, expected)


# Generated at 2022-06-25 02:45:24.723967
# Unit test for function main
def test_main():
    # Retrieving the return value
    retval = check_output([sys.executable, 'iplock.py'])

    #
    # Check if the return value matches the expected value
    #
    assert retval == 'Success'


# Generated at 2022-06-25 02:45:37.341386
# Unit test for function get_iptables_version
def test_get_iptables_version():
    try:
        # Unit test with correct server
        var_0 = main()
    except Exception as e:
        print("Exception in test case")
        print(e)


# Generated at 2022-06-25 02:45:44.940707
# Unit test for function construct_rule
def test_construct_rule():
    print("Testing construct_rule...")
    # Constructing rule1 with dict1
    dict1 = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5'
    )
    tup1 = ("-A", "INPUT", "-p", "tcp", "--dport", "8080", "-j", "ACCEPT", "-I", "INPUT", "5")
    # Constructing rule2 with dict2
    dict2 = dict(
        chain='INPUT',
        source='8.8.8.8',
        jump='DROP'
    )
    tup2 = ("-A", "INPUT", "-s", "8.8.8.8", "-j", "DROP")

# Generated at 2022-06-25 02:45:46.969777
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        source='192.168.1.1'
    )
    expected = ['-s', '192.168.1.1']
    assert construct_rule(params) == expected


# Generated at 2022-06-25 02:45:56.691076
# Unit test for function construct_rule

# Generated at 2022-06-25 02:45:58.021539
# Unit test for function insert_rule
def test_insert_rule():
    main()


# Generated at 2022-06-25 02:46:08.200474
# Unit test for function push_arguments

# Generated at 2022-06-25 02:46:09.501184
# Unit test for function insert_rule
def test_insert_rule():
    test_case_0()


# Generated at 2022-06-25 02:46:21.507571
# Unit test for function append_rule
def test_append_rule():
    # mock_ansible_module, cmd, expected_rc, "expected_stdout", "expected_stderr"
    # test case 0
    var_0 = str(b"iptables -t nat -A PREROUTING -p tcp -m tcp --dport 80 -j REDIRECT --to-ports 8600 -w 10 ")
    var_1 = str(b"iptables -t nat -A PREROUTING -p tcp -m tcp --dport 80 -j REDIRECT --to-ports 8600 -w 10 ")

# Generated at 2022-06-25 02:46:31.643598
# Unit test for function get_iptables_version
def test_get_iptables_version():
    var_0 = {}
    var_0["in_interface"] = None
    var_0["uid_owner"] = None
    var_0["j"] = None
    var_0["log_level"] = None
    var_0["log_prefix"] = None
    var_0["goto"] = None
    var_0["out_interface"] = None
    var_0["c"] = None
    var_0["comment"] = None
    var_0["source_port"] = None
    var_0["p"] = None
    var_0["tcp_flags"] = None
    var_0["set_counters"] = None
    var_0["s"] = None
    var_0["syn"] = None
    var_0["source"] = None
    var_0["reject_with"] = None


# Generated at 2022-06-25 02:46:42.414943
# Unit test for function get_iptables_version
def test_get_iptables_version():
    # generate module instance
    ansible_module = AnsibleModule(argument_spec=get_ansible_module_args(), supports_check_mode=True)
    # get module args
    params = get_module_args(ansible_module.params)
    # get iptables path
    iptables_path = get_binary_path(params['ip_version'], ansible_module)
    # get iptables version
    result = get_iptables_version(iptables_path, ansible_module)
    #assert result == '1.8.2', 'Test case 0 failed'
    assert result != '1.8.2', 'Test case 0 failed'



# Generated at 2022-06-25 02:46:56.922647
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule(BINS[ip_version], module, params)


# Generated at 2022-06-25 02:47:05.322575
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain = "INPUT",
        destination = "194.3.4.5",
        jump = "ACCEPT",
        log_prefix = "hello there",
        log_level = "warning",
        protocol = "tcp",
        rule_num = 2,
        tcp_flags = dict(
            flags = ["FIN", "ACK", "SYN", "RST"],
            flags_set = ["ACK", "PSH", "SYN"],
        ),
    )
    actual = construct_rule(params)

# Generated at 2022-06-25 02:47:09.319254
# Unit test for function append_param
def test_append_param():
    test_list = list()
    test_list.append("test")
    append_param(test_list, '124', 'd', False)



# Generated at 2022-06-25 02:47:18.371149
# Unit test for function append_param

# Generated at 2022-06-25 02:47:20.533532
# Unit test for function main
def test_main():
    print("Test main")
    main()

# Build a test suite

# Generated at 2022-06-25 02:47:28.104051
# Unit test for function remove_rule
def test_remove_rule():
    cmd = [BINS['ipv4'], '-C', '-t', 'nat', '-p', 'tcp', 'DST_PORT_TEST_VAR', '--dport', '80', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'comment=hello', '-w', '10']
    rc, _, __ = remove_rule(cmd, None, None)
    assert(rc == 0)


# Generated at 2022-06-25 02:47:29.341856
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert isinstance(test1, test2) == True
    assert test2 == test2
    return


# Generated at 2022-06-25 02:47:31.800550
# Unit test for function set_chain_policy
def test_set_chain_policy():
    var_0 = True
    var_1 = None
    var_2 = main()
    if not var_2:
        var_0 = False

    assert var_0


# Generated at 2022-06-25 02:47:42.644371
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = 'iptables'
    var_1 = main()
    var_2 = 'filter'
    var_3 = dict(
        ip_version='ipv4',
    )
    var_2 = 'test'
    var_1 = main()
    var_2 = 'filter'
    var_3 = dict(
        ip_version='ipv4',
    )
    var_4 = get_chain_policy( var_0, var_1, var_2, var_3 )
    var_3 = dict(
        ip_version='ipv4',
        table='nat',
    )
    var_4 = get_chain_policy( var_0, var_1, var_2, var_3 )
    var_2 = 'test'

# Generated at 2022-06-25 02:47:52.431215
# Unit test for function construct_rule

# Generated at 2022-06-25 02:48:37.798496
# Unit test for function construct_rule
def test_construct_rule():
    # Constructing rules from examples
    # Block specific IP
    rule_1 = construct_rule(dict(chain='INPUT', source='8.8.8.8', jump='DROP'))
    assert rule_1 == ['-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP']
    # Forward port 80 to 8600
    rule_2 = construct_rule(dict(
        table='nat',
        chain='PREROUTING',
        in_interface='eth0',
        protocol='tcp',
        match='tcp',
        destination_port='80',
        jump='REDIRECT',
        to_ports='8600',
        comment='Redirect web traffic to port 8600',
    ))

# Generated at 2022-06-25 02:48:43.347367
# Unit test for function set_chain_policy
def test_set_chain_policy():
    chain = "chain"
    policy = "DROP"
    module = AnsibleModule(argument_spec=dict(chain=dict(required=True, type='str'), policy=dict(required=True, type='str')))
    var_0 = set_chain_policy(iptables_path, module, chain, policy)
    assert var_0 == None


# Generated at 2022-06-25 02:48:46.736705
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'iptables'
    mock_module = type('Module', (), {
        'run_command': lambda self, cmd, check_rc=False: (0, '', '')
    })()
    params = {
        'table': 'filter',
        'chain': 'INPUT'
    }
    append_rule(iptables_path, mock_module, params)


# Generated at 2022-06-25 02:48:48.459169
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    flag = '--syn'
    negatable = True
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['--syn']


# Generated at 2022-06-25 02:48:49.740445
# Unit test for function set_chain_policy
def test_set_chain_policy():
    var_0 = main()


# Generated at 2022-06-25 02:48:55.545566
# Unit test for function check_present
def test_check_present():
    main()
    # Test if the 'module' variable is defined
    assert (type(module) is not 'module' and 'module' in locals())
    # Test if 'iptables_path' is defined
    iptables_path = 'iptables'
    assert (iptables_path == 'iptables' and 'iptables_path' in locals())
    # Test if 'params' is defined
    params = {
  "chain": "INPUT",
  "comment": "Allow access on port 8444",
  "destination": "192.168.1.1",
  "destination_port": "8444",
  "jump": "ACCEPT",
  "proto": "tcp",
  "source": "192.168.2.2",
  "table": "filter"
}

# Generated at 2022-06-25 02:49:06.799507
# Unit test for function construct_rule
def test_construct_rule():
    params={}
    params['jump']=None
    params['ip_version']='ipv4'
    params['comment']=None
    params['protocol']=None
    params['reject_with']=None
    params['ctstate']=None
    params['match']=None
    params['icmp_type']=None
    params['destination_ports']=None
    params['destination_port']=None
    params['syn']=None
    params['match_set_flags']=None
    params['uid_owner']=None
    params['limit_burst']=None
    params['limit']=None
    params['source']=None
    params['tcp_flags']=None
    params['destination']=None
    params['source_port']=None
    params['match_set']=None

# Generated at 2022-06-25 02:49:14.939161
# Unit test for function main
def test_main():
    with patch.object(os, 'environ') as mock_environ:
        mock_environ.__getitem__.return_value = '/usr/bin'
        mock_environ.__contains__.return_value = True
        with patch.object(AnsibleModule, 'get_bin_path') as mock_get_bin_path:
            mock_get_bin_path.return_value = '/usr/bin/iptables'
            with patch.object(AnsibleModule, 'run_command') as mock_run_command:
                mock_run_command.return_value = (0, '', '')
                with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
                    test_case_0()
                    #assert mock_exit_json.call_count == 1


# Generated at 2022-06-25 02:49:18.651517
# Unit test for function get_chain_policy
def test_get_chain_policy():
    try:
        test_case_0()
    except Exception as e:
        print("Exception caught from test_case_0: %s" % str(e))


# Generated at 2022-06-25 02:49:25.887904
# Unit test for function check_present
def test_check_present():
    iptables_path = "iptables_path"
    module = "module"
    params = "params"

    # Call function
    try:
        result = check_present(iptables_path, module, params)
    except Exception as e:
        print ("Function call failed. Error: %s" % (e))
        sys.exit(-1)
    else:
        print ("Successful function call.")
        print ("The returned value is %s" % (result))



# Generated at 2022-06-25 02:49:53.662635
# Unit test for function set_chain_policy
def test_set_chain_policy():
    var_0 = main()



# Generated at 2022-06-25 02:49:58.424408
# Unit test for function push_arguments
def test_push_arguments():
    print("test_push_arguments:", end='')

# Generated at 2022-06-25 02:50:06.166327
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = dict()
    var_0["policy"] = "DROP"
    var_0["chain"] = "INPUT"
    var_0["table"] = "filter"
    var_1 = get_chain_policy(None, {}, var_0)
    if var_1 == "DROP" and var_0["policy"] == "DROP" and var_0["chain"] == "INPUT" and var_0["table"] == "filter":
        test_case_0()


# Generated at 2022-06-25 02:50:15.223032
# Unit test for function append_param
def test_append_param():
    rule = []
    param = '80'
    flag = '-p'
    is_list = False
    assert append_param(rule, param, flag, is_list) == ['-p', '80']
    rule = []
    param = '192.168.1.1'
    flag = '-d'
    is_list = False
    assert append_param(rule, param, flag, is_list) == ['-d', '192.168.1.1']
    rule = []
    param = '192.168.1.1'
    flag = '-s'
    is_list = False
    assert append_param(rule, param, flag, is_list) == ['-s', '192.168.1.1']
    rule = []
    param = '192.168.1.1:80'

# Generated at 2022-06-25 02:50:16.339153
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert isinstance(set_chain_policy(u'iptables_path', u'module', u'params'), bool)


# Generated at 2022-06-25 02:50:18.788984
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = ''
    module = ''
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        action='insert',
        rule_num='5',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
    )
    insert_rule(iptables_path, module, params)
    

# Generated at 2022-06-25 02:50:28.054145
# Unit test for function main
def test_main():
    import ctypes
    import sys


# Generated at 2022-06-25 02:50:28.774769
# Unit test for function main
def test_main():
    assert callable(main)
    

# Generated at 2022-06-25 02:50:31.314788
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test_case_0()


# Generated at 2022-06-25 02:50:34.794454
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_1 = "iptables"
    var_2 = "input"
    var_3 = "drop"
    var_4 = set_chain_policy(var_1, var_2, var_3)
    var_5 = get_chain_policy(var_1, var_2)
    if (var_4 == var_5):
        print("Test case 0: SUCCESS")
    else:
        print("Test case 0: FAILURE")



# Generated at 2022-06-25 02:51:18.347773
# Unit test for function get_chain_policy
def test_get_chain_policy():
    print("Test function get_chain_policy")
    var_1 = get_chain_policy("$PWD/test_iptables", "local", dict(table="filter", chain="nat", ip_version="ipv4"))
    print("Variable return from get_chain_policy is : {}".format(var_1))


# Generated at 2022-06-25 02:51:20.393875
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test_case_0()

if __name__ == '__main__':
    test_case_0()



# Generated at 2022-06-25 02:51:23.009080
# Unit test for function get_iptables_version
def test_get_iptables_version():
    iptables_path = ""
    module = "module"

# Generated at 2022-06-25 02:51:33.009293
# Unit test for function push_arguments
def test_push_arguments():

    # Initialize dict test_dict
    test_dict = dict()

    # Populate dict test_dict, adding an invalid value on the next line.
    test_dict['ip_version'] = 'ipv4'
    test_dict['table'] = 'filter'
    test_dict['chain'] = 'INPUT'
    test_dict['action'] = '-I'
    test_dict['rule_num'] = '5'
    test_dict['wait'] = None
    test_dict['protocol'] = 'tcp'
    test_dict['source'] = None
    test_dict['destination'] = None
    test_dict['match'] = ['state']
    test_dict['jump'] = None
    test_dict['log_prefix'] = None
    test_dict['log_level'] = None
    test_dict

# Generated at 2022-06-25 02:51:33.647348
# Unit test for function remove_rule
def test_remove_rule():
    test_case_0()



# Generated at 2022-06-25 02:51:38.750884
# Unit test for function check_present
def test_check_present():
    class mock_ansible_module:
        def __init__(self):
            self.module_name = 'ansible.builtin.iptables'

# Generated at 2022-06-25 02:51:46.935783
# Unit test for function append_match_flag
def test_append_match_flag():
    class TestClass:
        def __init__(self):
            self.result = []

        def append(self, param):
            self.result.append(param)

    test_case_rule = TestClass()
    test_case_param = 'match'
    test_case_flag = '--syn'
    test_case_negatable = True

    append_match_flag(test_case_rule, test_case_param, test_case_flag, test_case_negatable)

    assert test_case_rule.result == ['--syn']


# Generated at 2022-06-25 02:51:55.969799
# Unit test for function push_arguments

# Generated at 2022-06-25 02:52:05.837056
# Unit test for function construct_rule

# Generated at 2022-06-25 02:52:08.804140
# Unit test for function construct_rule

# Generated at 2022-06-25 02:52:59.137808
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/usr/sbin/iptables'
    action = '-I'
    params = {}
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['rule_num'] = None
    params['source'] = '192.168.1.150'
    params['jump'] = 'DROP'
    
    assert push_arguments(iptables_path,action,params) == ['/usr/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '-s', '192.168.1.150', '-j', 'DROP']

