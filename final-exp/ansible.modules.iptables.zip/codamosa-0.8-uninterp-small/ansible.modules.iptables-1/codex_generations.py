

# Generated at 2022-06-25 02:43:33.255187
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-25 02:43:43.069307
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = 'iptables'
    action = '-A'
    params = {
        'state': 'present',
        'table': 'filter',
        'chain': 'INPUT',
        'action': 'append',
        'destination_port': '80',
        'ip_version': 'ipv4',
        'jump': 'ACCEPT'
    }
    actual_output = push_arguments(iptables_path, action, params)
    expected_output = [
        'iptables',
        '-t', 'filter',
        '-A', 'INPUT',
        '-p', 'tcp',
        '--dport', '80',
        '-j', 'ACCEPT'
    ]
    assert actual_output == expected_output



# Generated at 2022-06-25 02:43:45.849758
# Unit test for function append_rule
def test_append_rule():
    try:
        # Testing case 0
        str_0 = 'm\n01[$c'
        bool_0 = True
        test_case_0()
    except AssertionError:
        raise AssertionError("Test case 0 for function append_rule failed.")
    except ValueError:
        raise ValueError("An error occurred in test case 0 for function append_rule.")


# Generated at 2022-06-25 02:43:51.849534
# Unit test for function set_chain_policy
def test_set_chain_policy():
    p = dict(
        table='filter',
        chain='INPUT',
        policy='DROP',
    )

    # Create an IPv4 rule
    p['ip_version'] = 'ipv4'
    p['binary'] = IPTABLES_PATH
    set_chain_policy(IPTABLES_PATH, module, p)



# Generated at 2022-06-25 02:44:00.070762
# Unit test for function push_arguments

# Generated at 2022-06-25 02:44:06.977938
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    # Test case 1
    str_0 = 'm\n01[$c'
    bool_0 = True
    param = [str_0]
    flag = '{"'
    rule = []
    append_tcp_flags(rule, param, flag)
    var_0 = main()


# Generated at 2022-06-25 02:44:11.341939
# Unit test for function check_present
def test_check_present():
    params = {'protocol': 'tcp', 'jump': 'DROP', 'chain': 'INPUT',
              'table': 'filter', 'ip_version': 'ipv4'}
    # Test case 0
    iptables_path = '/sbin/iptables'
    module = 'ansible.module_utils.basic'
    bool_0 = check_present(iptables_path, module, params)
    assert bool_0 == True


# Generated at 2022-06-25 02:44:22.878600
# Unit test for function insert_rule
def test_insert_rule():
    str0 = 'v'
    command_0 = '        ansible.builtin.iptables: \n          \n                \n          \n      \n            \n    \n'
    # str1 = 'v'
    # params_0 = 'table: nat\n        chain: PREROUTING\n        in_interface: eth0\n        protocol: tcp\n        match: tcp\n        destination_port: 80\n        jump: REDIRECT\n        to_ports: 8600\n        comment: Redirect web traffic to port 8600\n'

# Generated at 2022-06-25 02:44:29.456554
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    # Input parameters
    rule = None
    param = None
    flag = None

    # Expected output
    # Call the function
    # Compare expected output with actual output
    assert (append_tcp_flags(rule, param, flag) == None)



# Generated at 2022-06-25 02:44:34.777866
# Unit test for function append_match_flag
def test_append_match_flag():
    str_0 = 'm\n01[$c'
    bool_0 = True
    var_0 = main()



# Generated at 2022-06-25 02:44:45.588480
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule_0 = ['m', '01[$c']

    append_tcp_flags(rule_0, test_case_0(), 'm\n01[$c')

    assert rule_0 == [('m', '01[$c', 'm', '01[$c', 'm', '01[$c', 'm', '01[$c', 'm', '01[$c')]


# Generated at 2022-06-25 02:44:46.729571
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(str_0, bool_0, bool_0) == bool_0


# Generated at 2022-06-25 02:44:58.664201
# Unit test for function construct_rule
def test_construct_rule():
    params = dict()

    params['wait'] = 'wait'
    params['protocol'] = 'protocol'
    params['source'] = 'source'
    params['destination'] = 'destination'
    params['match'] = 'match'
    params['tcp_flags'] = 'tcp_flags'
    params['jump'] = 'jump'
    params['log_prefix'] = 'log_prefix'
    params['log_level'] = 'log_level'
    params['to_destination'] = 'to_destination'
    params['destination_ports'] = 'destination_ports'
    params['to_source'] = 'to_source'
    params['goto'] = 'goto'
    params['in_interface'] = 'in_interface'
    params['out_interface'] = 'out_interface'

# Generated at 2022-06-25 02:45:02.856899
# Unit test for function get_iptables_version
def test_get_iptables_version():
    iptables_path = 'iptables'
    module = 'mock_module'

    test_case = call(iptables_path, module)
    get_iptables_version(iptables_path, module)

    assert test_case == get_iptables_version(iptables_path, module)


# Generated at 2022-06-25 02:45:04.692617
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = 'iptables'
    module = AnsibleModule
    params = dict()
    test_case_0()
    get_chain_policy(iptables_path, module, params)



# Generated at 2022-06-25 02:45:12.479832
# Unit test for function push_arguments
def test_push_arguments():
    str_0 = 'k\x0b=\x13'

# Generated at 2022-06-25 02:45:18.505979
# Unit test for function insert_rule
def test_insert_rule():
    rule_num_0 = 'Cv}Mq3_4CzBJ'
    iptables_path_0 = '`o^g(=DVA"Hk'
    iptables_path_1 = '1'
    state_0 = 'present'
    destination_port_0 = 'uBn2'
    ctstate_0 = 'p'
    destination_0 = '<_N'
    source_0 = 'N'
    uid_owner_0 = 'J'
    dst_range_0 = 'a'
    to_destination_0 = 'O'
    protocol_0 = '['
    chain_0 = '${'
    log_prefix_0 = '7'
    jump_0 = 'g'
    table_0 = 'JF'

# Generated at 2022-06-25 02:45:20.397149
# Unit test for function set_chain_policy
def test_set_chain_policy():
    str_0 = 'm\n01[$c'
    bool_0 = True
    assert bool_0


# Generated at 2022-06-25 02:45:23.775351
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(str_0, bool_0, bool_0) == 'QW'


# Generated at 2022-06-25 02:45:24.726922
# Unit test for function insert_rule
def test_insert_rule():
    assert test_case_0() == '01[$c'


# Generated at 2022-06-25 02:45:43.864637
# Unit test for function push_arguments
def test_push_arguments():
    path_0 = '<repr(str_0)'
    str_0 = 'k\x0b=\x13'
    str_1 = '=\x13k\x0b'
    str_2 = 'k\x0b=\x13'
    str_3 = '\x0bk=\x13'
    str_4 = "iptables"
    str_5 = '=\x13k\x0b'
    str_6 = 'k\x0b=\x13'
    str_7 = '=\x13k\x0b'
    str_8 = '\x13k=\x0b'
    str_9 = 'k\x0b=\x13'
    str_10 = "input"

# Generated at 2022-06-25 02:45:53.885066
# Unit test for function construct_rule
def test_construct_rule():
    param0 = set_type('', str)
    param1 = set_type('', str)
    param2 = set_type('', str)
    param3 = set_type('', str)
    param4 = set_type('', str)
    param5 = set_type('', str)
    param6 = set_type('', str)
    param7 = set_type('', str)
    param8 = set_type('', str)
    param9 = set_type('', str)
    param10 = set_type('', str)
    param11 = set_type('', str)
    param12 = set_type('', str)
    param13 = set_type('', str)
    param14 = set_type('', str)
    param15 = set_type('', str)
    param16 = set_type

# Generated at 2022-06-25 02:46:00.223221
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    for i in range(100):
        s = test_case_0()
        try:
            append_tcp_flags(rule, param, flag)
        except Exception:
            print("Error raised at iteration %d" % i)
            raise


# Generated at 2022-06-25 02:46:09.735099
# Unit test for function push_arguments

# Generated at 2022-06-25 02:46:21.735453
# Unit test for function construct_rule
def test_construct_rule():
    if str_0 == 'k\x0b=\x13':
        output = construct_rule(params)

# Generated at 2022-06-25 02:46:27.849505
# Unit test for function get_chain_policy
def test_get_chain_policy():
    str_0 = 'k\x0b=\x13'
    str_1 = '&h_'
    str_2 = 'P@'
    str_3 = '!'
    str_4 = 'k\x0b=\x13'
    str_5 = '!'
    str_6 = '!'
    str_7 = '!'
    str_8 = '!'
    str_9 = 'P@'
    str_10 = '%'
    str_11 = '%'
    str_12 = '%'
    str_13 = '%'
    str_14 = '%'
    str_15 = '%'
    str_16 = '%'
    str_17 = '%'
    str_18 = '%'
    str_19 = '%'
    str_20

# Generated at 2022-06-25 02:46:36.427490
# Unit test for function check_present
def test_check_present():
    iptables_path = '/home/vagrant/iptables'
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)

# Generated at 2022-06-25 02:46:47.448780
# Unit test for function append_rule
def test_append_rule():
    str_0 = 'k\x0b=\x13'
    str_1 = 'k\x0b=\x13'
    str_2 = 'k\x0b=\x13'
    str_3 = 'k\x0b=\x13'
    str_4 = 'k\x0b=\x13'
    str_5 = 'k\x0b=\x13'
    str_6 = 'k\x0b=\x13'
    str_7 = 'k\x0b=\x13'
    str_8 = 'k\x0b=\x13'
    str_9 = 'k\x0b=\x13'
    str_10 = 'k\x0b=\x13'

# Generated at 2022-06-25 02:46:52.087753
# Unit test for function append_match_flag
def test_append_match_flag():
    str_0 = 'k\x0b=\x13'
    str_1 = append_match_flag(str_0, True, False)
    copy_0 = str_0
    copy_1 = str_1
    if len(copy_0) >= len(copy_1):
        if len(copy_0) >= 2:
            test_case_0()
        test_case_0()
    elif len(copy_0) >= 2:
        test_case_0()
    test_case_0()


# Generated at 2022-06-25 02:46:59.501384
# Unit test for function get_chain_policy
def test_get_chain_policy():
    result = ""
    try:
        # Test case 0
        x = 'A\x12\x02'
        str_0 = x
        
    except Exception as e:
        print("[FAIL]")
        result = "[FAIL]\tget_chain_policy: " + str(e)
    else:
        print("[PASS]")
        result = "[PASS]\tget_chain_policy"
    return result
if __name__ == '__main__':
    print(test_get_chain_policy())

# Generated at 2022-06-25 02:47:19.224970
# Unit test for function push_arguments

# Generated at 2022-06-25 02:47:20.072564
# Unit test for function append_param
def test_append_param():
    str_0 = 'k\x0b=\x13'
    test_case_0()



# Generated at 2022-06-25 02:47:30.483826
# Unit test for function remove_rule
def test_remove_rule():
    str_0 = 'k\x0b=\x13'

    # Testing argument types
    str_1 = "='"
    str_2 = 'hA'
    str_3 = 'mV<\t'
    str_4 = ''
    str_5 = 'B\x00j+\x1c '
    str_6 = '+D'
    str_7 = '\x18\x0f2\x16'
    str_8 = '\x0eO'
    str_9 = 'C'
    int_0 = -1
    str_10 = 'G'
    str_11 = 'N'
    str_12 = 'g\x11'
    str_13 = ' '
    str_14 = 'KP'
    str_15 = '\x1a'


# Generated at 2022-06-25 02:47:39.135557
# Unit test for function flush_table
def test_flush_table():
    str_0 = 'k\x0b=\x13'
    table_2 = b'\x05\x14\x08\x1a\x1d'
    chain_3 = '8[\x1a*\x16\x0e\x16'
    ip_version_4 = 'f\x06\x1f!\x13\x11\x0e01'
    module_5 = make_module({'table': table_2, 'chain': chain_3, 'ip_version': ip_version_4}, False)
    make_ansible_module(module_5, table_2, chain_3, ip_version_4, str_0)

# Generated at 2022-06-25 02:47:47.429101
# Unit test for function construct_rule
def test_construct_rule():
    assert(construct_rule({'src_range': None, 'set_counters': None, 'tcp_flags': {'flags': ['ALL']
        , 'flags_set': ['ACK', 'SYN', 'FIN', 'RST']}, 'match': ['tcp', 'state'], 'ip_version': 'ipv4', 'jump': 'DROP'
        , 'ctstate': []}) == ['--p tcp', '-m state', '--tcp-flags ALL,ACK,SYN,FIN,RST', '-j DROP'])

# Generated at 2022-06-25 02:47:57.269991
# Unit test for function construct_rule
def test_construct_rule():
    params = [
        "IPTABLES:INFO: "
        "limit",
        "reject-with",
        "--reject-with",
        "YES",
        "YES",
    ]
    params = [1]
    rule = [params]

    # Check the general syntax of the rule

# Generated at 2022-06-25 02:48:03.287985
# Unit test for function append_match_flag
def test_append_match_flag():
    rule_0 = []
    param_0 = 'match'
    flag_0 = ''
    negatable_0 = False
    expected_0 = rule_0.extend([flag_0,])
    actual_0 = append_match_flag(rule_0, param_0, flag_0, negatable_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 02:48:05.765313
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('/R^\x1f', '-I', {'table': 'filter', 'chain': 'INPUT', 'rule_num': 0}) == ['/R^\x1f', '-t', 'filter', '-I', 'INPUT', '0']


# Generated at 2022-06-25 02:48:09.581619
# Unit test for function construct_rule
def test_construct_rule():
    rule = construct_rule(dict(
        match=['state'],
        ctstate=['new'],
    ))
    assert rule == ['-m', 'state', '--state', 'new'], rule



# Generated at 2022-06-25 02:48:15.594543
# Unit test for function push_arguments
def test_push_arguments():
    str_0 = 'k\x0b=\x13'

    assert push_arguments(str_0, '-I', test_case_0())


# Generated at 2022-06-25 02:48:37.412433
# Unit test for function construct_rule

# Generated at 2022-06-25 02:48:39.042110
# Unit test for function main
def test_main():
    assert func_0(0x2d, 0x4f) == str_0


# Generated at 2022-06-25 02:48:39.915447
# Unit test for function check_present
def test_check_present():
    str_1 = 'k\x0b=\x13'

# Function command

# Generated at 2022-06-25 02:48:45.783037
# Unit test for function flush_table
def test_flush_table():
    with mock.patch('os.path.exists', return_value=True) as mock_exists:
        with mock.patch('ansible_collections.ansible.builtin.plugins.module_utils.network.common.utils.AnsibleModule') as mock_AnsibleModule:
            module = mock_AnsibleModule.return_value
            module.run_command.return_value = (0, '', '')
            test_case_0()
            test_case_0()
            test_case_0()
            flush_table('/usr/sbin/iptables', module, {'chain': 'LOGGING', 'table': 'filter', 'ip_version': 'ipv4'})

            assert mock_exists.call_count == 2
            assert mock_AnsibleModule.call_count == 1




# Generated at 2022-06-25 02:48:46.494824
# Unit test for function append_rule
def test_append_rule():

    assert str_0 == 'k\x0b=\x13'


# Generated at 2022-06-25 02:48:55.578443
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = 'n\x05\x1a\x0b\x02\x1b\x10\x0f'
    module = 'j\x11\x0e\x1f\x0c\x1b\x12\x00\x0b\x13'
    params = 'j\x0c\r\x1b\x0b\x0c\x00\x13\x0f\x18'
    # 8
    assert _(remove_rule(iptables_path, module, params)) == _(None)


# Generated at 2022-06-25 02:49:02.663819
# Unit test for function construct_rule
def test_construct_rule():
    rule = ['!', '--icmpv6-type', '!=s*']
    params = {}
    params['match'] = ['conntrack']
    params['ctstate'] = ['related', 'established']
    params['jump'] = None
    params['ip_version'] = 'ipv6'
    params['icmp_type'] = '!=s*'
    ans = construct_rule(params)
    assert ans == rule, (ans, rule)


# Generated at 2022-06-25 02:49:10.863191
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module_path = 'ansible.builtin.iptables'
    module = importlib.import_module(module_path)
    module.run_command = mock_run_command
    mock_path = 'ansible.module_utils.basic.AnsibleModule'
    with mock.patch(mock_path) as mock_ansible_module:
        mock_ansible_module.run_command = MagicMock(return_value=(0, '', ''))
        mock_ansible_module.fail_json = MagicMock(return_value=test_case_0)
        set_chain_policy('iptables', mock_ansible_module, {})


# Generated at 2022-06-25 02:49:13.603330
# Unit test for function main
def test_main():
    env.update({"ANSIBLE_MODULE_ARGS": {'tag': 'tag value'}})
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:49:15.034747
# Unit test for function construct_rule
def test_construct_rule():
    test_case_0()


# Generated at 2022-06-25 02:49:30.634435
# Unit test for function append_rule
def test_append_rule():
    var_1 = main()
    var_2 = main()
    main()


# Generated at 2022-06-25 02:49:34.786925
# Unit test for function append_param
def test_append_param():
    var_0 = []
    var_1 = 'test'
    var_2 = 'test'
    var_3 = True
    var_4 = append_param(var_0, var_1, var_2, var_3)
    assert var_4 == False
    var_5 = ['!', 'test', 'test']
    var_6 = var_0 == var_5
    assert var_6

# Generated at 2022-06-25 02:49:36.041138
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(var_0, var_1) == var_2



# Generated at 2022-06-25 02:49:38.206947
# Unit test for function append_match_flag
def test_append_match_flag():
    r = []
    append_match_flag(r, 'match', '--syn', True)
    append_match_flag(r, 'negate', '--syn', True)
    assert r == [ '--syn', '!', '--syn' ]


# Generated at 2022-06-25 02:49:42.255780
# Unit test for function flush_table
def test_flush_table():
    var_0 = main()


# Generated at 2022-06-25 02:49:47.695858
# Unit test for function main
def test_main():
    iptables_path, module, params = required_params()

    module.params['table'] = 'filter'
    module.params['chain'] = 'INPUT'
    module.params['protocol'] = 'tcp'
    module.params['source'] = '192.168.0.1'
    module.params['jump'] = 'ACCEPT'
    module.params['wait'] = ''
    module.params['action'] = 'insert'
    main() # will fail

    var_0 = main()


# Generated at 2022-06-25 02:49:51.144633
# Unit test for function get_chain_policy
def test_get_chain_policy():
    run_cmd = []
    module = Mock()
    module.run_command.return_value = (0, "Chain FORWARD (policy DROP)", '')
    get_chain_policy("iptables", module, {'ip_version': 'ipv4', 'chain': 'FORWARD'})
    module.run_command.assert_called_with(run_cmd, True)


# Generated at 2022-06-25 02:49:55.537056
# Unit test for function push_arguments
def test_push_arguments():
    var_0 = "iptables"
    var_1 = "-I"

# Generated at 2022-06-25 02:49:56.889685
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = dict()
    var_0['policy'] = 'ACCEPT'

    var_1 = main()


# Generated at 2022-06-25 02:49:58.483556
# Unit test for function push_arguments
def test_push_arguments():
    # Testing function push_arguments
    push_arguments("iptables", "-I", {'table' : "INPUT", 'chain' : "INPUT" })


# Generated at 2022-06-25 02:50:17.269659
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = get_chain_policy()
    return (var_0)



# Generated at 2022-06-25 02:50:19.457160
# Unit test for function flush_table
def test_flush_table():
    # mock flush_table
    cmd = ['/sbin/iptables-save']
    rc, out, __ = module.run_command(cmd)
    assert(rc == 0)
    # mock flush_table
    rc, out, __ = module.run_command(cmd)
    assert(rc == 0)



# Generated at 2022-06-25 02:50:27.696660
# Unit test for function append_param
def test_append_param():
    # Initialize var_0 with some dummy value. We will overwrite it.
    var_0 = ['dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy', 'dummy']

    # Call append_param with some dummy arguments
    append_param(var_0, 'dummy', 'dummy', False)



if __name__ == '__main__':
    test_case_0()

# Rules should be a list of rule dictionaries with the following keys:
#    table => the table to set the rule in, filter by default
#    chain => the chain to put the rule in, INPUT by default
#    command => one of I(append), I(insert), I(delete), I(replace).
#               I(append)

# Generated at 2022-06-25 02:50:35.211889
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module_mock = MockedModule()
    module_mock.run_command = Mock(return_value=0)
    var_1 = get_iptables_version('', module_mock)
    assert var_1 == "1.6.1\n"
    module_mock.run_command.assert_called_with(['', '--version'], check_rc=True)


# Generated at 2022-06-25 02:50:39.449999
# Unit test for function set_chain_policy
def test_set_chain_policy():
    os.environ['ANSIBLE_DEVEL'] = '1'
    os.environ['ANSIBLE_DEBUG'] = '1'
    set_chain_policy(None, None, None)


# Generated at 2022-06-25 02:50:45.879944
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = '/usr/bin/iptables'
    module = AnsibleModule
    params = { 'table': 'filter', 'chain': 'INPUT', 'rule_num': '1' }

    assert callable(get_chain_policy)
    assert get_chain_policy(iptables_path, module, params) is None


# Generated at 2022-06-25 02:50:46.661852
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = case_0()


# Generated at 2022-06-25 02:50:57.658982
# Unit test for function construct_rule

# Generated at 2022-06-25 02:50:59.342819
# Unit test for function construct_rule
def test_construct_rule():
    table = dict(
        ip_version='ipv4',
        flush=False
    )
    rule = construct_rule(table)
    assert rule == []


# Generated at 2022-06-25 02:51:09.471674
# Unit test for function construct_rule

# Generated at 2022-06-25 02:51:30.439926
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = 'iptables'
    action = '-A'

# Generated at 2022-06-25 02:51:35.466833
# Unit test for function append_rule
def test_append_rule():
    # Tested with a fresh VM
    iptables_path = 'iptables'
    # Tested with a fresh VM
    module = AnsibleModule()
    # Tested with a fresh VM

# Generated at 2022-06-25 02:51:42.793861
# Unit test for function flush_table

# Generated at 2022-06-25 02:51:45.897986
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        policy='drp'
    )
    result = construct_rule(params)
    assert result == ['-w', '-p', 'drp']


# Generated at 2022-06-25 02:51:47.609491
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is None
    #assert var_0 == 'foo'


# Generated at 2022-06-25 02:51:56.290115
# Unit test for function remove_rule
def test_remove_rule():
    # Declare input arguments to function
    iptables_path = "/usr/bin/iptables"
    module = "/usr/bin/iptables"
    params = [false,"","INPUT",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false,"","",false]
    # Call the function

# Generated at 2022-06-25 02:52:05.986821
# Unit test for function flush_table
def test_flush_table():
    main()
    BINS = dict(
    ipv4='iptables',
    ipv6='ip6tables',
)
    ICMP_TYPE_OPTIONS = dict(
    ipv4='--icmp-type',
    ipv6='--icmpv6-type',
)

    append_param(rule, param, flag, True)
    cmd = [iptables_path]
    cmd.extend(['-t', params['table']])
    cmd.extend(['-F', params['chain']])

    assert(str(cmd) == "['iptables','-t','mangle','-F','INPUT_direct']")

if __name__ == '__main__':
    #test_flush_table()
    main()

# Generated at 2022-06-25 02:52:12.894359
# Unit test for function check_present
def test_check_present():
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec=dict())
    params = {}
    return_value = check_present(iptables_path, module, params)
    assert return_value is not None


# Generated at 2022-06-25 02:52:23.412050
# Unit test for function push_arguments

# Generated at 2022-06-25 02:52:26.349022
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain="INPUT",
        action="append",
        state="present",
        limit="2/second",
        limit_burst="20",
        log_prefix="IPTABLES:INFO: ",
        log_level="info",
        ip_version="ipv4",
        )
    rule = construct_rule(params)
    assert rule is not None
    print(rule)
    return rule

