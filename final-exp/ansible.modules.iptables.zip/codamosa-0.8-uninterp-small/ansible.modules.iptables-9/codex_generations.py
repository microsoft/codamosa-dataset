

# Generated at 2022-06-25 02:43:34.397756
# Unit test for function construct_rule

# Generated at 2022-06-25 02:43:43.185068
# Unit test for function construct_rule
def test_construct_rule():
    # Test case 1
    params = dict(
        protocol = 'tcp',
        destination = '192.168.0.1',
        destination_port = '80',
        flush = True,
        jump = 'DROP',
        match = [ 'tcp' ],
        set_counters = '10:20',
        source = '192.168.0.2',
        table = 'filter',
        comment = 'New rule',
        )
    rule = construct_rule(params)

# Generated at 2022-06-25 02:43:54.328744
# Unit test for function construct_rule

# Generated at 2022-06-25 02:43:57.401286
# Unit test for function construct_rule
def test_construct_rule():
    print("Testing construct_rule:")
    d = dict()
    d['protocol'] = 'tcp'
    d['source'] = '8.8.8.8'
    d['jump'] = 'REJECT'
    construct_rule(d)
    print('SUCCEEDED')


# Generated at 2022-06-25 02:44:03.186769
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(test_case_0(),test_case_0()) == test_case_0()

# Generated at 2022-06-25 02:44:10.591106
# Unit test for function check_present
def test_check_present():
    list_0 = ['test_str_0', 'test_str_1', [1, 2, 3]]
    list_1 = ['test_str_0', 'test_str_1', [1, 2, 3]]
    bool_0 = False
    bool_1 = True
    bool_2 = False
    str_0 = 'test_str_0'
    str_1 = 'test_str_1'
    str_2 = 'test_str_2'
    str_3 = 'test_str_3'
    str_4 = 'test_str_4'
    str_5 = 'test_str_5'
    str_6 = 'test_str_6'
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3

# Generated at 2022-06-25 02:44:16.067830
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:44:19.086412
# Unit test for function construct_rule
def test_construct_rule():
    rule = []
    print (construct_rule(rule))


# Generated at 2022-06-25 02:44:27.084457
# Unit test for function push_arguments
def test_push_arguments():
    # Generate input arguments
    action = '-I'

# Generated at 2022-06-25 02:44:30.116262
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    # Test with a list of flags.
    # test with a,b,c,d as flags.
    assert True == False

    # Test with a list of set of flags.
    # test with a,b,c,d as flags.
    assert True == False



# Generated at 2022-06-25 02:44:42.275240
# Unit test for function get_chain_policy
def test_get_chain_policy():
    pass


# Generated at 2022-06-25 02:44:45.070508
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule_0 = []
    param_0 = {'flags_set': ['ACK', 'RST', 'SYN', 'FIN'], 'flags': 'ALL'}
    flag_0 = '--tcp-flags'
    append_tcp_flags(rule_0, param_0, flag_0)


# Generated at 2022-06-25 02:44:48.853199
# Unit test for function append_match_flag
def test_append_match_flag():
    # Set up mock inputs
    rule = [ '--match-set', 'admin_hosts', '--match-set-flags', 'src', '--destination-port', '22', '--jump', 'ALLOW', ]
    param = 'match'
    flag = '--syn'
    negatable = False
    append_match_flag(rule, param, flag, negatable)
    print(rule)


# Generated at 2022-06-25 02:45:00.843872
# Unit test for function get_chain_policy
def test_get_chain_policy():
    bool_0 = True
    str_0 = '<`Y'
    var_0 = '~'
    var_1 = test_case_0()
    var_2 = get_chain_policy(str_0, bool_0, bool_0)
    var_2.append(str_0)
    var_2.extend(var_1)
    var_3 = get_chain_policy(bool_0, var_0, var_1)
    var_3.insert_rule(bool_0, var_2, var_1)
    var_4 = get_chain_policy(var_2, var_2, var_2)
    var_4.append_rule(var_2, bool_0, bool_0)

# Generated at 2022-06-25 02:45:04.658240
# Unit test for function get_iptables_version
def test_get_iptables_version():
    pass


# Generated at 2022-06-25 02:45:07.899292
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = True
    module = 'INPUT'
    params = dict(
        table='filter',
        chain='INPUT',
        policy='DROP'
    )
    set_chain_policy(iptables_path, module, params)


# Generated at 2022-06-25 02:45:18.973235
# Unit test for function construct_rule
def test_construct_rule():
    def __init__():
        var_0 = True
        str_0 = '--dst-range'
        var_1 = 'ctstate'
        str_1 = '9t'
        str_2 = '8y'
        str_3 = 'f-G'
        str_4 = 'oy'
        str_5 = '5a'
        str_6 = '--limit-burst'
        str_7 = '9t'
        str_8 = '8y'
        str_9 = '--state'
        str_10 = 'ny'
        str_11 = '--uid-owner'
        str_12 = '7n'
        str_13 = '-j'
        str_14 = '1n'
        str_15 = '-p'
        str_16 = 'wn'


# Generated at 2022-06-25 02:45:27.011967
# Unit test for function check_present
def test_check_present():
    str_0 = os.path.exists('/home/vagrant/ansible-tests/iptables/README.rst')
    var_0 = False
    var_0 = check_present(str_0, str_0, var_0)
    if (os.path.exists('/home/vagrant/ansible-tests/iptables/README.rst') or var_0 < os.path.abspath(os.path.expanduser('/home/vagrant/ansible-tests/iptables/README.rst'))):
        return 'OK'


# Generated at 2022-06-25 02:45:32.316286
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/bin/iptables'
    action = '-I'

# Generated at 2022-06-25 02:45:37.606583
# Unit test for function get_chain_policy
def test_get_chain_policy():
    # You can change the following lines to match your case!
    str_0 = "INPUT"
    str_1 = '0'
    int_0 = 22
    dict_0 = dict(
        chain=str_0,
        ip_version=str_1,
        destination_port=int_0,
        protocol=str_0,
        source=str_0
    )
    var_0 = get_chain_policy(dict_0, dict_0, dict_0)
    if var_0 > int_0:
        var_0 = insert_rule(dict_0, dict_0, dict_0)
    else:
        var_0 = remove_rule(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 02:45:50.630345
# Unit test for function append_rule
def test_append_rule():
    str_0 = 'H*-j'
    append_rule(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 02:45:56.092543
# Unit test for function construct_rule
def test_construct_rule():
    dict_0 = dict()
    dict_0.update({"limit_burst": "5", "limit": "5", "ctstate": "match", "jump": "ACCEPT", "out_interface": "lo"})

    string_0 = '*0'
    iptables_calls_0 = list()
    if dict_0["limit_burst"] is not None:
        iptables_calls_0.extend(["-m", "limit", "--limit-burst", dict_0["limit_burst"]])
    iptables_calls_0.extend(["-p", "tcp", "--jump", dict_0["jump"]])
    iptables_calls_0.extend(["-o", dict_0["out_interface"]])

# Generated at 2022-06-25 02:46:05.288913
# Unit test for function construct_rule
def test_construct_rule():
    str_0 = 'Conntrack'
    str_1 = '6.5.6.8'
    str_2 = 'F5APi'
    str_3 = 'CSI_RR'
    str_4 = 'P'
    str_5 = 'L'
    str_6 = 'CS6'
    str_7 = 'U'
    str_8 = 'L'
    str_9 = 'CS6'
    str_10 = 'U'
    str_11 = 'CS6'
    str_12 = 'y'
    str_13 = 'x0'
    str_14 = 'u'
    str_15 = ':s'
    str_16 = '8'
    str_17 = '*'
    str_18 = '9'
    str_19 = '*'


# Generated at 2022-06-25 02:46:09.906719
# Unit test for function get_chain_policy
def test_get_chain_policy():
    print("Running get_chain_policy Unit test")
    print("Successful test case")
    test_case_0()


# Generated at 2022-06-25 02:46:21.860118
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = 'H*-j'
    action = '-I'

# Generated at 2022-06-25 02:46:23.417699
# Unit test for function main
def test_main():
    # Testing
    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:46:26.507209
# Unit test for function remove_rule
def test_remove_rule():
    assert callable(remove_rule)


# Generated at 2022-06-25 02:46:27.123409
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule



# Generated at 2022-06-25 02:46:34.222274
# Unit test for function get_chain_policy
def test_get_chain_policy():
    bool_0 = False
    str_0 = 'H*-j'
    var_0 = get_chain_policy(bool_0, bool_0, str_0)
    var_1 = get_chain_policy(False, False, 'H*-j')
    var_1 = get_chain_policy(False, False, 'H*-j')
    var_2 = get_chain_policy(str_0, str_0, str_0)


# Generated at 2022-06-25 02:46:38.648691
# Unit test for function check_present
def test_check_present():
    args = dict()
    args['ip'] = '192.168.1.12'
    args['port'] = '8080'
    pass


# Generated at 2022-06-25 02:47:02.696928
# Unit test for function append_match_flag
def test_append_match_flag():
    bool_0 = True
    str_0 = 'P'
    str_1 = 'h'
    append_match_flag(bool_0, str_0, str_1, bool_0)


# Generated at 2022-06-25 02:47:09.473788
# Unit test for function flush_table
def test_flush_table():
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()
    assert flush_table()


# Generated at 2022-06-25 02:47:10.060378
# Unit test for function insert_rule
def test_insert_rule():
    assert True == True



# Generated at 2022-06-25 02:47:19.537940
# Unit test for function main
def test_main():
    bool_0 = False
    str_0 = 'H*-j'

# Generated at 2022-06-25 02:47:24.442374
# Unit test for function append_rule
def test_append_rule():
    bool_0 = False
    str_0 = 'H*-j'
    var_0 = append_rule(bool_0, str_0, str_0)

# Generated at 2022-06-25 02:47:27.840918
# Unit test for function append_rule
def test_append_rule():
    try:
    	# get arg
        iptables_path = test_case_0()
        module = test_case_0()
        params = test_case_0()
        # call function
        str_ret = append_rule(iptables_path, module, params)
    except:
        pass


# Generated at 2022-06-25 02:47:38.400299
# Unit test for function get_chain_policy
def test_get_chain_policy():

    chain_policy_0 = 'ACCEPT'
    chain_policy_1 = 'DROP'
    chain_policy_2 = 'QUEUE'
    chain_policy_3 = 'RETURN'

    assert get_chain_policy(chain_policy_0) == None
    assert get_chain_policy(chain_policy_1) == None
    assert get_chain_policy(chain_policy_2) == None
    assert get_chain_policy(chain_policy_3) == None

    chain_policy_4 = {'ACCEPT': 3, 'DROP': 1, 'QUEUE': 0, 'RETURN': 2}
    assert get_chain_policy(chain_policy_4) == 'ACCEPT'


# Generated at 2022-06-25 02:47:40.631362
# Unit test for function check_present
def test_check_present():
    # Get the full path to iptables binary
    iptables_path = module.get_bin_path('iptables', True)

    cmd = push_arguments(iptables_path, '-C', params)
    rc, _, __ = module.run_command(cmd, check_rc=False)
    return (rc == 0)
    
    


# Generated at 2022-06-25 02:47:45.069716
# Unit test for function get_chain_policy
def test_get_chain_policy():
    out = "Chain OUTPUT (policy ACCEPT)\n"
    assertion = get_chain_policy(None, None, out)
    assert assertion == "ACCEPT"
    print("Test : test_get_chain_policy() -> OK")


# Generated at 2022-06-25 02:47:53.231000
# Unit test for function main
def test_main():
    iptables_path = '/sbin/iptables'

# Generated at 2022-06-25 02:48:49.576770
# Unit test for function insert_rule

# Generated at 2022-06-25 02:48:50.848494
# Unit test for function remove_rule
def test_remove_rule():
    test_case_0()


# Generated at 2022-06-25 02:48:52.362577
# Unit test for function insert_rule
def test_insert_rule():
    print("Testing function test_insert_rule")
    test_case_0()


# Generated at 2022-06-25 02:48:56.582435
# Unit test for function append_match_flag
def test_append_match_flag():
    rule_0 = []
    param_0 = 'match'
    flag_0 = '--syn'
    negatable_0 = True
    append_match_flag(rule_0, param_0, flag_0, negatable_0)
    if rule_0[len(rule_0)-1] == flag_0:
        print('PASS')
    else:
        print('FAIL')


# Generated at 2022-06-25 02:49:08.180477
# Unit test for function main
def test_main():
    ## Dictionary to store module arguments
    module_args = {}
    ## Store the state for the arg
    module_args["state"] = "present"
    ## Store the state for the arg
    module_args["ip_version"] = "ipv4"
    ## Store the state for the arg
    module_args["table"] = "filter"
    ## Store the state for the arg
    module_args["action"] = "append"
    ## Store the state for the arg
    module_args["chain"] = "INPUT"
    ## Store the state for the arg
    module_args["jump"] = "ACCEPT"
    ## Store the state for the arg
    module_args["log_prefix"] = "abc"
    ## Store the state for the arg
    module_args["set_dscp_mark"] = "10"
    ##

# Generated at 2022-06-25 02:49:12.452417
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = ''
    bool_0 = False
    str_0 = 'H'
    bool_1 = True
    str_1 = '.'
    str_2 = '9~'
    str_3 = 'U'
    str_4 = ')'
    str_5 = 'j'
    var_0 = get_chain_policy(iptables_path, bool_0, str_0)
    var_1 = get_chain_policy(iptables_path, bool_1, str_1)
    var_2 = get_chain_policy(iptables_path, str_2, bool_0)
    var_3 = get_chain_policy(iptables_path, str_3, bool_1)

# Generated at 2022-06-25 02:49:17.917446
# Unit test for function construct_rule
def test_construct_rule():
    # Basic rule, should not throw
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
    )

    rule = construct_rule(params)
    expected = ['-A', 'INPUT', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']
    if rule != expected:
        print('Expected: ' + str(expected))
        print('Got: ' + str(rule))
        raise Exception('construct_rule test 0 failed.')
    else:
        print('construct_rule OK')


# Generated at 2022-06-25 02:49:22.419274
# Unit test for function append_rule
def test_append_rule():
    assert callable(append_rule)



# Generated at 2022-06-25 02:49:23.258275
# Unit test for function remove_rule
def test_remove_rule():
    test_case_0()


# Generated at 2022-06-25 02:49:25.553057
# Unit test for function flush_table
def test_flush_table():
    iptables_path = ''
    module = ''
    params = ''
    expected_result = True
    result = flush_table(iptables_path, module, params)
    assert result == expected_result, "Flush table should return true but it returned false"


# Generated at 2022-06-25 02:51:33.384853
# Unit test for function check_present
def test_check_present():
    bool_0 = False
    bool_1 = False
    str_0 = 'H*-j'
    str_1 = 'H*-j'
    dict_0 = dict()
    dict_0['chain'] = str_1
    dict_0['jump'] = str_1
    dict_0['protocol'] = str_1
    dict_0['reject_with'] = str_1
    dict_0['ip_version'] = str_1
    dict_0['table'] = str_1
    dict_0['comment'] = str_1
    dict_0['dst_range'] = str_1
    dict_0['icmp_type'] = str_1
    dict_0['src_range'] = str_1
    dict_0['destination'] = str_1

# Generated at 2022-06-25 02:51:42.357864
# Unit test for function construct_rule
def test_construct_rule():
    #Test case 1
    rule = []
    params = {}
    params['protocol'] = None
    params['source'] = None
    params['destination'] = None
    params['match'] = None
    params['tcp_flags'] = None
    params['jump'] = None
    params['log_prefix'] = None
    params['log_level'] = None
    params['to_destination'] = None
    params['destination_ports'] = None
    params['to_source'] = None
    params['goto'] = None
    params['in_interface'] = None
    params['out_interface'] = None
    params['fragment'] = None
    params['set_counters'] = None
    params['source_port'] = None
    params['destination_port'] = None
    params['to_ports']

# Generated at 2022-06-25 02:51:49.202183
# Unit test for function get_chain_policy
def test_get_chain_policy():
    bool_0 = False
    bool_1 = False
    str_0 = 'J4x+q'
    str_1 = 'zX@S'
    str_2 = 'L%c'
    str_3 = 'A'
    str_4 = 'J4x+q'
    var_0 = get_chain_policy(bool_0, bool_1, str_0)
    var_1 = get_chain_policy(str_1, str_2, str_3)
    var_2 = get_chain_policy(str_4, str_1, str_0)


# Generated at 2022-06-25 02:51:53.519804
# Unit test for function flush_table
def test_flush_table():
    str_0 = 'Xz~xI'
    str_1 = '8d@5'
    dict_0 = dict(table='nat', chain=str_0, flush=bool_0)
    var_0 = flush_table(str_1, dict_0, dict_0)


# Generated at 2022-06-25 02:51:55.824696
# Unit test for function get_chain_policy
def test_get_chain_policy():
    str_0 = "8xv>"
    bool_0 = True
    str_1 = "u{a0"
    str_2 = '*'

    assert get_chain_policy(bool_0, str_0, str_1, str_2) == 'H*-j'


# Generated at 2022-06-25 02:52:05.517092
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = 'iptables'
    action = '-I'

# Generated at 2022-06-25 02:52:11.951184
# Unit test for function construct_rule
def test_construct_rule():
    # Test case 0
    rule = 'iptables -w --destination-port --protocol\n' + \
           ' -s --jump --source-port --to-ports'
    params = dict(destination_port=None, protocol=None, source=None, jump=None,
                  source_port=None, to_ports=None, wait=None)
    params_rule = construct_rule(params)
    result = (rule == ' '.join(params_rule))
    assert result

    # Test case 1

# Generated at 2022-06-25 02:52:22.609263
# Unit test for function construct_rule

# Generated at 2022-06-25 02:52:26.901314
# Unit test for function main
def test_main():
    bool_0 = bool_random()
    str_0 = random_string()
    bool_1 = bool_random()
    str_1 = random_string()
    bool_2 = bool_random()
    str_2 = random_string()
    bool_3 = bool_random()
    str_3 = random_string()
    bool_4 = bool_random()
    str_4 = random_string()
    bool_5 = bool_random()
    str_5 = random_string()
    bool_6 = bool_random()
    str_6 = random_string()
    bool_7 = bool_random()
    str_7 = random_string()
    bool_8 = bool_random()
    str_8 = random_string()
    bool_9 = bool_random()
    str_9 = random_string()

# Generated at 2022-06-25 02:52:32.315693
# Unit test for function construct_rule
def test_construct_rule():
    # NOTE: Parameter values must be hard-coded here.
    params = dict(
        destination_ports=['80'],
        jump=None,
        protocol='tcp',
        action='append',
        table='filter',
        ip_version='ipv4',
        chain='INPUT',
        state='present',
    )

    rule = construct_rule(params)
    print(rule)
    assert rule == [
        '-A', 'INPUT', '-p', 'tcp', '--dport', '80',
    ]
