

# Generated at 2022-06-25 02:43:45.306779
# Unit test for function get_iptables_version
def test_get_iptables_version():
    test_0_0 = str()
    test_0_1 = str()
    test_0_2 = str()
    str_0 = get_iptables_version(test_0_0, test_0_1)
    str_1 = get_iptables_version(test_0_2, test_0_2)
    str_2 = get_iptables_version(test_0_1, test_0_0)
    str_3 = get_iptables_version(test_0_2, test_0_2)
    str_4 = get_iptables_version(test_0_2, test_0_2)
    str_5 = get_iptables_version(test_0_0, test_0_1)

# Generated at 2022-06-25 02:43:56.384359
# Unit test for function construct_rule

# Generated at 2022-06-25 02:43:58.994858
# Unit test for function push_arguments
def test_push_arguments():
    assert True


# Generated at 2022-06-25 02:44:04.041386
# Unit test for function get_iptables_version
def test_get_iptables_version():
    # Test cases
    assert('1.8.0' == get_iptables_version('iptables', 'module'))
    try:
        test_case_0()
    except:
        pass



# Generated at 2022-06-25 02:44:04.879741
# Unit test for function get_chain_policy
def test_get_chain_policy():
    get_chain_policy()


# Generated at 2022-06-25 02:44:07.254994
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = get_chain_policy("< ", "< ", "< ")
    try:
        assert var_0 == "< "
    except AssertionError as ae:
        raise ae


# Generated at 2022-06-25 02:44:09.345594
# Unit test for function remove_rule
def test_remove_rule():
    str_0 = '< '
    iptables_path = None
    module = None
    params = None
    remove_rule(iptables_path, module, params)


# Generated at 2022-06-25 02:44:18.810433
# Unit test for function construct_rule
def test_construct_rule():
    # params = dict(
    #     chain='INPUT',
    #     protocol='tcp',
    #     destination_port='80',
    #     ctstate='NEW',
    #     syn='match',
    #     ip_version='ipv4',
    #     jump='ACCEPT',
    #     comment='Accept new SSH connections.',
    # )
    # result = construct_rule(params)
    # print(result)
    test_case_0()
    # main()


# Generated at 2022-06-25 02:44:26.957199
# Unit test for function main
def test_main():
    iptables_path = BINS['ipv4']
    ip_version = 'ipv4'

# Generated at 2022-06-25 02:44:37.271231
# Unit test for function construct_rule

# Generated at 2022-06-25 02:44:52.384878
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert(get_iptables_version(str, str) == str)


# Generated at 2022-06-25 02:44:53.029804
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert test_case_0() == None


# Generated at 2022-06-25 02:45:04.610840
# Unit test for function append_rule

# Generated at 2022-06-25 02:45:06.765892
# Unit test for function get_chain_policy
def test_get_chain_policy():
    try:
        if (get_chain_policy == 'replace-me'):
            test_case_0()
    except Exception as e:
        print('An exception occurred: ' + str(e))



# Generated at 2022-06-25 02:45:10.981686
# Unit test for function append_match_flag
def test_append_match_flag():
    try:
        assert test_case_0() == True
    except AssertionError:
        print("test_append_match_flag failed")
    

# Generated at 2022-06-25 02:45:20.152621
# Unit test for function push_arguments
def test_push_arguments():
    argv = ['--table="nat"', '--chain="PREROUTING"', '--in-interface="eth0"', '--protocol="tcp"', '--match="tcp"', '--destination-port="80"', '--jump="REDIRECT"', '--to-ports="8600"', '--comment="Redirect web traffic to port 8600"']
    # open('./test_case_0.txt', 'r').read().split('\n')
    ansible_arguments = dict()

    # Process parameters passed to module
    for arg in argv:
        if arg.startswith('--table'):
            ansible_arguments['table'] = arg.split('=')[1]
        elif arg.startswith('--chain'):
            ansible_arguments['chain']

# Generated at 2022-06-25 02:45:22.705478
# Unit test for function get_iptables_version
def test_get_iptables_version():
    str_0 = '< '
    var_0 = get_iptables_version(str_0, str_0)
    test_case_0()


# Generated at 2022-06-25 02:45:29.236767
# Unit test for function main

# Generated at 2022-06-25 02:45:34.592314
# Unit test for function push_arguments

# Generated at 2022-06-25 02:45:35.260773
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-25 02:46:04.488473
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    main()
# END OF FILE

# Generated at 2022-06-25 02:46:11.335163
# Unit test for function main
def test_main():
    str_0 = 'signing_key_fingerprint'
    str_1 = 'signing_key_fingerprint'
    str_2 = 'signing_key_fingerprint'
    str_3 = 'signing_key_fingerprint'
    str_4 = 'signing_key_fingerprint'
    str_5 = 'signing_key_fingerprint'
    str_6 = 'signing_key_fingerprint'
    str_7 = 'signing_key_fingerprint'
    bool_0 = bool_0
    str_8 = 'signing_key_fingerprint'
    list_0 = ['signing_key_fingerprint', 'signing_key_fingerprint']

# Generated at 2022-06-25 02:46:14.098459
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert not get_chain_policy(0, 0, 0)


# Generated at 2022-06-25 02:46:17.278778
# Unit test for function remove_rule
def test_remove_rule():
    print()
    print('Testing remove_rule()')
    assert(remove_rule('ipv4', None, None) != False)
    assert(remove_rule('ipv6', None, None) != False)


# Generated at 2022-06-25 02:46:24.633084
# Unit test for function construct_rule

# Generated at 2022-06-25 02:46:34.313278
# Unit test for function construct_rule

# Generated at 2022-06-25 02:46:44.692493
# Unit test for function get_chain_policy
def test_get_chain_policy():
    print("Unit start test for function get_chain_policy")
    module_obj = AnsibleModule(
    argument_spec = dict(
        chain = dict(required=False, type='str'),
        table = dict(required=False, type='str')
    )
    )
    params = {
        'chain': 'INPUT',
        'table': 'filter'
    }
    iptables_path = "iptables"
    res = get_chain_policy(iptables_path, module_obj, params)
    assert res == 'DROP'
    print("Unit end test for function get_chain_policy")


# Generated at 2022-06-25 02:46:47.840650
# Unit test for function check_present
def test_check_present():
    try:
        test_case_0()
        print("Testcase 0 ok")
    except:
        print("Testcase 0 fail")

if __name__ == "__main__":
    test_check_present()


# Generated at 2022-06-25 02:46:50.255845
# Unit test for function check_present
def test_check_present():
    # Test setup
    module = AnsibleModule
    iptables_path = module
    module = module
    params = module
    result = check_present(iptables_path, module, params)

    # Test result
    assert result == True



# Generated at 2022-06-25 02:46:52.483694
# Unit test for function construct_rule
def test_construct_rule():
    rule = construct_rule('param')
    assert rule != None



# Generated at 2022-06-25 02:47:40.202742
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(str(11), str(11), str(13)) == None



# Generated at 2022-06-25 02:47:42.967231
# Unit test for function get_iptables_version
def test_get_iptables_version():
    get_iptables_version(str_0, var_0)


# Generated at 2022-06-25 02:47:48.335630
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-25 02:47:57.395830
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments("/usr/sbin/iptables", "-A",
                          dict(
                              table="filter",
                              chain="INPUT",
                              protocol="tcp",
                              wait="20",
                              wait="2",
                              comment="Ansible test rule")) == [
                                  '/usr/sbin/iptables', '-t', 'filter', '-A',
                                  'INPUT', '-p', 'tcp',
                                  '--comment', 'Ansible test rule']
    assert push_arguments("/usr/sbin/iptables", "-D",
                          dict(
                              table="filter",
                              chain="INPUT",
                              protocol="tcp",
                              wait="20",
                              wait="2",
                              comment="Ansible test rule"))

# Generated at 2022-06-25 02:48:04.414623
# Unit test for function push_arguments
def test_push_arguments():
    with open('test_push_arguments_data.json') as json_file:
        json_data = json.load(json_file)
        for user_input in json_data:
            string = user_input['string']
            regex = user_input['regex']
            expected_value = user_input['expected_value']
            value_1 = re.sub(regex, string)
            print(push_arguments(string, string, string))
            if value_1 == expected_value:
                print('Success!!')
            else:
                print('Failure!!')


# Generated at 2022-06-25 02:48:08.673912
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    try:
        assert test_case_0()
    except AssertionError:
        return False
    return True


# Generated at 2022-06-25 02:48:16.389278
# Unit test for function main
def test_main():
    import sys
    import json
    import tempfile
    # The following two lines are not a unit test but we include them in
    # this file so when this module is executed all tests are run.
    args_0 = dict(ip_version='ipv6', jump='TEE', gateway='192.168.1.1',
                  in_interface='eth0', out_interface='eth1')
    args_1 = dict(ip_version='ipv6', jump='LOG', log_prefix='foo',
                  log_level='info', in_interface='eth0', out_interface='eth1')
    args_2 = dict(ip_version='ipv6', jump='TEE', gateway='192.168.1.1',
                  state='present', log_prefix='foo', log_level='info')

# Generated at 2022-06-25 02:48:17.864282
# Unit test for function flush_table
def test_flush_table():
    try:
        result = flush_table("str_0", "str_0", "str_0")
    except IOError as e:
        result = str(e)
    assert(result == "test")


# Generated at 2022-06-25 02:48:27.491823
# Unit test for function push_arguments
def test_push_arguments():
    # Test function with default arguments
    str_0 = 'signing_key_fingerprint'
    str_1 = 'destination_port'
    str_2 = 'set_counters'
    str_3 = 'protocol'
    str_4 = 'uid_owner'
    str_5 = 'match_set'
    str_6 = 'dst_range'
    str_7 = 'source'
    str_8 = 'source_port'
    str_9 = 'comment'
    str_10 = 'limit'
    str_11 = 'syn'
    str_12 = 'reject_with'
    str_13 = 'ip_version'
    str_14 = 'wait'
    str_15 = 'log_prefix'
    str_16 = 'log_level'

# Generated at 2022-06-25 02:48:34.192133
# Unit test for function push_arguments
def test_push_arguments():
    var_1 = 'test'
    var_2 = 'test'
    var_3 = 'test'
    var_4 = 'test'
    var_5 = 'test'
    var_5 = False
    var_4 = push_arguments(var_1, var_2, var_3, var_4)