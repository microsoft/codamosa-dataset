

# Generated at 2022-06-25 02:43:33.620960
# Unit test for function construct_rule
def test_construct_rule():
    params = dict()
    params['wait'] = None
    params['protocol'] = None
    params['source'] = None
    params['destination'] = None
    params['match'] = None
    params['tcp_flags'] = None
    params['jump'] = None
    params['log_prefix'] = None
    params['log_level'] = None
    params['to_destination'] = None
    params['destination_ports'] = None
    params['to_source'] = None
    params['goto'] = None
    params['in_interface'] = None
    params['out_interface'] = None
    params['fragment'] = None
    params['set_counters'] = None
    params['source_port'] = None
    params['destination_port'] = None
    params['to_ports'] = None

# Generated at 2022-06-25 02:43:37.304433
# Unit test for function get_iptables_version
def test_get_iptables_version():
    str_0 = 'iptables v1.4.21'

    assert str_0 == get_iptables_version('', '')


# Generated at 2022-06-25 02:43:39.497800
# Unit test for function push_arguments
def test_push_arguments():
    assert(push_arguments("iptables-legacy", "--policy", "--proto", True) ==
           ["iptables-legacy", "-t", "--policy", "--proto"])


# Generated at 2022-06-25 02:43:43.116490
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    arg_0 = 'set_dscp_mark'
    arg_1 = False
    arg_2 = 'ipv6'
    rule = []
    append_tcp_flags(rule, arg_0, arg_1, arg_2)
    assert rule == []


# Generated at 2022-06-25 02:43:45.897955
# Unit test for function append_match_flag
def test_append_match_flag():
    flag = 'flag'
    rule = []
    param = 'match'

    assert append_match_flag(rule, param, flag, False) == ['flag']


# Generated at 2022-06-25 02:43:50.235178
# Unit test for function get_iptables_version
def test_get_iptables_version():
    str_0 = None
    float_0 = None
    var_1 = get_iptables_version(str_0, float_0)


# Generated at 2022-06-25 02:43:50.984508
# Unit test for function check_present
def test_check_present():
    print("Test check_present\tpassed")


# Generated at 2022-06-25 02:43:59.978520
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        chain='INPUT',
        ip_version='ipv4',
        table='filter'
    )
    iptables_path = None
    action = '-A'
    make_rule = True
    # Test case 0
    params['destination_port'] = 8080
    params['jump'] = 'ACCEPT'
    params['protocol'] = 'tcp'
    params['reject_with'] = None
    params['comment'] = None
    result = push_arguments(iptables_path, action, params, make_rule)
    # Test case 1
    params['destination_port'] = 80
    params['jump'] = 'ACCEPT'
    params['protocol'] = 'tcp'
    params['reject_with'] = 'tcp-reset'
    params['comment']

# Generated at 2022-06-25 02:44:05.289453
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert callable(get_chain_policy)


# Generated at 2022-06-25 02:44:08.860015
# Unit test for function flush_table

# Generated at 2022-06-25 02:44:31.305637
# Unit test for function construct_rule
def test_construct_rule():
  var_0 = dict(jump='ACCEPT', protocol='tcp', destination_port='8080')
  var_1 = construct_rule(var_0)
  assert var_1 == ['-p', 'tcp', '--destination-port', '8080', '-j', 'ACCEPT']
  var_0 = dict(icmp_type='test', protocol='icmp', jump='ACCEPT')
  var_1 = construct_rule(var_0)
  assert var_1 == ['-p', 'icmp', '--icmp-type', 'test', '-j', 'ACCEPT']
  var_0 = dict(match=['tcp','http'], protocol='tcp', destination_port='80', jump='ACCEPT')
  var_1 = construct_rule(var_0)

# Generated at 2022-06-25 02:44:36.430023
# Unit test for function append_match_flag
def test_append_match_flag():
    var_0 = dict()
    var_0 = dict()
    var_1 = append_match_flag(var_0, 'match', 'match', True)
    assert var_1 == None
    var_1 = append_match_flag(var_0, 'negate', 'match', True)
    assert var_1 == None


# Generated at 2022-06-25 02:44:37.977839
# Unit test for function check_present
def test_check_present():
    var_0 = dict()

    # Check return value of function is not 'null'
    assert var_0 != "null"

# Generated at 2022-06-25 02:44:43.963068
# Unit test for function construct_rule
def test_construct_rule():
    var_0 = dict()
    var_0['ref_0'] = construct_rule(var_0)



# Generated at 2022-06-25 02:44:54.987310
# Unit test for function construct_rule
def test_construct_rule():
    var_0 = dict()
    var_0['wait'] = None
    var_0['source'] = None
    var_0['protocol'] = 'ip'
    var_0['destination'] = None
    var_0['match'] = None
    var_0['tcp_flags'] = None
    var_0['jump'] = 'ACCEPT'
    var_0['log_prefix'] = None
    var_0['log_level'] = None
    var_0['to_destination'] = None
    var_0['destination_ports'] = None
    var_0['to_source'] = None
    var_0['goto'] = None
    var_0['in_interface'] = None
    var_0['out_interface'] = None
    var_0['fragment'] = None
    var

# Generated at 2022-06-25 02:45:00.963035
# Unit test for function set_chain_policy
def test_set_chain_policy():
    # Test case 0
    ansible_0 = dict(
        chain="INPUT",
        policy="DROP",
    )
    set_chain_policy( module=ansible_0 , params=ansible_0 )


# Generated at 2022-06-25 02:45:11.402690
# Unit test for function construct_rule
def test_construct_rule():
    for tc in test_cases:
        params = tc.get('params', {})
        rule = construct_rule(params)

        print(rule)
        print(tc['expected_rule'])

        assert set(tc['expected_rule']) == set(rule)

# Generated at 2022-06-25 02:45:15.297630
# Unit test for function main
def test_main():
    mocker = Mocker()
    module = AnsibleModule({})
    var_0 = {}
    with mocker.order():
        main(var_0)


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:45:22.777668
# Unit test for function get_iptables_version
def test_get_iptables_version():
    var_0 = 'ansible.module_utils.basic.AnsibleModule('
    var_0 += '   argument_spec=dict('
    var_0 += '      chain=dict('
    var_0 += '         required=True,'
    var_0 += '         type="str",'
    var_0 += '      ),'
    var_0 += '      protocol=dict('
    var_0 += '         required=False,'
    var_0 += '         type="str",'
    var_0 += '      ),'
    var_0 += '      state=dict('
    var_0 += '         required=True,'
    var_0 += '         type="str",'
    var_0 += '      ),'
    var_0 += '      table=dict('
    var_0 += '         required=False,'

# Generated at 2022-06-25 02:45:24.306272
# Unit test for function remove_rule
def test_remove_rule():
    var_0 = dict()
    var_1 = dict()
    var_1 = remove_rule("/usr/sbin/iptables", var_0, var_1)




# Generated at 2022-06-25 02:45:49.611173
# Unit test for function set_chain_policy
def test_set_chain_policy():
    args = dict(
        iptables_path='/usr/sbin/iptables',
        module='module',
        params='params',
        )
    obj = dict(**args)
    set_chain_policy(**obj)


# Generated at 2022-06-25 02:45:58.134362
# Unit test for function construct_rule

# Generated at 2022-06-25 02:46:08.438776
# Unit test for function get_chain_policy
def test_get_chain_policy():
    cmd = iptables_path, module, params
    # Test for get_chain_policy(cmd){
    var_0 = (10, 10, 0)
    var_1 = (10, 10, 0)
    var_2 = (10, 10, 0)
    cmd = (var_0, var_1, var_2)
    # try:
    var_0 = get_chain_policy(cmd)
    # except:
    #   pass
    # try:
    var_1 = get_chain_policy(cmd) == None
    # except:
    #   pass
    # try:
    var_2 = get_chain_policy(cmd) == None
    # except:
    #   pass
    var_0 = get_chain_policy(cmd)

# Generated at 2022-06-25 02:46:11.550061
# Unit test for function construct_rule
def test_construct_rule():
    var_0 = dict()

    # Step into the function
    # Step into the function
    # Step into the function
    # Step into the function
    var_1 = construct_rule(var_0)


    print(var_1)


# Generated at 2022-06-25 02:46:16.575804
# Unit test for function insert_rule
def test_insert_rule():
    # No error
    try:
        iptables_path = 'iptables'
        module = 1
        params = 1
        insert_rule(iptables_path, module, params)
    except Exception as e:
        raise e


# Generated at 2022-06-25 02:46:25.502461
# Unit test for function main
def test_main():
    var1 = dict()
    for i in range(100):
        var1['table'] = random.randint(0,10)
        var1['state'] = random.randint(0,10)
        var1['action'] = random.randint(0,10)
        var1['ip_version'] = random.randint(0,10)
        var1['chain'] = random.randint(0,10)
        var1['rule_num'] = random.randint(0,10)
        var1['protocol'] = random.randint(0,10)
        var1['wait'] = random.randint(0,10)
        var1['source'] = random.randint(0,10)
        var1['to_source'] = random.randint(0,10)

# Generated at 2022-06-25 02:46:34.910616
# Unit test for function construct_rule
def test_construct_rule():
    var_0 = dict()
    # my_rule = construct_rule(var_0)
    # assert my_rule == ['--table', '', '--insert', '', '-w', '', '-p', '', '-s', '', '-d', '', '-m', '', '--tcp-flags', '', '-j', '', '--log-prefix', '', '--log-level', '', '--to-destination', '', '-m', '', '-c', '', '--syn', '', '--uid-owner', '', '-m', '', '--limit', '', '--limit-burst', '', '-m', '', '!', '--reject-with', '', '--reject-with', '', '--icmp-type', '']
    # var_

# Generated at 2022-06-25 02:46:37.151922
# Unit test for function set_chain_policy
def test_set_chain_policy():

    var_0 = dict()
    var_1 = push_arguments('$0', '-P', var_0, make_rule=False)
    var_2 = var_1.append(var_0['policy'])
    # Returns 0



# Generated at 2022-06-25 02:46:38.825902
# Unit test for function main

# Generated at 2022-06-25 02:46:40.197625
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test_case_0()


# Generated at 2022-06-25 02:47:35.154984
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    for test_case_0 in [{'tcp_flags': {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': []}}, {'tcp_flags': {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}}]:
        assert True == append_tcp_flags(var_0, test_case_0['tcp_flags'], '-m tcp')


# Generated at 2022-06-25 02:47:40.203373
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    var_1 = dict()
    var_1['flags'] = ['some', 'flags']
    var_1['flags_set'] = ['some', 'flags_set']
    var_0 = []
    append_tcp_flags(var_0, var_1, '--tcp-flags')
    return var_0 == ['--tcp-flags', 'some,flags', 'some,flags_set']



# Generated at 2022-06-25 02:47:43.224254
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = dict()
    print(get_chain_policy(var_0, var_0, var_0))


# Generated at 2022-06-25 02:47:51.497733
# Unit test for function get_chain_policy
def test_get_chain_policy():

    module = AnsibleModule(
        argument_spec=dict(
            ip_version=dict(type='str', choices=['ipv4', 'ipv6'], required=True),
            chain=dict(type='str', required=True),
            table=dict(type='str', default='filter',
                       choices=['raw', 'mangle', 'nat', 'filter', 'security']),
        )
    )

    params = module.params
    iptables_path = BINS[params['ip_version']]

    result = get_chain_policy(iptables_path, module, params)

    module.exit_json(msg=result)


# Generated at 2022-06-25 02:47:53.339445
# Unit test for function set_chain_policy
def test_set_chain_policy():
    var_0 = dict()
    var_0['policy'] = "ACCEPT"
    var_0['chain'] = "INPUT"
    var_0['table'] = "nat"
    set_chain_policy("iptables", test_case_0(), var_0)


# Generated at 2022-06-25 02:47:57.786994
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = {}
    params['policy'] = None
    params['wait'] = None
    params['destination'] = None
    params['uid_owner'] = None
    params['log_level'] = None
    params['protocol'] = None
    params['source'] = None
    params['jump'] = None
    params['table'] = None
    params['ctstate'] = None
    params['action'] = 'insert'
    params['gateway'] = None
    params['set_dscp_mark_class'] = None
    params['match_set_flags'] = None
    params['limit'] = None
    params['limit_burst'] = None
    params['log_prefix'] = None
    params['set_counters'] = None
    params['match'] = None
    params['set_dscp_mark'] = None

# Generated at 2022-06-25 02:48:06.021457
# Unit test for function construct_rule
def test_construct_rule():
    rule = []
    var_0 = dict()

# Generated at 2022-06-25 02:48:10.646362
# Unit test for function push_arguments
def test_push_arguments():

    # No IO
    var_0 = dict()
    var_1 = "test"
    var_2 = var_0
    var_3 = var_1
    ret_0 = push_arguments(var_0, var_1, var_2, var_3)
    assert ret_0 is None



# Generated at 2022-06-25 02:48:21.919263
# Unit test for function append_rule

# Generated at 2022-06-25 02:48:31.641969
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = dict()

    # adding an element to the dict
    var_0['iptables_path'] = '/usr/bin/iptables'

    # adding an element to the dict
    var_0['module'] = ''

    # adding an element to the dict
    var_0['params'] = dict()

    # adding an element to the dict
    var_0['params']['table'] = 'filter'

    # adding an element to the dict
    var_0['params']['chain'] = 'INPUT'

    # calling the test case
    get_chain_policy(var_0['iptables_path'], var_0['module'], var_0['params'])


# Generated at 2022-06-25 02:49:24.201056
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict()
    param['flags'] = 'ALL'
    param['flags_set'] = ['ACK','RST','SYN','FIN']
    flag = '--tcp-flags'
    test_case_0()
    test_case_0()
    assert rule == [flag, 'ALL', 'ACK,RST,SYN,FIN']


# Generated at 2022-06-25 02:49:33.157584
# Unit test for function check_present

# Generated at 2022-06-25 02:49:39.796264
# Unit test for function main
def test_main():
    var_0 = dict()
    var_0['table'] = "filter"
    var_0['set_dscp_mark_class'] = ""
    var_0['log_prefix'] = ""
    var_0['source_port'] = ""
    var_0['policy'] = ""
    var_0['icmp_type'] = ""
    var_0['syn'] = "ignore"
    var_0['state'] = "present"
    var_0['tcp_flags'] = dict()
    var_0['out_interface'] = ""
    var_0['destination'] = ""
    var_0['destination_port'] = ""
    var_0['ip_version'] = "ipv4"
    var_0['chain'] = ""
    var_0['limit'] = ""
    var_0

# Generated at 2022-06-25 02:49:49.840945
# Unit test for function construct_rule
def test_construct_rule():
    rule = construct_rule(var_0)

# Generated at 2022-06-25 02:49:51.872681
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule(var_0)


# Generated at 2022-06-25 02:50:01.629521
# Unit test for function check_present
def test_check_present():
    assert(callable(check_present))
    module = AnsibleModule()

# Generated at 2022-06-25 02:50:03.158087
# Unit test for function append_rule
def test_append_rule():
    # Push arguments
    iptables_path = ""
    module = dict()
    params = dict()
    # Call function
    append_rule(iptables_path, module, params)


# Generated at 2022-06-25 02:50:12.916220
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec = dict())
    var_0 = None
    var_1 = str()
    var_2 = dict()
    var_3 = True
    var_4 = None
    var_0 = check_present(var_1, var_2, var_3, var_4)

# Module initialization

# Generated at 2022-06-25 02:50:22.130178
# Unit test for function main
def test_main():
    args = dict()
    args['table'] = 'filter'
    args['state'] = 'present'
    args['action'] = 'append'
    args['ip_version'] = 'ipv4'
    args['chain'] = 'INPUT'
    args['rule_num'] = None
    args['protocol'] = 'tcp'
    args['wait'] = None
    args['source'] = None
    args['to_source'] = None
    args['destination'] = None
    args['to_destination'] = None
    args['match'] = list()
    args['tcp_flags'] = dict()
    args['jump'] = None
    args['gateway'] = None
    args['log_prefix'] = None
    args['log_level'] = None
    args['goto'] = None

# Generated at 2022-06-25 02:50:32.514436
# Unit test for function push_arguments
def test_push_arguments():
    var_0 = dict()
    var_1 = dict()
    action_0 = '-I'
    action_1 = '-I'
    params_0 = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp'
    )
    params_1 = dict(
        table='filter',
        chain='INPUT',
        protocol='udp'
    )
    cmd_0_0 = push_arguments(var_0, action_0, params_0)
    cmd_0_1 = push_arguments(var_0, action_1, params_1)
    cmd_1_0 = push_arguments(var_1, action_0, params_0)
    cmd_1_1 = push_arguments(var_1, action_1, params_1)
   

# Generated at 2022-06-25 02:51:43.077377
# Unit test for function flush_table
def test_flush_table():
    var_0 = [{'ipv6': 'ip6tables', 'ipv4': 'iptables'}, {'ipv6': 'ip6tables', 'ipv4': 'iptables'}, {'ipv6': 'ip6tables', 'ipv4': 'iptables'}]
    var_1 = [{'ipv6': 'ip6tables', 'ipv4': 'iptables'}, {'ipv6': 'ip6tables', 'ipv4': 'iptables'}, {'ipv6': 'ip6tables', 'ipv4': 'iptables'}]
    var_2 = dict()
    #testing function
    flush_table(var_0, var_1, var_2)

test_case_0()
print("Test 0 Success")
test_flush_table

# Generated at 2022-06-25 02:51:48.905587
# Unit test for function get_chain_policy
def test_get_chain_policy():
    out4 = 'test_out4'
    var2 = 'test_var2'
    var12 = 'test_var12'
    var1 = 'test_var1'
    out3 = 'test_out3'
    out2 = 'test_out2'
    var3 = 'test_var3'
    var15 = 'test_var15'
    var16 = 'test_var16'
    var5 = 'test_var5'
    var17 = 'test_var17'
    var8 = 'test_var8'
    var7 = 'test_var7'
    out1 = 'test_out1'
    var9 = 'test_var9'
    var6 = 'test_var6'
    var10 = 'test_var10'
    rc = 'test_rc'
    var14

# Generated at 2022-06-25 02:51:57.305791
# Unit test for function construct_rule
def test_construct_rule():
    var_1 = dict()
    var_1['register'] = 'ansible_facts'
    var_1['ip_version'] = 'ipv4'
    var_1['jump'] = None
    var_1['protocol'] = None
    var_1['limit'] = '5/second'
    var_1['limit_burst'] = '100'
    var_1['uid_owner'] = 'root'
    var_1['gid_owner'] = 'root'
    var_1['reject_with'] = None
    var_1['tcp_flags'] = None
    var_1['icmp_type'] = None
    var_1['wait'] = '0'
    var_1['syn'] = None
    var_1['ctstate'] = None
    var_1['policy'] = None


# Generated at 2022-06-25 02:52:00.620904
# Unit test for function main
def test_main():
    var_1=main()


# Generated at 2022-06-25 02:52:10.890763
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_1 = "iptables"
    var_2 = AnsibleModule(argument_spec=dict())
    var_3 = dict()
    var_3["table"] = 'filter'
    var_3["ip_version"] = 'ipv4'
    var_3["chain"] = 'INPUT'
    var_3["policy"] = 'ACCEPT'
    var_3["state"] = 'present'
    var_3["flush"] = False
    var_3["action"] = "append"
    var_3["rule_num"] = None
    var_3["comment"] = None
    var_3["destination"] = None
    var_3["destination_port"] = None
    var_3["destination_ports"] = None
    var_3["protocol"] = None

# Generated at 2022-06-25 02:52:12.051210
# Unit test for function check_present
def test_check_present():
    var_0 = dict()
    return not(check_present(var_0))

# Unit tests for function iptables

# Generated at 2022-06-25 02:52:13.528913
# Unit test for function construct_rule
def test_construct_rule():
    var_0 = dict()
    assert construct_rule(var_0) == [], "task_1"


# Generated at 2022-06-25 02:52:14.317973
# Unit test for function append_match_flag
def test_append_match_flag():
    assert True


# Generated at 2022-06-25 02:52:21.802645
# Unit test for function append_match_flag
def test_append_match_flag():
    var0 = dict()
    append_match_flag(var0, 'match', 'test0', False)
    assert var0 == {'test0'}
    var1 = dict()
    append_match_flag(var1, 'negate', 'test1', True)
    assert var1 == {'!test1'}
    var2 = dict()
    append_match_flag(var2, None, 'test2', False)
    assert var2 == dict()



# Generated at 2022-06-25 02:52:22.772332
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = dict()
    assert get_chain_policy(var_0) == 0
