

# Generated at 2022-06-25 02:43:36.087474
# Unit test for function remove_rule
def test_remove_rule():
    str_1 = '\x0b\x0f!\td!Zm'

# Generated at 2022-06-25 02:43:45.027795
# Unit test for function append_rule
def test_append_rule():
    
    # Test keys to be used in parameter dict
    table = "filter"
    chain = "INPUT"
    dst = "1.2.3.4"
    jump = "ACCEPT"

    # Test parameters
    params = {
        "table": table,
        "chain": chain,
        "destination": dst,
        "jump": jump,
    }

    # Test command
    cmd = push_arguments('/usr/sbin/iptables', '-A', params)
    assert cmd == [
        '/usr/sbin/iptables', '-t', table, '-A', chain, '-d', dst, '-j', jump
    ]

# YAML test case # 0



# Generated at 2022-06-25 02:43:50.360798
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = list()
    param = 'match'
    flag = '--syn'
    negatable = True
    append_match_flag(rule, param, flag, negatable)

    if rule[0] == '--syn':
        return 1
    else:
        return 0


# Generated at 2022-06-25 02:44:01.840967
# Unit test for function flush_table
def test_flush_table():
    str_0 = '^r\x0caw!\tL!3AX'
    str_1 = '^r\x0caw!\tL!3AX'
    str_2 = '^r\x0caw!\tL!3AX'
    str_3 = '^r\x0caw!\tL!3AX'
    str_4 = '^r\x0caw!\tL!3AX'
    str_5 = '^r\x0caw!\tL!3AX'
    str_6 = '^r\x0caw!\tL!3AX'
    str_7 = '^r\x0caw!\tL!3AX'
    str_8 = '^r\x0caw!\tL!3AX'
   

# Generated at 2022-06-25 02:44:07.872149
# Unit test for function flush_table
def test_flush_table():
    str_0 = 'P\x0c[\x1f'
    str_1 = 'J\x1fq\x1f\x0cR\t'
    var_0 = get_iptables_version(str_0, str_0)
    var_1 = get_iptables_version(str_0, str_1)
    var_2 = get_iptables_version(str_1, str_1)
    var_3 = get_iptables_version(str_1, str_0)


# Generated at 2022-06-25 02:44:08.642403
# Unit test for function append_match_flag
def test_append_match_flag():
    test_case_0()


# Generated at 2022-06-25 02:44:09.374203
# Unit test for function push_arguments
def test_push_arguments():

    assert True == True


# Generated at 2022-06-25 02:44:11.019594
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = [ 'iptables' ]
    param = 'negate'
    flag = '--protocol'
    negatable = True
    assert append_match_flag(rule, param, flag, negatable) == None


# Generated at 2022-06-25 02:44:21.653804
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test', '--test-flag', False)
    if rule != [ '--test-flag', 'test' ]:
        print("Rule {} doesn't match expected result {}".format(rule, ['--test-flag', 'test']))
        return False
    rule = []
    append_param(rule, ['test', 'test2'], '--test-flag', True)
    if rule != [ '--test-flag', 'test', '--test-flag', 'test2' ]:
        print("Rule {} doesn't match expected result {}".format(rule, ['--test-flag', 'test', '--test-flag', 'test2']))
        return False
    rule = []
    append_param(rule, ['test', '!test2'], '--test-flag', True)


# Generated at 2022-06-25 02:44:23.637281
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(list(), str(), str(), bool()) == None


# Generated at 2022-06-25 02:44:45.013308
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_rule = []
    test_param = dict(flags=['SYN', 'ACK', 'RST'], flags_set=['SYN', 'ACK'])
    append_tcp_flags(test_rule, test_param, '--tcp-flags')
    if not test_rule == ['--tcp-flags', 'SYN,ACK,RST', 'SYN,ACK']:
        print('Failed test_append_tcp_flags. Expected: [\'--tcp-flags\', \'SYN,ACK,RST\', \'SYN,ACK\'], got: ' + str(test_rule))
        return False

    return True



# Generated at 2022-06-25 02:44:50.398225
# Unit test for function construct_rule

# Generated at 2022-06-25 02:45:00.982884
# Unit test for function construct_rule
def test_construct_rule():
    # Source:
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate=['NEW'],
        syn=['match'],
        jump=['ACCEPT'],
        comment=['Accept new SSH connections.'],
    )

    # Expected result:
    # iptables -A INPUT -p tcp --dport 22 -m conntrack --ctstate NEW -m syn -j ACCEPT -m comment --comment "Accept new SSH connections."
    result = construct_rule(params)


# Generated at 2022-06-25 02:45:11.411496
# Unit test for function check_present
def test_check_present():
    # Define test case inputs
    iptables_path = 'q\x0e\x14\x0eD\x15\x1b\x0e\x0b'
    module = 'm\x11Km\x06\x13'
    params = 'd\x1c\x1e\x1d\x0c@\x01\x16\x13\x12\x1b\x0b#\x1a\x06\x12'

    # Define expected output(s)
    expected = '8\x0b?L\x11m\x19\x0b\x1c1\x13\x0bB'

    # Actual function output
    actual = check_present(iptables_path, module, params)

    # Assert that actual values match expected values

# Generated at 2022-06-25 02:45:18.014554
# Unit test for function construct_rule
def test_construct_rule():
    """Unit test for function construct_rule"""
    test_rule_0 = '-A INPUT -s 10.0.0.1 -s ! 10.0.0.2 -s 10.0.0.3 -p tcp -m multiport --dports 80,443,8081:8083 -j ACCEPT -m comment --comment "Accept new SSH connections."'
    params_0 = {
        'syn': 'match',
        'protocol': 'tcp',
        'source': ['10.0.0.1', '10.0.0.2', '10.0.0.3'],
        'jump': 'ACCEPT',
        'destination_ports': ['80', '443', '8081:8083'],
        'comment': 'Accept new SSH connections.',
    }
    rule_0 = construct_

# Generated at 2022-06-25 02:45:27.016303
# Unit test for function check_present
def test_check_present():
    # Test case 1
    str_1 = 'iptables --version'
    var_1 = get_iptables_version(str_1, str_1)
    
    if var_1 >= LooseVersion(IPTABLES_WAIT_SUPPORT_ADDED):
        # Test case 2
        str_2 = 'iptables -t filter -C INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT'
        var_2 = check_present(str_2, str_2, str_2)
        print(var_2)
    else:
        # Test case 3
        str_3 = 'iptables -t filter -C INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT'

# Generated at 2022-06-25 02:45:32.082460
# Unit test for function insert_rule
def test_insert_rule():
    var_0 = '^r\x0caw!\tL!3AX'
    var_1 = var_0
    var_2 = var_0
    var_2 = LooseVersion(var_2)
    var_3 = LooseVersion('1.6.0')
    var_4 = LooseVersion('1.4.20')
    var_5 = LooseVersion('1.6.0')
    var_6 = LooseVersion('1.4.20')
    var_7 = LooseVersion('1.6.0')
    var_8 = LooseVersion('1.4.20')
    var_9 = LooseVersion('1.6.0')
    var_10 = LooseVersion('1.4.20')
    var_11 = LooseVersion('1.6.0')
   

# Generated at 2022-06-25 02:45:34.651016
# Unit test for function get_chain_policy
def test_get_chain_policy():
    str_0 = '^r\x0caw!\tL!3AX'
    var_0 = get_iptables_version(str_0, str_0)
    if var_0 is not None:
        var_0 = str(var_0)
    assert var_0 is None, 'g_0 = {0}'.format(var_0)


# Generated at 2022-06-25 02:45:40.510639
# Unit test for function main

# Generated at 2022-06-25 02:45:43.145407
# Unit test for function flush_table
def test_flush_table():
    params = dict(
        table='nat',
        chain='INPUT',
        flush=True
    )
    flush_table('iptables', params, make_rule=False)


# Generated at 2022-06-25 02:45:58.860408
# Unit test for function main
def test_main():
    args = dict(
        table='filter',
        state='present',
        action='append',
        ip_version='ipv4',
        chain=None,
        flush=False,
        rule=''
    )

    with pytest.raises(AnsibleExitJson):
        main()

    with pytest.raises(AnsibleFailJson):
        main()

    args = dict(
        table='filter',
        state='present',
        action='append',
        ip_version='ipv4',
        chain='INPUT',
        flush=False,
        rule=''
    )

    with pytest.raises(AnsibleExitJson):
        main()


# Generated at 2022-06-25 02:46:04.407744
# Unit test for function flush_table
def test_flush_table():
    str_0 = '^r\x0caw!\tL!3AX'
    assert (flush_table(str_0, str_0, str_0) == None)


# Generated at 2022-06-25 02:46:06.268820
# Unit test for function push_arguments
def test_push_arguments():
    var_0 = push_arguments(str_0, '-I', d)


# Generated at 2022-06-25 02:46:17.534220
# Unit test for function get_chain_policy
def test_get_chain_policy():
    # Test with valid and invalid parameters
    str_0 = '^r\x0caw!\tL!3AX'
    str_1 = '^r\x0caw!\tL!3AX'
    var_0 = get_iptables_version(str_0, str_1)

# Generated at 2022-06-25 02:46:19.542521
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = ''
    module = ''
    params = ''
    iptables_path = '<value>'
    module = '<value>'
    params = '<value>'
    try:
        set_chain_policy(iptables_path, module, params)
    except Exception:
        raise


# Generated at 2022-06-25 02:46:22.852860
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']


# Generated at 2022-06-25 02:46:35.115885
# Unit test for function main

# Generated at 2022-06-25 02:46:47.363855
# Unit test for function get_chain_policy
def test_get_chain_policy():
  assert get_chain_policy('\x00\\\x74\t\\\x1d\x1f\x1b\x0e\x0f\x03\x06\x05\x00\x00', '\x00\\\x74\t\\\x1d\x1f\x1b\x0e\x0f\x03\x06\x05\x00\x00', '\x00\\\x74\t\\\x1d\x1f\x1b\x0e\x0f\x03\x06\x05\x00\x00') == '\x00\\\x74\t\\\x1d\x1f\x1b\x0e\x0f\x03\x06\x05\x00\x00'

#

# Generated at 2022-06-25 02:46:48.643861
# Unit test for function construct_rule
def test_construct_rule():
    params = dict()
    construct_rule(params)


# Generated at 2022-06-25 02:46:54.873712
# Unit test for function construct_rule
def test_construct_rule():
    assert  construct_rule('8.0.0.0', 'tcp', 'tcp', 'tcp', 'tcp', 'tcp', 'tcp',\
                          'tcp', 'tcp', 'tcp', 'tcp', 'tcp', 'tcp', 'tcp', 'tcp',\
                          'tcp', 'tcp', 'tcp', 'tcp', 'tcp', 'tcp', 'tcp', 'tcp',\
                          'tcp', 'tcp', 'tcp') == 'tcp'

# Generated at 2022-06-25 02:47:12.188658
# Unit test for function set_chain_policy
def test_set_chain_policy():
    str_0 = '\x14\x1e\r\r'
    module_0 = get_module()
    arguments_0 = dict()
    expand_tilde_0 = dict()
    expand_tilde_0['src_range'] = ''
    expand_tilde_0['reject_with'] = ''
    expand_tilde_0['protocol'] = ''
    expand_tilde_0['comment'] = ''
    expand_tilde_0['limit_burst'] = '*\x7f\x0f\x0eI\x1f\x05'
    expand_tilde_0['src_range'] = ''
    expand_tilde_0['dst_range'] = ''
    expand_tilde_0['protocol'] = ''

# Generated at 2022-06-25 02:47:20.322196
# Unit test for function construct_rule

# Generated at 2022-06-25 02:47:26.122884
# Unit test for function remove_rule
def test_remove_rule():
    str_0 = 'Rv2\r'
    params = get_params(str_0, str_0)
    params['jump'] = 'RETURN'
    var_0 = remove_rule(str_0, str_0, params)


# Generated at 2022-06-25 02:47:38.284978
# Unit test for function insert_rule
def test_insert_rule():
    str_0 = '\x0c.R\x0c\x17\x1a\x1ds'
    str_1 = '0E^\x04T#\x09'
    str_2 = '\x18\x1d\x0b\x0b$\x0b\x03\x1d\x1a\x1d\x06Q'
    str_3 = '\x0c.R\x0c\x17\x1a\x1ds'
    str_4 = '0E^\x04T#\x09'
    str_5 = '\x18\x1d\x0b\x0b$\x0b\x03\x1d\x1a\x1d\x06Q'

# Generated at 2022-06-25 02:47:43.010659
# Unit test for function main
def test_main():
    str_0 = '^r\x0caw!\tL!3AX'
    str_1 = '^r\x0caw!\tL!3AX'
    main(str_0, str_1)


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:47:53.577911
# Unit test for function get_chain_policy
def test_get_chain_policy():
    chain = 'INPUT'
    policy = 'ACCEPT'
    table = 'filter'
    ip_version = 'ipv4'

    module = AnsibleModule({
        'chain': chain,
        'policy': policy,
        'table': table,
        'ip_version': ip_version,
    })

    iptables_bin = BINS[module.params['ip_version']]
    if module.params['ip_version'] == 'ipv6':
        module.fail_json(msg="Ipv6 not supported yet in get_chain_policy, please use ipv4")

    if not module.get_bin_path(iptables_bin, required=True):
        module.fail_json(msg="Could not find '%s' executable on the target" % iptables_bin)

    module.run_

# Generated at 2022-06-25 02:48:03.044079
# Unit test for function construct_rule

# Generated at 2022-06-25 02:48:04.012374
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule(None, None, None)


# Generated at 2022-06-25 02:48:09.113296
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({})
    BINS['ipv4'] = 'iptables'
    set_chain_policy(BINS['ipv4'], module, {'chain': None, 'table': 'filter', 'policy': 'ACCEPT', 'ip_version': 'ipv4'})
    set_chain_policy(BINS['ipv4'], module, {'chain': None, 'table': 'filter', 'policy': 'ACCEPT', 'ip_version': 'ipv4'})
    set_chain_policy(BINS['ipv4'], module, {'chain': None, 'table': 'filter', 'policy': 'ACCEPT', 'ip_version': 'ipv4'})

# Generated at 2022-06-25 02:48:13.266129
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4'
    )
    rules = construct_rule(params)
    assert rules == ['-w', '-p', '-s', '-d', '-m', '--limit', '--limit-burst',
        '--uid-owner', '--gid-owner', '--reject-with', '--icmp-type']


# Generated at 2022-06-25 02:48:53.455139
# Unit test for function append_rule
def test_append_rule():
    str_0 = '^r\x0caw!\tL!3AX'
    append_rule(str_0, str_0, str_0)


# Generated at 2022-06-25 02:48:55.688182
# Unit test for function get_iptables_version
def test_get_iptables_version():
    str_0 = '^r\x0caw!\tL!3AX'
    var_0 = get_iptables_version(str_0, str_0)
    print(var_0)
    print("Success #0")


# Generated at 2022-06-25 02:48:57.794727
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(var_0, var_0, var_0) == var_0


# Generated at 2022-06-25 02:49:07.234500
# Unit test for function push_arguments
def test_push_arguments():
    str_0 = '`\x7f\x0b\x7f\x0b\x7f\x0b\x7fgx'
    str_22 = '\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f\x1f'
    var_4 = push_arguments(str_0, str_22, str_0, str_0)
    print(var_4)




# Generated at 2022-06-25 02:49:15.262919
# Unit test for function construct_rule
def test_construct_rule():
    var_0 = 0

# Generated at 2022-06-25 02:49:21.533953
# Unit test for function check_present
def test_check_present():
    if LooseVersion('1.6.0') >= LooseVersion(IPTABLES_WAIT_WITH_SECONDS_SUPPORT_ADDED):
        str_0 = 'r\x0caw!\tL!3AX'
        var_0 = get_iptables_version(str_0, str_0)


# Generated at 2022-06-25 02:49:33.156744
# Unit test for function construct_rule

# Generated at 2022-06-25 02:49:34.097306
# Unit test for function insert_rule
def test_insert_rule():
    pass


# Generated at 2022-06-25 02:49:40.317374
# Unit test for function get_chain_policy
def test_get_chain_policy():
    str_0 = '$G|#\x1aB\x06e'
    str_1 = '|'
    str_2 = '<\x0b'
    str_3 = '\x05\x0b\x0c'
    str_4 = '\x05\x0b\x0c'
    str_5 = '@\x17\x0ch\x1f%\x1f\x1d]$\x0eF'

# Generated at 2022-06-25 02:49:44.924556
# Unit test for function construct_rule

# Generated at 2022-06-25 02:50:57.031950
# Unit test for function construct_rule

# Generated at 2022-06-25 02:51:03.387573
# Unit test for function construct_rule

# Generated at 2022-06-25 02:51:10.562613
# Unit test for function check_present
def test_check_present():
    # Test Cases
    module = type('', (), {})()
    module.run_command = lambda x, y: (0, '', '')

# Generated at 2022-06-25 02:51:16.346069
# Unit test for function get_chain_policy
def test_get_chain_policy():
    # Test case 0
    str_0 = '^r\x0caw!\tL!3AX'
    str_1 = '\n\t\x00\x15e'
    var_0 = get_iptables_version(str_0, str_1)
    if var_0 != 0:
        print('function get_iptables_version failed')
        exit(1)
    var_1 = str_0
    var_2 = str_1
    var_3 = get_chain_policy(var_1, var_0, var_2)
    if var_3 != 'ACCEPT':
        print('function get_chain_policy failed')
        exit(1)
    print('Test case 0 passed')


# Generated at 2022-06-25 02:51:17.385764
# Unit test for function set_chain_policy
def test_set_chain_policy():
    set_chain_policy(True, True, True)


# Generated at 2022-06-25 02:51:18.698825
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(iptables_path, module, params) == 'DROP'


# Generated at 2022-06-25 02:51:21.157965
# Unit test for function append_rule
def test_append_rule():
    str_0 = '\x10\x0cu\x1aGi\x11'
    var_0 = get_iptables_version(str_0, str_0)


# Generated at 2022-06-25 02:51:31.592907
# Unit test for function push_arguments
def test_push_arguments():
    # Tests iptables path is requested when waiting on a lock
    var_0 = 'iptables'
    var_1 = ['-t', 'filter', '-w', '1', '-A', 'test']
    var_2 = 'iptables-legacy'
    var_3 = ['-w', '1', var_0, '-t', 'filter', '-A', 'test']
    var_4 = '-w'
    if LooseVersion(var_0) >= IPTABLES_WAIT_WITH_SECONDS_SUPPORT_ADDED:
        var_4 += ' 1'
    if var_4 not in var_1:
        var_5 = var_1.index('-t')
        var_1.insert(var_5, var_4)

# Generated at 2022-06-25 02:51:36.664285
# Unit test for function main
def test_main():
    # Check if there is any argument
    assert len(sys.argv) >= 2

    # Run tests
    if sys.argv[1] == '0':
        test_case_0()
    else:
        print('unknown test case: ' + sys.argv[1])


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:51:40.392015
# Unit test for function construct_rule
def test_construct_rule():
    rule = construct_rule({'protocol': 'tcp',
                           'source': '8.8.8.8',
                           'jump': 'DROP'})
    assert rule == ['-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP']
