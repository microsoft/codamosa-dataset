

# Generated at 2022-06-25 02:43:33.257562
# Unit test for function insert_rule

# Generated at 2022-06-25 02:43:36.341845
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'run_command', return_value=(0, '', '')):
        with patch.object(AnsibleModule, 'get_bin_path', return_value='/sbin/iptables'):
            with patch.object(AnsibleModule, 'fail_json', return_value='/sbin/iptables'):
                var_0 = main()


# Generated at 2022-06-25 02:43:45.524580
# Unit test for function main
def test_main():
    var_0 = AnsibleModule()
    var_1 = 'filter'
    var_0.params['table'] = var_1         # filter
    var_2 = 'present'
    var_0.params['state'] = var_2         # present
    var_3 = 'append'
    var_0.params['action'] = var_3        # append
    var_4 = 'ipv4'
    var_0.params['ip_version'] = var_4    # ipv4
    var_5 = 'input'
    var_0.params['chain'] = var_5         # input
    var_6 = '6'
    var_0.params['rule_num'] = var_6      # 6
    var_7 = 'udp'
    var_0.params['protocol'] = var_7     

# Generated at 2022-06-25 02:43:56.546701
# Unit test for function set_chain_policy

# Generated at 2022-06-25 02:44:08.484000
# Unit test for function check_present

# Generated at 2022-06-25 02:44:11.292503
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test_params = {
        "params": "",
        "chain": "INPUT",
        "jump": "ACCEPT",
        "action": "append",
        "table": "filter",
        "state": "present"
    }
    test_result = get_chain_policy(test_params)
    return test_result


# Generated at 2022-06-25 02:44:17.327086
# Unit test for function set_chain_policy
def test_set_chain_policy():
    arguments = dict(
        chain="INPUT",
        policy="DROP",
        table="filter",
        comment="null"
    )

# Generated at 2022-06-25 02:44:26.605807
# Unit test for function push_arguments
def test_push_arguments():
    var_0 = 'iptables'
    var_1 = '-I'

# Generated at 2022-06-25 02:44:30.810911
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    expected = ['--tcp-flags', ',ALL,ACK,RST,SYN,FIN']
    input = dict(flags=['ALL'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    var_0 = append_tcp_flags([], input, '--tcp-flags')
    assert var_0 == expected


# Generated at 2022-06-25 02:44:40.411711
# Unit test for function get_chain_policy
def test_get_chain_policy():
    # Get the mock object from iptables module
    iptables_module_mock = pytest.Mock()

    # Assign the return value of iptables_module_mock.run_command to
    # the mock object run_command_mock
    run_command_mock = iptables_module_mock.run_command
    run_command_mock.return_value = ["iptables", "-L", "-C", "my_chain"]

    # Set the return value of the mocked run_command() method from the iptables module
    # to return a tuple of rc, stdout and stderr.
    run_command_mock.return_value = (0, "", "")

    # Get the return value of the mocked run_command() by calling the get_chain_policy()
    # function.
   

# Generated at 2022-06-25 02:47:17.905114
# Unit test for function construct_rule
def test_construct_rule():
    var_1 = dict(
        chain='INPUT',
        jump='DROP',
        ip_version='ipv4',
    )
    var_2 = construct_rule(var_1)
    assert var_2 == ['iptables', '-A', 'INPUT', '-j', 'DROP']

    var_1 = dict(
        chain='INPUT',
        destination_port='22',
        jump=None,
        ip_version='ipv4',
        comment='test',
    )
    var_2 = construct_rule(var_1)

# Generated at 2022-06-25 02:47:23.390639
# Unit test for function construct_rule

# Generated at 2022-06-25 02:47:38.265117
# Unit test for function push_arguments
def test_push_arguments():
    print("run unit test for function push_arguments")
    params = dict(
        iptables_path = 'iptables',
        action = '-I',
        table = 'filter',
        chain = 'INPUT',
        protocol = 'tcp',
        jump = 'ACCEPT',
        destination_port = '22',
        ctstate = 'NEW',
        syn = 'match',
    )
    expected_result = [ 'iptables', '-t', 'filter', '-I', 'INPUT', '-p', 'tcp',
                        '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW',
                        '--syn', '-j', 'ACCEPT' ]

    actual_result = push_arguments('iptables', '-I', params)

# Generated at 2022-06-25 02:47:40.973937
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, None) == None


# Generated at 2022-06-25 02:47:49.032328
# Unit test for function construct_rule

# Generated at 2022-06-25 02:47:51.996305
# Unit test for function append_param
def test_append_param():
    rule = ['action', 'append']
    param = 'chain'
    flag = '--chain'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['action', 'append', '--chain', 'chain']


# Generated at 2022-06-25 02:48:02.461057
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = "iptables"
    action = "-A"
    params = dict(
        ip_version="ipv4",
        table="filter",
        chain="INPUT",
        protocol="tcp",
        source_port="8080",
        jump="DROP",
    )
    make_rule = True
    expected = [
        "iptables",
        "-t",
        "filter",
        "-A",
        "INPUT",
        "-p",
        "tcp",
        "--source-port",
        "8080",
        "-j",
        "DROP"
    ]
    actual = push_arguments(iptables_path, action, params, make_rule)
    assert actual == expected


# Generated at 2022-06-25 02:48:14.512928
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = "/sbin/iptables"
    module = AnsibleModule()
    params = dict()
    params['table'] = ""
    params['chain'] = ""
    params['protocol'] = ""
    params['source'] = ""
    params['destination'] = ""
    params['match'] = ""
    params['tcp_flags'] = ""
    params['jump'] = ""
    params['log_prefix'] = ""
    params['log_level'] = ""
    params['to_destination'] = ""
    params['destination_ports'] = ""
    params['to_source'] = ""
    params['goto'] = ""
    params['in_interface'] = ""
    params['out_interface'] = ""
    params['fragment'] = ""
    params['set_counters'] = ""

# Generated at 2022-06-25 02:48:18.199824
# Unit test for function check_present
def test_check_present():
    var_0 = main()
    assert(check_present(var_0, var_0, var_0) == var_0)


# Generated at 2022-06-25 02:48:21.973823
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('iptables', '-I', 'INPUT', True) == ['-I', 'INPUT']


# Generated at 2022-06-25 02:51:33.554562
# Unit test for function construct_rule

# Generated at 2022-06-25 02:51:44.703055
# Unit test for function check_present

# Generated at 2022-06-25 02:51:50.071731
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol="tcp",
        source="8.8.8.8"
        )
    rule = ["-p tcp","-s 8.8.8.8"]
    assert construct_rule(params) == rule, "Failed test_construct_rule"
    print("Passed test_construct_rule")
    print(construct_rule(params))




# Generated at 2022-06-25 02:51:52.059407
# Unit test for function get_chain_policy
def test_get_chain_policy():
    var_0 = main()
    assert var_0['changed']


# Generated at 2022-06-25 02:51:59.723338
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        source='10.0.0.0/8',
        match=['comment', 'multiport'],
        destination_ports=[8000, '8080', '9090'],
        jump=None,
        ctstate='ESTABLISHED,NEW',
        flush=False,
        policy=None,
        syn='match',
        match_set='admin_hosts',
        match_set_flags='src',
        src_range='192.168.1.100-192.168.1.199',
        dst_range='10.0.0.1-10.0.0.50',
    )
    rules = construct_rule(params)

# Generated at 2022-06-25 02:52:11.529230
# Unit test for function construct_rule
def test_construct_rule():
    rule_0 = construct_rule(params=dict(
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        ip_version='ipv4',
    ))
    assert rule_0 == ['-p', 'tcp', '--dport', '80', '-j', 'ACCEPT', '-w']
    rule_1 = construct_rule(params=dict(
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        ip_version='ipv6',
    ))
    assert rule_1 == ['-p', 'tcp', '--dport', '80', '-j', 'ACCEPT', '-w']

# Generated at 2022-06-25 02:52:22.881652
# Unit test for function check_present

# Generated at 2022-06-25 02:52:25.400541
# Unit test for function check_present
def test_check_present():
    var_1 = construct_rule("iptables-save")

    var_2 = "iptables-restore"

    var_3 = construct_rule("iptables-save")

    return var_0


# Generated at 2022-06-25 02:52:30.439256
# Unit test for function main
def test_main():
    check_initial_values()
    with patch.object(AnsibleModule, 'run_command', return_value=get_run_command_return_object()):
        with patch.object(AnsibleModule, 'get_bin_path', return_value='/usr/bin/iptables'):
            test_case_0()


# Generated at 2022-06-25 02:52:41.456247
# Unit test for function check_present
def test_check_present():
    var_1 = None