

# Generated at 2022-06-20 22:01:47.661273
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ALL', 'ACK', 'RST'],
        flags_set=['ACK', 'SYN', 'FIN']
    )
    flags = '--tcp-flags'
    append_tcp_flags(rule, param, flags)

    assert rule[0] == flags
    assert rule[1] == ','.join(param['flags'])
    assert rule[2] == ','.join(param['flags_set'])



# Generated at 2022-06-20 22:01:59.203568
# Unit test for function construct_rule

# Generated at 2022-06-20 22:02:06.372882
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'test'}) == None
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'PREROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'POSTROUTING'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FOOBAR'}) == None



# Generated at 2022-06-20 22:02:07.527717
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == 'iptables v1.6.1'


# Generated at 2022-06-20 22:02:19.683984
# Unit test for function main
def test_main():
    # Require imports for the AnsibleModule class
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    # Check mode doesn't modify system state
    for check_mode in [True, False]:
        module = AnsibleModule(argument_spec={
            'ip_version': dict(type=str, default='ipv4'),
        })
        module.check_mode = check_mode
        main()
        assert module.params['changed'] is True

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:02:29.246659
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments(
        '/sbin/iptables',
        '-I',
        dict(
            chain="INPUT",
            table="filter",
            source="8.8.8.8",
            jump="DROP",
            rule_num=1,
        )) == [
        '/sbin/iptables',
        '-t',
        'filter',
        '-I',
        'INPUT',
        '1',
        '-s',
        '8.8.8.8',
        '-j',
        'DROP',
    ]



# Generated at 2022-06-20 22:02:32.381777
# Unit test for function append_match
def test_append_match():
    rule = []
    match = 'state'
    append_match(rule, True, match)
    assert rule == ['-m', match]
    rule = []
    append_match(rule, False, match)
    assert rule == []


# Generated at 2022-06-20 22:02:34.968138
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, "match")
    assert rule == ["-m", "match"]



# Generated at 2022-06-20 22:02:38.056622
# Unit test for function get_chain_policy
def test_get_chain_policy():
    chain_policy = get_chain_policy(None, None, {'chain': 'INPUT', 'ip_version': 'ipv4'})
    print(chain_policy)


# Generated at 2022-06-20 22:02:42.372186
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(iptables_path, module, params) == cmd


# Generated at 2022-06-20 22:03:05.927437
# Unit test for function append_wait
def test_append_wait():
    rule = []

    # iptables < 1.4.20 does not support the --wait flag
    append_wait(rule, '6', '--wait')
    assert rule == []

    # iptables < 1.6.0 does not support the --wait flag with seconds specified
    append_wait(rule, '6s', '--wait')
    assert rule == []

    # iptables >= 1.6.0 supports the --wait flag with seconds specified
    append_wait(rule, '6s', '--wait')
    assert rule == ['--wait', '6s']



# Generated at 2022-06-20 22:03:13.696768
# Unit test for function set_chain_policy
def test_set_chain_policy():
    chain = 'TEST_CHAIN'
    module = AnsibleModule(
        argument_spec=dict(
            policy=dict(type='str', choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN'])
        )
    )
    params = dict(
        chain=chain,
        table='filter',
        policy='ACCEPT'
    )
    # Create the chain to be able to set the policy
    cmd = push_arguments('iptables', '-N', dict(chain=chain, table='filter'), make_rule=False)
    module.run_command(cmd, check_rc=True)
    set_chain_policy('iptables', module, params)
    # Check that the policy is set correctly

# Generated at 2022-06-20 22:03:17.997546
# Unit test for function remove_rule
def test_remove_rule():
    cmd = ['/sbin/iptables', '-t', 'filter', '-D', 'FORWARD', '-d', '10.0.0.1']
    assert remove_rule('/sbin/iptables', module, cmd) == cmd



# Generated at 2022-06-20 22:03:24.706029
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['test1','test2']
    flag = '--ctstate'
    assert(append_csv(rule, param, flag)) == ['--ctstate', 'test1,test2']
    assert(rule) == ['--ctstate', 'test1,test2']



# Generated at 2022-06-20 22:03:25.649690
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert True



# Generated at 2022-06-20 22:03:33.134578
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 22:03:40.568998
# Unit test for function append_csv
def test_append_csv():
    rule = ['iptables', '-w', '10']
    param = ['ESTABLISHED', 'RELATED']
    flag = '-m'
    append_csv(rule, param, flag)
    assert rule == ['iptables', '-w', '10', '-m', 'ESTABLISHED,RELATED']



# Generated at 2022-06-20 22:03:41.371567
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(iptables_path, module) == "1.6.0"



# Generated at 2022-06-20 22:03:53.397955
# Unit test for function push_arguments
def test_push_arguments():
    args = [
        'iptables',
        '-t', 'filter',
        '-A', 'INPUT',
        '-s', '192.168.1.1'
        ]
    params = {
        'table': 'filter',
        'action': 'append',
        'chain': 'INPUT',
        'source': '192.168.1.1',
        'in_interface': 'lo',
        'jump': 'ACCEPT',
        'ip_version': 'ipv4',
        'comment': 'test_comment',
        'set_counters': '5:5',
        'conntrack': 'match',
        'ctstate': ['ESTABLISHED', 'RELATED'],
        'wait': '1',
    }

# Generated at 2022-06-20 22:03:58.992256
# Unit test for function append_param
def test_append_param():
    rule = []
    param = '80'
    flag = '--destination-port'
    result = [flag, param]
    append_param(rule, param, flag, False)
    assert rule == result
    rule = []
    param = None
    flag = '--destination-port'
    result = []
    append_param(rule, param, flag, False)
    assert rule == result
    rule = []
    param = '!80'
    flag = '--destination-port'
    result = ['!', flag, '80']
    append_param(rule, param, flag, False)
    assert rule == result
    rule = []
    param = ['80', '8080']
    flag = '--destination-port'
    result = [flag, '80', flag, '8080']
    append

# Generated at 2022-06-20 22:04:13.209853
# Unit test for function append_match
def test_append_match():
    inputs = [False, True]
    expected = [[], ['-m', 'match']]
    for i in range(len(inputs)):
        rule = []
        append_match(rule, inputs[i], 'match')
        assert rule == expected[i]


# Generated at 2022-06-20 22:04:23.347260
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='2001:db8:0:42::1',
        match='conntrack',
        ctstate='ESTABLISHED,RELATED',
        jump='ACCEPT',
        ip_version='ipv6',
        table='filter',
        chain='INPUT',
    )
    rule = construct_rule(params)
    assert rule == ['-w', '-p', 'tcp', '-s', '2001:db8:0:42::1', '-m', 'conntrack',
                    '--ctstate', 'ESTABLISHED,RELATED', '-j', 'ACCEPT']
    params['ctstate'] = None
    params['match'] = 'state'

# Generated at 2022-06-20 22:04:25.223167
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, 'ACCEPT', 'ACCEPT')
    assert rule == ['-j', 'ACCEPT']
    rule = []
    append_jump(rule, '', 'ACCEPT')
    assert rule == []


# Generated at 2022-06-20 22:04:27.869256
# Unit test for function flush_table
def test_flush_table():
    module = MockModule({'table': 'filter', 'chain': 'INPUT'})
    params = dict()
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    expected = ['iptables', '-t', 'filter', '-F', 'INPUT']
    result = flush_table('iptables', module, params)
    assert result == expected



# Generated at 2022-06-20 22:04:32.666790
# Unit test for function push_arguments

# Generated at 2022-06-20 22:04:43.786618
# Unit test for function main

# Generated at 2022-06-20 22:04:49.967873
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'param'
    jump = 'jump'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'jump']


# Generated at 2022-06-20 22:04:54.823932
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', None, { 'chain': 'INPUT', 'policy': 'ACCEPT' }) == 'iptables -P INPUT ACCEPT'
    assert set_chain_policy('iptables', None, { 'chain': 'INPUT', 'policy': 'DROP' }) == 'iptables -P INPUT DROP'
    assert set_chain_policy('iptables', None, { 'chain': 'INPUT', 'policy': 'QUEUE' }) == 'iptables -P INPUT QUEUE'
    assert set_chain_policy('iptables', None, { 'chain': 'INPUT', 'policy': 'RETURN' }) == 'iptables -P INPUT RETURN'



# Generated at 2022-06-20 22:04:59.697034
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == [ 'iptables', '-t nat', '-A PREROUTING', '-p tcp', '-s 192.168.1.100', '-d 192.168.1.0/24', '-m multiport', '--dports', '80', '8-10', '-j REDIRECT', '--to-ports', '8080']



# Generated at 2022-06-20 22:05:07.531355
# Unit test for function append_jump
def test_append_jump():
    """Tests append_jump"""
    input_data = dict(
        rule=['iptables', '-t', 'filter', '-A', 'OUTPUT', '-p', 'tcp', '-m', 'tcp', '--dport', '8080', '-m', 'comment', '--comment', 'Redirect web traffic to port 8600', '-j', 'REDIRECT', '--to-ports', '8600'],
        param='ACCEPT',
        jump='ACCEPT',
    )

# Generated at 2022-06-20 22:06:11.407303
# Unit test for function flush_table
def test_flush_table():
    params = { 'chain': 'INPUT', 'table': 'filter' }
    flush_table('iptables', None, params)
    assert True



# Generated at 2022-06-20 22:06:16.304306
# Unit test for function append_match
def test_append_match():
    rule = [1, 2, 3, 4]
    param = 'hello'
    match = 'bye'
    append_match(rule, param, match)
    assert rule == [1, 2, 3, 4, '-m', 'bye']


# Generated at 2022-06-20 22:06:20.469025
# Unit test for function flush_table
def test_flush_table():
    iptables_path = 'iptables'
    module = 'test'
    params = dict(chain='INPUT', table='mangle')
    flush_table(iptables_path, module, params)
    cmd = ['iptables', '-t', 'mangle', '-F', 'INPUT']
    print(cmd)

# Generated at 2022-06-20 22:06:27.601755
# Unit test for function construct_rule

# Generated at 2022-06-20 22:06:36.415548
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, '1:65535', '--destination-port', False)
    assert len(rule) == 2
    assert rule[0] == '--destination-port'
    assert rule[1] == '1:65535'
    rule = []
    append_param(rule, ['1:65535', '1:65535'], '--destination-port', True)
    assert len(rule) == 4
    assert rule[0] == '--destination-port'
    assert rule[1] == '1:65535'
    assert rule[2] == '--destination-port'
    assert rule[3] == '1:65535'
    rule = []
    append_param(rule, '!1:65535', '--destination-port', False)

# Generated at 2022-06-20 22:06:39.720622
# Unit test for function append_jump
def test_append_jump():
  assert append_jump(['-j', 'jump']) == ['-j', 'jump']


# Generated at 2022-06-20 22:06:44.524700
# Unit test for function append_param
def test_append_param():
    rule = []
    param = ['foo', '!bar', '!baz']
    append_param(rule, param, 'dst', True)
    assert rule == ['dst', 'foo', '!dst', 'bar', '!dst', 'baz']



# Generated at 2022-06-20 22:06:48.240786
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        chain='INPUT',
        source='192.168.1.2',
        protocol='tcp',
        jump='DROP',
        rule_num='1',
        table='filter',
        ip_version='ipv4'
    )

    iptables_path = 'iptables'
    cmd = push_arguments(iptables_path, '-I', params)
    print(cmd)
#test_insert_rule()



# Generated at 2022-06-20 22:06:49.518889
# Unit test for function append_wait
def test_append_wait():
    assert append_wait([], '2', '--wait') == ['--wait', '2']


# Generated at 2022-06-20 22:06:51.035659
# Unit test for function append_jump
def test_append_jump():
    rule = []
    jump = 'ACCEPT'
    append_jump(rule, '', jump)
    assert rule == []


# Generated at 2022-06-20 22:08:17.736565
# Unit test for function push_arguments
def test_push_arguments():
    assert (push_arguments('/sbin/iptables', '-A', dict(table='filter', chain='INPUT', destination_ports=['22', '23'], jump='ACCEPT')) ==
            ['/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-m', 'multiport', '--dports', '22,23', '-j', 'ACCEPT'])



# Generated at 2022-06-20 22:08:32.293888
# Unit test for function remove_rule
def test_remove_rule():
    # Expected command in form of a list.
    tested_command = ['iptables', '-t', 'nat', '-D', 'PREROUTING', '-p', 'tcp', '-m', 'multiport', '--dports', '80,443,8081:8083', '-j', 'ACCEPT']
    # Params that are given to function.
    tested_params = {'action': 'remove', 'chain': 'PREROUTING', 'destination_ports': ['80', '443', '8081:8083'], 'jump': 'ACCEPT', 'protocol': 'tcp', 'table': 'nat'}
    # Object that are used to simulate module in testing environment.
    test_obj = MagicMock()
    # Function generate the command to be tested.

# Generated at 2022-06-20 22:08:42.149619
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5'
    )
    assert(push_arguments('iptables', '-I', params) == [
        'iptables',
        '-t',
        'filter',
        '-I',
        'INPUT',
        '5',
        '-w',
        '-p',
        'tcp',
        '--dport',
        '8080',
        '-j',
        'ACCEPT'
    ])



# Generated at 2022-06-20 22:08:45.469505
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'DEFAULT'
    jump = 'DEFAULT'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'DEFAULT']


# Generated at 2022-06-20 22:08:48.285062
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {
        'chain': 'INPUT',
        'table': 'nat'
    }
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)



# Generated at 2022-06-20 22:08:55.507955
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    print(rule)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    print(rule)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    print(rule)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', False)
    print(rule)
    assert rule == []



# Generated at 2022-06-20 22:09:05.377182
# Unit test for function check_present

# Generated at 2022-06-20 22:09:09.165293
# Unit test for function get_iptables_version
def test_get_iptables_version():
    class TestModule(object):
        def run_command(self, command, check_rc=True):
            return (0, 'iptables v1.4.4', None)
    module = TestModule()
    assert get_iptables_version('/usr/bin/iptables', module) == '1.4.4'
    return



# Generated at 2022-06-20 22:09:17.198816
# Unit test for function remove_rule
def test_remove_rule():
    module = Mock()
    module.run_command = Mock()
    params = {
        'chain': 'FORWARD',
        'table': 'mangle',
        'protocol': 'tcp',
        'jump': None,
        'destination_port': 35027,
        'ip_version': 'ipv4',
        'wait': '5'
    }
    rule = ['-w', '5', '-p', 'tcp', '--dport', '35027']
    remove_rule('iptables', module, params)
    assert module.run_command.call_args[0][0] == rule



# Generated at 2022-06-20 22:09:19.598683
# Unit test for function main
def test_main():
    request = {
        "params":{
            "comment":"test"
        },
        "check_mode":False
    }

    main(request)
    assert 1==1


# Generated at 2022-06-20 22:10:58.800521
# Unit test for function append_match
def test_append_match():
    rule = []
    rule_exp = ["-m","match"]
    append_match(rule, True, "match")
    assert rule == rule_exp
    rule = ["-p","tcp"]
    append_match(rule, True, "match")
    assert rule == rule_exp + ["-p","tcp"]
    rule = []
    append_match(rule, False, "match")
    assert rule == []


# Generated at 2022-06-20 22:11:03.377669
# Unit test for function insert_rule
def test_insert_rule():
    inserted_rule = push_arguments('iptables','-I',{"table": "nat","chain": "PREROUTING","rule_num": "5","protocol": "tcp","destination_port": "80","jump": "REDIRECT","comment": "Redirect web traffic to port 8600","to_ports": "8600"})
    assert inserted_rule == ['iptables','-t','nat','-I','PREROUTING','5','-p','tcp','--destination-port','80','-j','REDIRECT','--comment','Redirect web traffic to port 8600','--to-ports','8600']
    #assert inserted_rule != ['iptables','-t','nat','-I','PREROUTING','6','-p','tcp','--destination-port','80','-j','REDIRECT','--comment','Red

# Generated at 2022-06-20 22:11:06.226893
# Unit test for function push_arguments
def test_push_arguments():
    """
        Verify that the arguments push the correct data
    """
    params = dict(
        chain='INPUT',
        jump='DROP',
        protocol='tcp',
        destination='8.8.8.8',
        destination_port='80',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '-d', '8.8.8.8', '--dport', '80', '-j', 'DROP']



# Generated at 2022-06-20 22:11:13.990730
# Unit test for function append_param
def test_append_param():
    rule = []
    param = ["!foo", "!bar"]
    assert append_param(rule, param, "--baz", True) == rule.extend(['--baz', '!foo', '--baz', '!bar'])
    rule = []
    param = "foo"
    assert append_param(rule, param, "--baz", False) == rule.extend(['--baz', 'foo'])
    rule = []
    param = "!foo"
    assert append_param(rule, param, "--baz", False) == rule.extend(['!', '--baz', 'foo'])

