

# Generated at 2022-06-20 22:01:55.205693
# Unit test for function construct_rule
def test_construct_rule():
    test_params = dict(
        source = '192.168.1.0/24',
        destination = '192.168.0.0/24',
        protocol = 'tcp',
        jump = 'ACCEPT',
        out_interface= 'eth0',
        match = ['state', 'iprange'],
        tcp_flags= dict(
        flags='ALL',
        flags_set= ['ACK', 'RST', 'SYN', 'FIN']
        ),
        destination_port = '8080',
        destination_ports = ['80', '443', '8081:8083'],
        limit= '10/minute',
        limit_burst= '20',
    )

# Generated at 2022-06-20 22:02:05.988819
# Unit test for function remove_rule
def test_remove_rule():
    command = ['iptables', '-t', 'nat', '-D', 'PREROUTING',
               '-p', 'tcp', '-d', '127.0.0.1', '--destination-port',
               '872', '-j', 'ACCEPT', '-m', 'comment', '--comment',
               'Remove test rule']
    assert command == remove_rule('iptables', 'module',
        {
            'action': 'remove',
            'chain': 'PREROUTING',
            'comment': 'Remove test rule',
            'destination': '127.0.0.1',
            'destination_port': '872',
            'jump': 'ACCEPT',
            'protocol': 'tcp',
            'table': 'nat',
        })




# Generated at 2022-06-20 22:02:16.037898
# Unit test for function construct_rule

# Generated at 2022-06-20 22:02:26.810020
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['SYN', 'ACK'], flags_set=['FIN', 'RST'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'SYN,ACK', 'FIN,RST']
    param = dict(flags=['SYN', 'ACK'], flags_set=['FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'SYN,ACK', 'FIN,RST', '--tcp-flags', 'SYN,ACK', 'FIN']


# Generated at 2022-06-20 22:02:33.098839
# Unit test for function append_wait
def test_append_wait():
    '''
    Tests for append_wait
    '''
    # rule is list and should append param and flag
    rule = []
    param = '2'
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule == ['--wait', '2']
    # rule is list, but should not append param and flag
    # param is None
    rule = []
    param = None
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule == []


# Generated at 2022-06-20 22:02:42.889045
# Unit test for function get_iptables_version
def test_get_iptables_version():
    import sys
    import tempfile
    import textwrap
    import subprocess
    import os
    if os.name == 'nt':
        import ctypes
        SEM_NOGPFAULTERRORBOX = 0x0002 # From MSDN
        ctypes.windll.kernel32.SetErrorMode(SEM_NOGPFAULTERRORBOX);
        CREATE_NO_WINDOW = 0x08000000    # From Windows API
        DETACHED_PROCESS = 0x00000008
    iptables_path = 'iptables'

# Generated at 2022-06-20 22:02:48.044302
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['INVALID', 'NEW']
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert rule == ['--ctstate', 'INVALID,NEW']



# Generated at 2022-06-20 22:02:52.364884
# Unit test for function append_jump
def test_append_jump():
    rule = []
    jump = 'DROP'
    append_jump(rule, jump, jump)
    assert rule == ['-j', 'DROP']



# Generated at 2022-06-20 22:03:07.030789
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, None, 'test_flag', False)
    assert len(rule) == 0

    param = 'test_param'
    append_param(rule, param, 'test_flag', False)
    assert rule == ['test_flag', 'test_param']

    param = '!test_param'
    append_param(rule, param, 'test_flag', False)
    assert rule == ['test_flag', 'test_param']

    rule = []
    append_param(rule, param, 'test_flag', True)
    assert rule == ['!', 'test_flag', 'test_param']

    params = ['test_param', '!test_param']
    rule = []
    append_param(rule, params, 'test_flag', True)

# Generated at 2022-06-20 22:03:08.575427
# Unit test for function get_iptables_version
def test_get_iptables_version():
    rc, out, err = module.run_command([iptables_path, '--version'])
    assert rc == 0



# Generated at 2022-06-20 22:03:24.336189
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'DROP'
    jump = 'DROP'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'DROP']



# Generated at 2022-06-20 22:03:32.124427
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = "/sbin/iptables"
    module = "dummy"
    params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4'
    )
    assert get_chain_policy(iptables_path, module, params) == 'ACCEPT'
    params = dict(
        table='filter',
        chain='FORWARD',
        ip_version='ipv4'
    )
    assert get_chain_policy(iptables_path, module, params) == 'ACCEPT'
    params = dict(
        table='filter',
        chain='OUTPUT',
        ip_version='ipv4'
    )
    assert get_chain_policy(iptables_path, module, params) == 'ACCEPT'


# Generated at 2022-06-20 22:03:33.214371
# Unit test for function append_jump
def test_append_jump():
    rule = [ 'iptables' ]
    append_jump(rule, True, 'ACCEPT')
    assert rule == [ 'iptables', '-j', 'ACCEPT']


# Generated at 2022-06-20 22:03:34.282483
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, 'ACCEPT', 'ACCEPT')
    assert rule == ['-j', 'ACCEPT']


# Generated at 2022-06-20 22:03:50.192239
# Unit test for function main

# Generated at 2022-06-20 22:04:02.137436
# Unit test for function construct_rule
def test_construct_rule():
    module = AnsibleModule({})
    assert construct_rule({
        'ip_version': 'ipv4',
        'protocol': 'tcp',
        'src_range': '0.0.0.0-255.255.255.255',
        'dst_range': '2.2.2.2-5.5.5.5',
        'jump': 'DROP',
        'match': ['iprange']
    }) == [ '-p', 'tcp', '-m', 'iprange', '--src-range', '0.0.0.0-255.255.255.255', '--dst-range', '2.2.2.2-5.5.5.5', '-j', 'DROP' ]


# Generated at 2022-06-20 22:04:10.395500
# Unit test for function insert_rule
def test_insert_rule():
    # Test the function
    module = AnsibleModule
    iptables_path = '/usr/sbin/iptables'
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num='1',
        protocol='tcp',
        destination_port='8080')
    insert_rule(iptables_path, module, params)



# Generated at 2022-06-20 22:04:20.287231
# Unit test for function remove_rule
def test_remove_rule():
    ip4tables_path = '/usr/sbin/iptables'
    params = {
        "table" : "filter",
        "chain":"INPUT"
    }
    cmd_answer = ['/usr/sbin/iptables', '-t','filter','-D','INPUT']
    assert remove_rule(ip4tables_path, None, params) == cmd_answer
    ip6tables_path = '/usr/sbin/ip6tables'
    params = {
        "table" : "filter",
        "chain":"INPUT"
    }
    cmd_answer = ['/usr/sbin/ip6tables', '-t','filter','-D','INPUT']
    assert remove_rule(ip6tables_path, None, params) == cmd_answer



# Generated at 2022-06-20 22:04:29.853152
# Unit test for function check_present
def test_check_present():
    from ansible.modules.network.iptables import Iptables
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict(
            chain = dict(required=True),
            protocol = dict(default='all'),
            jump = dict(default=None),
            src_range = dict(default=None),
        )
    )
    module.fail_json = lambda x, **y: x
    params = module.params
    params['ip_version'] = 'ipv4'
    params['table'] = 'filter'
    params['state'] = 'present'
    obj = Iptables(params)
    assert not check_present(obj.iptables_path, obj, params)



# Generated at 2022-06-20 22:04:33.104318
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(argument_spec={})
    params = dict(table='filter', chain='INPUT', wait=None, ip_version='ipv4')
    iptables_path = BINS[params['ip_version']]

    assert get_chain_policy(iptables_path, module, params) == 'ACCEPT'



# Generated at 2022-06-20 22:04:48.003080
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {}) is None



# Generated at 2022-06-20 22:04:55.729910
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path="/sbin/iptables"
    module=None
    params=dict()
    params['table']="filter"
    params['chain']="INPUT"
    params['protocol']="tcp"
    params['destination_port']="80"
    params['jump']="DROP"
    params['comment']="This rule is added by testing module"
    return remove_rule(iptables_path,module,params)



# Generated at 2022-06-20 22:05:03.098210
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict()
    flag = '--tcp-flags'
    param_flags = 'ABCD'
    param_flags_set = 'AB'
    param['flags'] = list(param_flags)
    param['flags_set'] = list(param_flags_set)
    append_tcp_flags(rule, param, flag)
    assert rule[-1] == flag
    assert rule[-2] == ','.join(param['flags_set'])
    assert rule[-3] == ','.join(param['flags'])



# Generated at 2022-06-20 22:05:06.888591
# Unit test for function flush_table
def test_flush_table():
    params =  dict(
        table='filter',
        chain='INPUT',
    )
    assert flush_table('iptables', params) == \
        'iptables -t filter -F INPUT'


# Generated at 2022-06-20 22:05:12.865304
# Unit test for function append_wait
def test_append_wait():
    rule = [BINS['ipv4'], '-A', 'INPUT']
    wait = '2'
    append_wait(rule, wait, '--wait')
    assert rule[-1] == wait


# Generated at 2022-06-20 22:05:16.849500
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = "10"
    flag = "--wait"
    append_wait(rule,param,flag)
    assert rule == ["--wait", "10"]



# Generated at 2022-06-20 22:05:21.780951
# Unit test for function construct_rule
def test_construct_rule():
    def test(params, expected_rule, test_name=None):
        test_name = test_name or "test_construct_rule"
        result = construct_rule(params)
        assert result == expected_rule, (
            "Expected rule '{0}' but was '{1}' for params {2}".format(
                expected_rule, result, params))


# Generated at 2022-06-20 22:05:37.583295
# Unit test for function check_present
def test_check_present():
    import os
    import tempfile

    iptables_path = os.path.join(tempfile.gettempdir(), 'iptables')

# Generated at 2022-06-20 22:05:43.064287
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, '192.168.1.100-192.168.1.199', '--src-range', False)
    assert rule == ['--src-range', '192.168.1.100-192.168.1.199']

    rule = []
    append_param(rule, '10.0.0.1-10.0.0.50', '--dst-range', False)
    assert rule == ['--dst-range', '10.0.0.1-10.0.0.50']

    rule = []
    append_param(rule, ['192.168.1.100-192.168.1.199', '10.0.0.1-10.0.0.50'], '--src-range', True)

# Generated at 2022-06-20 22:05:47.185433
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '/usr/sbin/iptables', params)
    assert check_present('iptables', 'iptables', params)
    assert check_present('ip6tables', 'ip6tables', params)



# Generated at 2022-06-20 22:06:01.456033
# Unit test for function remove_rule
def test_remove_rule():
    remove_rule('/sbin/iptables', None, {'table': 'filter', 'chain': 'INPUT'})


# Generated at 2022-06-20 22:06:13.303281
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ALL'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN']
    )
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']

    rule = []
    param = dict(
        flags=['ACK', 'SYN'],
        flags_set=['FIN']
    )
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,SYN', 'FIN']

    rule = []
    param = dict(
        flags=[],
        flags_set=[]
    )

# Generated at 2022-06-20 22:06:22.967280
# Unit test for function main

# Generated at 2022-06-20 22:06:30.422719
# Unit test for function construct_rule

# Generated at 2022-06-20 22:06:35.005569
# Unit test for function flush_table
def test_flush_table():
    iptables_path = 'iptables'
    module = AnsibleModule()
    params = dict(
        table='filter',
        chain='INPUT'
    )
    return flush_table(iptables_path, module, params)


# Generated at 2022-06-20 22:06:36.060903
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version("iptables", module) == IPTABLES_WAIT_SUPPORT_ADDED
# End of test



# Generated at 2022-06-20 22:06:40.275682
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == 'iptables -t filter -A INPUT -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT'



# Generated at 2022-06-20 22:06:44.210214
# Unit test for function append_csv
def test_append_csv():
    params = ['new', 'established', 'related']
    rule = ['--ctstate']
    append_csv(rule, params, '')
    assert rule == ['--ctstate', 'new,established,related']



# Generated at 2022-06-20 22:06:49.905908
# Unit test for function insert_rule
def test_insert_rule():
  module = None
  params = {
      'chain': 'INPUT',
      'protocol': 'tcp',
      'destination_port': 8080,
      'jump': 'ACCEPT',
      'action': 'insert',
      'rule_num': 5,
      'in_interface': 'eth0',
      'out_interface': 'eth1',
      'table': 'mangle',
      'wait': 1,
      'ip_version': 'ipv4',
      'state': 'present'
  }
  iptables_path = "/usr/bin/iptables"

# Generated at 2022-06-20 22:07:04.469582
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(argument_spec=dict())
    params = {
        'table': 'nat',
        'chain': 'PREROUTING',
        'action': 'append',
        'rule_num': '5',
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'REDIRECT',
        'to_ports': '8600',
    }
    cmd = push_arguments('iptables', module, params)
    assert cmd == [
        'iptables', '-t', 'nat', '-A', 'PREROUTING', '-p', 'tcp',
        '--dport', '80', '-j', 'REDIRECT', '--to-ports', '8600'
    ]



# Generated at 2022-06-20 22:07:21.449536
# Unit test for function check_present
def test_check_present():
    """
    Test check_present()
    """
    assert check_present('iptables', None, {'chain': 'INPUT', 'table': 'filter'})
    assert not check_present('iptables', None, {'chain': 'INPUT', 'table': 'nat'})


# Generated at 2022-06-20 22:07:26.510983
# Unit test for function append_param
def test_append_param():
    rule_list = []
    rule_var = "this is the flag"
    rule_list.append(rule_var)
    flag_var = "--this-is-the-flag"
    input_list = ["--this-is-the-flag", "this is the flag"]
    input_list2 = ["!this is the flag"]
    assert append_param(rule_list, rule_var, flag_var, False) == input_list
    assert append_param(rule_list, input_list2[0], flag_var, False) == ["--this-is-the-flag", "!this is the flag"]
    rule_list = []
    rule_var = ["this is the flag", "this is the second flag"]
    flag_var = "--this-is-the-flag"

# Generated at 2022-06-20 22:07:29.351890
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['a', 'b', 'c'], '--my-flag')
    assert rule == ['--my-flag', 'a,b,c']
    rule = []
    append_csv(rule, None, '--my-flag')
    assert rule == []




# Generated at 2022-06-20 22:07:38.815051
# Unit test for function push_arguments

# Generated at 2022-06-20 22:07:41.432784
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = push_arguments('iptables', '-P', {
        'chain': 'INPUT',
        'policy': 'DROP',
    }, make_rule=False)
    cmd.append('DROP')
    assert cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']

# Generated at 2022-06-20 22:07:53.356144
# Unit test for function construct_rule
def test_construct_rule():
    # Rule without set_counters that doesn't use match
    rule = construct_rule(dict(
        ip_version='ipv4',
        in_interface='eth0',
        source_port=None,
        protocol='tcp',
        destination_port='443',
        ctstate=None,
        comment='Accept new SSH connections.',
        jump='ACCEPT'
    ))
    assert rule == ['-A', 'INPUT', '-i', 'eth0', '-p', 'tcp', '--dport', '443',
                    '-m', 'comment', '--comment', 'Accept new SSH connections.', '-j', 'ACCEPT']
    # Rule with set_counters and uses match

# Generated at 2022-06-20 22:08:00.928724
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule =[]
    param = {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['SYN', 'FIN']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'SYN,FIN']



# Generated at 2022-06-20 22:08:08.307776
# Unit test for function push_arguments
def test_push_arguments():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.iptables import push_arguments

# Generated at 2022-06-20 22:08:10.356157
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--ip-sport', False)
    assert rule == ['--ip-sport']
    rule = []
    append_match_flag(rule, 'negate', '--ip-sport', True)
    assert rule == ['!', '--ip-sport']



# Generated at 2022-06-20 22:08:12.653140
# Unit test for function append_match
def test_append_match():
    rules = []
    param = True
    match = 'match'
    append_match(rules, param, match)
    assert rules == ['-m', match]
    rules = []
    param = False
    append_match(rules, param, match)
    assert rules == []


# Generated at 2022-06-20 22:08:29.715774
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert(set_chain_policy('iptables',module,params) == [])



# Generated at 2022-06-20 22:08:31.416079
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = [];
    append_match_flag(rule, 'match','--syn', True);
    append_match_flag(rule, 'negate','--syn', True);
    assert rule == [
        '--syn',
        '!', '--syn'
      ]



# Generated at 2022-06-20 22:08:42.869350
# Unit test for function push_arguments

# Generated at 2022-06-20 22:08:46.657798
# Unit test for function set_chain_policy
def test_set_chain_policy():
    param_dict = {
        'iptables_path': '/usr/sbin/iptables',
        'module': 'AnsibleModule',
        'chain': 'INPUT',
        'policy': 'DROP'
    }
    output_str = ' '.join(push_arguments('/usr/sbin/iptables', '-P', param_dict, make_rule=False))
    append_str = '-P INPUT DROP'
    assert output_str == append_str


# Generated at 2022-06-20 22:08:57.426473
# Unit test for function append_rule
def test_append_rule():
    import mock
    import sys
    ansible_module = mock.Mock(name='AnsibleModule')
    ansible_module.check_mode = False
    ansible_module.run_command = mock.MagicMock(return_value=(0, 'fake result', ''))
    sys.modules['ansible.module_utils.basic'] = mock.Mock(return_value=ansible_module)
    import iptables
    test_params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'ip_version': 'ipv4',
    }
    iptables.append_rule('iptables', ansible_module, test_params)

# Generated at 2022-06-20 22:09:04.783030
# Unit test for function insert_rule
def test_insert_rule():
    params = {
        "chain": "INPUT",
        "protocol": "",
        "destination_port":"8080",
        "jump": "ACCEPT",
        "action": "insert",
        "rule_num": "5"
    }
    cmd = [iptables_path]
    cmd.extend(["-t", params['table']])
    cmd.extend(["-I", params['chain']])
    cmd.extend([params['rule_num']])
    expected = ["-t", "filter", "-I", "INPUT", "5", "-p", "-dport", "8080", "-j", "ACCEPT"]
    return expected == cmd



# Generated at 2022-06-20 22:09:09.481665
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/bin/iptables'
    module = '...'
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        source='8.8.8.8',
        jump='DROP',
        rule_num='1',
        )
    assert append_rule(iptables_path, module, params) == ['/bin/iptables', '-t', 'filter', '-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP']


# Generated at 2022-06-20 22:09:11.265038
# Unit test for function append_csv
def test_append_csv():
    assert append_csv(['foo'], ['bar', 'baz'], '--bar') == ['foo', '--bar', 'bar,baz']



# Generated at 2022-06-20 22:09:16.302456
# Unit test for function main
def test_main():
    ip_version = 'ipv4'

# Generated at 2022-06-20 22:09:23.363911
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    # Ugly test, no time.
    rule = []
    param = ""
    flag = ""
    append_tcp_flags(rule, param, flag)
    assert rule == []

    rule = []
    param = dict()
    flag = ""
    append_tcp_flags(rule, param, flag)
    assert rule == []

    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN']
    )
    flag = ""
    append_tcp_flags(rule, param, flag)
    assert rule == []

    rule = []
    param = dict(
        flags_set=['ACK', 'RST', 'SYN', 'FIN']
    )
    flag = ""
    append_tcp_flags(rule, param, flag)

# Generated at 2022-06-20 22:09:53.246574
# Unit test for function flush_table
def test_flush_table():
    assert flush_table("iptables", "module", {"table":"filter"}) == [iptables, "-F", "filter"]

# Generated at 2022-06-20 22:10:02.626518
# Unit test for function main
def test_main():
    # Get arguments
    def get_arg(key):
        return module.params.get(key, None)

    # Set exit status
    def exit_json(*args, **kwargs):
        return_args = args[0]
        return_args['invocation'] = mock.call(**kwargs)

    # Set fail status
    def fail_json(*args, **kwargs):
        return_args = args[0]
        return_args['failed'] = True
        return_args['msg'] = kwargs['msg']
        return_args['invocation'] = mock.call(**kwargs)

    # Get option value
    def get_bin_path(bin_name, required):
        return '/usr/bin/%s' % bin_name

    # Check if IPtables is present

# Generated at 2022-06-20 22:10:08.914338
# Unit test for function append_csv
def test_append_csv():
    assert append_csv([], ['NEW'], '--ctstate') == ['--ctstate', 'NEW']
    assert append_csv([], ['NEW', 'RELATED'], '--ctstate') == ['--ctstate', 'NEW,RELATED']
    assert append_csv([], None, '--ctstate') == []



# Generated at 2022-06-20 22:10:13.743595
# Unit test for function append_param
def test_append_param():
    assert append_param(['a.out'], '80', '-p', False) == ['a.out', '-p', '80']
    assert append_param(['a.out'], '80', '-p', False) != ['a.out', '-p']


# Generated at 2022-06-20 22:10:18.743290
# Unit test for function append_match
def test_append_match():
    rule_test = list()
    append_match(rule_test, True, 'test')
    assert rule_test == ['-m', 'test']
    rule_test = list()
    append_match(rule_test, False, 'test')
    assert rule_test == list()



# Generated at 2022-06-20 22:10:24.683428
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})
    module.check_mode = True
    for ip_version in ['ipv4', 'ipv6']:
        for action, table in [['append', 'filter'], ['insert', 'nat']]:
            changed, result = flush_table(
                BINS[ip_version], module, {
                    'table': table,
                    'chain': 'INPUT'})
            assert changed is True
            assert result['commands'] == [
                [BINS[ip_version], '-t', table, '-F', 'INPUT']]

# Generated at 2022-06-20 22:10:27.071845
# Unit test for function append_jump
def test_append_jump():
    rule = []
    test_input = 'DROP'
    append_jump(rule, test_input, 'DROP')
    assert(rule == ['-j', 'DROP'])


# Generated at 2022-06-20 22:10:34.669115
# Unit test for function append_match
def test_append_match():
    # "ipsec-policy" is a printable match name
    assert append_match(['iptables'], True, 'ipsec-policy') == ['iptables', '-m', 'ipsec-policy']
    # "physdev" is a printable match name
    assert append_match(['iptables'], True, 'physdev') == ['iptables', '-m', 'physdev']
    assert append_match(['iptables'], False, 'physdev') == ['iptables']



# Generated at 2022-06-20 22:10:38.047256
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(table="filter", chain="INPUT", policy="ACCEPT")
    return set_chain_policy("iptables", None, params)



# Generated at 2022-06-20 22:10:49.459730
# Unit test for function insert_rule
def test_insert_rule():
    mock_iptables_path = 'mock_iptables_path'