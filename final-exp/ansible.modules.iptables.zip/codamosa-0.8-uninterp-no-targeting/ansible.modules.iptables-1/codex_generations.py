

# Generated at 2022-06-20 22:01:44.855427
# Unit test for function append_jump
def test_append_jump():
    rule =[]
    param= 'test'
    jump = 'test'
    append_jump(rule,param,jump)
    assert rule == ['-j','test']


# Generated at 2022-06-20 22:01:46.217118
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, 'ACCEPT', 'ACCEPT')
    assert rule[1] == '-j' and rule[2] == 'ACCEPT'


# Generated at 2022-06-20 22:01:47.556622
# Unit test for function append_match
def test_append_match():
    assert append_match(['-m', 'comment', '-j', 'ACCEPT'], True, 'comment') == ['-m', 'comment', '-j', 'ACCEPT']


# Generated at 2022-06-20 22:01:48.858090
# Unit test for function append_wait
def test_append_wait():
    rule = []
    wait_value = '10'
    append_wait(rule, wait_value, '-w')
    assert rule == ['-w', wait_value]



# Generated at 2022-06-20 22:01:52.981021
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = ['/sbin/iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']
    assert set_chain_policy('/sbin/iptables',
                            AnsibleModule(argument_spec={}, supports_check_mode=False),
                            dict(table='filter', chain='INPUT', policy='DROP')) == 0
    assert cmd == set_chain_policy('/sbin/iptables',
                                   AnsibleModule(argument_spec={}, supports_check_mode=False),
                                   dict(table='filter', chain='INPUT', policy='DROP'))



# Generated at 2022-06-20 22:01:56.453365
# Unit test for function append_match_flag
def test_append_match_flag(): # pragma: no cover
    rule = []
    append_match_flag(rule, 'match', '--match', False)
    assert '--match' in rule
    append_match_flag(rule, 'match', '--match', True)
    assert '--match' in rule
    append_match_flag(rule, 'negate', '--match', True)
    assert '--match' not in rule
    append_match_flag(rule, None, '--match', False)
    append_match_flag(rule, None, '--match', True)
    assert len(rule) == 0



# Generated at 2022-06-20 22:02:02.803804
# Unit test for function main

# Generated at 2022-06-20 22:02:03.808953
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('/sbin/iptables', module, params) == None



# Generated at 2022-06-20 22:02:09.576884
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils import basic
    import sys
    cm = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    cm.check_mode = False
    sys.modules['ansible.module_utils.basic'] = basic
    sys.modules['ansible.module_utils.basic'].AnsibleModule = basic.AnsibleModule
    global IPTABLES_WAIT_WITH_SECONDS_SUPPORT_ADDED
    global BINS
    global ICMP_TYPE_OPTIONS
    global IPTABLES_WAIT_SUPPORT_ADDED
    IPTABLES_WAIT_WITH_SECONDS_SUPPORT_ADDED = '1.7.0'

# Generated at 2022-06-20 22:02:15.526395
# Unit test for function append_match
def test_append_match():
    r = [ ]
    append_match(r, 'match', 'match name')
    assert r == [ '-m', 'match name' ]
    r = [ ]
    append_match(r, None, 'match name')
    assert r == [ ]


# Generated at 2022-06-20 22:02:38.566207
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, ['string1', 'string2'], '-m', True)
    assert rule == [ '-m', 'string1', '-m', 'string2' ]
    rule = []
    append_param(rule, ['string1', '!string2'], '-m', True)
    assert rule == [ '-m', 'string1', '!', '-m', 'string2']
    rule = []
    append_param(rule, [None, '!string2'], '-m', True)
    assert rule == [ '!', '-m', 'string2']
    rule = []
    append_param(rule, ['!string1', None], '-m', True)
    assert rule == [ '!', '-m', 'string1' ]
    rule = []


# Generated at 2022-06-20 22:02:48.654021
# Unit test for function insert_rule
def test_insert_rule():
    test_params = dict(
        state='present',
        chain='INPUT',
        rule_num=5,
        destination_port=8080,
        protocol='tcp',
        jump='ACCEPT',
        ip_version='ipv4',
    )
    test_cmd = push_arguments('iptables', '-I', test_params)

# Generated at 2022-06-20 22:02:54.891772
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(iptables_path=dict(type='str'), params=dict(type='dict'), ))
    assert_equal(set_chain_policy(module.params['iptables_path'], module, params), '')


# Generated at 2022-06-20 22:02:58.938000
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy("testi_path", "test_module", "test_params") == False


# Generated at 2022-06-20 22:02:59.916481
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, 'test-match')
    assert rule == ['-m', 'test-match']



# Generated at 2022-06-20 22:03:04.544211
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({}, {}, {})
    assert get_iptables_version('iptables', module) == '1.6.2'


# Generated at 2022-06-20 22:03:09.072256
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    ans = []
    append_tcp_flags(ans, dict(flags=['SYN', 'ACK'], flags_set=['SYN', 'ACK']), 'test')
    assert ans[0] == 'test'
    assert ans[1] == 'SYN,ACK'
    assert ans[2] == 'SYN,ACK'
    return 'Success'



# Generated at 2022-06-20 22:03:16.855332
# Unit test for function push_arguments
def test_push_arguments():
    # iptables_version is mocked here to force to fetch wait option for ipv4
    with mock.patch('ansible.module_utils.basic.AnsibleModule.get_bin_path') as get_bin_path_mock, \
            mock.patch('ansible.module_utils.basic.AnsibleModule.iptables_version', return_value='v1.4.20'):
        get_bin_path_mock.return_value = '/usr/bin/iptables'
        args = dict(
            chain='INPUT',
            destination='8.8.8.8',
            jump='DROP',
            protocol='tcp',
            comment='comment',
            state='present',
            wait='5',
            )

# Generated at 2022-06-20 22:03:20.993473
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(rule=[], param='match', flag='--icmp-type', negatable=True) == ['--icmp-type']


# Generated at 2022-06-20 22:03:23.907341
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = ['iptables', '-A']
    flags = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN'],
    )
    assert append_tcp_flags(rule, flags, '--tcp-flags') == ['iptables', '-A', '--tcp-flags', 'ACK,RST,SYN,FIN,ACK,RST,SYN,FIN']


# Generated at 2022-06-20 22:03:42.881739
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['SYN'], 'flags_set': ['ACK', 'RST']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'SYN', 'ACK,RST']



# Generated at 2022-06-20 22:03:51.568496
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'chain': 'INPUT',
        'table': 'filter',
    }
    assert get_chain_policy(None, module, module.params) is None
    module.run_command = lambda x, y, z: (0, "Chain INPUT (policy ACCEPT)\n", None)
    assert get_chain_policy(None, module, module.params) == 'ACCEPT'



# Generated at 2022-06-20 22:03:56.789648
# Unit test for function get_iptables_version
def test_get_iptables_version():
    class MockModule(object):
        def run_command(cmd, check_rc=True):
            return 0, 'v1.8.0', ''

    module = MockModule()

    assert get_iptables_version('iptables', module) == '1.8.0'


# Generated at 2022-06-20 22:04:08.291835
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule({
        'chain': 'INPUT',
        'protocol': 'tcp',
        'syn': 'match',
        'jump': 'DROP',
        'ip_version': 'ipv4',
        'reject_with': 'tcp-reset',
        'action': 'append'
    }) == ['--syn', '-p', 'tcp', '-j', 'DROP', '--reject-with', 'tcp-reset']

# Generated at 2022-06-20 22:04:18.007842
# Unit test for function append_rule

# Generated at 2022-06-20 22:04:33.486932
# Unit test for function append_param
def test_append_param():
    # test append single parameter without '!'
    rule = list()
    append_param(rule, '78', '--source-port', False)
    assert rule == ['--source-port', '78']
    # test append single parameter with '!'
    rule = list()
    append_param(rule, '!78', '--source-port', False)
    assert rule == ['!', '--source-port', '78']
    # test append list parameter without '!'
    rule = list()
    append_param(rule, ['78', '79'], '--destination-port', True)
    assert rule == ['--destination-port', '78', '--destination-port', '79']
    # test append list parameter with '!'
    rule = list()

# Generated at 2022-06-20 22:04:36.005394
# Unit test for function get_iptables_version
def test_get_iptables_version():
    ip_version = 'ipv4'
    module = MagicMock()
    module.run_command = MagicMock(return_value=(0, 'iptables v1.8.2', ''))
    assert get_iptables_version(BINS[ip_version], module) == '1.8.2'



# Generated at 2022-06-20 22:04:41.054254
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['--syn', '!', '--syn']

# Generated at 2022-06-20 22:04:44.190023
# Unit test for function append_match
def test_append_match():
    rule = []
    param = True
    match = 'state'
    append_match(rule, param, match)
    assert rule == ['-m', 'state']
    rule = []
    param = False
    match = 'state'
    append_match(rule, param, match)
    assert rule == []



# Generated at 2022-06-20 22:04:54.465469
# Unit test for function get_iptables_version
def test_get_iptables_version():
    iptables_path = '/usr/sbin/iptables'
    module = stub_module()
    out = get_iptables_version(iptables_path, module)
    assert out == '1.8.2'
    module.run_command.assert_called_once_with(
        [iptables_path, '--version'],
        check_rc=True
    )



# Generated at 2022-06-20 22:05:13.667076
# Unit test for function get_iptables_version
def test_get_iptables_version():
    path = '/usr/bin/iptables'
    module = FakeModule()
    module.run_command = MagicMock()
    module.run_command.return_value = (0, 'iptables v1.6.0', '')
    assert get_iptables_version(path, module) == '1.6.0'
    module.run_command.assert_called_with(
        ['/usr/bin/iptables', '--version'],
        check_rc=True
    )



# Generated at 2022-06-20 22:05:18.998141
# Unit test for function append_wait
def test_append_wait():
    rule = []
    assert [] == rule
    append_wait(rule, '10', '--wait')
    assert ['--wait', '10'] == rule
    append_wait(rule, '', '--wait')
    assert ['--wait', '10'] == rule
    append_wait(rule, None, '--wait')
    assert ['--wait', '10'] == rule


# Generated at 2022-06-20 22:05:23.411384
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, [], 'flag')
    assert rule == []
    rule = []
    append_csv(rule, ['a'], 'flag')
    assert rule == ['flag', 'a']
    rule = []
    append_csv(rule, ['a', 'b'], 'flag')
    assert rule == ['flag', 'a,b']



# Generated at 2022-06-20 22:05:35.797377
# Unit test for function construct_rule

# Generated at 2022-06-20 22:05:41.615866
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['ESTABLISHED', 'RELATED']
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert rule == ['--ctstate', 'ESTABLISHED,RELATED']



# Generated at 2022-06-20 22:05:45.814401
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, '80', '-s', False)
    assert rule == ['-s', '80']

    rule = []
    append_param(rule, '!80', '-s', False)
    assert rule == ['!', '-s', '80']

    rule = []
    append_param(rule, ['80', '443'], '-s', True)
    assert rule == ['-s', '80', '-s', '443']

    rule = []
    append_param(rule, ['!80', '!443'], '-s', True)
    assert rule == ['!', '-s', '80', '!', '-s', '443']



# Generated at 2022-06-20 22:05:49.603363
# Unit test for function insert_rule
def test_insert_rule():
    params = {}
    params['protocol'] = "tcp"
    params['jump'] = "ACCEPT"
    params['chain'] = "INPUT"
    params['insert'] = "iptables"
    params['table'] = "filter"
    insert_rule("iptables", "module", params)
# end of unit test



# Generated at 2022-06-20 22:05:51.250031
# Unit test for function set_chain_policy
def test_set_chain_policy():
    print(set_chain_policy('/sbin/iptables', 'module', 'params'))



# Generated at 2022-06-20 22:06:00.771108
# Unit test for function remove_rule
def test_remove_rule():
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port=80,
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.'
    )
    iptables_path = '/sbin/iptables'
    class MockModule:
        FAIL_SLEEP=.1
        def __init__(self, fail_sleep=FAIL_SLEEP):
            self.run_command_called = False
            self.run_command_args = None
            self.run_command_kwargs = None
            self.fail_sleep = fail_sleep
            self.check_rc = True

# Generated at 2022-06-20 22:06:05.549366
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'ACCEPT'
    jump = 'ACCEPT'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'ACCEPT']

    rule = []
    param = 'ACCEPT'
    jump = 'DROP'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'ACCEPT']

    rule = []
    param = 'DROP'
    jump = 'ACCEPT'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'DROP']


# Generated at 2022-06-20 22:06:34.414938
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '10', '--wait')
    assert rule == ['--wait', '10']



# Generated at 2022-06-20 22:06:39.818095
# Unit test for function append_rule
def test_append_rule():
    command = 'iptables -A INPUT -p tcp -m multiport --dports 22,80 -j ACCEPT'
    params_append = {
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_ports': ['22', '80'],
        'jump': 'ACCEPT'
    }
    cmd = push_arguments(BINS['ipv4'], '-A', params_append)
    assert command == ' '.join(cmd)



# Generated at 2022-06-20 22:06:42.832792
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(iptables_path='iptables', module=None) == '1.6.2'



# Generated at 2022-06-20 22:06:45.593419
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_param = dict(flags=['SYN', 'ACK'], flags_set=['ACK'])
    test_rule = []
    append_tcp_flags(test_rule, test_param, '--tcp-flags')
    assert test_rule == ['--tcp-flags', 'SYN,ACK', 'ACK']



# Generated at 2022-06-20 22:06:49.746577
# Unit test for function get_iptables_version
def test_get_iptables_version():
    '''
    Unit test function for getting iptables version.
    '''
    raw_out = 'v1.4.21'
    out = raw_out.split('v')[1].rstrip('\n')
    assert out == '1.4.21'


# Generated at 2022-06-20 22:06:55.465163
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['test1', 'test2', 'test3']
    flag = 'test'
    append_csv(rule, param, flag)
    assert rule == ['test', 'test1,test2,test3']



# Generated at 2022-06-20 22:07:04.257087
# Unit test for function construct_rule

# Generated at 2022-06-20 22:07:10.299967
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, {'flags': 'ALL', 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}, '--tcp-flags')
    expected_rule = ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']
    assert(rule == expected_rule)



# Generated at 2022-06-20 22:07:20.559452
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/sbin/iptables'
    action = '-I'
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        action='insert',
        rule_num='2',
        protocol='tcp',
        destination_port='80',
        comment='Accept new SSH connections.',
        jump='ACCEPT',
    )

    assert push_arguments(iptables_path, action, params) == [
        '/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '2', '-p', 'tcp',
        '--dport', '80', '-j', 'ACCEPT', '-m', 'comment', '--comment',
        'Accept new SSH connections.'
    ]
    params.update

# Generated at 2022-06-20 22:07:23.842421
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, '', 'match')
    assert rule == []

    rule = []
    append_match(rule, 'match', 'match')
    assert rule == ['-m', 'match']



# Generated at 2022-06-20 22:07:52.836607
# Unit test for function get_iptables_version
def test_get_iptables_version():
    iptables_version = get_iptables_version('iptables', None)
    assert iptables_version



# Generated at 2022-06-20 22:07:54.485290
# Unit test for function append_jump
def test_append_jump():
    rule = []
    jump = 'ACCEPT'
    append_jump(rule, jump, jump)
    assert rule == ['-j', jump]



# Generated at 2022-06-20 22:07:57.957856
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, 'yes', 'match')
    assert rule == ['-m', 'match']


# Generated at 2022-06-20 22:08:01.867150
# Unit test for function append_match
def test_append_match():
    rule = []
    param = 'tcp'
    match = 'tcp'
    assert append_match(rule, param, match)=="['-m', 'tcp']"


# Generated at 2022-06-20 22:08:08.633909
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule1 = []
    param1 = {'flags': ['SYN', 'FIN', 'RST', 'RST'], 'flags_set': ['SYN', 'ACK']}
    append_tcp_flags(rule1, param1, '--tcp-flags')
    assert rule1[1] == 'SYN,FIN,RST,RST'
    assert rule1[2] == 'SYN,ACK'
    rule2 = []
    param2 = None
    append_tcp_flags(rule2, param2, '--tcp-flags')
    assert not rule2
    rule2 = []
    param2 = {'flags': ['SYN', 'ACK', 'RST', 'RST'], 'flags_set': []}

# Generated at 2022-06-20 22:08:18.842204
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('/usr/bin/iptables', '-I', dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        protocol='tcp',
        source='127.0.0.1',
        jump='DROP',
        rule_num='3')) == ['/usr/bin/iptables', '-t', 'filter', '-I', 'INPUT', '3', '-p', 'tcp', '-s', '127.0.0.1', '-j', 'DROP']



# Generated at 2022-06-20 22:08:22.232213
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, "ACCEPT", "ACCEPT")
    assert rule == ['-j', 'ACCEPT']
    rule = []
    append_jump(rule, None, "ACCEPT")
    assert rule == []


# Generated at 2022-06-20 22:08:30.380192
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec={})
    iptables_path = '/sbin/iptables'
    ip_version = 'ipv4'
    table = 'filter'
    chain = 'INPUT'
    action = 'p'
    jump = 'ACCEPT'
    params = dict(ip_version=ip_version,
                  table=table,
                  chain=chain,
                  action=action,
                  jump=jump)
    cmd = push_arguments(iptables_path, '-C', params)
    module.run_command(cmd, check_rc=False)
    assert(check_present(iptables_path, module, params) == True)
# Unit test completed



# Generated at 2022-06-20 22:08:35.682578
# Unit test for function remove_rule
def test_remove_rule():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = mock_run_command
    params1 = {
        'table': 'filter',
        'ip_version': 'ipv4',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'source': '8.8.8.8/32',
        'jump': 'DROP',
        'comment': '',
        'wait': '',
        'rule_num': '',
    }
    remove_rule('iptables', module, params1)
    #module.run_command.assert_called()



# Generated at 2022-06-20 22:08:36.745674
# Unit test for function flush_table

# Generated at 2022-06-20 22:09:25.515526
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = DummyModule()
    params = dict(chain='INPUT', table='filter')
    assert get_chain_policy('/sbin/iptables', module, params) == 'ACCEPT'


# Generated at 2022-06-20 22:09:31.359292
# Unit test for function flush_table
def test_flush_table():
  module = AnsibleModule(argument_spec=dict(
        table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw', 'security'], aliases=['t']),
        chain=dict(default='INPUT', aliases=['C']),
        ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6'], aliases=['4']),
      ), supports_check_mode=True)
  flush_table('iptables', module, 'filter')


# Generated at 2022-06-20 22:09:32.650159
# Unit test for function append_match
def test_append_match():
    assert append_match([], True, 'match') == ['-m', 'match']
    assert append_match([], False, 'match') == []



# Generated at 2022-06-20 22:09:40.391891
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule({})
    test_params = {
        'table': 'filter',
        'chain': 'input',
        'protocol': 'udp',
        'jump': 'ACCEPT',
        'ip_version': 'ipv4',
    }
    check_present('iptables', test_module, test_params)
    test_params = {
        'table': 'filter',
        'chain': 'input',
        'source': '1.1.1.1',
        'jump': 'DROP',
        'ip_version': 'ipv4',
    }
    check_present('iptables', test_module, test_params)



# Generated at 2022-06-20 22:09:50.042626
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    class TestModule(object):
        def __init__(self, version='1.4.20'):
            self.params = dict()
            self.params['ip_version'] = 'ipv4'
            self.params['table'] = 'filter'
            self.params['chain'] = 'INPUT'
            self.params['jump'] = 'ACCEPT'
            self.ansible_version = ansible_version
            self.run_command_results = None

        def run_command(self, cmd, check_rc=False):
            assert cmd == ['iptables', '--version']

# Generated at 2022-06-20 22:09:56.350751
# Unit test for function remove_rule
def test_remove_rule():
    rule = construct_rule({"table": "filter", "chain": "INPUT", "protocol": "tcp", "destination_port": "20", "ctstate": "NEW", "syn": "match", "jump": "ACCEPT", "comment": "Accept new SSH connections."})
    assert remove_rule("iptables", None, {"table": "filter", "chain": "INPUT", "protocol": "tcp", "destination_port": "20", "ctstate": "NEW", "syn": "match", "jump": "ACCEPT", "comment": "Accept new SSH connections."}) == ["iptables", "-t", "filter", "-D", "INPUT"] + rule



# Generated at 2022-06-20 22:10:02.702455
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('iptables', '-A', dict(
        table='filter',
        chain='INPUT',
        rule_num=1,
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.'
        )) == ['iptables', '-t', 'filter', '-A', 'INPUT', '1', '-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']

# Generated at 2022-06-20 22:10:05.727916
# Unit test for function append_wait
def test_append_wait():
    rule = append_wait(['/sbin/iptables'], '1', '--wait')
    assert rule == ['/sbin/iptables', '--wait', '1']



# Generated at 2022-06-20 22:10:15.258112
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    flag = 'abc'
    negatable = True

    append_match_flag(rule, param, flag, negatable)
    assert rule == [flag]
    rule = []
    param = 'negate'
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['!', flag]
    rule = []
    param = 'negate'
    negatable = False
    append_match_flag(rule, param, flag, negatable)
    assert rule == [flag]

# Generated at 2022-06-20 22:10:17.607748
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(argument_spec={})
    assert get_chain_policy(None, module, dict(
        table='filter',
        chain='INPUT')) is None

