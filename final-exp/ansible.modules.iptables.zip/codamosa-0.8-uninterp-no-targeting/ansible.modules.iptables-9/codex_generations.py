

# Generated at 2022-06-20 22:01:50.866488
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule=[]
    append_tcp_flags(rule,1,1)
    assert rule == []

    rule=[]
    param_flags = dict(flags=['ACK'], flags_set=['RST'])
    append_tcp_flags(rule, param_flags, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK', 'RST']

    rule = []
    param_flags = dict(flags=['ACK'], flags_set=[])
    append_tcp_flags(rule, param_flags, '--tcp-flags')
    assert rule == []

    rule = []
    param_flags = dict(flags=[], flags_set=[])
    append_tcp_flags(rule, param_flags, '--tcp-flags')
    assert rule == []


# Generated at 2022-06-20 22:02:01.837722
# Unit test for function append_rule
def test_append_rule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO


# Generated at 2022-06-20 22:02:13.437382
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        jump='ACCEPT',
        comment='allow_tcp',
        source='10.0.0.0/24',
        match=['comment'],
        ip_version='ipv4',
        wait='3',
        set_dscp_mark='0x06',
        tcp_flags={
            'flags': ['SYN'],
            'flags_set': ['ACK', 'RST'],
        },
        state='present',
        ctstate=['NEW'],
    )
    rule = construct_rule(params)
    assert '-w' in rule
    assert '--set-dscp' in rule
    assert rule.index('-p') < rule.index('-s') < rule.index('-m')
    assert '--dports'

# Generated at 2022-06-20 22:02:25.314942
# Unit test for function append_param
def test_append_param():

    # Standard case
    rule = []
    param = 'foo'
    flag = '--bar'
    append_param(rule, param, flag, False)
    assert rule == ['--bar', 'foo']

    # Negation
    rule = []
    param = '!foo'
    flag = '--bar'
    append_param(rule, param, flag, False)
    assert rule == ['!', '--bar', 'foo']

    # Enumerated values
    rule = []
    param = ['bar', 'baz']
    flag = '--foo'
    append_param(rule, param, flag, True)
    assert rule == ['--foo', 'bar', '--foo', 'baz']

    # Enumerated values with negation
    rule = []
    param = ['bar', '!baz']
   

# Generated at 2022-06-20 22:02:34.709193
# Unit test for function construct_rule

# Generated at 2022-06-20 22:02:41.528273
# Unit test for function construct_rule

# Generated at 2022-06-20 22:02:48.520963
# Unit test for function check_present
def test_check_present():
    test_module = AnsibleModule({})
    test_params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'ACCEPT'
    }
    test_cmd = ['/sbin/iptables', '-C', '-t', 'filter', 'INPUT',
            '-p', 'tcp', '--destination-port', '80', '-j', 'ACCEPT']
    assert check_present('/sbin/iptables', test_module, test_params) == True



# Generated at 2022-06-20 22:02:49.565923
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', 'iptables -A INPUT -d 0/0 -j ACCEPT')



# Generated at 2022-06-20 22:03:00.280587
# Unit test for function append_rule
def test_append_rule():
    iptables_path = "iptables"
    module = ""
    params = {}
    params['table']="filter"
    params['chain'] = "INPUT"
    params['rule_num'] = ""
    params['protocol'] = ""
    params['source'] = ""
    params['destination'] = ""
    params['match'] = ""
    params['tcp_flags'] = ""
    params['jump'] = ""
    params['log_prefix'] = ""
    params['log_level'] = ""
    params['to_destination'] = ""
    params['destination_ports'] = ""
    params['to_source'] = ""
    params['goto'] = ""
    params['in_interface'] = ""
    params['out_interface'] = ""
    params['fragment'] = ""

# Generated at 2022-06-20 22:03:04.505306
# Unit test for function check_present
def test_check_present():
    assert (check_present('test', {'run_command': lambda cmd, **kwargs: cmd if kwargs=={'check_rc':False} else None}, {'table':'test_table', 'chain': 'test_chain'}) == False)


# Generated at 2022-06-20 22:03:26.926642
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    assert append_match_flag(rule, 'match', '--syn', True) == []
    assert rule == ['--syn']
    assert append_match_flag(rule, 'negate', '--syn', True) == []
    assert rule == ['!', '--syn']


# Generated at 2022-06-20 22:03:30.643092
# Unit test for function append_match
def test_append_match():
    rule = []
    rule_expected = []
    # Test valid match
    param = True
    append_match(rule, param, 'tcp')
    rule_expected.extend(['-m', 'tcp'])
    assert rule == rule_expected
    # Test invalid match
    param = False
    rule = []
    rule_expected = []
    append_match(rule, param, 'tcp')
    assert rule == rule_expected



# Generated at 2022-06-20 22:03:33.150315
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', {}) == '1.4.21'



# Generated at 2022-06-20 22:03:37.606830
# Unit test for function flush_table
def test_flush_table():
    import ansible
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils.compat
    import ansible.module_utils.urls
    module = ansible.module_utils.basic.AnsibleModule()
    module._ansible_version_ = LooseVersion("2.7.1.dev0")
    params = {
        'table': 'filter',
        'chain': 'FORWARD'
    }
    action = 'flush'
    flush_table('/sbin/iptables', module, params)
# End unit test for function flush_table


# Generated at 2022-06-20 22:03:46.478697
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 22:03:53.081048
# Unit test for function append_csv
def test_append_csv():
    a = ['!', '-I', 'INPUT', '-p', 'tcp', '-s', '192.168.1.100-192.168.1.199', '-d', '10.0.0.1-10.0.0.50', '-j', 'ACCEPT', '-m', 'comment', '--comment', '"Ansible"']
    b = ['--dport', '81,80', '--sport', '20,22,25']
    append_csv(a,b,'-m')
    print(a)

# Generated at 2022-06-20 22:04:05.799179
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '5', '-w')
    print(rule)
    assert rule == ['-w', '5']
    rule = []
    append_wait(rule, '5s', '-w')
    print(rule)
    assert rule == ['-w', '5s']
    rule = []
    append_wait(rule, '5s', '--wait')
    print(rule)
    assert rule == ['--wait', '5s']
    rule = []
    append_wait(rule, '5', '--wait')
    print(rule)
    assert rule == ['--wait', '5']


# Generated at 2022-06-20 22:04:10.621268
# Unit test for function append_wait
def test_append_wait():
    cmd = [ 'IPTABLES', '-A', 'INPUT', '-p', 'tcp', '-m', 'conntrack', '!' '-ctstate', 'ESTABLISHED,RELATED', '-j', 'DROP' ]
    append_wait(cmd, '2', '--wait')
    assert cmd == [ 'IPTABLES', '--wait', '2', '-A', 'INPUT', '-p', 'tcp', '-m', 'conntrack', '!' '-ctstate', 'ESTABLISHED,RELATED', '-j', 'DROP' ]

    append_wait(cmd, '1/hour', '--wait')

# Generated at 2022-06-20 22:04:14.273509
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '-m time', False)
    assert ['-m', 'time'] == rule
    append_match_flag(rule, 'negate', '-s', True)
    assert ['-m', 'time', '!', '-s'] == rule



# Generated at 2022-06-20 22:04:18.334270
# Unit test for function remove_rule
def test_remove_rule():
    test_params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        source='192.168.1.10',
        jump='DROP',
        action='remove'
    )
    test_iptables_path = '/sbin/iptables'
    test_remove_rule(test_iptables_path, test_params)



# Generated at 2022-06-20 22:04:29.842757
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(rule,param,flag,negatable) == rule.extend([flag])


# Generated at 2022-06-20 22:04:37.775062
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, None, "syn", True)
    assert len(rule) == 0
    rule = []
    append_match_flag(rule, "match", "syn", True)
    assert len(rule) == 1
    rule = []
    append_match_flag(rule, "negate", "syn", True)
    assert len(rule) == 2
    rule = []
    append_match_flag(rule, "invalid_val", "syn", True)
    assert len(rule) == 1



# Generated at 2022-06-20 22:04:40.164107
# Unit test for function append_jump
def test_append_jump():
    rule = []
    assert append_jump(rule, None, None) == None
    assert not rule
    assert append_jump(rule, 'ACCEPT', 'ACCEPT') == None
    assert rule == ['-j', 'ACCEPT']
    rule = []
    assert append_jump(rule, 'ACCEPT', 'DROP') == None
    assert rule == ['-j', 'ACCEPT']
# End of unit test for function append_jump


# Generated at 2022-06-20 22:04:43.808120
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain="INPUT", table="filter")) == "ACCEPT"



# Generated at 2022-06-20 22:04:46.268350
# Unit test for function append_wait
def test_append_wait():
    rule1 = ['-A', 'INPUT']
    rule2 = ['-A', 'INPUT']
    wait_parm = '10'
    append_wait(rule1, '', '-w')
    append_wait(rule2, wait_parm, '-w')
    assert rule1 != rule2


# Generated at 2022-06-20 22:04:47.565481
# Unit test for function append_rule
def test_append_rule():
  append_rule('sample_path', 'sample_module', 'sample_params')



# Generated at 2022-06-20 22:04:48.601268
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version == LooseVersion('1.4.20')



# Generated at 2022-06-20 22:04:58.002664
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'DROP', '--jump', False)
    assert rule == ['--jump', 'DROP']

    rule = []
    append_param(rule, ['DROP', 'ACCEPT'], '--jump', True)
    assert rule == ['--jump', 'DROP', '--jump', 'ACCEPT']

    rule = []
    append_param(rule, '!ACCEPT', '--jump', False)
    assert rule == ['!', '--jump', 'ACCEPT']



# Generated at 2022-06-20 22:05:11.399880
# Unit test for function append_csv
def test_append_csv():
    rule = []

# Generated at 2022-06-20 22:05:15.967761
# Unit test for function main

# Generated at 2022-06-20 22:05:30.985528
# Unit test for function append_match_flag
def test_append_match_flag():
    assert(append_match_flag(['-A'], 'negate', '-s', True) == ['-A', '-s'])
    assert(append_match_flag(['-A'], 'match', '-s', False) == ['-A', '!', '-s'])
    assert(append_match_flag(['-A'], 'negate', '-s', False) == ['-A', '!', '-s'])
    assert(append_match_flag(['-A'], 'match', '-s', True) == ['-A', '-s'])



# Generated at 2022-06-20 22:05:39.774728
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables',None,dict(table="nat",chain="PREROUTING")) == "ACCEPT"
    assert get_chain_policy('iptables',None,dict(table="nat",chain="INPUT")) == "DROP"
    assert get_chain_policy('iptables',None,dict(table="nat",chain="OUTPUT")) == "ACCEPT"
    assert get_chain_policy('iptables',None,dict(table="nat",chain="POSTROUTING")) == "MASQUERADE"
    assert get_chain_policy('iptables',None,dict(table="filter",chain="INPUT")) == "ACCEPT"
    assert get_chain_policy('iptables',None,dict(table="filter",chain="FORWARD")) == "ACCEPT"

# Generated at 2022-06-20 22:05:42.417135
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({})
    params = {
        'chain': 'INPUT',
        'table': 'filter',
        'policy': 'DROP',
        'wait': '5'
    }
    assert set_chain_policy('iptables', module, params) == ['iptables',
                                                            '-w', '5',
                                                            '-t', 'filter',
                                                            '-P', 'INPUT', 'DROP']



# Generated at 2022-06-20 22:05:50.948495
# Unit test for function insert_rule
def test_insert_rule():
    import os
    import sys
    test_args = [
        '-t', 'nat',
        '-I', 'chain',
        'rule_num',
    ]
    module = AnsibleModule(argument_spec={})
    module.params["table"] = "nat"
    module.params["chain"] = "chain"
    module.params["rule_num"] = "rule_num"
    module.params["action"] = "insert"
    iptables_path = "/bin/iptables"
    insert_rule(iptables_path, module, module.params)
    assert test_args == module.run_command.call_args[0][0]
    del os.environ['ANSIBLE_MODULE_ARGS']
    sys.argv = sys.argv[:1]



# Generated at 2022-06-20 22:05:57.384952
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param_1 = ['ESTABLISHED']
    flag_1 = '--ctstate'
    append_csv(rule, param_1, flag_1)
    assert rule == ['--ctstate', 'ESTABLISHED'], rule

    rule = []
    param_2 = []
    flag_2 = '--ctstate'
    append_csv(rule, param_2, flag_2)
    assert rule == [], rule



# Generated at 2022-06-20 22:06:05.895937
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = ['iptables', '-A', 'INPUT']
    param = {'flags': ['ALL'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['iptables', '-A', 'INPUT', '--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']


# Generate a list of arguments for *iptables commands

# Generated at 2022-06-20 22:06:18.455795
# Unit test for function append_match_flag
def test_append_match_flag():
    rule1 = []
    param1 = 'match'
    flag1 = 'test_flag1'
    negatable1 = False
    append_match_flag(rule1, param1, flag1, negatable1)
    assert rule1 == ['test_flag1']

    rule2 = []
    param2 = 'negate'
    flag2 = 'test_flag2'
    negatable2 = True
    append_match_flag(rule2, param2, flag2, negatable2)
    assert rule2 == ['!', 'test_flag2']

    rule3 = []
    param3 = None
    flag3 = 'test_flag3'
    negatable3 = True
    append_match_flag(rule3, param3, flag3, negatable3)
    assert rule3 == []



# Generated at 2022-06-20 22:06:22.832377
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = push_arguments('/usr/sbin/iptables', '-P', params, make_rule=False)
    cmd.append(params['policy'])
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-20 22:06:32.940136
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, None, '--match', False)
    assert rule == []
    rule = []
    append_param(rule, ['tcp'], '--protocol', True)
    assert rule == ['--protocol', 'tcp']
    rule = []
    append_param(rule, ['foo', 'bar'], '--protocol', True)
    assert rule == ['--protocol', 'foo', '--protocol', 'bar']
    rule = []
    append_param(rule, ['foo', '!bar'], '--protocol', True)
    assert rule == ['--protocol', 'foo', '!', '--protocol', 'bar']
    rule = []
    append_param(rule, None, '--protocol', True)
    assert rule == []


WAIT_PAR

# Generated at 2022-06-20 22:06:35.082618
# Unit test for function append_match
def test_append_match():
    r = ['-A', 'INPUT']
    append_match(r, True, 'match')
    assert r == ['-A', 'INPUT', '-m', 'match']


# Generated at 2022-06-20 22:06:49.409559
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = None 
    params = {
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'insert',
        'rule_num': '5',
        'chain': 'INPUT',
        'table': 'filter',
        'ip_version': 'ipv4'
    }
    insert_rule(iptables_path, module, params)



# Generated at 2022-06-20 22:06:54.744618
# Unit test for function append_match
def test_append_match():
    input_rule = []
    append_match(input_rule, 'dccp', 'dccp')
    assert input_rule == ['-m', 'dccp']


# Generated at 2022-06-20 22:07:06.441930
# Unit test for function push_arguments

# Generated at 2022-06-20 22:07:20.792940
# Unit test for function get_chain_policy
def test_get_chain_policy():
    import argparse
    args = argparse.Namespace()
    args.table = "nat"
    args.chain = "PREROUTING"
    args.policy = "ACCEPT"
    args.ip_version = "ipv4"
    args.state = "absent"
    args.jump = ""

    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 22:07:22.838575
# Unit test for function append_match
def test_append_match():
    result = []
    append_match(result, 'connlimit', 'connlimit')
    assert result == ['-m', 'connlimit']


# Generated at 2022-06-20 22:07:27.925852
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'tcp', '--protocol', False)
    assert rule == ['--protocol', 'tcp']

    append_param(rule, '!tcp', '--protocol', False)
    assert rule == ['--protocol', 'tcp', '!', '--protocol', 'tcp']

    append_param(rule, ['tcp', 'udp'], '--protocol', True)
    assert rule == ['--protocol', 'tcp', '!', '--protocol', 'tcp', '--protocol', 'tcp', '--protocol', 'udp']

    append_param(rule, None, '--protocol', False)

# Generated at 2022-06-20 22:07:30.172559
# Unit test for function append_match
def test_append_match():
    assert append_match([], 'match', 'match') == ['-m', 'match']
    assert append_match([], '', 'match') == []
    assert append_match(None, 'match', 'match') == ['-m', 'match']
    assert append_match([], None, 'match') == []
    assert append_match(None, None, 'match') == []


# Generated at 2022-06-20 22:07:31.850152
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule("iptables", "module", "params" )== -1


# Generated at 2022-06-20 22:07:39.789337
# Unit test for function push_arguments
def test_push_arguments():
    MODULE_ARGS = dict(
        action='insert',
        ip_version='ipv4',
        table='filter',
        chain='OUT',
        rule_num='1',
        state='present',
        protocol='tcp',
        syn='match',
        dest_range='10.0.0.1-10.0.0.50',
        src_range='192.168.1.100-192.168.1.199',
        icmp_type='8[0]',
        set_dscp_mark='8',
        set_dscp_mark_class='CS0',
        jump='DROP',
        reject_with='host-prohibited',
        ctstate='ESTABLISHED,RELATED',
        comment='test',
    )

# Generated at 2022-06-20 22:07:40.689956
# Unit test for function set_chain_policy
def test_set_chain_policy():
    set_chain_policy('', '', '')

# Generated at 2022-06-20 22:08:03.859880
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', 'iptables v1.6.0') == '1.6.0'
    assert get_iptables_version('ip6tables', 'ip6tables v1.6.0') == '1.6.0'
    assert get_iptables_version('iptables', 'iptables v1.6.0 dev') == '1.6.0'
    assert get_iptables_version('ip6tables', 'ip6tables v1.6.0 dev') == '1.6.0'
    assert get_iptables_version('iptables', 'iptables v1.6.0 (nf_tables)') == '1.6.0'

# Generated at 2022-06-20 22:08:12.886617
# Unit test for function main

# Generated at 2022-06-20 22:08:19.719276
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict())
    params = dict()
    iptables_path = 'iptables'
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['policy'] = 'DROP'
    cmd = set_chain_policy(iptables_path, module, params)
    assert cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']


# Generated at 2022-06-20 22:08:25.006615
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ALL', 'NEW', 'SYN', 'ACK', 'FIN'], flags_set=['ACK', 'RST', 'SYN'])
    append_tcp_flags(rule, param, "--tcp-flags")
    assert rule == ['--tcp-flags', 'ALL,NEW,SYN,ACK,FIN', 'ACK,RST,SYN']



# Generated at 2022-06-20 22:08:33.199438
# Unit test for function append_param
def test_append_param():
    items = ['item1', 'item2']
    flag = '--destination-port'
    rule = []
    append_param(rule, items, flag, True)
    if rule != ['--destination-port', 'item1', '--destination-port', 'item2']:
        raise AssertionError("List parameter is not handled correctly")
    rule = []
    append_param(rule, items[0], flag, False)
    if rule != ['--destination-port', 'item1']:
        raise AssertionError("Non-list parameter is not handled correctly")

    param = '! 80'
    flag = '--destination-port'
    rule = []
    append_param(rule, param, flag, False)
    if rule != ['!', '--destination-port', '80']:
        raise

# Generated at 2022-06-20 22:08:48.713315
# Unit test for function main

# Generated at 2022-06-20 22:08:55.121297
# Unit test for function append_csv
def test_append_csv():
  assert append_csv( rule = [], param = [], flag = '' ) == []
  assert append_csv( rule = [], param = ['a'], flag = 'a' ) == ['a', 'a']
  assert append_csv( rule = [], param = ['a', 'b'], flag = 'a' ) == ['a', 'a,b']
  assert append_csv( rule = [], param = ['a', 'b', 'c'], flag = 'a' ) == ['a', 'a,b,c']



# Generated at 2022-06-20 22:08:57.779466
# Unit test for function check_present
def test_check_present():
    check_present(None, None, {
        'protocol': 'tcp',
        'jump': 'ACCEPT',
        'rule_num': '',
        'destination_port': '22',
        'table': 'filter',
        'chain': 'INPUT',
        'state': 'present'
    })



# Generated at 2022-06-20 22:09:06.153559
# Unit test for function insert_rule
def test_insert_rule():
    module = MagicMock()
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': 1,
        'protocol': 'tcp',
        'destination_port': 80,
        'jump': 'ACCEPT',
        'state': 'present',
        'ip_version': 'ipv4',
    }
    expected_cmd = ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '1', '-p', 'tcp', '--dport', '80', '-j', 'ACCEPT']
    expected_rc = 0
    expected_stdout = ''
    expected_stderr = ''
    module.run_command.return_value = (expected_rc, expected_stdout, expected_stderr)


# Generated at 2022-06-20 22:09:07.293258
# Unit test for function append_jump
def test_append_jump():
    rule=[]
    result = append_jump(rule,'ACCEPT','ACCEPT')
    print (rule)


# Generated at 2022-06-20 22:09:18.867150
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(None, None) == ''



# Generated at 2022-06-20 22:09:24.723194
# Unit test for function push_arguments
def test_push_arguments():
    params = {
        'chain': 'INPUT',
        'action': 'insert',
        'rule_num': 5,
        'jump': 'ACCEPT',
        'source': '8.8.8.8',
        'ip_version': 'ipv4'
    }
    cmd = push_arguments(BINS[params['ip_version']], '-I', params)
    assert cmd == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-s', '8.8.8.8', '-j', 'ACCEPT'
    ]


# Generated at 2022-06-20 22:09:27.148841
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table = dict(type='str', default='filter'),
        chain = dict(type='str', required=True),
        flush = dict(type='bool', default=False)
    ))
    iptables_path = BINS['ipv4']
    flush_table(iptables_path, module, module.params)
    

# Generated at 2022-06-20 22:09:31.842299
# Unit test for function append_match
def test_append_match():
    rule = []
    param = 'test'
    match = 'match'
    append_match(rule, param, match)
    assert('-m' in rule)
    assert('match' in rule)


# Generated at 2022-06-20 22:09:32.919574
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/usr/bin/iptables', 1) == '1.4.21'



# Generated at 2022-06-20 22:09:35.151097
# Unit test for function append_match
def test_append_match():
    test_rule = []
    test_fluftwaffle = "fluftwaffle"
    assert test_rule == append_match(test_rule, test_fufwaffle, test_fluftwaffle)
    assert ["-m", "fluftwaffle"] == append_match(test_rule, True, test_fluftwaffle)


# Generated at 2022-06-20 22:09:38.618200
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule.clear()
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']



# Generated at 2022-06-20 22:09:40.258394
# Unit test for function check_present
def test_check_present():
    pass



# Generated at 2022-06-20 22:09:41.282179
# Unit test for function insert_rule
def test_insert_rule():
    assert append_rule([], {}, {}) is None



# Generated at 2022-06-20 22:09:44.618963
# Unit test for function remove_rule
def test_remove_rule():
    import mock
    args = dict(
        iptables_path = '/usr/local/bin/iptables',
        module = mock.Mock,
        params = dict(
            table='filter',
            chain='INPUT',
            protocol='tcp',
            destination_port=80,
            jump=None,
        )
    )
    cmd = push_arguments(**args)
    args['module'].run_command.assert_called_once_with(cmd, check_rc=True)
    

# Generated at 2022-06-20 22:10:45.383028
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', {}, {'chain': 'INPUT'}) == 'DROP'



# Generated at 2022-06-20 22:10:56.343242
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='Accept HTTP',
    )
    print(' '.join(construct_rule(params)))
    assert construct_rule(params) == ['iptables', '-A', 'INPUT', '-p', 'tcp', '--dport', '80', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept HTTP']



# Generated at 2022-06-20 22:11:11.579151
# Unit test for function construct_rule
def test_construct_rule():
    module = AnsibleModule(argument_spec={})

    def test(params, exp):
        rule = construct_rule(params)
        module.assertListEqual(rule, exp)

    test(dict(
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        set_counters='1234 5678',
        conntrack=True,
        ctstate='ESTABLISHED',
    ), ['-p', 'tcp', '--destination-port', '80', '-j', 'ACCEPT', '-c', '1234', '5678', '-m', 'conntrack', '--ctstate', 'ESTABLISHED'])
