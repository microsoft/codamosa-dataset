

# Generated at 2022-06-20 22:01:42.159138
# Unit test for function get_chain_policy
def test_get_chain_policy():
    import sys
    sys.argv = ['iptablesmod.py', '-a', '-m', 'conntrack', '-p', 'tcp', '-j', 'ACCEPT', '-w', '1', '-s', '192.168.1.1', '-d', '1.1.1.1', '-i', 'eth0', '-o', 'eth0', '-t', 'filter', '-c', '-N', 'test', '-P', 'ACCEPT']

# Generated at 2022-06-20 22:01:56.550976
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('', '', dict(chain='FORWARD', table='filter')) == 'ACCEPT'
    assert get_chain_policy('', '', dict(chain='OUTPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy('', '', dict(chain='INPUT', table='filter')) == 'ACCEPT'
    assert get_chain_policy('', '', dict(chain='INPUT', table='nat')) == 'ACCEPT'
    assert get_chain_policy('', '', dict(chain='INPUT', table='mangle')) == 'ACCEPT'
    assert get_chain_policy('', '', dict(chain='INPUT', table='raw')) == 'ACCEPT'



# Generated at 2022-06-20 22:02:04.092588
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = ['iptables']
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['iptables', '--syn']
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['iptables', '--syn', '!', '--syn']
    append_match_flag(rule, 'ignore', '--syn', True)
    assert rule == ['iptables', '--syn', '!', '--syn']



# Generated at 2022-06-20 22:02:08.436729
# Unit test for function append_match_flag
def test_append_match_flag():
    test_flag = 'some_flag'
    rule = []
    append_match_flag(rule, 'match', test_flag, True)
    assert rule == [test_flag]
    rule = []
    append_match_flag(rule, 'negate', test_flag, True)
    assert rule == ['!', test_flag]
    rule = []
    append_match_flag(rule, 'ignore', test_flag, True)
    assert rule == []
    append_match_flag(rule, '', test_flag, False)
    assert rule == []


# Generated at 2022-06-20 22:02:18.925367
# Unit test for function remove_rule
def test_remove_rule():
    from ansible.module_utils._text import to_bytes
    iptables_path = "iptables"
    rc = 0
    out = b"""
    Chain INPUT (policy ACCEPT 0 packets, 0 bytes)
    num   pkts bytes target     prot opt in     out     source               destination

Chain FORWARD (policy ACCEPT 0 packets, 0 bytes)
    num   pkts bytes target     prot opt in     out     source               destination

Chain OUTPUT (policy ACCEPT 0 packets, 0 bytes)
    num   pkts bytes target     prot opt in     out     source               destination
    """
    err = b""
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.run_command_args = []
            self.run_command_kwargs = []



# Generated at 2022-06-20 22:02:30.749345
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule_arr = ['--protocol', 'tcp']
    append_tcp_flags(rule_arr, {'flags': ['ALL'],'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}, '--tcp-flags')
    assert rule_arr == ['--protocol', 'tcp', '--tcp-flags', 'ALL,ACK,RST,SYN,FIN']
    rule_arr = ['--protocol', 'tcp']
    append_tcp_flags(rule_arr, {'flags': ['ALL']}, '--tcp-flags')
    assert rule_arr == ['--protocol', 'tcp']
    rule_arr = ['--protocol', 'tcp']

# Generated at 2022-06-20 22:02:35.312883
# Unit test for function append_wait
def test_append_wait():
    rule = []
    wait = "5"
    param = {'wait': wait}
    flag = "--wait"
    append_wait(rule, param['wait'], flag)
    assert len(rule) == 2
    first_rule = rule[0]
    assert first_rule == '--wait'
    second_rule = rule[1]
    assert second_rule == wait



# Generated at 2022-06-20 22:02:41.528369
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        comment="comment",
        chain="INPUT",
        protocol="tcp",
        destination_port="80",
        ctstate="NEW",
        syn="match",
        jump="ACCEPT",
        table="filter",
        ip_version="ipv4",
    )
    cmd = push_arguments("iptables", "-I", params)
    assert cmd == [
        "iptables", "-t", "filter", "-I", "INPUT",
        "-p", "tcp", "--dport", "80", "-m", "conntrack", "--ctstate", "NEW",
        "--syn", "-j", "ACCEPT", "-m", "comment", "--comment", "comment"
    ]



# Generated at 2022-06-20 22:02:43.251513
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule,True, 'iprange')
    expected = ['-m','iprange']
    assert(expected == rule)



# Generated at 2022-06-20 22:02:48.237973
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = 'iptables'
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='DROP',
        comment='Test insert rules',
        table='nat',
        action='insert',
        rule_num='3'
    )
    cmd = push_arguments(iptables_path, '-I', params)
    print(cmd)
    # module.run_command(cmd, check_rc=True)



# Generated at 2022-06-20 22:02:59.490170
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(argument_spec={})
    chain_policy = get_chain_policy(
        "iptables", module, {
            'table': 'filter',
            'chain': 'INPUT',
            'policy': 'DROP',
        })
    assert chain_policy == 'DROP'


# Generated at 2022-06-20 22:03:05.895259
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', None,
                            dict(
                                chain=None,
                                policy=None,
                                ip_version='ipv4',
                                state='present',
                                table='filter',
                                comment=None,
                                wait=None,
                                rules=None,
                                chain_present=False
                            ))



# Generated at 2022-06-20 22:03:07.708045
# Unit test for function append_csv
def test_append_csv():
    rl = ['a']
    append_csv(rl, ['b', 'c'], '--flag')
    assert rl == ['a', '--flag', 'b,c']



# Generated at 2022-06-20 22:03:14.160493
# Unit test for function main
def test_main():
    BINS = {
        'ipv4': 'iptables',
        'ipv6': 'ip6tables'
    }
    MODULE_ARGS = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        source='8.8.8.8',
        destination='8.8.8.4',
        jump='ACCEPT',
        state='present'
    )
    module_obj = AnsibleModule(argument_spec=MODULE_ARGS)
    iptables_path = module_obj.get_bin_path(BINS[MODULE_ARGS['ip_version']], True)

# Generated at 2022-06-20 22:03:20.105829
# Unit test for function flush_table
def test_flush_table():
    from ansible.modules.network.ip import iptables
    module = iptables
    test_params = {
        "chain": "INPUT",
        "table": "nat"
    }
    flush_table(iptables.BINS[test_params['ip_version']], module, test_params)
# End of unit tests



# Generated at 2022-06-20 22:03:28.126133
# Unit test for function remove_rule
def test_remove_rule():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.run_command = mock_run_command
    module._ansible_debug = False
    params = dict(
        chain='INPUT',
        table='filter',
        ip_version='ipv4',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='Test rule',
        state='present',
        action='remove',
    )
    remove_rule('/sbin/iptables', module, params)
    remove_rule('/sbin/iptables', module, params)



# Generated at 2022-06-20 22:03:38.451574
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = "/usr/sbin/iptables"
    module = {"run_command": run_command}

# Generated at 2022-06-20 22:03:40.311213
# Unit test for function check_present
def test_check_present():
    assert check_present("iptables", True) == True


# Generated at 2022-06-20 22:03:45.574230
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    flag = '--syn'
    negatable = True
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['--syn']
    rule = []
    param = 'negate'
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['!', '--syn']
    rule = []
    param = 'ignore'
    append_match_flag(rule, param, flag, negatable)
    assert rule == []



# Generated at 2022-06-20 22:03:47.964600
# Unit test for function main
def test_main():
    # Change this function so we can test this module properly
    pass


# Generated at 2022-06-20 22:04:03.686019
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    flag = '--syn'
    negatable = True
    expected = ['--syn']
    append_match_flag(rule,param,flag,negatable)
    assert rule == expected



# Generated at 2022-06-20 22:04:12.968656
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(['foo'], 'match', 'bar', False) == ['foo', 'bar']
    assert append_match_flag(['foo'], 'negate', 'bar', True) == ['foo', '!', 'bar']
    assert append_match_flag(['foo'], 'match', '!', False) == ['foo', '!']
    assert append_match_flag(['foo'], 'negate', 'match', True) == ['foo', '!', 'match']



# Generated at 2022-06-20 22:04:14.727235
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", None, {
        'policy': "INPUT",
    }) == "ACCEPT"



# Generated at 2022-06-20 22:04:18.385617
# Unit test for function append_match
def test_append_match():
    rule = ['iptables', '-A', 'INPUT']
    param = 'tcp'
    match = 'tcp'
    assert append_match(rule, param, match) == ['-m', 'tcp']



# Generated at 2022-06-20 22:04:31.098709
# Unit test for function append_param
def test_append_param():
    rule = []
    assert(append_param(rule, 'INPUT', '--in-interface', False) is None)
    assert(rule == ['--in-interface', 'INPUT'])
    rule = []
    assert(append_param(rule, '!INPUT', '--in-interface', False) is None)
    assert(rule == ['!', '--in-interface', 'INPUT'])
    rule = []
    assert(append_param(rule, None, '--in-interface', False) is None)
    assert(rule == [])



# Generated at 2022-06-20 22:04:35.728689
# Unit test for function push_arguments

# Generated at 2022-06-20 22:04:47.512711
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.realpath(__file__)))
    from ansible.modules.network.firewall.iptables import *

    sample_iptables_path = "/sbin/iptables"
    sample_version = "1.4.21"

    class SampleModule(AnsibleModule):
        def __init__(self, *args):
            super(self.__class__, self).__init__(*args)

        def run_command(self, cmd, check_rc=False):
            if cmd[0] == sample_iptables_path and cmd[1] == "--version":
                return (0, "iptables v{}".format(sample_version), "")
           

# Generated at 2022-06-20 22:05:00.081596
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec={})
    iptables_path = 'iptables'
    params = {
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '22',
        'jump': 'ACCEPT',
        'comment': 'myrule'
    }
    cmd = push_arguments(iptables_path, '-C', params)
    print(cmd)
    assert cmd == ['iptables', '-t', 'filter', '-C', 'INPUT', '-p', 'tcp', '--destination-port', '22', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'myrule']
    #rc, _, __

# Generated at 2022-06-20 22:05:06.513834
# Unit test for function append_csv
def test_append_csv():
    assert ['-A', '-m', 'set', '--match-set', 'admin_hosts', 'src', '-j', 'ACCEPT'] == append_csv(['-A'], ['src'], '--match-set')



# Generated at 2022-06-20 22:05:11.295325
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', 'SYN', True)
    assert rule == ['SYN']
    rule = []
    append_match_flag(rule, 'negate', 'SYN', True)
    assert rule == ['!', 'SYN']


# Generated at 2022-06-20 22:05:28.050461
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/usr/usr/bin/iptables'
    action = '-A'

# Generated at 2022-06-20 22:05:32.800859
# Unit test for function flush_table
def test_flush_table():
    assert(flush_table('/usr/sbin/iptables', None, {'table': 'filter', 'chain': 'INPUT'}) == None)

# Generated at 2022-06-20 22:05:40.502933
# Unit test for function insert_rule
def test_insert_rule():
    test_params = dict(src_range='192.168.1.100-192.168.1.199',dst_range='10.0.0.1-10.0.0.50',
                       jump='ACCEPT',protocol='tcp',table='filter',chain='FORWARD')
    test_module = AnsibleModule(argument_spec=dict(src_range='192.168.1.100-192.168.1.199',dst_range='10.0.0.1-10.0.0.50',
                       jump='ACCEPT',protocol='tcp',table='filter',chain='FORWARD'))
    test_iptables_path = 'iptables'
    cmd = push_arguments(test_iptables_path, '-I', test_params)

# Generated at 2022-06-20 22:05:49.635990
# Unit test for function flush_table
def test_flush_table():
    import sys
    import json
    import test_utils

    module_args = {
        'chain': 'INPUT',
        'table': 'filter',
        'wait': '0'
    }

    my_module = test_utils.get_module_mock(module_args=module_args)
    my_module.run_command = test_utils.run_command_mock(['iptables', '-w', '0', '-t', 'filter', '-F', 'INPUT'])

    flush_table('iptables', my_module, module_args)

    my_module.run_command.assert_called_with(['iptables', '-w', '0', '-t', 'filter', '-F', 'INPUT'], check_rc=True)



# Generated at 2022-06-20 22:05:58.298802
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test_module = AnsibleModule(argument_spec={})
    test_iptables_path = '/bin/iptables'
    test_params = {
        'table': 'filter',
        'chain': 'INPUT',
        'ip_version': 'ipv4',
        'wait': None,
    }
    assert get_chain_policy(test_iptables_path, test_module, test_params) == 'ACCEPT'



# Generated at 2022-06-20 22:06:01.583813
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod(verbose=True, report=True)

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:06:03.877857
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', ['iptables', '-L'], 'ACCEPT') == 'ACCEPT'



# Generated at 2022-06-20 22:06:16.592379
# Unit test for function get_chain_policy
def test_get_chain_policy():
    # Test for good chain policy
    params = dict(ip_version='ipv4',
                  table='nat',
                  chain='POSTROUTING',
                  policy='MASQUERADE')
    out = 'Chain POSTROUTING (policy MASQUERADE)\n'
    result = get_chain_policy('/usr/sbin/iptables',
                              AnsibleModule(argument_spec={}),
                              params=params)
    assert result == params['policy']

    # Test for user-defined chain
    params = dict(ip_version='ipv4',
                  table='filter',
                  chain='my_chain',
                  policy='DROP')
    out = '''Chain my_chain (policy DROP)
target     prot opt source               destination'''

# Generated at 2022-06-20 22:06:19.782590
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'ACCEPT'}) == 'ACCEPT'



# Generated at 2022-06-20 22:06:27.376446
# Unit test for function construct_rule

# Generated at 2022-06-20 22:06:47.273670
# Unit test for function append_param
def test_append_param():
    rule = []
    param = [0, '!1', '!2', '!3', 4, 5, '!6', 7, '!8']
    append_param(rule, param, '--dport', True)
    assert rule == ['--dport', '0', '!', '--dport', '1', '!', '--dport',
                    '2', '!', '--dport', '3', '--dport', '4', '--dport',
                    '5', '!', '--dport', '6', '--dport', '7', '!', '--dport',
                    '8']



# Generated at 2022-06-20 22:07:03.836554
# Unit test for function push_arguments
def test_push_arguments():
    test_params = {
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': '3',
        'protocol': 'tcp',
        'destination': '8.8.8.8',
        'destination_port': '80',
        'jump': 'DROP',
    }

    expected_output = [
        'iptables',
        '-t',
        'filter',
        '-I',
        'INPUT',
        '3',
        '-p',
        'tcp',
        '-d',
        '8.8.8.8',
        '--destination-port',
        '80',
        '-j',
        'DROP',
    ]
    assert push_arguments

# Generated at 2022-06-20 22:07:14.564337
# Unit test for function main

# Generated at 2022-06-20 22:07:25.919038
# Unit test for function main

# Generated at 2022-06-20 22:07:37.783921
# Unit test for function construct_rule
def test_construct_rule():
    # a test parameter list
    params = {}
    # add each possible parameter to the list
    params['ip_version'] = 'ipv4'
    params['source'] = None
    params['destination'] = None
    params['protocol'] = None
    params['in_interface'] = None
    params['out_interface'] = None
    params['fragment'] = None
    params['destination_ports'] = None
    params['tcp_flags'] = None
    params['syn'] = None
    params['ctstate'] = None
    params['jump'] = None
    params['log_prefix'] = None
    params['log_level'] = None
    params['set_counters'] = None
    params['match'] = None
    params['source_port'] = None
    params['destination_port'] = None


# Generated at 2022-06-20 22:07:39.155667
# Unit test for function flush_table
def test_flush_table():
    # Need to understand how to write a unit test for python code
    # that runs commands on the shell.
    pass



# Generated at 2022-06-20 22:07:52.066279
# Unit test for function flush_table
def test_flush_table():
    module = MagicMock()
    params = dict(
        table="filter",
        chain="INPUT",
        ip_version="ipv4"
    )
    flush_table('/usr/sbin/iptables', module, params)
    module.run_command.assert_called_with(
        ['/usr/sbin/iptables', '-t', 'filter', '-F', 'INPUT'],
        check_rc=True)
    params = dict(
        table="filter",
        chain="INPUT",
        ip_version="ipv6"
    )
    flush_table('/usr/sbin/iptables', module, params)

# Generated at 2022-06-20 22:07:55.894329
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['ESTABLISHED', 'RELATED']
    append_csv(rule, param, '--ctstate')
    assert rule == ['--ctstate', 'ESTABLISHED,RELATED']



# Generated at 2022-06-20 22:07:57.662101
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = "LOG"
    jump = "ACCEPT"
    append_jump(rule, param, jump)
    assert rule[0] == "-j"
    assert rule[1] == jump


# Generated at 2022-06-20 22:08:03.434323
# Unit test for function append_param
def test_append_param():
    append_param_test = []
    append_param(append_param_test, "80", "--dport", False)
    append_param(append_param_test, ["80","81"], "--dport", True)
    assert append_param_test == ['--dport', '80', '--dport', '80', '--dport', '81']


# Generated at 2022-06-20 22:08:56.823486
# Unit test for function push_arguments
def test_push_arguments():
    test_params = {
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination': '192.168.123.0/255.255.255.0',
        'destination_port': '22',
        'jump': 'ACCEPT',
        'table': 'filter'}

    cmd = push_arguments('/usr/sbin/iptables', '-A', test_params)

    assert cmd == ['/usr/sbin/iptables',
                   '-t', 'filter',
                   '-A', 'INPUT',
                   '-p', 'tcp',
                   '-d', '192.168.123.0/255.255.255.0',
                   '--destination-port', '22',
                   '-j', 'ACCEPT']



# Generated at 2022-06-20 22:09:04.635835
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(
        argument_spec=dict(
            ip_version=dict(required=True, type='str', choices=['ipv4', 'ipv6']),
            chain=dict(required=True, type='str'),
            table=dict(required=False, type='str', choices=[
                       'filter', 'mangle', 'nat', 'raw', 'security'], default='filter')
        )
    )
    result = get_chain_policy(
        BINS[module.params['ip_version']],
        module,
        module.params)
    assert result == 'ACCEPT'
    module.exit_json(changed=False, meta=result)



# Generated at 2022-06-20 22:09:06.515049
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables',{'run_command':['iptables --version']}) == '1.4.21'



# Generated at 2022-06-20 22:09:17.960132
# Unit test for function push_arguments
def test_push_arguments():
    args_dict = dict(
        iptables_path='iptables',
        action='-A',
        params=dict(
            table='filter',
            chain='INPUT',
            rule_num='',
            protocol='tcp',
            destination='8.8.8.8',
            destination_port='22',
            log_prefix='LOGPREFIX',
            log_level='LOGLEVEL',
            ip_version='ipv4',
        )
    )
    command = push_arguments(**args_dict)

# Generated at 2022-06-20 22:09:20.128829
# Unit test for function append_rule
def test_append_rule():
    IPTABLES_BIN = 'iptables'
    CHAIN = 'INPUT'
    IP_VERSION = 'ipv4'
    cmd = [IPTABLES_BIN, '-t', IP_VERSION, '-A', CHAIN]
    assert cmd == push_arguments(IPTABLES_BIN, '-A', IP_VERSION, CHAIN)



# Generated at 2022-06-20 22:09:21.165919
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '5', '--wait')
    assert rule == ['--wait', '5']



# Generated at 2022-06-20 22:09:23.361982
# Unit test for function remove_rule
def test_remove_rule():
    pass



# Generated at 2022-06-20 22:09:24.671431
# Unit test for function flush_table
def test_flush_table():
    pass



# Generated at 2022-06-20 22:09:29.596659
# Unit test for function construct_rule
def test_construct_rule():
    module = AnsibleModule({
        'destination_port': '80',
        'jump': 'ACCEPT',
        'limit': '1/s',
        'limit_burst': '20',
        'log_prefix': 'TEST: ',
        'protocol': 'tcp',
        'reject_with': 'icmp-port-unreachable',
        'state': 'present',
        'table': 'filter',
        'ip_version': 'ipv4',
    })
    result = construct_rule(module)

# Generated at 2022-06-20 22:09:35.964194
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = '/usr/sbin/iptables'
    class MockModule:
        def run_command(self, cmd, check_rc=False):
            return 0, 'Chain INPUT (policy ACCEPT)\n', ''

    module = MockModule()
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        policy="ACCEPT",
        make_rule=False)
    result = get_chain_policy(iptables_path, module, params)
    assert result == 'ACCEPT'


# Generated at 2022-06-20 22:10:56.738909
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(None, None) == "1.4.21"



# Generated at 2022-06-20 22:10:59.391244
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, 5, '-w')
    assert len(rule) == 2
    assert rule[0] == '-w'
    assert rule[1] == '5'


# Generated at 2022-06-20 22:11:03.345293
# Unit test for function get_chain_policy
def test_get_chain_policy():
    policy = get_chain_policy(None, None, {"chain": "INPUT",
                                           "table": "filter"})
    assert policy == "ACCEPT"



# Generated at 2022-06-20 22:11:13.323135
# Unit test for function construct_rule