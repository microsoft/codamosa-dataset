

# Generated at 2022-06-20 22:01:56.312591
# Unit test for function append_rule
def test_append_rule():
    cmd = push_arguments('iptables', '-A', params)
    module.run_command(cmd, check_rc=True)
    return cmd


# Generated at 2022-06-20 22:02:02.698186
# Unit test for function main

# Generated at 2022-06-20 22:02:05.788720
# Unit test for function check_present
def test_check_present():
    assert check_present("/usr/sbin/iptables",
                         None,
                         dict(table='filter',
                              chain='INPUT',
                              jump='DROP')) == True
    assert check_present("/usr/sbin/iptables",
                         None,
                         dict(table='filter',
                              chain='INPUT',
                              jump='ACCEPT')) == False



# Generated at 2022-06-20 22:02:21.253777
# Unit test for function main
def test_main():
    host_name = socket.gethostname()
    localhost = socket.gethostbyname(host_name)
    pwd = os.getcwd()
    iptables_path = '/sbin/iptables'

# Generated at 2022-06-20 22:02:22.992924
# Unit test for function append_csv
def test_append_csv():
    rule = []
    params = ['INVALID', 'ESTABLISHED,RELATED']
    for param in params:
        append_csv(rule, param, '--ctstate')
        print(rule)


# Generated at 2022-06-20 22:02:25.234687
# Unit test for function append_match
def test_append_match():
    test_match = ['-m', 'comment']
    actual_match = []
    append_match(actual_match, 'comment', 'comment')
    assert set(test_match) == set(actual_match)
    actual_match = []
    append_match(actual_match, None, 'comment')
    assert not actual_match



# Generated at 2022-06-20 22:02:31.573807
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, None, '--protocol', False)
    assert rule == []
    append_param(rule, ['!', 'tcp'], '--protocol', False)
    assert rule == ['!', '--protocol', 'tcp']
    append_param(rule, ['!', 'tcp'], '--protocol', True)
    assert rule == ['!', '--protocol', 'tcp', '!', '--protocol', 'tcp']



# Generated at 2022-06-20 22:02:42.442942
# Unit test for function insert_rule
def test_insert_rule():
    x = push_arguments("iptables", "-I", {"table":"filter","chain":"INPUT","protocol":"tcp","jump":None,"reject_with":"tcp-reset","wait":"","ip_version":"ipv4","rule_num":"5"})
    assert x == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '-j', 'REJECT', '--reject-with', 'tcp-reset']


# Generated at 2022-06-20 22:02:46.767661
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['ESTABLISHED', 'RELATED'], '--ctstate')
    assert rule == ['--ctstate', 'ESTABLISHED,RELATED']
    rule = []
    append_csv(rule, ['ACCEPT', 'DROP'], '-j')
    assert rule == ['-j', 'ACCEPT,DROP']



# Generated at 2022-06-20 22:02:57.032290
# Unit test for function insert_rule
def test_insert_rule():
    insert_rule('iptables', None, {'table': 'nat', 'chain': 'PREROUTING', 'in_interface': 'eth0', 'protocol': 'tcp', 'match': 'tcp', 'destination_port': '80', 'jump': 'REDIRECT', 'to_ports': '8600', 'comment': 'Redirect web traffic to port 8600', 'ip_version': 'ipv4', 'state': 'present', 'reject_with': None, 'icmp_type': None, 'flush': False, 'policy': None, 'wait': None, 'rule_num': '5'})



# Generated at 2022-06-20 22:03:21.828575
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['ESTABLISHED', 'RELATED'], '--ctstate')
    assert rule == ['--ctstate', 'ESTABLISHED,RELATED']

    rule = []
    append_csv(rule, 'ESTABLISHED', '--ctstate')
    assert rule == ['--ctstate', 'ESTABLISHED']

    rule = []
    append_csv(rule, None, '--ctstate')
    assert rule == []



# Generated at 2022-06-20 22:03:30.770628
# Unit test for function construct_rule

# Generated at 2022-06-20 22:03:42.844216
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    action = '-I'

# Generated at 2022-06-20 22:03:46.076186
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    assert append_tcp_flags == append_tcp_flags



# Generated at 2022-06-20 22:03:53.353087
# Unit test for function get_chain_policy
def test_get_chain_policy():
    from ansible.module_utils.common.process import get_bin_path
    module = type('test_module', (object,), {})
    module.run_command = lambda cmd, check_rc=True: (0, "Chain INPUT (policy ACCEPT)\n", "")
    module.exit_json = lambda changed: True
    params = dict(chain='INPUT')
    iptables_path = get_bin_path('iptables')
    assert get_chain_policy(iptables_path, module, params) == 'ACCEPT'



# Generated at 2022-06-20 22:03:58.967339
# Unit test for function insert_rule
def test_insert_rule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 22:04:03.994641
# Unit test for function flush_table
def test_flush_table():
    params = dict(
        table='filter',
        chain='INPUT'
    )
    cmd = push_arguments('iptables', '-F', params, make_rule=False)
    assert cmd == ['iptables', '-t', 'filter', '-F', 'INPUT']



# Generated at 2022-06-20 22:04:14.358504
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec=dict(
        table=dict(
            default='filter',
            choices=['filter', 'nat', 'mangle', 'raw', 'security'],
            type='str',
        ),
        chain=dict(required=True, type='str'),
        rule_num=dict(required=True, type='int'),
    ))
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num='1'
    )
    iptables_path = BINS['ipv4']
    insert_rule(iptables_path, module, params)



# Generated at 2022-06-20 22:04:19.632112
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {}
    param['flags'] = ['ACK','RST','SYN','FIN']
    param['flags_set'] = ['ACK', 'SYN']
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags',  'ACK,RST,SYN,FIN', 'ACK,SYN']



# Generated at 2022-06-20 22:04:29.850291
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    result = []
    tests = [
        (dict(flags='ALL', flags_set=['ACK', 'RST', 'SYN', 'FIN']), ['-m', 'tcp', '--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']),
        (dict(flags='ALL', flags_set=None), ['-m', 'tcp', '--tcp-flags', 'ALL']),
        (dict(flags=None, flags_set='ACK,RST,SYN,FIN'), ['-m', 'tcp', '--tcp-flags', 'ACK,RST,SYN,FIN']),
        (dict(flags=None, flags_set=None), ['-m', 'tcp']),
        (dict(), ['-m', 'tcp']),
    ]


# Generated at 2022-06-20 22:04:52.199156
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, '!google.com', '-m', False)
    assert rule == ['!', '-m', 'google.com']
    rule = []
    append_param(rule, None, '-m', False)
    assert rule == []
    rule = []
    append_param(rule, ['-m', '!test.com'], '-m', True)
    assert rule == ['-m', '-m', '-m', '!test.com']



# Generated at 2022-06-20 22:05:03.772872
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = 'iptables'
    table = 'filter'
    chain = 'test'
    source = '192.168.1.1'
    jump = 'ACCEPT'

# Generated at 2022-06-20 22:05:08.370953
# Unit test for function insert_rule
def test_insert_rule():
    params = {
        'chain': 'INPUT',
        'ip_version': 'ipv4',
        'protocol': 'tcp',
        'jump': 'ACCEPT',
        'destination_port': '8080',
        'rule_num': '5'
    }
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '-j', 'ACCEPT', '--dport', '8080']



# Generated at 2022-06-20 22:05:19.985638
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test', '--test', False)
    assert ['--test', 'test'] == rule
    rule = []
    append_param(rule, None, '--test', False)
    assert [] == rule
    rule = []
    append_param(rule, '!test', '--test', False)
    assert ['!', '--test', 'test'] == rule
    rule = []
    append_param(rule, ['test', 'test2'], '--test', True)
    assert ['--test', 'test', '--test', 'test2'] == rule
    rule = []
    append_param(rule, ['!test', '!test2'], '--test', True)

# Generated at 2022-06-20 22:05:22.428826
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']



# Generated at 2022-06-20 22:05:23.687062
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--match', False)
    assert (rule == ['--match'])



# Generated at 2022-06-20 22:05:36.224153
# Unit test for function append_rule
def test_append_rule():
    ipv4_argv = ['/usr/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-s', '192.168.1.1', '-j', 'ACCEPT']
    ipv6_argv = ['/usr/sbin/ip6tables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-s', '192.168.1.1', '-j', 'ACCEPT']

    # Test IPv4 without fail_keyword

# Generated at 2022-06-20 22:05:47.612544
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='mangle',
        ip_version='ipv4',
        chain='OUTPUT',
        protocol='tcp',
        tcp_flags={
            'flags': 'ALL',
            'flags_set': ['ACK', 'RST', 'SYN', 'FIN'],
        },
    )
    cmd = push_arguments('/sbin/iptables', '-A', params)
    assert cmd == [
        '/sbin/iptables',
        '-t', 'mangle',
        '-A', 'OUTPUT',
        '-p', 'tcp',
        '--tcp-flags', 'ALL,ACK,RST,SYN,FIN',
    ]
    assert push_arguments('/sbin/iptables', '-D', params) == cmd



# Generated at 2022-06-20 22:05:49.567507
# Unit test for function remove_rule
def test_remove_rule():
    assert utils.remove_rule(iptables_path, module, params) == True



# Generated at 2022-06-20 22:05:56.514801
# Unit test for function construct_rule
def test_construct_rule():
    # if no parameter is passed, module should just exit
    # without sending anything to the kernel
    p = {}
    assert construct_rule(p) == []

    # set mock return value
    # and see if it gets appended to the rule
    p = dict(protocol='tcp',
             source='192.168.0.1',
             match='limit',
             comment='Test')
    assert construct_rule(p) == [
        '-p', 'tcp',
        '-s', '192.168.0.1',
        '-m', 'limit',
        '-m', 'comment',
        '--comment', 'Test']

    # if param is none, it should not be appended

# Generated at 2022-06-20 22:06:22.647107
# Unit test for function main

# Generated at 2022-06-20 22:06:27.993454
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(name='ansible.builtin.iptables', check_invalid_arguments=False)
    params = dict(
        table='nat',
        chain='PREROUTING',
        in_interface='eth0',
        protocol='tcp',
        match='tcp',
        destination_port='80',
        jump='REDIRECT',
        to_ports='8600',
    )
    cmd = push_arguments('iptables', module, params)
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-20 22:06:31.358209
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, "test", "test")
    assert rule == ['-j', 'test']



# Generated at 2022-06-20 22:06:37.313993
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule({'table':'nat', 'chain':'INPUT'})
    flush_table('/sbin/iptables', module, {'table':'nat', 'chain':'INPUT', 'ip_version':'ipv4'})
    flush_table('/sbin/iptables', module, {'table':'nat', 'chain':'INPUT', 'ip_version':'ipv6'})



# Generated at 2022-06-20 22:06:39.586043
# Unit test for function check_present
def test_check_present():
    module = object()
    module.run_command = lambda *args, **kwargs: (1, '', '')
    assert check_present('iptables', module, dict(table='filter', chain='INPUT')) is False



# Generated at 2022-06-20 22:06:45.623305
# Unit test for function flush_table
def test_flush_table():
    iptables_path = 'iptables'
    module = AnsibleModule(
        argument_spec = dict(
            table = dict(type='str', default='filter'),
            chain = dict(type='str'),
            flush = dict(type='bool', default=False),
        )
    )
    params = module.params
    flush_table(iptables_path, module, params)



# Generated at 2022-06-20 22:06:51.206051
# Unit test for function construct_rule

# Generated at 2022-06-20 22:06:56.779886
# Unit test for function main

# Generated at 2022-06-20 22:06:59.363680
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None,None,{'chain': 'ACCEPT'}) == 'ACCEPT'
    assert get_chain_policy(None,None,{'chain': 'DROP'}) == 'DROP'



# Generated at 2022-06-20 22:07:02.808137
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(['-p', 'tcp'], 'match', '--syn', True) == ['-p', 'tcp', '--syn']
    assert append_match_flag(['-p', 'tcp'], 'negate', '--syn', True) == ['-p', 'tcp', '!', '--syn']
    assert append_match_flag(['-p', 'tcp'], 'match', '--syn', False) == ['-p', 'tcp']
    assert append_match_flag(['-p', 'tcp'], 'negate', '--syn', False) == ['-p', 'tcp']

# Generated at 2022-06-20 22:07:43.908097
# Unit test for function construct_rule

# Generated at 2022-06-20 22:07:55.817049
# Unit test for function main

# Generated at 2022-06-20 22:08:02.073762
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/bin/iptables'
    module = 'module'
    args = dict(
        table='nat',
        chain='OUTPUT',
        protocol='tcp',
        source='2.2.2.2',
        destination='0.0.0.0/0',
        destination_port='80',
        jump='REDIRECT',
        to_ports='8080',
        ip_version='ipv4',
        action='remove',
        force='yes'
    )
    params = get_module_params(args)
    cmd = remove_rule(iptables_path, module, params)

# Generated at 2022-06-20 22:08:08.212521
# Unit test for function remove_rule
def test_remove_rule():
    class Obj(object):
        def __init__(self):
            self.rc=0

    iptables_path = 'iptables'
    module = Obj()
    params = {
        'chain': 'INPUT',
        'table': 'filter'
    }
    cmd = push_arguments(iptables_path, '-D', params)
    assert cmd == ['iptables', '-t', 'filter', '-D', 'INPUT']
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-20 22:08:14.717770
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        jump='ACCEPT',
        )
    append_rule('/sbin/iptables', module, params)



# Generated at 2022-06-20 22:08:20.377982
# Unit test for function append_jump
def test_append_jump():
    rule = []
    jump="ACCEPT"
    append_jump(rule, param=True, jump=jump)
    assert rule == ['-j', jump]
    rule = []
    append_jump(rule, param=False, jump=jump)
    assert rule == []
    rule = []
    append_jump(rule, param=True, jump=None)
    assert rule == []


# Generated at 2022-06-20 22:08:23.531145
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, 'match')
    assert rule == ['-m', 'match']
    rule = []
    append_match(rule, False, 'match')
    assert rule == []


# Generated at 2022-06-20 22:08:32.216257
# Unit test for function construct_rule
def test_construct_rule():
    rule = construct_rule({
        'protocol': 'tcp',
        'source': '127.0.0.1',
        'destination': '192.168.0.0/16',
        'destination_port': '22',
        'jump': 'ACCEPT',
    })
    assert rule == [
        '-p', 'tcp',
        '-s', '127.0.0.1',
        '-d', '192.168.0.0/16',
        '--dport', '22',
        '-j', 'ACCEPT',
    ]

    # Jump will be ignored if reject_with is set

# Generated at 2022-06-20 22:08:36.007746
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("", "", dict(policy=None, chain="INPUT")) == "ACCEPT"



# Generated at 2022-06-20 22:08:45.316302
# Unit test for function insert_rule

# Generated at 2022-06-20 22:10:00.392473
# Unit test for function append_param
def test_append_param():
    assert append_param([], 'all', '-j', False) == ['-j', 'all']
    assert append_param([], '10/m', '--limit', False) == ['--limit', '10/m']
    assert append_param([], '!10/m', '--limit', False) == ['!', '--limit', '10/m']
    assert append_param([], ['10/m', '20/m'], '--limit', True) == ['--limit', '10/m', '--limit', '20/m']
    assert append_param([], ['!10/m', '20/m'], '--limit', True) == ['!', '--limit', '10/m', '--limit', '20/m']



# Generated at 2022-06-20 22:10:05.622773
# Unit test for function push_arguments

# Generated at 2022-06-20 22:10:17.542011
# Unit test for function check_present
def test_check_present():
    module_args = dict(
        table='raw',
        chain='PREROUTING',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        rule_num=5,
        state='present',
    )
    module = AnsibleModule(argument_spec=dict())
    module.params = module_args
    cmd = push_arguments('ipv4', '-C', module.params)
    assert cmd == [
        'iptables', '-t', 'raw', '-C', 'PREROUTING', '-p', 'tcp',
        '--dport', '8080', '-j', 'ACCEPT']
    cmd = push_arguments('ipv4', '-I', module.params)

# Generated at 2022-06-20 22:10:19.055517
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = ['iptables','-P','INPUT','DROP']
    assert cmd == set_chain_policy('iptables', 'module', 'params')



# Generated at 2022-06-20 22:10:23.475911
# Unit test for function insert_rule
def test_insert_rule():
    module = None
    iptables_path = 'iptables'

# Generated at 2022-06-20 22:10:26.101685
# Unit test for function flush_table
def test_flush_table():
    module = _prepare_module(dict(
        flush=True,
        chain='INPUT',
    ))
    cmd = push_arguments('/sbin/iptables', '-F', module.params, make_rule=False)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-F', 'INPUT']



# Generated at 2022-06-20 22:10:26.646373
# Unit test for function set_chain_policy
def test_set_chain_policy():
    pass



# Generated at 2022-06-20 22:10:33.739283
# Unit test for function append_rule
def test_append_rule():
    append_rule(
        iptables_path='/sbin/iptables', module='ansible.builtin.iptables', params={
            'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp',
            'source': '127.0.0.1', 'action': 'append', 'state': 'present',
            'jump': 'DROP', 'ip_version': 'ipv4'})



# Generated at 2022-06-20 22:10:38.955901
# Unit test for function insert_rule

# Generated at 2022-06-20 22:10:48.205966
# Unit test for function append_wait
def test_append_wait():
    rule = []
    # wait=1
    rule = []
    append_wait(rule, '1', '--wait')
    assert rule == ['--wait', '1']
    # wait=10
    rule = []
    append_wait(rule, '10', '--wait')
    assert rule == ['--wait', '10']
    # wait=10.1
    rule = []
    append_wait(rule, '10.1', '--wait')
    assert rule == ['--wait', '10.1']

