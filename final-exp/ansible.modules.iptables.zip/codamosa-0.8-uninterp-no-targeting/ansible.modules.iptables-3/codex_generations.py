

# Generated at 2022-06-20 22:02:02.013431
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    tcp_flags = dict(flags=['ALL', 'ESTABLISHED'], flags_set=['ACK', 'SYN'])
    append_tcp_flags(rule, tcp_flags, '--tcp-flags')
    assert rule == ['--tcp-flags','ALL,ESTABLISHED','ACK,SYN']
    rule = []
    tcp_flags = dict(flags=['ALL'], flags_set=['ACK', 'SYN'])
    append_tcp_flags(rule, tcp_flags, '--tcp-flags')
    assert rule == ['--tcp-flags','ALL','ACK,SYN']
    rule = []
    tcp_flags = dict(flags=['ALL', 'ESTABLISHED'], flags_set=['ACK'])

# Generated at 2022-06-20 22:02:09.100971
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_rule = []
    test_param = dict(
        flags=['ALL'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN'],
    )
    test_flag = '--tcp-flags'
    append_tcp_flags(test_rule, test_param, test_flag)
    assert test_rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-20 22:02:11.075377
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule({'ip_version': 'ipv4'})
    assert check_present('iptables', module, {'ip_version': 'ipv4', 'chain': 'INPUT', 'action': 'append', 'table': 'filter'})



# Generated at 2022-06-20 22:02:20.509736
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, None, "")
    assert len(rule) == 0
    append_tcp_flags(rule, {}, "")
    assert len(rule) == 0
    append_tcp_flags(rule, {'flags': ['ACK', 'RST', 'SYN', 'FIN']}, "")
    assert len(rule) == 2
    assert rule[1] == ','.join(['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, {'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}, "")
    assert len(rule) == 3
    assert rule[2] == ','.join(['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_

# Generated at 2022-06-20 22:02:26.585062
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    params = dict(table='filter', chain='INPUT', protocol='tcp', destination_port='8080')
    return push_arguments(iptables_path, '-A', params)
# End of append_rule



# Generated at 2022-06-20 22:02:32.649510
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4',
        policy='DROP',
        wait=None
    )
    module = AnsibleModule(argument_spec=dict())
    set_chain_policy('iptables', module, params)



# Generated at 2022-06-20 22:02:35.498431
# Unit test for function append_param
def test_append_param():
    rule_array = []
    param = "test"
    flag = "flag"
    assert append_param(rule_array, param, flag, False) == None
    assert rule_array == ['flag', "test"]



# Generated at 2022-06-20 22:02:37.158699
# Unit test for function append_match
def test_append_match():
  rule = []
  append_match(rule, True, 'test')
  assert rule == ['-m', 'test']
  append_match(rule, False, 'test')
  assert rule == ['-m', 'test']


# Generated at 2022-06-20 22:02:48.141089
# Unit test for function insert_rule

# Generated at 2022-06-20 22:02:59.500493
# Unit test for function construct_rule
def test_construct_rule():
    parameters = {
        'protocol': 'tcp',
        'source': '127.0.0.1',
        'destination': '127.0.0.1',
        'set_counters': '1:2',
        'source_port': '80',
        'destination_port': '80',
        'jump': 'ACCEPT',
        'ip_version': 'ipv6',
        'limit': '3/second',
        'limit_burst': '10',
        'uid_owner': 'user',
        'gid_owner': 'group',
        'comment': 'this is a test comment',
        'icmp_type': 'echo-request',
        'reject_with': 'tcp-reset',
    }

# Generated at 2022-06-20 22:03:15.568742
# Unit test for function append_param
def test_append_param():
    # append a param with flag
    assert append_param([], 'a', '-b', False) == ['-b', 'a']
    assert append_param([], '!a', '-b', False) == ['!', '-b', 'a']
    # append a list param with flag
    assert append_param([], ['a', 'b'], '-b', True) == ['-b', 'a', '-b', 'b']
    assert append_param([], ['!a', 'b'], '-b', True) == ['!', '-b', 'a', '-b', 'b']



# Generated at 2022-06-20 22:03:25.769246
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'iptables'
    action = '-A'
    module = 'ansible.builtin.iptables'
    source = '10.10.10.0'
    destination = '8.8.8.0'
    protocol = 'tcp'
    destination_port = '22'
    comment = 'Allow SSH access'
    params = dict(
        source=source,
        destination=destination,
        protocol=protocol,
        destination_port=destination_port,
        action=action,
        comment=comment,
        jump='ACCEPT',
        chain='INPUT'
    )
    append_rule(iptables_path, module, params)

test_append_rule()



# Generated at 2022-06-20 22:03:28.318207
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', '1.4.21')
    assert get_iptables_version('iptables', '1.6.0')
    assert get_iptables_version('iptables', '1.6.1')


# Generated at 2022-06-20 22:03:30.515605
# Unit test for function append_jump
def test_append_jump():
    assert append_jump(['iptables', '-A'], 'ACCEPT', 'ACCEPT') == ['iptables', '-A', '-j', 'ACCEPT']
    assert append_jump(['iptables', '-A'], 'DROP', 'DROP') == ['iptables', '-A', '-j', 'DROP']



# Generated at 2022-06-20 22:03:33.405011
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule
    params = dict(
        chain='INPUT',
        source='192.168.10.0/24',
        jump='DROP',
        table='filter'
    )
    append_rule(iptables_path, module, params)



# Generated at 2022-06-20 22:03:38.473739
# Unit test for function remove_rule
def test_remove_rule():
    from ansible.module_utils.basic import AnsibleModule
    params = dict(
        chain="INPUT",
        protocol="tcp",
        destination_port="22",
        ctstate=["NEW"],
        syn="match",
        jump="ACCEPT",
        comment="Accept new SSH connections.",
        table='filter'
        )
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec = dict())
    rule = construct_rule(params)
    cmd = push_arguments(iptables_path, '-D', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-D', 'INPUT'] + rule



# Generated at 2022-06-20 22:03:49.548468
# Unit test for function main
def test_main():
    ip_version = 'ipv4'
    iptables_path = module.get_bin_path(BINS[ip_version], True)
    # Check if chain option is required
    if args['flush'] is False and args['chain'] is None:
        module.fail_json(msg="Either chain or flush parameter must be specified.")

    if module.params.get('log_prefix', None) or module.params.get('log_level', None):
        if module.params['jump'] is None:
            module.params['jump'] = 'LOG'
        elif module.params['jump'] != 'LOG':
            module.fail_json(msg="Logging options can only be used with the LOG jump target.")

    # Check if wait option is supported

# Generated at 2022-06-20 22:03:53.500741
# Unit test for function append_match_flag
def test_append_match_flag():
    rule=[]
    flag='--syn'
    append_match_flag(rule, 'match', flag, True) 
    assert '--syn' in rule
    flag='--syn'
    append_match_flag(rule, 'negate', flag, True)  
    assert '--syn' in rule

# Generated at 2022-06-20 22:04:09.727729
# Unit test for function append_match_flag
def test_append_match_flag():
    parameters = [
        {'param': 'match', 'flag': '--udp', 'negatable': False},
        {'param': 'negate', 'flag': '--udp', 'negatable': True},
        {'param': 'match', 'flag': '--syn', 'negatable': True},
        {'param': 'negate', 'flag': '--syn', 'negatable': True},
        {'param': 'match', 'flag': '--syn', 'negatable': False},
        {'param': 'negate', 'flag': '--syn', 'negatable': False},
        {'param': 'match', 'flag': '--multiport', 'negatable': False},
    ]

# Generated at 2022-06-20 22:04:11.679844
# Unit test for function insert_rule
def test_insert_rule():
    assert 1==1, "Test case not implemented!"



# Generated at 2022-06-20 22:04:26.253693
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'ACCEPT'
    jump = param
    rule.extend(['-j', jump])
    append_jump(rule, param, jump)
    assert rule == ['-j', 'ACCEPT']

    rule = []
    param = None
    jump = param
    append_jump(rule, param, jump)
    assert rule == []



# Generated at 2022-06-20 22:04:28.648028
# Unit test for function append_match
def test_append_match():
  test_rule = ['test']
  append_match(test_rule, 'match', 'test')
  assert test_rule == ['test', '-m', 'test']



# Generated at 2022-06-20 22:04:39.332983
# Unit test for function check_present
def test_check_present():
  FROM_PRESENT = """Chain INPUT (policy DROP)
target     prot opt source               destination
ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0            ctstate RELATED,ESTABLISHED
ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           
accept     all  --  0.0.0.0/0            0.0.0.0/0           
"""

# Generated at 2022-06-20 22:04:46.051518
# Unit test for function append_match_flag
def test_append_match_flag():
    rule1 = []
    rule2 = []
    append_match_flag(rule1, 'match', '--syn', True)
    append_match_flag(rule2, 'negate', '--syn', True)
    assert rule1 == ['--syn']
    assert rule2 == ['!', '--syn']


# Generated at 2022-06-20 22:04:48.898110
# Unit test for function append_jump
def test_append_jump():
    temp_rule = list()
    rule = ["-j", "DROP"]
    append_jump(temp_rule, "DROP", "DROP")
    assert rule == temp_rule



# Generated at 2022-06-20 22:04:58.945960
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = None
    iptables_path = BINS['ipv4']
    params = {
        'chain': 'INPUT',
        'table': 'filter',
    }
    policy = get_chain_policy(iptables_path, module, params)
    assert policy in ('ACCEPT', 'DROP')
    params['chain'] = 'OUTPUT'
    policy = get_chain_policy(iptables_path, module, params)
    assert policy in ('ACCEPT', 'DROP')
    params['chain'] = 'FORWARD'
    policy = get_chain_policy(iptables_path, module, params)
    assert policy in ('ACCEPT', 'DROP')
    params['chain'] = 'NON_EXISTENT_CHAIN'

# Generated at 2022-06-20 22:05:05.241709
# Unit test for function remove_rule
def test_remove_rule():
    module = {}
    params = {'table': 'filter', 'chain': 'INPUT', 'wait': '5'}
    cmd = push_arguments('/sbin/iptables', '-D', params)
    return cmd



# Generated at 2022-06-20 22:05:13.171186
# Unit test for function get_chain_policy
def test_get_chain_policy():
    chain_header = "Chain FORWARD (policy DROP)"
    result = re.search(r'\(policy ([A-Z]+)\)', chain_header)
    assert result.group(1) == "DROP"

# end of unit test



# Generated at 2022-06-20 22:05:18.977155
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    with pytest.raises(SystemExit) as cm:
        append_match_flag(rule, 'invalid', '--syn', True)
    assert cm.value.args[0] == 1
    assert rule == []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    del rule[:]
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    del rule[:]
    append_match_flag(rule, None, '--syn', True)
    assert rule == []
    del rule[:]
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    del rule[:]

# Generated at 2022-06-20 22:05:24.819502
# Unit test for function insert_rule
def test_insert_rule():
    import os
    import sys
    import unittest
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))))
    from lib.check_iptables_rules import CheckRules
    class TestInsertRule(unittest.TestCase):
        def setUp(self):
            self.param = dict()
            self.param['table'] = 'filter'
            self.param['chain'] = 'INPUT'
            self.param['protocol'] = 'tcp'
            self.param['destination_port'] = 22
            self.param['ctstate'] = 'NEW'
            self.param['syn'] = 'match'

# Generated at 2022-06-20 22:05:44.099221
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, {'chain': 'INPUT', 'policy': 'DROP'}) is None
    assert get_chain_policy('iptables', None, {'chain': 'OUTPUT', 'policy': 'ACCEPT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', None, {'chain': 'FORWARD', 'policy': 'DROP'}) == 'DROP'



# Generated at 2022-06-20 22:05:55.214116
# Unit test for function get_chain_policy
def test_get_chain_policy():
    class FakeModule:
        def __init__(self, out):
            self.out = out
        def run_command(self, cmd, check_rc=False):
            return (0, self.out, '')
    module = FakeModule('Chain INPUT (policy DROP)\n')
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'policy': None
    }
    result = get_chain_policy('', module, params)
    assert result == 'DROP'



# Generated at 2022-06-20 22:05:57.307678
# Unit test for function append_match
def test_append_match():
    assert append_match('-m','','') == ''



# Generated at 2022-06-20 22:06:03.605297
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']



# Generated at 2022-06-20 22:06:10.637059
# Unit test for function append_param
def test_append_param():
    rule = []
    param = '100'
    flag = '--dport'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['--dport', '100']

    rule = []
    param = None
    flag = '--dport'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == []

    rule = []
    param = ['80', '443']
    flag = '--dport'
    is_list = True
    append_param(rule, param, flag, is_list)
    assert rule == ['--dport', '80', '--dport', '443']



# Generated at 2022-06-20 22:06:21.257638
# Unit test for function remove_rule
def test_remove_rule():
    rule = construct_rule({'table': 'filter',
                           'chain': 'INPUT',
                           'protocol': 'tcp',
                           'destination_port': '80',
                           'ctstate': 'ESTABLISHED',
                           'syn': 'match',
                           'jump': 'ACCEPT',
                           'comment': 'Accept new SSH connections.'})

# Generated at 2022-06-20 22:06:32.165463
# Unit test for function main
def test_main():
    # construct a dummy module to pass to main()
    module = AnsibleModule(dict())
    # also construct a dummy ansible-module-args$ object

# Generated at 2022-06-20 22:06:35.634730
# Unit test for function append_match
def test_append_match():
    rule = []
    match = 'state'
    assert([] == rule)
    append_match(rule, True, match)
    assert(['-m', match] == rule)
    append_match(rule, False, match)
    assert(['-m', match, '!', '-m', match] == rule)


# Generated at 2022-06-20 22:06:39.480675
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = 3
    flag = '-w'
    append_wait(rule, param, flag)
    assert rule == ['-w', param]



# Generated at 2022-06-20 22:06:42.937119
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp',
              'destination_port': '22', 'comment': 'test', 'jump': 'ACCEPT'}
    remove_rule(iptables_path, module, params)



# Generated at 2022-06-20 22:07:14.941100
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule=["-t","filter","-A","INPUT","-p","tcp","-m","tcp"]
    flags=dict(flags=['ACK', 'RST', 'SYN', 'FIN'],flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule,"","--tcp-flags")
    append_tcp_flags(rule,flags,"--tcp-flags")
    assert (rule==["-t","filter","-A","INPUT","-p","tcp","-m","tcp","--tcp-flags","ACK,FIN,RST,SYN","ACK,FIN,RST,SYN"])
    rule=["-t","filter","-A","INPUT","-p","tcp","-m","tcp"]

# Generated at 2022-06-20 22:07:25.883758
# Unit test for function append_rule
def test_append_rule():
    from ansible.module_utils.ansible_modlib.test.mock import MockAnsibleModule
    from ansible.module_utils.ansible_modlib.test.mock import MockAnsibleModuleArgs
    from ansible.module_utils.ansible_modlib.test.mock import MockAnsibleModuleExit
    import sys
    ipset_path="/sbin/ipset"

# Generated at 2022-06-20 22:07:31.375237
# Unit test for function append_param
def test_append_param():
    rule=[]
    append_param(rule, ['!', 'test'], 'test1', False)
    assert rule == ['!', 'test1', 'test']


# Generated at 2022-06-20 22:07:43.495980
# Unit test for function append_param
def test_append_param():
    rule = []
    params = {
        'chain': 'FORWARD',
        'in_interface': 'eth0',
        'out_interface': None,
        'source': '192.168.1.2',
        'destination': '192.168.2.2',
        'protocol': 'tcp',
        'ctstate': None,
        'tcp_flags': None,
        'syn': None,
        'comment': None,
    }

# Generated at 2022-06-20 22:07:48.978370
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = [1,2,3]
    flag = "--testflag"
    expected_result = ['--testflag', '1,2,3']
    append_csv(rule, param, flag)
    assert rule == expected_result



# Generated at 2022-06-20 22:07:55.259599
# Unit test for function get_iptables_version
def test_get_iptables_version():
    version1 = get_iptables_version(
        iptables_path="/sbin/iptables",
        module=obj
    )
    version2 = get_iptables_version(
        iptables_path="/usr/sbin/iptables",
        module=obj
    )
    version3 = get_iptables_version(
        iptables_path="/sbin/ip6tables",
        module=obj
    )



# Generated at 2022-06-20 22:07:55.700269
# Unit test for function append_param
def test_append_param():
    return


# Generated at 2022-06-20 22:08:03.859749
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    result = ['--tcp-flags', 'ACK,FIN,PSH,RST,SYN', 'ACK,FIN,PSH,RST,SYN']
    data = dict(
        flags=['ACK', 'FIN', 'PSH', 'RST', 'SYN'],
        flags_set=['ACK', 'FIN', 'PSH', 'RST', 'SYN'],
    )
    rule = []
    append_tcp_flags(rule, data, '--tcp-flags')
    assert result == rule



# Generated at 2022-06-20 22:08:05.414300
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/iptables', None) == '1.4.21\n'



# Generated at 2022-06-20 22:08:10.166615
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, "NEW", "NEW")
    assert rule == ['-j', 'NEW']
    rule = []
    append_jump(rule, "NEW,OLD", "NEW,OLD")
    assert rule == ['-j', 'NEW,OLD']
    rule = []
    append_jump(rule, None, "NEW")
    assert rule == []



# Generated at 2022-06-20 22:09:05.672501
# Unit test for function push_arguments
def test_push_arguments():
    assert(push_arguments('/usr/bin/iptables', '-A', {'table': 'nat', 'chain': 'PREROUTING', 'protocol': 'tcp', 'destination_port': '80', 'jump': 'REDIRECT', 'to_ports': '8600', 'ip_version': 'ipv4'}, False) == ['/usr/bin/iptables', '-t', 'nat', '-A', 'PREROUTING', '-p', 'tcp', '--dport', '80', '-j', 'REDIRECT', '--to-ports', '8600'])

# Generated at 2022-06-20 22:09:10.288478
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, None, '')
    assert len(rule) == 0

    rule = []
    append_tcp_flags(rule, {}, '')
    assert len(rule) == 0

    rule = []
    append_tcp_flags(rule, {'flags': ['all']}, '')
    assert len(rule) == 0

    rule = []
    append_tcp_flags(rule, {'flags_set': ['ack', 'syn']}, '')
    assert len(rule) == 0

    rule = []
    append_tcp_flags(rule, {'flags': ['all'], 'flags_set': ['ack', 'syn']}, '!')
    assert len(rule) == 3
    assert rule[1] == '! --tcp-flags'

# Generated at 2022-06-20 22:09:12.984891
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = ['1', '2', '3']
    append_tcp_flags(rule, {'flags': ['FIN', 'SYN', 'RST', 'ACK'], 'flags_set': ['ALL']}, '--tcp-flags')
    assert rule == ['1', '2', '3', '--tcp-flags', 'FIN,SYN,RST,ACK', 'ALL']



# Generated at 2022-06-20 22:09:15.964192
# Unit test for function append_match
def test_append_match():
    rule=[]
    append_match(rule, 'tcp', 'tcp')
    assert rule == ['-m', 'tcp']
    rule.pop()
    rule.pop()
    append_match(rule, None, 'tcp')
    assert rule == []



# Generated at 2022-06-20 22:09:31.843438
# Unit test for function push_arguments
def test_push_arguments():
    params = {'chain': 'FORWARD', 'comment': None, 'flush': None, 'goto': None, 'ip_version': 'ipv4', 'in_interface': None, 'jump': None, 'limit': None, 'limit_burst': None, 'match': None, 'match_set': None, 'match_set_flags': None, 'protocol': None, 'reject_with': None, 'set_counters': None, 'source': None, 'source_port': None, 'table': 'filter', 'tcp_flags': None, 'destination': None, 'destination_port': None, 'tee': None, 'to_destination': None, 'to_ports': None, 'to_source': None, 'uid_owner': None, 'wait': None, 'gid_owner': None}
    assert push_arguments

# Generated at 2022-06-20 22:09:35.728945
# Unit test for function append_jump
def test_append_jump():
    rule=["iptables"]
    param='ACCEPT'
    jump='ACCEPT'
    expected_rule=["iptables","-j","ACCEPT"]
    append_jump(rule,param,jump)
    assert rule==expected_rule
# Test function is completed



# Generated at 2022-06-20 22:09:43.394507
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5'
        )
    iptables_path = '/sbin/iptables'
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT','5', '-w', '-p', 'tcp', '--destination-port', '8080', '-j', 'ACCEPT']


# Generated at 2022-06-20 22:09:54.980126
# Unit test for function insert_rule

# Generated at 2022-06-20 22:10:00.031365
# Unit test for function flush_table
def test_flush_table():
    iptables_path = 'iptables'
    module = 'INPUT'
    params = '-F'
    make_rule = True

# Generated at 2022-06-20 22:10:01.699347
# Unit test for function append_wait
def test_append_wait():
    assert append_wait(['iptables'], '5', '--wait') == ['iptables', '--wait', '5']



# Generated at 2022-06-20 22:11:09.522082
# Unit test for function remove_rule
def test_remove_rule():
    from ansible.module_utils.basic import AnsibleModule
    iptables_path = '/sbin/iptables'