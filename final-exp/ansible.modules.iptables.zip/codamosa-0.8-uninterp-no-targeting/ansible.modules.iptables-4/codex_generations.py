

# Generated at 2022-06-20 22:01:42.382643
# Unit test for function insert_rule

# Generated at 2022-06-20 22:01:45.173031
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ["ESTABLISHED", "RELATED"]
    flag = "--ctstate"
    append_csv(rule, param, flag)

# Generated at 2022-06-20 22:01:48.691107
# Unit test for function set_chain_policy
def test_set_chain_policy():
    '''
    Tests set_chain_policy function with different values
    '''
    print (set_chain_policy('iptables', 'module', {'table':'filter', 'chain':'INPUT', 'policy':'ACCEPT'}))



# Generated at 2022-06-20 22:02:00.445102
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'iptables'

# Generated at 2022-06-20 22:02:01.660366
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', {}, dict(ip_version='ipv4', chain='INPUT')) == 0



# Generated at 2022-06-20 22:02:12.464177
# Unit test for function append_match
def test_append_match():
    rule1 = ["-A", "INPUT", "-m", "state", "--state", "NEW,RELATED,ESTABLISHED"]
    rule2 = ["-A", "INPUT", "--state", "NEW,RELATED,ESTABLISHED"]
    rule3 = ["-A", "INPUT", "-m", "state"]
    append_match(rule1, "state", "state")
    assert(rule1 == rule2)
    append_match(rule3, "state", "state")
    assert(rule1 == rule3)



# Generated at 2022-06-20 22:02:18.919808
# Unit test for function remove_rule
def test_remove_rule():
    params = dict()
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['rule_num'] = 1
    params['protocol'] = 'tcp'
    params['destination_port'] = '4040'
    params['jump'] = 'ACCEPT'
    iptables_path = '/sbin/iptables'
    #remove_rule(iptables_path, params)
    print(params['table'], params['chain'], params['action'])



# Generated at 2022-06-20 22:02:19.844056
# Unit test for function check_present

# Generated at 2022-06-20 22:02:31.701300
# Unit test for function construct_rule
def test_construct_rule():
    correct_rule = ['--test1', 'test2', 'test3']
    params = {'test1': 'test2', 'test3': None}
    rule = construct_rule(params)
    assert rule == correct_rule
    correct_rule = ['--test1', 'test2', '!', '--test3', 'test4', 'test5']
    params = {'test1': 'test2', 'test3': '!test4', 'test5': ''}
    rule = construct_rule(params)
    assert rule == correct_rule
    correct_rule = ['--test1', 'test2', 'test3', '--tcp-flags', 'test5', 'test6']

# Generated at 2022-06-20 22:02:37.543171
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, "5", "--wait")
    assert rule == ["--wait", "5"]
    rule = []
    append_wait(rule, None, "--wait")
    assert rule == []


# Generated at 2022-06-20 22:02:51.102844
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy("iptables", "policy", {}, {'ip_version': 'ipv4', 'chain': 'INPUT', 'action': 'insert', 'table': 'filter', 'policy': 'DROP'}, False)



# Generated at 2022-06-20 22:02:51.960186
# Unit test for function append_match
def test_append_match():
    rule = {}
    append_match(rule, True, 'match')
    assert '-m' in rule



# Generated at 2022-06-20 22:03:02.189447
# Unit test for function append_tcp_flags

# Generated at 2022-06-20 22:03:05.191619
# Unit test for function append_csv
def test_append_csv():
    result = []
    input = ['hello', 'world']
    append_csv(result, input, '--test')
    assert result == ['--test', 'hello,world']



# Generated at 2022-06-20 22:03:14.100592
# Unit test for function push_arguments

# Generated at 2022-06-20 22:03:17.192767
# Unit test for function append_jump
def test_append_jump():
    assert append_jump(['-j'], 'ACCEPT', None) == ['-j', 'ACCEPT']
    assert append_jump(['-j'], 'LOG', None) == ['-j', 'LOG']
    assert append_jump([], 'REJECT', None) == []
    assert append_jump(['-j'], None, None) == ['-j']



# Generated at 2022-06-20 22:03:20.618669
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('/sbin/iptables', 'test', params) == ['/sbin/iptables', '-t', 'test', '-P', 'test', 'test']



# Generated at 2022-06-20 22:03:26.007247
# Unit test for function append_wait
def test_append_wait():
    rule = list()
    append_wait(rule, param=None, flag="iptables")
    assert rule == list()
    append_wait(rule, param="2",flag="iptables")
    assert rule == ["iptables", "2"]


# Generated at 2022-06-20 22:03:27.959775
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert flush_table('iptables', module, {'table': 'filter'})



# Generated at 2022-06-20 22:03:29.763244
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'ACCEPT'
    jump = '-j'
    append_jump(rule, param, jump)
    assert(rule == ['-j', 'ACCEPT'])

# Append a rule based on the parameters given to the module

# Generated at 2022-06-20 22:03:38.473191
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.2'
# End of unit test



# Generated at 2022-06-20 22:03:40.391202
# Unit test for function append_match_flag
def test_append_match_flag():
    test_list = []
    append_match_flag(test_list, 'match', '--test', False)
    assert test_list == ['--test']
    append_match_flag(test_list, 'negate', '--test', True)
    assert test_list == ['--test', '!', '--test']



# Generated at 2022-06-20 22:03:44.364935
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['a', 'b'], '--a')
    assert rule == ['--a', 'a,b']



# Generated at 2022-06-20 22:03:45.215566
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables','') == '1.4.21'


# Generated at 2022-06-20 22:03:46.120808
# Unit test for function append_rule
def test_append_rule():
    assert append_rule == push_arguments



# Generated at 2022-06-20 22:03:53.678858
# Unit test for function check_present
def test_check_present():
    iptables_path = '/usr/bin/iptables'
    module = AnsibleModule()
    params = dict(
        ip_version       = 'ipv4',
        chain            = 'INPUT',
        table            = 'filter',
        protocol         = 'tcp',
        destination_port = '22',
        jump             = 'ACCEPT',
        comment          = 'Allow new SSH connections.',
    )
    assert check_present(iptables_path, module, params)
    assert not check_present(iptables_path, module, params)



# Generated at 2022-06-20 22:03:55.483888
# Unit test for function append_match
def test_append_match():
    rule = []
    match = 'match'
    append_match(rule, True, match)
    assert rule == ['-m', 'match']
    append_match(rule, False, match)
    assert rule == ['-m', 'match']



# Generated at 2022-06-20 22:04:00.586221
# Unit test for function insert_rule
def test_insert_rule():
    from ansible.modules.network.iptables import insert_rule, check_present
    from ansible.modules.network.iptables import append_rule
    import os

    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        rule_num='5',
        jump='ACCEPT',
        comment='test',
        ip_version='ipv4',
    )

    ips = []
    for i in range(1, 11):
        ips.append(str(i))

    params['destination_ports'] = ips
    iptables_path = '/sbin/iptables'
    if not os.path.isfile(iptables_path):
        print("No such file: %s" % iptables_path)
        exit(1)

    rule_exist

# Generated at 2022-06-20 22:04:04.466482
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_input=[
        {'chain': 'INPUT', 'ip_version': 'ipv4', 'jump': 'DROP', 'protocol': 'tcp', 'tcp_flags': {'flags': ['ALL'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}},
    ]
    test_output=['-A', 'INPUT', '-m', 'tcp', '--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN', '-j', 'DROP']
    for i in test_input:
        rule = []
        append_tcp_flags(rule, i['tcp_flags'], '--tcp-flags')
        assert rule == test_output


# Generated at 2022-06-20 22:04:09.239977
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 22:04:21.557060
# Unit test for function get_iptables_version
def test_get_iptables_version():
    version_re = re.compile(r'^(\d+)\.(\d+)\.(\d+)$')
    def _is_valid_version(version):
        match = version_re.match(version)
        return bool(match)
    assert _is_valid_version(get_iptables_version("/usr/local/sbin/iptables", None))


# Generated at 2022-06-20 22:04:26.652316
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/sbin/iptables'
    module = '/sbin/iptables'
    params = '-P INPUT DROP'
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-20 22:04:28.692842
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '1', '--wait')
    assert rule == ['--wait', '1']


# Generated at 2022-06-20 22:04:33.673736
# Unit test for function append_param
def test_append_param():
    # Call the function with a non-list
    print('Non-list single call')
    # Set param to None and expect a single entry without param
    print('  param=None')
    rule = []
    append_param(rule, None, "--param", False)
    print(rule)
    # Set param to value and expect a single entry with param as value
    print('  param=value')
    rule = []
    append_param(rule, "value", "--param", False)
    print(rule)
    # Set param to !value and expect a single entry with param as value
    print('  param=!value')
    rule = []
    append_param(rule, "!value", "--param", False)
    print(rule)
    # Call the function with a list
    print('List single call')
    #

# Generated at 2022-06-20 22:04:39.332645
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '60', '--wait')
    assert rule == ['--wait', '60']
    rule = []
    append_wait(rule, '', '--wait')
    assert rule == []



# Generated at 2022-06-20 22:04:46.723161
# Unit test for function flush_table
def test_flush_table():
    params = dict(
            ip_version='ipv4',
            table='nat',
            chain='INPUT',
            flush=True,
        )
    cmd = push_arguments('iptables', '-F', params,make_rule=False)
    assert cmd == ['iptables', '-t', 'nat', '-F', 'INPUT']


# Generated at 2022-06-20 22:04:59.215959
# Unit test for function main

# Generated at 2022-06-20 22:05:07.087831
# Unit test for function push_arguments

# Generated at 2022-06-20 22:05:08.514524
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) != ''


# Generated at 2022-06-20 22:05:12.926128
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('/usr/sbin/iptables', None, params={'table':'filter', 'chain':'INPUT', 'policy':'ACCEPT'}) == ['/usr/sbin/iptables', '-t', 'filter', '-P', 'INPUT', 'ACCEPT']



# Generated at 2022-06-20 22:05:40.745483
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['test_value_1', 'test_value_2', 'test_value_3'], '--test-flag')
    assert len(rule) == 2
    assert rule == ['--test-flag', 'test_value_1,test_value_2,test_value_3']


# Generated at 2022-06-20 22:05:45.370354
# Unit test for function push_arguments
def test_push_arguments():
    params = {
        'chain': 'INPUT',
        'jump': 'DROP',
        'table': 'filter',
        'ip_version': 'ipv4'
    }
    assert push_arguments('iptables', '-A', params) == ['iptables', '-t', 'filter', '-A', 'INPUT', '-j', 'DROP']



# Generated at 2022-06-20 22:05:55.408790
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 22:06:03.132012
# Unit test for function insert_rule
def test_insert_rule():
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'rule': '-p tcp -m multiport --dports 80,8080 -j ACCEPT'
    }
    cmd = "/sbin/iptables -I filter INPUT -p tcp -m multiport --dports 80,8080 -j ACCEPT"
    assert cmd == ' '.join(push_arguments('/sbin/iptables', '-I', params))



# Generated at 2022-06-20 22:06:07.889477
# Unit test for function append_match
def test_append_match():
    rule = []
    param = 'match'
    match = 'match'
    append_match(rule, param, match)
    assert rule == ['-m', 'match']
    rule = []
    param = None
    match = 'match'
    append_match(rule, param, match)
    assert rule == []


# Generated at 2022-06-20 22:06:14.318322
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec=dict())
    params = {
        'action': 'remove',
        'chain': 'INPUT',
        'table': 'filter',
        'destination_port': '22'
    }
    remove_rule(iptables_path, module, params)



# Generated at 2022-06-20 22:06:24.267981
# Unit test for function construct_rule
def test_construct_rule():
    rule_1 = [
        '-p', '6', '-s', '192.168.0.0/30', '--dport', '80', '-j', 'ACCEPT',
        '-m', 'comment', '--comment', '"Test rule for iptables"'
    ]
    assert construct_rule({
        'protocol': '6',
        'source': '192.168.0.0/30',
        'destination_port': '80',
        'jump': 'ACCEPT',
        'comment': 'Test rule for iptables',
    }) == rule_1

# Generated at 2022-06-20 22:06:29.566619
# Unit test for function construct_rule
def test_construct_rule():
    params = {
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'ACCEPT',
        'in_interface': 'eth0',
        'log_level': 'info',
        'log_prefix': 'TEST',
        'ip_version': 'ipv4',
    }
    rule = construct_rule(params)
    assert rule == [
        '-p', 'tcp', '--dport', '80', '-j', 'ACCEPT',
        '-i', 'eth0', '-m', 'comment', '--comment',
        'ansible-generated: IPv4 iptables rules',
        '-m', 'limit', '--limit', '2/second',
    ]


# Generated at 2022-06-20 22:06:35.823939
# Unit test for function check_present
def test_check_present():
    module = MockModule()
    assert check_present('/usr/local/bin/iptables', module, {
        'table': 'nat',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'ACCEPT',
    }) is False
    assert module.run_command.call_count == 1



# Generated at 2022-06-20 22:06:42.796906
# Unit test for function append_match
def test_append_match():
    rule = ['iptables', '-A', 'INPUT', '-p', 'tcp']
    match = 'state'
    check = ['iptables', '-A', 'INPUT', '-p', 'tcp', '-m', 'state']
    append_match(rule, True, match)
    assert (rule == check)



# Generated at 2022-06-20 22:07:07.956473
# Unit test for function remove_rule
def test_remove_rule():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    params = {'chain': 'INPUT', 'table': 'filter'}
    iptables_path = '/sbin/iptables'
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)


# Generated at 2022-06-20 22:07:12.439459
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/sbin/iptables'
    module = MockModule()
    params = dict(
        chain='INPUT',
        protocol='tcp',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    remove_rule(iptables_path, module, params)



# Generated at 2022-06-20 22:07:15.770170
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec={})
    iptables_path = '/sbin/iptables'
    params = dict(table='filter',
                chain='INPUT',
                rule_num='4',
                protocol='tcp',
                destination_port='8080',
                jump='ACCEPT')
    assert insert_rule(iptables_path, module, params) == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '4', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-20 22:07:26.132769
# Unit test for function insert_rule
def test_insert_rule():
    test_param = dict(
        table='filter',
        ip_version='ipv4',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port=8080,
        jump='ACCEPT',
        )
    test_rule = '-A INPUT -p tcp -m multiport --dports 8080 -m comment --comment "" -j ACCEPT'
    test_cmd = push_arguments('/usr/sbin/iptables', '-I', test_param)
    my_cmd = test_cmd[:3] + test_cmd[5:]
    test_rule_elements = [x for x in test_rule.split(' ') if x]
    my_rule_elements = []

# Generated at 2022-06-20 22:07:37.912842
# Unit test for function construct_rule
def test_construct_rule():
    from ansible.module_utils.basic import AnsibleModule
    import sys

# Generated at 2022-06-20 22:07:51.671444
# Unit test for function get_chain_policy

# Generated at 2022-06-20 22:08:01.706768
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--tcp-flags', True)
    assert rule == ['--tcp-flags']
    rule = []
    append_match_flag(rule, 'negate', '--tcp-flags', True)
    assert rule == ['!', '--tcp-flags']
    rule = []
    append_match_flag(rule, 'match', '--tcp-flags', False)
    assert rule == []
    rule = []
    append_match_flag(rule, 'negate', '--tcp-flags', False)
    assert rule == []



# Generated at 2022-06-20 22:08:12.141061
# Unit test for function append_wait
def test_append_wait():
    assert append_wait(['iptables'], '3', '--wait') == ['iptables', '--wait', '3']
    assert append_wait(['iptables'], '3s', '--wait') == ['iptables', '--wait', '3s']
    assert append_wait(['iptables'], '3 s', '--wait') == ['iptables', '--wait', '3s']
    assert append_wait(['iptables'], '3s', '--wait') == ['iptables', '--wait', '3s']
    assert append_wait(['iptables'], '3seconds', '--wait') == ['iptables', '--wait', '3seconds']
    assert append_wait(['iptables'], '3 seconds', '--wait') == ['iptables', '--wait', '3seconds']
    assert append

# Generated at 2022-06-20 22:08:16.163587
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'ACCEPT'
    jump = 'ACCEPT'
    append_jump(rule, param, jump)
    print("rule is %s", rule)


# Generated at 2022-06-20 22:08:26.291347
# Unit test for function main

# Generated at 2022-06-20 22:08:57.466391
# Unit test for function append_param
def test_append_param():
    rule = []

    append_param(rule, "INVALID", '--ctstate', False)
    append_param(rule, "ESTABLISHED", '--ctstate', False)
    append_param(rule, ["!RELATED", "NEW"], '--ctstate', True)

    assert rule == ['--ctstate', "INVALID", '--ctstate', "ESTABLISHED", '!', '--ctstate', "RELATED", '--ctstate', "NEW"]



# Generated at 2022-06-20 22:09:06.395332
# Unit test for function construct_rule

# Generated at 2022-06-20 22:09:09.270790
# Unit test for function check_present
def test_check_present():
    assert check_present(None, None, {'chain': 'INPUT',
                                      'protocol': 'tcp',
                                      'destination_port': '80',
                                      'jump': 'ACCEPT',
                                      'ip_version': 'ipv4',
                                      'table': 'filter'}) == False



# Generated at 2022-06-20 22:09:15.411078
# Unit test for function append_jump
def test_append_jump():
    rule = ['iptables', '-A', 'INPUT', '-p', 'tcp', '--dport', '25', '-m', 'comment']
    append_jump(rule, 'SMTP', 'SMTP')
    assert rule == ['iptables', '-A', 'INPUT', '-p', 'tcp', '--dport', '25', '-m', 'comment', '-j', 'SMTP']
    rule = ['iptables', '-A', 'INPUT', '-p', 'tcp', '--dport', '25', '-m', 'comment']
    append_jump(rule, None, 'SMTP')
    assert rule == ['iptables', '-A', 'INPUT', '-p', 'tcp', '--dport', '25', '-m', 'comment']



# Generated at 2022-06-20 22:09:17.912716
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, dict(flags=['ALL', 'NON'], flags_set=['ACK', 'RST', 'SYN', 'FIN']), '--tcp-flags')
    print(rule)
    assert rule == ['--tcp-flags', 'ALL,NON', 'ACK,RST,SYN,FIN']

# Generated at 2022-06-20 22:09:20.868964
# Unit test for function append_wait
def test_append_wait():
    assert append_wait(['/sbin/iptables'],'60','--wait') == ['/sbin/iptables', '--wait', '60']
    assert append_wait(['/sbin/iptables'], 'whatever', '--wait') == ['/sbin/iptables', '--wait', 'whatever']


# Generated at 2022-06-20 22:09:26.004431
# Unit test for function append_param
def test_append_param():
    x = ['iptables', '-A', 'INPUT']
    append_param(x, '123', '--something', False)
    assert x == ['iptables', '-A', 'INPUT', '--something', '123']
    x = ['iptables', '-A', 'INPUT']
    append_param(x, '!123', '--something', False)
    assert x == ['iptables', '-A', 'INPUT', '!', '--something', '123']
    x = ['iptables', '-A', 'INPUT']
    append_param(x, [1, 2, 3], '--something', True)
    assert x == ['iptables', '-A', 'INPUT', '--something', '1', '--something', '2', '--something', '3']

# Generated at 2022-06-20 22:09:31.336146
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = 'fake_module'
    params = {
        'iptables_path': iptables_path,
        'action': '-I',
        'chain': 'INPUT',
        'protocol': 'udp',
        'jump': 'DROP',
        'table': 'filter',
        'rule_num': 1
    }
    assert push_arguments(iptables_path, '-I', params) == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '1', '-p', 'udp', '-j', 'DROP']
# End of unit test



# Generated at 2022-06-20 22:09:35.480774
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, {'flags': ['ACK', 'SYN', 'FIN'], 'flags_set': ['ACK']}, flag='!')
    assert rule == ['!', '--tcp-flags', 'ACK,SYN,FIN', 'ACK']



# Generated at 2022-06-20 22:09:39.048071
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    params = {}
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['rule_num'] = 1
    params['protocol'] = 'tcp'
    params['destination'] = '192.168.1.1'
    params['jump'] = 'DROP'
    params['wait'] = 2
    params['destination_ports'] = '22,80,443'
    iptables_path = '/sbin/iptables'
    append_rule(iptables_path, module, params)



# Generated at 2022-06-20 22:10:15.053855
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/bin/iptables', None) == ''
    assert get_iptables_version('/bin/iptables', {'run_command': lambda x,y: ('0', 'hello world v1.7.8 (nf_tables)', '')}) == '1.7.8'
    assert get_iptables_version('/bin/iptables', {'run_command': lambda x,y: ('1', 'hello world v1.7.8 (nf_tables)', '')}) == ''


# Generated at 2022-06-20 22:10:21.989834
# Unit test for function get_iptables_version
def test_get_iptables_version():
    args = dict(
        iptables_path='iptables',
    )
    module = Mock(**args)
    rc, out, _ = module.run_command(['iptables', '--version'], check_rc=True)
    assert get_iptables_version('iptables', module) == out.split('v')[1].rstrip('\n')
    rc, out, _ = module.run_command(['ip6tables', '--version'], check_rc=True)
    assert get_iptables_version('ip6tables', module) == out.split('v')[1].rstrip('\n')



# Generated at 2022-06-20 22:10:24.885531
# Unit test for function remove_rule
def test_remove_rule():
    assert push_arguments("iptables", "-D", dict(
        table="filter",
        chain="INPUT",
        protocol="tcp",
        destination_port="8080",
        jump="ACCEPT",
        action="remove",
        rule_num="5")) == ['iptables', '-t', 'filter', '-D', 'INPUT', '5', '-p',
                            'tcp', '--dport', '8080', '-j', 'ACCEPT']


# Generated at 2022-06-20 22:10:36.723530
# Unit test for function check_present
def test_check_present():
    ipv4_iptables_path = '/usr/sbin/iptables'
    ipv6_iptables_path = '/usr/sbin/ip6tables'
    params = {
        'table': "filter",
        'chain': "INPUT",
        'protocol': "tcp",
        'destination_port': "443",
        'jump': "ACCEPT",
        'ip_version': "ipv4"
    }
    if check_present(ipv4_iptables_path, module, params):
        print ("Present")
    else:
        print ("Not Present")

# Generated at 2022-06-20 22:10:53.440800
# Unit test for function main

# Generated at 2022-06-20 22:10:57.702350
# Unit test for function insert_rule
def test_insert_rule():
    '''
    Unit test for function insert_rule
    '''
    class test_module():
        def __init__(self):
            self.run_command_rc = 0

        def run_command(self, cmd, check_rc=True):
            '''
            Fake run_command
            '''
            iptables_path = cmd[0]
            action = cmd[1]
            table = cmd[2]
            chain = cmd[3]
            rule_num = cmd[4]
            target_cmd = cmd[5]
            policy = cmd[6]
            if iptables_path == '/usr/bin/iptables':
                if action == '-I':
                    if table == 'nat' and chain == 'PREROUTING' and rule_num == '5':
                        return self.run_command_rc

# Generated at 2022-06-20 22:11:08.803837
# Unit test for function main