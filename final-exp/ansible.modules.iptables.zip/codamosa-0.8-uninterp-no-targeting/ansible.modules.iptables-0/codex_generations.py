

# Generated at 2022-06-20 22:01:58.297393
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', AnsibleModule(argument_spec={}), {
        'chain': 'INPUT',
        'table': 'filter',
        'ip_version': 'ipv4',
        'protocol': 'tcp',
        'destination_port': '22',
        'ctstate': 'NEW',
        'syn': 'match',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.'
    }) == True
#end


# Generated at 2022-06-20 22:02:04.406353
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['a', 'b', 'c']
    flag = '-b'
    append_csv(rule,param,flag)
    assert (rule == ['-b', 'a,b,c'])
    rule = []
    param = []
    append_csv(rule,param,flag)
    assert (rule == [])
    rule = []
    param = None
    append_csv(rule,param,flag)
    assert (rule == [])


# Generated at 2022-06-20 22:02:07.473446
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert(get_chain_policy(None,None,{'chain':'INPUT'})=='DROP')
    assert(get_chain_policy(None,None,{'chain':'FORWARD'})=='DROP')
    assert(get_chain_policy(None,None,{'chain':'OUTPUT'})=='ACCEPT')

# Generated at 2022-06-20 22:02:13.688372
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        table='filter',
        count=True,
        ip_version='ipv4',
    )
    rule = ['-w', '-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP']
    assert(construct_rule(params) == rule)



# Generated at 2022-06-20 22:02:20.793453
# Unit test for function append_jump
def test_append_jump():
    rule = ['--table', 'mangle']
    append_jump(rule, 'DROP', 'test')
    assert rule == ['--table', 'mangle', '-j', 'test']
    append_jump(rule, None, 'test')
    assert rule == ['--table', 'mangle', '-j', 'test']



# Generated at 2022-06-20 22:02:27.968613
# Unit test for function push_arguments

# Generated at 2022-06-20 22:02:30.836324
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(1,1,dict(chain="INPUT",policy="ACCEPT")) == None


# Generated at 2022-06-20 22:02:32.901008
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, 'ACCEPT', 'ACCEPT')
    assert rule == ['-j', 'ACCEPT']



# Generated at 2022-06-20 22:02:33.742001
# Unit test for function append_rule
def test_append_rule():
    assert(False), "Tests not implemented"



# Generated at 2022-06-20 22:02:40.890599
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        destination='10.0.0.1',
        destination_port='22',
        jump='ACCEPT',
        log_prefix='IPTABLES:INFO: ',
        log_level='info',
        ip_version='ipv4',
        ctstate=['NEW', 'ESTABLISHED'],
        limit='2/second',
        limit_burst='20',
    )
    # Expected output

# Generated at 2022-06-20 22:02:59.018725
# Unit test for function append_jump

# Generated at 2022-06-20 22:03:03.440203
# Unit test for function append_jump
def test_append_jump():
    assert append_jump(['-A', 'INPUT'], 'ACCEPT', 'ACCEPT') == ['-A', 'INPUT', '-j', 'ACCEPT']


# Generated at 2022-06-20 22:03:09.027400
# Unit test for function flush_table
def test_flush_table():

    iptables_path = '/sbin/iptables'
    module = module_mock()
    params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4'
    )
    cmd = push_arguments(iptables_path, '-F', params, make_rule=False)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-F', 'INPUT']



# Generated at 2022-06-20 22:03:16.408904
# Unit test for function push_arguments
def test_push_arguments():
    # Arrange

    # Act
    iptables_path = 'iptables'
    action = '-I'
    params = dict(
        state='present',
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    result = push_arguments(iptables_path, action, params)
    # Assert
    assert result == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']



# Generated at 2022-06-20 22:03:18.001842
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, 'match')
    test_assert(rule, '-m match')
    rule = []
    append_match(rule, False, 'match')
    test_assert(rule, [])
    


# Generated at 2022-06-20 22:03:22.024687
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/usr/bin/iptables'
    result = ['iptables', '-t', 'filter', '-I', 'INPUT', '2']
    params = dict(
        table = 'filter',
        chain = 'INPUT',
        rule_num = '2',
        jump = 'ACCEPT',
        protocol = 'tcp',
        destination_port = '80'
        )
    assert insert_rule(iptables_path,result,params)
    #assert insert_rule('/usr/bin/iptables',result,dict(table = 'filter', chain = 'INPUT', rule_num = '2', jump = 'ACCEPT', protocol = 'tcp', destination_port = '80')) == False


# Generated at 2022-06-20 22:03:27.166526
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', 'syn-match', True)
    append_match_flag(rule, 'negate', 'syn-not-match', True)
    assert rule == ['--syn', '--syn-not']



# Generated at 2022-06-20 22:03:30.192241
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = mock.MagicMock(return_value=(0, 'v1.4.18', ''))
    assert get_iptables_version('/sbin/iptables', module) == '1.4.18'



# Generated at 2022-06-20 22:03:42.092350
# Unit test for function main

# Generated at 2022-06-20 22:03:49.594014
# Unit test for function append_jump
def test_append_jump():
    assert append_jump(['iptables','-S'],'ACCEPT','ACCEPT') == ['iptables','-S','-j','ACCEPT']
    assert append_jump(['iptables','-S'],'DROP','DROP') == ['iptables','-S','-j','DROP']
    assert append_jump(['iptables','-S'],'DNAT','DNAT') == ['iptables','-S','-j','DNAT']



# Generated at 2022-06-20 22:04:07.463099
# Unit test for function append_csv
def test_append_csv():
    rule=[]
    append_csv(rule, None, 'test')
    assert rule == []
    append_csv(rule, [], 'test')
    assert rule == []
    append_csv(rule, ['1', '2', '3'], 'test')
    assert rule == ['test', '1,2,3']



# Generated at 2022-06-20 22:04:14.364118
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        ip_version = 'ipv4',
        table = 'filter',
        chain = 'INPUT',
        jump = 'ACCEPT',
        protocol = 'tcp',
        destination_port = 22,
        ctstate = 'NEW',
        syn = 'match',
        wait = '1',
    )
    append_rule(iptables_path, module, params)

# Generated at 2022-06-20 22:04:20.322958
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(argument_spec=dict())
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        state='present',
        action='append',
        jump='ACCEPT',
        flush=False,
        policy=None,
    )
    cmd = push_arguments('/usr/sbin/iptables', module, params)
    assert cmd == ['/usr/sbin/iptables', '-t', 'filter', '-A', 'INPUT',
                   '-j', 'ACCEPT']



# Generated at 2022-06-20 22:04:25.110490
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        chain='INPUT',
        state='present',
        ip_version='ipv4',
        protocol='tcp',
        table='nat',
        comment='Ansible test rule',
        action='-I',
        rule_num=1,
        jump='ACCEPT',
        ip_type='ipv4',
        port='80',
    )
    iptables_path = 'iptables'
    cmd = push_arguments(iptables_path, '-I', params)

# Generated at 2022-06-20 22:04:26.449354
# Unit test for function append_jump
def test_append_jump():
    test_rule = []
    param = None
    jump = 'ACCEPT'
    assert append_jump(test_rule, param, jump) == None
    assert test_rule == []


# Generated at 2022-06-20 22:04:27.711561
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.8.2'
test_get_iptables_version()



# Generated at 2022-06-20 22:04:33.118041
# Unit test for function append_wait
def test_append_wait():
    rule = ["hello", "world"]
    param = "3"
    flag = "--wait"
    append_wait(rule, param, flag)
    assert rule == ["hello", "world", "--wait", "3"]


# Generated at 2022-06-20 22:04:44.100861
# Unit test for function construct_rule
def test_construct_rule():
    expected = ['-w', '10s', '-s', '10.0.0.1', '-p', 'tcp', '-m', 'multiport',
                '--dports', '8080,8081', '-m', 'limit', '--limit', '10/second',
                '--limit-burst', '5', '-j', 'DNAT', '--to-destination', '10.0.0.2']
    params = dict(
        wait='10s',
        source='10.0.0.1',
        protocol='tcp',
        destination_ports=['8080', '8081'],
        limit='10/second',
        limit_burst='5',
        jump='DNAT',
        to_destination='10.0.0.2'
    )
    actual = construct

# Generated at 2022-06-20 22:04:44.986426
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], None, '!', True) == []



# Generated at 2022-06-20 22:04:49.359679
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
    chain = 'INPUT',
    action = 'present',
    table = 'filter',
    ip_version = 'ipv4',
    policy = 'DROP',
    )
    module = AnsibleModule(argument_spec = dict())
    iptables_path = 'iptables'
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-20 22:05:21.215508
# Unit test for function append_wait
def test_append_wait():
    rule = ['iptables']
    param = "3"
    flag = '-w'
    expected = ['iptables','-w','3']
    append_wait(rule,param,flag)
    assert rule == expected


# Generated at 2022-06-20 22:05:28.117269
# Unit test for function check_present
def test_check_present():
    cmd = ['iptables',
            '-t', 'nat',
            '-C', 'OUTPUT',
            '-p', 'tcp',
            '-s', '10.0.0.0/24',
            '-d', '192.168.1.1',
            '-m', 'multiport',
            '--dports', '80',
            '-j', 'DNAT',
            '--to-destination', '10.0.1.1',
            '-m', 'comment',
            '--comment', 'some comment',
            '-w', '2']
    assert check_present('iptables', 'nat', 'OUTPUT', cmd) == True



# Generated at 2022-06-20 22:05:37.066563
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule(
        'iptables',
        0,
        dict(
            table='filter',
            chain='INPUT',
            protocol='tcp',
            dest_port='22',
            jump='ACCEPT',
        ),
    ) == \
    [
        'iptables',
        '-t',
        'filter',
        '-D',
        'INPUT',
        '-p',
        'tcp',
        '--dport',
        '22',
        '-j',
        'ACCEPT',
    ]



# Generated at 2022-06-20 22:05:47.850153
# Unit test for function check_present
def test_check_present():
    import os
    import sys
    import subprocess
    import tempfile
    from ansible.modules.network.firewall import iptables

    iptables_path = iptables.IPTABLES_PATH
    if os.path.isfile('/usr/libexec/iptables/iptables'):
        iptables_path = '/usr/libexec/iptables/iptables'
    cmd = '%s -w -t filter -N test' % iptables_path
    cmd2 = '%s -w -t filter -A test -p tcp -m multiport --dports 22,23 -j DROP' % iptables_path
    subprocess.call(cmd, shell=True)
    subprocess.call(cmd2, shell=True)

# Generated at 2022-06-20 22:05:53.862124
# Unit test for function construct_rule
def test_construct_rule():
    params = {
        'chain': 'INPUT',
        'jump': 'ACCEPT',
        'comment': '"Accept all traffic"',
        'table': None,
        'ip_version': 'ipv4',
    }
    rule = construct_rule(params)
    assert rule == ['-j', 'ACCEPT', '-m', 'comment', '--comment', '"Accept all traffic"']
    params = {
        'chain': 'INPUT',
        'jump': 'ACCEPT',
        'comment': '"Accept all traffic"',
        'table': 'mangle',
        'ip_version': 'ipv4',
    }
    rule = construct_rule(params)

# Generated at 2022-06-20 22:06:05.667110
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        jump='ACCEPT',
        source='127.0.0.1',
        destination='192.0.2.1',
        in_interface='eth0',
        out_interface='eth1',
        protocol='icmp',
        ctstate='ESTABLISHED',
        limit='3/minute',
        limit_burst='5',
    )
    rule = construct_rule(params)

# Generated at 2022-06-20 22:06:10.425240
# Unit test for function append_match
def test_append_match():
    test = []
    append_match(test, True, 'string')
    assert test == ['-m', 'string']
    test = []
    append_match(test, False, 'string')
    assert test == []



# Generated at 2022-06-20 22:06:18.800870
# Unit test for function append_match_flag
def test_append_match_flag():
    params = dict()
    append_match_flag(params, 'match', '--syn', True)
    assert params == ['--syn']

    params = dict()
    append_match_flag(params, None, '--syn', True)
    assert params == []

    params = dict()
    append_match_flag(params, 'negate', '--syn', True)
    assert params == ['!', '--syn']

    params = dict()
    append_match_flag(params, 'nomatch', '--syn', False)
    assert params == []



# Generated at 2022-06-20 22:06:26.072718
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'FOO', '--foo', False)
    assert rule == ['--foo', 'FOO']
    rule = []
    append_param(rule, ['FOO', 'BAR'], '--foo', True)
    assert rule == ['--foo', 'FOO', '--foo', 'BAR']
    rule = []
    append_param(rule, ['!FOO', '!BAR'], '--foo', True)
    assert rule == ['!', '--foo', 'FOO', '!', '--foo', 'BAR']
    rule = []
    append_param(rule, [], '--foo', True)
    assert rule == []



# Generated at 2022-06-20 22:06:27.887409
# Unit test for function append_rule
def test_append_rule():
    append_rule(module)



# Generated at 2022-06-20 22:07:33.747260
# Unit test for function set_chain_policy
def test_set_chain_policy():
    print (push_arguments("iptables", '-P', params, make_rule=False))
    cmd = push_arguments("iptables", '-P', params, make_rule=False)
    cmd.append(params['policy'])
    module.run_command(cmd, check_rc=True)


# Generated at 2022-06-20 22:07:40.797240
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path='iptables'
    action='-A'
    params={'table':'filter','chain':'INPUT','protocol':'tcp','destination_port':'22','ctstate':'NEW','syn':'match','jump':'ACCEPT','comment':'Accept new SSH connections.','ip_version':'ipv4'}
    assert push_arguments(iptables_path,action,params)==['iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']


# Generated at 2022-06-20 22:07:53.011930
# Unit test for function main

# Generated at 2022-06-20 22:07:57.542311
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version("/usr/sbin/iptables", "") == "1.6.0"
    assert get_iptables_version("/usr/sbin/iptables", "") != "1.8.0"



# Generated at 2022-06-20 22:08:06.813741
# Unit test for function insert_rule
def test_insert_rule():
    from ansible.modules.network.firewall import iptables_raw
    from ansible.module_utils.six.moves import StringIO
    import sys
    stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

# Generated at 2022-06-20 22:08:20.069739
# Unit test for function construct_rule
def test_construct_rule():
    param = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        icmp_type='time-exceeded'
    )
    result = construct_rule(param)
    assert result == ['-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP', '--icmp-type', 'time-exceeded']

    param = dict(
        protocol='tcp',
        destination='8.8.8.8',
        jump='DROP',
        icmp_type='time-exceeded'
    )
    result = construct_rule(param)

# Generated at 2022-06-20 22:08:25.063349
# Unit test for function remove_rule
def test_remove_rule():
    assert ['iptables','-t','filter','-D','INPUT','!','-s','8.8.8.8','-j','DROP'] == \
        remove_rule('iptables', 'module', {'chain': 'INPUT', 'source': '!8.8.8.8', 'jump': 'DROP', 'table': 'filter'})



# Generated at 2022-06-20 22:08:26.567021
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('i/p', []) == '1.8.2\n'
    assert get_iptables_version('i/p2', []) == '0.0.0\n'



# Generated at 2022-06-20 22:08:34.275834
# Unit test for function main

# Generated at 2022-06-20 22:08:40.472488
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_rule = []
    test_param = dict(flags=["ALL"], flags_set=["ACK", "SYN"])
    test_flag = '--tcp-flags'
    append_tcp_flags(test_rule, test_param, test_flag)
    assert test_rule == ['--tcp-flags', 'ALL', 'ACK,SYN']

    test_rule = []
    test_param = dict(flags=[""], flags_set=["ACK", "SYN"])
    test_flag = '--tcp-flags'
    append_tcp_flags(test_rule, test_param, test_flag)
    assert test_rule == []



# Generated at 2022-06-20 22:10:00.697224
# Unit test for function construct_rule
def test_construct_rule():
    # GIVEN
    params = dict(
        source='192.0.2.1',
        comment='My test rule',
        ctstate='NEW, RELATED',
        jump='ACCEPT',
        limit='1/hour',
        reject_with='icmp-port-unreachable',
        ip_version='ipv4',
    )

    # WHEN
    rule = construct_rule(params)

    # THEN
    print(rule)
    assert ['!', '-s', '192.0.2.1'] == rule[1:4]
    assert ['-m', 'comment', '--comment', 'My test rule'] == rule[4:8]
    assert ['-m', 'conntrack', '--ctstate', 'NEW,RELATED'] == rule[8:12]

# Generated at 2022-06-20 22:10:06.849980
# Unit test for function append_match
def test_append_match():
    rule = ['iptables', '-A', 'test_iptables']
    param = dict(
        match=False
    )
    match = 'test_match'
    append_match(rule, param['match'], match)
    assert rule == ['iptables', '-A', 'test_iptables', '-m', 'test_match']
    param['match'] = True
    rule = ['iptables', '-A', 'test_iptables']
    append_match(rule, param['match'], match)
    assert rule == ['iptables', '-A', 'test_iptables', '-m', 'test_match']
    param['match'] = False
    rule = ['iptables', '-A', 'test_iptables']
    match = ' '
    append_match(rule, param['match'], match)

# Generated at 2022-06-20 22:10:17.824924
# Unit test for function insert_rule
def test_insert_rule():
    from mock import Mock
    import collections
    module = Mock()
    module_utils = Mock()
    module_utils.basic = Mock()
    module_utils.basic.AnsibleModule = Mock()
    module_utils.basic.AnsibleModule = collections.namedtuple(
        'AnsibleModule', [
            'run_command'
        ])
    module.run_command.return_value = (0, '', '')
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        ip_version='ipv4',
        action='insert',
        rule_num='5',
        comment='Test rule'
    )

# Generated at 2022-06-20 22:10:19.411765
# Unit test for function set_chain_policy
def test_set_chain_policy():
    print(set_chain_policy(None, None, {'chain':'INPUT', 'table':'filter', 'policy':'DROP'}))



# Generated at 2022-06-20 22:10:20.242766
# Unit test for function append_match_flag
def test_append_match_flag():
    assert([''])
    assert(['!', '--syn'])
    assert(['--syn'])



# Generated at 2022-06-20 22:10:21.843184
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '4', '-w')
    assert rule == ['-w', '4']



# Generated at 2022-06-20 22:10:23.092167
# Unit test for function get_iptables_version
def test_get_iptables_version():
    version = get_iptables_version('/sbin/iptables', None)
    assert(version in ['1.4.21', '1.6.0'])



# Generated at 2022-06-20 22:10:27.322067
# Unit test for function remove_rule
def test_remove_rule():
    r = remove_rule("iptables", "module", dict(table='filter', chain='INPUT', ip_version='ipv4'))
# end of unit test



# Generated at 2022-06-20 22:10:36.004673
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/sbin/iptables'
    iptables_path = '/sbin/iptables'
    module = 0
    params = dict(table='filter',
                  ip_version='ipv4',
                  chain='INPUT',
                  policy='ACCEPT',
                  action='set_policy')
    set_chain_policy(iptables_path, module, params)
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-20 22:10:43.333757
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict())
    params = dict()
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    cmd = flush_table('iptables', module, params)
    assert cmd == ['iptables', '-t', 'filter', '-F', 'INPUT']

