

# Generated at 2022-06-20 22:01:47.647389
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', False) == '1.6.1'


# Generated at 2022-06-20 22:01:49.042936
# Unit test for function append_csv
def test_append_csv():
    rule = []
    assert append_csv(rule, ['ESTABLISHED', 'RELATED'], '--ctstate') == None
    assert rule == ['--ctstate', 'ESTABLISHED,RELATED']


# Generated at 2022-06-20 22:01:54.661781
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '5', '--wait')
    assert rule[0] == '--wait'
    assert rule[1] == '5'


# Generated at 2022-06-20 22:01:56.405547
# Unit test for function append_csv
def test_append_csv():
    append_csv(['--name=foo'], ['bar', 'baz'], '--set_csv')
    assert(['--name=foo', '--set_csv', 'bar,baz'] == ['--name=foo', '--set_csv', 'bar,baz'])


# Generated at 2022-06-20 22:02:02.214361
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('test_iptables', None, {'table':'test_table', 'chain':'test_chain'}) == \
    [ 'test_iptables', '-t', 'test_table', '-D', 'test_chain' ]


# Generated at 2022-06-20 22:02:09.247905
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, "True", "jump")
    assert rule == ['-j', 'jump'], "Rule array should be ['-j', 'jump']"
    rule.pop()
    append_jump(rule, "False", "jump")
    assert rule == [], "Rule array should be []"


# Generated at 2022-06-20 22:02:18.299253
# Unit test for function append_csv
def test_append_csv():
    param = [ 'ESTABLISHED', 'RELATED' ]
    rule = []
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert(rule == ['--ctstate', 'ESTABLISHED,RELATED'])
    param = None
    rule = []
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert(rule == [])



# Generated at 2022-06-20 22:02:20.412258
# Unit test for function append_wait
def test_append_wait():
    def run(rule, param, flag):
        res = []
        append_wait(res, param, flag)
        return res

    assert run([], '5', '-w') == ['-w', '5']
    assert run([], None, '-w') == []
    assert run([], '', '-w') == []



# Generated at 2022-06-20 22:02:25.136531
# Unit test for function append_wait
def test_append_wait():
    assert append_wait(rule, '', '--wait') == None


# https://github.com/ansible/ansible/issues/49373

# Generated at 2022-06-20 22:02:32.156417
# Unit test for function append_rule
def test_append_rule():
    import uuid
    test_uuid = str(uuid.uuid4())
    test_uuid_2 = str(uuid.uuid4())
    result = run_command(["iptables", "-t", "filter", "-A", "OUTPUT", "-p", "tcp", "-s", "8.8.8.8", "-d", "192.168.1.1", "-m", "comment", "-j", "ACCEPT", "--comment", test_uuid_2])
    assert test_uuid_2 == result.strip()



# Generated at 2022-06-20 22:02:50.932061
# Unit test for function insert_rule
def test_insert_rule():
  params1 = dict(
    protocol='tcp',
    match='tcp',
    destination='192.168.1.1',
    destination_port=8080,
    jump='ACCEPT',
    comment='test_insert_rule',
    rule_num=5)
  params2 = dict(
    protocol='tcp',
    match='tcp',
    destination='192.168.1.2',
    destination_port=8081,
    jump='ACCEPT',
    comment='test_insert_rule',
    rule_num=5)

# Generated at 2022-06-20 22:02:52.728121
# Unit test for function append_match
def test_append_match():
    rule = []
    match = "test-match"
    param = True
    append_match(rule, param, match)
    assert rule == ['-m', match]
    rule = []
    param = False
    append_match(rule, param, match)
    assert rule == []


# Generated at 2022-06-20 22:02:59.675310
# Unit test for function construct_rule

# Generated at 2022-06-20 22:03:09.678211
# Unit test for function push_arguments

# Generated at 2022-06-20 22:03:12.647733
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = {}
    param['wait'] = '10'
    flag = '--wait'
    append_wait(rule, param['wait'], flag) 
    assert rule == ['--wait', '10']



# Generated at 2022-06-20 22:03:27.939373
# Unit test for function main

# Generated at 2022-06-20 22:03:29.429547
# Unit test for function append_match
def test_append_match():
    assert append_match([], None, 'test') == []
    assert append_match([], True, 'test') == ['-m', 'test']


# Generated at 2022-06-20 22:03:36.144088
# Unit test for function append_wait
def test_append_wait():
    rule = ['iptables']
    append_wait(rule, '0.2', '--wait')
    assert(rule == ['iptables', '--wait', '0.2'])
    rule = ['iptables']
    append_wait(rule, '', '--wait')
    assert(rule == ['iptables'])



# Generated at 2022-06-20 22:03:38.592139
# Unit test for function flush_table
def test_flush_table():
    assert (flush_table(iptables_path = 'iptables',
                        module = module,
                        params = {
                            'table': 'filter',
                            'chain': 'INPUT'
                        }) == ['iptables',
                               '-t', 'filter',
                               '-F', 'INPUT'])

# Generated at 2022-06-20 22:03:40.379889
# Unit test for function check_present
def test_check_present():
    assert check_present("iptables") == False



# Generated at 2022-06-20 22:04:12.191221
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = []
    jump = ['']
    append_jump(rule, param, jump)
    assert rule == []



# Generated at 2022-06-20 22:04:18.304673
# Unit test for function check_present
def test_check_present():
    cmd = '/sbin/iptables -C INPUT -d 127.0.0.1 -p tcp -m tcp --dport 80 -j DROP'
    assert check_present('/sbin/iptables', None, dict(args=cmd)) == False

    cmd = '/sbin/iptables -C INPUT -s 127.0.0.1 -p tcp -m tcp --dport 80 -j DROP'
    assert check_present('/sbin/iptables', None, dict(args=cmd)) == True



# Generated at 2022-06-20 22:04:24.519992
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    assert append_tcp_flags(rule=['--destination-port', '22'],
                            param=dict(flags=['ALL'], flags_set=['ACK', 'RST', 'SYN', 'FIN']),
                            flag='--tcp-flags') \
        == ['--destination-port', '22', '--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-20 22:04:28.042997
# Unit test for function get_chain_policy
def test_get_chain_policy():
    _, _, params = get_arguments()

    from ansible_collections.ansible.builtin.plugins.modules.core import AnsibleModule
    module_ = AnsibleModule({})
    assert get_chain_policy(None, module_, params) == ''



# Generated at 2022-06-20 22:04:33.262891
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ["2", "3", "4"]
    flag = "--ctstate"
    append_csv(rule, param, flag)
    assert rule == ['--ctstate', '2,3,4']



# Generated at 2022-06-20 22:04:34.651013
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', 'iptables v1.6.0') == '1.6.0'
    return



# Generated at 2022-06-20 22:04:41.712160
# Unit test for function insert_rule
def test_insert_rule():
    params = {
        'action': 'insert',
        'chain': 'INPUT',
        'destination_port': 8080,
        'ip_version': 'ipv4',
        'jump': 'ACCEPT',
        'protocol': 'tcp',
        'rule_num': 5,
    }
    assert insert_rule(BINS['ipv4'], None, params), "Not the expected output."



# Generated at 2022-06-20 22:04:45.918150
# Unit test for function append_match
def test_append_match():
    assert append_match([], True, 'match') == ['-m', 'match']
    assert append_match([], False, 'match') == []



# Generated at 2022-06-20 22:04:50.372686
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("/sbin/iptables", None, {"table": "filter", "chain": "FORWARD"}) == "ACCEPT"
    assert get_chain_policy("/sbin/iptables", None, {"table": "filter", "chain": "INPUT"}) == "ACCEPT"
    assert get_chain_policy("/sbin/iptables", None, {"table": "filter", "chain": "OUTPUT"}) == "ACCEPT"


# Generated at 2022-06-20 22:04:56.535970
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter', ip_version='ipv4')) is None
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter', ip_version='ipv4', policy='ACCEPT')) == 'ACCEPT'



# Generated at 2022-06-20 22:05:33.084619
# Unit test for function flush_table
def test_flush_table():
    if os.path.isfile('/etc/iptables.rules'):
        f = os.popen('cat /etc/iptables.rules')
        contents = f.readlines()
        f.close()
        print(contents)
    else:
        print('file not found')
    d = '/etc/iptables.rules'
    f = open(d,"w+")
    for i in range(3):
        f.write('some text  \n')
    f.close()
    f = os.popen('cat /etc/iptables.rules')
    contents = f.readlines()
    f.close
    print(contents)
    flush_table()
    f = o

# Generated at 2022-06-20 22:05:45.724650
# Unit test for function insert_rule

# Generated at 2022-06-20 22:05:52.764531
# Unit test for function main
def test_main():
    """
    Test module main
    """
    # Example cmd line:
    # ansible-playbook -i localhost, -c local -e "state=absent table=filter chain=INPUT" -vvv playbook.yml
    # ip6tables -t filter -nvxL OUTPUT

    if not os.path.isdir(TEST_DIR):
        os.mkdir(TEST_DIR)

# Generated at 2022-06-20 22:05:56.600263
# Unit test for function check_present
def test_check_present():
    print("test_check_present: Checking presence of new rule on ipv4")
    assert check_present("iptables", module, ipv4_payload)
    print("test_check_present: Checking presence of new rule on ipv6")
    assert check_present("ip6tables", module, ipv6_payload)



# Generated at 2022-06-20 22:06:02.155451
# Unit test for function remove_rule
def test_remove_rule():
    print(remove_rule('iptables', 'module', {
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': '1',
        'jump': 'DROP',
        'ip_version': 'ipv4',
        'wait': '1',
    }))
    print(remove_rule('iptables', 'module', {
        'table': 'filter',
        'chain': 'INPUT',
        'jump': 'DROP',
        'ip_version': 'ipv4',
        'wait': '1',
    }))



# Generated at 2022-06-20 22:06:13.913709
# Unit test for function insert_rule

# Generated at 2022-06-20 22:06:15.200669
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({})
    params = dict(chain='INPUT', policy='DROP', table='filter')
    set_chain_policy('iptables', module, params)


# Generated at 2022-06-20 22:06:17.981959
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', 'iptables v1.4.21') == '1.4.21'



# Generated at 2022-06-20 22:06:22.599971
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_rule = []
    test_param = {'flags': ['FIN', 'RST', 'SYN', 'ACK'], 'flags_set': ['ACK', 'SYN', 'FIN']}
    append_tcp_flags(test_rule, test_param, '--tcp-flags')
    assert test_rule == ['--tcp-flags', 'FIN,RST,SYN,ACK', 'ACK,SYN,FIN']


# Generated at 2022-06-20 22:06:28.904309
# Unit test for function insert_rule

# Generated at 2022-06-20 22:07:01.404630
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = "iptables"
    action = "-A"
    params = dict(
        table='nat',
        chain='INPUT',
        protocol='tcp',
        destination='10.127.0.1',
        jump='DROP'
    )
    result = push_arguments(iptables_path, action, params)
    assert result == ["iptables", "-t", "nat", "-A", "INPUT", "-p", "tcp", "-d", "10.127.0.1", "-j", "DROP"]



# Generated at 2022-06-20 22:07:06.994866
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import iptables

    if PY2:
        # This is a hack to deal with running tests under python 2 and 3
        # where the return type of run_command is different.
        class FakeModule(object):
            def __init__(self):
                self.run_command = lambda a, b: (0, 'iptables v1.7.0\n', '')

        module = FakeModule()

# Generated at 2022-06-20 22:07:09.900461
# Unit test for function append_param
def test_append_param():
    rule = []
    param = '192.168.1.0/24'
    append_param(rule, param, '--source', False)
    assert '--source' in rule
    assert param in rule


# Generated at 2022-06-20 22:07:14.527182
# Unit test for function append_rule
def test_append_rule():
    '''
    check if the function that append rule works well
    '''
    test = dict(
        chain = 'INPUT',
        jump = 'ACCEPT',
        table = 'filter'
    )
    assert ['iptables', '-t', 'filter', '-A', 'INPUT', '-j', 'ACCEPT'] == push_arguments('iptables', '-A', test)


# Generated at 2022-06-20 22:07:16.069826
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = '5'
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule == ['--wait', '5']


# Generated at 2022-06-20 22:07:26.223563
# Unit test for function construct_rule

# Generated at 2022-06-20 22:07:32.748346
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'iptables'

# Generated at 2022-06-20 22:07:40.254537
# Unit test for function insert_rule
def test_insert_rule():
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': '5',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT'
    }
    cmd = ['/sbin/iptables','-t','filter','-I','INPUT', '5', '-p','tcp', '--destination-port','8080','-j','ACCEPT']
    assert insert_rule('/sbin/iptables', None, params) == cmd


# Generated at 2022-06-20 22:07:48.294300
# Unit test for function construct_rule
def test_construct_rule():
    """
    Test construct_rule method
    """
    params = dict(
        chain='INPUT',
        destination_port='80',
        protocol='tcp',
        jump='ACCEPT'
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '--dport', '80', '-j', 'ACCEPT'], \
        "Failed to construct rule"


# Generated at 2022-06-20 22:07:51.631020
# Unit test for function get_chain_policy
def test_get_chain_policy():
    entry = 'Chain INPUT (policy DROP)'
    assert get_chain_policy(None, None, entry) == 'DROP'



# Generated at 2022-06-20 22:08:18.800673
# Unit test for function append_param
def test_append_param():
    rule = []
    param = "76"
    flag = "--dport"
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['--dport', param]
    rule = []
    param = "!76"
    flag = "--dport"
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['!', '--dport', param[1:]]
    rule = []
    param = ["80", "443"]
    flag = "--dport"
    is_list = True
    append_param(rule, param, flag, is_list)
    assert rule == ['--dport', param[0], '--dport', param[1]]


# Generated at 2022-06-20 22:08:22.189503
# Unit test for function flush_table
def test_flush_table():
    module = None
    params = dict(
        table='filter',
        chain='INPUT'
    )
    flush_table('iptables', module, params)
    flush_table('ip6tables', module, params)



# Generated at 2022-06-20 22:08:24.754248
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'ACCEPT'
    jump = 'ACCEPT'
    append_jump(rule, param, jump)
    assert rule == ['-j', jump]



# Generated at 2022-06-20 22:08:28.824420
# Unit test for function append_rule
def test_append_rule():
    # Test for STDERR redirect
    cmd = ['/sbin/iptables', '-A', 'FORWARD', '-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP']

# Generated at 2022-06-20 22:08:36.392888
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule(argument_spec={})
    ipv4_version = get_iptables_version("iptables", module)
    ipv6_version = get_iptables_version("ip6tables", module)
    version_re = re.compile(r"\d+\.\d+\.\d+")
    assert version_re.match(ipv4_version)
    assert version_re.match(ipv6_version)



# Generated at 2022-06-20 22:08:50.567888
# Unit test for function main

# Generated at 2022-06-20 22:08:58.366711
# Unit test for function get_chain_policy
def test_get_chain_policy():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, cmd, check_rc=False):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    m = MockModule()
    # Provide values to make the function return what we expect.
    m.run_command_results = [
        (0, "Chain INPUT (policy DROP)\n", ''),
        (0, "Chain INPUT (policy ACCEPT)\n", ''),
        (0, "Chain INPUT (policy DROP)\n", ''),
    ]

    # get_chain_policy(iptables_path, module, params)
    assert get_

# Generated at 2022-06-20 22:09:06.521859
# Unit test for function append_param
def test_append_param():
    assert [(['--protocol', 'tcp'], 'tcp')] == [(append_param(['--protocol'], 'tcp', '--protocol', False), 'tcp')]
    assert [(['--source', '8.8.8.8'], '8.8.8.8')] == [(append_param(['--source'], '8.8.8.8', '--source', False), '8.8.8.8')]
    assert [([], '8.8.8.8')] == [(append_param([], '8.8.8.8', '--source', False), '8.8.8.8')]
    assert [([], '')] == [(append_param([], '', '--source', False), '')]

# Generated at 2022-06-20 22:09:12.311600
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, "owner", "owner")
    append_match(rule, None, "owner")
    assert rule == ['-m', 'owner'] or rule == []


# Generated at 2022-06-20 22:09:13.337069
# Unit test for function flush_table
def test_flush_table():
    if flush_table(1,2,3):
        return True
    else:
        return False



# Generated at 2022-06-20 22:09:35.706354
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, "match", "--syn", True)
    assert rule == ['--syn']



# Generated at 2022-06-20 22:09:42.305941
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    tcp_flags = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'FIN'],
    )

    append_tcp_flags(rule, tcp_flags, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,FIN']

    tcp_flags = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=[],
    )
    rule = []
    append_tcp_flags(rule, tcp_flags, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'NONE']


# Generated at 2022-06-20 22:09:46.612975
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--match', True)
    assert rule == ['--match']

    rule = []
    append_match_flag(rule, 'negate', '--match', True)
    assert rule == ['!', '--match']


# Generated at 2022-06-20 22:09:49.232090
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert '--tcp-flags' in rule
    assert 'ACK,RST,SYN,FIN' in rule
    assert 'ACK,RST,SYN' in rule


# Generated at 2022-06-20 22:09:50.956115
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    assert append_tcp_flags([], {'flags':['ACK','RST','SYN','FIN'], 'flags_set':['ALL']}, '--tcp-flags') == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ALL']


# Generated at 2022-06-20 22:09:53.738247
# Unit test for function append_jump
def test_append_jump():
    rule = []
    jump = 'ACCEPT'
    append_jump(rule, jump, jump)
    assert rule == ['-j', 'ACCEPT']
    rule = []
    append_jump(rule, None, None)
    assert rule == []



# Generated at 2022-06-20 22:10:09.347065
# Unit test for function construct_rule

# Generated at 2022-06-20 22:10:16.672975
# Unit test for function append_param
def test_append_param():
    l=[]
    append_param(l,"test_param","--flag",False)
    assert l == ["--flag","test_param"]

    l=[]
    append_param(l,"!test_param","--flag",False)
    assert l == ["!","--flag","test_param"]

    l=[]
    append_param(l,["test_param","!test_param1"], "--flag", True)
    assert l == ["--flag","test_param", "!","--flag","test_param1"]


# Generated at 2022-06-20 22:10:21.989308
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'hello', '--flag', False)
    assert rule == ['--flag', 'hello']

    rule = []
    append_param(rule, ['hello', 'world'], '--flag', True)
    assert rule == ['--flag', 'hello', '--flag', 'world']

    rule = []
    append_param(rule, '!hello', '--flag', False)
    assert rule == ['!', '--flag', 'hello']



# Generated at 2022-06-20 22:10:24.152096
# Unit test for function append_match_flag
def test_append_match_flag():

    rule = [ 'iptables' ]
    flag = '--syn'

    append_match_flag(rule, flag, None)
    assert rule == [ 'iptables', '--syn' ]

    append_match_flag(rule, 'negate', flag, True)
    assert rule == [ 'iptables', '--syn', '!', '--syn' ]



# Generated at 2022-06-20 22:10:58.350726
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['1', '2'], '--destination-port')
    assert rule == ['--destination-port', '1,2']
    append_csv(rule, ['1', '2', '3'], '--destination-port')
    assert rule == ['--destination-port', '1,2,3']
    append_csv(rule, [], '--destination-port')
    assert rule == ['--destination-port']
    append_csv(rule, None, '--destination-port')
    assert rule == []



# Generated at 2022-06-20 22:11:02.837612
# Unit test for function push_arguments
def test_push_arguments():
    p = dict(
        comment='comment',
        chain='INPUT',
        action='-A',
        ip_version='ipv4',
        table='filter',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match'
    )
    cmd = push_arguments('iptables', '-A', p)
    assert cmd == ['iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '--dport', '80', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-m', 'comment', '--comment', 'comment']


# Generated at 2022-06-20 22:11:17.945203
# Unit test for function construct_rule