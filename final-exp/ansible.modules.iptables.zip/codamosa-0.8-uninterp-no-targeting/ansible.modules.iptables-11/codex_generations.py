

# Generated at 2022-06-20 22:01:47.371527
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={})

    # Mock class module
    module.run_command = MagicMock(return_value=(0, "Success", ""))
    # Mock function push_arguments
    module.push_arguments = PUSH_ARGUMENTS

    params = {
        'table': '',
        'chain': '',
        'ip_version': ''
    }

    # Mock functioon check_present
    module.check_present = CHECK_PRESENT

    params = {
        'table': 'mocktable',
        'chain': 'mockchain',
        'ip_version': 'ipv4'
    }

    # Mock function push_arguments
    module.push_arguments = PUSH_ARGUMENTS


# Generated at 2022-06-20 22:01:50.091787
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('', '', {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-20 22:01:56.060283
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec={})
    result = check_present('iptables', module, {
        'chain': 'test_chain',
        'protocol': 'tcp',
        'table': 'test_table',
        })
    assert result == False


# Generated at 2022-06-20 22:02:06.207484
# Unit test for function construct_rule
def test_construct_rule():
    rule_1 = construct_rule(
        dict(
            table='filter',
            ip_version='ipv4',
            source='8.8.8.8',
            protocol='tcp',
            jump='DROP',
        )
    )

    assert '-A INPUT -s 8.8.8.8 -p tcp -j DROP' == ' '.join(rule_1)

    rule_2 = construct_rule(
        dict(
            table='filter',
            ip_version='ipv4',
            destination='8.8.8.8',
            protocol='tcp',
            jump='DROP',
        )
    )
    assert '-A INPUT -d 8.8.8.8 -p tcp -j DROP' == ' '.join(rule_2)

    rule_3 = construct_

# Generated at 2022-06-20 22:02:16.257871
# Unit test for function flush_table
def test_flush_table():
    param = {}

    # Invalid chain
    param['chain'] = 'AAAA'
    cmd = push_arguments('iptables', '-F', param, make_rule=False)
    assert cmd == ['iptables', '-t', 'filter', '-F', 'AAAA']
    cmd = push_arguments('ip6tables', '-F', param, make_rule=False)
    assert cmd == ['ip6tables', '-t', 'filter', '-F', 'AAAA']

    # Invalid table
    param['table'] = 'AAAA'
    cmd = push_arguments('iptables', '-F', param, make_rule=False)
    assert cmd == ['iptables', '-t', 'AAAA', '-F', 'AAAA']

# Generated at 2022-06-20 22:02:18.302915
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({})
    assert LooseVersion(get_iptables_version('/tmp/iptables', module))

# Generated at 2022-06-20 22:02:20.614473
# Unit test for function check_present
def test_check_present():
    """Validate that the check_present function works"""
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
            'arg1': dict(),
            'arg2': dict(),
        }
    )
    assert check_present(m, 'arg1', 'arg2')



# Generated at 2022-06-20 22:02:22.915560
# Unit test for function append_jump
def test_append_jump():
    rule = []
    rule_expected = ['-j', 'ACCEPT']
    param = 'ACCEPT'
    jump = 'ACCEPT'
    append_jump(rule, param, jump)
    assert rule == rule_expected
# End of Unit test for function append_jump


# Generated at 2022-06-20 22:02:29.185078
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    param = 'match'
    flag = 'test'
    negatable = True
    append_match_flag(rule, param, flag, negatable)
    assert rule == ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','test'], \
        "append_match_flag() should return '{0}' when the param is '{1}' and flag is '{2}'".format(rule, param, flag)
   

# Generated at 2022-06-20 22:02:32.382670
# Unit test for function append_match
def test_append_match():
    assert append_match([], None, 'tcp') == []
    assert append_match([], '', 'tcp') == []
    assert append_match([], 'match', 'tcp') == ['-m', 'tcp']


# Generated at 2022-06-20 22:02:49.690758
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path='iptables'

# Generated at 2022-06-20 22:03:00.363125
# Unit test for function append_param
def test_append_param():
    rule = []
    param = 'eth0'
    flag = '--in-interface'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['--in-interface', 'eth0']

    rule = []
    param = '!eth0'
    flag = '--in-interface'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['!', '--in-interface', 'eth0']

    rule = []
    param = ['eth0', 'eth1']
    flag = '--in-interface'
    is_list = True
    append_param(rule, param, flag, is_list)

# Generated at 2022-06-20 22:03:04.566807
# Unit test for function append_match
def test_append_match():
    assert append_match([], 'key', 'value') == ['-m', 'value']
    assert append_match([], None, 'value') == []



# Generated at 2022-06-20 22:03:13.571448
# Unit test for function insert_rule
def test_insert_rule():
    '''
    Test for function insert_rule
    '''
    iptables_path = 'iptables'
    module = MockModule()
    params = dict(
        chain='INPUT',
        action='append', # insert
        table='mangle',
        ip_version='ipv4',
        protocol='tcp',
        source='127.0.0.1',
        destination='127.0.0.1',
        destination_port='80',
        in_interface='eth0',
        out_interface='eth0',
        jump='ACCEPT',
    )
    cmd = push_arguments(iptables_path, '-I', params)
    # call function
    insert_rule(iptables_path, module, params)
    # check result
    assert module.run_command.call_count == 1


# Generated at 2022-06-20 22:03:16.506108
# Unit test for function append_rule
def test_append_rule():
  print("Testing append_rule")
  assert 1 == 2


# Generated at 2022-06-20 22:03:24.471703
# Unit test for function append_csv
def test_append_csv():
    assert ['--match', 'state', '--state', 'RELATED,ESTABLISHED'] == append_csv([], ['RELATED', 'ESTABLISHED'], '--state')
    assert ['--match', 'state', '--state', 'RELATED,ESTABLISHED'] == append_csv([], 'RELATED,ESTABLISHED', '--state')


# Generated at 2022-06-20 22:03:29.429889
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = '5'
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule[0] == '--wait'
    assert rule[1] == '5'
# -t table
# -p protocol
# -s source
# -sport source_port
# -d destination
# -dport destination_port
# -j jump
# -m match [-m match]

# Generated at 2022-06-20 22:03:30.537545
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'test'
    jump = 'test'
    assert append_jump(rule, param, jump) == None


# Generated at 2022-06-20 22:03:32.985946
# Unit test for function append_csv
def test_append_csv():
  rule = []
  param = ['1','2','3']
  flag = '-p'
  append_csv(rule, param, flag)

  assert(rule[1]=='1,2,3')


# Generated at 2022-06-20 22:03:37.257739
# Unit test for function push_arguments

# Generated at 2022-06-20 22:03:51.267071
# Unit test for function flush_table
def test_flush_table():
    cmd = ['/sbin/iptables', '-t', 'nat', '-F', 'INPUT']
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-20 22:03:56.895018
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule({})
    params = dict(chain='INPUT', ip_version='ipv4', policy='DROP', action='append', table='filter')
    assert get_chain_policy('iptables', module, params) is None


# Generated at 2022-06-20 22:03:58.456660
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables','') is not None



# Generated at 2022-06-20 22:03:59.864042
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', None, dict(table='filter', chain='INPUT', source='8.8.8.8', jump='DROP')) == True



# Generated at 2022-06-20 22:04:02.541941
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({})
    assert get_iptables_version("iptables", module) == "1.4.21"



# Generated at 2022-06-20 22:04:11.756562
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['ACK,RST,SYN', 'FIN'], 'flags_set': ['ACK', 'RST', 'SYN,FIN']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-20 22:04:14.728852
# Unit test for function append_param
def test_append_param():
    rule = []
    foo_param = ['foo', 'bar', '!baz']
    bar_param = 'foobar'
    append_param(rule, foo_param, '--foo', True)
    assert rule == ['--foo', 'foo', '--foo', 'bar', '!', '--foo', 'baz']
    append_param(rule, bar_param, '--bar', False)
    assert rule == ['--foo', 'foo', '--foo', 'bar', '!', '--foo', 'baz', '--bar', 'foobar']



# Generated at 2022-06-20 22:04:19.713021
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = [] 
    param = {'flags':['ALL'], 'flags_set': ['ACK','RST','SYN','FIN']}
    flag = '-m'
    append_tcp_flags(rule, param, flag)
    assert rule == ['-m', 'tcp', '--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-20 22:04:24.276048
# Unit test for function push_arguments

# Generated at 2022-06-20 22:04:28.929435
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule({})
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        comment='test',
    )
    assert check_present('/sbin/iptables', module, params)


# Generated at 2022-06-20 22:04:57.994949
# Unit test for function push_arguments

# Generated at 2022-06-20 22:04:59.110817
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-20 22:05:06.341741
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        protocol='tcp',
        in_interface='eth0',
        jump='DROP',
        rule_num=3,
        comment='Drop invalid packets'
    )
    cmd = push_arguments('iptables', '-I', params)
    assert cmd == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '3', '-p', 'tcp',
        '-i', 'eth0', '-j', 'DROP', '-m', 'comment', '--comment',
        'Drop invalid packets'
    ]



# Generated at 2022-06-20 22:05:14.010137
# Unit test for function append_csv
def test_append_csv():
    test_rule = []
    test_param = ['ESTABLISHED', 'RELATED']
    test_flag = '--ctstate'
    append_csv(test_rule,test_param,test_flag)
    assert test_rule == ['--ctstate', 'ESTABLISHED,RELATED']



# Generated at 2022-06-20 22:05:14.748947
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:05:19.604004
# Unit test for function check_present

# Generated at 2022-06-20 22:05:22.003394
# Unit test for function append_match_flag
def test_append_match_flag():
    append_match_flag(["iptables", "-A"], "match", "--tcp-flags", True)
    return rule


# Generated at 2022-06-20 22:05:23.768684
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    assert append_tcp_flags(rule, {'flags': ['SYN', 'ACK'], 'flags_set': ['SYN', 'ACK']}, flag) == [flag, 'SYN,ACK', 'SYN,ACK']



# Generated at 2022-06-20 22:05:32.346357
# Unit test for function append_jump
def test_append_jump():
    l=[]
    append_jump(l, 'ACCEPT', 'ACCEPT')
    if l != ['-j', 'ACCEPT']:
        raise Exception("Error")
    l=[]
    append_jump(l, None, 'ACCEPT')
    if l != []:
        raise Exception("Error")
    else:
        print ("test_append_jump is OK OK OK")
# CODING
test_append_jump()



# Generated at 2022-06-20 22:05:45.401745
# Unit test for function construct_rule
def test_construct_rule():
    C = construct_rule

    assert C(dict(chain='INPUT', source='1.1.1.1',
                  jump='ACCEPT')) == ['-s', '1.1.1.1', '-j', 'ACCEPT']

    assert C(dict(chain='INPUT', source='1.1.1.1',
                  jump='ACCEPT', match='comment')) == [
        '-s', '1.1.1.1', '-j', 'ACCEPT', '-m', 'comment']


# Generated at 2022-06-20 22:06:00.490936
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(iptables_path="iptables", module=None, params=dict(table='filter', chain='INPUT')) == "ACCEPT"



# Generated at 2022-06-20 22:06:07.642781
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec=dict(
        table=dict(required=True, type='str'),
        chain=dict(required=True, type='str'),
    ))
    flush_table('iptables-path', module, dict(
        table='table',
        chain='INPUT',
    ))
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['iptables-path', '-t', 'table', '-F', 'INPUT']



# Generated at 2022-06-20 22:06:19.716210
# Unit test for function check_present
def test_check_present():
    class M(object):
        def __init__(self):
            self.loaded_params = None
            self.run_command_params = []
        def set_loaded_params(self, p):
            self.loaded_params = p
        def run_command(self, p, check_rc=False):
            self.run_command_params.append(p)
            return (0, "", "")

    m = M()
    params = dict(
        rule_num=None,
        reject_with='reject_with_value',
        limit=None,
        ctstate=None,
        src_range=None,
        dst_range=None,
        reject_with=None)
    check_present('/bin/iptables', m, params)
    print(m.run_command_params)
   

# Generated at 2022-06-20 22:06:23.296891
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-20 22:06:33.261508
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'ACCEPT'
    jump = 'ACCEPT'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'ACCEPT']
    rule = []
    param = 'DROP'
    jump = 'DROP'
    append_jump(rule, param, jump)
    assert rule == ['-j', 'DROP']
    rule = []
    param = 'ACCEPT'
    jump = None
    append_jump(rule, param, jump)
    assert rule == ['-j', 'ACCEPT']
    rule = []
    param = None
    jump = 'DROP'
    append_jump(rule, param, jump)
    assert rule == ['j', 'DROP']
    rule = []
    param = None
    jump = None

# Generated at 2022-06-20 22:06:40.804105
# Unit test for function main

# Generated at 2022-06-20 22:06:46.956009
# Unit test for function construct_rule

# Generated at 2022-06-20 22:06:56.650688
# Unit test for function push_arguments
def test_push_arguments():
    par = dict(table='filter',
               chain='INPUT',
               protocol='tcp',
               destination_port='80',
               jump='ACCEPT',
               comment='ACCEPT ssh traffic',
               ip_version='ipv4')
    cmd = push_arguments('iptables', '-A', par)
    assert cmd == ['iptables',
                   '-t', par['table'],
                   '-A', par['chain'],
                   '-p', par['protocol'],
                   '--destination-port', par['destination_port'],
                   '-j', par['jump'],
                   '-m', 'comment',
                   '--comment', par['comment']]


# Generated at 2022-06-20 22:07:02.854848
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN'],
    )
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']


# Generated at 2022-06-20 22:07:07.881192
# Unit test for function append_match
def test_append_match():
    rule = []
    param = 'conntrack'
    match = 'conntrack'
    append_match(rule, param, match)
    assert rule == ['-m', 'conntrack']


# Generated at 2022-06-20 22:07:24.174849
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['ESTABLISHED','RELATED']
    flag = '--ctstate'

    append_csv(rule, param, flag)
    assert rule == ['--ctstate', 'ESTABLISHED,RELATED']


# Generated at 2022-06-20 22:07:27.625365
# Unit test for function append_wait
def test_append_wait():
    rule = []
    expect_rule = []
    append_wait(rule, "10", "--wait")
    expect_rule.extend(["--wait", "10"])
    assert rule == expect_rule
    rule = []
    expect_rule = []
    append_wait(rule, "0", "--wait")
    assert rule == expect_rule
    rule = []
    expect_rule = []
    append_wait(rule, "", "--wait")
    assert rule == expect_rule



# Generated at 2022-06-20 22:07:30.967159
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', {'run_command' : lambda cmd, check_rc: (0, 'iptables v1.4.20', '')}) == '1.4.20'
    assert get_iptables_version('iptables', {'run_command' : lambda cmd, check_rc: (1, 'iptables v1.4.20', '')}) is None



# Generated at 2022-06-20 22:07:31.820638
# Unit test for function set_chain_policy
def test_set_chain_policy():
    pass

# Generated at 2022-06-20 22:07:38.061777
# Unit test for function append_match_flag
def test_append_match_flag():
    test_rule = []
    append_match_flag(test_rule, 'match', '--syn', True)
    assert test_rule == ['--syn']

    test_rule = []
    append_match_flag(test_rule, 'negate', '--syn', True)
    assert test_rule == ['!', '--syn']

    test_rule = []
    append_match_flag(test_rule, None, '--syn', True)
    assert test_rule == []



# Generated at 2022-06-20 22:07:42.746760
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['foo', 'bar']
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert rule == ['--ctstate', 'foo,bar']



# Generated at 2022-06-20 22:07:55.257657
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path='/sbin/iptables'
    module=None
    params={
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        'action': 'delete',
        'state': 'present',
        'protocol': 'tcp',
        'destination_port': '22',
        'ctstate': ['NEW'],
        'syn': 'match',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.',
        'set_counters': None,
        'reject_with': None,
        'ip_version': 'ipv4',
        'iptables_version': '1.4.21',
        'iptables_wait_support': False,
    }

# Generated at 2022-06-20 22:08:01.990261
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(
        argument_spec=dict(
            chain=dict(type='str'),
            ip_version=dict(type='str'),
        )
    )
    params = {
        'chain': 'INPUT',
        'ip_version': 'ipv4',
    }
    rc = check_present('iptables', module, params)
    assert rc == True
# -- end unit test



# Generated at 2022-06-20 22:08:07.820855
# Unit test for function append_rule
def test_append_rule():
    iptables_path = "/sbin/iptables"
    module = AnsibleModule({'module': 'test'})
    params = {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'jump': 'ACCEPT', 'destination_port': '80'}
    assert push_arguments(iptables_path, '-A', params) == ['/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-j', 'ACCEPT', '--destination-port', '80']



# Generated at 2022-06-20 22:08:16.581021
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = MockModule(params={'ip_version': 'ipv4', 'chain': 'INPUT', 'policy': 'ACCEPT', 'state': 'present'})
    set_chain_policy('iptables', module, module.params)
    assert module.run_command.called
    assert module.run_command.call_args[0][0] == ['iptables', '-P', 'INPUT', 'ACCEPT']


# Generated at 2022-06-20 22:08:50.755764
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    from io import StringIO
    module = AnsibleModule()
    output = StringIO('iptables v1.4.6')
    module.run_command = lambda args: (0, output.read(), '')
    assert(get_iptables_version('iptables', module) == '1.4.6')
    output = StringIO('iptables v1.4.6 (nf_tables)')
    module.run_command = lambda args: (0, output.read(), '')
    assert(get_iptables_version('iptables', module) == '1.4.6')



# Generated at 2022-06-20 22:08:53.611327
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['ESTABLISHED', 'RELATED']
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert rule == ['--ctstate', 'ESTABLISHED,RELATED']



# Generated at 2022-06-20 22:08:59.624378
# Unit test for function append_csv
def test_append_csv():
    rule = []
    append_csv(rule, ['ACK', 'RST', 'SYN'], '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN']
    rule = []
    append_csv(rule, None, '--tcp-flags')
    assert rule == []


# Generated at 2022-06-20 22:09:04.033690
# Unit test for function construct_rule
def test_construct_rule():
    rule_1 = (
        '-p tcp --destination-port 22 -j ACCEPT -m comment '
        '--comment "Accept new SSH connections."')
    params_1 = {
        'protocol': 'tcp',
        'destination_port': '22',
        'jump': 'ACCEPT',
        'match': ['comment'],
        'comment': 'Accept new SSH connections.',
        'ip_version': 'ipv4',
    }
    rule_2 = (
        '--limit 2/second --limit-burst 20 -j LOG --log-prefix '
        '"IPTABLES:INFO: " --log-level info')

# Generated at 2022-06-20 22:09:08.949189
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    assert ['-m', 'tcp', '--tcp-flags', 'SYN,RST,ACK,FIN', 'ACK,RST,SYN,FIN'] == append_tcp_flags([], dict(flags=['SYN', 'RST', 'ACK', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN']), '--tcp-flags')
    assert ['-m', 'tcp', '--tcp-flags', 'SYN,RST,ACK,FIN', 'ACK,RST,SYN,FIN'] == append_tcp_flags([], dict(flags=['SYN,RST,ACK,FIN'], flags_set=['ACK,RST,SYN,FIN']), '--tcp-flags')



# Generated at 2022-06-20 22:09:14.324868
# Unit test for function append_csv
def test_append_csv():
    rule = ['iptables', '-A', 'INPUT']
    param = ['ESTABLISHED', 'NEW']
    flag = '-m'
    append_csv(rule, param, flag)
    assert rule == ['iptables', '-A', 'INPUT', '-m', 'ESTABLISHED,NEW']


# Generated at 2022-06-20 22:09:15.749230
# Unit test for function append_jump
def test_append_jump():
    rule = [ ]
    param = 'test'
    jump = 'testjump'
    assert append_jump(rule,param,jump) == ['-j', 'testjump']



# Generated at 2022-06-20 22:09:20.023220
# Unit test for function insert_rule
def test_insert_rule():
    module = AnsibleModule(argument_spec={})
    params =  dict(
      chain='INPUT',
      ip_version='ipv4',
      jump='ACCEPT',
      protocol='tcp',
      destination_port='8080'
    )
    iptables_path = '/sbin/iptables'
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']
    iptables_path = '/sbin/iptables'
    params['rule_num'] = 5
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd

# Generated at 2022-06-20 22:09:29.309716
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['FIN', 'SYN', 'RST', 'ACK', 'URG', 'PSH', 'ALL'], 'flags_set': ['FIN', 'SYN', 'RST', 'ACK', 'URG', 'PSH']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'FIN,SYN,RST,ACK,URG,PSH,ALL', 'FIN,SYN,RST,ACK,URG,PSH']



# Generated at 2022-06-20 22:09:30.808881
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:10:24.683715
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    expected_rule = [
        '--match',
        'tcp',
        '--tcp-flags',
        'ACK,RST,SYN,FIN',
        'ACK,RST,SYN,FIN',
    ]
    rule = list()
    tcp_flags = dict(
        flags=['ACK','RST','SYN','FIN'],
        flags_set=['ACK','RST','SYN','FIN']
    )
    append_tcp_flags(rule, tcp_flags, '--tcp-flags')
    assert (rule == expected_rule)


# Generated at 2022-06-20 22:10:27.640594
# Unit test for function append_jump
def test_append_jump():
    assert append_jump([], 'DROP', 'DROP') == ['-j', 'DROP']
    assert append_jump([], 'ACCEPT', 'ACCEPT') == ['-j', 'ACCEPT']
    assert append_jump([], '', '') == []


# Generated at 2022-06-20 22:10:40.283207
# Unit test for function check_present

# Generated at 2022-06-20 22:10:47.879371
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {}
    param['flags'] = ['ALL']
    param['flags_set'] = ['ACK', 'RST', 'SYN', 'FIN']
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-20 22:10:51.016604
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule()
    flush_table('iptables', module, {'chain': 'INPUT', 'table': 'filter', 'state': 'present'})



# Generated at 2022-06-20 22:10:58.307662
# Unit test for function get_chain_policy
def test_get_chain_policy():
    out = "Chain INPUT (policy DROP)\n"
    assert get_chain_policy(None, None, None, out) == "DROP"
    out = "Chain INPUT (policy ACCEPT)\n"
    assert get_chain_policy(None, None, None, out) == "ACCEPT"
    out = "Chain INPUT (policy default ACCEPT)\n"
    assert get_chain_policy(None, None, None, out) == "ACCEPT"



# Generated at 2022-06-20 22:11:05.433487
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['ESTABLISHED', 'RELATED']
    flag = '--ctstate'
    append_csv(rule, param, flag)
    assert rule == ['--ctstate', 'ESTABLISHED,RELATED']
    rule = []
    param = ['ESTABLISHED']
    append_csv(rule, param, flag)
    assert rule == ['--ctstate', 'ESTABLISHED']



# Generated at 2022-06-20 22:11:08.611420
# Unit test for function append_jump
def test_append_jump():
    rule = []
    append_jump(rule, 'ACCEPT', 'ACCEPT')
    assert rule == ['-j','ACCEPT']
    rule = []
    append_jump(rule, '', 'ACCEPT')
    assert rule == []



# Generated at 2022-06-20 22:11:11.035966
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '3', '')
    assert rule == ['']


# Generated at 2022-06-20 22:11:16.503969
# Unit test for function check_present
def test_check_present():
  iptables_path = "iptables"
  params = dict(table="filter",
                chain="INPUT",
                ip_version="ipv4",
                source="1.1.1.1",
                jump="ACCEPT")
  command = ["iptables", "-t", "filter", "-C", "INPUT", "-s", "1.1.1.1", "-j", "ACCEPT"]
  if cmd == command:
    return 0
  else:
    return 1