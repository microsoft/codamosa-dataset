

# Generated at 2022-06-20 22:01:53.382103
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", "INPUT", "DROP") == "DROP"
    assert get_chain_policy("iptables", "INPUT", "ACCEPT") == "ACCEPT"
    assert get_chain_policy("iptables", "INPUT", "ACCEPT") == "ACCEPT"
    assert get_chain_policy("iptables", "INPUT", "NONE") == None


# Generated at 2022-06-20 22:02:00.849892
# Unit test for function append_param
def test_append_param():
    rule = []
    param = 'test'
    flag = '--test-flag'
    is_list = False
    append_param(rule, param, flag, is_list)
    assert rule == ['--test-flag', 'test']

    rule = []
    param = ['test1', '!test2']
    flag = '--test-flag'
    is_list = True
    append_param(rule, param, flag, is_list)
    assert rule == ['--test-flag', 'test1', '!', '--test-flag', 'test2']



# Generated at 2022-06-20 22:02:06.272716
# Unit test for function insert_rule
def test_insert_rule():
    args = {'action': 'insert', 'chain': 'INPUT',
            'destination_port': '80', 'ip_version': 'ipv4',
            'jump': 'ACCEPT',
            'protocol': 'tcp', 'rule_num': 5,
            'table': 'filter', 'wait': '3'}
    assert insert_rule('iptables', module={}, params=args) == [
        'iptables',
        '-t',
        'filter',
        '-I',
        'INPUT',
        '5',
        '-w',
        '3',
        '-p',
        'tcp',
        '--dport',
        '80',
        '-j',
        'ACCEPT'
    ]



# Generated at 2022-06-20 22:02:11.845600
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, 'match')
    assert(rule == ['-m', 'match'])
    rule = []
    append_match(rule, False, 'match')
    assert(rule == [])



# Generated at 2022-06-20 22:02:23.302706
# Unit test for function main
def test_main():
    import sys
    
    # Get arguments from command line
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 22:02:24.648995
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = "RETURN"
    jump = param
    append_jump(rule, param, jump)
    assert rule == ['-j', 'RETURN']


# Generated at 2022-06-20 22:02:30.682117
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(None, 'match', '--udp', True) == None
    assert append_match_flag(None, 'negate', '--udp', True) == None
    assert append_match_flag(None, 'foo', '--udp', True) == None
    assert append_match_flag(None, 'match', '--udp', False) == None
    assert append_match_flag(None, 'negate', '--udp', False) == None
    assert append_match_flag(None, 'foo', '--udp', False) == None
    assert append_match_flag([], 'match', '--udp', True) == ['--udp']
    assert append_match_flag([], 'negate', '--udp', True) == ['!', '--udp']
    assert append

# Generated at 2022-06-20 22:02:45.467899
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network import NetworkModule


# Generated at 2022-06-20 22:02:58.282097
# Unit test for function remove_rule
def test_remove_rule():
    import os
    from ansible.utils.hashing import md5s

    iptables_path = os.getcwd() + '/hist/iptables'
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-20 22:03:04.550486
# Unit test for function insert_rule
def test_insert_rule():
    module_params = {
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'insert',
        'rule_num': '5',
    }

    iptables_path = '/sbin/iptables'

    cmd = push_arguments(iptables_path, '-I', module_params)
    print(cmd)



# Generated at 2022-06-20 22:03:22.528497
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4'
    )
    assert construct_rule(params) == ['-w', '-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-20 22:03:24.770225
# Unit test for function append_jump
def test_append_jump():
    rule = ['']
    append_jump(rule, 'CT', 'CT')
    append_jump(rule, 'DROP', 'DROP')
    append_jump(rule, 'ACCEPT', 'ACCEPT')

# Generated at 2022-06-20 22:03:30.015549
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils import basic
    params = {
        'jump': 'ACCEPT',
        'protocol': 'tcp',
        'destination_port': '22',
        'ctstate': 'NEW',
        'syn': 'match',
        'chain': 'INPUT',
        'table': 'filter',
        'ip_version': 'ipv4'
        }
    assert check_present('iptables', basic.AnsibleModule(argument_spec={}), params)



# Generated at 2022-06-20 22:03:34.416914
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    flag = '--syn'
    negatable = True

    append_match_flag(rule, param, flag, negatable)
    assert len(rule) == 1
    assert rule == ['--syn']
    rule = []
    param = 'negate'
    flag = '--syn'
    negatable = True

    append_match_flag(rule, param, flag, negatable)
    assert len(rule) == 2
    assert rule == ['!', '--syn']


# Generated at 2022-06-20 22:03:45.686835
# Unit test for function insert_rule
def test_insert_rule():
    """
    Insert a rule on line 5
    ansible.builtin.iptables:
      chain: INPUT
      protocol: tcp
      destination_port: 8080
      jump: ACCEPT
      action: insert
      rule_num: 5
    """
    # Test some specific values for result code, stdout and stderr
    def test_run_command_basic(module, rc, out, err):
        cmd = '/usr/sbin/iptables -A INPUT -p tcp --dport 8080 -j ACCEPT'
        args = dict(
            cmd=cmd,
            check_rc=True
        )
        module.run_command(cmd, **args)
        return (rc, out, err)

    mock = {
        'run_command.side_effect': test_run_command_basic
    }

# Generated at 2022-06-20 22:03:46.983236
# Unit test for function append_rule
def test_append_rule():

    assert append_rule('iptables','module','params') == None


# Generated at 2022-06-20 22:03:50.736375
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = "10"
    flag = "--wait"
    append_wait(rule, param, flag)
    assert(rule == ['--wait', '10'])



# Generated at 2022-06-20 22:03:57.096889
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'something', '--syn', False)
    assert rule == []



# Generated at 2022-06-20 22:04:08.328490
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], 'match', '--syn', True) == ['--syn']
    assert append_match_flag([], 'negate', '--syn', True) == ['!', '--syn']
    assert append_match_flag([], '', '--syn', False) == []
    assert append_match_flag([], '', '--syn', True) == []
    assert append_match_flag([], None, '--syn', True) == []
    assert append_match_flag([], None, '--syn', False) == []


# Generated at 2022-06-20 22:04:15.761202
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    flag = '--tcp-flags'
    param = {}
    param['flags'] = []
    param['flags_set'] = []
    param['flags_set'].append('ACK')
    param['flags_set'].append('RST')
    param['flags_set'].append('SYN')
    param['flags_set'].append('FIN')
    rule = []
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-20 22:04:45.294163
# Unit test for function append_wait
def test_append_wait():
    assert append_wait(['-N'], '-wait', '-I') == ['-N','-I', '-wait']
    assert append_wait(['-N'], '3', '-I') == ['-N','-I' ,'3']
    assert append_wait(['-N'], '1/SECOND', '-I') == ['-N','-I' ,'1/SECOND']
    assert append_wait(['-N'], '1/MINUTE', '-I') == ['-N','-I' ,'1/MINUTE']
    assert append_wait(['-N'], '1/HOUR', '-I') == ['-N','-I' ,'1/HOUR']

# Generated at 2022-06-20 22:04:48.116771
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-20 22:05:00.685509
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest

    real_bin_path = sys.argv[0]
    sys.argv[0] = 'ansible-test'



# Generated at 2022-06-20 22:05:06.225158
# Unit test for function append_match
def test_append_match():
    rule = []
    param = True
    match = 'conntrack'
    append_match(rule, param, match)
    assert rule == ['-m', match]



# Generated at 2022-06-20 22:05:11.792406
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    append_match_flag(rule, 'negate', '--syn', True)
    append_match_flag(rule, None, '--syn', False)
    assert rule == ['--syn', '!', '--syn'], 'append_match_flag failed'



# Generated at 2022-06-20 22:05:22.724051
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        ip_version='ipv4',
        table='filter',
        rule_num='1',
        protocol='udp',
        destination='10.0.0.1',
        destination_port='53',
        jump='ACCEPT',
        comment='Example: Allow DNS',
        chain='INPUT',
        )
    iptables_path = "/sbin/iptables"
    cmd = push_arguments(iptables_path, '-I', params, make_rule=True)

# Generated at 2022-06-20 22:05:24.687976
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = ['1', '2', '3']
    flag = 'flag'
    assert append_csv(rule, param, flag) == None
    assert rule == ['flag', '1,2,3']



# Generated at 2022-06-20 22:05:25.404535
# Unit test for function remove_rule
def test_remove_rule():
    assert True


# Generated at 2022-06-20 22:05:27.329359
# Unit test for function append_match
def test_append_match():
    rule = [ ]
    param = 'tcp'
    match = 'tcp'
    append_match(rule, param, match)
    assert rule == ['-m', 'tcp']
test_append_match()



# Generated at 2022-06-20 22:05:30.552161
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec={
        'chain': {'required': True},
        'policy': {'required': True, 'choices': ['ACCEPT', 'DROP', 'QUEUE', 'RETURN']},
        'table': {'required': False, 'default': 'filter'},
        'ip_version': {'required': False, 'default': 'ipv4'},
    })
    params = module.params
    assert set_chain_policy('iptables', module, params) == None



# Generated at 2022-06-20 22:06:01.702988
# Unit test for function remove_rule

# Generated at 2022-06-20 22:06:02.980961
# Unit test for function append_match
def test_append_match():
    assert append_match([], True, 'match') == ['-m', 'match']
    assert append_match([], False, 'match') == []


# Generated at 2022-06-20 22:06:08.720215
# Unit test for function append_param
def test_append_param():
    assert append_param([], '1.2.3.4', '--source', False) == ['--source', '1.2.3.4']
    assert append_param([], '!1.2.3.4', '--source', False) == ['!', '--source', '1.2.3.4']
    assert append_param([], ['1.2.3.4'], '--source', True) == ['--source', '1.2.3.4']
    assert append_param([], ['!1.2.3.4'], '--source', True) == ['!', '--source', '1.2.3.4']



# Generated at 2022-06-20 22:06:11.482619
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(policy='ACCEPT', chain='INPUT', table='mangle')) == 'ACCEPT'



# Generated at 2022-06-20 22:06:16.590775
# Unit test for function append_csv
def test_append_csv():
    rule = []
    param = [ 'ESTABLISHED', 'RELATED' ]
    flag = '--ctstate'
    actual = append_csv(rule, param, flag)
    expected = ['--ctstate', 'ESTABLISHED,RELATED']
    assert actual == expected


# Generated at 2022-06-20 22:06:18.682463
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(['match'], 'match', 'test', True) == ['test']
    assert append_match_flag(['negate'], 'negate', 'test', True) == ['!', 'test']
    assert append_match_flag(['test', 'test'], 'negate', '!', False) == ['test', 'test']



# Generated at 2022-06-20 22:06:20.237894
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({}, check_invalid_arguments=False)
    assert get_iptables_version('/sbin/iptables', module) == '1.6.1'
test_get_iptables_version()



# Generated at 2022-06-20 22:06:21.416888
# Unit test for function set_chain_policy
def test_set_chain_policy():
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-20 22:06:31.753506
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, None, 'flag', False)
    assert rule == []
    append_param(rule, 'param', 'flag', False)
    assert rule == ['flag', 'param']
    append_param(rule, ['a', 'b'], 'flag', True)
    assert rule == ['flag', 'param', 'flag', 'a', 'flag', 'b']
    rule = []
    append_param(rule, '!param', 'flag', False)
    assert rule == ['!', 'flag', 'param']
    append_param(rule, ['!a', 'b'], 'flag', True)
    assert rule == ['!', 'flag', 'a', 'flag', 'b']



# Generated at 2022-06-20 22:06:40.432498
# Unit test for function main
def test_main():
    import pytest
    import tempfile

    # Test with missing required arguments
    with pytest.raises(SystemExit):
        main()

    # Test with required arguments which generate failure
    with pytest.raises(AnsibleFailJson):
        with pytest.raises(SystemExit):
            module = MagicMock(params={'ip_version': 'ipv4',
                                       'table': 'filter',
                                       'chain': 'FORWARD'})
            main(module)

    # Test with required args which should generate success

# Generated at 2022-06-20 22:07:04.584747
# Unit test for function remove_rule
def test_remove_rule():
    for action, result in tests_remove_rule:
        if remove_rule(action['iptables_path'], action['module'], action['params']):
            print('Rule should be removed from chain')
        else:
            print('Rule has not been removed from chain')



# Generated at 2022-06-20 22:07:14.662542
# Unit test for function main

# Generated at 2022-06-20 22:07:18.668855
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, '80', '--dport', False)
    assert rule == ['--dport', '80']
    rule = []
    append_param(rule, '80', '--dport', True)
    assert rule == ['--dport', '80']
    rule = []
    append_param(rule, [1, '80', '!90'], '--dport', True)
    assert rule == ['--dport', '1', '--dport', '80', '!', '--dport', '90']


# Generated at 2022-06-20 22:07:24.862500
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule()
    action = 'insert'
    table = 'filter'
    chain = 'INPUT'
    rule_num = '5'
    protocol = 'tcp'
    destination_port = '8080'
    jump = 'ACCEPT'
    params = [action, table, chain, rule_num, protocol, destination_port, jump]
    cmd = push_arguments(iptables_path, '-I', params)
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-20 22:07:31.401956
# Unit test for function append_rule
def test_append_rule():
    '''
    Test append_rule
    '''
    import os
    tmpdir = os.path.dirname(os.path.abspath(__file__))
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

# Generated at 2022-06-20 22:07:43.408727
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 22:07:55.777624
# Unit test for function check_present

# Generated at 2022-06-20 22:08:01.786254
# Unit test for function remove_rule
def test_remove_rule():
    module = AnsibleModule({})
    params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4',
        rule_num='6',
    )
    cmd = push_arguments('iptables', '-D', params)
    module.run_cmd(cmd, check_rc=True)



# Generated at 2022-06-20 22:08:09.048492
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['RST', 'ACK', 'SYN', 'FIN'], flags_set=['FIN'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert ('--tcp-flags', 'RST,ACK,SYN,FIN', 'FIN') == tuple(rule)


# Generated at 2022-06-20 22:08:18.101912
# Unit test for function get_chain_policy
def test_get_chain_policy():
    def run_command(cmd, check_rc=False):
        return 0, 'Chain INPUT (policy DROP)  ', None
    class Options:
        def __init__(self, module):
            self.module = module
            self.table = 'filter'
            self.chain = 'INPUT'
    options = Options(Options)
    options.module.run_command = run_command
    assert get_chain_policy('iptables', options.module, options) == 'DROP'


# Generated at 2022-06-20 22:08:44.167751
# Unit test for function get_iptables_version
def test_get_iptables_version():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    cmd = ['iptables', '--version']
    rc = test_module.run_command(cmd, check_rc=True)
    print(rc)



# Generated at 2022-06-20 22:08:49.981140
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, dict(table='filter', chain='INPUT')) == 'ACCEPT'
    assert get_chain_policy('iptables', None, dict(table='filter', chain='OUTPUT')) == 'ACCEPT'
    assert get_chain_policy('iptables', None, dict(table='filter', chain='FORWARD')) == 'ACCEPT'



# Generated at 2022-06-20 22:08:57.637960
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    param = 'match'
    flag = 'flag'
    negatable = True
    exp_rule = ['flag']
    append_match_flag(rule, param, flag, negatable)
    assert(rule == exp_rule)
    param = 'negate'
    exp_rule = ['flag', '!', 'flag']
    append_match_flag(rule, param, flag, negatable)
    assert(rule == exp_rule)
    param = 'something'
    exp_rule = ['flag', '!', 'flag']
    append_match_flag(rule, param, flag, negatable)
    assert(rule == exp_rule)
    param = None
    exp_rule = ['flag', '!', 'flag']
    append_match_flag(rule, param, flag, negatable)

# Generated at 2022-06-20 22:09:01.254084
# Unit test for function flush_table
def test_flush_table():    
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict(chain=dict(required=True)))
    module.run_command = MagicMock()
    module.run_command.return_value = (0, '', '')
    table = 'filter'

    params = dict(chain='test',
                  table=table)
    flush_table(iptables_path, module, params)
    module.run_command.assert_called_with(['/sbin/iptables', '-t', 'filter', '-F', 'test'])



# Generated at 2022-06-20 22:09:09.096939
# Unit test for function push_arguments

# Generated at 2022-06-20 22:09:11.435468
# Unit test for function set_chain_policy
def test_set_chain_policy():
    """Unit test for set_chain_policy"""
    params = {'chain': 'INPUT', 'policy': 'DROP'}
    assert set_chain_policy('/sbin/iptables', {'module': None}, params) == (
        ['/sbin/iptables', '-t', 'filter', '-P', 'INPUT', 'DROP'])



# Generated at 2022-06-20 22:09:16.434314
# Unit test for function append_rule
def test_append_rule():
    module = FakeModule()
    iptables_path = '/usr/bin/iptables'

# Generated at 2022-06-20 22:09:22.983953
# Unit test for function construct_rule

# Generated at 2022-06-20 22:09:26.969833
# Unit test for function append_jump
def test_append_jump():
    assert append_jump([], 'ACCEPT', 'ACCEPT') == ['-j', 'ACCEPT']
    assert append_jump([], None, 'ACCEPT') == []


# Generated at 2022-06-20 22:09:28.337616
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule(iptables_path, module, params) == cmd



# Generated at 2022-06-20 22:10:30.446854
# Unit test for function push_arguments
def test_push_arguments():
    assert [
        'iptables',
        '-t', 'filter',
        '-A', 'INPUT',
        '-p', 'tcp',
        '-j', 'ACCEPT'
    ] == push_arguments('iptables', '-A', dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4',
        protocol='tcp',
        jump='ACCEPT'
    ))



# Generated at 2022-06-20 22:10:35.252392
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = '10'
    flag = '--wait'
    append_wait(rule, param, flag)
    assert rule == [flag, param]

# Generated at 2022-06-20 22:10:51.123575
# Unit test for function push_arguments

# Generated at 2022-06-20 22:10:55.350248
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(
        ip_version = 'ipv4',
        policy='DROP',
        chain='INPUT',
        table='filter',
        wait=None
    )
    iptables_path = 'iptables'
    iptables_path = '/sbin/iptables'
    module = dict(
        run_command = lambda x, check_rc: (0, None, None),
    )
    cmds = set_chain_policy(iptables_path, module, params)


# Generated at 2022-06-20 22:10:57.730932
# Unit test for function append_jump
def test_append_jump():
    rule = list()
    append_jump(rule, 'ACCEPT', 'ACCEPT')



# Generated at 2022-06-20 22:11:12.780610
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = 'test'
    class module:
        def run_command(*args):
            arglist = args[1]
            if arglist[0] == 'test' and arglist[1] == '-t' and arglist[2] == 'nat' and arglist[3] == '-D' and arglist[4] == 'PREROUTING' and (arglist[5] == '-w' or arglist[5] == '-s') and arglist[6] == '10.10.10.10' and arglist[7] == '-p' and arglist[8] == 'tcp' and arglist[9] == '-j' and arglist[10] == 'ACCEPT':
                return (0, '', '')
            else:
                return (1, '', '')
   