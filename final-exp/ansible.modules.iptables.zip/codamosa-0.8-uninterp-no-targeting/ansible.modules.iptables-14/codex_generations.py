

# Generated at 2022-06-20 22:01:41.158287
# Unit test for function append_wait
def test_append_wait():
    rule = []
    ansible_module = AnsibleModule(
        argument_spec=dict(
            binary='',
            wait='10'
        )
    )
    result = append_wait(rule, ansible_module.params['wait'], '--wait')
    assert result == [ '--wait', '10' ]
    ansible_module = AnsibleModule(
        argument_spec=dict(
            binary='',
            wait=''
        )
    )
    result = append_wait(rule, ansible_module.params['wait'], '--wait')
    assert result == []


# Generated at 2022-06-20 22:01:48.543342
# Unit test for function main
def test_main():
    IPTABLES_OUTPUT = {
        'ipv4': 'iptables v1.4.21',
        'ipv6': 'ip6tables v1.4.21',
    }
    WAIT_SUPPORTED_STR = '--wait is supported'
    WAIT_NOT_SUPPORTED_STR = '--wait is not supported'


# Generated at 2022-06-20 22:01:56.381396
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test_data = [
        (
            'Chain OUTPUT (policy ACCEPT)',
            'ACCEPT',
        ),
        (
            'Chain OUTPUT',
            None,
        )
    ]
    for data in test_data:
        result = get_chain_policy('iptables', None, dict(chain='OUTPUT'))
        assert result == data[1]



# Generated at 2022-06-20 22:02:01.222630
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule1 = []
    flag1 = '--tcp-flags'
    append_tcp_flags(rule1,
            dict(flags=['ACK','RST','SYN', 'FIN'], flags_set=['ACK','RST','SYN', 'FIN']), flag1)
    assert rule1 == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-20 22:02:02.549690
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", [], None, "INPUT") == "ACCEPT"



# Generated at 2022-06-20 22:02:08.303639
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, "10", "-w")
    assert rule == ['-w', '10']
    rule = []
    append_wait(rule, "10s", "--wait")
    assert rule == ['--wait', '10s']
    rule = []
    append_wait(rule, '1/second', "--wait")
    assert rule == ['--wait', '1/second']
    rule = []
    append_wait(rule, '1/s', "--wait")
    assert rule == ['--wait', '1/s']
    rule = []
    append_wait(rule, '1/day', "--wait")
    assert rule == ['--wait', '1/day']
    rule = []
    append_wait(rule, '1/d', "--wait")

# Generated at 2022-06-20 22:02:17.388971
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    def assertListItemsEqual(list1, list2):
        assert len(list1) == len(list2)
        for i in range(len(list1)):
            assert list1[i] == list2[i]

    rule=[]
    param={'flags': ['ALL', 'NONE'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}
    expected_list=['--tcp-flags', 'ALL,NONE', 'ACK,RST,SYN,FIN']
    append_tcp_flags(rule, param, '--tcp-flags')
    assertListItemsEqual(rule, expected_list)


# Generated at 2022-06-20 22:02:21.577520
# Unit test for function append_jump
def test_append_jump():
    rule = []
    param = 'ACCEPT'
    jump = 'ACCEPT'
    append_jump(rule, param, jump)
    assert rule[0] == '-j'
    assert rule[1] == 'ACCEPT'


# Generated at 2022-06-20 22:02:23.370659
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version("iptables", test_module) == IPTABLES_VERSION

# Generated at 2022-06-20 22:02:25.082085
# Unit test for function append_match
def test_append_match():
    rule = []
    append_match(rule, True, 'ctstate')
    assert rule == ['-m','ctstate']
    rule = []
    append_match(rule, False, 'ctstate')
    assert rule == []



# Generated at 2022-06-20 22:02:52.828625
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {"table": "filter", "chain": "INPUT"}) == "ACCEPT"
    assert get_chain_policy(None, None, {"table": "filter", "chain": "FORWARD"}) == "DROP"
    assert get_chain_policy(None, None, {"table": "filter", "chain": "OUTPUT"}) is None


# Generated at 2022-06-20 22:02:57.898665
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        src=None,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='test comment',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'test comment']



# Generated at 2022-06-20 22:03:02.438327
# Unit test for function flush_table
def test_flush_table():
    args = {
        'table' : 'nat',
        'chain' : 'OUTPUT',
    }
    params = dict(chain='nat', flush=True)
    params.update(args)
    flush_table('iptables', test_module, params)
# end of unit test



# Generated at 2022-06-20 22:03:04.584966
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, '5', 'flag')
    assert rule == ['flag', '5']



# Generated at 2022-06-20 22:03:09.741202
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'invalid', '--syn', True)
    assert rule == []



# Generated at 2022-06-20 22:03:16.299258
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, ['1', '2', '3'], '--protocol', True)
    assert rule == ['--protocol', '1', '--protocol', '2', '--protocol', '3']

    rule = []
    append_param(rule, ['1', '2', '3'], '--protocol', False)
    assert rule == ['--protocol', '1', '--protocol', '2', '--protocol', '3']

    rule = []
    append_param(rule, 'abc', '--protocol', True)
    assert rule == ['--protocol', 'abc']


# Generated at 2022-06-20 22:03:19.887926
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, "2", "--wait 2")
    assert rule == ["--wait 2"]


# Generated at 2022-06-20 22:03:26.037213
# Unit test for function append_csv
def test_append_csv():
    rule = []
    test_param = ["test1", "test2"]
    flag = "test"
    append_csv(rule,test_param,flag)
    assert rule[0] == flag
    assert rule[1] == "test1,test2"


# Generated at 2022-06-20 22:03:33.428111
# Unit test for function main

# Generated at 2022-06-20 22:03:35.840739
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule(argument_spec={'table': {'default': 'filter'}})
    iptables_path = BINS[module.params['ip_version']]
    return get_iptables_version(iptables_path, module)



# Generated at 2022-06-20 22:04:11.342646
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'foo', '-f', False)
    assert rule == ['-f', 'foo']
    rule = []
    append_param(rule, ['foo'], '-f', True)
    assert rule == ['-f', 'foo']
    rule = []
    append_param(rule, ['foo', 'bar'], '-f', True)
    assert rule == ['-f', 'foo', '-f', 'bar']
    rule = []
    append_param(rule, ['!foo'], '-f', True)
    assert rule == ['!', '-f', 'foo']


# Generated at 2022-06-20 22:04:14.800585
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/usr/sbin/iptables', {'run_command': _fake_run_command}) == '1.6.0,8'



# Generated at 2022-06-20 22:04:25.707610
# Unit test for function check_present
def test_check_present():
    assert check_present(
        '/foo/iptables',
        {
            'run_command': lambda cmd, check_rc=False: (0, '', ''),
        },
        {
            'table': 'filter',
            'chain': 'INPUT',
            'rule_num': None,
            'protocol': None,
            'source': '8.8.8.8',
            'destination': '',
            'jump': 'DROP',
            'reject_with': None,
            'match': None,
            'tcp_flags': None,
            'icmp_type': None,
            'wait': None,
            'ctstate': None,
        },
    ) == True


# Generated at 2022-06-20 22:04:31.549027
# Unit test for function append_wait
def test_append_wait():
    rule = []
    param = "1"
    wait = "--wait"
    append_wait(rule, param, wait)
    assert rule == ["--wait", "1"]

# Generated at 2022-06-20 22:04:36.832361
# Unit test for function remove_rule
def test_remove_rule():
    import module_utils.iptables
    params = {
        'chain': 'INPUT',
        'ip_version': 'ipv4',
        'jump': 'DROP',
        'table': 'filter',
        'wait': None
    }
    ip4tables_path = module_utils.iptables.BINS['ipv4']
    module = FakeModule()
    remove_rule(ip4tables_path, module, params)
    assert module.run_command_called
    assert module.run_command_called_with[0] == [
        ip4tables_path, '-t', 'filter', '-D', 'INPUT', '-j', 'DROP']



# Generated at 2022-06-20 22:04:46.038234
# Unit test for function get_iptables_version
def test_get_iptables_version():
    rc_false = False
    out = 'v1.6.0'
    rc = 0
    module = _MockModule()
    iptables_path = 'iptables'
    module.run_command = lambda x, check_rc=True: (rc if check_rc else (rc_false, '', '')) if x == cmd else (1, '', '')
    assert get_iptables_version(iptables_path, module) == out



# Generated at 2022-06-20 22:04:49.432097
# Unit test for function flush_table
def test_flush_table():
    params = {}
    params['table'] = 'nat'
    params['chain'] = 'PREROUTING'
    params['flush'] = True
    flush_table('/sbin/iptables', None, params)



# Generated at 2022-06-20 22:04:59.137763
# Unit test for function push_arguments
def test_push_arguments():
    args_test = {
        'table': 'filter',
        'chain': 'INPUT',
        'ip_version': 'ipv4'
     }
    rules_test = {
        'tcp_flags': {'flags': ['ALL'], 'flags_set': ['ACK', 'RST', 'FIN']},
        'set_dscp_mark': '8',
        'set_dscp_mark_class': 'CS1',
        'comment': 'Accept new SSH connections',
        'protocol': 'tcp',
        'destination_port': '22',
        'jump': 'ACCEPT',
        'ctstate': ['NEW', 'RELATED', 'ESTABLISHED'],
        'syn': 'match',
        'ip_version': 'ipv4'
    }

# Generated at 2022-06-20 22:05:04.830431
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/iptables', 'iptables v1.6.1 (nf_tables)') == '1.6.1'

# Generated at 2022-06-20 22:05:18.199412
# Unit test for function append_param
def test_append_param():
    rule = []
    # Check each type of parameter
    param = 'test'
    append_param(rule, param, ' flag ', False)
    assert rule == [' flag ', 'test']

    rule = []
    param = '!test'
    append_param(rule, param, ' flag ', False)
    assert rule == ['!', ' flag ', 'test']

    rule = []
    param = ['test', '!test']
    append_param(rule, param, ' flag ', True)
    assert rule == [' flag ', 'test', '!', ' flag ', 'test']


# Generated at 2022-06-20 22:06:11.715723
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = "iptables"
    params = {}
    params['jump'] = "ACCEPT"
    params['destination_port'] = "80"
    params['source'] = "9.9.9.9"
    params['protocol'] = "tcp"
    params['in_interface'] = "lo"
    params['out_interface'] = "iface"
    params['chain'] = "INPUT"
    params['table'] = "filter"
    action = "-A"
    output = push_arguments(iptables_path, action, params)

# Generated at 2022-06-20 22:06:14.156109
# Unit test for function append_match
def test_append_match():
    assert append_match(['foo'], True, 'match') == ['foo', '-m', 'match']



# Generated at 2022-06-20 22:06:21.000569
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(['iptables'], 'match', '-m', 0) == ['iptables', '-m']
    assert append_match_flag(['iptables'], 'negate', '-m', 1) == ['iptables', '!', '-m']
    assert append_match_flag(['iptables'], 'none', '-m', 0) == ['iptables']
    assert append_match_flag(['iptables'], 'none', '-m', 1) == ['iptables']



# Generated at 2022-06-20 22:06:30.172783
# Unit test for function append_param
def test_append_param():
    rule = []
    assert rule == []
    append_param(rule, 'foo', '--bar', False)
    assert rule == ['--bar', 'foo']
    append_param(rule, '!foo', '--baz', False)
    assert rule == ['--bar', 'foo', '!', '--baz', 'foo']
    append_param(rule, ['foo', 'bar'], '--bar', True)
    assert rule == ['--bar', 'foo', '!', '--baz', 'foo', '--bar', 'foo', '--bar', 'bar']



# Generated at 2022-06-20 22:06:39.639234
# Unit test for function construct_rule

# Generated at 2022-06-20 22:06:44.972802
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({})
    iptables_version = get_iptables_version('/sbin/iptables', module)
    assert len(iptables_version) > 0
    assert re.match(r"^\d+\.\d+\.\d+", iptables_version) is not None


# Generated at 2022-06-20 22:06:48.035956
# Unit test for function append_jump
def test_append_jump():
    result = []
    append_jump(result, 'ACCEPT', 'ACCEPT')
    assert(result == ['-j', 'ACCEPT'])
    result = []
    append_jump(result, 'DROP', 'DROP')
    assert(result == ['-j', 'DROP'])


# Generated at 2022-06-20 22:06:52.761238
# Unit test for function append_param
def test_append_param():
    rule = []
    param = 'test'
    flag = '-s'
    append_param(rule, param, flag, False)
    assert rule == [flag, param]
    assert append_param(rule, [1, 2, 3], flag, True) is None
    assert rule == [flag, param, flag, '1', flag, '2', flag, '3']
    assert append_param(rule, ['!', param], flag, False) is None
    assert rule == [flag, param, flag, '1', flag, '2', flag, '3', '!', flag, param]



# Generated at 2022-06-20 22:06:55.421825
# Unit test for function append_wait
def test_append_wait():
    rule = []
    append_wait(rule, None, '--wait')
    assert '--wait' not in rule
    append_wait(rule, '', '--wait')
    assert '--wait' not in rule
    append_wait(rule, '5', '--wait')
    assert '--wait' in rule


# Generated at 2022-06-20 22:06:59.499960
# Unit test for function append_param
def test_append_param():
    r1 = []
    append_param(r1, 'tcp', '--protocol', False)
    assert r1 == ['--protocol', 'tcp']

    r2 = []
    append_param(r2, ['tcp', 'udp'], '--protocol', True)
    assert r2 == ['--protocol', 'tcp', '--protocol', 'udp']

    r3 = []
    append_param(r3, '!tcp', '--protocol', False)
    assert r3 == ['!', '--protocol', 'tcp']



# Generated at 2022-06-20 22:08:05.440275
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = ['!']
    param = dict(flags=['ALL'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['!', '--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-20 22:08:13.474093
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST', 'SYN', 'FIN']
    )
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-20 22:08:18.841890
# Unit test for function flush_table
def test_flush_table():
    module=AnsibleModule()
    params={'ipv4':True,'chain': 'INPUT','flush': True,'table':'filter'}
    flush_table(IPTABLES_BINS['ipv4'], module, params)
    flush_table(IPTABLES_BINS['ipv6'], module, params)

# Generated at 2022-06-20 22:08:20.336617
# Unit test for function remove_rule
def test_remove_rule():
  assert remove_rule("iptables", "module", 'params') == None


# Generated at 2022-06-20 22:08:29.918264
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'iptables'
    params = {}
    params = dict(sys.argv)
    params['table'] = json.loads(params['--table'])
    params['chain'] = json.loads(params['--chain'])
    params['protocol'] = json.loads(params['--protocol'])
    params['source'] = json.loads(params['--source'])
    params['destination'] = json.loads(params['--destination'])
    params['match'] = json.loads(params['--match'])
    params['jump'] = json.loads(params['--jump'])
    params['gateway'] = json.loads(params['--gateway'])
    params['log_prefix'] = json.loads(params['--log_prefix'])

# Generated at 2022-06-20 22:08:31.509929
# Unit test for function append_jump
def test_append_jump():
    assert append_jump(rule, param, jump) == rule.extend(['-j', jump])



# Generated at 2022-06-20 22:08:37.134986
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT')) is None
    assert get_chain_policy(None, None, dict(chain='INPUT')) is None
# End of unit test for function get_chain_policy()



# Generated at 2022-06-20 22:08:46.813970
# Unit test for function insert_rule

# Generated at 2022-06-20 22:08:54.117611
# Unit test for function append_jump
def test_append_jump():
    rule = []
    test_cases = [
        {'param': 'ACCEPT', 'jump': 'ACCEPT'},
        {'param': 'REJECT', 'jump': 'REJECT'},
        {'param': 'DROP', 'jump': 'DROP'},
        {'param': 'QUEUE', 'jump': 'QUEUE'},
        {'param': 'RETURN', 'jump': 'RETURN'}
    ]

    for test in test_cases:
        append_jump(rule, test['param'], test['jump'])
        assert rule == ['-j', test['jump']], 'missing jump value'
        rule = []


# Generated at 2022-06-20 22:09:00.562935
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        action='set_info',
        table='filter',
        chain='test_chain',
        policy='test_policy',
        ip_version='test_ip_version',
    ))
    set_chain_policy('test_iptables_path', module, module.params)
    module.exit_json(**module.params)



# Generated at 2022-06-20 22:10:20.318306
# Unit test for function construct_rule
def test_construct_rule():
    """Unit test for function construct_rule"""

# Generated at 2022-06-20 22:10:26.132255
# Unit test for function flush_table
def test_flush_table():
    test_module = dict(
        check_mode=False,
        no_log=True,
        params=dict(
            action='present',
            chain='INPUT',
            flush=True,
            table='filter',
            ip_version='ipv4')
    )
    flush_table('iptables', test_module, test_module['params'])
    print(test_module)

    assert test_module['params']['action'] == 'present'
    assert test_module['params']['chain'] == 'INPUT'
    assert test_module['params']['flush'] == True
    assert test_module['params']['table'] == 'filter'
    assert test_module['params']['ip_version'] == 'ipv4'
# End of test unit



# Generated at 2022-06-20 22:10:31.967620
# Unit test for function append_csv
def test_append_csv():
    assert append_csv([], ['foo', 'bar'], '--param') == ['--param', 'foo,bar']
    assert append_csv([], None, '--param') == []
    assert append_csv([], [], '--param') == []
test_append_csv()



# Generated at 2022-06-20 22:10:38.617529
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    rule_param = dict()
    rule_param['flags'] = ['ALL', 'ACK', 'FIN']
    rule_param['flags_set'] = ['ACK', 'SYN', 'FIN']
    flag = '--tcp-flags'
    append_tcp_flags(rule, rule_param, flag)
    assert rule == ['--tcp-flags', 'ALL,ACK,FIN', 'ACK,SYN,FIN']



# Generated at 2022-06-20 22:10:40.577657
# Unit test for function append_match_flag
def test_append_match_flag():
    ret = []
    append_match_flag(ret, 'match', 'A', False)
    assert ret == ['A']


# Generated at 2022-06-20 22:10:41.319284
# Unit test for function remove_rule
def test_remove_rule():
    pass



# Generated at 2022-06-20 22:10:56.885374
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='PREROUTING',
        destination_port='80',
        destination='192.168.1.1',
        in_interface='eth1',
        jump='ACCEPT',
        protocol='tcp',
        source='192.168.1.100',
        )
    assert construct_rule(params) == ['-A', 'PREROUTING', '-p', 'tcp', '-i', 'eth1', '-d', '192.168.1.1', '--dport', '80', '-s', '192.168.1.100', '-j', 'ACCEPT']


# Generated at 2022-06-20 22:11:06.488890
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(
            argument_spec=dict(
                table=dict(choices=['filter', 'nat', 'mangle', 'raw', 'security'], default='filter'),
                chain=dict(required=True),
                ip_version=dict(choices=['ipv4', 'ipv6'], default='ipv4'),
                bin_path=dict(default='/sbin/iptables')
            ),
            supports_check_mode=False
        )
    params = module.params
    iptables_path = params['bin_path']
    assert get_chain_policy(iptables_path, module, params) == 'DROP'



# Generated at 2022-06-20 22:11:15.391659
# Unit test for function main