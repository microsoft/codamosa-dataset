

# Generated at 2022-06-11 07:21:31.431721
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(policy='ACCEPT', chain='OUTPUT')) == 'ACCEPT'
    assert get_chain_policy(None, None, dict(policy='DROP', chain='OUTPUT')) == 'DROP'
    assert get_chain_policy(None, None, dict(policy='QUEUE', chain='OUTPUT')) == 'QUEUE'
    assert get_chain_policy(None, None, dict(policy='RETURN', chain='OUTPUT')) == 'RETURN'



# Generated at 2022-06-11 07:21:39.146672
# Unit test for function append_rule
def test_append_rule():
    params = {
      'chain': 'INPUT',
      'ip_version': 'ipv4',
      'source': '192.168.1.1',
      'protocol': 'tcp',
      'jump': 'ACCEPT',
      'table': 'filter'
    }
    iptables_path = '/usr/bin/iptables'
    result = push_arguments(iptables_path, '-A', params)
    assert result == ['/usr/bin/iptables', '-t', 'filter', '-A', 'INPUT', '-s', '192.168.1.1', '-p', 'tcp', '-j', 'ACCEPT']


# Generated at 2022-06-11 07:21:41.404556
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('whatever', AnsibleModule(argument_spec={})) == '1.6.0'


# Generated at 2022-06-11 07:21:46.482071
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(chain='INPUT', protocol='tcp', source='8.8.8.8',
                  jump='DROP')
    rule = construct_rule(params)
    assert rule == ['-A', 'INPUT', '-s', '8.8.8.8', '-p', 'tcp', '-j', 'DROP']
    params = dict(chain='INPUT', protocol='udp', source='172.16.0.0/24',
                  jump='ACCEPT')
    rule = construct_rule(params)
    assert rule == ['-A', 'INPUT', '-s', '172.16.0.0/24', '-p', 'udp', '-j',
                    'ACCEPT']

# Generated at 2022-06-11 07:21:52.673513
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule=['']
    param=dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    assert append_tcp_flags(rule, param, '--tcp-flags') == ['']
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']

test_append_tcp_flags()



# Generated at 2022-06-11 07:21:59.002077
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/bin/iptables'
    module = AnsibleModule
    params = dict(table='filter', chain='INPUT', ip_version='ipv4', protocol='icmp', destination='2a00:1450:4007:807::200e', jump='DROP')
    cmd = push_arguments(iptables_path, '-D', params)
    module.run_command(cmd, check_rc=True)


# Generated at 2022-06-11 07:22:02.802652
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module, iptables_path, params = load_module_args()
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']
    print("Expected:", cmd)

# Generated at 2022-06-11 07:22:11.447825
# Unit test for function insert_rule
def test_insert_rule():
    params = {
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': 8080,
        'jump': 'ACCEPT',
        'action': 'insert',
        'rule_num': 5,
        'table': 'filter'
    }
    assert(push_arguments('iptables', '-I', params) == [
           'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--destination-port', '8080', '-j', 'ACCEPT'])



# Generated at 2022-06-11 07:22:20.764987
# Unit test for function insert_rule
def test_insert_rule():
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')
    insert_rule('iptables','',' ')

# Generated at 2022-06-11 07:22:21.965874
# Unit test for function append_match_flag
def test_append_match_flag():
    assert(append_match_flag([], 'match', '--syn', 'negate'))


# Generated at 2022-06-11 07:22:34.857701
# Unit test for function insert_rule
def test_insert_rule():
  module = AnsibleModule
  rule = construct_rule(params)
  insert_rule('/bin/iptables', module, rule)
  check_present('/bin/iptables', module, rule)



# Generated at 2022-06-11 07:22:39.386082
# Unit test for function check_present
def test_check_present():
    module = FakeModule()
    assert check_present('iptables', module, dict(
        chain='OUTPUT',
        source='1.1.1.1',
        jump=None,
        action='append',
        ip_version='ipv4',
        table='filter',
        wait=None,
    )) is True



# Generated at 2022-06-11 07:22:48.666408
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule({})

# Generated at 2022-06-11 07:22:59.217955
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/usr/bin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {
        'table': 'filter',
        'chain': 'FORWARD',
        'protocol': 'tcp',
        'destination_port': '22',
        'ctstate': 'NEW',
        'syn': 'match',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.',
        'rule_num': '5'
    }
    insert_rule(iptables_path, module, params)
    assertTrue((module.run_command(cmd, check_rc=False) == (0)))



# Generated at 2022-06-11 07:23:03.681184
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    version = get_iptables_version('/sbin/iptables', module)
    assert isinstance(version, str)
    assert len(version) > 0


# Generated at 2022-06-11 07:23:16.373046
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        comment='Some comment',
        source='192.168.1.1',
        protocol='tcp',
        syn='match',
        jump='ACCEPT',
        log_prefix='log_prefix',
    )
    assert construct_rule(params) == [
        '-s', '192.168.1.1', '-p', 'tcp', '--syn', '-j',
        'ACCEPT', '--log-prefix', 'log_prefix', '-m',
        'comment', '--comment', 'Some comment']
    params = dict(
        comment='Some comment',
        source='192.168.1.1',
        protocol='tcp',
        syn='negate',
        jump='ACCEPT',
        log_prefix='log_prefix',
    )

# Generated at 2022-06-11 07:23:26.246892
# Unit test for function construct_rule

# Generated at 2022-06-11 07:23:32.957642
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/sbin/iptables'
    action = '-A'

# Generated at 2022-06-11 07:23:45.006808
# Unit test for function get_chain_policy
def test_get_chain_policy():
    ipv4_path = '/sbin/iptables'
    ipv6_path = '/sbin/ip6tables'
    module = AnsibleModule(argument_spec={})

    policy = 'DROP'
    table = 'filter'
    chain = 'INPUT'
    # create table and chain
    cmd_create = '{0} -t {1} -N {2}'.format(ipv4_path, table, chain)
    module.run_command(cmd_create, check_rc=True)

    # set policy
    cmd_policy = '{0} -t {1} -P {2} {3}'.format(ipv4_path, table, chain, policy)
    module.run_command(cmd_policy, check_rc=True)

# Generated at 2022-06-11 07:23:56.096939
# Unit test for function insert_rule
def test_insert_rule():
    module = module_mock()
    params = dict(table='filter', chain='INPUT', protocol='tcp', ip_version='ipv4', destination_port='8080', jump='ACCEPT', action='insert', rule_num='5')
    iptables_path = '/usr/bin/iptables'
    cmd = [iptables_path, '-t', params['table'], '-I', params['chain'], params['rule_num'], '-p',  params['protocol'], '--dport',  params['destination_port'] , '-j', params['jump']]
    module.run_command = mock_run_command(module, cmd, True)
    insert_rule(iptables_path, module, params)
    assert True



# Generated at 2022-06-11 07:24:05.978409
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-11 07:24:09.782797
# Unit test for function get_chain_policy
def test_get_chain_policy():
    params = dict(chain='INPUT', policy='ACCEPT', ip_version='ipv4')
    chain_policy = get_chain_policy('iptables', None, params)
    assert chain_policy == 'ACCEPT'



# Generated at 2022-06-11 07:24:17.053182
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        source='1.1.1.1',
        destination_port='80',
        ctstate='NEW',
        protocol='tcp',
        jump='ACCEPT',
        comment='test',
        ip_version='ipv6'
    )
    assert construct_rule(params) == [
        '-s', '1.1.1.1',
        '-p', 'tcp',
        '--destination-port', '80',
        '-m', 'conntrack',
        '--ctstate', 'NEW',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'test'
    ]


# Generated at 2022-06-11 07:24:18.605675
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule("1", "2", "3") == "3"



# Generated at 2022-06-11 07:24:19.263346
# Unit test for function append_rule
def test_append_rule():
    assert True



# Generated at 2022-06-11 07:24:30.903055
# Unit test for function get_chain_policy
def test_get_chain_policy():
    import os
    import sys
    sys.path.append(os.path.abspath(os.path.join(__file__, '..', '..', 'lib')))
    sys.path.append(os.path.abspath(os.path.join(__file__, '..', '..')))
    module_path = os.path.abspath(os.path.join(__file__, '..', '..', 'lib', 'ansible', 'modules'))
    sys.modules['ansible.modules.extras.network.iptables'] = __import__(
        'iptables', globals(), locals(), ['ansible', 'modules', 'extras', 'network'], -1)
    from ansible.modules.extras.network.iptables import iptables as iptables_module

# Generated at 2022-06-11 07:24:32.698628
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy() == 'INPUT'



# Generated at 2022-06-11 07:24:36.167526
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.iptables

    params = {
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination': '8.8.8.8',
    }
    res = ansible.module_utils.iptables.check_present('iptables', AnsibleModule(argument_spec={}), params)
    assert res == False


# Generated at 2022-06-11 07:24:41.264809
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', {'run_command': lambda *args, **kargs: (0, 'v1.6.0', '')}) == '1.6.0'
    assert get_iptables_version('iptables', {'run_command': lambda *args, **kargs: (0, 'v1.4.21', '')}) == '1.4.21'



# Generated at 2022-06-11 07:24:53.516706
# Unit test for function check_present

# Generated at 2022-06-11 07:25:10.990249
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = "/sbin/iptables" # path to iptables
    module = AnsibleModule()
    params = dict(chain='INPUT', ip_version='ipv4', table='filter')
    current_policy = get_chain_policy(iptables_path, module, params)
    print("Current policy for chain '%s' is '%s'. Change the policy if needed." % \
         (params['chain'], current_policy))


# Generated at 2022-06-11 07:25:12.109767
# Unit test for function check_present
def test_check_present():
    # TODO
    pass



# Generated at 2022-06-11 07:25:24.024844
# Unit test for function construct_rule
def test_construct_rule():
    ip_version = 'ipv4'

# Generated at 2022-06-11 07:25:34.645992
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['SYN'], flags_set=['ACK', 'RST'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'SYN', 'ACK,RST']
    param = dict(flags=['ALL'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'SYN', 'ACK,RST', '--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']
    param = []
    append_tcp_flags(rule, param, flag)

# Generated at 2022-06-11 07:25:40.012243
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    flag = '--tcp-flags'
    arrays = [{'flags': "ALL", 'flags_set': ["ACK", "RST"]}]
    expected_result = ['--tcp-flags', 'ALL', 'ACK,RST']
    assert append_tcp_flags([], arrays[0], flag) == expected_result


# Generated at 2022-06-11 07:25:50.077241
# Unit test for function main

# Generated at 2022-06-11 07:25:53.771986
# Unit test for function get_chain_policy
def test_get_chain_policy():
    params = dict(
            table='filter',
            chain='FORWARD',
            ip_version='ipv4',
            policy='DROP',
    )
    assert get_chain_policy(None, None, params) is None



# Generated at 2022-06-11 07:25:57.563789
# Unit test for function get_chain_policy
def test_get_chain_policy():
    result = get_chain_policy(None, None, dict(
        table='filter',
        chain='ACCEPT',
    ))
    print(result)
    assert result == 'ACCEPT'



# Generated at 2022-06-11 07:26:02.400766
# Unit test for function main
def test_main():
    import sys
    import os
    import json


# Generated at 2022-06-11 07:26:14.624277
# Unit test for function construct_rule

# Generated at 2022-06-11 07:26:48.718603
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule({})
    module.params = dict(
        ip_version='ipv4',
        table='filter',
        chain='FORWARD',
        )
    assert get_chain_policy('iptables', module, module.params) == 'ACCEPT'

    module.params = dict(
        ip_version='ipv6',
        table='filter',
        chain='FORWARD',
        )
    assert get_chain_policy('iptables', module, module.params) == 'REJECT'

    module.params = dict(
        ip_version='ipv4',
        table='filter',
        chain='NOSUCHCHAIN',
        )
    assert get_chain_policy('iptables', module, module.params) is None

# Unit tests for function append_param

# Generated at 2022-06-11 07:26:50.206515
# Unit test for function set_chain_policy
def test_set_chain_policy():
    set_chain_policy('iptables','module','params')


# Generated at 2022-06-11 07:27:01.017230
# Unit test for function main

# Generated at 2022-06-11 07:27:08.888634
# Unit test for function construct_rule
def test_construct_rule():
    params = dict()
    params['ip_version'] = 'ipv6'
    params['wait'] = '5'
    params['protocol'] = 'tcp'
    params['source'] = '192.168.1.1'
    params['destination'] = '10.0.0.1'
    params['match'] = ['conntrack', 'state']
    params['tcp_flags'] = dict(flags=['ALL'], flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    params['jump'] = 'DROP'
    params['log_prefix'] = 'logging event: '
    params['log_level'] = 'warning'
    params['to_destination'] = '10.0.0.2'
    params['destination_ports'] = ['80', '443']

# Generated at 2022-06-11 07:27:20.079582
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(
        argument_spec=dict(
            ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
            table=dict(default='filter',
                       choices=['filter', 'nat', 'mangle', 'raw']),
            chain=dict(default='INPUT', required=True,
                       choices=['INPUT', 'FORWARD', 'OUTPUT', 'PREROUTING',
                                'POSTROUTING']),
        ),
        supports_check_mode=True
    )
    params = module.params
    params['chain'] = 'INPUT'
    # Test the case when policy is present
    out = "Chain INPUT (policy ACCEPT)\n"
    policy_result = 'ACCEPT'

# Generated at 2022-06-11 07:27:24.327256
# Unit test for function remove_rule
def test_remove_rule():
    result = remove_rule(BINS['ipv4'], None, dict(table='filter', chain='INPUT', rule_num=1, ip_version='ipv4'))
    assert result == [BINS['ipv4'], '-t', 'filter', '-D', 'INPUT', '1']



# Generated at 2022-06-11 07:27:35.983856
# Unit test for function remove_rule
def test_remove_rule():
    mock_module = AnsibleModule(argument_spec = dict(
        iptables_path = dict(type='str', required=True),
        params = dict(type='dict', required=True)
        ))

# Generated at 2022-06-11 07:27:44.858668
# Unit test for function construct_rule

# Generated at 2022-06-11 07:27:46.022894
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/iptables', object) == '1.4.21'



# Generated at 2022-06-11 07:27:50.927560
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num=5,
        table='filter'
    )
    assert push_arguments('iptables', '-I', params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT'
    ]
    params['action'] = 'append'
    params['rule_num'] = None

# Generated at 2022-06-11 07:28:40.068175
# Unit test for function main
def test_main():
    # This is an auto-generated dummy test
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:28:49.312927
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol = "tcp",
        destination = "192.168.1.1",
        jump = "ACCEPT",
        in_interface = "eth0",
        source = "192.168.1.2",
        set_counters = "10:20",
        destination_port = "80",
        to_ports = "80",
        source_port = "80",
        uid_owner = "!foo",
        comment = "foobar",
        limit = "20/minute",
        limit_burst = "5",
    )

# Generated at 2022-06-11 07:28:58.555339
# Unit test for function construct_rule

# Generated at 2022-06-11 07:29:06.060406
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        rule_num='1',
        protocol='tcp',
        source='192.168.1.100-192.168.1.199',
        destination='10.0.0.1-10.0.0.50',
        jump='ACCEPT',
    )
    cmd = push_arguments('iptables', '-I', params)

# Generated at 2022-06-11 07:29:10.469767
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'SYN']
    )
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,SYN']



# Generated at 2022-06-11 07:29:19.395235
# Unit test for function construct_rule
def test_construct_rule():
    args = dict(
        protocol='tcp',
        source='8.8.8.8',
        in_interface='eth0',
        out_interface='eth1',
        jump='DROP',
        tcp_flags=dict(
            flags=['ALL'],
            flags_set=['ACK', 'RST', 'SYN', 'FIN']
        ),
        match=['tcp', 'multiport'],
        ctstate=['INVALID'],
        limit='2/minute',
        limit_burst='20',
        uid_owner='0',
        gid_owner='0',
        reject_with='reject-with',
        icmp_type='echo-request',
        ip_version='ipv4',
    )

# Generated at 2022-06-11 07:29:27.594516
# Unit test for function get_iptables_version
def test_get_iptables_version():
    class TestException(Exception):
        pass

    version = r'v1.4.21'

    class TestModule(object):
        def __init__(self, output, version):
            self.output = output
            self.version = version

        def run_command(self, cmd, check_rc=True):
            if cmd == ['/sbin/iptables', '--version']:
                return 0, self.output, ''
            raise TestException()

    module = TestModule(version, LooseVersion('1.4.21'))
    assert get_iptables_version('/sbin/iptables', module) == '1.4.21'



# Generated at 2022-06-11 07:29:28.948927
# Unit test for function append_rule
def test_append_rule():
    result = append_rule(iptables_path, module, params)


# Generated at 2022-06-11 07:29:38.552891
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        protocol='tcp',
        dest_port='80',
        jump='ACCEPT',
        chain='INPUT',
        comment='test-comment',
        table='filter'
    )
    assert push_arguments('iptables', '-I', params) == ['iptables', '-t', 'filter', '-I', 'INPUT', '-p', 'tcp', '--dport',  '80', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'test-comment']
    params['rule_num'] = '22'

# Generated at 2022-06-11 07:29:40.503055
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = 'iptables -P INPUT DROP'
    assert set_chain_policy(cmd) == 'iptables -P INPUT DROP'

