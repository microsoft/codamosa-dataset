

# Generated at 2022-06-11 07:21:36.993890
# Unit test for function push_arguments
def test_push_arguments():
    import random

    ipv_list = ['ipv4', 'ipv6']
    action_list = ['-I', '-A', '-D', '-R', '-Z', '-F', '-X', '-N', '-X', '-E']
    table_list = ['filter', 'nat', 'mangle', 'raw', 'security']
    ctstate_list = ['ESTABLISHED', 'RELATED', 'NEW', 'INVALID']
    src_range_list = ['192.168.1.1-192.168.1.10', '192.168.1.1-192.168.1.10']
    dst_range_list = ['192.168.1.1-192.168.1.10', '192.168.1.1-192.168.1.10']


# Generated at 2022-06-11 07:21:44.584540
# Unit test for function check_present
def test_check_present():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec = dict())
    module.run_command = MagicMock(return_value = (0, '', ''))
    params = dict()
    params['table'] = 'nat'
    params['chain'] = 'INPUT'
    params['protocol'] = None
    params['source'] = '10.0.0.1'
    params['destination'] = '10.0.0.2'
    params['jump'] = 'ACCEPT'
    params['state'] = 'present'
    params['reject_with'] = None
    params['comment'] = None
    params['in_interface'] = None
    params['out_interface'] = None
    params['source_port'] = None
    params['destination_port']

# Generated at 2022-06-11 07:21:48.852289
# Unit test for function construct_rule
def test_construct_rule():
    #TODO: construct_rule needs more test cases
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='9.9.9.9',
        reject_with='icmp-port-unreachable',
    )
    expected_rule = ['-p', 'tcp', '-s', '9.9.9.9', '--reject-with', 'icmp-port-unreachable', '-j', 'REJECT']
    assert construct_rule(params) == expected_rule



# Generated at 2022-06-11 07:21:52.066486
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments(
        'iptables', '-A', {
            'chain': 'INPUT', 'table': 'filter',
            'protocol': 'tcp', 'jump': 'ACCEPT',
            'destination_port': '80'
        }, True) == [
            'iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-j',
            'ACCEPT', '--dport', '80']



# Generated at 2022-06-11 07:21:55.228037
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy("iptables", "module", {"chain": "INPUT", "policy":"DROP"}) == 'iptables -t table -P INPUT DROP'


# Generated at 2022-06-11 07:21:59.847281
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    _rule = []
    _param = dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST'])
    append_tcp_flags(_rule, _param, '--tcp-flags')
    assert _rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST']



# Generated at 2022-06-11 07:22:10.716637
# Unit test for function get_chain_policy
def test_get_chain_policy():
    # Define parameters
    params = dict(
        chain="INPUT",
        policy="ACCEPT",
        ip_version='ipv4',
        table="filter"
    )
    # Define output
    out = 'Chain INPUT (policy ACCEPT)\n'
    out = out + 'target     prot opt source               destination          \n'
    out = out + 'ACCEPT     udp  --  0.0.0.0/0            0.0.0.0/0            udp dpt:53\n'
    out = out + 'ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:53\n'

# Generated at 2022-06-11 07:22:19.304280
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule({})
    params = dict(
        ip_version = "ipv4",
        table = "filter",
        chain = "INPUT",
        protocol = "tcp",
        destination = "172.16.1.1",
        jump = "DROP",
        wait = 1
    )
    cmd_sample = ['iptables', '-t', 'filter', '-A', 'INPUT', '-w', '1', '-d', 
                '172.16.1.1', '-p', 'tcp', '-j', 'DROP']
    cmd_tested = append_rule("ipv4", module, params)
    assert cmd_sample == cmd_tested


# Generated at 2022-06-11 07:22:26.295234
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    param = dict(
        flags=['ACK'],
        flags_set=['SYN', 'FIN']
    )
    rule = []
    append_tcp_flags(rule, param, '--syn')
    assert rule == ['--syn', 'ACK', 'SYN,FIN']

    param = dict(
        flags=['ALL'],
        flags_set=['ACK']
    )
    rule = []
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ALL', 'ACK']

    param = dict(
        flags=['SYN', 'RST'],
        flags_set=['FIN', 'ACK']
    )
    rule = []
    append_tcp_flags(rule, param, '--tcp-flags')
   

# Generated at 2022-06-11 07:22:35.985800
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(
         table="filter",
         chain="INPUT",
         policy=None)) is None
    assert get_chain_policy(None, None, dict(
         table="filter",
         chain="INPUT",
         policy=None)) is None
    assert get_chain_policy(None, None, dict(
         table="filter",
         chain="INPUT",
         policy=None)) is None
    assert get_chain_policy(None, None, dict(
         table="filter",
         chain="INPUT",
         policy=None)) is None
    assert get_chain_policy(None, None, dict(
         table="filter",
         chain="INPUT",
         policy=None)) is None

# Generated at 2022-06-11 07:22:54.040232
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule({})
    assert get_chain_policy(None, module, {'chain': 'INPUT'}) is None
    rc = 'INPUT     all  --  anywhere             anywhere             (policy DROP)'
    assert get_chain_policy(None, module, {'chain': 'INPUT'}, rc) == 'DROP'



# Generated at 2022-06-11 07:23:03.927428
# Unit test for function construct_rule
def test_construct_rule():
    params = {
        "table": "filter",
        "chain": "INPUT",
        "comment": "Demo rule",
        "protocol": "tcp",
        "destination_port": "9000",
        "jump": "ACCEPT",
        "ip_version": "ipv4",
        "reject_with": "icmp-port-unreachable",
        "source": "10.10.10.10",
        "icmp_type": "echo-request",
        "match": "state",
        "ctstate": "established",
        "wait": "2",
    }

# Generated at 2022-06-11 07:23:16.644655
# Unit test for function main

# Generated at 2022-06-11 07:23:26.470110
# Unit test for function main

# Generated at 2022-06-11 07:23:30.245394
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, "match", "--syn", True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, "negate", "--syn", True)
    assert rule == ['!', '--syn']


# Generated at 2022-06-11 07:23:35.438953
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--ctstate', True)
    assert rule == ['--ctstate']
    rule = []
    append_match_flag(rule, 'negate', '--ctstate', True)
    assert rule == ['!', '--ctstate']



# Generated at 2022-06-11 07:23:46.253638
# Unit test for function flush_table
def test_flush_table():
    module = MagicMock()
    module.run_command.return_value = (0, '', '')
    params = dict(chain='INPUT', table='filter')
    flush_table('iptables', module, params)
    assert module.run_command.call_args[0][0] == ['iptables', '-t', 'filter', '-F', 'INPUT']
    params = dict(chain='FORWARD', table='nat')
    flush_table('iptables', module, params)
    assert module.run_command.call_args[0][0] == ['iptables', '-t', 'nat', '-F', 'FORWARD']



# Generated at 2022-06-11 07:23:57.649110
# Unit test for function flush_table

# Generated at 2022-06-11 07:24:01.688667
# Unit test for function append_param
def test_append_param():
    mylist = []
    append_param(mylist, ('abc', 'def', 'ghi'), '--foo', True)
    assert mylist == ['--foo', 'abc', '--foo', 'def', '--foo', 'ghi']
    append_param(mylist, None, '--foo', True)
    assert mylist == ['--foo', 'abc', '--foo', 'def', '--foo', 'ghi']
    append_param(mylist, 'jkl', '--foo', False)
    assert mylist == ['--foo', 'abc', '--foo', 'def', '--foo', 'ghi', '--foo', 'jkl']
    append_param(mylist, '!mno', '--foo', False)

# Generated at 2022-06-11 07:24:12.885856
# Unit test for function main

# Generated at 2022-06-11 07:24:34.953341
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 07:24:38.855846
# Unit test for function get_chain_policy
def test_get_chain_policy():
    hdr = "Chain INPUT (policy ACCEPT)"
    result = re.search(r'\(policy ([A-Z]+)\)', hdr)
    if result:
        assert result.group(1) == "ACCEPT"
    else:
        assert False

# Generated at 2022-06-11 07:24:45.517765
# Unit test for function main

# Generated at 2022-06-11 07:24:48.061020
# Unit test for function get_chain_policy
def test_get_chain_policy():
    if get_chain_policy('iptables', None, {'chain': 'INPUT'}) == 'ACCEPT':
        return True
    return False



# Generated at 2022-06-11 07:24:56.878141
# Unit test for function push_arguments
def test_push_arguments():
    # iptables_path, action, params, make_rule=True):
    p = {'table': 'filter', 'chain': 'INPUT', 'rule_num': '1', 'protocol': 'tcp', 'jump': 'DROP', 'comment': 'test_rule'}
    assert push_arguments('iptables', '-A', p) == ['iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-j', 'DROP', '-m', 'comment', '--comment', 'test_rule']



# Generated at 2022-06-11 07:25:02.303947
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = "/sbin/iptables"
    action = '-D'
    params = {
        'ip_version': 'ipv4',
        'chain': 'INPUT',
        'table': 'filter',
        'comment': 'test',
    }
    cmd = push_arguments(iptables_path, action, params)
    print("cmd:", cmd)
    # module.run_command(cmd, check_rc=True)


# Generated at 2022-06-11 07:25:09.695729
# Unit test for function flush_table
def test_flush_table():
    module_name = 'ansible.builtin.iptables'
    module = AnsibleModule(
        argument_spec=dict(
            table=dict(required=True),
            chain=dict(required=True),
            ip_version=dict(default='ipv4'),
        ),
        supports_check_mode=True
    )

    iptables_path = BINS[module.params['ip_version']]
    flush_table(iptables_path, module, module.params)


# Generated at 2022-06-11 07:25:21.584411
# Unit test for function main
def test_main():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    import __builtin__ as builtins


# Generated at 2022-06-11 07:25:31.930092
# Unit test for function check_present
def test_check_present():
    import tempfile
    (outfd, outfile) = tempfile.mkstemp()
    (infd, infile) = tempfile.mkstemp()

    check_present(
        '/sbin/iptables',
        AnsibleModule({
            'from_what': infile,
            'to_what': outfile,
            'failed_when_result': True,
            'run_command': run_command,
        }),
        {
            'chain': 'INPUT',
            'ip_version': 'ipv4',
            'protocol': 'tcp',
            'destination_port': '80',
            'ctstate': 'NEW',
            'syn': 'match',
            'jump': 'ACCEPT',
        }
    ) == True


# Generated at 2022-06-11 07:25:43.352615
# Unit test for function remove_rule
def test_remove_rule():
    module = AnsibleModule({})
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        src_range='192.168.1.100-192.168.1.199',
        dst_range='10.0.0.1-10.0.0.50',
        jump='ACCEPT'
    )
    cmd = push_arguments('iptables', '-D', params)
    module.run_command(cmd, check_rc=True)
    assert cmd == ['-t', 'filter', '-D', 'INPUT', '192.168.1.100-192.168.1.199', '10.0.0.1-10.0.0.50', '-j', 'ACCEPT']


# Generated at 2022-06-11 07:25:54.622898
# Unit test for function flush_table
def test_flush_table():
    return True



# Generated at 2022-06-11 07:26:07.793485
# Unit test for function push_arguments
def test_push_arguments():
    params = {
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '22',
        'ctstate': ['NEW'],
        'syn': 'match',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.'
    }
    test_cmd = push_arguments('iptables', '-A', params)


# Generated at 2022-06-11 07:26:12.502134
# Unit test for function flush_table
def test_flush_table():
    iptables_path = BINS['ipv4']
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',)
    flush_table(iptables_path, module, params)



# Generated at 2022-06-11 07:26:16.085435
# Unit test for function check_present
def test_check_present():
    assert check_present(BINS['ipv4'], module_params) == False



# Generated at 2022-06-11 07:26:23.113037
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_rule = []
    append_tcp_flags(test_rule, {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'SYN']}, '-m tcp')
    assert test_rule == ['-m', 'tcp', '--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,SYN']
    assert test_rule == ['-m', 'tcp', '--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,SYN']


# Generated at 2022-06-11 07:26:25.806306
# Unit test for function check_present
def test_check_present():
    parameter = ['-C', '-t', 'mangle', 'INPUT', '-m', 'comment', '--comment', '"RETURN-2"', '-j', 'RETURN']
    assert push_arguments('iptables', parameter)



# Generated at 2022-06-11 07:26:30.619592
# Unit test for function get_iptables_version
def test_get_iptables_version():
    test_run = MockCommandRunner(
        stdout='iptables v1.6.1', rc=0)
    module = MockModule()
    print(get_iptables_version('iptables', module))
    assert module.run_command.call_count == 1
    assert test_run.get_call_args() == ['iptables', '--version']
    assert module.run_command.call_args == test_run.call_args



# Generated at 2022-06-11 07:26:41.039385
# Unit test for function construct_rule

# Generated at 2022-06-11 07:26:52.059423
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/path/to/iptables'
    table = 'filter'
    action = '-A'
    chain = 'INPUT'
    params = {
        'table': table,
        'action': action,
        'chain': chain,
        'protocol': 'tcp',
        'destination_port': 22,
        'ctstate': 'NEW',
        'syn': 'match',
        'jump': 'ACCEPT'
    }
    result = push_arguments(iptables_path, action, params)
    assert result == [iptables_path, '-t', table, action, chain, '-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT']




# Generated at 2022-06-11 07:26:57.781291
# Unit test for function check_present
def test_check_present():
    def test_run_command(args, check_rc=True):
        print(args)
        return 0, "", ""
    module = dict(run_command=test_run_command)
    params = dict(table='filter', chain='INPUT',
        protocol='tcp', dest_port='7'
    )
    assert(check_present('iptables', module, params))



# Generated at 2022-06-11 07:27:20.437267
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path='iptables'

# Generated at 2022-06-11 07:27:25.108087
# Unit test for function insert_rule
def test_insert_rule():
    assert push_arguments('iptables', '-I', {'chain':'INPUT', 'table':'filter', 'protocol':'tcp', 'destination_port': '80', 'ctstate':'NEW', 'syn':'match', 'jump':'ACCEPT', 'comment':'test'}) == ['iptables', '-t', 'filter', '-I', 'INPUT', '1', '-p', 'tcp', '--dport', '80', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'test']



# Generated at 2022-06-11 07:27:27.380557
# Unit test for function flush_table
def test_flush_table():
    params = dict(
        table = 'nat',
        chain = 'POSTROUTING',
    )
    flush_table(params)


# Generated at 2022-06-11 07:27:38.851490
# Unit test for function remove_rule
def test_remove_rule():
    from ansible.modules.network.iptables import push_arguments
    iptables_path = "iptables"
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

# Generated at 2022-06-11 07:27:39.488638
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:27:44.152307
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(
        argument_spec=dict(
            table='filter',
            chain='INPUT',
            ip_version='ipv4',
            policy='DROP',
        ),
    )
    set_chain_policy('iptables', module, dict(
            table='filter',
            chain='INPUT',
            ip_version='ipv4',
            policy='DROP',
        ))



# Generated at 2022-06-11 07:27:50.227143
# Unit test for function construct_rule

# Generated at 2022-06-11 07:27:55.332964
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = [ ]
    param= { 'flags':['ACK','RST','SYN','FIN'], 'flags_set':['ACK','RST','SYN','FIN'] }
    flag='--tcp-flags'
    append_tcp_flags(rule,param,flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']


# Generated at 2022-06-11 07:28:05.182806
# Unit test for function construct_rule

# Generated at 2022-06-11 07:28:08.052064
# Unit test for function check_present
def test_check_present():
    assert check_present(iptables_path='/bin/iptables',
                         module=module,
                         params={'chain': 'INPUT'}) == True


# Generated at 2022-06-11 07:28:30.284835
# Unit test for function set_chain_policy
def test_set_chain_policy():
    ipv4_params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4',
        policy='DROP',
        action=None,
        state=None,
        rule_num=None,
    )
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    cmd = push_arguments(iptables_path, '-P', ipv4_params, make_rule=False)
    cmd.append('DROP')

# Generated at 2022-06-11 07:28:37.537453
# Unit test for function set_chain_policy
def test_set_chain_policy():
    import tempfile
    import os.path
    cmd_file = tempfile.NamedTemporaryFile(delete=False)
    bin_path = '/usr/bin/iptables'
    cmd = [bin_path]
    cmd.extend(['-C', 'INPUT'])
    cmd.extend(['-p', 'tcp'])
    cmd.extend(['-m', 'comment'])
    cmd.extend(['--comment'])
    cmd.extend(['"test"'])
    cmd.extend(['-j', 'ACCEPT'])
    with open(cmd_file.name, 'w+') as f:
        f.write("#!/bin/sh\n")
        f.write(" ".join(cmd))

# Generated at 2022-06-11 07:28:38.213137
# Unit test for function append_rule
def test_append_rule():
    assert True



# Generated at 2022-06-11 07:28:44.383250
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(argument_spec={})
    iptables_path = 'iptables'
    params = {'chain': 'INPUT', 'ip_version': 'ipv4', 'jump': None,
              'protocol': 'tcp', 'destination_port': 80, 'table': 'filter'}
    cmd = push_arguments(iptables_path, '-A', params)
    module.run_command(cmd, check_rc=True)
    assert True



# Generated at 2022-06-11 07:28:53.856513
# Unit test for function check_present
def test_check_present():
    import sys
    sys.path.append('./lib')
    from ansible.modules.network.iptables import push_arguments, construct_rule
    mod_args = dict(
        action='append',
        chain='INPUT',
        destination='1.1.1.1',
        jump='ACCEPT',
        protocol='tcp',
        source='2.2.2.2',
        rule_num='5',
        ip_version='ipv4',
        table='filter',
    )
    cmd = push_arguments('/sbin/iptables', '-C', mod_args)
    expected_cmd = ['/sbin/iptables', '-t', 'filter', '-C', 'INPUT']
    expected_cmd.extend(construct_rule(mod_args))
    assert cmd == expected_

# Generated at 2022-06-11 07:28:58.054466
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, {'flags': 'ALL', 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']

test_append_tcp_flags()


# Generated at 2022-06-11 07:28:59.608688
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('/sbin/iptables', 'iptables_path', '-A', 'params')


# Generated at 2022-06-11 07:29:01.159349
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', module,'-C', params) == True



# Generated at 2022-06-11 07:29:05.327781
# Unit test for function construct_rule
def test_construct_rule():
    j_rule = ['-A', 'INPUT', '-p', 'tcp', '-m', 'comment', '--comment', '"test_comment"']
    test_rule = dict(
        action='append',
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        comment='"test_comment"')
    assert construct_rule(test_rule) == j_rule



# Generated at 2022-06-11 07:29:07.341962
# Unit test for function get_chain_policy
def test_get_chain_policy():
    chain_header = 'Chain INPUT (policy DROP)'
    result = get_chain_policy(None, None, chain_header)
    assert result == 'DROP'



# Generated at 2022-06-11 07:29:25.107529
# Unit test for function get_chain_policy
def test_get_chain_policy():
    args = dict(
        table = 'filter',
        chain = 'FAIL2BAN',
        ip_version = 'ipv4',
        )
    iptables_path = '/sbin/iptables'
    module = ''
    print(get_chain_policy(iptables_path, module, args))



# Generated at 2022-06-11 07:29:34.894962
# Unit test for function remove_rule
def test_remove_rule():
    # Test an ipv4 command
    cmd = remove_rule('iptables', 'module', {'ip_version': 'ipv4'})
    assert(cmd == ['iptables', '-t', 'module', '-D', 'module'])
    # Test an ipv6 command
    cmd = remove_rule('ip6tables', 'module', {'ip_version': 'ipv6'})
    assert(cmd == ['ip6tables', '-t', 'module', '-D', 'module'])
    # Test an ipv4 command with comment
    cmd = remove_rule('iptables', 'module', {'ip_version': 'ipv4', 'comment': 'comment'})

# Generated at 2022-06-11 07:29:37.013079
# Unit test for function append_rule
def test_append_rule():
    iptables_path = "/bin/iptables"
    assert append_rule(iptables_path, module, params) == cmd



# Generated at 2022-06-11 07:29:45.804792
# Unit test for function construct_rule

# Generated at 2022-06-11 07:29:53.604092
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec=dict(
        chain='INPUT',
        source='8.8.8.8',
        ip_version='ipv4'))
    from distutils.version import LooseVersion
    ipset_version = LooseVersion(module.run_command('iptables --version')[1].split(' ')[1])
    if ipset_version >= LooseVersion('1.4.20'):
        assert check_present(module.params['ip_version'], module, module.params)
    else:
        assert not check_present(module.params['ip_version'], module, module.params)



# Generated at 2022-06-11 07:30:02.267990
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/sbin/iptables'
    action = '-A'
    params = {
        'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp',
        'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match',
        'jump': 'ACCEPT', 'comment': 'Accept new SSH connections',
    }
    cmd = push_arguments(iptables_path, action, params)

# Generated at 2022-06-11 07:30:10.864706
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('iptables', '-D', {
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': 1,
        'protocol': 'tcp',
        'wait': '1',
    }, False) == ['iptables', '-t', 'filter', '-D', 'INPUT', '1']

# Generated at 2022-06-11 07:30:19.901907
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule()
    assert(check_present('/sbin/iptables', module, dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.')) == True)
    assert(check_present('/sbin/iptables', module, dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.')) == False)



# Generated at 2022-06-11 07:30:21.326850
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", None, {"table": "filter", "chain": "INPUT"}) == "ACCEPT"



# Generated at 2022-06-11 07:30:27.524882
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        source='8.8.8.8',
        jump='DROP',
        table='filter',
        state='present',
    )

    assert push_arguments('iptables', '-A', params) == [
        'iptables', '-t', 'filter', '-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP']
# End unit test