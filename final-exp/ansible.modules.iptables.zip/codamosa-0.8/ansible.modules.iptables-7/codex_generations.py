

# Generated at 2022-06-11 07:21:38.765389
# Unit test for function construct_rule
def test_construct_rule():

    params = dict(
        ip_version='ipv4',
        source='8.8.8.8',
        destination='8.8.8.0/24',
        jump='DROP',
        in_interface='eth0',
        comment='Test comment',
        destination_ports=[22, 8080, '9066:9068'],
        match_set='drop_ips',
        match_set_flags='dst',
        )

    rule = construct_rule(params)


# Generated at 2022-06-11 07:21:40.582275
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({})
    iptables_path = module.get_bin_path('iptables')
    assert LooseVersion(get_iptables_version(iptables_path, module)).major == 1


# Generated at 2022-06-11 07:21:44.774002
# Unit test for function check_present
def test_check_present():
    iptables_path = "/sbin/iptables"
    module = "AnsibleModule"
    params = dict(
        table="filter",
        chain="INPUT",
        protocol="tcp",
        destination_port="22",
        ctstate="NEW",
        syn="match",
        jump="ACCEPT",
        comment="Accept new SSH connections."
    )
    assert check_present(iptables_path, module, params) == True



# Generated at 2022-06-11 07:21:46.341033
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], 'match', 'foo', True) == ['foo']
    assert append_match_flag([], 'negate', 'foo', True) == ['!', 'foo']
    assert append_match_flag([], None, 'foo', True) == []



# Generated at 2022-06-11 07:21:57.458589
# Unit test for function remove_rule

# Generated at 2022-06-11 07:22:07.262497
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        chain='INPUT',
        table='filter',
        action=None,
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        ip_version='ipv4'
    )
    assert push_arguments('iptables', '-A', params)
    assert push_arguments('iptables', '-D', params)
    assert push_arguments('iptables', '-I', params)
    assert push_arguments('iptables', '-R', params)



# Generated at 2022-06-11 07:22:18.323826
# Unit test for function construct_rule
def test_construct_rule():
    # Test reject_with
    params = dict(
        jump=None,
        protocol='tcp',
        table='filter',
        ip_version='ipv4',
        reject_with='icmp-port-unreachable'
    )
    assert construct_rule(params) == ['-p', 'tcp', '-j', 'REJECT', '--reject-with', 'icmp-port-unreachable']
    # Test icmp_type
    params = dict(
        jump=None,
        protocol='tcp',
        table='filter',
        ip_version='ipv4',
        icmp_type='echo-reply'
    )
    assert construct_rule(params) == ['-p', 'tcp', '--icmp-type', 'echo-reply']
    # Test icmp_type on ip

# Generated at 2022-06-11 07:22:22.831247
# Unit test for function insert_rule
def test_insert_rule():
    params = {'ip_version': 'ipv4', 'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': ['NEW'], 'syn': 'match', 'jump': 'ACCEPT', 'action': 'insert', 'rule_num': '5'}
    iptables_path = '/sbin/iptables'
    cmd = push_arguments(iptables_path, '-I', params)
    print(cmd)



# Generated at 2022-06-11 07:22:33.678013
# Unit test for function push_arguments
def test_push_arguments():
    IPTABLES = '/sbin/iptables'
    params = {
        'state': 'present',
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'ACCEPT',
        'ip_version': 'ipv4',
    }
    expected_cmd = [IPTABLES, '-t', 'filter', '-A', 'INPUT', '-p', 'tcp',
                    '--dport', '80', '-j', 'ACCEPT']
    assert push_arguments(IPTABLES, '-A', params) == expected_cmd
    assert push_arguments(IPTABLES, '-A', params, False) == expected_cmd[:-1]



# Generated at 2022-06-11 07:22:44.342861
# Unit test for function construct_rule

# Generated at 2022-06-11 07:23:03.223973
# Unit test for function append_rule
def test_append_rule():
    print("CHECKING append_rule")
    params = dict(
        chain='INPUT',
        jump='ACCEPT',
        protocol='tcp'
    )
    if append_rule('/sbin/iptables', None, params):
        print("PASSED")
    else:
        print("FAILED")



# Generated at 2022-06-11 07:23:13.493573
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        destination='192.0.2.5',
        sport=80,
        dstport=443,
        syn='negate',
        jump='DROP',
        comment='"bogus packets"'
    )
    expected = [
        '-w',
        '-p', 'tcp',
        '-d', '192.0.2.5',
        '--syn', '!',
        '-j', 'DROP',
        '-m', 'comment',
        '--comment', '"bogus packets"'
    ]
    assert construct_rule(params) == expected



# Generated at 2022-06-11 07:23:25.055923
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        source='1.2.3.4',
        destination='5.6.7.8',
        ip_version='ipv4',
        in_interface='eth0',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        limit='10/sec',
        comment='Ansible: test rule',
        reject_with='log-tcp-sequence',
        icmp_type='echo-request',
    )

# Generated at 2022-06-11 07:23:32.409446
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule(dict(
        wait='3'
    )) == ['-w', '3']
    assert construct_rule(dict(
        protocol='tcp'
    )) == ['-p', 'tcp']
    assert construct_rule(dict(
        source='192.168.0.1'
    )) == ['-s', '192.168.0.1']
    assert construct_rule(dict(
        destination='192.168.0.1'
    )) == ['-d', '192.168.0.1']
    assert construct_rule(dict(
        match='tcp'
    )) == ['-m', 'tcp']
    assert construct_rule(dict(
        match=['tcp', 'limit']
    )) == ['-m', 'tcp', '-m', 'limit']

# Generated at 2022-06-11 07:23:38.714298
# Unit test for function get_chain_policy
def test_get_chain_policy():
    class FakeModule:
        def run_command(self, _, check_rc):
            out = """Chain OUTPUT (policy ACCEPT)
target     prot opt source               destination"""
            return 0, out, ''
    module = FakeModule()
    policy = get_chain_policy('', module, dict(ip_version='ipv4', table='filter', chain='OUTPUT'))
    assert policy == 'ACCEPT', "Invalid policy returned from iptables"



# Generated at 2022-06-11 07:23:51.121183
# Unit test for function construct_rule

# Generated at 2022-06-11 07:24:01.992227
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = "test_iptables"
    module = "test_module"
    params = dict(
        table='filter',
        chain='FORWARD',
        ip_version='ipv4',
        protocol='tcp',
        jump='ACCEPT',
        to_ports='8500',
        comment='Accept new SSH connections.\''
    )

    rule = dict(
        table='filter',
        chain='FORWARD',
        ip_version='ipv4',
        protocol='tcp',
        jump='ACCEPT',
        to_ports='8500',
        comment='Accept new SSH connections.\''
    )
    cmd, check_rc=True
    if check_rc:
        cmd.run_command(cmd, check_rc=True)



# Generated at 2022-06-11 07:24:13.109780
# Unit test for function construct_rule
def test_construct_rule():
    rule = []
    params = dict(
        protocol="tcp",
        source="192.168.1.1",
        match="state",
        ctstate="NEW",
        syn="match",
        jump="ACCEPT",
        comment="Test rule"
    )
    rule = construct_rule(params)
    assert(rule == ['-p', 'tcp', '-s', '192.168.1.1', '-m', 'state', '--state', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Test rule'])

    rule = []

# Generated at 2022-06-11 07:24:24.137209
# Unit test for function construct_rule

# Generated at 2022-06-11 07:24:26.258079
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, dict(chain='INPUT', table='filter')) is None


# Generated at 2022-06-11 07:24:56.534592
# Unit test for function main

# Generated at 2022-06-11 07:25:06.031133
# Unit test for function append_param
def test_append_param():
    """Test append_param is working as expected"""
    assert append_param([], None, '--test', False) is None
    # The first parameter sets the list [], so we don't bother looking at it
    # The second parameter is a flag prepended to the parameter
    # The third parameter is the parameter itself (including none when set to None)
    # The fourth parameter sets whether the parameter is a list or not (False for no, True for yes)
    # The function always returns None
    assert append_param([], 'test', '--test', False) == ['--test', 'test']
    assert append_param([], '!test', '--test', False) == ['!', '--test', 'test']

# Generated at 2022-06-11 07:25:18.098279
# Unit test for function construct_rule
def test_construct_rule():
    module = AnsibleModule({})

# Generated at 2022-06-11 07:25:21.785359
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables',{'run_command':run_command},['iptables','-t','filter','-D','INPUT','-s','8.8.8.8','-j','DROP']) == 0




# Generated at 2022-06-11 07:25:32.100504
# Unit test for function append_param
def test_append_param():
    params = [None, '', 'foobar', '!']
    assert append_param([], '', 'none', False) == []
    assert append_param([], '', 'no-flag', False) == []
    assert append_param([], None, 'no-flag', False) == []
    for param in params:
        for is_list in [False, True]:
            assert append_param([], param, '--foo', is_list) == []
            assert append_param([], param, '', is_list) == []
            # Note we don't test for '!', it's a special case for the module.
            assert append_param([], param, '--foo-bar', is_list) == []
    assert append_param([], None, '--foo', False) == []

# Generated at 2022-06-11 07:25:34.418933
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('/sbin/iptables', 'module', 'params') == None



# Generated at 2022-06-11 07:25:44.612672
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict(
        chain=dict(type='str', required=True),
        jump=dict(type='str'),
        rule_num=dict(type='int', required=True),
        ))
    params = dict(
        chain = 'INPUT',
        jump = 'ACCEPT',
        rule_num = 5,
        )
    cmd = push_arguments(iptables_path, '-I', params)
    if cmd == ['/sbin/iptables', '-I', 'INPUT', '5', '-j', 'ACCEPT']:
        return True
    else:
        return False

# Generated at 2022-06-11 07:25:52.695069
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 07:26:05.750796
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule(dict(
        ip_version='ipv4',
        jump='ACCEPT',
        destination_port=None,
        destination_ports=['80', '443'],
        protocol='tcp',
        comment='Accept http and https traffic.'
    )) == ['-j', 'ACCEPT', '-m', 'multiport', '--dports', '80,443', '-p', 'tcp',
           '-m', 'comment', '--comment', 'Accept http and https traffic.']


# Generated at 2022-06-11 07:26:16.948712
# Unit test for function append_rule

# Generated at 2022-06-11 07:26:52.165807
# Unit test for function check_present
def test_check_present():
    import shlex
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 07:26:54.492856
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {"table": "nat", "chain": "OUTPUT"}) == "ACCEPT"



# Generated at 2022-06-11 07:27:04.339373
# Unit test for function construct_rule

# Generated at 2022-06-11 07:27:11.144802
# Unit test for function construct_rule

# Generated at 2022-06-11 07:27:14.265521
# Unit test for function get_chain_policy
def test_get_chain_policy():
    get_chain_policy('iptables', None, {'policy': 'DROP', 'chain': 'INPUT' })


# Generated at 2022-06-11 07:27:15.785024
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(policy='ACCEPT')) == 'ACCEPT'



# Generated at 2022-06-11 07:27:22.187154
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
       flags=['ACK', 'PSH', 'URG'],
       flags_set=['FIN', 'RST']
    )
    flag = '-m'
    # rule.extend([flag, ','.join(param['flags']), ','.join(param['flags_set'])])
    append_tcp_flags(rule, param, flag)
    assert rule == ['-m', 'ACK,PSH,URG', 'FIN,RST']
    rule = []
    param = ''
    flag = '-m'
    append_tcp_flags(rule, param, flag)
    assert rule == []



# Generated at 2022-06-11 07:27:25.128748
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert (get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT')



# Generated at 2022-06-11 07:27:36.785878
# Unit test for function main

# Generated at 2022-06-11 07:27:45.334801
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import *


# Generated at 2022-06-11 07:28:22.079404
# Unit test for function main

# Generated at 2022-06-11 07:28:31.402368
# Unit test for function construct_rule

# Generated at 2022-06-11 07:28:42.133049
# Unit test for function append_rule
def test_append_rule():
    mock_module = MockModule({
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'jump': 'DROP',
        'state': 'present',
        'reject_with': 'tcp-reset',
    })
    assert append_rule('/usr/sbin/iptables', mock_module, mock_module.params) == ['/usr/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-w', '-p', 'tcp', '--dport', '80', '-j', 'DROP', '--reject-with', 'tcp-reset']


# Generated at 2022-06-11 07:28:44.970311
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict()
    params['policy'] = 'ACCEPT'
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['ip_version'] = 'ipv4'
    params['wait'] = '1'
    iptables_path = 'iptables'
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)

# Generated at 2022-06-11 07:28:45.909483
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy("/usr/sbin/iptables",None,params) == None


# Generated at 2022-06-11 07:28:47.600809
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule("/sbin/iptables", mock, {"table": "nat", "chain": "test_chain", "rule_num": "test_rule_num", "protocol": "tcp", "jump": "ACCEPT"})



# Generated at 2022-06-11 07:28:56.665430
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {
        'flags': ['ACK', 'RST', 'SYN', 'FIN'],
        'flags_set': ['ACK', 'RST'],
    }
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST']
    rule = []
    param = {
        'flags': 'ACK,RST,SYN,FIN',
        'flags_set': 'ACK,RST',
    }
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST']



# Generated at 2022-06-11 07:29:03.602705
# Unit test for function get_chain_policy
def test_get_chain_policy():
    chain = 'INPUT'
    expected = 'ACCEPT'
    module = mock_module(BINS['ipv4'])
    assert get_chain_policy(BINS['ipv4'], module, dict(chain=chain, table='filter')) == expected
    chain = 'OUTPUT'
    expected = 'ACCEPT'
    assert get_chain_policy(BINS['ipv4'], module, dict(chain=chain, table='filter')) == expected
    chain = 'FORWARD'
    expected = 'ACCEPT'
    assert get_chain_policy(BINS['ipv4'], module, dict(chain=chain, table='filter')) == expected



# Generated at 2022-06-11 07:29:06.888469
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    test_param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK'],
    )
    flag = '--tcp-flags'
    append_tcp_flags(rule, test_param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK']



# Generated at 2022-06-11 07:29:12.037203
# Unit test for function get_chain_policy
def test_get_chain_policy():
    out = 'Chain INPUT (policy DROP)\n'
    assert get_chain_policy(None, None, None) is None
    assert get_chain_policy(None, None, out) is 'DROP'
    out = 'Chain INPUT (policy)\n'
    assert get_chain_policy(None, None, out) is None
    out = 'Chain INPUT\n'
    assert get_chain_policy(None, None, out) is None



# Generated at 2022-06-11 07:30:07.003769
# Unit test for function construct_rule

# Generated at 2022-06-11 07:30:09.271733
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('/bin/iptables', '', {
        'table': 'filter',
        'chain': 'INPUT',
    }) == 'ACCEPT'



# Generated at 2022-06-11 07:30:19.415226
# Unit test for function construct_rule

# Generated at 2022-06-11 07:30:22.044714
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == '1.6.1'
    assert get_iptables_version('iptables', None) == get_iptables_version('iptables', '1.6.1')
# End of unit test for function get_iptables_version


# Generated at 2022-06-11 07:30:27.851577
# Unit test for function get_chain_policy
def test_get_chain_policy():
    # Creating a test module to test function get_chain_policy()
    test_module = AnsibleModule(
        argument_spec=dict(
            table='filter',
            chain='INPUT',
            policy='DROP',
            wait=None,
        )
    )
    # Testing with a pre-defined chain policy.
    assert get_chain_policy("iptables", test_module, {"table": "filter", "chain": "INPUT",  "policy": "DROP", "wait": None}) == "DROP"



# Generated at 2022-06-11 07:30:31.535001
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(table='filter', chain='INPUT', protocol='tcp', destination_port='8080', jump='ACCEPT', action='insert', rule_num='5')
    assert insert_rule(iptables_path, module, params) == 'iptables -t filter -I INPUT 5 -p tcp --destination-port 8080 -j ACCEPT'


# Generated at 2022-06-11 07:30:41.055909
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol = "tcp",
        destination = "10.0.0.2",
        destination_ports = "80,443",
        jump = "ACCEPT",
        in_interface = "eth0",
        match = ["tcp", "state", "iprange", "owner"],
        ctstate = ["ESTABLISHED", "RELATED"],
        src_range = "1.1.1.1-2.2.2.2",
        uid_owner = "abcdef",
        comment = "Comment Text"
    )

# Generated at 2022-06-11 07:30:42.730189
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FOO'}) is None



# Generated at 2022-06-11 07:30:45.626315
# Unit test for function flush_table
def test_flush_table():
    iptables_path = "iptables"
    args = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4'
    )
    action = "flush_table"
    result = flush_table(iptables_path, action, args)
    assert result == "/sbin/iptables -t filter -F INPUT"



# Generated at 2022-06-11 07:30:47.981098
# Unit test for function insert_rule
def test_insert_rule():
  cmd = insert_rule('/sbin/iptables', None, {'rule_num':1,'table':'test','chain':'test','state':'test'})
  assert '-t test -I test 1' in cmd
  assert '-w' in cmd

