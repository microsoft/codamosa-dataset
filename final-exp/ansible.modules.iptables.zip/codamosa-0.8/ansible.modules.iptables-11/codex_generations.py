

# Generated at 2022-06-11 07:21:32.222645
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='Test comment'
    )
    cmd = push_arguments('/sbin/ip6tables', '-I', params)
    assert cmd == ['/sbin/ip6tables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Test comment']



# Generated at 2022-06-11 07:21:39.541165
# Unit test for function construct_rule

# Generated at 2022-06-11 07:21:41.267339
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = ['iptables', '-A']
    rule_param = 'negate'
    rule_flag = '--test'
    rule_negatable = True
    append_match_flag(rule, rule_param, rule_flag, rule_negatable)
    assert '!', '--test' in rule



# Generated at 2022-06-11 07:21:47.849444
# Unit test for function append_rule
def test_append_rule():
    """
    Tests the functionality of `append_rule`
    """
    PARAMS = {}
    PARAMS['chain'] = 'test_chain'
    PARAMS['table'] = 'mangle'
    PARAMS['ip_version'] = 'ipv4'
    PARAMS['match'] = None
    PARAMS['source'] = '192.168.0.1'
    PARAMS['destination'] = '172.16.0.1'
    PARAMS['protocol'] = 'tcp'
    PARAMS['jump'] = 'ACCEPT'
    PARAMS['comment'] = 'test_comment'
    PARAMS['syn'] = None
    PARAMS['ctstate'] = None
    PARAMS['tcp_flags'] = None
    PARAMS['src_range'] = None
    PARAMS['dst_range'] = None


# Generated at 2022-06-11 07:21:53.151059
# Unit test for function append_param
def test_append_param():
  rule = []
  param1 = ['!', 'test']
  flag1 = '--test'
  append_param(rule, param1, flag1, False)
  assert rule == ['!', '--test', 'test']



# Generated at 2022-06-11 07:22:02.240038
# Unit test for function append_rule
def test_append_rule():
    from ansible.module_utils import basic

# Generated at 2022-06-11 07:22:09.644173
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils.basic import AnsibleModule
    iptables_path = 'iptables'
    module = AnsibleModule({})
    module.run_command = lambda x, **kw: (0, '', 'test')
    params = dict(
        table='filter',
        chain='ACCEPT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
    )
    assert check_present(iptables_path, module, params) == True


# Generated at 2022-06-11 07:22:14.187598
# Unit test for function get_iptables_version
def test_get_iptables_version():
    version = get_iptables_version('/sbin/iptables', None)
    assert re.match(r'^\d+\.\d+\.\d+$', version)
    assert LooseVersion(version) >= LooseVersion(IPTABLES_WAIT_SUPPORT_ADDED)
# End unit test



# Generated at 2022-06-11 07:22:22.536674
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain = 'INPUT',
        protocol = 'tcp',
        destination_port = '22',
        ctstate = 'NEW',
        syn = 'match',
        jump = 'ACCEPT',
        comment = 'Accept new SSH connections.',
        ip_version = 'ipv4',
        rule_num = '5',
        state = 'present',
        wait = '10',
    )
    result = ['iptables', '-w', '10', '-A', 'INPUT', '-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']
    assert construct_rule(params) == result

# Generated at 2022-06-11 07:22:26.152770
# Unit test for function insert_rule
def test_insert_rule():
    params = {
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'rule_num': '5',
        'table': 'filter',
    }

    assert(insert_rule('/usr/sbin/iptables', '', params) == True)



# Generated at 2022-06-11 07:22:47.618805
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='192.168.1.12',
        destination='192.168.1.15',
        tcp_flags=dict(flags='ALL', flags_set=['ACK', 'RST', 'SYN', 'FIN']),
        jump='ACCEPT',
        to_destination='192.168.2.15',
        out_interface='eth0',
        match=['limit', 'state'],
        limit='3/s',
        limit_burst='6',
        uid_owner=['user1', '!user2'],
        comment='my rule',
    )
    # The function should return list of arguments
    assert isinstance(construct_rule(params), list)
    # Expected rule

# Generated at 2022-06-11 07:22:58.560578
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    params = {
        "table": "filter",
        "chain": "INPUT",
        "protocol": "8",
        "destination_port": "80",
        "jump": "ACCEPT",
        "rule_num": "5"
    }
    cmd = push_arguments(iptables_path, '-I', params)
    assert(cmd == ['/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', '8', '--dport', '80', '-j', 'ACCEPT'])



# Generated at 2022-06-11 07:23:02.473237
# Unit test for function get_chain_policy
def test_get_chain_policy():
    _, _, policy = get_chain_policy('', '', {'chain': 'INPUT'})
    assert policy == 'DROP'
    _, _, policy = get_chain_policy('', '', {'chain': 'OUTPUT'})
    assert policy == 'ACCEPT'



# Generated at 2022-06-11 07:23:07.211607
# Unit test for function insert_rule
def test_insert_rule():
    insert_rule('/sbin/iptables', None, {
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': 5,
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT'
    })



# Generated at 2022-06-11 07:23:16.954228
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    params = {
        'action': 'append',
        'chain': 'INPUT',
        'protocol': 'udp',
        'destination_port': '80',
        'jump': 'ACCEPT'
    }
    cmd = push_arguments(iptables_path, '-A', params)
    assert cmd == ['/sbin/iptables', '-A', 'INPUT', '-p', 'udp', '--dport', '80', '-j', 'ACCEPT']
    return True



# Generated at 2022-06-11 07:23:26.733524
# Unit test for function remove_rule
def test_remove_rule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    import os
    import sys
    import tempfile

    # make sure we don't do destructive things to the user's system
    tempdir = tempfile.mkdtemp()
    old_sys_path, sys.path = sys.path, [tempdir]
    old_os_environ, os.environ = os.environ, {'PATH': "/usr/bin"}


# Generated at 2022-06-11 07:23:30.851128
# Unit test for function main
def test_main():
    args = dict(
        chain='RH-Firewall-1-INPUT',
        ip_version='ipv4',
        table='filter',
        state='present',
        protocol='tcp',
        destination='0/0',
        destination_port='22',
        comment="test",
        jump='ACCEPT',
        src_range=''
    )
    construct_rule(args)

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:23:40.898540
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/bin/iptables'
    action = '-D'
    chain = 'INPUT'
    table = 'filter'
    rule_num = ''
    protocol = 'tcp'
    source = '8.8.8.8'
    destination = '192.168.1.1'
    destination_port = '22'
    jump = 'DROP'
    comment = 'block_specific_ip'
    params = dict(rule_num=rule_num, chain=chain, table=table, protocol=protocol, source=source, destination=destination, destination_port=destination_port, jump=jump, comment=comment)
    cmd = push_arguments(iptables_path, action, params)

# Generated at 2022-06-11 07:23:44.625812
# Unit test for function flush_table
def test_flush_table():
    params = dict(
        table='filter',
        chain='INPUT',
        flush=True
    )
    assert flush_table('', '', params) == 'iptables -t filter -F INPUT'



# Generated at 2022-06-11 07:23:47.858645
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['ACK','RST','SYN','FIN'], flags_set=['ACK'])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK']


# Generated at 2022-06-11 07:24:02.797821
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = 'iptables'
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'policy': 'DROP'
    }
    assert set_chain_policy(iptables_path, module, params) == [
        'iptables', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-11 07:24:10.084803
# Unit test for function remove_rule
def test_remove_rule():
    class mock_module:
        def run_command(self, cmd, check_rc=True):
            t = True
            return cmd, check_rc, t

    module = mock_module()
    params = dict(chain='INPUT', ip_version='ipv4')
    cmd = push_arguments('iptables', '-D', params)
    rc, _, __ = module.run_command(cmd, check_rc=False)
    assert rc == 0



# Generated at 2022-06-11 07:24:11.989226
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': []}
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', '']


# Generated at 2022-06-11 07:24:13.543458
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables',None)=='1.6.0'


# Generated at 2022-06-11 07:24:24.503727
# Unit test for function push_arguments
def test_push_arguments():
    test_rule_args = {
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': '1',
        'action': '-I',
        'protocol': 'tcp',
        'destination_port': '22',
        'ctstate': 'NEW',
        'syn': 'match',
        'jump': 'ACCEPT',
        'comment': 'Allow new SSH connections.',
        'ip_version': 'ipv4'
    }


# Generated at 2022-06-11 07:24:30.492192
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    assert append_tcp_flags([], dict(flags=['ACK', 'RST', 'SYN', 'FIN'], flags_set=['ACK', 'RST', 'SYN', 'FIN']), '-m tcp --tcp-flags') == ['-m tcp --tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']


# Generated at 2022-06-11 07:24:41.342526
# Unit test for function construct_rule

# Generated at 2022-06-11 07:24:44.646027
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule
    cmd = push_arguments(BINS['ipv4'], module, CHECK_PRESENT_PARAMS)

# Generated at 2022-06-11 07:24:46.208266
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', module, params)



# Generated at 2022-06-11 07:24:48.217525
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', 'INPUT', 'DROP') == 'DROP'



# Generated at 2022-06-11 07:25:07.189222
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {
        'policy': None,
        'table': 'filter',
        'chain': 'INPUT',
    }) == 'DROP'

    assert get_chain_policy(None, None, {
        'policy': None,
        'table': 'filter',
        'chain': 'OUTPUT',
    }) == 'ACCEPT'

    assert get_chain_policy(None, None, {
        'policy': None,
        'table': 'filter',
        'chain': 'FORWARD',
    }) == 'ACCEPT'



# Generated at 2022-06-11 07:25:19.298148
# Unit test for function main

# Generated at 2022-06-11 07:25:24.232151
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    res = []
    append_tcp_flags(res, dict(flags=['ACK', 'PSH'], flags_set=['ACK', 'RST', 'SYN', 'FIN']), '--tcp-flags')
    assert res == ['--tcp-flags', 'ACK,PSH', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-11 07:25:34.869642
# Unit test for function construct_rule
def test_construct_rule():
    #rule_no_wait_no_syn = ['--icmp-type', 'echo-request', '-p', 'icmp', '-m', 'limit', '--limit', '1/hour', '-j', 'ACCEPT']
    #assert construct_rule(dict(ip_version='ipv4', protocol='icmp', icmp_type='echo-request', jump='ACCEPT', limit='1/hour', syn=None, comment=None)) == rule_no_wait_no_syn
    rule_wait_with_syn = ['-w', '10', '--icmp-type', 'echo-request', '-p', 'icmp', '-m', 'limit', '--limit', '1/hour', '--syn', '-j', 'ACCEPT']

# Generated at 2022-06-11 07:25:46.240993
# Unit test for function main
def test_main():
    # Target is not up to date, rule is present
    module = Mock()

# Generated at 2022-06-11 07:25:55.447983
# Unit test for function main

# Generated at 2022-06-11 07:26:03.751502
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('/sbin/iptables', {},
                            {'table': 'filter', 'chain': 'INPUT'}) == 'DROP'
    assert get_chain_policy('/sbin/iptables', {},
                            {'table': 'filter', 'chain': 'FORWARD'}) == 'DROP'
    assert get_chain_policy('/sbin/iptables', {},
                            {'table': 'filter', 'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-11 07:26:12.668711
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        rule='',
        protocol='tcp',
        source='127.0.0.1',
        destination='127.0.0.254',
        match='multiport',
        jump='ACCEPT',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '-s', '127.0.0.1', '-d', '127.0.0.254', '-j', 'ACCEPT']



# Generated at 2022-06-11 07:26:19.612729
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", {}, {"chain":"INPUT", "table": "filter"}) == "ACCEPT"
    assert get_chain_policy("iptables", {}, {"chain":"OUTPUT", "table": "filter"}) == "ACCEPT"
    assert get_chain_policy("iptables", {}, {"chain":"FORWARD", "table": "filter"}) == "DROP"



# Generated at 2022-06-11 07:26:19.998078
# Unit test for function flush_table
def test_flush_table():
    pass



# Generated at 2022-06-11 07:26:38.324460
# Unit test for function flush_table
def test_flush_table():
    # Arrange
    module = mock.Mock()
    module.run_command.return_value = 0, '', ''
    iptables_path = "iptables"
    params = dict(
        table="filter",
        chain="LISTEN"
    )
    expected = [iptables_path, '-t', 'filter', '-F', 'LISTEN']
    # Act
    flush_table(iptables_path, module, params)
    # Assert
    module.run_command.assert_called_with(expected)

# Generated at 2022-06-11 07:26:43.509416
# Unit test for function construct_rule
def test_construct_rule():
    """
    iptables rule to parse
    -A INPUT -p tcp --dport 8080 -j ACCEPT
    """
    params = {
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
    }
    compare_rule(construct_rule(params), params)



# Generated at 2022-06-11 07:26:54.705279
# Unit test for function check_present
def test_check_present():
    cmd = ['/sbin/iptables', '-C', 'INPUT', '-p', 'tcp', '-s', '12.34.21.23',
           '-d', '22.11.12.32', '-m', 'limit', '--limit', '24/hour', '--limit-burst', '120',
           '-j', 'DROP']
    assert check_present('/sbin/iptables', AnsibleModule(argument_spec={}), construct_rule(dict(
        chain='INPUT',
        protocol='tcp',
        source='12.34.21.23',
        destination='22.11.12.32',
        limit='24/hour',
        limit_burst='120',
        jump='DROP',
        ip_version='ipv4'
    ))) == True



# Generated at 2022-06-11 07:26:58.207189
# Unit test for function append_rule
def test_append_rule():
    append_rule('/usr/sbin/iptables', '', dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT'))



# Generated at 2022-06-11 07:26:59.071781
# Unit test for function append_rule
def test_append_rule():
    assert False



# Generated at 2022-06-11 07:27:01.755508
# Unit test for function append_match_flag
def test_append_match_flag():
    assert(append_match_flag(['iptables',], None, '--syn', True) == ['iptables',])
    assert(append_match_flag(['iptables',], 'match', '--syn', True) == ['iptables', '--syn'])
    assert(append_match_flag(['iptables',], 'negate', '--syn', True) == ['iptables', '!', '--syn'])


# Generated at 2022-06-11 07:27:05.303402
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module',
        {
            'table': 'filter',
            'chain': 'INPUT',
            'policy': 'DROP'
        }
    ) == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-11 07:27:08.108772
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = 'iptables'
    module = module()
    params = params()
    cmd = push_arguments(iptables_path, '-I', params)
    module.run_command(cmd, check_rc=True)
    


# Generated at 2022-06-11 07:27:12.659789
# Unit test for function append_rule
def test_append_rule():
    params = {
        'protocol': 'tcp',
        'source': '10.10.10.10',
        'destination': '10.20.20.20',
        'chain': 'INPUT',
        'table': 'filter',
        'destination_port': '80',
        'jump': 'ACCEPT',
    }
    iptables_path='iptables'
    module={}
    module.run_command = lambda x, y: None
    append_rule(iptables_path,module,params)
    assert module.run_command.called



# Generated at 2022-06-11 07:27:19.142137
# Unit test for function main

# Generated at 2022-06-11 07:27:43.489593
# Unit test for function main
def test_main():
    import requests
    import re
    import shlex
    import sys
    import json
    import os
    import argparse
    import tempfile
    import subprocess
    from ansible.module_utils.basic import *
    from ansible.module_utils._text import to_native


# Generated at 2022-06-11 07:27:51.206497
# Unit test for function remove_rule
def test_remove_rule():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    params = {'table':'filter', 'chain':'INPUT'}
    module.run_command = lambda cmd, check_rc=True: (0, '', '')
    remove_rule('iptables', module, params)



# Generated at 2022-06-11 07:27:58.952315
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/bin/iptables'

# Generated at 2022-06-11 07:28:10.062700
# Unit test for function construct_rule

# Generated at 2022-06-11 07:28:21.391060
# Unit test for function main

# Generated at 2022-06-11 07:28:30.755519
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = "/path/to/iptables"
    module = AnsibleModule(
    argument_spec = dict(
        ip_version = dict(default='ipv4', choices=['ipv4', 'ipv6']),
    )
    )
    params = dict(
        protocol='tcp',
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        state='absent',
        destination_port='22',
        jump='ACCEPT',
        comment='Accept new SSH connections.'
    )

# Generated at 2022-06-11 07:28:41.571631
# Unit test for function construct_rule

# Generated at 2022-06-11 07:28:45.471327
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(argument_spec={})
    params = dict(chain='INPUT', policy='DROP')
    iptables_path = 'iptables'
    result = get_chain_policy(iptables_path, module, params)
    assert result == 'ACCEPT'



# Generated at 2022-06-11 07:28:54.891686
# Unit test for function construct_rule

# Generated at 2022-06-11 07:29:03.265108
# Unit test for function construct_rule

# Generated at 2022-06-11 07:30:08.714092
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = "/usr/bin/iptables"
    module =  AnsibleModule(argument_spec=dict(table='filter', chain='INPUT', ip_version='ipv4'))
    params = {'chain': 'INPUT', 'comment': 'Allow new SSH connections.', 'destination_port': '22', 'ip_version': 'ipv4', 'jump': 'ACCEPT', 'match': 'tcp', 'syn': 'match', 'table': 'filter'}
    cmd = push_arguments(iptables_path, '-I', params)
    expected = '/usr/bin/iptables -t filter -I INPUT -p tcp -m tcp --dport 22 --syn -j ACCEPT -m comment --comment "Allow new SSH connections."'
    assert " ".join(cmd) == expected


# Generated at 2022-06-11 07:30:18.793764
# Unit test for function construct_rule
def test_construct_rule():

    rule = [
        '-s', '10.0.0.1',
        '-d', '10.0.0.2',
        '-p', 'tcp',
        '-m', 'conntrack',
        '--ctstate', 'RELATED,ESTABLISHED',
        '-m', 'limit',
        '--limit', '2/s',
        '--limit-burst', '5',
        '-m', 'comment',
        '--comment', '"Allow related and established connections"',
        '-j', 'ACCEPT',
    ]


# Generated at 2022-06-11 07:30:24.027125
# Unit test for function check_present
def test_check_present():
    rule = {
        'ip_version': 'ipv4',
        'chain': 'FORWARD',
        'table': 'filter',
        'protocol': 'tcp'
    }
    cmd = push_arguments('iptables', '-C', rule)
    assert cmd == [
        'iptables', '-t', 'filter', '-C', 'FORWARD', '-p', 'tcp']



# Generated at 2022-06-11 07:30:30.664535
# Unit test for function construct_rule

# Generated at 2022-06-11 07:30:39.923404
# Unit test for function construct_rule
def test_construct_rule():
    '''
    :return: Test construct rule function
    '''
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
    )
    result = construct_rule(params)
    assert result == ['-p', 'tcp', '--dport', '22', '-m', 'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.']



# Generated at 2022-06-11 07:30:42.159148
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec={})
    params = dict()
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    assert get_chain_policy(iptables_path, module, params) == 'ACCEPT'



# Generated at 2022-06-11 07:30:43.395787
# Unit test for function get_chain_policy
def test_get_chain_policy():
    policy = get_chain_policy('-L', None, dict(table='filter', chain='INPUT'))
    assert policy == 'ACCEPT'


# Generated at 2022-06-11 07:30:47.330899
# Unit test for function construct_rule
def test_construct_rule():
    # Arrange
    params = dict(
        protocol='tcp',
        jump='ACCEPT',
        comment='My comment'
    )

    # Act
    result = construct_rule(params)

    # Assert
    assert result == [
        '-p', 'tcp',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'My comment'
    ]


# Generated at 2022-06-11 07:30:54.254670
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        source='8.8.8.8',
        jump='DROP',
        ip_version='ipv4'
    )
    assert construct_rule(params) == ['-A', 'INPUT', '-s', '8.8.8.8', '-j', 'DROP']

    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port=22,
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4'
    )

# Generated at 2022-06-11 07:30:58.897057
# Unit test for function check_present