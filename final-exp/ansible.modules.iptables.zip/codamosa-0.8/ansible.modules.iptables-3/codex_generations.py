

# Generated at 2022-06-11 07:21:25.616247
# Unit test for function get_iptables_version
def test_get_iptables_version():
    return



# Generated at 2022-06-11 07:21:33.495794
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module_mock = Mock()
    class module_mock:
        run_command = Mock(return_value=(0, "Chain FORWARD (policy ACCEPT)", ""))
    xtables_mock = 'iptables'
    params_mock = dict(chain='FORWARD', action='insert', table='filter')
    assert get_chain_policy(xtables_mock, module_mock, params_mock) == 'ACCEPT'
    assert module_mock.run_command.call_args[0][0] == ['iptables', '-t', 'filter', '-L', 'FORWARD']



# Generated at 2022-06-11 07:21:42.174029
# Unit test for function main

# Generated at 2022-06-11 07:21:42.913733
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-11 07:21:48.107231
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/usr/bin/iptables', None) == '1.6.2'
    assert get_iptables_version('/usr/bin/ip6tables', None) == '1.6.2'

# ===========================================
# Unit test helper functions.
#


# Generated at 2022-06-11 07:21:59.808972
# Unit test for function construct_rule

# Generated at 2022-06-11 07:22:04.170930
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=["ALL"], flags_set=["ACK", "RST", "SYN", "FIN"])
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ALL', 'ACK,RST,SYN,FIN']
test_append_tcp_flags()



# Generated at 2022-06-11 07:22:14.911773
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
        flags_set=['ACK', 'RST'],
    )
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert(rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST'])
    rule = []
    param = dict(
        flags_set=['ACK', 'RST'],
    )
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)

    assert(rule == [])
    rule = []
    param = dict(
        flags=['ACK', 'RST', 'SYN', 'FIN'],
    )


# Generated at 2022-06-11 07:22:17.865501
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain':'test'}) == None
    assert get_chain_policy(None, None, {'chain':'INPUT'}) == 'ACCEPT'
# end of unit test



# Generated at 2022-06-11 07:22:29.294933
# Unit test for function construct_rule
def test_construct_rule():
    small_dict = dict(
        ip_version='ipv4',
        protocol='tcp',
        jump='ACCEPT',
    )
    large_dict = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='192.168.1.1',
        destination='192.168.0.1',
        match=['conntrack', 'owner'],
        ctstate='NEW',
        uid_owner='!root',
        destination_port='80',
        to_ports='8080',
        comment='This is a comment',
        syn='negate',
        jump='ACCEPT',
    )
    assert construct_rule(small_dict) == ['-p', 'tcp', '-j', 'ACCEPT']

# Generated at 2022-06-11 07:22:48.744847
# Unit test for function push_arguments

# Generated at 2022-06-11 07:23:00.823734
# Unit test for function construct_rule

# Generated at 2022-06-11 07:23:12.723439
# Unit test for function get_chain_policy
def test_get_chain_policy():
    class FakeModule:
        def __init__(self):
            self.run_command_called = False
            self.cmd = None
            self.rc = None
            self.out = None

        def run_command(self, cmd, check_rc=False):
            self.run_command_called = True
            self.cmd = cmd
            self.rc = self.rc
            self.out = self.out
            return self.rc, self.out, None

    class FakeArgs:
        def __init__(self):
            self.chain = 'INPUT'
            self.table = 'filter'
            self.action = 'present'
            self.ip_version = 'ipv4'
            self.policy = 'DROP'
            self.wait = None

    module = FakeModule()
    params = FakeArgs()


# Generated at 2022-06-11 07:23:16.748772
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--something', True)
    assert rule == ['--something']


# Generated at 2022-06-11 07:23:18.106663
# Unit test for function check_present
def test_check_present():
    check_present('iptables', module, {})



# Generated at 2022-06-11 07:23:27.752981
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        jump='DROP',
        source='192.168.0.20',
        destination='192.168.0.21',
        match='',
        set_counters='',
        source_port='',
        destination_port='80',
        comment='test',
        ip_version='ipv4',
        reject_with='',
        icmp_type='',
        ctstate='',
    )
    assert construct_rule(params) == ['-p', 'tcp', '-s',
                                      '192.168.0.20', '-d', '192.168.0.21', '-j',
                                      'DROP', '--comment', 'test']


# Generated at 2022-06-11 07:23:28.235779
# Unit test for function set_chain_policy
def test_set_chain_policy():
    pass



# Generated at 2022-06-11 07:23:34.152719
# Unit test for function construct_rule

# Generated at 2022-06-11 07:23:46.414084
# Unit test for function main

# Generated at 2022-06-11 07:23:48.727953
# Unit test for function insert_rule
def test_insert_rule():
    rule = construct_rule(params)
    command.extend(['-I', chain, rule_num])
    command.extend(rule)



# Generated at 2022-06-11 07:24:40.024257
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('/tmp/iptables',
                          '-I', {
                              'table': 'nat',
                              'chain': 'INPUT',
                              'rule_num': '5',
                              'protocol': 'tcp',
                              'destination_port': '8080',
                              'jump': 'ACCEPT',
                              'ip_version': 'ipv4'
                          }) == [
                              '/tmp/iptables', '-t', 'nat', '-I', 'INPUT', '5',
                              '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT'
                          ]



# Generated at 2022-06-11 07:24:52.044805
# Unit test for function construct_rule
def test_construct_rule():
    expected = [
        '-w',
        '-p', 'tcp',
        '-s', '8.8.8.8',
        '-d', '8.8.4.4',
        '-m', 'connlimit', '--connlimit-above', '100',
        '-m', 'conntrack', '--ctstate', 'ESTABLISHED,RELATED',
        '-m', 'limit', '--limit', '50/second', '--limit-burst', '20',
        '-j', 'ACCEPT',
        '-m', 'owner', '--gid-owner', 'root',
        '-m', 'comment', '--comment', 'This is a comment',
    ]

# Generated at 2022-06-11 07:24:55.391467
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {
        'table': 'filter',
        'chain': 'INPUT',
    }) == 'ACCEPT'



# Generated at 2022-06-11 07:25:02.919888
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 07:25:10.445234
# Unit test for function flush_table
def test_flush_table():
    module_args = dict(
        table='filter',
        chain='INPUT',
        flush=True,
    )
    res = {
        'changed': True,
        'cmd': ['/sbin/iptables', '-t', 'filter' ,'-F', 'INPUT'],
        'rc': 0,
        'stderr': '',
        'stderr_lines': [],
        'stdout': '',
        'stdout_lines': [],
    }
    return res



# Generated at 2022-06-11 07:25:22.462799
# Unit test for function set_chain_policy

# Generated at 2022-06-11 07:25:25.269956
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("", {}, {'table': 'nat', 'chain': 'POSTROUTING', 'ip_version': 'ipv4'}) == "ACCEPT"


# Generated at 2022-06-11 07:25:30.867982
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], 'not_match', '--foo', False) == []
    assert append_match_flag([], 'match', '--foo', False) == ['--foo']
    assert append_match_flag([], 'negate', '--foo', True) == ['!', '--foo']
    assert append_match_flag([], 'ignore', '--foo', True) == []



# Generated at 2022-06-11 07:25:35.788375
# Unit test for function construct_rule
def test_construct_rule():
    IPTABLES_VERSION = '1.4.20'

    command = ['iptables', '-w', '5', '-A', 'INPUT', '-p', 'tcp', '-s', '0.0.0.0/0', '-d', '0.0.0.0/0', '-j', 'DROP', '-m', 'conntrack', '--ctstate', 'INVALID', '-m', 'limit', '--limit', '3/min', '--limit-burst', '3', '-m', 'comment', '--comment', '"test comment"']

# Generated at 2022-06-11 07:25:47.273800
# Unit test for function construct_rule
def test_construct_rule():
    args = dict(
        command="insert",
        chain="INPUT",
        protocol="tcp",
        reject_with="icmp-port-unreachable",
        comment="just testing"
    )
    rule = construct_rule(args)
    assert rule == ['-w', '-j', 'REJECT', '--reject-with', 'icmp-port-unreachable', '-m', 'comment', '--comment', 'just testing']

    args = dict(
        command="append",
        chain="INPUT",
        protocol="tcp",
        destination_port="22",
        jump="ACCEPT",
        icmp_type="echo-request",
        ip_version="ipv4",
        comment="Allow SSH"
    )
    rule = construct_rule(args)

# Generated at 2022-06-11 07:26:52.624326
# Unit test for function append_rule
def test_append_rule():
    append_rule(iptables_path, module, params)


# Generated at 2022-06-11 07:27:02.937911
# Unit test for function construct_rule
def test_construct_rule():
    # ipv4
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='8.8.8.8',
        destination='10.0.0.1',
        jump='ACCEPT',
        )
    assert construct_rule(params) == [
        '-p', 'tcp', '-s', '8.8.8.8', '-d', '10.0.0.1', '-j', 'ACCEPT']
    params['syn'] = 'negate'
    assert construct_rule(params) == [
        '-p', 'tcp', '-s', '8.8.8.8', '-d', '10.0.0.1', '-j', 'ACCEPT', '!', '--syn']

# Generated at 2022-06-11 07:27:11.983100
# Unit test for function set_chain_policy
def test_set_chain_policy():
    ip_version = "ipv4"
    path = BINS[ip_version]
    m = AnsibleModule({'chain': 'INPUT', 'policy': 'DROP'}, check_invalid_arguments=False)
    set_chain_policy(path, m, {'table': 'filter', 'chain': 'INPUT', 'policy': 'DROP', 'ip_version': ip_version})
    assert m.run_command.call_count == 1
    assert m.run_command.call_args == (([path, '-t', 'filter', '-P', 'INPUT', 'DROP'],), {'check_rc': True})
# Test function set_chain_policy is called with ipv6

# Generated at 2022-06-11 07:27:15.066956
# Unit test for function flush_table
def test_flush_table():
    module = MockModule({})
    assert flush_table(
        '/bin/iptables',
        module,
        {'chain': 'OUTPUT', 'table': 'filter'}
    ) == [
        '/bin/iptables', '-t', 'filter', '-F', 'OUTPUT'
    ]



# Generated at 2022-06-11 07:27:18.947131
# Unit test for function check_present
def test_check_present():
    test_input = dict(
        iptables_path='/sbin/iptables',
        module='None',
        params=dict(
            table='filter',
            chain='INPUT',
            rule_num='1',
            jump='ACCEPT',
            protocol='tcp',
            source='8.8.8.8',
        ),
    )
    assert check_present(**test_input) == False


# Generated at 2022-06-11 07:27:25.187718
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("/usr/bin/iptables", None, dict(
        table='filter',
        chain='INPUT',
        policy='ACCEPT'
    )) == 'ACCEPT'
    assert get_chain_policy("/usr/bin/iptables", None, dict(
        table='filter',
        chain='INPUT',
        policy='DROP'
    )) == 'DROP'
    assert get_chain_policy("/usr/bin/iptables", None, dict(
        table='filter',
        chain='INPUT',
        policy='QUEUE'
    )) == 'QUEUE'
    assert not get_chain_policy("/usr/bin/iptables", None, dict(
        table='filter',
        chain='INPUT',
        policy='ACCEPT'
    )) == 'DROP'


# Generated at 2022-06-11 07:27:36.917017
# Unit test for function construct_rule
def test_construct_rule():
    """Unit test for function construct_rule"""
    # Success case
    # Test:
    #   dump rule with --line-numbers
    #   construct rule
    #   check if the constructed rule starts with rule number
    result = AnsibleModule(
        argument_spec=dict(
            ip_version=dict(required=True, choices=['ipv4', 'ipv6'], type='str'),
            chain=dict(required=True, type='str'),
            table=dict(required=True, type='str'),
        ),
        supports_check_mode=True,
    ).run_command(
        [BINS['ipv4'], '-t', 'filter', '-vL', 'INPUT', '--line-numbers'],
        check_rc=True
    )

# Generated at 2022-06-11 07:27:46.841764
# Unit test for function construct_rule

# Generated at 2022-06-11 07:27:52.900194
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        destination='127.0.1.1',
        destination_port='22',
        jump='ACCEPT',
        state='present',
        action='append',
        match=['tcp', 'conntrack', 'state'],
        tcp_flags=dict(
            flags=['ALL'],
            flags_set=['SYN'],
        ),
        ctstate=['RELATED', 'ESTABLISHED'],
        wait='10',
    )

# Generated at 2022-06-11 07:27:56.370687
# Unit test for function check_present
def test_check_present():
    sys.argv[1] = "-ttest table_test -Ca test rule"
    cmd = push_arguments('iptables', '-C', params)
    print(push_arguments('iptables', '-C', params))
    return (cmd)


# Generated at 2022-06-11 07:29:48.894453
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule('/usr/bin/iptables', {}, {'rule_num':5}) == ['iptables', '-I',  5]



# Generated at 2022-06-11 07:29:57.835283
# Unit test for function construct_rule

# Generated at 2022-06-11 07:30:06.777076
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/usr/sbin/iptables'
    module = mock_module

# Generated at 2022-06-11 07:30:16.582475
# Unit test for function construct_rule

# Generated at 2022-06-11 07:30:26.264866
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception


# Generated at 2022-06-11 07:30:27.792275
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy("iptables", "module", "params", "policy") == ["iptables", "-P", "params", "policy"]



# Generated at 2022-06-11 07:30:33.593817
# Unit test for function main
def test_main():
    iptables_path = '/sbin/iptables'

# Generated at 2022-06-11 07:30:38.568913
# Unit test for function construct_rule
def test_construct_rule():
    params_input_1 = dict(
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        match=['state'],
        ctstate=['NEW']
    )
    params_input_2 = dict(
        source='1.1.1.1/24',
        destination='2.2.2.2/24',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        match=['state'],
        ctstate=['NEW']
    )

# Generated at 2022-06-11 07:30:43.344462
# Unit test for function construct_rule
def test_construct_rule():

    params = dict(
        protocol='tcp',
        syn='match',
        action='insert',
        jump='ACCEPT',
        destination_ports='80',
        comment='Accept new SSH connections',
    )
    assert construct_rule(params) == [
        '-m', 'multiport', '--dports', '80', '-j', 'ACCEPT',
        '-m', 'comment', '--comment', 'Accept new SSH connections']



# Generated at 2022-06-11 07:30:44.839456
# Unit test for function get_chain_policy
def test_get_chain_policy():
    ips = get_chain_policy('iptables', 'module', params)
    assert ips == 'ACCEPT'

