

# Generated at 2022-06-11 07:21:22.080249
# Unit test for function set_chain_policy
def test_set_chain_policy():
    # construct rule
    params = {}
    params['chain'] = 'INPUT'
    params['policy'] = 'ACCEPT'
    result = []
    result.extend(['iptables', '-P', 'INPUT', 'ACCEPT'])
    assert result == push_arguments('iptables', None, params, make_rule=False)



# Generated at 2022-06-11 07:21:24.812792
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', None, dict(table='filter', chain='INPUT')
    ) == 'ACCEPT'



# Generated at 2022-06-11 07:21:27.520224
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('test_path', 'module', 'test_params') == None



# Generated at 2022-06-11 07:21:37.181699
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    import sys
    import os
    import re

    os.environ['ANSIBLE_MODULE_NO_SYSTEM_RANDOM'] = '1'


# Generated at 2022-06-11 07:21:40.608317
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {"policy": "ACCEPT", "chain": "INPUT"}) == "ACCEPT"



# Generated at 2022-06-11 07:21:47.276570
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num='5',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        comment='test',
        ip_version='ipv4',
        )
    assert push_arguments('iptables', '-I', params) == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'test']
    params.update(dict(jump='DROP'))

# Generated at 2022-06-11 07:21:52.616986
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._text import to_text
    from ansible.module_utils._text import to_bytes
    from tempfile import NamedTemporaryFile
    from contextlib import contextmanager
    import sys
    import os
    import imp

    try:
        from subprocess32 import CalledProcessError, TimeoutExpired
    except ImportError:
        from subprocess import CalledProcessError, TimeoutExpired

    if sys.version_info[0] > 2:
        # python3
        from io import StringIO
    else:
        # python2
        from io import BytesIO as StringIO

    import pytest

    @contextmanager
    def stdoutIO(stdout=None):
        # Simulate stdout
        old = sys.stdout


# Generated at 2022-06-11 07:21:55.741677
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    append_tcp_flags(rule, {"flags": ["ACK", "RST", "SYN", "FIN"], "flags_set": ["ACK", "RST", "SYN", "FIN"]}, "--tcp-flags")
    print (rule)

# Generated at 2022-06-11 07:22:01.702511
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/bin/iptables'
    module_params = {'table': 'nat', 'chain': 'PREROUTING', 'in_interface': 'eth0', 'protocol': 'tcp', 'match': 'tcp','destination_port': '80', 'jump': 'REDIRECT', 'to_ports': '8600', 'comment': 'Redirect web traffic to port 8600'}
    module = AnsibleModule(argument_spec={})
    cmd = push_arguments(iptables_path, '-A', module_params)
    print (cmd)


# Generated at 2022-06-11 07:22:02.683401
# Unit test for function remove_rule
def test_remove_rule():
    assert (remove_rule("-I",None,None)==None)



# Generated at 2022-06-11 07:22:22.919565
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        chain="LOGGING",
        action="append",
        state="present",
        limit="2/second",
        limit_burst="20",
        log_prefix="IPTABLES:INFO: ",
        log_level="info",
        ip_version="ipv4",
        table="filter"
    )
    result = push_arguments("iptables", action="-I", params=params)

# Generated at 2022-06-11 07:22:29.332895
# Unit test for function insert_rule
def test_insert_rule():
    class _module(object):
        def __init__(self):
            self.run_command_result = 0
            self.params = ['-I', '-t', 'mangle', '-A', 'INPUT', '-I', '3']
        def run_command(self,cmd, check_rc=True):
            self.params.extend(cmd)
            return self.run_command_result, "", ""
    module = _module()
    insert_rule("/usr/bin/iptables", module, {})
    assert module.params == ['-I', '-t', 'mangle', '-A', 'INPUT', '-I', '3', '-I', '-t', 'mangle', '-A', 'INPUT']

# Generated at 2022-06-11 07:22:30.722248
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 'module', 'params') == ['-P', 'params']



# Generated at 2022-06-11 07:22:38.518741
# Unit test for function main

# Generated at 2022-06-11 07:22:41.041241
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule({'chain': 'INPUT'})
    assert get_chain_policy(BINS['ipv4'], module, {'chain': 'INPUT'}) == 'ACCEPT'
    assert get_chain_policy(BINS['ipv6'], module, {'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-11 07:22:44.833440
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule(dict(
        protocol='tcp',
        jump=None,
        reject_with='tcp-reset',
        ip_version='ipv4'
    )) == ['--reject-with', 'tcp-reset']



# Generated at 2022-06-11 07:22:50.745117
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'OUTPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD', 'table': 'nat'}) == 'ACCEPT'



# Generated at 2022-06-11 07:23:00.688857
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/sbin/iptables'
    action = '-I'
    params = dict(
        chain="INPUT",
        destination='8.8.8.8/32',
        destination_port='80',
        jump='DROP',
        log_prefix='"IPTABLES"',
        log_level='info',
        in_interface='eth0',
    )
    rule = construct_rule(params)
    cmd = [iptables_path] + ['-t', None] + [action, params['chain']] + rule
    assert cmd == push_arguments(iptables_path, action, params)



# Generated at 2022-06-11 07:23:05.586902
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag(rule=[], param='match', flag='--match') == ['--match']
    assert append_match_flag(rule=[], param='negate', flag='--match', negatable=True) == ['!', '--match']


# Generated at 2022-06-11 07:23:10.459158
# Unit test for function push_arguments
def test_push_arguments():
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination': '127.0.0.1',
        'destination_ports': '80',
        'jump': 'ACCEPT',
        'comment': 'test_comment',
        'icmp_type': 'a',
        'ip_version': 'ipv4',
        'rule_num': None,
        'reject_with': None,
    }
    cmd = push_arguments('iptables', '-A', params)

# Generated at 2022-06-11 07:23:28.246659
# Unit test for function get_iptables_version
def test_get_iptables_version():
    class MockModule(object):
        def run_command(self, cmd, check_rc):
            class MockCompletedProcess(object):
                returncode = 0
                def __init__(self):
                    self.stderr = ""
            out = "iptables v1.6.2"
            return MockCompletedProcess.returncode, out, MockCompletedProcess.stderr
    module = MockModule()
    iptables_path = "iptables"
    result = get_iptables_version(iptables_path, module)
    assert result == "1.6.2"


# Generated at 2022-06-11 07:23:28.948327
# Unit test for function append_rule
def test_append_rule():
    assert append_rule() == "expected string"



# Generated at 2022-06-11 07:23:36.983418
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, None, '--ip-proto', True)
    assert rule == []
    append_match_flag(rule, None, '--ip-proto', False)
    assert rule == []
    append_match_flag(rule, 'match', '--ip-proto', False)
    assert rule == ['--ip-proto']
    append_match_flag(rule, 'negate', '--ip-proto', True)
    assert rule == ['--ip-proto', '!', '--ip-proto']



# Generated at 2022-06-11 07:23:40.003461
# Unit test for function set_chain_policy
def test_set_chain_policy():
    params = dict(table='filter', chain='INPUT', policy='DROP',
                  ip_version='ipv4')
    _ = set_chain_policy('iptables', None, params)
    assert 'iptables -t filter -P INPUT DROP'



# Generated at 2022-06-11 07:23:52.409139
# Unit test for function set_chain_policy
def test_set_chain_policy():
    import mock
    import os.path
    import subprocess
    from tempfile import NamedTemporaryFile

    class FakeAnsibleModule(object):
        def __init__(self, module_args, check_invalid_arguments=None, bypass_checks=False):
            self.module_args = module_args
            self.params = module_args

        def run_command(self, cmd, check_rc=True):
            if check_rc:
                return subprocess.call(cmd)
            else:
                p = subprocess.Popen(cmd)
                p.communicate()
                return p.returncode

    params = dict(
        chain='INPUT',
        policy='ACCEPT',
    )
    iptables_path = 'iptables'
    module = FakeAnsibleModule(params)

# Generated at 2022-06-11 07:24:00.668279
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
    chain='INPUT',
    protocol='tcp',
    destination_port='22',
    ctstate='NEW',
    syn='match',
    jump='ACCEPT',
    comment='Accept new SSH connections.'
    )
    result = construct_rule(params)
    expected = ["-p", "tcp", "-m", "conntrack", "--ctstate", "NEW", "--syn", "-j", "ACCEPT", "-m", "comment", "--comment", "Accept new SSH connections."]
    assert result == expected


# Generated at 2022-06-11 07:24:12.027313
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        source=None,
        jump=None
    )
    assert construct_rule(params) == []
    params = dict(
        source=None,
        jump='RETURN'
    )
    assert construct_rule(params) == ['-j', 'RETURN']
    params = dict(
        protocol=None,
        source='10.10.10.0/24',
        jump=None
    )
    assert construct_rule(params) == ['-s', '10.10.10.0/24']
    params = dict(
        protocol=None,
        source='!10.10.10.0/24',
        jump=None
    )
    assert construct_rule(params) == ['!', '-s', '10.10.10.0/24']

# Generated at 2022-06-11 07:24:22.260146
# Unit test for function set_chain_policy
def test_set_chain_policy():
    from ansible.modules.network.iptables import check_present
    from ansible.modules.network.iptables import check_present
    from ansible.modules.network.iptables import check_present
    from ansible.modules.network.iptables import check_present
    from ansible.modules.network.iptables import check_present
    from ansible.modules.network.iptables import check_present
    from ansible.modules.network.iptables import check_present
    from ansible.modules.network.iptables import check_present
    from ansible.modules.network.iptables import check_present
    from ansible.modules.network.iptables import check_present
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-11 07:24:26.456670
# Unit test for function construct_rule

# Generated at 2022-06-11 07:24:31.658295
# Unit test for function construct_rule

# Generated at 2022-06-11 07:24:55.992154
# Unit test for function append_rule
def test_append_rule():
    from ansible.modules.network.iptables import append_rule
    from subprocess import Popen, PIPE
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 07:25:00.774058
# Unit test for function get_chain_policy
def test_get_chain_policy():
    from ansible.module_utils.basic import AnsibleModule
    parameters = dict(
        table='filter',
        chain='INPUT',
        state='present',
        ip_version='ipv4'
    )
    iptables_path = BINS[parameters['ip_version']]
    module = AnsibleModule(argument_spec={})
    assert get_chain_policy(iptables_path, module, parameters) == 'ACCEPT'



# Generated at 2022-06-11 07:25:11.735623
# Unit test for function append_rule
def test_append_rule():
    from ansible.modules.network.iptables import check_present
    iptables_path = "/sbin/iptables"
    ip_version = "ipv4"
    action = "append"
    chain = "INPUT"
    table = "filter"
    protocol = "tcp"
    source = "8.8.8.8.8"
    jump = "DROP"
    state = "present"
    dest = "8.8.8.8"
    params = dict(
        ip_version=ip_version,
        action=action,
        chain=chain,
        table=table,
        protocol=protocol,
        source=source,
        jump=jump,
        state=state,
        destination=dest,
    )

    check_present(iptables_path, params)
    append_

# Generated at 2022-06-11 07:25:23.646648
# Unit test for function construct_rule
def test_construct_rule():
    # pylint: disable=too-many-locals,too-many-statements
    # TODO: break test down into smaller tests
    actual = [
        None,
        '-p',
        'tcp',
        '-s',
        '192.168.0.0/24',
        '-d',
        '--dports',
        '80,443,8081:8083',
        '-j',
        'ACCEPT',
        '-m',
        'multiport',
        '-m',
        'conntrack',
        '--ctstate',
        'NEW',
        '-m',
        'comment',
        '--comment',
        '"Accept new SSH connections."',
    ]

# Generated at 2022-06-11 07:25:28.461727
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    module.run_command = MagicMock(return_value=(0, "iptables v1.6.0", ''))
    assert get_iptables_version('/bin/iptables', module) == "1.6.0"



# Generated at 2022-06-11 07:25:33.371985
# Unit test for function main

# Generated at 2022-06-11 07:25:44.513758
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec={})
    chain = "INPUT"
    policy = "DROP"
    ip_version = "ipv4"
    params = {
        'chain': chain,
        'policy': policy,
        'ip_version': ip_version,
        'chain': "INPUT"
    }

    iptables_path = '/sbin/iptables'
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    #module.run_command(cmd, check_rc=True)
    assert cmd == ['/sbin/iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-11 07:25:52.612248
# Unit test for function construct_rule
def test_construct_rule():
    module = AnsibleModule({}, False)

# Generated at 2022-06-11 07:26:05.475240
# Unit test for function get_chain_policy
def test_get_chain_policy():
    import tempfile
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.pycompat24 import get_exception

    # Capture module arguments
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'ip_version': 'ipv4'
    }

    # Capture module results
    rc = None
    stdout = b''
    stderr = b''

    iptables_path = BINS[params['ip_version']]
    table_header = "Chain INPUT (policy ACCEPT)"

    # Create temp file
    tmpfd, tmpfname = tempfile.mkstemp()
    os.close(tmpfd)

    # Create a dummy file


# Generated at 2022-06-11 07:26:16.813556
# Unit test for function main

# Generated at 2022-06-11 07:26:51.607214
# Unit test for function get_chain_policy
def test_get_chain_policy():
    policy = get_chain_policy(None, None, dict(
        chain='INPUT',
        policy='DROP',
        table='filter',
        ip_version='ipv4',
    ))
    assert policy == 'DROP'
    policy = get_chain_policy(None, None, dict(
        chain='INPUT',
        policy='ACCEPT',
        table='filter',
        ip_version='ipv4',
    ))
    assert policy == 'ACCEPT'
    policy = get_chain_policy(None, None, dict(
        chain='INPUT',
        policy='ACCEPT',
        table='filter',
        ip_version='ipv6',
    ))
    assert policy == 'ACCEPT'



# Generated at 2022-06-11 07:26:56.649198
# Unit test for function get_chain_policy
def test_get_chain_policy():
    temp_module = AnsibleModule(
        argument_spec=dict(
            chain='INPUT',
            table='filter',
        ))
    chain_policy = get_chain_policy("iptables", temp_module, dict(
            chain='INPUT',
            table='filter',
        ))
    assert chain_policy == 'ACCEPT'


# Generated at 2022-06-11 07:26:59.484808
# Unit test for function check_present
def test_check_present():
    cmd = ['/sbin/iptables', '-t', '', '-C', '']
    cmd.extend(construct_rule(dict()))
    assert cmd


# Generated at 2022-06-11 07:27:07.818730
# Unit test for function construct_rule

# Generated at 2022-06-11 07:27:14.022160
# Unit test for function construct_rule
def test_construct_rule():
    params = {
        'protocol': 'tcp',
        'source': '8.8.8.8',
        'destination': '8.8.8.8',
        'jump': 'DROP',
        'set_counters': '10:20',
        'log_prefix': 'LOG_',
        'log_level': 'warning',
        'in_interface': 'eth0',
        'out_interface': 'eth1',
        'fragment': True,
        'source_port': '10:20',
        'destination_port': '10:20',
        'to_ports': '10:20',
        'syn': 'match',
        'comment': 'Test',
        'ctstate': ['new', 'established'],
    }

# Generated at 2022-06-11 07:27:18.337107
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(
        argument_spec=dict(
            table=dict(required=True),
            chain=dict(required=True),
        ),
    )
    iptables_path = 'iptables'
    params = dict(
        table='filter',
        chain='INPUT',
    )
    flush_table(iptables_path, module, params)
    flush_table(iptables_path, module, params)
    flush_table(iptables_path, module, params)



# Generated at 2022-06-11 07:27:22.128894
# Unit test for function flush_table
def test_flush_table():
    params = dict(
        chain='INPUT',
        table='filter',
        flush=True,
    )
    wait = '2'
    iptables_path = '/sbin/iptables'
    out = module.run_command(cmd, check_rc=True)

# Generated at 2022-06-11 07:27:29.801151
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(dict())
    iptables_path = module.get_bin_path("iptables", True)
    params = {
        'chain': 'INPUT',
        'table': 'filter'
    }
    cmd = push_arguments(iptables_path, '-C', params)
    rc, _, __ = module.run_command(cmd, check_rc=False)
    assert rc in [0, 1], 'iptables -C INPUT should exist in filter table'



# Generated at 2022-06-11 07:27:40.755875
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.1',
        destination='8.8.8.8',
        destination_port='80',
        jump=None,
        comment='A comment'
    )

    rule = construct_rule(params)
    assert rule == [
        '-p', 'tcp',
        '-s', '192.168.1.1',
        '-d', '8.8.8.8',
        '--dport', '80',
        '-m', 'comment',
        '--comment', 'A comment',
        '-j', 'REJECT'
    ]


# Generated at 2022-06-11 07:27:47.765333
# Unit test for function get_iptables_version
def test_get_iptables_version():
    class FakeModule:
        def run_command(self, cmd, check_rc=False):
            cmd_string = ' '.join(cmd)
            if cmd_string == 'iptables --version':
                out = 'iptables v1.4.20'
                return 0, out, ''
            else:
                out = 'ip6tables v1.4.20'
                return 0, out, ''
    params = {
        'chain': 'INPUT',
        'destination_port': '22',
        'jump': 'ACCEPT',
        'ip_version': 'ipv4'
    }
    module = FakeModule()
    iptables_path = 'iptables'
    iptables_version = get_iptables_version(iptables_path, module)

# Generated at 2022-06-11 07:29:32.459884
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/usr/bin/iptables'
    module = AnsibleModule({})
    params = {}
    params['table'] = 'filter'
    params['chain'] = 'INPUT'
    params['rule_num'] = 1
    params['protocol'] = 'tcp'
    params['destination_port'] = 80
    params['jump'] = 'ACCEPT'
    cmd = push_arguments(iptables_path, '-I', params)
    print(cmd)



# Generated at 2022-06-11 07:29:41.964051
# Unit test for function main

# Generated at 2022-06-11 07:29:44.882507
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments("", "", "") == []
    assert push_arguments("","","") == []
    assert push_arguments("", "", "") == []
    assert push_arguments("", "", "") == []



# Generated at 2022-06-11 07:29:48.820677
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', {}, {
        'chain': 'INPUT',
        }) == None
    assert get_chain_policy('iptables', {}, {
        'chain': 'INPUT',
        'policy': "ACCEPT",
        }) == "ACCEPT"



# Generated at 2022-06-11 07:29:52.858047
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = "/sbin/iptables"
    module = AnsibleModule({}, {})
    params = {
        'table': 'filter',
        'chain': 'INPUT',
    }
    assert get_chain_policy(iptables_path, module, params) == 'ACCEPT'



# Generated at 2022-06-11 07:30:00.951310
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(dict())
    module.run_command = lambda cmd, check_rc=True: (0, "Chain INPUT (policy ACCEPT)", "")

# Generated at 2022-06-11 07:30:03.509323
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = ansible_module('2')
    if module == '2':
        assert get_chain_policy("iptables", module, {'table': 'filter', 'chain': 'INPUT', 'ip_version': 'ipv4'}) == 'ACCEPT'


# Generated at 2022-06-11 07:30:06.893855
# Unit test for function get_chain_policy
def test_get_chain_policy():
    class TestModule:
        def __init__(self, policy, return_code, out):
            self.run_command = lambda cmd, check_rc: (return_code, out, "")
    module = TestModule(policy='DROP', return_code=0, out="Chain INPUT (policy DROP)\n")
    assert get_chain_policy("iptables", module, dict(chain="INPUT")) == "DROP"



# Generated at 2022-06-11 07:30:13.269955
# Unit test for function remove_rule
def test_remove_rule():
    params = dict(
        chain= 'INPUT',
        protocol='10.0/16',
        destination='10.0/16',
    )
    module = None
    iptables_path = '/sbin/iptables'
    cmd = push_arguments(iptables_path, '-D', params)
    assert cmd == [iptables_path, '-t', 'filter', '-D', 'INPUT', '-p', '10.0/16', '-d', '10.0/16']



# Generated at 2022-06-11 07:30:23.374033
# Unit test for function construct_rule