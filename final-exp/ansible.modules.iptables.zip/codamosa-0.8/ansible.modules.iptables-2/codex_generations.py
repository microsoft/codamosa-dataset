

# Generated at 2022-06-11 07:21:33.062270
# Unit test for function main

# Generated at 2022-06-11 07:21:35.033529
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = set_chain_policy('iptables', ['-w2', '-t', 'filter', '-P', 'INPUT', 'DROP'])
    assert cmd


# Generated at 2022-06-11 07:21:36.916573
# Unit test for function flush_table
def test_flush_table():
    flush_table('iptables_path', 'module', {'table': 'filter', 'chain': 'INPUT'})



# Generated at 2022-06-11 07:21:40.307880
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags = ['ACK', 'RST', 'SYN', 'FIN'],
        flags_set = ['ACK', 'RST', 'SYN']
    )
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN']


# Generated at 2022-06-11 07:21:43.095531
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert ['iptables', '-t', 'filter', '-P', 'INPUT', '--wait', '5', 'DROP'] == \
        push_arguments('iptables', '-P', {'chain': 'INPUT', 'policy': 'DROP', 'table': 'filter',
                                          'ip_version': 'ipv4', 'wait': '5'}, make_rule=False)



# Generated at 2022-06-11 07:21:48.851678
# Unit test for function construct_rule
def test_construct_rule():
    test_params = dict(
        chain='INPUT',
        ip_version='ipv4',
        source='8.8.8.8',
        dest='8.8.8.8',
    )
    result = construct_rule(test_params)
    assert result == [ '-s', '8.8.8.8', '-d', '8.8.8.8' ]
    test_params = dict(
        chain='FORWARD',
        ip_version='ipv4',
        source='8.8.8.8',
        dest='8.8.8.8',
        source_port='80',
        destination_port='8080',
    )
    result = construct_rule(test_params)

# Generated at 2022-06-11 07:21:58.811388
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/bin/iptables'
    module = AnsibleModule(
        argument_spec={
            'policy': {
                'required': True,
                'type': 'str',
                'choices': [
                    'ACCEPT',
                    'DROP',
                    'QUEUE',
                    'RETURN'
                ]
            },
        },
    )
    params = dict()
    params.update(dict(policy='DROP'))
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])

# Generated at 2022-06-11 07:22:10.588976
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        jump='DROP',
        destination_port=80,
        ctstate='ESTABLISHED',
        syn='match',
        wait=10,
        log_prefix='test:INFO:',
        log_level='info',
        reject_with='tcp-reset',
        icmp_type='echo-request'
    )

# Generated at 2022-06-11 07:22:15.265713
# Unit test for function append_match_flag
def test_append_match_flag():
    test_rule = []
    append_match_flag(test_rule, 'match', '--syn', True)
    if test_rule != ['--syn']:
        print("append_match_flag() test failed")
        #TODO
        #raise Exception("test_append_match_flag() failed")


# Generated at 2022-06-11 07:22:25.939879
# Unit test for function main

# Generated at 2022-06-11 07:22:37.272649
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule('iptables', 'module', 'params') == None


# Generated at 2022-06-11 07:22:47.259107
# Unit test for function construct_rule

# Generated at 2022-06-11 07:23:00.179152
# Unit test for function push_arguments

# Generated at 2022-06-11 07:23:02.004600
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 07:23:12.396995
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        destination='8.8.4.4',
        destination_port='53',
        jump='DROP',
        comment='DROPPING PACKETS MATCHING CRITERIA',
        ip_version='ipv4'
    )

    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '-s', '8.8.8.8', '-d', '8.8.4.4',
                    '--destination-port', '53', '-j', 'DROP',
                    '-m', 'comment', '--comment', 'DROPPING PACKETS MATCHING CRITERIA']



# Generated at 2022-06-11 07:23:19.883296
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = push_arguments('path', '-P', {
        'chain': 'INPUT',
        'table': 'filter',
        'policy': 'DROP',
        'ip_version': 'ipv4',
    }, make_rule=False)
    cmd.append('DROP')
    print(cmd)
    # ['path', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-11 07:23:21.889083
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', object(), dict(chain='INPUT', table='filter')) == 'DROP'



# Generated at 2022-06-11 07:23:30.649582
# Unit test for function main

# Generated at 2022-06-11 07:23:40.693963
# Unit test for function append_param
def test_append_param():
    # Test simple parameter
    rule = []
    append_param(rule, 'value', '--flag', False)
    assert rule == ['--flag', 'value']

    # Test inverted parameter
    rule = []
    append_param(rule, '!value', '--flag', False)
    assert rule == ['!', '--flag', 'value']

    # Test list parameter
    rule = []
    append_param(rule, ['value1', 'value2'], '--flag', True)
    assert rule == ['--flag', 'value1', '--flag', 'value2']

    # Test inverted list parameter
    rule = []
    append_param(rule, ['!value1', '!value2'], '--flag', True)

# Generated at 2022-06-11 07:23:52.516806
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    try:
        from ansible.modules.network.iptables import main
    except ImportError:
        raise SkipTest("could not import module")


# Generated at 2022-06-11 07:24:04.968026
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-11 07:24:06.291580
# Unit test for function get_iptables_version
def test_get_iptables_version():
    version = get_iptables_version('/bin/iptables',None)
    assert version == '1.6.1', version
# End unit test for function get_iptables_version



# Generated at 2022-06-11 07:24:11.313908
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", None, {"chain": "INPUT"}) == "ACCEPT"
    assert get_chain_policy("iptables", None, {"chain": "OUTPUT"}) == "ACCEPT"
    assert get_chain_policy("iptables", None, {"chain": "FORWARD"}) == "ACCEPT"



# Generated at 2022-06-11 07:24:13.018923
# Unit test for function insert_rule
def test_insert_rule():
    assert insert_rule("iptables",module,params) == 'iptables -t test_table -I test_chain -s test_source -d test_destination'



# Generated at 2022-06-11 07:24:17.085075
# Unit test for function get_chain_policy
def test_get_chain_policy():
    policy = get_chain_policy(None, None, {'chain': 'INPUT', 'table': 'filter'})
    assert policy == 'ACCEPT'
    policy = get_chain_policy(None, None, {'chain': 'FOO', 'table': 'filter'})
    assert policy is None



# Generated at 2022-06-11 07:24:28.787788
# Unit test for function main

# Generated at 2022-06-11 07:24:33.718025
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule()
    module.run_command = run_command_stub
    params = dict(ip_version='ipv4', table='filter', chain='INPUT', policy='ACCEPT')
    assert get_chain_policy('iptables', module, params) == 'ACCEPT'



# Generated at 2022-06-11 07:24:34.951218
# Unit test for function construct_rule
def test_construct_rule():
    # TODO
    pass



# Generated at 2022-06-11 07:24:37.686561
# Unit test for function insert_rule
def test_insert_rule():
    assert(insert_rule("iptables", None, {"table": "filter", "chain": "INPUT", "jump": "ACCEPT"}) == True)



# Generated at 2022-06-11 07:24:48.106395
# Unit test for function insert_rule

# Generated at 2022-06-11 07:25:01.943877
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({
        'ipv4_bin': '/sbin/iptables',
        'table': 'filter',
        'policy': 'DROP',
        'chain': 'INPUT'
    })
    return set_chain_policy('/sbin/iptables', module, module.params)



# Generated at 2022-06-11 07:25:07.899706
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': []}
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', '']
# Unit test
test_append_tcp_flags()


# Generated at 2022-06-11 07:25:13.025116
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = 'iptables'
    params = dict(
        table='filter',
        chain='INPUT',
        policy='DROP'
    )
    assert set_chain_policy(iptables_path, None, params) == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-11 07:25:24.810431
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']
    rule = []
    param = None
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == []
    rule = []
    param = {'flags': ['ACK', 'RST', 'SYN', 'FIN']}
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == []

# Generated at 2022-06-11 07:25:30.332120
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], None, '--syn', True) == []
    assert append_match_flag([], 'match', '--syn', True) == ['--syn']
    assert append_match_flag([], 'negate', '--syn', True) == ['!', '--syn']
    assert append_match_flag([], 'match', '--tcp-flags', True) == []


# Generated at 2022-06-11 07:25:36.437853
# Unit test for function get_iptables_version
def test_get_iptables_version():
    global BINS
    iptables_path = BINS['ipv4']

# Generated at 2022-06-11 07:25:41.233372
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', 'flag', False)
    assert rule == ['flag']
    rule = []
    append_match_flag(rule, 'negate', 'flag', True)
    assert rule == ['!', 'flag']


# Generated at 2022-06-11 07:25:43.299020
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', module) == '1.6.0'



# Generated at 2022-06-11 07:25:47.504186
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    assert get_iptables_version('iptables', module) == '1.8.2'
    assert(get_iptables_version('ip6tables', module) == '1.8.2')


# Generated at 2022-06-11 07:25:53.796838
# Unit test for function remove_rule
def test_remove_rule():
    # 1. Does not exist
    ip_version = 'ipv4'
    module = None
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '80',
        'ctstate': 'NEW',
        'syn': 'match',
        'jump': 'ACCEPT',
        'comment': 'Accept new SSH connections.',
        'ip_version': 'ipv4',
    }
    cmd = push_arguments(BINS[ip_version], '-D', params)
    rc, _, __ = module.run_command(cmd, check_rc=False)
    assert rc == 0
    
    

# Generated at 2022-06-11 07:26:17.298598
# Unit test for function construct_rule

# Generated at 2022-06-11 07:26:23.821341
# Unit test for function set_chain_policy
def test_set_chain_policy():
    xtables_lock_present = False
    cmd = ['iptables']
    cmd.extend(['-t', 'filter'])
    cmd.extend(['-P', 'INPUT'])
    cmd.append('DROP')
    cmd.extend(['-w', '2'])
    assert (cmd == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP', '-w', '2'])
    if xtables_lock_present:
        cmd = ['iptables']
        cmd.extend(['-t', 'filter'])
        cmd.extend(['-P', 'INPUT'])
        cmd.append('DROP')
        cmd.extend(['-w', '2'])

# Generated at 2022-06-11 07:26:31.150625
# Unit test for function get_chain_policy
def test_get_chain_policy():
    from ansible.module_utils import basic

    # Test 1
    m = basic.AnsibleModule(
        argument_spec=dict(
            table='filter',
            chain='INPUT',
            ip_version='ipv4',
            policy=None
        )
    )
    params = m.params

    results = get_chain_policy(params['ip_version'], m, params)
    assert results == 'ACCEPT'

    # Test 2
    m = basic.AnsibleModule(
        argument_spec=dict(
            table='filter',
            chain='FORWARD',
            ip_version='ipv4',
            policy=None
        )
    )
    params = m.params

    results = get_chain_policy(params['ip_version'], m, params)

# Generated at 2022-06-11 07:26:41.624029
# Unit test for function get_chain_policy
def test_get_chain_policy():
    path = '/sbin/iptables'
    action = '-L'
    chain = 'INPUT'
    table = 'filter'
    policy = 'DROP'
    out = 'Chain INPUT (policy DROP)\n'
    assert get_chain_policy(path, action, chain, table, out) == policy
    chain = 'OUTPUT'
    policy = 'DROP'
    out = 'Chain OUTPUT (policy DROP)\n'
    assert get_chain_policy(path, action, chain, table, out) == policy
    chain = 'FORWARD'
    policy = 'DROP'
    out = 'Chain FORWARD (policy DROP)\n'
    assert get_chain_policy(path, action, chain, table, out) == policy
    chain = 'INPUT'
    policy = 'ACCEPT'


# Generated at 2022-06-11 07:26:52.757503
# Unit test for function main

# Generated at 2022-06-11 07:26:55.926959
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(iptables_path='pwd', module='pwd', params={'table': 'nat', 'chain': 'INPUT', 'policy': 'DROP'}) is None


# Generated at 2022-06-11 07:26:58.587172
# Unit test for function get_chain_policy
def test_get_chain_policy():
    policy = get_chain_policy('iptables', 'module', dict(
            table='filter',
            chain='OUTPUT'
    ))
    assert policy == 'ACCEPT'


# Generated at 2022-06-11 07:27:03.751055
# Unit test for function main
def test_main():
    test_data_dir='/root/ansible/lib/ansible/modules/network/firewall'
    test_data_file=os.path.join(test_data_dir,'test-data.yml')
    test_data = open(test_data_file).read()
    test_data = yaml.load(test_data)
    result = main()

main()

# Generated at 2022-06-11 07:27:05.805602
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test = 'Chain INPUT (policy DROP)'
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'DROP'



# Generated at 2022-06-11 07:27:12.236265
# Unit test for function push_arguments

# Generated at 2022-06-11 07:27:38.249417
# Unit test for function append_rule
def test_append_rule():
    #test_append_rule.test_append_rule = append_rule
    import os
    import sys
    import imp
    import ansible
    from ansible.module_utils.basic import AnsibleModule

    os.environ['ANSIBLE_MODULE_UTILS'] = '../module_utils/'

    ansible_path = imp.find_module('ansible')[1]
    if ansible_path not in sys.path:
        sys.path.append(ansible_path)

    import ansible.module_utils.facts.system.iptables
    iptables_path = imp.find_module('iptables')[1]
    if iptables_path not in sys.path:
        sys.path.append(iptables_path)


# Generated at 2022-06-11 07:27:46.286497
# Unit test for function main

# Generated at 2022-06-11 07:27:50.649164
# Unit test for function remove_rule
def test_remove_rule():
    assert push_arguments('iptables', '-D', {'ip_version': 'ipv4', 'table': 'filter', 'chain': 'INPUT', 'jump': 'DROP', 'protocol': 'tcp', 'destination_port': '8080', 'ctstate': ['NEW'], 'comment': 'This is a test', 'match': ['conntrack']}) == ['iptables', '-t', 'filter', '-D', 'INPUT', '-p', 'tcp', '--dport', '8080', '-m', 'conntrack', '--ctstate', 'NEW', '-m', 'comment', '--comment', 'This is a test', '-j', 'DROP']



# Generated at 2022-06-11 07:27:52.503799
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("/sbin/iptables", "/sbin/iptables", "INPUT") == "ACCEPT"



# Generated at 2022-06-11 07:27:59.722677
# Unit test for function check_present
def test_check_present():
    module =  AnsibleModule(argument_spec={})
    params = {
        'protocol': 'tcp',
        'source': '1.1.1.1',
        'destination_port': '22',
        'jump': 'ACCEPT',
        'chain' : 'INPUT',
        'rule_num' : '2',
        'table' : 'filter'
    }
    assert check_present('iptables', module, params) == True
    params = {
        'protocol': None,
        'source': '1.1.1.1',
        'destination_port': '22',
        'jump': 'ACCEPT',
        'chain' : 'INPUT',
        'table' : 'filter'
    }
    assert check_present('iptables', module, params) == False
    params

# Generated at 2022-06-11 07:28:10.916209
# Unit test for function insert_rule

# Generated at 2022-06-11 07:28:12.471882
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-11 07:28:23.318523
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = '/sbin/iptables'
    #Test case 1
    params = dict(
        wait='10',
        table='mangle',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        rule_num='5',
        src_range='192.168.1.100-192.168.1.199',
        dst_range='10.0.0.1-10.0.0.50',
        to_ports='8080',
        source='192.168.1.1',
        match='tcp',
        reject_with='tcp-reset',
        ip_version='ipv4',
        action='insert'
    )
    cmd = push_arguments(iptables_path, '-I', params)

# Generated at 2022-06-11 07:28:32.506990
# Unit test for function remove_rule

# Generated at 2022-06-11 07:28:43.056342
# Unit test for function construct_rule

# Generated at 2022-06-11 07:29:13.468676
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables","","") is None
    assert get_chain_policy("iptables","","nat") is None
    assert get_chain_policy("iptables","","test_chain") is None
    assert get_chain_policy("iptables","","inet") is None



# Generated at 2022-06-11 07:29:22.625859
# Unit test for function main

# Generated at 2022-06-11 07:29:32.458083
# Unit test for function remove_rule
def test_remove_rule():
    """
    def remove_rule(iptables_path, module, params):
        cmd = push_arguments(iptables_path, '-D', params)
        module.run_command(cmd, check_rc=True)
    """
    import mock
    iptables_path='/sbin/iptables'
    module=mock.Mock()

# Generated at 2022-06-11 07:29:41.928233
# Unit test for function append_rule
def test_append_rule():
    global IPTABLES_WAIT_SUPPORT_ADDED
    if LooseVersion(IPTABLES_WAIT_SUPPORT_ADDED) < LooseVersion("1.4.20"):
        IPTABLES_WAIT_SUPPORT_ADDED = "1.4.20"

# Generated at 2022-06-11 07:29:51.162422
# Unit test for function construct_rule

# Generated at 2022-06-11 07:29:53.603863
# Unit test for function insert_rule
def test_insert_rule():
    from ansible.modules.network.iptables import insert_rule
    assert insert_rule(None, None, {'rule_num': 5}) == True



# Generated at 2022-06-11 07:30:02.259905
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='80',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.'
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '-m', 'conntrack', '--ctstate',
                    'NEW', '--syn', '--dport', '80', '-j', 'ACCEPT',
                    '-m', 'comment', '--comment', 'Accept new SSH connections.']

# Generated at 2022-06-11 07:30:06.790124
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', {}, {'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', {}, {'chain': 'OUTPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy('iptables', {}, {'chain': 'FORWARD', 'table': 'filter'}) == 'DROP'
    assert get_chain_policy('iptables', {}, {'chain': 'TEST', 'table': 'filter'}) == 'ACCEPT'



# Generated at 2022-06-11 07:30:11.616684
# Unit test for function append_rule
def test_append_rule():
    ipv4_path = '/sbin/iptables'
    ipv6_path = '/sbin/ip6tables'
    params = dict(
        protocol="tcp",
        source="10.10.10.0/24",
        destination_port=[ "22", "80" ],
        jump="ACCEPT",
        table="filter",
        chain="INPUT"
    )

    

# Generated at 2022-06-11 07:30:20.559755
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = "/usr/sbin/iptables"
    #module = AnsibleModule(argument_spec=dict())
    iptables_bin_path = module.get_bin_path(BINS[params['ip_version']], True)
    action = '-D'
    params = dict()
    params['ip_version'] = "ipv4"
    params['ip_version'] = "ipv4"
    params['table'] = dict(default='filter')
    params['state'] = dict(default='present')
    params['chain'] = dict(default='INPUT')
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)

