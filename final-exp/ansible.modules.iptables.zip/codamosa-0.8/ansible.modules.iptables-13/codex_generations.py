

# Generated at 2022-06-11 07:21:33.056177
# Unit test for function construct_rule
def test_construct_rule():
    # Test empty call
    assert construct_rule(dict()) == []

    # Test each possible keyword argument

# Generated at 2022-06-11 07:21:37.292027
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(argument_spec={})
    iptables_path = "iptables"
    params = dict(
        ip_version="ipv4",
        table="filter",
        chain="INPUT",
    )
    assert get_chain_policy(iptables_path, module, params) == "ACCEPT"



# Generated at 2022-06-11 07:21:42.047593
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec={
        'table': {'choices': ['filter', 'nat', 'mangle', 'raw'], 'default': 'filter'},
        'chain': {'required': True},
        'ip_version': {'choices': ['ipv4', 'ipv6'], 'default': 'ipv4'},
        'policy': {'required': True, 'choices': ['ACCEPT', 'DROP', 'QUEUE', 'RETURN']},
        'wait': {'default': None},
    })

    set_chain_policy(BINS[module.params['ip_version']], module, module.params)



# Generated at 2022-06-11 07:21:48.470076
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    a = ['--tcp-flags']
    p = {'flags': ['ACK', 'SYN', 'FIN'], 'flags_set': ['ACK', 'FIN']}
    append_tcp_flags(a, p, '--tcp-flags')
    assert a == ['--tcp-flags', 'ACK,SYN,FIN', 'ACK,FIN']

# Generated at 2022-06-11 07:21:51.273745
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', 'foobar', True)
    assert rule == ['foobar']
    rule = []
    append_match_flag(rule, 'negate', 'foobar', True)
    assert rule == ['!', 'foobar']
    rule = []
    append_match_flag(rule, 'match', 'foobar', False)
    assert rule == ['foobar']
    rule = []
    append_match_flag(rule, 'negate', 'foobar', False)
    return


# Generated at 2022-06-11 07:21:55.181042
# Unit test for function get_iptables_version
def test_get_iptables_version():
    version = get_iptables_version('/sbin/iptables', AnsibleModule(
                                   argument_spec={}))
    assert version.split('.')[0] == '1'



# Generated at 2022-06-11 07:21:59.549808
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", None, {"chain":"INPUT"}) == "ACCEPT"
    assert get_chain_policy("ip6tables", None, {"chain":"INPUT"}) == "ACCEPT"
    assert get_chain_policy("iptables", None, {"chain":"FORWARD"}) == "ACCEPT"
    assert get_chain_policy("iptables", None, {"chain":"OUTPUT"}) == "ACCEPT"



# Generated at 2022-06-11 07:22:02.804798
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    param = {
        'flags': 'ALL',
        'flags_set': ["ACK", "RST", "SYN", "FIN"],
    }
    rule = []
    append_tcp_flags(rule, param, '')
    assert rule == ['', 'ALL', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-11 07:22:12.819473
# Unit test for function check_present

# Generated at 2022-06-11 07:22:21.658350
# Unit test for function check_present
def test_check_present():
    argv = ['ansible-test', 'iptables', '-T', 'filter', '-C', 'INPUT', '-s', '1.1.1.1', '-p', 'tcp', '-m', 'multiport', '--dports', '80,443', '-m', 'comment', '--comment', 'Accept new SSH connections.', '-j', 'ACCEPT']
    params = dict(
        chain='INPUT',
        source='1.1.1.1',
        protocol='tcp',
        destination_ports=['80', '443'],
        jump='ACCEPT',
        table='filter',
        comment='Accept new SSH connections.',
        ip_version='ipv4'
    )
    assert push_arguments('iptables', '-C', params) == argv


# Generated at 2022-06-11 07:22:46.005947
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'test_chain', 'table': 'raw'}) == 'ACCEPT'


# Generated at 2022-06-11 07:22:46.911578
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', module) == '1.6.1'  # noqa



# Generated at 2022-06-11 07:22:52.715746
# Unit test for function remove_rule

# Generated at 2022-06-11 07:22:56.994811
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', AnsibleModule(dict()), dict(table='nat', chain='INPUT', protocol='tcp', destination_port='22', ctstate='NEW', syn='match', jump='ACCEPT')) == True


# Generated at 2022-06-11 07:23:05.166148
# Unit test for function construct_rule

# Generated at 2022-06-11 07:23:17.444969
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='1.1.1.1',
        destination='2.2.2.2',
        match=['tcp'],
        jump='ACCEPT',
        syn=None,
        log_prefix='test',
        log_level='info',
    )

    expected = [
        '-p', 'tcp',
        '-s', '1.1.1.1',
        '-d', '2.2.2.2',
        '-m', 'tcp',
        '-j', 'ACCEPT',
        '--log-prefix', 'test',
        '--log-level', 'info',
    ]
    result = construct_rule(params)
    assert result == expected



# Generated at 2022-06-11 07:23:19.521197
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy('iptables', 1, 1, 'DROP') == ['-P', 'INPUT']



# Generated at 2022-06-11 07:23:28.913706
# Unit test for function push_arguments

# Generated at 2022-06-11 07:23:39.237010
# Unit test for function set_chain_policy

# Generated at 2022-06-11 07:23:51.609545
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('/sbin/iptables', '-D', dict(
        chain='INPUT',
        table='mangle',
        icmp_type='echo-request',
        ip_version='ipv4',
    )) == [
        '/sbin/iptables',
        '-t', 'mangle',
        '-D', 'INPUT',
        '--icmp-type', 'echo-request'
    ]
    assert push_arguments('/sbin/iptables', '-A', dict(
        chain='INPUT',
        table='filter',
        in_interface='eth0',
    )) == [
        '/sbin/iptables',
        '-t', 'filter',
        '-A', 'INPUT',
        '-i', 'eth0'
    ]
    assert push

# Generated at 2022-06-11 07:24:10.034706
# Unit test for function remove_rule
def test_remove_rule():
    remove_rule(None, None, None)



# Generated at 2022-06-11 07:24:17.752362
# Unit test for function main
def test_main():
    iptables_path = '/sbin/iptables'
    action = "insert"

# Generated at 2022-06-11 07:24:29.407296
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(chain='INPUT', destination='1.1.1.1', jump='ACCEPT', comment='Test')
    rule = construct_rule(params)
    assert rule == ['-j', 'ACCEPT', '-m', 'comment', '--comment', 'Test']
    params = dict(chain='INPUT', destination='1.1.1.1',
                  comment='Test', reject_with='icmp-port-unreachable')
    rule = construct_rule(params)
    assert rule == ['-j', 'REJECT', '-m', 'comment', '--comment', 'Test', '--reject-with', 'icmp-port-unreachable']

# Generated at 2022-06-11 07:24:40.590591
# Unit test for function main

# Generated at 2022-06-11 07:24:45.446960
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test_params = {'table': 'filter', 'chain': 'INPUT'}
    iptables_path = 'iptables'
    gcp_result = get_chain_policy(iptables_path, None, test_params)
    assert gcp_result == 'ACCEPT'

# Generated at 2022-06-11 07:24:51.028518
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = "/usr/sbin/iptables"
    module = None
    params = {'policy': "ACCEPT", 'chain': "INPUT"}
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    print(cmd)


# Generated at 2022-06-11 07:25:00.896064
# Unit test for function check_present
def test_check_present():
    # Test -C
    iptables_path = 'iptables'
    module = AnsibleModule(argument_spec={})
    # Valid
    params = {
        'table': 'filter',
        'chain': 'chain_name',
        'ip_version': 'ipv4'
    }
    cmd = push_arguments(iptables_path, '-C', params)
    assert(cmd == [iptables_path, '-t', 'filter', '-C', 'chain_name'])
    # Test when chain does not exist.
    params = {
        'table': 'filter',
        'chain': 'does_not_exist',
        'ip_version': 'ipv4'
    }
    cmd = push_arguments(iptables_path, '-C', params)

# Generated at 2022-06-11 07:25:11.832883
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule(dict(jump='ACCEPT', state='present')) == ['-A', 'ACCEPT']
    assert construct_rule(dict(jump=None, state='present')) == ['-A']
    assert construct_rule(dict(jump=None, state='present', reject_with=None)) == ['-A']
    assert construct_rule(dict(jump=None, state='present', reject_with='icmp-net-unreachable')) == ['-A', '-j', 'REJECT', '--reject-with', 'icmp-net-unreachable']

# Generated at 2022-06-11 07:25:23.754596
# Unit test for function construct_rule

# Generated at 2022-06-11 07:25:30.108873
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('iptables', '-D', dict(table='filter', chain='INPUT', protocol='tcp', destination_ports='8080', jump='ACCEPT', comment='Testing')) == [
        'iptables', '-t', 'filter', '-D', 'INPUT', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT', '-m', 'comment', '--comment', 'Testing']



# Generated at 2022-06-11 07:26:19.158074
# Unit test for function main

# Generated at 2022-06-11 07:26:23.004610
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule({})
    assert(check_present('iptables', module, dict(chain='INPUT',
                                                  protocol='tcp',
                                                  table='filter',
                                                  source='1.1.1.1',
                                                  jump='ACCEPT')))


# Generated at 2022-06-11 07:26:29.168771
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(
        argument_spec=dict(
            source=dict(),
            table=dict(default='filter'),
            ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
            chain=dict(),
            jump=dict(choices=['ACCEPT', 'DROP', 'REJECT']),
        )
    )
    params = module.params
    iptables_path = BINS[params['ip_version']]
    assert check_present(iptables_path, module, params) == False
# End of unit test



# Generated at 2022-06-11 07:26:39.273744
# Unit test for function construct_rule

# Generated at 2022-06-11 07:26:39.893619
# Unit test for function append_rule
def test_append_rule():
    pass


# Generated at 2022-06-11 07:26:44.399269
# Unit test for function remove_rule
def test_remove_rule():
    cmd = ['iptables', '-t', 'filter', '-D', 'INPUT',
    '-p', 'tcp',
    '-m', 'multiport',
    '--dports', '25,143,110',
    '-j', 'DROP']
    print(cmd)


# Generated at 2022-06-11 07:26:55.542827
# Unit test for function remove_rule

# Generated at 2022-06-11 07:27:05.170843
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    class AnsibleExitJson(Exception):
        def __init__(self, module, result=None, **kwargs):
            self.kwargs = kwargs
            self.result = result
            self.module = module

    class AnsibleFailJson(Exception):
        def __init__(self, module, msg, **kwargs):
            self.msg = msg
            self.kwargs = kwargs
            self.module = module

    def exit_json(module, **kwargs):
        sys.exit(AnsibleExitJson(module, **kwargs))

    def fail_json(module, **kwargs):
        sys.exit(AnsibleFailJson(module, **kwargs))


# Generated at 2022-06-11 07:27:07.183824
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test_out = 'Chain INPUT (policy DROP)'
    assert(get_chain_policy('iptables', None, dict()) == 'DROP')
# End



# Generated at 2022-06-11 07:27:08.171238
# Unit test for function check_present
def test_check_present():
    assert not check_present("", "", "")



# Generated at 2022-06-11 07:28:08.835386
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/sbin/iptables'
    action = '-A'
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num='5',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT'
    )
    cmd = ['/sbin/iptables', '-t', 'filter', '-A', 'INPUT',
           '5', '-p', 'tcp', '--dport', '8080', '-j', 'ACCEPT']
    assert push_arguments(iptables_path, action, params) == cmd



# Generated at 2022-06-11 07:28:10.356665
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(iptables_path, module, params) == None



# Generated at 2022-06-11 07:28:21.585107
# Unit test for function construct_rule
def test_construct_rule():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 07:28:23.923110
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = 'iptables'
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    params = dict(table='filter', chain='INPUT', action='present', protocol='tcp', destination_port='8080', jump=None, ip_version='ipv4')
    assert remove_rule(iptables_path, module, params) == None


# Generated at 2022-06-11 07:28:25.077191
# Unit test for function check_present
def test_check_present():
    module = None
    assert check_present("iptables", module, params)



# Generated at 2022-06-11 07:28:32.924297
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(
        argument_spec=dict(
            table=dict(type='str', default='filter'),
            chain=dict(type='str', default='INPUT'),
            policy=dict(type='str', default='DROP'),
            ip_version=dict(type='str', default='ipv4'),
            wait=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    params = dict(
        table='filter',
        chain='INPUT',
        policy='DROP',
        ip_version='ipv4',
        wait=None,
    )
    set_chain_policy('iptables', module, params)


# Generated at 2022-06-11 07:28:36.192636
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert 'ACCEPT' == get_chain_policy("/sbin/iptables", "INPUT")
    assert get_chain_policy("/sbin/iptables", "INPUT_NEVER_EXISTS") == None
    assert get_chain_policy("/sbin/iptables", "OUTPUT") == None



# Generated at 2022-06-11 07:28:41.823718
# Unit test for function remove_rule

# Generated at 2022-06-11 07:28:44.686776
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('iptables', module, params) == "iptables -t nat -A chain -p icmp -s 10.10.10.1/24 -j ACCEPT"



# Generated at 2022-06-11 07:28:54.156172
# Unit test for function construct_rule

# Generated at 2022-06-11 07:29:56.269129
# Unit test for function check_present
def test_check_present():
    args = dict(
        # action=present
        chain='INPUT',
        table='filter',
        protocol='tcp',
        jump='DROP',
    )
    assert check_present(iptables_path='/sbin/iptables', module=AnsibleModule(argument_spec=dict()), params=args)



# Generated at 2022-06-11 07:29:57.410304
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', module, params) == True


# Generated at 2022-06-11 07:30:02.958146
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/usr/bin/iptables'
    ansible_module = AnsibleModule(argument_spec=dict(chain='INPUT', policy='DROP'))
    params = dict(chain='INPUT', policy='DROP')
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    print(cmd)

test_set_chain_policy()



# Generated at 2022-06-11 07:30:11.662664
# Unit test for function push_arguments
def test_push_arguments():
    # Check input table
    params = dict(
        chain='INPUT',
        table='foo',
    )
    cmd = push_arguments(BINS['ipv4'], '-A', params)
    assert cmd == ['iptables', '-t', 'foo', '-A', 'INPUT']

    # Check chain
    params = dict(
        chain='OUTPUT',
    )
    cmd = push_arguments(BINS['ipv4'], '-A', params)
    assert cmd == ['iptables', '-t', 'filter', '-A', 'OUTPUT']

    # Check rule_num
    params = dict(
        rule_num='3',
    )
    cmd = push_arguments(BINS['ipv4'], '-I', params)

# Generated at 2022-06-11 07:30:21.601202
# Unit test for function push_arguments
def test_push_arguments():
    # INPUT
    assert push_arguments('iptables', '-A', {
        'table': 'filter',
        'chain': 'INPUT',
        'source': '1.1.1.1'
    }) == ['iptables', '-t', 'filter', '-A', 'INPUT', '-s', '1.1.1.1']

# Generated at 2022-06-11 07:30:25.776966
# Unit test for function append_rule
def test_append_rule():
    module.run_command = MagicMock()
    command = push_arguments(iptables_path, '-A', params)
    append_rule(iptables_path, module, params)
    module.run_command.assert_called_once_with(cmd, check_rc=True)



# Generated at 2022-06-11 07:30:31.842574
# Unit test for function main

# Generated at 2022-06-11 07:30:34.362336
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = '/sbin/iptables'
    module = 'test_module'
    params = {}
    params['chain'] = 'INPUT'
    params['policy'] = 'ACCEPT'

    set_chain_policy(iptables_path, module, params)
    assert get_chain_policy(iptables_path, module, params) == 'ACCEPT'



# Generated at 2022-06-11 07:30:42.774737
# Unit test for function construct_rule

# Generated at 2022-06-11 07:30:44.253595
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('dummy', 'dummy', {'chain': 'DUMMY', 'policy': None, 'table': 'filter'}) == 'ACCEPT'

