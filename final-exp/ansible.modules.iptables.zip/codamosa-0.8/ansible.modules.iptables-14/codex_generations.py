

# Generated at 2022-06-11 07:21:30.910028
# Unit test for function construct_rule
def test_construct_rule():
    # this will be called during import
    # with __name__ set to 'ansible.builtin.iptables'
    if __name__ == 'ansible.builtin.iptables':
        import json
        import pytest
        import yaml
        with open('/tmp/test_construct_rule.yml') as f:
            args = yaml.load(f)
        for test in args:
            rule = construct_rule(test['params'])
            test['expected_rule'].sort()
            rule.sort()
            assert rule == test['expected_rule'], \
                'rule generated from %s is incorrect' % json.dumps(test['params'])


# Generated at 2022-06-11 07:21:35.938578
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    module = AnsibleModule(argument_spec=dict())
    try:
        get_iptables_version('iptables', module)
    except Exception:
        err = get_exception()
        assert (str(err) == 'Version check for iptables failed.')



# Generated at 2022-06-11 07:21:39.989582
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('/sbin/iptables',  m,  pwd) == 'DROP'


# Generated at 2022-06-11 07:21:44.567069
# Unit test for function get_chain_policy
def test_get_chain_policy():
    test_input = "Chain INPUT (policy DROP)\n"
    assert get_chain_policy(None, None, None, test_input) == "DROP"
    test_input = "Chain INPUT\n"
    assert get_chain_policy(None, None, None, test_input) == None



# Generated at 2022-06-11 07:21:50.431787
# Unit test for function push_arguments
def test_push_arguments():
    print('test_push_arguments')

# Generated at 2022-06-11 07:21:55.612909
# Unit test for function main
def test_main():
    args = dict(
        table='filter',
        state='present',
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        source='192.168.1.1',
        destination='10.10.1.1',
        jump='DROP',
        reject_with='icmp-host-prohibited',
        flush=True
    )


# Generated at 2022-06-11 07:22:07.172031
# Unit test for function push_arguments
def test_push_arguments():
    """
    Test function push_arguments
    """
    assert push_arguments('iptables', '-A', dict(
        table='filter', chain='INPUT', jump='ACCEPT',
        destination_port='8080', protocol='tcp'
        )) == ['iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-m', 'multiport', '--dports', '8080', '-j', 'ACCEPT']

# Generated at 2022-06-11 07:22:13.519145
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', None, \
        {'table': 'filter', 'chain': 'INPUT', \
        'protocol': 'tcp', 'destination_port': '80', 'ctstate': 'NEW', \
        'syn': 'match', 'jump': 'ACCEPT', \
        'comment': 'Accept new SSH connections.', 'ip_version': 'ipv4'}) == False



# Generated at 2022-06-11 07:22:15.209890
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(table='filter', chain='INPUT')) == 'ACCEPT'


# Generated at 2022-06-11 07:22:25.840308
# Unit test for function push_arguments

# Generated at 2022-06-11 07:22:54.748223
# Unit test for function construct_rule
def test_construct_rule():
    rules = []
    # Simple rule
    params = dict(
        chain='INPUT',
        protocol=None,
        source=None,
        destination=None,
        src_range=None,
        dst_range=None,
        destination_port=None,
        source_port=None,
        in_interface=None,
        out_interface=None,
        match=None,
        syn=None,
        tcp_flags=None,
        ctstate=None,
        jump=None,
        goto=None,
        limit=None,
        limit_burst=None,
        uid_owner=None,
        gid_owner=None,
        reject_with=None,
        icmp_type=None,
        comment=None,
    )
    rules.append(construct_rule(params))


# Generated at 2022-06-11 07:22:59.266153
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    result =  ["--tcp-flags", "ACK,FIN,PSH,RST,SYN,URG", "ACK,SYN,FIN"]
    param = {'flags': ['ACK', 'FIN', 'PSH', 'RST', 'SYN', 'URG'],
             'flags_set': ['ACK', 'SYN', 'FIN']}
    append_tcp_flags(rule=[], param=param, flag='--tcp-flags')
    assert result == rule



# Generated at 2022-06-11 07:23:06.445724
# Unit test for function insert_rule
def test_insert_rule():
    module_mock = MagicMock('module_mock')
    module_mock.run_command = MagicMock(return_value = (0, 'command executed', ''))
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num='5',
    )
    expected = ['iptables','-t','filter','-I','INPUT','5','-p','tcp','--dport','8080','-j','ACCEPT']
    
    result = insert_rule('iptables', module_mock, params)
    module_mock.run_command.assert_called_once_with(expected, check_rc=True)
# Testing
test_insert_rule()

# Generated at 2022-06-11 07:23:18.887737
# Unit test for function construct_rule

# Generated at 2022-06-11 07:23:25.201999
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(
        flags = ['ACK', 'RST', 'SYN', 'FIN'],
        flags_set = ['ACK', 'SYN'],
    )
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags','ACK,RST,SYN,FIN','ACK,SYN']
    param = dict(
        flags = ['ACK', 'RST'],
        flags_set = ['ACK'],
    )
    rule = []
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags','ACK,RST','ACK']


# Generated at 2022-06-11 07:23:29.044866
# Unit test for function construct_rule
def test_construct_rule():
  rule = construct_rule({
        'action': 'insert',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '8080'
    })
  assert rule == ['-I', 'INPUT', '-p', 'tcp', '--dport', '8080']



# Generated at 2022-06-11 07:23:37.037888
# Unit test for function construct_rule

# Generated at 2022-06-11 07:23:40.144366
# Unit test for function append_match_flag
def test_append_match_flag():
    module = AnsibleModule({})
    rule = []

    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']

    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['--syn', '!', '--syn']

    append_match_flag(rule, 'negate', '--syn', False)
    assert rule == ['--syn', '!', '--syn']



# Generated at 2022-06-11 07:23:52.463356
# Unit test for function construct_rule

# Generated at 2022-06-11 07:24:03.869424
# Unit test for function construct_rule
def test_construct_rule():
    """Unit test for function construct_rule
    """
    # Test full rule
    test_params = dict(
        source='10.0.0.1',
        destination='10.0.0.2',
        protocol='tcp',
        destination_port='80',
        match='tcp',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Test rule',
        ip_version='ipv4',
    )
    rule = construct_rule(test_params)

# Generated at 2022-06-11 07:24:25.645642
# Unit test for function main
def test_main():
    test_module_args={}
    test_module_args.update({'state':'absent','ip_version':'ipv4','rule_num':'0','table':'filter','protocol':'tcp','jump':'ACCEPT','comment':'test'})
    test_module_args.update({'destination':''})
    test_module_args.update({'reject_with':''})
    test_module_args.update({'dst_range':''})
    test_module_args.update({'destination_port':''})
    test_module_args.update({'action':'append','flush':'False','policy':'False'})
    test_module_args.update({'src_range':''})
    test_module_args.update({'destination_ports':''})
   

# Generated at 2022-06-11 07:24:28.199374
# Unit test for function flush_table
def test_flush_table():
    assert(flush_table('/usr/bin/iptables',{},{'table':'raw'}) == True)


# Generated at 2022-06-11 07:24:37.255586
# Unit test for function push_arguments
def test_push_arguments():
    params = {
        'action' : '-A',
        'chain' : 'INPUT',
        'table': 'filter',
        'protocol': 'tcp',
        'jump': 'ACCEPT',
        'syn': 'match',
        'ip_version': 'ipv4',
    }
    cmd = push_arguments('iptables', '-A', params)
    assert cmd == [ 'iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp',
                    '--syn', '-j', 'ACCEPT' ]
    return True

# Generated at 2022-06-11 07:24:39.608726
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    expected_output=['--tcp-flags', 'ACK,FIN,RST,SYN', '']
    rule=[]
    param = dict(
        flags=['ACK', 'FIN', 'RST', 'SYN'],
        flags_set=['']
    )
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == expected_output


# Generated at 2022-06-11 07:24:45.898157
# Unit test for function construct_rule

# Generated at 2022-06-11 07:24:49.195889
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    expected_result = ['--syn']
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == expected_result
    rule = []
    expected_result = ['!', '--syn']
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == expected_result
    rule = []
    expected_result = []
    append_match_flag(rule, 'ignore', '--syn', True)
    assert rule == expected_result



# Generated at 2022-06-11 07:24:56.376464
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = BINS['ipv4']
    action = '-I'
    params = {'table': 'filter', 'chain': 'INPUT', 'state': 'present', 'ip_version': 'ipv4'}
    assert push_arguments(iptables_path, action, params) == [
        'iptables', '-t', 'filter', '-I', 'INPUT'
    ]



# Generated at 2022-06-11 07:24:58.726105
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['--syn', '--syn']



# Generated at 2022-06-11 07:25:01.401405
# Unit test for function get_chain_policy
def test_get_chain_policy():
    chain_test = 'Chain INPUT (policy DROP)'
    policy = get_chain_policy(None, None, chain_test)
    assert policy == 'DROP'

# Generated at 2022-06-11 07:25:12.515518
# Unit test for function construct_rule
def test_construct_rule():
    params = {'jump': False, 'ip_version': 'ipv4', 'protocol': 'tcp',
              'destination': '172.31.0.0/16', 'log_prefix': '"IPTABLES:INFO: "',
              'ctstate': 'NEW', 'log_level': 'info', 'action': 'append',
              'limit': '2/second'}
    rule = construct_rule(params)

# Generated at 2022-06-11 07:25:35.659630
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 07:25:37.361000
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("", "", {"policy": "ACCEPT"}) == "ACCEPT"



# Generated at 2022-06-11 07:25:39.349153
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy("iptables", module, params) is None



# Generated at 2022-06-11 07:25:49.747513
# Unit test for function check_present
def test_check_present():
    import iptables
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 07:26:01.938589
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol="tcp",
        source="8.8.8.8",
        jump="DROP",
        ip_version="ipv4"
    )
    rule = ['-w']
    rule.extend(construct_rule(params))
    assert '-p' in rule
    assert '-s' in rule
    assert '-j' in rule
    assert parameters.get('destination') is None
    assert parameters.get('match') is None
    assert parameters.get('tcp_flags') is None
    assert parameters.get('log_prefix') is None
    assert parameters.get('log_level') is None
    assert parameters.get('to_destination') is None
    assert parameters.get('destination_ports') is None
    assert parameters.get('to_source') is None

# Generated at 2022-06-11 07:26:09.418079
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = "/sbin/iptables"
    module = "AnsibleModule"
    params = {}
    params['table'] = 'filter'
    params['chain'] = 'OUTPUT'
    params['jump'] = 'ACCEPT'
    params['reject_with'] = "test_reject_with"
    cmd = push_arguments(iptables_path, '-D', params)
    return cmd


# Generated at 2022-06-11 07:26:19.415598
# Unit test for function insert_rule

# Generated at 2022-06-11 07:26:22.770523
# Unit test for function get_iptables_version
def test_get_iptables_version():
    class Module:
        def run_command(self, cmd, check_rc):
            return 0, 'iptables v1.6.0', ''
    module = Module()
    module.exit_json = lambda a, b: b
    iptables_version = get_iptables_version('iptables', module)
    assert iptables_version == '1.6.0'

# Generated at 2022-06-11 07:26:24.213346
# Unit test for function check_present
def test_check_present():
    assert check_present('test', {'run_command':check_present_run_command}, {}) == True


# Generated at 2022-06-11 07:26:32.833890
# Unit test for function flush_table
def test_flush_table():
    iptables_path = 'iptables'
    rules = [
    #test1
    {'table': 'filter', 'chain': 'FORWARD', 'source': '192.168.1.2', 'destination': '192.168.1.1', 'jump': 'ACCEPT', 'ip_version': 'ipv4'},
    #test2
    {'table': 'filter', 'chain': 'OUTPUT', 'jump': 'ACCEPT', 'ip_version': 'ipv4'},
    #test3
    {'table': 'nat', 'chain': 'OUTPUT', 'jump': 'ACCEPT', 'ip_version': 'ipv4'},
    ]
    expect = ['iptables', '-t', 'filter', '-F', 'FORWARD']

# Generated at 2022-06-11 07:26:48.666433
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', policy='DROP')) == 'DROP'



# Generated at 2022-06-11 07:26:59.665493
# Unit test for function construct_rule

# Generated at 2022-06-11 07:27:04.127368
# Unit test for function set_chain_policy
def test_set_chain_policy():
    if __name__ == "__main__":
        #Execute only if run as a script
        params = dict(
            chain='INPUT',
            table='filter',
            policy='DROP'
        )
        print("params ", params)
        print("cmd ", push_arguments("iptables", '-P', params, make_rule=False))



# Generated at 2022-06-11 07:27:15.159441
# Unit test for function set_chain_policy
def test_set_chain_policy():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import load_platform_subclass
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.shell import ShellModule


# Generated at 2022-06-11 07:27:21.972311
# Unit test for function construct_rule
def test_construct_rule():
    rule = construct_rule(dict(
        jump='DROP',
        syn='match',
        source='1.1.1.1',
        destination='2.2.2.2',
        protocol='tcp',
        to_ports='8080',
        to_source='3.3.3.3',
        comment='DROP all traffic from 1.1.1.1 to 2.2.2.2',
        wait='30',
        ctstate='NEW',
        log_prefix='IPTABLES:INFO: ',
        log_level='info',
        limit='2/second',
        limit_burst='20',
        reject_with='tcp-reset',
        ip_version='ipv4'))

# Generated at 2022-06-11 07:27:24.050217
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:27:29.898797
# Unit test for function check_present
def test_check_present():
    params = {
        'chain': 'INPUT',
        'protocol': 'tcp',
        'source': '1.2.3.4',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'table': 'filter',
    }
    assert len(construct_rule(params)) > 0
    assert check_present('iptables', None, params)



# Generated at 2022-06-11 07:27:40.136311
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule({}, {})
    assert check_present('iptables', module, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.', 'ip_version': 'ipv4'})
    assert check_present('iptables', module, {'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'destination_port': '22', 'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT', 'comment': 'Accept new SSH connections.', 'ip_version': 'ipv6'})



# Generated at 2022-06-11 07:27:43.849098
# Unit test for function set_chain_policy
def test_set_chain_policy():
    test_params = { 'table': 'filter', 'chain': 'INPUT', 'policy': 'DROP' }
    cmd = push_arguments('iptables', '-P', test_params, make_rule=False)
    cmd.append(test_params['policy'])
    print(cmd)



# Generated at 2022-06-11 07:27:52.966093
# Unit test for function check_present
def test_check_present():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert check_present(
        '/sbin/iptables',module,{
            'chain': 'INPUT',
            'protocol': 'tcp',
            'destination_port': '80',
            'ctstate': 'NEW',
            'syn': 'match',
            'jump': 'ACCEPT',
            'comment': 'Accept new SSH connections.',
            'table': 'filter',
        }
    ) == True


# Generated at 2022-06-11 07:28:11.127194
# Unit test for function check_present
def test_check_present():
    module = DummyModule()
    params = dict(chain='INPUT',
                  table='filter',
                  comment='from ansible')
    cmd = push_arguments('iptables', '-C', params)
    assert check_present('iptables', module, params) == False



# Generated at 2022-06-11 07:28:14.993729
# Unit test for function remove_rule
def test_remove_rule():
    params = {
        'table': 'filter',
        'ip_version': 'ipv4',
        'chain': 'INPUT',
        'source': '8.8.8.8',
        'jump': 'DROP',
    }
    cmd = push_arguments('iptables', '-D', params)
    assert cmd == [
        'iptables',
        '-t', 'filter',
        '-D', 'INPUT',
        '-s', '8.8.8.8',
        '-j', 'DROP',
    ]



# Generated at 2022-06-11 07:28:25.313599
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule({
        'ip_version': 'ipv4',
        'protocol': 'tcp',
        'destination_port': 22,
        'source': '192.168.0.1',
        'syn': 'match',
        'jump': 'ACCEPT',
        'comment': 'Sample Rule',
        'wait': '10',
    }) == [
        '-w',
        '10',
        '-p',
        'tcp',
        '--destination-port',
        '22',
        '-s',
        '192.168.0.1',
        '--syn',
        '-j',
        'ACCEPT',
        '-m',
        'comment',
        '--comment',
        'Sample Rule'
    ]



# Generated at 2022-06-11 07:28:32.840086
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments("iptables", "-I", dict(ip_version="ipv4", table="filter", chain="INPUT", protocol="tcp", destination_port="22",
                                                 ctstate="NEW", syn="negate", jump="ACCEPT", comment="Accept new SSH connections.")) == \
           ["iptables", "-t", "filter", "-I", "INPUT", "--syn", "-p", "tcp", "--dport", "22", "-m", "conntrack", "--ctstate", "NEW", "-m", "comment", "--comment", "Accept new SSH connections.", "-j", "ACCEPT"]



# Generated at 2022-06-11 07:28:43.347000
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        action='insert',
        chain='INPUT',
        dest='0.0.0.0/0',
        jump='DROP',
        proto='tcp',
        sport='443',
        dport='443',
        state='NEW',
        ctstate='NEW',
        comment='Test comment',
        syn='match',
        ip_version='ipv4',
        wait='10')
    out = construct_rule(params)

# Generated at 2022-06-11 07:28:44.866470
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', None) == 'n/a'
    assert get_iptables_version('iptables', '1.4.20') == '1.4.20'



# Generated at 2022-06-11 07:28:49.628621
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={})
    # Test function does not exist
    with pytest.raises(SystemExit):
        main()

# Unit tests for module utils

# Generated at 2022-06-11 07:28:54.849346
# Unit test for function check_present
def test_check_present():
    result = check_present('/bin/iptables', None, dict(chain='INPUT',ip_version='ipv4'))
    assert result == True
    params = dict(chain='INPUT',ip_version='ipv4')
    params['protocol'] = 'udp'
    result = check_present('/bin/iptables', None, params)
    assert result == False


# Generated at 2022-06-11 07:28:56.184682
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    version = get_iptables_version('iptables', module)
    assert version is not None



# Generated at 2022-06-11 07:29:00.298560
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP']
# end



# Generated at 2022-06-11 07:29:16.566958
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('iptables', module)



# Generated at 2022-06-11 07:29:26.286352
# Unit test for function main

# Generated at 2022-06-11 07:29:27.640608
# Unit test for function append_rule
def test_append_rule():
    print('*** test_append_rule running ***')
    assert True


# Generated at 2022-06-11 07:29:36.719949
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path='iptables'
    module = AnsibleModule({})
    params=dict(
    action= 'insert',
    chain= 'INPUT',
    in_interface= 'eth0',
    protocol= 'tcp',
    match= 'tcp',
    destination_port= '8080',
    jump= 'ACCEPT',
    rule_num= '5'
    )
    cmd = push_arguments(iptables_path, '-I', params)
    assert cmd == ['iptables', '-t', 'filter', '-I', 'INPUT', '5', '-p', 'tcp', '-m', 'tcp', '--dport', '8080', '-j', 'ACCEPT']


# Generated at 2022-06-11 07:29:44.279881
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        chain="INPUT",
        protocol="tcp",
        destination_port="22",
        ctstate="NEW",
        syn="match",
        jump="ACCEPT",
        comment="Accept new SSH connections.",
        ip_version="ipv4",
    )
    expected = [
        '-p', 'tcp', '--dport', '22',
        '-m', 'conntrack', '--ctstate', 'NEW',
        '--syn', '-j', 'ACCEPT',
        '-m', 'comment', '--comment', 'Accept new SSH connections.'
    ]
    assert construct_rule(params) == expected



# Generated at 2022-06-11 07:29:53.685599
# Unit test for function construct_rule

# Generated at 2022-06-11 07:30:02.258569
# Unit test for function append_rule
def test_append_rule():
    from ansible.modules.network.iptables import append_rule
    from ansible.module_utils.basic import AnsibleModule
    example_params = {'chain': 'INPUT', 'comment': '', 'destination_port': '22', 'jump': 'ACCEPT', 'match': '', 'protocol': 'tcp', 'reject_with': '', 'rule_num': '', 'state': '', 'syn': '', 'table': 'filter'}
    module = AnsibleModule(argument_spec=example_params)
    append_rule('/sbin/iptables', module, example_params)
    module = AnsibleModule(argument_spec=example_params)

# Generated at 2022-06-11 07:30:10.908267
# Unit test for function main

# Generated at 2022-06-11 07:30:13.039502
# Unit test for function check_present
def test_check_present():
    assert check_present(None, None, {
        'chain': 'INPUT',
        'table': 'filter'
    }) == True


# Generated at 2022-06-11 07:30:23.099669
# Unit test for function main