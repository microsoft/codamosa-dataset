

# Generated at 2022-06-11 07:22:43.475309
# Unit test for function main

# Generated at 2022-06-11 07:22:50.887090
# Unit test for function check_present
def test_check_present():
    # Constructing some fake module parameters to go through the code
    ip_version = 'ipv4'
    action = 'present'
    protocol = 'tcp'
    jump = 'ACCEPT'
    set_counters = 'set_counters'
    chain = 'INPUT'
    module = AnsibleModule(argument_spec=dict(
        ip_version=dict(type='str', choices=['ipv4', 'ipv6'], required=True),
        action=dict(type='str', choices=['present', 'absent'], required=True),
        protocol=dict(type='str'),
        jump=dict(type='str'),
        set_counters=dict(type='str'),
        chain=dict(type='str', required=True),
        ))

    # Assigning a value to the variables using the fake module

# Generated at 2022-06-11 07:23:02.681807
# Unit test for function remove_rule
def test_remove_rule():
    module = AnsibleModule(argument_spec={})
    params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4',
        action='remove',
        state='present',
        destination='1.2.3.4',
        destination_port='22',
        protocol='tcp',
        wait=None,
    )
    iptables_path = module.get_bin_path('iptables')
    if iptables_path is None:
        module.fail_json(msg='iptables path could not be found')

    assert remove_rule(iptables_path, module, params) == None


# Generated at 2022-06-11 07:23:14.085069
# Unit test for function remove_rule
def test_remove_rule():
    ipv4_path = '/sbin/iptables'
    ipv6_path = '/sbin/ip6tables'

# Generated at 2022-06-11 07:23:25.558660
# Unit test for function append_param
def test_append_param():
    data = [
        ('a', '!b', ['test', '!', '-a', 'test', '-b', 'a']),
        ('a', 'b', ['test', '!', '-a', 'test', '-b', 'a']),
        (['a', 'b'], '!c', ['test', '!', '-a', 'test', '-b', 'a', 'b']),
        (['a', 'b'], 'c', ['test', '!', '-a', 'test', '-b', 'a', 'b']),
        (['a', '!b'], 'c', ['test', '!', '-a', 'test', '-b', 'a', '!b']),
    ]

# Generated at 2022-06-11 07:23:29.480804
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, "CST1", "--set-dscp-mark-class", False)
    assert rule == ['--set-dscp-mark-class', 'CST1']



# Generated at 2022-06-11 07:23:38.051123
# Unit test for function construct_rule
def test_construct_rule():
    # Arrange
    expected_rule_v4 = [
        '-w',
        '-p', 'tcp',
        '-s', '8.8.8.8',
        '-j', 'DROP',
        '-m', 'comment',
        '--comment', 'test comment',
    ]

    expected_rule_v6 = [
        '-w',
        '-p', 'tcp',
        '-s', '8.8.8.8',
        '-j', 'DROP',
        '-m', 'comment',
        '--comment', 'test comment',
        '--icmpv6-type', 'echoreq'
    ]


# Generated at 2022-06-11 07:23:45.733222
# Unit test for function check_present
def test_check_present():
    params = dict(chain='INPUT',
    protocol='tcp',
    destination_port='22',
    ctstate='NEW',
    syn='match',
    jump='ACCEPT',
    comment='Accept new SSH connections.',
    ip_version='ipv4')
    iptables_path='iptables'
    assert check_present(iptables_path, module, params)==True
# Unit Tests Ends



# Generated at 2022-06-11 07:23:50.503634
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = '/sbin/iptables'
    table = 'filter'
    chain = 'INPUT'
    policy = 'ACCEPT'
    chain_policy = get_chain_policy(iptables_path, None, module.params)
    assert chain_policy == policy


# Generated at 2022-06-11 07:23:59.389712
# Unit test for function push_arguments
def test_push_arguments():
    result = push_arguments(
        '/bin/iptables',
        '-A',
        dict(
            table='filter',
            chain='INPUT',
            jump='ACCEPT',
            protocol='tcp',
            comment='test comment'
        )
    )
    assert result == [
        '/bin/iptables',
        '-t', 'filter',
        '-A', 'INPUT',
        '-j', 'ACCEPT',
        '-p', 'tcp',
        '-m', 'comment',
        '--comment', 'test comment'
    ]



# Generated at 2022-06-11 07:24:56.820351
# Unit test for function set_chain_policy
def test_set_chain_policy():
    import subprocess
    import test
    import string
    import random
    """
    Test set_chain_policy function
    """
    cmd = "iptables -L -nv"
    output = subprocess.getoutput(cmd)
    lines = output.splitlines()
    chain_name = ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(20))
    line = "Chain " + chain_name + " (0 references)"
    if line not in lines:
        policy = "ACCEPT"
        cmd = "iptables -N" + chain_name
        subprocess.getoutput(cmd)
    else:
        policy = "DROP"

# Generated at 2022-06-11 07:25:00.117237
# Unit test for function append_match_flag
def test_append_match_flag():
    # Setup
    rule = []
    flag = '--syn'
    # Expected result
    rule_match = ['--syn']

    append_match_flag(rule, 'match', flag, True)
    assert rule == rule_match
# test_append_match_flag


# Generated at 2022-06-11 07:25:06.571366
# Unit test for function push_arguments
def test_push_arguments():
    result = push_arguments(BINS['ipv4'], '-I', {'table': 'filter', 'chain': 'INPUT', 'rule_num': 1})
    assert result[0] == 'iptables'
    assert result[1] == '-t'
    assert result[2] == 'filter'
    assert result[3] == '-I'
    assert result[4] == 'INPUT'
    assert result[5] == 1


# Generated at 2022-06-11 07:25:18.844238
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        jump='ACCEPT',
    )
    assert push_arguments('iptables', '-A', params) == [
        'iptables',
        '-t', 'filter',
        '-A', 'INPUT',
        '-p', 'tcp',
        '-j', 'ACCEPT'
    ]
    params['rule_num'] = '1'
    assert push_arguments('iptables', '-I', params) == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '1',
        '-p', 'tcp',
        '-j', 'ACCEPT'
    ]
    params

# Generated at 2022-06-11 07:25:29.683205
# Unit test for function main
def test_main():
    # Fields
    table='filter'
    state='present'
    action='append'
    ip_version='ipv4'
    chain=None
    rule_num=None
    protocol=None
    wait='2'
    source=None
    to_source=None
    destination=None
    to_destination=None
    match=[]
    tcp_flags=None
    jump=None
    gateway=None
    log_prefix='Unit Test Log'
    log_level='debug'
    goto=None
    in_interface=None
    out_interface=None
    fragment=None
    set_counters=None
    source_port=None
    destination_port=None
    destination_ports=[]
    to_ports=None
    set_dscp_mark=None
    set_dscp_mark

# Generated at 2022-06-11 07:25:33.264144
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables",None,dict(
        chain='INPUT',
        policy='ACCEPT'
    )) == 'ACCEPT'
    assert get_chain_policy("iptables",None,dict(
        chain='INPUT',
        policy='DROP'
    )) == 'DROP'


# Generated at 2022-06-11 07:25:40.646313
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({
        'ip_version': 'ipv4',
        'chain': 'INPUT',
        'table': 'filter',
        'policy': 'DROP',
    })
    iptables_path = 'iptables'
    assert push_arguments(iptables_path, '-P', module.params, make_rule=False) == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']


# Generated at 2022-06-11 07:25:50.494160
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        in_interface='eth0',
        protocol='tcp',
        destination_port='80',
        jump='ACCEPT',
        action='-A'
    )
    cmd = push_arguments('iptables', params['action'], params, True)
    assert cmd == ['iptables','-t','filter','-A','INPUT','-i','eth0','-p','tcp',
                   '--destination-port','80','-j','ACCEPT']

# Generated at 2022-06-11 07:25:59.598202
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path = 'iptables'
    module = AnsibleModule({})
    params = dict(
            table='filter',
            chain='INPUT',
            in_interface='eth0',
            protocol='tcp',
            destination_port=80,
            jump='ACCEPT',
            rule_num=5)
    cmd = push_arguments(iptables_path, '-I', params)
    assert(cmd == 'iptables -t filter -I INPUT 5 -i eth0 -p tcp --dport 80 -j ACCEPT')


# Generated at 2022-06-11 07:26:06.016544
# Unit test for function remove_rule
def test_remove_rule():
    global BINS
    iptables_path = BINS['ipv4']
    table = 'filter'
    chain = 'INPUT'
    source = '8.8.8.8'
    command = 'remove_rule'
    result = [iptables_path, '-t', table, command, chain, '-s', source]
    return(result)



# Generated at 2022-06-11 07:27:30.565483
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/sbin/iptables'
    action = '-I'
    params = dict(
        table='filter',
        chain='INPUT',
        comment='drop ICMP',
        protocol='icmp',
        source='8.8.8.8',
        jump='DROP'
    )
    expected_result = [
        iptables_path,
        '-t',
        'filter',
        action,
        'INPUT',
        '-w',
        '-p',
        'icmp',
        '-s',
        '8.8.8.8',
        '-m',
        'comment',
        '--comment',
        'drop ICMP',
        '-j',
        'DROP'
    ]

# Generated at 2022-06-11 07:27:37.400694
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule({'table': 'filter', 'chain': 'INPUT', 'flush': True}, check_invalid_arguments=False)
    try:
        flush_table('iptables', module, {'table': 'filter', 'chain': 'INPUT', 'flush': True})
        module.exit_json(changed=False)
    except Exception as e:
        module.fail_json(msg=repr(e))



# Generated at 2022-06-11 07:27:46.943566
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='filter',
        chain='INPUT',
        rule_num=5,
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='Ansible Test'
    )
    args = push_arguments('/sbin/iptables', '-I', params)
    assert args == [
        '/sbin/iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '5',
        '-p', 'tcp',
        '-s', '8.8.8.8',
        '-j', 'DROP',
        '-m', 'comment',
        '--comment', 'Ansible Test'
    ]

# Generated at 2022-06-11 07:27:51.602202
# Unit test for function check_present
def test_check_present():
    module = AnsibleModule(argument_spec={})
    module.params = dict(
        table='filter',
        chain='INPUT',
    )
    rc, _, __ = module.run_command(push_arguments('iptables', '-C', module.params), check_rc=False)
    assert rc == 0


# Generated at 2022-06-11 07:27:56.966422
# Unit test for function main

# Generated at 2022-06-11 07:28:02.989340
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    test_rule = []
    test_param = dict(
        flags=['ALL', 'SYN', 'ACK'],
        flags_set=['SYN', 'ACK']
    )
    append_tcp_flags(test_rule, test_param, '--tcp-flags')
    assert test_rule == ['--tcp-flags', 'ALL,SYN,ACK', 'SYN,ACK']



# Generated at 2022-06-11 07:28:14.265164
# Unit test for function main

# Generated at 2022-06-11 07:28:16.714533
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter', policy='DROP')) == 'DROP'



# Generated at 2022-06-11 07:28:19.875232
# Unit test for function flush_table
def test_flush_table():
    test_params = dict(
            chain="INPUT",
            table="filter"
        )
    flush_table("iptables", None, test_params)



# Generated at 2022-06-11 07:28:26.865851
# Unit test for function construct_rule

# Generated at 2022-06-11 07:29:56.798621
# Unit test for function push_arguments
def test_push_arguments():
    module = AnsibleModule({})
    # command fot test
    module.params = {
        'table': 'filter',
        'chain': 'INPUT',
        'rule_num': "5",
        'protocol': 'tcp',
        'destination_port': "8080",
        'jump': 'ACCEPT'
    }
    cmd = push_arguments("/usr/sbin/iptables", '-I', module.params)
    assert cmd == ['/usr/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5',
                   '-p', 'tcp', '--destination-port', '8080', '-j', 'ACCEPT']

# Generated at 2022-06-11 07:29:58.622946
# Unit test for function check_present
def test_check_present():
    check = check_present("iptables",module,['INPUT', '-p', 'tcp'])
    assert check == True


# Generated at 2022-06-11 07:30:07.570398
# Unit test for function construct_rule
def test_construct_rule():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 07:30:17.424334
# Unit test for function construct_rule

# Generated at 2022-06-11 07:30:20.100950
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(
        table='filter',
        chain="WHITELIST",
    )) == "ACCEPT"
    assert get_chain_policy(None, None, dict(
        table='filter',
        chain="WHITELIST2",
    )) is None



# Generated at 2022-06-11 07:30:27.462340
# Unit test for function main
def test_main():
    docs = get_docs()
    module = AnsibleModule(
        argument_spec=docs['argument_spec'],
        supports_check_mode=True,
    )
    # Make sure the permissions are good
    for ip_version in ("ipv4", "ipv6"):
        iptables_path = module.get_bin_path(BINS[ip_version], True)
        mode = os.stat(iptables_path).st_mode
        if not (stat.S_IXUSR & mode):
            module.fail_json(msg="iptables binary must be executable.")
    main()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:30:33.095370
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    # Expected output from iptables -L
    out = "Chain INPUT (policy ACCEPT)"
    assert get_chain_policy(None, module, dict()) == None
    assert get_chain_policy(None, module, dict(policy="ACCEPT")) == "ACCEPT"
    assert get_chain_policy(None, module, dict(policy="DROP")) == None
    assert get_chain_policy(None, module, dict(chain="INPUT")) == "ACCEPT"
    assert get_chain_policy(None, module, dict(chain="OUTPUT")) == None
    assert get_chain_policy(None, module, dict(chain="INPUT", out=out)) == "ACCEPT"


# Generated at 2022-06-11 07:30:38.886608
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--syn', False)
    assert rule == ['--syn']



# Generated at 2022-06-11 07:30:44.196681
# Unit test for function push_arguments

# Generated at 2022-06-11 07:30:48.447184
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert set_chain_policy(
        '/usr/bin/iptables',
        {'run_command': mock_run_command_success},
        {
            'table': 'filter',
            'chain': 'INPUT',
            'wait': '1',
            'ip_version': 'ipv4',
            'policy': 'DROP'
        }
    ) == ['/usr/bin/iptables', '-t', 'filter', '-P', 'INPUT', '-w', '1', 'DROP']

