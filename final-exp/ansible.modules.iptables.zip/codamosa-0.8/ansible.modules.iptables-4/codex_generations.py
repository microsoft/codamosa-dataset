

# Generated at 2022-06-11 07:21:33.629110
# Unit test for function flush_table
def test_flush_table():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec={})
    params = {
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
    }
    cmd = push_arguments(iptables_path, '-F', params, make_rule=False)
    cmd == ['/sbin/iptables', '-t', 'filter', '-F', 'INPUT']


# Generated at 2022-06-11 07:21:39.111614
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'policy': 'ACCEPT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'policy': 'DROP'}) == 'DROP'
    assert get_chain_policy(None, None, {'policy': 'Foo'}) == None
# Function get_chain_policy is covered by test_check_present



# Generated at 2022-06-11 07:21:45.834053
# Unit test for function push_arguments

# Generated at 2022-06-11 07:21:54.276226
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = "/usr/bin/iptables"
    module = "module"
    params = dict(
        ip_version='ipv4',
        chain='OUTPUT',
        policy='ACCEPT',
    )
    cmd = [iptables_path]
    cmd.extend(['-t', params['table']])
    cmd.extend(['-P', params['chain']])
    cmd.append(params['policy'])
    cmd_return = "-P OUTPUT ACCEPT"
    assert set_chain_policy(iptables_path, module, params) == cmd_return


# Generated at 2022-06-11 07:22:04.426303
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments(
        '/tmp/iptables', '-I',
        dict(
            table='filter', chain='INPUT', rule_num=3,
            protocol='tcp', destination_port='23', jump='DROP')) == [
        '/tmp/iptables', '-t', 'filter', '-I', 'INPUT', '3', '-p', 'tcp',
        '--destination-port', '23', '-j', 'DROP']

# Generated at 2022-06-11 07:22:13.699019
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='192.168.1.100',
        destination='192.168.1.200',
        match=['state', 'limit'],
        ctstate=['NEW', 'ESTABLISHED'],
        uid_owner='0-100',
        limit='5/minute',
        reject_with='icmp-host-unreachable'
    )
    rule = construct_rule(params)

# Generated at 2022-06-11 07:22:22.268080
# Unit test for function construct_rule

# Generated at 2022-06-11 07:22:33.172916
# Unit test for function push_arguments

# Generated at 2022-06-11 07:22:36.017374
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('', '', {'chain': 'INPUT'})
    assert get_chain_policy('', '', {'chain': 'FORWARD'})
    assert get_chain_policy('', '', {'chain': 'OUTPUT'})



# Generated at 2022-06-11 07:22:41.957507
# Unit test for function push_arguments

# Generated at 2022-06-11 07:23:12.017437
# Unit test for function get_chain_policy
def test_get_chain_policy():
    iptables_path = 'iptables'
    module = AnsibleModule()
    params = dict(chain = 'INPUT',
                  table = 'filter',
                  policy = None,
                  ip_version = 'ipv4')
    cmd = push_arguments(iptables_path, '-L', params, make_rule=False)
    out = 'Chain INPUT (policy DROP)\n'
    rc = 0
    module.run_command = mock_run_command
    setattr(module, '_ansible_check_mode', False)
    assert 'DROP' == get_chain_policy(iptables_path, module, params)
    ####Testing DROP policy
    assert 0 == rc
    assert out == out 


# Generated at 2022-06-11 07:23:17.345521
# Unit test for function get_chain_policy
def test_get_chain_policy():
    chain_header = 'Chain INPUT (policy ACCEPT)'
    result = re.search(r'\(policy ([A-Z]+)\)', chain_header)
    assert result.group(1) == 'ACCEPT'



# Generated at 2022-06-11 07:23:18.338810
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag() == True


# Generated at 2022-06-11 07:23:26.948581
# Unit test for function append_rule
def test_append_rule():
    assert append_rule('', {}, {'table': 'filter', 'chain': 'INPUT',
                           'protocol': 'tcp', 'destination_port': 22,
                           'ctstate': 'NEW', 'syn': 'match', 'jump': 'ACCEPT',
                           'comment': 'Accept new SSH connections.'}) == ["iptables",
        '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '--dport', '22', '-m',
        'conntrack', '--ctstate', 'NEW', '--syn', '-j', 'ACCEPT', '-m',
        'comment', '--comment', 'Accept new SSH connections.']


# Generated at 2022-06-11 07:23:33.947040
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        protocol=None,
        source='10.10.10.0/24',
        source_port=None,
        destination='10.20.20.20',
        destination_port='123',
        jump=None,
        match=None,
        ctstate=None,
        tcp_flags=None,
        syn=None,
        source_range=None,
        destination_range=None,
        in_interface=None,
        out_interface=None,
        frag=None,
        set_counters=None,
        comment=None,
    )
    rule = construct_rule(params)

# Generated at 2022-06-11 07:23:46.307594
# Unit test for function main
def test_main():
    iptables_path = '/sbin/iptables'
    main_module_params = {
        "state": "present",
        "ip_version": "ipv4",
        "action": "append",
        "table": "filter",
        "chain": "INPUT",
        "protocol": "all",
        "jump": "DROP",
        "wait": "10"
    }

# Generated at 2022-06-11 07:23:50.844107
# Unit test for function set_chain_policy
def test_set_chain_policy():
    actual = set_chain_policy('iptables', 'module', {'table': 'filter', 'chain': 'INPUT', 'policy': 'DROP'})
    expected = ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']
    assert actual == expected



# Generated at 2022-06-11 07:24:02.145629
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/sbin/iptables'
    module = AnsibleModule()

# Generated at 2022-06-11 07:24:05.249632
# Unit test for function flush_table
def test_flush_table():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert flush_table(None, module, {}) is None


# Generated at 2022-06-11 07:24:15.421015
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path=BINS['ipv4']
    action='-I'
    params={
            'ip_version': 'ipv4',
            'mode': 'append',
            'table': 'filter',
            'chain': 'INPUT',
            'protocol': 'tcp',
            'jump': 'ACCEPT',
            'state': 'present',
            'destination_port': 8080,
            'rule_num': 5,
            }
    result=push_arguments(iptables_path, action, params, make_rule=True)
    print(result)

# Generated at 2022-06-11 07:24:42.231289
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = ['iptables', '-I', 'INPUT', '-p', 'tcp']
    #test empty list
    append_tcp_flags(rule, {'flags': [], 'flags_set': []}, '--tcp-flags')
    assert rule == ['iptables', '-I', 'INPUT', '-p', 'tcp', '--tcp-flags', '', '']
    #test flags and flags_set
    rule = ['iptables', '-I', 'INPUT', '-p', 'tcp']
    append_tcp_flags(rule, {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': []}, '--tcp-flags')

# Generated at 2022-06-11 07:24:45.077544
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'DROP'}) == 'DROP'



# Generated at 2022-06-11 07:24:47.920721
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {'flags': ['ACK', 'RST', 'FIN', 'SYN'], 'flags_set': ['ACK', 'RST', 'SYN']}
    flag = '--tcp-flags'
    append_tcp_flags(rule, param, flag)
    assert rule == ['--tcp-flags', 'ACK,FIN,RST,SYN', 'ACK,RST,SYN']



# Generated at 2022-06-11 07:24:49.673694
# Unit test for function flush_table
def test_flush_table():
    assert flush_table("1","2","3") == None



# Generated at 2022-06-11 07:25:00.198447
# Unit test for function construct_rule
def test_construct_rule():
    '''
        Unit test for function construct_rule
    '''
    # test iptables
    params = dict(
        chain="INPUT",
        log_prefix="IPTABLES BLOCK ",
        log_level=None,
        jump="DROP",
        protocol="tcp",
        destination_ports="22",
        ctstate=["NEW"],
        syn=True,
        table="filter"
    )
    rule = construct_rule(params)
    assert rule == ['-w', '-p', 'tcp', '-m', 'conntrack', '--ctstate',
                    'NEW', '--syn', '--dports', '22', '-j', 'DROP']
    # test ip6tables

# Generated at 2022-06-11 07:25:04.757526
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = dict(flags=['SYN', 'ACK', 'RST'], flags_set=['FIN', 'PSH'])
    append_tcp_flags(rule, param, '--tcp-flags')
    assert rule == ['--tcp-flags', 'SYN,ACK,RST', 'FIN,PSH']



# Generated at 2022-06-11 07:25:09.056842
# Unit test for function append_match_flag
def test_append_match_flag():
    assert append_match_flag([], 'match', '--tcp-flags', True) == ['--tcp-flags']
    assert append_match_flag([], 'negate', '--tcp-flags', True) == ['!', '--tcp-flags']


# Generated at 2022-06-11 07:25:20.947697
# Unit test for function main
def test_main():
    # fail load module
    load_fixture = None

# Generated at 2022-06-11 07:25:31.412919
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(iptables_path='',
                            module=None,
                            params={'chain': 'FORWARD', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(iptables_path='',
                            module=None,
                            params={'chain': 'INPUT', 'table': 'filter'}) == 'ACCEPT'
    assert get_chain_policy(iptables_path='',
                            module=None,
                            params={'chain': 'FORWARD', 'table': 'nat'}) == 'ACCEPT'
    assert get_chain_policy(iptables_path='',
                            module=None,
                            params={'chain': 'PREROUTING', 'table': 'nat'}) == 'ACCEPT'

# Generated at 2022-06-11 07:25:43.119329
# Unit test for function append_param
def test_append_param():
    params = ['test1', 'test2', 'test3', 'test4', 'test5']
    ret = []
    append_param(ret, params, '-test1', True)
    assert ret == ['-test1', 'test1', '-test1', 'test2', '-test1', 'test3', '-test1', 'test4', '-test1', 'test5']
    ret = []
    append_param(ret, params, '-test2', True)
    assert ret == ['-test2', 'test1', '-test2', 'test2', '-test2', 'test3', '-test2', 'test4', '-test2', 'test5']
    ret = []
    append_param(ret, params, '-test3', True)

# Generated at 2022-06-11 07:27:42.331537
# Unit test for function push_arguments
def test_push_arguments():
    print("Testing push_arguments")
    test_args = {
        'table': 'nat',
        'chain': 'PREROUTING',
        'in_interface': 'eth0',
        'protocol': 'tcp',
        'match': 'tcp',
        'destination_port': '80',
        'jump': 'REDIRECT',
        'to_ports': '8600',
        'comment': 'Redirect web traffic to port 8600',
    }
    cmd = push_arguments('/usr/sbin/iptables', '-A', test_args)

# Generated at 2022-06-11 07:27:48.166069
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule(argument_spec=dict())
    params = dict(table='filter',
        chain='INPUT',
        jump='ACCEPT',
        rule_num=None,
        ip_version='ipv4',
        src_range=None,
        dst_range=None,
        match_set=None,
        match_set_flags=None,
        wait=None)
    cmd = push_arguments(iptables_path, '-A', params)
    assert(cmd == ['/sbin/iptables', '-t', 'filter', '-A', 'INPUT', '-j', "ACCEPT"])


# Generated at 2022-06-11 07:27:54.947776
# Unit test for function construct_rule
def test_construct_rule():
    """
    The test procedure is to (1) generate rules using the logic in this
    module and (2) flush the iptables table and (3) write them to the
    table and (4) dump the table and (5) compare the generated rule and
    the rules in the dumped table.

    Each rule is tested separately by setting one and only one parameter.
    For example, the test procedure for source rule consists of the
    following steps:
    1. Make a list of source IPs.
    2. Generate source rules (ip rule add).
    3. Flush the table.
    4. Write generated source rules to the table.
    5. Dump the table.
    6. Compare the source IPs with the dumped source rules.
    """
    import subprocess
    from tempfile import NamedTemporaryFile

# Generated at 2022-06-11 07:28:05.558601
# Unit test for function construct_rule

# Generated at 2022-06-11 07:28:10.706405
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', None, dict(
        chain='INPUT',
        table='filter',
        protocol='tcp',
        destination_port='8080',
        jump='ACCEPT',
        action='insert',
        rule_num=5
    )) is True



# Generated at 2022-06-11 07:28:22.438620
# Unit test for function append_param
def test_append_param():
    ret = []
    append_param(ret, ['--icmp-type', 'echo-reply'], '--icmp-type', True)
    assert ret == ['--icmp-type', 'echo-reply']

    ret = []
    append_param(ret, 'echo-reply', '--icmp-type', False)
    assert ret == ['--icmp-type', 'echo-reply']

    ret = []
    append_param(ret, ['--icmp-type', '!echo-reply'], '--icmp-type', True)
    assert ret == ['!', '--icmp-type', 'echo-reply']

    ret = []
    append_param(ret, '!echo-reply', '--icmp-type', False)
    assert ret == ['!', '--icmp-type', 'echo-reply']

# Generated at 2022-06-11 07:28:26.779693
# Unit test for function flush_table
def test_flush_table():
    module = type('module', (object,), {'run_command': lambda self, *_: (0, '', ''), 'check_mode': False})()
    return flush_table('iptables', module, {'ip_version': 'ipv4', 'table': 'filter', 'chain': 'INPUT'})



# Generated at 2022-06-11 07:28:35.313761
# Unit test for function push_arguments
def test_push_arguments():
    params = {
        "action": "-I",
        "chain": "INPUT",
        "destination": "213.188.37.131",
        "destination_port": "80",
        "jump": "ACCEPT",
        "rule_num": "5",
        "table": "filter",
    }
    expected = [
        '/sbin/iptables', '-t', 'filter', '-I', 'INPUT', '5', '-d', '213.188.37.131', '--destination-port', '80', '-j',
        'ACCEPT'
    ]
    assert push_arguments('/sbin/iptables', params['action'], params) == expected



# Generated at 2022-06-11 07:28:41.312985
# Unit test for function append_param
def test_append_param():
    rule = []

    append_param(rule, None, '--destination-port', False)
    assert rule == []

    rule = []
    append_param(rule, '443', '--destination-port', False)
    assert rule == ['--destination-port', '443']

    rule = []
    append_param(rule, [], '--destination-port', True)
    assert rule == []

    rule = []
    append_param(rule, ['80'], '--destination-port', True)
    assert rule == ['--destination-port', '80']

    rule = []
    append_param(rule, ['80','443'], '--destination-port', True)
    assert rule == ['--destination-port', '80','--destination-port', '443']

    rule = []
   

# Generated at 2022-06-11 07:28:43.919097
# Unit test for function get_iptables_version
def test_get_iptables_version():
    test_module = AnsibleModule(argument_spec=dict())
    version = get_iptables_version(BINS['ipv4'], test_module)
    assert version is not None

