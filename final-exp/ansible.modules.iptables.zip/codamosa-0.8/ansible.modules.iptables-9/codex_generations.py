

# Generated at 2022-06-11 07:21:31.890720
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", None, dict(table="filter", chain="INPUT")) == "ACCEPT"
    assert get_chain_policy("iptables", None, dict(table="filter", chain="FORWARD")) == "ACCEPT"
    assert get_chain_policy("iptables", None, dict(table="filter", chain="OUTPUT")) == "ACCEPT"



# Generated at 2022-06-11 07:21:39.242110
# Unit test for function construct_rule

# Generated at 2022-06-11 07:21:43.356579
# Unit test for function check_present
def test_check_present():
    path = "/usr/bin/iptables"
    module = "ansible.builtin.iptables"
    params = dict(
        table="nat",
        chain="INPUT",
        protocol="tcp",
        destination_port="22",
        ctstate="NEW",
        syn="match",
        jump="ACCEPT",
        comment="Accept new SSH connections.",
      )
    assert check_present(path, module, params) == False


# Generated at 2022-06-11 07:21:47.618625
# Unit test for function check_present
def test_check_present():
    module = MagicMock()
    module.run_command.return_value = (0, "", "")
    params = dict(
        table="filter",
        chain="INPUT",
        ip_version="ipv4",
        rule_num="1",
    )
    check_present("iptables", module, params)
    module.run_command.assert_called_with(
        ['iptables', '-t', 'filter', '-C', 'INPUT', '1'])



# Generated at 2022-06-11 07:21:59.473237
# Unit test for function construct_rule

# Generated at 2022-06-11 07:22:08.694357
# Unit test for function append_rule
def test_append_rule():
    iptables_path = 'iptables'

# Generated at 2022-06-11 07:22:10.348314
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('/foo', None, {'chain': 'INPUT'}) == "ACCEPT"



# Generated at 2022-06-11 07:22:18.807450
# Unit test for function push_arguments
def test_push_arguments():
    rule1 = "iptables -t filter -D INPUT -s 192.168.1.1/24 -d 192.168.2.2/24 -p tcp --source-port 456 --destination-port 65 -m state --state NEW,ESTABLISHED,RELATED -j DROP --comment 'Test rule'"
    rule2 = "iptables -t filter -I INPUT -s 192.168.1.1/24 -d 192.168.2.2/24 -p tcp --source-port 456 --destination-port 65 -m state --state NEW,ESTABLISHED,RELATED -j DROP --comment 'Test rule'"

# Generated at 2022-06-11 07:22:30.274142
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/usr/bin/iptables'
    action = '-t'

# Generated at 2022-06-11 07:22:41.857715
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path='iptables'
    params = dict(
        chain='INPUT',
        protocol='tcp',
        destination_port='22',
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        ip_version='ipv4',
        table='filter')
    cmd = push_arguments(iptables_path, '-D', params)
    # print cmd
    assert cmd== ['iptables',
      '-t', 'filter',
      '-D', 'INPUT',
      '-m', 'conntrack',
      '--ctstate', 'NEW',
      '-p', 'tcp',
      '--syn',
      '--dport', '22',
      '-j', 'ACCEPT']


# Generated at 2022-06-11 07:23:00.957498
# Unit test for function append_rule
def test_append_rule():
    import tempfile
    import shutil
    import os
    import fileinput
    base_dir = os.path.join(tempfile.mkdtemp(), "iptables")
    os.mkdir(base_dir)
    shutil.copyfile('iptables.py', os.path.join(base_dir, 'iptables.py'))
    cmd = "cd %s"%base_dir + ";" + "touch config"
    os.system(cmd)
    shutil.copyfile('iptables.py', os.path.join(base_dir, 'iptables.py'))

# Generated at 2022-06-11 07:23:07.148912
# Unit test for function set_chain_policy
def test_set_chain_policy():
    p = dict(
        ip_version='ipv4',
        table='filter',
        chain='INPUT',
        policy='ACCEPT',
    )

    c = set_chain_policy('/usr/bin/iptables', p)
    assert c == ['/usr/bin/iptables', '-t', 'filter', '-P', 'INPUT', 'ACCEPT']



# Generated at 2022-06-11 07:23:08.656550
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:23:11.687611
# Unit test for function get_chain_policy
def test_get_chain_policy():
    result = get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'DROP'})
    assert result == 'DROP'



# Generated at 2022-06-11 07:23:15.860649
# Unit test for function push_arguments
def test_push_arguments():
    iptables_path = '/usr/bin/iptables'
    action = '-I'
    params = dict(
    action='insert',
    wait='10',
    chain='INPUT',
    protocol='ipv4',
    destination='10.0.0.0/24',
    jump='RETURN',
    ctstate='NEW',
    comment='Test insert rule',
    rule_num='5',
    )

# Generated at 2022-06-11 07:23:17.922033
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', '-C', params) == (rc == 0)


# Generated at 2022-06-11 07:23:27.597940
# Unit test for function push_arguments
def test_push_arguments():
    assert (push_arguments('iptables', '-A', dict(table='filter', chain='INPUT',
                                                 protocol='tcp', source='192.168.1.1', destination='192.168.1.2',
                                                 destination_port='80', jump='ACCEPT')) ==
            ['iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '-s', '192.168.1.1', '-d', '192.168.1.2',
             '--dport', '80', '-j', 'ACCEPT'])

# Generated at 2022-06-11 07:23:34.953604
# Unit test for function construct_rule

# Generated at 2022-06-11 07:23:47.385441
# Unit test for function construct_rule
def test_construct_rule():
    params = dict()
    params['protocol'] = 'tcp'
    params['source'] = '1.1.1.1'
    params['destination'] = '2.2.2.2'
    params['match'] = ['tcp']
    params['tcp_flags'] = dict(flags=['ACK', 'RST', 'SYN', 'FIN'],
                               flags_set=['ACK', 'RST', 'SYN', 'FIN'])
    params['jump'] = 'DROP'
    params['log_prefix'] = "IPTABLES:INFO: "
    params['log_level'] = 'info'
    params['to_destination'] = "10.1.1.1"
    params['destination_ports'] = ['80', '443', '8080:8083']

# Generated at 2022-06-11 07:23:58.804378
# Unit test for function construct_rule

# Generated at 2022-06-11 07:24:22.718792
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule_tcp_flags_match = ['!', '--tcp-flags']
    rule_tcp_flags_no_flags_set = ['!', '--tcp-flags', 'ACK,FIN,PSH,RST,SYN', '']
    rule_tcp_flags_no_flags = ['!', '--tcp-flags', '', 'ACK,FIN,PSH,RST,SYN']
    rule_tcp_flags_with_exclamation_mark = ['!', '--tcp-flags', 'ACK,FIN,PSH,RST,SYN', 'ACK,FIN,PSH,RST,SYN']

# Generated at 2022-06-11 07:24:26.149770
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version(iptables_path, module) == out.split('v')[1].rstrip('\n')
# End of unit test for function get_iptables_version



# Generated at 2022-06-11 07:24:37.735530
# Unit test for function get_chain_policy
def test_get_chain_policy():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes # pylint: disable=protected-access
    from ansible.module_utils.common.network import ModuleStub
    from ansible.module_utils.common.network import get_exception # pylint: disable=protected-access
    import sys
    import io
    import contextlib

    #when one of these is returned, we'll think that it's successful, instead of expecting no return.
    module_returns = ['ACCEPT', 'DROP']

    #define the test variables
    params = {'chain': 'INPUT'}

    #define the test bytes to return
    test_bytes = b'Chain INPUT (policy DROP)\n...\n'

   

# Generated at 2022-06-11 07:24:48.214731
# Unit test for function construct_rule

# Generated at 2022-06-11 07:24:52.774493
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert push_arguments('iptables', '-P', {'chain': 'INPUT', 'policy': 'DROP'}, make_rule=False) == ['iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-11 07:24:57.526172
# Unit test for function insert_rule
def test_insert_rule():
    params = dict(
        chain="OUTPUT",
        protocol='tcp',
        destination_port=8080,
        jump='ACCEPT',
        rule_num=5
    )
    cmd = push_arguments('iptables', '-I', params)

# Generated at 2022-06-11 07:25:04.114943
# Unit test for function get_chain_policy
def test_get_chain_policy():
    class Module(object):
        def __init__(self, command, check_rc):
            self.rc = 0
            self.out = r'Chain INPUT (policy ACCEPT) '
            self.err = ''
        def run_command(self, cmd, check_rc):
            return self.rc, self.out, self.err

    params = dict(
        chain="INPUT"
    )
    m = Module(None, True)
    assert get_chain_policy(None, m, params) == 'ACCEPT'



# Generated at 2022-06-11 07:25:06.142353
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', {}, {'chain': 'INPUT'}) == None


# Generated at 2022-06-11 07:25:18.208936
# Unit test for function push_arguments
def test_push_arguments():
    params = {
        'chain': 'INPUT',
        'table': 'filter',
        'rule_num': '1',
        'jump': 'DROP',
        'source': '8.8.8.8',
        'reject_with': None
    }
    assert push_arguments('iptables', '-I', params) == [
        'iptables',
        '-t', 'filter',
        '-I', 'INPUT',
        '1',
        '-s', '8.8.8.8',
        '-j', 'DROP'
    ]

# Generated at 2022-06-11 07:25:29.019401
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments(BINS['ipv4'], '-I', dict(table='filter', chain='INPUT', rule_num=2)) == \
        ['iptables', '-t', 'filter', '-I', 'INPUT', '2']
    assert push_arguments(BINS['ipv4'], '-A', dict(table='filter', chain='INPUT')) == \
        ['iptables', '-t', 'filter', '-A', 'INPUT']
    assert push_arguments(BINS['ipv4'], '-A', dict(table='filter', chain='INPUT'), False) == \
        ['iptables', '-t', 'filter', '-A', 'INPUT']

# Generated at 2022-06-11 07:25:49.362258
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments('iptables', '-A', dict(
        chain='INPUT',
        protocol='tcp',
        destination_port=80,
        ctstate='NEW',
        table='filter',
        jump='ACCEPT',
        syn='match',
        comment='Accept new SSH connections.',
    )) == [
        'iptables', '-t', 'filter', '-A', 'INPUT', '-p', 'tcp', '--dport',
        '80', '--syn', '-m', 'conntrack', '--ctstate', 'NEW', '-j',
        'ACCEPT', '-m', 'comment', '--comment', 'Accept new SSH connections.'
    ]



# Generated at 2022-06-11 07:25:55.307072
# Unit test for function append_rule
def test_append_rule():
    iptables_path = "iptables"
    module = FauxAnsibleModule()
    params = {
'chain': 'INPUT',
'destination': '8.8.8.8',
'jump': 'DROP'
}
    cmd = push_arguments(iptables_path, '-A', params)
    module.run_command(cmd, check_rc=True)

# Generated at 2022-06-11 07:25:57.024551
# Unit test for function flush_table
def test_flush_table():
    assert flush_table(iptables_path, module, params) == None


# Generated at 2022-06-11 07:26:10.067097
# Unit test for function construct_rule
def test_construct_rule():
    src_port = '1024'
    dst_port = '65534'
    rule = construct_rule(dict(
        ip_version='ipv4',
        protocol='tcp',
        source='8.8.8.4',
        destination='8.8.8.3',
        jump='ACCEPT',
        source_port=src_port,
        destination_port=dst_port,
        syn='match',
    ))
    is_valid = (
        rule ==
        ['-p', 'tcp', '-s', '8.8.8.4', '-d', '8.8.8.3', '--source-port', src_port,
         '--destination-port', dst_port, '--syn', '-j', 'ACCEPT']
    )
    assert is_valid




# Generated at 2022-06-11 07:26:18.583405
# Unit test for function get_chain_policy
def test_get_chain_policy():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(
        argument_spec=dict(
            chain=dict(required=True),
            policy=dict(required=True),
            table=dict(required=True),
            ip_version=dict(required=True),
        )
    )
    test_params = dict(
        chain='INPUT',
        table='filter',
        ip_version='ipv4',
    )
    test_iptables_path = '/usr/sbin/iptables'
    assert get_chain_policy(test_iptables_path, test_module, test_params) == 'ACCEPT'



# Generated at 2022-06-11 07:26:24.375987
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule_tcp_flags = []
    param = {}
    param = {'flags': ['ACK', 'RST', 'SYN', 'FIN'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}
    append_tcp_flags(rule_tcp_flags, param, 'Tcp-flags')
    assert  rule_tcp_flags == ['Tcp-flags', 'ACK,RST,SYN,FIN', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-11 07:26:33.062917
# Unit test for function construct_rule

# Generated at 2022-06-11 07:26:43.600893
# Unit test for function push_arguments
def test_push_arguments():
    params = dict(
        table='nat',
        chain='PREROUTING',
        ip_version='ipv4',
        action='-I',
        rule_num='1',
        protocol='tcp',
        destination_port='80',
        jump='REDIRECT',
        to_ports='8600',
        comment='Redirect web traffic to port 8600')
    cmd = push_arguments('/sbin/iptables', '-I', params)

# Generated at 2022-06-11 07:26:45.975712
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'INPUT'}) == 'ACCEPT'



# Generated at 2022-06-11 07:26:57.089700
# Unit test for function flush_table
def test_flush_table():
    class TestModule(object):
        def __init__(self):
            self.params = dict(
                chain='INPUT',
                flush=True,
                table='filter',
                )

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

        def run_command(self, args, **kwargs):
            self.last_args = args
            self.last_kwargs = kwargs
            return (0, '', '')

    iptables_path = 'iptables'
    module = TestModule()

# Generated at 2022-06-11 07:27:38.111941
# Unit test for function construct_rule
def test_construct_rule():
    rule = construct_rule({
        'protocol': 'tcp',
        'source': '10.0.0.9', 'destination': '10.0.0.1',
        'tcp_flags': {'flags': ['ALL'], 'flags_set': ['SYN']},
        'source_port': 80, 'destination_port': 80,
        'match_set': 'test', 'match_set_flags': 'src',
        'wait': '10',
    })

# Generated at 2022-06-11 07:27:42.268636
# Unit test for function check_present
def test_check_present():
    try:
        rb = check_present('iptables', module, ['INPUT'], 'ACCEPT', {})
        assert rb == True
    except AssertionError:
        print("test_check_present fail")

# Generated at 2022-06-11 07:27:48.922898
# Unit test for function construct_rule

# Generated at 2022-06-11 07:27:57.450882
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(
        argument_spec=dict(
            table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw']),
            ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
            chain=dict(type='str', default='INPUT'),
            policy=dict(type='str', default='DROP', choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
        ),
    )
    iptables_path = BINS[dict(ipv4='iptables', ipv6='ip6tables').get(module.params['ip_version'])]
    params = module.params
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)


# Generated at 2022-06-11 07:28:08.419197
# Unit test for function construct_rule
def test_construct_rule():
    def test(params, expected):
        rule = construct_rule(params)
        assert rule == expected


# Generated at 2022-06-11 07:28:19.900285
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = mock.Mock()
    params = dict()
    params['chain'] = 'INPUT'
    params['table'] = 'filter'
    params['ip_version'] = 'ipv4'
    out = 'Chain INPUT (policy ACCEPT)\n\
    target     prot opt source               destination \n\
    ACCEPT     all  --  anywhere             anywhere \n\
    ACCEPT     all  --  anywhere             anywhere \n\
    ACCEPT     all  --  anywhere             anywhere'
    retval = 0
    module.run_command.return_value = (retval, out, '')
    policy = get_chain_policy('/bin/iptables', module, params)
    assert policy == 'ACCEPT'
# End unit test for get_chain_policy



# Generated at 2022-06-11 07:28:29.468460
# Unit test for function construct_rule
def test_construct_rule():
  assert construct_rule(dict(table='filter', chain='INPUT', match=['state', 'conntrack'], ctstate=['NEW', 'RELATED', 'ESTABLISHED'], in_interface='eth0', jump='ACCEPT')) == ['--table', 'filter', '--append', 'INPUT', '-m', 'conntrack', '--ctstate', 'NEW,RELATED,ESTABLISHED', '-m', 'state', '--state', 'NEW,RELATED,ESTABLISHED', '-i', 'eth0', '-j', 'ACCEPT']

# Generated at 2022-06-11 07:28:30.585675
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, dict(chain='INPUT', table='filter')) == 'ACCEPT'



# Generated at 2022-06-11 07:28:35.395412
# Unit test for function set_chain_policy
def test_set_chain_policy():
  module=AnsibleModule(argument_spec=dict(chain='INPUT', policy='DROP'))
  params=dict(chain='INPUT', policy='DROP')
  set_chain_policy(None, module, params)
  assert module.exit_json.called
  assert module.exit_json.call_args[0][0]['changed'] == True
  assert module.exit_json.call_args[0][0]['failed'] == False



# Generated at 2022-06-11 07:28:37.160115
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", "INPUT") == "ACCEPT"



# Generated at 2022-06-11 07:29:04.434092
# Unit test for function insert_rule
def test_insert_rule():
    iptables_path= '/sbin/iptables'
    module = AnsibleModule({})
    params = {}
    params['table'] = 'nat'
    params['chain'] = 'PREROUTING'
    params['protocol'] = 'tcp'
    params['destination_port'] = '80'
    params['jump'] = 'REDIRECT'
    params['to_ports'] = '8600'
    params['comment'] = 'Redirect web traffic to port 8600'
    params['rule_num'] = 5
    cmd = push_arguments(iptables_path, '-I', params)
    module.run_command(cmd, check_rc=True)



# Generated at 2022-06-11 07:29:12.687814
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 07:29:16.396818
# Unit test for function set_chain_policy
def test_set_chain_policy():
    rule = set_chain_policy('/usr/bin/iptables', None, dict(table='filter', chain='INPUT', policy='DROP'))
    assert rule == ['/usr/bin/iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']



# Generated at 2022-06-11 07:29:21.494537
# Unit test for function remove_rule
def test_remove_rule():
    rule = ['-D', 'INPUT', '-s', '8.8.8.8', '-p', 'tcp', '-j', 'DROP']
    assert remove_rule('iptables', None, rule) == ['iptables', '-D', 'INPUT', '-s', '8.8.8.8', '-p', 'tcp', '-j', 'DROP']



# Generated at 2022-06-11 07:29:22.362810
# Unit test for function get_chain_policy
def test_get_chain_policy():
    get_chain_policy()



# Generated at 2022-06-11 07:29:26.811116
# Unit test for function get_iptables_version
def test_get_iptables_version():
    class MockModule:
        def run_command(self, cmd, check_rc):
            return 0, 'v1.4.20', None

    iptables_path = '/sbin/iptables'
    module = MockModule()
    assert get_iptables_version(iptables_path, module) == '1.4.20'


# Generated at 2022-06-11 07:29:36.775492
# Unit test for function main
def test_main():
    # This is a very basic test to make sure we are doing at least
    # a bit of validation on input
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(default='present', choices=['absent', 'present']),
            table=dict(default='filter', choices=['filter', 'nat', 'mangle', 'raw', 'security']),
            ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
            chain=dict(required=True),
            rule=dict(required=True, type='list'),
        ),
        supports_check_mode=True
    )
    params = module.params
    rule = " ".join(params['rule'])


# Generated at 2022-06-11 07:29:45.622523
# Unit test for function main
def test_main():
    # Unit test for function main
    from ansible.modules.network.firewall.iptables import main


# Generated at 2022-06-11 07:29:49.382410
# Unit test for function flush_table
def test_flush_table():
    module = AnsibleModule(argument_spec={
        'table': {'default': 'filter'},
        'chain': {'default': 'INPUT'},
        })
    result = flush_table('iptables', module, module.params)
    assert result is None



# Generated at 2022-06-11 07:29:58.170881
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-11 07:30:54.502296
# Unit test for function construct_rule
def test_construct_rule():
    """
    Unit test for function construct_rule
    """
    params = dict(
        ip_version='ipv4',
        chain='INPUT',
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP'
        )
    rule = construct_rule(params)
    assert rule == ['-A', 'INPUT', '-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP']

    params['comment'] = 'test comment'
    rule = construct_rule(params)
    assert rule == ['-A', 'INPUT', '-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP',
                    '-m', 'comment','--comment','test comment']

    params