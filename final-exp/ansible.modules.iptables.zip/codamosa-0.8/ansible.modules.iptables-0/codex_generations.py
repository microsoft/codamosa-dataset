

# Generated at 2022-06-11 07:21:13.427298
# Unit test for function append_match_flag

# Generated at 2022-06-11 07:21:16.315402
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    assert append_tcp_flags([], {'flags': ['ALL'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}, 'flag') == ['flag', 'ALL', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-11 07:21:23.696532
# Unit test for function main

# Generated at 2022-06-11 07:21:30.679179
# Unit test for function remove_rule
def test_remove_rule():
    mock_module = AnsibleModule({
        'table': 'filter',
        'chain': 'INPUT',
        'ip_version': 'ipv4',
        'protocol': 'udp',
        'destination_port': '53',
        'jump': 'ACCEPT',
        'state': 'absent',
        })
    module = mock_module
    iptables_path = 'iptables'
    params = dict(
        table='filter',
        chain='INPUT',
        ip_version='ipv4',
        protocol='udp',
        destination_port='53',
        jump='ACCEPT',
        state='absent',
    )
    remove_rule(iptables_path, module, params)



# Generated at 2022-06-11 07:21:34.805942
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {"flags": ["ALL"], "flags_set": ["ACK", "RST", "SYN", "FIN"]}
    append_tcp_flags(rule, param, "--tcp-flags")
    assert rule == ["--tcp-flags", "ALL", "ACK,RST,SYN,FIN"]



# Generated at 2022-06-11 07:21:41.170557
# Unit test for function push_arguments
def test_push_arguments():
    assert push_arguments(
        '/usr/sbin/iptables',
        '-I',
        {
            'chain': 'INPUT',
            'table': 'filter',
            'rule_num': '42',
            'ctstate': ['NEW', 'ESTABLISHED'],
        },
    ) == [
        '/usr/sbin/iptables',
        '-t', 'filter',
        '-I', 'INPUT', '42',
        '-m', 'conntrack',
        '--ctstate', 'NEW,ESTABLISHED',
    ]



# Generated at 2022-06-11 07:21:46.255532
# Unit test for function construct_rule
def test_construct_rule():
  rule = construct_rule({
    'protocol': 'tcp',
    'source': None,
    'destination': None,
    'jump': 'ACCEPT',
    'ip_version': 'ipv4'
  })
  assert(rule == ['-p', 'tcp', '-j', 'ACCEPT'])
  rule = construct_rule({
    'protocol': None,
    'source': '1.2.3.4',
    'destination': None,
    'jump': 'ACCEPT',
    'ip_version': 'ipv4'
  })
  assert(rule == ['-s', '1.2.3.4', '-j', 'ACCEPT'])

# Generated at 2022-06-11 07:21:57.284139
# Unit test for function construct_rule
def test_construct_rule():
    base_rule = ['iptables', '-w', '-p', 'tcp', '-s', '1.2.3.4', '-d', '2.3.4.5', '-m', 'tcp', '--sport', '1234', '--dport', '5678', '-j', 'ACCEPT']
    assert construct_rule({
        'ip_version': 'ipv4',
        'wait': None,
        'protocol': 'tcp',
        'source': '1.2.3.4',
        'destination': '2.3.4.5',
        'match': 'tcp',
        'jump': 'ACCEPT',
        'source_port': 1234,
        'destination_port': 5678
    }) == base_rule

    base_rule.extend

# Generated at 2022-06-11 07:22:07.753152
# Unit test for function check_present
def test_check_present():
    assert check_present([], {'run_command': run_command_mock}, {
        'chain': 'INPUT',
        'jump': 'ACCEPT',
        'match': 'tcp',
        'protocol': 'tcp',
        'destination_port': '22',
    })
    assert not check_present([], {'run_command': run_command_mock}, {
        'chain': 'INPUT',
        'jump': 'ACCEPT',
        'match': 'tcp',
        'protocol': 'tcp',
        'destination_port': '12345',
    })



# Generated at 2022-06-11 07:22:09.603612
# Unit test for function append_rule
def test_append_rule():
    assert(test_append_rule == append_rule)
    return 0


# Generated at 2022-06-11 07:22:32.909284
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule({})

# Generated at 2022-06-11 07:22:40.021965
# Unit test for function insert_rule
def test_insert_rule():
    import tempfile
    params = {'chain': 'INPUT', 'table': 'mangle', 'protocol': 'tcp',
        'destination_port': '8080', 'jump': 'ACCEPT', 'action': 'insert',
        'rule_num': '5', 'ip_version': 'ipv4'}
    cmd = push_arguments(BINS['ipv4'], '-I', params)
    print(cmd)
    #module.run_command(cmd, check_rc=True)


# Generated at 2022-06-11 07:22:45.321128
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'INPUT'}) is None
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'UNKNOWN'}) is None
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'ACCEPT'}) == 'ACCEPT'
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'DROP'}) == 'DROP'
    assert get_chain_policy(None, None, {'table': 'filter', 'chain': 'QUEUE'}) == 'QUEUE'



# Generated at 2022-06-11 07:22:58.092410
# Unit test for function construct_rule

# Generated at 2022-06-11 07:23:00.643744
# Unit test for function check_present
def test_check_present():
    assert check_present('/sbin/iptables', '-C', {'1':'2', 'table':'filter', 'chain':'INPUT'}) == True


# Generated at 2022-06-11 07:23:12.538981
# Unit test for function main

# Generated at 2022-06-11 07:23:24.410546
# Unit test for function main

# Generated at 2022-06-11 07:23:32.014025
# Unit test for function main

# Generated at 2022-06-11 07:23:34.656060
# Unit test for function get_chain_policy
def test_get_chain_policy():
    params = {'chain': 'OUTPUT', 'table': 'filter'}
    assert(get_chain_policy('/sbin/iptables', {}, params) == 'ACCEPT')



# Generated at 2022-06-11 07:23:41.264897
# Unit test for function append_match_flag
def test_append_match_flag():
    rule = []
    append_match_flag(rule, 'match', '--syn', True)
    assert rule == ['--syn']
    rule = []
    append_match_flag(rule, 'negate', '--syn', True)
    assert rule == ['!', '--syn']
    rule = []
    append_match_flag(rule, 'match', '--match-set', False)
    assert rule == ['--match-set']
    rule = []
    append_match_flag(rule, 'negate', '--match-set', False)
    assert rule == ['--match-set', 'negate']


# Generated at 2022-06-11 07:24:04.268995
# Unit test for function get_chain_policy

# Generated at 2022-06-11 07:24:14.798469
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule({}) == []

# Generated at 2022-06-11 07:24:26.258991
# Unit test for function get_iptables_version
def test_get_iptables_version():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule()
    mod.run_command = MagicMock(return_value=(0, 'iptables v1.0.0', ''))
    assert get_iptables_version('/bin/iptables', mod) == '1.0.0'
    mod.run_command = MagicMock(return_value=(0, 'iptables v1.1.1 (nf_tables)', ''))
    assert get_iptables_version('/bin/iptables', mod) == '1.1.1'
    mod.run_command = MagicMock(return_value=(0, 'iptables v1.4.20 (nf_tables)', ''))

# Generated at 2022-06-11 07:24:37.829262
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        command='append',
        chain='INPUT',
        protocol='tcp',
        destination_port=80,
        ctstate='NEW',
        syn='match',
        jump='ACCEPT',
        comment='Accept new SSH connections.',
        ip_version='ipv4',
    )
    rule = construct_rule(params)
    assert rule == ['-p', 'tcp', '-m', 'conntrack',
                    '--ctstate', 'NEW', '--syn',
                    '-j', 'ACCEPT', '-m', 'comment',
                    '--comment', 'Accept new SSH connections.']
    params.update(dict(syn='negate'))
    rule = construct_rule(params)

# Generated at 2022-06-11 07:24:48.437051
# Unit test for function insert_rule
def test_insert_rule():
    ipv4_path = 'iptables'
    # Generate the test rule
    test_rule = dict()
    test_rule['rule_num'] = None
    test_rule['protocol'] = 'tcp'
    test_rule['destination_port'] = '20'
    test_rule['jump'] = 'ACCEPT'
    # Generate the test params
    test_params = dict()
    test_params['action'] = 'insert'
    test_params['chain'] = 'INPUT'
    test_params['table'] = 'filter'
    test_params['ip_version'] = 'ipv4'
    test_params['rule'] = test_rule
    # Generate a test module
    test_module = AnsibleModule(argument_spec=dict())
    test_module.params = test_params
   

# Generated at 2022-06-11 07:24:59.553342
# Unit test for function check_present

# Generated at 2022-06-11 07:25:10.656394
# Unit test for function append_rule

# Generated at 2022-06-11 07:25:12.220772
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:25:24.132830
# Unit test for function main

# Generated at 2022-06-11 07:25:26.530273
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version("/usr/bin/iptables","") == "1.4.21"


# Generated at 2022-06-11 07:25:48.402990
# Unit test for function append_param
def test_append_param():
    rule = []
    append_param(rule, 'test', '--test', False)
    assert rule == ['--test', 'test'], "test_append_param failed"
    rule = []
    append_param(rule, '!test', '--test', False)
    assert rule == ['!', '--test', 'test'], "test_append_param failed"
    rule = []
    append_param(rule, ['test1', '!test2', 'test3'], '--test', True)
    assert rule == ['--test', 'test1', '--test', '!', '--test', 'test2', '--test', 'test3'], "test_append_param failed"
test_append_param()


# Generated at 2022-06-11 07:25:58.893351
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule(argument_spec=dict(
        ip_version=dict(default='ipv4', choices=['ipv4', 'ipv6']),
        table=dict(default='filter', choices=['filter', 'raw', 'security', 'nat', 'mangle']),
        chain=dict(required=True),
        policy=dict(required=True),
    ))
    set_chain_policy('iptables', module, dict(
        table='filter',
        chain='test_chain',
        policy='DROP',
    ))
    set_chain_policy('iptables', module, dict(
        table='filter',
        chain='test_chain',
        policy='ACCEPT',
    ))



# Generated at 2022-06-11 07:26:08.619149
# Unit test for function remove_rule
def test_remove_rule():
    print("test")
    iptables_path = 'iptables'
    module = AnsibleModule
    params={ 'table': 'filter',
            'chain': 'INPUT',
            'ip_version': 'ipv4',
            'protocol': 'tcp',
            'destination_port': '22',
            'ctstate': 'NEW',
            'syn': 'match',
            'jump': 'ACCEPT',
            'comment': 'Accept new SSH connections.'}
    cmd = push_arguments(iptables_path, '-D', params)
    print(cmd)



# Generated at 2022-06-11 07:26:19.038934
# Unit test for function construct_rule
def test_construct_rule():
    params = dict()

    assert construct_rule(params) == []

    params = dict(wait='3')
    assert construct_rule(params) == ['-w', '3']

    params = dict(protocol='tcp')
    assert construct_rule(params) == ['-p', 'tcp']

    params = dict(protocol=None)
    assert construct_rule(params) == []

    params = dict(protocol='!tcp')
    assert construct_rule(params) == ['!', '-p', 'tcp']

    params = dict(jump='ACCEPT')
    assert construct_rule(params) == ['-j', 'ACCEPT']

    params = dict(jump='ACCEPT', protocol=None)
    assert construct_rule(params) == ['-j', 'ACCEPT']


# Generated at 2022-06-11 07:26:24.753229
# Unit test for function construct_rule

# Generated at 2022-06-11 07:26:31.702252
# Unit test for function get_chain_policy
def test_get_chain_policy():
    from ansible.module_utils.basic import AnsibleModule
    ips = dict(
               ipv4='iptables',
               ipv6='ip6tables',
              )
    module = AnsibleModule(argument_spec=dict())
    for i in ips:
        ip = ips[i]
        action = '-L'
        params = dict(
                      chain='INPUT',
                      table='filter',
                      ip_version=i,
                     )
        cmd = push_arguments(ip, action, params, make_rule=False)
        rc, out, _ = module.run_command(cmd, check_rc=True)
        chain_header = out.split("\n")[0]
        result = re.search(r'\(policy ([A-Z]+)\)', chain_header)
       

# Generated at 2022-06-11 07:26:35.562773
# Unit test for function construct_rule
def test_construct_rule():
    test_rule = construct_rule(dict(
        source='8.8.8.8',
        jump='DROP',
    ))
    assert test_rule == ['-s', '8.8.8.8', '-j', 'DROP']



# Generated at 2022-06-11 07:26:37.340530
# Unit test for function check_present
def test_check_present():
    assert check_present(None, None, {'chain': 'INPUT', 'table': 'nat'}) is True



# Generated at 2022-06-11 07:26:46.423240
# Unit test for function remove_rule
def test_remove_rule():
    # empty rule
    iptables_path = "iptables"
    module = create_module()
    params = {"ip_version": "ipv4", "table": "filter", "chain": "INPUT", "jump": "ACCEPT", "action": "remove"}
    assert(remove_rule(iptables_path, module, params) == 0)
    # rule with existing jump
    module = create_module()
    params = {"ip_version": "ipv4", "table": "filter", "chain": "INPUT", "jump": "ACCEPT", "action": "remove"}
    assert(remove_rule(iptables_path, module, params) == 0)



# Generated at 2022-06-11 07:26:57.492799
# Unit test for function set_chain_policy
def test_set_chain_policy():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.compat.version import LooseVersion
    import os

    module = AnsibleModule(argument_spec=dict(
        ip_version=dict(required=True, choices=['ipv4', 'ipv6']),
        chain=dict(required=True),
        policy=dict(required=True, choices=['ACCEPT', 'DROP', 'QUEUE', 'RETURN']),
    ))
    ip_version = module.params['ip_version']
    chain = 'INPUT'
    policy = 'DROP'
    iptables_path = os.path.join(os.getcwd(), 'iptables')
    set_chain_policy(iptables_path, module, params)


# Generated at 2022-06-11 07:27:20.436745
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', {}, {'chain': 'INPUT','policy': 'ACCEPT'}) == 'ACCEPT'
    assert get_chain_policy('iptables', {}, {'chain': 'INPUT','policy': 'DROP'}) == 'DROP'
    assert get_chain_policy('iptables', {}, {'chain': 'INPUT','policy': 'RETURN'}) == None


# Generated at 2022-06-11 07:27:31.421931
# Unit test for function main
def test_main():
    import sys
    import os
    test_args = dict(
        chain='INPUT',
        jump='ACCEPT',
        source='192.168.0.0/24',
        destination='192.168.1.0/24',
        )

    test_args_str=' '.join('--{0} {1}'.format(k,v) for k,v in test_args.iteritems())

# Generated at 2022-06-11 07:27:42.051378
# Unit test for function check_present
def test_check_present():
    iptables_path = '/usr/bin/iptables'
    params = {'table': 'filter',
              'chain': 'INPUT',
              'protocol': 'tcp',
              'destination_port': 80,
              'ctstate': 'NEW',
              'syn': 'match',
              'jump': 'ACCEPT',
              'comment': "Accept new TCP connections"}
    cmd = push_arguments(iptables_path, '-C', params)

# Generated at 2022-06-11 07:27:47.521178
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/usr/sbin/iptables'
    module = AnsibleModule(argument_spec=dict(chain=dict(required=True)))
    params = dict(chain='INPUT', policy='DROP', table='filter')
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    assert cmd == ['/usr/sbin/iptables', '-t', 'filter', '-P', 'INPUT', 'DROP']
    #assert module.run_command(cmd, check_rc=True) == 0


# Generated at 2022-06-11 07:27:56.897204
# Unit test for function insert_rule

# Generated at 2022-06-11 07:28:08.099854
# Unit test for function main

# Generated at 2022-06-11 07:28:19.532085
# Unit test for function construct_rule
def test_construct_rule():
    # Wait option
    wait_parameters = dict(
        wait='20',
        ip_version='ipv4'
    )
    assert construct_rule(wait_parameters) == ['-w', '20']

    # IPv6 - Wait option
    wait_parameters = dict(
        wait='20',
        ip_version='ipv6'
    )
    assert construct_rule(wait_parameters) == ['-w', '20']

    # Protocol option
    protocol_parameters = dict(
        protocol='tcp',
        ip_version='ipv4'
    )
    assert construct_rule(protocol_parameters) == ['-p', 'tcp']

    # Source option

# Generated at 2022-06-11 07:28:29.152604
# Unit test for function construct_rule

# Generated at 2022-06-11 07:28:32.645104
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        protocol='tcp',
        source='8.8.8.8',
        jump='DROP',
        comment='Test comment',
    )
    assert construct_rule(params) == ['-p', 'tcp', '-s', '8.8.8.8', '-j', 'DROP', '-m', 'comment', '--comment', 'Test comment']



# Generated at 2022-06-11 07:28:37.336536
# Unit test for function flush_table
def test_flush_table():
    xtable_path = '/usr/sbin/iptables'
    module = ''
    params = dict(
        table='filter',
        chain='INPUT'
        )
    flush_table(xtable_path, module, params)
    pass




# Generated at 2022-06-11 07:29:32.907782
# Unit test for function construct_rule
def test_construct_rule():
    '''
    Test of the construct_rule function
    '''

    params = {}
    params['ip_version'] = 'ipv4'
    params['wait'] = '20'
    params['jump'] = None
    params['reject_with'] = 'tcp-reset'
    params['protocol'] = 'tcp'
    params['chain'] = 'INPUT'
    params['table'] = 'filter'
    params['state'] = 'present'
    params['action'] = 'insert'
    params['source'] = '127.0.0.1'
    params['destination'] = None
    params['in_interface'] = None
    params['out_interface'] = None
    params['fragment'] = None
    params['set_counters'] = None
    params['source_port'] = None


# Generated at 2022-06-11 07:29:37.381264
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = MagicMock(name='AnsibleModule')
    cmd = ['iptables', '--version']
    module.run_command.return_value = [0, 'v1.6.0', '']
    result = get_iptables_version('iptables', module)
    assert result == '1.6.0'



# Generated at 2022-06-11 07:29:45.240724
# Unit test for function construct_rule
def test_construct_rule():
    from ansible.module_utils import basic
    import sys
    import json

    # parameters stored in a file
    with open('test_iptables_params.json') as f:
        test_params = json.load(f)

    # create an instance of the AnsibleModule
    module = basic.AnsibleModule(
        argument_spec=test_params['argument_spec']
    )

    # load parameters into module.params
    module.params = test_params['params']

    # print construct_rule(module.params)
    # print construct_rule(test_params["params"])
    print(json.dumps(construct_rule(test_params['params']), indent=4))



# Generated at 2022-06-11 07:29:54.824625
# Unit test for function get_chain_policy
def test_get_chain_policy():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.iptables import get_chain_policy
    module = None
    params = {
        'chain': 'INPUT',
        'state': 'present',
        'table': 'filter'
    }

    class MockModule(AnsibleModule):
        def run_command(self, cmd, check_rc=False):
            cmd_str = ' '.join(cmd)
            print("Running command: %s" % cmd_str)
            if cmd_str == "iptables -t filter -L INPUT":
                return 0, "Chain INPUT (policy ACCEPT)\n", None
            else:
                return 1, "Command not found", None



# Generated at 2022-06-11 07:29:57.823208
# Unit test for function remove_rule
def test_remove_rule():
    iptables_path = '/usr/bin/iptables'
    module = AnsibleModule()
    params = dict(
        table='filter',
        chain='INPUT',
        protocol='tcp',
        destination_port=['80'],
        jump='ACCEPT',
        rule_num='5'
    )
    cmd = push_arguments(iptables_path, '-D', params)
    print (cmd)


# Generated at 2022-06-11 07:30:00.047547
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None,None,{'table':'mangle','chain':'INPUT','policy':'ACCEPT'}) == 'ACCEPT'


# Generated at 2022-06-11 07:30:07.530799
# Unit test for function construct_rule
def test_construct_rule():
    module = AnsibleModule({
        'chain': 'OUTPUT',
        'protocol': 'tcp',
        'destination_port': '8080',
        'jump': 'ACCEPT',
        'action': 'insert',
        'rule_num': 5,
        'state': 'present',
        'wait': 5,
        'comment': 'testrule',
        'syn': 'negate',
    })
    params = module.params
    assert construct_rule(params) == ['-w5', '-p', 'tcp', '--dport', '8080', '-m', 'comment', '--comment', 'testrule', '-j', 'ACCEPT']



# Generated at 2022-06-11 07:30:17.300234
# Unit test for function insert_rule
def test_insert_rule():
    cmd = ["iptables", "-I", "INPUT","-s","192.168.0.0/24","-p","tcp","-d","192.168.0.2","-j","ACCEPT"]
    card_ip = "192.168.0.2"
    rule_num = 5
    ip_version = "ipv4"

    iptables_path = BINS[ip_version]

    action = 'insert'
    chain = 'INPUT'
    protocol = 'tcp'
    jump = 'ACCEPT'
    rule_num = 5
    source = '192.168.0.0/24'
    destination = card_ip


# Generated at 2022-06-11 07:30:22.764785
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT'}) == 'INPUT'
    assert get_chain_policy(None, None, {'chain': 'OUTPUT'}) == 'OUTPUT'
    assert get_chain_policy(None, None, {'chain': 'FORWARD'}) == 'FORWARD'
    assert get_chain_policy(None, None, {'chain': 'other'}) == 'other'



# Generated at 2022-06-11 07:30:24.537458
# Unit test for function check_present
def test_check_present():
    assert check_present("iptables", "module", "params") == true
