

# Generated at 2022-06-11 07:21:31.706997
# Unit test for function append_rule
def test_append_rule():
    append_rule('', '', '', '', '', '')



# Generated at 2022-06-11 07:21:34.582067
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule(argument_spec={})
    if LooseVersion(get_iptables_version('iptables', module)) < LooseVersion('1.4.20'):
        print("iptables does not support wait lock")
        return False
    return True



# Generated at 2022-06-11 07:21:38.704284
# Unit test for function flush_table
def test_flush_table():
    params = {
        'table': 'filter',
        'chain': 'INPUT'
    }
    assert push_arguments('iptables', '-F', params, make_rule=False) == ['iptables', '-t', 'filter', '-F', 'INPUT']

# Generated at 2022-06-11 07:21:47.599962
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    result = []
    append_tcp_flags(result, {'flags': ['ALL'], 'flags_set': ['ACK']}, '--tcp-flags')
    append_tcp_flags(result, {'flags': ['ALL', 'ACK', 'RST'], 'flags_set': ['ACK', 'RST', 'SYN', 'FIN']}, '--tcp-flags')
    assert result == ['--tcp-flags', 'ALL', 'ACK', '--tcp-flags', 'ALL,ACK,RST', 'ACK,RST,SYN,FIN']



# Generated at 2022-06-11 07:21:59.448836
# Unit test for function construct_rule

# Generated at 2022-06-11 07:22:08.644069
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        ip_version='ipv4',
        protocol='tcp',
        source='1.1.1.1/24',
        destination='8.8.8.8/24',
        jump='DROP',
        state='present',
        set_counters='5 4',
    )
    rule = construct_rule(params)
    assert rule == [
        '-p', params['protocol'],
        '-s', params['source'],
        '-d', params['destination'],
        '-j', params['jump'],
        '-c', params['set_counters'],
    ]

# Generated at 2022-06-11 07:22:17.010933
# Unit test for function main
def test_main():
    output = dict(failed=False, changed=False,
                  ip_version='ipv4', table='filter',
                  chain=None, flush=None,
                  rule='', state='present')
    parsed_args = dict(ip_version='ipv4', table='filter',
                       chain=None, flush=None,
                       rule='', state='present')
    check_output = dict(failed=False, changed=True,
                        ip_version='ipv4', table='filter',
                        chain=None, flush=None,
                        rule='', state='present')

# Generated at 2022-06-11 07:22:24.236141
# Unit test for function get_iptables_version
def test_get_iptables_version():
    params = dict(
        action='not used',
        chain='not used',
        table='not used',
    )
    p = dict(
        path='not used',
        ip_version='not used',
    )
    class MockModule:
        run_command = return_run_command()
    class MockModule_s1:
        run_command = return_run_command('iptables v1.8.2 (nf_tables)')
    class MockModule_s2:
        run_command = return_run_command('iptables v1.6.0')

    m = MockModule()
    assert get_iptables_version('/bin/iptables', m) == '1.4.21'

    m = MockModule_s1()

# Generated at 2022-06-11 07:22:31.108206
# Unit test for function construct_rule

# Generated at 2022-06-11 07:22:39.236026
# Unit test for function append_tcp_flags
def test_append_tcp_flags():
    rule = []
    param = {
        'flags': ['ACK', 'RST', 'SYN', 'FIN'],
        'flags_set': ['ACK', 'RST', 'SYN', 'FIN']
    }
    append_tcp_flags(rule, param, '--tcp-flags')
    assert '--tcp-flags' in rule
    assert 'ACK,RST,SYN,FIN' in rule
    assert 'ACK,RST,SYN,FIN' in rule


# Generated at 2022-06-11 07:22:59.285313
# Unit test for function check_present
def test_check_present():
    assert check_present('/bin/iptables', {}, {'ip_version': 'ipv4', 'table': 'filter', 'chain': 'INPUT', 'protocol': 'tcp', 'source': '8.8.8.8', 'jump': 'DROP'}) == False


# Generated at 2022-06-11 07:23:02.743490
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'DROP'}) == 'DROP'
    assert get_chain_policy(None, None, {'chain': 'INPUT', 'policy': 'not-a-policy'}) == None



# Generated at 2022-06-11 07:23:11.689286
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy("iptables", "module", dict(chain="INPUT", table="mangle")) is None
    assert get_chain_policy("iptables", "module", dict(chain="INPUT", table="filter")) == "ACCEPT"
    assert get_chain_policy("iptables", "module", dict(chain="FORWARD", table="filter")) == "ACCEPT"
    assert get_chain_policy("iptables", "module", dict(chain="OUTPUT", table="filter")) == "ACCEPT"
    assert get_chain_policy("iptables", "module", dict(chain="user", table="filter")) is None



# Generated at 2022-06-11 07:23:20.287606
# Unit test for function append_match_flag
def test_append_match_flag():
    temp = []
    append_match_flag(temp, "match", "foo", True)
    assert temp == ['foo']
    temp = []
    append_match_flag(temp, "negate", "foo", True)
    assert temp == ['!', 'foo']
    temp = []
    append_match_flag(temp, "foo", "foo", True)
    assert temp == []
    temp = []
    append_match_flag(temp, "match", "foo", False)
    assert temp == ['foo']



# Generated at 2022-06-11 07:23:25.288134
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        source='10.0.0.1',
        jump='ACCEPT',
        comment=True,
    )
    expected_rule = ['-s', '10.0.0.1', '-j', 'ACCEPT', '-m', 'comment', '--comment']
    assert list(construct_rule(params)) == expected_rule



# Generated at 2022-06-11 07:23:28.246812
# Unit test for function get_chain_policy
def test_get_chain_policy():
    policy = get_chain_policy('/usr/bin/iptables', 'module',
                              {'chain': 'test', 'table': 'test'})
    if policy is not None:
        assert True
    else:
        assert False



# Generated at 2022-06-11 07:23:28.713528
# Unit test for function append_rule
def test_append_rule():
    return



# Generated at 2022-06-11 07:23:29.265353
# Unit test for function append_match_flag
def test_append_match_flag():

    pass


# Generated at 2022-06-11 07:23:37.389263
# Unit test for function main
def test_main():
    """ Unit Test for function main """

    # Test case for
    # - table=filter
    # - state=present
    # - action=append
    # - ip_version=ipv4
    # - chain=
    # - rule_num=
    # - protocol=
    # - wait=
    # - source=
    # - to_source=
    # - destination=
    # - to_destination=
    # - match=[]
    # - tcp_flags=dict(flags=[],flags_set=[])
    # - jump=
    # - gateway=
    # - log_prefix=
    # - log_level=
    # - goto=
    # - in_interface=
    # - out_interface=
    # - fragment=
    # - set_counters=
    # - source_port=

# Generated at 2022-06-11 07:23:42.636530
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = ''
    iptables_path = '/sbin/iptables'
    result = get_iptables_version(iptables_path, module)
    assert result == '1.4.21'


# Generated at 2022-06-11 07:23:59.254640
# Unit test for function get_iptables_version
def test_get_iptables_version():
    cmd = [iptables_path, '--version']
    rc, out, _ = module.run_command(cmd, check_rc=True)
    return out.split('v')[1].rstrip('\n')


# Generated at 2022-06-11 07:24:10.724710
# Unit test for function check_present
def test_check_present():
    failed_cases = []

# Generated at 2022-06-11 07:24:20.089231
# Unit test for function construct_rule
def test_construct_rule():
    params = {
        'protocol': 'tcp',
        'destination': '192.168.1.1',
        'destination_port': '80',
        'jump': 'ACCEPT',
        'ip_version': 'ipv4'
    }
    assert construct_rule(params) == [
        '-p', 'tcp',
        '-d', '192.168.1.1',
        '--dport', '80',
        '-j', 'ACCEPT'
    ]

    params = {
        'protocol': 'tcp',
        'destination': '192.168.1.1',
        'destination_port': None,
        'jump': 'ACCEPT',
        'ip_version': 'ipv4'
    }

# Generated at 2022-06-11 07:24:31.907509
# Unit test for function get_chain_policy
def test_get_chain_policy():
    def fake_module(rc, out, err):
        return dict(
            run_command=lambda x, **kwargs: (rc, out, err),
        )

    module = fake_module(0, (
        "Chain INPUT (policy ACCEPT)\n"
        "target     prot opt source               destination\n"
    ), '')
    assert 'ACCEPT' == get_chain_policy('/bin/true', module, dict(
        chain='INPUT',
        table='filter',
    ))

    module = fake_module(0, (
        "Chain INPUT (policy ACCEPT)\n"
        "target     prot opt source               destination\n"
    ), '')

# Generated at 2022-06-11 07:24:35.113970
# Unit test for function get_chain_policy
def test_get_chain_policy():
    assert get_chain_policy('iptables', 'ansible_module', {'policy': None, 'chain': 'OUTPUT'}) == 'ACCEPT'



# Generated at 2022-06-11 07:24:38.561841
# Unit test for function flush_table
def test_flush_table():
    iptables_path = 'iptables'
    module = AnsibleModule()
    params = dict(
        table='filter',
        chain='INPUT'
        )
    flush_table(iptables_path,module,params)


# Generated at 2022-06-11 07:24:39.943998
# Unit test for function append_rule
def test_append_rule():
    append_rule(iptables_path, module, params)



# Generated at 2022-06-11 07:24:51.997923
# Unit test for function construct_rule
def test_construct_rule():
    assert(construct_rule(dict(jump='ACCEPT', ip_version='ipv4')) == [
        '-j', 'ACCEPT',
    ])
    assert(construct_rule(dict(jump='ACCEPT', ip_version='ipv6')) == [
        '-j', 'ACCEPT',
    ])
    assert(construct_rule(dict(jump='ACCEPT', ip_version='ipv6', ctstate=['ESTABLISHED'])) == [
        '-j', 'ACCEPT',
        '-m', 'conntrack',
        '--ctstate', 'ESTABLISHED',
    ])

# Generated at 2022-06-11 07:25:01.395075
# Unit test for function construct_rule
def test_construct_rule():
    params = dict(
        jump='ACCEPT',
        wait='3',
        protocol='tcp',
        uid_owner='nobody',
        ctstate='NEW',
        src_range='192.168.1.100-192.168.1.199',
        dst_range='10.0.0.1-10.0.0.50',
        limit='5/hour',
        limit_burst='5',
        destination_ports=['80'],
        comment='Test rule',
        icmp_type='echo-request',
        )
    params['ip_version'] = 'ipv4'
    result = construct_rule(params)

# Generated at 2022-06-11 07:25:12.514742
# Unit test for function append_rule
def test_append_rule():
    iptables_path = '/sbin/iptables'
    module = AnsibleModule

# Generated at 2022-06-11 07:25:46.667606
# Unit test for function construct_rule
def test_construct_rule():
    module = dict(
        protocol='tcp',
        source='1.1.1.1',
        destination='8.8.8.8',
        match='conntrack',
        match_set='admin_hosts',
        ctstate='RELATED,ESTABLISHED',
        comment='test comment',
        jump='ACCEPT',
    )
    params = dict(
        ip_version='ipv4',
        protocol=module['protocol'],
        source=module['source'],
        destination=module['destination'],
        match=module['match'],
        match_set=module['match_set'],
        match_set_flags='src',
        ctstate=module['ctstate'],
        comment=module['comment'],
        jump=module['jump'],
    )
    result

# Generated at 2022-06-11 07:25:48.799434
# Unit test for function set_chain_policy
def test_set_chain_policy():
    cmd = push_arguments(iptables_path, '-P', params, make_rule=False)
    cmd.append(params['policy'])
    module.run_command(cmd, check_rc=True)

    return cmd



# Generated at 2022-06-11 07:25:52.919967
# Unit test for function set_chain_policy
def test_set_chain_policy():
    iptables_path = '/sbin/iptables'
    module = None
    params = dict(
        chain='INPUT',
        policy='DROP',
    )
    set_chain_policy(iptables_path, module, params)



# Generated at 2022-06-11 07:26:01.775183
# Unit test for function get_iptables_version
def test_get_iptables_version():
    module = AnsibleModule({})
    assert get_iptables_version('iptables', module) != LooseVersion('1.4.19')
    assert get_iptables_version('iptables', module) >= LooseVersion('1.4.20')
    module = AnsibleModule({})
    assert get_iptables_version('ip6tables', module) != LooseVersion('1.4.19')
    assert get_iptables_version('ip6tables', module) >= LooseVersion('1.4.20')



# Generated at 2022-06-11 07:26:10.622589
# Unit test for function append_rule
def test_append_rule():
    module = AnsibleModule({})
    params = {
        'chain': "INPUT",
        'jump': "ACCEPT",
        'table': "filter",
        'ip_version': "ipv4"
    }
    iptables_path = "iptables"
    append_rule(iptables_path, module, params)
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == "iptables -t filter -A INPUT ACCEPT"



# Generated at 2022-06-11 07:26:20.122968
# Unit test for function construct_rule

# Generated at 2022-06-11 07:26:26.541049
# Unit test for function construct_rule
def test_construct_rule():
    result = construct_rule({
        'protocol': None,
        'source': '!192.0.2.0/24',
        'destination': '10.0.0.0/8',
        'jump': 'ACCEPT',
        'comment': 'Allow access to private subnet',
        'destination_ports': ['20','21','22','23','25','53','80','161','443','465','587','993','995','5060','5061'],
        'in_interface': 'eth1'
    })

# Generated at 2022-06-11 07:26:27.869204
# Unit test for function check_present
def test_check_present():
    assert check_present('iptables', Module, params) == True


# Generated at 2022-06-11 07:26:29.348836
# Unit test for function get_iptables_version
def test_get_iptables_version():
    assert get_iptables_version('/sbin/iptables', dict()) == '1.4.21'



# Generated at 2022-06-11 07:26:35.194032
# Unit test for function remove_rule
def test_remove_rule():
    assert remove_rule(None,None,{}) == None
    assert remove_rule(None,None,{'rule_num': None}) == None
    assert remove_rule(None,None,{'rule_num': 1}) == None
    assert remove_rule(None,None,{'rule_num': '1'}) == None
    assert remove_rule(None,None,{'rule_num': "1"}) == None



# Generated at 2022-06-11 07:27:27.164909
# Unit test for function set_chain_policy
def test_set_chain_policy():
    module = AnsibleModule({
        'ip_version': 'ipv4',
        'table': 'filter',
        'chain': 'INPUT',
        'rule': None,
        'policy': 'ACCEPT',
        'wait': None,
        'flush': False,
    })
    params = module.params
    set_chain_policy('/sbin/iptables', module, params)
    return module.exit_json(changed=True)

# Generated at 2022-06-11 07:27:38.648448
# Unit test for function construct_rule

# Generated at 2022-06-11 07:27:39.958355
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:27:45.182765
# Unit test for function get_chain_policy
def test_get_chain_policy():
    # Valid iptables output
    assert get_chain_policy(None, None, None) == "DROP"
    assert get_chain_policy(None, None, None) == "ACCEPT"
    assert get_chain_policy(None, None, None) == "QUEUE"
    assert get_chain_policy(None, None, None) == "RETURN"
    # Invalid iptables output
    assert not get_chain_policy(None, None, None)



# Generated at 2022-06-11 07:27:47.458745
# Unit test for function set_chain_policy
def test_set_chain_policy():
    assert True



# Generated at 2022-06-11 07:27:53.321066
# Unit test for function construct_rule

# Generated at 2022-06-11 07:28:01.180783
# Unit test for function flush_table
def test_flush_table():
    class TestModule(object):
        def __init__(self):
            self.params = dict(
                chain='INPUT',
                table='filter',
                ip_version='ipv4',
                action='append'
            )
            self.fail_json = False

        def run_command(self, cmd, check_rc=True):
            """
            This is a stubbed method that acts like run_command.  It provides unit test support.
            :param cmd:
            :param check_rc:
            :return:
            """
            print("In stubbed run_command!")
            print("Command is: %s" % ' '.join(cmd))
            if cmd == ['iptables', '-t', 'filter', '-F', 'INPUT']:
                return 0, "", ""

# Generated at 2022-06-11 07:28:07.475760
# Unit test for function construct_rule
def test_construct_rule():
    rule = construct_rule(dict(
        protocol='tcp',
        jump='ACCEPT',
        source='192.168.1.2',
        icmp_type='echo-request',
        ip_version='ipv4',
    ))
    assert rule == ['-p', 'tcp', '-j', 'ACCEPT', '-s', '192.168.1.2', '--icmp-type', 'echo-request']



# Generated at 2022-06-11 07:28:12.884894
# Unit test for function append_rule
def test_append_rule():
    m = mock.Mock()
    m.run_command = mock.Mock()
    append_rule("iptables", m, {"table": "filter", "chain": "INPUT"})
    m.run_command.assert_called_with(['iptables', '-t', 'filter', '-A', 'INPUT'], check_rc=True)



# Generated at 2022-06-11 07:28:23.621700
# Unit test for function construct_rule
def test_construct_rule():
    assert construct_rule(dict(
        protocol='tcp',
        destination_port=80,
        jump='ACCEPT',
        comment='Accept http traffic',
    )) == [
        '-p', 'tcp',
        '--dport', '80',
        '-j', 'ACCEPT',
        '-m', 'comment',
        '--comment', 'Accept http traffic',
    ]

    assert construct_rule(dict(
        protocol='tcp',
        destination_port=80,
        jump='REJECT',
        reject_with='port-unreach',
    )) == [
        '-p', 'tcp',
        '--dport', '80',
        '-j', 'REJECT',
        '--reject-with', 'port-unreach',
    ]



# Generated at 2022-06-11 07:30:19.414651
# Unit test for function push_arguments

# Generated at 2022-06-11 07:30:24.219918
# Unit test for function get_chain_policy
def test_get_chain_policy():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'Chain INPUT (policy DROP)', ''))
    result = get_chain_policy("iptables", module, {"ip_version": "ipv4", "chain": "INPUT", "table": "filter"})
    assert result == "DROP"
    # Test error handling
    module.run_command = MagicMock(return_value=(1, 'Command Error', ''))
    result = get_chain_policy("iptables", module, {"ip_version": "ipv4", "chain": "INPUT", "table": "filter"})
    assert result is None



# Generated at 2022-06-11 07:30:30.775564
# Unit test for function main

# Generated at 2022-06-11 07:30:41.055205
# Unit test for function append_rule

# Generated at 2022-06-11 07:30:41.921855
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:30:45.268730
# Unit test for function append_rule
def test_append_rule():
    params = {
        'table': 'filter',
        'chain': 'INPUT',
        'protocol': 'tcp',
        'destination_port': '443',
        'jump': 'ACCEPT',
        'ip_version': 'ipv4'
    }
    # TODO
    # append_rule(params)
    print("test_append_rule complete.")


# Generated at 2022-06-11 07:30:46.153539
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:30:51.465819
# Unit test for function main

# Generated at 2022-06-11 07:30:55.621771
# Unit test for function get_chain_policy
def test_get_chain_policy():
    testcases = [
        ('Chain INPUT (policy DROP)', 'DROP'),
        ('Chain INPUT (policy ACCEPT)', 'ACCEPT'),
        ('Chain INPUT (policy ACCEPT)', 'ACCEPT'),
        ('Chain INPUT (policy QUEUE)', 'QUEUE'),
        ('Chain INPUT (policy RETURN)', 'RETURN'),
        ('Chain INPUT (policy foo)', 'foo'),
        ('Chain INPUT (policy)', None),
        ('', None),
    ]
    for testcase in testcases:
        assert get_chain_policy(None, None, { "chain": "INPUT" }) == testcase[1]
