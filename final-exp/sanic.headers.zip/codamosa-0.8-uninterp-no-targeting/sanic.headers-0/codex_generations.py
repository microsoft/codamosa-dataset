

# Generated at 2022-06-21 22:56:24.087321
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize(
        (("for", "127.0.0.1:80"), ("path", "/"), ("proto", "http"))
    ) == {"for": "127.0.0.1:80", "path": "/", "proto": "http"}
    assert fwd_normalize(
        (("for", "8.8.8.8"), ("path", '/"'), ("proto", "HTtp"))
    ) == {"for": "8.8.8.8", "path": '/"', "proto": "http"}

# Generated at 2022-06-21 22:56:34.429164
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from collections import namedtuple
    from sanic import Sanic
    from sanic.request import Request
    import uuid
    import random
    # this half-implements default Sanic configs
    # to be used in test only
    config = Sanic().config
    # this returns the key->value pairs in the order of the input
    # if it successfully parses the forwarded field
    # otherwise it returns None

# Generated at 2022-06-21 22:56:40.827294
# Unit test for function format_http1_response
def test_format_http1_response():
    assert b"HTTP/1.1 200 OK\r\n\r\n" == format_http1_response(200, [])
    assert (
        format_http1_response(200, [("Content-Type", "text/plain")])
        == b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n"
    )



# Generated at 2022-06-21 22:56:53.149794
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("0:0:0:0:0:0:0:1") == "[0:0:0:0:0:0:0:1]"
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("localhost") == "localhost"
    assert fwd_normalize_address("kubernetes.default.svc.cluster.local") == "kubernetes.default.svc.cluster.local"

# Generated at 2022-06-21 22:56:58.141988
# Unit test for function format_http1_response
def test_format_http1_response():
    assert (
        format_http1_response(
            404, [("Content-Type", "text/html"), ("Content-Length", "0")]
        )
        == b"HTTP/1.1 404 Not Found\r\nContent-Type: text/html\r\nContent-Length: 0\r\n\r\n"
    )

# Generated at 2022-06-21 22:57:08.093995
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("_foo") == "_foo"
    assert fwd_normalize_address("foo") == "foo"
    assert fwd_normalize_address("Foo") == "foo"
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("2001:db8::1") == "[2001:db8::1]"
    assert fwd_normalize_address("[2001:db8::1]") == "[2001:db8::1]"
    assert fwd_normalize_address("[2001:DB8::1]") == "[2001:db8::1]"
    assert fwd_normalize_address("[2001:db8::1]%eth0") == "[2001:db8::1]"


# Generated at 2022-06-21 22:57:17.589798
# Unit test for function parse_forwarded

# Generated at 2022-06-21 22:57:29.088879
# Unit test for function fwd_normalize
def test_fwd_normalize():
    """Test if the function fwd_normalize works as expected."""
    options = [('host', "'"), ('proto', 'x-scheme'), ('for', 'example.com'), ('proto', 'x-forwarded-proto'), ('path', '',)]
    exp = {'host': "'", 'proto': 'x-forwarded-proto', 'for': 'example.com', 'path': ''}
    assert fwd_normalize(options) == exp

    options = [('host', ''), ('proto', 'x-scheme'), ('for', 'example.com'), ('proto', ''), ('path', '',)]
    exp = {'host': '', 'proto': 'x-forwarded-proto', 'for': 'example.com', 'path': ''}
    assert fwd_normalize(options)

# Generated at 2022-06-21 22:57:31.864552
# Unit test for function format_http1_response
def test_format_http1_response():
    status = 200
    headers = [("Content-Type","application/json")]
    assert format_http1_response(status, headers) == (
        b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
    )

# Generated at 2022-06-21 22:57:37.302080
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("127.0.0.1") == ('127.0.0.1', None)
    assert parse_host("127.0.0.1:5000") == ('127.0.0.1', 5000)
    assert parse_host("[::1]") == ('::1', None)
    assert parse_host("[::1]:5000") == ('::1', 5000)
    assert parse_host("host:domain.com") == ('host:domain.com', None)
    assert parse_host("host:domain.com:5000") == ('host:domain.com', 5000)

    assert parse_host("127.0.0.1:badport") == (None, None)
    assert parse_host("127.0.0.1:5000:bad") == (None, None)

# Generated at 2022-06-21 22:57:47.265100
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-Proto" : "http",
        "X-Forwarded-Host" : "localhost:8000",
        "X-Forwarded-Port" : "80",
        "X-Forwarded-Path" : "/",
        "X-Scheme" : "http",
    }
    print(parse_xforwarded(headers))


# Generated at 2022-06-21 22:57:55.744962
# Unit test for function fwd_normalize
def test_fwd_normalize():
    # Simple tests
    assert fwd_normalize({"a": "b"}) == {"a": "b"}
    assert fwd_normalize({"a": None}) == {}
    assert fwd_normalize([]) == {}

    # "By" and "for" address normalization
    assert fwd_normalize({"by": "HOST.com"}) == {"by": "host.com"}
    assert fwd_normalize({"by": "[::1]"}) == {"by": "[::1]"}
    assert fwd_normalize({"by": "_hidden"}) == {"by": "_hidden"}
    assert fwd_normalize({"by": "unknown"}) == {}

    # "Proto" and "host" lower-casing

# Generated at 2022-06-21 22:58:02.714341
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from pprint import pprint
    from sanic.config import Config

    config = Config()
    config.FORWARDED_FOR_HEADER = 'X-Forwarded-For'
    config.PROXIES_COUNT = 1
    config.REAL_IP_HEADER = 'X-Real-IP'
    config.FORWARDED_PROTO_HEADER = 'X-Forwarded-Proto'
    config.FORWARDED_HOST_HEADER = 'X-Forwarded-Host'
    config.FORWARDED_PORT_HEADER = 'X-Forwarded-Port'
    config.FORWARDED_PATH_HEADER = 'X-Forwarded-Path'

# Generated at 2022-06-21 22:58:07.449127
# Unit test for function format_http1_response
def test_format_http1_response():
    resp = format_http1_response(200, [b"Content-Type", b"application/json"])
    assert resp == b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"

_HTTP2_STATUSLINES = dict(
    (status, b":status: %d\r\n" % status) for status in range(1000)
)



# Generated at 2022-06-21 22:58:13.268236
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("::1") == "[::1]"
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("_my_addr") == "_my_addr"
    assert fwd_normalize_address("_my_addr:port") == "_my_addr:port"
    assert fwd_normalize_address("_my_addr:port") == "_my_addr:port"
    with pytest.raises(ValueError):
        fwd_normalize_address("unknown")

# Generated at 2022-06-21 22:58:17.626057
# Unit test for function parse_content_header
def test_parse_content_header():
    from urllib.parse import unquote
    s = 'form-data; name="key1"; filename=file.bin;  name=upload; filename="file.txt"'
    print(parse_content_header(s))
    ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    s2 = 'form-data; name="key1"; filename=file.bin;  name="upload"; filename="file.txt"'
    print(parse_content_header(s2))
    ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-21 22:58:29.783159
# Unit test for function parse_content_header
def test_parse_content_header():
    from sanic import Sanic
    from sanic.exceptions import InvalidUsage

    app = Sanic("test_parse_content_header")

    @app.route("/content_header")
    def handler(request):
        return request.headers.get('content_type')

    @app.exception(InvalidUsage)
    def handler1(request, exception):
        return exception

    @app.exception(Exception)
    def handler2(request, exception):
        return exception

    request, response = app.test_client.get(
        "/content_header",
        headers={"Content-Type": "application/json;charset=utf8"}
    )
    assert response.text == 'application/json'


# Generated at 2022-06-21 22:58:33.956239
# Unit test for function format_http1_response
def test_format_http1_response():
    assert format_http1_response(404, []) == b"HTTP/1.1 404 Not Found\r\n\r\n"
    assert format_http1_response(201, []) == b"HTTP/1.1 201 Created\r\n\r\n"
    assert format_http1_response(200, []) == b"HTTP/1.1 200 OK\r\n\r\n"
    assert format_http1_response(200, [("h1", "v1")]) == b"HTTP/1.1 200 OK\r\nh1: v1\r\n\r\n"

# Generated at 2022-06-21 22:58:38.224976
# Unit test for function format_http1_response
def test_format_http1_response():
    h = [(b"a", b"1"), (b"b", b"2"), (b"c", b"3")]
    assert (
        format_http1_response(200, h)
        == b"HTTP/1.1 200 OK\r\n"
        b"a: 1\r\n"
        b"b: 2\r\n"
        b"c: 3\r\n"
        b"\r\n"
    )

# Generated at 2022-06-21 22:58:48.001498
# Unit test for function parse_content_header

# Generated at 2022-06-21 22:58:54.658198
# Unit test for function format_http1_response
def test_format_http1_response():
    r = format_http1_response(200, [])
    assert r == b"HTTP/1.1 200 OK\r\n\r\n"



# Generated at 2022-06-21 22:59:07.264900
# Unit test for function format_http1_response
def test_format_http1_response():
    import http.client
    assert format_http1_response(
        200, [('Content-Type', 'text/plain'), ('Content-Length', '12')]
    ) == b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 12\r\n\r\n"
    try:
        http.client.responses[600]
    except KeyError:
        print(http.client.responses)
        raise
    assert format_http1_response(600, []) == b"HTTP/1.1 600 UNKNOWN\r\n\r\n"

# Generated at 2022-06-21 22:59:14.049839
# Unit test for function parse_forwarded
def test_parse_forwarded():
    #print("No Forwarded")
    headers = {"Host": "google.com"}
    config = {"FORWARDED_SECRET": "my-secret"}
    assert parse_forwarded(headers, config) == None
    #print("Single Forwarded")
    headers = {"Host": "google.com", "Forwarded": "for=192.0.2.60;proto=https;by=203.0.113.43;host=example.com;secret=my-secret"}
    config = {"FORWARDED_SECRET": "my-secret"}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'https', 'by': '203.0.113.43', 'host': 'example.com'}
    #print("Multiple Forwarded")

# Generated at 2022-06-21 22:59:22.157202
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("host", "example.com")]) == {"host": "example.com"}
    assert fwd_normalize([("host", "example.com"), ("host", "EXAMPLE.COM")]) == {"host": "example.com"}
    assert fwd_normalize([("path", "/")]) == {"path": "/"}
    assert fwd_normalize([("path", "/test")]) == {"path": "/test"}
    assert fwd_normalize([("path", "/test?a=1")]) == {"path": "/test?a=1"}
    assert fwd_normalize([("path", "/test?a=1%20")]) == {"path": "/test?a=1 "}

# Generated at 2022-06-21 22:59:29.441330
# Unit test for function fwd_normalize
def test_fwd_normalize():
    def check(fwd, expected):
        assert fwd_normalize(fwd) == expected
    check([("for", "192.168.44.44")], {"for": "192.168.44.44"})
    check([("for", "192.168.44.44"), ("proto", "http")], {"for": "192.168.44.44", "proto": "http"})
    check([("for", "192.168.44.44"), ("proto", "http"), ("host", "host.example.com"), ("port", "80"), ("path", "/path/to/page")], {"for": "192.168.44.44", "proto": "http", "host": "host.example.com", "port": 80, "path": "/path/to/page"})

# Generated at 2022-06-21 22:59:32.031591
# Unit test for function fwd_normalize
def test_fwd_normalize():
    fwd_normalize([("host", "sanic.com")]) == {"host":"sanic.com"}

# Generated at 2022-06-21 22:59:39.461205
# Unit test for function fwd_normalize
def test_fwd_normalize():
    # Test 1
    print("\nTest 1")
    fwd = [
        ("proto", "http"),
        ("host", "127.0.0.1"),
        ("port", "8080"),
        ("path", "/test"),
        ("for", "127.0.0.1"),
        ("by", "127.0.0.1"),
    ]
    options = fwd_normalize(fwd)
    print(options)

    # Test 2
    print("\nTest 2")

# Generated at 2022-06-21 22:59:49.856226
# Unit test for function format_http1_response
def test_format_http1_response():
    """Make sure the function format_http1_response format the response header
    correctly.
    """
    header = [
        (b"connection", b"keep-alive"),
        (b"content-length", b"32"),
        (b"content-type", b"text/plain"),
        (b"date", b"Sun, 01 Mar 2020 15:55:20 GMT"),
        (b"server", b"Sanic/19.12.1"),
    ]

# Generated at 2022-06-21 23:00:02.897775
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header("text/html") == ("text/html", {})
    assert parse_content_header("text/html; charset=utf-8") == ("text/html", {"charset": "utf-8"})
    assert parse_content_header("text/html; charset=utf-8; encoding=gzip") == ("text/html", {"charset": "utf-8", "encoding": "gzip"})
    assert parse_content_header('text/html; charset="utf-8"') == ("text/html", {"charset": "utf-8"})
    assert parse_content_header("text/html; charset=utf-8; encoding=gzip;") == ("text/html", {"charset": "utf-8", "encoding": "gzip"})

# Generated at 2022-06-21 23:00:09.842528
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"x-forwarded-for": "192.168.0.1"}
    assert parse_xforwarded(headers, None) == {"for": "192.168.0.1"}
    headers = {"x-forwarded-for": "192.168.0.1, 10.0.0.1"}
    assert parse_xforwarded(headers, None) == {"for": "10.0.0.1"}

# Generated at 2022-06-21 23:00:27.499475
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic import Sanic
    from sanic.request import RequestParameters
    app = Sanic(__name__)
    p = app.config.PROXIES_COUNT
    assert p == 0
    app.config.PROXIES_COUNT = 1
    assert app.config.PROXIES_COUNT == 1
    headers = RequestParameters({'x-forwarded-for': '127.0.0.1,0.0.0.1,0.0.0.2'})
    assert parse_xforwarded(headers, app.config) == {'for': '0.0.0.2'}
    app.config.PROXIES_COUNT = 0
    assert app.config.PROXIES_COUNT == 0

# Generated at 2022-06-21 23:00:39.017877
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request

    config = Config(
        RETRY_AFTER=100,
        FORWARDED_SECRET=os.urandom(16),
        FORWARDED_FOR_HEADER="X-Forwarded-For",
    )


# Generated at 2022-06-21 23:00:47.015621
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for="_mdnxzd2xk";;proto=http;host="foo.bar:8080";;by=_mdnxzd2xk;secret=_mdnxzd2xk'}
    config = {'PROXIES_COUNT': 0, 'REAL_IP_HEADER': 'X-Real-Ip', 'FORWARDED_SECRET': '_mdnxzd2xk'}
    x = parse_forwarded(headers, config)



# Generated at 2022-06-21 23:00:58.862963
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("") == (None, None,)
    assert parse_host("google.com") == ("google.com", None,)
    assert parse_host("google.com:") == ("google.com", None,)
    assert parse_host("google.com:80") == ("google.com", 80,)
    assert parse_host("127.0.0.1") == ("127.0.0.1", None,)
    assert parse_host("127.0.0.1:80") == ("127.0.0.1", 80,)
    assert parse_host("[::1]") == ("::1", None,)
    assert parse_host("[::1]:80") == ("::1", 80,)

# Generated at 2022-06-21 23:01:03.602291
# Unit test for function parse_host
def test_parse_host():
    host1 = parse_host("localhost")
    host2 = parse_host("192.168.1.1")
    assert host1 == ('localhost', None)
    assert host2 == ('192.168.1.1', None)



# Generated at 2022-06-21 23:01:11.581225
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "24.24.24.24")]) == {"for": "24.24.24.24"}
    assert fwd_normalize([("for", "1234")]) == {}
    assert fwd_normalize([("for", "unknown")]) == {}
    assert fwd_normalize([("for", "_foobar")]) == {"for": "_foobar"}
    assert fwd_normalize([("for", "::1")]) == {"for": "[::1]"}
    assert fwd_normalize([("host", "host.com")]) == {"host": "host.com"}
    assert fwd_normalize([("host", "host.com:8080")]) == {}

# Generated at 2022-06-21 23:01:19.106413
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("Test.ru") == "test.ru"
    assert fwd_normalize_address("Localhost") == "localhost"
    assert fwd_normalize_address("A") == "a"
    assert fwd_normalize_address("A.B") == "a.b"
    assert fwd_normalize_address("A.b") == "a.b"
    assert fwd_normalize_address("a.B") == "a.b"
    assert fwd_normalize_address("_test.ru") == "_test.ru"
    assert fwd_normalize_address("_a") == "_a"
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"

# Generated at 2022-06-21 23:01:28.278288
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    import sanic
    print("TESTING FUNCTION parse_xforwarded")
    app = sanic.Sanic("testing")
    @app.route("/")
    async def handle(request):
        return sanic.response.text("OK")
    with app.test_client() as client:
        print("Checking... ")
        tmp = client.get("/")
        tmp = tmp.request.headers
        print(tmp)
        assert (parse_xforwarded(tmp, app.config) == None)

if __name__ == "__main__":
    test_parse_xforwarded()

# Generated at 2022-06-21 23:01:36.209588
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    ipv6 = "dead:beef:11c9::dead"
    assert fwd_normalize_address(ipv6) == f"[{ipv6}]"
    assert fwd_normalize_address("::1") == "[::1]"
    assert fwd_normalize_address("::") == "[::]"
    assert fwd_normalize_address("a::b") == "[a::b]"
    assert fwd_normalize_address("a::") == "[a::]"
    assert fwd_normalize_address("a:b:c:d:e:f:1.2.3.4") == "[a:b:c:d:e:f:1.2.3.4]"
    assert fwd_normalize_address("_123") == "_123"
    assert fwd_normalize_address

# Generated at 2022-06-21 23:01:43.626235
# Unit test for function parse_content_header
def test_parse_content_header():
    content_header = 'form-data; name="upload"; filename="file.txt"'
    expect_key, expect_value = 'form-data', {'name': 'upload', 'filename': 'file.txt'}
    parse_content_header(content_header) == (expect_key, expect_value)

# Generated at 2022-06-21 23:01:53.891340
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("key", "value")]) == {"key": "value"}
    assert fwd_normalize([("key", "")]) == {}
    assert fwd_normalize([("key", None)]) == {"key": None}

# Generated at 2022-06-21 23:02:01.365234
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {}
    headers["x-scheme"] = "https"
    headers["x-forwarded-proto"] = "http"
    headers["x-forwarded-host"] = "192.168.1.100:8888"
    headers["x-forwarded-port"] = "9000"
    headers["x-forwarded-path"] = "/test_path"
    headers["x-real-ip"] = "127.0.0.1"

    class config:
        PROXIES_COUNT = 0
        REAL_IP_HEADER = "x-real-ip"
        FORWARDED_FOR_HEADER = ""
        FORWARDED_SECRET = ""
        TRUSTED_PROXIES = []
    options = parse_xforwarded(headers, config)

# Generated at 2022-06-21 23:02:06.967680
# Unit test for function format_http1_response
def test_format_http1_response():
    header_list = [(b'Content-Type', b'application/json')]
    assert format_http1_response(200, header_list) == (b'HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n')

# Generated at 2022-06-21 23:02:15.374989
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("localhost") == "localhost"
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    # "localhost" should not be replaced with "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("unknown") == ""

# Generated at 2022-06-21 23:02:24.334906
# Unit test for function format_http1_response
def test_format_http1_response():
    # Check that format_http1_response(200, []) and the other HTTP 1.1
    # responses work fine
    assert format_http1_response(200, []) == b"HTTP/1.1 200 OK\r\n\r\n"
    assert (
        format_http1_response(599, []) == b"HTTP/1.1 599 UNKNOWN\r\n\r\n"
    )

    # Check that a response with headers works fine
    # Note: We need to use brackets instead of parens, because parens are
    # overloaded in Python 3
    assert (
        format_http1_response(200, [("x", "y")])
        == b"HTTP/1.1 200 OK\r\nx: y\r\n\r\n"
    )

# Generated at 2022-06-21 23:02:31.032634
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize(
        [("path", "a")]
    ) == {"path": "a"}  # str
    assert fwd_normalize(
        [("port", "8080")]
    ) == {"port": 8080}  # int
    assert fwd_normalize(
        [("by", "ipv6"), ("for", "ipv6")]
    ) == {"by": "[ipv6]", "for": "[ipv6]"}  # ipv6 bracketing
    assert fwd_normalize(
        [("by", "_obfuscated"), ("proto", "_obfuscated")]
    ) == [("by", "_obfuscated"), ("proto", "_obfuscated")]  # case

# Generated at 2022-06-21 23:02:41.908807
# Unit test for function parse_host
def test_parse_host():
    # Test some valid host names
    assert parse_host("[::1]") == ("::1", None)
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("https://example.com/") == ("example.com", None)
    assert parse_host("www.example.com:8080") == ("www.example.com", 8080)

    # Hosts with invalid characters must return None
    assert parse_host("[::1") == (None, None)  # Missing closing bracket
    assert parse_host("/invalid") == (None, None)  # Invalid character
    assert parse_host("-invalid") == (None, None)  # Invalid character

    # Test for missing values
    assert parse_host("localhost:") == ("localhost", None)  # Missing port
    assert parse_host

# Generated at 2022-06-21 23:02:46.552945
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address('8.8.8.8') == '8.8.8.8'
    assert fwd_normalize_address('hello') == 'hello'
    assert fwd_normalize_address('_hello') == '_hello'
    assert fwd_normalize_address(':8.8.8.8') == ':8.8.8.8'
    assert fwd_normalize_address('::8') == '::8'
    assert fwd_normalize_address('[::8]') == '[::8]'
    assert fwd_normalize_address('[::8') == '[::8'
    assert fwd_normalize_address('::8]') == '::8]'

# Generated at 2022-06-21 23:02:50.029267
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address('UnknoWn') == 'unknown'
    assert fwd_normalize_address('_unknown') == '_unknown'
    assert fwd_normalize_address('::1') == '[::1]'
    assert fwd_normalize_address('127.0.0.1') == '127.0.0.1'

# Generated at 2022-06-21 23:03:00.996654
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("host", "localhost")]) == {
        "host": "localhost"
    }
    assert fwd_normalize([("host", "localhost"), ("host", "localhost")]) == {
        "host": "localhost"
    }
    assert fwd_normalize([("port", "9000"), ("port", "8000")]) == {}
    assert fwd_normalize([("port", "8000")]) == {"port": 8000}
    assert fwd_normalize([("port", "invalid")]) == {}
    assert fwd_normalize([("proto", "http")]) == {"proto": "http"}
    assert fwd_normalize([("proto", "HTTP")]) == {"proto": "http"}
    assert fwd_normalize

# Generated at 2022-06-21 23:03:27.297725
# Unit test for function format_http1_response
def test_format_http1_response():
    headers = [
        (b"KEY1", b"VALUE1"),
        (b"KEY10", b"VALUE10"),
        (b"KEY2", b"VALUE2"),
        (b"KEY4", b"VALUE4"),
        (b"KEY5", b"VALUE5"),
        (b"KEY9", b"VALUE9"),
        (b"KEY6", b"VALUE6"),
        (b"KEY8", b"VALUE8"),
        (b"KEY7", b"VALUE7"),
        (b"KEY3", b"VALUE3"),
    ]
    ret = format_http1_response(200, headers)

# Generated at 2022-06-21 23:03:31.985684
# Unit test for function format_http1_response
def test_format_http1_response():
    # for response without body
    assert (
        format_http1_response(200, []) == b"HTTP/1.1 200 OK\r\n\r\n"
        and format_http1_response(204, []) == b"HTTP/1.1 204 No Content\r\n\r\n"
        and format_http1_response(400, []) == b"HTTP/1.1 400 Bad Request\r\n\r\n"
    )
    # for response with body
    headers = [
        (b"server", b"Sanic/0.7.0"),
        (b"content-type", b"text/html"),
        (b"date", b"Wed, 05 Apr 2017 14:37:47 GMT"),
        (b"connection", b"keep-alive"),
    ]

# Generated at 2022-06-21 23:03:41.268701
# Unit test for function parse_host
def test_parse_host():
    host1 = "127.0.0.1:1234"
    assert parse_host(host1) == ("127.0.0.1", 1234)
    host2 = "example.com"
    assert parse_host(host2)[0] == "example.com"
    host3 = "[::1]"
    assert parse_host(host3) == ("::1", None)
    host4 = "::1"
    assert parse_host(host4) == ("::1", None)
    host5 = "::1:1234"
    assert parse_host(host5) == ("::1", 1234)
    try:
        host6 = "::1:1234:1234"
        parse_host(host6)
        assert False
    except ValueError:
        pass

# Generated at 2022-06-21 23:03:51.571169
# Unit test for function fwd_normalize

# Generated at 2022-06-21 23:03:58.408579
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:8080") == ("localhost", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[0:0:0:0:0:0:0:1]:8080") == ("[0:0:0:0:0:0:0:1]", 8080)
    assert parse_host("[::]:8080") == ("[::]", 8080)
    assert parse_host("192.168.178.1") == ("192.168.178.1", None)
    assert parse_host("192.168.178.1:8080") == ("192.168.178.1", 8080)

# Generated at 2022-06-21 23:04:05.005740
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    import pytest

    # Check that the returned dict is correct
    class Header:
        def __init__(self, real_ip_header, proxies_count, forwarded_for_header):
            self.real_ip_header = real_ip_header
            self.proxies_count = proxies_count
            self.forwarded_for_header = forwarded_for_header
        def __getitem__(self, key):
            if key == self.real_ip_header:
                return "real_ip_addr"
            if key == self.forwarded_for_header:
                return ["prox_addr1", "prox_addr2"]
    

# Generated at 2022-06-21 23:04:05.875781
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    value = "192.168.1.1"
    fwd_normalize_address(value)



# Generated at 2022-06-21 23:04:14.565786
# Unit test for function fwd_normalize
def test_fwd_normalize():

    fwd_result = fwd_normalize([("host","example.com"), ("proto","http"), ("path","/api"), ("port", "8080"), ("for", "1.2.3.4")])
    assert fwd_result == {'host': 'example.com', 'proto': 'http', 'path': '/api', 'port': 8080, 'for': '1.2.3.4'}

    fwd_result = fwd_normalize([("host","example.com"), ("proto","https"), ("path","/api"), ("port", "443"), ("for", "1.2.3.4")])
    assert fwd_result == {'host': 'example.com', 'proto': 'https', 'path': '/api', 'port': 443, 'for': '1.2.3.4'}

# Generated at 2022-06-21 23:04:23.710527
# Unit test for function parse_content_header
def test_parse_content_header():
    value = 'form-data; name=upload; filename=\"file.txt\"'
    result = ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header(value) == result

    value = 'form-data; name=upload; filename=\"file.txt\"; test="qwe\", weq;"; f=; f2=";'
    result = ('form-data', {'name': 'upload', 'filename': 'file.txt', 'test': 'qwe", weq;', 'f': '', 'f2': ';'})
    assert parse_content_header(value) == result

    value = 'form-data; name=upload; filename=\"file.txt\"; test="qwe\", weq;"; f=; f2=";'

# Generated at 2022-06-21 23:04:27.804980
# Unit test for function parse_forwarded
def test_parse_forwarded():
    h = {'forwarded' : 'test'}
    config = {'FORWARDED_SECRET' : 'test'}
    assert parse_forwarded(h, config) != None

# Generated at 2022-06-21 23:04:52.091045
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename=file.txt') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name="upload"; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name="up load"; filename="file.txt"') == ('form-content-disposition', {'name': 'up load', 'filename': 'file.txt'})


# Generated at 2022-06-21 23:05:02.819087
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config

    class TestConfig(Config):
        REAL_IP_HEADER = "X-Forwarded-For"
        FORWARDED_FOR_HEADER = "X-Forwarded-For"
        FORWARDED_SECRET = ""
        PROXIES_COUNT = 1

    config = TestConfig()

    class FakeHeaders():
        def get(self, header_name):
            header_dict = {
                "X-Forwarded-For": "127.0.0.1",
                "X-Scheme": "http",
                "X-Forwarded-Proto": "http",
                "X-Forwarded-Host": "example.com",
                "X-Forwarded-Port": "80",
                "X-Forwarded-Path": "/path"
            }

# Generated at 2022-06-21 23:05:05.887222
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    import json
    with open('test_data/test_dict.json') as f:
        test_dict = json.load(f)
    for k,v in test_dict.items():
        print (k,v)
        print(parse_xforwarded(v))


# Generated at 2022-06-21 23:05:11.400426
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert not fwd_normalize([("by", "foo")])
    assert fwd_normalize([("by", "_foo")]) == {"by": "_foo"}
    assert fwd_normalize([("by", "unknown")]) == {"by": "unknown"}
    assert fwd_normalize([("by", "::1")]) == {"by": "::1"}
    assert fwd_normalize([("by", "127.0.0.1")]) == {"by": "127.0.0.1"}
    assert fwd_normalize([("by", "127.0.0.1,n1")]) == {"by": "127.0.0.1"}
    assert fwd_normalize([("by", "n1,127.0.0.1")]) == {"by": "127.0.0.1"}


# Generated at 2022-06-21 23:05:17.451277
# Unit test for function format_http1_response
def test_format_http1_response():
    data = [
        (200, b"hello"),
        (400, b"world"),
        (200, b"foo"),
    ]
    assert format_http1_response(data[0][0], data[0:1]) == b"HTTP/1.1 200 OK\r\nconnection: keep-alive\r\ncontent-length: 5\r\n\r\nhello"
    assert format_http1_response(data[1][0], data[1:2]) == b"HTTP/1.1 400 BAD REQUEST\r\nconnection: keep-alive\r\ncontent-length: 5\r\n\r\nworld"

# Generated at 2022-06-21 23:05:20.290705
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("example.com") == ("example.com", None)
    assert parse_host("example.com:443") == ("example.com", 443)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:5000") == ("[::1]", 5000)



# Generated at 2022-06-21 23:05:32.856214
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.request import Request
    import socket
    import time
    import threading
    import random
    import asyncio

    async def _run_server():
        count = 0

        def get_random_str():
            return ''.join(random.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') for _ in range(4))
        
        G_SERVER = 'sakura_forwarded_' + get_random_str()
        print(G_SERVER)
        s = socket.socket()     
        s.bind(('0.0.0.0', 0))  
        s.listen(5)
        s.setblocking(False)
        print("socket start at", s.getsockname())


# Generated at 2022-06-21 23:05:40.165064
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {'X-Forwarded-For': '127.0.0.1, 192.168.0.1, 172.17.0.3',
               'X-Forwarded-Host': 'example.com',
               'X-Forwarded-Port': '8000',
               'X-Forwarded-Proto': 'https',
               'X-Forwarded-Path': '/app'}
    assert parse_xforwarded(headers, None) == parse_forwarded(headers, None)

# Generated at 2022-06-21 23:05:49.974013
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'https', 
        'x-forwarded-for': '192.168.0.3, 192.168.0.2, 192.168.0.1', 
        'x-forwarded-port': '443', 
        'x-forwarded-host': '192.168.0.3', 
        'x-forwarded-path': '/'
    }

    config = {
        'REAL_IP_HEADER': 'x-forwarded-for', 
        'PROXIES_COUNT': 2, 
        'FORWARDED_FOR_HEADER': 'x-forwarded-for', 
        'FORWARDED_PROTO_HEADER': 'x-forwarded-proto'
    }

    ret = parse_xforwarded(headers, config)

# Generated at 2022-06-21 23:05:58.383373
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("_") == "_"
    assert fwd_normalize_address("abcd.123.0") == "abcd.123.0"
    assert fwd_normalize_address("2001:0db8:0000:0042:0000:8a2e:0370:7334") == "2001:db8:0:42::8a2e:370:7334"
    assert fwd_normalize_address("2001:db8:0:42::8a2e:370:7334") == "2001:db8:0:42::8a2e:370:7334"