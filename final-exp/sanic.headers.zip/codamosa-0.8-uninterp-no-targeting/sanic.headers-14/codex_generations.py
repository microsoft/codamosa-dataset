

# Generated at 2022-06-21 22:56:29.239079
# Unit test for function parse_forwarded

# Generated at 2022-06-21 22:56:40.625003
# Unit test for function parse_host
def test_parse_host():
    print(parse_host("127.0.0.1"))
    print(parse_host(""))
    print(parse_host("2asdf"))
    print(parse_host("a.b.c.d"))
    print(parse_host("a3:dd:3:23::1"))
    assert parse_host("2asdf") == ("", None)
    assert parse_host("a.b.c.d") == ("a.b.c.d", None)
    assert parse_host("a3:dd:3:23::1") == ("2asdf", None)
    assert parse_host("a3:dd:3:23::1:22") == ("a3:dd:3:23::1", 22)


if __name__ == '__main__':
    test_parse_host()

# Generated at 2022-06-21 22:56:55.391974
# Unit test for function fwd_normalize
def test_fwd_normalize():
    import pytest
    # Check address normalization
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "[::1]")]) == {"for": "[::1]"}
    assert fwd_normalize([("for", "__example.com")]) == {"for": "__example.com"}
    assert fwd_normalize([("for", "__EXAMPLE.com")]) == {"for": "__EXAMPLE.com"}
    assert fwd_normalize([("for", "unknown")]) == {}
    with pytest.raises(ValueError):
        fwd_normalize([("for", "127.0.0.1, example.com")])



# Generated at 2022-06-21 22:57:01.665679
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("[::1]") == ("::1", None)
    assert parse_host("hostname") == ("hostname", None)
    assert parse_host("hostname:8080") == ("hostname", 8080)
    assert parse_host("hostname:") == ("hostname", None)
    assert parse_host(":8080") == (None, 8080)
    assert parse_host("") == (None, None)

# Generated at 2022-06-21 22:57:10.842352
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("127.0.0.1:8888") == ("127.0.0.1", 8888)
    assert parse_host("127.0.0.1") == ("127.0.0.1", None)
    assert parse_host("127.0.0.1:") == ("127.0.0.1", None)
    assert parse_host("[::ffff:127.0.0.1]:8888") == ("[::ffff:127.0.0.1]", 8888)
    assert parse_host("[::ffff:127.0.0.1]:") == ("[::ffff:127.0.0.1]", None)
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:80") == ("localhost", 80)
    assert parse_

# Generated at 2022-06-21 22:57:17.471943
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    from sanic.server import HttpProtocol as SanicHttpProtocol
    sanic_http_protocol = SanicHttpProtocol(None, None, None)
    assert sanic_http_protocol.fwd_normalize_address('1.1.1.1') == '1.1.1.1'
    assert sanic_http_protocol.fwd_normalize_address('1234:5678:90ab:cdef:1234:5678:90ab:cdef') == \
            '[1234:5678:90ab:cdef:1234:5678:90ab:cdef]'

# Generated at 2022-06-21 22:57:28.999087
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("1.2.3.4") == "1.2.3.4"
    assert fwd_normalize_address("2001:db8:0000:1:1:1:1:1") == "2001:db8::1:1:1:1:1"
    assert fwd_normalize_address("_foo") == "_foo"
    assert fwd_normalize_address("_foobar") == "_foobar"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("UNKNOWN") == "unknown"
    assert fwd_normalize_address("UNKNOWN") == "unknown"
    assert fwd_normalize_address("Unknown") == "unknown"
    assert fwd_normalize_address("unknown") == "unknown"


# Generated at 2022-06-21 22:57:29.680246
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}



# Generated at 2022-06-21 22:57:38.760629
# Unit test for function parse_forwarded
def test_parse_forwarded():
    options = parse_forwarded({'Forwarded': 'secret=abc,by=sanic'}, 'config')
    assert options == {'secret': 'abc', 'by': 'sanic'}

    options = parse_forwarded({'Forwarded': 'secret=def,by=sanic'}, 'config')
    assert options == None

    options = parse_forwarded({'Forwarded': 'by=sanic,secret=abc'}, 'config')
    assert options == None

    options = parse_forwarded({'Forwarded': 'secret=abc'}, 'config')
    assert options == None

    options = parse_forwarded({'Forwarded': 'by=sanic'}, 'config')
    assert options == None


# Generated at 2022-06-21 22:57:49.008568
# Unit test for function fwd_normalize
def test_fwd_normalize():
    config = Config()
    config.REAL_IP_HEADER = ""
    config.FORWARDED_FOR_HEADER = ""
    config.FORWARDED_SECRET = ""
    config.PROXIES_COUNT = 0
    headers = Headers([('X-Forwarded-For', 'Test')])
    assert parse_xforwarded(headers, config) == {'for': 'test'}
    
    headers = Headers([('X-Forwarded-For', 'Test, TEST, Test')])
    assert parse_xforwarded(headers, config) == {'for': 'test, test, test'}
    
    headers = Headers([('X-Forwarded-For', 'Test, Test, Test, Test')])
    assert parse_xforwarded(headers, config) == None


# Generated at 2022-06-21 22:58:02.065796
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    # full test see test_requests.py
    headers = {
        "x-forwarded-for": "172.217.20.14",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/",
        "x-forwarded-port": "5672",
    }
    for count, key in [(1, "for"), (2, "proto"), (2, "port")]:
        options = parse_xforwarded(headers, Config(PROXIES_COUNT=count))
        print(options)
        assert options[key] == headers["x-forwarded-" + key]
    options = parse_xforwarded({}, Config(PROXIES_COUNT=2))
    assert options == None



# Generated at 2022-06-21 22:58:05.700081
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("192.168.1.2") == '192.168.1.2'
    assert fwd_normalize_address("_secret") == '_secret'
    assert fwd_normalize_address("[::1]") == '[::1]'

# Generated at 2022-06-21 22:58:07.182945
# Unit test for function parse_host
def test_parse_host():
    host = "192.168.0.1"
    print(parse_host(host))


# Generated at 2022-06-21 22:58:14.512912
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-Host": "test.com",
        "X-Forwarded-For": "127.0.0.1",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Scheme": "https"
    }

    class Config:
        FORWARDED_FOR_HEADER: str = "X-Forwarded-For"
        PROXIES_COUNT: int = 2
        REAL_IP_HEADER: Optional[str] = None
        FORWARDED_SECRET: Optional[str] = None

    res = parse_xforwarded(headers, Config())
    assert res == {
        'host': 'test.com',
        'port': 80,
        'for': '127.0.0.1',
        'proto': 'https'
    }

# Generated at 2022-06-21 22:58:25.575665
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("google.com") == ("google.com", None)
    assert parse_host("google.com:80") == ("google.com", 80)
    assert parse_host("google.com:443") == ("google.com", 443)
    assert parse_host("::1") == ("[::1]", None)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("::1:8080") == ("::1", 8080)

if __name__ == '__main__':
    test_parse_host()

# Generated at 2022-06-21 22:58:27.914848
# Unit test for function parse_host
def test_parse_host():
    print(parse_host('1.1.1.1:80'))

if __name__ == '__main__':
    test_parse_host()

# Generated at 2022-06-21 22:58:36.852990
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("1.2.3.4") == "1.2.3.4"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret:123") == "_secret:123"
    assert fwd_normalize_address("localhost") == "localhost"
    assert fwd_normalize_address("example.com") == "example.com"
    assert fwd_normalize_address("[2001:0db8:85a3:0000:0000:8a2e:0370:7334]") == \
           "[2001:0db8:85a3:0000:0000:8a2e:0370:7334]"



# Generated at 2022-06-21 22:58:42.616712
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"forwarded": "for=192.0.2.60;proto=http"}
    config = type("", (), {"FORWARDED_SECRET": None})()
    res = parse_forwarded(headers, config)
    assert res == {"for": "192.0.2.60", "proto": "http"}

# Generated at 2022-06-21 22:58:53.451926
# Unit test for function format_http1_response
def test_format_http1_response():
    """Test format_http1_response function"""
    # Test that response is properly formatted
    status = 200
    headers = [
        (b"Content-Type", b"text/html"),
        (b"Content-Length", b"0"),
        (b"Date", b"Fri, 11 Aug 2017 13:37:37 GMT"),
        (b"Connection", b"close"),
    ]
    assert b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 0\r\nDate: Fri, 11 Aug 2017 13:37:37 GMT\r\nConnection: close\r\n\r\n" == format_http1_response(status, headers)

# Generated at 2022-06-21 22:58:57.304661
# Unit test for function format_http1_response
def test_format_http1_response():
    assert format_http1_response(200, []) == (
        b"HTTP/1.1 200 OK\r\n\r\n"
    )
    assert format_http1_response(299, []) == (
        b"HTTP/1.1 299 OK\r\n\r\n"
    )
    assert format_http1_response(404, []) == (
        b"HTTP/1.1 404 NOT FOUND\r\n\r\n"
    )
    assert format_http1_response(599, []) == (
        b"HTTP/1.1 599 UNKNOWN\r\n\r\n"
    )

# Generated at 2022-06-21 22:59:14.030064
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("192.0.2.27") == "192.0.2.27"
    assert fwd_normalize_address("2001:db8:85a3:0:0:8a2e:370:7334") == "[2001:db8:85a3:0:0:8a2e:370:7334]"
    assert fwd_normalize_address("unknown") == ""
    assert fwd_normalize_address("_obfuscated-keyword") == "_obfuscated-keyword"
    assert fwd_normalize_address("_obfuscated-keyword.") == "_obfuscated-keyword."
    assert fwd_normalize_address("::1") == "[::1]"

# Generated at 2022-06-21 22:59:25.342395
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    IPV4="192.168.1.1"
    IPV4_NORMALIZED=fwd_normalize_address(IPV4)
    assert  IPV4 == IPV4_NORMALIZED, "IPV4 equal, should be equal"

    IPV6="2001:0db8:85a3:0000:0000:8a2e:0370:7334"
    IPV6_NORMALIZED=fwd_normalize_address(IPV6)
    assert  "[2001:db8:85a3:0:0:8a2e:370:7334]" == IPV6_NORMALIZED, "IPV6 equal, should be equal"

    IPV6_2="2001:0db8:85a3::8a2e:0370:7334"
    IPV6

# Generated at 2022-06-21 22:59:32.403116
# Unit test for function format_http1_response
def test_format_http1_response():
    headers = [
        b'Content-Type', b'text/plain',
        b'Content-Length', b'5'
    ]
    assert format_http1_response(200, headers) == b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 5\r\n\r\n"

# Generated at 2022-06-21 22:59:39.617271
# Unit test for function format_http1_response

# Generated at 2022-06-21 22:59:49.926291
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({'forwarded': ['for="_mdnx"; proto=https','for="_mdnx"; proto=https']}, uvloop.Loop()) == {"for": '_mdnx', "proto": "https"}
    assert parse_forwarded({'forwarded': ['for="_mdnx"; proto=https, for=192.0.2.60; proto=http; by=203.0.113.43']}, uvloop.Loop()) == {"for": '_mdnx', "proto": "https"}
    ret = parse_forwarded({'forwarded': ['for="[2001:db8:cafe::17]"; host=example.com; proto=https, for=192.0.2.60; proto=http; by=203.0.113.43']}, uvloop.Loop())

# Generated at 2022-06-21 22:59:54.431017
# Unit test for function fwd_normalize
def test_fwd_normalize():
    # Make a list of options with (key, value) tuples
    def opts(*options):
        return [
            (key.lower(), val)
            for key, val in map(lambda o: o.split("="), options)
        ]

    assert fwd_normalize([]) == {}
    assert fwd_normalize(opts("a=b")) == {"a": "b"}
    assert fwd_normalize(opts("a=1234")) == {"a": "1234"}
    assert fwd_normalize(opts("a=\"1234\"")) == {"a": "1234"}
    assert fwd_normalize(opts("a=1234", "a=4321")) == {"a": "4321"}

    # Check that unknown values are not forwarded

# Generated at 2022-06-21 23:00:04.168743
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("") == (None, None)
    assert parse_host(":1") == (None, None)
    assert parse_host("1:") == (None, None)
    assert parse_host("a:1") == ("a", 1)
    assert parse_host("a:1") == ("a", 1)
    assert parse_host("[::1]:2") == ("::1", 2)
    assert parse_host("a") == ("a", None)

# Generated at 2022-06-21 23:00:13.390167
# Unit test for function format_http1_response
def test_format_http1_response():
    headers = [(b"Content-Type", b"text/html"), (b"Connection", b"Close")]
    assert format_http1_response(403, headers) == (
        b"HTTP/1.1 403 Forbidden\r\n"
        b"Content-Type: text/html\r\n"
        b"Connection: Close\r\n"
        b"\r\n"
    )

# Moved from response.py to here so that request.py can use it

# Generated at 2022-06-21 23:00:18.871514
# Unit test for function parse_content_header
def test_parse_content_header():
    print(parse_content_header("form-data; name=upload; filename=\"file.txt\""))
    print(parse_content_header("form-data; name=upload; filename=\"file.txt\""))


# Generated at 2022-06-21 23:00:28.080361
# Unit test for function format_http1_response
def test_format_http1_response():
    def sh(*args):
        return b": ".join(args) + b"\r\n"
    assert (
        format_http1_response(200, [])
        == b"HTTP/1.1 200 OK\r\n\r\n"
    )
    assert format_http1_response(
        200, [(b"Host", b"example.com"), (b"X-Foo", b"bar")]
    ) == b"HTTP/1.1 200 OK\r\n" + (sh(b"Host", b"example.com") + sh(b"X-Foo", b"bar")) + b"\r\n"

# Generated at 2022-06-21 23:00:43.938224
# Unit test for function fwd_normalize
def test_fwd_normalize():
    fwd_normalize(("for", "unknown"))
    fwd_normalize(("FOR", "unknown"))
    fwd_normalize(("host", "unknown"))
    fwd_normalize(("host", 1))
    fwd_normalize(("port", 1))
    fwd_normalize(("port", "1"))
    fwd_normalize(("path", "/hello"))
    fwd_normalize(("path", "/hello%20"))


# Generated at 2022-06-21 23:00:51.409443
# Unit test for function parse_content_header
def test_parse_content_header():
    # Test key-only
    assert parse_content_header('form-data') == ('form-data', {})
    # Test key-value token
    assert parse_content_header('form-data; name=upload') == ('form-data', {'name': 'upload'})
    # Test key-value quoted
    assert parse_content_header('form-data; name="upload"') == ('form-data', {'name': 'upload'})
    # Test multiple values
    assert parse_content_header('form-data; name="upload"; filename=file.txt') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    # Test escaping
    assert parse_content_header('form-data; name="upload\\"') == ('form-data', {'name': 'upload\\"'})
    #

# Generated at 2022-06-21 23:00:52.430391
# Unit test for function parse_host
def test_parse_host():
    print(parse_host("127.0.0.1:8000"))



# Generated at 2022-06-21 23:01:02.173485
# Unit test for function parse_content_header
def test_parse_content_header():
    file_path = os.path.join(os.path.dirname(__file__), "requests.txt")
    content_type_list = []
    file = open(file_path, "r")
    lines = file.read().split('\n')
    for line in lines:
        if len(line) == 0:
            continue
        content_type_list.append(parse_content_header(line))
    assert len(content_type_list) == 4
    assert content_type_list[0] == ('multipart/form-data', {'boundary': '----WebKitFormBoundaryF88ye2Iz5oIYPtCm'})
    assert content_type_list[1] == ('form-data', {'filename': 'file.txt'})

# Generated at 2022-06-21 23:01:09.314889
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt"'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt"','hehe':'haha'})


# Generated at 2022-06-21 23:01:19.140480
# Unit test for function parse_host
def test_parse_host():
    # Test normal case
    assert "localhost", 80 == parse_host("localhost:80")
    # Test normal IP address
    assert "127.0.0.1", 80 == parse_host("127.0.0.1:80")
    # Test normal IPv6 address
    assert "::1", 80 == parse_host("[::1]:80")
    # Test normal case with missing port
    assert "localhost", None == parse_host("localhost")
    # Test normal IP address with missing port
    assert "127.0.0.1", None == parse_host("127.0.0.1")
    # Test normal IPv6 address with missing port
    assert "::1", None == parse_host("[::1]")
    # Test empty case
    assert None, None == parse_host("")
    # Test strange case
    assert None

# Generated at 2022-06-21 23:01:29.804779
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic import Sanic
    from sanic.response import stream, empty
    from sanic.request import Request
    from sanic.websocket import WebsocketProtocol

    # mock headers
    headers = {
        'X-Forwarded-For': '127.0.0.1, 192.168.0.100',
        'x-forwarded-proto': 'https',
        'X-Forwarded-Port': '80, 443',
        'x-forwarded-path': '/path/to/resource',
        'x-forwarded-host': 'test.test.test'
    }
    config = Sanic().config
    _headers = mock.MagicMock()
    _headers.keys = lambda: headers.keys()
    _headers.get = lambda k: headers[k]
    _request = mock.MagicM

# Generated at 2022-06-21 23:01:35.327383
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = [("X-Forwarded-Host", "foo"), ("X-Forwarded-Port", "443")]
    assert (
        parse_xforwarded(headers=headers, proxies_count=1) == {"host": "foo", "port": 443}
    )

# Generated at 2022-06-21 23:01:49.189974
# Unit test for function format_http1_response
def test_format_http1_response():
    assert format_http1_response(200, []) == b'HTTP/1.1 200 OK\r\n\r\n'
    assert format_http1_response(200, [
        ('HEADER1', 'VALUE1'), ('HEADER2', 'VALUE2')
    ]) == b'HTTP/1.1 200 OK\r\nHEADER1: VALUE1\r\nHEADER2: VALUE2\r\n\r\n'
    assert format_http1_response(
        400, [
            ('HEADER1', 'VALUE1'), ('HEADER2', 'VALUE2')
        ]
    ) == b'HTTP/1.1 400 Bad Request\r\nHEADER1: VALUE1\r\nHEADER2: VALUE2\r\n\r\n'
    assert format_http1

# Generated at 2022-06-21 23:01:57.383689
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    """Tests for function fwd_normalize_address.
    """
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("0:0:0:0:0:0:0:1") == "[::1]"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_Obscured-5") == "_Obscured-5"

# Generated at 2022-06-21 23:02:19.021035
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"X-Real-IP": "122.1.1.1", "X-Forwarded-For": "101.1.1.1, 122.1.1.1, 123.1.1.1"}
    config = {"REAL_IP_HEADER": "x-real-ip", "PROXIES_COUNT": 1, "FORWARDED_FOR_HEADER": "x-forwarded-for"}
    assert parse_xforwarded(headers, config) == {'for': '122.1.1.1'}

# Generated at 2022-06-21 23:02:27.467414
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("_local") == "_local"
    assert fwd_normalize_address("_LOCAL") == "_local"
    assert fwd_normalize_address("::1") == "[::1]"
    assert fwd_normalize_address("::1%0") == "[::1%0]"
    assert fwd_normalize_address("::1%wlan0") == "[::1%wlan0]"
    assert fwd_normalize_address("::1%eth0") == "[::1%eth0]"
    assert fwd_normalize_address("::1%WLAN0") == "[::1%wlan0]"
    assert fwd_normalize_address("::1%ETH0") == "[::1%eth0]"

# Generated at 2022-06-21 23:02:40.576977
# Unit test for function parse_host

# Generated at 2022-06-21 23:02:48.068962
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"X-Forwarded-Host": "www.baidu.com"}
    config = {}
    config["REAL_IP_HEADER"] = None
    config["PROXIES_COUNT"] = None
    config["FORWARDED_FOR_HEADER"] = "X-Forwarded-For"
    options = parse_xforwarded(headers, config)
    print(options)

if __name__ == '__main__':
    test_parse_xforwarded()

# Generated at 2022-06-21 23:02:59.350351
# Unit test for function parse_content_header
def test_parse_content_header():
    value1 = 'multipart/form-data; boundary="--------------------------054510641593619011322344"'
    value2 = 'form-data; name="upload"; filename="file.txt"'
    content_type, options = parse_content_header(value1)
    assert content_type == 'multipart/form-data'
    assert options == {'boundary': '--------------------------054510641593619011322344'}
    content_type, options = parse_content_header(value2)
    assert content_type == 'form-data'
    assert options == {'name':'upload', 'filename':'file.txt'}

if __name__ == "__main__":
    test_parse_content_header()
    print("test_headers.py: all unit tests are passed")

# Generated at 2022-06-21 23:03:09.644413
# Unit test for function parse_host
def test_parse_host():
    host, port = parse_host("192.168.100.100")
    assert host is not None
    assert port is None
    assert host == "192.168.100.100"

    host, port = parse_host("192.168.100.100:80")
    assert host is not None
    assert port is not None
    assert host == "192.168.100.100"
    assert port == 80

    host, port = parse_host("[2002::]:443")
    assert host is not None
    assert port is not None
    assert host == "[2002::]"
    assert port == 443

    host, port = parse_host("[2002::]")
    assert host is not None
    assert port is None
    assert host == "[2002::]"

    host, port = parse_host("localhost")
    assert host is not None

# Generated at 2022-06-21 23:03:12.013414
# Unit test for function format_http1_response
def test_format_http1_response():
    assert format_http1_response(200, [(b"Content-Type", b"text/plain")]) == b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n"

# Generated at 2022-06-21 23:03:14.728860
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("127.0.0.1") == ('127.0.0.1', None)
    assert parse_host("127.0.0.1:1234") == ('127.0.0.1', 1234)
    assert parse_host(">:[>") == (None, None)

# Generated at 2022-06-21 23:03:27.249623
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("example.com") == ("example.com", None)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("example.com:80") == ("example.com", 80)
    assert parse_host("[::1]:1") == ("[::1]", 1)
    assert parse_host("example.com:65535") == ("example.com", 65535)
    assert parse_host("example.com:65636") is None
    assert parse_host("example.com:") is None
    assert parse_host("[::1]:") is None
    assert parse_host("[::1]_:1") is None
    assert parse_host("[::1]:1_") is None

# Generated at 2022-06-21 23:03:38.430477
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"Forwarded": "secret=secret, By=by"}, config) == {
        "secret": "secret", "by": "by"
    }
    assert (
        parse_forwarded(
            {"Forwarded": "secret=secret,by=by;foo, fOO=bar"}, config
        )
        == {"secret": "secret", "by": "by", "foo": "", "foo": "bar"}
    )
    assert parse_forwarded({"Forwarded": "by=by;secret=secret"}, config) is None
    assert parse_forwarded({"Forwarded": "secret=secret"}, config) is None
    assert parse_forwarded({"Forwarded": "secret=secret,"}, config) == {}
    assert parse_forwarded({"Forwarded": "secret=secret, ,"}, config) == {}


# Generated at 2022-06-21 23:04:11.149613
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from .request import Request
    headers={"Forwarded": "for=\"_hidden\", for=192.0.2.60;proto=https"}
    request = Request(None, headers, version=1, parsed_url=None, socket=None, )
    result = parse_forwarded(request,None)
    assert result[0][0] == 'for'
    assert result[0][1] == '192.0.2.60'
    assert result[1][0] == 'proto'
    assert result[1][1] == 'https'



# Generated at 2022-06-21 23:04:16.341143
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    class Dictable(dict):
        def get(self, key, default=None):
            return self.get(key, default)

    # Only X-Forwarded-For
    headers = Dictable()
    headers.__setitem__("X-Forwarded-For", '192.168.1.1, 192.168.1.2, 192.168.1.3')
    assert parse_xforwarded(headers, "sanic.config")
    # Only X-Forwarded-Host
    headers = Dictable()
    headers.__setitem__("X-Forwarded-Host", '192.168.1.1:8080')
    assert parse_xforwarded(headers, "sanic.config")
    # Only X-Forwarded-Proto
    headers = Dictable()

# Generated at 2022-06-21 23:04:22.462060
# Unit test for function parse_content_header
def test_parse_content_header():
    content_type = 'form-data; name=upload; filename="file.txt";'
    value, options = parse_content_header(content_type)
    assert value == 'form-data'
    assert options == {'name': 'upload', 'filename': 'file.txt'}
    # case2: no options
    content_type = 'form-data'
    value, options = parse_content_header(content_type)
    assert value == 'form-data'
    assert options == {}


# Generated at 2022-06-21 23:04:27.379985
# Unit test for function parse_content_header
def test_parse_content_header():
    content = 'form-data; name=upload; filename=\"file.txt\"'
    dict = {'name': 'upload', 'filename': 'file.txt'}

    assert parse_content_header(content)[1] == dict

# Generated at 2022-06-21 23:04:35.410000
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("example.com") == "example.com"
    assert fwd_normalize_address("_example.com") == "_example.com"
    assert fwd_normalize_address("::") == "[::]"
    assert fwd_normalize_address("0:1::2") == "[0:1::2]"
    assert fwd_normalize_address("[::]") == "[::]"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[1::1]") == "[1::1]"

# Generated at 2022-06-21 23:04:43.244076
# Unit test for function fwd_normalize
def test_fwd_normalize():
    from collections import namedtuple
    from urllib.parse import unquote

    fwd = namedtuple('fwd', 'key value')
    assert fwd_normalize(iter([])) == {}

    assert fwd_normalize([fwd('by', '192.168.0.1')]) == {'by': '192.168.0.1'}
    assert fwd_normalize([fwd('host', 'host.example.org'),
                          fwd('proto', 'http'),
                          fwd('port', '80')]) == \
           {'host': 'host.example.org', 'proto': 'http', 'port': 80}
    # TODO: Add test case for 'for'



# Generated at 2022-06-21 23:04:53.724026
# Unit test for function parse_content_header
def test_parse_content_header():
    key, value = parse_content_header('form-data; name=upload; filename="file.txt"')
    assert key == 'form-data'
    assert value['name'] == 'upload'
    assert value['filename'] == 'file.txt'

    key, value = parse_content_header('form-data; name="quoted"')
    assert key == 'form-data'
    assert value['name'] == 'quoted'

    # Note: no need to test a case where every single character is quoted, this
    # is already handled by the regex.

    # Test that the '%' character is not unescaped
    key, value = parse_content_header('form-data; name="%quote"')
    assert key == 'form-data'
    assert value['name'] == '%quote'

    # Test that the '

# Generated at 2022-06-21 23:05:03.656552
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    """ Test the function parse_xforwarded"""
    from sanic import Sanic
    app = Sanic(__name__)
    app.config.PROXIES_COUNT = 1
    app.config.FORWARDED_FOR_HEADER = 'x-forwarded-for'
    app.config.FORWARDED_PROTO_HEADER = 'x-scheme'
    app.config.FORWARDED_HOST_HEADER = 'x-forwarded-host'
    app.config.FORWARDED_PORT_HEADER = 'x-forwarded-port'
    app.config.FORWARDED_PATH_HEADER = 'x-forwarded-path'

# Generated at 2022-06-21 23:05:10.289195
# Unit test for function fwd_normalize

# Generated at 2022-06-21 23:05:20.969406
# Unit test for function fwd_normalize
def test_fwd_normalize():
    # Excepted result
    excepted_result = {"by": "192.168.1.6", "proto": "https", "host": "example.com", "port": 3000}
    # Test data

# Generated at 2022-06-21 23:06:13.097163
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"real-ip": "127.0.0.1"}
    config = RequestConfig()
    assert parse_xforwarded(headers, config) == {"for": "127.0.0.1"}


# Unit tests for function parse_xforwarded, assert the parsed output of
# x-forwarded-for, x-forwarded-proto, x-forwarded-port and x-forwarded-host
# headers with various setings of PROXIES_COUNT, REAL_IP_HEADER,
# FORWARDED_FOR_HEADER and FORWARDED_PROTO_HEADER