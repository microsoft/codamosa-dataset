

# Generated at 2022-06-18 05:14:05.956752
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    app = Sanic()
    app.config.FORWARDED_SECRET = "secret"

    @app.route("/")
    async def test(request: Request) -> HTTPResponse:
        return HTTPResponse(
            "",
            headers={
                "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43"
            },
        )

    request, response = app.test_client.get("/")
    assert response.status == 200

# Generated at 2022-06-18 05:14:14.655683
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/test',
        'x-forwarded-proto': 'https',
        'x-forwarded-for': '192.168.1.1, 192.168.1.2, 192.168.1.3'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }

# Generated at 2022-06-18 05:14:26.164308
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/path/to/file",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:14:38.055190
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:14:49.913271
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    config = Config()
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.PROXIES_COUNT = 2
    headers = {
        "X-Real-IP": "127.0.0.1",
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2, 192.168.1.3",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Path": "/test",
        "X-Scheme": "https",
        "X-Forwarded-Proto": "http",
    }
    assert parse_x

# Generated at 2022-06-18 05:15:02.863054
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {"for": "127.0.0.2"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2"), ("for", "127.0.0.3")]) == {"for": "127.0.0.3"}

# Generated at 2022-06-18 05:15:13.749607
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'http',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-path': '/path',
        'x-forwarded-proto': 'https',
    }
    config = {
        'REAL_IP_HEADER': 'x-real-ip',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': '',
    }

# Generated at 2022-06-18 05:15:26.064484
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:15:36.018563
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketCommonWriter
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketCommonReader
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocket

# Generated at 2022-06-18 05:15:47.291830
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/path/to/resource",
        "x-scheme": "https",
    }
    config = {
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "REAL_IP_HEADER": "x-forwarded-for",
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:16:02.690416
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.headers.get("X-Forwarded-For"))

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(request.headers.get("X-Forwarded-For"))

    config = Config()


# Generated at 2022-06-18 05:16:13.947506
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("proto", "https")]) == {
        "for": "1.2.3.4",
        "proto": "https",
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("proto", "https"), ("host", "example.com")]) == {
        "for": "1.2.3.4",
        "proto": "https",
        "host": "example.com",
    }

# Generated at 2022-06-18 05:16:24.300724
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:16:34.411619
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.request import Request
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43;secret=secret"}
    request = Request(headers=headers, config=config)
    assert request.forwarded_for == "192.0.2.60"
    assert request.forwarded_proto == "http"
    assert request.forwarded_host == None
    assert request.forwarded_port == None
    assert request.forwarded_path == None
    headers = {"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43;host=example.com;secret=secret"}

# Generated at 2022-06-18 05:16:45.499227
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}

# Generated at 2022-06-18 05:16:56.290682
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:17:05.906299
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize

# Generated at 2022-06-18 05:17:12.332828
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt'})


# Generated at 2022-06-18 05:17:16.900596
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:17:27.913750
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:17:45.174628
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {"for": "127.0.0.2"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2"), ("for", "127.0.0.3")]) == {"for": "127.0.0.3"}

# Generated at 2022-06-18 05:17:56.697282
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {"for": "1.2.3.4", "by": "5.6.7.8"}

# Generated at 2022-06-18 05:18:03.720709
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": None,
        "FORWARDED_FOR_HEADER": None,
    }
    assert parse_xforwarded(headers, config) == {
        "proto": "https",
        "host": "example.com",
        "port": 443,
        "path": "/",
    }

# Generated at 2022-06-18 05:18:14.945343
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:18:27.178227
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:8000") == ("localhost", 8000)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:8000") == ("[::1]", 8000)
    assert parse_host("[::1]:8000") == ("[::1]", 8000)
    assert parse_host("[::1]:8000") == ("[::1]", 8000)
    assert parse_host("[::1]:8000") == ("[::1]", 8000)
    assert parse_host("[::1]:8000") == ("[::1]", 8000)
    assert parse_host("[::1]:8000") == ("[::1]", 8000)

# Generated at 2022-06-18 05:18:39.591993
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"
    }
    config = {
        "FORWARDED_SECRET": "secret"
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.60",
        "proto": "http",
        "by": "203.0.113.43",
    }
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43"
    }

# Generated at 2022-06-18 05:18:51.869091
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17;proto=https;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17;proto=https;by=203.0.113.43",
        ]
    }

# Generated at 2022-06-18 05:19:01.646000
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-proto": "http",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-path": "/",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:19:14.037125
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'x-forwarded-proto': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:19:22.455482
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {
        "for": "1.2.3.4"
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {
        "for": "1.2.3.4"
    }

# Generated at 2022-06-18 05:19:44.736694
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/",
        "x-forwarded-for": "192.0.2.1",
    }
    config = {"PROXIES_COUNT": 1, "FORWARDED_FOR_HEADER": "x-forwarded-for"}
    assert parse_xforwarded(headers, config) == {
        "for": "192.0.2.1",
        "proto": "https",
        "host": "example.com",
        "port": 443,
        "path": "/",
    }

# Generated at 2022-06-18 05:19:54.592500
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1",
        "x-forwarded-proto": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:20:06.160927
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '%2Fpath%2Fto%2Fresource',
        'x-scheme': 'http',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:20:11.644233
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:80") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:80") == "[::1]"
    assert fwd_normalize_address("_obfuscated") == "_obfuscated"
    assert fwd_normalize_address("_obfuscated:80") == "_obfuscated"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown:80") == "unknown"

# Generated at 2022-06-18 05:20:22.243452
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "192.168.1.1",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:20:34.701694
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter

# Generated at 2022-06-18 05:20:45.675523
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.views import CompositionView
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.server import serve
    from sanic.testing import SanicTestClient
    from sanic.testing import HOST, PORT
    from sanic.testing import _create_test_server
    from sanic.testing import _create_test_client
    from sanic.testing import _create_test_app
    from sanic.testing import _create_test_request
    from sanic.testing import _create_

# Generated at 2022-06-18 05:20:56.088067
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {'X-Forwarded-For': '127.0.0.1', 'X-Forwarded-Host': '127.0.0.1', 'X-Forwarded-Port': '8080', 'X-Forwarded-Path': '127.0.0.1'}
    config = {'REAL_IP_HEADER': 'X-Forwarded-For', 'PROXIES_COUNT': 1, 'FORWARDED_FOR_HEADER': 'X-Forwarded-For'}
    assert parse_xforwarded(headers, config) == {'for': '127.0.0.1', 'host': '127.0.0.1', 'port': 8080, 'path': '127.0.0.1'}

# Generated at 2022-06-18 05:21:07.746544
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.0.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/path/to/resource'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:21:19.664514
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": 2,
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
    }

# Generated at 2022-06-18 05:21:37.305441
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '127.0.0.1, 127.0.0.2',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'http',
        'X-Forwarded-Path': '/test',
    }

# Generated at 2022-06-18 05:21:45.697666
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43']}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17', 'proto': 'https', 'by': '203.0.113.43'}
    headers = {'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43']}

# Generated at 2022-06-18 05:21:57.330047
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "192.168.0.1",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": "",
    }

# Generated at 2022-06-18 05:22:08.488080
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": None,
        "FORWARDED_FOR_HEADER": None,
    }
    assert parse_xforwarded(headers, config) == {
        "proto": "https",
        "host": "example.com",
        "port": 443,
        "path": "/path/to/resource",
    }



# Generated at 2022-06-18 05:22:15.521679
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    print(parse_forwarded(headers, config))

if __name__ == '__main__':
    test_parse_forwarded()

# Generated at 2022-06-18 05:22:24.055486
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret")]) == {
        "for": "1.2.3.4",
        "by": "secret",
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret"), ("by", "secret")]) == {
        "for": "1.2.3.4",
        "by": "secret",
    }

# Generated at 2022-06-18 05:22:33.271132
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43"
    }
    config = {
        "FORWARDED_SECRET": "secret"
    }
    result = parse_forwarded(headers, config)
    assert result == {
        "for": "192.0.2.60",
        "proto": "http",
        "by": "203.0.113.43"
    }

# Generated at 2022-06-18 05:22:44.603483
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:8080") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:8080") == "[::1]"
    assert fwd_normalize_address("_obfuscated") == "_obfuscated"
    assert fwd_normalize_address("_obfuscated:8080") == "_obfuscated"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown:8080") == "unknown"

# Generated at 2022-06-18 05:22:55.929704
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:80") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:80") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret:80") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown:80") == "unknown"
    assert fwd_normalize_address("_secret:80") == "_secret"

# Generated at 2022-06-18 05:23:07.083495
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}

# Generated at 2022-06-18 05:23:36.204019
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "http",
        "X-Forwarded-Path": "/test",
    }
    config = {
        "REAL_IP_HEADER": "X-Forwarded-For",
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:23:43.510518
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret"
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "http",
        "by": "203.0.113.43",
    }



# Generated at 2022-06-18 05:23:53.024232
# Unit test for function parse_forwarded