

# Generated at 2022-06-18 05:13:27.656673
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "9.10.11.12"}

# Generated at 2022-06-18 05:13:38.658463
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {"for": "127.0.0.2"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2"), ("for", "127.0.0.3")]) == {"for": "127.0.0.3"}

# Generated at 2022-06-18 05:13:49.909392
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;by=203.0.113.43;secret=secret']}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17', 'by': '203.0.113.43', 'secret': 'secret'}
    headers = {'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;by=203.0.113.43;secret=wrong']}
    assert parse_forward

# Generated at 2022-06-18 05:14:01.649400
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "::1")]) == {"for": "[::1]"}
    assert fwd_normalize([("for", "::1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "::1"), ("for", "127.0.0.1"), ("for", "::1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "::1"), ("for", "127.0.0.1"), ("for", "::1"), ("for", "127.0.0.1")])

# Generated at 2022-06-18 05:14:11.522179
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:14:23.392562
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '443',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'http',
    }
    config = {
        'REAL_IP_HEADER': None,
        'PROXIES_COUNT': 0,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
    }

# Generated at 2022-06-18 05:14:36.176383
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43",
            "for=192.0.2.43;proto=http;by=203.0.113.43,for=192.0.2.60;proto=http;by=203.0.113.43",
        ]
    }

# Generated at 2022-06-18 05:14:46.981704
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:14:55.034299
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-proto': 'https',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }
    options = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:15:04.036424
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "1.2.3.4",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "path",
    }
    config = {
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "REAL_IP_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:15:22.106256
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:15:31.743410
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed

    app = Sanic('test_parse_forwarded')

    @app.route('/')
    async def handler(request):
        return HTTPResponse(request.headers.get('X-Forwarded-For'))

    @app.websocket('/ws')
    async def ws_handler(request, ws):
        try:
            while True:
                await ws.recv()
        except ConnectionClosed:
            pass

    config = Config()
    config

# Generated at 2022-06-18 05:15:41.048422
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "192.168.1.1, 192.168.1.2, 192.168.1.3",
    }
    config = {
        "REAL_IP_HEADER": "x-real-ip",
        "PROXIES_COUNT": 3,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": "",
    }

# Generated at 2022-06-18 05:15:46.675615
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43']}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:15:57.748844
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/test",
    }
    config = type("Config", (object,), {"PROXIES_COUNT": 1})()
    assert parse_xforwarded(headers, config) == {
        "for": "127.0.0.1",
        "host": "example.com",
        "port": 80,
        "proto": "https",
        "path": "/test",
    }

# Generated at 2022-06-18 05:16:08.486972
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:80") == ("localhost", 80)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:80") == ("[::1]", 80)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:65535") == ("[::1]", 65535)
    assert parse_host("[::1]:65536") == (None, None)
    assert parse_host("[::1]:-1") == (None, None)
    assert parse_host("[::1]:0") == (None, None)

# Generated at 2022-06-18 05:16:19.499785
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17",
            "for=192.0.2.43, for=198.51.100.17;by=203.0.113.43",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "REAL_IP_HEADER": "x-real-ip",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:16:27.747974
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '443',
        'X-Forwarded-Path': '/path/to/resource',
    }

# Generated at 2022-06-18 05:16:36.599338
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {"for": "1.2.3.4", "by": "5.6.7.8"}

# Generated at 2022-06-18 05:16:46.567637
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '127.0.0.1',
        'x-forwarded-host': '127.0.0.1',
        'x-forwarded-port': '8080',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:17:02.904966
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {
        "for": "1.2.3.4"
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret")]) == {
        "for": "1.2.3.4",
        "by": "secret",
    }

# Generated at 2022-06-18 05:17:15.114828
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-proto': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': '',
        'PROXIES_COUNT': 0,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:17:25.897583
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {"for": "127.0.0.2"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2"), ("for", "127.0.0.3")]) == {"for": "127.0.0.3"}

# Generated at 2022-06-18 05:17:34.220551
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "192.0.2.60, 2001:db8:cafe::17",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 2,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": "secret",
    }

# Generated at 2022-06-18 05:17:45.493539
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/test',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
    }

# Generated at 2022-06-18 05:17:57.071688
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4:80")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4:8080")]) == {"for": "1.2.3.4", "port": 8080}
    assert fwd_normalize([("for", "1.2.3.4:8080"), ("port", "80")]) == {"for": "1.2.3.4", "port": 8080}

# Generated at 2022-06-18 05:18:08.195345
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    import socket
    import asyncio

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1

    class TestServer(HttpProtocol):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.app = app


# Generated at 2022-06-18 05:18:18.503921
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/path/to/file",
    }

# Generated at 2022-06-18 05:18:29.963566
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/path/to/file.html",
    }

# Generated at 2022-06-18 05:18:42.154414
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.0.1")]) == {"for": "192.168.0.1"}
    assert fwd_normalize([("for", "192.168.0.1"), ("for", "192.168.0.1")]) == {"for": "192.168.0.1"}
    assert fwd_normalize([("for", "192.168.0.1"), ("for", "192.168.0.2")]) == {"for": "192.168.0.2"}
    assert fwd_normalize([("for", "192.168.0.1"), ("for", "192.168.0.2"), ("for", "192.168.0.3")]) == {"for": "192.168.0.3"}

# Generated at 2022-06-18 05:18:59.218023
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}

# Generated at 2022-06-18 05:19:06.097767
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {"for": "127.0.0.2"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2"), ("for", "127.0.0.3")]) == {"for": "127.0.0.3"}

# Generated at 2022-06-18 05:19:17.619053
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:19:28.500937
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "PROXIES_COUNT": 1,
        "REAL_IP_HEADER": "x-real-ip",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }
    assert parse_xforwarded(headers, config) == {
        "host": "example.com",
        "port": 443,
        "proto": "https",
        "path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:19:32.236350
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:19:43.868506
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/",
    }
    config = {
        "REAL_IP_HEADER": None,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }
    assert parse_xforwarded(headers, config) == {
        "for": "127.0.0.1",
        "host": "example.com",
        "port": 80,
        "proto": "http",
        "path": "/",
    }



# Generated at 2022-06-18 05:19:53.479343
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1, 127.0.0.2",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 2,
    }

# Generated at 2022-06-18 05:20:00.629212
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.views import HTTPMethodView

    class TestView(HTTPMethodView):
        def get(self, request):
            return HTTPResponse(request.forwarded)

    config = Config()
    config.FORWARDED_SECRET = "secret"
    app = Sanic("test_parse_forwarded")
    app.add_route(TestView.as_view(), "/")
    protocol = HttpProtocol(app, config)

# Generated at 2022-06-18 05:20:11.551625
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:20:22.109122
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/path/to/resource',
        'x-scheme': 'https',
    }
    config = {
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': '',
        'REAL_IP_HEADER': '',
    }

# Generated at 2022-06-18 05:20:45.856761
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43"
    }
    config = {
        "FORWARDED_SECRET": "secret"
    }
    assert parse_forwarded(headers, config) == {
        "for": "198.51.100.17",
        "proto": "https",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:20:56.897883
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.PROXIES_COUNT = 0
    config.REAL_IP_HEADER = None

    # Test that the function returns None if no secret is found
    headers = {"forwarded": "for=127.0.0.1; by=127.0.0.1"}
    assert parse_forwarded(headers, config) is None

    # Test that the function returns None if no secret is found

# Generated at 2022-06-18 05:21:03.668464
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:21:11.347335
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:21:22.348114
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2',
        'x-forwarded-host': 'example.com',
        'x-forwarded-proto': 'https',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:21:34.107978
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with a valid Forwarded header
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

    # Test with a valid Forwarded header with multiple values
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}

# Generated at 2022-06-18 05:21:41.122889
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:21:48.071590
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {
        "for": "1.2.3.4",
        "by": "5.6.7.8",
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8"), ("for", "9.10.11.12")]) == {
        "for": "9.10.11.12",
        "by": "5.6.7.8",
    }
    assert fwd_normal

# Generated at 2022-06-18 05:21:58.968106
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret")]) == {"for": "1.2.3.4", "by": "secret"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8", "by": "secret"}

# Generated at 2022-06-18 05:22:10.376030
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;by=203.0.113.43;proto=https'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;by=203.0.113.43;proto=https'}

# Generated at 2022-06-18 05:22:45.799875
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:22:56.738477
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/test",
    }

# Generated at 2022-06-18 05:23:07.875000
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '443',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/foo/bar',
        'X-Scheme': 'http',
    }
    config = {
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'REAL_IP_HEADER': 'X-Forwarded-For',
    }

# Generated at 2022-06-18 05:23:16.229617
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-proto": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": None,
    }