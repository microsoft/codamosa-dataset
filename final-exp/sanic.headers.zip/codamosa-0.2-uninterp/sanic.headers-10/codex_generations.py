

# Generated at 2022-06-18 05:13:23.096380
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename=\"file.txt\"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt;') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt; ') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:13:30.147421
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'http',
        'X-Forwarded-Path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:13:40.768367
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {
        "for": "1.2.3.4",
        "by": "5.6.7.8",
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8"), ("by", "9.10.11.12")]) == {
        "for": "1.2.3.4",
        "by": "9.10.11.12",
    }

# Generated at 2022-06-18 05:13:47.282445
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("UNKNOWN") == "unknown"
    assert fwd_normalize_address("Unknown") == "unknown"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("UNKNOWN") == "unknown"
    assert fwd_normalize_address("Unknown") == "unknown"
    assert fwd_normalize_address

# Generated at 2022-06-18 05:13:57.475545
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:14:08.072174
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:14:18.147688
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret")]) == {"for": "1.2.3.4", "by": "secret"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4", "by": "secret"}

# Generated at 2022-06-18 05:14:27.828655
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient
    from sanic.testing import create_server

    app = Sanic("test_parse_forwarded")
    app.config.FORWARDED_SECRET = "secret"

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.forwarded)


# Generated at 2022-06-18 05:14:39.274884
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient
    from sanic.testing import create_server

    app = Sanic("test_parse_xforwarded")


# Generated at 2022-06-18 05:14:50.717602
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.1.1")]) == {"for": "192.168.1.1"}
    assert fwd_normalize([("for", "192.168.1.1"), ("for", "192.168.1.2")]) == {"for": "192.168.1.1"}
    assert fwd_normalize([("for", "192.168.1.1"), ("for", "192.168.1.2"), ("for", "192.168.1.3")]) == {"for": "192.168.1.1"}

# Generated at 2022-06-18 05:15:04.378764
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-proto": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": None,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:15:14.203518
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17;by=203.0.113.43",
            "for=192.0.2.43,for=198.51.100.17;by=203.0.113.43",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "http",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:15:20.913305
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for=192.0.2.60; proto=http; by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:15:27.478212
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;host=example.com;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'host': 'example.com', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:15:34.248493
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/path/to/resource'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:15:44.248360
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.request import Request
    from sanic.config import Config
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.testing import HOST, PORT
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.views import CompositionView
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.response import json
    from sanic.response import text
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream

# Generated at 2022-06-18 05:15:55.582874
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:8080") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:8080") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret:8080") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown:8080") == "unknown"

# Generated at 2022-06-18 05:16:04.115258
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, "secret") == {"for": "192.0.2.60", "proto": "http", "by": "203.0.113.43"}
    assert parse_forwarded({"forwarded": "for=192.0.2.43, for=198.51.100.17"}, "secret") == {"for": "198.51.100.17"}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, "secret") == {"for": "192.0.2.60", "proto": "http", "by": "203.0.113.43"}
    assert parse_

# Generated at 2022-06-18 05:16:15.467395
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-proto": "https",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:16:25.305989
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/path",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": None,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:16:37.574607
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/',
        'x-scheme': 'https',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': '',
    }

# Generated at 2022-06-18 05:16:47.200176
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient
    from sanic.testing import create_server

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(text=str(request.forwarded))

    @app.websocket("/ws")
    async def handler(request, ws):
        await ws.send(str(request.forwarded))


# Generated at 2022-06-18 05:16:57.364039
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'www.example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/path/to/resource',
        'x-scheme': 'https',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': '',
    }

# Generated at 2022-06-18 05:17:06.656045
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.0.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-proto': 'https',
        'x-scheme': 'http',
        'x-forwarded-path': '/test'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': ''
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:17:17.567408
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {
        "for": "5.6.7.8"
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret")]) == {
        "for": "1.2.3.4",
        "by": "secret",
    }

# Generated at 2022-06-18 05:17:28.639743
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("_127.0.0.1") == "_127.0.0.1"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_unknown") == "_unknown"
    assert fwd_normalize_address("_unknown_") == "_unknown_"
    assert fwd_normalize_address("_unknown_1") == "_unknown_1"
    assert fwd_normalize_address("_unknown_1_") == "_unknown_1_"
    assert fwd_normalize_address("_unknown_1_2") == "_unknown_1_2"

# Generated at 2022-06-18 05:17:35.599442
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'x-forwarded-host': 'example.com',
        'x-forwarded-proto': 'https',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:17:46.316243
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17",
        ]
    }
    config = type("Config", (object,), {"FORWARDED_SECRET": "secret"})
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "http",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:17:55.211899
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17;by=203.0.113.43'
    }
    config = {
        'FORWARDED_SECRET': 'secret'
    }
    assert parse_forwarded(headers, config) == {
        'for': '192.0.2.43',
        'proto': 'http',
        'by': '203.0.113.43'
    }

# Generated at 2022-06-18 05:18:04.018443
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test cases from RFC 7239
    # https://tools.ietf.org/html/rfc7239#section-4
    assert parse_forwarded(
        {"forwarded": ["for=192.0.2.60;proto=http;by=203.0.113.43"]},
        type("", (), {"FORWARDED_SECRET": None}),
    ) == {"for": "192.0.2.60", "proto": "http", "by": "203.0.113.43"}
    assert parse_forwarded(
        {"forwarded": ["for=192.0.2.43, for=198.51.100.17"]},
        type("", (), {"FORWARDED_SECRET": None}),
    ) == {"for": "198.51.100.17"}
    assert parse_forwarded

# Generated at 2022-06-18 05:18:22.049554
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:80") == ("localhost", 80)
    assert parse_host("localhost:8080") == ("localhost", 8080)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:80") == ("[::1]", 80)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)

# Generated at 2022-06-18 05:18:33.065253
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": 0,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:18:45.668136
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("example.com") == ("example.com", None)
    assert parse_host("example.com:80") == ("example.com", 80)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:80") == ("[::1]", 80)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:65535") == ("[::1]", 65535)
    assert parse_host("[::1]:65536") == (None, None)
    assert parse_host("[::1]:65537") == (None, None)
    assert parse_host("[::1]:65538") == (None, None)

# Generated at 2022-06-18 05:18:56.945728
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse

    config = Config()
    config.FORWARDED_SECRET = "secret"

    # Test with no secret
    config.FORWARDED_SECRET = None
    request = Request("GET", "/", headers={"Forwarded": "for=1.2.3.4"})
    assert request.forwarded == None

    # Test with secret
    config.FORWARDED_SECRET = "secret"
    request = Request("GET", "/", headers={"Forwarded": "for=1.2.3.4"})
    assert request.forwarded == None

    # Test with secret
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:19:04.963035
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.forwarded)

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(request.forwarded)

    # Start server
    server = app.create_server(
        HOST, PORT, protocol=HttpProtocol, websocket_protocol=WebSocketProtocol
    )

# Generated at 2022-06-18 05:19:17.009715
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.PROXIES_COUNT = 1

    # Test HTTP

# Generated at 2022-06-18 05:19:29.004258
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-scheme": "https",
    }

# Generated at 2022-06-18 05:19:41.491980
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.testing import HOST, PORT

    app = Sanic("test_parse_xforwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(text="OK")

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send("OK")


# Generated at 2022-06-18 05:19:48.680890
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:80") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:80") == "[::1]"
    assert fwd_normalize_address("example.com") == "example.com"
    assert fwd_normalize_address("example.com:80") == "example.com"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret:80") == "_secret"

# Generated at 2022-06-18 05:19:57.693546
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1, 192.168.1.2, 192.168.1.3",
        "x-forwarded-host": "example.com",
        "x-forwarded-proto": "https",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/test",
    }
    config = type("Config", (), {"PROXIES_COUNT": 3})
    assert parse_xforwarded(headers, config) == {
        "for": "192.168.1.3",
        "proto": "https",
        "host": "example.com",
        "port": 443,
        "path": "/test",
    }

# Generated at 2022-06-18 05:20:19.104263
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/test",
        "x-forwarded-for": "1.2.3.4, 5.6.7.8",
    }
    config = {
        "REAL_IP_HEADER": "x-real-ip",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 2,
    }

# Generated at 2022-06-18 05:20:27.223500
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.testing import HOST, PORT
    from sanic.views import CompositionView
    from sanic.router import Router
    from sanic.blueprints import Blueprint
    from sanic.response import text
    from sanic.response import json
    from sanic.response import html
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream
    from sanic.response import redirect

# Generated at 2022-06-18 05:20:35.557491
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "1.2.3.4",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = type("Config", (), {"PROXIES_COUNT": 1})
    assert parse_xforwarded(headers, config) == {
        "for": "1.2.3.4",
        "host": "example.com",
        "port": 80,
        "proto": "https",
        "path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:20:39.395571
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17;by=203.0.113.60",
            "for=192.0.2.43, for=198.51.100.17;by=203.0.113.60, for=192.0.2.60;proto=http;by=203.0.113.43",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret"
    }

# Generated at 2022-06-18 05:20:49.755358
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Path": "/path/to/file",
    }

# Generated at 2022-06-18 05:20:59.256840
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:21:09.689757
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.testing import HOST, PORT
    from sanic.views import CompositionView
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.response import json
    from sanic.response import text
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream

# Generated at 2022-06-18 05:21:21.397386
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {"for": "127.0.0.2"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2"), ("for", "127.0.0.3")]) == {"for": "127.0.0.3"}

# Generated at 2022-06-18 05:21:32.491366
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = 'secret'
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:21:43.197884
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43']}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43']}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
   

# Generated at 2022-06-18 05:22:01.867874
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17",
            "for=192.0.2.43;by=203.0.113.43;secret=secret",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
        "REAL_IP_HEADER": "X-Real-IP",
        "PROXIES_COUNT": 3,
    }

# Generated at 2022-06-18 05:22:11.790531
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;host=example.com;port=80;path=/;by=203.0.113.43;secret=abcdefg"
    }
    config = {
        "FORWARDED_SECRET": "abcdefg"
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.60",
        "proto": "http",
        "host": "example.com",
        "port": 80,
        "path": "/",
        "by": "203.0.113.43",
        "secret": "abcdefg"
    }

# Generated at 2022-06-18 05:22:22.450779
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, None) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.60;proto=http;by=203.0.113.43"}, None) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:22:33.778145
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import RequestParameters
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketEvent

# Generated at 2022-06-18 05:22:45.710803
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("_127.0.0.1") == "_127.0.0.1"
    assert fwd_normalize_address("_127.0.0.1") == "_127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("UNKNOWN") == "unknown"
    assert fwd_normalize_address("_unknown") == "_unknown"
    assert fwd_normalize_address("_UNKNOWN") == "_UNKNOWN"

# Generated at 2022-06-18 05:22:56.642805
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("192.168.1.1") == "192.168.1.1"
    assert fwd_normalize_address("_192.168.1.1") == "_192.168.1.1"
    assert fwd_normalize_address("2001:0db8:85a3:0000:0000:8a2e:0370:7334") == "[2001:0db8:85a3:0000:0000:8a2e:0370:7334]"
    assert fwd_normalize_address("_2001:0db8:85a3:0000:0000:8a2e:0370:7334") == "_2001:0db8:85a3:0000:0000:8a2e:0370:7334"

# Generated at 2022-06-18 05:23:07.787363
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "X-Real-Ip"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.PROXIES_COUNT = 1

    # Test HTTP
    protocol = HttpProtocol(config=config)

# Generated at 2022-06-18 05:23:16.185738
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17', 'proto': 'https', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.43, for=198.51.100.17;proto=https;by=203.0.113.43'}