

# Generated at 2022-06-18 05:14:05.645840
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:14:13.757658
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1, 192.168.1.2, 192.168.1.3",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:14:25.428839
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {
        "for": "127.0.0.1"
    }
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {
        "for": "127.0.0.2"
    }
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "::1")]) == {
        "for": "::1"
    }
    assert f

# Generated at 2022-06-18 05:14:37.806790
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient
    from sanic.testing import create_server
    from sanic.testing import create_test_server

    app = Sanic("test_parse_xforwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.headers.get("X-Forwarded-For"))


# Generated at 2022-06-18 05:14:45.898775
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:14:55.021023
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:80") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:80") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret:80") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown:80") == "unknown"
    assert fwd_normalize_address("_secret:80") == "_secret"

# Generated at 2022-06-18 05:15:04.005695
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:80") == ("localhost", 80)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:80") == ("[::1]", 80)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_

# Generated at 2022-06-18 05:15:14.002093
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;by=203.0.113.43;host=example.com;proto=https",
            "for=192.0.2.43, for=198.51.100.17;by=203.0.113.43",
        ]
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:15:26.105779
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter

# Generated at 2022-06-18 05:15:36.061757
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:80") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:80") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret:80") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown:80") == "unknown"
    assert fwd_normalize_address("_secret:unknown") == "_secret:unknown"


# Generated at 2022-06-18 05:15:49.977476
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'http',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-path': '/path/to/resource',
        'x-forwarded-for': '192.168.1.1, 192.168.1.2, 192.168.1.3'
    }
    config = {
        'REAL_IP_HEADER': '',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for'
    }

# Generated at 2022-06-18 05:16:02.040735
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    config = Config()
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:16:08.097261
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource'
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'FORWARDED_SECRET': 'secret'
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:16:13.203405
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:16:23.769727
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename=\"file.txt\"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt;') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:16:34.188192
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}
    config = {"FORWARDED_SECRET": "secret"}
    assert parse_forwarded(headers, config) == {"for": "192.0.2.60", "proto": "http"}

    headers = {"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}
    config = {"FORWARDED_SECRET": "wrong"}
    assert parse_forwarded(headers, config) == None

    headers = {"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}
    config = {"FORWARDED_SECRET": "secret"}
    assert parse_forwarded

# Generated at 2022-06-18 05:16:45.303556
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.0.2.43")]) == {"for": "192.0.2.43"}
    assert fwd_normalize([("for", "192.0.2.43"), ("by", "example.com")]) == {
        "for": "192.0.2.43",
        "by": "example.com",
    }
    assert fwd_normalize([("for", "192.0.2.43"), ("by", "example.com"), ("by", "example.com")]) == {
        "for": "192.0.2.43",
        "by": "example.com",
    }

# Generated at 2022-06-18 05:16:55.995415
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    config = Config()
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.PROXIES_COUNT = 1
    headers = {
        "X-Real-IP": "127.0.0.1",
        "X-Forwarded-For": "127.0.0.1, 127.0.0.2",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Path": "/path",
        "X-Scheme": "http",
        "X-Forwarded-Proto": "https",
    }

# Generated at 2022-06-18 05:17:05.667996
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:17:16.714137
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "http",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-path": "/path",
        "x-forwarded-for": "127.0.0.1",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:17:32.337138
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2, 192.168.1.3",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "443",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:17:44.800105
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1


# Generated at 2022-06-18 05:17:56.182802
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import pytest
    from sanic.config import Config
    from sanic.request import RequestParameters

    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = RequestParameters()
    headers.add("forwarded", "for=192.0.2.60;proto=http;by=203.0.113.43")
    headers.add("forwarded", "for=192.0.2.43, for=198.51.100.17")
    headers.add("forwarded", "secret=secret;for=192.0.2.43;by=203.0.113.43")
    headers.add("forwarded", "secret=secret;for=192.0.2.43;by=203.0.113.43")

# Generated at 2022-06-18 05:18:04.664306
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "127.0.0.1, 192.168.1.1",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Path": "/path/to/file",
    }

# Generated at 2022-06-18 05:18:13.374303
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60; proto=http; by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17",
        ]
    }
    config = {"FORWARDED_SECRET": "secret"}
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "http",
        "by": "203.0.113.43",
    }



# Generated at 2022-06-18 05:18:20.759970
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17;proto=https;by=203.0.113.43",
        ]
    }
    config = {"FORWARDED_SECRET": "secret"}
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "https",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:18:31.673842
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.request import Request
    from sanic.config import Config
    from sanic.exceptions import InvalidUsage
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.log import logger
    from sanic.constants import HTTP_METHODS
    import socket
    import asyncio
    import pytest
    import os
    import sys
    import time
    import json
    import logging
    import random
    import string

    # Create a Sanic application
    app = Sanic()

    # Create a Sanic application
    app = Sanic()

    # Create a Sanic application
    app = Sanic()

    # Create

# Generated at 2022-06-18 05:18:44.061441
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/",
    }

# Generated at 2022-06-18 05:18:51.189711
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "9.10.11.12"}

# Generated at 2022-06-18 05:18:59.103932
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/test",
    }
    config = {
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "REAL_IP_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:19:17.052066
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;by=203.0.113.43']}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:19:29.005248
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=https"}, {"FORWARDED_SECRET": "secret"}) == {"for": "192.0.2.60", "proto": "https"}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=https, for=192.0.2.60;proto=https"}, {"FORWARDED_SECRET": "secret"}) == {"for": "192.0.2.60", "proto": "https"}

# Generated at 2022-06-18 05:19:38.366805
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/",
    }
    assert parse_xforwarded(headers, None) == {
        "for": "192.168.1.1",
        "host": "example.com",
        "port": 80,
        "proto": "http",
        "path": "/",
    }

# Generated at 2022-06-18 05:19:47.883051
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '443',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'FORWARDED_SECRET': None,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:19:57.650312
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.PROXIES_COUNT = 0
    config.REAL_IP_HEADER = None

    # Test with no secret
    config.FORWARDED_SECRET = None
    assert parse_forwarded({"Forwarded": "for=1.2.3.4"}, config) is None

    # Test with secret
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:20:09.233298
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:20:13.546730
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43, for=198.51.100.17'
    }
    config = {
        'FORWARDED_SECRET': 'secret'
    }
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:20:23.629256
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:20:35.486018
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/test",
    }
    assert parse_xforwarded(headers, None) == {
        "for": "127.0.0.1",
        "host": "example.com",
        "port": 80,
        "proto": "http",
        "path": "/test",
    }

# Generated at 2022-06-18 05:20:44.728957
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-proto": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/",
    }
    config = type("Config", (), {"PROXIES_COUNT": 1})
    assert parse_xforwarded(headers, config) == {
        "for": "127.0.0.1",
        "proto": "https",
        "host": "example.com",
        "port": 443,
        "path": "/",
    }



# Generated at 2022-06-18 05:21:19.491773
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketWriter

# Generated at 2022-06-18 05:21:32.401002
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret"}) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret2"}) == None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": ""}) == None

# Generated at 2022-06-18 05:21:43.117560
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17;proto=https;by=203.0.113.43",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
        "REAL_IP_HEADER": "X-Real-IP",
        "PROXIES_COUNT": 2,
    }

# Generated at 2022-06-18 05:21:49.096194
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret"}) == {"for": "192.0.2.60", "proto": "http", "by": "203.0.113.43"}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "wrong"}) == None

# Generated at 2022-06-18 05:21:59.725209
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/file',
        'x-forwarded-proto': 'https',
        'x-forwarded-for': '192.168.1.1, 192.168.1.2'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }

# Generated at 2022-06-18 05:22:10.939677
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1, 192.168.0.2",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": 2,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": None,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:22:21.704207
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.testing import SanicTestClient
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    import asyncio
    import os
    import sys
    import unittest
    import warnings
    from unittest import mock


# Generated at 2022-06-18 05:22:32.961430
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:22:44.229644
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1, 192.168.1.2, 192.168.1.3",
        "x-forwarded-host": "example.com",
        "x-forwarded-proto": "https",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 3,
    }

# Generated at 2022-06-18 05:22:55.486893
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.0.1, 192.168.0.2',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'http',
    }
    config = {
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'REAL_IP_HEADER': 'X-Forwarded-For',
    }

# Generated at 2022-06-18 05:23:51.143043
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.43, for=\"[2001:db8:cafe::17]\"",
            "by=203.0.113.60;proto=http;host=example.com",
            "secret=\"abc\"",
            "by=203.0.113.60;proto=http;host=example.com",
            "secret=\"def\"",
        ]
    }
    config = {
        "FORWARDED_SECRET": "abc",
        "PROXIES_COUNT": 0,
        "REAL_IP_HEADER": "",
        "FORWARDED_FOR_HEADER": "",
    }