

# Generated at 2022-06-18 05:13:22.485468
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret"}) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret2"}) == None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": ""}) == None

# Generated at 2022-06-18 05:13:29.529915
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("UNKNOWN") == "unknown"
    assert fwd_normalize_address("Unknown") == "unknown"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("UNKNOWN") == "unknown"
    assert fwd_normalize_address("Unknown") == "unknown"

# Generated at 2022-06-18 05:13:40.091890
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:13:49.674485
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("_127.0.0.1") == "_127.0.0.1"
    assert fwd_normalize_address("_127.0.0.1:80") == "_127.0.0.1:80"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:80") == "[::1]:80"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown:80") == "unknown:80"
    assert fwd_normalize_address("_unknown") == "_unknown"
    assert fwd_

# Generated at 2022-06-18 05:14:01.276227
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/test",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:14:11.298875
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'http',
    }

# Generated at 2022-06-18 05:14:23.355679
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {
        "for": "1.2.3.4"
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret")]) == {
        "for": "1.2.3.4",
        "by": "secret",
    }

# Generated at 2022-06-18 05:14:36.175939
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret"}) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "wrong"}) == None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": ""}) == None

# Generated at 2022-06-18 05:14:46.982173
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("192.168.0.1") == "192.168.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_192.168.0.1") == "_192.168.0.1"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_unknown") == "_unknown"
    assert fwd_normalize_address("_192.168.0.1,_unknown") == "_192.168.0.1,_unknown"

# Generated at 2022-06-18 05:14:55.034355
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.1.1")]) == {"for": "192.168.1.1"}
    assert fwd_normalize([("for", "192.168.1.1"), ("for", "192.168.1.2")]) == {
        "for": "192.168.1.1"
    }
    assert fwd_normalize([("for", "192.168.1.1"), ("by", "secret")]) == {
        "for": "192.168.1.1",
        "by": "secret",
    }

# Generated at 2022-06-18 05:15:10.140457
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient
    from sanic.testing import create_server

    app = Sanic("test_parse_forwarded")


# Generated at 2022-06-18 05:15:15.860484
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'proto': 'http', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:15:27.724722
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketEvent

# Generated at 2022-06-18 05:15:30.022839
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:15:39.759937
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'Forwarded': 'for=192.0.2.43, for=198.51.100.17'}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17'}
    headers = {'Forwarded': 'for=192.0.2.43, for=198.51.100.17, for=192.0.2.17'}
   

# Generated at 2022-06-18 05:15:49.974794
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.1.1")]) == {"for": "192.168.1.1"}
    assert fwd_normalize([("for", "192.168.1.1"), ("for", "192.168.1.2")]) == {"for": "192.168.1.2"}
    assert fwd_normalize([("for", "192.168.1.1"), ("for", "192.168.1.2"), ("for", "192.168.1.3")]) == {"for": "192.168.1.3"}

# Generated at 2022-06-18 05:15:54.447395
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:16:03.549578
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "::1")]) == {"for": "::1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "::1"), ("for", "::2")]) == {"for": "::2"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "::1"), ("for", "::2"), ("for", "::3")]) == {"for": "::3"}

# Generated at 2022-06-18 05:16:14.736982
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": None,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }
    assert parse_xforwarded(headers, config) == {
        "for": "192.168.1.1",
        "host": "example.com",
        "port": 80,
        "proto": "https",
        "path": "/",
    }

# Generated at 2022-06-18 05:16:24.916095
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {"for": "1.2.3.4", "by": "5.6.7.8"}

# Generated at 2022-06-18 05:16:37.919470
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.views import CompositionView

    class TestView(CompositionView):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def get(self, request):
            return HTTPResponse(request.headers)

    class TestConfig(Config):
        FORWARDED_SECRET = "secret"
        FORWARDED_FOR_HEADER = "X-Forwarded-For"
        REAL_IP_HEADER = "X-Real-IP"
        PROXIES_COUNT = 1


# Generated at 2022-06-18 05:16:47.393755
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocket
    from sanic.websocket import Web

# Generated at 2022-06-18 05:16:57.565223
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketCommonReader
    from sanic.websocket import WebSocketCommonWriter

# Generated at 2022-06-18 05:17:06.802576
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with no secret
    assert parse_forwarded({'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}, None) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}, 'secret') == None

    # Test with secret

# Generated at 2022-06-18 05:17:14.894893
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': '203.0.113.43'}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17', 'proto': 'https', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:17:25.692227
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "9.10.11.12"}

# Generated at 2022-06-18 05:17:34.099209
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol

    config = Config()
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.PROXIES_COUNT = 1

    protocol = HttpProtocol(config)
    request = Request(protocol, "GET", "/", [], b"", None, None, None)

# Generated at 2022-06-18 05:17:45.493778
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage

    app = Sanic(__name__)

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.headers)

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(request.headers)


# Generated at 2022-06-18 05:17:57.072081
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:18:05.178540
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    config = Config()
    config.FORWARDED_SECRET = "secret"

    # Test HTTP
    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(text=str(request.forwarded))

    server = app.create_server(HOST, PORT, protocol=HttpProtocol, config=config)
    _, test_server = loop.run_until_complete(server)


# Generated at 2022-06-18 05:18:27.732579
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:80") == ("localhost", 80)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:80") == ("[::1]", 80)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_

# Generated at 2022-06-18 05:18:40.106660
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:18:52.364338
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "::1")]) == {"for": "[::1]"}
    assert fwd_normalize([("for", "unknown")]) == {}
    assert fwd_normalize([("for", "_secret")]) == {"for": "_secret"}
    assert fwd_normalize([("for", "127.0.0.1"), ("proto", "http")]) == {
        "for": "127.0.0.1",
        "proto": "http",
    }

# Generated at 2022-06-18 05:19:00.587433
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient

    app = Sanic("test_parse_xforwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(text=str(request.ip))

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(str(request.ip))


# Generated at 2022-06-18 05:19:11.847201
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
    }

# Generated at 2022-06-18 05:19:21.576307
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:8080") == ("localhost", 8080)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1%eth0]") == ("[::1%eth0]", None)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)
    assert parse

# Generated at 2022-06-18 05:19:30.578020
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1


# Generated at 2022-06-18 05:19:37.335195
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:19:47.105257
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketEvent

# Generated at 2022-06-18 05:19:56.941733
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    app = Sanic("test_parse_forwarded")


# Generated at 2022-06-18 05:20:19.248789
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with no secret
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http"},
                           {"FORWARDED_SECRET": None}) == \
        {"for": "192.0.2.60", "proto": "http"}
    # Test with secret
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;secret=abc"},
                           {"FORWARDED_SECRET": "abc"}) == \
        {"for": "192.0.2.60", "proto": "http"}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;secret=xyz"},
                           {"FORWARDED_SECRET": "abc"}) == None
    #

# Generated at 2022-06-18 05:20:29.558117
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/foo/bar'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1
    }

# Generated at 2022-06-18 05:20:37.962809
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:20:48.387615
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.server import serve
    import asyncio
    import socket
    import time
    import random
    import string
    import os
    import sys
    import logging
    import unittest
    import tempfile
    import contextlib

    class TestParseForwarded(unittest.TestCase):
        def setUp(self):
            self.app = Sanic('test_parse_forwarded')
            self.app.config.FORWARDED_SECRET = 'secret'
            self.app.config.FORWARDED_FOR_HEADER = 'X-Forwarded-For'
            self

# Generated at 2022-06-18 05:20:56.819445
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17",
            "for=192.0.2.43;by=203.0.113.43",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:21:07.824738
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:21:19.747230
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage

    config = Config()
    config.PROXIES_COUNT = 1
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.FORWARDED_PROTO_HEADER = "X-Forwarded-Proto"
    config.FORWARDED_HOST_HEADER = "X-Forwarded-Host"
    config.FORWARDED_PORT_HEADER = "X-Forwarded-Port"
    config.FORWARDED_PATH_HEADER = "X-Forwarded-Path"

    # Test with no

# Generated at 2022-06-18 05:21:32.503121
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43'}

# Generated at 2022-06-18 05:21:43.247558
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/foo/bar',
    }
    config = {
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': '',
        'REAL_IP_HEADER': '',
    }

# Generated at 2022-06-18 05:21:52.542022
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http"},
                           {"FORWARDED_SECRET": "secret"}) == {
                               "for": "192.0.2.60", "proto": "http"
                           }
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http"},
                           {"FORWARDED_SECRET": "secret2"}) is None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http"},
                           {"FORWARDED_SECRET": ""}) is None

# Generated at 2022-06-18 05:22:23.711215
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with empty header
    assert parse_forwarded({"forwarded": ""}, Config()) == None

    # Test with empty secret
    assert parse_forwarded({"forwarded": "for=127.0.0.1"}, Config()) == None

    # Test with empty secret
    assert parse_forwarded({"forwarded": "for=127.0.0.1"}, Config(FORWARDED_SECRET="secret")) == None

    # Test with empty secret
    assert parse_forwarded({"forwarded": "for=127.0.0.1; secret=secret"}, Config(FORWARDED_SECRET="secret")) == {"for": "127.0.0.1"}

    # Test with empty secret

# Generated at 2022-06-18 05:22:31.390382
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:22:38.641817
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("proto", "https")]) == {
        "for": "127.0.0.1",
        "proto": "https",
    }
    assert fwd_normalize([("for", "127.0.0.1"), ("proto", "https"), ("proto", "http")]) == {
        "for": "127.0.0.1",
        "proto": "http",
    }
    assert fwd_normalize([("for", "127.0.0.1"), ("proto", "https"), ("proto", "http"), ("host", "example.com")])

# Generated at 2022-06-18 05:22:44.646455
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:22:55.927210
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.views import CompositionView

    class TestView(CompositionView):
        def __init__(self):
            self.received_request = None

        async def get(self, request):
            self.received_request = request
            return HTTPResponse("OK")

    class TestServer:
        def __init__(self, config):
            self.config = config
            self.app = None

    class TestHttpProtocol(HttpProtocol):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)


# Generated at 2022-06-18 05:23:07.083034
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:23:15.761861
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43'}