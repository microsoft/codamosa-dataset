

# Generated at 2022-06-18 05:13:49.403510
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse

    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {"forwarded": "by=127.0.0.1; for=127.0.0.1; proto=http"}
    request = Request("GET", "/", headers=headers, config=config)
    assert request.forwarded == {"by": "127.0.0.1", "for": "127.0.0.1", "proto": "http"}

    headers = {"forwarded": "by=127.0.0.1; for=127.0.0.1; proto=http, by=127.0.0.2; for=127.0.0.2; proto=https"}
   

# Generated at 2022-06-18 05:14:00.863940
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2, 192.168.1.3",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:14:10.922087
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "http",
        "X-Forwarded-Path": "/test",
    }

# Generated at 2022-06-18 05:14:23.360973
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:14:36.129518
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:14:46.949288
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1

    class TestProtocol(HttpProtocol):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.request = None


# Generated at 2022-06-18 05:14:55.763033
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "192.168.1.1, 192.168.1.2, 192.168.1.3",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": 3,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:15:04.473442
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Path": "/foo/bar",
    }
    config = {
        "REAL_IP_HEADER": "X-Forwarded-For",
        "PROXIES_COUNT": 2,
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:15:11.297620
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:15:17.928914
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2, 192.168.1.3",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "X-Forwarded-For",
        "PROXIES_COUNT": 3,
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
        "FORWARDED_SECRET": "",
    }

# Generated at 2022-06-18 05:15:35.607043
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/',
    }

# Generated at 2022-06-18 05:15:42.035853
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt'})


# Generated at 2022-06-18 05:15:53.304845
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename=\"file.txt\"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload') == ('form-data', {'name': 'upload'})
    assert parse_content_header('form-data') == ('form-data', {})
    assert parse_content_header('form-data; name=upload; filename=file.txt;') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:16:03.013536
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret.example.com") == "_secret.example.com"
    assert fwd_normalize_address("_secret.example.com:80") == "_secret.example.com:80"
    assert fwd_normalize_address("_secret.example.com:8080") == "_secret.example.com:8080"
    assert fwd_normalize_address("_secret.example.com:8080") == "_secret.example.com:8080"

# Generated at 2022-06-18 05:16:14.241545
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\";") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"; ") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"; ") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:16:24.528504
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret"}) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret2"}) == None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": ""}) == None

# Generated at 2022-06-18 05:16:34.479326
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config

    config = Config()
    config.FORWARDED_SECRET = "secret"

    # Test with no secret
    config.FORWARDED_SECRET = None
    assert parse_forwarded({}, config) is None

    # Test with secret
    config.FORWARDED_SECRET = "secret"
    assert parse_forwarded({"forwarded": "secret=secret"}, config) == {}
    assert parse_forwarded({"forwarded": "secret=secret, for=127.0.0.1"}, config) == {"for": "127.0.0.1"}

# Generated at 2022-06-18 05:16:45.536933
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {
        "for": "127.0.0.1"
    }
    assert fwd_normalize([("for", "::1")]) == {"for": "[::1]"}
    assert fwd_normalize([("for", "unknown")]) == {}
    assert fwd_normalize([("for", "_secret")]) == {"for": "_secret"}
    assert fwd_normalize([("for", "127.0.0.1"), ("proto", "https")]) == {
        "for": "127.0.0.1",
        "proto": "https",
    }

# Generated at 2022-06-18 05:16:56.291354
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.43, for="[2001:db8:cafe::17]"; proto=https; by=203.0.113.60; host=example.com; secret=12345'}
    config = {'FORWARDED_SECRET': '12345'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'proto': 'https', 'by': '203.0.113.60', 'host': 'example.com'}
    headers = {'forwarded': 'for=192.0.2.43, for="[2001:db8:cafe::17]"; proto=https; by=203.0.113.60; host=example.com; secret=12345'}

# Generated at 2022-06-18 05:17:05.865777
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/",
    }

# Generated at 2022-06-18 05:17:21.013774
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "192.168.1.1, 192.168.1.2, 192.168.1.3",
    }
    config = {
        "PROXIES_COUNT": 3,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:17:31.414604
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/test",
    }

# Generated at 2022-06-18 05:17:44.451503
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.testing import SanicTestClient

    app = Sanic("test_parse_xforwarded")


# Generated at 2022-06-18 05:17:55.706578
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'www.example.com',
        'x-forwarded-proto': 'https',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/test',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:18:04.364697
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1",
        "x-forwarded-proto": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/file",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": "",
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:18:15.546405
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-proto': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:18:27.303728
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:8080") == ("localhost", 8080)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1%eth0]") == ("[::1%eth0]", None)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)
    assert parse_host("[::1%eth0]") == ("[::1%eth0]", None)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)

# Generated at 2022-06-18 05:18:39.746211
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.testing import HOST, PORT

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse("OK")

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send("OK")


# Generated at 2022-06-18 05:18:52.018419
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "1.2.3.4, 5.6.7.8, 9.10.11.12",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "443",
        "X-Forwarded-Path": "/foo/bar",
        "X-Scheme": "https",
    }
    config = {
        "REAL_IP_HEADER": None,
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
        "PROXIES_COUNT": 2,
    }

# Generated at 2022-06-18 05:19:01.809145
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {
        "for": "1.2.3.4",
        "by": "5.6.7.8",
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8"), ("for", "9.10.11.12")]) == {
        "for": "9.10.11.12",
        "by": "5.6.7.8",
    }

# Generated at 2022-06-18 05:19:19.334296
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:19:29.420634
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17;proto=https;by=203.0.113.43",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "REAL_IP_HEADER": "x-real-ip",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:19:41.861970
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "::1")]) == {"for": "::1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "::1"), ("for", "127.0.0.1")]) == {"for": "::1"}

# Generated at 2022-06-18 05:19:47.836037
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "127.0.0.1",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "http",
        "X-Forwarded-Path": "/",
    }
    config = type("Config", (), {"PROXIES_COUNT": 1})
    assert parse_xforwarded(headers, config) == {
        "for": "127.0.0.1",
        "host": "example.com",
        "port": 80,
        "proto": "http",
        "path": "/",
    }

# Generated at 2022-06-18 05:19:57.615083
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {'forwarded': 'for=192.0.2.60;proto=http;host=example.com;by=secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'host': 'example.com', 'by': 'secret'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;host=example.com;by=secret,for=192.0.2.61;proto=http;host=example.com;by=secret'}

# Generated at 2022-06-18 05:20:09.186280
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path",
        "x-forwarded-proto": "https",
        "x-forwarded-for": "192.168.1.1, 192.168.1.2",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 2,
    }

# Generated at 2022-06-18 05:20:15.281606
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "http",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-path": "/path",
    }
    assert parse_xforwarded(headers, None) == {
        "proto": "http",
        "host": "example.com",
        "port": 80,
        "path": "/path",
    }



# Generated at 2022-06-18 05:20:24.898258
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/test",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:20:35.631581
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '127.0.0.1',
        'x-forwarded-host': '127.0.0.1',
        'x-forwarded-port': '8080',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/test',
        'x-scheme': 'http',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:20:39.743611
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17', 'proto': 'https', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:21:00.635374
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "192.168.1.1, 192.168.1.2, 192.168.1.3",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 3,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": None,
    }

# Generated at 2022-06-18 05:21:08.435321
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'proto': 'http', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:21:16.577958
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=https;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'proto': 'https', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:21:24.090909
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": None,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }
    assert parse_xforwarded(headers, config) == {
        "for": "192.168.1.1",
        "host": "example.com",
        "port": 80,
        "proto": "https",
        "path": "/",
    }

# Generated at 2022-06-18 05:21:34.750634
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/test",
    }

# Generated at 2022-06-18 05:21:43.904629
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:21:49.457043
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '127.0.0.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/test'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1
    }

# Generated at 2022-06-18 05:21:59.945265
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "10.0.0.1")]) == {"for": "10.0.0.1"}
    assert fwd_normalize([("for", "10.0.0.1"), ("for", "10.0.0.1")]) == {"for": "10.0.0.1"}
    assert fwd_normalize([("for", "10.0.0.1"), ("for", "10.0.0.2")]) == {"for": "10.0.0.2"}
    assert fwd_normalize([("for", "10.0.0.1"), ("for", "10.0.0.2"), ("for", "10.0.0.3")]) == {"for": "10.0.0.3"}

# Generated at 2022-06-18 05:22:11.093270
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.0.1, 192.168.0.2, 192.168.0.3",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Path": "/foo/bar",
    }
    config = {
        "REAL_IP_HEADER": "X-Forwarded-For",
        "PROXIES_COUNT": 3,
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
        "FORWARDED_SECRET": "",
    }

# Generated at 2022-06-18 05:22:21.853928
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {
        "for": "127.0.0.2"
    }
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {
        "for": "127.0.0.2"
    }

# Generated at 2022-06-18 05:23:00.254995
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '1.2.3.4',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:23:10.577688
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
   

# Generated at 2022-06-18 05:23:21.073282
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-forwarded-for"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1

    app = Sanic("test_parse_forwarded")


# Generated at 2022-06-18 05:23:31.864870
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.response import json
    from sanic.handlers import ErrorHandler
    from sanic.constants import HTTP_METHODS
    from sanic.constants import REQUEST_TIMEOUT
    from sanic.constants import REQUEST_MAX_SIZE
    from sanic.constants import RESPONSE_TIMEOUT
   