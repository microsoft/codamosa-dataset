

# Generated at 2022-06-18 05:14:04.627486
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2',
        'x-scheme': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for'
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:14:13.265568
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.views import CompositionView
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.server import serve
    from sanic.response import text
    from sanic.response import json
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream

# Generated at 2022-06-18 05:14:22.008859
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43']
    }
    config = {
        'FORWARDED_SECRET': 'secret'
    }
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:14:29.703786
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1, 192.168.0.2, 192.168.0.3",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-scheme": "http",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 2,
    }

# Generated at 2022-06-18 05:14:40.096400
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {"for": "1.2.3.4", "by": "5.6.7.8"}

# Generated at 2022-06-18 05:14:47.460108
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43']}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:14:55.429090
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedAbnormal
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedTLSHandshake
    from sanic.websocket import WebSocketConnection

# Generated at 2022-06-18 05:15:04.298879
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient
    from sanic.testing import create_server
    from sanic.testing import create_test_server
    from sanic.testing import create_test_websocket_server
    from sanic.testing import create_websocket_server
    from sanic.testing import mock_request
    from sanic.testing import mock_websocket_request
    from sanic.testing import websocket_test
    from sanic.views import HTTPMethodView

# Generated at 2022-06-18 05:15:14.504060
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {"for": "127.0.0.2"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2"), ("for", "127.0.0.3")]) == {"for": "127.0.0.3"}

# Generated at 2022-06-18 05:15:26.510473
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:15:49.637383
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient
    from sanic.testing import create_server
    from sanic.testing import create_test_server

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(text=str(request.forwarded))

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(str(request.forwarded))

    # Test

# Generated at 2022-06-18 05:16:01.743786
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:16:07.678491
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43",
            "for=192.0.2.43;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "http",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:16:12.930649
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/test',
        'X-Scheme': 'http',
        'X-Real-Ip': '192.168.1.1'
    }

# Generated at 2022-06-18 05:16:23.508077
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("127.0.0.1") == ("127.0.0.1", None)
    assert parse_host("127.0.0.1:8000") == ("127.0.0.1", 8000)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:8000") == ("[::1]", 8000)
    assert parse_host("example.com") == ("example.com", None)
    assert parse_host("example.com:8000") == ("example.com", 8000)
    assert parse_host("example.com:") == ("example.com", None)
    assert parse_host("example.com:a") == (None, None)
    assert parse_host("example.com:1a") == (None, None)
   

# Generated at 2022-06-18 05:16:34.072287
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:16:41.721462
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:16:52.561537
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 2

    # Test with HTTP

# Generated at 2022-06-18 05:17:02.679174
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:17:09.768770
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse

    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=https;by=203.0.113.43",
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=https;by=203.0.113.43",
        ]
    }

# Generated at 2022-06-18 05:17:26.154314
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:17:34.370520
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage

    config = Config()
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.FORWARDED_PROTO_HEADER = "X-Forwarded-Proto"
    config.FORWARDED_HOST_HEADER = "X-Forwarded-Host"
    config.FORWARDED_PORT_HEADER = "X-Forwarded-Port"

# Generated at 2022-06-18 05:17:45.532248
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:17:57.071372
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("_") == "_"
    assert fwd_normalize_address("_1") == "_1"
    assert fwd_normalize_address("_1.2.3.4") == "_1.2.3.4"
    assert fwd_normalize_address("_1.2.3.4:5") == "_1.2.3.4:5"
    assert fwd_normalize_address("_1.2.3.4:5/6") == "_1.2.3.4:5/6"
    assert fwd_normalize_address("_1.2.3.4:5/6?7") == "_1.2.3.4:5/6?7"

# Generated at 2022-06-18 05:18:05.179227
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3'}
    config = {'PROXIES_COUNT': 3}
    assert parse_xforwarded(headers, config) == {'for': '192.168.1.1'}
    config = {'PROXIES_COUNT': 2}
    assert parse_xforwarded(headers, config) == {'for': '192.168.1.2'}
    config = {'PROXIES_COUNT': 1}
    assert parse_xforwarded(headers, config) == {'for': '192.168.1.3'}
    config = {'PROXIES_COUNT': 0}
    assert parse_xforwarded(headers, config) == None
   

# Generated at 2022-06-18 05:18:16.211923
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43;host=example.com;port=8080;path=/test",
            "for=192.0.2.60;proto=http;by=203.0.113.43;host=example.com;port=8080;path=/test",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
        "PROXIES_COUNT": 1,
        "REAL_IP_HEADER": "",
        "FORWARDED_FOR_HEADER": "",
    }

# Generated at 2022-06-18 05:18:27.464788
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:18:39.949617
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("_127.0.0.1") == "_127.0.0.1"
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_[::1]") == "_[::1]"
    assert fwd_normalize_address("_[::1]") == "_[::1]"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normal

# Generated at 2022-06-18 05:18:52.213908
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.testing import HOST, PORT

    app = Sanic("test_parse_xforwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.headers.get("X-Forwarded-For", "None"))

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(request.headers.get("X-Forwarded-For", "None"))

    config = Config()
    config.PROXIES

# Generated at 2022-06-18 05:19:01.932766
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize({"for": "127.0.0.1"}) == {"for": "127.0.0.1"}
    assert fwd_normalize({"for": "::1"}) == {"for": "[::1]"}
    assert fwd_normalize({"for": "127.0.0.1", "proto": "https"}) == {
        "for": "127.0.0.1",
        "proto": "https",
    }
    assert fwd_normalize({"for": "127.0.0.1", "proto": "https", "host": "example.com"}) == {
        "for": "127.0.0.1",
        "proto": "https",
        "host": "example.com",
    }
    assert fwd_normal

# Generated at 2022-06-18 05:19:18.382002
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    config = Config()
    config.PROXIES_COUNT = 1
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_PROTO_HEADER = "X-Forwarded-Proto"
    config.FORWARDED_HOST_HEADER = "X-Forwarded-Host"
    config.FORWARDED_PORT_HEADER = "X-Forwarded-Port"
    config.FORWARDED_PATH_HEADER = "X-Forwarded-Path"

# Generated at 2022-06-18 05:19:29.275352
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.worker import GunicornWorker
    from sanic.app import Sanic
    from sanic.log import logger
    from sanic.exceptions import InvalidUsage
    import asyncio
    import socket
    import sys
    import os
    import json
    import pytest
    import time
    import logging
    import logging.config
    import logging.handlers
    from sanic.log import logger
    from sanic.exceptions import InvalidUsage
    from sanic.response import json as sanic_json

# Generated at 2022-06-18 05:19:41.698437
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/test'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': ''
    }

# Generated at 2022-06-18 05:19:48.702233
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:19:54.726025
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    request = Request(config, "GET", "/", headers={
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43, for=192.0.2.43;proto=http;by=203.0.113.43"
    })

# Generated at 2022-06-18 05:20:02.580219
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17;by=203.0.113.43;secret=_secret_'}
    config = {'FORWARDED_SECRET': '_secret_'}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:20:13.452613
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "::1")]) == {"for": "[::1]"}
    assert fwd_normalize([("for", "::1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "::1"), ("for", "127.0.0.1"), ("for", "::1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "::1"), ("for", "127.0.0.1"), ("for", "::1"), ("for", "127.0.0.1")])

# Generated at 2022-06-18 05:20:23.550079
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "9.10.11.12"}

# Generated at 2022-06-18 05:20:35.486356
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2',
        'x-forwarded-proto': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:20:43.500433
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'FORWARDED_SECRET': '',
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:20:58.733645
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-host': 'host',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': 'path',
        'x-scheme': 'https',
        'x-real-ip': '127.0.0.1'
    }
    config = {
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'REAL_IP_HEADER': 'x-real-ip',
        'PROXIES_COUNT': 1
    }

# Generated at 2022-06-18 05:21:09.321422
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:21:19.176576
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.0.1',
        'x-forwarded-proto': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/test',
    }
    assert parse_xforwarded(headers, None) == {
        'for': '192.168.0.1',
        'proto': 'https',
        'host': 'example.com',
        'port': 443,
        'path': '/test',
    }

# Generated at 2022-06-18 05:21:25.074726
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {
        "for": "1.2.3.4"
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret")]) == {
        "for": "1.2.3.4",
        "by": "secret",
    }

# Generated at 2022-06-18 05:21:34.453788
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "1.2.3.4, 5.6.7.8",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Path": "/path",
    }
    config = type("Config", (), {"PROXIES_COUNT": 1})
    assert parse_xforwarded(headers, config) == {
        "for": "5.6.7.8",
        "host": "example.com",
        "port": 80,
        "proto": "https",
        "path": "/path",
    }

# Generated at 2022-06-18 05:21:43.735135
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:21:49.428684
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "127.0.0.1",
        "X-Forwarded-Host": "localhost",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Path": "/test",
        "X-Scheme": "http",
    }
    config = {
        "REAL_IP_HEADER": "X-Forwarded-For",
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
        "PROXIES_COUNT": 1,
    }
    assert parse_xforwarded(headers, config) == {
        "for": "127.0.0.1",
        "host": "localhost",
        "port": 80,
        "path": "/test",
        "proto": "http",
    }

# Generated at 2022-06-18 05:21:59.947210
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '1.2.3.4',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'http',
    }

# Generated at 2022-06-18 05:22:11.129996
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:22:21.888625
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.0.1")]) == {"for": "192.168.0.1"}
    assert fwd_normalize([("for", "192.168.0.1"), ("for", "192.168.0.2")]) == {"for": "192.168.0.1"}
    assert fwd_normalize([("for", "192.168.0.1"), ("for", "192.168.0.2"), ("for", "192.168.0.3")]) == {"for": "192.168.0.1"}

# Generated at 2022-06-18 05:22:42.828736
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "1.2.3.4",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/test",
    }

# Generated at 2022-06-18 05:22:53.750267
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/test",
        "x-forwarded-proto": "https",
    }
    config = {
        "REAL_IP_HEADER": "x-real-ip",
        "PROXIES_COUNT": 2,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": "secret",
    }
    assert parse_xforwarded(headers, config) == {
        "proto": "https",
        "host": "example.com",
        "port": 443,
        "path": "/test",
    }


#

# Generated at 2022-06-18 05:23:04.873050
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-scheme': 'https',
        'x-forwarded-path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:23:13.843252
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'www.example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'http',
        'X-Scheme': 'https',
        'X-Forwarded-Path': '/test'
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For'
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:23:23.027782
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {
        "for": "1.2.3.4",
        "by": "5.6.7.8",
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8"), ("for", "9.10.11.12")]) == {
        "for": "1.2.3.4",
        "by": "5.6.7.8",
    }

# Generated at 2022-06-18 05:23:33.939700
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'http',
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'FORWARDED_SECRET': '',
    }

# Generated at 2022-06-18 05:23:45.370294
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.forwarded)

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(request.forwarded)

    app.config.FORWARDED_SECRET = "secret"
    app.config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    app.config.RE

# Generated at 2022-06-18 05:23:53.654327
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.request import Request
    from sanic.config import Config
    from sanic.server import HttpProtocol
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage

    config = Config()
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.FORWARDED_PROTO_HEADER = "X-Forwarded-Proto"
    config.FORWARDED_HOST_HEADER = "X-Forwarded-Host"
    config.FORWARDED_PORT_HEADER = "X-Forwarded-Port"
    config.FORWARDED_PATH_HEADER = "X-Forwarded-Path"