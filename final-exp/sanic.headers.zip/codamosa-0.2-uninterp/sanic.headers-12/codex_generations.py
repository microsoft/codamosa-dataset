

# Generated at 2022-06-18 05:14:05.342408
# Unit test for function format_http1_response
def test_format_http1_response():
    assert format_http1_response(200, []) == b"HTTP/1.1 200 OK\r\n\r\n"
    assert format_http1_response(200, [(b"a", b"b")]) == b"HTTP/1.1 200 OK\r\na: b\r\n\r\n"
    assert format_http1_response(200, [(b"a", b"b"), (b"c", b"d")]) == b"HTTP/1.1 200 OK\r\na: b\r\nc: d\r\n\r\n"

# Generated at 2022-06-18 05:14:13.631578
# Unit test for function format_http1_response
def test_format_http1_response():
    assert format_http1_response(200, []) == b"HTTP/1.1 200 OK\r\n\r\n"
    assert format_http1_response(200, [(b"Content-Type", b"text/plain")]) == b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n"
    assert format_http1_response(200, [(b"Content-Type", b"text/plain"), (b"Content-Length", b"0")]) == b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 0\r\n\r\n"
    assert format_http1_response(404, []) == b"HTTP/1.1 404 Not Found\r\n\r\n"


# Generated at 2022-06-18 05:14:25.349801
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with no secret
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http"}, {"FORWARDED_SECRET": None}) == {"for": "192.0.2.60", "proto": "http"}
    # Test with secret
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;secret=secret"}, {"FORWARDED_SECRET": "secret"}) == {"for": "192.0.2.60", "proto": "http"}
    # Test with secret but no secret in header
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http"}, {"FORWARDED_SECRET": "secret"}) == None
    # Test with secret but secret in header is wrong

# Generated at 2022-06-18 05:14:37.735219
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView
    from sanic.response import json
    import asyncio
    import socket
    import time
    import uuid

    class TestView(HTTPMethodView):
        def get(self, request):
            return json(request.forwarded)

    app = Sanic(__name__)
    app.add_route(TestView.as_view(), '/')

    # Create a socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock

# Generated at 2022-06-18 05:14:48.260533
# Unit test for function format_http1_response
def test_format_http1_response():
    assert format_http1_response(200, []) == b"HTTP/1.1 200 OK\r\n\r\n"
    assert format_http1_response(200, [(b"A", b"B")]) == b"HTTP/1.1 200 OK\r\nA: B\r\n\r\n"
    assert format_http1_response(200, [(b"A", b"B"), (b"C", b"D")]) == b"HTTP/1.1 200 OK\r\nA: B\r\nC: D\r\n\r\n"

# Generated at 2022-06-18 05:14:53.114109
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17'}
    config = {'FORWARDED_SECRET': 'secret'}
    print(parse_forwarded(headers, config))


# Generated at 2022-06-18 05:15:03.115220
# Unit test for function format_http1_response
def test_format_http1_response():
    assert format_http1_response(200, []) == b"HTTP/1.1 200 OK\r\n\r\n"
    assert format_http1_response(200, [("Content-Type", "text/plain")]) == \
        b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n"
    assert format_http1_response(404, []) == b"HTTP/1.1 404 Not Found\r\n\r\n"
    assert format_http1_response(404, [("Content-Type", "text/plain")]) == \
        b"HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n"

# Generated at 2022-06-18 05:15:14.042501
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/path',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
    }

# Generated at 2022-06-18 05:15:26.148997
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/test",
        "x-forwarded-proto": "https",
        "x-real-ip": "127.0.0.1",
        "x-forwarded-for": "127.0.0.1, 127.0.0.2, 127.0.0.3",
    }
    config = {
        "REAL_IP_HEADER": "x-real-ip",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 3,
    }

# Generated at 2022-06-18 05:15:36.107105
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '10.0.0.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/path/to/file',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:15:55.484883
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1",
        "x-forwarded-proto": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:16:02.359250
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43']}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17', 'proto': 'https', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:16:13.719603
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Forwarded-Proto': 'https',
        'X-Scheme': 'http',
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'FORWARDED_SECRET': '',
    }

# Generated at 2022-06-18 05:16:24.144365
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = 'secret'
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43;proto=http;by=203.0.113.43'}
    print(parse_forwarded(headers, config))
    headers = {'forwarded': 'for=192.0.2.43;proto=http;by=203.0.113.43, for=192.0.2.43;proto=http;by=203.0.113.43'}
    print(parse_forwarded(headers, config))

# Generated at 2022-06-18 05:16:34.339252
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "192.168.1.1, 192.168.1.2, 192.168.1.3",
    }
    config = {
        "PROXIES_COUNT": 2,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "REAL_IP_HEADER": "x-real-ip",
        "FORWARDED_SECRET": "",
    }

# Generated at 2022-06-18 05:16:45.461492
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "8080",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:16:56.192199
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.request import Request
    from sanic.config import Config
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.views import CompositionView
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import File
    from sanic.response import file_stream
    from sanic.response import json
    from sanic.response import text
    from sanic.response import html

# Generated at 2022-06-18 05:17:05.788530
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {
        "for": "127.0.0.1"
    }
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {
        "for": "127.0.0.1"
    }

# Generated at 2022-06-18 05:17:16.889780
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:17:27.915098
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
        "REAL_IP_HEADER": "X-Real-IP",
        "PROXIES_COUNT": 2,
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "http",
        "by": "203.0.113.43",
    }
    assert parse_x

# Generated at 2022-06-18 05:17:46.050734
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("by", "1.2.3.4")]) == {"by": "1.2.3.4"}
    assert fwd_normalize([("by", "1.2.3.4"), ("for", "5.6.7.8")]) == {
        "by": "1.2.3.4",
        "for": "5.6.7.8",
    }
    assert fwd_normalize([("by", "1.2.3.4"), ("for", "5.6.7.8"), ("by", "9.10.11.12")]) == {
        "by": "9.10.11.12",
        "for": "5.6.7.8",
    }

# Generated at 2022-06-18 05:17:57.428524
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/test'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1
    }
    result = parse_xforwarded(headers, config)
    assert result == {'for': '192.168.1.1', 'host': 'example.com', 'port': 80, 'proto': 'http', 'path': '/test'}

# Generated at 2022-06-18 05:18:08.786870
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.PROXIES_COUNT = 0
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.FORWARDED_PROTO_HEADER = "x-forwarded-proto"
    config.FORWARDED_HOST_HEADER = "x-forwarded-host"
    config.FORWARDED_PORT_HEADER = "x-forwarded-port"

# Generated at 2022-06-18 05:18:18.772492
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret.example.com") == "_secret.example.com"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("UNKNOWN") == "unknown"
    assert fwd_normalize_address("Unknown") == "unknown"
    assert fwd_normalize_address("unknown.example.com") == "unknown.example.com"
    assert fwd_normalize_address("UNKNOWN.example.com") == "unknown.example.com"

# Generated at 2022-06-18 05:18:30.276644
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return text("OK")

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send("OK")

    @app.websocket("/ws_common")
    async def ws_common_handler(request, ws):
        await ws.send("OK")


# Generated at 2022-06-18 05:18:39.382229
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("_127.0.0.1") == "_127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_[::1]") == "_[::1]"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_unknown") == "_unknown"

# Generated at 2022-06-18 05:18:51.673814
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43;proto=http;by=203.0.113.43",
            "for=192.0.2.43;proto=http;by=203.0.113.43",
            "for=192.0.2.43;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43",
        ]
    }

# Generated at 2022-06-18 05:19:01.517650
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.request import Request
    from sanic.config import Config
    from sanic.exceptions import InvalidUsage
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1

    class TestHttpProtocol(HttpProtocol):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.config = config


# Generated at 2022-06-18 05:19:13.904299
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient

    app = Sanic("test_parse_forwarded")


# Generated at 2022-06-18 05:19:22.365605
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "1.2.3.4",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/test",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:19:45.426177
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.views import CompositionView
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.log import logger
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.response import text
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream

# Generated at 2022-06-18 05:19:51.432312
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.43, for="[2001:db8:cafe::17]"; proto=https; by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'proto': 'https', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:19:59.517832
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:20:11.230285
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {
        "for": "1.2.3.4"
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret")]) == {
        "for": "1.2.3.4",
        "by": "secret",
    }

# Generated at 2022-06-18 05:20:21.744190
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:20:28.491737
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient

    app = Sanic("test_parse_xforwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.headers.get("X-Forwarded-For"))

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(request.headers.get("X-Forwarded-For"))
        await ws.close()

    config = Config()
    config

# Generated at 2022-06-18 05:20:37.248591
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "1.2.3.4",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-path": "/path",
        "x-forwarded-proto": "https",
    }

# Generated at 2022-06-18 05:20:47.652226
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:20:55.501926
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-scheme": "https",
    }
    assert parse_xforwarded(headers, None) == {
        "for": "127.0.0.1",
        "host": "example.com",
        "port": 80,
        "proto": "http",
    }

# Generated at 2022-06-18 05:21:07.705154
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-proto": "https",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": None,
    }

# Generated at 2022-06-18 05:21:32.448619
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1, 192.168.1.2",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": 2,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": None,
    }

# Generated at 2022-06-18 05:21:43.156687
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "192.168.1.1, 192.168.1.2, 192.168.1.3",
    }
    config = {
        "REAL_IP_HEADER": "x-real-ip",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 3,
    }

# Generated at 2022-06-18 05:21:49.118808
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/path/to/resource'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }

# Generated at 2022-06-18 05:21:59.769446
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("127.0.0.1") == ("127.0.0.1", None)
    assert parse_host("127.0.0.1:80") == ("127.0.0.1", 80)
    assert parse_host("127.0.0.1:8080") == ("127.0.0.1", 8080)
    assert parse_host("[::1]") == ("::1", None)
    assert parse_host("[::1]:80") == ("::1", 80)
    assert parse_host("[::1]:8080") == ("::1", 8080)
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:80") == ("localhost", 80)

# Generated at 2022-06-18 05:22:10.971992
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:22:21.741144
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("_") == "_"
    assert fwd_normalize_address("_1") == "_1"
    assert fwd_normalize_address("_1.2.3.4") == "_1.2.3.4"
    assert fwd_normalize_address("1.2.3.4") == "1.2.3.4"
    assert fwd_normalize_address("1.2.3.4:80") == "1.2.3.4:80"
    assert fwd_normalize_address("1.2.3.4:8080") == "1.2.3.4:8080"
    assert fwd_normalize_address("1.2.3.4:8080") == "1.2.3.4:8080"
    assert f

# Generated at 2022-06-18 05:22:33.009760
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage

    # Create a mock request
    config = Config()
    config.FORWARDED_SECRET = "test"
    request = Request(
        "GET",
        "/",
        headers={"Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43"},
        config=config,
    )

    # Test if the parse_forwarded function returns the correct values
    assert request.forwarded

# Generated at 2022-06-18 05:22:44.272372
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:22:55.481366
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:23:06.468800
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43;proto=http;by=203.0.113.43",
            "for=192.0.2.43;proto=http;by=203.0.113.43, for=192.0.2.43;proto=http;by=203.0.113.43",
        ]
    }

# Generated at 2022-06-18 05:23:30.114689
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-proto": "http",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-real-ip",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:23:36.918532
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:8080") == "127.0.0.1:8080"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:8080") == "[::1]:8080"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret:8080") == "_secret:8080"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown:8080") == "unknown:8080"
    assert fwd_normal

# Generated at 2022-06-18 05:23:47.198373
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "9.10.11.12"}