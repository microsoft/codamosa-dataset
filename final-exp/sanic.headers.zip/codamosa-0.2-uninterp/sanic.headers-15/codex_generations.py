

# Generated at 2022-06-18 05:13:30.961945
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret.example.com") == "_secret.example.com"
    assert fwd_normalize_address("_secret.example.com:80") == "_secret.example.com:80"
    assert fwd_normalize_address("_secret.example.com:8080") == "_secret.example.com:8080"
    assert fwd_normalize_address("_secret.example.com:8080/path") == "_secret.example.com:8080/path"
    assert fwd_normalize_address("_secret.example.com:8080/path?query") == "_secret.example.com:8080/path?query"

# Generated at 2022-06-18 05:13:40.647980
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/path/to/resource",
    }
    config = type("Config", (object,), {"PROXIES_COUNT": 1})
    assert parse_xforwarded(headers, config) == {
        "for": "127.0.0.1",
        "host": "example.com",
        "port": 80,
        "proto": "http",
        "path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:13:47.310274
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("_") == "_"
    assert fwd_normalize_address("_123") == "_123"
    assert fwd_normalize_address("_123.456.789.012") == "_123.456.789.012"
    assert fwd_normalize_address("123.456.789.012") == "123.456.789.012"
    assert fwd_normalize_address("123.456.789.012:80") == "123.456.789.012:80"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:80") == "[::1]:80"
    assert fwd_normalize_address("[::1]:8080") == "[::1]:8080"

# Generated at 2022-06-18 05:13:57.526705
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.PROXIES_COUNT = 0
    config.REAL_IP_HEADER = None

    # Test that the function returns None if no secret is found
    headers = {"Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}
    request = Request(
        "GET", "http://example.com", headers=headers, config=config
    )
    assert request.forwarded is None

    # Test that the function returns None if no secret is found

# Generated at 2022-06-18 05:14:06.992381
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {'x-forwarded-for': '127.0.0.1', 'x-forwarded-host': 'localhost', 'x-forwarded-port': '8080', 'x-forwarded-path': '/test'}
    config = {'PROXIES_COUNT': 1, 'FORWARDED_FOR_HEADER': 'x-forwarded-for', 'REAL_IP_HEADER': 'x-forwarded-for', 'FORWARDED_SECRET': ''}
    assert parse_xforwarded(headers, config) == {'for': '127.0.0.1', 'host': 'localhost', 'port': 8080, 'path': '/test'}


# Generated at 2022-06-18 05:14:16.072791
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:14:26.741150
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("192.168.1.1") == "192.168.1.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_192.168.1.1") == "_192.168.1.1"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_unknown") == "_unknown"
    assert fwd_normalize_address("_unknown_") == "_unknown_"
    assert fwd_normalize_address("_unknown_1") == "_unknown_1"
    assert fwd_normalize_address("_unknown_1.2.3.4") == "_unknown_1.2.3.4"
    assert fwd_normalize_

# Generated at 2022-06-18 05:14:38.423585
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret"}) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret2"}) == None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": ""}) == None

# Generated at 2022-06-18 05:14:50.051335
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '127.0.0.1',
        'x-forwarded-host': '127.0.0.1',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': '',
    }

# Generated at 2022-06-18 05:15:02.863243
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename=\"file.txt\"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt;') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt; ') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:15:16.110173
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {
        "for": "1.2.3.4",
        "by": "5.6.7.8",
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8"), ("by", "9.10.11.12")]) == {
        "for": "1.2.3.4",
        "by": "9.10.11.12",
    }

# Generated at 2022-06-18 05:15:27.962959
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2, 192.168.1.3",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "443",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:15:34.537477
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {
        "for": "5.6.7.8"
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {
        "for": "1.2.3.4",
        "by": "5.6.7.8",
    }

# Generated at 2022-06-18 05:15:44.726775
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '127.0.0.1',
        'x-forwarded-host': 'localhost',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-scheme': 'https',
        'x-forwarded-path': '/test'
    }

# Generated at 2022-06-18 05:15:56.874493
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43;proto=https;by=203.0.113.43",
            "for=192.0.2.43;proto=https;by=203.0.113.43, for=192.0.2.43;proto=https;by=203.0.113.43",
        ]
    }

# Generated at 2022-06-18 05:16:04.384388
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret2'}
    assert parse_forwarded(headers, config) == None

# Generated at 2022-06-18 05:16:15.724920
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "::1")]) == {"for": "[::1]"}
    assert fwd_normalize([("for", "::1"), ("proto", "https")]) == {
        "for": "[::1]",
        "proto": "https",
    }
    assert fwd_normalize([("for", "::1"), ("proto", "https"), ("host", "example.com")]) == {
        "for": "[::1]",
        "proto": "https",
        "host": "example.com",
    }

# Generated at 2022-06-18 05:16:25.474131
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.0.1, 192.168.0.2',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:16:34.971971
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "9.10.11.12"}

# Generated at 2022-06-18 05:16:45.572618
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "1.2.3.4",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": "",
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:16:59.728511
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17",
        ]
    }
    config = {"FORWARDED_SECRET": "secret"}
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "http",
        "by": "203.0.113.43",
    }
    config = {"FORWARDED_SECRET": "wrong"}
    assert parse_forwarded(headers, config) is None
    headers = {"Forwarded": ["for=192.0.2.43"]}

# Generated at 2022-06-18 05:17:07.968755
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic(__name__)
    app.config.FORWARDED_SECRET = "secret"

    @app.route("/")
    async def handler(request):
        return text(str(parse_forwarded(request.headers, app.config)))

    @app.route("/<path:path>")
    async def handler_with_path(request, path):
        return text(str(parse_forwarded(request.headers, app.config)))


# Generated at 2022-06-18 05:17:19.337399
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with a valid header
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

    # Test with a valid header and a secret
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43;secret=secret'}
    config = {'FORWARDED_SECRET': 'secret'}

# Generated at 2022-06-18 05:17:22.926937
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request

    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;by=203.0.113.43;secret=secret"}
    request = Request(headers=headers, config=config)
    assert request.forwarded == {"for": "192.0.2.60", "proto": "http", "by": "203.0.113.43"}

# Generated at 2022-06-18 05:17:32.372885
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:8080") == ("localhost", 8080)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1%eth0]") == ("[::1%eth0]", None)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)
    assert parse_host("[::1%eth0]:") == ("[::1%eth0]", None)
    assert parse_host("[::1%eth0]:abc") == ("[::1%eth0]", None)

# Generated at 2022-06-18 05:17:44.799243
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "192.168.0.1",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": None,
    }

# Generated at 2022-06-18 05:17:56.228156
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17'}
    config = {'FORWARDED_SECRET': 'secret2'}
    assert parse_forwarded

# Generated at 2022-06-18 05:18:04.693029
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'http',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'https',
    }
    config = {
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'REAL_IP_HEADER': 'X-Forwarded-For',
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:18:11.796107
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}

# Generated at 2022-06-18 05:18:20.425871
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:18:33.360580
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2"), ("for", "127.0.0.3")]) == {"for": "127.0.0.1"}

# Generated at 2022-06-18 05:18:45.966315
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/'
    }

# Generated at 2022-06-18 05:18:51.062058
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request

    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43"}
    request = Request(headers=headers, config=config)
    assert request.forwarded == {"for": "198.51.100.17", "proto": "https", "by": "203.0.113.43"}

# Generated at 2022-06-18 05:19:01.172050
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60; proto=http; by=203.0.113.43, for=192.0.2.43, for=198.51.100.17",
            "for=192.0.2.43; proto=https; by=203.0.113.43",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "REAL_IP_HEADER": "x-real-ip",
        "PROXIES_COUNT": 3,
    }

# Generated at 2022-06-18 05:19:13.391528
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '1.2.3.4',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:19:22.030881
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:19:28.196158
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import ConnectionClosed

# Generated at 2022-06-18 05:19:34.970891
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.0.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/path/to/resource',
        'x-scheme': 'https',
    }
    config = {
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': '',
        'REAL_IP_HEADER': '',
    }

# Generated at 2022-06-18 05:19:44.657651
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43"}
    request = Request(headers=headers, config=config)
    print(parse_forwarded(request.headers, config))
    assert parse_forwarded(request.headers, config) == {'for': '198.51.100.17', 'proto': 'https', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:19:54.445777
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-proto': 'https',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:20:07.753132
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:20:12.808097
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    config = Config()
    config.REAL_IP_HEADER = 'X-Real-IP'
    config.PROXIES_COUNT = 1
    config.FORWARDED_FOR_HEADER = 'X-Forwarded-For'
    config.FORWARDED_SECRET = 'secret'

# Generated at 2022-06-18 05:20:23.306671
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket

# Generated at 2022-06-18 05:20:35.448342
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:20:46.442947
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:20:56.975219
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 2

    # Create a server
    app = Sanic("test_parse_xforwarded")


# Generated at 2022-06-18 05:21:07.984420
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'http',
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'FORWARDED_SECRET': '',
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:21:19.908410
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1

    protocol = HttpProtocol(None, None, None, None, config)


# Generated at 2022-06-18 05:21:32.580380
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '10.0.0.1, 10.0.0.2',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': '',
    }

# Generated at 2022-06-18 05:21:43.319416
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.1.1")]) == {"for": "192.168.1.1"}
    assert fwd_normalize([("for", "192.168.1.1"), ("for", "192.168.1.2")]) == {"for": "192.168.1.2"}
    assert fwd_normalize([("for", "192.168.1.1"), ("for", "192.168.1.2"), ("for", "192.168.1.3")]) == {"for": "192.168.1.3"}

# Generated at 2022-06-18 05:22:01.699373
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1

    def test_request(headers):
        request = Request(
            "GET", "/", headers=headers, version="1.1", config=config
        )
        response = HTTPResponse("OK")

# Generated at 2022-06-18 05:22:12.630348
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:22:23.150360
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedAbnormal
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedRemoteProtocolError
    from sanic.websocket import WebSocketConnectionClosedInternalError

# Generated at 2022-06-18 05:22:34.507386
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:22:46.622670
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.testing import HOST, PORT

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.forwarded)

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        return ws.send(request.forwarded)

    # Create a server and a client

# Generated at 2022-06-18 05:22:57.678898
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with a valid secret
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'proto': 'http', 'by': '203.0.113.43'}

    # Test with a invalid secret

# Generated at 2022-06-18 05:23:08.713386
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43,for="[2001:db8:cafe::17]:4711";proto=https']}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'Forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43,for="[2001:db8:cafe::17]:4711";proto=https']}
    config = {'FORWARDED_SECRET': 'secret2'}
    assert parse_

# Generated at 2022-06-18 05:23:20.578211
# Unit test for function parse_forwarded