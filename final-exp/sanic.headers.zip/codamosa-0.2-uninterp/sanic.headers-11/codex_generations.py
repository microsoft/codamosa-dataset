

# Generated at 2022-06-18 05:13:43.361753
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:13:51.093298
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "::1")]) == {"for": "[::1]"}
    assert fwd_normalize([("for", "unknown")]) == {}
    assert fwd_normalize([("for", "_secret")]) == {"for": "_secret"}
    assert fwd_normalize([("for", "127.0.0.1"), ("by", "127.0.0.1")]) == {
        "for": "127.0.0.1",
        "by": "127.0.0.1",
    }

# Generated at 2022-06-18 05:14:02.507193
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/path/to/resource'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': None
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:14:12.115825
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {
        "for": "5.6.7.8"
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {
        "for": "1.2.3.4",
        "by": "5.6.7.8",
    }

# Generated at 2022-06-18 05:14:24.075302
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:14:31.101710
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "1.2.3.4",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/foo/bar",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:14:40.785517
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}

# Generated at 2022-06-18 05:14:52.488424
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:15:02.937594
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    config = Config()
    config.FORWARDED_SECRET = "secret"

    class TestHttpProtocol(HttpProtocol):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.config = config

    class TestWebSocketProtocol(WebSocketProtocol):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.config = config


# Generated at 2022-06-18 05:15:13.877670
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {"for": "1.2.3.4", "by": "5.6.7.8"}

# Generated at 2022-06-18 05:15:30.013410
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17;by=203.0.113.43;secret=12345',
        'x-forwarded-for': '192.0.2.43, 198.51.100.17',
        'x-forwarded-proto': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource'
    }


# Generated at 2022-06-18 05:15:39.761129
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:8080") == ("localhost", 8080)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1%eth0]") == ("[::1%eth0]", None)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)
    assert parse

# Generated at 2022-06-18 05:15:49.975016
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with a valid secret
    headers = {
        "forwarded": "for=192.0.2.60;proto=https;by=203.0.113.43,for=192.0.2.43;proto=https;by=203.0.113.43,for=192.0.2.43;proto=https;by=203.0.113.43"
    }
    config = {
        "FORWARDED_SECRET": "secret"
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "https",
        "by": "203.0.113.43",
    }

    # Test with an invalid secret

# Generated at 2022-06-18 05:16:02.040001
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient
    from sanic.testing import loop
    from sanic.testing import main
    from sanic.testing import run_test_server
    from sanic.testing import test_config
    from sanic.testing import TestServer
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import StreamBuffer


# Generated at 2022-06-18 05:16:13.610270
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:16:24.064779
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:80") == ("localhost", 80)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:80") == ("[::1]", 80)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:65535") == ("[::1]", 65535)
    assert parse_host("[::1]:65536") == (None, None)
    assert parse_host("[::1]:-1") == (None, None)
    assert parse_host("[::1]:0") == ("[::1]", 0)

# Generated at 2022-06-18 05:16:28.480791
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/test',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:16:37.071171
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Path": "/path/to/resource",
        "X-Scheme": "https",
        "X-Forwarded-Proto": "http",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": None,
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
    }

# Generated at 2022-06-18 05:16:46.932643
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "127.0.0.1",
        "x-forwarded-proto": "http",
        "x-forwarded-port": "80",
        "x-forwarded-path": "/test",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:16:51.727740
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"") == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:17:07.142570
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "9.10.11.12"}

# Generated at 2022-06-18 05:17:18.097392
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1

    app = Sanic("test_parse_forwarded")


# Generated at 2022-06-18 05:17:29.189177
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1, 192.168.1.2, 192.168.1.3",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:17:37.201533
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17', 'proto': 'https', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:17:47.261738
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for=192.0.2.43, for=198.51.100.17;by=203.0.113.60;proto=https;host=example.com;port=8080;path=/foo/bar'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'by': '203.0.113.60', 'proto': 'https', 'host': 'example.com', 'port': 8080, 'path': '/foo/bar'}

# Generated at 2022-06-18 05:17:58.232025
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"X-Forwarded-For": "192.168.0.1, 192.168.0.2",
               "X-Forwarded-Host": "example.com",
               "X-Forwarded-Port": "80",
               "X-Forwarded-Path": "/path/to/resource",
               "X-Scheme": "http",
               "X-Forwarded-Proto": "https"}
    config = {"PROXIES_COUNT": 2,
              "FORWARDED_FOR_HEADER": "X-Forwarded-For",
              "REAL_IP_HEADER": "X-Forwarded-For",
              "FORWARDED_SECRET": None}

# Generated at 2022-06-18 05:18:05.520981
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with empty string
    assert parse_forwarded({"forwarded": ""}, None) is None
    # Test with empty string and secret
    assert parse_forwarded({"forwarded": ""}, "secret") is None
    # Test with secret
    assert parse_forwarded({"forwarded": "secret"}, "secret") == {}
    # Test with secret and by
    assert parse_forwarded({"forwarded": "secret, by=secret"}, "secret") == {"by": "secret"}
    # Test with secret and by and for
    assert parse_forwarded({"forwarded": "secret, by=secret, for=127.0.0.1"}, "secret") == {"by": "secret", "for": "127.0.0.1"}
    # Test with secret and by and for and proto

# Generated at 2022-06-18 05:18:16.486989
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "127.0.0.1",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "http",
        "X-Forwarded-Path": "/path/to/file",
    }

# Generated at 2022-06-18 05:18:27.882263
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.1.1")]) == {"for": "192.168.1.1"}
    assert fwd_normalize([("for", "192.168.1.1"), ("by", "192.168.1.2")]) == {
        "for": "192.168.1.1",
        "by": "192.168.1.2",
    }
    assert fwd_normalize([("for", "192.168.1.1"), ("by", "192.168.1.2")]) == {
        "for": "192.168.1.1",
        "by": "192.168.1.2",
    }

# Generated at 2022-06-18 05:18:40.256998
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:19:02.495878
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:19:10.624283
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;host=example.com;port=8080;path=/foo/bar'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'host': 'example.com', 'port': 8080, 'path': '/foo/bar'}


# Generated at 2022-06-18 05:19:20.691157
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'http',
    }

# Generated at 2022-06-18 05:19:30.049786
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:19:38.914760
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret"
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "http",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:19:48.293171
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.PROXIES_COUNT = 0
    config.REAL_IP_HEADER = None

    # Test with no secret
    config.FORWARDED_SECRET = None
    request = Request("GET", "/", headers={"Forwarded": "for=1.2.3.4"})
    assert parse_forwarded(request.headers, config) is None

    # Test with secret
    config.FORWARDED_SECRET = "secret"
   

# Generated at 2022-06-18 05:19:57.946075
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 05:20:07.261028
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {
        "forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;by=203.0.113.43;secret=secret"
    }
    assert parse_forwarded(headers, config) == {
        "for": "198.51.100.17",
        "by": "203.0.113.43",
        "proto": "http",
    }

# Generated at 2022-06-18 05:20:17.359731
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}

# Generated at 2022-06-18 05:20:26.337669
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.0.1")]) == {"for": "192.168.0.1"}
    assert fwd_normalize([("for", "192.168.0.1"), ("for", "192.168.0.2")]) == {"for": "192.168.0.1"}
    assert fwd_normalize([("for", "192.168.0.1"), ("for", "192.168.0.2"), ("for", "192.168.0.3")]) == {"for": "192.168.0.1"}

# Generated at 2022-06-18 05:20:59.649393
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource',
        'x-forwarded-for': '192.0.2.43, 2001:db8:cafe::17'
    }
    config = {
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1
    }

# Generated at 2022-06-18 05:21:09.837334
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'http',
    }

# Generated at 2022-06-18 05:21:21.496463
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:21:33.883263
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.worker import GunicornWorker
    from sanic.app import Sanic

    app = Sanic("test_parse_forwarded")


# Generated at 2022-06-18 05:21:43.522492
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"x-forwarded-for": "127.0.0.1"}
    config = {"REAL_IP_HEADER": "x-forwarded-for", "PROXIES_COUNT": 1}
    assert parse_xforwarded(headers, config) == {"for": "127.0.0.1"}

    headers = {"x-forwarded-for": "127.0.0.1, 127.0.0.2"}
    config = {"REAL_IP_HEADER": "x-forwarded-for", "PROXIES_COUNT": 1}
    assert parse_xforwarded(headers, config) == {"for": "127.0.0.2"}


# Generated at 2022-06-18 05:21:49.307029
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43'}

# Generated at 2022-06-18 05:21:59.894887
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:22:11.052306
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Path': '/test',
        'X-Scheme': 'https',
        'X-Forwarded-Proto': 'http',
    }

# Generated at 2022-06-18 05:22:21.816416
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("by", "127.0.0.1")]) == {
        "for": "127.0.0.1",
        "by": "127.0.0.1",
    }
    assert fwd_normalize([("for", "127.0.0.1"), ("by", "127.0.0.1"), ("by", "127.0.0.1")]) == {
        "for": "127.0.0.1",
        "by": "127.0.0.1",
    }

# Generated at 2022-06-18 05:22:33.108023
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.0.1, 192.168.0.2, 192.168.0.3",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Path": "/path/to/file",
        "X-Scheme": "http",
        "X-Forwarded-Proto": "https",
    }