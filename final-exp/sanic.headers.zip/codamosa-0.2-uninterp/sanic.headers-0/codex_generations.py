

# Generated at 2022-06-18 05:13:43.627328
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:13:51.281049
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:8080") == "127.0.0.1:8080"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:8080") == "[::1]:8080"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret:8080") == "_secret:8080"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown:8080") == "unknown:8080"
    assert fwd_normal

# Generated at 2022-06-18 05:14:02.141586
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=https;by=203.0.113.43"
    }
    config = {
        "FORWARDED_SECRET": "secret",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "REAL_IP_HEADER": "x-real-ip",
        "PROXIES_COUNT": 0,
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "https",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:14:11.870648
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.request import Request
    from sanic.config import Config
    from sanic.response import HTTPResponse
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.server import serve
    from sanic.server import serve_multiple
    from sanic.server import trigger_events
    from sanic.server import trigger_events_for_request
    from sanic.server import trigger_events_for_response
    from sanic.server import trigger_events_for_websocket
    from sanic.server import trigger_events_for_websocket_error
    from sanic.server import trigger_events_for_async_response

# Generated at 2022-06-18 05:14:23.793794
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:14:30.948820
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http"}, config=None) == {'for': '192.0.2.60', 'proto': 'http'}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http, for=192.0.2.60;proto=http"}, config=None) == {'for': '192.0.2.60', 'proto': 'http'}

# Generated at 2022-06-18 05:14:40.708603
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_unknown") == "_unknown"
    assert fwd_normalize_address("_unknown_") == "_unknown_"
    assert fwd_normalize_address("_unknown_1") == "_unknown_1"
    assert fwd_normalize_address("_unknown_1.2.3.4") == "_unknown_1.2.3.4"

# Generated at 2022-06-18 05:14:52.459204
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.forwarded)

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(request.forwarded)

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED

# Generated at 2022-06-18 05:15:02.938096
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:15:13.836107
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("by", "127.0.0.1")]) == {
        "for": "127.0.0.1",
        "by": "127.0.0.1",
    }
    assert fwd_normalize([("for", "127.0.0.1"), ("by", "127.0.0.1"), ("by", "127.0.0.2")]) == {
        "for": "127.0.0.1",
        "by": "127.0.0.2",
    }

# Generated at 2022-06-18 05:15:30.176528
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}

# Generated at 2022-06-18 05:15:38.043214
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/",
    }
    assert parse_xforwarded(headers, None) == {
        "for": "127.0.0.1",
        "host": "example.com",
        "port": 80,
        "proto": "http",
        "path": "/",
    }

# Generated at 2022-06-18 05:15:49.341303
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import RequestParameters
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1

    class TestHttpProtocol(HttpProtocol):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.config = config

    async def handler(request):
        return HTTPResponse(request.forwarded)

# Generated at 2022-06-18 05:16:01.476751
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:16:13.563588
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2, 192.168.1.3",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "443",
        "X-Forwarded-Path": "/path/to/file",
        "X-Scheme": "https",
    }

# Generated at 2022-06-18 05:16:24.077125
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:8080") == "127.0.0.1:8080"
    assert fwd_normalize_address("_127.0.0.1") == "_127.0.0.1"
    assert fwd_normalize_address("_127.0.0.1:8080") == "_127.0.0.1:8080"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:8080") == "[::1]:8080"
    assert fwd_normalize_address("_[::1]") == "_[::1]"

# Generated at 2022-06-18 05:16:27.214113
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17'
    }
    config = {
        'FORWARDED_SECRET': 'secret'
    }
    assert parse_forwarded(headers, config) == {
        'for': '192.0.2.60',
        'proto': 'http',
        'by': '203.0.113.43'
    }

# Generated at 2022-06-18 05:16:36.249004
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:80") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:8080") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:8080/") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:8080/test") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:8080/test/") == "127.0.0.1"
    assert fwd_

# Generated at 2022-06-18 05:16:46.279169
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43;proto=https;by=203.0.113.43",
            "for=192.0.2.43;proto=https;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
        "REAL_IP_HEADER": "X-Real-IP",
        "PROXIES_COUNT": 0,
    }
    assert parse_

# Generated at 2022-06-18 05:16:57.034197
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/test',
    }

# Generated at 2022-06-18 05:17:19.969029
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/test",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:17:30.597910
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-scheme": "http",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-path": "/path/to/resource",
    }
    config = type("Config", (), {"PROXIES_COUNT": 1})
    assert parse_xforwarded(headers, config) == {
        "for": "192.168.1.1",
        "proto": "http",
        "host": "example.com",
        "port": 80,
        "path": "/path/to/resource",
    }
    config.PROXIES_COUNT = 2
    assert parse_xforwarded(headers, config) is None


# Generated at 2022-06-18 05:17:43.115012
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17;proto=https;by=203.0.113.43",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:17:51.470879
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:8080") == ("localhost", 8080)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1%eth0]") == ("[::1%eth0]", None)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)
    assert parse_host("[::1%eth0]") == ("[::1%eth0]", None)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)

# Generated at 2022-06-18 05:17:56.763873
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-proto': 'https',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:18:04.994734
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import RequestParameters

    config = Config()
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.FORWARDED_PROTO_HEADER = "x-forwarded-proto"
    config.FORWARDED_HOST_HEADER = "x-forwarded-host"
    config.FORWARDED_PORT_HEADER = "x-forwarded-port"
    config.FORWARDED_PATH_HEADER = "x-forwarded-path"
    config.PROXIES_COUNT = 2

    headers = RequestParameters()
    headers["x-real-ip"] = "127.0.0.1"

# Generated at 2022-06-18 05:18:16.047553
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {
        "for": "5.6.7.8"
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {
        "for": "1.2.3.4",
        "by": "5.6.7.8",
    }

# Generated at 2022-06-18 05:18:27.385458
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.REAL_IP_HEADER = "X-Real-IP"
    config.PROXIES_COUNT = 1

    app = Sanic("test_parse_forwarded")


# Generated at 2022-06-18 05:18:35.358061
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with a valid secret
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43, for=198.51.100.17;by=203.0.113.43;secret=secret'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17', 'by': '203.0.113.43', 'proto': 'http'}
    # Test with a valid secret, but no matching secret in the header

# Generated at 2022-06-18 05:18:42.162257
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '1.2.3.4',
        'x-forwarded-proto': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': None
    }

# Generated at 2022-06-18 05:19:03.276567
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.views import CompositionView

    app = Sanic('test_parse_forwarded')

    @app.route('/')
    async def handler(request):
        return HTTPResponse(request.forwarded)

    @app.websocket('/ws')
    async def ws_handler(request, ws):
        await ws.send(str(request.forwarded))

    @app.route('/view')
    class View(CompositionView):
        async def get(self, request):
            return HTTPR

# Generated at 2022-06-18 05:19:14.994156
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/test",
    }

# Generated at 2022-06-18 05:19:22.953619
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("_") == "_"
    assert fwd_normalize_address("_foo") == "_foo"
    assert fwd_normalize_address("_foo.bar") == "_foo.bar"
    assert fwd_normalize_address("foo") == "foo"
    assert fwd_normalize_address("foo.bar") == "foo.bar"
    assert fwd_normalize_address("foo.bar.baz") == "foo.bar.baz"
    assert fwd_normalize_address("Foo.Bar.Baz") == "foo.bar.baz"
    assert fwd_normalize_address("Foo.Bar.Baz.Quux") == "foo.bar.baz.quux"

# Generated at 2022-06-18 05:19:28.880557
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'http',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'https'
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 1
    }

# Generated at 2022-06-18 05:19:39.813269
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "localhost",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/test",
    }
    config = type("Config", (), {"PROXIES_COUNT": 1})
    assert parse_xforwarded(headers, config) == {
        "for": "127.0.0.1",
        "host": "localhost",
        "port": 80,
        "proto": "http",
        "path": "/test",
    }

# Generated at 2022-06-18 05:19:45.504425
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17', 'proto': 'https', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:19:55.367219
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "http",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-path": "/path",
    }
    config = {
        "REAL_IP_HEADER": "x-real-ip",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }
    assert parse_xforwarded(headers, config) == {
        "proto": "http",
        "host": "example.com",
        "port": 80,
        "path": "/path",
    }
    headers["x-real-ip"] = "1.2.3.4"

# Generated at 2022-06-18 05:20:01.478498
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "1.2.3.4"), ("for", "1.2.3.4")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:20:09.832755
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    config = Config()
    config.PROXIES_COUNT = 1
    config.FORWARDED_FOR_HEADER = 'X-Forwarded-For'
    config.REAL_IP_HEADER = 'X-Real-IP'
    headers = {'X-Forwarded-For': '192.168.0.1, 192.168.0.2', 'X-Real-IP': '192.168.0.3'}
    assert parse_xforwarded(headers, config) == {'for': '192.168.0.2'}

# Generated at 2022-06-18 05:20:20.103234
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test the function parse_forwarded
    # Test case 1
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    # Test case 2
    headers = {'Forwarded': 'for=192.0.2.43, for=198.51.100.17'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == None
    # Test case 3

# Generated at 2022-06-18 05:20:59.142944
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normal

# Generated at 2022-06-18 05:21:09.629643
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {"for": "127.0.0.2"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2"), ("for", "127.0.0.3")]) == {"for": "127.0.0.3"}

# Generated at 2022-06-18 05:21:21.351597
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.PROXIES_COUNT = 0
    config.REAL_IP_HEADER = ""
    config.FORWARDED_FOR_HEADER = ""

    def test(headers, expected):
        request = Request(
            "GET",
            "/",
            headers=headers,
            version="1.1",
            protocol="HTTP/1.1",
            app=None,
            config=config,
        )
        assert request.forwarded == expected


# Generated at 2022-06-18 05:21:31.252330
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17;by=203.0.113.43;secret=test'}
    config = {'FORWARDED_SECRET': 'test'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'proto': 'http', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:21:39.177328
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret"}) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret2"}) == None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": None}) == None

# Generated at 2022-06-18 05:21:46.940868
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"

    # Test with HTTP/1.1
    request = Request(
        "GET",
        "/",
        headers={
            "forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=https;by=203.0.113.43"
        },
        version="1.1",
        config=config,
    )

# Generated at 2022-06-18 05:21:58.590702
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:22:10.333286
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.1.1")]) == {
        "for": "192.168.1.1"
    }
    assert fwd_normalize([("for", "192.168.1.1"), ("by", "192.168.1.2")]) == {
        "for": "192.168.1.1",
        "by": "192.168.1.2",
    }
    assert fwd_normalize([("for", "192.168.1.1"), ("by", "192.168.1.2")]) == {
        "for": "192.168.1.1",
        "by": "192.168.1.2",
    }

# Generated at 2022-06-18 05:22:15.326282
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol

    class TestView(HTTPMethodView):
        def get(self, request):
            return HTTPResponse(request.forwarded)

    class TestWebSocket(WebSocketProtocol):
        def on_message(self, message):
            self.send(self.request.forwarded)

    app = Sanic("test_parse_forwarded")
    app.add_route(TestView.as_view(), "/")
    app.add_websocket_route(TestWebSocket.as_view(), "/ws")
    config

# Generated at 2022-06-18 05:22:23.995445
# Unit test for function parse_forwarded