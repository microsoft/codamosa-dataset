

# Generated at 2022-06-18 05:14:06.841038
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    import asyncio
    import socket

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1

    app = Sanic("test_parse_forwarded")


# Generated at 2022-06-18 05:14:15.365975
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {
        "for": "1.2.3.4"
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret")]) == {
        "for": "1.2.3.4",
        "by": "secret",
    }

# Generated at 2022-06-18 05:14:26.636627
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:8080") == ("localhost", 8080)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1%eth0]") == ("[::1%eth0]", None)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)
    assert parse_host("[::1%eth0]") == ("[::1%eth0]", None)
    assert parse_host("[::1%eth0]:8080") == ("[::1%eth0]", 8080)

# Generated at 2022-06-18 05:14:38.332726
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {"for": "1.2.3.4", "by": "5.6.7.8"}

# Generated at 2022-06-18 05:14:49.959835
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret"}) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret2"}) == None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": None}) == None

# Generated at 2022-06-18 05:15:02.902066
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:15:13.794359
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}

# Generated at 2022-06-18 05:15:26.064319
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import sanic.config
    sanic.config.Config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:15:36.017162
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:15:47.292386
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.1.1.1")]) == {"for": "1.1.1.1"}
    assert fwd_normalize([("for", "1.1.1.1"), ("for", "2.2.2.2")]) == {"for": "2.2.2.2"}
    assert fwd_normalize([("for", "1.1.1.1"), ("for", "2.2.2.2"), ("for", "3.3.3.3")]) == {"for": "3.3.3.3"}

# Generated at 2022-06-18 05:16:03.196082
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-proto": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:16:14.389303
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:16:22.172903
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43"
    }
    config = {
        "FORWARDED_SECRET": "secret"
    }
    assert parse_forwarded(headers, config) == {
        "for": "198.51.100.17",
        "proto": "https",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:16:33.916330
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import text
    from sanic.server import HttpProtocol

    class TestConfig(Config):
        FORWARDED_SECRET = "secret"

    config = TestConfig()
    protocol = HttpProtocol(None, None, None, config=config)
    request = Request(protocol, "GET", "/", [], b"", None, None, None)
    request.headers = {
        "forwarded": "for=192.0.2.60; proto=http; by=203.0.113.43, for=198.51.100.17; by=203.0.113.43; secret=secret"
    }

# Generated at 2022-06-18 05:16:43.706064
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1, 192.168.1.2",
        "x-forwarded-host": "example.com",
        "x-forwarded-proto": "https",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    assert parse_xforwarded(headers, config) == {
        "for": "192.168.1.2",
        "proto": "https",
        "host": "example.com",
        "port": 443,
        "path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:16:55.151129
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:17:04.930085
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:80") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:80") == "[::1]"
    assert fwd_normalize_address("_obfuscated") == "_obfuscated"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("Unknown") == "unknown"
    assert fwd_normalize_address("UNKNOWN") == "unknown"
    assert fwd_normalize_address("UNKNOWN:80") == "unknown"

# Generated at 2022-06-18 05:17:15.873785
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret2'}
    assert parse_forwarded(headers, config) == None

# Generated at 2022-06-18 05:17:26.745512
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') != ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:17:34.695402
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("_127.0.0.1") == "_127.0.0.1"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_unknown") == "_unknown"
    assert fwd_normalize_address("_unknown_") == "_unknown_"
    assert fwd_normalize_address("_unknown_1") == "_unknown_1"
    assert fwd_normalize_address("_unknown_1_") == "_unknown_1_"
    assert fwd_normalize_address("_unknown_1_2") == "_unknown_1_2"

# Generated at 2022-06-18 05:17:49.770562
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/foo/bar",
        "x-forwarded-for": "192.168.0.1, 192.168.0.2, 192.168.0.3",
    }
    config = {
        "REAL_IP_HEADER": None,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:17:59.688245
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret"}) == {"for": "192.0.2.60", "proto": "http", "by": "203.0.113.43"}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret2"}) == None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": ""}) == None

# Generated at 2022-06-18 05:18:10.938980
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normal

# Generated at 2022-06-18 05:18:19.904303
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.testing import HOST, PORT

    app = Sanic(__name__)

    @app.route("/")
    async def handler(request):
        return HTTPResponse(text=request.headers.get("X-Forwarded-For"))

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(request.headers.get("X-Forwarded-For"))

    config = Config()

# Generated at 2022-06-18 05:18:31.066146
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '10.0.0.1, 10.0.0.2, 10.0.0.3',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/path/to/resource',
    }

# Generated at 2022-06-18 05:18:43.483498
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/file",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:18:55.224718
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43;proto=https;by=203.0.113.43",
            "for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43;proto=https;by=203.0.113.43",
        ]
    }

# Generated at 2022-06-18 05:19:03.775795
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'http',
        'x-forwarded-host': 'localhost:8000',
        'x-forwarded-port': '8000',
        'x-forwarded-path': '/',
        'x-forwarded-for': '127.0.0.1'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1
    }

# Generated at 2022-06-18 05:19:16.131034
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.1.1")]) == {"for": "192.168.1.1"}
    assert fwd_normalize([("for", "192.168.1.1"), ("for", "192.168.1.2")]) == {"for": "192.168.1.2"}
    assert fwd_normalize([("for", "192.168.1.1"), ("for", "192.168.1.2"), ("for", "192.168.1.3")]) == {"for": "192.168.1.3"}

# Generated at 2022-06-18 05:19:28.576820
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.testing import HOST, PORT

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.forwarded)

    @app.websocket("/ws")
    async def handler(request, ws):
        return ws.send(request.forwarded)

    @app.websocket("/ws_error")
    async def handler(request, ws):
        raise InvalidUsage("test")


# Generated at 2022-06-18 05:19:42.253509
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:19:48.702865
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret"}) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret2"}) == None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": None}) == None

# Generated at 2022-06-18 05:19:54.746187
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:8080") == "127.0.0.1:8080"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:8080") == "[::1]:8080"
    assert fwd_normalize_address("_obfuscated") == "_obfuscated"
    assert fwd_normalize_address("_obfuscated:8080") == "_obfuscated:8080"
    assert fwd_normalize_address("unknown") == "unknown"

# Generated at 2022-06-18 05:20:06.150705
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "5.6.7.8"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "9.10.11.12"}

# Generated at 2022-06-18 05:20:16.233199
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1:80")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1:80"), ("by", "127.0.0.1")]) == {
        "for": "127.0.0.1",
        "by": "127.0.0.1",
    }

# Generated at 2022-06-18 05:20:25.560253
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '443',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:20:35.704937
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": None,
        "FORWARDED_FOR_HEADER": None,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:20:43.767782
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:20:55.242132
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.views import CompositionView

    class TestView(CompositionView):
        def __init__(self):
            super().__init__()
            self.add("GET", self.get)

        async def get(self, request):
            return HTTPResponse(request.forwarded)

    app = Sanic("test_parse_forwarded")
    app.add_route(TestView.as_view(), "/")
    app.config.FORWARDED_SECRET = "secret"

    # Test with no forwarded header

# Generated at 2022-06-18 05:21:07.682904
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedAbnormal
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedRemoteProtocolError
    from sanic.websocket import WebSocketConnectionClosedInternalError

# Generated at 2022-06-18 05:21:22.474497
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {"for": "1.2.3.4", "by": "5.6.7.8"}

# Generated at 2022-06-18 05:21:34.107570
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic(__name__)
    app.config.FORWARDED_SECRET = "secret"

    @app.route("/")
    async def handler(request):
        return text(request.forwarded)

    client = app.test_client
    assert client.get("/").status == 200
    assert client.get("/", headers={"Forwarded": "by=127.0.0.1"}).status == 200
    assert client.get("/", headers={"Forwarded": "secret=secret"}).status == 200
    assert client.get("/", headers={"Forwarded": "secret=secret, by=127.0.0.1"}).status == 200

# Generated at 2022-06-18 05:21:37.937815
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17;by=203.0.113.43;secret=secret",
            "for=192.0.2.43,for=198.51.100.17;by=203.0.113.43;secret=secret",
        ]
    }

# Generated at 2022-06-18 05:21:46.152633
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-proto": "https",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:21:57.889991
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17'}
    config = {'FORWARDED_SECRET': 'secret1'}
    assert parse_forwarded

# Generated at 2022-06-18 05:22:10.137537
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.0.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/',
        'x-scheme': 'http',
    }

# Generated at 2022-06-18 05:22:21.239277
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/",
    }

# Generated at 2022-06-18 05:22:32.330956
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:22:43.325628
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:22:54.415361
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "localhost",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/test",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:23:13.916621
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection

    config = Config()
    config.REAL_IP_HEADER = 'X-Real-IP'
    config.FORWARDED_FOR_HEADER = 'X-Forwarded-For'
    config.PROXIES_COUNT = 1
    config.FORWARDED_SECRET = None


# Generated at 2022-06-18 05:23:23.053960
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {"for": "127.0.0.2"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2"), ("for", "127.0.0.3")]) == {"for": "127.0.0.3"}

# Generated at 2022-06-18 05:23:33.940284
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}, {'FORWARDED_SECRET': 'secret'}) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}, {'FORWARDED_SECRET': 'wrong'}) == None
    assert parse_forwarded({'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}, {'FORWARDED_SECRET': None}) == None

# Generated at 2022-06-18 05:23:45.353864
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("_127.0.0.1") == "_127.0.0.1"
    assert fwd_normalize_address("2001:0db8:85a3:0000:0000:8a2e:0370:7334") == "[2001:0db8:85a3:0000:0000:8a2e:0370:7334]"
    assert fwd_normalize_address("_2001:0db8:85a3:0000:0000:8a2e:0370:7334") == "_2001:0db8:85a3:0000:0000:8a2e:0370:7334"

# Generated at 2022-06-18 05:23:53.622648
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import RequestParameters
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.views import CompositionView

    class TestView(CompositionView):
        def __init__(self, app, handler):
            super().__init__(app, handler)

        async def get(self, request):
            return HTTPResponse(text="OK")

    class TestApp:
        def __init__(self):
            self.config = Config()
            self.config.REAL_IP_HEADER = "X-Real-IP"
            self.config.FORWARDED_FOR_HEADER = "X-Forwarded-For"