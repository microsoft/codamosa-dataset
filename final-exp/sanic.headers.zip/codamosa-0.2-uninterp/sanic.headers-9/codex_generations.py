

# Generated at 2022-06-18 05:13:48.556233
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "http",
        "X-Forwarded-Path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": 2,
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
        "FORWARDED_SECRET": None,
    }

# Generated at 2022-06-18 05:13:59.499261
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    config = Config()
    config.FORWARDED_SECRET = "secret"

    # Test with HTTP/1.1
    app = Sanic("test_parse_forwarded")
    @app.route("/")
    def handler(request):
        return HTTPResponse(str(request.forwarded))


# Generated at 2022-06-18 05:14:09.784394
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol

    # Create a server
    app = Sanic('test_parse_xforwarded')

    @app.route('/')
    async def handler(request):
        return HTTPResponse(text=str(request.forwarded))

    # Start the server
    server = app.create_server(
        host=HOST, port=PORT, return_asyncio_server=True,
        protocol=HttpProtocol, websocket_protocol=WebSocketProtocol)
    loop = asyncio.get_event_loop()

# Generated at 2022-06-18 05:14:23.349063
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.PROXIES_COUNT = 1

    # Test parse_forwarded
    # Test with no secret
    config.FORWARDED_SECRET = None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http"}, config) is None


# Generated at 2022-06-18 05:14:36.039522
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("by", "secret")]) == {
        "for": "127.0.0.1",
        "by": "secret",
    }
    assert fwd_normalize([("for", "127.0.0.1"), ("by", "secret"), ("proto", "https")]) == {
        "for": "127.0.0.1",
        "by": "secret",
        "proto": "https",
    }

# Generated at 2022-06-18 05:14:46.879735
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'http',
        'X-Forwarded-Path': '/path'
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 1
    }

# Generated at 2022-06-18 05:14:55.694250
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.1.1")]) == {"for": "192.168.1.1"}
    assert fwd_normalize([("for", "192.168.1.1"), ("proto", "https")]) == {
        "for": "192.168.1.1",
        "proto": "https",
    }
    assert fwd_normalize([("for", "192.168.1.1"), ("proto", "https"), ("by", "192.168.1.2")]) == {
        "for": "192.168.1.1",
        "proto": "https",
        "by": "192.168.1.2",
    }

# Generated at 2022-06-18 05:15:02.291043
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=https;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:15:12.891175
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:80") == ("localhost", 80)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:80") == ("[::1]", 80)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:65535") == ("[::1]", 65535)
    assert parse_host("[::1]:65536") == (None, None)
    assert parse_host("[::1]:-1") == (None, None)
    assert parse_host("[::1]:foo") == (None, None)
    assert parse_host("[::1]:") == (None, None)

# Generated at 2022-06-18 05:15:18.697242
# Unit test for function format_http1_response
def test_format_http1_response():
    assert format_http1_response(200, []) == b"HTTP/1.1 200 OK\r\n\r\n"
    assert format_http1_response(200, [(b"Content-Length", b"0")]) == b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n"
    assert format_http1_response(200, [(b"Content-Length", b"0"), (b"Content-Type", b"text/html")]) == b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\nContent-Type: text/html\r\n\r\n"
    assert format_http1_response(404, []) == b"HTTP/1.1 404 Not Found\r\n\r\n"
    assert format_

# Generated at 2022-06-18 05:15:32.823830
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:15:41.746026
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/test",
        "x-scheme": "http",
    }
    config = type("Config", (), {"PROXIES_COUNT": 1})()
    assert parse_xforwarded(headers, config) == {
        "for": "192.168.1.1",
        "host": "example.com",
        "port": 80,
        "proto": "https",
        "path": "/test",
    }
    config.PROXIES_COUNT = 0

# Generated at 2022-06-18 05:15:52.899793
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'http',
        'X-Forwarded-Proto': 'https',
    }

# Generated at 2022-06-18 05:16:02.040653
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60; proto=http; by=203.0.113.43, for=198.51.100.17; proto=https; by=203.0.113.43",
        "Forwarded": "for=192.0.2.43, for=198.51.100.17",
    }
    config = {
        "FORWARDED_SECRET": "secret",
    }
    result = parse_forwarded(headers, config)
    assert result == {
        "for": "192.0.2.43",
        "proto": "https",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:16:13.608935
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "http",
        "X-Forwarded-Path": "/",
    }

# Generated at 2022-06-18 05:16:24.065381
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "http",
        "x-forwarded-host": "localhost:8080",
        "x-forwarded-port": "8080",
        "x-forwarded-path": "/",
        "x-forwarded-for": "127.0.0.1"
    }
    config = {
        "REAL_IP_HEADER": "",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for"
    }
    assert parse_xforwarded(headers, config) == {
        "for": "127.0.0.1",
        "proto": "http",
        "host": "localhost:8080",
        "port": 8080,
        "path": "/"
    }

# Generated at 2022-06-18 05:16:30.540960
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:8080") == "127.0.0.1:8080"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:8080") == "[::1]:8080"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret:8080") == "_secret:8080"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown:8080") == "unknown:8080"
    assert fwd_normal

# Generated at 2022-06-18 05:16:37.956555
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'http',
        'X-Forwarded-Path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:16:47.420326
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:16:52.058405
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:17:26.544020
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:17:34.615575
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-proto': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:17:45.683863
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normal

# Generated at 2022-06-18 05:17:57.244822
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol

    class TestConfig(Config):
        FORWARDED_SECRET = "secret"
        FORWARDED_FOR_HEADER = "X-Forwarded-For"
        REAL_IP_HEADER = "X-Real-IP"
        PROXIES_COUNT = 1

    config = TestConfig()
    request = Request(
        "GET",
        "/",
        headers={"Forwarded": "for=192.0.2.60; proto=http; by=secret"},
        config=config,
    )

# Generated at 2022-06-18 05:18:04.634204
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }
    assert parse_xforwarded(headers, config) == {
        "proto": "https",
        "host": "example.com",
        "port": 443,
        "path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:18:15.798517
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.views import CompositionView

    class TestView(CompositionView):
        def __init__(self):
            super().__init__()
            self.add(["GET"], self.handler)

        async def handler(self, request):
            return HTTPResponse(request.headers.get("X-Forwarded-For"))

    app = Sanic("test_parse_forwarded")
    app.add_route(TestView.as_view(), "/")
    app.config.FORWARDED_SECRET = "secret"

    # Test with FORWARDED_SECRET
   

# Generated at 2022-06-18 05:18:27.344497
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-scheme': 'http',
        'x-forwarded-path': '/path/to/file'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }

# Generated at 2022-06-18 05:18:39.799275
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:18:52.070669
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'host',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/path',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
    }

# Generated at 2022-06-18 05:18:59.925099
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    import socket
    import asyncio
    import pytest
    import os
    import sys
    import time
    import json
    import logging
    import threading
    import unittest
    import traceback
    import random
    import string
    import uuid
    import pprint
    import requests
    import urllib
    import urllib.parse
    import urllib.request
    import urllib.error
    import urllib.response
    import urllib.parse
    import urllib.request
    import urllib

# Generated at 2022-06-18 05:19:21.607478
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:19:27.876588
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.utils import sanic_endpoint_test
    from sanic.views import CompositionView

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.headers.get("X-Forwarded-For"))


# Generated at 2022-06-18 05:19:34.801958
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normal

# Generated at 2022-06-18 05:19:45.316923
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with a valid header
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

    # Test with a valid header and a secret
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43;secret=secret'}
    config = {'FORWARDED_SECRET': 'secret'}

# Generated at 2022-06-18 05:19:55.155118
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test cases from RFC 7239
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"},
                           {"FORWARDED_SECRET": "secret"}) == {
                               "for": "192.0.2.60",
                               "proto": "http",
                               "by": "203.0.113.43"
                           }
    assert parse_forwarded({"forwarded": "for=192.0.2.43, for=198.51.100.17"},
                           {"FORWARDED_SECRET": "secret"}) == {
                               "for": "198.51.100.17"
                           }

# Generated at 2022-06-18 05:20:06.203703
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '443',
        'X-Forwarded-Path': '/path/to/resource'
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'FORWARDED_SECRET': 'secret'
    }

# Generated at 2022-06-18 05:20:11.686169
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "127.0.0.1",
        "x-forwarded-proto": "http",
        "x-forwarded-port": "80",
        "x-forwarded-path": "/test",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:20:22.288831
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:20:30.821960
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:20:42.127754
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test cases from RFC 7239
    # https://tools.ietf.org/html/rfc7239#section-5.2
    assert parse_forwarded(
        {
            "forwarded": [
                "for=192.0.2.60;proto=http;by=203.0.113.43",
                "for=192.0.2.43, for=198.51.100.17",
            ]
        },
        type("", (), {"FORWARDED_SECRET": None}),
    ) == {
        "for": "192.0.2.43",
        "proto": "http",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:21:15.971956
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        'forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43']
    }
    config = {
        'FORWARDED_SECRET': 'secret'
    }
    assert parse_forwarded(headers, config) == {
        'for': '198.51.100.17',
        'proto': 'https',
        'by': '203.0.113.43'
    }

# Generated at 2022-06-18 05:21:22.086053
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:21:33.124150
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-host': 'host',
        'x-forwarded-proto': 'proto',
        'x-forwarded-port': 'port',
        'x-forwarded-path': 'path',
        'x-scheme': 'scheme'
    }
    config = {
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'REAL_IP_HEADER': 'x-real-ip'
    }
    assert parse_xforwarded(headers, config) == {'host': 'host', 'proto': 'proto', 'port': 'port', 'path': 'path'}

# Generated at 2022-06-18 05:21:43.444758
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": [
            "for=192.0.2.60; proto=http; by=203.0.113.43, for=192.0.2.43, for=198.51.100.17",
            "for=192.0.2.43, for=198.51.100.17",
        ]
    }
    config = {"FORWARDED_SECRET": "secret"}
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "http",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:21:52.954561
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return text(str(request.forwarded))

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(str(request.forwarded))

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_FOR_HEAD

# Generated at 2022-06-18 05:22:01.648510
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1, 192.168.0.2, 192.168.0.3",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:22:12.545397
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/path",
    }

# Generated at 2022-06-18 05:22:23.152055
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource',
        'x-forwarded-for': '192.0.2.43, 2001:db8:cafe::17'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 2
    }

# Generated at 2022-06-18 05:22:34.507739
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.PROXIES_COUNT = 1

    # Test for HTTP

# Generated at 2022-06-18 05:22:44.731120
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43",
        "Forwarded": "for=192.0.2.43, for=198.51.100.17",
    }
    config = {
        "FORWARDED_SECRET": "secret",
    }
    assert parse_forwarded(headers, config) == {
        "for": "198.51.100.17",
        "proto": "https",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:23:20.927808
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    config = Config()
    config.REAL_IP_HEADER = "X-Real-Ip"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.PROXIES_COUNT = 2
    headers = {
        "X-Real-Ip": "127.0.0.1",
        "X-Forwarded-For": "127.0.0.1, 127.0.0.2, 127.0.0.3",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Path": "/foo/bar",
        "X-Scheme": "https",
    }
    result = parse_xforwarded(headers, config)
   

# Generated at 2022-06-18 05:23:31.704704
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/test",
        "x-forwarded-for": "192.168.0.1, 192.168.0.2, 192.168.0.3",
    }
    config = {
        "REAL_IP_HEADER": "x-real-ip",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 3,
    }