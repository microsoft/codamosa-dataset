

# Generated at 2022-06-18 05:13:41.658256
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/resource',
        'x-forwarded-proto': 'https',
        'x-forwarded-for': '192.168.1.1, 192.168.1.2, 192.168.1.3'
    }
    config = {
        'REAL_IP_HEADER': 'x-real-ip',
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }

# Generated at 2022-06-18 05:13:48.018842
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    class TestConfig(Config):
        FORWARDED_SECRET = "secret"
        FORWARDED_FOR_HEADER = "X-Forwarded-For"
        REAL_IP_HEADER = "X-Real-IP"
        PROXIES_COUNT = 2

    class TestHttpProtocol(HttpProtocol):
        def __init__(self, *args, **kwargs):
            self.config = TestConfig()
            super().__init__(*args, **kwargs)


# Generated at 2022-06-18 05:13:59.014895
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource'
    }

# Generated at 2022-06-18 05:14:04.215349
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.0.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-proto': 'https',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/test'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }

# Generated at 2022-06-18 05:14:13.052946
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/",
        "x-scheme": "https",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:14:24.808788
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketCommonDisconnect

# Generated at 2022-06-18 05:14:37.146213
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43",
        "X-Forwarded-For": "192.0.2.43, 192.0.2.43",
        "X-Forwarded-Proto": "http, http",
        "X-Forwarded-Host": "example.com, example.com",
        "X-Forwarded-Port": "80, 80",
        "X-Forwarded-Path": "/foo/bar, /foo/bar",
    }

# Generated at 2022-06-18 05:14:49.819184
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "127.0.0.1",
    }
    config = type("Config", (object,), {"PROXIES_COUNT": 1})()
    assert parse_xforwarded(headers, config) == {
        "proto": "https",
        "host": "example.com",
        "port": 443,
        "path": "/path/to/resource",
        "for": "127.0.0.1",
    }

# Generated at 2022-06-18 05:15:02.824170
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:15:13.708526
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.request import Request
    from sanic.config import Config
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient
    from sanic.testing import _create_test_server
    from sanic.testing import _create_test_websocket_server

    app = Sanic("test_parse_forwarded")
    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "x-real-ip"
    config

# Generated at 2022-06-18 05:15:32.035879
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import text

    app = Sanic('test_parse_forwarded')

    @app.route('/')
    async def handler(request):
        return text(str(request.forwarded))

    config = Config()
    config.FORWARDED_SECRET = 'secret'

    request, response = app.test_client.get(
        '/',
        headers={
            'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=198.51.100.17;proto=https;by=203.0.113.43'
        }
    )


# Generated at 2022-06-18 05:15:41.258600
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    import asyncio
    import sys
    import os
    import time
    import json
    import unittest
    import socket
    import tempfile
    import threading
    import multiprocessing
    import subprocess
    import signal
    import contextlib
    import traceback


# Generated at 2022-06-18 05:15:52.330364
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/test',
    }

# Generated at 2022-06-18 05:16:02.546364
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path",
        "x-forwarded-for": "192.168.0.1, 192.168.0.2, 192.168.0.3",
    }
    config = {
        "REAL_IP_HEADER": "x-real-ip",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 2,
    }

# Generated at 2022-06-18 05:16:13.835621
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:16:24.222233
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '127.0.0.1',
        'x-forwarded-host': '127.0.0.1',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/test'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': ''
    }

# Generated at 2022-06-18 05:16:34.375355
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "::1")]) == {"for": "[::1]"}
    assert fwd_normalize([("for", "::1"), ("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "::1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "::1"), ("for", "::1")]) == {"for": "[::1]"}

# Generated at 2022-06-18 05:16:45.501820
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:80") == ("localhost", 80)
    assert parse_host("[::1]") == ("[::1]", None)
    assert parse_host("[::1]:80") == ("[::1]", 80)
    assert parse_host("[::1]:8080") == ("[::1]", 8080)
    assert parse_host("[::1]:65535") == ("[::1]", 65535)
    assert parse_host("[::1]:65536") == (None, None)
    assert parse_host("[::1]:-1") == (None, None)
    assert parse_host("[::1]:0") == ("[::1]", 0)

# Generated at 2022-06-18 05:16:56.289256
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/test",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": "",
        "PROXIES_COUNT": 1,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:17:05.904926
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedAbnormalClosure
    from sanic.websocket import WebSocketConnectionClosedTLSHandshake
    from sanic.websocket import WebSocket

# Generated at 2022-06-18 05:17:26.205338
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:17:34.426905
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:17:45.570131
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': '',
    }

# Generated at 2022-06-18 05:17:57.116740
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:18:05.203489
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("for", "9.10.11.12")]) == {"for": "1.2.3.4"}

# Generated at 2022-06-18 05:18:12.161407
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "secret")]) == {"for": "1.2.3.4", "by": "secret"}
    assert fwd_normalize([("by", "secret"), ("for", "1.2.3.4")]) == {"for": "1.2.3.4", "by": "secret"}

# Generated at 2022-06-18 05:18:20.640842
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/test",
    }

# Generated at 2022-06-18 05:18:31.578451
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-proto": "https",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": None,
    }

# Generated at 2022-06-18 05:18:43.961550
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("proto", "https")]) == {
        "for": "1.2.3.4",
        "proto": "https",
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("proto", "https"), ("port", "443")]) == {
        "for": "1.2.3.4",
        "proto": "https",
        "port": 443,
    }

# Generated at 2022-06-18 05:18:55.500666
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:19:18.118936
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"

    # Test with HTTP
    app = Sanic("test_parse_forwarded")
    app.config = config


# Generated at 2022-06-18 05:19:29.274780
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with a valid secret
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43, for=198.51.100.17;by=203.0.113.43;secret=test'}
    config = {'FORWARDED_SECRET': 'test'}
    assert parse_forwarded(headers, config) == {'for': '198.51.100.17', 'by': '203.0.113.43', 'proto': 'http'}

    # Test with an invalid secret

# Generated at 2022-06-18 05:19:40.125526
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43, for=198.51.100.17",
            "for=192.0.2.43, for=198.51.100.17",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret",
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "http",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:19:48.871141
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43",
            "for=192.0.2.43;proto=http;by=203.0.113.43,for=192.0.2.60;proto=http;by=203.0.113.43",
        ]
    }

# Generated at 2022-06-18 05:19:58.306938
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1, 192.168.1.2',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:20:10.048827
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '127.0.0.1, 192.168.0.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/test',
        'x-scheme': 'https',
    }

# Generated at 2022-06-18 05:20:16.520377
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43, for=198.51.100.17;by=203.0.113.43;secret=12345",
        "X-Forwarded-For": "192.0.2.43, 198.51.100.17",
        "X-Forwarded-Proto": "http",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Path": "/foo/bar",
    }

# Generated at 2022-06-18 05:20:25.761647
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret"}) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": "secret2"}) == None
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}, {"FORWARDED_SECRET": ""}) == None

# Generated at 2022-06-18 05:20:30.425611
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"}
    config = {"FORWARDED_SECRET": "secret"}
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.60",
        "proto": "http",
        "by": "203.0.113.43",
    }
    headers = {"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43"}
    config = {"FORWARDED_SECRET": "secret"}

# Generated at 2022-06-18 05:20:38.448443
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '127.0.0.1',
        'x-forwarded-host': 'localhost',
        'x-forwarded-port': '8080',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/test'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }

# Generated at 2022-06-18 05:21:10.017422
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:21:20.450928
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43",
        "Forwarded": "for=192.0.2.43, for=198.51.100.17",
    }
    config = {
        "FORWARDED_SECRET": "secret",
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "https",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:21:33.001720
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1, 192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 2,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:21:43.444603
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43",
            "for=192.0.2.43;proto=http;by=203.0.113.43,for=192.0.2.60;proto=http;by=203.0.113.43"
        ]
    }

# Generated at 2022-06-18 05:21:52.955544
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'https',
        'X-Forwarded-Proto': 'http',
    }
    config = {
        'REAL_IP_HEADER': None,
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'FORWARDED_SECRET': None,
    }
    result = parse_xforwarded(headers, config)

# Generated at 2022-06-18 05:22:00.978636
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "1.2.3.4",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = type("Config", (), {"PROXIES_COUNT": 1})
    assert parse_xforwarded(headers, config) == {
        "for": "1.2.3.4",
        "host": "example.com",
        "port": 443,
        "proto": "https",
        "path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:22:09.724575
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': ['secret=mysecret;by=192.168.0.1;for=192.168.0.2;proto=https;host=example.com;port=443;path=/foo/bar']}
    config = {'FORWARDED_SECRET': 'mysecret'}
    assert parse_forwarded(headers, config) == {'by': '192.168.0.1', 'for': '192.168.0.2', 'proto': 'https', 'host': 'example.com', 'port': 443, 'path': '/foo/bar'}


# Generated at 2022-06-18 05:22:20.884317
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'https',
        'x-forwarded-host': 'www.example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/test',
        'x-forwarded-for': '192.168.1.1, 192.168.1.2, 192.168.1.3'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for'
    }

# Generated at 2022-06-18 05:22:31.888240
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '8080',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/test',
        'X-Scheme': 'http',
    }

# Generated at 2022-06-18 05:22:38.892558
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-proto": "https",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "REAL_IP_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:23:21.811635
# Unit test for function parse_forwarded