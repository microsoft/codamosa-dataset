

# Generated at 2022-06-18 05:14:12.994068
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = {"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43,for=192.0.2.43;proto=http;by=203.0.113.43,for=198.51.100.17;proto=https;by=203.0.113.43"}
    options = parse_forwarded(headers, config)
    assert options == {"for": "192.0.2.43", "proto": "http", "by": "203.0.113.43"}

# Generated at 2022-06-18 05:14:24.764876
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:14:37.097564
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename=\"file.txt\"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt;') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename=file.txt; ') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:14:49.817374
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage

    config = Config()
    config.PROXIES_COUNT = 1
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_PROTOCOL_HEADER = "X-Forwarded-Proto"
    config.FORWARDED_HOST_HEADER = "X-Forwarded-Host"
    config.FORWARDED_PORT_HEADER = "X-Forwarded-Port"
    config.FORWARD

# Generated at 2022-06-18 05:14:56.096813
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}

# Generated at 2022-06-18 05:15:04.650794
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-18 05:15:14.673749
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.app import Sanic
    from sanic.log import logger
    from sanic.testing import SanicTestClient
    from sanic.utils import sanic_endpoint_test

    app = Sanic("test_parse_xforwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.headers.get("X-Forwarded-For"))


# Generated at 2022-06-18 05:15:26.727528
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
        "x-forwarded-for": "192.168.1.1",
    }
    config = {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": None,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:15:33.686374
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-proto": "https",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
    }

# Generated at 2022-06-18 05:15:41.196442
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43, for=192.0.2.43, for=198.51.100.17;by=203.0.113.43;proto=https, for=192.0.2.43;by=203.0.113.43;proto=https'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'proto': 'https', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:16:01.128167
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "localhost",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "http",
        "x-forwarded-path": "/",
    }

# Generated at 2022-06-18 05:16:13.564038
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommonScope
    from sanic.websocket import WebSocketCommonMessage

# Generated at 2022-06-18 05:16:24.023288
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.testing import HOST, PORT, SanicTestClient
    from sanic.utils import sanic_endpoint_test

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(request.forwarded)

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(request.forwarded)


# Generated at 2022-06-18 05:16:34.303049
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient
    from sanic.testing import create_server

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    async def handler(request):
        return text("OK")

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.PROXIES_COUNT = 1



# Generated at 2022-06-18 05:16:43.057004
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43,for=198.51.100.17;by=203.0.113.43;proto=https"
    }
    config = {
        "FORWARDED_SECRET": "secret"
    }
    assert parse_forwarded(headers, config) == {
        "for": "198.51.100.17",
        "by": "203.0.113.43",
        "proto": "https"
    }

# Generated at 2022-06-18 05:16:51.169454
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}


# Generated at 2022-06-18 05:17:01.252829
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1")]) == {
        "for": "127.0.0.1"
    }
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {
        "for": "127.0.0.2"
    }

# Generated at 2022-06-18 05:17:12.105939
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-proto": "https",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/path/to/resource",
    }
    config = {
        "REAL_IP_HEADER": "x-forwarded-for",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    }

# Generated at 2022-06-18 05:17:16.754366
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT

    config = Config()
    config.FORWARDED_SECRET = "secret"

    app = Sanic("test_parse_forwarded")
    app.config = config

    @app.route("/")
    async def handler(request):
        return text(str(request.forwarded))

    @app.listener("before_server_start")
    def init(app, loop):
        app.server = loop.run_until_complete(
            loop.create_server(
                lambda: HttpProtocol(app, request_class=Request), HOST, PORT
            )
        )


# Generated at 2022-06-18 05:17:27.760260
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("by", "127.0.0.1")]) == {
        "for": "127.0.0.1",
        "by": "127.0.0.1",
    }
    assert fwd_normalize([("for", "127.0.0.1"), ("by", "127.0.0.1"), ("by", "127.0.0.2")]) == {
        "for": "127.0.0.1",
        "by": "127.0.0.2",
    }
    assert fwd_normal

# Generated at 2022-06-18 05:17:45.137612
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT
    from sanic.testing import SanicTestClient
    from sanic.testing import create_server

    app = Sanic("test_parse_xforwarded")


# Generated at 2022-06-18 05:17:56.648744
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/test'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }

# Generated at 2022-06-18 05:18:04.940223
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'http',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-path': '/path',
        'x-forwarded-proto': 'https',
        'x-forwarded-for': '1.2.3.4, 5.6.7.8, 9.10.11.12'
    }
    config = {
        'REAL_IP_HEADER': '',
        'PROXIES_COUNT': 3,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': ''
    }

# Generated at 2022-06-18 05:18:15.965338
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import RequestParameters
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.testing import HOST, PORT
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    from sanic.views import CompositionView
    import asyncio
    import pytest
    import socket
    import time
    import os
    import sys
    import json
    import logging
    import re

    # Create a logger
    logger.setLevel(logging.DEBUG)
    logger.addHandler(logging.StreamHandler())

    # Create the application
    app = Sanic(__name__)

   

# Generated at 2022-06-18 05:18:27.385714
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '443',
        'X-Forwarded-Path': '/foo/bar',
        'X-Scheme': 'https',
        'X-Forwarded-Proto': 'https',
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'FORWARDED_SECRET': '',
    }

# Generated at 2022-06-18 05:18:39.851053
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import RequestParameters
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    protocol = HttpProtocol(None, config=config)

# Generated at 2022-06-18 05:18:52.119232
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/test'
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': 'secret'
    }

# Generated at 2022-06-18 05:19:01.898512
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("127.0.0.1") == ("127.0.0.1", None)
    assert parse_host("127.0.0.1:8000") == ("127.0.0.1", 8000)
    assert parse_host("[::1]") == ("::1", None)
    assert parse_host("[::1]:8000") == ("::1", 8000)
    assert parse_host("localhost") == ("localhost", None)
    assert parse_host("localhost:8000") == ("localhost", 8000)
    assert parse_host("example.com") == ("example.com", None)
    assert parse_host("example.com:8000") == ("example.com", 8000)
    assert parse_host("example.com:") == ("example.com", None)

# Generated at 2022-06-18 05:19:14.401689
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normal

# Generated at 2022-06-18 05:19:22.680471
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol

    config = Config()
    config.FORWARDED_SECRET = "secret"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.REAL_IP_HEADER = "X-Real-IP"
    config.PROXIES_COUNT = 1

    # Test HTTP

# Generated at 2022-06-18 05:19:38.576493
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:80") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:80") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"

# Generated at 2022-06-18 05:19:48.085773
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "192.168.1.1")]) == {"for": "192.168.1.1"}
    assert fwd_normalize([("for", "192.168.1.1:80")]) == {"for": "192.168.1.1"}
    assert fwd_normalize([("for", "192.168.1.1:80"), ("for", "192.168.1.2")]) == {
        "for": "192.168.1.2"
    }
    assert fwd_normalize([("for", "192.168.1.1"), ("for", "192.168.1.2")]) == {
        "for": "192.168.1.2"
    }

# Generated at 2022-06-18 05:19:57.823937
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Path": "/path/to/resource",
    }

# Generated at 2022-06-18 05:20:09.465669
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:20:16.317452
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '192.168.1.1, 192.168.1.2, 192.168.1.3',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'http',
    }

# Generated at 2022-06-18 05:20:25.045248
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:80") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:80") == "[::1]"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("_secret:80") == "_secret"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("unknown:80") == "unknown"

# Generated at 2022-06-18 05:20:35.666456
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/test',
        'x-scheme': 'https',
    }
    config = {
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'REAL_IP_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:20:43.731570
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = "secret"

# Generated at 2022-06-18 05:20:55.198947
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import RequestParameters

    config = Config()
    config.FORWARDED_SECRET = "secret"
    headers = RequestParameters()
    headers.add("forwarded", "for=192.0.2.43, for=\"[2001:db8:cafe::17]\"")
    headers.add("forwarded", "by=203.0.113.60;proto=http;host=example.com")
    headers.add("forwarded", "secret=secret, for=192.0.2.61, by=203.0.113.60")
    headers.add("forwarded", "for=192.0.2.43, for=\"[2001:db8:cafe::17]\"")

# Generated at 2022-06-18 05:21:07.618339
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/test",
        "x-forwarded-for": "192.168.0.1, 192.168.0.2, 192.168.0.3",
    }
    config = type("Config", (), {"PROXIES_COUNT": 1})
    assert parse_xforwarded(headers, config) == {
        "proto": "https",
        "host": "example.com",
        "port": 443,
        "path": "/test",
        "for": "192.168.0.3",
    }
    config.PROXIES_COUNT = 2
    assert parse_xforwarded

# Generated at 2022-06-18 05:21:34.083718
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.2.3.4")]) == {"for": "1.2.3.4"}
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8")]) == {
        "for": "1.2.3.4",
        "by": "5.6.7.8",
    }
    assert fwd_normalize([("for", "1.2.3.4"), ("by", "5.6.7.8"), ("by", "9.10.11.12")]) == {
        "for": "1.2.3.4",
        "by": "9.10.11.12",
    }

# Generated at 2022-06-18 05:21:43.558578
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.0.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/',
    }

# Generated at 2022-06-18 05:21:49.349578
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2")]) == {"for": "127.0.0.2"}
    assert fwd_normalize([("for", "127.0.0.1"), ("for", "127.0.0.2"), ("for", "127.0.0.3")]) == {"for": "127.0.0.3"}

# Generated at 2022-06-18 05:21:56.868629
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

# Generated at 2022-06-18 05:22:08.853270
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_SECRET = 'secret'
    headers = {'forwarded': 'for=192.0.2.43, for="[2001:db8:cafe::17]"; proto=https; by=203.0.113.60; secret=secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.43', 'proto': 'https', 'by': '203.0.113.60'}
    headers = {'forwarded': 'for=192.0.2.43, for="[2001:db8:cafe::17]"; proto=https; by=203.0.113.60; secret=wrong'}
    assert parse_forwarded(headers, config) == None

# Generated at 2022-06-18 05:22:14.970887
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketEvent
    from sanic.websocket import WebSocketEventType

# Generated at 2022-06-18 05:22:23.796743
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '127.0.0.1',
        'x-forwarded-host': '127.0.0.1',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }

# Generated at 2022-06-18 05:22:35.012866
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret'}
    assert parse_forwarded(headers, config) == {'for': '192.0.2.60', 'proto': 'http', 'by': '203.0.113.43'}

    headers = {'forwarded': 'for=192.0.2.60;proto=http;by=203.0.113.43'}
    config = {'FORWARDED_SECRET': 'secret1'}
    assert parse_forwarded(headers, config) == None


# Generated at 2022-06-18 05:22:46.799366
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT

    config = Config()
    config.PROXIES_COUNT = 1
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_PROTO_HEADER = "X-Forwarded-Proto"
    config.FORWARDED_HOST_HEADER = "X-Forwarded-Host"
    config.FORWARDED_PORT_HEADER = "X-Forwarded-Port"

# Generated at 2022-06-18 05:22:57.869983
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '127.0.0.1, 192.168.0.1',
        'X-Forwarded-Host': 'example.com',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Port': '443',
        'X-Forwarded-Path': '/path/to/resource',
        'X-Scheme': 'http',
    }
    config = {
        'REAL_IP_HEADER': 'X-Forwarded-For',
        'PROXIES_COUNT': 2,
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'FORWARDED_SECRET': '',
    }

# Generated at 2022-06-18 05:23:34.386006
# Unit test for function parse_forwarded

# Generated at 2022-06-18 05:23:45.408469
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.43,for=192.0.2.43,for=198.51.100.17",
            "for=192.0.2.43;proto=https;by=203.0.113.43",
            "for=192.0.2.43;proto=https;by=203.0.113.43",
        ]
    }
    config = {
        "FORWARDED_SECRET": "secret"
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "https",
        "by": "203.0.113.43",
    }

# Generated at 2022-06-18 05:23:53.687929
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '80',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/path/to/resource',
    }
    config = {
        'REAL_IP_HEADER': 'x-forwarded-for',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }
    result = parse_xforwarded(headers, config)