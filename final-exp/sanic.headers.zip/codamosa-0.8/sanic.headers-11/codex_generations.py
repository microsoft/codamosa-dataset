

# Generated at 2022-06-12 08:44:46.820612
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("192.168.0.1") == "192.168.0.1"
    assert fwd_normalize_address("_secret") == "_secret"
    assert fwd_normalize_address("unknown") is None


# Generated at 2022-06-12 08:44:55.273768
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    config = Config()

    # Normal values
    h = {"forwarded": "for=111.222.111.222;by=_secret;by=_secret2"}
    assert parse_forwarded(h, config) == {"for": "111.222.111.222"}
    h = {
        "forwarded": "for=111.222.111.222;by=_secret2,for=111.222.111.222;by=_secret"
    }
    assert parse_forwarded(h, config) == {"for": "111.222.111.222"}
    h = {"forwarded": "for=111.222.111.222;by=_secret,for=111.222.111.222"}

# Generated at 2022-06-12 08:45:06.152045
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    """Function test parse_xforwarded"""
    headers = {'X-Forwarded-Host': 'www.google.com',
               'X-Forwarded-Port': '443',
               'X-Forwarded-Proto': 'https',
               'X-Forwarded-Path': '/search',
               'X-Real-Ip': '199.100.100.100'}
    config = {'REAL_IP_HEADER': 'X-Real-Ip',
              'PROXIES_COUNT': 1,
              'FORWARDED_FOR_HEADER': 'X-Forwarded-For'}

# Generated at 2022-06-12 08:45:14.051573
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import DEFAULT_CONFIG
    from sanic.request import Request
    from sanic.views import HTTPMethodView

    config = DEFAULT_CONFIG.copy()
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.PROXIES_COUNT = 2

    class Proxy(HTTPMethodView):
        def get(self, request):
            print(request.headers)
            print(request.port)
            print(request.host)
            print(request.ip)
            print(request.protocol)
            return request

    app = Sanic('sanic')
    app.config.from_object(config)

# Generated at 2022-06-12 08:45:22.235860
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    import logging

    logging.basicConfig(level=logging.DEBUG)
    headers = {
        "X-Real-IP": '192.0.2.1',
        "X-Scheme": 'https',
        "X-Forwarded-Host": 'server.example',
        "X-Forwarded-Path": '/path/to/site',
        "X-Forwarded-Port": '80',
        "X-Forwarded-Proto": 'http',
    }
    expected = {
        "proto": "http",
        "host": "server.example",
        "port": 80,
        "path": "/path/to/site"
    }
    output = parse_xforwarded(headers, {})
    logging.debug(f"output: {output}")
    assert output == expected

# Generated at 2022-06-12 08:45:28.263038
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config

    config = Config()
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    config.REAL_IP_HEADER = "x-real-ip"
    config.PROXIES_COUNT = 2
    config.FORWARDED_SECRET = "abc123"

    from sanic.exceptions import InvalidUsage
    from http.cookies import SimpleCookie

    class Headers:
        def __init__(self):
            self.c = SimpleCookie()

        def __getitem__(self, item):
            return self.c[item].value

        def get(self, item):
            return self.c[item].value

        def getall(self, item):
            return [self.c[item].value]


# Generated at 2022-06-12 08:45:31.523803
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": ["for=_secret, for=_secret"]}, {}) is None
    assert parse_forwarded({"forwarded": ["for=_secret, for=_secret"]}, {'FORWARDED_SECRET': "_secret"}) is not None


# Generated at 2022-06-12 08:45:40.847403
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    config = {'FORWARDED_FOR_HEADER': "X-Forwarded-For",
              'REAL_IP_HEADER': "X-Real-IP",
              'FORWARDED_FOR_HEADERS': ["X-Forwarded-For", "X-Forwared"],
              'PROXIES_COUNT': 1}

    headers = {'X-Forwarded-For': "192.168.0.1, 10.10.10.10, 172.16.0.1",
               'X-Forwarded-Host': "www.example.com",
               'X-Forwarded-Port': "443",
               'X-Forwarded-Proto': "https",
               'X-Forwarded-Path': "abc"}
    addr, fwd = parse_xforwarded(headers, config)

# Generated at 2022-06-12 08:45:46.015854
# Unit test for function parse_content_header
def test_parse_content_header():
    header = 'text/html; charset="utf-8"'
    value, options = parse_content_header(header)
    #print([options])
    assert value == 'text/html'
    assert [('charset', 'utf-8')] == list(options.items())


# Generated at 2022-06-12 08:45:57.739847
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from collections import namedtuple
    import urllib
    from sanic.request import Request

    # TODO: Need to update test case
    # fwd = "secret=%s; by=%s; for=%s; proto=https; host=%s; port=%s"
    fwd = "secret=%s; by=%s; for=%s; proto=https; host=%s; port=%s"
    fwd = fwd % (
        urllib.quote("123456"),
        urllib.quote("https://example.com"),
        urllib.quote("192.168.2.1"),
        urllib.quote("example.com"),
        urllib.quote("80"),
    )
    Case = namedtuple("Case", ["headers", "config", "expected"])

# Generated at 2022-06-12 08:46:14.729191
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    def get_xforwarded(xforwarded_proto='https', x_real_ip='1.1.1.1',
                       forwarded_for='2.2.2.2,3.3.3.3,4.4.4.4,5.5.5.5'):
        return {
            'X-Real-Ip': x_real_ip,
            'Forwarded': forwarded_for,
            'X-Forwarded-Proto': xforwarded_proto
        }
    assert parse_xforwarded(get_xforwarded(), None) == {
        'for': '2.2.2.2',
        'proto': 'https'
    }



# Generated at 2022-06-12 08:46:23.699364
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-for": "127.0.0.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "80",
    }
    config = type("Config", (), {"PROXIES_COUNT": 1})()
    forward_options = parse_xforwarded(headers, config)
    assert forward_options == {
        "for": "127.0.0.1",
        "proto": "https",
        "host": "example.com",
        "port": 80,
    }

if __name__ == "__main__":
    test_parse_xforwarded()

# Generated at 2022-06-12 08:46:34.445015
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:46:45.222709
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("_192.168.1.1") == "_192.168.1.1"
    assert fwd_normalize_address("192.168.1.1") == "192.168.1.1"
    assert fwd_normalize_address("192.168.1.1:3128") == "192.168.1.1:3128"
    assert fwd_normalize_address("192.168.1.1:80") == "192.168.1.1:80"
    assert fwd_normalize_address("fe80::74b:5a55:95a5:2b59") == "[fe80::74b:5a55:95a5:2b59]"

# Generated at 2022-06-12 08:46:51.660830
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = [
        "By=_secret;For=_proxy1,For=_proxy2;Proto=_proto;Host=_host",
        "By=_secret,For=_proxy3,Proto=_proto2;Host=_host;",
    ]
    config = type('config', (), {'FORWARDED_SECRET': '_secret'})()
    result = parse_forwarded(headers, config)
    assert result["for"] == "_proxy1"

# Generated at 2022-06-12 08:47:00.341109
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    assert parse_xforwarded({"x-real-ip": "127.0.0.1"}, request.Config()) == {
        "for": "127.0.0.1"
    }
    assert parse_xforwarded({"x-forwarded-for": "127.0.0.1"}, request.Config()) == {
        "for": "127.0.0.1"
    }
    assert parse_xforwarded(
        {"x-forwarded-for": "127.0.0.1, 127.0.0.2"}, request.Config()
    ) == {"for": "127.0.0.1"}

# Generated at 2022-06-12 08:47:12.157575
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from collections import OrderedDict
    from .config import Config, HashedRemoteAddress, RemoteAddress


# Generated at 2022-06-12 08:47:18.820322
# Unit test for function parse_forwarded
def test_parse_forwarded():
    result = parse_forwarded('secret; by="secret"; proto=https, host=example.org; for=192.0.2.43')
    assert result['secret'] == 'secret'
    assert result['host'] == 'example.org'
    assert result['for'] == 'for="192.0.2.43"'

    result = parse_forwarded('secret=1234; by="secret"; proto=https, host=example.org; for=192.0.2.43')
    assert result == None

# Generated at 2022-06-12 08:47:25.554023
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    """Unit test for function parse_xforwarded"""
    # pylint: disable=redefined-outer-name
    class MockHeaders:
        """MockHeaders class"""

        def __init__(self, header):
            self._header = header

        def get(self, name):
            """Get header"""
            return self._header

        def getall(self, name):
            """Get header"""
            return [self._header]

    class MockConfig:
        """MockConfig class"""
        REAL_IP_HEADER = "X-Real-IP"
        PROXIES_COUNT = 1
        FORWARDED_FOR_HEADER = "X-Forwarded-For"

    assert parse_xforwarded(MockHeaders(None), MockConfig()) is None
    config = MockConfig()
    headers = MockHead

# Generated at 2022-06-12 08:47:33.231945
# Unit test for function parse_host
def test_parse_host():
    assert ("abcdefghijklmnopqrstuvwxyz.abcdefghijklmnopqrstuvwxyz.abcdefghijklmnopqrstuvwxyz.abcde",
            80) == parse_host("abcdefghijklmnopqrstuvwxyz.abcdefghijklmnopqrstuvwxyz.abcdefghijklmnopqrstuvwxyz.abcde")
    assert ("[1234::5678]", 80) == parse_host("[1234::5678]")
    assert ("[]", 80) == parse_host("[]")
    assert (None, 80) == parse_host("")
    assert (None, 80) == parse_host("[]_")
    assert (None, 80) == parse_host("[]_:80")



# Generated at 2022-06-12 08:47:43.457933
# Unit test for function parse_content_header
def test_parse_content_header():
    
    result = parse_content_header("form-data; name=upload; filename=\"file.txt\"")

    assert result == ("form-data", {'name': 'upload', 'filename': 'file.txt'})



# Generated at 2022-06-12 08:47:53.904054
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.exceptions import InvalidUsage
    from sanic.config import Config
    from sanic.response import redirect
    from sanic import Sanic
    from sanic.testing import HttpTestClient
    app = Sanic("test_client_app")
    @app.route("/")
    @app.route("/<name>")
    async def index(request, name=None):
        return redirect("http://example.com")
    
    client = HttpTestClient(app, server_kwargs={'access_log': False})
    headers={}
    headers['x-scheme'] = "https"
    headers['x-forwarded-host'] = "192.168.0.1"
    headers['x-forwarded-port'] = "80"
    headers['x-forwarded-path'] = "/index"

# Generated at 2022-06-12 08:48:03.252544
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import random

    config = object()
    secret = random.randint(10000, 99999)
    setattr(config, 'FORWARDED_SECRET', secret)
    header_for = 'for=10.0.0.9'
    header_by = 'by=10.0.0.9'
    header_secret = str(secret)
    header = header_for + ';' + header_by + ';' + header_secret
    headers = {'forwarded': [header]}
    d = parse_forwarded(headers, config)
    assert d == {'for': '10.0.0.9', 'by': '10.0.0.9'}


if __name__ == '__main__':
    test_parse_forwarded()

# Generated at 2022-06-12 08:48:14.516193
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:48:24.320710
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    class FakeHeaders(object):
        def __init__(self, headers: HeaderIterable):
            self.headers = dict(headers)

        def get(self, header: str) -> Any:
            return self.headers.get(header)

        def getall(self, header: str) -> List[Any]:
            return self.headers.get(header)

    class FakeConfig(object):
        def __init__(self):
            self.REAL_IP_HEADER = 'X-Real-Ip'
            self.PROXIES_COUNT = 3
            self.FORWARDED_FOR_HEADER = 'X-Forwarded-For'

    # Case 1: A minimal case
    # XXX: params:

# Generated at 2022-06-12 08:48:34.165172
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-Host': 'local.test.sanic.com',
        'X-Forwarded-For': '192.168.115.203, 10.0.0.1, localhost',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/test_path'
    }
    config = {
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For',
        'REAL_IP_HEADER': '',
        'PROXIES_COUNT': 2
    }
    options = parse_xforwarded(headers, config)
    assert options['host'] == 'local.test.sanic.com'
    assert options['for'] == '192.168.115.203'
    assert options['proto'] == 'https'

# Generated at 2022-06-12 08:48:44.221946
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("www.example.com:8080") == ("www.example.com", 8080)
    assert parse_host("127.0.0.1") == ("127.0.0.1", None)
    assert parse_host("127.0.0.1:") == ("127.0.0.1", None)
    assert parse_host("[::1]") == ("::1", None)
    assert parse_host("[::1]:") == ("::1", None)
    assert parse_host("[::1]:8080") == ("::1", 8080)
    assert parse_host("127.0.0.1:80") == ("127.0.0.1", 80)
    assert parse_host("www.example.com") == ("www.example.com", None)

# Generated at 2022-06-12 08:48:45.679598
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    print(parse_xforwarded())
    print("end")

# Generated at 2022-06-12 08:48:51.300272
# Unit test for function parse_forwarded
def test_parse_forwarded():

    print(parse_forwarded('"abc"', {}))
    assert parse_forwarded(['"abc"'], {'FORWARDED_SECRET': 'abc'})
    assert parse_forwarded(['"abc","def"'], {'FORWARDED_SECRET': 'def'})

    assert parse_forwarded(['"abc","def","ghi"'], {'FORWARDED_SECRET': 'def'})

# Generated at 2022-06-12 08:49:01.228929
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    # Tests for config.FORWARDED_FOR_HEADER, config.REAL_IP_HEADER
    headers = {}
    config = type("FakeConfig", (object,), {})
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.FORWARDED_PROTO_HEADER = "X-Forwarded-Proto"
    config.FORWARDED_HOST_HEADER = "X-Forwarded-Host"
    config.FORWARDED_PORT_HEADER = "X-Forwarded-Port"
    config.FORWARDED_PATH_HEADER = "X-Forwarded-Path"
    config.REAL_IP_HEADER = "X-Real-IP"
    config.PROXIES_COUNT = 1
    # Custom check with X-Forwarded-For and X-Real

# Generated at 2022-06-12 08:49:12.841067
# Unit test for function parse_forwarded
def test_parse_forwarded():
    """Test parse_forwarded"""
    headers = {"forwarded": "for=1.2.3.4, secret=foo"}
    config = {"FORWARDED_SECRET": "foo"}
    assert parse_forwarded(headers, config) == {"for": "1.2.3.4"}

# Generated at 2022-06-12 08:49:17.940972
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"Forwarded": "By=zdd; for=127.0.0.1; secret=token, For=\"[::1]\""}
    config = {"FORWARDED_SECRET": "token"}
    assert parse_forwarded(headers, config) == {'by': 'zdd', 'secret': 'token', 'for': '127.0.0.1'}

# Generated at 2022-06-12 08:49:20.129308
# Unit test for function parse_forwarded
def test_parse_forwarded():
    print(parse_forwarded({"FORWARDED": "for=_my-addr, secret=my-secret"}, None))


# Generated at 2022-06-12 08:49:28.113832
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    def test(c: Dict, given: Dict, expected: Dict):
        g = {}
        for k, v in given.items():
            g[f"x-forwarded-{k}"] = v
        assert parse_xforwarded(g, c) == expected

    test(
        {"REAL_IP_HEADER": "real", "PROXIES_COUNT": 1, "FORWARDED_FOR_HEADER": "fwd"},
        {"real": "1.2.3.4", "scheme": "https", "host": "example.com", "port": "999", "path": "/path"},
        {"for": "1.2.3.4", "proto": "https", "host": "example.com", "port": 999, "path": "/path"},
    )

# Generated at 2022-06-12 08:49:36.905038
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    config = type('Config', (object,), {
        'PROXIES_COUNT': 1,
        'REAL_IP_HEADER': 'x-real-ip',
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_HOST_HEADER': 'x-forwarded-host',
        'FORWARDED_PORT_HEADER': 'x-forwarded-port',
        'FORWARDED_PROTO_HEADER': 'x-forwarded-proto',
        'FORWARDED_PATH_HEADER': 'x-forwarded-path'
    })
    config.REAL_IP_HEADER = 'x-real-ip'
    config.FORWARDED_FOR_HEADER =  'x-forwarded-for'


# Generated at 2022-06-12 08:49:47.543028
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "www.example.com",
        "x-forwarded-port": "443",
    }
    config = {
        "PROXIES_COUNT": 1,
        "REAL_IP_HEADER": "x-real-ip",
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_HOST_HEADER": "x-forwarded-host",
        "FORWARDED_PROTO_HEADER": "x-forwarded-proto",
        "FORWARDED_PORT_HEADER": "x-forwarded-port",
    }

# Generated at 2022-06-12 08:49:58.092097
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {b"x-forwarded-for": b"1.2.3.5", "x-scheme": "123"}
    # The headers variable is not a dictionary!
    config = {b"PROXIES_COUNT": 1}
    ret = parse_xforwarded(headers, config)
    assert ret['for'] == b'1.2.3.5'
    assert ret['host'] == 123
    assert ret['port'] == None
    assert ret['path'] == None

    # Test for port
    headers = {"x-forwarded-port": "1234"}
    config = {b"PROXIES_COUNT": 1}
    ret = parse_xforwarded(headers, config)
    assert ret['for'] == None
    assert ret['host'] == None
    assert ret['port'] == 1234


# Generated at 2022-06-12 08:50:04.810870
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic import Sanic
    from sanic.response import html


    app = Sanic(__name__)

    @app.route("/")
    async def root(request):
        return html("Forwarded: {!s}".format(parse_xforwarded(request.headers, app.config)))


    if __name__ == "__main__":
        app.run(host= "127.0.0.1", port=8000)

# Generated at 2022-06-12 08:50:14.567178
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert dict(fwd_normalize([])) == {}
    assert dict(fwd_normalize([("for", "1.2.3.4")])) == {"for": "1.2.3.4"}
    assert dict(fwd_normalize([("for", "1.2.3.4"), ("by", "secret")])) == {
        "for": "1.2.3.4",
        "by": "secret",
    }
    assert dict(
        fwd_normalize([("for", "1.2.3.4"), ("for", "5.6.7.8"), ("by", "secret")])
    ) == {"for": "1.2.3.4", "by": "secret"}

# Generated at 2022-06-12 08:50:18.305988
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "http",
        "x-forwarded-host": "localhost:8080",
        "x-forwarded-path": "hello1",
        "x-forwarded-port": "8888"
    }
    print(parse_xforwarded(headers, None))

test_parse_xforwarded()

# Generated at 2022-06-12 08:50:33.808922
# Unit test for function parse_forwarded
def test_parse_forwarded():
    hdr = "for=\"_gazonk\"; proto=\"https\", for=192.0.2.60; by=203.0.113.43"
    config = lambda: None
    config.FORWARDED_SECRET = "_gazonk"
    config.PROXIES_COUNT = None
    assert parse_forwarded(hdr, config) == {
        "for": "_gazonk",
        "proto": "https",
        "by": "192.0.2.60",
    }
    config.FORWARDED_SECRET = "192.0.2.60"
    assert parse_forwarded(hdr, config) == {
        "for": "192.0.2.60",
        "proto": "https",
        "by": "203.0.113.43",
    }


# Generated at 2022-06-12 08:50:37.699568
# Unit test for function parse_forwarded
def test_parse_forwarded():

    headers = {'forwarded':['for=127.0.0.1;by=127.0.0.1;host=host1.com;port=8080']}
    print(parse_forwarded(headers,'secret'))

# Generated at 2022-06-12 08:50:44.859135
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.request import Headers

    headers = Headers(
        {
            "x-forwarded-for": "127.0.0.1, localhost",
            "x-forwarded-host": "www.example.com",
            "x-forwarded-port": "443",
            "x-forwarded-proto": "https",
        }
    )

    print(parse_xforwarded(headers, {"PROXIES_COUNT": 2}))
    # {'for': '127.0.0.1', 'host': 'www.example.com', 'port': 443,
    #  'proto': 'https'}


# Nested tests for function parse_forwarded
if __name__ == "__main__":
    from sanic.request import Headers


# Generated at 2022-06-12 08:50:54.053492
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    # Unit test for function parse_xforwarded
    class Request:
        def __init__(self, headers, config=None):
            if config is None:
                config = {}
            self.headers = headers.copy()
            for h, v in config.items():
                setattr(self, h, v)

        def get(self, name, default=None):
            return self.headers.get(name, default)

        def getall(self, name: str, default: list = None) -> List[str]:
            return self.headers.getall(name, default)


# Generated at 2022-06-12 08:51:06.159916
# Unit test for function parse_forwarded
def test_parse_forwarded():
    print(parse_forwarded('for=10.1.1.1; by=_pe4rg4; host=example.com', 'peter'))
    print(parse_forwarded('for="10.1.1.1"; by=_pe4rg4; host=example.com', 'peter'))
    print(parse_forwarded('for="192.168.1.1"; by=_pe4rg4; host=example.com', 'peter'))
    print(parse_forwarded('for="192.168.1.1"; by=_pe4rg4; host=example.com; proto=http', 'peter'))

# Generated at 2022-06-12 08:51:16.965037
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([] ) == {}
    assert fwd_normalize( [ ("for", "a.b") ] ) == { "for": "a.b" }
    assert fwd_normalize( [ ("for", "a.b"), ("by", "c.d"), ("proto", "http") ] ) == {"by": "c.d", "for": "a.b", "proto": "http"}
    assert fwd_normalize( [ ("for", "a.b"), ("by", "c.d"), ("proto", "http"), ("path", "/a/b") ] ) == {"by": "c.d", "for": "a.b", "path": "/a/b", "proto": "http"}

# Generated at 2022-06-12 08:51:28.037239
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from . import helpers

    # Create empty header
    headers = helpers.SimpleNamespace()

    # Create Sanic config
    config = helpers.SimpleNamespace()

    # Test forwarded header
    headers.getall = lambda x: ["by=_forward1; for=192.0.2.60; proto=https; host=www.example.com; x-anything=blabla"]
    config.FORWARDED_SECRET = "_forward1"
    config.REAL_IP_HEADER = None
    config.PROXIES_COUNT = 1
    config.FORWARDED_FOR_HEADER = "x-forwarded-for"
    result = parse_forwarded(headers, config)
    assert result["by"] == "_forward1"
    assert result["for"] == "192.0.2.60"

# Generated at 2022-06-12 08:51:37.552543
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.server import HttpProtocol
    import io
    import pytest

    config = Config()
    config.REAL_IP_HEADER = None
    config.FORWARDED_FOR_HEADER = None
    config.PROXIES_COUNT = None

# Generated at 2022-06-12 08:51:44.339332
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers_list1 = [
        "for=\"_gazonk\"",
        "by=_foobar",
        "proto=http",
        "host=_foobar",
        "port=443",
        "path=example\\"
    ]
    headers = "; ".join(headers_list1)
    result = parse_forwarded(headers)
    print(result)
    assert result["for"] == "_gazonk"
    assert result["by"] == "_foobar"
    assert result["proto"] == "http"
    assert result["host"] == "_foobar"
    assert result["port"] == 443
    assert result["path"] == "example\\"


# Generated at 2022-06-12 08:51:54.930679
# Unit test for function parse_xforwarded

# Generated at 2022-06-12 08:52:09.231168
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = "Forwarded: for=192.0.2.60;proto=http;by=203.0.113.43"
    assert parse_forwarded(headers) == {
        "for": "192.0.2.60",
        "proto": "http"
    }
    headers = "Forwarded: for=192.0.2.43, for=198.51.100.17"
    assert parse_forwarded(headers) == {
        "for": "192.0.2.43"
    }
    headers = "Forwarded: for=192.0.2.43, for=198.51.100.17;by=203.0.113.60"

# Generated at 2022-06-12 08:52:18.261068
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.response import text

    from sanic import Sanic
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT

    app = Sanic("test_parse_xforwarded")

    @app.get("/raw")
    async def raw(request):
        return text(str(request.remote_addr))

    @app.get("/proxy")
    async def proxy(request):
        return text(str(request.ip))

    @app.get("/ftp")
    async def ftp(request):
        return text(str(request.ip))


# Generated at 2022-06-12 08:52:26.539991
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.request import _request_ctx_stack, Request

    with _request_ctx_stack.top:
        req = Request({
            "type": "http",
            "headers": {
                "Forwarded": "for=\"\", for=\"192.168.0.10\", for=\"192.168.0.1\"",
                "Host": "testserver.org"
            }
        }, None)

        assert parse_forwarded(req.headers, req.app.config) == {
            "for": "192.168.0.1",
            "host": "testserver.org"
        }


# Generated at 2022-06-12 08:52:34.681601
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    """解析xforwarded的参数"""
    headers = {
        "X-Forwarded-Host":"www.google.com",
        "X-Forwarded-Path": "/v1/book/",
        "X-Scheme":"https",
        "X-Forwarded-Port":"443",
    }
    config = type("config", (object,), {})()
    config.PROXIES_COUNT = 3
    config.FORWARDED_FOR_HEADER="X-Forwarded-For"
    config.REAL_IP_HEADER="X-Real-Ip"
    config.FORWARDED_SECRET="test"
    options = parse_xforwarded(headers, config)
    print(options)
    assert options is not None

# Generated at 2022-06-12 08:52:43.606148
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Sanic receives the forwarded strings in the form of a list
    # (headers are case insensitive, but we use lower case)
    headers = {'forwarded': ['"by=\\"_bob, for=\\"192.0.2.60\\""; proto=https; host=example.com; foo=bar,for="192.0.2.43",for=192.0.2.61, by=_alice',
                             'for="r2d2\"c3po\""',
                             'by=\\"_bob, for=\\"192.0.2.60\\""; proto=https; host=example.com; foo=bar']}
    config = {'FORWARDED_SECRET':"_bob"}

    # Expecting a normalized (all lower case) and de-quoted result

# Generated at 2022-06-12 08:52:51.578659
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43;host=example.com",
    }
    assert parse_forwarded(headers, "") == {
        "for": "192.0.2.60",
        "proto": "http",
        "by": "203.0.113.43",
        "host": "example.com",
    }
    headers["Forwarded"] += ", for=192.0.2.61"
    assert parse_forwarded(headers, "") == {
        "for": "192.0.2.60",
        "proto": "http",
        "by": "203.0.113.43",
        "host": "example.com",
    }
    headers["Forwarded"]

# Generated at 2022-06-12 08:52:57.485237
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = { 'forwarded': [ 'for=192.0.2.60; '
                               'proto=http; '
                               'by=203.0.113.43; '
                               'secret=abc123' ] }
    assert parse_forwarded(headers) == {
        'for': '192.0.2.60',
        'by': '203.0.113.43',
        'proto': 'http',
        'secret': 'abc123'
    }

# Generated at 2022-06-12 08:53:08.370071
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize({"by": "12.34.56.78"}) == {"by": "12.34.56.78"}
    assert fwd_normalize({"by": "12.34.56.78".upper()}) == {"by": "12.34.56.78"}
    assert fwd_normalize({"by": "12.34.56.78.90"}) == {"by": "12.34.56.78.90"}
    assert fwd_normalize({"by": "12.34.56.78".upper(), "proto": "http"}) == {
        "by": "12.34.56.78",
        "proto": "http",
    }

# Generated at 2022-06-12 08:53:16.567068
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:53:26.761762
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from collections import UserDict
    from sanic.config import Config

    class Header(UserDict):

        def get(self, name: str, default: Optional[str] = None):
            return self.data.get(name, default)

        def getall(self, name: str, default: Optional[str] = None):
            return self.data.getall(name, default)

    class Headers(Header):

        def getall(self, name: str):
            return self.data.getall(name)


# Generated at 2022-06-12 08:53:48.429584
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:53:58.346253
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from unittest import TestCase
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse

    class TestRequest(TestCase):
        def setUp(self):
            self.config = Config(PROXIES_COUNT=3)

        def test_parse_xforwarded_nothing(self):
            req = Request(
                "GET",
                "/",
                headers={},
                version=11,
                app=None,
                config=self.config,
                server_state=None,
            )
            self.assertEqual(req.xforwarded_options, None)


# Generated at 2022-06-12 08:54:01.632011
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.request import Request
    request = Request(None, None, None, None, None, None, None, None)
    request.headers = {
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-For": "1.2.3.4"
    }



# Generated at 2022-06-12 08:54:12.299340
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    import unittest
    from unittest import TestCase

    class RequestTestCase(TestCase):

        def test_parse_xforwarded_no_proxies_count(self):

            from sanic.request import Request

            request = Request(
                b"GET",
                "/",
                protocol=b"HTTP/1.1",
                headers={
                    b"Host": b"localhost:80",
                    b"X-Forwarded-For": b"192.168.1.1",
                },
            )

            request_xforwarded = parse_xforwarded(request.headers, request.config)
            self.assertEqual(request_xforwarded, None)

        def test_parse_xforwarded_proxies_count(self):

            from sanic.request import Request


# Generated at 2022-06-12 08:54:18.207390
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'http',
        'x-forwarded-host': '127.0.0.1:8081',
        'x-forwarded-for': '192.168.1.1',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/static/registry'
    }
    ret = parse_xforwarded(headers)
    print(ret)


if __name__ == '__main__':
    test_parse_xforwarded()

# Generated at 2022-06-12 08:54:26.903289
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    assert parse_xforwarded({"X-Forwarded-For": "192.168.1.1"}, config) == {"for": "192.168.1.1"}
    assert parse_xforwarded({"X-Forwarded-For": "192.168.1.1, 192.168.1.2"}, config) == {"for": "192.168.1.2"}
    assert parse_xforwarded({"X-Forwarded-For": "192.168.1.1", "X-Forwarded-Host": "myserver.test"}, config) == {"for": "192.168.1.1", "host": "myserver.test"}

# Generated at 2022-06-12 08:54:35.876810
# Unit test for function parse_forwarded
def test_parse_forwarded():
    PROXIES_COUNT = 1
    REAL_IP_HEADER = "X-Forwarded-For"
    FORWARDED_FOR_HEADER = "X-Forwarded-For"
    FORWARDED_SECRET = "s3cr3t"
    FORWARDED_PROTO_HEADER = "X-Forwarded-Proto"
    FORWARDED_HOST_HEADER = "X-Forwarded-Host"
    FORWARDED_PORT_HEADER = "X-Forwarded-Port"
    FORWARDED_PATH_HEADER = "X-Forwarded-Path"
