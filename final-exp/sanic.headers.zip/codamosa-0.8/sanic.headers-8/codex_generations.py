

# Generated at 2022-06-12 08:44:50.533309
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=192.0.2.60;proto=https;,for=192.0.2.43,' +
                            'for=198.51.100.17,for=192.0.2.43;by=192.0.2.16,' +
                            'for=192.0.2.43;by=192.0.2.16;secret=secret'}
    config = {'FORWARDED_SECRET': 'secret', 'REAL_IP_HEADER': '',
              'PROXIES_COUNT': '', 'FORWARDED_FOR_HEADER': ''}
    options = parse_forwarded(headers, config)
    assert options is not None
    assert options['for'] == '192.0.2.43'

# Generated at 2022-06-12 08:44:56.613190
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("127.0.0.1:80") == "127.0.0.1"
    assert fwd_normalize_address("abc.def") == "abc.def"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("[::1]:80") == "[::1]"
    assert fwd_normalize_address("[::1]%eth0") == "[::1]%eth0"


# Generated at 2022-06-12 08:45:06.966892
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    # getall() is not implemented
    class FakeRequest:
        def __init__(self, headers):
            self.headers = headers

        def getall(self, header):
            if isinstance(self.headers[header], str):
                return [self.headers[header]]
            return self.headers[header]

        def get(self, header):
            return self.headers[header]

    class Config:
        PROXIES_COUNT = 1
        REAL_IP_HEADER = None
        FORWARDED_FOR_HEADER = "x-forwarded-for"

    config = Config()

    # Testing with only FORWARDED_FOR_HEADER with multiple headers

# Generated at 2022-06-12 08:45:15.156461
# Unit test for function parse_forwarded
def test_parse_forwarded():
    test_header = "for=203.0.113.42; proto=https, for=\"[2001:db8:cafe::17]\"; by=203.0.113.43; secret, for=192.0.2.43, for=198.51.100.17; by=192.0.2.61;proto=http, for=203.0.113.43; by=192.0.2.63, for=192.0.2.44, for=198.51.100.18; by=192.0.2.62;proto=http, for=203.0.113.44; by=192.0.2.64"
    # Test case 1: should return value
    ret = parse_forwarded(test_header, '')
    assert ret is not None
    # Test case 2: should raise error

# Generated at 2022-06-12 08:45:26.343455
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("2001:0db8:85a3:0000:0000:8a2e:0370:7334") == "[2001:0db8:85a3:0000:0000:8a2e:0370:7334]"
    assert fwd_normalize_address("_secret-value") == "_secret-value"
    assert fwd_normalize_address("2001:0DB8:85A3:0000:0000:8A2E:0370:7334") == "[2001:0db8:85a3:0000:0000:8a2e:0370:7334]"
    assert fwd_normalize_address("_secret-value") == "_secret-value"
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"


# Generated at 2022-06-12 08:45:35.513869
# Unit test for function parse_forwarded
def test_parse_forwarded():

    # Quoted pairs are "special" in Python, that's why
    # we need to double them up here.

    http_header = 'for=_proxy1;by=_proxy2;proto=_https;'\
    + 'host=_proxy3;port=_3128;secret="ab\\"c";for=_proxy4, '\
    + 'for=_proxy5; by=_proxy6;proto=_https;host=_proxy7;'\
    + 'port=_3128;secret="ab\\"c"'

    expected_output = {
        "for": "_proxy5",
        "by": "_proxy6",
        "proto": "_https",
        "host": "_proxy7",
        "port": _3128,
        "secret": "ab\"c"
    }

    output

# Generated at 2022-06-12 08:45:46.771435
# Unit test for function parse_forwarded
def test_parse_forwarded():
    #Basic case
    assert parse_forwarded({'Forwarded': ['for="127.0.0.1";proto=http', 'by=test-secret']}, {"FORWARDED_SECRET":"test-secret"}) == {'by': 'test-secret', 'for': '127.0.0.1', 'proto': 'http'}
    #Regex parsing

# Generated at 2022-06-12 08:45:48.867587
# Unit test for function parse_content_header
def test_parse_content_header():
    print(parse_content_header("form-data; name=upload; filename=\"file.txt\""))


# Generated at 2022-06-12 08:46:00.299331
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    import os
    config = type('', (object,), {})()
    headers = type('', (object,), {})()
    config.REAL_IP_HEADER = os.getenv('REAL_IP_HEADER')
    config.PROXIES_COUNT = os.getenv('PROXIES_COUNT')
    config.FORWARDED_FOR_HEADER = os.getenv('FORWARDED_FOR_HEADER')
    headers.ip = os.getenv('IP')
    headers.x_scheme = os.getenv('X_SCHEME')
    headers.x_forwarded_proto = os.getenv('X_FORWARDED_PROTO')
    headers.x_forwarded_host = os.getenv('X_FORWARDED_HOST')
    headers.x_forwarded

# Generated at 2022-06-12 08:46:10.660282
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for=198.51.100.4;proto=https;by=192.0.2.43, for=203.0.113.60;proto=http;by=193.0.2.1;host=example.com'}
    config = {'FORWARDED_SECRET': 'test',
              'REAL_IP_HEADER': '',
              'FORWARDED_FOR_HEADER': '',
              'PROXIES_COUNT': 0}
    ip1, proto1, host1, by1 = parse_forwarded(headers, config)
    assert ip1 == '198.51.100.4'
    assert proto1 == 'https'
    assert host1 == 'example.com'
    assert by1 == '192.0.2.43'

# Generated at 2022-06-12 08:46:22.658795
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"forwarded":"By = \"_forwarded_\"; For = \"19.01.1993.01; Secret = \"19.01.1993.01\"; Proto = \"this is not x-forwarded-proto\"; Host = \"this is not x-forwarded-host\"; Port = \"this is not x-forwarded-port\"; Path = \"this is not x-forwarded-path\";,"}
    config = Config()
    config.FORWARDED_SECRET = "19.01.1993.01"
    print(parse_forwarded(headers, config))


# Generated at 2022-06-12 08:46:34.101660
# Unit test for function parse_forwarded
def test_parse_forwarded():
    """Test parse_forwarded function."""
    from sanic.request import Headers, Request

    def _parse(*, secret=None, forwarded_for=None, forwarded=None):
        req = Request(
            None, None, None, None, Headers(), None, None, None, None, None
        )
        req.app.config.setdefault("FORWARDED_SECRET", secret)
        req.headers.setdefault("for", forwarded_for)
        req.headers.setdefault("forwarded", forwarded)
        return parse_forwarded(req.headers, req.app.config)

    # No secret or headers must return None
    assert _parse() is None
    assert _parse(secret="secret") is None
    assert _parse(forwarded_for="127.0.0.1") is None

# Generated at 2022-06-12 08:46:41.606651
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.test_utils import SanicTestServer

    test_server = SanicTestServer(config_dict=dict(FORWARDED_FOR_HEADER='X-Forwarded-For',PROXIES_COUNT=2))
    request, response = test_server.create_request("GET", "/", headers={"X-Forwarded-For": "10.0.0.1, 10.0.0.2, 10.0.0.3"})
    print(parse_xforwarded(request.headers, test_server.app.config))

# Generated at 2022-06-12 08:46:52.387574
# Unit test for function parse_xforwarded

# Generated at 2022-06-12 08:47:00.799747
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {'x-scheme': 'https', 'x-forwarded-host': 'localhost:8000', 'x-forwarded-port': '8000', 'x-forwarded-path': '/', 'x-forwarded-proto': 'https', 'x-forwarded-for': '127.0.0.1, 10.0.2.2'}
    config = {'REAL_IP_HEADER': 'x-forwarded-for', 'FORWARDED_FOR_HEADER': 'x-forwarded-for', 'PROXIES_COUNT': 1, 'FORWARDED_SECRET': ''}
    assert(parse_xforwarded(headers, config)) == {'for': '127.0.0.1', 'proto': 'https', 'host': 'localhost:8000', 'port': 8000, 'path': '/'}

# Generated at 2022-06-12 08:47:12.614299
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("_") == "_"
    assert fwd_normalize_address("__") == "_"
    assert fwd_normalize_address("unknown") == "_unknown"
    assert fwd_normalize_address("-") == "-._"
    assert fwd_normalize_address("a-.-") == "a-.-._"
    assert fwd_normalize_address("_address") == "_address"
    assert fwd_normalize_address("127.0.0.1") == "127.0.0.1"
    assert fwd_normalize_address("[::1]") == "[::1]"
    assert fwd_normalize_address("::1") == "[::1]"

    with pytest.raises(ValueError):
        fwd_normalize_address("")


# Generated at 2022-06-12 08:47:21.910544
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from collections import OrderedDict
    import json
    import os

    test_dir = os.path.dirname(__file__)
    test_dir = os.path.join(test_dir, "forwarded_tests.json")
    with open(test_dir, "rb") as f:
        tests = json.load(f)

    results = OrderedDict()
    for test in tests:
        input_string = test["input"]
        secret = test["secret"]
        expected_output = test["output"]
        print(input_string)
        if expected_output is None:
            print("Error")
        headers = {'Forwarded': input_string}
        config = {'FORWARDED_SECRET': secret}
        output = parse_forwarded(headers, config)

# Generated at 2022-06-12 08:47:24.807801
# Unit test for function fwd_normalize
def test_fwd_normalize():
    test_case = "proto=http; host=test.com; by=1.1.1.1; for=2.2.2.2; port=80;"
    result = fwd_normalize(parse_forwarded({"forwarded": [test_case]}, None))
    assert result ==  {"proto": "http", "host": "test.com", "by": "1.1.1.1", "for": "2.2.2.2", "port": 80}

# Generated at 2022-06-12 08:47:32.897688
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    print("test_parse_xforwarded()")
    headers = {"x-scheme": "https", "x-forwarded-host": "example.com", "x-forwarded-port": "80",
               "x-forwarded-path": "/", "x-forward-proto": "http", "x-forwarded-for": "127.0.0.1"}
    config = {}
    config["PROXIES_COUNT"] = 2
    config["FORWARDED_FOR_HEADER"] = "x-forwarded-for"
    config["FORWARDED_PROTO_HEADER"] = "x-forwarded-proto"
    config["REAL_IP_HEADER"] = "x-real-ip"
    config["FORWARDED_SECRET"] = None

# Generated at 2022-06-12 08:47:43.865152
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    #parse_xforwarded = f0._parse_xforwarded
    config = BaseConfig()
    class Headers(dict):
        def get(self, key, default=None):
            return self.get(key, default)
        def getall(self, key, default=None):
            return self.get(key, default)

    config.FORWARDED_FOR_HEADER = 'X-Forwarded-For'
    config.REAL_IP_HEADER = 'X-Real-Ip'
    config.PROXIES_COUNT = 4

# Generated at 2022-06-12 08:47:58.169892
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    config = Config()
    config.FORWARDED_SECRET = "test"
    req = Request(
        {
            "headers": [
                [b"Forwarded", b"by=1.2.3.4,\r\n host=example.com, secret=\"test\""],
                [
                    b"Forwarded",
                    b"for=1.2.3.5,by=5.6.7.8;host=proxy,proto=http;port=80,by=1.2.3.4",
                ],
            ]
        },
        config,
        None,
    )

    req.headers.getlist = req.headers.getall
    # Test parsing of a single Forwarded header

# Generated at 2022-06-12 08:48:09.622928
# Unit test for function fwd_normalize

# Generated at 2022-06-12 08:48:20.587588
# Unit test for function fwd_normalize
def test_fwd_normalize():
    v = fwd_normalize_address("127.0.0.1")
    assert v == "127.0.0.1"
    v = fwd_normalize_address("_127.0.0.1")
    assert v == "_127.0.0.1"
    v = fwd_normalize_address("fe80::1")
    assert v == "[fe80::1]"
    v = fwd_normalize_address("_fe80::1")
    assert v == "_fe80::1"
    v = fwd_normalize_address("unknown")
    assert v is None
    v = fwd_normalize_address("")
    assert v is None

if __name__ == "__main__":
    test_fwd_normalize()

# Generated at 2022-06-12 08:48:24.703228
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    h = {
        'x-forwarded-for': '111.222.333.444',
        'x-scheme': 'https',
        'x-forwarded-proto': 'https',
        'x-forwarded-host': 'example.com',
        'x-forwarded-port': '443',
        'x-forwarded-path': 'test'
    }
    print(parse_xforwarded(h, config))


# Generated at 2022-06-12 08:48:34.570076
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import unittest
    import json

    # Test cases with target string and expected result

# Generated at 2022-06-12 08:48:44.557504
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]).empty()

# Generated at 2022-06-12 08:48:55.343397
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # parse_forwarded should return None in case of mismatch
    assert parse_forwarded({},object) == None
    assert parse_forwarded({'forwarded': ['foo']},object) == None
    assert parse_forwarded({'forwarded': ['by=127.0.0.1,for="foo"']},object) == None
    assert parse_forwarded({'forwarded': ['by=127.0.0.1; secret=""]']},object) == None
    # parse_forwarded should return [] in case of correct match
    assert parse_forwarded({'forwarded': ['by=127.0.0.1,for=192.0.2.0,secret="foobar"']},object) == []
    # parse_forwarded should return a dict with key-values in case of correct match

# Generated at 2022-06-12 08:49:04.172106
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    shdr = "127.0.0.1" # A sample value for the real_ip_header
    hdrs = {shdr:'127.0.0.1', 'x-forwarded-host':'TestHost', 'x-forwarded-port':'8000'}
    config = {'proxies_count':1, 'real_ip_header':shdr, 'forwarded_for_header': shdr}
    try:
        r = parse_xforwarded(hdrs, config)
    except Exception as e:
        print("test_parse_xforwarded: Exception: " + str(e.args))
    print("test_parse_xforwarded: Result: " + str(r))
    #print("test_parse_xforwarded: Result: " + str(r))
    return r

# Generated at 2022-06-12 08:49:13.305903
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "2001:db8::1",
        "x-forwarded-host": "test.com",
        "x-forwarded-port": "80",
        "x-forwarded-proto": "https",
    }
    config = {"PROXIES_COUNT": 1, "FORWARDED_FOR_HEADER": "x-forwarded-for"}
    assert parse_xforwarded(headers, config) == {
        "for": "2001:db8::1",
        "host": "test.com",
        "port": 80,
        "proto": "https",
    }


if __name__ == "__main__":
    test_parse_xforwarded()

# Generated at 2022-06-12 08:49:22.916886
# Unit test for function parse_host
def test_parse_host():
    test_ipv4_hosts = [
        ("localhost:8080", ("localhost", 8080)),
        ("www.test.com", ("www.test.com", None)),
        ("192.168.1.1:3000", ("192.168.1.1", 3000)),
        ("192.168.1.1:50000", ("192.168.1.1", 50000)),
        ("192.168.0.0", ("192.168.0.0", None)),
    ]

# Generated at 2022-06-12 08:49:46.446562
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.exceptions import InvalidUsage
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic(__name__)

    @app.route("/")
    async def handler(request):
        if request.forwarded:
            return json(request.forwarded)
        else:
            raise InvalidUsage
    client = SanicTestClient(app, port=0)

# Generated at 2022-06-12 08:49:57.096229
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded([('forwarded', 'for=\"abc\";by=\"secret\"')], type('Config', (object,), {'FORWARDED_SECRET': 'secret'})) == {'for': 'abc', 'by': 'secret'}
    assert parse_forwarded([('forwarded', 'For=_\"bad-end-quote;by=secret;proto=https')], type('Config', (object,), {'FORWARDED_SECRET': 'secret'})) == None

# Generated at 2022-06-12 08:49:57.887363
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert True



# Generated at 2022-06-12 08:50:08.608412
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-Protocol": "http",
        "X-Forwarded-For": "129.79.245.252,129.79.245.252,129.79.245.252",
        "X-Forwarded-Port": "443",
        "X-Forwarded-Host": "test.host",
        "X-Forwarded-Path": "/test/path/",
    }
    assert parse_xforwarded(headers, None) == {
        "proto": "http",
        "for": "129.79.245.252",
        "port": 443,
        "host": "test.host",
        "path": "/test/path/",
    }
    headers["X-Forwarded-Protocol"] = ""

# Generated at 2022-06-12 08:50:18.436067
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic import Sanic
    app = Sanic()
    config = app.config
    
    # set REAL_IP_HEADER = 1
    config.REAL_IP_HEADER = 1
    # set PROXIES_COUNT = 1
    config.PROXIES_COUNT = 1
    
    
    headers = {
        "Forwarded": "for=192.0.2.43, for=198.51.100.17",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Port": "443",
        "X-Forwarded-Path": "/application"
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-12 08:50:28.949725
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from collections import namedtuple
    from urllib.parse import parse_qs

    class Headers:
        """This is just like a list, but it can be indexed by name."""

        def __init__(self, hint=None):
            self._headers = []
            self._normalized = {}
            self._hint = hint

        def add(self, name, value):
            self._headers.append((name, value))
            norm = name.lower()
            self._normalized[norm] = name

        def get(self, name):
            # Simulate how browsers normalize headers
            norm = name.lower()
            if norm not in self._normalized:
                return self._hint
            return self[self._normalized[norm]]


# Generated at 2022-06-12 08:50:39.580590
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "bad")]) == {}
    assert fwd_normalize([("for", "bad"), ("by", "ok")]) == {'by': 'ok'}
    assert fwd_normalize([("for", "bad"), ("by", "ok"), ("for", "good")]) == {'by': 'ok', 'for': 'good'}
    assert fwd_normalize([("for", "not"), ("for", "bad"), ("by", "ok")]) == {'by': 'ok', 'for': 'not'}
    assert fwd_normalize([("by", "bad"), ("by", "ok")]) == {'by': 'ok'}
    assert fwd_normalize([("host", "bad"), ("host", "ok")])

# Generated at 2022-06-12 08:50:50.777290
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded(None, None) == {}
    assert parse_forwarded({"forwarded": ["by=x.x.x.x"]}, {"FORWARDED_SECRET": None}) == {}
    assert parse_forwarded({"forwarded": "by=x.x.x.x"}, {"FORWARDED_SECRET": "secret"}) == {"by": "x.x.x.x"}
    assert parse_forwarded({"forwarded": "for=10.0.1.1;by=x.x.x.x"}, {"FORWARDED_SECRET": "secret"}) == {
        "for": "10.0.1.1", "by": "x.x.x.x"}

# Generated at 2022-06-12 08:51:02.144793
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # No header
    assert parse_forwarded({}, {'FORWARDED_SECRET': 'a'}) is None
    # Secret not in header
    assert parse_forwarded({'forwarded': 'for=127.0.0.1'}, {'FORWARDED_SECRET': 'b'}) is None
    # Secret in header
    assert parse_forwarded({'forwarded': 'for=127.0.0.1; secret=a'}, {'FORWARDED_SECRET': 'a'}) == {'for': '127.0.0.1'}
    # Secret in another part of header

# Generated at 2022-06-12 08:51:14.318398
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize({"for": "unknown"}) == {}
    assert fwd_normalize({"for": "_obfuscated"}) == {"for": "_obfuscated"}
    assert fwd_normalize({"for": "192.168.0.1"}) == {"for": "192.168.0.1"}
    assert fwd_normalize({"for": "2001:0db8:85a3:0000:0000:8a2e:0370:7334"}) == {"for": "[2001:0db8:85a3:0000:0000:8a2e:0370:7334]"}
    assert fwd_normalize({"port": "12345"}) == {"port": 12345}

# Generated at 2022-06-12 08:51:29.524900
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    class Sanic:
        class Request:
            class config:
                PROXIES_COUNT = 2
                FORWARDED_FOR_HEADER = "X-Forwarded-For"

    req = Sanic.Request()
    req.headers = {
        "X-Forwarded-For": "1.2.3.4,2.3.4.5,3.4.5.6"
    }

    assert parse_xforwarded(req.headers, req.config) == {"for": "3.4.5.6"}


# Generated at 2022-06-12 08:51:39.015527
# Unit test for function fwd_normalize
def test_fwd_normalize():
    fwd = [
        ("FoR", "127.0.0.1"),
        ("For", "::1"),
        ("for", "::1"),
        ("for", "::1"),
        ("proto", "https"),
        ("prOto", "HTTPs"),
        ("host", "example.com"),
        ("host", "example.com"),
        ("port", "443"),
        ("port", "invalid"),
        ("path", "https://example.com/"),
        ("path", "https://example%2ecom/"),
        ("invalid", "invalid"),
    ]


# Generated at 2022-06-12 08:51:44.155539
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-forwarded-host": "example.org",
        "x-forwarded-path": "hello%20world",
    }
    options = parse_xforwarded(headers, None)
    assert options == {
        "proto": "https",
        "host": "example.org",
        "path": "hello world",
    }

# Generated at 2022-06-12 08:51:50.989863
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-host': 'fast.com.cn',
        'x-forwarded-proto': 'https',
    }
    config = {
        'REAL_IP_HEADER': '',
        'PROXIES_COUNT': 0,
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
    }
    ret = parse_xforwarded(headers, config)
    print(ret)


# Test for function parse_forwarded

# Generated at 2022-06-12 08:51:55.349350
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import json
    import sanic
    from sanic.response import text
    from sanic.config import Config
    app = sanic.Sanic()
    config = Config()
    config.REAL_IP_HEADER = 'remote-addr'
    config.FORWARDED_FOR_HEADER = 'x-forwarded-for'
    config.FORWARDED_SECRET = 'fwdsx'

    @app.route("/")
    async def dump_headers(request):
        """Return all headers as JSON.
        Note that .headers.keys() is not reliable.
        """
        ret = {}
        for header in dir(request.headers):
            if header[0] == "_":
                continue  # Skip internal headers or private members
            key = header.replace("_", "-").title()

# Generated at 2022-06-12 08:52:04.673980
# Unit test for function fwd_normalize
def test_fwd_normalize():
    from collections import namedtuple

    T = namedtuple('T', 'expected call')

# Generated at 2022-06-12 08:52:11.044847
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Note: This test must be kept in sync with any changes to function
    # parse_forwarded.
    import io
    import itertools
    import sys
    import tempfile
    from sanic.log import configure_logging
    from sanic.request import Request
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic_compress import Compress
    from .test_helpers import TestClient

    # We use a TestClient here, because it allows us to feed requests directly
    # to the HttpProtocol and make the request process run through while
    # providing us the result.

# Generated at 2022-06-12 08:52:20.176600
# Unit test for function fwd_normalize

# Generated at 2022-06-12 08:52:25.541451
# Unit test for function parse_forwarded
def test_parse_forwarded():
    mock_headers = {
        "forwarded" : [
            "for=192.0.2.60; proto=http; by=203.0.113.43, for=127.0.0.1; proto=http; by=203.0.113.43",
            "for=192.0.2.43, for=198.51.100.17"
        ]
    }

    fwd = parse_forwarded(mock_headers, {})
    print(fwd)


# Generated at 2022-06-12 08:52:32.792500
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"x-scheme": "http",
               "x-forwarded-host": "host.com",
                "x-forwarded-port": "80",
                "x-forwarded-path": "path"}
    config = {'REAL_IP_HEADER': '1.1.1.1',
              'PROXIES_COUNT': 2,
              'FORWARDED_FOR_HEADER': 'x-forwarded-for'}
    assert parse_xforwarded(headers, config) == {'proto': 'http',
                                          'host': 'host.com',
                                          'port': 80,
                                          'path': 'path'}


# Generated at 2022-06-12 08:52:54.033595
# Unit test for function fwd_normalize
def test_fwd_normalize():
    res = fwd_normalize([('port', '8080')])
    assert res['port'] == 8080
    res = fwd_normalize([('port', '8080'), ('by', '127.0.0.1')])
    assert res['port'] == 8080
    assert res['by'] == '127.0.0.1'
    res = fwd_normalize([('for', '127.0.0.1')])
    assert res['for'] == '127.0.0.1'
    # IPv6
    res = fwd_normalize([('for', '2001:0db8:85a3:0000:0000:8a2e:0370:7334')])

# Generated at 2022-06-12 08:53:04.372925
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    config = DotDict({
        "REAL_IP_HEADER": "x-real-ip", 
        "PROXIES_COUNT": 2,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    })
    headers = DotDict({
        "x-real-ip": "172.10.0.1", 
        "x-forwarded-for": "172.10.0.2, 172.10.0.3",
        "x-forwarded-proto": "https",
        "x-forwarded-host": "test.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/test",
    })

    options = parse_xforwarded(headers, config)

# Generated at 2022-06-12 08:53:13.968375
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded(
        {'forwarded': 'for="_gazonk" ,proto=https, by=_jinx, secret=123'},
        {'FORWARDED_SECRET': '123'}
    ) == {'by': '_jinx', 'for': '_gazonk', 'proto': 'https'}
    assert parse_forwarded(
        {'forwarded': 'for="_gazonk" ,proto=https, by=_jinx, secret=123'},
        {'FORWARDED_SECRET': '1234'}
    ) == None
    assert parse_forwarded(
        {'forwarded': 'for="_gazonk" ,proto=https, by=_jinx'},
        {'FORWARDED_SECRET': '123'}
    )

# Generated at 2022-06-12 08:53:24.543122
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:53:34.767697
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert {'for': '192.168.1.1', 'by': '192.168.1.2'} == parse_forwarded(
        {'forwarded': 'for=192.168.1.1, by=192.168.1.2; secret=my-secret'},
        {"FORWARDED_SECRET": "my-secret"}
    )
    assert {'for': '192.168.1.1', 'by': '192.168.1.2'} == parse_forwarded(
        {'forwarded': 'for=192.168.1.1; secret=my-secret, by=192.168.1.2'},
        {"FORWARDED_SECRET": "my-secret"}
    )

# Generated at 2022-06-12 08:53:44.010779
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    assert parse_xforwarded({
        'X-Forwarded-Host': '10.1.2.3:80',
        'X-Forwarded-For': '192.168.1.1, 10.1.2.3'
    }, {
        'PROXIES_COUNT': 2,
        'REAL_IP_HEADER': 'X-Forwarded-Host'
    }) == {
        'proto': 'http',
        'host': '10.1.2.3:80',
        'port': 80,
        'for': '192.168.1.1',
    }

# Generated at 2022-06-12 08:53:53.702421
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "by=_behind",
            "By=_behind-middle",
            "for=127.0.0.1; by=_behind-last;proto=https",
            "For=_ipv6;by=_behind;proto=http;Host=_host-last; secret=loose",
        ]
    }
    expected_ret = {
        "by": "_behind-last",
        "for": "127.0.0.1",
        "proto": "https",
        "host": "_host-last",
    }
    assert parse_forwarded(headers, "loose") == expected_ret



# Generated at 2022-06-12 08:54:02.209691
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.request import Request
    req = Request(None, headers={
        "X-Forwarded-For": "192.168.1.1, 192.168.1.2, 192.168.1.3",
        "X-Forwarded-Host": "example.com",
        "X-Forwarded-Path": "/path",
        "X-Forwarded-Port": "80",
        "X-Forwarded-Proto": "https",
    }, scheme="http")
    assert req._raw_headers is not None
    config = req.app.config

# Generated at 2022-06-12 08:54:13.031845
# Unit test for function fwd_normalize
def test_fwd_normalize():
    # TODO: implement
    # test parse_xforwarded
    # test parse_forwarded
    # test parse_content_header: invalid input
    # Test fwd_normalize_address
    assert fwd_normalize_address("1.1.1.1") == "1.1.1.1"
    assert fwd_normalize_address("_1.1.1.1") == "_1.1.1.1"
    assert fwd_normalize_address("2001:db8:85a3::8a2e:370:7334") == "[2001:db8:85a3::8a2e:370:7334]"
    assert fwd_normalize_address("Unknown") == "unknown"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_

# Generated at 2022-06-12 08:54:20.545802
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from collections import namedtuple
    from sanic import Sanic
    from sanic.request import RequestParameters
    from sanic.response import StreamingHTTPResponse
    import os
    import random
    import tempfile
    import uuid

    # Cribbed and modified from sanic.server.HTTPServer._get_additional_headers() and
    # sanic.utils.request_ctx
    def _get_additional_headers(self, request, headers):
        forwarded_protocol = None
        forwarded_for = None
        forwarded_proto = None
        forwarded_host = None
        forwarded_port = None
        forwarded_uri = None
        forwarded_path = None
        forwarded_prefix = None

        # Set the forwarded headers