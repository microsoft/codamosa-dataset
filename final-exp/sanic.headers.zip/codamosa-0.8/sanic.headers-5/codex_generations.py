

# Generated at 2022-06-12 08:44:48.301351
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", "127.0.0.1")]) == {
        "for": "127.0.0.1"
    }
    assert fwd_normalize([("for", "[::1]")]) == {"for": "[::1]"}
    assert fwd_normalize([("for", "192.168.1.1")]) == {
        "for": "192.168.1.1"
    }
    assert fwd_normalize([("for", "invalid")]) == {}
    assert fwd_normalize([("proto", "http")]) == {"proto": "http"}
    assert fwd_normalize([("proto", "HTTPS")]) == {"proto": "https"}

# Generated at 2022-06-12 08:44:55.075894
# Unit test for function parse_forwarded
def test_parse_forwarded():
    forwardd_dict={'for':'27.15.89.100','by': '127.0.0.1','proto':'http'}
    headers={'forwarded':'by=127.0.0.1;for=27.15.89.100;proto=http,by=192.168.27.1;for=127.0.0.1;proto=http'}
    config=namedtuple('config',['proxies_count','FORWARDED_SECRET'])
    options=parse_forwarded(headers,config(2,'127.0.0.1'))
    assert options==forwardd_dict

# Generated at 2022-06-12 08:45:04.607701
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.request import RequestParameters
    headers = RequestParameters({'forwarded': ['for=192.0.2.60;proto=https;host=example.com;port=8080']})
    config.PROXIES_COUNT = 1

    # parse_forwarded(headers, config) returns a dictionary of <key>=<value>
    # (plain string, not decoded HTTP header)
    result = parse_forwarded(headers, config)
    assert result == {'for': '192.0.2.60', 'proto': 'https', 'host': 'example.com', 'port': 8080}


# Generated at 2022-06-12 08:45:12.686885
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("by", "unknown")]) == {}
    assert fwd_normalize([("by", "127.0.0.1")]) == {"by": "127.0.0.1"}
    assert fwd_normalize([("by", "::1")]) == {"by": "[::1]"}
    assert fwd_normalize([("port", "80")]) == {"port": 80}
    assert fwd_normalize([("port", "invalid")]) == {}
    assert fwd_normalize([("path", "x=%C3%A0")]) == {"path": "x=à"}
    assert fwd_normalize([("path", "foo%2Fbar")]) == {"path": "foo/bar"}

# Generated at 2022-06-12 08:45:15.361385
# Unit test for function fwd_normalize
def test_fwd_normalize():
    options = [('host','localhost'), ('port','1450'), ('proto','https')]
    assert fwd_normalize(options) == {'host': 'localhost', 'port': 1450, 'proto': 'https'}

# Generated at 2022-06-12 08:45:26.351522
# Unit test for function parse_forwarded
def test_parse_forwarded():
    def equal(x, y):
        return set(x) == set(y) and x.keys() == y.keys()

    assert equal(parse_forwarded({"Forwarded": "secret=s, by=a"}, {}), {"by": "a", "secret": "s"})
    assert equal(parse_forwarded({"Forwarded": "secret=s;by=a"}, {}), {"by": "a", "secret": "s"})
    assert equal(parse_forwarded({"Forwarded": "secret=s , by=a"}, {}), {"by": "a", "secret": "s"})
    assert equal(parse_forwarded({"Forwarded": " secret=s , by=a "}, {}), {"by": "a", "secret": "s"})

# Generated at 2022-06-12 08:45:28.404442
# Unit test for function parse_content_header
def test_parse_content_header():
    res = parse_content_header("form-data; name=upload; filename=\"file.txt\"")
    assert res == ('form-data', {'name': 'upload', 'filename': 'file.txt'})

# Generated at 2022-06-12 08:45:36.744215
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    import os
    headers_env = os.environ.get("SANIC_TEST_HEADERS")
    if headers_env is None:
        return
    import json
    import random
    import string
    from sanic import Sanic
    from sanic.request import Request

    class MockHeaders:
        def __init__(self, **kwargs):
            self.headers = kwargs

        def __getattr__(self, key):
            return self.headers.get(key)

        def get(self, key, default=""):
            return self.headers.get(key, default)

        def getall(self, key):
            return self.headers.get(key, "").split(",")

    sanic = Sanic("test_parse_xforwarded")


# Generated at 2022-06-12 08:45:40.276633
# Unit test for function fwd_normalize
def test_fwd_normalize():
    print(fwd_normalize({"by":"_foo-bar","proto":"http","host":"host:80","port":80,"path":"/"}))
    print(fwd_normalize({"by":"_foo-bar","proto":"http","host":"host:80","port":80,"path":"/%2F"}))
    print(fwd_normalize({"by":"_foo-bar","proto":"http","host":"host:80","port":80,"path":"/%2F%2F"}))


# Generated at 2022-06-12 08:45:48.988657
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;by=203.0.113.60;host=example.com;path=%2Fapp2%2Fresource",
            "for=192.0.2.60;by=203.0.113.60;path=%2Fapp2%2Fresource",
        ]
    }
    config = type("Config", (object,), {"FORWARDED_SECRET": "bleh"})()
    result = parse_forwarded(headers, config)
    print(result)

# Generated at 2022-06-12 08:46:11.873472
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': '127.0.0.1',
        'X-Forwarded-Host': 'localhost',
        'X-Forwarded-Port': '8080',
        'X-Forwarded-Path': '/test/123'
    }
    config = {
        'FORWARDED_FOR_HEADER': 'x-forwarded-for',
        'FORWARDED_SECRET': None,
        'PROXIES_COUNT': None,
        'REAL_IP_HEADER': None,
        'TRUSTED_PROXIES': None
    }
    expected = {'for': '127.0.0.1', 'host': 'localhost', 'port': 8080, 'path': '/test/123'}

# Generated at 2022-06-12 08:46:18.692912
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"},
                            {"FORWARDED_SECRET": "secret"}) == {
        "for": "192.0.2.60",
        "proto": "http",
        "by": "203.0.113.43",
    }
    assert parse_forwarded({"forwarded": "for=192.0.2.60;proto=http;by=203.0.113.43"},
                            {"FORWARDED_SECRET": None}) == None

# Generated at 2022-06-12 08:46:22.708433
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-Host": "localhost",
        "X-Forwarded-Port": "80"
    }
    opt = parse_xforwarded(headers, None)
    assert opt['host'] == 'localhost'
    assert opt['port'] == 80



# Generated at 2022-06-12 08:46:25.009916
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"x-forwarded-proto": "https", "x-forwarded-for": "192.168.1.1"}
    config = {"FORWARDED_FOR_HEADER": "x-forwarded-for", "REAL_IP_HEADER": None}
    proxy = parse_xforwarded(headers, config)
    print(proxy)

# Generated at 2022-06-12 08:46:35.664279
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.response import HTTPResponse
    from sanic.request import Request

    config = Config()
    config.FORWARDED_SECRET = "secret0"
    
    # Example 1:
    #     Forwarded: for=192.0.2.60;proto=http;by=203.0.113.43
    #     X-Forwarded-For: proxy1, proxy2
    #     X-Forwarded-Host: host.example.com
    #     X-Forwarded-Proto: https
    #     X-Forwarded-Port: 443
    

# Generated at 2022-06-12 08:46:42.042846
# Unit test for function parse_forwarded
def test_parse_forwarded():
     # Unit test for function parse_forwarded
    headers = {
        'Forwarded': 'host=host123.com;secret=secret123;proto=http, '
        + 'for=ip123.com;secret=secret123;proto=https;by=proxy123.com'
    }
    ret = parse_forwarded(headers, 'secret123')
    print(ret)

if __name__ == '__main__':
    test_parse_forwarded()

# Generated at 2022-06-12 08:46:52.844540
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded(
        'secret=TEST; for="[::1]\", by=_google2', 'TEST') == {'secret': 'TEST', 'for': '[::1]', 'by': '_google2'}
    assert parse_forwarded(
        'secret=TEST; by=_google2; for="[::1]\", secret=TEST', 'TEST') == {'secret': 'TEST', 'for': '[::1]', 'by': '_google2'}

# Generated at 2022-06-12 08:47:01.008959
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.testing import assert_equal
    from sanic.request import Request

    config = Config()
    config.FORWARDED_SECRET = "asdf"

    d = "for=1.2.3.4; proto=http; by=5.6.7.8; secret=asdf"
    req = Request(headers={"Forwarded": d}, config=config)

    assert_equal(req.forwarded, {'for': '1.2.3.4', 'proto': 'http'})

    d = "for=1.2.3.4; proto=http, secret=asdf, by=5.6.7.8; proto=https, secret=asdf"
    req = Request(headers={"Forwarded": d}, config=config)

    assert_equal

# Generated at 2022-06-12 08:47:05.493619
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    import sanic
    app = sanic.Sanic(__name__)
    headers={"X-Forwarded-For":"10.0.0.1"}
    print(parse_xforwarded(headers, app.config))

if __name__ == '__main__':
    test_parse_xforwarded()

# Generated at 2022-06-12 08:47:17.223607
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import pytest
    from sanic import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.response import text

    app = Sanic(__name__)

    @app.route("/<name>")
    async def forward(request, name):
        return text(name)

    forwarded_secret = "supersecret"

    @app.listener("before_server_start")
    def setup(app, loop):
        app.config.FORWARDED_SECRET = forwarded_secret

    client = app.test_client
    success_key = (
        "for=192.0.2.60;proto=http;host=www.example.com;by=203.0.113.43,for=203.0.113.43;by=192.0.2.60"
    )
    success

# Generated at 2022-06-12 08:47:31.870841
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from datadog import statsd
    from datadog.dogstatsd.base import DogStatsd
    from sanic.config import Config
    from sanic.exceptions import SanicException

    from framework.sanic.helpers import parse_xforwarded
    from framework.util import ADDRESS, HOST, PORT, PROTOCOL
    from framework.util import (
        FORWARDED_FOR_HEADER,
        FORWARDED_HOST_HEADER,
        FORWARDED_PORT_HEADER,
        FORWARDED_PROTO_HEADER,
        PROXIES_COUNT,
        REAL_IP_HEADER,
    )

    # Mock DogStatsd and Config to avoid actual logging
    statsd_mock = statsd
    statsd = DogStatsd(mock=True)
    config_mock

# Generated at 2022-06-12 08:47:39.622425
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.server import HttpProtocol
    from sanic import Sanic

    app = Sanic()

    @app.route("/hello/")
    async def test(request):

        request.protocol = HttpProtocol(app, app.is_request_stream,
                                        base=None)

        request.headers = {'x-forwarded-for':  '192.168.0.1'}

        options = parse_xforwarded(request.headers, request.app.config)
        assert options['for'] == '192.168.0.1'



# Generated at 2022-06-12 08:47:50.226045
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {'X-Forwarded-For' : '192.168.1.1'}
    res = parse_xforwarded(headers, config)

# Generated at 2022-06-12 08:47:58.323576
# Unit test for function parse_forwarded
def test_parse_forwarded():
    def assert_results(expected: Options, header: str = None) -> None:
        if header is None:
            header = expected.get("for", "")
        else:
            header = header
        headers = []
        for a in header.split(","):
            headers.append(a.strip())
        result = parse_forwarded(headers=headers, config="test")
        # Test by value
        assert result == expected
        # Test by object identity
        if expected.get("for"):
            assert result["for"] is expected["for"]

    assert_results({"for": "1.2.3.4"})
    assert_results({"for": "1.2.3.4"}, header='for="1.2.3.4"')

# Generated at 2022-06-12 08:48:03.301597
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"a": "A", "b": ["A", "B"]}
    assert parse_xforwarded(headers, "c") == None
    headers = {"c": "A", "b": ["A", "B"]}
    assert parse_xforwarded(headers, "c") == {'for': 'A'}

# Generated at 2022-06-12 08:48:14.523501
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({"Forwarded": "by=_HOST, for=_IP"},
                           AttrDict(FORWARDED_SECRET='_HOST')) == {
        'by': '_HOST',
        'for': '_ip'
    }
    assert parse_forwarded({"Forwarded": "by=\"_ HOST\", for=\"_IP\""},
                           AttrDict(FORWARDED_SECRET='"_ HOST"')) == {
        'by': '"_ HOST"',
        'for': '"_ip"'
    }
    assert parse_forwarded({"Forwarded": " secret = _HOST ; by = _HOST,"},
                           AttrDict(FORWARDED_SECRET='_HOST')) is None

# Generated at 2022-06-12 08:48:24.320628
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    def assert_parse(headers, config, expected):
        assert parse_xforwarded(headers, config) == expected

    config = Mock()
    config.PROXIES_COUNT = 2
    config.FORWARDED_FOR_HEADER = 'X-Forwarded-For'
    config.REAL_IP_HEADER = 'X-Real-IP'

    # Simple example
    headers = Mock()
    headers.get = Mock(side_effect=lambda k: {
        'X-Forwarded-For': '10.128.0.1, 192.168.0.1',
        'X-Real-IP': '8.8.8.8',
    }[k])
    assert_parse(headers, config, {'for': '10.128.0.1'})

    # Real world example
    headers = Mock()

# Generated at 2022-06-12 08:48:32.378089
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"forwarded": "for=\"_test_addr_\";proto=_test_proto_;by=_test_by_"}
    config = {
        "FORWARDED_FOR_HEADER": None,
        "PROXIES_COUNT": None,
        "REAL_IP_HEADER": None,
        "FORWARDED_SECRET": "_test_by_"
    }
    forwarded = parse_forwarded(headers, config)

    if forwarded is None:
        print("None")
        return None
    for f in forwarded:
        print(f)
    return forwarded


test_parse_forwarded()

# Generated at 2022-06-12 08:48:42.378956
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic_cookies import Header
    config = {'FORWARDED_SECRET':'', 'FORWARDED_FOR_HEADER':''}
    headers = Header('forwarded', 'for=::1;proto=https;host=127.0.0.1;port=443;by=127.0.0.1')
    assert parse_forwarded(headers, config) == {'for': '::1', 'proto': 'https', 'host': '127.0.0.1', 'port': 443, 'by': '127.0.0.1'}
    headers = Header('forwarded')
    assert parse_forwarded(headers, config) == None
    config = {'FORWARDED_SECRET':'secret', 'FORWARDED_FOR_HEADER':''}

# Generated at 2022-06-12 08:48:52.692274
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:49:06.614620
# Unit test for function parse_host
def test_parse_host():
    # Normal host:port
    assert parse_host("127.0.0.1:8080") == ("127.0.0.1", 8080)
    # Normal localhost:port
    assert parse_host("localhost") == ("localhost", None)
    # IPv6 address
    assert parse_host("[2001:db8:85a3:8d3:1319:8a2e:370:7348]") == ("[2001:db8:85a3:8d3:1319:8a2e:370:7348]", None)
    # IPv6 address with port

# Generated at 2022-06-12 08:49:13.201286
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-host': 'mysite.com', 
        'x-forwarded-port': '80'
    }
    config = {
        'FORWARDED_FOR_HEADER': 'x-forwarded-host',
        'PROXIES_COUNT': 'x-forwarded-port'
    }

    host, port = parse_xforwarded(headers, config)
    assert host == 'mysite.com'
    assert port == 80

# Generated at 2022-06-12 08:49:22.837442
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"forwarded": ["By=192.0.2.60; Proto=https; Host=www.example.com"]}
    config = {"FORWARDED_SECRET": "secret"}
    assert parse_forwarded(headers, config) == {"for": "192.0.2.60", "proto": "https", "host": "www.example.com"}

    headers = {"forwarded": ["By=192.0.2.60; Proto=https; Host=www.example.com; X-OpenResty-Cache=Hit"]}
    config = {"FORWARDED_SECRET": "secret"}
    assert parse_forwarded(headers, config) == {"for": "192.0.2.60", "proto": "https", "host": "www.example.com"}


# Generated at 2022-06-12 08:49:25.816106
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"x-forwarded-host": "www.example.com:123/path"}
    ret = parse_xforwarded(headers, config)
    assert ret == {"host": "www.example.com:123", "path": "/path"}, ret

# Generated at 2022-06-12 08:49:35.387256
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    assert parse_xforwarded(headers(None), Config()) is None

    assert parse_xforwarded(headers("8.8.8.8"), Config()) == {
        "for": "8.8.8.8"
    }

    assert parse_xforwarded(
        headers(None, "8.8.8.8"), Config(FORWARDED_FOR_HEADER="X-Forwarded-For")
    ) == {
        "for": "8.8.8.8"
    }

    assert parse_xforwarded(headers(None, "8.8.8.8", "1.2.3.4"), Config()) == {
        "for": "1.2.3.4"
    }


# Generated at 2022-06-12 08:49:46.446872
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config

    config = Config(
        REAL_IP_HEADER="X-Real-IP",
        FORWARDED_FOR_HEADER="X-Forwarded-For",
        PROXIES_COUNT=1,
        GATEWAY="traefik",
    )

    result = parse_xforwarded(
        {
            "X-Scheme": "https",
            "X-Real-IP": "192.168.0.1",
            "X-Forwarded-For": "192.168.0.2",
            "X-Forwarded-Host": "www.example.com",
            "X-Forwarded-Port": "80",
            "X-Forwarded-Path": "https://www.example.com/path",
        },
        config,
    )

# Generated at 2022-06-12 08:49:57.097300
# Unit test for function parse_forwarded
def test_parse_forwarded():
    assert parse_forwarded({'a': 'b'}, {}) is None

    headers = {
        'forwardedn': 'for=192.0.2.43, for="[2001:db8:cafe::17]";proto=http'
    }
    assert parse_forwarded(headers, {}) is None
    assert parse_forwarded(headers, {'FORWARDED_SECRET': 'secret'}) is not None
    assert parse_forwarded(headers, {'FORWARDED_SECRET': 'nope'}) is None

    headers = {
        'forwardedn': 'by="secret";;for=192.0.2.43,for="[2001:db8:cafe::17]",proto=http'
    }

# Generated at 2022-06-12 08:50:07.653169
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:50:17.692995
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    # Test if all cases are covered
    # Method 1
    headers = {'x-forwarded-proto': 'http'}
    config = {'PROXIES_COUNT': 1, 'FORWARDED_FOR_HEADER': 'X-Forwarded-For', 'REAL_IP_HEADER': 'X-Forwarded-For'}
    assert parse_xforwarded(headers, config)[0][1] == 'http'

    # Method 2
    headers = {'x-forwarded-for': 'http://localhost'}
    config = {'PROXIES_COUNT': 1, 'FORWARDED_FOR_HEADER': 'X-Forwarded-For', 'REAL_IP_HEADER': 'X-Forwarded-For'}

# Generated at 2022-06-12 08:50:28.229623
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic import Sanic

    app = Sanic(__name__)
    # X-Forwarded-Proto and X-Forwarded-Port are used instead
    # of default ones X-Scheme and X-Forwarded-Host
    app.config.PROXIES_COUNT = 1
    app.config.REAL_IP_HEADER = 'X-Real-Ip'
    app.config.FORWARDED_FOR_HEADER = 'X-Forwarded-For'
    app.config.FORWARDED_PROTO_HEADER = 'X-Forwarded-Proto'

    class MockRequest:
        def __init__(self, headers: HeaderIterable):
            self.headers = {h[0]: h[1] for h in headers}

        def get(self, key: str, default=None):
            return self

# Generated at 2022-06-12 08:50:51.937814
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    """
    Test parse_xforwarded with path, host, port and proto headers
    """
    headers = {"x-forwarded-path": "first/second/third",
               "x-forwarded-host": "www.example.com",
               "x-forwarded-port": "8080",
               "x-forwarded-proto": "https",
               }

    conf = {
        "REAL_IP_HEADER": "x-real-ip",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
        "FORWARDED_SECRET": "hush",
    }

    # Test with valid headers
    options = parse_xforwarded(headers, conf)
    assert options["path"] == "first/second/third"
   

# Generated at 2022-06-12 08:51:04.150869
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:51:09.211189
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'X-Forwarded-For': 'test_forwarded_ip'
    }
    expected = {
        'for': 'test_forwarded_ip'
    }
    parsed = parse_xforwarded(headers, None)
    assert parsed == expected
    print("Test success")

test_parse_xforwarded()

# Generated at 2022-06-12 08:51:16.145563
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.response import text

    @app.route("/")
    async def handler(request):
        return text("%s" % request.headers.get("X-FORWARDED-HOST"))

    request, response = app.test_client.get("/", headers={"X-FORWARDED-HOST": "127.0.0.1"})
    assert response.status == 200
    assert response.text == "127.0.0.1"

# Generated at 2022-06-12 08:51:27.134746
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.response import text
    from sanic.testing import HOST, PORT
    from sanic_backend.app import server

    # Issue #547: RFC 7239 Forwarded header not parsed correctly
    # https://github.com/huge-success/sanic/issues/547


# Generated at 2022-06-12 08:51:31.938076
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"X-Forwarded-For": "127.0.0.1"}
    config.REAL_IP_HEADER = "X-Forwarded-For"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.PROXIES_COUNT = 0

    parse_xforwarded(headers, config)


# Generated at 2022-06-12 08:51:40.141589
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "192.168.1.1",
        "x-forwarded-host": "example.com",
        "x-forwarded-port": "1234",
        "x-forwarded-proto": "https",
    }
    class options:
        REAL_IP_HEADER = None
        PROXIES_COUNT = 100
        FORWARDED_FOR_HEADER = "x-forwarded-for"
    assert parse_xforwarded(headers, options) == {
        "for": "192.168.1.1",
        "proto": "https",
        "host": "example.com",
        "port": 1234,
    }

# Generated at 2022-06-12 08:51:50.345569
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    import sanic
    from sanic.request import Header, Headers
    from typing import Dict

    app = sanic.Sanic()
    app.config.REAL_IP_HEADER = "X-Forwarded-For"
    app.config.FORWARDED_FOR_HEADER = "X-Forwarded-For"

    # mockup the headers (and do no convert the dict to a Header)
    headers = Headers({"X-Forwarded-For": "127.0.0.1, 127.0.0.2"})

    # sanity check
    assert len(headers.getall("x-forwarded-for")) == 2
    assert headers.get("x-forwarded-for") == "127.0.0.1, 127.0.0.2"


# Generated at 2022-06-12 08:51:51.976410
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    assert parse_xforwarded({"x-forwarded-for": "foo"}, {}) == {'for': 'foo'}

# Generated at 2022-06-12 08:51:58.520537
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {'X-Scheme': 'http', 'X-Forwarded-Host': 'host1.host2.host3'}
    config = {'REAL_IP_HEADER': 'X-Real-IP', 'PROXIES_COUNT': 0, 'FORWARDED_FOR_HEADER': 'X-Forwarded-For'}
    assert parse_xforwarded(headers, config) == {'proto': 'http', 'host': 'host1.host2.host3'}

# Generated at 2022-06-12 08:52:21.306485
# Unit test for function parse_forwarded
def test_parse_forwarded():

    headers = [
        'by=_secret, for=192.0.2.60, for="[2001:db8:cafe::17]", by=_secret',
        'for=192.0.2.43, by=_othersecret, for=198.51.100.17',
        'for=192.0.2.61, for="[2001:db8:cafe::19]";proto=https',
        'for=192.0.2.44, for="[2001:db8:cafe::1e]",_e=1',
    ]
    config = Dict[str, object]
    config['FORWARDED_SECRET'] = "_secret"
    config['PROXIES_COUNT'] = 1
    config['FORWARDED_FOR_HEADER'] = "x-forwarded-for"

# Generated at 2022-06-12 08:52:29.736554
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    # No X-Forwarded present
    assert parse_xforwarded({}, MagicMock()) == None
    # No X-Forwarded-For present
    assert parse_xforwarded({'X-Forwarded-Proto': 'https'}, MagicMock()) == None
    # X-Forwarded-For present, not enough proxies
    assert parse_xforwarded({'X-Forwarded-For': '127.0.0.1'}, MagicMock(PROXIES_COUNT=2)) == None
    # X-Forwarded-For present, enough proxies

# Generated at 2022-06-12 08:52:37.901371
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic import Sanic
    from sanic.config import Config
    config = Config()
    config.apply_defaults(REAL_IP_HEADER="X-Real-Ip", FORWARDED_FOR_HEADER="X-Forwarded-For", FORWARDED_SECRET=None)
    app = Sanic("sanic", config)

    from sanic.request import Request
    from sanic.response import json
    import json
    import time

    @app.route("/", methods=['POST'])
    async def test(request):
        print(request.__dict__)

# Generated at 2022-06-12 08:52:46.905938
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.app import Sanic
    h = {
        "x-scheme": "https",
        "x-forwarded-proto": "http",
        "x-forwarded-for": "172.0.0.1,52.0.0.1",
        "x-forwarded-host": "upstream1,upstream2",
        "x-forwarded-port": "80,8080",
        "x-forwarded-path": "/hello/world",
    }
    Sanic("test_parse_xforwarded").config.PROXIES_COUNT = 2

# Generated at 2022-06-12 08:52:51.788882
# Unit test for function parse_forwarded
def test_parse_forwarded():
    print(parse_forwarded("", "abcd"))
    print(parse_forwarded("secret=abcd, for=id", "abcd"))
    print(parse_forwarded("secret=abcd, for=id, by=id, proto=http", "abcd"))
    print(parse_forwarded("secret=abcd, secret=id, by=id, proto=http", "abcd"))
    print(parse_forwarded("secret=abcd, secret=abcd, by=id, proto=http", "abcd"))

# Generated at 2022-06-12 08:53:00.567619
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "http",
        "x-real-ip": "192.168.1.1",
        "x-forwarded-host": "192.168.1.1",
        "x-forwarded-port": "8888",
        "x-forwarded-path": "/",
    }

    assert parse_xforwarded(headers, {}) == {
        "by": "192.168.1.1",
        "host": "192.168.1.1",
        "for": "192.168.1.1",
        "proto": "http",
        "port": 8888,
        "path": "/",
    }



# Generated at 2022-06-12 08:53:11.123638
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic import Sanic
    from sanic.config import Config
    from sanic.request import Request
    import asynctest

    app = Sanic("test_parse_forwarded")

    @app.route("/")
    def handler(request: Request):
        return text(json.dumps(request.forwarded))

    @asynctest.fail_on(active_handles=True)
    async def test(headers_in, headers_out):
        headers = [
            ('Forwarded', 'secret=forwarded-secret; for="1.1.1.1", for="_batman"; proto=https, for="_batman"; host="foo.bar" by="_batman", for="2.2.2.2"')
        ]
        for key, value in headers_in:
            headers.append

# Generated at 2022-06-12 08:53:18.193257
# Unit test for function parse_forwarded
def test_parse_forwarded():
    config = {}
    config['FORWARDED_SECRET'] = ''
    headers = {}
    options = parse_forwarded(headers, config)
    assert options == None

    config['FORWARDED_SECRET'] = ''
    headers = {'Forwarded': ''}
    options = parse_forwarded(headers, config)
    assert options == None

    config['FORWARDED_SECRET'] = 'mysecret'
    headers = {'Forwarded': ''}
    options = parse_forwarded(headers, config)
    assert options == None

    config['FORWARDED_SECRET'] = 'mysecret'
    headers = {'Forwarded': 'secret=unknown'}
    options = parse_forwarded(headers, config)
    assert options == None

    config['FORWARDED_SECRET'] = 'mysecret'
    headers

# Generated at 2022-06-12 08:53:28.889865
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from .config import Config
    from .request import Request
    config = Config()
    config.FORWARDED_SECRET = "super-secret"
    # The by field is empty
    headers = {"forwarded": "proto=https; by="}
    req = Request("GET", "/test", headers=headers, config=config)
    assert parse_forwarded(req.headers, config) == fwd_normalize([("proto", "https")])  # noqa: E501
    # The by field matches
    headers = {"forwarded": "proto=https; by=192.168.1.1; by=super-secret; host=x; host=y"}  # noqa: E501
    req = Request("GET", "/test", headers=headers, config=config)

# Generated at 2022-06-12 08:53:37.188778
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.request import Request
    from sanic.config import Config
    from sanic.response import text
    from sanic.server import HttpProtocol
    app = Sanic('test_parse_forwarded')
    app.config.FORWARDED_SECRET = 'secret'
    headers = Headers()
    headers.add('Forwarded', 'for=192.0.2.60;proto=http;by=203.0.113.43,For=192.0.2.43, for=198.51.100.17,for=198.51.100.17;proto=https')
    request = Request('GET', '/', headers=headers)
    message, protocol, _ = HttpProtocol.request_parser(request)

# Generated at 2022-06-12 08:54:13.252468
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"forwarded": "secret=abcd by=111.222.333.444; for=111.222.333.444"}
    config = type("",(), {"FORWARDED_SECRET":"abcd"})()
    result = parse_forwarded(headers, config)
    assert result == {"by": "111.222.333.444", "for": "111.222.333.444"}

    headers1 = {"forwarded": "secret=abcd by=111.222.333.444; for=111.222.333.444"}
    config1 = type("",(), {"FORWARDED_SECRET":"abcd1"})()
    result1 = parse_forwarded(headers1, config1)
    assert result1 == None


# Generated at 2022-06-12 08:54:20.597727
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from . import config
    import json

# Generated at 2022-06-12 08:54:30.426412
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    config = Config()
    config.PROXIES_COUNT = 1
    config.REAL_IP_HEADER = 'X-Real-IP'
    config.FORWARDED_FOR_HEADER = 'X-Forwarded-For'
    config.FORWARDED_SECRET = ''
    config.FORWARDED_HOST_HEADER = ''

    from sanic.request import Request
    config = Request.config_class(config=config)
    from sanic.exceptions import NotFound

    request = Request.empty(config=Request.config_class(config=config))
    response = request.app.error_handler.response(request, NotFound())
    assert (b"HTTP/1.1 404 Not Found\r\n") in response.body