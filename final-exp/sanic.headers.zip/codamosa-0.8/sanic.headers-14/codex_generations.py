

# Generated at 2022-06-12 08:44:47.431286
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("by", "127.0.0.1")]) == {"by": "127.0.0.1"}
    assert fwd_normalize([("by", "::1")]) == {"by": "[::1]"}
    assert fwd_normalize([("by", "my.host")]) == {"by": "my.host"}
    assert fwd_normalize([("for", "127.0.0.1")]) == {"for": "127.0.0.1"}
    assert fwd_normalize([("for", "unknown")]) == {}
    assert fwd_normalize([("by", "_my.secret:123")]) == {"by": "_my.secret:123"}



# Generated at 2022-06-12 08:44:55.733372
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import json

    sanic_app = Sanic("test")
    sanic_app.config.PROXIES_COUNT = 5
    sanic_app.config.FORWARDED_SECRET =  "testsecret"
    sanic_app.config.REAL_IP_HEADER = "X-Forwarded-For"

    @sanic_app.route("/")
    def handler(request: Request) -> HTTPResponse:
        return json(request.headers)
    
    client = sanic_app.test_client
    headers = {
        "X-Forwarded-For" : "1.2.3.4"
    }
    rv = client.get("/", headers=headers)
    assert r

# Generated at 2022-06-12 08:45:02.924595
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"x-forwarded-for": "192.168.1.1"}
    print(parse_xforwarded(headers, config))
    headers = {"x-forwarded-for": "192.168.1.1", "x-forwarded-proto": "https", "x-forwarded-host": "example.org", "x-forwarded-port": "80", "x-forwarded-path": "snowman:%E2%98%83"}
    print(parse_xforwarded(headers, config))

# Generated at 2022-06-12 08:45:11.026174
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    n_tests = 100 * 1000
    import time

    for n in range(1, n_tests+1):
        headers = {
            "x-forwarded-for": "1.1.1.1",
            "x-forwarded-host": "www.example.com",
            "x-forwarded-port": "31",
            "x-forwarded-proto": "http",
            "x-scheme": "https",
        }
        parse_xforwarded(headers, None)

        if len(n_tests) >= 100:
            print(n, "executed.")

        if n % 10000 == 0:
            print(n, "sleep...")
            time.sleep(1)



# Generated at 2022-06-12 08:45:18.014162
# Unit test for function parse_content_header
def test_parse_content_header():
    assert (parse_content_header("form-data; name=upload; filename=file.txt") ==
            ('form-data', {'name': 'upload', 'filename': 'file.txt'}))
    assert (parse_content_header("form-data; name=upload; filename=\"file.txt\"") ==
            ('form-data', {'name': 'upload', 'filename': 'file.txt'}))

    assert (parse_content_header("form-data; name=upload; filename=file \\\"txt\\\"") ==
            ('form-data', {'name': 'upload', 'filename': 'file \\"txt\\"'}))

# Generated at 2022-06-12 08:45:23.917727
# Unit test for function fwd_normalize
def test_fwd_normalize():
    fwd = [('for', '127.0.0.1'), ('by', '_secretForwarder1'), ('host', 'example.com')]
    res = fwd_normalize(fwd)
    assert res['for'] == '127.0.0.1'
    assert res['by'] == '_secretForwarder1'
    assert res['host'] == 'example.com'

# Generated at 2022-06-12 08:45:33.783483
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    # forward for test
    forward_for_test = {
        'HTTP_X_FORWARDED_FOR': '10.0.0.1',
        'HTTP_X_FORWARDED_PROTO': 'https',
        'HTTP_X_FORWARDED_PORT': '443',
        'HTTP_X_FORWARDED_HOST': 'sanic.org',
        'HTTP_X_FORWARDED_PATH': '/staging/users/edit?param=1',
    }
    print(parse_xforwarded(forward_for_test, None))

    # forwarded fot test

# Generated at 2022-06-12 08:45:45.256188
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:45:53.549779
# Unit test for function parse_forwarded
def test_parse_forwarded():
    h = [
        'for="[::1]:1234";by=_secret;proto=http:;host=localhost;path="/proto"',
        'for="[::1]:1234";by=_secret;proto=http:;host=localhost;path="/path"',
    ]
    assert parse_forwarded(h, "") is None
    assert parse_forwarded(h, "_secret") == {
        'for': '[::1]:1234', 'by': '_secret', 'proto': 'http:', 'host': 'localhost', 'path': '/path'}

# Generated at 2022-06-12 08:45:58.305205
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"forwarded": ["for=192.0.2.1,for=192.0.2.2,for=192.0.2.3"]}
    config = {"FORWARDED_SECRET": "12345"}
    print(parse_forwarded(headers, config))


# Generated at 2022-06-12 08:46:16.232156
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:46:19.715689
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    opts = parse_xforwarded({"X-Forwarded-For":"127.0.0.1", "X-Forwarded-For": "10.10.10.10"}, 5)
    print(opts)
    assert opts["for"] == "10.10.10.10"

# Generated at 2022-06-12 08:46:30.739509
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {'x-forwarded-for': '127.0.0.1', 'x-forwarded-host': 'host', 'x-forwarded-port': '1234', 'x-forwarded-path': 'path'}
    config = {'REAL_IP_HEADER': 'x-forwarded-for', 'PROXIES_COUNT': '3'}
    result = parse_xforwarded(headers, config)
    assert result['for'] == '127.0.0.1'
    assert result['host'] == 'host'
    assert result['port'] == 1234
    assert result['path'] == 'path'


# Generated at 2022-06-12 08:46:39.207875
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = [
        "By=_secret;For=192.0.2.60;Proto=https;Host=example.com;Port=80",
        "For=\"_secret\", for=192.0.2.61;proto=http;",
        "for=192.0.2.62, by=_secret;",
        "for=192.0.2.63;By=_secret",
    ]

    for h in headers:
        a = parse_forwarded(h, "192.0.2.60:80")
        assert a["for"] == "192.0.2.60"
        assert a["host"] == "example.com"
        assert a["proto"] == "https"
        assert a["port"] == 80


# Generated at 2022-06-12 08:46:50.801644
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:46:59.761753
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60; proto=http; by=203.0.113.43",
            "for=192.0.2.43, for=\"[2001:db8:cafe::17]\";by=203.0.113.60"
        ]
    }
    # simple test
    assert parse_forwarded(headers, {
        "PROXIES_COUNT": 3,
        "FORWARDED_SECRET": "203.0.113.43"
    }) == {
        "for": "192.0.2.60",
        "proto": "http",
        "by": "203.0.113.43"
    }
    # CIDR test for for=

# Generated at 2022-06-12 08:47:11.628734
# Unit test for function fwd_normalize
def test_fwd_normalize():
    import unittest
    class FwdNormalizeTest(unittest.TestCase):
        def check(self, src, out):
            self.assertEqual(src, fwd_normalize(src.items()))
        def test_empty(self):
            self.check({}, {})
        def test_nodel(self):
            self.check({"proto": "http"}, {"proto": "http"})
        def test_del_none(self):
            self.check({"proto": None}, {})
        def test_del_empty(self):
            self.check({"proto": ""}, {})
        def test_del_unknown(self):
            self.check({"for": "unknown"}, {})

# Generated at 2022-06-12 08:47:20.372747
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    h = {
        'x-forwarded-host': 'apple.com',
        'x-forwarded-proto': 'https://',
        'x-scheme': 'http://',
        'x-forwarded-path': 'abc',
        'x-forwarded-port': '80',
    }
    ret = parse_xforwarded(h, {
        "REAL_IP_HEADER": None,
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "x-forwarded-for",
    })
    assert ret == {'host': 'apple.com', 'proto': 'http://', 'path': 'abc', 'port': 80}


# Generated at 2022-06-12 08:47:25.048510
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([("for", "1.1.1.1"), ("by", "test")]) == {
        "proto": "http",
        "host": "test",
        "for": "1.1.1.1",
        "by": "test",
        "path": "/",
        "port": None,
    }
    assert fwd_normalize([("for", "1.1.1.1"), ("by", "test2")]) == {
        "for": "1.1.1.1",
        "by": "test2",
    }
    assert fwd_normalize([("for", "test3"), ("by", "test2")]) == {
        "for": "test3",
        "by": "test2",
    }

# Generated at 2022-06-12 08:47:30.450845
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test each line of the function parse_forwarded
    assert parse_forwarded( {"Forwarded":""}, {}) is None
    assert parse_forwarded( {"Forwarded":"by=192.0.2.43, for=\"[::1]:8000\""}, {}) is None

    config = {}
    config['FORWARDED_SECRET'] = '0f0f0f'
    assert parse_forwarded( {"Forwarded": "secret=0f0f0f; by=192.0.2.43, for=\"[::1]:8000\""}, config) is not None

    assert parse_forwarded( {"Forwarded":"for=\"0f0f0f\", for=\"192.0.2.43\""}, config) is None

# Generated at 2022-06-12 08:47:46.871948
# Unit test for function parse_forwarded
def test_parse_forwarded():
    '''
    f_header, f_secret, expected
    '''

# Generated at 2022-06-12 08:47:56.450751
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '8.8.8.8',
        'x-forwarded-host': 'example.org',
        'x-forwarded-port': '443',
        'x-forwarded-path': '/path/to/nowhere',
        'x-scheme': 'https',
        'x-forwarded-proto': 'https, http'
    }

# Generated at 2022-06-12 08:48:07.609553
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    # simple case
    headers = {'x-forwarded-for': '192.168.1.1'}
    config = {'REAL_IP_HEADER': 'x-forwarded-for', 'FORWARDED_FOR_HEADER': 'x-forwarded-for', 'PROXIES_COUNT': 1}
    assert parse_xforwarded(headers, config) == {'for': '192.168.1.1'}

    # simple case with multiple headers
    headers = {'x-forwarded-for': ['192.168.1.1', '192.168.1.2', '192.168.1.3']}

# Generated at 2022-06-12 08:48:14.473076
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"Forwarded": "for=[2001:db8:cafe::17]:4711;proto=https,for=192.0.2.60;proto=https;by=203.0.113.43"}
    assert parse_forwarded(headers, 'config') == {
        "for": "[2001:db8:cafe::17]",
        "proto": "https",
        "by": "192.0.2.60",
    }

# Generated at 2022-06-12 08:48:21.158240
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    header = {'X-Forwarded-For': '127.0.0.1'}
    config = {}
    config['REAL_IP_HEADER'] = 'X-Forwarded-For'
    config['PROXIES_COUNT'] = 1
    config['FORWARDED_FOR_HEADER'] = 'X-Forwarded-For'
    assert parse_xforwarded(header, config) == {'for': '127.0.0.1'}



# Generated at 2022-06-12 08:48:27.435586
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import random, string
    def gen_str(n):
        return ''.join(random.choice(string.ascii_letters) for _ in range(n))

    # empty input
    assert parse_forwarded({}, None) is None
    # empty header
    assert parse_forwarded({'Forwarded': ''}, None) is None
    # no secret
    assert parse_forwarded({'Forwarded': 'for= for="\\"for\\""'}, None) is None
    assert parse_forwarded({'Forwarded': 'by= for="\\"for\\""'}, None) is None
    # missing secret
    assert parse_forwarded({'Forwarded': 'by= for="\\"for\\""'}, "secret") is None
    # partial secret

# Generated at 2022-06-12 08:48:37.422086
# Unit test for function fwd_normalize
def test_fwd_normalize():
    # From the Forwarded spec:
    # https://tools.ietf.org/html/rfc7239#section-4
    # They are ready for parsing w/o `fwd_normalize` function
    assert fwd_normalize([("by", "unknown")]) == {"by": "unknown"}
    assert fwd_normalize([("by", "192.0.2.60")]) == {"by": "192.0.2.60"}
    assert fwd_normalize([("path", "foo")]) == {"path": "foo"}

# Generated at 2022-06-12 08:48:45.526499
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    assert parse_xforwarded({
        'X-Forwarded-Host': 'baz.bar.com',
        'X-Forwarded-Port': 80,
        'X-Forwarded-Path': '/path/to/stuff',
        'X-Forwarded-Proto': 'https',
        'Real-Ip': '1.2.3.4'
    }, {}) == {
        'proto': 'https',
        'host': 'baz.bar.com',
        'port': 80,
        'path': '/path/to/stuff',
        'for': '1.2.3.4'
    }


# Generated at 2022-06-12 08:48:52.436821
# Unit test for function parse_xforwarded
def test_parse_xforwarded():

    headers = {
        'forwarded': ['X-Forwarded-For: 1.1.1.1, 2.2.2.2'],
        'x-scheme': 'http',
        'x-forwarded-host': 'host',
        'x-forwarded-port': '80',
        'x-forwarded-path': '/'
    }

    print(parse_xforwarded(headers))

if __name__ == '__main__':
    test_parse_xforwarded()

# Generated at 2022-06-12 08:49:02.086882
# Unit test for function parse_forwarded
def test_parse_forwarded():
    options = parse_forwarded('for=192.0.2.60;proto=http;host=www.example.com', '127.0.0.1')
    assert options['by'] == '127.0.0.1'
    assert options['for'] == '192.0.2.60'
    assert options['proto'] == 'http'
    assert options['host'] == 'www.example.com'
    assert options.get('port') == None
    assert options.get('path') == None
    options = parse_forwarded('FOR=192.0.2.61;Proto=https;HOST=www.example.com', '127.0.0.1')
    assert options['by'] == '127.0.0.1'
    assert options['for'] == '192.0.2.61'

# Generated at 2022-06-12 08:49:18.621179
# Unit test for function parse_forwarded
def test_parse_forwarded():
    c = AttrDict()
    c.FORWARDED_SECRET = "mysecret"
    c.REAL_IP_HEADER = False
    c.PROXIES_COUNT = 1

    def run_test(header, target):
        assert parse_forwarded({"Forwarded": header}, c) == target

    run_test("for=192.0.2.60;proto=http;by=203.0.113.43", {
        'for': '192.0.2.60',
        'proto': 'http',
        'by': '203.0.113.43'
    })

# Generated at 2022-06-12 08:49:24.573176
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    test_headers = {
        'X-Forwarded-For': '255.255.255.255',
        'X-Forwarded-Host': 'hogehoge.com',
        'X-Forwarded-Port': '4321',
        'X-Forwarded-Proto': 'http',
        'X-Scheme': 'https'
    }

    result = parse_xforwarded(test_headers, object)
    print(result)


if __name__ == "__main__":
    test_parse_xforwarded()

# Generated at 2022-06-12 08:49:34.657352
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": [
            "for=\"129.78.138.66\";by=203.0.113.43",
            "for=\"129.78.138.66\",proto=http;by=203.0.113.43,",
            "for=\"192.1.2.3\";proto=http,for=192.0.2.43;proto=https",
            "For=\"[2001:db8:cafe::17]:4711\";proto=https,for=\"[2001:db8:cafe::17]\";proto=https,for=unknown",
            "for=129.78.138.66;proto=http;by=\"[203.0.113.43]\"",
        ]
    }

# Generated at 2022-06-12 08:49:45.896994
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    xforwarded_for_header = 'for=192.0.2.60; proto=https, for=192.0.2.43; proto=https, for=198.51.100.17'
    xforwarded_host_header = 'example.com'
    xforwarded_proto_header = 'https'
    xforwarded_port_header = '8765'
    xforwarded_path_header = '/test'

# Generated at 2022-06-12 08:49:56.602158
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from collections import namedtuple
    from unittest.mock import patch

    from sanic import Sanic
    from sanic.testing import SanicTestClient

    class MockRequest:
        headers = {'Forwarded': 'For=192.0.2.43, for="[2001:db8:cafe::17]:4711";'
                                'proto=https, host=myhost; secret=secret123'}

    app = Sanic('myapp')

    @app.route('/')
    def handler(request):
        # We mock request.raw_args because this is set before forwarded
        # parsing and it should not influence the parsing
        with patch.object(request, 'raw_args', return_value={}):
            request['forwarded'] = parse_forwarded(request, request.app)
            return None

   

# Generated at 2022-06-12 08:50:07.237634
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic import Sanic
    from sanic.request import Request
    app = Sanic(__name__)
    app.config.FORWARDED_SECRET = None


# Generated at 2022-06-12 08:50:17.364771
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from sanic.request import BaseRequest

    headers = {
        'x-forwarded-for': '1.1.1.1, 2.2.2.2, 3.3.3.3, 4.4.4.4',
        'x-forwarded-host': 'example-host'
    }

    request = BaseRequest(headers=headers)
    config = Config(
        REAL_IP_HEADER=None,
        FORWARDED_FOR_HEADER='x-forwarded-for',
        FORWARDED_SECRET=None,
        PROXIES_COUNT=3
    )

    xforwarded = parse_xforwarded(request.headers, config)

    assert xforwarded['by'] == '1.1.1.1'

# Generated at 2022-06-12 08:50:27.690642
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from .constants import HEADER_X_FORWARDED_FOR, HEADER_X_FORWARDED_HOST, HEADER_X_FORWARDED_PORT, HEADER_X_FORWARDED_PROTO, HEADER_X_FORWARDED_PATH, HEADER_X_FORWARDED_SERVER, HEADER_X_FORWARDED_BY, HEADER_X_FORWARDED_PROTOCOL, HEADER_X_FORWARDED_PROTO_VERSION, HEADER_X_FORWARDED_FOR_PROTO, HEADER_X_FORWARDED_FOR_PROTO_VERSION
    import sanic.config
    sanic_config = sanic.config.Config()
    sanic_config.PROXIES_COUNT = 3
    sanic_config.REAL_IP_HEADER = HEADER_X_

# Generated at 2022-06-12 08:50:38.120440
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"X-Forwarded-For": "192.0.2.60, 2001:db8::ff00:42:8329",
               "X-Forwarded-Proto": "https",
               "X-Forwarded-Host": "example.com",
               "X-Forwarded-Port": "443",
               "X-Forwarded-Path": "/path/to/resource"}
    config = {"PROXIES_COUNT": 2}
    fwd = parse_xforwarded(headers, config)
    assert fwd["for"] == "2001:db8::ff00:42:8329"
    assert fwd["proto"] == "https"
    assert fwd["host"] == "example.com"
    assert fwd["port"] == 443
    assert fwd["path"] == "/path/to/resource"

   

# Generated at 2022-06-12 08:50:43.244721
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': ['host=abc;host=def;host=ghi;port=80','host=def','secret=123','host=jkl','by=192.168.1.101','host=mno','host=pqr','by=192.168.1.100']}
    config = {'FORWARDED_SECRET':'123'}
    print(parse_forwarded(headers, config))

if __name__ == '__main__':
    test_parse_forwarded()

# Generated at 2022-06-12 08:50:55.513224
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    return

# Generated at 2022-06-12 08:51:06.828039
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded':['for=192.0.2.43;proto=http;by=example.org, for="[2001:db8:cafe::17]";proto=https;by=\\"other.example.org\\"']} 
    config = {'PROXIES_COUNT':'6','FORWARDED_SECRET':'"secret"'}
    ret = parse_forwarded(headers, config)
    assert ret == {'for': '192.0.2.43', 'proto': 'http', 'by': 'example.org'}, "forwarded parse error"
    
    
    

if __name__ == '__main__':
    test_parse_forwarded()

# Generated at 2022-06-12 08:51:17.187377
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'forwarded': 'for=198.51.100.17; proto=https; by=103.230.156.108; host=example.org; fwd="200.1.2.3, 2001:db8::c001, 192.0.2.42"'}
    config = {'FORWARDED_SECRET': 'e2b94c1e-3d3f-4aa9-9780-febc81f82b55'}
    res = parse_forwarded(headers, config)
    print(res)
    assert res['for'] == '198.51.100.17'
    assert res['proto'] == 'https'
    assert res['host'] == 'example.org'
    assert res['by'] == '103.230.156.108'

# Generated at 2022-06-12 08:51:28.172705
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    assert parse_xforwarded({ 'X-Forwarded-For': '1.1.1.1' }, { 'PROXIES_COUNT': 1, 'FORWARDED_FOR_HEADER': 'X-Forwarded-For', 'REAL_IP_HEADER': 'X-Real-IP'}) == fwd_normalize([('for', '1.1.1.1')])

# Generated at 2022-06-12 08:51:37.681658
# Unit test for function parse_forwarded
def test_parse_forwarded():
    print("Testing function parse_forwarded")

# Generated at 2022-06-12 08:51:44.398473
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:51:54.618495
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"Forwarded": ["for=192.0.2.43, for=\"[2001:db8:cafe::17]\""]}
    config = {"FORWARDED_SECRET": "forwarded-secret"}
    result = parse_forwarded(headers, config)
    assert result == {"for": "192.0.2.43"}

    headers = {
        "Forwarded": ["for=192.0.2.43, for=\"[2001:db8:cafe::17]\", secret=forwarded-secret"]
    }
    config = {"FORWARDED_SECRET": "forwarded-secret"}
    result = parse_forwarded(headers, config)
    assert result == {"for": "192.0.2.43", "secret": "forwarded-secret"}

# Generated at 2022-06-12 08:52:03.751960
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {'x-scheme': 'https', 'x-forwarded-host': 'www.abc.com', 'x-forwarded-path': '/abc/def', 'x-forwarded-port': '443', 'x-forwarded-proto': 'https', 'x-forwarded-for': '192.168.11.100, 192.168.11.101, 192.168.11.102'}
    config = {'REAL_IP_HEADER': None, "FORWARDED_FOR_HEADER": 'x-forwarded-for', "PROXIES_COUNT": 0, "FORWARDED_SECRET": None}
    print(parse_xforwarded(headers, config))

if __name__ == '__main__':
    test_parse_xforwarded()

# Generated at 2022-06-12 08:52:10.575435
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    # some test cases
    headers = {
        "X-FORWARDED-FOR": "127.0.0.1",
        "X-FORWARDED-HOST": "example.com",
        "X-FORWARDED-PORT": "80",
        "X-FORWARDED-PATH": "/test",
    }
    assert parse_xforwarded(headers, config=Config()) == {
        "for": "127.0.0.1",
        "host": "example.com",
        "port": 80,
        "path": "/test",
    }


# Generated at 2022-06-12 08:52:19.749300
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    """Unit tests for function parse_xforwarded"""
    config = EnvironBuilder()
    headers = EnvironBuilder()

    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.REAL_IP_HEADER = "X-Real-IP"

    # : One proxy, no X-Real-IP
    headers.set("X-Forwarded-For", "127.0.0.1")
    ret = parse_xforwarded(headers, config)
    assert "for" in ret
    assert ret["for"] == "127.0.0.1"

    # : Two proxies, no X-Real-IP
    headers.set("X-Forwarded-For", "127.0.0.1, 127.0.0.2")
    ret = parse_xforwarded(headers, config)

# Generated at 2022-06-12 08:52:41.271155
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    config = {
        "FORWARDED_FOR_HEADER": "X-Forwarded-For",
        "FORWARDED_HOST_HEADER": "X-Forwarded-Host",
        "FORWARDED_PORT_HEADER": "X-Forwarded-Port",
        "FORWARDED_PROTO_HEADER": "X-Forwarded-Proto",
        "FORWARDED_PROTO_SECURE": "https",
    }
    headers = {
        "X-Forwarded-For": "172.68.1.1, 172.68.1.2",
        "X-Forwarded-Host": "192.168.1.101",
        "X-Forwarded-Port": "443",
        "X-Forwarded-Proto": "http",
    }

# Generated at 2022-06-12 08:52:49.711291
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        'forwarded': [
            'for=192.0.2.60;proto=http;by=203.0.113.43,Forwarded:for=_myhost, Forwarded:for=192.0.2.43, for=unknown;proto=http;by=203.0.113.43',
            'for=192.0.2.43',
            'for=198.51.100.17;by=203.0.113.60'
        ]
    }
    config = {'FORWARDED_SECRET': 'secret'}
    normal_result = {'for': '192.0.2.43', 'by': 'secret', 'proto': 'http'}
    assert parse_forwarded(headers, config) == normal_result

# Generated at 2022-06-12 08:52:59.516575
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'Host:8443;proto=https,For="_abc.134";by=10.0.0.1;For="[2001:db8:cafe::17];proto=http;host=site.com;by=192.0.2.60,for=192.0.2.60;proto=http;by=203.0.113.43,for=203.0.113.43;by="secret"'}
    config = {'FORWARDED_SECRET':'secret'}
    r = parse_forwarded(headers, config)
    assert(r == {'host': 'site.com', 'proto': 'http', 'for': '203.0.113.43', 'by': '192.0.2.60'})

# Run all tests

# Generated at 2022-06-12 08:53:10.195438
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43,for=127.0.0.1']}
    config = {'FORWARDED_SECRET': 'secret'}
    res = parse_forwarded(headers, config)
    assert res == {'for': '127.0.0.1', 'proto': 'http'}
    headers = {'Forwarded': ['for=192.0.2.60;proto=http;by=203.0.113.43']}
    res = parse_forwarded(headers, config)
    assert res == None
    headers = {'Forwarded': ['for=192.0.2.60;proto=http;by=secret']}
    res = parse_forwarded(headers, config)

# Generated at 2022-06-12 08:53:12.776942
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    assert parse_xforwarded({"X-Forwarded-For": "10.12.15.2, 10.12.15.3, 1.1.1.1"}, {}) == None

# Generated at 2022-06-12 08:53:19.001594
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test with a correct Forwarded HTTP Header
    correct_forwarded_header = [
        "for=\"_gazonk\"; by=_username; protocol=https; host=example.com;",
        "proto=https",
    ]
    result = parse_forwarded(
        {  # Dummy "headers" object with getall() method
            "forwarded": correct_forwarded_header
        },
        {"FORWARDED_SECRET": "_username"},
    )
    assert result is not None
    assert result["for"] == "_gazonk"
    assert result["by"] == "_username"
    assert result["protocol"] == "https"
    assert result["host"] == "example.com"

    # Test with a correct Forwarded HTTP Header, with some extra info

# Generated at 2022-06-12 08:53:24.740379
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.app import Sanic
    from sanic.request import Request
    app = Sanic()

    @app.route('/')
    async def test(request: Request):
        return request.headers

    _, response = app.test_client.get('/', headers={'X-Forwarded-Host': 'hello'})
    assert response.status == 200
    assert response.json['X-Forwarded-Host'] == 'hello'

# Generated at 2022-06-12 08:53:34.913175
# Unit test for function parse_forwarded
def test_parse_forwarded():
    def assertForwarded(string: str, expected: Options):
        assert parse_forwarded([string], Config()) == expected
        assert parse_forwarded([string, string], Config()) == expected
        assert parse_forwarded(["secret=" + string], Config()) == expected

    assertForwarded(
        "secret=123, for=127.0.0.2; by=192.168.0.1; host=example.com:443; proto=https; path=/some/path",
        {"for": "127.0.0.2", "by": "192.168.0.1", "host": "example.com", "proto": "https", "port": 443, "path": "/some/path"},
    )

# Generated at 2022-06-12 08:53:42.090124
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {'Forwarded': 'for="_gazonk" ,  by=203.0.113.43 ;proto=https;host=example.com;port=80,For=" [ 2001:db8:cafe::17 ] ";proto=https'}
    result = parse_forwarded(headers, None)
    print(result)
    assert result['for'] == '_gazonk'
    assert result['by'] == '203.0.113.43'
    assert result['proto'] == 'https'
    assert result['host'] == 'example.com'
    assert result['port'] == '80'

# Generated at 2022-06-12 08:53:52.465992
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = { 'Forwarded' : ['for=192.0.2.43, for=198.51.100.17;proto=http, for=unknown, for=2001:db8:cafe::17']}
    config = { 'FORWARDED_SECRET' : 'supersecret' }
    expected = {'for': '2001:db8:cafe::17', 'proto': 'http'}
    assert expected == parse_forwarded(headers, config)

    headers = { 'Forwarded' : ['for=192.0.2.43, for=198.51.100.17;proto=http, for=unknown, for=_hyphens--ok!;proto=https']}
    config = { 'FORWARDED_SECRET' : 'supersecret' }

# Generated at 2022-06-12 08:54:26.782319
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import json

    FORWARDED_SECRET = "ToXEn"
    headers = {"Forwarded": "By=_ToXEn_;For=50.63.202.32;Proto=HTTPS", "Host": "0.0.0.0:8000"}
    config = type("Config", (), {"FORWARDED_SECRET": FORWARDED_SECRET})()
    print(json.dumps(parse_forwarded(headers, config), indent=4))
    headers = {"Forwarded": ["By=_ToXEn2_;For=50.63.202.32;Proto=HTTPS"], "Host": "0.0.0.0:8000"}
    config = type("Config", (), {"FORWARDED_SECRET": "ToXEn2"})()

# Generated at 2022-06-12 08:54:35.765985
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-forwarded-for": "42.42.42.42",
        "x-forwarded-host": "example.org",
        "x-forwarded-proto": "hTtPs",
        "x-forwarded-path": "http%3A%2F%2Fexample.org%2Ftest%3Ftest=test",
        "x-scheme": "http",
    }
    config = type(
        "config", (), {
            "PROXIES_COUNT": 0,
            "REAL_IP_HEADER": None,
            "FORWARDED_SECRET": None,
        }
    )()