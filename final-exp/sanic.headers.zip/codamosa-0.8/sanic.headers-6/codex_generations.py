

# Generated at 2022-06-12 08:44:50.821274
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    config = Config()
    config.FORWARDED_FOR_HEADER = 'X-Forwarded-For'
    config.REAL_IP_HEADER = 'X-Real-IP'
    config.PROXIES_COUNT = 1
    from sanic.request import Request
    headers = {
        'X-Forwarded-For': '1.2.3.4, 2.3.4.5',
        'X-Real-IP': '5.5.5.5',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Forwarded-Path': '/foo/bar',
        'X-Forwarded-Host': 'example.com',
        'X-Scheme' : 'http'
    }
   

# Generated at 2022-06-12 08:45:02.453901
# Unit test for function fwd_normalize_address
def test_fwd_normalize_address():
    assert fwd_normalize_address("192.168.1.1") == "192.168.1.1"
    assert fwd_normalize_address("_dev.example.com") == "_dev.example.com"
    assert fwd_normalize_address("2001:db8:85a3:8d3:1319:8a2e:370:7348") == "[2001:db8:85a3:8d3:1319:8a2e:370:7348]"


if __name__ == "__main__":
    import sys
    import traceback
    import types
    
    # For pytest to work
    sys.argv = [sys.argv[0], __file__]
    all_tests = {}

# Generated at 2022-06-12 08:45:12.389880
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:45:22.486566
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    import copy
    from sanic.request import Headers

    headers = Headers()
    content = {
        "REAL_IP_HEADER": "X-Real-IP",
        "PROXIES_COUNT": 1,
        "FORWARDED_FOR_HEADER": "X-Forwarded-For"
    }

    headers["X-Real-IP"] = "192.168.1.1"
    parsed_headers = parse_xforwarded(headers, copy.deepcopy(content))
    assert parsed_headers["for"] == "192.168.1.1"

    headers["X-Forwarded-For"] = "192.168.1.2"
    parsed_headers = parse_xforwarded(headers, copy.deepcopy(content))
    assert parsed_headers["for"] == "192.168.1.2"

# Generated at 2022-06-12 08:45:32.683692
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize([]) == {}
    assert fwd_normalize([("for", b"foo")]) == {"for": "foo"}
    assert fwd_normalize([("proto", "hTTp")]) == {"proto": "http"}
    assert fwd_normalize([("proto", "hTTpS")]) == {"proto": "https"}
    assert (
        fwd_normalize(
            [("proto", "http"), ("proto", "https")]
        ) == {"proto": "https"}
    )
    assert fwd_normalize([("host", " bAr.com\t")]) == {"host": "bar.com"}
    assert fwd_normalize([("port", "4242")]) == {"port": 4242}

# Generated at 2022-06-12 08:45:43.710259
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # init the test env
    config = Mock()
    config.FORWARDED_SECRET = "secret1;key1=value1,secret2;key2=value2"
    header = Mock()
    header.getall = Mock(return_value = ["secret1;key1=value1,secret2;key2=value2"])
    request = Mock()
    request.headers = header

    # init expected result
    expected_result = {"key2":"value2"}

    # call parse_forwarded
    result = parse_forwarded(request.headers, config)

    assert result == expected_result

    # init the test env
    config = Mock()
    config.FORWARDED_SECRET = "secret1;key1=value1,secret2;key2=value2"
    header = Mock()
    header.getall

# Generated at 2022-06-12 08:45:47.417509
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {"Forwarded": "By=192.0.2.60; forwarding=192.0.2.60; proto=http"}
    assert parse_forwarded(headers) == {
        "by": "192.0.2.60",
        "for": "192.0.2.60",
        "proto": "http",
    }

# Generated at 2022-06-12 08:45:58.344849
# Unit test for function fwd_normalize
def test_fwd_normalize():
    """Unit test for function fwd_normalize"""
    fwd = parse_forwarded({'Forwarded': 'for=192.0.2.43, for=[2001:db8:cafe::17]; proto=https, by=203.0.113.43; host="[2001:db8:cafe::17]:443"', 'Other': 'forwarded, not-forwarded'}, config)
    assert fwd_normalize(fwd) == {'for':'192.0.2.43', 'proto':'https', 'by':'203.0.113.43', 'host':'[2001:db8:cafe::17]', 'port':'443', 'path':'[2001:db8:cafe::17]'}

# Generated at 2022-06-12 08:46:08.754044
# Unit test for function parse_forwarded
def test_parse_forwarded():
    print("parse_forwarded(headers)={}".format(parse_forwarded("", "")))
    assert parse_forwarded("","") == None
    assert parse_forwarded("","secret") == None
    assert parse_forwarded("for=192.0.2.60; proto=http; by=203.0.113.43; secret=123","1337") == None
    assert parse_forwarded("for=192.0.2.60; proto=http; by=203.0.113.43; secret=1337","mt5") == None

# Generated at 2022-06-12 08:46:14.533783
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    class FakeHeaders():
        def get(self, key):
            headers = {
                "X-Forwarded-For": "127.0.0.1, 1.1.1.1, 2.2.2.2",
                "X-Forwarded-Host": "1111.com",
                "X-Forwarded-Port": "80",
                "X-Forwarded-Scheme": "HTTPS",
                "X-Forwarded-Path": "/c/d"
            }
            return headers.get(key)

    headers = FakeHeaders()
    config = Config()
    config.PROXIES_COUNT = 3
    print(parse_xforwarded(headers, config))

# Generated at 2022-06-12 08:46:30.787037
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    config = Config()
    config.PROXIES_COUNT = 2
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.FORWARDED_PROTO_HEADER = "X-Forwarded-Proto"
    config.FORWARDED_HOST_HEADER = "X-Forwarded-Host"
    config.FORWARDED_PORT_HEADER = "X-Forwarded-Port"
    config.FORWARDED_PATH_HEADER = "X-Forwarded-Path"
    config.REAL_IP_HEADER = "X-Real-IP"

    #Test the headers in the order which they might be received

# Generated at 2022-06-12 08:46:39.458351
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:46:51.116893
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Test parsing of forwarded headers according to RFC 7239
    headers = {}
    assert parse_forwarded(headers, config) is None
    assert parse_xforwarded(headers, config) is None
    # Test parsing of simple values
    headers = {"forwarded": ["for=192.0.2.60;proto=https;by=203.0.113.43"]}
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.60",
        "proto": "https",
    }
    headers = {
        "forwarded": ["for=192.0.2.43, for=\"[2001:db8:cafe::17]\";proto=http;by=203.0.113.43"]
    }

# Generated at 2022-06-12 08:46:57.819200
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    header = {}
    header['X-Forwarded-For'] = "192.168.1.1"
    header['X-Forwarded-Host'] = "192.168.1.1"
    header['X-Forwarded-Port'] = "80"
    header['X-Forwarded-Proto'] = 'http'

    options = parse_xforwarded(header, 'api')
    assert options == {'for': '192.168.1.1', 'host': '192.168.1.1', 'port': 80, 'proto': 'http'}

# Generated at 2022-06-12 08:47:09.060914
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:47:19.500434
# Unit test for function fwd_normalize
def test_fwd_normalize():
    assert fwd_normalize_address("192.0.2.30") == "192.0.2.30"
    assert fwd_normalize_address("[2001:db8::30]") == "[2001:db8::30]"
    assert fwd_normalize_address("_8f6W9AWv") == "_8f6W9AWv"
    assert fwd_normalize_address("Unknown") == "unknown"
    assert fwd_normalize_address("unknown") == "unknown"
    assert fwd_normalize_address("UNKNOWN") == "unknown"

    assert fwd_normalize([("secret", "not"), ("secret", "secret")]) == {}
    assert fwd_normalize([("secret", "secret"), ("secret", "not")]) == {}


# Generated at 2022-06-12 08:47:23.928414
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from typing import Dict, Any
    
    headers = [('X-Scheme', 'http'), ('X-Forwarded-For', '1.1.1.1'), ('X-Forwarded-Proto', 'https'),
               ('X-Forwarded-Host', 'hostname'), ('X-Forwarded-Port', '8000'), ('X-Forwarded-Path', '/path')]
    d = dict(headers)
    config = {
            'REAL_IP_HEADER': "X-Scheme",
            'FORWARDED_FOR_HEADER': "X-Forwarded-For",
            'FORWARDED_SECRET': ""
        }
    a = parse_xforwarded(d, config)   # returns a dictionary
    print(a)

# Generated at 2022-06-12 08:47:32.469560
# Unit test for function parse_forwarded
def test_parse_forwarded():
    config = {}
    config["FORWARDED_SECRET"] = 'secret-key'
    headers = {}
    headers["forwarded"] = [
        'By=secret-key; For=127.0.0.1; Host=hostname.com; Proto=https; Port=443; Path=abc',
        'By=secret-key;Proto=https',
        'By="secret-key";For="_obf_addr_";Proto="https"',
        'By=;For=127.0.0.1;Proto=https'
    ]
    result = parse_forwarded(headers, config)
    assert result == {'for': '127.0.0.1', 'proto': 'https', 'host': 'hostname.com', 'port': 443, 'path': 'abc'}


# Generated at 2022-06-12 08:47:43.416054
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic import Sanic
    from sanic.response import json
    from sanic.config import Config
    config = Config()
    config.REAL_IP_HEADER = None
    config.PROXIES_COUNT = 0
    config.FORWARDED_FOR_HEADER = None
    config.FORWARDED_SECRET = None

    app = Sanic('test_parse_forwarded')

    @app.route("/hello")
    async def test(request):
        forwarded_header = request.headers.get("Forwarded", None)
        real_ip_header = request.headers.get("X-Real-IP", None)
        forwarded_for_header = request.headers.get("X-Forwarded-For", None)


# Generated at 2022-06-12 08:47:53.898425
# Unit test for function parse_forwarded

# Generated at 2022-06-12 08:48:13.656292
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    # Set up Sanic app
    from sanic import Sanic
    from sanic.config import Config
    from sanic.request import Request
    from sanic.response import HTTPResponse
    app = Sanic()
    app.config.from_object(Config)

    @app.route("/test", methods=["GET", "PUT", "POST", "DELETE"])
    async def test(request: Request):
        """Test function, used as example of function parse_xforwarded.
        """
        request.app.config.PROXIES_COUNT = 2
        request.app.config.FORWARDED_FOR_HEADER = "x-forwarded-for"
        request.app.config.REAL_IP_HEADER = "x-real-ip"

        # Check if host and port are properly parsed
       

# Generated at 2022-06-12 08:48:23.762036
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-scheme': 'http',
        'x-forwarded-host': 'localhost:8000',
        'x-forwarded-port': '443',
        'x-forwarded-proto': 'https',
        'x-forwarded-path': '/api/v1',
        'REAL_IP_HEADER': '',
        'PROXIES_COUNT': 1,
        'FORWARDED_FOR_HEADER': ''
    }
    config = type('config', (object,), {})()
    config.REAL_IP_HEADER = ''
    config.PROXIES_COUNT = 1
    config.FORWARDED_FOR_HEADER = ''
    assert parse_xforwarded(headers, config) == {}


# Generated at 2022-06-12 08:48:33.553020
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import pytest

    headers = {
        "FORWARDED": [
            "for=192.0.2.60;proto=http;host='for_host'",
            "for=192.0.2.60;by=_secret;proto=http;secret=_secret",
            "for=192.0.2.60;by=_secret;proto=http;secret=_secret;proto=https",
        ]
    }

    assert parse_forwarded(headers, None) == {
        "for": "192.0.2.60",
        "by": "_secret",
        "proto": "https",
    }

# Generated at 2022-06-12 08:48:34.129079
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    return True

# Generated at 2022-06-12 08:48:37.469373
# Unit test for function parse_content_header
def test_parse_content_header():
    ct = 'form-data; name="upload"; filename="file.txt"'
    ct = "text/plain"
    res = parse_content_header(ct)
    print(res)
    # ('text/plain', {})


# Generated at 2022-06-12 08:48:42.086181
# Unit test for function parse_forwarded
def test_parse_forwarded():
    """Function parse_forwarded"""
    import pytest

    fw_headers = {
        "secret": {
            "secret=secret": {"secret": "secret"},
            "secret=secret,host=foo": {"host": "foo", "secret": "secret"},
            "by=other,host=foo": None,
            "for=127.0.0.1": {"for": "127.0.0.1"},
        },
        "none": {
            "secret=secret": None,
            "for=127.0.0.1": None,
            "host=foo": None,
            "host=foo,secret=secret": None,
        },
    }
    # format is:
    #   {"header": x, "expected_output": y}

# Generated at 2022-06-12 08:48:52.486577
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import sanic
    app = sanic.Sanic()
    app.config.FORWARDED_SECRET = "secret"

    result = parse_forwarded(
        {
            "Forwarded": "For=1.2.3.4, For=5.6.7.8; By=9.10.11.12; Host=abc; Proto=https, By=secret"
        },
        app.config,
    )
    assert result == {"by": "9.10.11.12", "for": "1.2.3.4", "host": "abc", "proto": "https"}


# Generated at 2022-06-12 08:49:02.125978
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"x-forwarded-proto": "https"}
    config = object()
    config.REAL_IP_HEADER = None
    config.FORWARDED_FOR_HEADER = 'x-forwarded-for'
    # Default values (same as config.PROXIES_COUNT=0, REAL_IP_HEADER=None)
    assert parse_xforwarded(headers, config) is None
    # Not enough proxies
    config.PROXIES_COUNT = 2
    headers['x-forwarded-for'] = '1.1.1.1'
    assert parse_xforwarded(headers, config) is None
    # Basic parsing
    config.PROXIES_COUNT = 1
    headers['x-forwarded-for'] = '1.1.1.1'

# Generated at 2022-06-12 08:49:08.439677
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    assert parse_xforwarded({"X-Real-IP": "127.0.0.1"}, config) == {
        "for": "127.0.0.1"
    }
    assert parse_xforwarded(
        {"X-Forwarded-Proto": "https", "X-Forwarded-Path": "/abc"}, config
    ) == {"for": "127.0.0.1", "proto": "https", "path": "/abc"}

# Generated at 2022-06-12 08:49:18.865014
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    config = SanicConfig()
    config.PROXIES_COUNT = 1
    config.REAL_IP_HEADER = 'X-Real-IP'
    config.FORWARDED_FOR_HEADER = 'X-Forwarded-For'
    config.FORWARDED_HOST_HEADER = 'X-Forwarded-Host'
    config.FORWARDED_PROTO_HEADER = 'X-Forwarded-Proto'
    h = Headers({'X-Real-IP': '127.0.0.1', 'X-Forwarded-For': '192.168.1.1,192.168.1.2', 'X-Forwarded-Host': 'youtube.com', 'X-Forwarded-Proto': 'https'})
    res = parse_xforwarded(h, config)

# Generated at 2022-06-12 08:49:30.456193
# Unit test for function parse_content_header
def test_parse_content_header():
    content_header = 'form-data; name=upload; filename=\"file.txt\"'
    expected = ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    actual = parse_content_header(content_header)
    assert expected == actual

if __name__ == "__main__":
    test_parse_content_header()

# Generated at 2022-06-12 08:49:35.351108
# Unit test for function parse_content_header
def test_parse_content_header():
    # Parse from string
    assert parse_content_header("form-data; name=upload; filename=\"file.txt\"") == ("form-data", {"name": "upload", "filename": "file.txt"})
    # Parse from bytes
    assert parse_content_header(b"form-data; name=upload; filename=\"file.txt\"") == ("form-data", {"name": "upload", "filename": "file.txt"})


# Generated at 2022-06-12 08:49:46.446800
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {"X-Forwarded-For": "a, b, c", "X-Forwarded-Host": "hostname"}
    config = {}
    config["REAL_IP_HEADER"] = "X-Forwarded-For"
    config["FORWARDED_FOR_HEADER"] = "X-Forwarded-For"
    config["FORWARDED_PROTOCOL_HEADER"] = "X-Forwarded-Proto"
    config["FORWARDED_HOST_HEADER"] = "X-Forwarded-Host"
    config["FORWARDED_SERVER_HEADER"] = "X-Forwarded-Host"
    config["FORWARDED_PORT_HEADER"] = "X-Forwarded-Port"
    config["FORWARDED_PREFIX_HEADER"] = "X-Forwarded-Prefix"
   

# Generated at 2022-06-12 08:49:55.794670
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-proto': 'https',
        'x-forwarded-host': 'localhost',
        'x-forwarded-path': '',
        'x-forwarded-port': '8080',
    }
    config = {"FORWARDED_FOR_HEADER": 'x-forwarded-host',
              "PROXIES_COUNT": 0,
              "FORWARDED_SECRET": "",
              "REAL_IP_HEADER": 'x-forwarded-for'}
    assert parse_xforwarded(headers, config) == {'proto': 'https', 'host': 'localhost', 'path': '', 'port': 8080}

# Generated at 2022-06-12 08:50:06.091506
# Unit test for function parse_content_header
def test_parse_content_header():
    assert parse_content_header('form-data; name=upload; filename="file.txt"') == ('form-data', {'name': 'upload', 'filename': 'file.txt'})
    assert parse_content_header('application/x-www-form-urlencoded') == ('application/x-www-form-urlencoded', {})
    assert parse_content_header('') == ('', {})
    assert parse_content_header('form-data; name="upload"') == ('form-data', {'name': 'upload'})
    assert parse_content_header(r'form-data; name="upload\\"') == ('form-data', {'name': 'upload"'})
    assert parse_content_header('"a;b"') == ('a;b', {})

# Generated at 2022-06-12 08:50:12.748794
# Unit test for function fwd_normalize
def test_fwd_normalize():
    addr = "fe80:dead:beef::1"
    assert fwd_normalize_address(addr) == "[fe80:dead:beef::1]"

    addr = "127.0.0.1"
    assert fwd_normalize_address(addr) == addr

    addr = "deadbeef::"
    assert fwd_normalize_address(addr) == addr

    addr = "_deadbeef"
    assert fwd_normalize_address(addr) == addr

# Generated at 2022-06-12 08:50:20.571822
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import SanicConfig

    c = SanicConfig()
    c.FORWARDED_SECRET = "secret"

    # Test with no secret specified
    assert parse_forwarded({"forwarded": ""}, c) == None

    # Test with secret not found in header
    assert parse_forwarded({"forwarded": ""}, c) == None

    # Test with "secret" specified
    assert parse_forwarded({"forwarded": "for=192.168.0.1; secret=123"}, c) == None
    assert parse_forwarded({"forwarded": "for=192.168.0.1; secret=secret"}, c) == {
        "for": "192.168.0.1",
        "secret": "secret",
    }

    # Test with "by" specified

# Generated at 2022-06-12 08:50:28.647733
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    """
    Parse a x-forwarded-for header correctly
    """
    
    from sanic.test import SanicTestClient
    from sanic import Sanic

    app = Sanic()

    headers = {'x-forwarded-for': '192.168.1.1'}
    forwarded_config = {'FORWARDED_FOR_HEADER': 'x-forwarded-for'}
    
    actual = parse_xforwarded(headers, forwarded_config)
    expected = {'for': '192.168.1.1'}

    assert actual == expected

# Generated at 2022-06-12 08:50:38.465165
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config

    config = Config({"FORWARDED_SECRET": '"secret"'})
    headers = {
        "forwarded": 'for=192.0.2.60;proto=http;host="example.com",for="[2001:db8:cafe::17]:4711";by=\"[2001:db8:cafe::17]";secret="secret",for=unknown,for=192.0.2.43'
    }
    assert parse_forwarded(headers, config) == {
        "for": "192.0.2.43",
        "proto": "http",
        "host": "example.com",
        "by": "[2001:db8:cafe::17]",
    }

# Generated at 2022-06-12 08:50:43.388747
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {'X-FORWARDED-FOR': '127.0.0.1,127.0.0.1,127.0.0.1'}
    config = {'PROXIES_COUNT': 1}

    assert parse_xforwarded(headers, config) == {'for': '127.0.0.1'}



# Generated at 2022-06-12 08:50:56.024801
# Unit test for function parse_forwarded
def test_parse_forwarded():
    options = [
        ('for', '87.99.102.105'), ('by', '_secret'), ('host', 'localhost'), ('proto', 'https'), ('path', '/path')
    ]
    options.reverse()
    for_val, options = parse_forwarded('for=87.99.102.105; by=_secret, host=localhost; proto=https; path=/path', None)
    assert for_val == reversed(options)

# Generated at 2022-06-12 08:51:08.332567
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "X-Forwarded-Port": "8000",
        "X-Forwarded-For": "192.168.1.1",
        "X-Forwarded-Proto": "https",
        "X-Forwarded-Host": "hostname.host.com:8080",
        "X-Forwarded-Path": "/path/to/endpoint",
    }

# Generated at 2022-06-12 08:51:13.684885
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    assert parse_xforwarded({"x-forwarded-for":"192.168.1.1"},{
        "REAL_IP_HEADER":"x-forwarded-for",
        "PROXIES_COUNT": 1
    }) == {"for":"192.168.1.1"}


# Generated at 2022-06-12 08:51:20.141913
# Unit test for function parse_forwarded
def test_parse_forwarded():
    # Parse Forwarded header with secret
    assert parse_forwarded({'forwarded':['for="_gazonk"']}, None) is None
    assert parse_forwarded({'forwarded':['secret=_gazonk; for=_gazonk']}, None) is None
    assert parse_forwarded({'forwarded':['secret="_gazonk"; for=_gazonk']}, None) is None
    assert parse_forwarded({'forwarded':['secret=_gazonk,for=_gazonk']}, None) is None
    assert parse_forwarded({'forwarded':['secret="_gazonk",for=_gazonk']}, None) is None
    assert parse_forwarded({'forwarded':['secret=_gazonk,for="_gazonk"']}, None) is None

# Generated at 2022-06-12 08:51:28.083949
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {'x-scheme': 'http', 'x-forwarded-host': 'localhost:2'}
    config = {'REAL_IP_HEADER': 'x-scheme', 'PROXIES_COUNT': 2, 'FORWARDED_FOR_HEADER': 'x-scheme'}
    assert parse_xforwarded(headers, config) == {'proto': 'http', 'host': 'localhost:2'}

if __name__ == '__main__':
    test_parse_xforwarded()

# Generated at 2022-06-12 08:51:36.114157
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-for': '127.0.0.1',
        'x-scheme': 'http',
        'x-forwarded-proto': 'http',
        'x-forwarded-host': '10.0.0.1:8080',
        'x-forwarded-port': '8080'
    }
    options = parse_xforwarded(headers, {})
    assert options == {
        'for': '127.0.0.1',
        'proto': 'http',
        'host': '10.0.0.1',
        'port': 8080,
        'path': None
    }

# Generated at 2022-06-12 08:51:43.606744
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from .request import Request
    from .constants import POST, DELETE


# Generated at 2022-06-12 08:51:49.237497
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "Forwarded": "for=192.0.2.60; proto=http; host=example.com"
    }
    config = {
        "FORWARDED_SECRET": "random-string-here"
    }
    fwd = parse_forwarded(headers, config)
    assert fwd["for"] == "192.0.2.60" and fwd["proto"] == "http"

# Generated at 2022-06-12 08:51:59.314407
# Unit test for function parse_forwarded
def test_parse_forwarded():

    # HTTP/1.1 request example
    headers_http11 ={
    'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'User-Agent': 'python-requests/2.21.0', 'Connection': 'keep-alive', 'Host': '127.0.0.1:8000'}
    
    # HTTPS/1.1 request example
    #headers_https11 ={
    #'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'User-Agent': 'python-requests/2.21.0', 'Connection': 'keep-alive', 'Host': '127.0.0.1:8000', 'X-Forwarded-Proto': 'https'}

    # HTTP/2.0 request example
    #headers_http2 = {
    #

# Generated at 2022-06-12 08:52:07.955436
# Unit test for function fwd_normalize
def test_fwd_normalize():
    from sanic.config import Config
    from collections import ChainMap
    config = Config()
    config.REAL_IP_HEADER = "IP-Address"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    config.PROXIES_COUNT = 3
    
    #
    # Test cases for OPTIONS attribute (RFC 7239)
    #

# Generated at 2022-06-12 08:52:24.106439
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import pytest
    from .test_requests import dump_headers, read_headers
    #
    # Test parsing
    #

    def check_parse(headers, result, config=None, secret=None):
        config = config or {}
        config["FORWARDED_SECRET"] = secret
        assert parse_forwarded(headers, config) == result

    # Check that that parsing is sane
    check_parse(
        headers={},
        result=None,
    )

# Generated at 2022-06-12 08:52:32.362543
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    from sanic.config import Config
    from multipart import MultiDictProxy
    # Setup a new config
    config = Config()
    config.PROXIES_COUNT = 1
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"

    # Setup a MultiDictProxy
    # h1 = "0.0.0.0"
    # h2 = "127.0.0.1"
    # h3 = "192.168.1.1"
    # h4 = "192.168.1.2"

# Generated at 2022-06-12 08:52:38.817279
# Unit test for function parse_host
def test_parse_host():
    assert parse_host("a.b.c") == ("a.b.c", None)
    assert parse_host("1.2.3.4") == ("1.2.3.4", None)
    assert parse_host("a.b.c:123") == ("a.b.c", 123)
    assert parse_host("[1::2]:80") == ("1::2", 80)
    assert parse_host("[1%2:2]") == ("1%2:2", None)
    assert parse_host("[1%2:2]:80") == ("1%2:2", 80)



# Generated at 2022-06-12 08:52:47.783573
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        # Real IP header test
        'X-Forwarded-For': '1.1.1.1',
        # Forwarded header test
        'Forwarded': 'for=10.0.0.1; proto=http; host=www.example.com; port=80; path=/path_name',
        # Traditional tests
        'X-Forwarded-Host': 'www.example.com',
        'X-Forwarded-Path': '/path_name',
        'X-Forwarded-Port': '80',
        'X-Forwarded-Proto': 'https',
        'X-Scheme': 'http'
    }
    class config:
        class Value:
            def __init__(self, x):
                self.value = x

        FORWARDED_FOR_HEADER='Forwarded'
        FOR

# Generated at 2022-06-12 08:52:54.073937
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        "x-scheme": "https",
        "x-real-ip": "127.0.0.1",
        "x-forwarded-for": "test",
        "x-forwarded-host": "test.com",
        "x-forwarded-port": "443",
        "x-forwarded-path": "/test",
    }

# Generated at 2022-06-12 08:53:04.415978
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import os
    import sys
    import unittest
    
    # Mock class Request 
    class Request():
        def __init__(self, headers, config):
            self.headers = headers
            self.config = config
    
    # Mock class Config
    class Config():
        def __init__(self, FORWARDED_SECRET):
            self.FORWARDED_SECRET = FORWARDED_SECRET
            
    FORWARDED_SECRET = 'foobar'
    req_headers = {'Forwarded': 'secret=foobar; for=192.0.2.60; proto=https; by=203.0.113.43; host=www.example.com; port=8080; path="/foo/bar"'}
    
    

# Generated at 2022-06-12 08:53:13.967277
# Unit test for function parse_forwarded
def test_parse_forwarded():
    from sanic.config import Config
    from sanic.response import raw
    headers = raw._fake_headers(
        '''\
        forwarded: for=10.1.1.1, for="_test", host=test.test, proto=test.test, \
        port=1, path=/http; by=10.2.2.2, by="_test\\"",
        forwarded: xxx=yyy, zzz=yyy
        '''
    )
    config = Config(FORWARDED_SECRET="_test")

# Generated at 2022-06-12 08:53:22.833911
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = {
        'x-forwarded-host': 'xip.io',
        'x-forwarded-proto': 'http',
        'x-forwarded-path': '/user/12345',
        'x-forwarded-port': '8080',
        'x-forwarded-for': '127.0.0.1'
    }

    result = parse_xforwarded(headers, config)

    assert result['host'] == 'xip.io' and result['proto'] == 'http' and result['port'] == 8080 and result['path'] == '/user/12345' and result['for'] == '127.0.0.1'


# Generated at 2022-06-12 08:53:33.153727
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    headers = CaseInsensitiveDict()
    headers.set("x-forwarded-for", "127.0.0.1, 192.168.1.1, 172.0.0.1")
    headers.set("x-forwarded-host", "example.com:80")
    headers.set("x-forwarded-port", "9090")
    headers.set("x-forwarded-path", "/example/")
    headers.set("x-scheme", "http")

    assert parse_xforwarded(headers, None) == {
        "for": "127.0.0.1",
        "host": "example.com",
        "port": 9090,
        "proto": "http",
        "path": "/example/",
    }

# Generated at 2022-06-12 08:53:42.240654
# Unit test for function parse_forwarded
def test_parse_forwarded():
    """Test the function parse_forwarded()."""
    fwd = 'for="192.0.2.60";proto=https;by="_yay"'
    result = parse_forwarded({'forwarded': fwd}, sanic.config.Config())
    expected_result = {'for': '192.0.2.60', 'proto': 'https', 'by': '_yay'}
    assert(result == expected_result)

    fwd = 'for=192.0.2.60;by=203.0.113.43, for="[2001:db8:cafe::17]:4711"'
    result = parse_forwarded({'forwarded': fwd}, sanic.config.Config())

# Generated at 2022-06-12 08:53:59.488382
# Unit test for function parse_forwarded
def test_parse_forwarded():
    import pdb
    from collections import OrderedDict
    from sanic.config import Config
    from sanic.request import Request
    def generate_headers(fwd_string: str) -> Dict[str, str]:
        return { "forwarded": fwd_string }

    def generate_request(fwd_string: str, config: Config) -> Request:
        headers = generate_headers(fwd_string)
        parsed_headers = Request.parse_headers(headers.items())
        uri = "http://a.b"
        remote_addr = "c.d"
        return Request(
            headers=headers,
            parsed_headers=parsed_headers,
            uri=uri,
            remote_addr=remote_addr,
            config=config,
        )


# Generated at 2022-06-12 08:54:02.763608
# Unit test for function parse_forwarded
def test_parse_forwarded():
    ret = parse_forwarded({"forwarded": "secret=s; by=\"[2a00:1450:4001:811::200e]:3333\""},
                          Config())
    assert ret == {"secret" : "s", "by" : "2a00:1450:4001:811::200e:3333"}

# Generated at 2022-06-12 08:54:12.448810
# Unit test for function parse_forwarded
def test_parse_forwarded():
    headers = {
        "forwarded": [
            "for=192.0.2.60;proto=http;host=example.com,\tfor=;proto=http;host=localhost",
            "For=;proto=;host=,\tfor=\"_hidden\";proto=unknown;host=\"[example.com]\";hide=yes",
            "By=_secret, by=_secret",
        ]
    }
    config = FakeConfig()
    config.FORWARDED_SECRET = "_secret"
    assert parse_forwarded(FakeHeaders(headers), config) == {
        "for": "192.0.2.60",
        "proto": "http",
        "host": "example.com",
    }

# Generated at 2022-06-12 08:54:20.250359
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from sanic.config import Config, ConfigAttribute
    config = Config()
    config.PROXIES_COUNT = 1
    config.REAL_IP_HEADER = "X-Real-IP"
    config.FORWARDED_FOR_HEADER = "X-Forwarded-For"
    class Header:
        def __init__(self, raw, ip="127.0.0.1", scheme="https", host="example.com", port=9000, path="/path/to/nowhere"):
            self.__raw = raw
            self.__ip = ip
            self.__scheme = scheme
            self.__host = host

# Generated at 2022-06-12 08:54:30.024957
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    test_headers = {
    'x-scheme': 'https',
    'x-forwarded-host': 'test.sanic.com',
    'x-forwarded-port': '443',
    'x-forwarded-proto': 'https',
    'x-forwarded-path': '/test/path'
    }
    test_config = {
        'REAL_IP_HEADER': 'X-Scheme',
        'PROXIES_COUNT': '2',
        'FORWARDED_FOR_HEADER': 'X-Forwarded-For'
    }
    fwd = parse_xforwarded(test_headers, test_config)
    assert 'port' in fwd
    assert fwd['port'] == 443
    assert 'host' in fwd

# Generated at 2022-06-12 08:54:37.952918
# Unit test for function parse_xforwarded
def test_parse_xforwarded():
    header_config = {}
    header_config['REAL_IP_HEADER'] = 'x-real-ip'
    header_config['FORWARDED_FOR_HEADER'] = 'x-forwarded-for'
    header_config['PROXIES_COUNT'] = 1
    header = {}
    header['x-real-ip'] = '1.1.1.1'
    header['x-forwarded-for'] = '127.0.0.1'
    result = parse_xforwarded(header, header_config)
    assert result['for'] == '1.1.1.1'
    header['x-forwarded-for'] = '127.0.0.1,127.0.0.2'
    result = parse_xforwarded(header, header_config)