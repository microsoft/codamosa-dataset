

# Generated at 2022-06-25 01:49:26.518197
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    bytes_0 = b'\x0f,\x87/'
    yum_dnf_0 = YumDnf(bytes_0)

    # Test for a list with strings that are comma separated
    some_list_0 = ['a,b,c', 'd,e', 'f']
    expected_some_list_0 = ['a', 'b', 'c', 'd', 'e', 'f']
    actual_some_list_0 = yum_dnf_0.listify_comma_sep_strings_in_list(some_list_0)
    assert expected_some_list_0 == actual_some_list_0

    # Test for an unmodified list
    some_list_1 = ['a', 'b', 'c', 'd', 'e', 'f']
    expected_some_

# Generated at 2022-06-25 01:49:34.157870
# Unit test for constructor of class YumDnf
def test_YumDnf():
    temp_file = tempfile.NamedTemporaryFile()

    # Test module argument_spec
    yum_dnf_1 = YumDnf(None)
    assert yumdnf_argument_spec == yum_dnf_1.module.argument_spec

    # Test variables

# Generated at 2022-06-25 01:49:44.433715
# Unit test for constructor of class YumDnf
def test_YumDnf():
    bytes_0 = b'\x0f,\x87/'
    dict_0 = dict()
    dict_0['allow_downgrade'] = '\x80\xa3\x0c\xdc\x7f\x8e\x00\x1f\x03\x7f\x0f'
    dict_0['autoremove']= bytes_0
    dict_0['bugfix'] = '\x80\xa3\x0c\xdc\x7f\x8e\x00\x1f\x03\x7f\x0f'
    dict_0['cacheonly'] = bytes_0

# Generated at 2022-06-25 01:49:47.693595
# Unit test for constructor of class YumDnf
def test_YumDnf():
    test_case_0()
    test_get_packages()
    test_convert_requires_to_package()
    test_autoremove()
    test_is_locked()
    test_download_packages()
    test_install_packages()
    test_install_from_repos()
    test_update_cache()
    test_run_command_with_check_mode()
    test_run_command()


# Generated at 2022-06-25 01:49:50.585560
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    bytes_0 = b'\x0f,\x87/'
    yum_dnf_0 = YumDnf(bytes_0)
    assert yum_dnf_0.is_lockfile_pid_valid() == None


# Generated at 2022-06-25 01:49:56.575229
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf

# Generated at 2022-06-25 01:49:59.956974
# Unit test for constructor of class YumDnf
def test_YumDnf():
    # Test cases
    test_case_0()

if __name__ == '__main__':
    test_YumDnf()

# Generated at 2022-06-25 01:50:01.437625
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    bytes_0 = b'\x0f,\x87/'
    yum_dnf_0 = YumDnf(bytes_0)
    yum_dnf_0.wait_for_lock()


# Generated at 2022-06-25 01:50:06.233351
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    bytes_0 = b'[A-z]K`*'
    yum_dnf_0 = YumDnf(bytes_0)
    str_0 = '\n\t\t\t\n'
    str_1 = ':\x00\x00\x00,\x00\x00\x00#\x00\x00\x00'
    str_2 = '\x1a\x00\x00\x00\x00\x00\x00\x00Z\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 01:50:08.354065
# Unit test for constructor of class YumDnf
def test_YumDnf():
    assert True

test_case_0()
test_YumDnf()

# Generated at 2022-06-25 01:50:26.365256
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    # following test case is added to pass the pylint test
    module = {"check_mode": False, "params": {}}
    yd = YumDnf(module)
    try:
        yd.run()
    except NotImplementedError:
        pass



# Generated at 2022-06-25 01:50:27.581752
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    y = YumDnf(None)
    assert y.wait_for_lock() is None


# Generated at 2022-06-25 01:50:33.397057
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():

    # Create a temp file to workaround the module's creation of a temp
    # directory. Use the full path of the tmpfile to avoid issues with
    # parameters to tempfile.mkstemp()
    tmpfile = tempfile.mkstemp()[1]

    # Create an augsment_spec that is identical to the yumdnf_argument_spec
    # except for the require_one_of and mutually_exclusive fields.

# Generated at 2022-06-25 01:50:37.724075
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    with tempfile.NamedTemporaryFile() as temp:
        temp.write(b"!/usr/bin/python")
        temp.flush()
        temp.seek(0)
        module = None
        some_class = YumDnf(module)
        try:
            some_class.run()
            assert False
        except NotImplementedError:
            assert True


# Generated at 2022-06-25 01:50:43.909662
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """
    Unit test for method listify_comma_sep_strings_in_list of class YumDnf
    """
    module = MockModule()
    yd = YumDnf(module)
    some_list = ['a', 'b', 'c', 'd,e,f', 'g', 'h,i,j']
    expected_list = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
    returned_list = yd.listify_comma_sep_strings_in_list(some_list)
    assert expected_list == returned_list
    some_list = ['a,b', 'b', 'c,d']
    expected_list = ['a', 'b', 'c,d']
    returned_list

# Generated at 2022-06-25 01:50:52.927245
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class YumDnfTest(YumDnf):
        def is_lockfile_pid_valid(self):
            return False

        def run(self):
            self.wait_for_lock()
            with tempfile.NamedTemporaryFile() as f:
                self.lockfile = f.name
                self.wait_for_lock()

        def fail(self, msg):
            raise Exception(to_native(msg))

    class MyModule(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = False
            self.fail_json = self.fail

        def fail(self, msg, result=None):
            raise Exception(to_native(msg))


# Generated at 2022-06-25 01:51:01.703400
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    module = dict()
    yd = YumDnf(module)
    if os.path.exists(yd.lockfile):
        _, tf_name = tempfile.mkstemp()
        yd.lockfile = tf_name
        with open(yd.lockfile, 'w+') as lockfile:
            lockfile.write("12345")
        with open(yd.lockfile, 'w+') as lockfile:
            lockfile.write("12345")
        if yd.is_lockfile_pid_valid():
            os.remove(yd.lockfile)
        else:
            raise AssertionError("Unit test for method is_lockfile_pid_valid of class YumDnf failed")

# Generated at 2022-06-25 01:51:12.314174
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = Mock()

# Generated at 2022-06-25 01:51:20.588205
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-25 01:51:29.606609
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    from ansible.module_utils.yum import Yum
    yum = Yum(module=None)
    try:
        os.kill(1234, 0)
    except OSError:
        assert not yum.is_lockfile_pid_valid()
    with tempfile.NamedTemporaryFile() as f:
        os.chown(f.name, 0, 0)
        yum.lockfile = f.name
        try:
            os.kill(1234, 0)
        except OSError:
            assert not yum.is_lockfile_pid_valid()

# Generated at 2022-06-25 01:52:09.070988
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class ModuleMock(object):
        def __init__(self):
            self.params = dict(lock_timeout=2)
            self.fail_json = self.fail
        def fail(self, msg):
            raise Exception('fail_json was called')
    class YumDnfMock(YumDnf):
        def __init__(self, module):
            super(YumDnfMock, self).__init__(module)
            # create a tmp file
            fd, self.lockfile = tempfile.mkstemp(prefix='ansible-yum-lock-test-', suffix=".pid")
            # set the pidfile to current pid
            with os.fdopen(fd, 'w') as f:
                f.write("{0}\n".format(os.getpid()))
       

# Generated at 2022-06-25 01:52:20.117424
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import shutil
    import tempfile
    import pytest

    from ansible.module_utils.basic import AnsibleModule

    from ansible.modules.package.yum import Yum
    from ansible.modules.package.dnf import DNFModule

    from ansible_collections.ansible.netcommon.plugins.module_utils.package.yumdnf import YumDnf

    def is_lockfile_pid_valid(self):
        return True

    def fail_json(self, msg, results=[]):
        global failed
        print(msg)
        failed = True

    def exists(self, lockfile):
        global exists
        if exists is not None and exists is True:
            return True
        else:
            return False

    temp_dir = tempfile.mkdtemp()
    lockfile = tempfile

# Generated at 2022-06-25 01:52:27.360798
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    class TestYumDnf(YumDnf):
        pkg_mgr_name = 'yum'
        def is_lockfile_pid_valid(self):
            pass

    test_yum = TestYumDnf(None)

    assert test_yum.listify_comma_sep_strings_in_list([]) == []
    assert test_yum.listify_comma_sep_strings_in_list(['a']) == ['a']
    assert test_yum.listify_comma_sep_strings_in_list(['a, b']) == ['a', 'b']
    assert test_yum.listify_comma_sep_strings_in_list(['a, b', 'c']) == ['a', 'b', 'c']
   

# Generated at 2022-06-25 01:52:34.035971
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():

    # set up test environment with mock module
    module = MockModule()
    distinfo = MockDistInfo()

    # init YumDnf class
    y = YumDnf(module)

    # check method listify_comma_sep_strings_in_list
    assert y.listify_comma_sep_strings_in_list([]) == []
    assert y.listify_comma_sep_strings_in_list([',']) == []
    assert y.listify_comma_sep_strings_in_list(['p1,p2', 'p3,p4']) == ['p1', 'p2', 'p3', 'p4']

# Generated at 2022-06-25 01:52:39.997796
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible.module_utils.basic import AnsibleModule
    pm = YumDnf(AnsibleModule({}))
    try:
        pm.wait_for_lock()
    except SystemExit as e:
        assert(e.code == 1)
        return
    assert(False and 'Exception was not raised')


# Generated at 2022-06-25 01:52:46.357300
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import mock

    # Lockfile present -> test successful
    yumdnf_inst = YumDnf()
    yumdnf_inst.lock_timeout = 30
    yumdnf_inst._is_lockfile_present = mock.MagicMock(return_value=True)
    yumdnf_inst.is_lockfile_pid_valid = mock.MagicMock(return_value=True)
    yumdnf_inst.wait_for_lock()

    # Lockfile present -> test failure due to timeout
    yumdnf_inst = YumDnf()
    yumdnf_inst.lock_timeout = 0
    yumdnf_inst._is_lockfile_present = mock.MagicMock(return_value=True)
    yumdnf_inst.is_lockfile_pid_

# Generated at 2022-06-25 01:52:55.977191
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import module_mocks
    _module = module_mocks.MockModule()

# Generated at 2022-06-25 01:53:02.583324
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.common.collections import ImmutableDict
    yum = YumDnf(None)
    assert yum.listify_comma_sep_strings_in_list(['a,b']) == ['a', 'b']
    assert yum.listify_comma_sep_strings_in_list(['a, b']) == ['a', 'b']
    assert yum.listify_comma_sep_strings_in_list(['a, b', 'c']) == ['a', 'b', 'c']
    assert yum.listify_comma_sep_strings_in_list(['a, b', 'c, d']) == ['a', 'b', 'c', 'd']
    assert yum.listify_comma_sep_

# Generated at 2022-06-25 01:53:09.767609
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Setup
    y = YumDnf(object)
    y.lock_timeout = 0
    tmp_dir = tempfile.mkdtemp(dir='/tmp')
    y.lockfile = tmp_dir + '/file.lock'

    # Test
    try:
        y.wait_for_lock()
    except Exception as e:
        assert False

    # Test with lockfile
    try:
        os.mkfifo(y.lockfile, 0o777)
        y.wait_for_lock()
        assert False
    except Exception as e:
        pass

    # Test with timeout
    try:
        os.remove(y.lockfile)
    except:
        pass

    y.lock_timeout = 2

# Generated at 2022-06-25 01:53:16.444033
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    # Imports inside method so they can be mocked
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    yum_dnf = YumDnf(module)

    with tempfile.NamedTemporaryFile() as temp:
        yum_dnf.lockfile = temp.name
        try:
            yum_dnf.wait_for_lock()
        except BaseException as e:
            msg = to_native(e)
            assert msg == 'yum lockfile is held by another process'

# Generated at 2022-06-25 01:54:05.598363
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils import yum as yum_module
    mock_module = yum_module.AnsibleModule(yumdnf_argument_spec)
    result = YumDnf(mock_module)
    assert result


# Generated at 2022-06-25 01:54:16.592635
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    Test wait_for_lock method of class YumDnf using a temporary file as the lock file
    """

    class FakeModule():
        def fail_json(self, msg):
            raise Exception(msg)


# Generated at 2022-06-25 01:54:23.716908
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    lfp_tmp_dir = tempfile.mkdtemp()
    lfp_tmp_filename = os.path.join(lfp_tmp_dir, "yum.pid")
    lfp_tmp_file = open(lfp_tmp_filename, 'w')
    lfp_tmp_file.write(str(os.getpid()) + "\n")
    lfp_tmp_file.close()
    yd = YumDnf(None)
    yd.lockfile = lfp_tmp_filename
    assert yd.is_lockfile_pid_valid() == True
    yd.lockfile = lfp_tmp_filename + ".invalid"
    assert yd.is_lockfile_pid_valid() == False
    os.remove(lfp_tmp_filename)

# Generated at 2022-06-25 01:54:32.490380
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """
    Unit test for listify_comma_sep_strings_in_list method
    """
    from ansible.module_utils.basic import AnsibleModule

    test_src_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../lib/ansible/module_utils/tests/'))
    module_path = os.path.join(test_src_path, 'test_package_mgr_common.py')
    test_mod = AnsibleModule(module_path, argument_spec=yumdnf_argument_spec)
    test_yumdnf = YumDnf(test_mod)


# Generated at 2022-06-25 01:54:41.908428
# Unit test for constructor of class YumDnf
def test_YumDnf():
    class Fake_Module(object):
        def __init__(self, params, check_mode=False):
            self.params = params
            self.check_mode = check_mode

        def fail_json(self, msg):
            self.msg = msg
            self.failed = True


# Generated at 2022-06-25 01:54:49.612702
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = None

# Generated at 2022-06-25 01:54:58.165190
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.module_utils.basic

# Generated at 2022-06-25 01:55:04.661862
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    class MockModule(object):
        params = {'lock_timeout': 1}

        class Failed(Exception):
            def fail_json(self, **msg):
                raise self

        def fail_json(self, **msg):
            raise self.Failed("fail_json")

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
            self.lockfile = tempfile.NamedTemporaryFile(delete=False)

        def is_lockfile_pid_valid(self):
            return True

    module = MockModule()

# Generated at 2022-06-25 01:55:10.955674
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():  # pylint: disable=invalid-name
    class TestModule(object):
        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

    test_module = TestModule()
    yum_dnf = YumDnf(test_module)

    # Items in list as str
    list_1 = ['foo', 'bar']
    list_1_expected = ['foo', 'bar']
    list_1_result = yum_dnf.listify_comma_sep_strings_in_list(list_1)
    if list_1_result != list_1_expected:
        raise AssertionError("listify_comma_sep_strings_in_list expected {0} but got {1}".format(list_1_expected, list_1_result))

    #

# Generated at 2022-06-25 01:55:15.238758
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    l = []
    assert [] == YumDnf.listify_comma_sep_strings_in_list(l)

    d = dict(module=dict(fail_json=lambda x: None))
    y = YumDnf(d)
    y.listify_comma_sep_strings_in_list(['foo'])
    y.listify_comma_sep_strings_in_list(['foo,bar'])
    y.listify_comma_sep_strings_in_list(['foo, bar'])

    try:
        y.listify_comma_sep_strings_in_list(['foo bar'])
        assert 0
    except SystemExit as e:
        assert "should be passed as a comma separated string" in to_native(e)


# Generated at 2022-06-25 01:57:02.510525
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.plugins.modules.package_manager.yum import Yum
    from ansible_collections.community.general.plugins.modules.package_manager.dnf import DNF
    import inspect

    def check_class_methods(cls, class_name):
        class_methods = inspect.getmembers(cls, predicate=inspect.isfunction)
        class_methods = set(method[0] for method in class_methods)
        parent_methods = inspect.getmembers(cls.__base__, predicate=inspect.isfunction)
        parent_methods = set(method[0] for method in parent_methods)

# Generated at 2022-06-25 01:57:12.117808
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = FakeAnsibleModule()

    module.params['allow_downgrade'] = False
    module.params['autoremove'] = False
    module.params['bugfix'] = False
    module.params['cacheonly'] = False
    module.params['conf_file'] = "/etc/yum.conf"
    module.params['disable_excludes'] = None
    module.params['disable_gpg_check'] = False
    module.params['disable_plugin'] = []
    module.params['disablerepo'] = []
    module.params['download_only'] = False
    module.params['download_dir'] = None
    module.params['enable_plugin'] = []
    module.params['enablerepo'] = []
    module.params['exclude'] = []
    module.params['installroot'] = "/"


# Generated at 2022-06-25 01:57:13.594230
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    y = YumDnf(object())
    with pytest.raises(NotImplementedError):
        y.run()


# Generated at 2022-06-25 01:57:19.846893
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    test_cases = (
        (['foo'], ['foo']),
        (['foo', 'bar'], ['foo', 'bar']),
        (['foo,bar'], ['foo', 'bar']),
        (['foo, bar'], ['foo', 'bar']),
        ([' foo,bar '], ['foo', 'bar']),
        ([' foo ,bar '], ['foo', 'bar']),
        ([' foo , bar '], ['foo', 'bar']),
        ([' foo , bar ,  baz,qux '], ['foo', 'bar', 'baz', 'qux']),
        (['', 'foo'], ['foo']),
        ([',', 'foo', 'bar'], ['foo', 'bar']),
    )

# Generated at 2022-06-25 01:57:25.428576
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():

    class MyYumDnf(YumDnf):
        def run(self):
            return
        def is_lockfile_pid_valid(self):
            return

    # Build a module
    module = AnsibleModule(argument_spec={})

    # Build a MyYumDnf
    yumdnf = MyYumDnf(module)

    phase = 'Test 1 - basic data check'
    input_list = ['foo', 'bar', 'yada,do']
    want = ['foo', 'bar', 'yada', 'do']
    got = yumdnf.listify_comma_sep_strings_in_list(input_list)

# Generated at 2022-06-25 01:57:35.836868
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yum_dnf = YumDnf(None)
    my_list = ["one,two,three"]
    new_list = yum_dnf.listify_comma_sep_strings_in_list(my_list)
    assert new_list == ["one","two","three"]

    my_list = ["one, two, three"]
    new_list = yum_dnf.listify_comma_sep_strings_in_list(my_list)
    assert new_list == ["one","two","three"]

    my_list = ["one"]
    new_list = yum_dnf.listify_comma_sep_strings_in_list(my_list)
    assert new_list == ["one"]

    my_list = ["one,two", "three"]
    new_

# Generated at 2022-06-25 01:57:44.728868
# Unit test for constructor of class YumDnf
def test_YumDnf():
    '''
    Test YumDnf constructor.
    '''

    test_module = MockModule()

    yum = YumDnf(test_module)
    assert yum.bugfix is False

    test_module.params['bugfix'] = True
    yum = YumDnf(test_module)
    assert yum.bugfix is True

    assert yum.names == []

    test_module.params['name'] = ['package1', 'package2']
    yum = YumDnf(test_module)
    assert yum.names == ['package1', 'package2']

    assert yum.disablerepo == []
    test_module.params['disablerepo'] = ['repo1', 'repo2']
    yum = YumDnf(test_module)
   

# Generated at 2022-06-25 01:57:51.159323
# Unit test for constructor of class YumDnf

# Generated at 2022-06-25 01:57:56.800667
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    class FakePopen(object):
        def __init__(self):
            self.returncode = 0
            self.stdout = "1778".encode()

    class FakePopen2(object):
        def __init__(self):
            self.returncode = 1
            self.stdout = "".encode()

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    class FakeYumDnf(YumDnf):
        # This function is overriden by classes Yum and Dnf
        def is_lockfile_pid_valid(self):
            return True

    # Create temporary file containing fake lock file
    empty_fd, empty_file = tempfile.mkstemp()
    os.close(empty_fd)

    fake_fd, fake

# Generated at 2022-06-25 01:57:57.994149
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    y = YumDnf(None)
    y.run()
