

# Generated at 2022-06-25 01:49:23.803630
# Unit test for constructor of class YumDnf
def test_YumDnf():
    # Destroy actual object of class YumDnf
    yum_dnf_0 = YumDnf()

# Generated at 2022-06-25 01:49:25.738325
# Unit test for constructor of class YumDnf
def test_YumDnf():
    str_0 = '\r:PWjb'
    yum_dnf_0 = YumDnf(str_0)
    assert True
    return


# Generated at 2022-06-25 01:49:26.586880
# Unit test for constructor of class YumDnf
def test_YumDnf():
    pass


# Generated at 2022-06-25 01:49:29.753281
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    str_0 = '\r:PWjb'
    yum_dnf_0 = YumDnf(str_0)
    yum_dnf_0.wait_for_lock()


# Generated at 2022-06-25 01:49:31.689387
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    yum_dnf_0 = YumDnf(str_0)
    yum_dnf_0.is_lockfile_pid_valid()


# Generated at 2022-06-25 01:49:36.068930
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    list_0 = []
    list_0 += [to_native(str_0) for str_0 in ['abc', 'def,ghi,jkl']]

    # Act
    result = YumDnf(None).listify_comma_sep_strings_in_list(list_0)

    # Assert
    assert result == ['abc', 'def', 'ghi', 'jkl']


# Generated at 2022-06-25 01:49:38.946928
# Unit test for constructor of class YumDnf
def test_YumDnf():
    assert not test_case_0()
    return True


if __name__ == '__main__':
    test_YumDnf()

# Generated at 2022-06-25 01:49:45.131123
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    # Definitions
    str_0 = '\r:PWjb'
    yum_dnf_0 = YumDnf(str_0)

    # Call the method
    str_1 = None
    try:
        yum_dnf_0.listify_comma_sep_strings_in_list(str_1)
    except Exception as e:
        print_exception(e, 'listify_comma_sep_strings_in_list')


if __name__ == "__main__":
    # Execute the main function
    main()

# Generated at 2022-06-25 01:49:52.837870
# Unit test for constructor of class YumDnf
def test_YumDnf():
    # Trying a series of valid and invalid parameters for the class constructor of YumDnf
    # The class constructor should throw an exception if the parameter name is not a string
    with pytest.raises(AssertionError):
        yum_dnf = YumDnf(100)

    # The class constructor should throw an exception if the parameter name is not an instance of string.
    with pytest.raises(AssertionError):
        yum_dnf_0 = YumDnf('yum')
    with pytest.raises(AssertionError):
        yum_dnf_1 = YumDnf('yum')
    with pytest.raises(AssertionError):
        yum_dnf_2 = YumDnf('yum')

# Generated at 2022-06-25 01:49:57.612746
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    lock_file = tempfile.NamedTemporaryFile(delete=False)
    lock_file.write(bytes(str(os.getpid()), 'UTF-8'))
    lock_file.close()

    try:
        test_case_1 = YumDnf('/bin/ls')
        test_case_1.lockfile = lock_file.name

        test_case_2 = YumDnf('/bin/ls')
        test_case_2.lockfile = lock_file.name

        assert test_case_1.is_lockfile_pid_valid()
        assert test_case_2.is_lockfile_pid_valid()
    finally:
        os.unlink(lock_file.name)


# Generated at 2022-06-25 01:50:26.997177
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.module_utils.basic
    from ansible_collections.community.general.plugins.modules.package_manager import yum_base


# Generated at 2022-06-25 01:50:31.699015
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.modules.packaging.os.yum as yum

    yum_module_instance = yum.YumModule(
        argument_spec={},
        suppress_check_mode=True,
        bypass_checks=False
    )

    # Make sure the constructor raises the proper error if no state is specified

# Generated at 2022-06-25 01:50:40.109065
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    input_list = ['a,b', 'c', 'd,e', '', 'f,g,h']
    answer_list = ['a', 'b', 'c', 'd', 'e', '', 'f', 'g', 'h']
    assert YumDnf.listify_comma_sep_strings_in_list(input_list) == answer_list

    input_list = ['ab', 'c,d', 'ee', '', 'f,g,h']
    answer_list = ['ab', 'c', 'd', 'ee', '', 'f', 'g', 'h']
    assert YumDnf.listify_comma_sep_strings_in_list(input_list) == answer_list



# Generated at 2022-06-25 01:50:42.998858
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    # Tests run() method of class YumDnf.
    # Following error is expected:
    # NotImplementedError: Can't instantiate abstract class YumDnf with abstract methods run
    yumdnf_obj = YumDnf(None)
    yumdnf_obj.run()


# Generated at 2022-06-25 01:50:52.006724
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.yumdnf_common import YumDnfModule

    module = YumDnfModule(yumdnf_argument_spec)
    yum_dnf = YumDnf(module)

    assert yum_dnf.allow_downgrade is False
    assert yum_dnf.autoremove is False
    assert yum_dnf.bugfix is False
    assert yum_dnf.cacheonly is False
    assert yum_dnf.conf_file is None
    assert yum_dnf.disable_excludes is None
    assert yum_dnf.disable_gpg_check is False
    assert yum_dnf.disable_plugin == []
    assert yum_dnf.disablerepo == []
    assert yum_dnf.download_only

# Generated at 2022-06-25 01:50:56.761004
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    YD = YumDnf()
    try:
        YD.run()
    except NotImplementedError:
        pass
    else:
        raise AssertionError("NotImplementedError should be raised")


# Generated at 2022-06-25 01:51:04.497418
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import ansible_collections
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import call, patch
    from ansible_collections.notstdlib.moveitallout.plugins.modules import yum

    from ansible_collections.notstdlib.moveitallout.plugins.modules._yumdnf import YumDnf

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            pass

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            YumDnf.__init

# Generated at 2022-06-25 01:51:13.475148
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    # Unit test to test the working of method listify_comma_sep_strings_in_list()
    # in class YumDnf
    assert YumDnf.listify_comma_sep_strings_in_list(["a,b,c", "d", "e,f"]) == ["a", "b", "c", "d", "e", "f"]
    assert YumDnf.listify_comma_sep_strings_in_list(["a,b,c,d,,,"]) == ["a", "b", "c", "d"]
    assert YumDnf.listify_comma_sep_strings_in_list([","]) == []


# Generated at 2022-06-25 01:51:19.314540
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Unit testing function for YumDnf class constructor
    """
    from ansible.module_utils.common.collections import ImmutableDict

    # Test when list is not passed
    module = ImmutableDict(argument_spec=yumdnf_argument_spec['argument_spec'], check_invalid_arguments=False)

# Generated at 2022-06-25 01:51:27.945386
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    module = MockModule()
    # test case 1
    y = YumDnf(module)
    y.lockfile = None
    assert y.is_lockfile_pid_valid() is False
    # test case 2
    y = YumDnf(module)
    with tempfile.NamedTemporaryFile() as f:
        y.lockfile = f.name
        assert y.is_lockfile_pid_valid() is False
    # test case 3
    y = YumDnf(module)
    with tempfile.NamedTemporaryFile() as f:
        content = to_native("")
        f.write(content.encode("utf-8"))
        f.flush()
        y.lockfile = f.name
        assert y.is_lockfile_pid_valid() is False
    #

# Generated at 2022-06-25 01:52:18.512889
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.basic import AnsibleModule

    class TestYumDnf(YumDnf):
        def __init__(self, module):
            super(TestYumDnf, self).__init__(module)

        @staticmethod
        def is_lockfile_pid_valid():
            return True

        def run(self):
            return True

    module = AnsibleModule(name='yum', **yumdnf_argument_spec)
    testyumdnf = TestYumDnf(module=module)
    testyumdnf.run()

# Generated at 2022-06-25 01:52:26.637524
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    # testing list with no comma separated string
    yum_dnf_obj = YumDnf(None)
    test_list = [""]
    expected_list = []
    assert yum_dnf_obj.listify_comma_sep_strings_in_list(test_list) == expected_list

    # testing list with comma separated string
    test_list = ["test1,test2,test3"]
    expected_list = ["test1", "test2", "test3"]
    assert yum_dnf_obj.listify_comma_sep_strings_in_list(test_list) == expected_list



# Generated at 2022-06-25 01:52:33.993558
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create a fake lock file
    tempfile.tempdir = '/tmp'
    lockfile = tempfile.NamedTemporaryFile(prefix='ansible-yum-lock-', suffix='', dir='/tmp')
    lockfile.write(b'1\n')
    lockfile.close()

    # Create a fake ansible module
    import ansible.module_utils.basic
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean

# Generated at 2022-06-25 01:52:36.455985
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    with pytest.raises(NotImplementedError):
        YumDnf.run(YumDnf)


# Generated at 2022-06-25 01:52:45.074657
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-25 01:52:54.841701
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    import tempfile
    import ansible.module_utils.basic

    module_args = dict(
        pkg=dict(type='str'),
    )

    module = ansible.module_utils.basic.AnsibleModule(argument_spec=module_args,
                                                      supports_check_mode=True)

    test_object = YumDnf(module)

    # when a list of strings with comma separated elements is passed
    test_list = ['a', 'b, c', 'd, e, f', 'g, h, i, j', '', 'l,', ',m, n']
    expected_result = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'l', 'm', 'n']
    result = test_object.listify

# Generated at 2022-06-25 01:53:01.772642
# Unit test for method run of class YumDnf
def test_YumDnf_run():

    from ansible.module_utils.yumdnf import YumDnf
    from ansible.module_utils.common.dict_transformations import _get_all_subsets

    class ConcreteYumDnf(YumDnf):

        def __init__(self, module):
            super(ConcreteYumDnf, self).__init__(module)

        def is_lockfile_pid_valid(self):
            return False

    class TestModule(object):
        def __init__(self, params, check_mode=True, supports_check_mode=True):
            self.params = params
            self.check_mode = check_mode
            self.supports_check_mode = supports_check_mode

        def fail_json(self, msg, results=[]):
            raise Exception(msg)



# Generated at 2022-06-25 01:53:04.609063
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    """
    YumDnf.run() is an abstract method and is tested in the test cases
    for both the yum and dnf module
    """
    pass



# Generated at 2022-06-25 01:53:15.687794
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    module = YumDnf(None)
    assert module.listify_comma_sep_strings_in_list(['pkg1', 'pkg2']) == ['pkg1', 'pkg2']
    assert module.listify_comma_sep_strings_in_list(['pkg1, pkg2']) == ['pkg1', 'pkg2']
    assert module.listify_comma_sep_strings_in_list(['pkg1', 'pkg2', 'pkg3, pkg4']) == ['pkg1', 'pkg2', 'pkg3', 'pkg4']
    assert module.listify_comma_sep_strings_in_list(['pkg1, pkg2, pkg3', 'pkg4']) == ['pkg1', 'pkg2', 'pkg3', 'pkg4']
    assert module

# Generated at 2022-06-25 01:53:24.386849
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Unit test for constructor of class YumDnf
    """

# Generated at 2022-06-25 01:54:29.134639
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum import YumDnf

    class yumdnf_mock(YumDnf):
        def is_lockfile_pid_valid(self):
            return True

        def run(self):
            return None

    with tempfile.NamedTemporaryFile(mode='w+b', delete=False) as f:
        f.write(b'12345')

        # Create mock module

# Generated at 2022-06-25 01:54:39.987718
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    class TestYumDnf(YumDnf):
        def __init__(self, module):
            pass

    yumdnf = TestYumDnf(None)
    assert yumdnf.listify_comma_sep_strings_in_list(["foo", "bar"]) == ["foo", "bar"]
    assert yumdnf.listify_comma_sep_strings_in_list(["foo,bar"]) == ["foo", "bar"]
    assert yumdnf.listify_comma_sep_strings_in_list(["foo, bar"]) == ["foo", "bar"]

# Generated at 2022-06-25 01:54:44.812537
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yum_dnf_obj = YumDnf()

    # test for listify_comma_sep_strings_in_list() method returns correct list when
    # the list contains only comma separated strings
    actual_result = yum_dnf_obj.listify_comma_sep_strings_in_list(['a,b,c,d,e'])
    expected_result = ['a', 'b', 'c', 'd', 'e']
    assert actual_result == expected_result

    # test for listify_comma_sep_strings_in_list() method returns correct list when
    # the list contains some instances of comma separated strings and some not
    # comma separated strings

# Generated at 2022-06-25 01:54:53.780890
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    import io
    import sys
    import traceback
    import module_utils.basic as basic
    import ansible.module_utils.yumdnf as yumdnf


    # Mock the module
    module = basic.AnsibleModule(
        argument_spec=yumdnf_argument_spec
    )

    # Mock the Lockfile class
    class Lockfile():
        def __init__(self, lockfile, timeout=30, threaded=False, fail_when_locked=False, shared=False):
            self.lockfile = lockfile
            self.timeout = timeout

        def acquire(self):
            pass

        def release(self):
            pass

    # Mock the RpmBase class
    class RpmBase(yumdnf.YumDnf):
        def __init__(self, module):
            super

# Generated at 2022-06-25 01:55:01.413646
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    # Create an instance of module class
    module = AnsibleModule({}, {}, supports_check_mode=True)

    # Create an instance of YumDnf class
    yumdnf = YumDnf(module)

    assert yumdnf.listify_comma_sep_strings_in_list(["apache", "php"]) == ["apache", "php"]
    assert yumdnf.listify_comma_sep_strings_in_list(["apache, php"]) == ["apache", "php"]
    assert yumdnf.listify_comma_sep_strings_in_list(["apache,php"]) == ["apache", "php"]
    assert yumdnf.listify_comma_sep_strings_in_list(["apache", ""]) == ["apache"]
   

# Generated at 2022-06-25 01:55:07.624330
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    """
    This is a unit test for method run of class YumDnf.
    """

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
    )

    yumdnf_obj=YumDnf(module)
    try:
        yumdnf_obj.run()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 01:55:15.612993
# Unit test for constructor of class YumDnf
def test_YumDnf():

    import ansible.module_utils.basic

# Generated at 2022-06-25 01:55:22.503421
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Create a temporary directory and add it to the module argument.
    tmpdir = tempfile.mkdtemp()
    module_args = dict(installroot=tmpdir)

# Generated at 2022-06-25 01:55:33.599130
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():

    class DummyYumDnf(YumDnf):
        def __init__(self, module):
            super(DummyYumDnf, self).__init__(module)
            self.pkg_mgr_name = 'dummy_mgr'
            self.lockfile = 'test_file'

        def is_lockfile_pid_valid(self):
            return True

    module = DummyModule()
    test_obj = DummyYumDnf(module)

    test_obj.wait_for_lock()

    # test_is_lockfile_pid_valid_neg
    test_obj.lock_timeout = 0

    test_obj.wait_for_lock()
    expected = 'dummy_mgr lockfile is held by another process'

# Generated at 2022-06-25 01:55:41.654666
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():

    test_class = YumDnf(None)

    try:
        with tempfile.NamedTemporaryFile() as temp:
            test_class.lockfile = temp.name
            test_class.is_lockfile_pid_valid()
    except NotImplementedError:
        pass
    except Exception as e:
        # unexpected exception
        from traceback import format_exc
        import sys

        expected_message = "method is_lockfile_pid_valid() must be implemented"
        exc_type, exc_value, exc_traceback = sys.exc_info()
        actual_message = str(exc_value)

        if expected_message != actual_message:
            raise Exception("\n" + format_exc())


# Generated at 2022-06-25 01:57:46.167140
# Unit test for constructor of class YumDnf
def test_YumDnf():
    os.path.isfile = MagicMock(side_effect=[False])
    glob.glob = MagicMock(side_effect=[False])
    module = MagicMock()

# Generated at 2022-06-25 01:57:52.463067
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    with tempfile.NamedTemporaryFile() as lockfile:
        yum_dnf_obj = YumDnf(lockfile)
        yum_dnf_obj.lockfile = lockfile.name
        yum_dnf_obj.lock_timeout = 1

        yum_dnf_obj.wait_for_lock()

# Generated at 2022-06-25 01:58:03.073958
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Unit test for constructor of class YumDnf
    """

# Generated at 2022-06-25 01:58:13.939910
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    # This class is needed to simulate module
    class Module():
        def fail_json(self, msg, results=None):
            raise Exception('Execution failed due to lockfile')
    # This class is needed to simulate YumDnf class
    class YumDnfMock(YumDnf):
        def __init__(self, module):
            # YumDnfMock is abstract class, so init of parent class is needed
            super(YumDnfMock, self).__init__(module)
            # mocked value of lock_timeout
            self.lock_timeout = 2
            # mocked value of lockfile
            self.lockfile = os.path.join(tempfile.mkdtemp(), 'yum.pid')
            os.system('touch {0}'.format(self.lockfile))
            #

# Generated at 2022-06-25 01:58:19.621603
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    import pytest
    from ansible.module_utils.yum_dnf import YumDnf

    class TestYumDnf(YumDnf):
        def __init__(self, module):
            super(TestYumDnf, self).__init__(module)

        def is_lockfile_pid_valid(self):
            return True

    class ModuleMock(object):
        def __init__(self, params):
            self.params = params
            self.name = 'test'

        def fail_json(self, *args, **kwargs):
            fail_json(*args, **kwargs)


# Generated at 2022-06-25 01:58:30.172616
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    list_for_testing = ['f1,f2,f3,f4', 'f5', 'f6,f7,f8']
    ydf = YumDnf(object())
    test_list = ydf.listify_comma_sep_strings_in_list(list_for_testing)
    assert test_list == ['f1', 'f2', 'f3', 'f4', 'f5', 'f6', 'f7', 'f8'], 'Comma separated elements are not detected and parsed'
    list_for_testing = ['f1, f2, f3, f4', 'f5', 'f6', 'f7,f8']
    test_list = ydf.listify_comma_sep_strings_in_list(list_for_testing)
    assert test_

# Generated at 2022-06-25 01:58:40.338111
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Test case for constructor of class YumDnf
    """

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum import YumDnf


# Generated at 2022-06-25 01:58:46.950134
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = MockModule()

# Generated at 2022-06-25 01:58:54.237473
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    ''' Unit test for method wait_for_lock of class YumDnf '''

    class MockModule(object):
        ''' Mock class for AnsibleModule '''

        def __init__(self, **kwargs):
            for key, val in kwargs.items():
                setattr(self, key, val)

        def fail_json(self, **kwargs):
            pass

    class MockYumDnf(YumDnf):
        ''' Mock class for YumDnf '''

        def __init__(self, module):
            self.pkg_mgr_name = 'DebugYum'
            self.lockfile = tempfile.mktemp()
            self.lock_timeout = 0
            super(MockYumDnf, self).__init__(module)


# Generated at 2022-06-25 01:59:02.208095
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    class YumDnfTester(YumDnf):
        def __init__(self, argument_spec, supports_check_mode):
            super(YumDnfTester, self).__init__(argument_spec, supports_check_mode)

        def is_lockfile_pid_valid(self):
            return False

    # Create fake module to pass in constructor
    class FakeModule(object):
        def __init__(self, param):
            self.params = param

        def fail_json(self, msg, results=[]):
            raise NotImplementedError

    # Method listify_comma_sep_strings_in_list should return a list
    param = dict(name=[])
    m = FakeModule(param)