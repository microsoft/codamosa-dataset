

# Generated at 2022-06-25 01:49:23.094601
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    print("Testing wait_for_lock")
    
    YumDnf_instance0 = YumDnf(module)
    YumDnf_instance0.wait_for_lock()
   

# Generated at 2022-06-25 01:49:23.903639
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    # TODO
    pass

# Generated at 2022-06-25 01:49:31.654968
# Unit test for constructor of class YumDnf
def test_YumDnf():
    try:
        import ansible.module_utils.yum
    except ImportError:
        import sys
        print("Skipping unit tests for class YumDnf because import of ansible.module_utils.yum failed: " + str(sys.exc_info()[0]))
        return

# Generated at 2022-06-25 01:49:39.745678
# Unit test for constructor of class YumDnf
def test_YumDnf():
  import inspect
  import sys, os
  import tempfile
  import shutil
  import subprocess
  import json
  import pytest

  #############################
  # Message Printing Subroutine
  #############################
  def print_message(module_name, test_name, message, state):
    """
    Prints a message in a consistent manner to STDOUT.
    Arguments:
      module_name -- the name of the module
      test_name -- the name of the test
      message -- additional message for the test
      state -- pass, fail, or error
    """
    print("\n")
    if state == "pass":
      print("TEST PASSED: " + module_name + ": " + test_name)

# Generated at 2022-06-25 01:49:40.214207
# Unit test for constructor of class YumDnf
def test_YumDnf():
    assert True


# Generated at 2022-06-25 01:49:42.387239
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    try:
        test_case_0()
    except:
        print('unexpected exception caught')
    else:
        print('test cases passed')

# Add a unit test for method run of class YumDnf

# Generated at 2022-06-25 01:49:52.660833
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    print("test_YumDnf_listify_comma_sep_strings_in_list")

    # Test cases
    str_0 = 'a,b,c'
    str_0_item_0  = 'a'
    str_0_item_1  = 'b'
    str_0_item_2  = 'c'
    str_0_list_0 = [str_0_item_0,str_0_item_1,str_0_item_2]

    str_1 = 'a,b,c'
    str_1_item_0  = 'a'
    str_1_item_1  = 'b'
    str_1_item_2  = 'c'

# Generated at 2022-06-25 01:49:53.616516
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    module = ArgumentSpec()
    YumDnf.run(module.params)

# Generated at 2022-06-25 01:49:58.462990
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    temp1 = tempfile.NamedTemporaryFile()
    file_name1 = temp1.name

    temp2 = tempfile.NamedTemporaryFile()
    file_name2 = temp2.name

    class MockYumDnf(YumDnf):

        def __init__(self, module):
            YumDnf.__init__(self, module)

        def is_lockfile_pid_valid(self):
            return True

    module_1 = MockYumDnf(file_name1)


# Generated at 2022-06-25 01:50:00.777675
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    some_list = ['a', 'b,c', 'd']
    yum = YumDnf(dict_0)
    assert set_0 == set_0


if __name__ == '__main__':
    test_case_0()
    test_YumDnf_listify_comma_sep_strings_in_list()

# Generated at 2022-06-25 01:50:18.804600
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """YumDnf constructor test case."""
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True
    )
    YumDnf(module)



# Generated at 2022-06-25 01:50:23.754550
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create dummy-pid file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(to_native('dummy-pid'))
        f.flush()
        pid_file_name = f.name

    # Create instance of YumDnf class and override method is_lockfile_pid_valid
    # with the implementation that always returns True
    yum_dnf_obj = YumDnf(None)
    yum_dnf_obj.lockfile = pid_file_name
    yum_dnf_obj.is_lockfile_pid_valid = lambda: True

    # Verify that is_lockfile_pid_valid method always returns True
    assert yum_dnf_obj.is_lockfile_pid_valid()

    # Remove dummy-pid file

# Generated at 2022-06-25 01:50:30.878959
# Unit test for method run of class YumDnf

# Generated at 2022-06-25 01:50:39.012416
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create a temp file
    temp_fd, temp_file = tempfile.mkstemp()

    # Create a temp file with PID in it
    with os.fdopen(temp_fd, 'w') as tmp:
        tmp.write(str(os.getpid()))

    # Validate method for an invalid PID
    assert YumDnf.is_lockfile_pid_valid(temp_file) == False

    # Validate method for a valid PID
    assert YumDnf.is_lockfile_pid_valid(temp_file) == True

    # Remove temp files
    os.remove(temp_file)

# Generated at 2022-06-25 01:50:44.854179
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    pkgmgr = YumDnf(None)
    assert pkgmgr.listify_comma_sep_strings_in_list([]) == []
    assert pkgmgr.listify_comma_sep_strings_in_list(["a", "b"]) == ["a", "b"]
    assert pkgmgr.listify_comma_sep_strings_in_list(["a", "b,c", "d"]) == ["a", "b", "c", "d"]
    assert pkgmgr.listify_comma_sep_strings_in_list(["a", "b,c,d"]) == ["a", "b", "c", "d"]

# Generated at 2022-06-25 01:50:53.502260
# Unit test for method run of class YumDnf

# Generated at 2022-06-25 01:50:59.614011
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary file that won't be locked
    temp_file = tempfile.NamedTemporaryFile()

    # Create a module with a non-existing lockfile
    module = AnsibleModule(
        argument_spec=dict(
            _ansible_lockfile=dict(type='path', default=to_native(temp_file.name)),
        )
    )

    y = YumDnf(module)

    assert y.is_lockfile_pid_valid()

# Generated at 2022-06-25 01:51:06.123407
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    import unittest

    class TestYumDnf(YumDnf):
        pass

    test_obj = TestYumDnf('')
    list_old = ['httpd', 'postfix,sendmail', 'telnet', 'rsh', 'rsync', 'rcp,nfs', 'xinetd', 'vsftpd,proftpd', 'samba', 'ypserv,tftp,tftp-server', 'talk', 'telnet-server', 'rsh-server', 'rsyncd', 'nfs-utils', 'rpcbind', 'xinetd', 'vsftpd,proftpd', 'smb', 'ypserv,tftp,tftp-server', 'talk-server', 'telnet-server']

# Generated at 2022-06-25 01:51:14.220869
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import os
    import tempfile
    import pytest
    import ansible.module_utils.yum
    # Create a temporary directory with a yum.pid present
    test_dir = tempfile.mkdtemp()
    yum_pid_path = os.path.join(test_dir, 'yum.pid')
    open(yum_pid_path, 'a').close()
    # Create the yumdnf object and assert that the pid file is valid
    # and is the one we created
    yum_object = ansible.module_utils.yum.Yum(object(), dict())
    yum_object.lockfile = yum_pid_path
    assert yum_object.is_lockfile_pid_valid() == True
    # Create the file and write a wrong pid.

# Generated at 2022-06-25 01:51:19.992044
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-25 01:51:54.264837
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    # Setup
    module = MockModule()
    YumDnf._is_lockfile_present = Mock(side_effect=[True, True, True, False, False])
    yum_dnf = YumDnf(module)
    yum_dnf.lock_timeout = 2

    # Run
    yum_dnf.wait_for_lock()

    # Assert
    assert module.fail_json.called is False


# Generated at 2022-06-25 01:52:01.344081
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    class YumDnfModule(YumDnf):
        def __init__(self, module):
            super(YumDnfModule, self).__init__(module)

        def is_lockfile_pid_valid(self):
            pass

    class YumDnfModuleMock(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, msg, results):
            raise NotImplementedError('YumDnfModuleMock.fail_json not implemented')

    yumdnf = YumDnfModule(YumDnfModuleMock())


# Generated at 2022-06-25 01:52:11.298697
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class MockModule(object):
        def __init__(self):
            self.params = dict(
                lock_timeout=2,
            )

        def fail_json(self, msg):
            self.msg = msg

    module = MockModule()
    yum = YumDnf(module)

    # test for lockfile not present
    yum.wait_for_lock()

    # test for lockfile present case 1
    open(module.params['lock_timeout'], 'a').close()
    yum.wait_for_lock()

    # test for lockfile present case 2
    os.remove(module.params['lock_timeout'])
    open(module.params['lock_timeout'], 'a').close()
    time.sleep(3)
    yum.wait_for_lock()

# Generated at 2022-06-25 01:52:22.409227
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create a fake lockfile
    lockfile = tempfile.NamedTemporaryFile(delete=False)
    lockfile.close()
    # Write fake PID to lockfile
    f = open(lockfile.name, 'w')
    f.write(str(os.getpid()))
    f.close()

    # Create a YumDnf instance
    class FakeYumDnf(YumDnf):
        pkg_mgr_name = 'Yum'
        lockfile = lockfile.name
        # Overwrite abstract method to avoid exception
        def is_lockfile_pid_valid(self):
            return True

    # Create a module instance
    class FakeModule(object):
        class ModuleFailJson(Exception):
            pass

        def fail_json(self, msg, results=[]):
            raise

# Generated at 2022-06-25 01:52:32.203832
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    def test_module(module_args, **kwargs):
        module = FakeAnsibleModule(module_args)
        yum_dnf = FakeYumDnf(module, lock_timeout=30)
        yum_dnf.wait_for_lock()
        assert not module.fail_json.called

    ARGS = {
        'state': 'present',
        'name': 'tree'
    }
    test_module(ARGS)

    def is_lockfile_pid_valid():
        return True

    ARGS = {
        'state': 'present',
        'name': 'tree',
        'lock_timeout': 10,
        'is_lockfile_pid_valid': is_lockfile_pid_valid,
    }
    test_module(ARGS)


# Generated at 2022-06-25 01:52:35.112552
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    # Here, module is a mock object
    # YumDnf.__init__(YumDnf, module)
    YumDnf.run(YumDnf, "module")
    # Here, __init__ should be mock after execution
    # YumDnf.is_lockfile_pid_valid(YumDnf)
    YumDnf.is_lockfile_pid_valid(YumDnf)



# Generated at 2022-06-25 01:52:39.028008
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    obj = YumDnf(object)
    with pytest.raises(NotImplementedError):
        obj.run()


# Generated at 2022-06-25 01:52:48.601690
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.six import StringIO
    # Initialize a dummy module
    class TestModule(object):
        def __init__(self):
            self.fail_json = self.fail_json_mock
        def fail_json_mock(self, msg):
            raise ValueError(msg)


# Generated at 2022-06-25 01:52:53.263356
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    '''
    Test for wait_for_lock of YumDnf class
    '''
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    class TestLock:
        '''
        Test Class for lock_pid
        '''
        def __init__(self, pid):
            self.pid = pid

        def is_lockfile_pid_valid(self):
            '''
            Test method for pid valid
            is_lockfile_pid_valid() function
            of class YumDnf
            '''
            return False

    def test_module_args():
        '''
        Test module arguments
        '''

# Generated at 2022-06-25 01:53:00.183942
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import ansible.utils.unsafe_proxy
    from ansible.compat.tests import unittest

    # create new instance of class ModuleStub
    class ModuleStub(ansible.utils.unsafe_proxy.AnsibleUnsafeText):

        class ModuleFailJson(ansible.utils.unsafe_proxy.AnsibleUnsafeText):

            def __init__(self, msg='', **kwargs):
                self.msg = msg
                self.kwargs = kwargs

        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            raise self.ModuleFailJson(**kwargs)


# Generated at 2022-06-25 01:53:52.565306
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    test_input_1 = ["a,b,c,d", "d,e,f", "f,g,h", "i,j,k,l,m", "a,b,c,d", "e", "f,g,h", "i,j,k,l,m"]
    test_input_2 = ["", "", "", "", "", "", "", ""]
    test_input_3 = ["a, b, c, d", "d,e,f", "f, g, h", "i, j, k, l, m", "a, b, c, d", "e", "f, g, h", "i, j, k, l, m"]

# Generated at 2022-06-25 01:53:58.539042
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    """ This method will not generate an exception if run method of class YumDnf is not implemented"""
    yumdnf = YumDnf(None)
    yumdnf.run()



# Generated at 2022-06-25 01:54:07.601111
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.package.yum.yum import Yum, YumPackageManager

    class TestModule(object):
        def __init__(self):
            self.argument_spec = yumdnf_argument_spec
            self.fail_json = None
            self.params = {}
            self.tmp = None

        def fail_json(self, *args, **kwargs):
            raise AssertionError("unexpected call to fail_json method")

    class TestYum(Yum):
        def __init__(self, module):
            self.module = module

        def run(self):
            return

    class TestYumPackageManager(YumPackageManager):
        def __init__(self, module):
            self.module

# Generated at 2022-06-25 01:54:14.745446
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    '''
    method to test the method YumDnf.listify_comma_sep_strings_in_list
    '''

    # create the module
    module = FakeModule()
    module.params['name'] = ['pkg1', 'pkg2', 'pkg3,pkg4,pkg5']

    # create a YumDnf object and set its parameter
    yumdnf = YumDnf(module)

    # test
    assert ['pkg1', 'pkg2', 'pkg3', 'pkg4', 'pkg5'] == yumdnf.listify_comma_sep_strings_in_list(yumdnf.names)



# Generated at 2022-06-25 01:54:16.777539
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    try:
        YumDnf().run()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 01:54:23.815821
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    """
    This is a unit test for method is_lockfile_pid_valid of class YumDnf
    """
    tmpdir = tempfile.mkdtemp()
    lockfile = tmpdir + "/test.pid"
    with open(lockfile, "w") as lock:
        pid = str(os.getpid())
        lock.write(pid)
        lock.close()

    yumdnf = YumDnf(None)
    yumdnf.lockfile = lockfile
    assert yumdnf.is_lockfile_pid_valid()

    with open(lockfile, "w") as lock:
        pid = str(999999)
        lock.write(pid)
        lock.close()

    assert not yumdnf.is_lockfile_pid_valid()


# Generated at 2022-06-25 01:54:27.119872
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    import json
    module = AnsibleModule(argument_spec={})
    pkg = YumDnf(module)
    assert pkg


# Generated at 2022-06-25 01:54:33.328101
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    result = True
    failed_test_cases = []
    try:
        m = YumDnf(None)
    except NotImplementedError:
        result = True
    except Exception as e:
        result = False
        failed_test_cases.append("Method run() of class YumDnf has thrown unexpected error '{0}'".format(to_native(e)))
    if not result:
        print("Failed to run test case 'test_YumDnf_run'. Following test cases failed: {0}".format(failed_test_cases))


# Generated at 2022-06-25 01:54:40.222732
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    """
    This unit test covers the scenario where method run of class YumDnf is invoked directly
    """
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    class FakeFs:
        def __init__(self, module):
            self.module = module

        def close(self):
            pass

    class FakeAnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False):
            self.argument_spec = argument_spec
            self.params = ImmutableDict(argument_spec, True)


# Generated at 2022-06-25 01:54:49.422760
# Unit test for constructor of class YumDnf
def test_YumDnf():

    yumdnf = YumDnf(module=None)

    assert yumdnf.allow_downgrade is False
    assert yumdnf.autoremove is False
    assert yumdnf.bugfix is False
    assert yumdnf.cacheonly is False
    assert yumdnf.conf_file is None
    assert yumdnf.disable_excludes is None
    assert yumdnf.disable_gpg_check is False
    assert yumdnf.disable_plugin == []
    assert yumdnf.disablerepo == []
    assert yumdnf.download_only is False
    assert yumdnf.download_dir is None
    assert yumdnf.enable_plugin == []
    assert yumdnf.enablerepo == []

# Generated at 2022-06-25 01:56:26.896691
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-25 01:56:29.635289
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    try:
        yumdnf = YumDnf()
        yumdnf.run()
    except NotImplementedError as e:
        print("Unit test passed.")



# Generated at 2022-06-25 01:56:36.646526
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = MagicMock()
    yum = YumDnf(module)

    assert yum.module == module
    assert yum.lockfile == '/var/run/yum.pid'
    assert yum.allow_downgrade == False
    assert yum.autoremove == False
    assert yum.bugfix == False
    assert yum.cacheonly == False
    assert yum.conf_file == None
    assert yum.disable_excludes == None
    assert yum.disable_gpg_check == False
    assert yum.disable_plugin == []
    assert yum.disablerepo == []
    assert yum.download_only == False
    assert yum.download_dir == None
    assert yum.enable_plugin == []
    assert yum.enablerepo == []
    assert yum

# Generated at 2022-06-25 01:56:42.664657
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum_utils import YumDnf

    def mock_fail_json(*args, **kwargs):
        module_args = kwargs['argument_spec']
        raise NotImplementedError()

    module = AnsibleModule(
        argument_spec={'param': {}},
        supports_check_mode=True
    )
    module.fail_json = mock_fail_json

    # Instantiate an object of YumDnf
    yum_dnf_obj = YumDnf(module)

    # Test using a list of strings with no comma separated strings
    input_list = ['string1', 'string2', 'string3']
    expected_output = ['string1', 'string2', 'string3']
   

# Generated at 2022-06-25 01:56:47.634728
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    yd = YumDnf(None)

    # Test if a bogus PID is correctly reported
    yd.lockfile = tempfile.NamedTemporaryFile(mode="w", delete=False).name
    with open(yd.lockfile, 'w') as f:
        f.write("bogus\n")
    assert not yd.is_lockfile_pid_valid()

    # Test if a PID from another user is correctly reported
    pid_from_another_user = tempfile.NamedTemporaryFile(mode="w", delete=False).name
    with open(pid_from_another_user, 'w') as f:
        f.write("{0}\n".format(os.getpid() - 1))
    os.chmod(pid_from_another_user, 0o600)
    yd.lock

# Generated at 2022-06-25 01:56:53.436842
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():

    class MockYumDnf(YumDnf):
        pass

    original_list = ['z', 'z,y', 'z,y,x', 'w', 'w,x', 'w,x,y']
    expected_result = ['z', 'y', 'z', 'y', 'x', 'w', 'x', 'w', 'x', 'y']

    results = MockYumDnf(None).listify_comma_sep_strings_in_list(original_list)
    for result in results:
        assert result in expected_result, "Invalid result: " + result
    assert len(results) == len(expected_result), "Incorrect number of results"



# Generated at 2022-06-25 01:57:02.293809
# Unit test for constructor of class YumDnf

# Generated at 2022-06-25 01:57:11.506373
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # _test_module.params is a dict that gets passed to the
    # module.run_command function
    _test_module = dict(params={'lock_timeout': 0})
    _test_module = type('', (), _test_module)

    class TestYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            # return True b/c we want to test waiting for the lock
            return True
    obj_wait_for_lock = TestYumDnf(_test_module)
    with tempfile.NamedTemporaryFile() as obj_tempfile:
        lockfile = os.path.basename(obj_tempfile.name)
        obj_wait_for_lock.lockfile = obj_tempfile.name

# Generated at 2022-06-25 01:57:18.152132
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    # create mock module
    module = type('', (), {})()
    module.fail_json = lambda **kw: None
    module.params = {
        'lock_timeout': 30,
        'pkg_mgr_name': 'yum',
    }
    mock_module = module

    # create mock file
    mock_pid = tempfile.mktemp()
    with open(mock_pid, 'w') as f:
        f.write('mock data')

    # create mock class object
    class MockYumDnf(object):

        def __init__(self, module):
            self.module = module
            self.lockfile = mock_pid

        def is_lockfile_pid_valid(self):
            return True

    # create mock call to method
    mock_YumDnf = MockYum

# Generated at 2022-06-25 01:57:24.937873
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import pytest

    from ansible.module_utils import basic
    from ansible.module_utils.ansible_release import __version__

    argument_spec = yumdnf_argument_spec

    test_obj = YumDnf(basic.AnsibleModule(argument_spec))
    test_obj.lock_timeout = -1
    test_obj._is_lockfile_present = lambda: True
    test_obj.is_lockfile_pid_valid = lambda: True

    with pytest.raises(SystemExit) as excinfo:
        test_obj.wait_for_lock()

    assert excinfo.value.code == 1
    assert isinstance(test_obj.module.params['ANSIBLE_MODULE_ARGS']['lock_timeout'], type(1))
    assert __version__ in test_obj