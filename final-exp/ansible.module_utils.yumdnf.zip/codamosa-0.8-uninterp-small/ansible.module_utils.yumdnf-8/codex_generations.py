

# Generated at 2022-06-25 01:49:21.478048
# Unit test for constructor of class YumDnf
def test_YumDnf():
    pass


# Generated at 2022-06-25 01:49:24.827013
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    bool_0 = False
    yum_dnf_0 = YumDnf(bool_0)
    assert yum_dnf_0.is_lockfile_pid_valid() == False

# Generated at 2022-06-25 01:49:25.999701
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    yum_dnf_0 = YumDnf(None)
    return None

# Generated at 2022-06-25 01:49:33.053501
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    list_0 = [ ]
    yum_dnf_0 = YumDnf(list_0)
    list_1 = ['Apple,Banana,Cherry']
    yum_dnf_1 = YumDnf(list_1)
    yum_dnf_2 = yum_dnf_0.listify_comma_sep_strings_in_list(yum_dnf_1)
    assert 'Apple' == yum_dnf_2[0]
    assert 'Banana' == yum_dnf_2[1]
    assert 'Cherry' == yum_dnf_2[2]
    assert len(yum_dnf_2) == 3



# Generated at 2022-06-25 01:49:33.531006
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    assert True

# Generated at 2022-06-25 01:49:35.035285
# Unit test for constructor of class YumDnf
def test_YumDnf():
    bool_0 = False
    yum_dnf_0 = YumDnf(bool_0)



# Generated at 2022-06-25 01:49:36.234064
# Unit test for constructor of class YumDnf
def test_YumDnf():
    bool_2 = False
    yum_dnf_2 = YumDnf(bool_2)



# Generated at 2022-06-25 01:49:37.904707
# Unit test for constructor of class YumDnf
def test_YumDnf():
    result = test_case_0()

if __name__ == '__main__':
    test_YumDnf()

# Generated at 2022-06-25 01:49:44.070775
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    bool_0 = os.path.isfile('/tmp/mock_file')
    yum_dnf_0 = YumDnf(bool_0)
    yum_dnf_0.lock_timeout = 0
    # AssertionError: True != False
    # TODO: Implement YumDnf.is_lockfile_pid_valid
    # yum_dnf_0.is_lockfile_pid_valid = mock.MagicMock(return_value=False)
    yum_dnf_0.wait_for_lock()


# Generated at 2022-06-25 01:49:52.764682
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    test_list = ['a', 'b', 'c']
    index = 0
    expected = ['a', 'b', 'c']

    def mock_module_fail_json(msg):
        raise Exception(msg)

    class MockYumDnf(YumDnf):
        def __init__(self, bool_val):
            pass
        def is_lockfile_pid_valid(self):
            return True

    mock_yum_dnf_0 = MockYumDnf(False)
    mock_yum_dnf_0.module = type('', (object,), {'fail_json': mock_module_fail_json})
    actual = mock_yum_dnf_0.listify_comma_sep_strings_in_list(test_list)

    assert actual == expected # Ass

# Generated at 2022-06-25 01:50:15.304413
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    import unittest
    import ansible.modules.packaging.os.yum as yum
    import ansible.modules.packaging.os.dnf as dnf
    class TestYumDnfListifyCommaSepStringsInList(unittest.TestCase):
        def test_listify_comma_sep_strings_in_list_yum(self):
            y = yum.YumModule(None)
            self.assertEqual(y.listify_comma_sep_strings_in_list(['pkg1']), ['pkg1'])
            self.assertEqual(y.listify_comma_sep_strings_in_list(['pkg1', 'pkg2,pkg3']), ['pkg1', 'pkg2', 'pkg3'])

# Generated at 2022-06-25 01:50:20.472191
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    module = ImmutableDict(
        check_mode=False,
        debug=True,
        diff=False,
        argument_spec=yumdnf_argument_spec,
    )
    x = YumDnf(module)
    assert not x.allow_downgrade
    assert not x.autoremove
    assert not x.bugfix
    assert not x.cacheonly
    assert x.conf_file is None
    assert x.disable_excludes is None
    assert not x.disable_gpg_check
    assert x.disable_plugin == []
    assert x.disablerepo == []
    assert not x.download_only
    assert x

# Generated at 2022-06-25 01:50:23.855739
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    '''
    Returns True if test passes
    '''

    test_list = ['test1', 'test2,test3']
    test_obj = YumDnf(None)
    new_list = test_obj.listify_comma_sep_strings_in_list(test_list)
    if len(new_list) != 3 or 'test1' not in new_list or 'test2' not in new_list or 'test3' not in new_list:
        return False
    return True



# Generated at 2022-06-25 01:50:28.233807
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    import unittest

    class test_YumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            return True

    class test_YumDnf_listify_comma_sep_strings_in_list(unittest.TestCase):

        def setUp(self):
            self.module = FakeModule()
            self.module.params['allow_downgrade'] = False
            self.module.params['autoremove'] = False
            self.module.params['bugfix'] = False
            self.module.params['cacheonly'] = False
            self.module.params['conf_file'] = None
            self.module.params['disable_excludes'] = None
            self.module.params['disable_gpg_check'] = False

# Generated at 2022-06-25 01:50:37.605622
# Unit test for constructor of class YumDnf
def test_YumDnf():
    destroy_fixture(fixture_path)
    create_fixture(fixture_path, yum_stdout)

    yum_dnf_obj = YumDnf(module)
    assert yum_dnf_obj.allow_downgrade == False
    assert yum_dnf_obj.autoremove == False
    assert yum_dnf_obj.bugfix == False
    assert yum_dnf_obj.cacheonly == False
    assert yum_dnf_obj.conf_file == None
    assert yum_dnf_obj.disable_excludes == None
    assert yum_dnf_obj.disable_gpg_check == False
    assert yum_dnf_obj.disable_plugin == []
    assert yum_dnf_obj.disablerepo == []
    assert yum

# Generated at 2022-06-25 01:50:41.893608
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """
    unit test to test listify_comma_sep_strings_in_list method
    of class YumDnf
    """
    obj = YumDnf(None)
    yum_dnf_class_method_result = obj.listify_comma_sep_strings_in_list(['foo,bar', 'xxx', 'yyy'])
    assert yum_dnf_class_method_result == ['foo', 'bar', 'xxx', 'yyy']

# Generated at 2022-06-25 01:50:51.658191
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    method to unit test the constructor of class YumDnf
    """
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
    )

    # Create instance of class YumDnf(
    test_yumdnf = YumDnf(module)

    # Test Instance Variables
    assert test_yumdnf.module == module
    assert test_yumdnf.allow_downgrade == False
    assert test_yumdnf.autoremove == False
    assert test_yumdnf.bugfix == False

# Generated at 2022-06-25 01:50:57.440371
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """ Test wait_for_lock(self) method of YumDnf class
    Test case:
        1. Check if lockfile is present
        2. Check if running process has lockfile pid
    """
    def is_lockfile_pid_valid(self):
        """ Test method to check if process id in lock file is valid"""
        if os.path.isfile(self.lockfile):
            with open(self.lockfile, 'r') as pid_file:
                pid = pid_file.read().strip()
            if os.path.isdir("/proc/%s" % pid):
                return True
            else:
                return False
        return False

    def fail_json(self, msg):
        """ Test method to fail_json"""
        print("Error: %s" % msg)


# Generated at 2022-06-25 01:51:05.918883
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.yum import YumDnfModule
    fake_module = YumDnfModule()

    yum_dnf = YumDnf(fake_module)
    # This should force the method to return an empty list instead of [""]
    assert yum_dnf.listify_comma_sep_strings_in_list([""]) == []

    # Tests that if a string containing comma separated strings is passed, the
    # method will return a list containing elements of the string split by the
    # comma instead of the string itself
    assert yum_dnf.listify_comma_sep_strings_in_list(
        ["A,B"]) == ["A", "B"]

    # Tests that if a list containing comma separated strings is passed, the
    # method will return a list

# Generated at 2022-06-25 01:51:15.732468
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    module = type("module", (), {
        "params": dict(name=[]),
        "fail_json": lambda **kwargs: sys.exit(1)
    })
    yumdnf_obj = YumDnf(module)
    names = [
        "name1,name2,name3,name4",
        "name5,name6",
        "name7",
        "name8,name9",
        "name10"
    ]
    result = yumdnf_obj.listify_comma_sep_strings_in_list(names)

# Generated at 2022-06-25 01:51:54.673203
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_str
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.basic import AnsibleModule

    class TestYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            return True

        def run(self):
            pass

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            self._tmp_path = None

        @property
        def tmp_path(self):
            if self._tmp_path is None:
                self._tmp_path = temp

# Generated at 2022-06-25 01:52:01.658014
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.modules.packaging.os.yum as yum
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.six as six


# Generated at 2022-06-25 01:52:11.324223
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    with tempfile.NamedTemporaryFile() as tmpfile:
        tmpfile.write(to_native('123456789'))
        tmpfile.seek(0)

        yumdnf = YumDnf(module=None)
        yumdnf.lockfile = tmpfile.name

        assert yumdnf.is_lockfile_pid_valid()

        tmpfile.seek(0)
        tmpfile.truncate()
        tmpfile.write(to_native('12345\n'))
        tmpfile.seek(0)

        assert not yumdnf.is_lockfile_pid_valid()

        tmpfile.seek(0)
        tmpfile.truncate()
        tmpfile.write(to_native('12345'))
        tmpfile.seek(0)

        assert not yum

# Generated at 2022-06-25 01:52:22.441537
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    tmp = tempfile.mkdtemp()

# Generated at 2022-06-25 01:52:26.652601
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible_collections.ansible.community.plugins.module_utils.package import yumdnf_base

    class test_class(yumdnf_base.YumDnf):
        pkg_mgr_name = "dummy_pkg_mgr_name"
        lockfile = "/tmp/lockfile"

        def is_lockfile_pid_valid(self):
            return True

    yumdnf_base_obj = test_class(None)
    yumdnf_base_obj.lock_timeout = 5

    # If a lockfile is present and lock_timeout is positive:
    # Test if the wait_for_lock method calls module.fail_json() after the
    # timeout has expired.

# Generated at 2022-06-25 01:52:31.128389
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    Test if lockfile is present or not.
    """

    temp_file = tempfile.NamedTemporaryFile(delete=False)

    if not temp_file:
        raise Exception('Could not create a tempfile')

    temp_file.close()

    mock_module = create_mock_module(
        temp_file.name,
        lock_timeout=2,
        list=None,
        state=None,
        autoremove=False,
        name=['']
    )

    mock_module.fail_json = lambda *args, **kwargs: mock_module.exit_args
    mock_module.exit_args = None

    yum_dnf = YumDnf(mock_module)


# Generated at 2022-06-25 01:52:40.462327
# Unit test for constructor of class YumDnf
def test_YumDnf():

    module = MockModule()

    my_class = YumDnf(module)

    assert my_class.allow_downgrade == 'False'
    assert my_class.autoremove == 'False'
    assert my_class.bugfix == 'False'
    assert my_class.cacheonly == 'False'
    assert my_class.conf_file == 'None'
    assert my_class.disable_excludes == 'None'
    assert my_class.disable_gpg_check == 'False'
    assert my_class.disable_plugin == '[]'
    assert my_class.disablerepo == '[]'
    assert my_class.download_only == 'False'
    assert my_class.download_dir == 'None'
    assert my_class.enable_plugin == '[]'
    assert my_class.enable

# Generated at 2022-06-25 01:52:46.623970
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    y = YumDnf(None)
    assert y.listify_comma_sep_strings_in_list([]) == []
    assert y.listify_comma_sep_strings_in_list([""]) == []
    assert y.listify_comma_sep_strings_in_list(["a"]) == ["a"]
    assert y.listify_comma_sep_strings_in_list(["a", "b"]) == ["a", "b"]
    assert y.listify_comma_sep_strings_in_list(["a", "a,b"]) == ["a", "b"]

# Generated at 2022-06-25 01:52:56.009821
# Unit test for constructor of class YumDnf
def test_YumDnf():
    fake_module = FakeModule()
    yum = YumDnf(fake_module)
    assert yum.allow_downgrade == fake_module.params['allow_downgrade']
    assert yum.autoremove == fake_module.params['autoremove']
    assert yum.bugfix == fake_module.params['bugfix']
    assert yum.cacheonly == fake_module.params['cacheonly']
    assert yum.conf_file == fake_module.params['conf_file']
    assert yum.disable_excludes == fake_module.params['disable_excludes']
    assert yum.disable_gpg_check == fake_module.params['disable_gpg_check']
    assert yum.disable_plugin == fake_module.params['disable_plugin']

# Generated at 2022-06-25 01:53:04.597933
# Unit test for constructor of class YumDnf
def test_YumDnf():
    # create mock module
    module = type('module', (object,), dict())
    module.params = dict()
    module.params['allow_downgrade'] = False
    module.params['autoremove'] = False
    module.params['bugfix'] = False
    module.params['cacheonly'] = False
    module.params['conf_file'] = None
    module.params['disable_excludes'] = None
    module.params['disable_gpg_check'] = False
    module.params['disable_plugin'] = []
    module.params['disablerepo'] = []
    module.params['download_only'] = False
    module.params['download_dir'] = None
    module.params['enable_plugin'] = []
    module.params['enablerepo'] = []
    module.params['exclude'] = []
   

# Generated at 2022-06-25 01:53:51.189501
# Unit test for constructor of class YumDnf
def test_YumDnf():
    # can't instantiate abstract class
    try:
        yd = YumDnf(None)
        raise AssertionError('YumDnf should be abstract class')
    except NotImplementedError:
        pass

    from ansible.module_utils.six.moves import mock

    module = mock.MagicMock()
    module.params = {}
    yd = YumDnf(module)

# Generated at 2022-06-25 01:53:59.071250
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yumdnf.yum import Yum

    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        mutually_exclusive=[['name', 'list']],
        required_one_of=[['name', 'list', 'update_cache']],
        supports_check_mode=True,
    )
    try:
        yum = Yum(module)
    except NotImplementedError:
        pass
    else:
        raise RuntimeError("NotImplementedError was not raised")



# Generated at 2022-06-25 01:54:09.421620
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    """
    Test for method YumDnf.is_lockfile_pid_valid
    Sample arguments
    lockfile = '/var/run/yum.pid'
    pkg_mgr_name = 'yum'
    """

    tempdir=tempfile.mkdtemp()

    # Create a fake file with PID of non-existent process
    lockfile = os.path.join(tempdir, "non-existent.pid")
    open(lockfile, 'w').write("99999999")

    # Create a fake file with PID of existing process
    lockfile_pid_exists = os.path.join(tempdir, "demo.pid")
    open(lockfile_pid_exists, 'w').write("%s" %os.getpid())

    # Create a fake file with invalid PID
    lockfile_pid_

# Generated at 2022-06-25 01:54:11.268751
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    assert YumDnf.is_lockfile_pid_valid() is None


# Generated at 2022-06-25 01:54:21.921589
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """
    Unit test for method listify_comma_sep_strings_in_list of class YumDnf
    """
    list_input = ["one", "two, three", "four , five"]
    list_output = ["one", "two", "three", "four", "five"]

    tmp_fd, temp_path = tempfile.mkstemp(prefix='test_yum')
    os.close(tmp_fd)
    os.remove(temp_path)
    mock_module = type('MockModule', (object, ), {'params': {'installroot': '/'}})
    mock_object = YumDnf(mock_module())
    list_result = mock_object.listify_comma_sep_strings_in_list(list_input)
    assert list_result == list

# Generated at 2022-06-25 01:54:30.425261
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yumdnf_module = YumDnf(module={'argument_spec': dict(name=dict(default=[], type='list'))})
    assert yumdnf_module.listify_comma_sep_strings_in_list(['a']) == ['a']
    assert yumdnf_module.listify_comma_sep_strings_in_list(['a, b']) == ['a', 'b']
    assert yumdnf_module.listify_comma_sep_strings_in_list(['a,  b']) == ['a', 'b']
    assert yumdnf_module.listify_comma_sep_strings_in_list(['a', 'b, c']) == ['a', 'b', 'c']
    assert yumdnf_module

# Generated at 2022-06-25 01:54:41.385483
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = type('', (), {})()

# Generated at 2022-06-25 01:54:49.562195
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class MockModule:
        class MockFailJson:
            def __init__(self, module, msg):
                self.msg = msg
                self.module = module

            def __call__(self, **kwargs):
                if self.module._is_lockfile_present:
                    raise Exception(self.msg)

        def __init__(self):
            self.params = dict()
            self.fail_json = self.MockFailJson(self, '{0} lockfile is held by another process'.format('foo'))

        @property
        def _is_lockfile_present(self):
            return False

    # Setup YumDnf instance with a lock_timeout of 1
    yumdnf = YumDnf(MockModule())
    yumdnf.lock_timeout = 1

    # Lock

# Generated at 2022-06-25 01:54:58.166437
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Initialising a class of type YumDnf
    """
    import ansible.module_utils.basic

# Generated at 2022-06-25 01:55:03.808478
# Unit test for constructor of class YumDnf
def test_YumDnf():
    class YumDnfTest:
        def __init__(self, params):
            self.params = params

    def check_val(val):
        return val


# Generated at 2022-06-25 01:56:32.996782
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    assert True == False

# Generated at 2022-06-25 01:56:37.868216
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Test not implemented
    """
    pass



# Generated at 2022-06-25 01:56:43.382852
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # register mock for _is_lockfile_present
    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
            self.is_lockfile_pid_valid = Mock(return_value=True)
            self.lockfile = None

        def _is_lockfile_present(self):
            return True

        def is_lockfile_pid_valid(self):
            return True

    # prepare module_args
    module_args = yumdnf_argument_spec.copy()
    module_args['lock_timeout'] = 1

    # prepare mock module
    mock_module = MagicMock(name='mock_module')
    mock_module.params = module_args

    # decide if the

# Generated at 2022-06-25 01:56:52.053504
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    '''
    Create a fake lockfile and see if wait_for_lock() removes it.
    '''
    fd, yum_pidfile = tempfile.mkstemp(prefix='ansible_test_yum_pidfile_')
    os.close(fd)

    module = MockModule()
    yum = YumDnf(module)
    yum.lockfile = yum_pidfile

    module.fail_json.mock_calls = []
    module.run_command.mock_calls = []

    # Mock method is_lockfile_pid_valid()
    yum.is_lockfile_pid_valid = lambda: True

    # Mock module.run_command()
    module.run_command.return_value = (0, "", "")

    # Lockfile present and not removed


# Generated at 2022-06-25 01:57:00.633043
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = MagicMock()
    instance = YumDnf(module)
    attr_list = dir(instance)
    assert 'module' in attr_list
    assert 'allow_downgrade' in attr_list
    assert 'autoremove' in attr_list
    assert 'bugfix' in attr_list
    assert 'cacheonly' in attr_list
    assert 'conf_file' in attr_list
    assert 'disable_excludes' in attr_list
    assert 'disable_gpg_check' in attr_list
    assert 'disable_plugin' in attr_list
    assert 'disablerepo' in attr_list
    assert 'download_only' in attr_list
    assert 'download_dir' in attr_list
    assert 'enable_plugin' in attr_

# Generated at 2022-06-25 01:57:09.121384
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.modules.package.yum.yum import YumModule
    from ansible.modules.package.dnf.dnf import DnfModule

    # Check if constructor of class YumDnf populates correct variables
    # when input parameters are given to constructor of class YumModule

# Generated at 2022-06-25 01:57:14.429119
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    y = YumDnf('')
    assert y.is_lockfile_pid_valid() is False


# Generated at 2022-06-25 01:57:20.678571
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    assert YumDnf.listify_comma_sep_strings_in_list(
        YumDnf, ['a', 'b,c', 'd, e ,f']) == ['a', 'b', 'c', 'd', 'e', 'f']
    assert YumDnf.listify_comma_sep_strings_in_list(YumDnf, ['a, b']) == ['a', 'b']
    assert YumDnf.listify_comma_sep_strings_in_list(YumDnf, ['']) == []
    assert YumDnf.listify_comma_sep_strings_in_list(YumDnf, ['a,b,c']) == ['a', 'b', 'c']



# Generated at 2022-06-25 01:57:30.920610
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    def is_lockfile_pid_valid():
        return True

    def module_fail_json():
        return True
    class Module():
        def __init__(self):
            self.fail_json = module_fail_json

    y = YumDnf(Module())
    y.lock_timeout = 1
    y.wait_for_lock = wait_for_lock
    y.is_lockfile_pid_valid = is_lockfile_pid_valid
    def _is_lockfile_present():
        return True

    y._is_lockfile_present = _is_lockfile_present
    y.lockfile = tempfile.mkstemp()[1]
    y.pkg_mgr_name = "YUM"
    assert y._is_lockfile_present() == True
    y.wait_for_

# Generated at 2022-06-25 01:57:40.836426
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    obj = YumDnf(None)
    test_cases = {
        "existing_list": [1, 2, 3],
        "given_list": [],
        "expected_list": [1, 2, 3],
    }
    obj.listify_comma_sep_strings_in_list(test_cases["given_list"])
    assert test_cases["given_list"] == test_cases["expected_list"]
    test_cases = {
        "existing_list": [1, 2, 3],
        "given_list": None,
        "expected_list": [1, 2, 3],
    }
    obj.listify_comma_sep_strings_in_list(test_cases["given_list"])