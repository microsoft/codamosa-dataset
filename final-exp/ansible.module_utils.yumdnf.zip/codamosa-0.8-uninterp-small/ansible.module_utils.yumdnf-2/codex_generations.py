

# Generated at 2022-06-25 01:49:29.212904
# Unit test for constructor of class YumDnf
def test_YumDnf():

    with tempfile.TemporaryDirectory() as tmpdirname:
        bytes_0 = b'\xad\x9b\x0c\xc0\xff\x8a\x85\xe7C\xea\x1e\x9f~\x9f\x8f'
        yum_dnf_0 = YumDnf(bytes_0)

        yum_dnf_1 = YumDnf(bytes_0)
        assert yum_dnf_0.bugfix == yum_dnf_1.bugfix
        assert yum_dnf_0.update_cache == yum_dnf_1.update_cache
        assert yum_dnf_0.names == yum_dnf_1.names
        assert yum_dnf_0.download_only == yum

# Generated at 2022-06-25 01:49:33.305882
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    bytes_1 = b'u\xf1b\x82\xd6$~\x96\xeb\xd2Drk{\r\x9b\x03\x01\xa2\x8a'
    bytes_1 = YumDnf(bytes_1)
    bytes_1.run()

if __name__ == '__main__':
    test_YumDnf_run()
    test_case_0()

# Generated at 2022-06-25 01:49:36.801557
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    bytes_0 = b'Z\xa3\x8f\x1a\xe2\x19%\xaf\xc7\xa9\x9a\x12\xf1\x18\xc0C@\xee\x11'
    yum_dnf_0 = YumDnf(bytes_0)

    # Call wait_for_lock() method


# Generated at 2022-06-25 01:49:44.940893
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    bytes_0 = b'u\xf1b\x82\xd6$~\x96\xeb\xd2Drk{\r\x9b\x03\x01\xa2\x8a'
    yum_dnf_0 = YumDnf(bytes_0)
    bytes_1 = b'\xfc\x87\xc3y\xa3\x1b\xdb\x9d\x05V}\x13\xba\xdb\xae\x18\xa5\xcf\xce'
    yum_dnf_0.lockfile = bytes_1
    result = yum_dnf_0.wait_for_lock()
    assert result == None


# Generated at 2022-06-25 01:49:50.426824
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = dict()
    module['argument_spec'] = dict()
    module['params'] = dict()
    module['params']['allow_downgrade'] = False
    module['params']['autoremove'] = False
    module['params']['bugfix'] = False
    module['params']['cacheonly'] = False
    module['params']['conf_file'] = None
    module['params']['disable_excludes'] = None
    module['params']['disable_gpg_check'] = False
    module['params']['disable_plugin'] = list()
    module['params']['disablerepo'] = list()
    module['params']['download_only'] = False
    module['params']['download_dir'] = None
    module['params']['enable_plugin'] = list()

# Generated at 2022-06-25 01:49:51.223539
# Unit test for constructor of class YumDnf
def test_YumDnf():
    test_case_0()


# Generated at 2022-06-25 01:49:55.531323
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    yum_dnf_0 = YumDnf(None)
    try:
        yum_dnf_0.wait_for_lock()
    except Exception as e:
        assert False, "Fails in wait_for_lock: {}".format(e.args)


# Generated at 2022-06-25 01:50:04.150344
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    bytes_0 = b'u\xf1b\x82\xd6$~\x96\xeb\xd2Drk{\r\x9b\x03\x01\xa2\x8a'
    str_0 = "09,^p\x11&\x16\x07\x4c\xea\x07\x15\x17\x1c\x02\x0cI\x13\x1d\x16\x01\x18\x06j"
    yum_dnf_0 = YumDnf(bytes_0)
    yum_dnf_0.listify_comma_sep_strings_in_list(str_0)


# Generated at 2022-06-25 01:50:12.984546
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    bytes_0 = b'u\xf1b\x82\xd6$~\x96\xeb\xd2Drk{\r\x9b\x03\x01\xa2\x8a'
    yum_dnf_0 = YumDnf(bytes_0)
    ret_val_0 = yum_dnf_0.listify_comma_sep_strings_in_list([''])
    ret_val_1 = yum_dnf_0.listify_comma_sep_strings_in_list([''])
    assert ret_val_0 == []
    assert ret_val_1 == []


# Generated at 2022-06-25 01:50:16.363921
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    test_case_0()

# Generated at 2022-06-25 01:50:34.918999
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    var_0 = dict()


# Generated at 2022-06-25 01:50:41.517389
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    var_0 = ['']
    obj = YumDnf(var_0)
    var_0 = ['a', 'b']
    obj = YumDnf(var_0)
    var_0 = ['a', 'b', 'c']
    obj = YumDnf(var_0)
    var_0 = ['a', 'b', 'c', '']
    obj = YumDnf(var_0)
    var_0 = ['a', 'b', 'c', '', '']
    obj = YumDnf(var_0)
    var_0 = ['a,b', 'c']
    obj = YumDnf(var_0)
    var_0 = ['a,b,c']
    obj = YumDnf(var_0)
    var

# Generated at 2022-06-25 01:50:51.620429
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = dict()
    assert test_case_0() == 0
    assert test_case_1() == 0
    assert test_case_2() == 0
    assert test_case_3() == 0
    assert test_case_4() == 0
    assert test_case_5() == 0
    assert test_case_6() == 0
    assert test_case_7() == 0
    assert test_case_8() == 0
    assert test_case_9() == 0
    assert test_case_10() == 0
    assert test_case_11() == 0
    assert test_case_12() == 0
    assert test_case_13() == 0
    assert test_case_14() == 0
    assert test_case_15() == 0
    assert test_case_16() == 0
    assert test_case_

# Generated at 2022-06-25 01:51:01.609705
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    obj0 = YumDnf(var_0)
    obj0.listify_comma_sep_strings_in_list([' a, b ', ' c '])
    obj0.listify_comma_sep_strings_in_list(['a', 'a,b'])
    obj0.listify_comma_sep_strings_in_list(['a, b', 'a , b'])
    obj0.listify_comma_sep_strings_in_list(['a'])
    obj0.listify_comma_sep_strings_in_list([' a, b '])
    obj0.listify_comma_sep_strings_in_list(['a,b', 'c'])
    obj0.listify_comma_sep_strings_in

# Generated at 2022-06-25 01:51:05.443412
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    yum_dnf = YumDnf(var_0)
    yum_dnf.wait_for_lock()


# Generated at 2022-06-25 01:51:10.706546
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    # Initialize the class
    yumdnf = YumDnf(var_0)

    # Define expected parameter values
    some_list = ["one", "two,three,four", "five"]

    # Perform the method
    result = yumdnf.listify_comma_sep_strings_in_list(some_list)

    # Assert the result
    assert result == ["one", "two", "three", "four", "five"]


# Generated at 2022-06-25 01:51:19.587251
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    var_0 = dict()
    var_1 = dict()
    test_modules_0 = YumDnf(var_0)
    test_modules_1 = YumDnf(var_1)
    print("Testing function is_lockfile_pid_valid")
    print("Module: %s" % test_modules_0.__class__.__name__)
    var_0 = test_modules_0.is_lockfile_pid_valid()
    if var_0:
        test_case_0()
    else:
        var_1 = test_modules_1.is_lockfile_pid_valid()
    print("Test completed")


# Generated at 2022-06-25 01:51:28.281702
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf

# Generated at 2022-06-25 01:51:32.672082
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    print()
    print("Testing method wait_for_lock of class YumDnf")

    obj = YumDnf(var_0)
    YumDnf.wait_for_lock(obj)




# Generated at 2022-06-25 01:51:38.880260
# Unit test for constructor of class YumDnf
def test_YumDnf():
    var_0 = dict()
    module = dict()

    # yumdnf = YumDnf(module)
    # yumdnf.is_lockfile_pid_valid()
    # yumdnf._is_lockfile_present()
    # yumdnf.wait_for_lock()

if __name__ == "__main__":
    test_case_0()
    test_YumDnf()

# Generated at 2022-06-25 01:52:16.239925
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    assert YumDnf.listify_comma_sep_strings_in_list(var_0) == ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n"], \
        "YumDnf.listify_comma_sep_strings_in_list() FAILED"


# Generated at 2022-06-25 01:52:24.855305
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    var_0 = dict()
    var_1 = []
    assert YumDnf.listify_comma_sep_strings_in_list(var_0, var_1) == None

    input_var_2 = ["abc", "abc, abc"]
    output_expected_var_2 = ["abc", "abc", "abc"]
    assert YumDnf.listify_comma_sep_strings_in_list(var_0, input_var_2) == output_expected_var_2

    input_var_3 = ["abc", "abc,", "abc"]
    output_expected_var_3 = ["abc", "abc", "abc"]
    assert YumDnf.listify_comma_sep_strings_in_list(var_0, input_var_3) == output

# Generated at 2022-06-25 01:52:27.729529
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    test_case_0()

# Generated at 2022-06-25 01:52:31.250956
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    fixture_0 = []
    expected_0 = []
    actual_0 = YumDnf.listify_comma_sep_strings_in_list(fixture_0)
    assert actual_0 == expected_0

if __name__ == '__main__':
    import sys
    num_args = len(sys.argv)
    if num_args > 1 and sys.argv[1] == 'test_YumDnf_listify_comma_sep_strings_in_list':
        test_YumDnf_listify_comma_sep_strings_in_list()

# Generated at 2022-06-25 01:52:32.450997
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    YumDnf(var_0).is_lockfile_pid_valid()


# Generated at 2022-06-25 01:52:36.880017
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    # Declare the parameter as a global variable
    global module

# Generated at 2022-06-25 01:52:42.124922
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    test_instance = YumDnf.__new__()
    test_instance.lock_timeout = 0
    test_instance._is_lockfile_present = lambda : True
    test_instance.lockfile = tempfile.mktemp()

    test_instance.wait_for_lock()

    # AssertionError: AssertionError: {0} lockfile is held by another process != None
    pass

# Generated at 2022-06-25 01:52:49.446207
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    var_0 = dict()
    var_0 = dict()
    var_1 = dict()
    var_1 = dict()
    def test_case_0(self):
        # Assign §§TEST_CASE_0_YUM_LOCK_FILE to "/tmp/test_lockfile"
        # Assign $$TEST_CASE_0_YUM_PID to 1
        # Create file "/tmp/test_lockfile"
        # If $$TEST_CASE_0_YUM_PID exists, assert True
        pass

# Generated at 2022-06-25 01:52:52.905142
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Setup
    self = YumDnf()

    # Calling wait_for_lock
    result = self.wait_for_lock()

    # Test assertions
    if type(result) is not None:
        raise AssertionError()


# Generated at 2022-06-25 01:52:57.875912
# Unit test for constructor of class YumDnf
def test_YumDnf():
    try:
        # Prepare the test
        os.chdir(tempfile.gettempdir())

        # Test the following function is called with valid parameters,
        # and return positive value
        test_case_0()
    except BaseException as e:
        print(to_native(e))
        raise

# Generated at 2022-06-25 01:53:29.263700
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yum_dnf_obj = YumDnf(None)
    list_of_strings = ['a,b,c', 'apple, banana, orange', '1,2,3', 'foo , bar , baz' ]
    list_after_listify_comma_sep_strings_in_list = yum_dnf_obj.listify_comma_sep_strings_in_list(list_of_strings)
    expected_result = ['a', 'b', 'c', 'apple', 'banana', 'orange', '1', '2', '3', 'foo', 'bar', 'baz']
    assert list_after_listify_comma_sep_strings_in_list == expected_result

# Generated at 2022-06-25 01:53:34.300091
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import unittest
    import ansible.modules.package_manager.yum as yum
    from ansible.module_utils.basic import AnsibleModule

    class TestYumDnf_wait_for_lock(unittest.TestCase):
        def test_YumDnf_wait_for_lock(self):
            tempdir = tempfile.mkdtemp()
            file_to_be_locked = os.path.join(tempdir, "file_to_be_locked")
            file_to_be_locked_second = os.path.join(tempdir, "file_to_be_locked_second")
            lock_path = os.path.join(tempdir, "yum.lock")

# Generated at 2022-06-25 01:53:40.834753
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    make_module = lambda path: lambda **kw: lambda **kw2: None
    make_module.fail_json = lambda **kw: None
    make_module.run_command = lambda cmd, **kw: (0, "/usr/bin/yum", "")
    yd = YumDnf(make_module)
    if os.path.exists("/var/run/yum.pid"):
        yd.wait_for_lock()

# Generated at 2022-06-25 01:53:47.918554
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yum_dnf = YumDnf(None)

    # Test 1: Test if empty list is returned for empty list
    test_list = []
    expected_list = []
    assert expected_list == yum_dnf.listify_comma_sep_strings_in_list(test_list)

    # Test 2: Test if None is returned for None list
    test_list = None
    expected_list = []
    assert expected_list == yum_dnf.listify_comma_sep_strings_in_list(test_list)

    # Test 3: Test if list with one element is returned
    test_list = ['test_1']
    expected_list = ['test_1']
    assert expected_list == yum_dnf.listify_comma_sep_strings_in_list

# Generated at 2022-06-25 01:53:52.183279
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=yumdnf_argument_spec)

    # test with empty list
    old_list = []
    new_list = module.YumDnf.listify_comma_sep_strings_in_list(old_list)
    assert new_list == [], "expected list: [] , but got %s" % new_list

    # test with a single element
    old_list = ["a"]
    new_list = module.YumDnf.listify_comma_sep_strings_in_list(old_list)

# Generated at 2022-06-25 01:54:03.015101
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():

    # No input values
    yum_dnf = YumDnf(dict())
    assert yum_dnf.listify_comma_sep_strings_in_list([]) == []

    # Empty list
    yum_dnf = YumDnf(dict())
    assert yum_dnf.listify_comma_sep_strings_in_list([""]) == []

    # 2 elements in a list
    yum_dnf = YumDnf(dict())
    assert yum_dnf.listify_comma_sep_strings_in_list(["ansible", "python"]) == ["ansible", "python"]

    # 2 elements in a list and 2 comma separated in a single list element
    yum_dnf = YumDnf(dict())
    assert y

# Generated at 2022-06-25 01:54:11.524812
# Unit test for constructor of class YumDnf

# Generated at 2022-06-25 01:54:21.944546
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # test_module_dir and test_lockfile are declared inside mock_yumdnf.py
    # test_module_dir and test_lockfile are used to test wait_for_lock method
    # of YumDnf.
    # test_module_dir and test_lockfile are created/removed dynamically
    # while executing unit testcase.
    #
    # To run the unit testcase:
    # 1. In class YumDnf, import mock_yumdnf.py by adding the following line of code.
    # from ansible_collections.ansible.community.tests.unit.modules.packaging.os.yum import mock_yumdnf

    # 2. To see the test output, set the following environment variable.
    # $ DEBUG=true
    import os
    import mock_yumdnf

# Generated at 2022-06-25 01:54:30.448329
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    '''
    This is a unit test for YumDnf.listify_comma_sep_strings_in_list method.
    '''
    class TestYumDnf(YumDnf):
        def __init__(self):
            pass

        def is_lockfile_pid_valid(self):
            return

    # declare a list
    test_list = ['abc', 'def', 'ghi, jkl', 'mno,pqr', 'stu,vwx,yz']

    # mock TestYumDnf object
    TestYumDnfObj = TestYumDnf()

    # apply method listify_comma_sep_strings_in_list to test_list
    test_list = TestYumDnfObj.listify_comma_sep_strings

# Generated at 2022-06-25 01:54:41.411275
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # create a mock module
    class MockModule(object):
        def __init__(self, name):
            self.name = name
            self.params = dict()

        def fail_json(self, msg):
            raise Exception(msg)

    class MockYumDnf(YumDnf):
        def __init__(self):
            module = MockModule('yumdnf')
            super(MockYumDnf, self).__init__(module)

        # mock _is_lockfile_present
        def _is_lockfile_present(self):
            return True

        # mock wait_for_lock
        def wait_for_lock(self):
            return

        # mock is_lockfile_pid_valid
        def is_lockfile_pid_valid(self):
            return True

    #

# Generated at 2022-06-25 01:55:38.041404
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    import unittest
    class TestYumDnf(YumDnf):
        def __init__(self, module):
            super(TestYumDnf, self).__init__(module)
        def is_lockfile_pid_valid(self):
            return None
    test_module = type('test_module', (), {})
    test_module.module = type('module', (), {})
    test_module.module.fail_json = lambda msg: msg
    test_module.module.check_mode = False


# Generated at 2022-06-25 01:55:46.010129
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    module = AnsibleModule(argument_spec={})
    pkg = YumDnf(module)

    pid = os.getpid()
    lockfile = tempfile.mktemp()
    with open(lockfile, 'w') as fh:
        fh.write(to_native(pid))

    pkg.lockfile = lockfile
    pkg.lock_timeout = 0

    try:
        pkg.wait_for_lock()
    except:
        # We are expecting a failure
        pass
    else:
        assert False, "lockfile '%s' with our pid '%s' should not be there." % (pkg.lockfile, pid)

    os.remove(lockfile)
    assert True

# Generated at 2022-06-25 01:55:55.172408
# Unit test for constructor of class YumDnf
def test_YumDnf():
    class Module:
        def fail_json(self, msg, results=None):
            self.fail = msg

    mod = Module()

# Generated at 2022-06-25 01:56:03.823182
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yum_dnf = YumDnf(object)
    actual = yum_dnf.listify_comma_sep_strings_in_list(['a,b,c'])
    expected = ['a', 'b', 'c']
    assert actual == expected, 'Method returned %s expected %s' % (actual, expected)
    actual = yum_dnf.listify_comma_sep_strings_in_list(['abc'])
    expected = ['abc']
    assert actual == expected, 'Method returned %s expected %s' % (actual, expected)
    actual = yum_dnf.listify_comma_sep_strings_in_list(['a,b,c', 'abc'])
    expected = ['a', 'b', 'c', 'abc']
    assert actual == expected

# Generated at 2022-06-25 01:56:10.475520
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    # Some data-providing methods:
    def mock_is_lockfile_present(self):
        return False

    def mock_is_lockfile_pid_valid(self):
        return True

    def mock_getpid(self):
        return 333

    def mock_getppid(self):
        return 444

    class MockModule(object):
        """
        Mock class for the ansible module in yum_dnf_common.py
        """

        def __init__(self):
            self.params = {
                'lock_timeout': 1,
            }

        def fail_json(self, msg, results=None):
            print('ERROR: {0}'.format(msg))
            return


# Generated at 2022-06-25 01:56:20.296435
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Unit test for constructor of class YumDnf.

    AnsibleModule object is mocked as it is quite complex and it is not
    necessary for constructor's test.
    """
    yumdnf_argument_spec['required_one_of'] = [('name', 'list', 'update_cache')]
    yumdnf_argument_spec['mutually_exclusive'].append(('name', 'list'))


# Generated at 2022-06-25 01:56:28.781145
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """
    This test covers the following:
    1. Scenario where there are no commas in the list
    2. Scenario where there are comma separated strings in the list
    3. Scenario where there are consecutive comma separated strings in the list
    4. Scenario where there are strings with comma in list
    5. Scenario where there is an emtpy list
    6. Scenario where list having an empty string
    """
    yd = YumDnf('module')
    assert yd.listify_comma_sep_strings_in_list(['a', 'b', 'c']) == ['a', 'b', 'c']


# Generated at 2022-06-25 01:56:36.430197
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():

    # Importing it here to avoid dependency on YumDnf in yum.py
    from ansible.modules.packaging.os import yum
    y = yum.Yum(dict())

    # Defining test cases
    # Test cases - expected

# Generated at 2022-06-25 01:56:42.004780
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    assert YumDnf.listify_comma_sep_strings_in_list(["bash,foo"]) == ["bash", "foo"]
    assert YumDnf.listify_comma_sep_strings_in_list(["bash"]) == ["bash"]
    assert YumDnf.listify_comma_sep_strings_in_list(["bash, foo", "bash foo"]) == ["bash", "foo", "bash foo"]
    assert YumDnf.listify_comma_sep_strings_in_list([","]) == []
    assert YumDnf.listify_comma_sep_strings_in_list([]) == []

# Generated at 2022-06-25 01:56:50.449065
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import json
    import os
    import shutil
    import sys
    import tempfile
    sys.modules['ansible'] = __import__('mock')
    import ansible.module_utils

    def yum_mock(self):
        if self.lock_timeout:
            return
        else:
            return

    # import Ansible module snippets
    sys.modules['ansible.module_utils.basic'] = __import__('mock')
    sys.modules['ansible.module_utils.basic'].AnsibleModule = __import__('mock')
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import configparser

    # import module snippets

# Generated at 2022-06-25 01:58:32.840569
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    Test wait_for_lock when lock is not present
    """
    class FakeModule(object):
        params = {'lock_timeout': -1}

    class FakeYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            pass

        def _is_lockfile_present(self):
            return False

    yd = FakeYumDnf(FakeModule())
    yd.wait_for_lock()


# Generated at 2022-06-25 01:58:42.458112
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    obj = ansible.module_utils.basic.AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    yum = YumDnf(obj)
    assert yum.listify_comma_sep_strings_in_list(['foo']) == ['foo']
    assert yum.listify_comma_sep_strings_in_list(['foo,bar']) == ['foo', 'bar']
    assert yum.listify_comma_sep_strings_in_list(['foo,bar', 'baz']) == ['foo', 'bar', 'baz']
    assert yum.listify_comma_sep_strings_in_list(['foo', 'bar,baz']) == ['foo', 'bar', 'baz']
    assert yum.listify

# Generated at 2022-06-25 01:58:48.926663
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible.module_utils.basic import AnsibleModule

    def execute_module(module):
        mod = AnsibleModule(module)
        lockfile = tempfile.NamedTemporaryFile()
        mod.params['lock_timeout'] = 0
        y = YumDnf(mod)
        y.lockfile = lockfile.name
        try:
            y.wait_for_lock()
        except Exception as error:
            mod.fail_json(msg=to_native(error), results=[])

        lockfile.close()

    def execute_module_and_fail(module):
        mod = AnsibleModule(module)
        lockfile = tempfile.NamedTemporaryFile()
        mod.params['lock_timeout'] = 0
        y = YumDnf(mod)
        y.lockfile = lockfile

# Generated at 2022-06-25 01:58:54.631301
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # create mock YumDnf class and its attributes
    class MockModule:
        def __init__(self):
            self.params = dict()
        def fail_json(self, msg, results=[]):
            raise SystemExit(msg)

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
            self.lockfile = '/test.pid'

        def is_lockfile_pid_valid(self):
            return True

    module = MockModule()
    module.params = {'lock_timeout': '5'}
    mockYumDnf = MockYumDnf(module)

    # build test cases:
    # first case: no lock file

# Generated at 2022-06-25 01:59:02.066635
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.modules.packaging.os import yum
    from ansible.modules.packaging.os import dnf
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestYumDnfRun(unittest.TestCase):
        def test_run_yum_dnf(self):
            yum_dnf_modules = [yum, dnf]
            for module in yum_dnf_modules:
                with self.subTest(module=module):
                    self.assertRaises(RuntimeError, module.run)

    return unittest.makeSuite(TestYumDnfRun)