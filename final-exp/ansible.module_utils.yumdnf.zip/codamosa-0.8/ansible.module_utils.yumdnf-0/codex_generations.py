

# Generated at 2022-06-11 06:28:43.385334
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import pprint
    import sys
    if sys.version_info.major < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 06:28:53.358658
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    test_module = YumDnf(module)
    test_module.lockfile = tempfile.NamedTemporaryFile(delete=False).name
    test_module.lock_timeout = 20

    # case when lockfile exists
    test_module.is_lockfile_pid_valid = lambda: True
    test_module.wait_for_lock()

    time.sleep(21)
    # case when lockfile is not present
    test_module._is_lockfile_present = lambda: False
    test_module.wait_for_lock()

    # case when lockfile exists but lock_timeout is 0
    test_module._is_lockfile_present = lambda: True
    test_module.lock_timeout = 0
    test_module.wait_for_lock()

    # case when lockfile exists and lock_timeout is a positive

# Generated at 2022-06-11 06:29:01.304505
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Unit test for construction of class YumDnf
    """

    def test_parameters(parameters):
        """
        Sub method to test that parameters in the constructor are set according to the argument specification
        """
        for (param_name, param_value) in parameters.items():
            try:
                result = getattr(yumdnf_obj, param_name)
            except AttributeError:
                raise Exception("Attribute '%s' not found in class %s " % (param_name, yumdnf_obj.__class__.__name__))

# Generated at 2022-06-11 06:29:10.488568
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    Check if the wait_for_lock method of YumDnf, waits for timeout seconds and raises an error
    """

    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    from os.path import isfile

    class MockModule(object):
        def __init__(self):
            self.fail_json = self.mock_fail_json
            self.exit_json = self.mock_exit_json
            self.check_mode = False
            self.fail_json_was_called = False
            self.exit_json_was_called = False

        def mock_fail_json(self, results, msg):
            self.fail_json_was_called = True


# Generated at 2022-06-11 06:29:20.300097
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible_collections.testns.testcoll.plugins.modules.package.yum import YumDnf
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2


# Generated at 2022-06-11 06:29:28.741610
# Unit test for constructor of class YumDnf

# Generated at 2022-06-11 06:29:38.100263
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class module:
        def __init__(self, msg):
            self.msg = msg

        def fail_json(self, msg):
            raise Exception(msg)

        def params(self):
            return {}

    class YumDnf(YumDnf):
        def __init__(self, module):
            YumDnf.__init__(self, module)

            self.pkg_mgr_name = "YUM"
            self.lock_timeout = -2
            self.lockfile = tempfile.gettempdir() + 'yum.pid'

        def is_lockfile_pid_valid(self):
            return True

    # Test case 1: lockfile exists
    with open(YumDnf(module("")).lockfile, 'w') as f:
        f.write("")


# Generated at 2022-06-11 06:29:39.920517
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    import mock

    yum_dnf = YumDnf(mock.Mock())
    yum_dnf.run()

# Generated at 2022-06-11 06:29:47.118369
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    class FakeModule():
        def __init__(self):
            self.params = {}
            self.check_mode = False

        def fail_json(self, **parser):
            return

        def exit_json(self, **kwargs):
            return

        def set_fact(self, **kwargs):
            return


# Generated at 2022-06-11 06:29:53.314764
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Create a YumDnf object with minimal parameters
    yd = YumDnf(module=dict())

    # Check error message when lockfile is present
    tempfile_fd, yd.lockfile = tempfile.mkstemp()
    with open(yd.lockfile, 'w'):
        pass
    yd.lock_timeout = 0
    try:
        yd.wait_for_lock()
    except SystemExit as e:
        assert e.code == 1
        assert e.args[0].startswith('yum lockfile is held by another process')

    # Set self.lock_timeout to a positive value.
    # Check that error is not raised when the lockfile is present
    yd.lock_timeout = 1

# Generated at 2022-06-11 06:30:19.736705
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = AnsibleModule(yumdnf_argument_spec)
    yumdnf = YumDnf(module)

    assert yumdnf.module == module
    assert yumdnf.allow_downgrade == module.params['allow_downgrade']
    assert yumdnf.autoremove == module.params['autoremove']
    assert yumdnf.bugfix == module.params['bugfix']
    assert yumdnf.cacheonly == module.params['cacheonly']
    assert yumdnf.conf_file == module.params['conf_file']
    assert yumdnf.disable_excludes == module.params['disable_excludes']
    assert yumdnf.disable_gpg_check == module.params['disable_gpg_check']
    assert yumdnf.disable_plugin

# Generated at 2022-06-11 06:30:30.405889
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    """
    Unit test for method is_lockfile_pid_valid of class YumDnf
    """
    # Create temp directory
    tempdir = tempfile.mkdtemp()

    # Create test lockfile
    lockfile = os.path.join(tempdir, 'yum.pid')

    # Create test class object
    test_class = YumDnf(None)

    # Set the lockfile to the test lockfile and the pid to 0
    test_class.lockfile = lockfile
    test_class.lockfile_pid = 0

    # Test when lockfile is present and the pid is 0, it should return True
    assert test_class.is_lockfile_pid_valid()

    # Test when lockfile is present and the pid is 1, it should return False
    test_class.lockfile_pid = 1


# Generated at 2022-06-11 06:30:39.715074
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import ansible.module_utils.yum
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.selinux

    test_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            lock_timeout=dict(type='int', default=5)
        )
    )
    test_module.get_bin_path = lambda x: '/usr/bin/true'

    test_module.check_mode = False
    test_module.no_log = False
    test_module.deprecation = None

    test_module.exit_json = lambda x: None

# Generated at 2022-06-11 06:30:48.584925
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO
    # Setup module args
    argument_spec = {
        'name': {'type': 'list', 'elements': 'str', 'aliases': ['pkg']},
    }
    module = AnsibleModule(argument_spec=argument_spec, supports_check_mode=True)

    # Setup instance of class YumDnf
    class MockYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            return True
        def run(self):
            return
    yum_dnf = MockYumDnf(module)

    # Setup

# Generated at 2022-06-11 06:30:58.466038
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import unittest
    import ansible.module_utils._text as text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.basic import AnsibleModule

    class TestYumDnf(YumDnf):
        def __init__(self, module):
            super(TestYumDnf, self).__init__(module)
            self.pkg_mgr_name = 'yum'

        def is_lockfile_pid_valid(self):
            return True

        def run(self):
            pass


# Generated at 2022-06-11 06:31:07.265653
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    from mock import patch

    module_args = dict(
        state='present',
        name='some_package'
    )


# Generated at 2022-06-11 06:31:16.974506
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.yumdnf import YumDnf
    input_list = ['string1', 'string2', 'string3', 'string4,string5', 'string6,string7,string8']
    expected_output = ['string1', 'string2', 'string3', 'string4', 'string5', 'string6', 'string7', 'string8']
    output_list = YumDnf(object()).listify_comma_sep_strings_in_list(input_list)
    assert output_list == expected_output

    input_list = ['string1', 'string2', 'string3', 'string4, string5', 'string6, string7,string8']

# Generated at 2022-06-11 06:31:25.338706
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create a dummy file
    dummy_file = tempfile.NamedTemporaryFile()
    _, path = os.path.split(dummy_file.name)

    # Try every value to see if the value is valid or not
    if YumDnf.is_lockfile_pid_valid(YumDnf, path):
        assert True, "Expected %s is valid lockfile pid" % path
    else:
        assert False, "Expected %s is valid lockfile pid" % path

    if not YumDnf.is_lockfile_pid_valid(YumDnf, "/tmp/invalid"):
        assert True, "Expected /tmp/invalid is invalid lockfile pid"
    else:
        assert False, "Expected /tmp/invalid is invalid lockfile pid"

# Unit

# Generated at 2022-06-11 06:31:33.772558
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = FakeAnsibleModule(argument_spec=yumdnf_argument_spec)
    module.params['name'] = ["user-root-dir, install", "user-root-dir, remove"]
    yumdnf = YumDnf(module)
    assert yumdnf.allow_downgrade == False
    assert yumdnf.autoremove == False
    assert yumdnf.bugfix == False
    assert yumdnf.cacheonly == False
    # The conf_file is not available
    assert yumdnf.conf_file is None
    assert yumdnf.disable_excludes is None
    assert yumdnf.disable_gpg_check == False
    assert yumdnf.disable_plugin == []
    assert yumdnf.disablerepo == []
    assert yum

# Generated at 2022-06-11 06:31:42.915104
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import string_types

    class FakeModule(AnsibleModule):
        def _load_params(self):
            return dict(
                argument_spec=dict(
                    lock_timeout=dict(type='int', default=30),
                ),
            )
        def fail_json(self, **kwargs):
            raise AssertionError('Lockfile is not removed.')

    def is_lockfile_pid_valid():
        return True

    yumdnf = YumDnf(FakeModule())
    yumdnf.lockfile = tempfile.mkstemp()[1]
    yumdn

# Generated at 2022-06-11 06:32:15.816452
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
        '''Generate a fake lockfile, run the method and remove it again'''

        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp.write('12345')

        yumdnf = YumDnf(None)
        yumdnf.lockfile = to_native(tmp.name)
        yumdnf._is_lockfile_present()
        yumdnf.wait_for_lock()
        os.remove(tmp.name)

# Generated at 2022-06-11 06:32:27.305172
# Unit test for constructor of class YumDnf

# Generated at 2022-06-11 06:32:37.255539
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Unit test for YumDnf.
    """
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 06:32:49.911878
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = None

    yd = YumDnf(module)
    assert not yd.allow_downgrade
    assert not yd.autoremove
    assert not yd.bugfix
    assert not yd.cacheonly
    assert yd.conf_file is None
    assert yd.disable_excludes is None
    assert not yd.disable_gpg_check
    assert yd.disable_plugin == []
    assert yd.disablerepo == []
    assert not yd.download_only
    assert yd.download_dir is None
    assert yd.enable_plugin == []
    assert yd.enablerepo == []
    assert yd.exclude == []
    assert yd.installroot == "/"
    assert yd.install_repoquery
    assert yd.install_weak_

# Generated at 2022-06-11 06:33:02.230087
# Unit test for constructor of class YumDnf
def test_YumDnf():

    # Test when to_native() function is not available
    class FakeModule(object):
        def __init__(self):
            self.params = dict(
                state='present',
                name='dummy-name',
            )

        def fail_json(self, msg, **kwargs):
            pass

    y = YumDnf(FakeModule())

    # state is present
    assert y.state == 'present'

    # make sure names are converted to list
    assert y.names == ['dummy-name']

    # state is not present
    y.state = None
    assert y.state == 'present'

    # state is latest but autoremove is passed
    y.state = 'latest'
    y.autoremove = True
    assert y.state == 'present'

    # Test when to_native() function

# Generated at 2022-06-11 06:33:11.348827
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    class DummyYumDnf(YumDnf):
        def run(self):
            pass
        def is_lockfile_pid_valid(self):
            pass
        def __init__(self, module):
            YumDnf.__init__(self, module)

    class DummyModule(object):
        def __init__(self):
            self.params = {}

    # This function should return 'True', if pid is valid
    lockfile_pid_valid = DummyYumDnf(DummyModule())
    lockfile_pid_valid.lockfile = open('/sys/class/net/eth0/address')
    try:
        assert lockfile_pid_valid.is_lockfile_pid_valid()
    finally:
        pass
        lockfile_pid_valid.lockfile.close

# Generated at 2022-06-11 06:33:20.897008
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=yumdnf_argument_spec)

    # Test case: lockfile exists and is valid
    def is_lockfile_pid_valid_mock(obj):
        return True

    test_object1 = YumDnf(module)
    test_object1.is_lockfile_pid_valid = is_lockfile_pid_valid_mock
    test_object1.lock_timeout = 2
    test_object1.wait_for_lock()
    assert test_object1.module.fail_json.called is False

    # Test case: lockfile exists and is invalid
    def is_lockfile_pid_valid_mock(obj):
        return False


# Generated at 2022-06-11 06:33:30.722720
# Unit test for constructor of class YumDnf

# Generated at 2022-06-11 06:33:41.197235
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    import os
    import random
    import string
    import tempfile
    from ansible.module_utils.six import PY3

    def random_string(length):
        if PY3:
            return ''.join(random.choice(string.ascii_lowercase) for i in range(length))
        else:
            return ''.join(random.choice(string.lowercase) for i in range(length))

    tmp_dir = tempfile.mkdtemp(prefix='ansible_test_lockfile_')
    lock_file = os.path.join(tmp_dir, '.' + random_string(20))

    # Create a fake lock file
    with open(lock_file, 'w') as f:
        f.write('1234')

    # Test if the the is_lockfile_pid_valid function works

# Generated at 2022-06-11 06:33:45.138305
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    '''
    Unit test for method wait_for_lock of class YumDnf
    '''
    module = AnsibleModule(argument_spec={})
    lockfile = '/var/run/yum.pid'
    obj = YumDnf(module)
    retval = obj.wait_for_lock()
    assert retval is None

# Generated at 2022-06-11 06:34:44.562438
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    # Initialize module object
    module = AnsibleModule(argument_spec=dict())

    # Initialize YumDnf object
    yum = YumDnf(module)

    # List after comma separated strings are processed
    expected_result = ['package-1', 'package-2', 'package-3']

    # List with comma separated strings
    input_list = ['package-1,package-2', 'package-3', 'package-4']

    # Call method listify_comma_sep_strings_in_list
    result = yum.listify_comma_sep_strings_in_list(input_list)

    assert result == expected_result

    # List with comma separated strings in a string
    input_list = ['package-1,package-2']

    # Call method listify_comma_se

# Generated at 2022-06-11 06:34:46.742321
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    y = YumDnf()
    try:
        y.run()
    except NotImplementedError:
        pass



# Generated at 2022-06-11 06:34:56.333585
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Ensures that the constructor of the base class YumDnf is properly parsing
    the parameters passed to it
    """
    # Set up the module
    module = FakeModule()
    module.params["name"] = "test_package"
    module.params["state"] = "latest"

    # Construct YumDnf
    yumdnf_mock = YumDnf(module)

    # Ensure that YumDnf's attributes are set to the proper values passed in the module
    assert yumdnf_mock.allow_downgrade == False
    assert yumdnf_mock.autoremove == False
    assert yumdnf_mock.bugfix == False
    assert yumdnf_mock.cacheonly == False
    assert yumdnf_mock.conf_file == None

# Generated at 2022-06-11 06:35:06.479404
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.module_utils.yumdnf as yd
    import ansible.module_utils.common.collections as collections


# Generated at 2022-06-11 06:35:16.674169
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    x = YumDnf(None)
    assert x.listify_comma_sep_strings_in_list(['abc, def,ghi']) == ['abc', 'def', 'ghi']
    assert x.listify_comma_sep_strings_in_list(['abc,def,ghi']) == ['abc', 'def', 'ghi']
    assert x.listify_comma_sep_strings_in_list(['abc , def ,ghi']) == ['abc', 'def', 'ghi']
    assert x.listify_comma_sep_strings_in_list(['abc , def ']) == ['abc', 'def']
    assert x.listify_comma_sep_strings_in_list(['abc , def ']) == ['abc', 'def']
   

# Generated at 2022-06-11 06:35:27.116585
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = YumDnf(module)
    assert module.allow_downgrade == allow_downgrade
    assert module.autoremove == autoremove
    assert module.bugfix == bugfix
    assert module.cacheonly == cacheonly
    assert module.conf_file == conf_file
    assert module.disable_excludes == disable_excludes
    assert module.disable_gpg_check == disable_gpg_check
    assert module.disable_plugin == disable_plugin
    assert module.disablerepo == disablerepo
    assert module.download_only == download_only
    assert module.download_dir == download_dir
    assert module.enable_plugin == enable_plugin
    assert module.enablerepo == enablerepo
    assert module.exclude == exclude
    assert module.installroot == installroot
    assert module.install_

# Generated at 2022-06-11 06:35:38.107670
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    Test case for YumDnf.wait_for_lock()
    """

    class MockYumDnf(YumDnf):

        def is_lockfile_pid_valid(self):
            return True

    # Testcase when lock exists
    module = MagicMock()
    yum_dnf = MockYumDnf(module)
    yum_dnf.lock_timeout = 2
    with patch.object(yum_dnf, '_is_lockfile_present') as mock_is_lockfile_present:
        mock_is_lockfile_present.side_effect = [True, True, False]
        yum_dnf.wait_for_lock()

    # Testcase when lock does not exist
    module = MagicMock()
    yum_dnf = MockYum

# Generated at 2022-06-11 06:35:46.993081
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible_collections.ansible.community.plugins.module_utils.yumdnf as ofs


# Generated at 2022-06-11 06:35:53.595717
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    '''
    Test case for listify_comma_sep_strings_in_list method of YumDnf class
    '''
    from ansible.module_utils.yum_dnf import YumDnf

    yumdnf_obj = YumDnf(None)

    test_list_1 = ['vim','git','ntp','bind','postgres','python','telnet','httpd','nginx','java']
    test_list_2 = ['vim, git, ntp']
    test_list_3 = ['vim,git,ntp,bind']
    test_list_4 = ['vim, git', 'ntp,bind']
    test_list_5 = ['vim', 'git, ntp', 'bind']
    test_list_6 = ['vim', 'git, ntp,bind']


# Generated at 2022-06-11 06:35:56.205099
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    # Input YumDnf, no return value
    yumdnf = YumDnf()
    yumdnf.run()


# Generated at 2022-06-11 06:37:48.512717
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    tmpdir = tempfile.mkdtemp()
    module = MockModule()

    # Fake lockfile
    lockfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    module.params['lock_timeout'] = 0
    yumdnf = YumDnf(module)
    yumdnf.lockfile = lockfile.name
    yumdnf.wait_for_lock()
    lockfile.close()

    # Fake lockfile & lockfile with pid
    lockfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    with open(lockfile.name, 'w') as f:
        f.write('9999')
    module.params['lock_timeout'] = 0
    yumdnf = YumDnf(module)
    yumdnf.lockfile = lockfile.name

# Generated at 2022-06-11 06:37:58.079937
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Generating the name of the lockfile
    #  This is a file in /tmp directory (?)
    #  And its name has the form of yum-{user}-{pid}
    #  This line is taken from Ansible/ansible/modules/packaging/os/yum.py
    #  method main()
    lock = 'yum-{0}-{1}'.format(os.getlogin(), os.getpid())
    lock = os.path.join(tempfile.gettempdir(), lock)
    module = self
    # If there is no lockfile, means there is no other process running
    # so return immediately
    if not os.path.isfile(lock):
        return
    # If timeout <= 0, skip wait

# Generated at 2022-06-11 06:38:05.864661
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():

    yum = YumDnf('')

    # Test strings without commas
    assert yum.listify_comma_sep_strings_in_list(['abc','def','ghi']) == ['abc','def','ghi']

    # Test with commas
    assert yum.listify_comma_sep_strings_in_list(['a,b','c','d,e,f']) == ['a','b','c','d','e','f']

    # Test with commas and spaces
    assert yum.listify_comma_sep_strings_in_list(['a , b',' c ','d , e, f ']) == ['a','b','c','d','e','f']

# Generated at 2022-06-11 06:38:16.212777
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    test_data = dict(
        list_as_string='abc,def',
        list_as_list=['abc', 'def'],
        list_empty=[],
        list_integers=[1,2,3],
        list_one_element=['abc'],
        list_comma_sep_string='abc',
        list_comma_sep_string_with_spaces='abc, def',
        list_comma_sep_string_list=['abc, def'],
    )

    yumdnf = YumDnf(None)
    assert yumdnf.listify_comma_sep_strings_in_list(
        test_data['list_as_string']
    ) == test_data['list_as_list']
    assert yumdnf.listify_

# Generated at 2022-06-11 06:38:25.479927
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    # TODO: mocked module
    module = None
    yumdnf_instance = YumDnf(module)
    some_list = ['abc', 'def', 'ghi']
    new_list = yumdnf_instance.listify_comma_sep_strings_in_list(some_list)
    assert some_list == ['abc', 'def', 'ghi']
    assert new_list == ['abc', 'def', 'ghi']
    some_list_str = ['abc', '1,2,3', '4', '5,6,7', 'def', 'ghi']
    new_list_str = yumdnf_instance.listify_comma_sep_strings_in_list(some_list_str)