

# Generated at 2022-06-11 06:28:48.933709
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():

    yum = YumDnf(None)
    assert yum.listify_comma_sep_strings_in_list([""]) == []
    assert yum.listify_comma_sep_strings_in_list(["a,b"]) == ["a", "b"]
    assert yum.listify_comma_sep_strings_in_list(["a,b", "c"]) == ["a", "b", "c"]
    assert yum.listify_comma_sep_strings_in_list(["a,", "b", "c"]) == ["a", "b", "c"]
    assert yum.listify_comma_sep_strings_in_list(["a, b"]) == ["a, b"]
    assert yum.listify_comma_

# Generated at 2022-06-11 06:28:59.176925
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.modules.package.yum import Yum
    import ansible.module_utils.ansible_release
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import json
    import re


# Generated at 2022-06-11 06:29:08.108113
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    test_list_1 = ["foo", "bar", "baz", "funk, chicken", "bind, named"]
    test_list_2 = ["foo, bar, baz", "funk, chicken", "bind, named"]
    test_list_3 = ["foo", "bar", "", "baz", "funk, chicken", "bind, named"]
    expected_result = ["foo", "bar", "baz", "funk", "chicken", "bind", "named"]

    yumdnf = YumDnf(None)

    assert yumdnf.listify_comma_sep_strings_in_list(test_list_1) == expected_result
    assert yumdnf.listify_comma_sep_strings_in_list(test_list_2) == expected_result
   

# Generated at 2022-06-11 06:29:17.802400
# Unit test for constructor of class YumDnf
def test_YumDnf():
    class TestModule:
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-11 06:29:26.722266
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    '''
    Test Case:
    Check when lock is held by another process, then it should fail with msg "lockfile is held by another process".
    Note: To simulate lock held by another process, we are creating a lock file as root user.
    '''
    with tempfile.NamedTemporaryFile(prefix='ansible_test_lockfile_', dir='/var/run') as tmpfile:
        tmpfile.file.close()
        # Create a lock file as root user
        try:
            os.chmod(tmpfile.name, 0o444)
        except IOError as ex:
            tmpfile.close()
            if ex.errno == 13:
                print("Current user is not root user and could not create lock file to test wait_for_lock")

# Generated at 2022-06-11 06:29:31.254043
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    class Module(object):
        pass

    class TestYumDnf(YumDnf):
        def __init__(y_self, y_module):
            super(TestYumDnf, y_self).__init__(y_module)

    module = Module()
    test_yumdnf = TestYumDnf(module)

    actual = test_yumdnf.listify_comma_sep_strings_in_list('a,,b,c,d,,e')
    assert actual == ['a', 'b', 'c', 'd', 'e'], 'actual: %s' % actual

    class ModuleNew(object):
        def __init__(self):
            self.params = dict(name=[], disablerepo=[], enablerepo=[], exclude=[])


# Generated at 2022-06-11 06:29:35.540296
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils import basic

    obj = YumDnf(basic._AnsibleModule)  # pylint: disable=protected-access
    with pytest.raises(NotImplementedError):
        obj.run()


# Generated at 2022-06-11 06:29:42.513275
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    test_YumDnf_wait_for_lock()
    This method will test the wait_for_lock method
    """

    # Create a mock module and mock the arguments
    module = AnsibleModule(argument_spec={'lock_timeout': dict(type='int', default=30)})

    module.params["lock_timeout"] = 15

    # Mock the instance of class YumDnf and initialize it with the mock module
    yum_dnf_obj = YumDnf(module)

    # If a lockfile is present we will not wait
    yum_dnf_obj.is_lockfile_pid_valid = Mock(return_value=True)
    yum_dnf_obj._is_lockfile_present = Mock(return_value=True)
    yum_dnf_obj.wait

# Generated at 2022-06-11 06:29:49.693791
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    class MockModule:
        def fail_json(self, msg, results):
            return {'failed': True, 'msg': msg, 'results': results}

    class MockYumDnf(YumDnf):
        pkg_mgr_name = 'yum'

        class MockPopen(object):
            @staticmethod
            def communicate():
                return '0', '0'

        def is_lockfile_pid_valid(self):
            return True

    # Case 1: lockfile does not exist, no pid is running
    mock_module = MockModule()
    mock_yum = MockYumDnf(mock_module)
    mock_yum.lockfile = tempfile.mktemp()


# Generated at 2022-06-11 06:29:53.991010
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    module = ansible_module_mock()
    dnf_obj = DnfModule(module)
    try:
        dnf_obj.run()
    except NotImplementedError:
        pass
    else:
        raise AssertionError('_run method of class YumDnf is not implemented.')


# This function is imported into the unit test class above. It is called when
# AnsibleModule.fail_json() is called. It generates the exception that is
# caught by the unit test.

# Generated at 2022-06-11 06:30:21.558437
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # create a dummy yum module
    module = DummyModule(params={'name': ['vim', 'httpd'],
                                 'state': 'latest',
                                 'lock_timeout': 3})
    # create a dummy yum object
    # if a file was created at the lockfile location
    # wait_for_lock should return after 3 seconds, if not, it will fail
    yum = YumDnf(module)
    with tempfile.NamedTemporaryFile(dir="/var/run/") as lockfile:
        yum.lockfile = lockfile.name
    # test the wait_for_lock method
    yum.wait_for_lock()


# dummy module class to be able to test YumDnf.wait_for_lock()
# method of class YumDnf

# Generated at 2022-06-11 06:30:32.369074
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    Test the wait_for_lock() method of Class YumDnf
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yumdnf import YumDnf

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a ansible argument spec

# Generated at 2022-06-11 06:30:40.738826
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    y = YumDnf("")
    assert y.listify_comma_sep_strings_in_list(["a,b", "c,d,e f", "g", "h", "i, j,k", "l,m, n"]) == ["a", "b", "c", "d", "e f", "g", "h", "i", "j", "k", "l", "m", "n"]
    assert y.listify_comma_sep_strings_in_list(["a", "b,c, d, e f", "g", "h", "i j", "k,l,m"]) == ["a", "b", "c", "d", "e f", "g", "h", "i j", "k", "l", "m"]
    assert y.listify

# Generated at 2022-06-11 06:30:49.717361
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    '''
    Test for YumDnf_wait_for_lock() method
    '''
    from ansible.module_utils.yum_dnf_common import YumDnf
    from ansible.module_utils.yum import Yum

    class MockYumDnf(YumDnf):
        '''
        Mock class for YumDnf
        '''
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
            self.paths = {'system_repo_dir': '/etc/yum.repos.d'}

        def is_lockfile_pid_valid(self):
            '''
            Mock function which returns False
            '''
            return False


# Generated at 2022-06-11 06:30:59.685403
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Prepare mock module
    module_name = 'ansible.module_utils.yum_dnf.YumDnf'
    module_mocks = {
        '__name__': module_name,
        '__file__': module_name,
        '__package__': module_name,
        'get_bin_path': lambda x: '/bin/' + x,
        'fail_json': lambda x: (module_name, os.EX_THUMBUP),
    }

    with tempfile.NamedTemporaryFile('wb', delete=False) as tf:
        LockfileContent = to_native('99999')
        tf.write(str.encode(LockfileContent))
        tf.close()
        with tempfile.NamedTemporaryFile('wb', delete=False) as jf:
            Pid

# Generated at 2022-06-11 06:31:01.824863
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    module = MockModule()
    instance = YumDnf(module)
    assert instance.is_lockfile_pid_valid() == False


# Generated at 2022-06-11 06:31:09.166847
# Unit test for constructor of class YumDnf
def test_YumDnf():
    yumdnf = YumDnf(None)
    assert yumdnf is not None
    assert yumdnf.allow_downgrade is False
    assert yumdnf.autoremove is False
    assert yumdnf.bugfix is False
    assert yumdnf.cacheonly is False
    assert yumdnf.conf_file is None
    assert yumdnf.disable_excludes is None
    assert yumdnf.disable_gpg_check is False
    assert yumdnf.disable_plugin == []
    assert yumdnf.disablerepo == []
    assert yumdnf.download_only is False
    assert yumdnf.download_dir is None
    assert yumdnf.enable_plugin == []
    assert yumdnf.enablerepo == []

# Generated at 2022-06-11 06:31:18.881821
# Unit test for constructor of class YumDnf

# Generated at 2022-06-11 06:31:26.230007
# Unit test for constructor of class YumDnf
def test_YumDnf():

    import os
    import sys
    import unittest

    module = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'modules', 'packaging', 'os', 'yum.py')
    if module not in sys.path:
        sys.path.append(module)

    from ansible.modules.packaging.os.yum import YumModule

    for case in testcases:
        test_instance = YumDnf(YumModule)
        test_instance.module.params = case
        test_instance.listify_comma_sep_strings_in_list(test_instance.names)
        test_instance.listify_comma_sep_strings_in_list(test_instance.disablerepo)

# Generated at 2022-06-11 06:31:34.832410
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 06:32:15.348143
# Unit test for constructor of class YumDnf

# Generated at 2022-06-11 06:32:26.605149
# Unit test for constructor of class YumDnf

# Generated at 2022-06-11 06:32:33.629348
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    class TestYumDnf(YumDnf):
        def __init__(self, module):
            super(TestYumDnf, self).__init__(module)

        def is_lockfile_pid_valid(self):
            return True

    fake_module = FakeModule()
    yum_dnf_obj = TestYumDnf(fake_module)
    assert yum_dnf_obj.is_lockfile_pid_valid() is True


# Generated at 2022-06-11 06:32:41.079128
# Unit test for constructor of class YumDnf
def test_YumDnf():
    class TestYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            return True

        @property
        def pkg_mgr_name(self):
            return 'TestYum'

    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 06:32:50.346348
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    When the lockfile doesn't exist, the function returns immediately.
    """
    class YumDnfMock(YumDnf):
        def __init__(self, module):
            YumDnf.__init__(self, module)
            self.lockfile = None

    class AnsibleModuleMock:
        def params(self, key):
            if key == "lock_timeout":
                return 0

    yumdnf_obj = YumDnfMock(AnsibleModuleMock())
    yumdnf_obj.wait_for_lock()


# Generated at 2022-06-11 06:32:52.063224
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    assert YumDnf.run() is NotImplementedError

# Generated at 2022-06-11 06:33:03.750666
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = MockModule()

# Generated at 2022-06-11 06:33:04.383796
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    return True


# Generated at 2022-06-11 06:33:16.264575
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    dnf = YumDnf(module=None)
    assert dnf.listify_comma_sep_strings_in_list(["a", "b", "c", "d,e"]) == ['a', 'b', 'c', 'd', 'e']
    assert dnf.listify_comma_sep_strings_in_list(["a,b", "c", "d,e"]) == ['a', 'b', 'c', 'd', 'e']
    assert dnf.listify_comma_sep_strings_in_list(["a,b", "c", "d", "e"]) == ['a', 'b', 'c', 'd', 'e']
    assert dnf.listify_comma_sep_strings_in_list(['']) == []

# Generated at 2022-06-11 06:33:23.021639
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """In this test we will use AnsibleModule fake class to test YumDnf class.
    This test will not be able to test everything but just some basic functionality.
    """
    from ansible.module_utils.basic import AnsibleModule

    # Run for yum module
    module = AnsibleModule(supports_check_mode=True, **yumdnf_argument_spec)

    # declare module_default_arguments

# Generated at 2022-06-11 06:34:22.368995
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import shutil
    import stat

    module = AnsibleModule(
        argument_spec=dict(
            lock_timeout=dict(type='int', default=2),
        ),
        supports_check_mode=True
    )

    fake_obj = YumDnf(module)
    fake_obj.lockfile = "/tmp/lockfile_test"
    fake_obj.is_lockfile_pid_valid = lambda: True

    # Lockfile is not present
    fake_obj.wait_for_lock()

    # Lockfile is present but the PID is not valid
    open(fake_obj.lockfile, "w")
    fake_obj.is_lockfile_pid_valid = lambda: False
    fake_obj.wait_for_lock

# Generated at 2022-06-11 06:34:26.934363
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    module = AnsibleModule(argument_spec={})
    yumdnf_obj = YumDnf(module)

    class SubClass(YumDnf):
        def run(self):
            pass

        def is_lockfile_pid_valid(self):
            return True

    sub_obj = SubClass(module)

    # Check if the lockfile already exists
    if not os.path.isfile(sub_obj.lockfile):
        try:
            # Create lockfile
            open(sub_obj.lockfile, 'w').close()
        except:
            module.fail_json(msg='Lock file creation failed')

    test_lock_obj = tempfile.NamedTemporaryFile(mode='w')
    test_lock_obj.write('1')
    test_lock_obj.flush()

    sub

# Generated at 2022-06-11 06:34:34.974641
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    result = YumDnf(None).listify_comma_sep_strings_in_list(['one, two', 'three, four', 'five'])
    assert result == ['one', 'two', 'three', 'four', 'five']
    result = YumDnf(None).listify_comma_sep_strings_in_list([])
    assert result == []
    result = YumDnf(None).listify_comma_sep_strings_in_list([""])
    assert result == []


# Generated at 2022-06-11 06:34:45.030130
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    # test different inputs of list

    # test when list contains comma-seperated strings
    # test when list contains comma-seperated strings with space as seperator
    # test when list contains comma-seperated strings with comma as seperator
    # test when list contains strings with comma in it
    # test when list contains strings with comma as seperator
    # test when list contains strings with comma as seperator with space
    # test when list contains strings with comma as seperator with multiple commas

    # test when list doesn't contain comma-seperated strings
    # test when list is empty
    # test when list has comma as only element
    # test when list has

# Generated at 2022-06-11 06:34:51.376104
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """Test conversion of list of comma-separated elements to list of elements. """
    ydf = YumDnf(None)
    retval = ydf.listify_comma_sep_strings_in_list(['python', 'php,mariadb', 'rabbitmq', '', 'http, https'])
    assert retval == ['python', 'php', 'mariadb', 'rabbitmq', '', 'http', 'https']


# Generated at 2022-06-11 06:34:56.950472
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():

    first_list = ['pkg1', 'pkg2', 'pkg,pkg3', 'pkg4,pkg5,pkg6']
    expected_list = ['pkg1', 'pkg2', 'pkg4', 'pkg5', 'pkg6']
    result_list = YumDnf.listify_comma_sep_strings_in_list(first_list)
    assert result_list == expected_list
    # raise Exception(result_list + " is not equal to " + expected_list)


# Generated at 2022-06-11 06:35:03.378863
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    '''
    This method will return the pid valid or not
    '''

    file_desc, temp_file = tempfile.mkstemp(prefix="ansible_test_input_")
    os.write(file_desc, "1234".encode('utf-8'))
    os.close(file_desc)
    if yum_dnf_lock.is_lockfile_pid_valid(temp_file):
        os.unlink(temp_file)
    else:
        os.unlink(temp_file)
        raise AssertionError


# Generated at 2022-06-11 06:35:06.273168
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    yd = YumDnf(None)
    assert yd.run() is NotImplemented

# Generated at 2022-06-11 06:35:16.541107
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.yum import YumDnf
    dummy = YumDnf()
    # test sanity condition
    assert dummy.listify_comma_sep_strings_in_list([]) == [], 'Empty list should return empty list'

    # test 2 valid elements
    assert dummy.listify_comma_sep_strings_in_list(['foo', 'bar']) == ['foo', 'bar'], 'Should return 2 elements in the list'

    # test 1 comma separated element
    assert dummy.listify_comma_sep_strings_in_list(['foo,bar']) == ['foo', 'bar'], 'Should return 2 elements in the list'

    # test 1 comma separated elements at start and end

# Generated at 2022-06-11 06:35:26.981175
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    y = YumDnf({})
    orig_list = ['package1', 'package2', 'package3, package4', '', 'package5']
    returned_list = y.listify_comma_sep_strings_in_list(orig_list)
    assert returned_list == ['package1', 'package2', 'package3', 'package4', 'package5']
    returned_list = y.listify_comma_sep_strings_in_list(['package1, package2, package3, package4, package5'])
    assert returned_list == ['package1', 'package2', 'package3', 'package4', 'package5']
    returned_list = y.listify_comma_sep_strings_in_list([])
    assert returned_list == []
    returned_list = y.list

# Generated at 2022-06-11 06:37:15.671299
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf

# Generated at 2022-06-11 06:37:23.429645
# Unit test for constructor of class YumDnf
def test_YumDnf():

    module = MockModule()

    yum_dnf = YumDnf(module)

    assert yum_dnf.allow_downgrade
    assert yum_dnf.autoremove
    assert yum_dnf.bugfix
    assert yum_dnf.cacheonly
    assert yum_dnf.conf_file == "test_conf_file"
    assert yum_dnf.disable_excludes == "test_disable_excludes"
    assert yum_dnf.disable_gpg_check
    assert yum_dnf.disable_plugin == ["A", "B", "C"]
    assert yum_dnf.disablerepo == ["1", "2", "3"]
    assert yum_dnf.download_only

# Generated at 2022-06-11 06:37:30.866773
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Create a simple module to reference in the YumDnf constructor. This allows
    us to test all logic that uses params from the module in the YumDnf constructor
    itself
    """

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 06:37:39.143065
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # create a YumDnf class, with a dummy lockfile
    class YumDnfTest(YumDnf):
        def is_lockfile_pid_valid(self):
            return True

    fd, lockfile = tempfile.mkstemp()
    os.close(fd)
    yumdnf = YumDnfTest(None)
    yumdnf.lockfile = lockfile
    yumdnf.lock_timeout = 0

    # test case when the lockfile does not exists
    if os.path.isfile(lockfile):
        os.unlink(lockfile)
    yumdnf.wait_for_lock()

    # test case when the lockfile is present and the lock_timeout is unlimited
    fd = os.open(lockfile, os.O_TRUNC)

# Generated at 2022-06-11 06:37:44.332498
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    """Unit test of method run"""
    module = MagicMock()
    module.fail_json.side_effect = Exception(
        "Killing the unit test run because 'YumDnf.run' method wasn't redefined"
    )
    yumdnf = YumDnf(module)        # noqa: F841 unused variable
    yumdnf.run()


# Generated at 2022-06-11 06:37:55.440242
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """
    Test the behaviour of the method listify_comma_sep_strings_in_list of the class YumDnf
    """
    ydf = YumDnf(None)
    assert ydf.listify_comma_sep_strings_in_list(['foo']) == ['foo']
    assert ydf.listify_comma_sep_strings_in_list(['foo,bar']) == ['foo', 'bar']
    assert ydf.listify_comma_sep_strings_in_list(['foo', 'bar']) == ['foo', 'bar']
    assert ydf.listify_comma_sep_strings_in_list(['foo, bar']) == ['foo', 'bar']
    assert ydf.listify_comma_sep_strings_in_

# Generated at 2022-06-11 06:38:02.105101
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    import inspect
    import os
    import tempfile
    imp.reload(yum_utils)
    pkg_mgr = yum_utils.YumDnf(dict(name=['vim'],
                                     state='present',
                                     install_repoquery='True'))

    # Test pid 0 is not a valid lock file pid
    pkg_mgr.lockfile = '/var/run/yum.pid'
    with open(pkg_mgr.lockfile, 'w') as pid_0_file_obj:
        pid_0_file_obj.write("0")
    ret = yum_utils.YumDnf.is_lockfile_pid_valid(pkg_mgr)
    os.remove(pkg_mgr.lockfile)
    assert ret is False

    # Test pid 1 is

# Generated at 2022-06-11 06:38:03.187451
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    assert False



# Generated at 2022-06-11 06:38:13.349614
# Unit test for constructor of class YumDnf

# Generated at 2022-06-11 06:38:22.830938
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    """
    Test case for method YumDnf.run method
    """
    temp_file = tempfile.NamedTemporaryFile()