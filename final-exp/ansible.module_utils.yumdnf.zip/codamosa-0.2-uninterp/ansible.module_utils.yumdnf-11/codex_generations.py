

# Generated at 2022-06-17 03:49:52.126289
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    with pytest.raises(NotImplementedError):
        YumDnf(None).run()


# Generated at 2022-06-17 03:50:00.912322
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Test the constructor of class YumDnf
    """
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=yumdnf_argument_spec)
    yumdnf = YumDnf(module)
    assert yumdnf.allow_downgrade is False
    assert yumdnf.autoremove is False
    assert yumdnf.bugfix is False
    assert yumdnf.cacheonly is False
    assert yumdnf.conf_file is None
    assert yumdnf.disable_excludes is None
    assert yumdnf.disable_gpg_check is False
    assert yumdnf.disable_plugin == []
    assert yumdnf.disablerepo == []
    assert yumdnf.download_only

# Generated at 2022-06-17 03:50:10.303036
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-17 03:50:21.498503
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum import YumDnf

    module = AnsibleModule(argument_spec={})
    yumdnf = YumDnf(module)

    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c,d']) == ['a', 'b', 'c', 'd']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c,d']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-17 03:50:28.248500
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import ansible.module_utils.yum
    import ansible.module_utils.dnf
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.json_utils
    import ansible.module_utils.pycompat24
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.urllib.response
    import ansible.module_utils.six.moves.urllib.robotparser
    import ansible.module_utils.six.m

# Generated at 2022-06-17 03:50:37.049933
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
    )
    yumdnf = YumDnf(module)
    assert yumdnf.allow_downgrade == module.params['allow_downgrade']
    assert yumdnf.autoremove == module.params['autoremove']
    assert yumdnf.bugfix == module.params['bugfix']
    assert yumdnf.cacheonly == module.params['cacheonly']
    assert yumdnf.conf_file == module.params['conf_file']
    assert yumdnf.disable_excludes == module.params['disable_excludes']
    assert yumdnf.disable_gpg_check

# Generated at 2022-06-17 03:50:48.878320
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yum = YumDnf(module)
    assert yum.listify_comma_sep_strings_in_list(['a,b,c']) == ['a', 'b', 'c']
    assert yum.listify_comma_sep_strings_in_list(['a,b,c', 'd,e,f']) == ['a', 'b', 'c', 'd', 'e', 'f']
    assert yum.listify_comma_sep_strings_in_list(['a,b,c', 'd,e,f', 'g']) == ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    assert y

# Generated at 2022-06-17 03:50:59.729537
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.module_utils.basic
    import ansible.module_utils.yum

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
    )

    yumdnf = YumDnf(module)

    assert yumdnf.allow_downgrade == False
    assert yumdnf.autoremove == False
    assert yumdnf.bugfix == False
    assert yumdnf.cacheonly == False
    assert yumdnf.conf_file == None
    assert yumdnf.disable_excludes == None
    assert yumdnf.disable_gpg_check == False
    assert yumdnf.disable_plugin == []
    assert yumdnf.disable

# Generated at 2022-06-17 03:51:10.469917
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = AnsibleModule(argument_spec=yumdnf_argument_spec)
    yumdnf = YumDnf(module)
    assert yumdnf.allow_downgrade == False
    assert yumdnf.autoremove == False
    assert yumdnf.bugfix == False
    assert yumdnf.cacheonly == False
    assert yumdnf.conf_file == None
    assert yumdnf.disable_excludes == None
    assert yumdnf.disable_gpg_check == False
    assert yumdnf.disable_plugin == []
    assert yumdnf.disablerepo == []
    assert yumdnf.download_only == False
    assert yumdnf.download_dir == None
    assert yumdnf.enable_plugin == []
    assert yum

# Generated at 2022-06-17 03:51:14.400750
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yum_dnf = YumDnf(module)
    assert yum_dnf.listify_comma_sep_strings_in_list(['a,b,c']) == ['a', 'b', 'c']
    assert yum_dnf.listify_comma_sep_strings_in_list(['a,b,c', 'd,e,f']) == ['a', 'b', 'c', 'd', 'e', 'f']

# Generated at 2022-06-17 03:51:41.018286
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import ansible.module_utils.yum
    import ansible.module_utils.dnf
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.json_utils
    import ansible.module_utils.pycompat24
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.six.moves.http_cookiejar
    import ansible.module_utils.six.moves.http_client
    import ansible.module_utils.six.moves.configparser


# Generated at 2022-06-17 03:51:49.294392
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['lock_timeout'] = 30
            self.params['lockfile'] = '/var/run/yum.pid'

        def fail_json(self, msg, results=[]):
            raise Exception(msg)

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)

        def is_lockfile_pid_valid(self):
            return True

    module = MockModule()
    yumdnf = MockYumDnf(module)

    assert yumdnf.is_lockfile_pid_valid() is True


# Generated at 2022-06-17 03:52:00.240547
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
    )
    yumdnf = YumDnf(module)
    assert yumdnf.allow_downgrade == module.params['allow_downgrade']
    assert yumdnf.autoremove == module.params['autoremove']
    assert yumdnf.bugfix == module.params['bugfix']
    assert yumdnf.cacheonly == module.params['cacheonly']
    assert yumdnf.conf_file == module.params['conf_file']
    assert yumdnf.disable_excludes == module.params['disable_excludes']
    assert yumdnf.disable_gpg_check

# Generated at 2022-06-17 03:52:07.378739
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum import YumDnf

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
            self.pkg_mgr_name = 'mock'

        def is_lockfile_pid_valid(self):
            return True

    module = AnsibleModule(argument_spec={
        'lock_timeout': dict(type='int', default=30),
    })

    yumdnf = MockYumDnf(module)
    yumdnf.lockfile = tempfile.mkstemp()[1]

    # Test lockfile is not present
    yumdnf.wait_for

# Generated at 2022-06-17 03:52:19.043540
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yumdnf = YumDnf(module)

    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c']) == ['a', 'b', 'c']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c', 'd,e,f']) == ['a', 'b', 'c', 'd', 'e', 'f']

# Generated at 2022-06-17 03:52:29.872839
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=yumdnf_argument_spec)
    yumdnf = YumDnf(module)
    assert yumdnf.allow_downgrade == module.params['allow_downgrade']
    assert yumdnf.autoremove == module.params['autoremove']
    assert yumdnf.bugfix == module.params['bugfix']
    assert yumdnf.cacheonly == module.params['cacheonly']
    assert yumdnf.conf_file == module.params['conf_file']
    assert yumdnf.disable_excludes == module.params['disable_excludes']
    assert yumdnf.disable_gpg_check == module.params['disable_gpg_check']

# Generated at 2022-06-17 03:52:33.049759
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    """
    Unit test for method is_lockfile_pid_valid of class YumDnf
    """
    yumdnf = YumDnf(None)
    assert yumdnf.is_lockfile_pid_valid() == False

# Generated at 2022-06-17 03:52:42.448760
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file in the temporary directory
    tmp_file_in_dir = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    tmp_file_in_dir.close()

    # Create a temporary file in the temporary directory
    tmp_file_in_dir2 = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    tmp_file_in_dir2.close()

    # Create a temporary file in the temporary directory

# Generated at 2022-06-17 03:52:52.798586
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import tempfile
    import shutil
    import os
    import time
    import sys
    import subprocess
    import signal
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a lockfile
    lockfile = os.path.join(tmpdir, 'yum.pid')
    with open(lockfile, 'w') as f:
        f.write('1')

    # Create a module
    module = AnsibleModule(
        argument_spec=dict(
            lock_timeout=dict(type='int', default=30),
        ),
        supports_check_mode=True,
    )

    # Create a YumDnf object
    yumdnf = YumDnf(module)



# Generated at 2022-06-17 03:53:01.666919
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_file.write(b'1')
    tmp_file.flush()

    # Create a YumDnf object
    yumdnf = YumDnf(None)

    # Set the lockfile to the temporary file
    yumdnf.lockfile = tmp_file.name

    # Test that the lockfile is present
    assert yumdnf._is_lockfile_present()

    # Test that the lockfile is removed after the timeout
    yumdnf.lock_timeout = 1
    yumdnf.wait_for_lock()
    assert not yumdnf._is_lockfile_present()

    # Test that the lockfile is not removed if the timeout is 0

# Generated at 2022-06-17 03:53:32.155946
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    try:
        YumDnf(None).run()
    except NotImplementedError:
        pass
    else:
        assert False, "Should have raised NotImplementedError"


# Generated at 2022-06-17 03:53:44.747401
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yum_dnf = YumDnf(module)
    assert yum_dnf.listify_comma_sep_strings_in_list(['a,b', 'c']) == ['a', 'b', 'c']
    assert yum_dnf.listify_comma_sep_strings_in_list(['a,b', 'c,d']) == ['a', 'b', 'c', 'd']
    assert yum_dnf.listify_comma_sep_strings_in_list(['a,b', 'c,d', 'e']) == ['a', 'b', 'c', 'd', 'e']
    assert yum_dnf.listify

# Generated at 2022-06-17 03:53:54.122889
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    test_list = ['a', 'b', 'c', 'd,e,f', 'g,h', 'i', 'j,k']
    expected_list = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k']
    yumdnf = YumDnf(None)
    assert yumdnf.listify_comma_sep_strings_in_list(test_list) == expected_list


# Generated at 2022-06-17 03:53:59.489997
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=yumdnf_argument_spec)
    yumdnf = YumDnf(module)
    assert yumdnf.allow_downgrade == module.params['allow_downgrade']
    assert yumdnf.autoremove == module.params['autoremove']
    assert yumdnf.bugfix == module.params['bugfix']
    assert yumdnf.cacheonly == module.params['cacheonly']
    assert yumdnf.conf_file == module.params['conf_file']
    assert yumdnf.disable_excludes == module.params['disable_excludes']
    assert yumdnf.disable_gpg_check == module.params['disable_gpg_check']

# Generated at 2022-06-17 03:54:09.655191
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()

    # Create a YumDnf object
    yumdnf = YumDnf(None)

    # Set the lockfile to the temporary file
    yumdnf.lockfile = tmp_file.name

    # Test that the lockfile is present
    assert yumdnf._is_lockfile_present()

    # Test that the lockfile is not removed after 1 second
    yumdnf.lock_timeout = 1
    yumdnf.wait_for_lock()
    assert yumdnf._is_lockfile_present()

    # Remove the lockfile
    os.remove(tmp_file.name)

    # Test that the lockfile is not present
    assert not y

# Generated at 2022-06-17 03:54:22.558448
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    import ansible.module_utils.yum
    yum_dnf = ansible.module_utils.yum.YumDnf(None)
    assert yum_dnf.listify_comma_sep_strings_in_list(['a,b,c']) == ['a', 'b', 'c']
    assert yum_dnf.listify_comma_sep_strings_in_list(['a,b,c', 'd,e,f']) == ['a', 'b', 'c', 'd', 'e', 'f']

# Generated at 2022-06-17 03:54:29.467201
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile()
    # Write the PID of the current process to the temporary file
    temp_file.write(str(os.getpid()))
    # Flush the file
    temp_file.flush()
    # Create an instance of YumDnf
    yum_dnf = YumDnf(None)
    # Set the lockfile attribute of the instance to the temporary file
    yum_dnf.lockfile = temp_file.name
    # Assert that the method returns True
    assert yum_dnf.is_lockfile_pid_valid() == True
    # Close the temporary file
    temp_file.close()


# Generated at 2022-06-17 03:54:37.169525
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 03:54:48.479485
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import ansible.module_utils.yum
    import ansible.module_utils.dnf
    import ansible.module_utils.six
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils.json_utils
    import ansible.module_utils.pycompat24
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.dict_transformations
    import ansible.module_utils.common.text
    import ansible.module_utils.common.process
    import ansible.module_utils.common.file
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.systemd
    import ansible.module_utils.common.run_command

# Generated at 2022-06-17 03:54:55.338471
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['lock_timeout'] = 30

        def fail_json(self, msg):
            raise Exception(msg)

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)

        def is_lockfile_pid_valid(self):
            return True

    module = MockModule()
    yumdnf = MockYumDnf(module)
    yumdnf.lockfile = tempfile.mktemp()

# Generated at 2022-06-17 03:55:55.612616
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['lock_timeout'] = 1

        def fail_json(self, msg, results):
            self.msg = msg
            self.results = results

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
            self.lockfile = tempfile.NamedTemporaryFile(delete=False).name

        def is_lockfile_pid_valid(self):
            return True

    module = MockModule()
    yumdnf = MockYumDnf(module)

    # Test that the lockfile is removed
    yumdnf.wait_for_lock()

# Generated at 2022-06-17 03:56:03.668099
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.module_utils.basic
    import ansible.module_utils.yum


# Generated at 2022-06-17 03:56:10.672687
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yum = YumDnf(module)
    assert yum.listify_comma_sep_strings_in_list(['a,b', 'c', 'd,e,f']) == ['a', 'b', 'c', 'd', 'e', 'f']
    assert yum.listify_comma_sep_strings_in_list(['a,b', 'c', 'd,e,f', 'g,h,i,j']) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']

# Generated at 2022-06-17 03:56:21.990219
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['lock_timeout'] = 0
            self.fail_json = lambda msg: self.fail(msg)

        def fail(self, msg):
            raise Exception(msg)

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
            self.lockfile = tempfile.mktemp(prefix='ansible_test_')
            self.pkg_mgr_name = 'yum'

        def is_lockfile_pid_valid(self):
            return True

    module = MockModule()
    yum = MockYumDnf(module)

    # Create lockfile
   

# Generated at 2022-06-17 03:56:29.249664
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()

    # Create a temporary module
    tmp_module = type('', (), {})()
    tmp_module.params = dict(lock_timeout=1)
    tmp_module.fail_json = lambda msg: None

    # Create a temporary YumDnf object
    tmp_YumDnf = YumDnf(tmp_module)
    tmp_YumDnf.lockfile = tmp_file.name
    tmp_YumDnf.is_lockfile_pid_valid = lambda: True

    # Test wait_for_lock
    tmp_YumDnf.wait_for_lock()

    # Remove temporary file
    os.unlink(tmp_file.name)

# Generated at 2022-06-17 03:56:38.871060
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create a temporary file
    fd, tmp_file = tempfile.mkstemp()
    # Write a pid in the temporary file
    os.write(fd, b'12345')
    os.close(fd)
    # Create a YumDnf object
    yumdnf = YumDnf(None)
    # Set the lockfile to the temporary file
    yumdnf.lockfile = tmp_file
    # Check that the pid is valid
    assert yumdnf.is_lockfile_pid_valid()
    # Remove the temporary file
    os.remove(tmp_file)


# Generated at 2022-06-17 03:56:48.569365
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum import YumDnfPackageManager

    class DummyModule(object):
        def __init__(self):
            self.params = dict()
            self.params['lock_timeout'] = 0
            self.fail_json = lambda msg: self.fail(msg)
            self.fail = lambda msg: self.msg.append(msg)
            self.msg = []

    class DummyYumDnfPackageManager(YumDnfPackageManager):
        def __init__(self, module):
            super(DummyYumDnfPackageManager, self).__init__(module)
            self.lockfile = '/tmp/yum.pid'

        def is_lockfile_pid_valid(self):
            return

# Generated at 2022-06-17 03:56:53.956693
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile()
    # Write PID to the file
    tmpfile.write(to_native(os.getpid()))
    tmpfile.flush()
    # Create an instance of YumDnf
    yumdnf = YumDnf(None)
    # Set lockfile to the temporary file
    yumdnf.lockfile = tmpfile.name
    # Check if PID is valid
    assert yumdnf.is_lockfile_pid_valid()
    # Close the temporary file
    tmpfile.close()

# Generated at 2022-06-17 03:57:03.161956
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yumdnf = YumDnf(None)
    assert yumdnf.listify_comma_sep_strings_in_list(["a,b,c"]) == ["a", "b", "c"]
    assert yumdnf.listify_comma_sep_strings_in_list(["a,b,c", "d,e,f"]) == ["a", "b", "c", "d", "e", "f"]
    assert yumdnf.listify_comma_sep_strings_in_list(["a,b,c", "d,e,f", "g,h,i"]) == ["a", "b", "c", "d", "e", "f", "g", "h", "i"]
    assert yumdnf.listify_comma_

# Generated at 2022-06-17 03:57:14.571208
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yumdnf = YumDnf(module)
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c,d']) == ['a', 'b', 'c', 'd']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c,d', 'e']) == ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-17 03:59:11.384694
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yumdnf = YumDnf(module)

    assert yumdnf.listify_comma_sep_strings_in_list(["a,b", "c"]) == ["a", "b", "c"]
    assert yumdnf.listify_comma_sep_strings_in_list(["a, b", "c"]) == ["a", "b", "c"]
    assert yumdnf.listify_comma_sep_strings_in_list(["a,b", "c,d"]) == ["a", "b", "c", "d"]

# Generated at 2022-06-17 03:59:16.607481
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
    )
    yumdnf = YumDnf(module)
    yumdnf.run()

# Generated at 2022-06-17 03:59:24.960516
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    Unit test for method wait_for_lock of class YumDnf
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum import YumDnf

    class MockYumDnf(YumDnf):
        """
        Mock class for YumDnf
        """
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
            self.pkg_mgr_name = "mock"

        def is_lockfile_pid_valid(self):
            return True

    module = AnsibleModule(argument_spec={})
    yumdnf = MockYumDnf(module)
    yumdnf.lock_timeout = 0
    yumdnf

# Generated at 2022-06-17 03:59:33.369470
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yumdnf = YumDnf(module)
    assert yumdnf.listify_comma_sep_strings_in_list(['a', 'b,c', 'd']) == ['a', 'b', 'c', 'd']
    assert yumdnf.listify_comma_sep_strings_in_list(['a', 'b,c,d']) == ['a', 'b', 'c', 'd']
    assert yumdnf.listify_comma_sep_strings_in_list(['a', 'b,c,d', 'e']) == ['a', 'b', 'c', 'd', 'e']
    assert yumdnf.list