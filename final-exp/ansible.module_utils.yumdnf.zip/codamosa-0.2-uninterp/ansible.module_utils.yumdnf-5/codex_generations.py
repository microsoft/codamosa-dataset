

# Generated at 2022-06-17 03:50:00.911808
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import ansible.module_utils.yum
    import ansible.module_utils.dnf
    import ansible.module_utils.yum_dnf
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.facts
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.dict_transformations
    import ansible.module_utils.common.text
    import ansible.module_utils.common.process
    import ansible.module_utils.common.file
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.json_utils
    import ansible.module_utils.common.validation
    import ans

# Generated at 2022-06-17 03:50:10.278683
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = AnsibleModule(argument_spec={})
    yumdnf = YumDnf(module)
    assert yumdnf.module == module
    assert yumdnf.allow_downgrade == False
    assert yumdnf.autoremove == False
    assert yumdnf.bugfix == False
    assert yumdnf.cacheonly == False
    assert yumdnf.conf_file == None
    assert yumdnf.disable_excludes == None
    assert yumdnf.disable_gpg_check == False
    assert yumdnf.disable_plugin == []
    assert yumdnf.disablerepo == []
    assert yumdnf.download_only == False
    assert yumdnf.download_dir == None
    assert yumdnf.enable_plugin == []
   

# Generated at 2022-06-17 03:50:21.526137
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yumdnf = YumDnf(module)
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c']) == ['a', 'b', 'c']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c', 'd,e,f']) == ['a', 'b', 'c', 'd', 'e', 'f']

# Generated at 2022-06-17 03:50:31.615278
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
    )
    yumdnf = YumDnf(module)
    assert yumdnf.allow_downgrade == module.params['allow_downgrade']
    assert yumdnf.autoremove == module.params['autoremove']
    assert yumdnf.bugfix == module.params['bugfix']
    assert yumdnf.cacheonly == module.params['cacheonly']
    assert yumdnf.conf_file == module.params['conf_file']
    assert yumdnf.disable_excludes == module.params['disable_excludes']
    assert yumdnf.disable_gpg_check

# Generated at 2022-06-17 03:50:39.306943
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yumdnf = YumDnf(module)
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c']) == ['a', 'b', 'c']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c']) == ['a', 'b', 'c']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c,d']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-17 03:50:49.625174
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yumdnf = YumDnf(None)
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c,d']) == ['a', 'b', 'c', 'd']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c,d', 'e']) == ['a', 'b', 'c', 'd', 'e']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c,d', 'e', 'f,g']) == ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    assert yumdnf.listify_comma_sep_strings_in_

# Generated at 2022-06-17 03:50:55.989644
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
    )

    yumdnf = YumDnf(module)

    assert yumdnf.allow_downgrade == module.params['allow_downgrade']
    assert yumdnf.autoremove == module.params['autoremove']
    assert yumdnf.bugfix == module.params['bugfix']
    assert yumdnf.cacheonly == module.params['cacheonly']
    assert yumdnf.conf_file == module.params['conf_file']
    assert yumdnf.disable_excludes == module.params['disable_excludes']
    assert yumdnf.disable_gpg_check

# Generated at 2022-06-17 03:51:06.787824
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    Unit test for method wait_for_lock of class YumDnf
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum_dnf import YumDnf

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
            self.pkg_mgr_name = 'mock'

        def is_lockfile_pid_valid(self):
            return True

    module = AnsibleModule(
        argument_spec=dict(
            lock_timeout=dict(type='int', default=30),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-17 03:51:20.094494
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 03:51:30.191307
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum import YumDnf

    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.params['lock_timeout'] = 0
            self.fail_json = lambda msg: None

    class FakeYumDnf(YumDnf):
        def __init__(self, module):
            super(FakeYumDnf, self).__init__(module)
            self.lockfile = tempfile.mktemp()

        def is_lockfile_pid_valid(self):
            return True

    # Test case 1: lockfile is present
    with open(FakeYumDnf(FakeModule()).lockfile, 'w') as f:
        f.write

# Generated at 2022-06-17 03:51:53.481194
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_file_name = tmp_file.name
    tmp_file.close()

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary lock file
    tmp_lockfile = tempfile.NamedTemporaryFile(dir=tmp_dir)
    tmp_lockfile_name = tmp_lockfile.name
    tmp_lockfile.close()

    # Create a temporary module
    tmp_module = type('module', (object,), dict(fail_json=lambda self, msg: None))()

    # Create a temporary YumDnf object
    tmp_yumdnf = YumDnf(tmp_module)

    # Set the lockfile attribute of the temporary YumDnf object

# Generated at 2022-06-17 03:52:02.247250
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yd = YumDnf(None)
    assert yd.listify_comma_sep_strings_in_list(['a,b', 'c', 'd,e']) == ['a', 'b', 'c', 'd', 'e']
    assert yd.listify_comma_sep_strings_in_list(['a,b', 'c', 'd,e', '']) == ['a', 'b', 'c', 'd', 'e']
    assert yd.listify_comma_sep_strings_in_list([',', 'c', 'd,e', '']) == ['c', 'd', 'e']

# Generated at 2022-06-17 03:52:08.602058
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum_dnf import YumDnf


# Generated at 2022-06-17 03:52:13.939185
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yumdnf = YumDnf(module)

    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c,d']) == ['a', 'b', 'c', 'd']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c,d', 'e']) == ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-17 03:52:24.830633
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    # Write a valid pid to the temporary file
    tmpfile.write(b'1')
    tmpfile.close()

    # Create a YumDnf object
    yumdnf = YumDnf(None)
    # Set the lockfile to the temporary file
    yumdnf.lockfile = tmpfile.name
    # Test if the pid is valid
    assert yumdnf.is_lockfile_pid_valid()

    # Remove the temporary file
    os.remove(tmpfile.name)

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    # Write an invalid pid to the temporary file
    tmpfile.write(b'0')
    tmpfile

# Generated at 2022-06-17 03:52:32.380868
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yumdnf = YumDnf(None)
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c']) == ['a', 'b', 'c']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c', 'd,e,f']) == ['a', 'b', 'c', 'd', 'e', 'f']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c', 'd,e,f', 'g,h,i']) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
    assert yumdnf.listify_comma_

# Generated at 2022-06-17 03:52:41.145322
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Create a mock module
    module = MockModule()

    # Create a mock lockfile
    lockfile = tempfile.NamedTemporaryFile(delete=False)
    lockfile.write(to_native(os.getpid()))
    lockfile.close()

    # Create a mock YumDnf object
    yumdnf = YumDnf(module)
    yumdnf.lockfile = lockfile.name

    # Test wait_for_lock method
    yumdnf.wait_for_lock()

    # Remove the mock lockfile
    os.remove(lockfile.name)


# Generated at 2022-06-17 03:52:50.735284
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = MockModule()

# Generated at 2022-06-17 03:53:01.217408
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=yumdnf_argument_spec)
    yumdnf = YumDnf(module)
    assert yumdnf.allow_downgrade == module.params['allow_downgrade']
    assert yumdnf.autoremove == module.params['autoremove']
    assert yumdnf.bugfix == module.params['bugfix']
    assert yumdnf.cacheonly == module.params['cacheonly']
    assert yumdnf.conf_file == module.params['conf_file']
    assert yumdnf.disable_excludes == module.params['disable_excludes']
    assert yumdnf.disable_gpg_check == module.params['disable_gpg_check']

# Generated at 2022-06-17 03:53:12.906381
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Create a temporary file
    (fd, tmp_file) = tempfile.mkstemp()
    os.close(fd)

    # Create an instance of YumDnf
    module = MockModule()
    yumdnf = YumDnf(module)
    yumdnf.lockfile = tmp_file

    # Create a lock file
    with open(tmp_file, 'w') as f:
        f.write('1')

    # Test wait_for_lock with a timeout of 0
    yumdnf.lock_timeout = 0
    yumdnf.wait_for_lock()
    assert os.path.isfile(tmp_file)

    # Test wait_for_lock with a timeout of 1
    yumdnf.lock_timeout = 1
    yumdnf.wait_for_lock

# Generated at 2022-06-17 03:53:54.499786
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yum_dnf = YumDnf(None)
    assert yum_dnf.listify_comma_sep_strings_in_list(['a,b,c']) == ['a', 'b', 'c']
    assert yum_dnf.listify_comma_sep_strings_in_list(['a,b,c', 'd,e,f']) == ['a', 'b', 'c', 'd', 'e', 'f']
    assert yum_dnf.listify_comma_sep_strings_in_list(['a,b,c', 'd,e,f', 'g']) == ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    assert yum_dnf.listify_comma_sep_strings_

# Generated at 2022-06-17 03:54:02.886542
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.yum import YumDnf
    yumdnf = YumDnf(None)
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c']) == ['a', 'b', 'c']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c', 'd,e,f']) == ['a', 'b', 'c', 'd', 'e', 'f']

# Generated at 2022-06-17 03:54:11.255019
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum_dnf import YumDnf


# Generated at 2022-06-17 03:54:16.337561
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import ansible.module_utils.yum_dnf
    import ansible.module_utils.yum
    import ansible.module_utils.dnf
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.module_utils.urls
    import ansible.module_utils.facts
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.dict_transformations
    import ansible.module_utils.common.text
    import ansible.module_utils.common.process
    import ansible.module_utils.common.json_utils
    import ansible.module_utils.common.file
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.network
    import ansible

# Generated at 2022-06-17 03:54:28.223999
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 03:54:37.161068
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda msg: None

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
            self.pkg_mgr_name = 'mock'
            self.lockfile = '/tmp/mock.pid'

        def is_lockfile_pid_valid(self):
            return True

    # Test case 1: lockfile is not present
    module = MockModule()
    module.params['lock_timeout'] = 0
    yumdnf = MockYumDnf(module)
    yumdnf.wait_for_lock()

    # Test case 2: lockfile

# Generated at 2022-06-17 03:54:44.043627
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    yumdnf = YumDnf(module)
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c,d']) == ['a', 'b', 'c', 'd']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c,d', 'e']) == ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-17 03:54:50.652951
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create a temporary file
    fd, path = tempfile.mkstemp()
    # Write PID to the file
    with os.fdopen(fd, 'w') as tmp:
        tmp.write(str(os.getpid()))
    # Create YumDnf object
    yumdnf = YumDnf(None)
    # Set lockfile to the temporary file
    yumdnf.lockfile = path
    # Check that the PID is valid
    assert yumdnf.is_lockfile_pid_valid()
    # Remove the temporary file
    os.remove(path)

# Generated at 2022-06-17 03:55:01.971609
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum import YumDnf

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()

    # Create a temporary module
    module = AnsibleModule(
        argument_spec=dict(
            lock_timeout=dict(type='int', default=30),
        ),
        supports_check_mode=True,
    )

    # Create a temporary YumDnf object
    yum_dnf = YumDnf(module)
    yum_dnf.lockfile = tmp_file.name

    # Test wait_for_lock method
    yum_dnf.wait_for_lock()

    # Remove the temporary file
    os

# Generated at 2022-06-17 03:55:14.469865
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    """
    Unit test for method is_lockfile_pid_valid of class YumDnf
    """
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['lock_timeout'] = 30
            self.params['conf_file'] = None
            self.params['disable_gpg_check'] = False
            self.params['installroot'] = "/"
            self.params['disable_excludes'] = None
            self.params['disablerepo'] = []
            self.params['enablerepo'] = []
            self.params['exclude'] = []
            self.params['install_repoquery'] = True
            self.params['install_weak_deps'] = True
            self.params['validate_certs'] = True

# Generated at 2022-06-17 03:56:09.247114
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Create a temporary file
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as tmp:
        tmp.write('12345')

    # Create a YumDnf object
    class YumDnfMock(YumDnf):
        def is_lockfile_pid_valid(self):
            return True

    yumdnf_mock = YumDnfMock(None)
    yumdnf_mock.lockfile = path

    # Check if the lockfile is present
    assert yumdnf_mock._is_lockfile_present()

    # Remove the temporary file
    os.remove(path)


# Generated at 2022-06-17 03:56:21.901115
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import ansible.modules.packaging.os.yum as yum
    import ansible.modules.packaging.os.dnf as dnf
    import ansible.module_utils.basic as basic
    import ansible.module_utils.six as six
    import ansible.module_utils.yum as yum_utils
    import ansible.module_utils.dnf as dnf_utils
    import ansible.module_utils.yum_base as yum_base
    import ansible.module_utils.dnf_base as dnf_base
    import ansible.module_utils.yum_repository as yum_repository
    import ansible.module_utils.dnf_repository as dnf_repository
    import ansible.module_utils.yum_plugin_enable

# Generated at 2022-06-17 03:56:26.017400
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    try:
        YumDnf(None).run()
    except NotImplementedError:
        pass
    else:
        raise AssertionError("NotImplementedError not raised")


# Generated at 2022-06-17 03:56:36.873523
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    Unit test for method wait_for_lock of class YumDnf
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yumdnf import YumDnf

    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.params['lock_timeout'] = 30
            self.fail_json = lambda *args, **kwargs: None

    class FakeYumDnf(YumDnf):
        def __init__(self, module):
            super(FakeYumDnf, self).__init__(module)
            self.lockfile = tempfile.NamedTemporaryFile().name

        def is_lockfile_pid_valid(self):
            return True

    # Test 1:

# Generated at 2022-06-17 03:56:46.718468
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum import YumDnf


# Generated at 2022-06-17 03:56:58.587769
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda msg: None

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
            self.pkg_mgr_name = 'yum'
            self.lockfile = '/var/run/yum.pid'

        def is_lockfile_pid_valid(self):
            return True

    module = MockModule()
    module.params['lock_timeout'] = 0
    yumdnf = MockYumDnf(module)
    yumdnf.lockfile = tempfile.mkstemp()[1]
    yumdnf.wait_for_lock

# Generated at 2022-06-17 03:57:08.911003
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yumdnf = YumDnf(None)
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b', 'c']) == ['a', 'b', 'c']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c']) == ['a', 'b', 'c']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c', 'd']) == ['a', 'b', 'c', 'd']
    assert yumdnf.listify_comma_sep_strings_in_list(['a,b,c', 'd,e']) == ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-17 03:57:18.465749
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
    )
    yumdnf = YumDnf(module)
    assert yumdnf.allow_downgrade == module.params['allow_downgrade']
    assert yumdnf.autoremove == module.params['autoremove']
    assert yumdnf.bugfix == module.params['bugfix']
    assert yumdnf.cacheonly == module.params['cacheonly']
    assert yumdnf.conf_file == module.params['conf_file']
    assert yumdnf.disable_excludes == module.params['disable_excludes']
    assert yumdnf.disable_gpg_check

# Generated at 2022-06-17 03:57:26.224851
# Unit test for constructor of class YumDnf
def test_YumDnf():
    # Create a temporary file for testing
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a module for testing

# Generated at 2022-06-17 03:57:34.462463
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    tmpfile.close()

    # Create a YumDnf object
    class FakeModule(object):
        def __init__(self):
            self.params = dict(lock_timeout=1)
            self.fail_json = lambda msg: None

    class FakeYumDnf(YumDnf):
        def __init__(self, module):
            super(FakeYumDnf, self).__init__(module)
            self.lockfile = tmpfile.name
            self.pkg_mgr_name = "Fake"

        def is_lockfile_pid_valid(self):
            return True

    yumdnf = FakeYumDnf(FakeModule())

    # Test with lockfile present

# Generated at 2022-06-17 03:59:32.711745
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Unit test for constructor of class YumDnf
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum import YumDnf


# Generated at 2022-06-17 03:59:43.025202
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yum import YumModule
    from ansible.module_utils.dnf import DnfModule

    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
    )

    yum_module = YumModule(module)
    dnf_module = DnfModule(module)

    assert yum_module.allow_downgrade == dnf_module.allow_downgrade
    assert yum_module.autoremove == dnf_module.autoremove
    assert yum_module.bugfix == dnf_module.bugfix
    assert yum_module.cacheonly == dnf_module.cacheonly
    assert yum_