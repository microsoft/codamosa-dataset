

# Generated at 2022-06-20 21:09:13.729023
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    import ansible.module_utils.yum as yum_utils
    # It is necessary to import yum_utils so method listify_comma_sep_strings_in_list can be called
    # without creating an instance or modifying the usage of class YumDnf in file yum.py


# Generated at 2022-06-20 21:09:24.891547
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    # Positive test with few list items
    list_1 = ["foo", "foo,bar"]
    exp_list_1 = ["foo", "foo", "bar"]
    assert(YumDnf.listify_comma_sep_strings_in_list([], list_1) == exp_list_1)

    # Positive test with comma separated string as the only list item
    list_2 = ["foo,bar"]
    exp_list_2 = ["foo", "bar"]
    assert(YumDnf.listify_comma_sep_strings_in_list([], list_2) == exp_list_2)

    # Positive test with single quoted comma separated string as the only list item
    list_3 = ["'foo','bar'"]
    exp_list_3 = ["foo", "bar"]

# Generated at 2022-06-20 21:09:27.407818
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    module = MockModule()
    mgr = YumDnf(module)
    mgr.wait_for_lock()

# Generated at 2022-06-20 21:09:38.933245
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    """
    Test function for YumDnf, when lockfile is present,
    and when lockfile is not present.
    Tests :ansible.module_utils.yum_base.yum.wait_for_lock function
    """
    def _is_lockfile_pid_valid():
        return True

    def fail_json(msg):
        raise Exception("fail_json: %s" % msg)

    # test that wait_for_lock will fail when lockfile is present
    yum_dnf_class = YumDnf(None)
    yum_dnf_class.lockfile = tempfile.mktemp()
    yum_dnf_class.is_lockfile_pid_valid = _is_lockfile_pid_valid

# Generated at 2022-06-20 21:09:46.871291
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    # Test that NotImplemented is raised
    class YumDnf_object(YumDnf):
        def __init__(self):
            pass
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    yumdnf = YumDnf_object(module)
    try:
        yumdnf.run()
        raise AssertionError('run method of class YumDnf should raise NotImplementedError')
    except NotImplementedError:
        pass


# Generated at 2022-06-20 21:09:59.054108
# Unit test for method is_lockfile_pid_valid of class YumDnf

# Generated at 2022-06-20 21:10:01.746395
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    YumDnf.run(YumDnf)

# Generated at 2022-06-20 21:10:08.249228
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    some_list = ['one', 'two', 'three,four', 'five,six', 'seven,eight,nine']
    y = YumDnf(None)
    final = y.listify_comma_sep_strings_in_list(some_list)
    assert final == ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine']



# Generated at 2022-06-20 21:10:17.627888
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    class FakeArgs(object):
        def __init__(self, module=None):
            self.module = module
    def fake_import_module(name):
        if name == 'dnf.Base':
            class FakeDnfBase(object):
                def __init__(self, args=None):
                    class FakeConf(object):
                        def __init__(self):
                            self.installroot = '/'
                    self.conf = FakeConf()
            return FakeDnfBase

# Generated at 2022-06-20 21:10:21.711152
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    with tempfile.NamedTemporaryFile() as tmp:
        tmp.write(b"#!/usr/bin/python\n")
        tmp.flush()
        p = YumDnf({"run_command": ["python", tmp.name]})
        with pytest.raises(NotImplementedError):
            p.run()

# Generated at 2022-06-20 21:10:44.683472
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    YumDnf({"params": yumdnf_argument_spec})


# Generated at 2022-06-20 21:10:57.398144
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible.module_utils import basic
    from ansible.compat.tests import mock

    module = basic.AnsibleModule(
        YumDnf.yumdnf_argument_spec,
        supports_check_mode=True
    )

    ydf = YumDnf(module)

    # Validate the defaults
    assert ydf.cacheonly == module.params['cacheonly']
    assert ydf.conf_file == module.params['conf_file']
    assert ydf.disable_gpg_check == module.params['disable_gpg_check']
    assert ydf.exclude == module.params['exclude']
    assert ydf.installroot == module.params['installroot']
    assert y

# Generated at 2022-06-20 21:11:13.084950
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    # Generate test object.
    test_obj = YumDnf(None)
    # Test with empty list.
    message = "Fail to handle empty list."
    assert test_obj.listify_comma_sep_strings_in_list([]) == [], message
    # Test with list with no comma separated string in it.
    message = "Fail to handle list with no comma separated string in it."
    assert test_obj.listify_comma_sep_strings_in_list(["a"]) == ["a"], message
    # Test with comma separated string without empty element in list.
    message = "Fail to handle comma separated string without empty element in list."

# Generated at 2022-06-20 21:11:21.122210
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.version = "2.0"

        def fail_json(self, msg, results=None):
            return {'failed': True, 'msg': msg}

    class FakeYumDnf(YumDnf):
        def __init__(self, module):
            super(FakeYumDnf, self).__init__(module)
            self.pkg_mgr_name = 'dnf'

        def is_lockfile_pid_valid(self):
            return False

        def run(self):
            return

    # Test when lock file is present but lock_timeout is <= 0
    params = dict(
        lock_timeout=-1,
    )
    module = FakeModule(params)
    y

# Generated at 2022-06-20 21:11:26.098665
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    class YumDnfTest(YumDnf):
        def __init__(self, module):
            super(YumDnfTest, self).__init__(module)
            self.pkg_mgr_name = "test_pkg"

        def run(self):
            return "pkg"

    class YumDnfTestError(YumDnf):
        def __init__(self, module):
            super(YumDnfTestError, self).__init__(module)
            self.pkg_mgr_name = "test_pkg_err"

        def is_lockfile_pid_valid(self):
            return False


# Generated at 2022-06-20 21:11:31.907827
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    import ansible.module_utils.yumdnf
    module = ansible.module_utils.yumdnf.YumDnf(None)
    try:
        module.run()
    except:
        pass


# Generated at 2022-06-20 21:11:39.641493
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import os
    import time
    from ansible.module_utils.yum_dnf import YumDnf
    from ansible.modules.packaging.os import yum
    from ansible.module_utils.six import with_metaclass

    class Yum(with_metaclass(ABCMeta, YumDnf)):
        '''
        This is a concrete class just for unit test purpose.
        '''
        def __init__(self, module):
            YumDnf.__init__(self, module)
            self.pkg_mgr_name = 'yum'

        def is_lockfile_pid_valid(self):
            return True

    # Create a lock file
    fd, local_lockfile = tempfile.mkstemp()
    os.close(fd)

    # Wait

# Generated at 2022-06-20 21:11:44.769507
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    mod = AnsibleModule(argument_spec={})
    (is_valid, pid) = YumDnf(mod).is_lockfile_pid_valid()
    assert is_valid is False
    assert pid is None



# Generated at 2022-06-20 21:11:49.825229
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    """
    Test method `run` of class `YumDnf`.

    It is not possible to test this method because the class `YumDnf` is abstract and does not implement `run`.
    """
    pass


# Generated at 2022-06-20 21:12:00.838713
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    class MockModule:
        """
        This is a small mock module class to be used in this test
        """
        params = dict()
        fail_json = lambda self, msg, results: msg

    mock_module = MockModule()
    mock_module.params = yumdnf_argument_spec  # Set the params to argument_spec
    mock_module.params['name'] = []

    # Instantiate a mock class of YumDnf
    class mockYumDnf(YumDnf):
        """
        Abstract class that handles the population of instance variables that should
        be identical between both YUM and DNF modules because of the feature parity
        and shared argument spec
        """
        def __init__(self, module):
            self.module = module

        def is_lockfile_pid_valid(self):
            return

# Generated at 2022-06-20 21:12:34.110017
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.module_utils.yum
    module = ansible.module_utils.yum.Yum(dict(name=['pkg']))

    yd = YumDnf(module)
    assert yd.allow_downgrade is False
    assert yd.autoremove is False
    assert yd.bugfix is False
    assert yd.cacheonly is False
    assert yd.conf_file is None
    assert yd.disable_excludes is None
    assert yd.disable_gpg_check is False
    assert yd.disable_plugin == []
    assert yd.disablerepo == []
    assert yd.download_only is False
    assert yd.download_dir is None
    assert yd.enable_plugin == []
    assert yd.enablerepo == []
    assert y

# Generated at 2022-06-20 21:12:35.493581
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    raise NotImplementedError


# Generated at 2022-06-20 21:12:38.941671
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    test_instance = YumDnf(object)
    assert test_instance.is_lockfile_pid_valid()


# Generated at 2022-06-20 21:12:54.347954
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

    module = AnsibleModule(yumdnf_argument_spec)

    # test no action, fails

# Generated at 2022-06-20 21:12:59.523142
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    try:
        YumDnf(None).run()
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-20 21:13:15.201329
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.yum_dnf import YumDnf

    module = AnsibleModule(supports_check_mode=True)
    module.run_command = lambda command, check_rc=True, close_fds=True: (0, '', '')
    module.fail_json = lambda **kwargs: module.exit_json(rc=-1, **kwargs)

    class MockYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            pass

    yumdnf_obj = MockYumDnf(module)

    # Test case for PY2

# Generated at 2022-06-20 21:13:25.933358
# Unit test for method run of class YumDnf
def test_YumDnf_run():

    module = ansible_module_create()

    yd = YumDnf.run(module)

    assert yd.state == "absent"
    assert yd.autoremove == False
    assert yd.bugfix == False
    assert yd.cacheonly == False
    assert yd.conf_file == None
    assert yd.disable_excludes == None
    assert yd.disable_gpg_check == False
    assert yd.disable_plugin == []
    assert yd.disablerepo == []
    assert yd.download_only == False
    assert yd.download_dir == None
    assert yd.enable_plugin == []
    assert yd.enablerepo == []
    assert yd.exclude == []
    assert yd.installroot == "/"
    assert yd.install

# Generated at 2022-06-20 21:13:34.078676
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    This test validates that if a comma separated string is passed in the
    configuration variable names, it is converted to a list
    """
    import ansible.modules.packaging.os.yum as yum
    module = yum.AnsibleModule(
        argument_spec=dict(
            name="cowsay,fortune-mod",
        ),
        supports_check_mode=True,
    )
    module.check_mode = False
    yum_dnf_instance = YumDnf(module)
    assert isinstance(yum_dnf_instance.names, list)



# Generated at 2022-06-20 21:13:41.327784
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
    )
    yumdnf = YumDnf(module=module)
    assert yumdnf.allow_downgrade == module.params['allow_downgrade']
    assert yumdnf.autoremove == module.params['autoremove']
    assert yumdnf.bugfix == module.params['bugfix']
    assert yumdnf.cacheonly == module.params['cacheonly']
    assert yumdnf.conf_file == module.params['conf_file']
    assert yumdnf.disable_excludes == module.params['disable_excludes']

# Generated at 2022-06-20 21:13:52.094491
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    y = YumDnf(None)
    assert y.listify_comma_sep_strings_in_list([]) == []
    assert y.listify_comma_sep_strings_in_list(['httpd']) == ['httpd']
    assert y.listify_comma_sep_strings_in_list(['httpd,vim-enhanced']) == ['httpd', 'vim-enhanced']
    assert y.listify_comma_sep_strings_in_list(['httpd', 'vim-enhanced']) == ['httpd', 'vim-enhanced']
    assert y.listify_comma_sep_strings_in_list(['httpd,,vim-enhanced']) == ['httpd', 'vim-enhanced']
    assert y.listify_comma_

# Generated at 2022-06-20 21:14:43.770244
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    """Test method YumDnf.run()
    """
    class MockModule(object):
        pass

    class MockYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            return True

    yumdnf = MockYumDnf(MockModule())
    assert yumdnf.run() is False


# Generated at 2022-06-20 21:14:56.468578
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    my_module = type('module', (object,), {})
    my_module.fail_json = lambda msg: msg

    my_yumdnf = YumDnf(my_module)

    list_with_comma_separated_string = ['some', 'string', 'comma , separated']
    list_without_comma_separated_string = ['some', 'normal', 'list']
    empty_list = [""]

    assert my_yumdnf.listify_comma_sep_strings_in_list(list_with_comma_separated_string) == \
           ['some', 'string', 'comma ', ' separated']

# Generated at 2022-06-20 21:15:03.382657
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """
    The method listify_comma_sep_strings_in_list should accept a list of strings
    as the parameter, find any strings in that list that are comma separated,
    remove them from the list and add their comma separated elements to the
    original list.
    """
    input_list = ['package1', 'package2,package3', 'package4',
                  'package5,package6,package7', 'package8']
    expected_list = ['package1', 'package2', 'package3', 'package4',
                     'package5', 'package6', 'package7', 'package8']
    mock_module = DummyModule(input_list)
    yum = YumDnf(mock_module)

# Generated at 2022-06-20 21:15:08.970457
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    """
    unit test to check the validness of lockfile
    """
    class TestYumDnf(YumDnf):
        """
        Class to test pid of lockfile
        """
        def is_lockfile_pid_valid(self):
            """
            Checks if lockfile is valid
            """
            return True

    test_yum_dnf = TestYumDnf(None)
    assert test_yum_dnf.is_lockfile_pid_valid() is True



# Generated at 2022-06-20 21:15:24.700140
# Unit test for constructor of class YumDnf

# Generated at 2022-06-20 21:15:36.390333
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    from ansible.module_utils.common.process import get_bin_path

    class TestClass(YumDnf):
        def __init__(self, module):
            super(TestClass, self).__init__(module)

    class TestModule(object):
        def __init__(self, params):
            super(TestModule, self).__init__()
            self.params = params

    tm = TestModule(dict(lock_timeout=10))
    yd = TestClass(tm)

    with tempfile.NamedTemporaryFile(mode='w+', delete=False) as temp_file:
        temp_file.write("1234")
        temp_file.flush()
        yd.lockfile = temp_file.name
        assert yd.is_lockfile_pid_valid()


# Generated at 2022-06-20 21:15:47.947322
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    val = 1615
    with tempfile.NamedTemporaryFile() as file:
        file.write(str(val).encode('utf-8'))
        file.flush()
        lockfile = file.name
        try:
            os.kill(val, 0)
        except OSError:
            # PID doesn't exist
            assert YumDnf.is_lockfile_pid_valid(lockfile) is False
        else:
            assert YumDnf.is_lockfile_pid_valid(lockfile) is True

            # PID exists; inject an invalid PID into the PID file and ensure that is_lockfile_pid_valid returns False
            val = -1
            os.kill(val, 9)

# Generated at 2022-06-20 21:15:55.598975
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    class DummyModule:
        def __init__(self):
            self.params = {}

        def fail_json(self, msg):
            raise Exception(msg)

    class DummyClass(YumDnf):
        def run(self):
            pass

    dmodule = DummyModule()
    dummy = DummyClass(dmodule)

    assert dmodule.params == {}

    # Initial test values
    result = dummy.listify_comma_sep_strings_in_list(some_list=['a,b,c,d', 'e', 'f'])
    expected = ['a', 'b', 'c', 'd', 'e', 'f']
    assert result == expected, 'result={0} is not equal to expected={1}'.format(result, expected)

    result = dummy.listify_comma

# Generated at 2022-06-20 21:16:07.897385
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    """
    Unit test to test YumDnf.run()
    """
    class TestYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            return False

    yumdnf_inst = TestYumDnf('test_module')
    yumdnf_inst.module.fail_json = lambda **kwargs: None

    try:
        yumdnf_inst.run()
    except NotImplementedError:
        pass
    else:
        raise AssertionError("NotImplementedError not raised by run")



# Generated at 2022-06-20 21:16:19.096650
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class MockYumDnf(YumDnf):
        '''
        Mock class for YumDnf.
        '''
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)
        def is_lockfile_pid_valid(self):
            return False
    module = type('', (), {})()
    module.fail_json = lambda *args, **kwargs: None
    obj = MockYumDnf(module)
    with tempfile.NamedTemporaryFile() as f:
        obj.lockfile = f.name
        # create a lockfile
        f.write(b"1234")
        f.flush()
        assert obj._is_lockfile_present()
        obj.wait_for_lock()
        # should

# Generated at 2022-06-20 21:17:56.962876
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    '''
    Test case for method run of class YumDnf
    '''
    y = YumDnf(None)
    try:
        y.run()
    except NotImplementedError as e:
        assert True


# Generated at 2022-06-20 21:18:12.037459
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.module_utils.yum
    mod = ansible.module_utils.yum.AnsibleModule(argument_spec={})
    mod.params['conf_file'] = '/etc/yum.conf'
    mod.params['enable_plugin'] = ['foo']
    mod.params['disable_plugin'] = ['bar']
    mod.params['lock_timeout'] = 0
    y = YumDnf(mod)
    assert y.allow_downgrade is False, str(y)
    assert y.autoremove is False, str(y)
    assert y.bugfix is False, str(y)
    assert y.cacheonly is False, str(y)
    assert y.conf_file == '/etc/yum.conf', str(y)
    assert y.disable_excludes == None, str

# Generated at 2022-06-20 21:18:23.135763
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    yumdnf_object = YumDnf('module')
    # create a temporary file
    yumdnf_object.lockfile = tempfile.NamedTemporaryFile(mode="w", delete=True)
    yumdnf_object.lock_timeout = 1
    assert not yumdnf_object._is_lockfile_present()
    yumdnf_object.wait_for_lock()

    # create a temporary directory
    # test_case 1 - when lock_timeout is set to 0
    yumdnf_object.lockfile = tempfile.TemporaryDirectory().name
    yumdnf_object.lock_timeout = 0
    assert yumdnf_object._is_lockfile_present()
    yumdnf_object.wait_for_lock()

    # test_case 2 - when lock_

# Generated at 2022-06-20 21:18:32.097313
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    my_module = MockModule(argument_spec=yumdnf_argument_spec)

    # test that the _is_lockfile_present returns the value for the lockfile
    # returned by the function call
    my_class = YumDnf(my_module)
    my_class.lockfile = tempfile.mkstemp()

    my_class.wait_for_lock()
    assert my_module.fail_json.called == False
    os.remove(my_class.lockfile)

# Generated at 2022-06-20 21:18:44.072608
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = None
    yum_dnf = YumDnf(module)
    assert isinstance(yum_dnf, YumDnf)
    assert yum_dnf.allow_downgrade is None
    assert yum_dnf.autoremove is None
    assert yum_dnf.bugfix is None
    assert yum_dnf.cacheonly is None
    assert yum_dnf.conf_file is None
    assert yum_dnf.disable_excludes is None
    assert yum_dnf.disable_gpg_check is None
    assert yum_dnf.disable_plugin == []
    assert yum_dnf.disablerepo == []
    assert yum_dnf.download_only is None
    assert yum_dnf.download_dir is None
    assert y

# Generated at 2022-06-20 21:18:48.251419
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    module = mock.Mock()
    yumdnf = YumDnf(module)
    assert yumdnf.run() is None
