

# Generated at 2022-06-20 21:09:12.799063
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Test case to check right construction of class YumDnf
    """

# Generated at 2022-06-20 21:09:16.681628
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True
    )
    y = YumDnf(module=module)
    assert('name' in y.__dict__) is True


# Generated at 2022-06-20 21:09:28.769588
# Unit test for method wait_for_lock of class YumDnf

# Generated at 2022-06-20 21:09:40.942011
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    from ansible_collections.community.general.plugins.modules.kubernetes.k8s.module_utils.common import KubernetesAnsibleModule

    test_module = KubernetesAnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    test_timeout = 30
    yum_dnf = YumDnf(test_module)
    yum_dnf.lockfile = 'test_lockfile'

# Generated at 2022-06-20 21:09:52.540319
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    with tempfile.NamedTemporaryFile() as tmpfile:
        with open(tmpfile.name, 'w') as f:
            f.write('42')
        lockfile = tmpfile.name
        class DummyModule:
            def fail_json(self, *args, **kwargs):
                pass
        ansible_mod = DummyModule()
        yum_dnf = YumDnf(ansible_mod)
        yum_dnf.lockfile = lockfile
        try:
            yum_dnf.is_lockfile_pid_valid()
        except NotImplementedError:
            pass

# Generated at 2022-06-20 21:10:08.245793
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.basic import AnsibleModule
    from copy import deepcopy

    module = AnsibleModule(argument_spec=deepcopy(yumdnf_argument_spec))

    yum = YumDnf(module=module)

    assert yum.allow_downgrade is False
    assert yum.autoremove is False
    assert yum.bugfix is False
    assert yum.cacheonly is False
    assert yum.conf_file is None
    assert yum.disable_excludes is None
    assert yum.disable_gpg_check is False
    assert yum.disablerepo == []
    assert yum.download_only is False
    assert yum.download_dir is None
    assert yum.enablerepo == []
    assert yum.exclude == []
    assert yum

# Generated at 2022-06-20 21:10:15.470693
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    mod = AnsibleModule(
        argument_spec=dict(
            allow_downgrade=dict(type='bool', default=False),
        ),
        required_one_of=[['name', 'list', 'update_cache']],
        mutually_exclusive=[['name', 'list']],
        supports_check_mode=True,
    )

    with pytest.raises(NotImplementedError):
        obj = YumDnf(mod)
        obj.run()

# Generated at 2022-06-20 21:10:23.478556
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    def is_lockfile_pid_valid():
        return True

    class FakeModule:
        params = {
            'lock_timeout': 1,
        }
        def fail_json(self, msg, results):
            raise Exception(msg)

    yd = YumDnf(FakeModule())

    yd.is_lockfile_pid_valid = is_lockfile_pid_valid
    with tempfile.NamedTemporaryFile(delete=False, mode='w') as lf:
        lf.write('1234')
        lf.flush()
        yd.lockfile = lf.name
        try:
            yd.wait_for_lock()
        finally:
            os.unlink(lf.name)

    yd.is_lockfile_pid_valid = is_lockfile_pid_valid

# Generated at 2022-06-20 21:10:28.568899
# Unit test for constructor of class YumDnf
def test_YumDnf():
    class MockModule(object):
        def __init__(self):
            self._params = dict()

        def params(self, name):
            return self._params.get(name, None)

        def fail_json(self, msg, results=[]):
            raise Exception(msg)

    # Test constructor
    test_module = MockModule()
    test_module._params['allow_downgrade'] = True
    test_module._params['autoremove'] = False
    test_module._params['cacheonly'] = False
    test_module._params['conf_file'] = '/etc/yum.conf'
    test_module._params['disable_excludes'] = None
    test_module._params['disable_gpg_check'] = True

# Generated at 2022-06-20 21:10:39.556382
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Test when pid is valid
    with tempfile.NamedTemporaryFile() as pidfile:
        pidfile.write(to_native(os.getpid()))
        pidfile.flush()
        yumdnf_obj = YumDnf(None)
        yumdnf_obj.lockfile = pidfile.name
        assert yumdnf_obj.is_lockfile_pid_valid()

    # Test when pid is not valid
    with tempfile.NamedTemporaryFile() as pidfile:
        pidfile.write(b'123')
        pidfile.flush()
        yumdnf_obj = YumDnf(None)
        yumdnf_obj.lockfile = pidfile.name
        assert not yumdnf_obj.is_lockfile_pid_valid()

# Unit

# Generated at 2022-06-20 21:11:00.254520
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    yd = YumDnf({})
    yd.lockfile = '/tmp/test_yum_dnf.lock'

    yd.is_lockfile_pid_valid = lambda: False

    # Test when lockfile is absent
    def _is_lockfile_present():
        return False
    yd._is_lockfile_present = _is_lockfile_present

    yd.wait_for_lock()

    # Test when lockfile is present but pid is invalid
    def _is_lockfile_present():
        return True
    yd._is_lockfile_present = _is_lockfile_present

    yd.lock_timeout = 0


# Generated at 2022-06-20 21:11:11.966255
# Unit test for constructor of class YumDnf

# Generated at 2022-06-20 21:11:17.377358
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
    )

    yumdnf = YumDnf(module)
    try:
        yumdnf.run()
    except NotImplementedError as e:
        assert True
    except Exception as e:
        assert False, 'Unexpected exception raised: {0}'.format(e)


# Generated at 2022-06-20 21:11:26.611718
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    tmpdir = tempfile.mkdtemp()
    tmpfile = open(tmpdir + '/pid', 'w')
    tmpfile.write('12345678')
    tmpfile.close()

    obj = YumDnf(None)
    obj.lockfile = tmpdir +'/pid'
    result = obj.is_lockfile_pid_valid()
    assert result == False

    # Make sure that the tmpdir is removed
    os.remove(tmpdir + '/pid')
    os.rmdir(tmpdir)


# Generated at 2022-06-20 21:11:35.232769
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    # Create a mock class that only has the method of interest
    class YumDnfMock(YumDnf):
        def is_lockfile_pid_valid(self):
            pass
    ydm = YumDnfMock(None)

    assert ydm.listify_comma_sep_strings_in_list(['a', 'b', 'c,d']) == ['a', 'b', 'c', 'd']



# Generated at 2022-06-20 21:11:41.184370
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    lockfile = tempfile.mkstemp()[1]

# Generated at 2022-06-20 21:11:52.194180
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six.moves import StringIO

    yumdnf = None

# Generated at 2022-06-20 21:12:02.631104
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    yum_dnf_mock = YumDnf(None)

    # If lockfile doesn't exist
    yum_dnf_mock.lockfile = '/path/to/non/existing/file'
    result = yum_dnf_mock.is_lockfile_pid_valid()
    assert result is False

    # If lockfile exist, but it's a stale lockfile
    with tempfile.NamedTemporaryFile('w', delete=False) as lockfile:
        lockfile.write('1')
    yum_dnf_mock.lockfile = lockfile.name
    result = yum_dnf_mock.is_lockfile_pid_valid()
    assert result is False
    os.remove(yum_dnf_mock.lockfile)

    # If lockfile exists and it

# Generated at 2022-06-20 21:12:12.507161
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.fail_json = lambda a: False

    class MockYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            return False

    module = MockModule(lock_timeout=0)
    result = MockYumDnf(module)
    assert result.wait_for_lock() is None

    module = MockModule(lock_timeout=0)
    result = MockYumDnf(module)
    result.lockfile = existing_lockfile
    assert result.wait_for_lock() is None

    module = MockModule(lock_timeout=1)
    result = MockYumDnf(module)
    result.lockfile

# Generated at 2022-06-20 21:12:22.385122
# Unit test for method run of class YumDnf
def test_YumDnf_run():

    # Create a mock module
    class MockModule:
        params = {}
        fail_json = None
    module = MockModule()

    # Create a mock subprocess
    class MockSubprocess:
        CalledProcessError = None
    subprocess = MockSubprocess()

    # Create a class wrapper for a mock method
    class MockException(Exception):
        pass

    # Create a mock method
    def mocked_wait_for_lock(*args, **kwargs):
        return


# Generated at 2022-06-20 21:12:40.446499
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    assert_equals(is_lockfile_pid_valid(), False)


# Generated at 2022-06-20 21:12:55.477265
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    """
    The use of tempfile.mkstemp() will create a file with a random name.
    The delete parameter is set to False to ensure that the file is not deleted
    on close once the test completes.
    """
    fd, path = tempfile.mkstemp(prefix='ansible_is_lockfile_pid_valid_test_', suffix='_pid', dir='/tmp', delete=False)
    os.write(fd, b"1")
    os.close(fd)
    module = object
    module.fail_json = lambda x, y: False
    module.fail_json.msg = "Test fail_json"
    module.debug = lambda x: True
    module.params = dict(lockfile=path)
    yum_dnf = YumDnf(module)
    assert yum_dnf

# Generated at 2022-06-20 21:13:01.887018
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import os.path
    import sys
    pkg_mgr_name = 'Yum'
    lock_timeout = 0
    lockfile = ''
    module = ''
    yum_dnf = YumDnf(module)
    yum_dnf.pkg_mgr_name = pkg_mgr_name
    yum_dnf.lock_timeout = lock_timeout
    yum_dnf.lockfile = lockfile
    assert yum_dnf._is_lockfile_present() == False
    yum_dnf.wait_for_lock()
    assert yum_dnf._is_lockfile_present() == False


# Generated at 2022-06-20 21:13:10.254973
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    class YumDnf(with_metaclass(ABCMeta, object)):
        def __init__(self):
            pass
        def run(self):
            pass
    class TestYumDnf(YumDnf):
        def __init__(self):
            YumDnf.__init__(self)

    yumdnf = TestYumDnf()
    yumdnf.run()

# Generated at 2022-06-20 21:13:15.023451
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.common.collections import ImmutableDict

    def fail_json(msg, **kwargs):
        raise Exception(msg)

    def get_bin_path(exe, required=False, opt_dirs=[]):
        return ''

    module = ImmutableDict(
        fail_json=fail_json,
        check_mode=False,
        no_log=False,
        get_bin_path=get_bin_path,
    )

    yum_dnf = YumDnf(module)

    # Test empty list
    assert yum_dnf.listify_comma_sep_strings_in_list([]) == []

    # Test single package

# Generated at 2022-06-20 21:13:18.861834
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    with pytest.raises(NotImplementedError):
        YumDnf.run()



# Generated at 2022-06-20 21:13:34.677372
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    lock_timeout = 10
    lockfile = tempfile.mkstemp()[1]
    lockfile_pid = 1234
    class MockModule(object):

        def __init__(self):
            self.params = dict(lock_timeout=lock_timeout, lockfile=lockfile)

        def fail_json(self, msg, results):
            print(msg)

    class MockYumDnf(YumDnf):
        def __init__(self, module):
            super(MockYumDnf, self).__init__(module)

        def is_lockfile_pid_valid(self):
            return True

    yum_dnf = MockYumDnf(MockModule())

    # Create lockfile before running wait_for_lock()

# Generated at 2022-06-20 21:13:41.286858
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Test case for constructor of class YumDnf
    """
    def my_ansible_module():
        return fake_ansible_module

    def mock_fail_json(*args, **kwargs):
        raise Exception("Fail")

    def mock_exit_json(*args, **kwargs):
        raise Exception("Exit")

    # instance of class YumDnf is created

# Generated at 2022-06-20 21:13:44.541620
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    try:
        yumdnf = YumDnf(None)
        yumdnf.run()
    except NotImplementedError:
        pass


# Generated at 2022-06-20 21:13:59.327942
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    class YumDnf_mock():
        def __init__(self):
            self.module = None
            self.lockfile = ''
    class MockModule():
        def __init__(self):
            self.params = dict(lock_timeout = 30)
    class MockRunner():
        def __init__(self, cmd, chdir=None):
            self.rc = 0
            self.cmd = cmd
            self.stdout = ''
            self.stderr = ''
            self.chdir = chdir
            self.stdout_lines = []
            self.stderr_lines = []

        def run(self):
            if self.cmd == ['pwd']:
                self.stdout = '/\n'

# Generated at 2022-06-20 21:14:21.036537
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    import ansible.modules.packaging.os.yum

    m = ansible.modules.packaging.os.yum.AnsibleModule(argument_spec={
        'name': {
            'type': 'list', 'aliases': ['pkg']},
    })
    y = YumDnf(m)
    assert y.listify_comma_sep_strings_in_list([]) == []
    assert y.listify_comma_sep_strings_in_list(["a,b,c"]) == ["a", "b", "c"]
    assert y.listify_comma_sep_strings_in_list(["a,", ",b,c"]) == ["a", "b", "c"]

# Generated at 2022-06-20 21:14:32.197421
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    """
    Test for method is_lockfile_pid_valid
    """
    yumdnf = YumDnf(object())

    yumdnf.lockfile = '/var/run/yum.pid'
    yumdnf.lockfile_pid = '99999'
    assert not yumdnf.is_lockfile_pid_valid()

    yumdnf.lockfile = '/var/run/yum.pid'
    yumdnf.lockfile_pid = ''
    assert not yumdnf.is_lockfile_pid_valid()

    yumdnf.lockfile = '/var/run/yum.pid'
    yumdnf.lockfile_pid = '1'
    assert yumdnf.is_lockfile_pid_valid()


# Generated at 2022-06-20 21:14:41.553293
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    mock_module = MagicMock()
    y = YumDnf(mock_module)
    assert y.listify_comma_sep_strings_in_list([]) == []
    assert y.listify_comma_sep_strings_in_list(["string1", "string2"]) == ["string1", "string2"]
    assert y.listify_comma_sep_strings_in_list(["string1, string2"]) == ["string1", "string2"]
    assert y.listify_comma_sep_strings_in_list(["string1,string2"]) == ["string1", "string2"]


# TODO: This can be removed once yum is updated to not call _parse_remote_repo_opts

# Generated at 2022-06-20 21:14:44.228462
# Unit test for constructor of class YumDnf
def test_YumDnf():
    '''
    Unit test for constructor of class YumDnf
    '''
    test_module = AnsibleModule(name='TestModule', argument_spec=yumdnf_argument_spec)
    yd = YumDnf(test_module)
    assert yd.wait_for_lock() == None

# Generated at 2022-06-20 21:14:56.503470
# Unit test for constructor of class YumDnf
def test_YumDnf():
    '''
    Test case when module.params was constructed using wrong
    param type. For example, module.params['name'] were
    a list of comma separated strings.
    '''
    module = Mock()

# Generated at 2022-06-20 21:14:59.916927
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    fake_module = dict(
        fail_json=lambda self, msg, **kwargs: print(msg),
        params=dict(
            lock_timeout=3,
        ),
    )

    def _is_lockfile_present():
        return True

    # pid matching will not happen for a fake YumDnf obje

# Generated at 2022-06-20 21:15:04.137021
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    def is_lockfile_pid_valid():
        return False
    y = YumDnf(None)
    y.is_lockfile_pid_valid = is_lockfile_pid_valid
    assert not y._is_lockfile_present()


# Generated at 2022-06-20 21:15:06.716084
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.common.removed import removed_module
    with pytest.raises(NotImplementedError):
        removed_module.YumDnf.run()


# Generated at 2022-06-20 21:15:22.682491
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    This is a unit test for the constructor of the class YumDnf.

    The following things are tested:
    - List of comma separated strings is converted to a list with all elements as separate strings
    - List with single element [""] is converted to empty list []
    """

    def execute_module(module_args, fail_json=False):
        module = AnsibleModule(argument_spec=yumdnf_argument_spec)
        module.params['name'] = module_args['name']
        module.params['disablerepo'] = module_args['disablerepo']
        module.params['enablerepo'] = module_args['enablerepo']
        module.params['exclude'] = module_args['exclude']
        yum = YumDnf(module)
        return module.exit_json()


# Generated at 2022-06-20 21:15:34.519528
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """
    Unit test for method listify_comma_sep_strings_in_list of class YumDnf
    """
    yumdnf_obj = YumDnf(None)


# Generated at 2022-06-20 21:16:03.848559
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
  lockfile = 'tests/test_yum_dnf/test.lockfile'
  # create empty lockfile
  try:
    with open(lockfile, 'w') as fd:
      pass
  except:
    raise
  # test without lockfile_pid_valid
  yum_dnf = YumDnf(dict({}))
  assert(not yum_dnf.is_lockfile_pid_valid())
  # test with lockfile_pid_valid
  yum_dnf.lockfile_pid_valid = True
  assert(yum_dnf.is_lockfile_pid_valid())
  # remove empty lockfile
  os.remove(lockfile)


# Generated at 2022-06-20 21:16:13.992335
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    # Create an instance of the base class
    yum_dnf = YumDnf(None)
    try:
        yum_dnf.run()
    except NotImplementedError:
        pass
    else:
        assert False, "If method run of YumDnf was implemented, this line should not be reached. Expected NotImplementedError got None."

    # Test method listify_comma_sep_strings_in_list with lists of strings containing commas
    assert yum_dnf.listify_comma_sep_strings_in_list(["aaa", "bbb,ccc"]) == ["aaa", "bbb", "ccc"]

# Generated at 2022-06-20 21:16:27.959000
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.module_utils.yum_utils
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 21:16:37.080383
# Unit test for method run of class YumDnf
def test_YumDnf_run():

    with mock.patch('ansible.module_utils.common.run_command') as run_command, mock.patch('ansible.module_utils.ansible_yum.Yum') as Yum:
        mock_module = MagicMock()
        mock_module.params = dict()
        y = YumDnf.Yum(mock_module)
        y.run()
        assert not run_command.called


# Generated at 2022-06-20 21:16:48.140905
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    class DummyYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            return True
    dummy_yumdnf = DummyYumDnf(None)

    # Test 1 - Non empty list
    assert dummy_yumdnf.listify_comma_sep_strings_in_list(["a,b"]) == ["a", "b"]
    assert dummy_yumdnf.listify_comma_sep_strings_in_list(["a"]) == ["a"]
    assert dummy_yumdnf.listify_comma_sep_strings_in_list(["a", ",b"]) == ["a", "b"]

# Generated at 2022-06-20 21:16:53.802515
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.yum import Yum
    yum = Yum(dict())
    assert yum.listify_comma_sep_strings_in_list(["a"]) == ["a"]
    assert yum.listify_comma_sep_strings_in_list(["a,b"]) == ["a", "b"]
    assert yum.listify_comma_sep_strings_in_list(["a, b"]) == ["a", "b"]
    assert yum.listify_comma_sep_strings_in_list(["a", "b,c"]) == ["a", "b", "c"]
    assert yum.listify_comma_sep_strings_in_list

# Generated at 2022-06-20 21:17:05.499217
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.basic import AnsibleModule
    AnsibleModule = AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='list', elements='str', default=[]),
        )
    )
    with tempfile.TemporaryDirectory() as tmpdir:
        yumdnf = YumDnf(module)
        try:
            yumdnf.run()
        except NotImplementedError:
            pass
        else:
            assert False, "Test should fail"


# Generated at 2022-06-20 21:17:13.839915
# Unit test for constructor of class YumDnf
def test_YumDnf():
    # Cases for space separated packages in names
    # Names should be a list of strings, Test with a list of empty string
    module = MockModule()
    module.params['name'] = [""]
    yum_dnf_instance = YumDnf(module)
    assert yum_dnf_instance.names == [""], "Expected: [''] Actual: %s" % yum_dnf_instance.names

    # Names should be a list of strings, Test with a list of one element
    module = MockModule()
    module.params['name'] = ['git']
    yum_dnf_instance = YumDnf(module)
    assert yum_dnf_instance.names == ['git'], "Expected: ['git'] Actual: %s" % yum_dnf_instance.names

    # Names should

# Generated at 2022-06-20 21:17:19.379992
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    try:
        y = YumDnf(None)
        y.run()
    except NotImplementedError:
        pass
    except:
        assert False, 'Unexpected exception raised'
    else:
        assert False, 'Expected exception not raised'


# Generated at 2022-06-20 21:17:32.504809
# Unit test for constructor of class YumDnf

# Generated at 2022-06-20 21:18:33.849149
# Unit test for constructor of class YumDnf
def test_YumDnf():
    class Yum(YumDnf):
        def is_lockfile_pid_valid(self):
            return True
        def run(self):
            pass

    class YumDnfModuleMock():
        class fail_json():
            def __init__(self, msg, results=None):
                self.msg = msg
                self.results = results
        class params():
            def __init__(self, argument_spec, required_one_of, mutually_exclusive, supports_check_mode):
                self.argument_spec = argument_spec
                self.required_one_of = required_one_of
                self.mutually_exclusive = mutually_exclusive
                self.supports_check_mode = supports_check_mode
            def __getitem__(self, key):
                return getattr(self, key)

   

# Generated at 2022-06-20 21:18:44.938967
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=yumdnf_argument_spec,
        supports_check_mode=True,
        mutually_exclusive=[['name', 'list']],
        required_one_of=[['name', 'list', 'update_cache']],
    )

    yumdnf_module = YumDnf(module)

    # lists
    list1 = ["str1", "str2", "str3", "str4,str5,str6,str7", "str8", "str9", "str10,str11"]