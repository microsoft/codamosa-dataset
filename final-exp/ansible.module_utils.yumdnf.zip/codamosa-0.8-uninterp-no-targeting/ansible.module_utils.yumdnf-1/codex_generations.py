

# Generated at 2022-06-20 21:09:12.841606
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):
        def __init__(self, fail_json_msg, **kwargs):
            self.fail_json_msg = fail_json_msg
            self.params = kwargs

        def fail_json(self, msg):
            raise Exception(self.fail_json_msg)

    # create a fake yum.pid

# Generated at 2022-06-20 21:09:13.702137
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    assert True


# Generated at 2022-06-20 21:09:24.903689
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """Unit tests for method listify_comma_sep_strings_in_list of class YumDnf"""

    # Test for correct execution of the method for various input parameters
    temp_module = MockModule()
    test_obj = YumDnf(temp_module)
    assert test_obj.listify_comma_sep_strings_in_list(['abc']) == ['abc']
    assert test_obj.listify_comma_sep_strings_in_list(['abc,def']) == ['abc', 'def']
    assert test_obj.listify_comma_sep_strings_in_list(['abc, def, ghi']) == ['abc', 'def', 'ghi']

# Generated at 2022-06-20 21:09:36.202409
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class FakeModule(object):
        def __init__(self, name, lock_timeout):
            self.name = name
            self.lock_timeout = lock_timeout

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            if exc_type is not None:
                raise exc_value

        def fail_json(self, msg, results=[]):
            raise ValueError(msg)

    class FakeStat(object):
        def __init__(self, st_uid):
            self.st_uid = st_uid

    def mock_isfile(path):
        if path == "/proc/self/status":
            return True
        elif path == "/var/run/yum.pid":
            return True
        else:
            return False



# Generated at 2022-06-20 21:09:37.133245
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    assert True


# Generated at 2022-06-20 21:09:46.603735
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = FakeModule(
        enablerepo=['foo', 'bar'],
        exclude=['baz', 'eggs'],
        installroot='/',
        lock_timeout=10,
    )


# Generated at 2022-06-20 21:09:58.911780
# Unit test for constructor of class YumDnf

# Generated at 2022-06-20 21:10:00.518046
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    o = YumDnf(object)
    o.is_lockfile_pid_valid()

# Generated at 2022-06-20 21:10:10.530500
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={
        'state': dict(type='str', default="present"),
        'lock_timeout': dict(type='int', default=30),
    },
    supports_check_mode=False)

    y = YumDnf(m)
    y.lockfile = tempfile.mktemp()
    if os.path.exists(y.lockfile):
        os.unlink(y.lockfile)

    y.wait_for_lock()
    with open(y.lockfile, 'w') as f:
        pid = os.getpid()
        f.write(str(pid))

    y.is_lockfile_pid_valid = lambda: True
    y.wait_for_lock()


# Generated at 2022-06-20 21:10:17.076978
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Unit test for is_lockfile_pid_valid
    # Create a fake lockfile
    tmp_fd, tmp_path = tempfile.mkstemp()

    assert YumDnf.is_lockfile_pid_valid(tmp_path) is True

    # Create a fake lockfile with a non existing pid
    os.write(tmp_fd, to_native("999999").encode())

    # Make sure is_lockfile_pid_valid() returns False
    assert YumDnf.is_lockfile_pid_valid(tmp_path) is False

    # Clean up
    os.close(tmp_fd)
    os.unlink(tmp_path)

# Generated at 2022-06-20 21:10:40.165068
# Unit test for constructor of class YumDnf
def test_YumDnf():
    module = MockModule()
    pkg_mgr = YumDnf()

    # Test that members of class YumDnf are correctly initialized
    assert pkg_mgr.module == module
    assert pkg_mgr.allow_downgrade is False
    assert pkg_mgr.autoremove is False
    assert pkg_mgr.bugfix is False
    assert pkg_mgr.cacheonly is False
    assert pkg_mgr.conf_file is None
    assert pkg_mgr.disable_excludes is None
    assert pkg_mgr.disable_gpg_check is False
    assert pkg_mgr.disable_plugin == []
    assert pkg_mgr.disablerepo == []
    assert pkg_mgr.download_only is False
    assert pkg_mgr

# Generated at 2022-06-20 21:10:50.380664
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    try:
        os.mkdir(tempfile.gettempdir() + '/test_pkg_mgr')
    except Exception as e:
        raise Exception("Unable to create directory for test_pkg_mgr module tests. Exception %s" % str(e))
    try:
        os.mkdir(tempfile.gettempdir() + '/test_pkg_mgr/var')
        os.mkdir(tempfile.gettempdir() + '/test_pkg_mgr/var/run')
    except Exception as e:
        raise Exception("Unable to create directory for test_pkg_mgr module tests. Exception %s" % str(e))

# Generated at 2022-06-20 21:10:59.033864
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class FakeModule(object):
        """
        Fake class for module
        """
        params = dict(lock_timeout=30)

        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

    class FakeYumDnf(YumDnf):
        """
        Fake class for YumDnf, only to test method wait_for_lock
        """
        def __init__(self, module):
            super(FakeYumDnf, self).__init__(module)
            self.pkg_mgr_name = 'yum'
            self.lockfile = '/tmp/yum.pid'

        def is_lockfile_pid_valid(self):
            """
            Fake method to test is_lockfile_pid_valid
            """
            return True

    # test if lock

# Generated at 2022-06-20 21:11:02.361332
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    with pytest.raises(NotImplementedError):
        obj = YumDnf(object)
        obj.run()



# Generated at 2022-06-20 21:11:16.428292
# Unit test for constructor of class YumDnf
def test_YumDnf():
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-20 21:11:23.168277
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    class MockModule(object):
        def __init__(self):
            self.params = dict()
        def fail_json(self, msg, results=[]):
            raise Exception(msg)

    # pid which is running, lock_timeout of 30s
    test_yumdnf = YumDnf(MockModule())
    test_yumdnf.lockfile = tempfile.mktemp()
    pid = os.getpid()
    open(test_yumdnf.lockfile, 'w').write('%d\n' % pid)
    test_yumdnf.lock_timeout = 30
    test_yumdnf.wait_for_lock()
    # lockfile is removed
    assert not os.path.isfile(test_yumdnf.lockfile)

    # pid which is running, lock

# Generated at 2022-06-20 21:11:34.354324
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    #
    # Test for RH-based system
    #
    from ansible.module_utils.redhat_yumdnf import YumDnf
    import ansible.module_utils.six.moves.http_client as httplib
    import ansible.module_utils.six.moves.xmlrpc_client as xmlrpclib
    import ansible.module_utils.six.moves.urllib.parse as urlparse

    class MockModule(object):
        def __init__(self, argument_spec):
            self.params = {
                "conf_file": "/etc/yum.conf",
            }

        def fail_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 21:11:41.134401
# Unit test for constructor of class YumDnf

# Generated at 2022-06-20 21:11:46.905620
# Unit test for constructor of class YumDnf
def test_YumDnf():
    # Stub module object
    class ModuleStub(object):
        params = dict(param1=1, param2="hello")

    # Create an instance
    yd = YumDnf(ModuleStub())

    # Check that the instance variables have been set correctly
    assert yd.param1 == 1
    assert yd.param2 == "hello"

# Generated at 2022-06-20 21:11:59.010341
# Unit test for constructor of class YumDnf
def test_YumDnf():
    """
    Unit test for constructor of class YumDnf
    :return:
    """
    import ansible.module_utils.yum

    my_module = ansible.module_utils.yum.MyModule()
    my_module.params['allow_downgrade'] = False
    my_module.params['autoremove'] = False
    my_module.params['conf_file'] = "/etc/yum.conf"
    my_module.params['disable_excludes'] = None
    my_module.params['disable_gpg_check'] = False
    my_module.params['disable_plugin'] = []
    my_module.params['download_only'] = False
    my_module.params['download_dir'] = None
    my_module.params['enable_plugin'] = []
    my_module.params

# Generated at 2022-06-20 21:12:31.326385
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    from ansible.module_utils.basic import AnsibleModule
    my_obj = YumDnf(AnsibleModule)
    result = my_obj.listify_comma_sep_strings_in_list(['foo', 'bar', 'baz'])
    assert(result == ['foo', 'bar', 'baz'])
    result = my_obj.listify_comma_sep_strings_in_list(['foo, bar, baz'])
    assert(result == ['foo', 'bar', 'baz'])
    result = my_obj.listify_comma_sep_strings_in_list(['foo,bar,baz'])
    assert(result == ['foo', 'bar', 'baz'])
    result = my_obj.listify_comma_sep_strings_

# Generated at 2022-06-20 21:12:39.751000
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    yumdnf = YumDnf(None)
    yumdnf.lock_timeout = 0
    yumdnf.lockfile = tempfile.mkstemp()[1]
    result = yumdnf._is_lockfile_present()
    assert not result
    yumdnf.lock_timeout = 1
    yumdnf.lockfile = tempfile.mkstemp()[1]
    result = yumdnf._is_lockfile_present()
    assert not result
    yumdnf.lock_timeout = 2
    yumdnf.lockfile = tempfile.mkstemp()[1]
    result = yumdnf._is_lockfile_present()
    assert not result
    yumdnf.lock_timeout = 3
    yumdnf.lockfile = tempfile.mk

# Generated at 2022-06-20 21:12:45.748755
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(
            pkg_mgr_name = dict(type='str'),
            lock_timeout = dict(type='int')
        ),
        supports_check_mode=True
    )
    def run_m(self):
        self.module.fail_json(msg="{0} lockfile is held by another process".format(self.pkg_mgr_name))
    y = YumDnf(m)
    y.run = run_m
    y.pkg_mgr_name = 'yum'
    y.lock_timeout = 2
    y.lockfile = tempfile.mkstemp()[1]
    # Create a lockfile

# Generated at 2022-06-20 21:12:53.383155
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    from ansible.module_utils.yumdnf_base import YumDnf

    argspec = yumdnf_argument_spec.get('argument_spec')
    yumdnf = YumDnf({'argument_spec': argspec})
    assert yumdnf.is_lockfile_pid_valid()



# Generated at 2022-06-20 21:12:59.875340
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    import unittest
    import sys
    import json

    # Importing module in the context of this file allows accessing protected
    # methods of class YumDnf
    module_path = os.path.realpath(os.path.dirname(__file__))
    sys.path.append(module_path + '/../../')
    mod = __import__('yum')


# Generated at 2022-06-20 21:13:15.345324
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    class YumDnfMock(YumDnf):
        def __init__(self, module):
            YumDnf.__init__(self, module)
            self.lockfile = '/var/run/yum.pid'
            self.lock_timeout = 30

        def is_lockfile_pid_valid(self):
            return True

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda *args, **kwargs: None

    module = AnsibleModuleMock()
    yum_dnf_module = YumDnfMock(module)
    assert yum_dnf_module._is_lockfile_present()


# Generated at 2022-06-20 21:13:23.686380
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'yum':dict(type='bool', required=True)})
    if not module.params['yum']:
        from ansible.modules.packaging.os import dnf
        pkg_mgr = dnf.DNF(module)
    else:
        from ansible.modules.packaging.os.yum import Yum
        pkg_mgr = Yum(module)
    pkg_mgr.run()

# Generated at 2022-06-20 21:13:30.670078
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    # Mock _is_lockfile_present to return True
    def _is_lockfile_present(self):
        return True

    # Mock is_lockfile_pid_valid to return True
    def is_lockfile_pid_valid(self):
        return True

    # Mock fail_json method of AnsibleModule
    def fail_json(self, msg):
        raise Exception(msg)

    # Mock sleep method of time
    def sleep(sec):
        return True

    # Mock module creation

# Generated at 2022-06-20 21:13:33.489134
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    # Create an instance of some class that inherits from YumDnf
    yumdnf = YumDnf()

    # Verify the exception is raised
    with pytest.raises(NotImplementedError):
        yumdnf.run()


# Generated at 2022-06-20 21:13:40.981374
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    # create mock object for module, and ensure
    # that it is of type ansible.module_utils.basic.AnsibleModule
    # https://docs.ansible.com/ansible/latest/dev_guide/developing_modules_general.html
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    module = AnsibleModule(argument_spec=dict())
    yum = YumDnf(module)
    yum.run()
    # test fail_json without msg, with changed=true, with results=TEST

# Generated at 2022-06-20 21:14:29.240312
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    class MyYumDnf(YumDnf):
        def __init__(self, module):
            self.pkg_mgr_name = 'dummy_yum'
            self.lockfile = tempfile.mktemp()
            YumDnf.__init__(self, module)

        def wait_for_lock(self):
            return YumDnf.wait_for_lock(self)

        def is_lockfile_pid_valid(self):
            return True

    test_module = AnsibleModule(argument_spec=dict(lock_timeout=dict(type='int', default=1)))

    test_yum = MyYumDnf(test_module)
    with open(test_yum.lockfile, 'w') as lock_file:
        lock_file.write("1")


# Generated at 2022-06-20 21:14:35.466019
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    yum = YumDnf(None)
    some_list = []    
    assert yum.listify_comma_sep_strings_in_list(some_list) == []
    some_list = ["foo", "bar", "baz"]
    assert yum.listify_comma_sep_strings_in_list(some_list) == ["foo", "bar", "baz"]
    some_list = ["foo", "bar,baz,qux"]
    assert yum.listify_comma_sep_strings_in_list(some_list) == ["foo", "bar", "baz", "qux"]
    some_list = ["foo", "", "bar", "baz,qux"]

# Generated at 2022-06-20 21:14:40.311924
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    """Unit test for method is_lockfile_pid_valid of class YumDnf"""
    class TestYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            return True

    yumdnf = TestYumDnf(True)
    assert yumdnf.is_lockfile_pid_valid() is True


# Generated at 2022-06-20 21:14:46.405684
# Unit test for constructor of class YumDnf
def test_YumDnf():

    module = AnsibleModule(
        argument_spec=dict(
            argument_spec=dict(),
            required_one_of=[],
            mutually_exclusive=[],
            supports_check_mode=True,
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-20 21:14:54.071421
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    """Unit test for method is_lockfile_pid_valid of class YumDnf

    Run command: python -m pytest -s -v test_YumDnf.py
    """
    # We can't do much testing on a abstract class
    yum_dnf = YumDnf(None)
    assert yum_dnf.is_lockfile_pid_valid() == True


# Generated at 2022-06-20 21:15:05.697675
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.module_utils.yum

    # Must work with and without YumDnf prefix

# Generated at 2022-06-20 21:15:15.203193
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """
    Unit test for yum/dnf.listify_comma_sep_strings_in_list()
    """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    class fake_YumDnf(with_metaclass(ABCMeta, YumDnf)):
        def __init__(self, module):
            self.module = module
        def is_lockfile_pid_valid(self):
            return False

    yum_dnf = fake_YumDnf(module)

    input_list = ["one, two,four", "five, six", "ten, eleven", "twelve"]
    output_list = yum_dnf.listify_comma_sep_strings_in_list(input_list)



# Generated at 2022-06-20 21:15:28.219085
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import os
    import tempfile
    import shutil
    from ansible.module_utils.six import PY3
    if PY3:
        from urllib.request import urlopen
    else:
        from urllib2 import urlopen

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def fail_json(self, *args, **kwargs):
            raise Exception(args[0])


# Generated at 2022-06-20 21:15:31.547105
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    with pytest.raises(NotImplementedError):
        y = YumDnf(module)
        y.run()



# Generated at 2022-06-20 21:15:47.141843
# Unit test for constructor of class YumDnf
def test_YumDnf():
    from ansible.modules.package.yum import YumDnfModule
    from ansible.module_utils.facts.system.pkg_mgr import PackageManager
    from ansible.module_utils.facts.system.pkg_mgr import YumPackageManager
    from ansible.module_utils.facts.system.pkg_mgr import DnfPackageManager
    from ansible.module_utils.facts.system.pkg_mgr import RpmPackageManager
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import RpmBasedDistribution
    from ansible.module_utils.facts.system.distribution import RedHatDistribution
    from ansible.module_utils.facts.system.distribution import ScientificRedHatDistribution

    # Create our fake package

# Generated at 2022-06-20 21:17:22.844524
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    with tempfile.TemporaryDirectory() as tmpdirname:
        module = FakeAnsibleModule()
        module.name = ['bash']
        yum_obj = YumDnf(module)
        yum_obj.yum_path = 'yum'
        yum_obj.module.params['name'] = ['bash']

        result = yum_obj.run()
        assert result['msg'] == 'No changes needed for bash-4.2.46-20.el7.x86_64. ' \
                                 'Package(s) already installed and latest version'



# Generated at 2022-06-20 21:17:33.701222
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    # Mock class that includes DNF module
    class DnfModuleMock(object):

        class ModuleFailJsonException(Exception):
            pass

        def __init__(self, msg, results):
            self.msg = msg
            self.results = results

        def fail_json(self, msg, results):
            raise self.ModuleFailJsonException(msg, results)

    # mock the required parameters of DNF module
    module = DnfModuleMock(msg='', results=[])

    # Check if method returns expected results
    # 1. If the lockfile pid is valid
    # 2. If the lockfile pid is invalid
    # 3. If the lockfile pid is not present
    # 4. If the lockfile pid is invalid and there is another lockfile pid
    # 5. If the lockfile pid is invalid and there is another

# Generated at 2022-06-20 21:17:43.006286
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():
    '''
    validation of the method wait_for_lock of the class YumDnf
    '''
    global test_wait_for_lock_counter
    test_wait_for_lock_counter = 0
    global test_wait_for_lock_passed
    test_wait_for_lock_passed = True

    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self.params['lock_timeout'] = 2
            self.lockfile = None

        def fail_json(self, msg):
            global test_wait_for_lock_passed
            test_wait_for_lock_passed = False


# Generated at 2022-06-20 21:17:54.486817
# Unit test for constructor of class YumDnf
def test_YumDnf():
    import ansible.module_utils.yumdnf
    import ansible.module_utils.yum
    import ansible.module_utils.dnf
    import ansible.module_utils.basic
    import ansible.modules.packaging.os
    import ansible.utils.module_docs
    import ansible.module_utils.four

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=yumdnf_argument_spec['argument_spec'],
        required_one_of=yumdnf_argument_spec['required_one_of'],
        mutually_exclusive=yumdnf_argument_spec['mutually_exclusive'],
        supports_check_mode=yumdnf_argument_spec['supports_check_mode'],
    )

    # Test with Y

# Generated at 2022-06-20 21:18:09.815601
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    """Unit test for method `listify_comma_sep_strings_in_list` of class `YumDnf`."""
    yumdnf = YumDnf({'params':
                         {'name': ['package1, package2', 'package3'],
                          'disablerepo': 'disabledrepo1',
                          'enablerepo': 'enabledrepo1',
                          'exclude': ['excludepackage1, excludepackage2', 'excludepackage3'],
                         },
                    })
    assert yumdnf.names == ['package1', 'package2', 'package3']
    assert yumdnf.disablerepo == ['disabledrepo1']
    assert yumdnf.enablerepo == ['enabledrepo1']
    assert yumdnf.ex

# Generated at 2022-06-20 21:18:20.342436
# Unit test for method run of class YumDnf
def test_YumDnf_run():

    from ansible.module_utils import basic
    from ansible.module_utils.common.sys_info import get_distribution

    distro = get_distribution()
    if distro.lower() == 'fedora':
        from ansible.modules.package_manager.dnf import DnfPackageManager as PackageManager
    else:
        from ansible.modules.package_manager.yum import YumPackageManager as PackageManager

    module = basic.AnsibleModule(
        argument_spec=PackageManager.argument_spec,
    )

    package_manager = PackageManager(module)
    try:
        package_manager.run()
    except Exception as e:
        module.fail_json(msg=to_native(e))



# Generated at 2022-06-20 21:18:25.041691
# Unit test for method run of class YumDnf
def test_YumDnf_run():
    try:
        YumDnf.run(object)
    except Exception as e:
        print(to_native(e))
        assert(type(e) is NotImplementedError)


# Generated at 2022-06-20 21:18:31.542183
# Unit test for method listify_comma_sep_strings_in_list of class YumDnf
def test_YumDnf_listify_comma_sep_strings_in_list():
    class MockModule:
        def fail_json(self, *args, **kwargs):
            raise AssertionError("Fail JSON was passed to fail_json")

    class MockYumDnf(YumDnf):
        def is_lockfile_pid_valid(self):
            return False

    m = MockModule()
    yd = MockYumDnf(m)
    assert yd.listify_comma_sep_strings_in_list([]) == []
    assert yd.listify_comma_sep_strings_in_list([""]) == []
    assert yd.listify_comma_sep_strings_in_list(["foo"]) == ["foo"]
    assert yd.listify_comma_sep_strings_in_list(["foo, bar"])

# Generated at 2022-06-20 21:18:41.286352
# Unit test for method is_lockfile_pid_valid of class YumDnf
def test_YumDnf_is_lockfile_pid_valid():
    tempdir = tempfile.mkdtemp()
    lockfile_path = os.path.join(tempdir, "test_YumDnf_is_lockfile_pid_valid.pid")
    with open(lockfile_path, 'w') as fd:
        fd.write(to_native(os.getpid()))
    yumdnf = YumDnf(dict())
    yumdnf.lockfile = lockfile_path
    ans = yumdnf.is_lockfile_pid_valid()
    assert ans == True

# Generated at 2022-06-20 21:18:55.488513
# Unit test for method wait_for_lock of class YumDnf
def test_YumDnf_wait_for_lock():

    class TestModule():
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg, results):
            pass

    class TestYumDnf(YumDnf):
        def __init__(self, module):
            super(TestYumDnf, self).__init__(module)

        def is_lockfile_pid_valid(self):
            return True

    yum = TestYumDnf(TestModule({'lock_timeout': 0}))
    yum.lockfile = tempfile.mkstemp()[1]
    result = yum.wait_for_lock()
    os.remove(yum.lockfile)
    assert result == None

    yum = TestYumDnf(TestModule({'lock_timeout': 2}))
