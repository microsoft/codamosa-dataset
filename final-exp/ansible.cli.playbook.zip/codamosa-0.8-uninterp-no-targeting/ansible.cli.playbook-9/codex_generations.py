

# Generated at 2022-06-20 13:12:46.344133
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = PlaybookCLI.init_parser(options=None)
    assert parser is not None

# Generated at 2022-06-20 13:12:47.616642
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pbcli = PlaybookCLI()
    pbcli.run()

# Generated at 2022-06-20 13:12:49.728171
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    test_cli = PlaybookCLI(args=['playbook.yml'])
    assert test_cli.parser

# Generated at 2022-06-20 13:12:54.604180
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # test for non-empty args
    options = opt_help.make_parser(['site.yml'], '0.1')
    options = CLI.base_parser(options)
    result = PlaybookCLI(options).run()
    assert(result == 0)

    # test for empty args
    options = opt_help.make_parser([], '0.1')
    options = CLI.base_parser(options)
    result = PlaybookCLI(options).run()
    assert(result == 255)

# Generated at 2022-06-20 13:12:58.494460
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cls = PlaybookCLI()
    cls.options = opt_help.get_default_options(constants=C, stdout_callback=None, runas_pass='test_pass')
    cls.options.verbosity = 6
    cls.options.syntax = True
    cls.options.connection = "test_connection"
    cls.parser = None
    cls.args = None
    result = cls.post_process_args(cls.options)
    assert result.verbosity == 6
    assert result.syntax == True

# Generated at 2022-06-20 13:13:00.123272
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb = PlaybookCLI()
    assert pb is not None

# Generated at 2022-06-20 13:13:01.117902
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    p = PlaybookCLI(['ansible-playbook', 'test.yml'], '0.0')
    assert p.parser is not None

# Generated at 2022-06-20 13:13:01.827496
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:13:05.778559
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    ''' constructor test'''
    obj = PlaybookCLI(['playbook.yml'])
    assert obj._playbook_paths == ['playbook.yml']
    assert obj.options is None
    assert obj.args is None



# Generated at 2022-06-20 13:13:15.535373
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    from ansible import cli, context
    load_plugins()

# Generated at 2022-06-20 13:13:31.589777
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Test with no arg
    test_args = []
    cli = PlaybookCLI(args=test_args)
    test_playbookCLI_instance = cli.init_parser()
    assert test_playbookCLI_instance.__class__.__name__ == 'CLI'


test_PlaybookCLI_init_parser()


# Generated at 2022-06-20 13:13:35.589417
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pbcli = PlaybookCLI([__file__])
    assert isinstance(pbcli, PlaybookCLI)
    assert hasattr(pbcli, 'run')

# Generated at 2022-06-20 13:13:37.051305
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    assert PlaybookCLI()

# Generated at 2022-06-20 13:13:41.637447
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    p = PlaybookCLI(['-i', 'localhost,', '-e',
                     '@test_data/ansible-cmdline/test_vars.yaml', '--list-hosts',
                     'test_data/ansible-cmdline/playbook_lists.yaml'])
    assert p is not None

# Generated at 2022-06-20 13:13:42.822681
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:13:44.883217
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: Need to add unit tests for method run of class PlaybookCLI()
    pass

# Generated at 2022-06-20 13:13:49.674416
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    # Create a test parser
    parser = PlaybookCLI.create_parser()
    options, args = parser.parse_known_args(['playbook.yml', 'playbook2.yml'])

    # Create a PlaybookCLI object by passing it the test parser and options
    playbook_cli = PlaybookCLI(parser, options)

    # Call the init_parser method of the playbook_cli object
    playbook_cli.init_parser()

# Generated at 2022-06-20 13:13:52.836501
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    """
    Empty function to test that we can unit test the
    post_process_args method of class PlaybookCLI
    """
    pass

# Generated at 2022-06-20 13:14:01.894793
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class Args():
        pass

    context.CLIARGS = Args()

    context.CLIARGS.ask_pass = True
    context.CLIARGS.ask_su_pass = True
    context.CLIARGS.ask_su_pass = True
    context.CLIARGS.ask_vault_pass = True
    context.CLIARGS.verbosity = 0

    cli = PlaybookCLI(args=['ansible-playbook', 'test'])
    cli.post_process_args(context.CLIARGS)

    assert context.CLIARGS.verbosity == 0

# Generated at 2022-06-20 13:14:03.886476
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI(['ansible-playbook'])
    assert cli._play_prereqs()

# Generated at 2022-06-20 13:14:23.946599
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    result = PlaybookCLI()
    assert result

# Generated at 2022-06-20 13:14:27.732936
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # object instantiation for testing
    pb = PlaybookCLI()
    # check attribute verbosity exists
    assert pb.verbosity
    # check method init_parser exists
    assert pb.init_parser

# Generated at 2022-06-20 13:14:29.818787
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Create a parser object
    parser = PlaybookCLI()
    parser.init_parser()


# Generated at 2022-06-20 13:14:40.101350
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockPlaybookExecutor(object):
        playbook_executor_results = list()

        @staticmethod
        def run():
            return MockPlaybookExecutor.playbook_executor_results

    class MockDisplay(object):
        @staticmethod
        def display(x):
            pass

    class MockCLI(object):
        @staticmethod
        def run():
            pass

        @staticmethod
        def post_process_args(options):
            pass

        @staticmethod
        def get_host_list(inventory, subset):
            pass

        @staticmethod
        def ask_passwords():
            return None, None

        @staticmethod
        def _play_prereqs():
            return (None, None, None)

        @staticmethod
        def _flush_cache(inventory, variable_manager):
            pass



# Generated at 2022-06-20 13:14:40.745635
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pass

# Generated at 2022-06-20 13:14:43.025031
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Setup a fixture PlaybookCLI object
    import multiprocessing
    # TODO


# Generated at 2022-06-20 13:14:55.549471
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Test function argument parser
    parser = CLI.base_parser(
        usage='%prog [options] playbook.yml [playbook2 ...]',
        connect_opts=True,
        meta_opts=True,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        inventory_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        desc='Runs Ansible playbooks, executing the defined tasks on the targeted hosts.')
    parser.add_argument('--list-tasks', dest='listtasks', action='store_true',
                        help='list all tasks that would be executed')

# Generated at 2022-06-20 13:15:03.876879
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from unittest.mock import MagicMock, patch
    from ansible.cli.playbook import PlaybookCLI

    def ask_passwords():
        return (None, None)

    def get_host_list(inventory, subset):
        pass

    class Display():
        def __init__(self):
            self.verbosity = 0

        def display(self, msg):
            pass

    class AnsibleError():
        def __init__(self, msg):
            pass

    class CLI():
        def __init__(self, args):
            self.args = args
            self.parser = MagicMock()
            self.CONSTANTS_PATH = None

        def parse(self):
            return self.args


# Generated at 2022-06-20 13:15:04.822258
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:15:06.129566
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pbcli = PlaybookCLI()
    pbcli.init_parser()


# Generated at 2022-06-20 13:15:41.581754
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    fixture = PlaybookCLI(['-v', 'playbook.yml'])
    fixture._flush_cache = lambda a, b: None
    fixture.ask_passwords = lambda: ('sshpass', 'becomepass')
    fixture._play_prereqs = lambda: ('loader', 'inventory', 'variable_manager')
    # Silence the output
    fixture.display = lambda a: None
    assert 0 == fixture.run()

# Generated at 2022-06-20 13:15:42.819413
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    c = PlaybookCLI()
    c.post_process_args([])

# Generated at 2022-06-20 13:15:51.335485
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pl_cli = PlaybookCLI()
    for handler in pl_cli.parser._handlers:
        if handler._option_string == '-h':
            assert handler.help == PlaybookCLI.parser.description
    assert pl_cli.parser._get_optional_actions
    assert pl_cli.parser._print_message == '%(prog)s [options] playbook.yml [playbook2 ...]'
    assert pl_cli.parser._print_usage == '%(prog)s [options] playbook.yml [playbook2 ...]'

# Generated at 2022-06-20 13:15:59.003637
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pb = PlaybookCLI([])
    args = ["--list-tags", "--list-tasks", "playbook1.yml", "playbook2.yml"]
    parser = pb.init_parser()
    result = parser.parse_args(args)

    # expected result
    exp_args = ['playbook1.yml', 'playbook2.yml']
    exp_listtags = True
    exp_listtasks = True
    assert result.args == exp_args
    assert result.listtags == exp_listtags
    assert result.listtasks == exp_listtasks

# Generated at 2022-06-20 13:16:00.917533
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    cli = PlaybookCLI(args=[])
    assert cli.parser._prog_name == "ansible-playbook"

# Generated at 2022-06-20 13:16:04.337822
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    # This test case is for constructor of class PlaybookCLI
    display = Display()
    cli = PlaybookCLI(None, display)
    assert cli.display == display, 'PlaybookCLI object creation failed'


# Generated at 2022-06-20 13:16:04.882180
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:16:13.482160
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # setup:
    add_all_plugin_dirs = PlaybookCLI.setup(
            'add_all_plugin_dirs',
            {'ansible_module_utils._text.to_bytes':lambda s, errors='strict':s,
             'os.path.exists':lambda s:True,
             'os.path.isfile':lambda s:True,
             'os.stat':lambda s:TypeVar('os.stat',**{'st_mode':TypeVar('os.stat.st_mode',**{'S_ISFIFO':True})}),
             'os.path.abspath':lambda s:s,
             'os.path.dirname':lambda s:s,
             }
        )
    add_all_plugin_dirs([])

# Generated at 2022-06-20 13:16:25.543735
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-20 13:16:39.762882
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    inventories = [u'zzz']
    forks = 5
    step = True
    start_at_task = u'blah'
    module_path = u'zzzz'
    inventory = u'x,y'
    subset = u'a:b'
    ask_pass = True
    private_key_file = u'1234'
    skip_tags = u'tag1,tag2'
    tags = u'tag3,tag4'
    verbosity = 2
    syntax = True
    ask_vault_pass = True
    vault_password_file = u'987'
    listtasks = True
    listtags = True
    check = True
    diff = True
    remote_user = 'bob'
    connection = u'local'
    become = True

# Generated at 2022-06-20 13:17:33.746098
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    PlaybookCLI.init_parser(PlaybookCLI)

# Generated at 2022-06-20 13:17:42.454303
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    playbook_cli = PlaybookCLI(args=["ansible-playbook", "--list-hosts", "--list-tasks", "--list-tags", "--syntax-check", "--limit", "all", "--step", "--start-at-task", "--flush-cache", "--force-handlers", "--inventory-file", "hosts", "example.yml"])
    options = playbook_cli.parse()
    playbook_cli.post_process_args(options)

    # Check if the context parameter of class PlaybookCLI is changed by the post_process_args method
    assert context.CLIARGS['listhosts'] == True
    assert context.CLIARGS['listtasks'] == True
    assert context.CLIARGS['listtags'] == True
    assert context.CLIARGS

# Generated at 2022-06-20 13:17:55.076031
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI([])

    # Test with no arguments in args dict
    cli_args_dict = {}
    cli.post_process_args(cli_args_dict)

    # Test  with list_hosts in args dict
    cli_args_dict = {'listhosts': True}
    cli.post_process_args(cli_args_dict)

    # Test with list_tasks in args dict
    cli_args_dict = {'listtasks': True}
    cli.post_process_args(cli_args_dict)

    # Test with list_tags in args dict
    cli_args_dict = {'listtags': True}
    cli.post_process_args(cli_args_dict)

    # Test with step in args dict
    cli_args

# Generated at 2022-06-20 13:18:02.668831
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class FakeOptions(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    def assertRaisesAnsibleError(e):
        assert isinstance(e, AnsibleError)
        assert str(e) == 'parameter conflicts detected: fork_opts'

    cli = PlaybookCLI(['/path/to/playbook.yml'], '/dev/null')
    options = FakeOptions(listhosts=True)
    cli.post_process_args(options)

    options = FakeOptions(listtags=True)
    cli.post_process_args(options)

    options = FakeOptions(listtasks=True)
    cli.post_process_args(options)

    options = FakeOptions

# Generated at 2022-06-20 13:18:13.615840
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class MockParser(object):
        def error(self, msg):
            raise Exception(msg)

    class MockOptions(object):
        privilege_escalation = False
        connection = 'local'
        forks = 1
        timeout = 10
        verbosity = 0
        check = False
        start_at_task = None
        step = False
        diff = False
        host_key_checking = True
        remote_user = None
        become = False
        become_user = None
        become_method = None
        become_ask_pass = True

    mock_args = MockOptions()

    class MockCLI(object):
        def validate_conflicts(self, options, runas_opts=True, vault_opts=True, fork_opts=True):
            return

    cli = MockCLI()

# Generated at 2022-06-20 13:18:15.986616
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # create instance of PlaybookCLI
    cli_obj = PlaybookCLI()
    # check if instance created properly
    assert isinstance(cli_obj, PlaybookCLI)

# Generated at 2022-06-20 13:18:27.025651
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    # Create the parser
    parser = CLI.base_parser(
        usage="%prog [options] playbook.yml [playbook2 ...]",
        # epilog='Use %(prog)s --help for more information about a given subcommand.',
        connect_opts=True, meta_opts=True, runas_opts=True, subset_opts=True, check_opts=True, inventory_opts=True, runtask_opts=True, vault_opts=True, fork_opts=True, module_opts=True)

    # Add the list of repo args
    parser.add_argument('--list-tasks', dest='listtasks', action='store_true', help="list all tasks that would be executed")

# Generated at 2022-06-20 13:18:34.637531
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    
    cli=PlaybookCLI()

    # create parser for CLI options
    cli.init_parser()

    # create object for dataloader to load the data from yaml
    loader=DataLoader()

    # create inventory object with
    inventory=InventoryManager(loader=loader, sources='localhost,')

    # create variable manager object
    variable_manager=VariableManager(loader=loader, inventory=inventory)

    play_context=cli.cli_play_context()

    # create play
    play=Play()
   

# Generated at 2022-06-20 13:18:36.561781
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    playbookcli = PlaybookCLI()
    assert playbookcli.module_opts is None


# Generated at 2022-06-20 13:18:44.966371
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import ansible.playbook.play

    playbook_obj = ansible.playbook.play.Play()
    playbook_cli = PlaybookCLI(None)
    playbook_cli.options = dict()

    context.CLIARGS = dict()
    context.CLIARGS['subset'] = ''
    context.CLIARGS['listhosts'] = True
    context.CLIARGS['flush_cache'] = False

    context.CLIARGS['listtags'] = False
    context.CLIARGS['listtasks'] = False
    ret = playbook_cli.run()

    # output.clear()

# Generated at 2022-06-20 13:21:16.431581
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(['Init', 'Parser', 'Test'], 'ini')
    parser = cli.init_parser()

    assert parser._option_string_actions['-i'] == parser._option_string_actions['--inventory-file']
    assert parser._option_string_actions['-l'] == parser._option_string_actions['--limit']
    assert parser._option_string_actions['--list-hosts'] == parser._option_string_actions['--list-hosts']
    assert parser._option_string_actions['-C'] == parser._option_string_actions['--check']
    assert parser._option_string_actions['-g'] == parser._option_string_actions['--tags']

# Generated at 2022-06-20 13:21:25.200643
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.utils.display import Display
    from ansible.plugins.loader import add_all_plugin_dirs
    import ansible.constants as C
    import os
    import sys
    import unittest

    # Test loading playbook names from directory with json, yaml and yml files
    # to make sure only playbook has been loaded

# Generated at 2022-06-20 13:21:40.458908
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Retrieve global ansible variables
    gvars = globals()

    # Create a new instance of the Ansible ArgumentParser object
    ap = gvars['AnsibleArgumentParser']()

    # Create a new instance of the Ansible CLI object
    acli = gvars['AnsibleCLI'](ap)

    # Create a new instance of the Ansible CLI Playbook object
    acli_pb = gvars['PlaybookCLI'](acl)

    # Create a new instance of the Ansible CLI Options object
    acli_opts = gvars['AnsibleOptions'](acl)

    # Create a new instance of the Ansible CLI Options Playbook object
    acli_opts_pb = gvars['PlaybookOptions'](acl)

    # For PlaybookCLI keep only the following options
    #

# Generated at 2022-06-20 13:21:44.606284
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    try:
        pbc = PlaybookCLI()
        assert isinstance(pbc, PlaybookCLI)
    except Exception as e:
        print(e)
        assert 0


# Generated at 2022-06-20 13:21:52.566150
# Unit test for constructor of class PlaybookCLI

# Generated at 2022-06-20 13:21:59.742906
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import pkgutil
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    # This test looks for playbooks in the 'test/integration/playbooks' dir,
    # but we don't want to import it, because that causes the modules to be loaded by the loader
    # which would happen when running the module, and that can cause collisions in importers.
    # Using pkgutil.get_loader will load the module without causing the importers to be loaded.
    p = pkgutil.get_loader("ansible.playbook.playbook")
    test_playbook_dir = os.path.join(os.path.dirname(p.filename), 'playbooks/test')

    # create base objects
    loader, inventory, variable_manager = PlaybookCLI._play_

# Generated at 2022-06-20 13:22:06.394201
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-20 13:22:08.555970
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    import argparse
    PlaybookCLI.init_parser(PlaybookCLI())


# Generated at 2022-06-20 13:22:17.253414
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    Unit test for method run of class PlaybookCLI
    '''
    # pylint: disable=unused-argument
    class MockPlaybookCLI(PlaybookCLI):
        ''' Mock class for unit test '''

        def __init__(self, args=None):
            self.args = args
            self.config = None

        def init_parser(self):
            ''' mock for init_parser method'''
            return

        def post_process_args(self, options):
            ''' mock for post_process_args method'''
            return options

        def run(self):
            return None

    class MockCLI(CLI):
        ''' mock class for CLI '''
        def get_opt(self, names):
            ''' mock for getopt method'''
            return self.options

# Generated at 2022-06-20 13:22:18.199028
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = PlaybookCLI()
    parser.init_parser()
    assert parser.parser is not None