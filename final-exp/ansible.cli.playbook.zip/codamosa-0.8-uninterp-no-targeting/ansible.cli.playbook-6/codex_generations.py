

# Generated at 2022-06-20 13:12:46.060041
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    try:
        PlaybookCLI()
    except NameError as e:
        assert True, "constructor of PlaybookCLI raised NameError exception!: %s" % e
    else:
        assert False, "constructor of PlaybookCLI did not raise NameError exception!"

# Generated at 2022-06-20 13:12:54.582377
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    args = [
        'ansible-playbook',
        '-i', './hosts',
        '-e', 'ansible_python_interpreter=/usr/bin/python3',
        'playbook.yml',
        'playbook2.yml'
    ]

    parser = PlaybookCLI(args).init_parser()

    assert parser.description == "Runs Ansible playbooks, executing the defined tasks on the targeted hosts."
    assert parser.usage == "%prog [options] playbook.yml [playbook2 ...]"

    for option in parser._option_string_actions.keys():
        if option == '-l' or option == '--limit':
            assert option in parser._option_string_actions
        if option == '-i' or option == '--inventory-file':
            assert option in parser._

# Generated at 2022-06-20 13:13:01.752337
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class MockPlaybookCLI(PlaybookCLI):
        def __init__(self):
            self.parser = MockParser()

    class MockParser():
        def __init__(self):
            self.args = ['playbook1', 'playbook2']

    playbook_cli = MockPlaybookCLI()
    playbook_cli.post_process_args('options')
    assert playbook_cli.display.verbosity == 'options'

# Generated at 2022-06-20 13:13:03.718254
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pbc = PlaybookCLI()
    assert isinstance(pbc, PlaybookCLI)

# Generated at 2022-06-20 13:13:05.919590
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli_obj = PlaybookCLI()
    cli_obj.init_parser()
    assert hasattr(cli_obj, 'parser')

# Generated at 2022-06-20 13:13:09.418563
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    assert PlaybookCLI
    cli = PlaybookCLI()
    cli.init_parser()
    assert cli.parser
    assert cli.parser._actions[3].help == 'list all tasks that would be executed'



# Generated at 2022-06-20 13:13:11.683739
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI()
    cli.post_process_args(cli.parse())
    cli.run()

# Generated at 2022-06-20 13:13:16.024810
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    """
    This is to test the method init_parser of class PlaybookCLI
    """
    playbook_cli = PlaybookCLI()
    playbook_cli.init_parser()
    assert playbook_cli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert playbook_cli.parser.prog == 'ansible-playbook'

# Generated at 2022-06-20 13:13:18.420768
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # This is a constructor test of class PlaybookCLI
    # Please check if the object is successfully callable
    PlaybookCLI()

if __name__ == '__main__':
    test_PlaybookCLI()

# Generated at 2022-06-20 13:13:30.759317
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class Options:
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = None
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.become_ask_pass = False
            self.remote_user = ''
            self.verbosity = 0
            self.check = False
            self.syntax = None
            self.inventory = None
            self.listhosts = None
            self.subset = None
            self.extra_vars = []
            self.ask_vault_pass = False
            self.vault_password_files = None
            self.vault_ids = None
            self.tags = []
            self.skip_tags = []

# Generated at 2022-06-20 13:13:41.428189
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pb = PlaybookCLI()
    pb.run()

# Generated at 2022-06-20 13:13:46.074507
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    # Constructor of class PlaybookCLI
    obj = PlaybookCLI()

    # Test case for properties
    assert obj.description == 'Ansible Playbook Runner'

    # Test case for methods
    obj.post_process_args({})
    obj.run()

# Generated at 2022-06-20 13:13:58.573834
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI()

    # test case 1: none of the options are provided

# Generated at 2022-06-20 13:14:13.016082
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # mock options passed to PlaybookCLI object

# Generated at 2022-06-20 13:14:16.582981
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # create object of class PlaybookCLI
    cli = PlaybookCLI()
    # test parser object creation and init_parser method
    parser = cli.init_parser()
    # verify that parser is object
    assert isinstance(parser, object)



# Generated at 2022-06-20 13:14:31.024825
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import unittest
    import tempfile
    from ansible.vars.reserved import DEFAULT_VAULT_PASSWORD_FILE

    class TestPlaybookCLI(unittest.TestCase):
        def setUp(self):
            class Bunch(dict):
                def __getattr__(self, key):
                    return self[key]

# Generated at 2022-06-20 13:14:32.337487
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
  cli = PlaybookCLI()
  assert cli


# Generated at 2022-06-20 13:14:40.337462
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # When calling the PlaybookCLI constructor with two arguments, ansible-playbook tests if they are both valid
    PlaybookCLI(["play1.yml", "play2.yml"])

    # When calling the PlaybookCLI constructor with one argument, ansible-playbook tests if it is a valid file
    PlaybookCLI(["play1.yml"])

    # When calling the PlaybookCLI constructor with no arguments, ansible-playbook tests if there is a playbook in the current directory
    PlaybookCLI([])

# Generated at 2022-06-20 13:14:43.430588
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(None)
    parser = cli.init_parser()
    assert isinstance(parser, CLI.parser_class)


# Generated at 2022-06-20 13:14:55.095125
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()

    # without arguments, parser.error will be raised
    try:
        cli.parse([])
    except:
        pass

    cli.parse(['--connection', 'local', 'playbook_test.yml'])
    (ret, ) = cli.run()
    assert 0 == ret

    cli.parse(['--connection', 'local', 'playbook_test_with_include.yml'])
    (ret, ) = cli.run()
    assert 0 == ret

    cli.parse(['--connection', 'local', 'playbook_test_with_include_roles.yml'])
    (ret, ) = cli.run()
    assert 0 == ret

# Generated at 2022-06-20 13:15:20.446454
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb = PlaybookCLI()
    assert pb is not None

if __name__ == "__main__":
    pb = PlaybookCLI()
    pb.run()

# Generated at 2022-06-20 13:15:21.872093
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI()
    return cli

# Generated at 2022-06-20 13:15:25.894911
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    argv = ['playbook.yml', 'playbook2.yml']
    cli = PlaybookCLI(args=argv)
    parser = cli.init_parser()
    assert parser is not None


# Generated at 2022-06-20 13:15:26.499800
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:15:37.737155
# Unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-20 13:15:51.246631
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Mock class used to test method run
    class MockAnsibleError(AnsibleError):
        def __init__(self, message):
            self.message = message

    # Mock class used to test method run
    class MockPlaybookCLI(PlaybookCLI):
        def _play_prereqs(self):
            return

        def ask_passwords(self):
            return ("sshpass", "becomepass")

    # Create a PlaybookCLI object
    pb_cli = MockPlaybookCLI()

    # Mock variables
    mock_playbook = "playbook.yml"

    # Call run() method
    assert pb_cli.run() == 0

    # Create a PlaybookCLI object
    pb_cli = MockPlaybookCLI()

    # Mock variables

# Generated at 2022-06-20 13:16:01.018867
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class MockPlaybookCLI(PlaybookCLI):
        def __init__(self):
            self.option_parsed = None
            self.options = None
            self.parser = None

        def init_parser(self):
            self.parser = MockOptParser()

        def validate_conflicts(self, options, runas_opts=True, fork_opts=True):
            self.options = options

    pb_cli = MockPlaybookCLI()
    pb_cli.post_process_args(pb_cli.parser.option_parsed)

    assert pb_cli.options.verbosity == 0
    assert pb_cli.options.connection == 'smart'
    assert pb_cli.options.remote_user == 'ansible_user'
    assert pb_cli.options.ask_

# Generated at 2022-06-20 13:16:10.908667
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.module_utils.six.moves import builtins
    from ansible import context

    class FakeModule(object):
        def __init__(self, name):
            self.name = name
            self.tags = []
            self.implicit = False

    class FakeBlock(object):
        def __init__(self, blocks):
            self.block = blocks

        def has_tasks(self):
            return len(self.block) > 0

        def filter_tagged_tasks(self, vars):
            return self

    class FakePlay(object):
        def __init__(self, play_hosts=None, play_name=None, play_tasks=None, play_tags=None, included_path=None):
            self.hosts = play_hosts
            self.name = play_

# Generated at 2022-06-20 13:16:20.492488
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    loader = object()
    inventory = object()
    variable_manager = object()
    pbex = object()
    args = dict(
        flush_cache=False,
        inventory=inventory,
        listtags=False,
        listtasks=False,
        subset='all',
        verbosity=0,
        password=False,
    )
    cli = PlaybookCLI([], args)
    cli._play_prereqs = lambda: (loader, inventory, variable_manager)
    cli.ask_passwords = lambda: (None, None)
    cli.run()

# Generated at 2022-06-20 13:16:30.137501
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    Unit test for AnsibleCLI.run()

    This needs to be a unit test for the CLI class, not a functional test for
    the playbook CLI.  If you want to test the playbook CLI, you want to test
    the playbook() function in lib/ansible/__init__.py, not this class.

    That said...

    We mock out two pieces for this test:
      1) CLI.run()
      2) Option parsing via OptionParser

    The first is necessary because we want to test run() without spawning a
    subprocess.  The second is necessary because we want to verify the CLI
    options structured correctly and passed to PlaybookCLI.run() correctly.
    """
    import ansible.cli
    import ansible.cli.playbook

    # Patch the tested class so that we can do unit testing on it

# Generated at 2022-06-20 13:17:26.858427
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    cli = PlaybookCLI(args=['--list-tasks', 'playbook.yml'])
    assert cli.run() == 0

# Generated at 2022-06-20 13:17:38.005476
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    args = ['ansible-playbook', 'generate-inventory.yml', 'generate-path']
    cli = PlaybookCLI(args)
    assert cli.parser._prog == 'ansible-playbook'
    assert cli.parser._usage == "%prog [options] playbook.yml [playbook2 ...]"
    assert cli.parser._description == "Runs Ansible playbooks, executing the defined tasks on the targeted hosts."

    parser = cli.parser

# Generated at 2022-06-20 13:17:38.885501
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    PlaybookCLI().init_parser()

# Generated at 2022-06-20 13:17:51.252735
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # create an argument with default value
    key = '--list-hosts'
    default_value = False
    option = opt_help.add_option(key=key, default=default_value)

    # create a mock of class PlaybookCLI
    # create a mock of class PlaybookCLI
    class MockPlaybookCLI(PlaybookCLI):
        def __init__(self, parser):
            self.parser = parser

    # create a instance of class PlaybookCLI
    playbook_cli = MockPlaybookCLI(parser=None)

    # create a mock of class CLI
    class MockCLI(CLI):
        def __init__(self):
            self.parser = None


# Generated at 2022-06-20 13:17:53.281354
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        PlaybookCLI().run()
    except:
        pass

# Generated at 2022-06-20 13:17:54.799389
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli=PlaybookCLI()
    playbook_cli.run()

# Generated at 2022-06-20 13:18:06.816778
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #preparing test context
    c = context.CLIARGS
    setattr(c, 'verbosity', 0)
    setattr(c, 'syntax', False)
    setattr(c, 'listtags', False)
    setattr(c, 'listtasks', False)
    setattr(c, 'step', False)
    setattr(c, 'start_at_task', False)
    setattr(c, 'flush_cache', False)
    setattr(c, 'args', ['ansible/test/utils/test_module_utils_basic.py'])

    PlaybookCLI.run()

# Generated at 2022-06-20 13:18:08.972038
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    c = PlaybookCLI()
    c.parse()
    b = c._play_prereqs()
    assert(b != None)

# Generated at 2022-06-20 13:18:18.272037
# Unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-20 13:18:28.996380
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    class MyPlaybookCLI(PlaybookCLI):
        def get_version(self):
            return 2.5

    cli = MyPlaybookCLI()
    cli.init_parser()

    assert cli.parser is not None
    # assert args is not None
    assert cli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'

    # verify opt_help.add_runas_options(self.parser)

# Generated at 2022-06-20 13:20:50.557316
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    module = PlaybookCLI()
    assert module.parser is not None


# Generated at 2022-06-20 13:20:57.016496
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class test_Playbook():
        def __init__(self):
            self.hosts = ["hostname"]
            self.name = "testname"
    class test_CLIARGS():
        def __init__(self, args):
            self.args = args
    class test_PlaybookExecutor():
        def __init__(self):
            self.playbooks = ["test"]
            self.inventory = "test"
            self.variable_manager = "test"
            self.loader = "test"
            self.passwords = "test"
    class test_Display():
        def __init__(self):
            pass

        def display(self, message, stderr=False, screen_only=False, log_only=False, runner_on=False):
            messages.append(message)


# Generated at 2022-06-20 13:21:00.581102
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pl = PlaybookCLI()
    assert isinstance(pl.parser, object)

# Generated at 2022-06-20 13:21:05.835368
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    '''
    :return:
    '''

    # Define a simple argparse.Namespace() object.
    #
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # Note: If you change the number of arguments, you have to change the assertions.

# Generated at 2022-06-20 13:21:06.353373
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:21:10.028652
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    fake_class = PlaybookCLI()

    context.CLIARGS = {}
    fake_class.init_parser()
    assert fake_class.parser


# Generated at 2022-06-20 13:21:18.846986
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.cli.arguments import OptionParser
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display
    opt = OptionParser()
    add_all_plugin_dirs()
    display = Display()
    cli = PlaybookCLI(opt)
    assert cli.post_process_args({"verbosity": 0, "listtags": True})



# Generated at 2022-06-20 13:21:25.356537
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI([])
    options, args = cli.parser.parse_args(['--list-hosts', '--step'])

    cli.post_process_args(options)
    assert context.CLIARGS['subset'] == 'all'
    assert context.CLIARGS['listhosts'] is True
    assert context.CLIARGS['step'] is True
    assert context.CLIARGS['listtags'] is False
    assert context.CLIARGS['listtasks'] is False
    assert context.CLIARGS['syntax'] is False

# Generated at 2022-06-20 13:21:28.098182
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    PlaybookCLI()

# Generated at 2022-06-20 13:21:30.447639
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    main = PlaybookCLI(args=['-h'])
    assert isinstance(main, PlaybookCLI)