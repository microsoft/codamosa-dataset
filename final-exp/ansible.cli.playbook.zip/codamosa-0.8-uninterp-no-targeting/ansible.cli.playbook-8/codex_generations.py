

# Generated at 2022-06-20 13:12:43.554202
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb = PlaybookCLI()
    pb.run()

# Generated at 2022-06-20 13:12:49.994993
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.cli.playbook import PlaybookCLI

    # Patch CLI.base_parser
    original_base_parser = PlaybookCLI.base_parser
    PlaybookCLI.base_parser = lambda s: s

    # Test with no args
    context.CLIARGS = {}
    PlaybookCLI().post_process_args({})
    assert context.CLIARGS['verbosity'] == 0

    # Test with '-v'
    context.CLIARGS = {}
    PlaybookCLI().post_process_args({'verbosity': 1})
    assert context.CLIARGS['verbosity'] == 1

    # Test with '-vvv'
    context.CLIARGS = {}
    PlaybookCLI().post_process_args({'verbosity': 3})
    assert context.CLI

# Generated at 2022-06-20 13:13:05.735541
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    from optparse import OptionParser
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    parser = OptionParser()

    # create parser for CLI options
    p = PlaybookCLI(parser)
    p.init_parser()

    # initialize option parser
    options, args = p.parser.parse_args([])

    context.CLIARGS = options

    # make sure the vault password is required
    with pytest.raises(AnsibleError):
        p.post_process_args(options)

    # make sure the vault password is required
    options.ask_vault_pass = True
    with pytest.raises(AnsibleError) as excinfo:
        p.post_process_args(options)

# Generated at 2022-06-20 13:13:13.848505
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pbcli = PlaybookCLI()
    pbcli.init_parser()
    assert isinstance(pbcli.parser, CLI.base_parser)
    assert pbcli.parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'
    assert pbcli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert pbcli.parser._positionals.title == 'Playbook(s)'
    assert pbcli.parser._positionals.metavar == 'playbook'
    assert pbcli.parser._positionals.nargs == '+'

# Generated at 2022-06-20 13:13:21.279706
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Test with check mode
    cli = PlaybookCLI()
    opts = cli.parser.parse_args(['--check', '{}'])
    cli.post_process_args(opts)
    assert cli.validate_conflicts(opts, runas_opts=True, fork_opts=True) is None

    # Test with not check mode, fork and remote user
    cli = PlaybookCLI()
    opts = cli.parser.parse_args(['-f', '7', '--remote-user', 'root', '{}'])
    cli.post_process_args(opts)
    assert cli.validate_conflicts(opts, runas_opts=True, fork_opts=True) is None

    # Test with not check mode, fork

# Generated at 2022-06-20 13:13:32.725622
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.inventory.host_list import InventoryModule as inventory_host_list
    options = opt_help.add_runas_options(parser=None)
    options = opt_help.add_vault_options(parser=options)
    options = opt_help.add_check_options(parser=options)
    options = opt_help.add_fork_options(parser=options)
    options = opt_help.add_connect_options(parser=options)
    options = opt_help.add_meta_options(parser=options)
    options = opt_help.add_subset_options(parser=options)
    options = opt_help.add_inventory_options(parser=options)
    options = opt_help.add_runtask

# Generated at 2022-06-20 13:13:45.271387
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import PluginLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    cli = PlaybookCLI(
        None,
        variable_manager=variable_manager,
        loader=loader,
        inventory=inventory,
        subsets=dict(),
        stdin_path='/dev/null',
        runas_passwords=dict(),
        passwords=dict(),
    )

# Generated at 2022-06-20 13:13:46.318382
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI([])

# Generated at 2022-06-20 13:13:48.915866
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    assert cli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'

# Generated at 2022-06-20 13:14:00.984383
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    ''' Unit test for method post_process_args of class PlaybookCLI '''
    import argparse
    argv = ['--list-tasks', '--list-tags', '--step', '--start-at-task', 't1', 't2']
    opt = argparse.Namespace()
    opt.listtasks = False
    opt.listtags = False
    opt.step = False
    opt.start_at_task = None
    opt.args = []
    assert PlaybookCLI.post_process_args(PlaybookCLI(), opt).__dict__ == \
        vars(argparse.Namespace(listtasks=True, listtags=True, step=True, start_at_task='t1', args=['t2']))

# Generated at 2022-06-20 13:14:16.317969
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(args=['--check'])
    assert cli.post_process_args(cli.parser.parse_args(['--check'])).check
    assert not cli.post_process_args(cli.parser.parse_args(['--check', '--no-check'])).check
    assert cli.post_process_args(cli.parser.parse_args(['--no-check'])).check


# Generated at 2022-06-20 13:14:17.702871
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI()
    cli.post_process_args()


# Generated at 2022-06-20 13:14:27.099382
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #
    # Mock out parts of the PlaybookCLI object that don't need to be tested.
    #
    class MockPlaybookCLI(PlaybookCLI):
        def init_parser(self):
            return
        def post_process_args(self, options):
            return
        def run(self):
            return
        def ask_passwords(self):
            return 'sshpass', 'becomepass'
        def _play_prereqs(self):
            return None, None, None

    #
    # Mock out some parts of the CLI object that don't need to be tested.
    #
    class MockCLI(CLI):
        def init_parser(self):
            self.parser = None
            return
        def post_process_args(self, options):
            return

# Generated at 2022-06-20 13:14:38.235275
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Test with
    #   - non-existing playbook
    #   - no playbook specified

    p = PlaybookCLI()

    with pytest.raises(AnsibleError) as excinfo:
        p.run()
    assert "the playbook: None could not be found" in excinfo.value
    assert "the playbook: None does not appear to be a file" in excinfo.value

    argv = ['ansible-playbook', 'playbook.yml']
    cliargs = p.parse(args=argv[1:])
    context._init_global_context(cliargs)

    with pytest.raises(AnsibleError) as excinfo:
        p.run()
    assert "the playbook: playbook.yml could not be found" in excinfo.value

# Generated at 2022-06-20 13:14:43.963964
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = PlaybookCLI().init_parser()
    args = [
        '--syntax-check',
        '-i', 'inventory_file',
        '--list-hosts',
        '-l', '192.168.56.10',
        '--list-tasks',
        '--list-tags',
        '--step',
        '--start-at-task', 'task',
        'ansible/test/integration/targets/test_module_args.yml',
    ]
    options = parser.parse_args(args)
    assert options.syntax or options.check or options.listhosts or options.listtasks or options.listtags or options.step
    assert not options.start_at_task
    assert options.inventory is not None

# Generated at 2022-06-20 13:14:45.516589
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI()
    cli.parse()

# Generated at 2022-06-20 13:14:49.325748
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # test default values of attributes
    p = PlaybookCLI()
    assert p.parser is None
    assert p.options is None
    assert p.args is None

# Generated at 2022-06-20 13:14:52.068308
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    """
    Unit test for constructor of class PlaybookCLI

    """

    playbook_cli = PlaybookCLI()
    assert playbook_cli

# Generated at 2022-06-20 13:14:53.190214
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO
    pass


# Generated at 2022-06-20 13:14:54.861098
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()
    cli.run()

# Generated at 2022-06-20 13:15:15.034866
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_host = "ansible-test-host"
    test_host_vars = {u'ansible_connection': u'test'}
    test_sshpass = "test_sshpass"
    test_becomepass = "test_becomepass"
    test_verbosity = False

    test_passwords = {u'conn_pass': test_sshpass, u'become_pass': test_becomepass}
    test_args = ['test_playbook']

    test_host_list = [test_host]

    test_playbook = 'test_playbook'


# Generated at 2022-06-20 13:15:24.818656
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # Check parameters
    pb = CLI.get_cli_class('playbook')(params=['ansible-playbook', '--help'])
    assert len(pb.parser._option_string_actions) == 14
    assert '-k' in pb.parser._option_string_actions
    assert '--ask-pass' in pb.parser._option_string_actions
    assert '--list-hosts' in pb.parser._option_string_actions
    assert '--list-tasks' in pb.parser._option_string_actions

# Generated at 2022-06-20 13:15:31.593923
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Create an instance of PlaybookCLI class
    cli = PlaybookCLI()
    # Unit test for the method __init__ of class PlaybookCLI by passing the
    # instance of PlaybookCLI class as an argument
    test_parser = cli.init_parser()

    # Verifying the correct usage of the method
    # by checking the return type of the method
    assert isinstance(test_parser, CLI)


# Generated at 2022-06-20 13:15:35.019015
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pass

# Generated at 2022-06-20 13:15:37.550162
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    class TestPlaybookCLI(PlaybookCLI):
        def run(self):
            return self

    p = TestPlaybookCLI()

# Generated at 2022-06-20 13:15:40.872399
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    p_PlaybookCLI = PlaybookCLI()
    assert p_PlaybookCLI.init_parser() is not None



# Generated at 2022-06-20 13:15:44.258340
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    mock_parser = "mock parser"
    cli = PlaybookCLI(parser=mock_parser)
    assert cli.parser == mock_parser

# Generated at 2022-06-20 13:15:54.643073
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Make sure we do not make any file descriptor calls on windows, due to the
    # extremely slow fd leak on Windows
    import ansible.release
    if ansible.release.platform == "windows":
        return

    # Testing CLI args
    test_args = ["ansible-playbook", "test.yml"]

    # Testing CLI options
    test_args.append("--connection=ssh")
    test_args.append("--module-path=/usr/share/ansible/plugins/modules")
    test_args.append("--private-key=/etc/ansible/ssh_key")
    test_args.append("--forks=5")
    test_args.append("--timeout=10")

    # Run post_process_args
    cli = PlaybookCLI()
    cli.parser = opt_help.create

# Generated at 2022-06-20 13:15:56.366715
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    """
    This is a placeholder for a pytest unit test for PlaybookCLI.
    """
    pass

# Generated at 2022-06-20 13:15:57.335885
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass # TODO


# Generated at 2022-06-20 13:16:24.693827
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    PlaybookCLI()

# Generated at 2022-06-20 13:16:39.671457
# Unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-20 13:16:41.033883
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    playbook_cli = playbookCLI()

    assert playbook_cli.parser is not None

# Generated at 2022-06-20 13:16:49.169110
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    import sys
    import ansible

    PlaybookCLI.setup_vault_secrets_cache()


# Generated at 2022-06-20 13:16:52.232114
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Note: Currently, this unit test only tests the import of the method run.
    from ansible.cli.playbook import PlaybookCLI
    assert PlaybookCLI.run is not None

# Generated at 2022-06-20 13:16:55.224195
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import pytest
    cli = PlaybookCLI(args=['playbook.yml'])
    with pytest.raises(AnsibleError):
        cli.run()

# Generated at 2022-06-20 13:17:01.304967
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Test with no CLI args
    args = ['']
    cli = PlaybookCLI(args)
    parser = cli.init_parser()
    assert parser == cli.parser
    assert parser.prog == 'ansible-playbook'


if __name__ == '__main__':
    pb = PlaybookCLI([])
    pb.parse()
    pb.run()

# Generated at 2022-06-20 13:17:04.852109
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # Create an instance of PlaybookCLI to test its constructor
    ansible_playbook = PlaybookCLI(['/test/test_playbook.yaml'])

    assert ansible_playbook.parser._prog == 'ansible-playbook'
    assert ansible_playbook.parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'
    assert ansible_playbook.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'


# Generated at 2022-06-20 13:17:14.327954
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # what we get
    raw_args = ['--inventory', 'inventory', 'playbook.yml', '--limit', 'foo']
    # what we want
    expected_options = {'inventory': 'inventory', 'subset': 'foo', 'args': ['playbook.yml']}

    # test the code
    pbcli = PlaybookCLI()
    pbcli.init_parser()
    options = pbcli.post_process_args(raw_args)

    assert options.args == expected_options['args']
    assert options.inventory == expected_options['inventory']
    assert options.subset == expected_options['subset']

# Generated at 2022-06-20 13:17:23.914250
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    """
    This is a demonstration of how to unit test a constructor of a class
    Use cases:
      The class has no __init__ method
      The class has an __init__ method
    """
    # Reference: https://docs.python.org/2/library/unittest.html#unittest.TestCase

    # This is an example of how to create a unit test for a class that does not have an __init__ method
    from ansible.cli.playbook import PlaybookCLI
    p = PlaybookCLI([])
    assert p

    # This is an example of how to create a unit test for a class that has an __init__ method
    from ansible.cli.adhoc import AdHocCLI
    a = AdHocCLI([])
    assert a

# Generated at 2022-06-20 13:18:20.965462
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    PlaybookCLI().init_parser()

# Generated at 2022-06-20 13:18:21.945193
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass
# Testing  PlaybookCLI - end

# Generated at 2022-06-20 13:18:31.525339
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from collections import namedtuple
    mock_options = namedtuple('mock_options', ['listtags', 'listtasks', 'syntax', 'subset', 'module_path', 'flush_cache', 'listhosts', 'connection', 'remote_user', 'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args', 'scp_extra_args', 'become', 'become_method', 'become_user', 'verbosity', 'check', 'start_at_task', 'step', 'diff'])

    options = mock_options(False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, None, '0', False, False, False, False)
    PlaybookCLI().post_

# Generated at 2022-06-20 13:18:39.203269
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    """Test if it init the parser object with playbook options."""
    parser = CLI.base_parser(
        usage="%prog [options] playbook.yml [playbook2 ...]",
        desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts.")
    PlaybookCLI.init_parser(None, parser)
    for option in ['list-tasks', 'list-tags', 'step', 'start-at-task']:
        parser.get_option(option)



# Generated at 2022-06-20 13:18:52.059570
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    import mock
    import tempfile
    import os
    args_file_fd, args_file = tempfile.mkstemp()
    with mock.patch('ansible.cli.CLI._get_args_file', return_value=args_file):
        pbcli = PlaybookCLI(args=[])
        with mock.patch.object(PlaybookCLI, '_parse_cli_opts', return_value=(pbcli.parser, {})):
            with mock.patch.object(pbcli, 'post_process_args', return_value='custom_args'):
                with mock.patch.object(pbcli, 'get_bin_path', return_value=''):
                    result = pbcli.parse()
                    assert result == 'custom_args'

# Generated at 2022-06-20 13:18:54.893988
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    ansible_module = PlaybookCLI()
    # Just testing nothing fails at the moment.
    playbook_results = ansible_module.run()
    assert(playbook_results == 0)

# Generated at 2022-06-20 13:19:04.677090
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import pytest
    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # create a test playbook (to be located in the same directory as the test)
    playbook_filename = 'test_PlaybookCLI_run.yml'
    test_playbook = """
    - hosts: test
      tasks:
        - name: succeed
          fail:
            msg: 'I was supposed to fail'
    """
    with open(playbook_filename, 'w') as test_playbook_file:
        test_playbook_file.write(test_playbook)

   

# Generated at 2022-06-20 13:19:09.000185
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    PlaybookCLI(cmd='ansible-playbook')

if __name__ == '__main__':

    cli = PlaybookCLI(cmd='ansible-playbook')
    cli.parse()
    cli.run()

# Generated at 2022-06-20 13:19:16.617019
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class Opts(object):
        pass
    opts = Opts()
    opts.ask_pass = False
    opts.verbosity = 1
    playbook_cli = PlaybookCLI(args=[])
    # general assertion is that post_process_args does not raise
    # ValueError when it is supposed to
    try:
        playbook_cli.post_process_args(opts)
    except ValueError:
        raise AssertionError('ValueError exception raised')

# Generated at 2022-06-20 13:19:25.488010
# Unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-20 13:20:45.827154
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    """
    Test case for constructor of class PlaybookCLI
    :return: None
    """
    # Test for valid constructor of class PlaybookCLI without any arguments
    PPlaybook_cli = PlaybookCLI()
    if not isinstance(PPlaybook_cli, PlaybookCLI):
        raise AssertionError("Not instance of class PlaybookCLI")

# Generated at 2022-06-20 13:20:46.517418
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:20:54.962387
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.executor.playbook_executor import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    cli = PlaybookCLI([], loader=loader)

    args = [
        '--connection', 'local', '--inventory', '/dev/null', '--module-path',
        'fake_dir', '--list-hosts', '--diff', '--syntax-check', '--ask-vault-pass', '--vault-password-file', '/dev/null',
        '--forks', '10', 'fake_playbook.yml'
    ]
    options = cli.parse(args)
    # Without --ask-vault-pass
    assert not options.ask_vault_pass
    # With --ask-vault

# Generated at 2022-06-20 13:21:00.557890
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    playbook_cli = PlaybookCLI()
    playbook_cli.init_parser()

    # Test that passing in --step with --list-tags raises an error
    # as these two options are mutually exclusive
    options = playbook_cli.parser.parse_args(['--step', '--list-tags'])
    try:
        playbook_cli.post_process_args(options)
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-20 13:21:09.671329
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Use the following arguments:
    # --check --diff -e var=val
    # --extra-vars var=val --flush-cache --force-handlers --list-hosts
    # --list-tags --list-tasks --start-at-task foo

    class Options:
        check = True
        diff = True
        extra_vars = {'var': 'val'}
        flush_cache = True
        force_handlers = True
        listhosts = True
        listtags = True
        listtasks = True
        start_at_task = 'foo'
        verbosity = 0

    options = Options()
    playbook_cli = PlaybookCLI(args=['playbook.yml'])
    playbook_cli.options = options
    playbook_cli.post_process_args(options)

    assert context

# Generated at 2022-06-20 13:21:22.615128
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    mycli = PlaybookCLI(['test'])
    mycli.init_parser()
    assert mycli.parser.ignore_unknown_hosts is False
    assert mycli.parser.timeout == C.DEFAULT_TIMEOUT
    assert mycli.parser.listhosts == False
    assert mycli.parser.listtasks == False
    assert mycli.parser.listtags == False
    assert mycli.parser.step == False
    assert mycli.parser.start_at_task == None
    assert mycli.parser.connection == C.DEFAULT_TRANSPORT
    assert mycli.parser.remote_user == C.DEFAULT_REMOTE_USER
    assert mycli.parser.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE

# Generated at 2022-06-20 13:21:27.174972
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # See https://docs.pytest.org/en/latest/fixture.html#fixture-parametrize
    #test_cases = [
    #    {'playbook': 'playbook.yml', },
    #    {'playbook': 'playbook2.yml', },
    #]
    #for test_case in test_cases:
    #    yield test_PlaybookCLI_instance, test_case

    # This is a typical usage of the CLI
    # It also demonstrates how to use it from outside the command line
    cli = PlaybookCLI(['playbook.yml'])

    # An empty argument list throws an exception
    #cli = PlaybookCLI([])

    # Find the parser
    parser = cli.get_optparser()

    # Provide the values of the arguments
    #

# Generated at 2022-06-20 13:21:30.643606
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI([])
    # Test with --check
    options = cli.parser.parse_args(['--check'])[0]
    cli.post_process_args(options)
    assert options.check
    # Test with --syntax
    options = cli.parser.parse_args(['--syntax'])[0]
    cli.post_process_args(options)
    assert options.syntax
    # Test without --check and without --syntax
    options = cli.parser.parse_args([])[0]
    cli.post_process_args(options)
    assert options.check is True
    assert options.syntax is False

# Generated at 2022-06-20 13:21:39.206674
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # 1: Test if all playbooks are accessible

# Generated at 2022-06-20 13:21:48.299974
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class MockCLI:
        def __init__(self):
            self.last_called = None
            self.args = None
            self.options = None
            self.display = display

        def __call__(self, *args, **kwargs):
            self.last_called = '__call__'
            self.args = args
            self.options = kwargs
            return True

        def get_opt(arg):
            self.last_called = 'get_opt'
            self.args = arg
            return True

    class MockProvider:
        def get_opt(self, arg, dest=None, inherit=True):
            self.last_called = 'get_opt'
            self.args = arg
            return True

    class MockLoader:
        def __init__(self):
            self.path_was_