

# Generated at 2022-06-20 13:12:55.943376
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-20 13:12:56.337736
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:12:58.133960
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    assert(isinstance(PlaybookCLI(), PlaybookCLI))

# Generated at 2022-06-20 13:13:00.803868
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI(args=["test_inventory"])
    assert cli.parser._prog == "ansible-playbook"

# Generated at 2022-06-20 13:13:03.298813
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    args = ['test.yml', 'test2.yml']
    obj = PlaybookCLI(args)  # No error

# Generated at 2022-06-20 13:13:13.022376
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(None)
    parser = cli.init_parser()
    assert parser._actions[5].dest == 'listtasks'
    assert parser._actions[5].help == "list all tasks that would be executed"

    assert parser._actions[6].dest == 'listtags'
    assert parser._actions[6].help == "list all available tags"

    assert parser._actions[7].dest == 'step'
    assert parser._actions[7].help == "one-step-at-a-time: confirm each task before running"

    assert parser._actions[8].dest == 'start_at_task'
    assert parser._actions[8].help == "start the playbook at the task matching this name"

# Generated at 2022-06-20 13:13:20.629902
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # create a dummy class to assert args and call the tested method
    class DummyPlaybookCLI(PlaybookCLI):
        def __init__(self):
            pass

        def run(self):
            pass

    # create dummy args

# Generated at 2022-06-20 13:13:26.643004
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # FIXME: fix tests
    return
    p = PlaybookCLI(None, None, None)
    p.init_parser()
    options, args = p.parser.parse_args(['playbook1', 'playbook2', 'playbook3'])
    assert options.check and options.runsubset and options.listhosts and options.listtags and options.listtasks

# Generated at 2022-06-20 13:13:35.273837
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    import argparse
    from ansible.cli.arguments import option_helpers
    parser = argparse.ArgumentParser()
    option_helpers.add_runtask_options(parser)
    option_helpers.add_vault_options(parser)
    option_helpers.add_fork_options(parser)
    option_helpers.add_module_options(parser)
    option_helpers.add_runas_options(parser)
    option_helpers.add_subset_options(parser)


# Generated at 2022-06-20 13:13:37.705526
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cls = PlaybookCLI()
    assert cls.run() == 0


# Generated at 2022-06-20 13:14:00.549463
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # verify that verbosity is set correctly
    cli_parser = CLI.base_parser(constants=C)
    playbook_cli = PlaybookCLI(parser=cli_parser)
    args = playbook_cli.parser.parse_args([])
    playbook_cli.post_process_args(args)
    assert display.verbosity == 0
    args = playbook_cli.parser.parse_args(["-v"])
    playbook_cli.post_process_args(args)
    assert display.verbosity == 1
    args = playbook_cli.parser.parse_args(["-vv"])
    playbook_cli.post_process_args(args)
    assert display.verbosity == 2
    args = playbook_cli.parser.parse_args(["-vvv"])

# Generated at 2022-06-20 13:14:15.080262
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    playbook_cli = PlaybookCLI()
    # playbook_cli.post_process_args(
    #     {
    #         'connection': '',
    #         'forks': '',
    #         'become': '',
    #         'become_method': '',
    #         'become_user': '',
    #         'check': '',
    #         'diff': '',
    #         'listhosts': '',
    #         'listtags': '',
    #         'listtasks': '',
    #         'syntax': '',
    #         'vault_password_files': '',
    #         'vault_ids': '',
    #         'force_handlers': '',
    #         'flush_cache': '',
    #         'step': '',

# Generated at 2022-06-20 13:14:29.660091
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # create parser for CLI options
    PlaybookCLI.parser = opt_help.create_parser('test_ansible_playbook_test', 'playbook',)

    # ansible playbook specific opts
    PlaybookCLI.parser.add_argument('--list-tasks', dest='listtasks', action='store_true',
                                 help="list all tasks that would be executed")

    # add options to parser
    PlaybookCLI.init_parser()

    # test each option

# Generated at 2022-06-20 13:14:31.386771
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    p = PlaybookCLI(['some_file.yml'])
    assert p

# Generated at 2022-06-20 13:14:40.918657
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    """Test PlaybookCLI.post_process_args."""
    import io
    from ansible.cli.playbook import PlaybookCLI
    from units.compat.mock import patch, mock_open
    from ansible.errors import AnsibleError

    mock_parser = 'ansible.cli.playbook.PlaybookCLI.init_parser'

    @patch(mock_parser)
    def test_post_process_args(mock_parser):
        """Test post_process_args.

        utility method which executes playbook CLI common code.

        :param mock_parser: mocked parser
        :returns: none
        """

# Generated at 2022-06-20 13:14:54.908816
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Note: Instead of trying to compare the entire result, we can compare the
    # expected and actual tasks. The implementation of the generator
    # PlaybookExecutor._run_play() is complex, and relies on many other
    # modules and plugins. So instead of writing a test for it, we just
    # compare the tasks it runs with what we expect it to run.

    # Dummy class to satisfy instantiation of PlaybookCLI class.
    class DummyPluginLoader:
        def get(self, *args, **kwargs):
            pass

        def all(self):
            pass

    # Dummy class to satisfy instantiation of CLI class
    class DummyCLI(CLI):
        def __init__(self):
            add_all_plugin_dirs('/path/to/plugins')
            self.options = {}
            opt_help

# Generated at 2022-06-20 13:15:10.367553
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    def read_command_line_options(argslist):
        cli = PlaybookCLI(args=argslist)
        # option_parser is a private attribute and it's not recommended to use it in this way
        cli.parser = cli.option_parser
        options = cli.parse()
        options = cli.post_process_args(options)
        return options

    fake_vault_password_file = "/fake/path/to/file"
    options = read_command_line_options(["-v", "--vault-password-file=%s" % fake_vault_password_file])
    assert options.verbose == 2
    assert options.vault_password_file == fake_vault_password_file


# Generated at 2022-06-20 13:15:11.442967
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI([])
    assert cli


# Generated at 2022-06-20 13:15:27.066977
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    test_cli = PlaybookCLI()
    test_cli.parser = CLI.base_parser(
        usage="%prog [options] playbook.yml [playbook2 ...]",
        desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts.")
    test_cli.options = test_cli.parser.parse_args([])[0]
    test_cli.post_process_args(test_cli.options)


# Generated at 2022-06-20 13:15:27.723768
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    PlaybookCLI()

# Generated at 2022-06-20 13:15:56.035499
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class TestPlaybookCLI(PlaybookCLI):
        def __init__(self):
            pass
    TestPlaybookCLI.parser = TestPlaybookCLI.create_parser()
    options = TestPlaybookCLI.parser.parse_args(['ansible-playbook', '--check', '--diff', '--syntax-check', '--list-hosts', '--list-tasks', '--list-tags', '--step', '--start-at-task="copy"', 'playbook.yml'])
    TestPlaybookCLI.post_process_args(options)

# Generated at 2022-06-20 13:16:01.299007
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    context.CLIARGS = {'listhosts': False, 'listtags': False, 'listtasks': False, 'syntax': False, 'tags': [], 'skip_tags': [], 'start_at_task': None, 'step': False, 'diff': False}
    pl = PlaybookCLI()
    pl.run()

# Generated at 2022-06-20 13:16:02.208496
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    p = PlaybookCLI()
    print(p)

# Generated at 2022-06-20 13:16:11.844032
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    # GIVEN: Create a mock object.
    cli = PlaybookCLI()

    # WHEN: execute function parse and do_parsing
    temp_args = ['playbook.yml', 'playbook2.yml']
    context.CLIARGS = cli.parse(args=temp_args)
    cli.do_parsing()

    # THEN: check the status of execution
    assert context.CLIARGS is not None
    assert context.CLIARGS['listhosts'] is False
    assert context.CLIARGS['listtasks'] is False
    assert context.CLIARGS['listtags'] is False
    assert context.CLIARGS['step'] is False
    assert context.CLIARGS['start_at_task'] is None

# Generated at 2022-06-20 13:16:13.407656
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    p = PlaybookCLI('/usr/bin/ansible-playbook')

# Generated at 2022-06-20 13:16:25.496030
# Unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-20 13:16:30.309467
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb_cli = PlaybookCLI()
    pb_cli.parse()
    print(pb_cli.args)

# Generated at 2022-06-20 13:16:41.455907
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    pb = PlaybookCLI()
    pb.options = opt_help.command_base_parser(constants=C, runas_opts=True,
                                              as_root_opts=True, check_opts=True,
                                              verbosity_opts=True, fork_opts=True,
                                              module_opts=True, subset_opts=True, runtask_opts=True,
                                              vault_opts=True)
    pb.parse()
    context.CLIARGS['check'] = True
    # We test the method with different values of verbosity passed
    # through the CLI options
    # verbosity=True
    context.CLIARGS['verbosity'] = 1
    options = pb.post_process_args(pb.options)

# Generated at 2022-06-20 13:16:49.402447
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    context._init_global_context(None)

# Generated at 2022-06-20 13:16:55.224319
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI()
    cli.parser = cli.create_parser()
    cli.options = cli.parser.parse_args(['-i', 'localhost,'])
    cli.post_process_args(cli.options)


if __name__ == '__main__':
    cli = PlaybookCLI()
    cli.main()

# Generated at 2022-06-20 13:17:46.436653
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    pass

# Generated at 2022-06-20 13:17:57.918409
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Set object for PlaybookCLI class
    test_playbookCLI_obj = PlaybookCLI()

    # Settings data
    test_playbookCLI_obj.parser = AnsibleCLI()
    test_playbookCLI_obj.parser.options = opt_help.create_base_parser()

    # Set values for base class
    test_playbookCLI_obj.options = test_playbookCLI_obj.parser.options

    # Set values for playbooks
    test_playbookCLI_obj.args = ['playbook1.yml', 'playbook2.yml']
    test_playbookCLI_obj.parser.args = ['playbook1.yml', 'playbook2.yml']

# Generated at 2022-06-20 13:18:01.745094
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(['playbook_cli_test'])
    cli.init_parser()
    assert cli is not None

# Generated at 2022-06-20 13:18:04.548077
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    assert CLI.parser is None
    assert PlaybookCLI.parser is None
    PlaybookCLI()
    assert PlaybookCLI.parser is not None


# Generated at 2022-06-20 13:18:09.556373
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    # Create instance of class PlaybookCLI
    playbook_cli = PlaybookCLI()

    #Test init_parser
    assert playbook_cli.init_parser()

    #Test post_process_args
    assert playbook_cli.post_process_args(playbook_cli.options)

    #Test run
    assert playbook_cli.run()

# Generated at 2022-06-20 13:18:17.275576
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Setup the context for testing
    context._init_global_context(['ansible-playbook', '--list-hosts'])

    # Setup the PlaybookCLI class for testing
    options = CLI.base_parser(PlaybookCLI, 'PlaybookCLI').parse_args(
        ['--list-hosts', '--list-tasks', '--list-tags', '--step', '--start-at-task', 'test_playbook.yml']
    )
    pbc = PlaybookCLI(None, options)

    # Run the test
    pbc.post_process_args(options)

# Generated at 2022-06-20 13:18:28.193916
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    playbook = PlaybookCLI(['ansible', 'playbook'])
    options = playbook.parse()

    # Verifies all options are as expected
    assert options.verbosity == 4
    assert options.connection == 'ssh'
    assert options.timeout == 10
    assert options.remote_user is None
    assert options.ask_pass is False
    assert options.private_key is None
    assert options.ssh_common_args is None
    assert options.ssh_extra_args is None
    assert options.sftp_extra_args is None
    assert options.scp_extra_args is None
    assert options.become is False
    assert options.become_method == 'sudo'
    assert options.become_user is None
    assert options.become_ask_pass is False
    assert options.become_exec_

# Generated at 2022-06-20 13:18:28.758272
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:18:36.009889
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    CLI.set_defaults()

    parser = PlaybookCLI.create_parser()
    args = parser.parse_args([os.path.join(os.path.dirname(__file__), 'fixtures/playbook.yml')])
    pb = PlaybookCLI(args)

    pb.run()

# Generated at 2022-06-20 13:18:43.468134
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    test_cli = PlaybookCLI()
    test_cli.init_parser()
    assert test_cli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert test_cli.parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'
    with open('ansible/cli-playbook-init-parser') as f:
        assert test_cli.parser.format_help() == f.read()


# Generated at 2022-06-20 13:21:00.595685
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:21:04.890269
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pl = PlaybookCLI()
    pl.init_parser()
    pl.parser = CLI.base_parser(constants=C,
                                runas_opts=True,
                                subset_opts=True,
                                check_opts=True,
                                inventory_opts=True,
                                runtask_opts=True,
                                vault_opts=True,
                                fork_opts=True,
                                module_opts=True,
                                connection_opts=True,
                                remote_user_opts=True,
                                verbosity_opts=True,
                                output_opts=True,
                                runas_prompt_opts=True,
                                async_opts=True)
    pl._play_prereqs()

# Generated at 2022-06-20 13:21:12.763529
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import pytest
    from tempfile import NamedTemporaryFile
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory

    pb = PlaybookCLI(['foo'])

    # test cli option validation
    options = pb.parser.parse_args(('-T 10 foo.yml'.split()))
    assert 10 == options.forks
    try:
        options = pb.parser.parse_args(('-T -1 foo.yml'.split()))
        assert False
    except SystemExit:
        assert True

    # test with missing playbook file

# Generated at 2022-06-20 13:21:15.703167
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    p = PlaybookCLI()
    assert p._display is not None
    assert isinstance(p._display, Display)
    assert p._play_prereqs is not None

# Generated at 2022-06-20 13:21:16.966384
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI(args=[])

# Generated at 2022-06-20 13:21:18.338387
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pb = PlaybookCLI(args=[])
    assert pb.parser is not None

# Generated at 2022-06-20 13:21:20.410749
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(args=[])
    options = cli.parse()
    cli.post_process_args(options)
    assert options

# Generated at 2022-06-20 13:21:25.136220
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    inventory = None
    variable_manager = None
    loader = None
    pb = PlaybookCLI(None, [], [], [])
    options = pb.parser.parse_args([])
    try:
        pb.post_process_args(options)
    except Exception as error:
        assert False, "Exception raised in post_process_args(%s) method: %s" % (options, error)

# Generated at 2022-06-20 13:21:30.192173
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()
    cli.post_process_args(cli.options)
    cli.run()

# Generated at 2022-06-20 13:21:35.903734
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    cli = PlaybookCLI()
    cli.init_parser()

    assert cli.parser.usage == "%prog [options] playbook.yml [playbook2 ...]"
    assert cli.parser.description == "Runs Ansible playbooks, executing the defined tasks on the targeted hosts."