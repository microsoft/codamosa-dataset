

# Generated at 2022-06-20 13:12:48.262335
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    def test_args(args):
        cliargs = {}
        cliargs['args'] = args

        my_cli = PlaybookCLI()
        my_cli.options = lambda: None
        my_cli.options.connection = 'smart'
        my_cli.options.module_path = '/home/user/ansible/library'
        my_cli.options.forks = 5
        my_cli.options.timeout = 10
        my_cli.options.remote_user = 'test'
        my_cli.options.private_key_file = '/home/user/.ssh/id_rsa'
        my_cli.options.ssh_common_args = '-o ProxyCommand="ssh -W %h:%p test@jumphost"'
        my_cli.options.ssh_extra_args = ''
        my_

# Generated at 2022-06-20 13:12:51.459637
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # Test with invalid source value, ensure correct exception raised
    try:
        PlaybookCLI('boom')
        raise AssertionError('The constructor of the PlaybookCLI class should raise an exception on bad source')
    except TypeError:
        pass

# Generated at 2022-06-20 13:12:56.220580
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    assert cli.parser is not None

# Generated at 2022-06-20 13:12:59.449094
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    # # Create and initialize the class object to test
    cli = PlaybookCLI(None, None)

    # Do the test
    cli.init_parser()


# Generated at 2022-06-20 13:13:00.094279
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    #TODO: need mocking
    pass


# Generated at 2022-06-20 13:13:04.794142
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(['/fake', '-e', '@/fake', '-v'])
    opts = cli.parse()
    cli.post_process_args(opts)

    assert opts.extra_vars == '@/fake'
    assert opts.verbosity == 1

# Generated at 2022-06-20 13:13:06.370760
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    P = PlaybookCLI(args=[])
    assert isinstance(P.parser, type(P))

# Generated at 2022-06-20 13:13:16.000568
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # Create test PlaybookCLI instance
    cli = PlaybookCLI(args=[])

    # Check for the proper options
    assert cli.options.syntax == False
    assert cli.options.listhosts == False
    assert cli.options.listtasks == False
    assert cli.options.listtags == False
    assert cli.options.step == False
    assert cli.options.start_at_task == None
    assert cli.options.args == []

    # Check for the proper option_groups
    assert len(cli.option_groups) == 5
    assert cli.option_groups[0].name == 'Connection Options'
    assert cli.option_groups[1].name == 'Metadata Options'
    assert cli.option_groups[2].name == 'Privilege Escalation Options'

# Generated at 2022-06-20 13:13:17.779171
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    p = PlaybookCLI([])
    assert isinstance(p, PlaybookCLI)
    assert isinstance(p, CLI)

# Generated at 2022-06-20 13:13:30.265176
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Initialize the Objects of the classes that will be used in the test
    cli = PlaybookCLI()
    options = cli.init_parser()

    # Test for the invalid case (More than one verbosity value passed)
    option_values = ['-v', '-vv', '-vvv', '-vvvv', '-vvvvv', '-vvvvvv',
                     '-vvvvvvv', '-vvvvvvvv', '-vvvvvvvvv']
    for option_val in option_values:
        options = [option_val]
        try:
            cli.post_process_args(options)
        except AnsibleOptionsError as e:
            if "too many v flags" not in str(e):
                raise

    # Test for invalid case (Verbosity passed with check mode)

# Generated at 2022-06-20 13:13:49.981901
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test with no playbook option. It should terminate
    # calling process with exit code 2
    test1args = {}
    test1args['args'] = []
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        PlaybookCLI(args=test1args).run()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 2

    # Test with a real playbook file. It should return 0.
    test2args = {}
    test2args['args'] = [os.path.join(os.path.dirname(__file__), 'playbook_test.yml')]
    assert PlaybookCLI(args=test2args).run() == 0

    test3args = {}

# Generated at 2022-06-20 13:14:01.815031
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    pb_cli = PlaybookCLI(['/usr/bin/ansible-playbook',
                          '--vault-password-file=/tmp/vault_password.txt',
                          '--syntax-check',
                          'playbook1',
                          'playbook2'])
    options = pb_cli.parse()

    pb_cli.post_process_args(options)
    assert options.verbosity == 0
    assert not options.listhosts
    assert not options.listtasks
    assert options.syntax
    assert 'playbook1' in options.args
    assert 'playbook2' in options.args
    assert options.description
    assert not options.connection
    assert not options.remote_user
    assert not options.inventory_file
    assert not options.module_path

# Generated at 2022-06-20 13:14:03.306485
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
  cli = PlaybookCLI()
  assert isinstance(cli, PlaybookCLI)

# Generated at 2022-06-20 13:14:03.951488
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:14:15.744652
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI([])
    context.CLIARGS = {}
    context.CLIARGS['verbosity'] = 0
    context.CLIARGS['connection'] = 'local'
    context.CLIARGS['module_path'] = '/path/to/mymodules'
    context.CLIARGS['forks'] = 10
    context.CLIARGS['remote_user'] = 'foo'
    context.CLIARGS['private_key_file'] = '/path/to/my/key'
    context.CLIARGS['ssh_common_args'] = ''
    context.CLIARGS['ssh_extra_args'] = ''
    context.CLIARGS['sftp_extra_args'] = ''
    context.CLIARGS['scp_extra_args'] = ''


# Generated at 2022-06-20 13:14:26.059514
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(['test.yml'])
    cli.parse()
    assert cli.options.verbosity == 3
    assert cli.options.connection == 'smart'
    assert cli.options.timeout == C.DEFAULT_TIMEOUT
    assert cli.options.forks == 5
    assert cli.options.remote_user == 'root'
    assert cli.options.private_key_file == C.DEFAULT_PRIVATE_KEY_FILE
    assert cli.options.ssh_common_args == ''
    assert cli.options.ssh_extra_args == ''
    assert cli.options.sftp_extra_args == ''
    assert cli.options.scp_extra_args == ''
    assert cli.options.become is False

# Generated at 2022-06-20 13:14:37.585605
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI()
    playbook_cli.parser = 'parser'
    playbook_cli.parser.parse_args = 'parse_args'
    playbook_cli.post_process_args = 'post_process_args'
    playbook_cli.run = 'run'

    mock_post_process_args = 'mock post_process_args'
    playbook_cli.post_process_args = lambda a, b, c, d, e, f, g, h, i, j, k, l: mock_post_process_args
    mock_run = lambda a, b, c: 'run called with parameters a, b, c'
    playbook_cli.run = mock_run


# Generated at 2022-06-20 13:14:42.293690
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    # we test a subset of the options because there are many which
    # would require mocking of the other libraries to be tested
    options = [
        '--list-hosts',
        '--syntax-check',
        '--list-tasks',
        '--list-tags',
        '--step',
        '--start-at-task',
    ]
    for op in options:
        assert op in cli.parser._option_string_actions

# Generated at 2022-06-20 13:14:43.645655
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    p_instance = PlaybookCLI(['test.yml'])
    assert isinstance(p_instance, PlaybookCLI)

# Generated at 2022-06-20 13:14:55.946782
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class Options(object):
        verbosity = True
        syntax = None
        step = None
        start_at_task = None
        inventory = None
        subset = None
        listhosts = None
        listtasks = None
        listtags = None
        step = None
        start_at_task = None
        vault_password_file = None
        new_vault_password_file = None
        vault_ids = []
        force_handlers = None
        flush_cache = None
        run_once = None
        checkpoint_on_error = None
        connection = 'ssh'
        module_path = None
        forks = 5
        remote_user = None
        remote_port = None
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        ssh_exec

# Generated at 2022-06-20 13:15:17.391257
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    playbook = PlaybookCLI([])
    assert playbook


# Generated at 2022-06-20 13:15:19.737110
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    PlaybookCLI().init_parser()


# Generated at 2022-06-20 13:15:31.892067
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class TestPlaybookCLI(PlaybookCLI):
        def __init__(self):
            super(TestPlaybookCLI, self).__init__()

    cli = TestPlaybookCLI()
    cli.parser = cli.create_parser()
    cli.options, cli.args = cli.parser.parse_args([])
    cli.post_process_args(cli.options)
    assert not cli.options.syntax, "Expected syntax to be false."
    assert cli.options.verbosity == 0, "Expected verbosity to be 0."
    assert cli.options.connection == 'smart', "Expected connection to be 'smart'."
    assert cli.options.module_path is None, "Expected module_path to be None."
    assert not cli.options.listtags

# Generated at 2022-06-20 13:15:41.563625
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    p = PlaybookCLI()
    parser = p.parser

    # Verify the correct parser options

# Generated at 2022-06-20 13:15:49.631564
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    """Return an instance of class PlaybookCLI"""
    invocation = 'ansible-playbook'
    pbcli = PlaybookCLI(
        None,
        None,
        None,
        'usage',
        'description',
        'epilog',
        'version',
        'formatter_class',
        'default_config_files',
        invocation,
    )
    assert pbcli.prog_name == invocation
    return pbcli

# Generated at 2022-06-20 13:15:56.725888
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Test invocation with --check, --list-tasks, --list-tags, --diff and --step
    # which should not set C.DEFAULT_FORKS
    cli = PlaybookCLI(['--check', '--list-tasks', '--list-tags', '--diff', '--step', 'playbook.yml'])
    opts = cli.post_process_args(cli.parser.parse_args())
    assert opts.check
    assert opts.listtasks
    assert opts.listtags
    assert opts.diff
    assert opts.step
    assert not opts.start_at_task

    # Test invocation with --check, --list-tasks, --list-tags, --diff and --step
    # and --start-at-task, which should not set C.DEFAULT_FOR

# Generated at 2022-06-20 13:15:58.115043
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI.run()

# Generated at 2022-06-20 13:16:07.671455
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    from collections import namedtuple
    from units.mock.cli import MockCLI
    from ansible.errors import AnsibleError
    from ansible.playbook.play import Play

    # Test that constructor calls super
    cli = PlaybookCLI(args=[])
    assert not cli.options is None
    assert not cli.args is None
    assert issubclass(PlaybookCLI, CLI)

    # Test that constructor calls init_parser
    cli_args = MockCLI.parsed_to_namedtuple()
    cli = PlaybookCLI(args=cli_args)
    assert not cli.parser._anonymous_help is None

    # Test that constructor calls _play_prereqs

# Generated at 2022-06-20 13:16:14.645781
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    # Create a test playbook cli and populate it with test data
    parser = PlaybookCLI(['/path/to/ansible/playbook.yml'])

    # Test that the options are defined in the help message
    assert parser.parser.option_list.__contains__(parser.parser.get_option('--list-tags'))
    assert parser.parser.option_list.__contains__(parser.parser.get_option('--step'))
    assert parser.parser.option_list.__contains__(parser.parser.get_option('--start-at-task'))

    # Test that the help option is defined
    assert parser.parser.option_list.__contains__(parser.parser.get_option('--help'))

# Generated at 2022-06-20 13:16:26.267999
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    from ansible.parsing.yaml import objects as yaml_objects
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import json

    sys.argv = ['ansible-playbook', '--list-tasks', 'test_playbook.yml']
    cli = PlaybookCLI(None)
    cli._play_prereqs = lambda: (None, None, None)
    cli.init_parser()

    playbooks = [
        'test_playbook.yml',
        'test_playbook_with_invalid_characters.yml',
    ]
    for fname in playbooks:
        with open(fname) as playbook_file:
            playbook = yaml_objects.AnsibleBaseYAMLObject.from_y

# Generated at 2022-06-20 13:17:19.324108
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pbcli = PlaybookCLI([])
    assert pbcli

# Generated at 2022-06-20 13:17:32.881980
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    mock_args = []

# Generated at 2022-06-20 13:17:36.740324
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    try:
        PlaybookCLI.post_process_args(context.CLIARGS)
    except AnsibleError as e:
        assert False, e.message

test_PlaybookCLI_post_process_args()

# Generated at 2022-06-20 13:17:41.784030
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # PlaybookCLI.run is tested in integration tests, we just run it
    # for code & coverage completeness.
    playbook_cli = PlaybookCLI()
    playbook_cli.run()

# Generated at 2022-06-20 13:17:54.613055
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Instantiate object and set some global variables
    pb = PlaybookCLI(args=[])
    os.environ["ANSIBLE_REMOTE_TEMP"] = "/tmp/ansible-remote"

    # Static variables for this test
    in_args = ['playbook.yml']
    in_verbosity = 0
    in_connection = None
    in_module_path = None
    in_forks = 0
    in_remote_user = None
    in_private_key_file = None
    in_ssh_common_args = None
    in_ssh_extra_args = None
    in_sftp_extra_args = None
    in_scp_extra_args = None
    in_become = False
    in_become_method = None
    in_become_user = None

# Generated at 2022-06-20 13:18:09.331569
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli_args = ['-i', '127.0.0.1,', '--inventory-file', '/etc/ansible/hosts']
    cli = PlaybookCLI(cli_args)
    cli.init_parser()
    options, args = cli.parser.parse_args(cli_args)
    assert options.connection == 'smart'
    assert options.inventory_file == '/etc/ansible/hosts'
    assert options.module_path is None
    assert options.remote_user == 'root'
    assert options.ask_pass is False
    assert options.ask_sudo_pass is True
    assert options.verbosity == 0
    assert options.check is False
    assert options.diff is False
    assert options.syntax is False
    assert options.listhosts is False
    assert options.list

# Generated at 2022-06-20 13:18:18.416757
# Unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-20 13:18:21.112024
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pb_cli = PlaybookCLI()
    assert pb_cli.parser._subcommands.choices.keys() == []

# Generated at 2022-06-20 13:18:30.809981
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    '''
    Test post_process_args to see if it does what it should
    '''
    # We need to do a lot of setup here in order to test this function.
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.plugin_docs import read_docstring
    from ansible.plugins import module_loader
    from ansible.parsing.plugin_docs import read_docstring

    # Get the original values of these collections
    orig_collection_paths = AnsibleCollectionConfig.collection_paths
    orig_collection_ignore = AnsibleCollectionConfig.collection_ignore
    orig_collection_dirs = AnsibleCollectionConfig.collection_dirs

    # Make it so our test collection will be found

# Generated at 2022-06-20 13:18:37.035755
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI()
    cli.parse()
    options = context.CLIARGS

    # Test with --list-tasks
    # Test with --list-tags
    # Test with --step
    # Test with --start-at-task
    # Test with --check
    for opt in ['-l', '-L', '-s', '-S', '-C']:
        context.CLIARGS = {}
        options.update({'verbosity': 1, 'check': False, 'syntax': False, 'start_at_task': None, 'step': False, 'listhosts': False, 'listtasks': False, 'listtags': False, 'flush_cache': False, 'args': ['playbook1.yml', 'playbook2.yml']})

# Generated at 2022-06-20 13:21:03.889029
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    ''' test init_parser method of class PlaybookCLI '''

    def test_parser_with_options():
        ''' check if parser can take options '''
        c = PlaybookCLI(args=[])
        c.init_parser()
        c.parser.parse_args(["-v", "example.yml"])

    test_parser_with_options()


# Generated at 2022-06-20 13:21:04.737613
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    PlaybookCLI()

# Generated at 2022-06-20 13:21:13.590302
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class FakePlaybookCLI(PlaybookCLI):
        def init_parser(self):
            return

        def post_process_args(self, options):
            return super(FakePlaybookCLI, self).post_process_args(options)

    cli = FakePlaybookCLI()
    cli.options = Mock()
    cli.options.verbosity = 1
    cli.post_process_args(cli.options)
    assert display.verbosity == 1

# Generated at 2022-06-20 13:21:14.523874
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    _ = PlaybookCLI()

# Generated at 2022-06-20 13:21:15.844583
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    assert PlaybookCLI()

# Generated at 2022-06-20 13:21:18.237905
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    test_instance = PlaybookCLI()
    assert isinstance(test_instance.parser, CLI.parser.__class__)


# Generated at 2022-06-20 13:21:26.336612
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbookCLI = PlaybookCLI()

# Generated at 2022-06-20 13:21:26.974828
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    assert PlaybookCLI()

# Generated at 2022-06-20 13:21:27.386878
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:21:28.592048
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    #TODO
    pass