

# Generated at 2022-06-20 13:12:47.548953
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    """PlaybookCLI - init_parser()"""
    yamlfile = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ansible.yaml')
    cli = PlaybookCLI(['--config', yamlfile])

    assert isinstance(cli.parser, CLI.base_parser) == True
    assert cli.parser.version == C.__version__

    # Validate required args
    assert cli.parser._optionals.title == 'options'

    # Validate connect args
    assert cli.parser._positionals.title == 'playbook'
    assert cli.parser._positionals.help == 'Playbook(s)'
    assert cli.parser._positionals.metavar == 'playbook'

# Generated at 2022-06-20 13:12:48.645841
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI().run()

# Generated at 2022-06-20 13:12:52.494448
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    expected_parser = CLI.create_parser('ansible-playbook',
                                        usage="%prog [options] playbook.yml [playbook2 ...]",
                                        desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts.")
    PlaybookCLI.init_parser(expected_parser)
    assert expected_parser is not None

# Generated at 2022-06-20 13:12:58.714997
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI(args=[])
    assert cli.parser is not None
    assert cli.parser._prog is not None

if __name__ == '__main__':
    import pytest
    pytest.main(["-v", __file__])

# Generated at 2022-06-20 13:12:59.458765
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:13:03.721887
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Setup a dict of args as if they came from the CLI
    args = dict(
        host_key_checking=True,
        private_key_file='c:\\users\\jdoe\\.ssh\\id_rsa',
        check=True,
        listhosts=False,
        listtasks=False,
        listtags=False,
        syntax=False,
        subset="all"
    )

    cli = PlaybookCLI(args)
    # Invoke method to test
    context.CLIARGS = cli.post_process_args(args)
    # Verify results
    assert context.CLIARGS['host_key_checking'] == True
    assert context.CLIARGS['private_key_file'] == 'c:\\users\\jdoe\\.ssh\\id_rsa'
   

# Generated at 2022-06-20 13:13:14.233096
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    playbook_cli = PlaybookCLI()

    assert playbook_cli is not None
    #
    # TODO: Find out why self.parser is not available to use for the test?
    #
    # assert playbook_cli.parser.action == 'store'
    # assert playbook_cli.parser.dest == 'listhosts'
    #
    # assert playbook_cli.parser.action == 'store'
    # assert playbook_cli.parser.dest == 'listtasks'
    #
    # assert playbook_cli.parser.action == 'store'
    # assert playbook_cli.parser.dest == 'listtags'
    #
    # assert playbook_cli.parser.action == 'store'
    # assert playbook_cli.parser.dest == 'step'
    #
    # assert playbook_cli.parser.action == 'store'


# Generated at 2022-06-20 13:13:15.285594
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    result = cli.init_parser()
    assert result is None


# Generated at 2022-06-20 13:13:19.479898
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Create a fake command line args
    argv = ['-i', 'localhost,']

    # Create PlaybookCLI object
    cli = PlaybookCLI(argv)

    parser = cli.init_parser()

    # Test if the following options are added to the parser.
    assert ('-i' in parser._option_string_actions)
    assert ('--inventory' in parser._option_string_actions)

# Generated at 2022-06-20 13:13:31.505085
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI([])
    opts = cli.parse(['foo/bar.yaml'])
    assert not opts.become
    assert not opts.become_user
    assert not opts.check
    assert not opts.diff
    assert not opts.flush_cache
    assert not opts.force_handlers
    assert not opts.forks
    assert not opts.listhosts
    assert not opts.listtags
    assert not opts.listtasks
    assert not opts.step
    assert not opts.syntax
    assert not opts.start_at_task
    assert not opts.vault_password_file
    assert not opts.vault_identity_list
    assert not opts.verbosity
    assert not opts.version
   

# Generated at 2022-06-20 13:13:44.765807
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    This is a unit test for method run of class PlaybookCLI.
    '''
    playbook_cli = PlaybookCLI()
    playbook_cli.post_process_args(playbook_cli.options)
    playbook_cli.run()


# Generated at 2022-06-20 13:13:50.768442
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Create an instance of PlaybookCLI
    cli = PlaybookCLI()

    # Create a namespace for the arguments
    options = CLI.base_parser(constants=C).parse_args([])

    # Store the current value of display verbosity
    display_verbosity = display.verbosity

    # Assert that the display verbosity is the same
    assert display.verbosity == display_verbosity

    # Call the method post_process_args
    cli.post_process_args(options)

    # Assert that the display verbosity is the same
    assert display.verbosity == display_verbosity

# Generated at 2022-06-20 13:14:02.450447
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockPlaybookExecutor:
        def __init__(self):
            self.playbooks = "playbook.yml"
            self.inventory = "test"
            self.variable_manager = "test"
            self.loader = "test"
            self.passwords = "test"
            self.results = [{'playbook': 'playbook.yml',
                             'plays': [{'playbook:': 'playbook.yml', 'idx': '1', 'hosts': 'localhost', 'name': 'test'}]}]
        def run(self):
            return self.results


    class MockCLI:
        def __init__(self):
            self.args = []

    class MockPlaybookCLI(PlaybookCLI):
        def __init__(self):
            self.args = []

# Generated at 2022-06-20 13:14:10.656934
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import unittest
    from ansible.utils.display import Display
    display = Display()
    
    class SimplePlaybookExecutor():
        def __init__(self, playbooks, inventory=None, variable_manager=None, loader=None, passwords=None):
            pass
        def run(self):
            return 0

    class SimpleInventory():
        def __init__(self, loader=None):
            pass
        def list_hosts(self):
            return [host for host in ['hostA', 'hostB', 'hostC']]
        def get_hosts(self, hostlist=None):
            return [host for host in ['hostA', 'hostB', 'hostC']]

    class SimpleVariableManager():
        def __init__(self, loader=None, inventory=None):
            pass

# Generated at 2022-06-20 13:14:21.227953
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.errors import AnsibleError


# Generated at 2022-06-20 13:14:22.908818
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI()

# Generated at 2022-06-20 13:14:30.017657
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    args = ['-i', 'test_inventory', '-M', 'test_module_path', 'test_ansible_dir', 'test_playbook']
    context.CLIARGS = {'args': args}
    playbook_cli = PlaybookCLI(args)
    playbook_cli.init_parser()
    assert playbook_cli.parser.description == u'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'

# Generated at 2022-06-20 13:14:34.837949
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pl = PlaybookCLI(args=[])
    pl.init_parser()
    options, args = pl.parser.parse_known_args()
    options = pl.post_process_args(args=options)
    pl.parser._split_args(options)
    pl.run()
    assert 1==1

# Generated at 2022-06-20 13:14:36.252481
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PB = PlaybookCLI([])
    PB.run()

# Generated at 2022-06-20 13:14:38.742884
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Test with args
    args = ['ansible-playbook', '/tmp/playbook.yml']
    pb = PlaybookCLI(args)
    assert pb.args == args

# Generated at 2022-06-20 13:15:10.584688
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Case 1: no options
    # Expected result: success
    test_parser = PlaybookCLI()
    test_parser.init_parser()
    test_options = test_parser.parser.parse_args([])
    try:
        test_result = test_parser.post_process_args(options=test_options)
    except SystemExit:
        assert False, "Ansible failed to start when no options are passed in."

    # Case 2: pass in --syntax-check
    # Expected result: success
    test_parser = PlaybookCLI()
    test_parser.init_parser()
    test_options = test_parser.parser.parse_args(['--syntax-check'])

# Generated at 2022-06-20 13:15:25.895461
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI

    #test_PlaybookCLI_run_init
    args = []
    args.append('playbook.yml')
    args.append('connector.j2')
    args.append('-e')
    args.append('ansible_connection=ssh')
    args.append('-e')
    args.append('ansible_ssh_user=yourname')
    args.append('-e')
    args.append('ansible_ssh_pass=secret')
    args.append('-e')
    args.append('ansible_sudo_pass=secret')
    args.append('-i')
    args.append('inventory.cfg')

    # Create mock objects
    mock_cls = PlaybookCLI(args)

    # Test unit!
   

# Generated at 2022-06-20 13:15:26.733713
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI()
    assert isinstance(cli, PlaybookCLI)

# Generated at 2022-06-20 13:15:27.232318
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    PlaybookCLI()

# Generated at 2022-06-20 13:15:28.707658
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pbcli = PlaybookCLI()
    assert pbcli.run is not None

# Generated at 2022-06-20 13:15:39.064224
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import unittest
    import ansible

    class TestPlaybookCLI(unittest.TestCase):

        def test_version_check(self):
            from ansible.errors import AnsibleError
            from ansible.cli import CLI

            old_version_info = ansible.__version__
            ansible.__version__ = '1.4.0'

            old_stdout = CLI.CLI_STDOUT
            CLI.CLI_STDOUT = StringIO()

            try:
                self.assertRaises(AnsibleError, PlaybookCLI().run())
            except AttributeError:
                pass    # older ansible versions do not raise an error, hence the AttributeError

            ansible.__version__ = old_version_info
            CLI.CLI_STDOUT = old_stdout

# Generated at 2022-06-20 13:15:41.995692
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    instance = PlaybookCLI()
    a = None
    instance.post_process_args(a)

# Generated at 2022-06-20 13:15:46.031147
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    playbook = 'playbook1'
    cli = PlaybookCLI()
    opts = cli.parse()
    cli.post_process_args(opts)
    cli.run()

# Generated at 2022-06-20 13:15:47.213043
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb = PlaybookCLI()


# Generated at 2022-06-20 13:15:54.682789
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(['ansible-playbook', '--list-hosts', '--connection=local', '--inventory=host,otherhost', '--extra-vars', 'var1=val1', '--extra-vars', 'var2=val2'])
    assert cli.options.inventory == ['host', 'otherhost']
    assert cli.options.listhosts
    assert cli.options.connection == 'local'
    assert cli.options.extra_vars['var1'] == 'val1'
    assert cli.options.extra_vars['var2'] == 'val2'

# Generated at 2022-06-20 13:16:47.876779
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    PlaybookCLI()

# Generated at 2022-06-20 13:16:51.536907
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    '''
    Test the init_parser method of the PlaybookCLI class
    '''
    cli = PlaybookCLI([])
    parser = cli.init_parser()
    assert isinstance(parser, CLI.parser_class)

# Generated at 2022-06-20 13:16:56.897043
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # TODO: setup argv for test
    argv = ["ansible-playbook", "--list-tasks", "playbook.yml"]
    cli = PlaybookCLI(argv)
    options = cli.parse()
    options = cli.post_process_args(options)

# Generated at 2022-06-20 13:17:05.751551
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import unittest

    import ansible.cli.playbook
    import ansible.playbook

    class TestPlaybookCLI_run(unittest.TestCase):
        """Test when is_playbook() returns False"""
        def setUp(self):
            self.cli = ansible.cli.playbook.PlaybookCLI(args=[])
            self.playbook = ansible.playbook.Playbook()
            self.playbook._entries = [1, 2, 3]

        def test_1_true(self):
            result = self.cli.is_playbook()
            self.assertTrue(result)

        def test_2_false(self):
            result = self.cli.is_playbook(self.playbook)
            self.assertFalse(result)

    unittest.main()

# Generated at 2022-06-20 13:17:17.817082
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import unittest
    import unittest.mock as mock
    from . import test_utils as utils
    from .mock_artifactory_server import ArtifactoryServer

    # below are only the args that would be passed to PlaybookCLI.run()
    # kwargs = {'listhosts': False, 'listtags': False, 'syntax': False, 'subset': None,
    #          'step': False, 'start_at_task': None, 'inventory': 'test/test.inv',
    #          'args': playbooks}
    #
    # this test will only execute the ansible-playbook command with a single playbook
    # passed as arguments
    playbooks = ['test/test.yml']


# Generated at 2022-06-20 13:17:26.477567
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    args = ['--list-hosts']
    cli = PlaybookCLI(args)
    parser = cli.parser
    assert parser is not None
    assert parser.prog == 'ansible-playbook'
    assert parser.description.strip() == PlaybookCLI.__doc__.strip()
    assert parser.usage == '%(prog)s [options] playbook.yml [playbook2 ...]'
    assert isinstance(parser._positionals, optparse.ArgumentGroup)
    assert parser._positionals.title == 'positional arguments'
    assert len(parser._positionals._group_actions) == 1
    assert parser._positionals._group_actions[0].dest == 'args'
    assert parser._positionals._group_actions[0].help == 'Playbook(s)'
    assert parser._positionals._group

# Generated at 2022-06-20 13:17:37.756888
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from io import StringIO
    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader

    # test1: run playbook with --listhosts
    # test2: run playbook with --listhosts and -i option
    option1 = "--listhosts"
    option2 = "-i host,host2"
    playbooks = ["playbook.yml"]
    argv = ["", option1] + playbooks
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    inventory.add_host(host=None, group='host')
    inventory.add_host(host=None, group='host2')
    args = Playbook

# Generated at 2022-06-20 13:17:44.465956
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import argparse
    from ansible_collections.ansible.community.tests.unit.plugins.test_cli.test_bin.test_playbookcli import (
        FakeOptions, FakeAnsibleCoreCLI, FakePlaybookCLI, FakeAnsibleCLI)
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 0

    FakeParser = argparse.ArgumentParser()
    FakeParser.add_argument('args', help='Playbook(s)', metavar='playbook', nargs='+')
    options = FakeOptions(FakeParser)
    options.connection = 'ssh'
    options.module_path = '/fake/path'
    options.forks = 5
    options.remote_user = 'fake_remote_user'

# Generated at 2022-06-20 13:17:56.735055
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    assert cli.parser.prog == 'ansible-playbook'
    assert cli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert cli.parser.description == "Runs Ansible playbooks, executing the defined tasks on the targeted hosts."
    assert cli.parser._positionals.title == 'Playbook(s)'
    assert cli.parser._positionals.metavar == 'playbook'
    assert cli.parser._positionals.nargs == '+'
    assert cli.get_opt('--list-tasks') == cli.parser._option_string_actions['--list-tasks']

# Generated at 2022-06-20 13:18:00.725168
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # create a PlaybookCLI object
    playbook_cli = PlaybookCLI()

    # set test data
    args = []
    parser = playbook_cli.create_parser(args, 'ansible-playbook')
    options, args = parser.parse_args(args)
    context.CLIARGS = options

    # invoke the method post_process_args
    assert playbook_cli.post_process_args(options)

# Generated at 2022-06-20 13:20:11.424373
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys
    import tempfile

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    class TestPlaybookCLI(unittest.TestCase):
        ''' Unit tests to test class PlaybookCLI '''

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_playbook_cli(self):
            ''' Test playbook cli command '''

# Generated at 2022-06-20 13:20:16.797269
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Initialize empty object for test
    test_object = PlaybookCLI()

    # Execute method
    test_object.init_parser()

    # Check if resulting object has attributes
    assert hasattr(test_object, 'parser')

    # Check object if object type is same as initial object
    assert isinstance(test_object, PlaybookCLI)

# Generated at 2022-06-20 13:20:18.312816
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    instance, _ = PlaybookCLI.parse([])
    assert isinstance(instance, PlaybookCLI)

# Generated at 2022-06-20 13:20:25.382974
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    p = PlaybookCLI()
    p.options = opt_help.create_parser()
    p.options.ask_vault_pass = False
    p.options.ask_pass = False
    p.options.listhosts = False
    p.options.listtags = False
    p.options.listtasks = False
    p.options.syntax = False
    p.options.sudo_user = False
    p.options.sudo = False
    p.options.diff = False
    p.options.connection = 'ssh'
    p.options.check = False
    p.options.timeout = 10
    p.options.remote_user = 'root'
    p.options.verbosity = 0
    p.options.inventory = ''

# Generated at 2022-06-20 13:20:34.865710
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # GIVEN
    pb = PlaybookCLI(command='test')

    # WHEN
    pb.init_parser()

    # THEN
    assert pb.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert pb.parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'

    # WHEN
    args = pb.parser.parse_args([])

    # THEN
    assert args.force_handlers is None
    assert args.listhosts is None
    assert args.meta is None
    assert args.step is None
    assert args.start_at_task is None
    assert args.syntax is None
    assert args.vault_password_file is None
    assert args.new_vault_password_file is None


# Generated at 2022-06-20 13:20:42.227786
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Create a parser, which will allow us to call post_process_args
    p = PlaybookCLI()
    p.init_parser()

    # Create some options.
    options = p.parser.parse_args([
        '-i', '/path/to/hosts',
        '--list-hosts'
    ])

    # Run the method under test
    result = p.post_process_args(options)

    # Assert that the command line arguments have been expanded and copied
    # into context.CLIARGS.  This is what run does with these values.
    assert context.CLIARGS['listhosts']
    assert context.CLIARGS['subset'] == None

    # Assert that the method returned the same options instance.
    # This isn't really needed, but it doesn't hurt to have this level


# Generated at 2022-06-20 13:20:47.349844
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    host_list = ('localhost,')
    inventory = "example/hosts"
    # Creating a PlaybookCLI object with args
    cli = PlaybookCLI(['ansible-playbook', 'playbook.yml', '--list-hosts',
                      '--inventory', inventory, '--limit', host_list])
    # Creating a mock options object
    options = opt_help.get_base_parser().parse_args([])[0]
    # Adding host_list,inventory and list_hosts to options object
    options.listhosts = True
    options.inventory = inventory
    options.subset = host_list
    # Calling post_process_args

# Generated at 2022-06-20 13:20:49.431574
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    sys_module = __import__('sys')
    sys_module.argv = ['ansible-playbook', '--version']
    PlaybookCLI()

# Generated at 2022-06-20 13:20:53.302037
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
        pb_test = PlaybookCLI()
        pb_test.args = ['test1.yml', 'test2.yml']
        print(pb_test.parser)
        print(pb_test.run())

if __name__ == '__main__':
    test_PlaybookCLI()

# Generated at 2022-06-20 13:21:05.524971
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(["-h"], 'test')
    parser = cli.parser
    assert parser.prog == 'ansible-playbook'
    assert parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert parser.description == '''Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'''
    group_connection = parser._option_string_actions['--connection'].container
    assert group_connection.title == 'connection related options'
