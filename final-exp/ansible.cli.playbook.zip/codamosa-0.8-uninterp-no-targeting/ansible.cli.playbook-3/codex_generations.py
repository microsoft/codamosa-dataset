

# Generated at 2022-06-20 13:12:47.618217
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    PlaybookCLI.init_parser()

# Generated at 2022-06-20 13:12:55.540927
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    pb = PlaybookCLI(['playbook1.yml'])
    pb.run()

    # Test for command options

# Generated at 2022-06-20 13:13:06.905507
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    cli = PlaybookCLI(['./test/test_data/test_playbook_cli.yml'])
    cli.parse()
    options = cli.options

    assert options is not None
    assert options.listtags is False
    assert options.listtasks is False
    assert options.step is False
    assert options.start_at_task is None
    assert options.subset is None
    assert options.connection is None
    assert options.forks is None
    assert options.inventory is None
    assert options.module_path is None
    assert options.remote_user is None
    assert options.private_key_file is None
    assert options.ssh_common_args == ''
    assert options.ssh_extra_args == ''
    assert options.sftp_extra_args == ''
    assert options.sc

# Generated at 2022-06-20 13:13:11.683676
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = PlaybookCLI.init_parser(PlaybookCLI(), [])
    assert parser.prog == 'ansible-playbook'
    assert parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'



# Generated at 2022-06-20 13:13:13.398894
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb = PlaybookCLI()
    pb.init_parser()
    pb.parse()
    assert pb.parser is not None

# Generated at 2022-06-20 13:13:22.432367
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    # Test case 1: with args, cover exception
    command = PlaybookCLI(['./test/support/args_test_playbook.yml'])
    command.parser = command._init_parser()
    options = command.parser.parse_args(['./test/support/args_test_playbook.yml'])
    command.post_process_args(options)
    assert command.run() == 0

    # Test case 2: with no args
    command = PlaybookCLI()
    command.parser = command._init_parser()
    options = command.parser.parse_args([])
    command.post_process_args(options)
    assert command.run() == 0

# Generated at 2022-06-20 13:13:24.362028
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    Unit test for method run of class PlaybookCLI
    """
    pass

# Generated at 2022-06-20 13:13:30.299483
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(['playbook.yml'])
    cli.post_process_args()
    assert context.CLIARGS['listhosts'] == False

    cli = PlaybookCLI(['playbook.yml', '-L'])
    cli.post_process_args()
    assert context.CLIARGS['listhosts'] == True

# Generated at 2022-06-20 13:13:43.592851
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.module_utils._text import to_text

    play = PlaybookCLI(args=None)
    parser = play.parser
    opt_help.add_connect_options(parser)
    opt_help.add_meta_options(parser)
    opt_help.add_runas_options(parser)
    opt_help.add_subset_options(parser)
    opt_help.add_check_options(parser)
    opt_help.add_inventory_options(parser)
    opt_help.add_runtask_options(parser)
    opt_help.add_vault_options(parser)
    opt_help.add_fork_options(parser)
    opt_help.add_module_options(parser)



# Generated at 2022-06-20 13:13:58.354081
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Initialize the class
    cli = PlaybookCLI()
    options, args = cli.parser.parse_args([])

    # test first use case
    options.listhosts = True
    options.listtasks = False
    options.listtags = False
    options.syntax = False
    options.step = False
    options.start_at_task = None
    options.connection = 'local'
    options.timeout = 30
    options.ssh_common_args = None
    options.sftp_extra_args = None
    options.scp_extra_args = None
    options.ssh_extra_args = None
    options.become = False
    options.become_method = 'sudo'
    options.become_user = None
    options.become_ask_pass = False
    options

# Generated at 2022-06-20 13:14:18.929627
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.cli.playbook import PlaybookCLI
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.dumper import AnsibleDumper

    display = Display()

    class FakeOptParser():
        def __init__(self):
            self.args = []
            self.values = []

        def add_argument(self, arg='', action='', dest='', help='', metavar='', nargs='', type='', choices='', required=''):
            self.args.append(arg)
            self.values.append(None)


# Generated at 2022-06-20 13:14:27.942746
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    class Options(object):
        verbosity = 1
    class Options2(object):
        host_key_checking = True
    class Options3(object):
        flush_cache = True
    class Options4(object):
        listtasks = True
    class Options5(object):
        listtags = True
    class Options6(object):
        step = True
    class Options7(object):
        start_at_task = 'mytask'
    class Options8(object):
        syntax = True
    class Options9(object):
        subset = 'localhost'
    class Options10(object):
        inventory = '/test/inventory'
    class Options11(object):
        diff = True

# Generated at 2022-06-20 13:14:31.558211
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pb_cli = PlaybookCLI(["init_parser"])
    pb_cli.init_parser()
    assert isinstance(pb_cli.parser, object)


# Generated at 2022-06-20 13:14:41.012173
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    kwargs = dict(
        inventory=Mock(),
        loader=Mock(),
        variable_manager="variable_manager",
        passwords=dict(conn_pass="conn_pass", become_pass="become_pass"),
        playbooks=["playbook_1", "playbook_2"],
    )
    pbex = Mock()
    pbex.run.return_value = True
    PCLI = PlaybookCLI(**kwargs)
    PCLI._play_prereqs = Mock(return_value=(kwargs.pop("loader"), kwargs.pop("inventory"), kwargs.pop("variable_manager")))
    pbex_cls = Mock(return_value=pbex)

# Generated at 2022-06-20 13:14:45.228613
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.utils.vars import combine_vars

    # Testing for the case when we want to ask for both passwords

    # Testing for the case when we want to ask for become_pass only
    # Testing for the case when we want to ask for both passwords

# Generated at 2022-06-20 13:14:48.040898
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Test that PlaybookCLI.init_parser fails if run in non-interactive mode
    pass

# Generated at 2022-06-20 13:14:48.793290
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pass

# Generated at 2022-06-20 13:14:50.829902
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI()
    assert cli is not None, "cli is not PlaybookCLI"

# Generated at 2022-06-20 13:14:53.085035
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI(args=[])
    res = cli.run()
    assert res == 2

# Generated at 2022-06-20 13:14:53.580343
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    assert PlaybookCLI() is not None

# Generated at 2022-06-20 13:15:12.132865
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pb_cli = PlaybookCLI()
    pb_cli.init_parser()
    args = ['--vault-id', 'myvault', '--vault-id', 'myothervault', '--list-hosts', '@myhosts', '--graph', 'foo.dot', '--limit', 'all', 'site.yml']
    parsed = vars(pb_cli.parser.parse_args(args))
    assert parsed['vault_ids'] == ['myvault', 'myothervault']
    assert parsed['graph'] == 'foo.dot'
    assert parsed['listhosts']



# Generated at 2022-06-20 13:15:28.031731
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    def _count_args(playbook_cli, options, expected_count):
        options_count = 0
        for key in list(options.keys()):
            if options[key]:
                options_count += 1
        assert playbook_cli.post_process_args(options) is None, 'post_process_args returned a non-None value'
        assert options_count == expected_count, 'expected %d options, got %d' % (expected_count, options_count)

    def _test_connect_options(playbook_cli, options):
        for option in opt_help.connect_options:
            options[option.dest] = True
            _count_args(playbook_cli, options, expected_count=opts_count)
            options[option.dest] = False
            opts_count += 1

    # Scenario

# Generated at 2022-06-20 13:15:30.819272
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb = PlaybookCLI(['playbook.yml', '--list-tasks'])
    assert pb is not None

# Generated at 2022-06-20 13:15:31.500091
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:15:47.764031
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    """
    Test that PlaybookCLI.post_process_args() returns the specified args with
    added defaults, when non-defaults are provided
    """

# Generated at 2022-06-20 13:15:50.501719
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb = PlaybookCLI(args=[])
    assert pb._display is not None
    assert pb._options is not None

# Generated at 2022-06-20 13:16:00.560222
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.utils.sentinel import Sentinel

    yml = """
        - name: Sample
          hosts: testserver
          tasks: []
    """

    hosts = ["testserver"]
    host = Host(name="testserver", port=22)
    sentinel = Sentinel()
    display.verbosity = 0

    im = InventoryManager(loader=DataLoader(), sources=hosts)
    im.add_host(host)

    v = VariableManager()

# Generated at 2022-06-20 13:16:07.595012
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    playbook = PlaybookCLI()

    # PlaybookCLI.run method requires user-input -> replace with a fake function

    def dummy(prompt):
        return True
    #
    # add objects to __dict__
    #
    playbook.__dict__['ask_passwords'] = dummy
    playbook.__dict__['_play_prereqs'] = dummy
    playbook.__dict__['_flush_cache'] = dummy

    #
    # call method
    #
    r = playbook.run()

    #
    # check results
    #
    assert r == 0

# Generated at 2022-06-20 13:16:22.122954
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI([])
    display.verbosity = 3

# Generated at 2022-06-20 13:16:31.232999
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # create fake CLI object
    CLI = type('cli', (object,), {})
    CLI.ask_passwords = lambda *args: (None, None)
    CLI.get_host_list = lambda *args: None
    CLI.still_running = lambda *args: None
    CLI.ask_vault_passwords = lambda *args: None
    # fake play_prereqs method
    class _loader_mock:
        def set_basedir(*args, **kwargs):
            pass
    class _inventory_mock:
        def get_hosts(*args, **kwargs):
            return []
        def list_hosts(*args, **kwargs):
            return []
    class _variable_manager_mock:
        def clear_facts(*args, **kwargs):
            pass

# Generated at 2022-06-20 13:17:03.750682
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import shutil
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    # Create a playbook directory
    playbook_dir = 'test_playbook_dir'
    os.mkdir(playbook_dir)

    # Create a playbook file
    playbook_filename = os.path.join(playbook_dir, 'test_playbook.yaml')
    with open(playbook_filename, 'w') as f:
        print('---', file=f)
        print('- hosts: all', file=f)
        print('  tasks:', file=f)
        print('    - ping:', file=f)

    # Create a hosts file
    inventory_filename = os.path.join(playbook_dir, 'hosts')

# Generated at 2022-06-20 13:17:15.218136
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli_args = dict(
        connection='smart',
        module_path=None,
        forks=5,
        become=False,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        syntax=False,
        start_at_task=None,
        verbosity=None,
        listhosts=None,
        listtasks=None,
        listtags=None,
        step=False,
        start_at_task=None,
        inventory=None,
        subset=None,
        extra_vars=[],
        tags=[],
        skip_tags=[],
        flush_cache=False,
        args=[],
    )
    cli_obj = PlaybookCLI(['--forks=5'])

# Generated at 2022-06-20 13:17:19.612101
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    playbook_cli = PlaybookCLI(None, None)
    playbook_cli.init_parser()
    args, unknown_args = playbook_cli.parser.parse_known_args(args=['--version'])
    assert (args.version == False)


# Generated at 2022-06-20 13:17:21.084423
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:17:33.483794
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    def test_args(args, expected):
        # Clear the command line arguments initialized in the ansible.constants
        sys.argv = [sys.argv[0]]
        # Update the command line arguments with the ones that you would like to test
        for arg in args:
            sys.argv.append(arg)

        cli = PlaybookCLI()
        cli.init_parser()
        if len(cli.parser._actions) != len(expected):
            for i in cli.parser._actions:
                print(i.dest)

        assert len(cli.parser._actions) == len(expected)
        for index in range(len(cli.parser._actions)):
            assert cli.parser._actions[index].dest == expected[index]


# Generated at 2022-06-20 13:17:42.328689
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from unittest.mock import patch
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.errors import AnsibleError
    import os

    def mock_run(self):
        return 0

    def mock_ask_passwords(*args, **kwargs):
        return '', ''

    def mock_play_prereqs(self):
        return (None, None, None)

    def mock_get_host_list(inventory, subset):
        return ['host']

    def mock_exists(str):
        return True

    def test_init_parser(mock_self):
        mock_self.parser.add_argument = MagicMock()
        mock_self.init_parser()

# Generated at 2022-06-20 13:17:50.605639
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    test_instance = PlaybookCLI()
    test_instance.init_parser()
    test_instance.args = ['ansible-playbook', 'test.yml']
    # Check for default verbosity
    result = test_instance.post_process_args(test_instance.options)
    assert result.verbosity == 0
    # Check for verbosity level
    test_instance.options.verbosity = 1
    test_instance.post_process_args(test_instance.options)
    assert result.verbosity == 1

# Generated at 2022-06-20 13:17:54.466899
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    """
    PlaybookCLI - constructor
    """
    # Initialize a new PlaybookCLI object
    cli = PlaybookCLI([])
    assert cli.parser is not None

# Generated at 2022-06-20 13:18:09.332249
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    invoke_module = './hacking/test-module.py'
    collection_path = os.path.realpath(os.path.join(os.getcwd(), 'lib/ansible/modules/common'))
    collection = ['ansible.builtin', 'ansible_test_collection', collection_path]
    playbook = './hacking/test_playbook.yml'
    args = ['-m', invoke_module, os.path.realpath(playbook)]
    with open(playbook, 'w') as f:
        f.write(
            '---\n'
            '- hosts: localhost\n'
            '  tasks:\n'
            '    - name: Test\n'
            '      ansible.builtin.debug: msg=test\n'
        )
    # create a parser to

# Generated at 2022-06-20 13:18:18.410986
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    from ansible.utils.color import stringc
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    loader = DataLoader()
    display = Display()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-20 13:19:32.943550
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI()

    # Test with verbose
    options = opt_help.parse(['playbook.yml', '-v'])
    options = cli.post_process_args(options)
    assert options is not None
    assert options.verbosity > 0
    assert options.inventory is None

    # Test with inventory
    options = opt_help.parse(['playbook.yml', '-i', 'inventory', '-v'])
    options = cli.post_process_args(options)
    assert options is not None
    assert options.verbosity > 0
    assert options.inventory == 'inventory'

# Generated at 2022-06-20 13:19:40.224348
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # create base objects
    loader = DataLoader()
    variable_manager = VariableManager()

    # create an inventory with a host
    inventory = InventoryManager(loader=loader, sources=('localhost,',))
    variable_manager.set_inventory(inventory)

    # prepare a playbook with a task
    play = Play().load({'hosts': 'localhost', 'gather_facts': 'no', 'tasks': [{'debug': {'msg': 'Hello world'}}]}, variable_manager=variable_manager, loader=loader)
    play._included_file = 'playbook.yml'

    # create

# Generated at 2022-06-20 13:19:41.880284
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    myPlaybookCLI = PlaybookCLI()
    assert myPlaybookCLI != None

# Generated at 2022-06-20 13:19:51.917830
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI([])
    cli._populate_action_args()
    parser = cli.parser
    # Check if parser object is not None
    assert parser is not None
    # Check if post_process_args() raise AnsibleError for wrong values
    options, args = parser.parse_args(['--forks', '-1', 'any.yml'])
    try:
        cli.post_process_args(options)
        assert False
    except AnsibleError:
        assert True
    # Check if post_process_args() returns the options
    options, args = parser.parse_args(['--forks', '10', 'any.yml'])
    assert cli.post_process_args(options) == options

# Generated at 2022-06-20 13:19:54.763992
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # avoid lookup of host vars
    context.CLIARGS = {'host_vars': {}, 'group_vars': {}}

    pb = PlaybookCLI(["test.yml"])
    pb.run()

# Generated at 2022-06-20 13:19:59.879103
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = PlaybookCLI(['foobar']).init_parser()
    assert parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'
    assert parser.prog == 'ansible-playbook'

    (options, args) = parser.parse_args(['foobar'])
    assert options.listhosts is False
    assert options.listtasks is False
    assert options.listtags is False
    assert options.syntax is False
    assert options.step is False
    assert options.start_at_task is None
    assert options.args == ['foobar']

# Generated at 2022-06-20 13:20:04.428633
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(['--check'])
    options = cli.parse()

    # post_process_args() returns the same options object
    options = cli.post_process_args(options)

    # --check should set other parameters
    assert options.syntax
    assert options.diff

# Generated at 2022-06-20 13:20:12.234966
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-20 13:20:17.074291
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # FIXME: implement test_PlaybookCLI_post_process_args
    # FIXME: use something other than None as mock args
    # FIXME: create a mock class for display
    pbcli = PlaybookCLI()
    assert pbcli.post_process_args(None) == None

# Generated at 2022-06-20 13:20:17.797106
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass