

# Generated at 2022-06-20 13:12:53.849433
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(['-i', 'a/b/c', '-u', 'foo', '--private-key', 'a/b/c', '-k', 'play.yml'])
    cli.parse()
    options_parsed = cli.post_process_args(cli.options)

    assert options_parsed.ask_pass is False
    assert options_parsed.ask_su_pass is False
    assert options_parsed.ask_sudo_pass is False
    assert options_parsed.ask_vault_pass is False


test_PlaybookCLI_post_process_args()

# Generated at 2022-06-20 13:12:58.945373
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    playbook = PlaybookCLI(['playbook.yml', 'playbook2.yml'])
    assert playbook.name == 'playbook.yml playbook2.yml'
    assert playbook.playbook == ['playbook.yml', 'playbook2.yml']

# Generated at 2022-06-20 13:13:01.132066
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    test_cli = PlaybookCLI()
    test_cli.init_parser()



# Generated at 2022-06-20 13:13:05.299397
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Define playbook_cli command line options
    playbook_cli = PlaybookCLI(['-i', 'localhost,', '-l', 'localhost', '-m', 'setup',
                                '-a', 'gather_subset=min', '-v', 'tests/unittests/test_module_setup.py'])
    # Define expected values for command line options
    display.verbosity = 1
    context.CLIARGS['verbosity'] = 1
    context.CLIARGS['subset'] = 'localhost'
    context.CLIARGS['module_paths'] = None
    context.CLIARGS['connection'] = 'smart'
    context.CLIARGS['listhosts'] = True
    context.CLIARGS['remainder'] = ['/bin/ls']
    context.CL

# Generated at 2022-06-20 13:13:05.879428
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:13:15.644270
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    '''Unit test for method post_process_args of class PlaybookCLI'''

    def mock_run_args(self, args=None):
        # Mocks the run method in PlaybookCLI to return the args passed to it.
        if args:
            return args
        else:
            return self.args

    def mock_get_opt_parser(self):
        # Mocks the _get_opt_parser method in PlaybookCLI to return self.parser
        return self.parser

    def mock_read_cli_env(self):
        # Mocks the _read_cli_env method in PlaybookCLI to return self.CLI_ENV_VARS
        return self.CLI_ENV_VARS

    parser_mock = PlaybookCLI()
    parser_mock._get_opt_parser = mock

# Generated at 2022-06-20 13:13:17.117490
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pass

if __name__ == '__main__':
    test_PlaybookCLI()

# Generated at 2022-06-20 13:13:29.472423
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = PlaybookCLI()._load_kwargs(pass_parser=True)
    assert parser.formatter_class.__name__ == 'RawTextHelpFormatter', \
        'repr(parser.formatter_class) was %s' % repr(parser.formatter_class)
    assert parser.description == "Runs Ansible playbooks, executing the defined tasks on the targeted hosts.", \
        'repr(parser.description) was %s' % repr(parser.description)
    assert parser.usage.startswith('usage: %prog [options] playbook.yml [playbook2 ...]')
    args = parser.parse_args()
    assert args.syntax == False, 'args.syntax was %s' % repr(args.syntax)

# Generated at 2022-06-20 13:13:30.209809
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:13:43.443907
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    import os
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
    from units.mock.vault_secrets import VaultSecretStub
    from units.modules.test_packaging import AnsibleModuleStub

    class AnsiblePlaybookExecutorStub(object):
        def __init__(self, playbooks, inventory, loader, variable_manager, options):
            self.playbooks = playbooks
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader
            self.options = options
            self.passwords = {}

        def run(self):
            return []

    class AnsibleVariableManagerStub(object):
        def __init__(self, inventory):
            self.inventory = inventory


# Generated at 2022-06-20 13:14:02.112874
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    import sys
    fake_parser = opt_help.create_parser()
    # run under a fake subparser to verify we're actually registering there
    with opt_help.SubParser(fake_parser, "ansible-playbook") as subparser:
        cli = PlaybookCLI(parser=subparser)
        cli.init_parser()
        args = ['--help']
        results = fake_parser.parse_args(args)
        assert results.func == cli.run
        assert results.subcommand == "ansible-playbook"

# Generated at 2022-06-20 13:14:04.124867
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    playbook_cli = PlaybookCLI()
    playbook_cli.init_parser()
    assert playbook_cli.parser

# Generated at 2022-06-20 13:14:11.427442
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    inventory = CLI.setup_inventory(context.CLIARGS['inventory'])
    display.verbosity = context.CLIARGS['verbosity']

    play_source = dict(
        name = "Ansible Play 0",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    tqm = None
    callback = ResultsCollector()

# Generated at 2022-06-20 13:14:14.987139
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    ansible_cli = PlaybookCLI()
    ansible_cli.init_parser()
    ansible_cli.parse()
    ansible_cli.post_process_args(ansible_cli)
    ansible_cli.run()

# Generated at 2022-06-20 13:14:16.624972
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # check if class PlaybookCLI was successfully constructed:
    assert PlaybookCLI
    assert PlaybookCLI().run

# Generated at 2022-06-20 13:14:26.701709
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import inventory_loader
    PlaybookCLI._flush_cache = lambda x,y: None
    pbcli = PlaybookCLI([])
    pbcli.ask_passwords = lambda: ('sshpass','becomepass')
    pbcli.post_process_args = lambda options: options

# Generated at 2022-06-20 13:14:30.340917
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cls = PlaybookCLI()
    cls.parser = cls.create_parser()
    cls.post_process_args(args={'verbosity': 2})
    assert display.verbosity == 2

# Generated at 2022-06-20 13:14:35.460912
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    '''Unit test for class PlaybookCLI, method init_parser'''
    obj = PlaybookCLI()
    assert(isinstance(obj, PlaybookCLI))
    assert(obj.parser is not None)
    assert(obj.parser.usage == '%prog [options] playbook.yml [playbook2 ...]')



# Generated at 2022-06-20 13:14:43.117961
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    #
    # check post_process_args
    #
    # test with no options
    cli = PlaybookCLI([])
    opt = cli.post_process_args({})
    assert opt == {}

    # test with verbosity
    cli = PlaybookCLI([])
    opt = cli.post_process_args({'verbose': True})
    assert isinstance(opt, dict)
    assert opt == {'verbosity': 2, 'verbose': True}

    # test with --connection
    cli = PlaybookCLI([])
    opt = cli.post_process_args({'connection': 'docker'})
    assert opt == {'connection': 'docker'}

    # test with --inventory-file
    cli = PlaybookCLI([])
    opt = cli.post_process_

# Generated at 2022-06-20 13:14:55.639513
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Perform some unit tests
    from ansible.cli.playbook import PlaybookCLI

    class MockOptions:
        def __init__(self):
            self.connection = 'ssh'
            self.module_path = None
            self.forks = 10
            self.private_key_file = '/tmp/key.pem'
            self.ssh_common_args = ''
            self.ssh_extra_args = ''
            self.sftp_extra_args = ''
            self.scp_extra_args = ''
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'jdoe'
            self.verbosity = 0
            self.check = False
            self.diff = False


# Generated at 2022-06-20 13:15:26.713958
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # test for PlaybookCLI constructor
    plugins = C.config.get_config_value('DEFAULT', 'action_plugins')
    cli = PlaybookCLI(args=['-i', 'test/ansible_playbook/test_playbook.yml', 'docs/playbook_test.yml'],
                      callback=None,
                      runner_callback=None,
                      passwords=None,
                      action_plugins=plugins)
    assert cli

# Generated at 2022-06-20 13:15:37.910089
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class TestException(Exception):
        pass

    # Construct mock objects for testing.
    import ansible
    from collections import namedtuple
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.parsing.dataloader import DataLoader

    def _get_constants():
        # Helper function to get constants associated with PlaybookCLI.
        return namedtuple('Constants', [
            'DEFAULT_MODULE_NAME', 'DEFAULT_MODULE_PATH',
            'DEFAULT_PLAYBOOK_PATH', 'CONSTANT_DEPRECATION_WARNING'
        ])(
            C.DEFAULT_MODULE_NAME, C.DEFAULT_MODULE_PATH,
            C.DEFAULT_PLAYBOOK_PATH, C.CONSTANT_DEPRECATION_WARNING
        )



# Generated at 2022-06-20 13:15:39.396550
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # TODO
    assert False

# Generated at 2022-06-20 13:15:49.962110
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # Create a CLI object
    cli = PlaybookCLI(['[example.org]'])
    # Create a parser object
    parser = cli.create_parser()
    # Create a namespace object
    args = parser.parse_args(['[example.org]'])
    # Create a collection_loader object
    collection_loader = cli.create_loader(args)
    # Create a variable_manager object
    variable_manager = cli.create_variable_manager(collection_loader, args)
    # Create a connections object
    connections = cli.create_connections(variable_manager, args)

# Generated at 2022-06-20 13:15:56.599380
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI([])

    cli.init_parser()

    # Now assert the values of the resulting parser
    parser = cli.parser

    assert parser.get_default('listhosts') == False
    assert parser.get_default('listtasks') == False
    assert parser.get_default('listtags') == False
    assert parser.get_default('syntax') == False
    assert parser.get_default('step') == False


# Generated at 2022-06-20 13:15:58.938831
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    from ansible.cli.cli import CLI
    cli = CLI()
    assert cli is not None


# Generated at 2022-06-20 13:16:08.210691
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create the command line arguments for test
    args = ['ansible-playbook', 'test.yml']

# Generated at 2022-06-20 13:16:15.379107
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Tests for case where inventory is not set and forks is set greater than 0.
    # Should cause an error since forks is greater than 0 but inventory is not set.
    class PlaybookCLIMock(PlaybookCLI):
        def run(self, args):
            assert False

    args = [
        '--forks', '3'
    ]
    parser = PlaybookCLIMock()
    try:
        parser.parse(args)
    except AnsibleError as e:
        assert '--inventory/-i is required when forks > 0' in to_bytes(e)

    # Tests for case where inventory is not set and forks is set to 0.
    # Should not cause an error since forks is 0.
    args = [
        '--forks', '0'
    ]
    parser = PlaybookCLI()
    parser.parse

# Generated at 2022-06-20 13:16:19.657459
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    play_cli = PlaybookCLI()
    (options, args) = play_cli.parser.parse_args(['playbook_cli.yml'])
    play_cli.post_process_args(options)
    play_cli.run()

# Generated at 2022-06-20 13:16:29.674909
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    import mock
    import tempfile
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    # initialize the base class

# Generated at 2022-06-20 13:17:05.659911
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from io import StringIO
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class FakePlaybookExecutor:
        def __init__(self, playbooks, inventory, variable_manager, loader, passwords):
            self.results = []

        def run(self):
            self.results.append({
                'playbook': 'fake_playbook.yaml',
                'plays': [FakePlay('fake_play.yaml', 'fake_play', ['localhost'], [])]
            })
            return self.results


# Generated at 2022-06-20 13:17:17.725170
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    '''
    Test post_process_args of class PlaybookCLI
    '''
    def _test_deprecation(args):
        # TODO: Find a way to trigger parsing errors, as BaseCLI._parse_cli_opts()
        #       catches before returning
        ##### Trigger parsing errors #####
        # options.fake_opt = 8888
        # options.connection = 'asdf'
        # options.remote_user += 'x'

        with Display():
            cli = PlaybookCLI()
            options = cli.parse(args)


# Generated at 2022-06-20 13:17:32.828502
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = CLI.base_parser(
        usage="%prog [options] playbook.yml [playbook2 ...]",
        connect_opts=False,
        meta_opts=False,
        runas_opts=False,
        subset_opts=False,
        check_opts=False,
        runtask_opts=False,
        vault_opts=False,
        fork_opts=False,
        module_opts=False,
        desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts."
    )

    cli = PlaybookCLI(parser)
    cli.init_parser()

    assert cli.parser._actions[6].dest == 'listtasks'
    assert cli.parser._actions[7].dest == 'listtags'
    assert cli

# Generated at 2022-06-20 13:17:39.699990
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    playbook_cli = PlaybookCLI()
    playbook_cli.parser = opt_help.CommandParser(usage='%prog [options] playbook.yml [playbook2 ...]',
                                                 desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts.")
    playbook_cli.init_parser()
    assert playbook_cli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert playbook_cli.parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'

# Generated at 2022-06-20 13:17:46.819284
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    cli = PlaybookCLI(['-i', 'inventory/hosts'])
    assert cli.args == ['inventory/hosts']
    assert isinstance(cli.parser, CLI.base_parser)
    assert isinstance(cli.options, dict)
    assert isinstance(cli.commands, dict)
    assert isinstance(cli.display, Display)
    assert isinstance(cli.playbooks, list)



# Generated at 2022-06-20 13:17:54.455341
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    # Initialize parser
    p = PlaybookCLI(None)
    p.init_parser()

    # Check some options
    assert p.parser.get_default('syntax') == False
    assert p.parser.get_default('diff') == False
    assert p.parser.get_default('tags') == ''
    assert p.parser.get_default('skip_tags') == ''
    assert p.parser.get_default('check') == False

# Generated at 2022-06-20 13:18:01.982796
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    pbcli = PlaybookCLI(args='test.yml -vvvv'.split())
    parser = pbcli.init_parser()
    assert parser.description.startswith('Runs Ansible')


# Generated at 2022-06-20 13:18:08.269607
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    from ansible.cli.arguments import option_helpers as opt_help

    # create a test parser
    c = PlaybookCLI()
    c.init_parser()
    c.parser.add_argument('-v', '--verbose', dest='verbosity', action='count', default=0,
                          help='verbose mode (-vvv for more, -vvvv to enable connection debugging)')
    c.parser.add_argument('-m', dest='module_path',
                          help="prepend colon-separated path(s) to module library (default=[u'/usr/share/ansible'])",
                          type=opt_help.list_type, default=None)

    # create a mock options object

# Generated at 2022-06-20 13:18:14.365907
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """ Test function for ansible.cli.playbook.PlaybookCLI._run """
    test_args = ["ansible-playbook", "test.yml", "--list-hosts"]
    from ansible.utils.display import Display
    display = Display()
    playbook_cli = PlaybookCLI(args=test_args)
    playbook_cli.parse()
    results = playbook_cli.run()
    assert results == 0



# Generated at 2022-06-20 13:18:18.273654
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Create a fake class for test
    class FakePlaybookCLI(PlaybookCLI):
        def init_parser(self):
            self.parser = argparse.ArgumentParser()

    cli = FakePlaybookCLI(args=[])

    # Run the method under test
    args = cli.post_process_args(cli.parse())

    assert args['verbosity'] == 0

# Generated at 2022-06-20 13:19:23.146897
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI()

# Generated at 2022-06-20 13:19:33.880276
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    from collections import namedtuple

    from ansible.cli import CLI
    from ansible.cli.playbook import PlaybookCLI

    Options = namedtuple('Options', ['connection', 'remote_user', 'ask_pass', 'private_key_file',
                                     'sudo', 'sudo_user', 'ask_sudo_pass', 'verbosity', 'ack_pass',
                                     'check','listhosts','listtasks','listtags','syntax','module_path',
                                     'forks','subset','diff','step','start_at_task','inventory_file',
                                     'list_hosts', 'list_tasks', 'list_tags', 'step', 'start_at_task', 'args'])

   

# Generated at 2022-06-20 13:19:38.787811
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args = []
    display = Display()
    cli = PlaybookCLI(args, display)
    cli.run()

# Generated at 2022-06-20 13:19:41.469164
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # Create a parser for CLI options
    p = PlaybookCLI(['/usr/bin/ansible-playbook'])
    assert p is not None

# Generated at 2022-06-20 13:19:51.951300
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI()
    cli.init_parser()

    # Test when no conflicts exist
    options = opt_help.parse_options(['-v'], cli.parser)
    result = cli.post_process_args(options)
    assert result['verbosity'] == 2

    # Test when conflicts exist
    options = opt_help.parse_options(['-v', '--ask-su-pass', '--ask-pass'], cli.parser)
    cli.post_process_args(options)
    assert 'ERROR! The following options are mutually exclusive: become_ask_pass, ask_pass' in cli.parser.error

    # Reset the parser
    cli.reset_parser()
    cli.init_parser()

# Generated at 2022-06-20 13:19:53.656923
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    context.CLIARGS = {'remainder': []}
    cli = PlaybookCLI()
    assert cli is not None

if __name__ == '__main__':
    test_PlaybookCLI()

# Generated at 2022-06-20 13:19:55.478116
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI()
    options = cli.parse()
    options = cli.post_process_args(options)
    assert isinstance(options, dict)

# Generated at 2022-06-20 13:19:56.959066
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    raise NotImplementedError


# Generated at 2022-06-20 13:20:07.662809
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    import argparse
    from collections import namedtuple

    testargs = namedtuple("testargs", "verbose listhosts listtasks listtags step start_at_task")
    testargs.verbose = 1
    testargs.listhosts = ''
    testargs.listtasks = ''
    testargs.listtags = ''
    testargs.step = ''
    testargs.start_at_task = ''

    # create parser for CLI options
    usage = "%prog [options] playbook.yml [playbook2 ...]"
    desc = "Runs Ansible playbooks, executing the defined tasks on the targeted hosts."
    cli = PlaybookCLI(parser=argparse.ArgumentParser(usage, description=desc))

    # parse args
    parser = cli.parser

# Generated at 2022-06-20 13:20:14.344733
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI

    pb = PlaybookCLI(['playbook.yml'])
    pb.options.verbosity = 0
    pb.options.listtags = True
    pb.options.listtasks = True
    pb.options.flush_cache = False
    pb.options.inventory = ['inventory']
    pb.options.subset = None
    pb.options.tags = None
    pb.options.skip_tags = None
    pb.options.diff = False
    pb.options.skip_tags = None
    pb.options.step = False
    pb.options.start_at_task = None

    # Test for run where all goes well