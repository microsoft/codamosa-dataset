

# Generated at 2022-06-20 13:12:55.613634
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    cls = PlaybookCLI()
    cls.parser = CLI.base_parser(constants=C, runas_opts=True,
                                 subset_opts=True, fork_opts=True, runtask_opts=True, vault_opts=True,
                                 check_opts=True, meta_opts=True, inventory_opts=True, connect_opts=True)

    # Valid options
    options = cls.parser.parse_args(['--limit', 'localhost', 'playbook.yml'])
    cls.post_process_args(options)

    # Check for conflicting options errors
    options = cls.parser.parse_args(['--limit', 'localhost', '--diff', 'playbook.yml'])

# Generated at 2022-06-20 13:13:01.186799
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI(args=['ansible-playbook', '--help'])
    cli.parse()
    assert cli.parser.usage == "%prog [options] playbook.yml [playbook2 ...]"
    assert cli.parser.description == \
           "Runs Ansible playbooks, executing the defined tasks on the targeted hosts."

# Generated at 2022-06-20 13:13:12.178619
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # 1. Mock class
    class Cli:
        def __init__(self):
            self.version = False
            self.verbosity = 0
            # In post_process_args called self.validate_conflicts() which is why we need it here
            self.validate_conflicts = lambda x: None

    # 2. Fake CLI args
    class Args:
        def __init__(self):
            self.syntax = False
            self.listhosts = False
            args = ""

    # 3. Build test cases

# Generated at 2022-06-20 13:13:19.928700
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    test_cli = PlaybookCLI([])
    test_args = test_cli.post_process_args(test_cli.parser.parse_args([]))
    assert test_args.verbosity == 0
    assert test_args.listhosts == False
    assert test_args.subset == None
    assert test_args.listtasks == False
    assert test_args.listtags == False
    assert test_args.syntax == False
    assert test_args.start_at_task == None
    assert test_args.step == False
    assert test_args.args == []

    test_args = test_cli.post_process_args(test_cli.parser.parse_args(['-v','inventory','playbook.yml','playbook2.yml']))
    assert test_args.verbosity == 1


# Generated at 2022-06-20 13:13:21.086309
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    playbook_cli = PlaybookCLI()
    assert isinstance(playbook_cli, PlaybookCLI)

# Generated at 2022-06-20 13:13:32.581369
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import stat
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.cli.arguments import option_helpers as opt_help

    display = Display()

# Generated at 2022-06-20 13:13:40.238163
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    class TestPlaybookCLI(PlaybookCLI):
        def __init__(self):
            super(TestPlaybookCLI, self).__init__()
            self.init_parser()
            self.args = self.parser.parse_args([])

    cli = TestPlaybookCLI()
    args = cli.args

    assert args.listhosts is False
    cli.post_process_args(args)
    assert args.listhosts is True

# Generated at 2022-06-20 13:13:50.068537
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-20 13:14:01.859974
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    PlaybookCLI = PlaybookCLI(['/usr/bin/ansible-playbook',
                               '--list-hosts',
                               '--list-tasks',
                               'playbook.yml',
                               'playbook2.yml',
                               'playbook3.yml'])

    # pre check
    assert len(PlaybookCLI.parser._actions) == 21
    assert len(PlaybookCLI.parser._option_string_actions['-i'].choices) == 2

    context.CLIARGS = vars(PlaybookCLI.args)

    # post check
    assert len(PlaybookCLI.parser._actions) == 22
    assert len(PlaybookCLI.parser._option_string_actions['-i'].choices) == 3

# Generated at 2022-06-20 13:14:09.504381
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI()
    cli.parser = CLI.base_parser(
        constants=C,
        usage='usage',
        connect_opts=True,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        inventory_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True
    )
    options = cli.parser.parse_args(['--list-hosts'])
    # We are only interested in checking if this is not raising an error
    cli.post_process_args(options)



# Generated at 2022-06-20 13:14:22.665101
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    args = ['ansible-playbook', '--step', '--start-at-task', 'task1', 'playbook.yml']
    options = CLI.parse(args)
    pbcli = PlaybookCLI(args)
    assert pbcli.post_process_args(options).start_at_task == 'task1'

# Generated at 2022-06-20 13:14:34.360345
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args = [
        '--inventory', 'inventory.ini',
        '--module-path', '/path/to/ansible/modules',
        '--extra-vars', 'host=testserver', 'foo=bar',
        '--syntax-check', 'test.yml',
    ]

    CLI.args = args
    CLI.parse()

    runner = PlaybookCLI()
    runner.parse()
    runner.post_process_args(context.CLIARGS)

    assert context.CLIARGS['subset'] == ['testserver']
    assert context.CLIARGS['extra_vars']['foo'] == 'bar'

    # Test run and some of its internals
    # TODO: add tests for inventory, variable_manager and password
    runner.run()

# Generated at 2022-06-20 13:14:35.007357
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:14:42.885789
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Invalid vaul_password can not be run with vault_password_file, the same for --ask-pass and --ask-become-pass
    parser = PlaybookCLI()
    parser.init_parser()
    options = parser.parser.parse_args(
        ['playbook.yml', '--vault-password-file', '/etc/ansible/vault', '--vault-password', 'password'])
    options = parser.post_process_args(options)
    assert options.vault_password is None
    options = parser.parser.parse_args(
        ['playbook.yml', '--vault-password', 'password', '--vault-password-file', '/etc/ansible/vault'])
    options = parser.post_process_args(options)

# Generated at 2022-06-20 13:14:55.457895
# Unit test for method init_parser of class PlaybookCLI

# Generated at 2022-06-20 13:15:10.454158
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path
    from ansible.utils.display import Display
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    display = Display()
    display.verbosity = 3
    PB_CLI = PlaybookCLI()
    PB_CLI.parser = PB_CLI.init_parser()
    options = PB_CLI.parser.parse_args(['playbook_dir/playbook.yml'])
    PB_CLI.post_process_args(options)

# Generated at 2022-06-20 13:15:25.537865
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Set up instance of PlaybookCLI
    context._init_global_context(['ansible-playbook'])
    pbc = PlaybookCLI(args=[])

    # Set up mock display for testing output
    class MockDisplay:
        def __init__(self):
            self.displayed = []

        def display(self, msg, *args, **kwargs):
            self.displayed.append(msg)

    display = MockDisplay()
    pbc.display = display

    # Set up fake inventory
    class FakeInventory:
        def __init__(self):
            self.hosts = ['localhost', '127.0.0.1']
            self.groups = ['all']
            self.vars = {'group_all': {'hosts': [host] for host in self.hosts}}


# Generated at 2022-06-20 13:15:29.982174
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Create instances of various test classes and test data
    PlaybookCLI_instance = PlaybookCLI()
    PlaybookCLI_instance.args = ['test.yml']

    # Init parser
    PlaybookCLI_instance.init_parser()

    # Set options
    PlaybookCLI_instance.options = PlaybookCLI_instance.parser.parse_args(['test.yml'])

    return PlaybookCLI_instance.run()



# Generated at 2022-06-20 13:15:31.116243
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO
    pass

# Generated at 2022-06-20 13:15:33.780606
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI([])
    cli.init_parser()
    assert cli.parser  # didn't crash

# Generated at 2022-06-20 13:15:58.203522
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    args = ['--private-key', '~/foo/bar.pem', '--private-key', '~/foo/bar2.pem', '--list-hosts', 'test.yml']
    cli_args = PlaybookCLI(args).parse()
    # FIXME, this remove multiple private-keys, however it should be an array
    cli_args = PlaybookCLI(args).post_process_args(cli_args)
    assert cli_args.private_key == '~/foo/bar2.pem'
    assert cli_args.subset == 'all'

# Generated at 2022-06-20 13:16:07.741480
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-20 13:16:15.071411
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    args = [
        'playbook', '--list-hosts', 'playbook.yml',
        '--fork', '2',
        '--limit', 'host1',
        '--vault-password-file', 'vpass',
        '--ask-vault-pass',
        '--ask-sudo-pass',
        '--ask-su-pass',
        '--ask-pass',
        '--list-hosts',
        '--list-tasks',
        '--list-tags',
        '--step',
        '--start-at-task', 'task1',
        '--start-at-task', 'task2'
    ]

    pbcli = PlaybookCLI(args)
    options = pbcli.parser.parse_args(args)

    assert options.listhosts == True

# Generated at 2022-06-20 13:16:25.543743
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    cli = PlaybookCLI([])
    options = cli.parser.parse_args([])
    assert options.verbosity == 0
    options = cli.parser.parse_args(["-v"])
    assert options.verbosity == 1
    options = cli.parser.parse_args(["-vv"])
    assert options.verbosity == 2
    options = cli.parser.parse_args(["-vvv"])
    assert options.verbosity == 3
    options = cli.parser.parse_args(["-vvvv"])
    assert options.verbosity == 4
    options = cli.parser.parse_args(["-vvvvv"])
    assert options.verbosity == 4 # Max

# Generated at 2022-06-20 13:16:39.762929
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Create an instance of class PlaybookCLI
    playbook_cli = PlaybookCLI()

    # Retrieve its parser
    parser = playbook_cli.parser

    # Assert that the parser contains all options necessary for the CLI tool
    assert parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert parser.prog == 'ansible-playbook'
    assert parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'
    assert parser.formatter_class == opt_help.AnsibleFormatter

    # Assert verbosity options
    assert opt_help.has_option(parser, '-v')
    assert opt_help.has_option(parser, '-vv')
    assert opt_help.has_option(parser, '-vvv')

# Generated at 2022-06-20 13:16:48.401830
# Unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-20 13:16:53.186947
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Create a play and assert the parser is generated correctly

    PlaybookCLI.init_parser()
    parser = context.CLIARGS['parser']

    assert '--list-tasks' in parser.format_help()

# Generated at 2022-06-20 13:17:03.863077
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import tempfile
    import shutil
    import unittest

    from ansible.cli.playbook import PlaybookCLI
    from ansible.plugins.loader import add_all_plugin_dirs, get_all_plugin_loaders

    class TestPlaybookCLI_run(unittest.TestCase):
        ''' creating a temporary directory,
            creating a file named test_data_source in the directory,
            adding the directory to the search path for plugins
            running the PlaybookCLI with the file as the only argument '''

        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)

# Generated at 2022-06-20 13:17:05.290300
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI(args=[])
    cli.run()

# Generated at 2022-06-20 13:17:17.286709
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = PlaybookCLI(['playbook.yml']).init_parser()
    args = ['-e', 'food=yum']
    options = parser.parse_args(args)
    assert options.extra_vars == 'food=yum'

    args = ['--limit', 'all']
    options = parser.parse_args(args)
    assert options.subset == 'all'

    args = ['--syntax-check']
    options = parser.parse_args(args)
    assert options.syntax == True

    args = ['--forks', '50']
    options = parser.parse_args(args)
    assert options.forks == 50

    args = ['--list-hosts']
    options = parser.parse_args(args)
    assert options.listhosts == True


# Generated at 2022-06-20 13:17:49.001559
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    """
    This is a unit test for method init_parser of class PlaybookCLI with
    return value as a parser object
    """
    pb_parser = PlaybookCLI()
    pb_parser.init_parser()
    assert pb_parser.parser is not None


# Generated at 2022-06-20 13:17:56.382365
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    test_object_PlaybookCLI = PlaybookCLI()
    test_object_PlaybookCLI.init_parser()
    test_parser_expected = optparse.OptionParser(
        usage="%prog [options] playbook.yml [playbook2 ...]",
        description="Runs Ansible playbooks, executing the defined tasks on the targeted hosts."
    )
    assert test_object_PlaybookCLI.parser.format_help() == test_parser_expected.format_help()

# Generated at 2022-06-20 13:17:57.292155
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    assert PlaybookCLI()

# Generated at 2022-06-20 13:18:00.394756
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    parser = PlaybookCLI()
    parser.parser
    assert parser.parser is not None


# Generated at 2022-06-20 13:18:12.150841
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class Options:
        connection = None
        module_path = None
        forks = None
        become = None
        become_method = None
        become_user = None
        check = None
        diff = None
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        subset = None
        sudo = None
        sudo_user = None
        verbosity = None
        start_at_task = None
        step = None
        inventory = None
        private_key_file = None
        flush_cache = None
        remote_user = None
        args = None

    options = Options()
    options.connection='local'
    options.module_path=None
    options.forks=5
    options.become=False
    options.become_method=None
    options.bec

# Generated at 2022-06-20 13:18:12.726006
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:18:17.377920
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI(['playbook.yml'])
    assert cli.args == ['playbook.yml']

# Generated at 2022-06-20 13:18:21.669375
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    os.environ['ANSIBLE_CONFIG'] = 'ansible.cfg'
    cli = PlaybookCLI(['playbook.yml'])
    cli.post_process_args(cli.options)
    results = cli.run()
    assert results == 0

# Generated at 2022-06-20 13:18:31.301794
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # create a test PlaybookCLI instance
    test_instance = PlaybookCLI()

    # create a test options object
    test_options = opt_help.create_base_parser()
    test_options.connection = 'ssh'
    test_options.remote_user = 'root'
    test_options.become = True
    test_options.become_method = 'sudo'
    test_options.become_user = 'root'
    test_options.verbosity = 5
    test_options.check = True

    test_instance.post_process_args(test_options)
    assert C.DEFAULT_TRANSPORT == test_options.connection
    assert test_options.remote_user == 'root'
    assert C.DEFAULT_BECOME == test_options.become
    assert C.DEFAULT

# Generated at 2022-06-20 13:18:33.228706
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    assert isinstance(PlaybookCLI(), PlaybookCLI)

# Generated at 2022-06-20 13:19:49.021284
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    import ansible
    from ansible.utils.display import Display
    obj = PlaybookCLI()
    assert obj.parser._prog == os.path.split(sys.argv[0])[-1]
    assert obj.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert obj.parser.description == ('Runs Ansible playbooks, executing the defined tasks on the targeted hosts.')

if __name__ == '__main__':
    import sys
    test_PlaybookCLI()

# Generated at 2022-06-20 13:19:49.647757
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    PlaybookCLI()

# Generated at 2022-06-20 13:19:57.212426
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    """ Verify post_process_args behavior.

    Before running all tests, we should reset all options to their default values.
    """
    # Reset values for all options to their default
    context.CLIARGS = context.CLIARGS_CLEAN.copy()

    # We can add our default values here
    for k,v in opt_help.playbook_defaults.items():
        context.CLIARGS[k] = v

    playbook_cli = PlaybookCLI(args=[])

    # Not in conflict
    options = playbook_cli.parse(args=[])
    assert playbook_cli.post_process_args(options) == options

    # Conflict -n and -e
    options = playbook_cli.parse(args=['--check'])
    options.check = True

# Generated at 2022-06-20 13:19:58.090492
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pass

# Generated at 2022-06-20 13:19:59.698306
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    PlaybookCLI.post_process_args(context.CLIARGS)

# Generated at 2022-06-20 13:20:08.401788
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a new PlaybookCLI
    pcli = PlaybookCLI(['playbook.yml'])

    assert hasattr(pcli, "init_parser"), "attribute init_parser doesn't exist"
    assert hasattr(pcli, "post_process_args"), "attribute post_process_args doesn't exist"
    assert hasattr(pcli, "run"), "attribute run doesn't exist"
    assert hasattr(pcli, "_play_prereqs"), "attribute _play_prereqs doesn't exist"
    assert hasattr(pcli, "ask_passwords"), "attribute ask_passwords doesn't exist"
    assert hasattr(pcli, "_flush_cache"), "attribute _flush_cache doesn't exist"

# Generated at 2022-06-20 13:20:14.768297
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    parser = cli.init_parser()

    args = ['--list-hosts', '-v', '--list-tasks', '--list-tags', '--syntax-check', '--start-at-task', 'alternate_hostname_tasks', '--step', '--inventory', 'hosts', '-t', 'tags_to_run', '--ask-vault-pass', '--ask-pass', '--tags', 'automated', '--skip-tags', 'manual', '--extra-vars', '@test_vars.yml', '--extra-vars', '@test_vars_2.yml', 'test_playbook.yml']
    parsed_args = parser.parse_args(args)

    assert parsed_args.ask_pass

# Generated at 2022-06-20 13:20:19.409164
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    """
    This is a test of the constructor of the class PlaybookCLI.
    The constructor and its parameters are the following:
    __init__(self, args, stdin=None)
    :param args:
    :param stdin:
    """
    args = []
    stdin = None
    test = PlaybookCLI(args, stdin)
    assert test

# Generated at 2022-06-20 13:20:26.453496
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    """
    This test case checks if the ansible-playbook command line options
    are added to the parser object.
    """
    parser = PlaybookCLI(args=[])
    parser.init_parser()
    args = ['playbook.yml']
    namespace = parser.parser.parse_args(args)
    pargs = vars(namespace)

    assert pargs['subset'] == None
    assert pargs['listhosts'] == False
    assert pargs['listtasks'] == False
    assert pargs['listtags'] == False
    assert pargs['step'] == False
    assert pargs['start_at_task'] == None
    assert pargs['private_key_file'] == C.DEFAULT_PRIVATE_KEY_FILE
    assert pargs['verbosity'] == 0

# Generated at 2022-06-20 13:20:27.915921
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create tests for PlaybookCLI.run
    pass