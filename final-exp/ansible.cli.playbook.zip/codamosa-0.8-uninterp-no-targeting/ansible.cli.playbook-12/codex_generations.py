

# Generated at 2022-06-20 13:12:48.960399
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    class TestPlaybookCLI(PlaybookCLI):
        def __init__(self):
            super(PlaybookCLI, self).__init__()

    tpc = TestPlaybookCLI()
    tpc.alias = {}
    tpc.constants = C
    tpc.parser = tpc.init_parser()
    tpc.parser.parse_args = lambda x, y: ['ansible-playbook', '-i', 'localhost,']
    tpc.parse()
    assert tpc.post_process_args(tpc.options) is not None

# Generated at 2022-06-20 13:12:54.772079
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    assert cli.parser is not None



# Generated at 2022-06-20 13:12:55.688444
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:12:57.505280
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    # Arg parsing functionality is too entwined with the code to
    # test it effectively, so just make sure we can invoke it.
    parser = PlaybookCLI().init_parser()
    options, args = parser.parse_args(['play.yml'])

# Generated at 2022-06-20 13:12:59.228322
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''TODO: write unit test for PlaybookCLI.run'''
    pass

# Generated at 2022-06-20 13:13:09.516829
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # We need to override Ansible CLI constants to make it possible to run
    # this unit test independent from the stock Ansible.
    C.DEFAULT_MODULE_PATH = "/dev/null"
    C.DEFAULT_ROLES_PATH = "/dev/null"
    C.DEFAULT_PLAYBOOK_PATH = os.getcwd()
    C.DEFAULT_PRIVATE_ROLE_VARS_PATH = "/dev/null"
    C.DEFAULT_ACTION_PLUGIN_PATH = "/dev/null"
    C.DEFAULT_CACHE_PLUGIN_PATH = "/dev/null"
    C.DEFAULT_CALLBACK_PLUGIN_PATH = "/dev/null"
    C.DEFAULT_CONNECTION_PLUGIN_PATH = "/dev/null"
    C.DEFAULT_

# Generated at 2022-06-20 13:13:18.549228
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(args=['--bar-host', 'host1', '--private-key', 'key1', '-i', 'inventory1', '--list-hosts'])
    opt = cli.parser.parse_args(['--list-hosts', '--bar-host', 'host1', '--private-key', 'key1', '-i', 'inventory1'])
    cli.options = opt
    cli.post_process_args(opt)
    context.CLIARGS = cli.args
    assert context.CLIARGS.bar_host == 'host1'
    assert context.CLIARGS.private_key_file == 'key1'
    assert context.CLIARGS.inventory == 'inventory1'

# Generated at 2022-06-20 13:13:30.894835
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # create mock parser object
    parser_mock = CLIMockedParser()

    # create mock options
    options_mock = CLIMockedOptions()

    # set defaults
    options_mock.verbosity = 4
    options_mock.listhosts = False
    options_mock.listtags = False
    options_mock.check = False
    options_mock.syntax = False
    options_mock.become = False
    options_mock.become_method = ''
    options_mock.become_user = ''
    options_mock.become_ask_pass = False
    options_mock.ask_pass = False
    options_mock.private_key_file = ''
    options_mock.listtasks = False
    options_mock.list_hosts = ''

# Generated at 2022-06-20 13:13:36.230398
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
   pbcli = PlaybookCLI()
   pbcli.parser = pbcli._init_parser()
   pbcli.init_parser()
   pbcli.args = ["--help"]

   pbcli.run()

# Generated at 2022-06-20 13:13:38.316703
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    '''
    Unit test for method init_parser of class PlaybookCLI
    '''
    pass


# Generated at 2022-06-20 13:14:00.550189
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class Options():
        def __init__(self):
            self.listhosts = False
            self.listtasks = False
            self.listtags = False
            self.syntax = False
            self.flush_cache = False
            self.verbosity = False

    class Context():
        def __init__(self):
            self.CLIARGS = Options()

    context.CLIARGS = Context()

    class FakeInventory():
        def __init__(self):
            self.list_hosts = lambda : ['test_host']
            self.get_hosts = lambda x: ['test_host']

    class FakeVariableManager():
        def __init__(self):
            self.get_vars = lambda x: {'test_var': 'test_value'}

# Generated at 2022-06-20 13:14:04.235612
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    raise NotImplementedError

# Generated at 2022-06-20 13:14:06.274041
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI('playbook')
    assert cli.parser is not None


# Generated at 2022-06-20 13:14:08.335741
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    p = PlaybookCLI([])
    return p

# Generated at 2022-06-20 13:14:18.888649
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a dummy host
    test_host = type('test_host', (object,), {'name': 'test_name', 'get_name.return_value': 'test_name', '__str__.return_value': 'test_name'})()

    # Create a dummy playbook
    test_playbook = type('test_playbook', (object,), {'name': 'test_name', 'tags': [], 'hosts.return_value': [test_host], 'get_name.return_value': 'test_playbook'})()

    # Create a dummy loader
    test_loader = type('test_loader', (object,), {'set_basedir.return_value': None})()

    # Create a dummy inventory

# Generated at 2022-06-20 13:14:27.888510
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    '''
    This method tests the following:
        - ``display.verbosity`` is set to the value of ``options.verbosity``
        - ``validate_conflicts`` is called with the parameters ``runas_opts`` and ``fork_opts`` both set to True

    This method relies on the following fixture:
        - ``PlaybookCLI`` object named ``cls``

    This method mocks the following method:
        - ``get_default_options`` from class ``CLI``

    This method performs and assertions on the following objects:
        - ``display.verbosity``
    '''
    # Arrange
    options = {
        'verbosity': 99
    }
    with patch.object(CLI, 'get_default_options', return_value = options):
        # Act
        actual = cls.post_process_

# Generated at 2022-06-20 13:14:38.827629
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    display.verbosity = False
    cli = PlaybookCLI()
    cli.post_process_args(cli.parser.parse_args([]))
    inventory = cli.inventory

    # No args
    assert len(inventory.hosts) == 0
    assert len(inventory.list_hosts()) == 1

    # Empty args
    cli.post_process_args(cli.parser.parse_args(['']))
    assert len(inventory.hosts) == 0
    assert len(inventory.list_hosts()) == 1

    # One empty arg
    cli.post_process_args(cli.parser.parse_args(['', '']))
    assert len(inventory.hosts) == 0
    assert len(inventory.list_hosts()) == 1

    # One empty arg, no empty host
    inventory

# Generated at 2022-06-20 13:14:51.658962
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    Unit test for method run of class PlaybookCLI
    '''
    import unittest

    # https://stackoverflow.com/questions/9191668/override-init-and-call-init-of-base-class-in-python
    class TestPlaybookCLI(PlaybookCLI):
        ''' PlaybookCLI subclass for testing purpose '''
        def __init__(self, *args, **kwargs):
            '''
            Constructor
            '''
            super().__init__(*args, **kwargs)

    class MockDisplay():
        ''' Mock class for Display '''
        def __init__(self, *args, **kwargs):
            '''
            Constructor
            '''


# Generated at 2022-06-20 13:14:56.648627
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    # test for constructor of class PlaybookCLI
    parser = PlaybookCLI.create_parser(None)
    args = ['ansible', '-i', 'my.inventory', 'my.playbook']
    options = parser.parse_args(args)
    assert options.inventory == ['my.inventory']
    assert options.args == ['my.playbook']

# Generated at 2022-06-20 13:14:57.311697
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:15:24.098958
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # constructor of class PlaybookCLI
    # PlaybookCLI._ask_passwords()
    # PlaybookCLI.ask_passwords()
    # PlaybookCLI._flush_cache()
    # PlaybookCLI.run()
    # PlaybookCLI.parse()
    pass

# Generated at 2022-06-20 13:15:25.796616
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    assert cli.parser


# Generated at 2022-06-20 13:15:26.968475
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb = PlaybookCLI()
    assert pb is not None

# Generated at 2022-06-20 13:15:38.079748
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    playbookcli = PlaybookCLI()
    playbookcli.init_parser()

    assert playbookcli.parser._actions[0].dest == 'version'
    assert playbookcli.parser._actions[1].dest == 'inventory-file'
    assert playbookcli.parser._actions[2].dest == 'listhosts'
    assert playbookcli.parser._actions[3].dest == 'subset'
    assert playbookcli.parser._actions[4].dest == 'module-path'
    assert playbookcli.parser._actions[5].dest == 'extra-vars'
    assert playbookcli.parser._actions[6].dest == 'forks'
    assert playbookcli.parser._actions[7].dest == 'ask-vault-pass'
    assert playbookcli.parser._actions[8].dest == 'vault-password-file'
    assert playbookcli.parser

# Generated at 2022-06-20 13:15:39.879602
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # TODO: implement this
    pass

# Generated at 2022-06-20 13:15:44.259483
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    b_cli = PlaybookCLI()
    b_parser = b_cli.init_parser()

    assert isinstance(b_parser, b_cli.parser.__class__) == True


# Generated at 2022-06-20 13:15:48.573209
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    cli = PlaybookCLI(["ansible-playbook","--list-tasks","playbook.yml","playbook2.yml"])
    assert cli.parser._positionals.title == "Playbook(s)"
    assert cli.parser._positionals.metavar == "playbook"
    assert cli.parser._positionals.nargs == '+'
    assert cli.parser.description == "Runs Ansible playbooks, executing the defined tasks on the targeted hosts."

    cli = PlaybookCLI(["ansible-playbook", "--list-tasks", "playbook.yml", "playbook2.yml"])
    assert cli.parser._positionals.title == "Playbook(s)"
    assert cli.parser._positionals.metavar == "playbook"

# Generated at 2022-06-20 13:15:56.405095
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.plugins.loader import add_all_plugin_dirs, get_all_plugin_loaders
    from ansible.utils import context_objects as co

    class FakePlaybookExecutor:
        def __init__(self, playbooks, inventory, variable_manager, loader, passwords):
            pass

        def run(self):
            all_vars = {}
            all_vars['play_hosts'] = AnsibleSequence()
            all_vars['play_hosts'].append('127.0.0.1')
            all_vars['play_hosts'].append('localhost')
            all_vars['play_gather_subset'] = Ansible

# Generated at 2022-06-20 13:16:04.708341
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    import os
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import StringIO

    class PlaybookCLITest(PlaybookCLI):
        def get_optparser(self):
            import json
            class OptParser():
                def __init__(self):
                    self.args = ['vagrant.yml']
                    self.verbosity = 1
                    self.listhosts = False
                    self.listtags = False
                    self.listtasks = False
                    self.syntax = False
                    self.connection = 'ssh'
                    self.timeout = 10
                    self.private_key_file = '~/.ssh/id_rsa'
                    self.remote_user = 'vagrant'
                    self.remote_pass = None
                    self.sudo = False

# Generated at 2022-06-20 13:16:06.868006
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    my_playbook = PlaybookCLI()
    #assert isinstance(my_playbook, PlaybookCLI)


# Generated at 2022-06-20 13:16:36.881233
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI(['playbook.yml'])
    assert cli.args == ['playbook.yml']

# Generated at 2022-06-20 13:16:46.725219
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    class MockedPlaybookCLI(PlaybookCLI):
        def __init__(self, args):
            # class variables are used to avoid passing arguments to the constructor
            self.args = args
        def init_parser(self):
            self.parser = None
        def run(self):
            self.post_process_args(self.args)

    # with no verbosity arg, display.verbosity is set to 0
    args = {'verbosity': 0}
    cli = MockedPlaybookCLI(args)
    assert display.verbosity == 0

    # with '-v' as verbosity arg, display.verbosity is set to 1
    args = {'verbosity': 1}
    cli = MockedPlaybookCLI(args)
    assert display.verbosity == 1
    assert args['verbosity'] == 1

# Generated at 2022-06-20 13:16:48.455039
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    playbook_cli = PlaybookCLI()
    playbook_cli.init_parser()


# Generated at 2022-06-20 13:17:00.304618
# Unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-20 13:17:07.628287
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI()
    cli.parser = cli.create_parser()
    cli.options, cli.args = cli.parser.parse_args(['-k', '-K', '-u', 'myusername', '-U', 'myotherusername',
                                                   '-v', '-vvvv', '-l', 'all', '--private-key',
                                                   '~/.ssh/id_rsa', '-i', 'localhost,'])
    cli.post_process_args(cli.options)
    assert context.CLIARGS['ask_pass'] is True
    assert context.CLIARGS['ask_su_pass'] is True
    assert context.CLIARGS['ask_sudo_pass'] is True

# Generated at 2022-06-20 13:17:19.418747
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(None, False)

    parser = cli.init_parser()
    cli_args = parser.parse_args([])

    #
    # Make sure that all options of the base class are here
    #
    # This is not the ideal way to test the method.
    #
    # The ideal way would parse the help and make sure that all the options of
    # the base class are there. Unfortunately, this is not possible since the
    # help is not easily parsed.
    #
    assert cli_args.check
    assert cli_args.host_key_checking
    cli_args.help
    assert cli_args.inventory
    assert cli_args.listhosts
    assert cli_args.listtags
    assert cli_args.listtasks
    assert cli_

# Generated at 2022-06-20 13:17:32.884646
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import sys
    # Mocking
    pb_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, pb_dir)
    from ansible.cli import CLI
    from ansible.cli import PlaybookCLI
    from ansible.plugins.loader import _get_all_plugin_loaders
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-20 13:17:34.393758
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI()
    assert isinstance(cli, PlaybookCLI)

# Generated at 2022-06-20 13:17:42.770767
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    from ansible.utils.display import Display
    from ansible.plugins.loader import add_all_plugin_dirs, add_directory
    from ansible.cli import CLI

    display = Display()
    display.verbosity = 3
    # The logs will be produced only if log_path is specified.
    if False:
        # Since _init_logger() will be called in CLI._process_args(), log_path has to be specified ahead of time.
        display.log_path = "/tmp/test_PlaybookCLI_post_process_args.log"
        # _init_logger() in CLI._process_args() will use "log_path" of "display" instead.
        CLI.log_path = None

# Generated at 2022-06-20 13:17:43.988223
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    assert PlaybookCLI()

# Generated at 2022-06-20 13:18:43.702029
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:18:53.728414
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    import argparse

    parser = argparse.ArgumentParser()
    args = [
        '-i', 'hosts',
        '-v',
        'playbooks/basic.yaml',
        '-l', 'host',
    ]

    # PlaybookCLI.init_parser(self, usage=usage, desc=description)
    cli = PlaybookCLI(parser)
    cli.parse(args)
    assert 'basic.yaml' in cli.args



# Generated at 2022-06-20 13:19:02.363831
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    # create CLI object
    cli = PlaybookCLI(['playbook', '--list-tasks', '-vvv'])

    # set up args
    cli.run()

    # Verify args are set
    assert cli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert cli.parser._actions[13].dest == 'listtasks'
    assert cli.parser._actions[13].const is True
    assert cli.parser._actions[13].default is False
    assert cli.parser._actions[13].option_strings == ['-l', '--list-tasks']

# Generated at 2022-06-20 13:19:06.237933
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(['playbook.yml'])

# Generated at 2022-06-20 13:19:09.060494
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb = PlaybookCLI(args="playbook.yml")
    assert type(pb) is PlaybookCLI


# Generated at 2022-06-20 13:19:10.945963
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # TODO: mock self.args
    pass


# Generated at 2022-06-20 13:19:16.845255
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # A class, subclass of PlaybookCLI and with modified 'init_parser'
    class MockPlaybookCLI():
        '''  Create a class that only overrides the method, 'init_parser' '''
        def init_parser(self):
            return 'parser'

    # pass the test by returning the required parser
    assert MockPlaybookCLI().init_parser() == 'parser'

# Generated at 2022-06-20 13:19:19.499036
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    playbook_cli = PlaybookCLI()
    playbook_cli.init_parser()
    assert isinstance(playbook_cli.parser, opt_help.Parser)

# Generated at 2022-06-20 13:19:32.737191
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    class Options:
        def __init__(self):
            self.connection = 'smart'
            self.verbosity = 0
            self.timeout = 10
            self.check = False
            self.syntax = False
            self.listhosts = False
            self.listtasks = False
            self.listtags = False
            self.step = False
            self.start_at_task = None
            self.ask_vault_pass = False
            self.vault_password_file = None
            self.new_vault_password_file = None
            self.ask_become_pass = False
            self.become_ask_pass = False
            self.ask_pass = False
            self.private_key_file = None
            self.remote_user = None
            self.module_path = None
            self

# Generated at 2022-06-20 13:19:40.046210
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import unittest
    import sys
    import os
    from ansible.cli.playbook import PlaybookCLI
    from ansible.module_utils.six import StringIO

    class TestPlaybookCLI(unittest.TestCase):
        def setUp(self):
            self.pb = PlaybookCLI(args=['ansible/test/unit/cli/ansible-playbook/dummy.yml'])
            sys.argv = ['ansible-playbook', 'ansible/test/unit/cli/ansible-playbook/dummy.yml']
            self.pb.optsfile = os.devnull


# Generated at 2022-06-20 13:22:17.148680
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Method is static, so we need to fake a class
    import collections
    PlaybookCLI = collections.namedtuple('PlaybookCLI', ['_cli_options'])

    # Create a fake parser and add all options
    from ansible.cli.arguments import option_helpers as opt_help
    fake_parser = opt_help.create_base_parser(constants=None)
    opt_help.add_connect_options(fake_parser)
    opt_help.add_meta_options(fake_parser)
    opt_help.add_runas_options(fake_parser)
    opt_help.add_subset_options(fake_parser)
    opt_help.add_check_options(fake_parser)
    opt_help.add_inventory_options(fake_parser)
    opt_help.add_

# Generated at 2022-06-20 13:22:21.899778
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    """Unit test for method post_process_args of class PlaybookCLI"""

    import argparse
    import os
    import sys

    test_args = [sys.argv[0], 'one.yml', 'two.yml', '--list-hosts']

    # use tempfile to setup a temp dir with some test yml files.
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    temp_yml_one = os.path.join(tmp_dir, 'one.yml')

    with open(temp_yml_one, 'w') as fout:
        fout.write('---\n- hosts: test_hosts\n  tasks:\n    - debug: msg="first"\n')


# Generated at 2022-06-20 13:22:23.172763
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # Print help message
    PlaybookCLI([])

# Generated at 2022-06-20 13:22:26.191525
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    """
    Unit test for method init_parser of class PlaybookCLI
    """
    play = PlaybookCLI()
    assert play.parser is not None
