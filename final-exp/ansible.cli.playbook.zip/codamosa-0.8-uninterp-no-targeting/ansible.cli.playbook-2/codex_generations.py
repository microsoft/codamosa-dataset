

# Generated at 2022-06-20 13:12:55.303763
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(['It is a test string'])
    cli.init_parser()
    assert cli.parser._actions[1].dest == 'listhosts'
    assert cli.parser._actions[1].help == 'list all hosts matched by pattern'
    assert cli.parser._actions[2].dest == 'listtasks'
    assert cli.parser._actions[2].help == 'list all tasks that would be executed'
    assert cli.parser._actions[3].dest == 'listtags'
    assert cli.parser._actions[3].help == 'list all available tags'
    assert cli.parser._actions[4].dest == 'step'
    assert cli.parser._actions[4].help == 'one-step-at-a-time: confirm each task before running'
    assert cl

# Generated at 2022-06-20 13:12:57.937432
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    '''Unit test for method post_process_args of class PlaybookCLI'''
    assert PlaybookCLI().post_process_args({})

# Generated at 2022-06-20 13:12:58.664263
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pass

# Generated at 2022-06-20 13:13:04.356346
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Injecting mocks
    mock_pbex = MockPlaybookExecutor()
    mock_cli = PlaybookCLI()
    mock_cli.play_prereqs = MockPlayPrereqs()
    mock_cli.ask_passwords = MockAskPasswords()

    mock_cli.run()
    mock_pbex.run.assert_called_with()


# Generated at 2022-06-20 13:13:05.165449
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:13:08.555027
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    assert 'usage' in cli.parser._actions[2].option_strings
    assert '--flush-cache' in cli.parser._actions[2].option_strings


# Generated at 2022-06-20 13:13:11.890263
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pbcli = PlaybookCLI(['dummy'])
    pbcli.options = opt_help.parse_options([])
    pbcli.post_process_args(pbcli.options)
    pbcli.run()

# Generated at 2022-06-20 13:13:15.118869
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = PlaybookCLI().init_parser()
    args = ['-i', 'localhost,', 'playbook.yml', 'playbook2.yml']
    options = parser.parse_args(args)
    assert options.args == ['playbook.yml', 'playbook2.yml']

# Generated at 2022-06-20 13:13:22.089527
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    import os
    import tempfile
    import shutil
    import sys
    import ansible
    from ansible.playbook.play import Play

    this_dir, this_filename = os.path.split(__file__)
    test_file = os.path.join(this_dir, 'test_playbook_post_process')

    # TODO: replace with playbook_cli subclass
    class PrefixedCLI(PlaybookCLI):
        def __init__(self, args):
            super(PrefixedCLI, self).__init__()
            self.args = args


# Generated at 2022-06-20 13:13:25.418823
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    ''' Unit test for constructor of class PlaybookCLI '''

    # Test creation of object
    playbook_cli = PlaybookCLI()
    assert playbook_cli is not None

# Generated at 2022-06-20 13:13:37.333232
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    """
    This is a unit test for the constructor of class PlaybookCLI
    """
    p = PlaybookCLI(args=['-h'])
    assert p

# Generated at 2022-06-20 13:13:45.894722
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # fail without playbook
    try:
        PlaybookCLI([])
    except AnsibleError:
        pass
    else:
        raise AssertionError('Failed to raise AnsibleError without playbook')

    # fail with an invalid playbook
    try:
        PlaybookCLI(['not_a_real_playbook'])
    except AnsibleError:
        pass
    else:
        raise AssertionError('Failed to raise AnsibleError with an invalid playbook')

    # succeed with minimal valid playbook
    PlaybookCLI(['playbook.yml'])

# Generated at 2022-06-20 13:13:58.409032
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Create a test PlaybookCLI object via the init_parser hook
    # that is called from the command-line
    test_cli = CLI()
    test_cli.init_parser()
    test_cli.options = test_cli.parser.parse_args(['playbook.yml', 'playbook2.yml'])
    test_cli.post_process_args(test_cli.options)

    # Create a test PlaybookCLI object without init_parser hook
    test_PlaybookCLI = PlaybookCLI()
    test_PlaybookCLI.options = test_cli.parser.parse_args(['playbook.yml', 'playbook2.yml'])
    test_PlaybookCLI.options.verbose = True

    # Assert that the attribute 'verbose' is changed to 'verbosity'


# Generated at 2022-06-20 13:14:10.388369
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # create class instance and create/add arguments
    cli = PlaybookCLI(args=['-vvvv'])

    # create the parser
    cli.init_parser()

    # insert global args in the command line
    sys.argv.extend(['-vvvv', 'foo.yml'])

    # build options from the command line
    options, args = cli.parser.parse_args()

    # post process the options
    options = cli.post_process_args(options)

    # execute run method
    with pytest.raises(AnsibleError):
        cli.run()

# Generated at 2022-06-20 13:14:20.949984
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI()
    cli.setup()
    options = cli.parse()
    ansible_vars = C.config.load_config_file()

    # test for normal case - hash of options should be 0
    new_options = cli.post_process_args(options)
    assert hash(new_options) == 0

    # test for show_custom_stats case - hash of options should be 0
    new_options.show_custom_stats = True
    new_options = cli.post_process_args(new_options)
    assert hash(new_options) == 0

    # test for skip_tags case - hash of options should be 0
    new_options.skip_tags = "test"
    new_options = cli.post_process_args(new_options)

# Generated at 2022-06-20 13:14:33.724070
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Create a playbook_cli object
    playbook_cli = PlaybookCLI()

    # Check to see that a dict is returned

# Generated at 2022-06-20 13:14:42.178689
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    """
    This test case covers the different calls of init_parser() of class PlaybookCLI
    :return:
    """

    # Pass the object of class PlaybookCLI to get the object of class OptionParser
    # so that test case could verify the options defined in OptionParser object
    obj_PlaybookCLI = PlaybookCLI()
    obj_PlaybookCLI.init_parser()
    obj_OptionParser = obj_PlaybookCLI.parser

    # Verify the usage of OptionParser object
    assert obj_OptionParser.usage == '%prog [options] playbook.yml [playbook2 ...]'

    # Verify the description of OptionParser object
    assert obj_OptionParser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'

    obj_ArgumentParser = obj_PlaybookCLI.parser



# Generated at 2022-06-20 13:14:48.568050
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # This test uses get_bin_path method of CLITool() class which uses find_executable()
    # to find a binary which is not available on windows, therefore it is necessary
    # to stub this method to avoid an error
    import shutil
    shutil.which = lambda name: name

    playbook_cli = PlaybookCLI()

# Generated at 2022-06-20 13:14:51.423096
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli_args = ['test.yml']
    cli = PlaybookCLI(args=cli_args)
    parser = cli.init_parser()
    assert parser

# Generated at 2022-06-20 13:14:54.762793
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    assert isinstance(cli, PlaybookCLI)
    cli.parse()
    assert cli.parser is not None

# Generated at 2022-06-20 13:15:19.806886
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:15:22.170839
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    a = PlaybookCLI()
    a.post_process_args({'verbosity': 3})
    a.parse()

# Generated at 2022-06-20 13:15:30.461462
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    parser = PlaybookCLI.base_parser(
        usage="%prog [options] playbook.yml [playbook2 ...]",
        connect_opts=True,
        meta_opts=True,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        inventory_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        async_opts=True,
    )
    opt_help.add_cli_options(parser)
    options = parser.parse_args([])
    handler = PlaybookCLI(parser, options)
    handler.post_process_args(options)
    assert not options.ask_pass

# Generated at 2022-06-20 13:15:38.160455
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    def mock_super_init_parser(self, usage, desc):
        self.usage = usage
        self.desc = desc

    # mock super class
    CLI.init_parser = mock_super_init_parser

    # execute method
    cli = PlaybookCLI()
    cli.init_parser()

    # make assertions
    assert cli.usage == "%prog [options] playbook.yml [playbook2 ...]"
    assert cli.desc == "Runs Ansible playbooks, executing the defined tasks on the targeted hosts."

    # delete mock
    del CLI.init_parser

# Generated at 2022-06-20 13:15:45.522052
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #set some param for test
    context._init_global_context(['ansible-playbook', 'test_playbook.yml', '-i', 'localhost,', '--list-tasks'])
    context.CLIARGS['listhosts'] = True
    #call the method
    pb = PlaybookCLI()
    pb.run()

# Generated at 2022-06-20 13:15:47.156641
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    Test for method run of class PlaybookCLI
    '''
    pass

# Generated at 2022-06-20 13:15:55.947284
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    Unit test for class PlaybookCLI

    Need to test the following:
    1. PlaybookCLI().run() is not started unless CLI.parse() is successful
    2. Parsing error

    '''
    # Test case 1: test if method run is not invoked without CLI.parse()
    # mock object
    def mock_parse():
        return True
    # mock class
    class MockPlaybookCLI:
        def __init__(self):
            self.run_method_invoked = False
        def run(self):
            self.run_method_invoked = True

    # mock method
    PlaybookCLI.parse = mock_parse

    pbcli = MockPlaybookCLI()

    pbcli.run()

# Generated at 2022-06-20 13:16:03.742689
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Test the case that object of PlaybookCLI is created.
    def TestPlaybookCLI():
        TestPlaybookCLI.TestParser = opt_help.create_base_parser(constants.DEFAULT_MODULE_PATH,
                                                                 constants.DEFAULT_MODULE_NAME,
                                                                 constants.DEFAULT_MODULE_ARGS)
        return PlaybookCLI(TestPlaybookCLI.TestParser)
    TestPlaybookCLIObject = TestPlaybookCLI()
    assert TestPlaybookCLIObject is not None

# Generated at 2022-06-20 13:16:12.673520
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    ''' this function is used as unit test for class PlaybookCLI '''
    from mock import MagicMock, call
    from ansible.cli.playbook import PlaybookCLI
    from ansible.cli import CLI

    # create mock objects

# Generated at 2022-06-20 13:16:17.014791
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    '''
    Test init_parser method of class PlaybookCLI
    '''
    # TODO: uncomment this code when we have implemented the method
    # pbcli = PlaybookCLI()
    # pbcli.init_parser()
    pass



# Generated at 2022-06-20 13:17:16.234982
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # should raise error with no required arguments defined
    try:
        PlaybookCLI().parse()
        assert False
    except SystemExit as ex:
        if ex.code != 2:
            assert False
        assert True

    # should be ok when required arguments are defined
    cli = PlaybookCLI(['--connection', 'local', 'test-playbook.yml'])
    result = cli.parse()
    assert type(result) == AnsibleOptions

# Generated at 2022-06-20 13:17:18.000687
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    """docstring for test_PlaybookCLI"""
    pass

# Generated at 2022-06-20 13:17:21.130908
# Unit test for constructor of class PlaybookCLI

# Generated at 2022-06-20 13:17:25.793209
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a class instance of PlaybookCLI
    instance = PlaybookCLI()

    # Check if the function run (inherited by class CLI) is called
    instance.run()

    # This test is successful if no exception is raised

# Generated at 2022-06-20 13:17:28.148025
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    args = []
    pb_cli = PlaybookCLI(args)
    assert pb_cli

# Generated at 2022-06-20 13:17:38.802902
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # create a fake instance of class PlaybookCLI
    test_pbcli = PlaybookCLI()

    # create a fake list of args
    test_args = ['a', 'b', 'c', '-k', '-r', 'd']
    assert test_args == context.CLIARGS['args']

    # Test with -k & -r
    test_pbcli.post_process_args(test_args)
    assert {} == context.CLIARGS['ask_pass']
    assert {} == context.CLIARGS['ask_su_pass']
    assert None == context.CLIARGS['private_key_file']
    assert None == context.CLIARGS['remote_user']

    # Test with -K & -R

# Generated at 2022-06-20 13:17:51.138525
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.errors import AnsibleError
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    class FakeOptions:
        verbosity = 0
        listhosts = False
        subset = None
        listtasks = False
        listtags = False
        flush_cache = False
        list_tasks = False
        list_tags = False
        step = False
        start_at_task = None
        args = None
        connection = 'ssh'
        remote_user = None
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args

# Generated at 2022-06-20 13:17:55.743867
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    """
    This function tests the __init__ function of PlaybookCLI
    Returns:
        excepted result
    """
    cli = PlaybookCLI()
    assert isinstance(cli, PlaybookCLI)
    assert 'run' in dir(cli)

# Generated at 2022-06-20 13:18:01.922217
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #
    # We need a fake class to test private methods
    #
    class TestPlaybookCLI(PlaybookCLI):
        def __init__(self):
            pass

        def _play_prereqs(self):
            class FakePlaybookExecutor:
                def __init__(self):
                    pass

                def run(self):
                    return []

            loader = None
            inventory = None
            variable_manager = None
            return (loader, inventory, variable_manager)

        def _flush_cache(self, inventory, variable_manager):
            pass
    #
    # Actual test method
    #
    tpc = TestPlaybookCLI()
    tpc.run()

# Generated at 2022-06-20 13:18:06.104797
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(args=[])
    cli.options, cli.args = cli.parser.parse_known_args()
    cli.post_process_args(cli.options)
    assert cli.options.verbosity >= 0


# Generated at 2022-06-20 13:20:15.660825
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:20:17.030487
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    play = PlaybookCLI()
    play.init_parser()



# Generated at 2022-06-20 13:20:17.799988
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:20:24.888554
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.executor.task_queue_manager import TaskQueueManager

    # create a fake file for ansible-playbook
    # create a fake argv for ansible-playbook
    # initialize a mock class for PlaybookCLI
    # call run() method

    mock_class = PlaybookCLI([])

    # with patch.object(mock_class, '_play_prereqs', return_value=(None, None, None)):
    #     with patch.object(mock_class, '_flush_cache', return_value=None):
    #         with patch.object(mock_class, 'ask_passwords', return_value=(None, None)):
    #             with patch.object(mock_class, 'post_process_args', return

# Generated at 2022-06-20 13:20:29.319976
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(['-h'])
    assert cli.parser.get_default_values().fork == 5
    assert cli.parser.get_default_values().module_name == 'command'


# Generated at 2022-06-20 13:20:32.197299
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pbcli = PlaybookCLI(["/home/user/testing.yml"])
    assert pbcli.parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'

# Generated at 2022-06-20 13:20:39.094458
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    class Object(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    p = PlaybookCLI()


# Generated at 2022-06-20 13:20:40.056663
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:20:44.510404
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    p = PlaybookCLI()
    p.init_parser()
    opts = p.parser.option_list
    assert opts.__contains__('--list-tasks')


# Generated at 2022-06-20 13:20:45.973406
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''Unit test for method run of class PlaybookCLI'''
    pass