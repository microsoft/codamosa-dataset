

# Generated at 2022-06-20 13:12:48.596829
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    # Note:  This function is only used to unit test the constructor of
    #        class PlaybookCLI.  It is not used during normal execution of
    #        Ansible programs.

    # Create source for argparse
    argparse_obj = PlaybookCLI()

    # Create parser for CLI options
    argparse_obj.init_parser()

    # Create options for CLI arguments
    argparse_obj.init_options()

    # Test constructor of class PlaybookCLI
    instance = PlaybookCLI()

# Generated at 2022-06-20 13:12:54.550266
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    class Mock():

        def __init__(self):
            self.args = []

        def add_argument(self, *args, **kwargs):
            self.args.append((args, kwargs))

    p = PlaybookCLI()

    mock_parser = Mock()
    p.init_parser(mock_parser)

    assert mock_parser.args[0] == (('-k', '--ask-pass'), {'dest': 'ask_pass', 'action': 'store_true',
                                                          'help': "ask for connection password"})


# Generated at 2022-06-20 13:13:02.165401
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Test execution of the method against valid and invalid values.
    # Valid
    p = PlaybookCLI(args=['ansible-playbook', '--version'])
    p.init_parser()
    assert p.parser is not None
    # Invalid
    p = PlaybookCLI(args=['ansible-playbook', '--bad_option'])
    try:
        p.init_parser()
        assert False
    except SystemExit:
        assert True

# Generated at 2022-06-20 13:13:12.831227
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    display = Display()
    display.verbosity = 3
    inventory = None
    loader = None
    variable_manager = None
    cli = PlaybookCLI(
        args=['/opt/projects/ansible/playbooks/test.yml'],
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
    )
    cli.parse()
    if hasattr(cli, 'module_path'):
        module_path = cli.module_path
    else:
        module_path = None
    cli.post_process_args(module_path=module_path)
    context.CLIARGS['diff'] = True
    context.CLIARGS['flush_cache'] = False
    context.CLIARGS['listhosts'] = False
    context.CLI

# Generated at 2022-06-20 13:13:20.507241
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    os.environ["ANSIBLE_CONFIG"] = "tests/ansible.cfg"
    cli = PlaybookCLI()
    cli.init_parser()

    # check for parser for CLI options
    assert cli.parser is not None
    # check if usage and description match
    assert cli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert cli.parser.description == '''Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'''

    # check the existence of options added by add_connect_options
    assert cli.parser.has_option('--connection')
    assert cli.parser.has_option('--module-path')
    assert cli.parser.has_option('--forks')

# Generated at 2022-06-20 13:13:32.131238
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    #test PlaybookCLI.post_process_args with different settings
    #
    #test with no-opts
    cli = PlaybookCLI(args=[])
    cli.parser = CLI.base_parser(
        constants=constants,
        runas_opts=True,
        meta_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        connection_opts=True,
        subparser_loader=CLI.load_subparsers,
    )
    context.CLIARGS = cli.parser.parse_args(args=[])
    assert not cli.post_process_args(context.CLIARGS)

    #test with --list-hosts
   

# Generated at 2022-06-20 13:13:40.835246
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pl = PlaybookCLI(['/path/to/playbook.yml'])
    if not isinstance(pl, PlaybookCLI):
        raise Exception("Not a PlaybookCLI object")
    if not isinstance(pl.parser, CLI.base_parser):
        raise Exception("Not a base_parser object")
    if not isinstance(pl.display, Display):
        raise Exception("Not a Display object")
    if not isinstance(pl.basedir, to_bytes):
        raise Exception("Not a unicode string")

# Generated at 2022-06-20 13:13:41.478130
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-20 13:13:50.692140
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI(['-i', 'localhost,', '-e', '@test_vars.yml', '-t', 'tag1,tag2',
                       '-l', 'tag2', '-vvvv', '--syntax-check', '--list-tasks', '--list-tags', '--step',
                       '--start-at-task', 'Test_Task_1'])

    assert cli.options.connection == 'smart'
    assert cli.options.verbosity == 4
    assert cli.options.inventory == ['localhost,']
    assert cli.options.extra_vars == ['@test_vars.yml']
    assert cli.options.tags == ['tag1', 'tag2']
    assert cli.options.limit == 'tag2'

# Generated at 2022-06-20 13:13:53.671773
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI()
    cli.parse()
    cli.post_process_args(cli.args)
    cli.run()

# Generated at 2022-06-20 13:14:05.704963
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    playbook_cli = PlaybookCLI(['ansible-playbook', '--list-hosts'])
    playbook_cli.init_parser()
    playbook_cli.parse()
    assert context.CLIARGS['listhosts'] == True

# Generated at 2022-06-20 13:14:17.589853
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Test case 1
    # Test that one can set the verbosity level with -v
    case_1 = PlaybookCLI()
    case_1.init_parser()
    args = ['-v']
    options = case_1.parser.parse_args(args)[0]
    assert options.verbosity == 2
    assert options.syntax == False
    assert options.listhosts == False
    assert options.listtags == False
    assert options.listtasks == False
    assert options.step == False
    assert options.start_at_task == None
    assert options.args == []

    # Test case 2
    # Test that one can set the verbosity level with -vv
    case_2 = PlaybookCLI()
    case_2.init_parser()
    args = ['-vv']
    options = case_2

# Generated at 2022-06-20 13:14:27.042266
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI([])

# Generated at 2022-06-20 13:14:29.159327
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    assert cli.parser is not None

# Generated at 2022-06-20 13:14:31.328992
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(['-h'])
    assert cli.parser is not None

# Generated at 2022-06-20 13:14:33.776216
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    p = PlaybookCLI(args=[])
    assert isinstance(p, PlaybookCLI)
    assert isinstance(p, CLI)

# Generated at 2022-06-20 13:14:42.205108
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Arrange
    playbook_cli = PlaybookCLI()
    playbook_cli.parser = opt_help.get_optparser()

    playbook_cli.options, playbook_cli.args = playbook_cli.parser.parse_args()
    playbook_cli.options.connection = 'ssh'
    playbook_cli.options.remote_user = 'admin'
    playbook_cli.options.verbosity = 0
    playbook_cli.args = ['playbook.yml']

    # Act
    options = playbook_cli.post_process_args(playbook_cli.options)

    # Assert
    assert options.connection == 'ssh'
    assert options.remote_user == 'admin'
    assert options.verbosity == 0
    assert playbook_cli.args == ['playbook.yml']
    assert playbook_cli.args[0]

# Generated at 2022-06-20 13:14:46.494405
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.cli.arguments import OPTION_BOOLEANS

    # Load fixture
    class Options(object):
        pass
    options = Options()
    for key in OPTION_BOOLEANS:
        setattr(options, key, None)
    options.sudo_user = None
    options.sudo = None
    options.verbosity = None
    options.check = False
    options.step = False
    options.start_at_task = None
    options.subset = None
    options.diff = False

    # Call method being tested
    result = PlaybookCLI._post_process_args(options)

    # Assert result
    assert result.check is False
    assert result.diff is False
    assert result.subset is None

    # Call method being tested again
    options.check = True
    options

# Generated at 2022-06-20 13:14:52.311108
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    assert cli.parser.prog == "ansible-playbook"
    assert cli.parser.usage.startswith("%prog [options] playbook.yml")
    assert cli.parser.description.startswith("Runs Ansible playbooks")

# Generated at 2022-06-20 13:15:01.875842
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test run without argument
    args = []
    with pytest.raises(SystemExit):
        cli = PlaybookCLI(args)
        cli.parse()

    # Test run with a valid playbook
    test_playbook = 'tests/test_playbook.yml'
    args = ['ansible-playbook', test_playbook]
    cli = PlaybookCLI(args)
    cli.parse()
    with pytest.raises(SystemExit) as pytest_wrap_excinfo:
        cli.run()
    assert pytest_wrap_excinfo == 0

    # Test run with a missing playbook
    args = ['ansible-playbook', '/tmp/test_playbook.yml']
    cli = PlaybookCLI(args)
    cli.parse()

# Generated at 2022-06-20 13:15:31.004891
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    import ansible.constants as C

    # success case: no conflicting arguments
    cli_args = ['-e', '@some_file.json']
    options = CLI.parse(args=cli_args, output_opts=False)
    post_processed_options = PlaybookCLI.post_process_args(options)
    assert post_processed_options == options

    # fail case: conflicting arguments
    cli_args = ['-e', '@some_file.json', '--ask-su-pass', '--ask-become-pass']
    options = CLI.parse(args=cli_args, output_opts=False)

# Generated at 2022-06-20 13:15:33.110040
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI()
    print(type(cli))

test_PlaybookCLI()

# Generated at 2022-06-20 13:15:42.138910
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    playbook = PlaybookCLI(['playbook.yaml', 'playbook2.yaml'])
    assert playbook.parser.prog == 'ansible-playbook'
    assert playbook.parser._actions[1].dest == 'listhosts'
    assert playbook.parser._actions[2].dest == 'listtasks'
    assert playbook.parser._actions[3].dest == 'listtags'
    assert playbook.parser._actions[4].dest == 'step'
    assert playbook.parser._actions[5].dest == 'start_at_task'
    assert playbook.parser._actions[6].dest == 'args'
    assert playbook.parser._actions[6].metavar == 'playbook'
    assert playbook.parser._actions[6].nargs == '+'

# Generated at 2022-06-20 13:15:54.277812
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    class TestPlaybookCLI(PlaybookCLI):
        def __init__(self):
            self.parser = CLI.base_parser(
                usage="%prog [options] playbook.yml [playbook2 ...]",
                desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts.")

    test_cli = TestPlaybookCLI()
    test_cli.parser.add_argument('-a', '--a-option', default=None, action='store', dest='a_option')
    test_cli.parser.add_argument('--b-option', default=None, action='store', dest='b_option')
    test_cli.parser.add_argument('--c-option', default=None, action='store', dest='c_option')

# Generated at 2022-06-20 13:15:58.203862
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pbcli = PlaybookCLI([])
    parser = pbcli.init_parser()
    assert parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'

# Generated at 2022-06-20 13:16:07.741190
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Make sure that the --version option is there
    parser = _PlaybookCLI_init_parser()
    assert parser.has_option('--version')

    # Make sure that the --help option is there
    assert parser.has_option('--help')
    assert parser.get_option('--help').help == 'Display this help message and exit'

    # Make sure the runas options are there
    assert parser.has_option('--user')
    assert parser.has_option('--become')
    assert parser.has_option('--become-user')
    assert parser.has_option('--become-method')

    # Make sure that the other options are there
    assert parser.has_option('-k')
    assert parser.has_option('--ask-pass')

# Generated at 2022-06-20 13:16:08.775975
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = PlaybookCLI.init_parser()
    assert parser is not None

# Generated at 2022-06-20 13:16:15.708632
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Create class under test
    cli_args = CLI.base_parser(constants=C, runas_opts=True, subset_opts=True, vault_opts=True, fork_opts=True, module_opts=True, check_opts=True, runtask_opts=True, connect_opts=True)
    cli_args.add_argument('--list-hosts', dest='listhosts', action='store_true',
                          help="outputs a list of matching hosts; does not execute anything else")
    cli_args.add_argument('--list-tasks', dest='listtasks', action='store_true',
                          help="list all tasks that would be executed")

# Generated at 2022-06-20 13:16:27.161889
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    cli = PlaybookCLI()
    cli.parser = opt_help.create_parser('ansible-playbook', '2.5')
    cli.init_parser()

    # Create test options and arguments
    test_opts = []
    test_args = ['/playbook.yml']

    # Create expected options and arguments
    expected_opts = {}
    expected_args = []

    # Set verbosity to 3
    for i in range(0, 3):
        test_opts.append('-v')
    expected_opts['verbosity'] = 3

    # Set connection to local
    test_opts.append('-c')
    test_opts.append('local')
    expected_opts['connection'] = 'local'

    # Set forks to 5

# Generated at 2022-06-20 13:16:31.262493
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Create a parser
    parser = CLI.parser()

    # Create a PlaybookCLI object
    pb_cli = PlaybookCLI(parser)

    # Check that parser contains all options with the correct default value
    assert pb_cli.parser._actions[1].default == 'smart'
    assert pb_cli.parser._actions[2].default == False
    assert pb_cli.parser._actions[3].default == False
    assert pb_cli.parser._actions[4].default == C.DEFAULT_SUBSET
    assert pb_cli.parser._actions[5].default == False
    assert pb_cli.parser._actions[6].default == C.DEFAULT_PRIVATE_KEY_FILE
    assert pb_cli.parser._actions[7].default == C.DEFAULT_HOST_LIST


# Generated at 2022-06-20 13:17:31.688585
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Arguments and options for ansible-playbook command
    pargs = ['--check', '--list-hosts', 'check-ssh.yml']
    pargs = pargs + ['--inventory-file', 'playbooks/inventory', '--list-tasks', '--step']
    pargs = pargs + ['--start-at-task', 'Get the number of machines from terraform output']
    cli = PlaybookCLI(args=pargs)
    cli.parse()
    cli.run()

# Main function to execute ansible-playbook command
if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-20 13:17:34.459320
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb = PlaybookCLI([])
    assert pb.parser is not None
    assert isinstance(pb, CLI)
    assert isinstance(pb, PlaybookCLI)

# Generated at 2022-06-20 13:17:42.769943
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """Test if method run of class PlaybookCLI works correctly."""

    # Test 1
    # Test if _flush_cache works correctly
    # Test if return value is zero(0) when it runs successfully
    # Test if return value is -1 when it failed

    context.CLIARGS = {}
    context.CLIARGS['listhosts'] = True
    context.CLIARGS['listtasks'] = True
    context.CLIARGS['listtags'] = True
    context.CLIARGS['subset'] = True
    context.CLIARGS['flush_cache'] = True
    context.CLIARGS['args'] = [True]

    class TestAnsibleParser:

        def __init__(self):
            pass


# Generated at 2022-06-20 13:17:43.928615
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pass


# Generated at 2022-06-20 13:17:56.338292
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI()
    cli.parse()
    cli.post_process_args(cli.options)
    assert context.CLIARGS['verbosity'] == 3
    assert context.CLIARGS['listtasks'] == False
    assert context.CLIARGS['listtags'] == False
    assert context.CLIARGS['step'] == False
    assert context.CLIARGS['start_at_task'] == None
    assert context.CLIARGS['args'][0] != None
    assert context.CLIARGS['check'] == False
    assert context.CLIARGS['connection'] == 'local'
    assert context.CLIARGS['module_path'] == None
    assert context.CLIARGS['forks'] == 5

# Generated at 2022-06-20 13:17:57.590784
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pbcli = PlaybookCLI()



# Generated at 2022-06-20 13:18:01.149102
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = PlaybookCLI().init_parser()
    assert parser.description == "Runs Ansible playbooks, executing the defined tasks on the targeted hosts."

# Generated at 2022-06-20 13:18:12.675887
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    test_playbook_cli = PlaybookCLI(['file'])
    test_data_loader = DataLoader()
    test_inventory = InventoryManager(loader=test_data_loader, sources=['localhost'])

    #To test for empty playbook
    test_playbook_cli.run()

    # To test for 'load_extra_vars' method
    test_variable_manager = test_playbook_cli.variable_manager
    test_variable_manager._extra_vars = {'extra_key': 'extra_value'}
    test_variable_manager._host_vars = {}

# Generated at 2022-06-20 13:18:26.125525
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    ''' unit test to test AnsibleModuleCLI in cli/adhoc.py '''

    # 1) use a subset of hosts
    cli = PlaybookCLI(['playbook', '--subset', 'hostname'])
    assert cli.args.subset == ['hostname']

    # 2) use a subset of hosts with a negative result
    cli = PlaybookCLI(['playbook', '--subset', '!hostname'])
    assert cli.args.subset == ['!hostname']

    # 3) use check mode (dry run)
    cli = PlaybookCLI(['playbook', '--check'])
    assert cli.args.check is True

    # 4) list hosts in inventory, should be localhost

# Generated at 2022-06-20 13:18:34.122629
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    # test with empty args
    def constructor_with_empty_args():
        return PlaybookCLI([])

    # test with too many args
    def constructor_with_too_many_args():
        return PlaybookCLI(['-i', '1', '-i', '2'])

    # test with bad short option
    def constructor_with_bad_short_option():
        return PlaybookCLI(['-x'])

    # test with bad long option
    def constructor_with_bad_long_option():
        return PlaybookCLI(['--badoption'])

    # test with bad option value
    def constructor_with_bad_option_value():
        return PlaybookCLI(['--timeout=-1'])

    # test with -o that requires an argument

# Generated at 2022-06-20 13:19:40.618846
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    PlaybookCLI()

# Generated at 2022-06-20 13:19:51.786015
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.errors import AnsibleError
    from optparse import OptionParser

    os.environ["ANSIBLE_ROLES_PATH"] = os.path.join(os.path.dirname(__file__), 'roles')

    class MockOptionParser(OptionParser):
        def __init__(self, **kwargs):
            OptionParser.__init__(self, **kwargs)

    # method to be tested
    _post_process_args = opt_help.post_process_args

    # test cases

    # get_opts should return OptionParser
    # test case - option parser
    opts = MockOptionParser()
    opts.add_option("-b", "--background", dest="background", default=1, type="int")

# Generated at 2022-06-20 13:19:55.809645
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    PlaybookCLI()


# Generated at 2022-06-20 13:20:00.703311
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = CLI()
    cli.init_parser()
    assert cli.parser._actions[-1].dest == 'subset'
    assert cli.parser._actions[-1].help == 'further limit selected hosts to an additional pattern'


# Generated at 2022-06-20 13:20:02.334542
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    test_instance = PlaybookCLI()
    test_instance.init_parser()

# Generated at 2022-06-20 13:20:10.142526
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    plugin_loader_mock = Mock()
    plugin_loader_mock.return_value.get_all.return_value = []
    setattr(ansible.plugins.loader, '_PluginLoader__singleton', plugin_loader_mock)

    cli = PlaybookCLI(args=['inventory'])
    cli.parser = Mock()
    cli.run()

    cli.parser.error.assert_called_once_with('At least one playbook file must be specified')

    cli = PlaybookCLI(args=['inventory', 'playbook'])
    cli.parser = Mock()
    cli.run()

    cli.parser.error.assert_called_once_with('the playbook: playbook could not be found')

    cli = PlaybookCLI(args=['inventory', '.ansible'])

# Generated at 2022-06-20 13:20:20.745950
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Test case 1 - set the verbosity level.
    # Expected result: verbosity = 3

    context.CLIARGS = {'verbosity': 3}
    expected_result = {'verbosity': 3}
    actual_result = PlaybookCLI.post_process_args(PlaybookCLI(), context.CLIARGS)
    assert actual_result == expected_result

    # Test case 2 - set the verbosity level.
    # Expected result: verbosity = 1.

    context.CLIARGS = {'verbosity': 1}
    expected_result = {'verbosity': 1}
    actual_result = PlaybookCLI.post_process_args(PlaybookCLI(), context.CLIARGS)
    assert actual_result == expected_result

# Generated at 2022-06-20 13:20:22.978876
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Create a PlaybookCLI object
    cli = PlaybookCLI()
    cli.init_parser()
    # The parser object has been initialized
    assert cli.parser



# Generated at 2022-06-20 13:20:34.653543
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    '''
    test post_process_args with various inputs
    '''
    cli = PlaybookCLI()
    cli.parser = CLI.base_parser(constants=C, usage='usage',
                                 output_opts=True, runas_opts=True,
                                 connect_opts=True, check_opts=True,
                                 module_opts=True, subset_opts=True,
                                 vault_opts=True, fork_opts=True,
                                 runtask_opts=True, stdvars_opts=True,
                                 mitogen_opts=True)
    # test with listing tasks
    with context.CLIARGS.push('-T'):
        with context.CLIARGS.update(verbosity=5):
            opts = cli.post

# Generated at 2022-06-20 13:20:40.623201
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(['./test_PlaybookCLI_post_process_args', '-vvvv', '--inventory=test/unittests/inventory', '--extra-vars=vars_file=test/unittests/extra_vars.yml', 'playbook.yml'])
    args = cli.post_process_args(cli.parser.parse_args())

    assert args.verbosity == 4
    assert args.inventory == 'test/unittests/inventory'
    assert args.extra_vars[0].split('=')[0] == 'vars_file'
    assert args.extra_vars[0].split('=')[1] == 'test/unittests/extra_vars.yml'

