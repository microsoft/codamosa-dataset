

# Generated at 2022-06-16 20:02:10.530379
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:11.031874
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:11.759913
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:12.644176
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-16 20:02:13.816292
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:14.377430
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:19.776507
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a PlaybookCLI object
    pb_cli = PlaybookCLI()

    # Create a parser object
    parser = pb_cli.create_parser()

    # Create a argparse namespace object
    args = parser.parse_args(['--list-hosts', '--list-tasks', '--list-tags', '--syntax-check', '--start-at-task', 'test', 'playbook.yml'])

    # Call post_process_args method of PlaybookCLI class
    pb_cli.post_process_args(args)

    # Call run method of PlaybookCLI class
    pb_cli.run()

# Generated at 2022-06-16 20:02:20.334279
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:20.864996
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:21.383480
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:33.201283
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:33.921965
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-16 20:02:34.444593
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:42.779603
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import sys
    import tempfile
    from ansible.cli.playbook import PlaybookCLI
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-16 20:02:43.610402
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-16 20:02:44.101077
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:44.798129
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:45.767276
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:52.551094
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a PlaybookCLI object
    cli = PlaybookCLI()

    # Create a parser for CLI options
    cli.init_parser()

    # Create a parser for CLI options
    cli.post_process_args(cli.parser.parse_args(['--list-hosts', 'test.yml']))

    # Create a PlaybookCLI object
    cli = PlaybookCLI()

    # Create a parser for CLI options
    cli.init_parser()

    # Create a parser for CLI options
    cli.post_process_args(cli.parser.parse_args(['--list-tasks', 'test.yml']))

    # Create a PlaybookCLI object
    cli = PlaybookCLI()

    # Create a parser for CLI options
    cli.init_parser()

   

# Generated at 2022-06-16 20:02:53.165124
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:03.478555
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:04.138189
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:04.951885
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:05.577959
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:06.023455
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:06.455163
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:07.021682
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:14.925588
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    display = Display()
    display.verbosity = 3

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # setup dirs to enable loading plugins from all playbooks in case they add callbacks/inventory/etc

# Generated at 2022-06-16 20:03:15.436819
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:16.337626
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:03:30.740235
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: write unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:03:35.169276
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create a PlaybookCLI object
    cli = PlaybookCLI(['playbook.yml'])
    # create a parser object
    parser = cli.create_parser()
    # create a options object
    options = parser.parse_args(['playbook.yml'])
    # create a context object
    context.CLIARGS = options
    # call the run method
    cli.run()

# Generated at 2022-06-16 20:03:41.655385
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-16 20:03:43.283048
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:43.859891
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:44.410215
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:44.997216
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:45.761722
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:46.122921
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:46.663381
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-16 20:04:01.626897
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement test
    pass

# Generated at 2022-06-16 20:04:02.034422
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:02.464563
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:03.107402
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:03.671211
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:04.058763
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:04.836611
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for PlaybookCLI.run
    pass

# Generated at 2022-06-16 20:04:05.424724
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:06.034687
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement test
    pass

# Generated at 2022-06-16 20:04:06.633374
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement test
    pass

# Generated at 2022-06-16 20:04:24.035080
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:28.015908
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    Unit test for method run of class PlaybookCLI
    '''
    # TODO: implement test_PlaybookCLI_run
    pass

# Generated at 2022-06-16 20:04:28.830946
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:29.418411
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:30.012007
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:32.459413
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement this unit test
    pass

# Generated at 2022-06-16 20:04:33.314292
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:34.209926
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:34.753274
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:36.006573
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-16 20:04:49.987899
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:50.501500
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:51.236005
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:51.764809
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:52.630078
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement
    pass

# Generated at 2022-06-16 20:04:53.303075
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:57.938367
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create a PlaybookCLI object
    pbcli = PlaybookCLI()
    # create a parser
    pbcli.init_parser()
    # create a parser options
    options = pbcli.parser.parse_args(['--list-tasks', 'playbook.yml'])
    # set the parser options to CLIARGS
    context.CLIARGS = vars(options)
    # call method run of class PlaybookCLI
    pbcli.run()

# Generated at 2022-06-16 20:04:58.941274
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:59.620573
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:00.679441
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement test
    pass

# Generated at 2022-06-16 20:05:29.689352
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:40.005167
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a new instance of PlaybookCLI
    pbcli = PlaybookCLI()

    # Create a new instance of CLI
    cli = CLI()

    # Create a new instance of Display
    display = Display()

    # Create a new instance of PlaybookExecutor
    pbex = PlaybookExecutor()

    # Create a new instance of AnsibleCollectionConfig
    acc = AnsibleCollectionConfig()

    # Create a new instance of AnsibleError
    ae = AnsibleError()

    # Create a new instance of Block
    b = Block()

    # Create a new instance of AnsibleCollectionConfig
    acc = AnsibleCollectionConfig()

    # Create a new instance of AnsibleCollectionConfig
    acc = AnsibleCollectionConfig()

    # Create a new instance of AnsibleCollectionConfig
    acc = AnsibleCollectionConfig()

    # Create

# Generated at 2022-06-16 20:05:40.792576
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:51.531554
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a PlaybookCLI object
    cli = PlaybookCLI()

    # Create a parser
    parser = cli.create_parser()

    # Create a argparse.Namespace object
    args = parser.parse_args(['--list-hosts', 'playbook.yml'])

    # Set the attributes of the Namespace object
    args.listhosts = True
    args.listtasks = False
    args.listtags = False
    args.syntax = False
    args.connection = 'ssh'
    args.module_path = None
    args.forks = 5
    args.remote_user = 'root'
    args.private_key_file = None
    args.ssh_common_args = None
    args.ssh_extra_args = None

# Generated at 2022-06-16 20:05:52.556765
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:05:52.940010
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:53.672114
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:05:54.037054
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:54.512245
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:55.003855
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:29.426974
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:30.976142
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:31.753587
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:32.288967
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:32.852137
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:33.365101
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:33.790623
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:34.628575
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:06:35.145248
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:35.659739
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:07:10.726676
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # Create a mock inventory
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])

    # Create a mock variable manager
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # Create a mock loader
    loader = DataLoader()

    # Create a mock options

# Generated at 2022-06-16 20:07:20.586790
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.cli.playbook import PlaybookCLI
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    display = Display()

    class TestPlaybookCLI(unittest.TestCase):

        def setUp(self):
            self.parser = PlaybookCLI(
                usage="%prog [options] playbook.yml [playbook2 ...]",
                desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts.")
            self.parser.parse()

        def tearDown(self):
            pass


# Generated at 2022-06-16 20:07:21.435014
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement
    pass

# Generated at 2022-06-16 20:07:22.081357
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:07:23.992975
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: write unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:07:24.942749
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:07:25.581833
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:07:26.479060
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:07:27.204736
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:07:27.824364
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:08:44.009123
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement test
    pass

# Generated at 2022-06-16 20:08:44.579303
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:08:45.045243
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:08:56.378737
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    # Create a mock inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a mock context

# Generated at 2022-06-16 20:08:56.942370
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:08:57.499825
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:08:58.363192
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement
    pass

# Generated at 2022-06-16 20:08:58.928249
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:08:59.733689
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-16 20:09:00.963483
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:11:36.660718
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a test PlaybookCLI object
    test_PlaybookCLI = PlaybookCLI()

    # Create a test parser object
    test_parser = test_PlaybookCLI.init_parser()

    # Create a test options object
    test_options = test_parser.parse_args(['--list-tasks', 'test_playbook.yml'])

    # Call the run method of the PlaybookCLI object
    test_PlaybookCLI.run()

# Generated at 2022-06-16 20:11:37.140591
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:11:37.591991
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:11:38.029841
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:11:38.653218
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-16 20:11:44.889500
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import sys
    import tempfile
    import unittest

    class TestPlaybookCLI(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test_playbook.yml')
            with open(self.test_file, 'w') as f:
                f.write('''
                - hosts: localhost
                  tasks:
                    - name: test task
                      debug:
                        msg: test
                ''')

        def tearDown(self):
            os.remove(self.test_file)
            os.rmdir(self.test_dir)


# Generated at 2022-06-16 20:11:45.390096
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:11:53.845297
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # create base objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # setup dirs to enable loading plugins from all playbooks in case they add callbacks/inventory/etc

# Generated at 2022-06-16 20:11:54.508154
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:11:55.534721
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test
    pass