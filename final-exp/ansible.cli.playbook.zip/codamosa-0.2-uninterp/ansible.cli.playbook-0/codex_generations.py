

# Generated at 2022-06-16 20:02:30.076385
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:30.932509
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:31.532104
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:32.801562
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()
    cli.run()

# Generated at 2022-06-16 20:02:33.299710
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:41.729094
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.collection_loader import AnsibleCollectionConfig

# Generated at 2022-06-16 20:02:42.204886
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:02:50.042988
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-16 20:02:52.959581
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test with no args
    cli = PlaybookCLI(['ansible-playbook'])
    cli.parse()
    cli.run()

# Generated at 2022-06-16 20:02:53.581872
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:05.202557
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:05.604065
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:06.476187
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:07.064817
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:08.366049
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: write unit test for PlaybookCLI.run
    pass

# Generated at 2022-06-16 20:03:09.277288
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:10.295448
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:11.030826
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:12.044343
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:18.359994
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-16 20:03:30.683408
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:31.884579
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:03:32.416216
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:42.264428
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create a PlaybookCLI object
    cli = PlaybookCLI()

    # create a parser for CLI options
    cli.init_parser()

    # create a mock options object
    class Options:
        def __init__(self):
            self.listhosts = False
            self.listtasks = False
            self.listtags = False
            self.syntax = False
            self.connection = 'local'
            self.module_path = None
            self.forks = 5
            self.remote_user = 'root'
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = False
            self

# Generated at 2022-06-16 20:03:49.784590
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import sys
    import tempfile
    import shutil
    import json
    import unittest
    from ansible.cli.playbook import PlaybookCLI
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskIn

# Generated at 2022-06-16 20:03:57.414323
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import IncludeTask
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.collection_loader import AnsibleCollectionConfig

# Generated at 2022-06-16 20:03:58.294762
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:03:58.944229
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:00.343358
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:04:01.061867
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:04:18.524782
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:22.978978
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a PlaybookCLI object
    pbcli = PlaybookCLI()
    # Create a parser object
    parser = pbcli.create_parser()
    # Create a list of arguments
    args = ['playbook.yml']
    # Parse the arguments
    options = parser.parse_args(args)
    # Set the options to the context
    context.CLIARGS = options
    # Call the run method
    pbcli.run()

# Generated at 2022-06-16 20:04:23.608439
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:24.232256
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:25.148470
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:26.903633
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:27.932620
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:28.622935
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:04:40.236502
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import add_all_plugin_dirs

    display = Display()
    display.verbosity = 3

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # setup dirs to enable loading plugins from all playbooks in case they add callbacks/inventory/etc

# Generated at 2022-06-16 20:04:40.710829
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:00.207435
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:00.832489
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:01.410183
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:02.066966
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:02.752984
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:03.334721
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:03.751993
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:11.601477
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.default import CallbackModule
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play

# Generated at 2022-06-16 20:05:16.565167
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a PlaybookCLI object
    cli = PlaybookCLI()
    # Create a parser for CLI options
    cli.init_parser()
    # Create a parser for CLI options
    cli.post_process_args(context.CLIARGS)
    # Run the CLI
    cli.run()

# Generated at 2022-06-16 20:05:17.333536
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:44.971837
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement test
    pass

# Generated at 2022-06-16 20:05:45.427377
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:45.885236
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:46.324151
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:46.942564
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:47.647555
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:48.464950
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:49.036337
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:49.622665
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:05:50.201678
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:58.404638
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:59.026728
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:06:59.637616
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:07:00.517279
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:07:01.109760
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:07:02.406156
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:07:10.354153
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.errors import AnsibleError
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-16 20:07:10.788150
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:07:11.669199
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement
    pass

# Generated at 2022-06-16 20:07:13.890324
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:08:31.149598
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:08:32.529072
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:08:35.921676
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a PlaybookCLI object
    cli = PlaybookCLI()

    # Create a parser for CLI options
    cli.init_parser()

    # Create a parser for CLI options
    cli.post_process_args(context.CLIARGS)

    # Run the method
    cli.run()

# Generated at 2022-06-16 20:08:36.375039
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:08:42.613278
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a PlaybookCLI object
    pbcli = PlaybookCLI()

    # Create a parser object
    parser = pbcli.create_parser()

    # Create a list of arguments

# Generated at 2022-06-16 20:08:43.283956
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:08:43.722354
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:08:54.836168
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.errors import AnsibleError
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars_files
    from ansible.utils.vars import load_vault_vars
    from ansible.utils.vars import load_vault_

# Generated at 2022-06-16 20:09:02.757250
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path

    # create base objects
    loader = DataLoader()
    display = Display()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

   

# Generated at 2022-06-16 20:09:04.806043
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-16 20:10:21.970654
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:10:22.636013
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:10:24.669425
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: create a test
    pass

# Generated at 2022-06-16 20:10:31.386535
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a PlaybookCLI object
    pb_cli = PlaybookCLI()

    # Create a parser object
    parser = pb_cli.create_parser()

    # Create a argparse namespace object
    args = parser.parse_args(['-i', 'localhost,', '-c', 'local', 'playbook.yml'])

    # Create a context object
    context.CLIARGS = args

    # Call method run of class PlaybookCLI
    pb_cli.run()

# Generated at 2022-06-16 20:10:39.729681
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path, _get_collection_playbook_path

    # create base objects
    display = Display()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create the playbook executor,

# Generated at 2022-06-16 20:10:40.296425
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:10:41.770488
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for PlaybookCLI.run
    pass

# Generated at 2022-06-16 20:10:42.333090
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:10:43.011882
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:10:43.569962
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:12:04.440944
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:12:04.960334
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:12:05.514738
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:12:06.159305
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:12:06.698035
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:12:08.578009
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:12:09.085256
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-16 20:12:10.098123
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test for method run of class PlaybookCLI
    pass

# Generated at 2022-06-16 20:12:10.801000
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement
    pass

# Generated at 2022-06-16 20:12:11.264886
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass