

# Generated at 2022-06-10 22:19:55.000250
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    context._init_global_context(['playbook'])
    context.CLIARGS['args'] = ['playbook']
    context.CLIARGS['json'] = False
    context.CLIARGS['syntax'] = False
    context.CLIARGS['listtags'] = False
    context.CLIARGS['listtasks'] = False
    context.CLIARGS['listhosts'] = False
    context.CLIARGS['connection'] = 'local'
    context.CLIARGS['module_path'] = None
    context.CLIARGS['forks'] = 5
    context.CLIARGS['remote_user'] = 'remote_user'
    context.CLIARGS['private_key_file'] = None
    context.CLIARGS['ssh_common_args'] = None


# Generated at 2022-06-10 22:20:04.581459
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    mock_inventory = MockInventory()
    mock_loader = MockLoader()
    mock_variable_manager = MockVariableManager()
    mock_passwords = MockPasswords()

    mock_pbex = MockPlaybookExecutor(mock_passwords)
    mock_pbex.run_return = exit_result_success
    mock_pbex.run_ok_to_call = True # run() calls get_host_list() to get the list of hosts

    mock_playbooks = ['playbook.yaml']
    mock_CLIARGS = {'args': mock_playbooks,
                    'subset': None,
                    'listhosts': False,
                    'listtasks': False,
                    'listtags': False,
                    'syntax': False}

# Generated at 2022-06-10 22:20:16.570203
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import sys
    import tempfile

    from ansible.cli.playbook import PlaybookCLI
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.constants import CLIConstants
    from ansible.utils.display import Display

    # Create playbook and inventory
    if sys.version_info[0] > 2:
        # Python 3
        _, tmp_playbook = tempfile.mkstemp(suffix='.yml', prefix='ansible-playbook-unit-test-', text=True)
        _, tmp_inventory = tempfile.mkstemp(suffix='.yml', prefix='ansible-inventory-unit-test-', text=True)

# Generated at 2022-06-10 22:20:18.227363
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import pytest
    
    with pytest.raises(SystemExit):
        PlaybookCLI().run()

# Generated at 2022-06-10 22:20:23.621254
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    mock_connection_loader = {}
    mock_inventory = {}
    mock_variable_manager = {}
    mock_playbook_executor = {}
    mock_results = [0, 1]
    cli = PlaybookCLI(connection_loader=mock_connection_loader,
                    inventory=mock_inventory,
                    variable_manager=mock_variable_manager,
                    playbook_executor=mock_playbook_executor)

    mock_playbook_executor.run.return_value = mock_results
    assert cli.run() == mock_results[0]

# Generated at 2022-06-10 22:20:26.893941
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()
    cli.post_process_args = lambda x, y=None: x
    cli.run()

# Generated at 2022-06-10 22:20:27.618311
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:20:28.744681
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert PlaybookCLI.run is not None

# Generated at 2022-06-10 22:20:41.846162
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.cli import CLI

    # Create the mock objects
    module_loader = 'AnsibleModuleLoader'
    variable_manager = 'AnsibleVariableManager'
    loader = 'AnsibleLoader'
    inventory = 'AnsibleInventory'
    context_args = 'args'
    display_args = 'display'
    ansible_plugins = 'AnsiblePlugins'

    # Create the mock inventory

# Generated at 2022-06-10 22:20:42.254012
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:05.238044
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    playbook_cli = PlaybookCLI()
    playbook_cli._flush_cache = lambda inventory, variable_manager: None

    class Options(object):
        check = False
        listtags = False
        listtasks = False
        step = False
        subset = None
        syntax = False

        def __init__(self):
            self.errors = []
            self.verbosity = 5
            self.flush_cache = True
            self.connection = 'local'
            self.module_path = None

    class Inventory(object):
        class Host(object):
            vars = {}

            def __init__(self, hostname):
                self.hostname = hostname

            def get_vars(self):
                return self.vars

            def get_name(self):
                return self.hostname


# Generated at 2022-06-10 22:21:06.336741
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:19.171454
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Test arguments and errors

    options = ["--flush-cache"]
    context.CLIARGS = context.CLI.parser.parse_args(args=options)
    context.CLIARGS['listtags'] = True
    context.CLIARGS['listtasks'] = True
    context.CLIARGS['listhosts'] = True
    context.CLIARGS['syntax'] = True
    context.CLIARGS['module_path'] = None
    context.CLIARGS['module_path'] = None
    context.CLIARGS['flush_cache'] = False
    context.CLIARGS['tags'] = None
    context.CLIARGS['skip_tags'] = None
    context.CLIARGS['one_line'] = False
    context.CLIARGS['tree'] = None

# Generated at 2022-06-10 22:21:31.571588
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create a dict object for CLI options
    options = dict()
    options['listhosts'] = False
    options['listtasks'] = False
    options['listtags'] = False
    options['syntax'] = False
    options['module_path'] = None
    options['become'] = None
    options['become_method'] = None
    options['become_user'] = None
    options['check'] = False
    options['diff'] = False
    options['inventory'] = None
    options['password'] = None
    options['private_key_file'] = None
    options['tags'] = None
    options['skip_tags'] = None
    options['start_at_task'] = None
    options['subset'] = None
    options['verbosity'] = None
    options['connection'] = None

# Generated at 2022-06-10 22:21:40.212572
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    Test the class PlaybookCLI by using the parameter
    of the method run.
    It returns True if the test is passed and False otherwise.
    """
    from queue import Empty
    from ansible.errors import AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.module_utils.connection as connection
    import ansible.playbook.play as play
    import ansible.playbook.playbook as playbook

    test_pass = True
    fake_executor = "fake_executor"
    fake_loader = "fake_loader"

    """ Test with an empty argument """
    my_playbookcli = PlaybookCLI()

# Generated at 2022-06-10 22:21:47.174955
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # test case 1
    context.CLIARGS = dict(args=['test.yml'], start_at_task='test', subset='test', listhosts=True, listtasks=True,
                           listtags=True, syntax=False, flush_cache=True, step=True, verbose=1, vault_password_file='/tmp')
    PlaybookCLI().run()


# Generated at 2022-06-10 22:21:47.960996
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:58.542736
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """ Test PlaybookCLI.run(). """
    import argparse
    from ansible.plugins.loader import add_all_plugin_dirs

    # Setup test variables
    # Test data for parsing the args
    argv = ['playbook.yml']

    # Mock a PlaybookCLI object
    my_play = PlaybookCLI(args=argv)

    # Test the PlaybookCLI object
    # Test that CLI.run() raises an error because of missing -i option
    with pytest.raises(SystemExit):
        my_play.run()

    # Test the PlaybookCLI object
    # Test that CLI.run() raises an error because of missing -i option
    argv.append('-i')
    argv.append('localhost,')
    my_play = PlaybookCLI(args=argv)

# Generated at 2022-06-10 22:22:06.205782
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    import pytest
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils._text import to_bytes

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from units.mock.plugins.connection import mock_connection

    from units.mock.plugins.callback import CallbackModule
    from units.mock.plugins.callback.loader import CallbackModuleLoader

    from units.mock.plugins.inventory import mock_inventory

# Generated at 2022-06-10 22:22:11.883539
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys
    import pytest

    sys.argv = [sys.argv[0]]
    sys.argv.extend(["--list-hosts", "example.yml", "--limit=all"])
    c = PlaybookCLI(args=sys.argv[1:])
    assert c.run() == 0

# Generated at 2022-06-10 22:22:34.751482
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:22:45.594405
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    # test data fixtures

# Generated at 2022-06-10 22:22:48.283507
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pbcli = PlaybookCLI()
    pbcli.parse(['--list-hosts', 'playbook.yml'])
    pbcli.run()

# Generated at 2022-06-10 22:22:56.414275
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI._flush_cache = lambda x, y: None
    import sys

    if sys.version_info >= (2, 7):
        # shutil.which not in 2.6
        # FIXME: monkeypatch shutil.which
        import shutil
        shutil.which = lambda x, y=None: x

    # patching display
    def display(message):
        return message

    # FIXME: Monkeypatch CLI.ask_vault_pass and CLI.ask_passwords
    def dummy_vault_pass():
        return 'a'

    def dummy_pass():
        return 'a', 'b'

    CLI.ask_vault_pass = dummy_vault_pass
    CLI.ask_passwords = dummy_pass

    # FIXME: Monkeypatch PlaybookCLI.ask_passwords
    Play

# Generated at 2022-06-10 22:22:58.380530
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pb_cli = PlaybookCLI([])
    # pb_cli.run()

# Generated at 2022-06-10 22:23:04.871637
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class DisplayObject(object):
        display_target = ''

        def display(self, *args, **kwargs):
            self.display_target += str(args)

    display_object = DisplayObject()
    display.verbosity = 4
    display.verbose = lambda *args, **kwargs: display_object.display(*args, **kwargs)
    playbook_cli = PlaybookCLI()
    playbook_cli.run()

# Generated at 2022-06-10 22:23:06.835895
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbookCLI = PlaybookCLI()
    playbookCLI.run()

# Generated at 2022-06-10 22:23:19.733413
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.plugins import callback_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    class FakeOptions:
        connection = "local"
        module_path = None
        forks = 100
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        subset = None
        verbosity = 5
        inventory = None
        timeout = 10
        ask_pass = None
        private_key_file = None
        ask_key_pass = None
        tags = None
        skip_tags

# Generated at 2022-06-10 22:23:20.830133
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    c = PlaybookCLI()
    c.run()

# Generated at 2022-06-10 22:23:30.691063
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import sys
    import yaml
    from textwrap import dedent

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import collection_loader
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.utils.vault import VaultLib

    # Flag to indicate whether the test case should skip testing the
    # run method because the vault-password-file functionality is not
    # available.
    SKIP_TEST_RUN_WITH_VAULT_PASSWORD_FILE = False

    # Flag to

# Generated at 2022-06-10 22:24:29.885370
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:40.298381
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Create test fixtures
    loader = 'loader'
    inventory = 'inventory'
    variable_manager = 'variable_manager'
    passwords = {}

    # Create test object of class PlaybookCLI
    cli = PlaybookCLI()

    # Create test object of class PlaybookExecutor
    pbex = PlaybookExecutor()

    # Create test objects to use in method run
    results = ['results']

    # Mock method _play_prereqs to return loader, inventory and variable_manager
    cli._play_prereqs = lambda *a, **kw: (loader, inventory, variable_manager)

    # Mock method ask_passwords to return sshpass and becomepass
    cli.ask_passwords = lambda *a, **kw: (sshpass, sshpass)

    # Mock method get_host_list to retrieve list of

# Generated at 2022-06-10 22:24:51.381888
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Basic initialization
    pb_cli = PlaybookCLI(['/some/folder/some_playbook.yml'])
    # Mock some methods of PlaybookCLI class
    pb_cli.ask_passwords = lambda: (None, None)
    pb_cli.validate_conflicts = lambda x, y, z: None
    # Mock some methods of PlaybookExecutor class
    # We need to import the class here to avoid cyclic imports
    PlaybookExecutor.run = lambda x, y, z, a, b, c, d: (0, None)

    # Create the loader, inventory and variable manager
    loader = DataLoader()

# Generated at 2022-06-10 22:24:59.696987
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create host groups with hosts
    group_all = "group_all"
    group_all_hosts = ["host1", "host2", "host3"]
    group_all_hosts_objs = [InventoryHost(host_name) for host_name in group_all_hosts]
    inventory = Inventory(host_list=[])

    # create the group and add hosts to it.
    group_all_object = InventoryGroup(group_all)
    group_all_object.add_hosts(group_all_hosts_objs)
    inventory.add_group(group_all_object)

    # create a loader for loading from source
    loader = DataLoader()

    # create a variable manager and add the host groups.
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)



# Generated at 2022-06-10 22:25:00.745688
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass


# Generated at 2022-06-10 22:25:14.555861
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Create a mock CLI object
    class MockPlaybookCLI(PlaybookCLI):
        def __init__(self):
            self.display = display

        def post_process_args(self, options):
            options = super(MockPlaybookCLI, self).post_process_args(options)

            display.verbosity = options.verbosity
            self.validate_conflicts(options, runas_opts=True, fork_opts=True)

            return options

        def _play_prereqs(self):
            return super(MockPlaybookCLI, self)._play_prereqs()

        def _flush_cache(self, inventory, variable_manager):
            return super(MockPlaybookCLI, self)._flush_cache(inventory, variable_manager)

        def run(self):
            return

# Generated at 2022-06-10 22:25:15.471401
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI('test', 'test')
    assert cli.run() is None

# Generated at 2022-06-10 22:25:21.082944
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class OnePassCLI(PlaybookCLI):
        def __init__(self):
            pass

    cli = OnePassCLI()
    cli.ask_passwords = lambda: ('sshpass', 'becomepass')
    cli.get_opt = lambda opt: True
    cli.parse()
    cli.post_process_args = lambda opts: opts
    cli.run()

# Generated at 2022-06-10 22:25:34.574967
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Create a mock object of PlayExecutor
    class PlaybookExecutor(object):
        @staticmethod
        def run():
            return 0
    # mock the actual method
    PlaybookExecutor.run = PlaybookExecutor.run

    context_manager_mock = context._Context()
    context_manager_mock.CLIARGS = dict()
    context_manager_mock.CLIARGS['syntax'] = False
    context_manager_mock.CLIARGS['tags'] = None
    context_manager_mock.CLIARGS['skip_tags'] = None
    context_manager_mock.CLIARGS['flush_cache'] = False
    context_manager_mock.CLIARGS['start_at_task'] = None

# Generated at 2022-06-10 22:25:41.210341
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class PlaybookCLI_test(PlaybookCLI):
        def _play_prereqs(self):
            self.loader = None
            self.inventory = None
            self.variable_manager = None
            return self.loader, self.inventory, self.variable_manager
        def ask_passwords(self):
            return self.sshpass, self.becomepass

    return PlaybookCLI_test().run

# Generated at 2022-06-10 22:26:48.576328
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI(['test_playbook.yml', '-i', 'inven'])
    assert cli.run() == 0

# Generated at 2022-06-10 22:27:00.285163
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #noinspection PyNoneFunctionAssignment
    def _ask_passwords():
        return None, None

    #noinspection PyNoneFunctionAssignment
    def _play_prereqs():
        return None, None, None

    class Dummy(object):
        def __init__(self):
            self.display = Display()
            self.CLIARGS = dict()

    context.CLIARGS = Dummy()

    context.CLIARGS.display = Display()
    context.CLIARGS.args = ['test.yml']

    context.CLIARGS.verbosity = 0

    # Define object PlaybookCLI
    PlaybookCLI.ask_passwords = _ask_passwords
    PlaybookCLI._play_prereqs = _play_prereqs

    # Define object Playbook

# Generated at 2022-06-10 22:27:07.387047
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:27:18.836208
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # py3 compat
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # required imports
    import sys
    import argparse
    from ansible.cli.playbook import PlaybookCLI

    # invoke PlaybookCLI.run with a mocked argv[1]
    # patch.object uses a python 3ism
    with patch.object(sys, 'argv', ['ansible-playbook', '-i', 'localhost', __file__]):

        # init the PlaybookCLI() class
        obj = PlaybookCLI( )
        obj.setup()

        # create an argparse.Namespace for the _prereqs() def
        opt = argparse.Namespace()

        # set the options
        opt.listhosts = True

# Generated at 2022-06-10 22:27:24.077793
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible import context
    from ansible.errors import AnsibleError
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display

    display = Display()

# Generated at 2022-06-10 22:27:32.938135
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import io
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vault_loader
    from ansible.vars import VariableManager

    class MockPlaybookExecutor:
        def __init__(self, *args, **kwargs):
            pass
        def run(self):
            return 0

    ########################################################################

    class MockParser:
        def __init__(self):
            pass

    class MockPlaybook:
        def __init__(self, *args, **kwargs):
            pass

        def compile(self):
            yield MockBlock()

    class MockBlock:
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-10 22:27:46.467423
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Note that this test assumes that the working directory is the ansible directory
    # and therefore we don't add plugin directories.  We also assume that the
    # environment variables like ANSIBLE_CONFIG are not set.

    # Dummy inventory which always returns ansible_connection=local for all hosts
    class DummyInventory:
        def __init__(self):
            self._hosts = {'all': {'hosts': {'localhost': {}}}}
            self._hosts['all']['hosts']['localhost']['ansible_connection'] = 'local'

        @classmethod
        def list_hosts(self):
            return ['localhost']

        def get_hosts(self, hosts):
            return ['localhost']

    # Dummy loader which returns empty variables and empty basedirs

# Generated at 2022-06-10 22:27:55.688276
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.inventory import Inventory
    from ansible.utils.vars import load_extra_vars
    from ansible.vars import VariableManager

    from .mock import patch
    from .myvcr.playbookcli_vcr import use_cassette

    collection_name = 'ansible_collections.namespace.collection_name'
    playbook_name = '../' + collection_name + '/tests/ansible_namespace/collection_name/playbook.yml'
    collection_path = './tests/ansible_namespace/collection_name'
    inventory_path = './tests/ansible_namespace/collection_name/inventory.ini'
    host_list = ['localhost']


# Generated at 2022-06-10 22:27:56.709437
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:28:06.985487
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #testcase 1 :
    #    context.CLIARGS['flush_cache'] == True
    context.CLIARGS = dict(flush_cache = True)
    PlaybookCLI._flush_cache = Mock(return_value=None)
    display.display = Mock(return_value=None)
    pbex = Mock()
    results = Mock()
    pbex.run.return_value = results
    PlaybookCLI.run()
    assert results == None

    #testcase 2 :
    #    context.CLIARGS['flush_cache'] == False
    #    results is a list
    #    for each p in results :
    #        - results[p]['plays'] is a list
    #        - for each idx, play in enumerate(results[p]['plays']):
    #           