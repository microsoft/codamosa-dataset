

# Generated at 2022-06-10 22:19:45.809991
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()
    cli.init_parser()
    cli.post_process_args(cli.options)
    cli.run()

# Generated at 2022-06-10 22:19:56.852713
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins import module_loader
    import ansible.inventory.manager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    display.verbosity = 3
    add_all_plugin_dirs('/usr/lib/python3.6/site-packages/ansible/plugins')

    class MockPlaybookExecutor(PlaybookExecutor):
        def run(self):
            ''' Simulate PlaybookExecutor() by returning a Playbook() directly '''


# Generated at 2022-06-10 22:20:03.512232
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    inv = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    cli = PlaybookCLI(['-i', 'localhost,', 'tests/playbooks/test_playbook.yml'])
    pbex = cli._play_prereqs(loader, inv, VariableManager())

    assert isinstance(pbex.playbooks, list)

# Generated at 2022-06-10 22:20:04.409053
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI.run()

# Generated at 2022-06-10 22:20:08.993052
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create the playbook executor, which manages running the plays via a task queue manager
    pbex = PlaybookExecutor(playbooks=['/PlaybookCLI.yml'], inventory=None,
                            variable_manager=None, loader=None,
                            passwords=None)
    pbex.run
    pass

# Generated at 2022-06-10 22:20:09.709748
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    return

# Generated at 2022-06-10 22:20:19.737739
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pbcli = PlaybookCLI()

# Generated at 2022-06-10 22:20:33.306363
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PLUGIN_PATH_ONE = "ansible/plugins/action"
    PLUGIN_PATH_TWO = "ansible/plugins/lookup"
    TEST_PLAYBOOK_DIR = "unit_tests/utils"
    TEST_PLAYBOOK = "unit_tests/utils/ping.yml"
    TEST_INVENTORY = "unit_tests/utils/ping_inventory.yml"

    test_args = [TEST_PLAYBOOK]

# Generated at 2022-06-10 22:20:34.874434
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    raise NotImplementedError()

# Generated at 2022-06-10 22:20:45.981791
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Init inventory manager
    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)

    # Init options

# Generated at 2022-06-10 22:20:57.015724
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:08.127519
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class PlaybookCLI_run_helper:
        def __init__(self):
            self.fake_args = []

        def get_host_list(self, inventory, subset):
            return ['localhost']

        def run(self):
            return 0

    class TmpPlaybookCLI(PlaybookCLI):
        def __init__(self):
            pass

        def get_optparser(self):
            return PlaybookCLI_run_helper()

        def _play_prereqs(self):
            return None, None, None

        def ask_passwords(self):
            return None, None

        def post_process_args(self, options):
            return options

    tmp_playbook_cli = TmpPlaybookCLI()
    results = tmp_playbook_cli.run()

# Generated at 2022-06-10 22:21:20.943508
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # run a playbook with a role
    pb = PlaybookCLI(['playbooks/test_playbook.yml'])
    pb.options.connection = 'local'
    ret_value = pb.run()
    assert ret_value == 0

    # run a playbook with a failing task
    pb = PlaybookCLI(['playbooks/fail_task.yml'])
    pb.options.connection = 'local'
    ret_value = pb.run()
    assert ret_value == 2

    # run a playbook with --syntax-check
    pb = PlaybookCLI(['playbooks/syntax_check.yml'])
    pb.options.syntax = True
    pb.options.connection = 'local'
    ret_value = pb.run()
    assert ret_

# Generated at 2022-06-10 22:21:28.696844
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    print("Starting test PlaybookCLI_run")

    # Input args
    inventory = dict()
    loader = dict()
    variable_manager = dict()

    # Create new instance of class PlaybookCLI
    pbcli = PlaybookCLI()

    # Execute code in method run
    pbcli.run(inventory, loader, variable_manager)

    print("Finished test PlaybookCLI_run")

# Generated at 2022-06-10 22:21:30.902274
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args = ['--list-hosts', 'site.yaml']
    cli = PlaybookCLI(args)
    assert cli.run() == 0

# Generated at 2022-06-10 22:21:39.743082
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:21:41.114585
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:42.527265
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:51.797389
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockCLI():
        def get_host_list(self, inventory, subset):
            pass

        def ask_passwords(self):
            pass

    class MockPlaybookExecutor():
        def __init__(self, playbooks, inventory, variable_manager, loader, passwords):
            pass

        def run(self):
            return True

    class MockDisplay():
        class Display(object):
            def __init__(self, verbosity):
                pass

    class MockContext():
        class CLIARGS():
            def __init__(self):
                self.verbosity = 0
                self.flush_cache = False
                self.listhosts = True
                self.listtasks = True
                self.listtags = True
                self.step = True
                self.start_at_task = 'task'

# Generated at 2022-06-10 22:21:52.777687
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:22:28.480741
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: Add tests for all cases/branch/conditions, not just successful runs
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.plugins.loader import add_all_plugin_dirs
    import os
    import stat
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path

    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    context._init_global_context(None)
    context.CLIARGS = namespace = opt_help.parse()

# Generated at 2022-06-10 22:22:31.456868
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # initialize and create object
    cli = PlaybookCLI(None)
    cli.init_parser()
    cli.parser.parse_args('')

# Generated at 2022-06-10 22:22:39.777336
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockOptions():
        flush_cache = False
        listhosts = False
        listtags = False
        listtasks = False
        syntax = False
        subset = None
        inventory = ["localhost,"]

    class MockCLIArgs():
        args = ['a.yml']

    class MockDisplay():
        verbosity = 3

    cli = PlaybookCLI(['a.yml'], '/path/to/config')
    cli.options = MockOptions()
    context.CLIARGS = MockCLIArgs()
    display = MockDisplay()

    assert cli.run() == 0

# Generated at 2022-06-10 22:22:50.014004
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI._flush_cache = lambda a, b: None
    for v in ('-i', '--private-key'):
        for i in ('/path/to/private/key', '~/.ssh/id_rsa'):
            cmd = [v, i, '-e', 'host_key_checking=False', 'localhost', '-m ping']

            pbcli = PlaybookCLI(cmd)
            pbcli.parse()
            pbcli.run()

    for v in ('-u', '--user'):
        for i in ('user1', 'user2'):
            cmd = [v, i, '-e', 'host_key_checking=False', 'localhost', '-m ping']

            pbcli = PlaybookCLI(cmd)
            pbcli.parse()
            p

# Generated at 2022-06-10 22:22:57.674115
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #
    # Unit test for method run of class PlaybookCLI.
    #

    #
    # This test case is not used by the framework. However, it can be used for
    # ad hoc testing.
    #

    #########################################################################
    # Prerequisites for this test case
    #########################################################################

    #########################################################################
    # Set up for this test case
    #########################################################################

    # Create a PlaybookCLI object.
    cli = PlaybookCLI()

    #########################################################################
    # Exercise the class and methods being tested
    #########################################################################

    # Run the test case.
    context.CLIARGS = None
    cli.run()

# Generated at 2022-06-10 22:23:07.588106
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    hostvars = dict()
    hostvars["10.10.10.1"] = dict()
    hostvars["10.10.10.1"]["ansible_host"] = "10.10.10.1"
    hostvars["10.10.10.1"]["ansible_user"] = "root"
    hostvars["10.10.10.1"]["ansible_port"] = 22
    hostvars["10.10.10.2"] = dict()
    hostvars["10.10.10.2"]["ansible_host"] = "10.10.10.2"
    hostvars["10.10.10.2"]["ansible_user"] = "root"
    hostvars["10.10.10.2"]["ansible_port"] = 22

# Generated at 2022-06-10 22:23:12.873491
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    This is a unit test for a method in class PlaybookCLI
    It tests whether the method runs properly
    '''
    # Create the object cli_obj
    cli_obj = PlaybookCLI()

    # Invoke the run() method
    cli_obj.run()

# Generated at 2022-06-10 22:23:25.529193
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import mock
    from ansible.cli.playbook import PlaybookCLI
    from ansible.errors import AnsibleError
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.utils.display import Display

    class Options():
        verbosity = 2
        check = False
        force_handlers = False
        flush_cache = False
        inventory = ''
        listhosts = True
        listtasks = False
        listtags = False
        private_key_file = '/dev/null'
        skip_tags = ''
        subset = ''
        tags = ''
        step = False
        syntax = False
        start_at_task = False
        diff = False


# Generated at 2022-06-10 22:23:31.873422
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create a PlaybookCLI object without any parameters
    pb_cli = PlaybookCLI()

    # append a playbook to the list of args
    pb_cli.options.args.append("playbook_path")
    pb_cli.options.listhosts = True
    pb_cli.options.listtags = True
    pb_cli.options.listtasks = True
    pb_cli.options.flush_cache = True

    # Run the run method of class PlaybookCLI. The output is redirected to a temporary file.
    # The content of the file is returned.
    pb_cli.run()

# Generated at 2022-06-10 22:23:32.938740
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:40.000759
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Init
    pb = PlaybookCLI()
    pb.parser = pb.init_parser()
    if hasattr(pb.parser, '_get_optional_actions'):
        # NOTE: This is a different API on Python 2.6
        actions = pb.parser._get_optional_actions()
    else:
        actions = []
        for group in pb.parser._action_groups:
            if group.title == 'options':
                actions.extend(group._group_actions)

    # Create the parser
    options = []
    for action in actions:
        if '--version' in action.option_strings:
            # Ansible 2.0.0 added this as a CLI option so it will exist in the
            # list of actions and is not something we want to test.
            continue

# Generated at 2022-06-10 22:24:49.987502
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import DictInventory
    from units.mock.vars import VariableManager

    loader = DictDataLoader({})
    inventory = DictInventory(
        {
            "dummy": {"hosts": ["localhost"]},
            "dummy2": {},
            "dummy3": {"vars": {"key": "value"}},
        }
    )
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    playbook_cli = PlaybookCLI([])
    playbook_cli.post_process_args({})

    with pytest.raises(AnsibleError):
        playbook_cli.run()

# Generated at 2022-06-10 22:24:50.955049
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass


# Generated at 2022-06-10 22:24:59.398738
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class MockPlaybookCLI(PlaybookCLI):
        def __init__(self):
            self.ansible_options = {'verbosity': 5}
            self.args = ['/path/to/playbook.yml']

        def _play_prereqs(self):
            class MockAnsibleFileFinder:
                def __init__(self):
                    self.basedir = '/path/to/playbook'

            class MockLoader:
                def __init__(self):
                    self.basedir = '/path/to/playbook'
                    self.find_plugin = MockAnsibleFileFinder()

            class MockInventory:
                def __init__(self):
                    self.list_hosts = lambda: ['host1', 'host2']


# Generated at 2022-06-10 22:25:01.903605
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    play_prereqs()::
        loader, inventory, variable_manager = self._play_prereqs()
    """
    pass

# Generated at 2022-06-10 22:25:02.771760
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:25:16.405261
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Testing on a linux system
    if os.name == 'posix' and 'linux' in sys.platform:
        # Instanciate the plugin
        pb = PlaybookCLI()

        # setting up and run prereqs for pb
        pb_parser = pb.init_parser()
        args = pb_parser.parse_args('-i ./test/integration/inventory/hosts --list-hosts playbook.yml')
        options = pb.post_process_args(args)

        # execute run
        pb.run()

    # Testing on a windows system
    if os.name == 'nt':
        # Instanciate the plugin
        pb = PlaybookCLI()

        # setting up and run prereqs for pb
        pb_parser = pb.init_parser()

# Generated at 2022-06-10 22:25:21.900268
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockCLI:
        def __init__(self, args):
            self.args = args

    collection_paths = ':'.join(context.CLIARGS['COLLECTIONS_PATHS'])
    args = ['ansible-playbook', '--inventory-file=hosts', '--list-hosts', 'playbook.yml']
    fake_args = MockCLI(args)
    pb = PlaybookCLI(fake_args)
    pb.run()

# Generated at 2022-06-10 22:25:23.614419
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert False, "No tests for PlaybookCLI.run"


# Generated at 2022-06-10 22:25:24.872702
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook = PlaybookCLI()
    playbook.run()

# Generated at 2022-06-10 22:26:32.945533
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert True

# Generated at 2022-06-10 22:26:35.818115
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO:
    # This test requires a playbook to run against.
    # We should have a universal playbook (in the tests) to run against.
    pass

# Generated at 2022-06-10 22:26:39.260570
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Setup and run test
    play = PlaybookCLI(['playbook.yml'])

    results = play.run()
    # Teardown and verify test
    assert results == 0

# Generated at 2022-06-10 22:26:50.508256
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class Options(object):
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        subset = None
        flush_cache = True
        args = None
        connection = None
        module_path = None
        forks = None
        remote_user = None
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = None
        become_method = None
        become_user = None
        become_ask_pass = None
        verbosity = None
        check = None
        start_at_task = None
        inventory = None
        inventory_manager = None
        vault_password_files = None
        verbosity_level = None
       

# Generated at 2022-06-10 22:26:51.058306
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:27:02.925856
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockVault(object):
        def __init__(self):
            self.password = None

    class MockLoader(object):
        def __init__(self):
            self.basedir = None

    class MockOptions(object):
        def __init__(self):
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None
            self.connection = "local"
            self.module_path = None
            self.forks = 5
            self.remote_user = None
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become

# Generated at 2022-06-10 22:27:03.718788
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:27:06.683712
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.utils.display import Display
    display = Display()

    pbcli=PlaybookCLI([])
    pbcli.check_cli=True
    pbcli.options = pbcli.parse()

    pbcli.run()

# Generated at 2022-06-10 22:27:17.905402
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    host_path = "/tmp/ansible-playbook-test/hosts"
    playbook_path = "/tmp/ansible-playbook-test/test-playbook.yml"

    # create dummy inventory and playbook files
    os.makedirs(os.path.dirname(host_path))
    with open(host_path, 'w') as f:
        f.write("local ansible_connection=local\n")

    with open(playbook_path, 'w') as f:
        f.write("- hosts: local\n"
                "  gather_facts: no\n"
                "  tasks:\n"
                "  - debug: msg='Hello World!'")

    # test PlaybookCLI
    (sshpass, becomepass) = PlaybookCLI.ask_passwords()
    context.CLI

# Generated at 2022-06-10 22:27:22.133429
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    context._init_global_context(['ansible-playbook', 'test.yml'])
    context.CLIARGS = {'args': ['test.yml']}
    pb = PlaybookCLI()
    pb.run()