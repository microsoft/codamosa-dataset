

# Generated at 2022-06-10 22:19:53.002697
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # create a PlaybookCLI command
    p = PlaybookCLI()

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    # create needed objects
    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list=[])
    variable_manager = VariableManager()

    # create some arguments to pass to the CLI
    args = [
        '--connection', 'local',
        '--module-path', '../module_utils',
        '-i', 'localhost,'
    ]

    playbook_path = '../../../test/integration/inventory_hostname'

    try:
        os.mkdir('/tmp/test_results')
    except Exception:
        pass


# Generated at 2022-06-10 22:19:55.042684
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: need better unit tests here
    # Currently the code for run method in PlaybookCLI is too hard to test
    pass

# Generated at 2022-06-10 22:20:04.617058
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:20:16.609207
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    """
    Unit test for method run of class PlaybookCLI
    """

    from units.mock.cli_args import MockCLIArgs
    from units.mock.collections_config import MockCollectionsConfigForPlaybookCLI
    from units.mock.loader import DictDataLoader
    from units.mock.lookup_registry import MockLookupRegistry
    from units.mock.path import MockPathHierarchy
    from units.mock.plugins import MockPluginManager
    from units.mock.role_resolver import MockRoleResolver
    from units.mock.ssh_pass import MockSSHPass
    from units.mock.vault import MockVaultSecret

    # Setup mock plugins
    mock_plugin_manager = MockPluginManager(directories_list=['units/mock/plugins'])
   

# Generated at 2022-06-10 22:20:21.904241
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import ansible.config.loader
    c = ansible.config.loader.ConfigLoader()
    c.load_config_file()
    c.set_config_attr('DEFAULT', 'deprecation_warnings', False)
    c.set_config_attr('DEFAULT', 'roles_path', 'test/data/test_roles/')

    pbc = PlaybookCLI(args=['playbook1.yml'])
    pbc.run()

# Generated at 2022-06-10 22:20:27.607922
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    pb = PlaybookCLI(['--connection', 'local', '--limit', 'localhost', '../../tests/test_playbooks/playbook_cli_test.yml'])
    context.CLIARGS = vars(pb.options)
    pb.run()


# Generated at 2022-06-10 22:20:28.270438
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:20:41.452752
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Patch global method get_task_vars which is used in PlaybookCLI
    # Method PlaybookCLI._flush_cache calls get_task_vars
    # get_task_vars is used in lots of places so it is global variable
    # Both are used for testing
    temp_func = CLI.get_task_vars
    def _get_task_vars(self, host, task):
        vars = dict()
        vars['ansible_all_ipv4_addresses'] = ['192.168.1.1', '10.1.1.1']
        vars['ansible_all_ipv6_addresses'] = ['fe80::1', '2002::1']
        return vars
    CLI.get_task_vars = _get_task_vars

    # Patch global method get

# Generated at 2022-06-10 22:20:46.350717
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # PlaybookCLI.run() relies on setup supplied by PlayCLI, so we need to
    # supply some of the same functionality.
    # For example, it calls AnsibleRunner, which takes a list of args.
    # We need to create
    # one of those, but don't want to make the PlayCLI module available, so
    # we'll just create a list that looks like the argv list

    # This test uses the self.playbooks for module_utils.common
    # We could use argv_list to create a list of self.playbooks
    # But let's just use the first one for now
    # Also, let's leave out the other self.playbooks for now.

    # We need to add playbook into the CLIARGS
    playbook = ['/opt/ansible/test/playbooks/1.yml']
    #

# Generated at 2022-06-10 22:20:49.749531
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    context.CLIARGS = {'subset': None, 'flush_cache': None, 'listhosts': None, 'listtags': None, 'listtasks': None,
                       'syntax': None, 'step': None, 'start_at_task': None, 'args': [], 'diff': None,
                       'tags': [], 'skip_tags': [], 'check': None, 'verbosity': 0}

# Generated at 2022-06-10 22:21:00.585724
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:08.816007
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # One and only one source of input data - it is a simple string
    # prepared in advance and provided by the test.
    # Parsing of a string into a dictionary is available and widely tested,
    # so it can be handled by the original parser.
    input_data = "{'args': ['./test_playbook.yml'], 'listtasks': True, 'verbosity': 4}"
    parsed_input = CLI.base_parser(input_data, PlaybookCLI, "playbook")
    p = PlaybookCLI(parsed_input)
    assert p.run() == 0


# Generated at 2022-06-10 22:21:09.901533
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:11.002490
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass


# Generated at 2022-06-10 22:21:24.681785
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # create input data
    import tempfile
    (fd, path_pwd) = tempfile.mkstemp()
    (fd, path_vault) = tempfile.mkstemp()
    (fd, path_exclude) = tempfile.mkstemp()
    with open(path_pwd, 'w') as fd:
        fd.write('')
    with open(path_vault, 'w') as fd:
        fd.write('')
    with open(path_exclude, 'w') as fd:
        fd.write('')

    from ansible.cli import CLI
    from argparse import Namespace
    args = Namespace()
    args.ask_pass = False
    args.ask_vault_pass = False
    args.lookup_plugins = ''
   

# Generated at 2022-06-10 22:21:27.877422
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PL_CLI = PlaybookCLI()
    PL_CLIAPI = PlaybookCLI(args=[])
    PL_CLI.run()
    PL_CLIAPI.run()

# Generated at 2022-06-10 22:21:31.411042
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook = PlaybookCLI(['/tmp/test_PlaybookCLI_run_playbook.yml'])
    assert playbook is not None
    playbook.run()

# Generated at 2022-06-10 22:21:32.246677
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:34.690524
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert PlaybookCLI.run() == None, "test_PlaybookCLI_run failed!"


# Generated at 2022-06-10 22:21:38.707540
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Tests if the right exception is raised if a playbook is not found

    instance = PlaybookCLI()
    instance.options = {'ask_pass': False, 'ask_become_pass': False}
    instance.args = ['playbook.yml']

    try:
        instance.run()
    except AnsibleError:
        pass

# Generated at 2022-06-10 22:22:05.136043
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    namespace = lambda: None

    import ansible.config.manager
    conf_mgr = ansible.config.manager.ConfigManager(None)

    namespace.listtasks = None
    namespace.become_method = None
    namespace.connection = 'ssh'
    namespace.listtags = None
    namespace.step = None
    namespace.start_at_task = None
    namespace.verbosity = 0
    namespace.syntax = None
    namespace.tags = None
    namespace.check = False
    namespace.diff = False
    namespace.force_handlers = False
    namespace.flush_cache = False
    namespace.extra_vars = None
    namespace.show_custom_stats = None
    namespace.module_path = None
    namespace.skip_tags = None
    namespace.inventory = None
    namespace.subset = None


# Generated at 2022-06-10 22:22:17.080914
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    from ansible.cli import CLI
    from ansible.plugins.loader import add_cli_opt, get_cli_opts

    parser = CLI.base_parser(
        runas_opts=True,
        vault_opts=True,
        output_opts=True,
        check_opts=True,
        runtask_opts=True,
        connect_opts=True,
        subset_opts=True,
        fork_opts=True,
        module_opts=True,
    )

    subparsers = parser.add_subparsers(metavar='{test}' + ' [test-options]', dest='module_name')
    add_cli_opt(subparsers.add_parser('test', description="Test description", help='Example test help'), test=True)

   

# Generated at 2022-06-10 22:22:18.744697
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """This is a test method for PlaybookCLI class
    """
    pass

# Generated at 2022-06-10 22:22:28.465958
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class options:
        pass

    mock_args = ['playbook.yml']
    mock_options = options()
    mock_options.listhosts = None
    mock_options.listtasks = None
    mock_options.listtags = None
    mock_options.syntax = None
    mock_options.connection = 'ssh'
    mock_options.module_path = None
    mock_options.forks = 5
    mock_options.remote_user = None
    mock_options.private_key_file = None
    mock_options.ssh_common_args = None
    mock_options.ssh_extra_args = None
    mock_options.sftp_extra_args = None
    mock_options.scp_extra_args = None
    mock_options.become = False
    mock_options.become

# Generated at 2022-06-10 22:22:39.650475
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Arrange
    from ansible.executor import module_common

    class Play():
        class Task():
            def __init__(self, name, tags, action, implicit):
                self.name = name
                self.tags = tags
                self.action = action
                self.implicit = implicit
            def get_name(self):
                return self.name

        def __init__(self, name, hosts, tags, tasks):
            self.name = name
            self.hosts = hosts
            self.tags = tags
            self.tasks = tasks
            self.compile = lambda: [self]
            self.filter_tagged_tasks = lambda all_vars: self

        def block(self):
            return self.tasks

        def has_tasks(self):
            return self.tasks is not None

# Generated at 2022-06-10 22:22:40.221140
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:22:41.492485
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pb = PlaybookCLI()
    pb.run()



# Generated at 2022-06-10 22:22:51.781749
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """ PlaybookCLI - run() """
    import doctest
    from ansible.cli.playbook import PlaybookCLI
    from ansible.errors import AnsibleError
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping


# Generated at 2022-06-10 22:22:52.309396
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass  # TODO

# Generated at 2022-06-10 22:22:52.866520
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:23:47.786135
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:23:55.009097
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class Options:
        listhosts = False
        listtasks = False
        listtags = False
        syntax = False
        subset = None
        limit = None
        inventory = 'inventory'
        flush_cache = False

    class PlaybookCLI_class:
        def __init__(self):
            self.args = "test_file"
            self.options = Options()
            self.parser = True

    PlaybookCLI_result = PlaybookCLI_class()
    PlaybookCLI_result.run()

# Generated at 2022-06-10 22:24:03.766338
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    ac = {
        'args': ['.'],
        'check': False,
        'flush_cache': False,
        'host_key_checking': True,
        'listhosts': False,
        'listtags': False,
        'listtasks': False,
        'module_path': None,
        'start_at_task': None,
        'step': False,
        'subset': None,
        'syntax': False,
        'verbosity': 0,
        'version': False,
        'check': False,
        'diff': False,
        'timeout': 10,
        'run_once': False
    }

    cli = PlaybookCLI(ac)
    cli.run()

# Generated at 2022-06-10 22:24:09.520564
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Given
    ansible_args = [
        'ansible-playbook',
        'pb1.yml'
    ]
    cli = PlaybookCLI(args=ansible_args)

    # When
    result = cli.run()

    # Then
    assert result == 0

# Generated at 2022-06-10 22:24:22.460085
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # The purpose of this test is to see if PlaybookCLI.run() is working as expected.
    # To do this, we need to create a Ansible options object assign some values
    # to it, and then pass it to PlaybookCLI.run() to see if it returns the expected
    # result.
    # To make this test work, we need the following:
    # 1. A CLI options object (which will be passed to PlaybookCLI.run())
    # 2. A variable manager object for the variable_manager
    # 3. A list of playbooks to be executed

    # Create a CLI options object
    context.CLIARGS = {}

# Generated at 2022-06-10 22:24:23.264058
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:24.561729
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    PlaybookCLI.run()

# Generated at 2022-06-10 22:24:36.550172
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """ playbooks.tests.test_PlaybookCLI_run """

    from ansible.cli.playbook import PlaybookCLI
    from ansible.utils.display import Display
    class MyCLI(PlaybookCLI):
        pass

    my_display = Display()
    my_options = None
    args_args = ['playbook.yml']

# Generated at 2022-06-10 22:24:37.174593
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:43.184502
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create an instance of class PlaybookCLI
    pbcli = PlaybookCLI([])

    # Create an instance of class PlayCLI
    class PlayCLI(CLI):
        def run(self):
            return 0

    context._init_global_context(PlayCLI())

    # Test whether run() method is returning 0
    assert pbcli.run() == 0



# Generated at 2022-06-10 22:25:57.259948
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import tempfile
    import shutil
    import os

    # test init
    fd, fpath = tempfile.mkstemp()
    fpath = os.path.join(fpath, 'playbook')
    os.makedirs(fpath)
    shutil.copy('./test/integration/ansible_playbook/test_playbook.yml', fpath)
    cli = PlaybookCLI(['test_playbook.yml'])
    cli.options = lambda: None
    setattr(cli.options, 'step', True)
    setattr(cli.options, 'listhosts', True)
    setattr(cli.options, 'listtasks', True)
    setattr(cli.options, 'listtags', True)
    setattr(cli.options, 'syntax', True)

# Generated at 2022-06-10 22:26:05.878475
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    plugin_loaders = []
    for p in C.DEFAULT_LOADERS:
        loader = getattr(__import__('ansible.plugins.loader', fromlist=[p]), p)
        if not loader:
            raise Exception("failed to import plugin type %s" % p)
        plugin_loaders.append(loader)
    cli = PlaybookCLI()
    cli.plugin_loaders = plugin_loaders
    cli.args = ['test_playbook.yml']
    cli.parser = None
    cli.parser = cli.create_parser()
    cli.post_process_args()
    cli.run()



# Generated at 2022-06-10 22:26:11.542070
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys
    context._init_global_context(CLIArgs(args=[sys.argv[0]]))
    context.CLIARGS['args'] = ['playbook.yml']
    context.CLIARGS['flush_cache'] = True

    inventory = None
    variable_manager = None

    class PlaybookCLI_Mock(PlaybookCLI):
        def _play_prereqs(self):
            return (None, inventory, variable_manager)

    cli = PlaybookCLI_Mock()
    cli.run()

# Generated at 2022-06-10 22:26:12.025445
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:26:16.214929
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Arrange
    args = ['test.yml']
    try:
        pbc = PlaybookCLI(args)
    except Exception as e:
        print(e)
        assert False

    # Act
    pbc.run()

    # Assert
    # TODO: Find a way to test this
    assert True



# Generated at 2022-06-10 22:26:21.866115
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """unit test for method run"""
    config = {'listtags': [], 'listtasks': [], 'args': 'playbook.yml', 'verbosity': 0}
    cli = PlaybookCLI(['-l', 'localhost', '-i', 'hosts', 'playbook.yml'])
    cli.parse()

    assert cli.run() == 0


# Generated at 2022-06-10 22:26:31.198554
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Arrangement
    # Assume that when ask_passwords method is called it returns (None, None)
    # and that when _play_prereqs is called it returns (loader, inventory, variable_manager)
    # and that when get_host_list is called it returns {}

    cli_class = PlaybookCLI()
    cli_class.ask_passwords = lambda: (None, None)
    cli_class._play_prereqs = lambda: (loader, inventory, variable_manager)
    cli_class.get_host_list = lambda inventory, subset: {}

    # Act
    # Assume that when run method is called it returns results
    results = cli_class.run()

    # Assert
    # Assume that pbex.run returns results
    assert results == results

# Generated at 2022-06-10 22:26:31.929951
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    return True

# Generated at 2022-06-10 22:26:44.412792
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Initializes the argument parser
    parser = CLI.base_parser(
        usage="%prog [options] playbook.yml [playbook2 ...]",
        connect_opts=True,
        meta_opts=True,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        inventory_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True
    )
    # Adds the additional command line arguments to arg parser
    parser.add_argument('--list-tasks', dest='listtasks', action='store_true',
                        help="list all tasks that would be executed")

# Generated at 2022-06-10 22:26:51.047992
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args = CLI.base_parser(constants=C, runas_opts=True, output_opts=True, runtask_opts=True, vault_opts=True, fork_opts=True, module_opts=True, check_opts=True).parse_args('-vvv play.yml'.split())
    cli = PlaybookCLI.from_args(args)
    print(cli)

# test_PlaybookCLI_run()

# Generated at 2022-06-10 22:29:05.734581
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass


# Generated at 2022-06-10 22:29:07.018868
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    Unit test for method run of class PlaybookCLI

    """
    p = PlaybookCLI()
    p.run()

# Generated at 2022-06-10 22:29:11.591596
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class AnsibleCliOptions():
        verbosity = 1
        listhosts = True
        listtasks = True
        listtags = True
        syntax = True
        flush_cache = True
        subset = ''
        tags = ''
        skip_tags = ''
        limits = ''
        start_at_task = ''
        args = ['playbook.yml']
    context.CLIARGS = AnsibleCliOptions()
    pb = PlaybookCLI()

    try:
        pb.run()
    except SystemExit:
        pass

# Generated at 2022-06-10 22:29:12.047246
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:29:12.973332
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pb = PlaybookCLI()
    pb.run()

# Generated at 2022-06-10 22:29:21.401497
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class FakeCLIARGS:
        flush_cache = False
        listtags = False
        listtasks = False
        subset = None
        verbosity = 0
        syntax = False
        start_at_task = None
        step = False
        args = ""
    class FakeOptions:
        def __init__(self, flush_cache, listtags, listtasks, subset, verbosity, syntax, start_at_task, step, certificate_info):
            self.flush_cache = flush_cache
            self.listtags = listtags
            self.listtasks = listtasks
            self.subset = subset
            self.verbosity = verbosity
            self.syntax = syntax
            self.start_at_task = start_at_task
            self.step = step
            self.certificate_info = certificate_info



# Generated at 2022-06-10 22:29:31.372180
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
