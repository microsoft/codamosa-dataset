

# Generated at 2022-06-10 22:19:38.871305
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:19:46.812292
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import sys
    from ansible.module_utils.six import b
    from ansible.parsing.vault import VaultLib

    class Options(object):
        def __init__(self):
            self.listhosts = False
            self.listtasks = False
            self.listtags = False
            self.syntax = False
            self.connection = 'ssh'
            self.module_path = None
            self.forks = 5
            self.remote_user = None
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = False
            self.become_method = 'sudo'


# Generated at 2022-06-10 22:19:57.862403
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Note that calling test cases need to provide a command line
    # that provides an inventory file, and at least one valid playbook.
    # For example:
    #
    # python test/units/cli/cli_test.py
    #   --inventory test/units/inventory/hosts \
    #   --playbook test/units/playbooks/subset_inventory.yml \
    #   TestPlaybookCLI.test_run \

    # Get the list of options in the CLI class
    options = PlaybookCLI.parse()

    assert options is not None

    assert options.subset is not None

    # Need to set the options for internal use
    context.CLIARGS = options

    # Note that the CLI class also has an run method, but I would prefer
    # (for unit testing purposes) to not have that one called.

# Generated at 2022-06-10 22:20:06.593574
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    display.verbosity = 5
    ansible_path = os.path.realpath(os.path.join(os.path.dirname(__file__), '../'))
    test_playbook = os.path.join(ansible_path, 'test/sanity/cli/test.yml')
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader, 'localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-10 22:20:07.715028
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI().run()

# Generated at 2022-06-10 22:20:12.623737
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    Test the run method of class PlaybookCLI

    """
    test_playbook_cli = PlaybookCLI()
    test_playbook_cli.init_parser()
    context.CLIARGS = {'args': 'test_playbook'}
    test_playbook_cli.run()

# Generated at 2022-06-10 22:20:22.337655
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.utils.collection_loader._collection_finder import _get_collection_base_path, COLLECTIONS_PATH_ENVVAR

    from ansible.cli.playbook import PlaybookCLI

    fake_playbook = '''
    - hosts: all
      tasks:
        - name: try to get facts
          setup:
    '''

    # create fake playbook 'test'
    os.environ[COLLECTIONS_PATH_ENVVAR] = '/tmp/ansible_collections'
    test_playbook_path = _get_collection_base_path() + "/test/test_collection.yml"

# Generated at 2022-06-10 22:20:23.398326
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI().run()

# Generated at 2022-06-10 22:20:36.914214
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # The following values are shared across test cases
    ansible_playbook_cmd = ["ansible-playbook"]
    playbook_path = "../../../examples/ansible-playbooks/example-playbook.yaml"
    playbook_fullpath = os.path.realpath(os.path.join(os.getcwd(), playbook_path))

    #
    # Test case 1: With list option
    #

    class MockDisplay:
        def __init__(self):
            # The following variables are used to store the values passed to various display method calls
            self.verbosity = None
            self.msg = None

        def display(self, msg):
            # Store the messages passed to display method
            self.msg = msg


# Generated at 2022-06-10 22:20:47.385162
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = CLI()
    cli.parser = CLI.base_parser(add_help=False)
    cli.options, cli.args = cli.parser.parse_known_args()
    cli.options.listhosts = True
    cli.options.listtasks = False
    cli.options.listtags = False
    cli.options.syntax = False
    cli.options.connection = 'local'
    cli.options.module_path = None
    cli.options.forks = 5
    cli.options.private_key_file = None
    cli.options.ssh_common_args = None
    cli.options.ssh_extra_args = None
    cli.options.sftp_extra_args = None
    cli.options.scp_extra_

# Generated at 2022-06-10 22:21:08.211195
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    
    # import and define required objects
    from ansible.plugins.loader import plugins
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    
    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    
    options = Options(connection='smart', module_path='/path/to/mymodules', forks=10, become=None, become_method=None, become_user=None, check=False, diff=False)
    
    loader = DataLoader()
    passwords = dict(conn_pass=None, become_pass=None)
    

# Generated at 2022-06-10 22:21:20.990926
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """Unit test of PlaybookCLI.run
    """
    # Tests run a command line, either a playbook or ad hoc,
    # and verify it succeeds or fails as expected.
    # Test for command line success

    # Test for command line failure
    # Test for command line failure
    from ansible.utils.display import Display
    from ansible.cli.playbook import PlaybookCLI

    display = Display()
    command_line = 'test'
    options = {}
    args = ['/etc/ansible/test.yml']
    with pytest.raises(AnsibleError) as exc:
        cli = PlaybookCLI()
        cli.run()
    msg = 'the playbook: /etc/ansible/test.yml could not be found'
    assert exc.match(msg)

# Generated at 2022-06-10 22:21:33.293811
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.strategy import StrategyBase

    class MockCLI(object):
        parser = None

        def __init__(self):
            self.parser = None

        def init_parser(self):
            self.parser = None

        def post_process_args(self, options):
            return options

        def run(self):
            return 0

    # basic test
    cli = MockCLI()
    cli.init_parser()
    (options, args) = cli.parser.parse

# Generated at 2022-06-10 22:21:41.367991
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a test object PlaybookCLI
    from ansible.cli.playbook import PlaybookCLI
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    import os
    import sys


    class MockCLIRunner(object):
        def __init__(self):
            self.options = {}

        def run(self):
            return 0

    class MockOption(object):
        def __init__(self, args, values):
            i = 0

# Generated at 2022-06-10 22:21:48.117564
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # This is a unit test for method run of class PlaybookCLI.
    #
    # Note: There is no doc string for this method as it is not meant to
    # be a part of the public API.
    #
    # Here we are testing the presence of the __doc__ attribute
    # and that it is a string.

    assert PlaybookCLI.run.__doc__

    assert isinstance(PlaybookCLI.run.__doc__, str)

# Generated at 2022-06-10 22:21:48.983609
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:53.238531
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.adhoc import AdHocCLI

    # set up for collecting stdout, stderr, and logging
    output_stdout = []
    output_stderr = []

    def _stdout_mock(out):
        output_stdout.append(out)

    def _stderr_mock(err):
        output_stderr.append(err)

    # insert mock methods
    display.display = _stdout_mock
    display.display = _stderr_mock


# Generated at 2022-06-10 22:21:54.082825
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  assert True

# Generated at 2022-06-10 22:21:54.642372
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:57.430053
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI.add_file_logger(logger='playbook', log_path='/dev/null')
    print(PlaybookCLI.run())

# Generated at 2022-06-10 22:22:23.057723
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO:
    #   - test all options
    #   - move better to integration tests
    pass

# Generated at 2022-06-10 22:22:30.720994
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:22:31.884251
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:22:32.689841
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert True

# Generated at 2022-06-10 22:22:42.754752
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Given
    class MyPlaybookExecutor(object):
        def __init__(self, *args, **kwargs):
            pass

        def run(self):
            return []

    class MyOptionParser(object):
        def __init__(self, *args, **kwargs):
            pass

        def parse_args(self):
            return None

    class MyAction(object):
        def __init__(self, *args, **kwargs):
            pass

    class MyArgumentParser(object):
        def __init__(self, *args, **kwargs):
            pass

        def add_argument(self, *args, **kwargs):
            return None

        def add_option(self, *args, **kwargs):
            return None


# Generated at 2022-06-10 22:22:53.046564
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys

    from ansible.cli.playbook import PlaybookCLI
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display
    from ansible.executor.playbook_executor import PlaybookExecutor

    data_loader = DataLoader()

    inventory = InventoryManager(loader=data_loader, sources=[])
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)
    display

# Generated at 2022-06-10 22:23:04.517932
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    sys.modules['ansible'] = mock_ansible_module()

    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-10 22:23:17.276320
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Mock class for the Ansible Playbook Executor
    class MockPlaybookExecutor:
        def __init__(self, playbooks, inventory, variable_manager, loader, passwords):
            pass

        def run(self):
            return [{
                'playbook': "playbook.yml",
                'plays' : [{
                    '_included_path': None,
                    'hosts': ['127.0.0.1'],
                    'name': 'Example Playbook',
                    'tags': ['example-tag']
                }]
            }]


    # Mock class for Ansible Command Line arguments
    class MockCLIArgs:
        def __init__(self, inventory, args, listhosts, listtags, listtasks, verbosity):
            self.inventory = inventory
            self.args = args

# Generated at 2022-06-10 22:23:19.397384
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI(args=[])
    assert cli.run() == 0

# Generated at 2022-06-10 22:23:20.112104
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:19.891074
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # instantiate object
    cli = PlaybookCLI()
    # initialize the parser
    cli.init_parser()
    cli.parse()
    # post process options
    cli.post_process_args()
    # run command
    cli.run()
    # TODO: implement assertions

# Generated at 2022-06-10 22:24:33.086804
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    pb = PlaybookCLI()
    context.CLIARGS = {'args': ["playbook1.yml", "playbook2.yml"],
                       'listtasks': True,
                       'listtags': False,
                       'step': True,
                       'start_at_task': 'start_task',
                       'listhosts': False,
                       'subset': '',
                       'flush_cache': False,
                       'verbosity': 0}

    pb.post_process_args(context.CLIARGS)

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-10 22:24:43.971176
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Have to do this before we load modules
    for i in add_all_plugin_dirs(os.path.dirname(__file__) + "/../lib/ansible/modules/core"):
        sys.path.insert(0, i)
    # Have to do this before we load collections
    for i in add_all_plugin_dirs(os.path.dirname(__file__) + "/../lib/ansible/collections/ansible"):
        sys.path.insert(0, i)

    # define a test class
    class TestPlaybookCLI(PlaybookCLI):
        def post_process_args(self, options):
            return super(TestPlaybookCLI, self).post_process_args(options)

        def _play_prereqs(self):
            return mock_loader, mock_

# Generated at 2022-06-10 22:24:44.531230
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI.run()

# Generated at 2022-06-10 22:24:45.188815
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:46.273711
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """test_PlaybookCLI_run"""

    pass

# Generated at 2022-06-10 22:24:55.879833
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    import os

    # create dummy inventory
    inventory = InventoryManager(loader=DataLoader(), sources='')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    context.CLIARGS = {}
    context.CLIARGS['flush_cache'] = False
    context.CLIARGS['listtags'] = True
    context.CLIARGS['listtasks'] = True
    context.CLIARGS['listhosts'] = True
    context.CLIARGS['diff'] = True
    context.CLIARGS['syntax'] = True
    context

# Generated at 2022-06-10 22:24:57.668297
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """Return a dict with results of run()."""
    cli = PlaybookCLI()
    cli.parse()
    return cli.run()

# Generated at 2022-06-10 22:25:09.277060
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('test_PlaybookCLI_run')
    cli = PlaybookCLI()
    args = ['test.yml']
    cli.parse()
    options = cli.post_process_args(args)
    assert options.ask_vault_pass == False
    assert options.become == True
    assert options.become_ask_pass == None
    assert options.become_method == 'sudo'
    assert options.become_user == 'root'
    assert options.check == False
    assert options.connection == 'smart'
    assert options.diff == False
    assert options.extra_vars == []
    assert options.flush_cache == None
    assert options.inventory_file == ''
    assert options.listhosts == False
    assert options.listtags == False
    assert options.listtasks

# Generated at 2022-06-10 22:25:20.967937
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import json

    class Options(object):

        def __init__(self):
            self.verbosity = 4
            self.listtasks = False
            self.listtags = False
            self.step = False
            self.start_at_task = None
            self.args = []

    class FakePlaybook(object):

        def __init__(self):
            self.inventory = FakeInventory()
            self.loader = FakeLoader()
            self.variable_manager = FakeVariableManager()
            self.passwords = {}

        def run(self):
            return ""

    class FakeInventory(object):
        def __init__(self):
            self.list_hosts = lambda: ""

    class FakeVariableManager(object):
        def __init__(self):
            self.clear_facts = lambda: ""


# Generated at 2022-06-10 22:26:28.957786
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:26:40.948127
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli import CLI

    CLI.setup();
    cli = PlaybookCLI(args=['playbook.yml'])
    cli.parse()

    with patch('ansible.cli.CLI.ask_passwords') as ask_passwords:
        with patch('ansible.cli.CLI._play_prereqs') as _play_prereqs:
            with patch('ansible.executor.playbook_executor.PlaybookExecutor.run') as run:
                run.return_value = 1
                cli.run()

                # assert
                ask_passwords.assert_called_once()
                _play_prereqs.assert_called_once()
                run.assert_called_once()

# Generated at 2022-06-10 22:26:45.428542
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class Options:
        connection = 'smart'
        forks = 10
        ask_pass = False
        private_key_file = '/path/to/file'
        remote_user = 'someuser'
        verbosity = 0
        listhosts = False
        listtasks = False
        listtags = False
        syntax = False
        subset = None
        check = False
        diff = False
        inventory = None
        extra_vars = None
        extra_vars_file = None
        vault_password_files = None
        run_once = False
        start_at_task = None
        step = False
        args = ['/path/to/file']

    class Context:
        CLIARGS = Options

    context = Context
    p = PlaybookCLI(context)
    p.run()

# Generated at 2022-06-10 22:26:48.991763
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test = PlaybookCLI(['unittest', 'tests/test_data/test_playbook.yml'])
    try:
        test.run()
    except SystemExit:
        assert True
        return
    assert False

# Generated at 2022-06-10 22:26:54.378792
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import ansible.utils.plugin_docs as plugin_docs
    args = [
        'playbook.yml',
    ]
    options = opt_help.parse_cli_args(args)
    cli = PlaybookCLI(args)
    context.CLIARGS = plugin_docs.load_options(options)
    options = cli.post_process_args(options)
    display.verbosity = options.verbosity
    # TODO: need to find a way to test this function
    cli.run()

# Generated at 2022-06-10 22:27:05.065974
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.utils.vars import combine_vars

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display

# Generated at 2022-06-10 22:27:16.052983
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.constants import DEFAULT_HOST_LIST, DEFAULT_MODULE_NAME, DEFAULT_MODULE_PATH, DEFAULT_MODULE_ARGS, DEFAULT_FORKS
    from ansible.inventory import Inventory, Host
    from ansible.vars.manager import VariableManager
    import os
    import tempfile

    # test one
    # prepare a test environment
    test_env_path = tempfile.mkdtemp()
    os.environ['ANSIBLE_CONFIG'] = os.path.join(test_env_path, 'ansible.cfg')
    os.environ['ANSIBLE_ROLES_PATH'] = os.path.join(test_env_path, 'roles')

# Generated at 2022-06-10 22:27:26.474530
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # setup test system
    # set a request for verbosity
    context.CLIARGS = {'verbosity': 2, 'args': ['test_data/host_vars/host_vars.yml']}

    # init the playbook
    cli = PlaybookCLI(args=[])
    cli.parse()
    cli.post_process_args(cli.options)
    cli.run()

    assert context.CLIARGS['verbosity'] == 2
    assert context.CLIARGS['args'] == ['test_data/host_vars/host_vars.yml']

# Generated at 2022-06-10 22:27:39.474429
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class CLIArgs(object):
        '''
            Temporary class to hold a mock of context.CLIARGS and implement an
            indexer to access the args attribute.
        '''
        def __init__(self):
            self.args = []

        def __getitem__(self, key):
            if key == 'args':
                return self.args
            else:
                raise KeyError(key)

    def get_host_list(inventory, subset):
        return True
    def ask_passwords():
        return (None, None)
    def _play_prereqs():
        return (None, None, None)

    class PlaybookExecutor(object):
        '''
            Temporary class for mocking the PlaybookExecutor.  Returns a list of
            playbooks that are passed to the constructor.
        '''
       

# Generated at 2022-06-10 22:27:50.802132
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.constants import DEFAULT_MODULE_PATH
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    mock_loader = DataLoader()
    mock_inventory = InventoryManager(loader=mock_loader, sources=[])
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)
