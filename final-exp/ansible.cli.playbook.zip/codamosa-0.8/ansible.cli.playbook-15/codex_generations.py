

# Generated at 2022-06-10 22:19:56.255897
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # This is an example of how to write a unit test for the method run of class PlaybookCLI
    # To execute this test use the following command: python -m ansible.cli.playbook as an
    # alternative, you can add this method to an existing test class.
    # Here just a simple test:
    from ansible.cli.playbook import PlaybookCLI
    from ansible.plugins.loader import add_all_plugin_dirs
    
    # Setup your test environment
    add_all_plugin_dirs()
    playbook_cli = PlaybookCLI()
    playbook_cli.base_parser = playbook_cli.init_parser()
    playbook_cli.options = playbook_cli.base_parser.parse_args()
    playbook_cli.post_process_args(playbook_cli.options)

    # Call the method

# Generated at 2022-06-10 22:19:56.862183
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:19:57.991531
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbookcli = PlaybookCLI()
    playbookcli.run()

# Generated at 2022-06-10 22:20:06.672756
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class FakeOptions(object):
        verbosity = 0
        listhosts = False
        listtasks = False
        listtags = False
        syntax = False
        flush_cache = False
        subset = None
        start_at_task = None

        def __init__(self, args):
            self.args = args

    PlaybookCLI.ask_passwords = lambda x: (None, None)
    PlaybookCLI._play_prereqs = lambda x: (None, None, None)
    PlaybookCLI._flush_cache = lambda x, y: None

    class FakePbex(object):
        def __init__(self, playbook, inventory, variable_manager, loader, passwords):
            pass

        def run(self):
            return 0

    PlaybookCLI.PlaybookExecutor = FakePbex


# Generated at 2022-06-10 22:20:18.142129
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys
    
    # I have to implement a parser object to pass it to PlaybookCLI.__init__
    # Although it makes the unit test dependent of the implementation details
    # of the parser module, I choose to manually create the parser object to avoid
    # the import of optparse, argparse or whatever parser is used.
    from ansible.cli import CLI
    from ansible.cli.argparser import Parser
    parser = Parser(
        usage='%prog [options] playbook.yml [playbook2 ...]', 
        epilog='See "ansible-doc -t playbook CLI" for details.',
        formatter_class=lambda prog: optparse.HelpFormatter(prog, max_help_position=30))

# Generated at 2022-06-10 22:20:19.945794
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """ unit testing of method run of class PlaybookCLI """
    pass

# Generated at 2022-06-10 22:20:22.451984
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI(args = [])
    cli.run()
    assert 1 ==1

# Generated at 2022-06-10 22:20:35.911260
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os

    # Fake run to create OPTIONS, can be removed when RunCLI.run is modified
    class FakeOptions():
        def __init__(self):
            self.verbosity = 0
            self.inventory = 'inventory/test'
            self.module_path = os.path.join(os.path.dirname(__file__), '../../../')
            self.listhosts = False
            self.listtags = False
            self.listtasks = False
            self.syntax = False
            self.connection = 'local'
            self.timeout = 10
            self.forks = 5
            self.remote_user = 'root'
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra

# Generated at 2022-06-10 22:20:36.599521
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:20:37.239400
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:20:50.071005
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Initializing PlaybookCLI object with args
    pbcli = PlaybookCLI(['-i',
                         'test_inventory',
                         '-l',
                         'test_host',
                         'test_playbook'])

    # Executing run method
    pbcli.run()

# Generated at 2022-06-10 22:20:50.840963
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert True

# Generated at 2022-06-10 22:20:52.466722
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:20:53.464668
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI.run()

# Generated at 2022-06-10 22:21:05.804232
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #
    # Create test fixtures
    #
    # This inner function can be called from the test cases to create a PlaybookCLI
    # object with a test instance of the parser object.
    #
    # It is assumed that the PlaybookCLI object is instantiated with test fixtures
    # in the following test cases:
    #
    #   - test_PlaybookCLI_run_syntax_error
    #   - test_PlaybookCLI_run_playbook_not_found
    #   - test_PlaybookCLI_run_something_else
    #
    def _create_PlaybookCLI(args):
        import argparse
        parser = argparse.ArgumentParser()
        PlaybookCLI.init_parser(parser)
        parsed_args = parser.parse_args(args)
        cli = Playbook

# Generated at 2022-06-10 22:21:10.724891
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    config_data = {}
    config_data['ANSIBLE_HOST_KEY_CHECKING'] = 'False'
    config_data['ANSIBLE_DEPRECATION_WARNINGS'] = 'False'
    config_data['ANSIBLE_KEEP_REMOTE_FILES'] = 'True'

    cli = PlaybookCLI(['-i', 'local,'])
    cli.parse()
    cli.post_process_args(cli.options)
    cli.run()

# Generated at 2022-06-10 22:21:24.176509
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a mock inventory and playbook executor
    from tempfile import TemporaryDirectory
    from ansible.vars.manager import VariableManager

    # Create a mock loader for the loader object
    def __init__(self, *args, **kwargs):
        self.inventory = None

    def set_basedir(self, p1):
        pass

    class mock_loader:
        def __init__(self, *args, **kwargs):
            pass

    # Create a mock inventory
    inventory = []

    # Create a mock variable manager
    variable_manager = VariableManager()

    # Create a mock playbook executor
    class mock_playbook_executor:
        def run(self, *args, **kwargs):
            return 0


# Generated at 2022-06-10 22:21:34.900513
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    pbcli = PlaybookCLI(['tests/test_utils/test_playbooks/syntax-ok.yml', 'tests/test_utils/test_playbooks/syntax-error.yml'])
    pbcli.options = pbcli.parser.parse_args([])

    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader, sources=['tests/test_utils/test_inventory/hosts'])
    variable_manager = VariableManager(loader=dataloader, inventory=inventory)

    pbcli.loader = dataloader
    p

# Generated at 2022-06-10 22:21:41.480109
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Initialize objects
    display = Display()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Dummy arguments
    args = {"listhosts": False, "listtasks": False, "listtags": False, "syntax": False}
    context.CLIARGS = args

    # Create fake playbook with fake hosts and tasks

# Generated at 2022-06-10 22:21:42.575024
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:22:03.709357
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''test run method of class PlaybookCLI'''

    # Note: In this test we are testing only if run() is called
    #       and that it is called with expected variables.
    #       We are not testing the actual execution of the playbook
    #       with all its complexities. But the complexity of the code
    #       is reduced by using Mock object.
    import unittest.mock as mock

    # create an object for class PlaybookCLI
    obj = PlaybookCLI()

    # create a Mock object for class PlaybookCLI
    # which we will use for testing
    mck =  mock.Mock(spec = PlaybookCLI)

    # create a patch for the run method
    # we will use this patch to check if run method is called.

# Generated at 2022-06-10 22:22:15.976943
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class FakeOptions(object):
        verbosity = 0

    class FakeCLIARGS(object):
        module_path = None
        listhosts = False
        listtasks = False
        listtags = False
        syntax = False
        subset = None
        fork = 0
        timeout = 0
        connection = None
        remote_user = None
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = None
        become_method = None
        become_user = None
        become_ask_pass = False
        verbosity = 0
        check = False
        diff = True
        flush_cache = False
        inventory = None
        extra_vars = None

# Generated at 2022-06-10 22:22:17.133959
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    module = PlaybookCLI()
    module.run()

# Generated at 2022-06-10 22:22:18.429154
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI.run()

# Generated at 2022-06-10 22:22:26.014762
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pbcl = PlaybookCLI()
    pbcl.parser = pbcl.create_parser()
    pbcl.options, pbcl.args = pbcl.parser.parse_args(['--list-tasks', '--ask-pass', '--ask-become-pass',
                                                      '--diff','--check','--become','--verbose','--inventory','inventory','playbook.yml'])
    pbcl.args = ['ansible/test/unit/mock/fqcn-collection-playbook.yml']
    pbcl.run()

# Generated at 2022-06-10 22:22:28.036495
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    b = PlaybookCLI(args=['ansible_playbook_test_test_playbook_does_not_exist'])
    assert b.run() == 2

# Generated at 2022-06-10 22:22:39.518282
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pb_cli = PlaybookCLI(['/bin/ansible-playbook', '-i', 'foo.ini', '-c', 'local', '-u', 'foo',
                          '-m', 'raw', '-k', '-K', 'bar', '-s', '-v', '--extra-vars', 'x=y',
                          '--ask-sudo-pass', '--ask-pass', '--step', '--flush-cache', '--tags',
                          'foo,bar', '--skip-tags', 'baz', '--syntax-check', '--list-tasks',
                          '-e', '{foo: bar}', '--start-at-task', 'bar', '--list-tags', 'foo.yml'])
    pb_cli.init_parser()  #

# Generated at 2022-06-10 22:22:43.331317
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args = "--hosts localhost -t all test.yml"
    pb = PlaybookCLI(args.split())
    pb.run()

    args = "--hosts localhost -t all"
    pb = PlaybookCLI(args.split())
    pb.run()
    assert False

# Generated at 2022-06-10 22:22:45.065307
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    run_results = PlaybookCLI.run()
    assert run_results == 0

# Generated at 2022-06-10 22:22:49.459729
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''Unit test for method run of class PlaybookCLI'''
    playbook_cli = PlaybookCLI()
    context.CLIARGS = dict(listhosts=True, listtasks=True, listtags=True)
    assert playbook_cli.run() == 0



# Generated at 2022-06-10 22:23:21.488189
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli import CLI
    from ansible.utils.vars import AnsibleVars
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.config.manager import ConfigManager
    from io import StringIO
    import sys
    import os
    import stat
    import types

    # create base objects
    cli = PlaybookCLI()
    config_manager = ConfigManager()

# Generated at 2022-06-10 22:23:31.116041
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:23:38.114298
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    playbook_file = dir_path + '/../../../examples/meta/site.yaml'
    options = CLI.base_parser().parse_args(['-i', 'localhost,', playbook_file, '--list-tags'])
    p = PlaybookCLI(options)

    p.run()

# Generated at 2022-06-10 22:23:48.387910
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import mock
    from ansible.executor.task_queue_manager import TaskQueueManager

    instance = PlaybookCLI()

    # Test for list-tasks
    context.CLIARGS = {'listtasks': True}
    instance.run()

    # Test for list-tags
    context.CLIARGS = {'listtags': True}
    instance.run()

    # Test for inventory
    context.CLIARGS = {'inventory': 'inventory'}
    instance.run()

    # Test for subset
    context.CLIARGS = {'subset': 'subset'}
    instance.run()

    # Test for check
    context.CLIARGS = {'check': True}
    instance.run()

    # Test for diff

# Generated at 2022-06-10 22:23:58.254460
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import setup_module
    import ansible.utils.display
    args = ['playbook_cli', 'play.yml']

# Generated at 2022-06-10 22:24:10.700241
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class MockOptions(object):
        verbosity = opt_help.Verbosity(0)
        connection = 'local'
        module_path = None
        forks = opt_help.DeprecatedForkValue(100, None, False)
        become = False
        become_method = 'sudo'
        become_user = None
        check = False
        diff = False
        syntax = False
        flush_cache = False
        listhosts = True
        listtags = False
        listtasks = False
        step = False
        start_at_task = None
        args = ['tests/test_playbook_cli.yml']



# Generated at 2022-06-10 22:24:11.279813
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:12.243458
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert True

# Generated at 2022-06-10 22:24:25.815470
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class FakePbExec(object):
        def __init__(self):
            self.return_value = [1, 2, 3]

        def run(self):
            return self.return_value

    class FakeDisplay(object):
        def __init__(self):
            self.message = ''

        def display(self, msg):
            self.message = msg

    class FakeOptions(object):
        def __init__(self, args, verbosity=0):
            self.args = args
            self.verbosity = verbosity

    class FakePlaybook(object):
        def __init__(self, path):
            self.path = path
            self.hosts = 'hosts'
            self.name = 'name'
            self.tags = 'tags'
            self._included_path = None


# Generated at 2022-06-10 22:24:30.083333
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Create a CLI object and set the arguments
    cli = PlaybookCLI()
    cli.options = cli.parser.parse_args(['playbook.yml'])

    assert cli.run() == 0

# Generated at 2022-06-10 22:25:31.621109
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #TODO
    return None

# Generated at 2022-06-10 22:25:34.027585
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    src = 'tests' + os.path.sep + 'fixtures' + os.path.sep + 'test_playbook'
    playbook_file = src + os.path.sep + 'playbook.yml'
    cli = PlaybookCLI(args=[playbook_file])
    cli.run()
    loader = cli._play_prereqs()[0]
    assert loader.get_basedir() == src

# Generated at 2022-06-10 22:25:35.061714
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:25:41.653856
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # create base objects
    loader, inventory, variable_manager = CLI.get_play_prereqs([__file__])

    # create the playbook executor, which manages running the plays via a task queue manager
    pbex = PlaybookExecutor([__file__], inventory, variable_manager, loader, passwords=dict())

    results = pbex.run()

    assert(isinstance(results, int))

# Generated at 2022-06-10 22:25:54.271305
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import mock
    import sys

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    pbwrapper = mock.MagicMock()
    sys.modules['ansible.playbook'] = pbwrapper
    pbwrapper.Playbook.return_value = mock.MagicMock(
        run=mock.MagicMock(
            return_value=[mock.MagicMock(
                playbook='fake_playbook',
                plays=[mock.MagicMock(
                    name='fake_play',
                    tags=[],
                    _included_path='fake_included_path'
                )]
            )]
        )
    )

    pbcli = PlaybookCLI()


# Generated at 2022-06-10 22:25:54.870315
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:25:57.041462
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI(['test.yml'])
    cli.run()


# Generated at 2022-06-10 22:26:07.289818
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockPlaybookCLI(PlaybookCLI):
        def ask_passwords(self):
            return ("password", "become_password")
    pbcli = MockPlaybookCLI()

    class MockOptions:
        verbosity = 0
        connection = 'ssh'
        module_path = None
        forks = 5
        ask_pass = False
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = False
        become_method = 'sudo'
        become_user = 'root'
        become_ask_pass = False
        check = False
        diff = False
        listhosts = False
        listtags = False
        listtasks = False

# Generated at 2022-06-10 22:26:07.854640
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:26:14.941175
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from io import StringIO
    from ansible.utils.display import Display
    import sys
    import re

    class MyCLI(PlaybookCLI):

        def __init__(self):
            pass

        def parse(self):
            pass

        def post_process_args(self, options):
            return options

    class MyDisplay(Display):

        def __init__(self):
            pass

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            print(msg)

    class MyCLIArgs(object):
        def __init__(self):
            self.verbosity = 0
            self.connection = 'ssh'
            self.module_path = None
            self.forks = 0
            self.remote_user = None

# Generated at 2022-06-10 22:27:24.633068
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.vault import VaultLib
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path

    mocker.patch('ansible.cli.CLI.get_host_list')

    # prepare test setup
    add_all_plugin_dirs()
    collection_id = 'collection'
    collection_path = os.path.join(DATA_PATH, collection_id)
    AnsibleCollectionConfig.playbook_paths = [collection_path]

    # setup test data

# Generated at 2022-06-10 22:27:25.319726
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:27:28.847766
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: we need to be able to verify that options get saved properly,
    # and that the PlaybookCLI will pass them along to the PlaybookExecutor
    # when it is created. Currently, this has to be done through a private
    # variable access (to context.CLIARGS).
    pass

# Generated at 2022-06-10 22:27:30.467859
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    Unit test for method run of class PlaybookCLI
    '''
    pass

# Generated at 2022-06-10 22:27:42.833069
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # initial error check, to make sure all specified playbooks are accessible
    # before we start running anything through the playbook executor
    # also prep plugin paths
    b_playbook_dirs = []
    context.CLIARGS['args'] = ['playbook']
    for playbook in context.CLIARGS['args']:
        playbook_collection = _get_collection_name_from_path(playbook)
        if not playbook_collection:
            # setup dirs to enable loading plugins from all playbooks in case they add callbacks/inventory/etc
            b_playbook_dir = os.path.dirname(os.path.abspath(to_bytes(playbook, errors='surrogate_or_strict')))
            add_all_plugin_dirs(b_playbook_dir)
            b_playbook_dirs

# Generated at 2022-06-10 22:27:43.426232
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:27:53.884784
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible import context
    from ansible.cli.playbook import PlaybookCLI
    from ansible.cli.arguments import options

    context.CLIARGS = options.parse_args(
        args=[],
        version=None,
    )
    context.CLIARGS['listhosts'] = False
    context.CLIARGS['listtasks'] = False
    context.CLIARGS['listtags'] = False
    context.CLIARGS['syntax'] = False
    context.CLIARGS['flush_cache'] = False

    context.CLIARGS['module_path'] = None
    context.CLIARGS['forks'] = None
    context.CLIARGS['become'] = None
    context.CLIARGS['become_method'] = None
    context.CL

# Generated at 2022-06-10 22:28:02.251574
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """This test case is just to check whether the variable called as "results" in run() method of class PlaybookCLI
    is returned successfully.
    """
    pbCLI = PlaybookCLI()
    pbCLI.args = ['test.yml']
    pbCLI.parser = pbCLI.init_parser()
    pbCLI.options = pbCLI.parser.parse_args(pbCLI.args)
    pbCLI.check_deprecated_cli_options()
    pbCLI.post_process_args()
    assert pbCLI.run() == None

# Generated at 2022-06-10 22:28:11.517884
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Task
    display = Display()
    loader = None
    inventory = None
    variable_manager = None
    # Return value is expected to be an Ansible exit code
    ansible_exit_code = 0
    # To make test run in a clean environment
    curr_dir = os.path.dirname(os.path.dirname(__file__))
    curr_dir_path = os.path.abspath(curr_dir)
    sys.path.insert(1, curr_dir_path)
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

# Generated at 2022-06-10 22:28:14.287221
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI(['/usr/bin/ansible-playbook','my-playbook.yml'])
    assert cli.run() is None