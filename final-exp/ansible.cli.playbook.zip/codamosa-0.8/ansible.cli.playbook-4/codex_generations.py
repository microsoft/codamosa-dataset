

# Generated at 2022-06-10 22:19:47.409074
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # FIXME: there are a number of tests that need to be implemented here:
    #        * success
    #        * failure
    #        * empty playbook
    #        * missing playbook
    pass

# Generated at 2022-06-10 22:19:49.964954
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Test PlaybookCLI.run(self)
    # PlaybookCLI().run()
    pass



# Generated at 2022-06-10 22:20:00.457585
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    The following test case tests the run method of class PlaybookCLI
    """
    from unittest import mock
    from ansible.errors import AnsibleError
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs


# Generated at 2022-06-10 22:20:01.203774
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:20:11.926422
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.cli import CLI
    from collections import namedtuple

    class MockCLI(CLI):
        @staticmethod
        def parse():
            args = namedtuple('args', 'listhosts listtasks listtags syntax flush_cache subset')
            return args('', '', '', '', '', '')

        def init_parser(self):
            pass

    class MockDisplay:
        @staticmethod
        def display(msg):
            pass

    display = MockDisplay()
    cmd = MockCLI(args=['playbook', 'playbook2'])
    cmd.run()

# Generated at 2022-06-10 22:20:13.448610
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # @todo: Write unit test
    pass

# Generated at 2022-06-10 22:20:15.431424
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: Test PlaybookCLI.run()
    pass

# Generated at 2022-06-10 22:20:23.720122
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockPlaybookCLI:
        def __init__(self, playbooks):
            self.args = [playbooks]

        def post_process_args(self, options):
            self.display = Display()
            self.display.verbosity = options.verbosity
            self.validate_conflicts(options, runas_opts=True, fork_opts=True)
            return options

    class MockLoader:
        def __init__(self, collection_playbooks):
            self.collection_playbooks = collection_playbooks

        def set_basedir(self, basedir):
            self.basedir = basedir

    class MockInventory(object):
        @staticmethod
        def list_hosts():
            return []


# Generated at 2022-06-10 22:20:37.178259
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # pylint: disable=protected-access,unused-variable,expression-not-assigned
    import os
    import shutil
    import sys
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from units.mock.executor import get_loader
    from units.mock.loader import DictDataLoader

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create mock objects
    class FakeDisplay:
        def __init__(self):
            self.displayed = []


# Generated at 2022-06-10 22:20:42.796327
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Instantiating PlaybookCLI
    options = [
        '-i', 'invent.inventory',
        'test.yml'
    ]
    # Call run method
    with open('test.yml', 'w') as f:
        f.write('---')
    PlaybookCLI(args=options).run()


# Generated at 2022-06-10 22:20:57.548542
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    Unit test for method run of class PlaybookCLI.
    :return: None
    '''
    pass

# Generated at 2022-06-10 22:21:07.532589
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class MockCLIARGS:
        module_paths = []
        vault_ids = []
        verbosity = 0
        subset = None
        flush_cache = False
        syntax = False
        listhosts = False
        listtasks = False
        listtags = False
        start_at_task = 'start_at_task'
        step = False
        args = 'args'

    # Note: this implicitly tests the PlaybookExecutor.run method
    context.CLIARGS = MockCLIARGS()
    try:
        pbcli = PlaybookCLI('')
        assert pbcli.run() == 0
    finally:
        del context.CLIARGS


# Generated at 2022-06-10 22:21:09.891323
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: this should be a full unit test, create a playbook and run it on localhost
    pass

# Generated at 2022-06-10 22:21:22.993405
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class MockCLI(object):

        def __init__(self):
            self.options = {}
            self.args = []

    class MockInventory(object):

        def __init__(self):
            self.hosts, self.groups = {}, {}

        def list_hosts(self):
            return [MockHost('test')]

    class MockHost(object):

        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class MockPlaybookExecutor(object):

        def __init__(self, playbooks, inventory, variable_manager, loader, passwords):
            self.playbooks = playbooks
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader

# Generated at 2022-06-10 22:21:34.237604
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.utils.display import Display
    display = Display()

    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager.from_file('test/ansible_hosts')

    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager(inventory=inventory)

    # initial error check, to make sure all specified playbooks are accessible
    # before we start running anything through the playbook executor
    # also prep plugin paths
    b_playbook_dirs = []

# Generated at 2022-06-10 22:21:40.051391
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """Unittest for method run in class PlaybookCLI"""
    class FakeAnsiblePlaybookCLI(PlaybookCLI):
        def ask_passwords(self):
            return (None, None)
        def _play_prereqs(self):
            return (None, None, None)
        def _flush_cache(self, inventory, variable_manager):
            pass
    fake_ansible_playbook_cli = FakeAnsiblePlaybookCLI()
    assert fake_ansible_playbook_cli.run() == 0

# Generated at 2022-06-10 22:21:42.748698
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI()
    # playbook_cli.run()
    pass

# Generated at 2022-06-10 22:21:51.954495
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockInventoryPlugin(object):
        def verify_file(self, path):
            return True

    class MockCLI(object):
        def get_host_list(self, inventory, subset):
            return subset

        class Namespace(object):
            def __init__(self, **kwargs):
                self.__dict__.update(kwargs)

        def parse(self, **kwargs):
            return self.Namespace(
                listtags=True,
                listtasks=True,
                tags=None,
                subset='',
                **kwargs
            )

    playbook = 'test.yml'

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    cli = MockCLI

# Generated at 2022-06-10 22:22:00.579026
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test case 1: No args provided
    old_stdout = sys.stdout
    sys.stdout = StringIO()
    pbcli = PlaybookCLI()
    with pytest.raises(SystemExit) as system_exit:
        pbcli.run()
    assert system_exit.value.code == 1
    sys.stdout = old_stdout

    # Test case 2: Invalid option provided
    old_stdout = sys.stdout
    sys.stdout = StringIO()
    pbcli = PlaybookCLI()
    pbcli.args = ['test']
    with pytest.raises(SystemExit) as system_exit:
        pbcli.run()
    assert system_exit.value.code == 2
    sys.stdout = old_stdout

    # Test case 3: invalid playbook

# Generated at 2022-06-10 22:22:02.619561
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    PlaybookCLI.run = test_run
    PlaybookCLI.run()



# Generated at 2022-06-10 22:22:26.591352
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import sys
    import stat
    import tempfile
    import ansible.playbook.play

    ansible_playbook_cli = PlaybookCLI(['ansible-playbook'])
    assert isinstance(ansible_playbook_cli, PlaybookCLI)

    # Create temporary directory
    tmp_path = tempfile.mkdtemp()

    # Create temporary playbook
    (fd, pb_path) = tempfile.mkstemp(dir=tmp_path)
    os.close(fd)

    # Create temporary hosts inventory file
    (fd, inv_path) = tempfile.mkstemp(dir=tmp_path, prefix='test_ansible_module')
    f = open(inv_path, 'w')
    f.write('[test]\n')

# Generated at 2022-06-10 22:22:37.335038
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class Parser(object):
        def __init__(self):
            self.args = []

    class Options(object):
        def __init__(self):
            self.step = None
            self.start_at_task = None

    class PlaybookExecutor(object):
        def __init__(self):
            self.results = None

        def run(self):
            return self.results

    class CLIARGS(object):
        def __init__(self):
            self.listhosts = False
            self.listtasks = False
            self.listtags = False
            self.syntax = False
            self.flush_cache = False
            self.subset = None
            self.verbosity = 0

    context.CLIARGS = CLIARGS()

    class Display(object):
        verbosity = 0

# Generated at 2022-06-10 22:22:46.471219
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Arrange
    class TestInventory(object):
        def __init__(self,hosts):
            self.hosts = hosts
        def list_hosts(self):
            return self.hosts
        def get_hosts(self,hosts):
            return self.hosts
    class TestVariableManager(object):
        def __init__(self,vars):
            self.vars = vars
        def get_vars(self,play=None):
            return self.vars
        def clear_facts(self,hostname):
            pass
    class TestLoader(object):
        def __init__(self,basedir):
            self.basedir = basedir
        def set_basedir(self,basedir):
            pass

# Generated at 2022-06-10 22:22:52.176058
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Object under test
    cli = PlaybookCLI(args=['ansible/test/integration/targets/default',
                            '-i', 'localhost,'])

    # Setup test data
    setup_test_data()

    # Run test
    exit_code = cli.run()

    # Cleanup test data
    cleanup_test_data()

    # Test assertions
    assert exit_code == 0



# Generated at 2022-06-10 22:23:03.985701
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class Options():
        verbosity = 1
        listhosts = True
        listtasks = False
        listtags = False
        syntax = False
        subset = None
        extra_vars = [('foo', 'bar')]
        playbook = 'test-playbook'
        inventory = '/tmp/inventory'
        flush_cache = False
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        b_vault_password_files = []
        b_ask_vault_pass = False
        b_new_vault_password_file = None
        b_vault_ids = []
        b_selinux_special_fs = None
        b_forks = 5
        b_module_path = None


# Generated at 2022-06-10 22:23:16.886100
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockRunner:
        def __init__(self):
            self.args = {}
            self.options = {}

        def get_host_list(self, inventory, subset):
            self.args['inventory'] = inventory
            self.args['subset'] = subset
            return ['localhost']

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            pass
    class MockDisplay:
        def __init__(self):
            self.verbosity = 3
    class MockCLIArgs:
        def __init__(self):
            self.listhosts = False
            self.listtasks = False
            self.listtags = False
            self.syntax = False
            self.flush_cache = True
            self.subset = 'all'
           

# Generated at 2022-06-10 22:23:28.384255
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # this unit test is not working in windows
    # play will be executed during the test, so skip it
    # todo: fix this test
    import sys
    if sys.platform == 'win32':
        return

    plbcli = PlaybookCLI()
    # initialize the parser
    plbcli.init_parser()
    # create the resulting object
    args = plbcli.parser.parse_args([
        '--syntax-check',
        'ansible/test/integration/targets/test.yml'
    ])
    # process the result of parsing
    args = plbcli.post_process_args(args)
    # run the method, which is under test
    results = plbcli.run()
    # check the result
    assert results == 0



# Generated at 2022-06-10 22:23:40.461242
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Arrange
    # We need a host to use in the test with a fact cache.
    #
    # The regex pattern will match any host name.
    # This is needed to run PlaybookCLI.get_host_list.
    test_host = type('', (), {
        'name': 'test_host',
        'vars': {
            'ansible_ssh_port': None,
            'ansible_ssh_host': '127.0.0.1',
            'ansible_ssh_user': 'test_user',
        }
    })()


# Generated at 2022-06-10 22:23:50.897732
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.parsing.dataloader import DataLoader

    # Prepare test objects
    cli = PlaybookCLI(['/path/to/playbook'])
    cli.options = cli.args = cli.parser.parse_args([])
    cli.options.password = cli.options.become_pass = 'test'
    cli.options.check = False
    cli.options.listhosts = False
    cli.options.listtags = False
    cli.options.listtasks = False
    cli.options.syntax = False
    cli.options.flush_cache = True
    cli.options.verbosity = 5
    cli.options.one_line = False
    cli.options.start_at_task = None
    cli.options.step

# Generated at 2022-06-10 22:23:59.560282
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """Checking that when we run the command with the following options:
    -C, -f 10, --limit, --syntax-check and --list-tasks this method is working
    as it should"""

    # Mocking the AnsibleCLI and the PlaybookCLI object
    from mock import Mock
    from ansible.playbook.play_context import PlayContext
    from ansible.cli.playbook import PlaybookCLI
    playbook_cli = PlaybookCLI(Mock())
    playbook_cli.options = Mock()

    # Creating variables for option checking
    playbook_cli.options.connection = 'local'
    playbook_cli.options.force_handlers = 10
    playbook_cli.options.listtasks = True
    playbook_cli.options.limit = 'all'
    playbook_cli.options.syntax = True



# Generated at 2022-06-10 22:24:33.015244
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    Sets up a PlaybookCLI object for testing
    """

    # Create a Mock PlaybookCLI that returns command line arguments
    cls = PlaybookCLI()
    cls.get_opt = lambda: None
    cls.get_opt.listhosts = False
    cls.get_opt.listtags = False
    cls.get_opt.listtasks = True
    cls.get_opt.syntax = False
    cls.get_opt.step = True
    cls.get_opt.start_at_task = None
    cls.get_opt.verbosity = False
    cls.args = ['ansible/test/units/module_utils/test_command_module.py']

    # Run method under test
    result = cls.run()

    # Assert results


# Generated at 2022-06-10 22:24:43.919519
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args = [
        'ansible-playbook',
        '--connection', 'local',
        '--inventory', '/path/to/inventory',
        '--limit', 'localhost',
        '--list-hosts',
        '/path/to/playbook.yml',
    ]
    cli = PlaybookCLI(args)

    # _check_tags() is run to set _ask_pass_lockout, which isn't tested here,
    # it is run elsewhere
    cli._check_tags(['all'])

    # Bare minimum setup. Variables are placed in order of appearance
    # in the PlaybookCLI.run() method
    #

    # aliases() is needed because of the use of the CLI.ask_vault_pass() method
    # and the AnsibleOptions class

# Generated at 2022-06-10 22:24:46.870722
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI()
    playbook_cli.parser.parse_args(['--list-hosts', 'playbook1.yml'])
    playbook_cli.run()

# Generated at 2022-06-10 22:24:48.355089
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  print("stub")
  # TODO: Implement actual unit test

# Generated at 2022-06-10 22:24:50.111070
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    module = PlaybookCLI()
    result = module.run()
    assert(result == 0)

# Generated at 2022-06-10 22:24:52.967924
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli import CLI

    playbook_cli = PlaybookCLI(args=[])
    with pytest.raises(SystemExit):
        playbook_cli.run()



# Generated at 2022-06-10 22:24:53.638366
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:54.201841
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:54.788507
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:25:04.443426
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    from ansible.playbook.play_context import PlayContext

    class Mock_PlaybookExecutor(object):
        def __init__(self, playbooks, inventory, variable_manager, loader, passwords):
            self.playbooks = playbooks
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader
            self.passwords = passwords

        def run(self):
            pass

    class Mock_Inventory(object):
        def __init__(self):
            pass

        def list_hosts(self):
            pass

    class Mock_VariableManager(object):
        def __init__(self):
            pass

        def clear_facts(self, name):
            pass

    class Mock_Display(object):
        verbosity = 2


# Generated at 2022-06-10 22:25:52.308604
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI()

    args_list = ['-vv', 'test.yml', '--list-hosts']
    parser_mock = opt_help.make_parser(args_list)
    context.CLIARGS = parser_mock.parse_args(args_list)
    context.CLIARGS['diff'] = False
    display.verbosity = context.CLIARGS['verbosity']


# Generated at 2022-06-10 22:25:52.920788
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:25:53.488803
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:26:04.508526
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.parsing.dataloader import DataLoader

    # Create a (fake?) inventory with hosts.
    try:
        from ansible.inventory.manager import InventoryManager
    except ImportError:
        from ansible.inventory import Inventory

    InventoryManager._create_empty_inventory = lambda *args, **kwargs: Inventory(loader=None)
    hosts = ['127.0.0.2', '127.0.0.3', '127.0.0.4']
    inventory = InventoryManager(loader=None, sources=[';'.join(hosts)])
    inventory.subset('all')

    # Create a (fake?) variable manager
    variable_manager = CLI.variable_manager_cls(loader=DataLoader(), inventory=inventory)

    # Create a (fake?) module loader

# Generated at 2022-06-10 22:26:10.469223
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI(args=[])
    # test normal usage
    playbook_cli.options = (OptParseMock(
        listtasks=False, listtags=False, step=False, start_at_task=None, subset=None,
        inventory=None, forks=None, private_key_file=None,
        extra_vars=[], args=['test.yml']
    ))
    playbook_cli.context = None
    playbook_cli.CLI = None
    assert playbook_cli.run() == 0



# Generated at 2022-06-10 22:26:19.972665
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    Unit test for method run of class PlaybookCLI
    '''
    display = Display()
    display.verbosity=2
    loader, inventory, variable_manager = PlaybookCLI._play_prereqs()

# Generated at 2022-06-10 22:26:20.975965
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI().run()

# Generated at 2022-06-10 22:26:22.360519
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test PlaybookCLI.run method
    pass

# Generated at 2022-06-10 22:26:22.990229
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:26:31.819922
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys

    class my_playbook_cli(PlaybookCLI):
        def __init__(self):
            pass

        def run(self):
            print('running')

    if sys.version_info >= (3, 8):
        import unittest
        import unittest.mock


# Generated at 2022-06-10 22:27:01.283321
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    :return:
    """
    loader, inventory, variable_manager = PlaybookCLI.init_objects()

# Generated at 2022-06-10 22:27:07.987193
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockPlaybookCLI(PlaybookCLI):
        def __init__(self):
            self.instance = PlaybookCLI()
            self.instance.init_parser = lambda: None
            self.instance.post_process_args = lambda opt: opt
            self.instance.parser = lambda: None
            self.instance.display = display
            self.instance.validate_conflicts = lambda opt: opt
            self.instance.ask_passwords = lambda: (None, None)
            self.instance.run_playbook = lambda pbex: None

    class MockPlaybookExecutor(object):
        def __init__(self):
            self.is_list = False

        def run(self):
            if self.is_list:
                return []
            else:
                return None


# Generated at 2022-06-10 22:27:09.249721
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Make sure ansible-playbook --version properly exists with code 0
    # without any error.
    result = PlaybookCLI().run()
    assert result == 0

# Generated at 2022-06-10 22:27:23.006223
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test the method run of class PlaybookCLI
    # Arrange
    inventory = Inventory()
    variable_manager = VariableManager()
    loader = DataLoader()
    CLI.setup_verbosity()

    from ansible.vars.manager import VariableManager

    # one --extra-vars at a time
    for extra_vars in (dict(k='v'), dict(k1=1), dict(k2='2')):
        display.verbosity = 3

# Generated at 2022-06-10 22:27:24.383790
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    cli = PlaybookCLI(['localhost'])
    cli.run()

# Generated at 2022-06-10 22:27:33.169851
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI()
    playbook_cli.options = context.CLIARGS

# Generated at 2022-06-10 22:27:46.513897
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.parsing import vault
    from ansible.plugins.loader import vault_loader

    vault.VaultLib = vault_loader.get('VaultLib')
    class AnsibleVault:
        def __init__(self):
            pass
        class VaultEditor:
            def __init__(self):
                pass
    vault.AnsibleVault = AnsibleVault()
    class AnsibleModule:
        def __init__(self):
            self.params = {
                'vault_password_file': '',
                'ask_vault_pass': False
            }
        def fail_json(self, *args):
            return

# Generated at 2022-06-10 22:27:47.090517
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:27:48.717159
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """

    :return:
    """
    pass

# Generated at 2022-06-10 22:27:56.621903
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:29:20.398030
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:29:30.119041
# Unit test for method run of class PlaybookCLI