

# Generated at 2022-06-10 22:19:47.028090
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import pytest

    from ansible.cli.playbook import PlaybookCLI
    from ansible.errors import AnsibleError

    with pytest.raises(AnsibleError):
        PlaybookCLI.run(PlaybookCLI())

# Generated at 2022-06-10 22:19:52.185477
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Solves issue #39210: Running a playbook
    # https://github.com/ansible/ansible/issues/39210
    args = []
    args.append("tests/test_data/test.yml")
    context.CLIARGS = {'args': args}
    PlaybookCLI().run()

# Generated at 2022-06-10 22:19:53.149390
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:20:02.804673
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.inventory.manager import InventoryManager

    class PlaybookExecutor(object):
        def __init__(self, playbooks, inventory, variable_manager, loader, passwords):
            self.playbooks = playbooks
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader
            self.passwords = passwords

        def run(self):
            playbook = self.playbooks[0]
            b_playbook_dir = os.path.realpath(os.path.dirname(to_bytes(playbook, errors='surrogate_or_strict')))
            add_all_plugin_dirs(b_playbook_dir)

# Generated at 2022-06-10 22:20:08.924498
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """ Test function run in PlaybookCLI class """
    class MockPlaybookCLI():
        args = ['test_PlaybookCLI_run.yml']

    pb_cli = MockPlaybookCLI()
    # This will raise an exception if the playbook has a syntax error
    PlaybookCLI.run(pb_cli)


# Generated at 2022-06-10 22:20:19.552523
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import tempfile
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.inventory import Inventory
    from ansible.module_utils.six import PY3
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play


# Generated at 2022-06-10 22:20:22.083108
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """Unit test for ansible.cli.playbook.PlaybookCLI.run"""



# Generated at 2022-06-10 22:20:35.579700
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Arrange
    from ansible.errors import AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    import tempfile

    def _get_host_list(hosts):
        return hosts

    # test with no inventory and bad play
    fake_play = Play()
    fake_play.hosts = 'badhost'

# Generated at 2022-06-10 22:20:46.498266
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.errors import AnsibleError
    from unit.mock.loader import DictDataLoader
    from unit.mock.inventory import MockInventory
    import sys

    class MockPlaybookExecutor(object):
        class TaskQueueManager(object):
            def __init__(self):
                self.result = 'task result'

        def run(self):
            return self.TaskQueueManager().result

    class MockLoader(object):
        pass

    class MockVariableManager(object):
        pass

    class TestCLI(PlaybookCLI):
        def __init__(self):
            super(TestCLI, self).__init__()

            # initialize needed member variables

# Generated at 2022-06-10 22:20:47.143536
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:20:57.394441
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  pass

# Generated at 2022-06-10 22:21:08.378958
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    from optparse import Values

    from units.compat import unittest
    from units.compat.mock import patch
    from ansible.cli.playbook import CLI

    def _get_options(args):
        parser = CLI.base_parser(constants=C)
        (options, args) = parser.parse_args(args)
        return options


# Generated at 2022-06-10 22:21:15.691246
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class Test:
        def __init__(self):
            self.args = ['all']
            self.options = []
            self.parser = None
            self.inventory = None
            self.variable_manager = None

    test = Test()
    test_playbook_cli = PlaybookCLI(test)
    test_playbook_cli.post_process_args(test.options)
    assert test_playbook_cli.run() == 0

# Generated at 2022-06-10 22:21:27.500240
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    parser = PlaybookCLI.base_parser(constants=C)
    # If you want to test PlaybookCLI.run(), you should pass a valid
    # playbook path to args.
    args = parser.parse_args(['--list-tasks', '--list-tags', 'playbook.yml', 'playbook2.yml'])
    # AnsibleCLI.get_opt_parser() seems to not support passing constants.
    # So you have to pass the context.CLIARGS to the __init__ method.
    cli = PlaybookCLI(constants=C, args=args)
    cli.parse()
    cli.run()

# Generated at 2022-06-10 22:21:29.442435
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    inst_PlaybookCLI = PlaybookCLI()
    inst_PlaybookCLI.run()

# Generated at 2022-06-10 22:21:38.630047
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    loader, inventory, variable_manager = PlaybookCLI._play_prereqs()
    playbooks = ['test.yml']
    loader._create_directory_tree = lambda _: None
    loader._get_file_contents = lambda file_name: ''
    loader._compile_directory_tree = lambda _: [Playbook()._entries.append(Play()._entries.append(Block()))]

    pbcli = PlaybookCLI([])
    pbcli._flush_cache = lambda a, b: None


# Generated at 2022-06-10 22:21:44.249653
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.cli.arguments import OptionParser

    options = Optio

# Generated at 2022-06-10 22:21:46.973164
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''def run(self):
        # What it does:
        # What changes:
        # Things to check:
        '''
    pass

# Generated at 2022-06-10 22:21:58.117820
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import ansible.cli.CLI
    import ansible.plugins.loader

    args = ['/home/ansible/test_playbook.yml']
    cli = CLI()
    cli.options = args

    # TODO: mock flush_cache and _play_prereqs
    #cli.flush_cache = lambda *args: None
    #cli._play_prereqs = lambda *args: None

    # TODO: mock CLI.ask_passwords
    def ask_passwords(): return None, None
    CLI.ask_passwords = ask_passwords

    # TODO: mock PlaybookCLI.validate_conflicts
    PlaybookCLI.validate_conflicts = lambda *args: None

    # TODO: mock CLI.get_host_list

# Generated at 2022-06-10 22:22:06.014519
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cwd = os.getcwd()

    # FIXME: This shouldn't be necessary.  We should be able to import it from
    #        the CLI module.
    sys.path.insert(0, cwd)


# Generated at 2022-06-10 22:22:24.584794
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:22:24.986865
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:22:25.744432
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:22:40.405739
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:22:44.668519
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    Unit test function for Ansible class PlaybookCLI method run
    '''
    # Create test object
    cli = PlaybookCLI([])
    cli.options = cli.base_parser.parse_args([], values=cli.defaults)
    # Run test
    cli.run()

# Generated at 2022-06-10 22:22:54.194532
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

	# Stubbing the parser object
    def parser_stub(self, prog, usage, desc):
        pass

    CLI.parser = parser_stub

    # Stubbing the post_process_args method
    def post_process_args_stub(self, options):
        return options

    CLI.post_process_args = post_process_args_stub

    # Stubbing the _play_prereqs method
    def _play_prereqs_stub(self):
        return None, None, None

    CLI._play_prereqs = _play_prereqs_stub

    # Stubbing the ask_passwords method
    def ask_passwords_stub(self):
        return None, None

    CLI.ask_passwords = ask_passwords_stub

    # Stubbing the run of PlaybookExecutor

# Generated at 2022-06-10 22:23:05.634882
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class Options:
        verbosity = 0
        listhosts = False
        listtasks = False
        listtags = False
        syntax = False
        subset = None
        check = False

    class UtilsModule:
        def _check_delegated_vars(self, *args, **kwargs):
            return False

    class Host:
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class Inventory:
        def __init__(self):
            self.list_hosts_return = []

        def list_hosts(self, *args, **kwargs):
            return self.list_hosts_return

        def get_hosts(self, *args, **kwargs):
            return self.list_hosts_return



# Generated at 2022-06-10 22:23:17.950202
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:23:29.177483
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    display_class = Display()
    display_class.verbosity = 0
    display_class.warning = lambda *args, **kwargs: None
    display_class.deprecated = lambda *args, **kwargs: None

    # A mock inventory
    class MockInventory:
        def __init__(self, host_list):
            self.host_list = host_list
            self.parsed_inventory = None
        
        def list_hosts(self):
            return self.host_list
    
    
    # A mock VariableManager

# Generated at 2022-06-10 22:23:30.052002
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:34.315444
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:24:38.434575
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """test_PlaybookCLI_run is the unit test for method run of class PlaybookCLI
    """

    cli_args = ['/bin/ansible-playbook', 'test_playbook.yml']
    context.CLIARGS = {'args': cli_args, 'listhosts': True}
    cli = PlaybookCLI()
    print('Test PlaybookCLI_run: ', cli.run())

# Generated at 2022-06-10 22:24:42.923977
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # FIXME: This is not a proper unit test as it relies on CLI._play_prereqs to work properly
    # FIXME: But it is not a test of that as it only tests the method's return value.
    # FIXME: This is really an integration test.
    pass

# Generated at 2022-06-10 22:24:44.020262
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO
    pass

# Generated at 2022-06-10 22:24:47.445610
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    os.environ['ANSIBLE_CONFIG'] = 'test/unit/cli/ansible.cfg'
    cli = PlaybookCLI(args=['ansible-playbook', '-i', 'localhost,', '-e', '@test/unit/cli/test_playbook_cli_vars.yml', '-l', 'localhost', '-v',
                            'test/unit/playbook_tests/basic.yml'])
    try:
        exit_val = cli.run()
    except SystemExit as e:
        exit_val = e.code
    assert exit_val == 0


# Generated at 2022-06-10 22:24:48.963182
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """Unit test for method run of class PlaybookCLI"""
    assert False

# Generated at 2022-06-10 22:24:49.583337
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:58.324663
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    with open("test/test_playbookcli.yml", 'r') as stream:
        data = yaml.safe_load(stream)
        stream.close()

    pbcli = PlaybookCLI(["test/test_playbookcli.yml"])

    # Test listhosts
    pbcli.options = mock.MagicMock()
    pbcli.options.listhosts = True
    assert type(pbcli.run()) == type(0)

    # Test syntax
    pbcli.options.listhosts = False
    pbcli.options.syntax = True
    assert type(pbcli.run()) == type(0)

    # Test hosts

# Generated at 2022-06-10 22:25:10.557927
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import inspect
    import unittest
    from ansible.playbook.play_context import PlayContext

    # Mock options
    class MockOptions(object):
        connection = 'local'
        module_path = None
        forks = 5
        remote_user = 'root'
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = False
        become_method = 'sudo'
        become_user = None
        verbosity = 0
        check = False
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        flush_cache = False
        subset = None
        inventory = None

# Generated at 2022-06-10 22:25:11.876724
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    runner = PlaybookCLI([])

# Generated at 2022-06-10 22:27:22.225116
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    display.verbosity = 3
    loader, inventory, variable_manager = ansible.cli.CLI.setup_locations(None, None, None, None, None)
    playbook = 'test_PlaybookCLI_run.yml'
    args = ['--host', 'localhost', playbook]
    cli = PlaybookCLI(args)
    result = cli.run()
    assert result == 0
    assert not os.path.exists('./test_PlaybookCLI_run_output.txt')
    args = ['--host', 'localhost', playbook, '--list-tasks']
    cli = PlaybookCLI(args)
    result = cli.run()
    assert result == 0
    assert not os.path.exists('./test_PlaybookCLI_run_output.txt')
    args

# Generated at 2022-06-10 22:27:30.509227
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class TestPlaybookCLI(PlaybookCLI):
        def get_opt_parser(self):
            # force parser_class set in init_parser to be None
            # so we can get a basic opt parser, without all the
            # extra options added by opt_helpers
            self.parser_class = None
            return super(PlaybookCLI, self).get_opt_parser()

    cli = TestPlaybookCLI()
    cli.init_parser()
    cli.post_process_args(cli.parser.parse_args(['-i', 'hosts', '-l', 'host1', '-T', '1', 'playbook.yml']))
    cli.run()

# Generated at 2022-06-10 22:27:32.014452
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI(args=[])
    res = cli.run()
    assert res == 0

# Generated at 2022-06-10 22:27:41.062542
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys

    # get a mock object of stdout
    mocked_stdout = sys.stdout

    # create a mock function to simulate the stdout.write() method
    def mocked_write(data):
        # make sure that the mock method only accepts one argument
        assert isinstance(data, str)

    mocked_stdout.write = mocked_write

    in_args = ['ansible-playbook', 'playbook.yml']
    with mock.patch.object(sys, 'argv', in_args):
        pbcli = PlaybookCLI()
        pbcli.run()

# Generated at 2022-06-10 22:27:42.483212
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI()
    playbook_cli.run()

# Generated at 2022-06-10 22:27:53.157156
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.module_utils.six import StringIO

    class Ansible_Display(object):
        def display(self, msg, *args, **kwargs):
            self.buf.write(msg)

        def error(self, msg, *args, **kwargs):
            self.buf.write('ERROR: ' + msg)

    class Ansible_CLIARGS(object):
        def __init__(self, args, listhosts, listtasks, listtags):
            self.args = args
            self.verbosity = 0
            self.inventory = None
            self.listhosts = listhosts
            self.listtasks = listtasks
            self.listtags = listtags
            self.syntax = False
            self.connection = 'ssh'
            self.module_path = None
            self.forks

# Generated at 2022-06-10 22:28:03.484634
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.parser.yaml.objects import AnsibleUnicode

    class AnsibleCliArgs(object):
        module_path = ""
        extra_vars = []

        def __init__(self):
            self.collect_facts = False
            self.connection = ""
            self.subset = ""

    context.CLIARGS = AnsibleCliArgs()
    context.CLIARGS.subset = "subset"

    my_list = [[[[["action"]]]] for i in range(0, 5)]
    my_list[0][0][0][0][0].append(AnsibleUnicode("action"))

    items = [["action"] for i in range(0, 5)]
    items[0].append("action")


# Generated at 2022-06-10 22:28:06.812582
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_args = ['ansible-playbook', 'playbook.yml']
    cli = PlaybookCLI(args=test_args)
    context.CLIARGS = cli.parse()
    cli.run()
    assert True


# Generated at 2022-06-10 22:28:18.088299
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import unittest
    import ansible.utils.display
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.playbook.play import Play

    playbook_content = """
    ---
    - hosts: all
      tasks:
        - debug:
            msg: yay
    """
    # mock options
    class MockOptions(object):
        verbosity = 0
        listtags = None
        listtasks = None
        subset = None
        syntax = None
        start_at_task = None
        step = None
        flush_cache = None
        connection = None
        timeout = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        ssh_

# Generated at 2022-06-10 22:28:31.255907
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # mock up a dummy display
    display.verbosity = 1

    # mock up a dummy args namespace
    class Args(object):
        verbosity = 2
        inventory = 'hosts'
        subset = 'all'
        module_path = ''
        forks = 10
        ask_vault_pass = False
        ask_pass = False
        private_key_file = ''
        remote_user = ''
        connection = ''
        timeout = 10
        ssh_common_args = ''
        sftp_extra_args = ''
        scp_extra_args = ''
        ssh_extra_args = ''
        become = False
        become_method = ''
        become_user = ''
        become_ask_pass = False
        listhosts = False
        listtasks = False
        listtags = False