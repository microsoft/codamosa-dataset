

# Generated at 2022-06-10 22:19:58.315028
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    with mock.patch.object(CLI, 'post_process_args') as mock_post_process_args:
        with mock.patch.object(CLI, '_play_prereqs') as mock__play_prereqs:
            with mock.patch.object(PlaybookCLI, '_flush_cache') as mock__flush_cache:
                with mock.patch.object(CLI, 'ask_passwords') as mock_ask_passwords:
                    with mock.patch.object(PlaybookExecutor, 'run') as mock_PlaybookExecutor_run:
                        cli = PlaybookCLI()
                        cli.init_parser()
                        cli.options = mock.MagicMock()
                        parser = mock.MagicMock()
                        cli.options.CONFIG_FILE = parser
                        cli.options.private

# Generated at 2022-06-10 22:20:08.593568
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli import CLI
    from ansible.cli.arguments import option_helpers
    results = CLI.run([])

    assert type(results) == list
    assert type(results[0]) == PlaybookCLI

    results1 = CLI.run([], [])

    assert type(results1) == list
    assert type(results1[0]) == PlaybookCLI

    #TODO: Possible to set attributes of the class CLI
    #option_helpers. =
    #results2 = CLI.run([], [])

    #assert type(results2) == list
    #assert type(results2[0]) == PlaybookCLI

    #TODO: Possible to set attributes of the class CLI
    #option_helpers. =
    #results3 = CLI.run([], [])

    #assert type(

# Generated at 2022-06-10 22:20:17.848901
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    options = opt_help.parse()
    context.CLIARGS = options[0]
    display.verbosity = options[0].verbosity
    CLI.get_host_list(inventory=None, subset=None)
    loader, inventory, variable_manager = PlaybookCLI._play_prereqs()
    pbex = PlaybookExecutor(playbooks=None, inventory=inventory, variable_manager=variable_manager, loader=loader, passwords={})
    results = pbex.run()

# Generated at 2022-06-10 22:20:22.136975
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pbcli = PlaybookCLI(args=['ansible/test/units/module_utils/test_pm.py', '--list-tags'])
    result = pbcli.run()
    assert result == 0

# Generated at 2022-06-10 22:20:22.843108
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:20:28.041286
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys
    sys.argv = ['ansible-playbook', 'test-playbook.yaml']
    cli = PlaybookCLI()
    cli.run()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-10 22:20:41.233355
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block

    class mock_playbook:
        def __init__(self, path):
            self.playbook = path

        def __getitem__(self, item):
            return self

    class mock_play:
        def __init__(self, name, host, implict, tags):
            self.name = name
            self.hosts = host
            self.implicit = implict
            self.tags = tags

    class mock_task:
        def __init__(self, name, action, implict, tags):
            self.name = name
            self.action = action
            self.implicit = implict
            self.tags = tags

        def get_name(self):
            return self.name



# Generated at 2022-06-10 22:20:46.102803
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import sys
    import shutil
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import all as plugin_loader

    import pytest

    # pytest -s -v test_PlaybookCLI.py::test_PlaybookCLI_run
    #py.test.skip("showing class creation")

    ###################################################################
    # Prep work
    ###################################################################

    # set up required paths
    test_dir = os.path.dirname(__file__)
    data_path = os.path.join(test_dir, '../../lib/ansible/plugins/test/data')

# Generated at 2022-06-10 22:20:53.387726
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli import CLI
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from io import StringIO

    class FakeLoader(DataLoader):
        def __init__(self):
            pass

        def load(self, path, *args, **kwargs):
            return dict()

    class FakeInventoryManager(InventoryManager):
        def __init__(self, loader, sources):
            super(FakeInventoryManager, self).__init__(loader=loader, sources=sources)

        def get_hosts(self, pattern='all'):
            return list()

# Generated at 2022-06-10 22:20:54.777094
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import ansible.utils.loader
    #TODO
    pass

# Generated at 2022-06-10 22:21:06.491564
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:21:19.376645
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    def get_args(argv):
        args = []
        in_args = False
        for arg in argv:
            if arg == '--':
                in_args = True
            elif in_args:
                args.append(arg)
        return args

    argv = ['ansible-playbook', '--list-hosts', 'test_playbook.yml']
    options, display_args = PlaybookCLI.parse(args=argv[1:])
    options.args = get_args(argv)

    inventory, variable_manager, loader, options = PlaybookCLI._play_prereqs(options)
    pb_executor = PlaybookExecutor(playbooks=[options.args[0]], inventory=inventory,
                                   variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-10 22:21:31.757344
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    import collections
    import os
    import shutil
    import tempfile

    from ansible.plugins.loader import load_callback_plugin
    from ansible.plugins.loader import load_filter_plugin
    from ansible.plugins.loader import load_lookup_plugin

    import pytest

    # Create a temporary directory containing a simple playbook (with an include)
    # and a task with a simple action to copy a file
    top_directory = tempfile.mkdtemp()
    playbook_contents = '''
- include: included_playbook.yml
- hosts: localhost
  tasks:
    - copy:
        src: playbook.yml
        dest: /dev/null
'''


# Generated at 2022-06-10 22:21:40.339904
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    path = os.path.join(os.path.dirname(__file__), '..', 'plugins', 'action', 'setup.yml')
    test_user = 'setup'

    args = [
        'ansible-playbook',
        '--list-hosts',
        path,
        '--user',
        test_user,
    ]

    # Make sure ansible-playbook doesn't throw an exception

# Generated at 2022-06-10 22:21:51.084059
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import unittest.mock as mock

    # Mock get_host_list.  This will keep it from blowing up
    real_get_host_list = CLI.get_host_list

    def mock_get_host_list(inventory, subset):
        return set(inventory.list_hosts())

    CLI.get_host_list = mock_get_host_list

    # Monkey patch the class so we always use the test PlaybookCLI
    real_PlaybookCLI = CLI.CLI

    CLI.CLI = PlaybookCLI

    # Create the test subject and run with something that won't blow up
    test_subject = CLI([to_bytes(__file__)])

    with mock.patch.object(PlaybookCLI, '_play_prereqs'):
        test_subject.run()

    # Restore the

# Generated at 2022-06-10 22:21:51.964186
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:21:56.459765
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI._flush_cache = lambda *args: None
    PlaybookCLI.ask_passwords = lambda *args: ('', '')
    PlaybookCLI.validate_conflicts = lambda *args: None
    PlaybookCLI._play_prereqs = lambda *args: (None, None, None)
    assert PlaybookCLI.run(PlaybookCLI()) == 0

# Generated at 2022-06-10 22:22:05.082975
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import tempfile
    import shutil

    # create a tmp dir
    temp_dir = tempfile.mkdtemp()

    temp_playbook_1 = """
        ---
        - hosts: localhost
          tasks:
            - command: /bin/echo "Hello World!"
            - debug: msg="Hello World!"
    """

    temp_playbook_2 = """
        ---
        - hosts: localhost
          tasks:
            - command: /bin/echo "Hello World!"
            - debug: msg="Hello World!"
    """

    with open(temp_dir + "/test_playbook_1.yml", "wt") as temp_file:
        temp_file.write(temp_playbook_1)


# Generated at 2022-06-10 22:22:05.778236
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:22:14.484745
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    display = Display()
    display.verbosity = 3
    opts = {
        'listhosts': False,
        'listtasks': False,
        'listtags': False,
        'syntax': False,
        'step': False,
        'start_at_task': None
    }
    context._init_global_context(opts)
    cli = PlaybookCLI(['./test/ansible-playbook/test_playbook.yml'])
    cli.parse()
    assert cli.run() == 0

# Generated at 2022-06-10 22:22:46.252757
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class MockOptions(object):
        def __init__(self):
            self.force_handlers = None
            self.flush_cache = None
            self.listhosts = None
            self.listtags = None
            self.listtasks = None
            self.step = None
            self.start_at_task = None
            self.syntax = None
            self.verbosity = 0
            self.connection = None
            self.timeout = None
            self.remote_user = None
            self.remote_port = None
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.ssh_transfer_method = None
            self

# Generated at 2022-06-10 22:22:47.349343
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement test
    pass

# Generated at 2022-06-10 22:22:55.875022
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Create temporary inventory file
    (fd, filename) = tempfile.mkstemp()

# Generated at 2022-06-10 22:22:56.578317
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:22:58.614599
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''unit test for method PlaybookCLI.run'''
    pass

# Generated at 2022-06-10 22:22:59.515876
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:23:00.542580
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    raise NotImplementedError

# Generated at 2022-06-10 22:23:08.879730
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.utils import context_objects as co
    from ansible.utils.vars import combine_vars
    from ansible.inventory import Inventory
    from ansible.plugins.loader import add_all_plugin_dirs

    pb_filename = 'test/ansible-playbook/playbooks/playbook_cli.yml'
    loader, inventory, variable_manager = PlaybookCLI._play_prereqs(pb_filename)


# Generated at 2022-06-10 22:23:18.335327
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """ Unit test for method run of class PlaybookCLI. """

    Display.verbosity = 1

    # Test when the args option is not set
    test_cli = PlaybookCLI([])
    assert test_cli.run() == 2

    # Test with tags: tags=mytag
    CLI.setup()

    test_cli = PlaybookCLI([])
    test_cli.parser.version = '2.8.0'
    test_cli.parser.tags = 'mytag'
    test_cli.parser.args = ['myplaybook.yml']
    assert test_cli.run() == 0

# Generated at 2022-06-10 22:23:20.068225
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO
    pass

# Generated at 2022-06-10 22:24:22.737122
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    user_args = ['ansible-playbook', '/path/to/site.yml']
    def _get_options(args=None):
        return opt_help.read_cli_args(args)
    context.CLIARGS = _get_options(user_args)
    playbook_executor_obj = PlaybookCLI().run()

# Generated at 2022-06-10 22:24:23.441285
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:35.584093
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create fake object
    class FakePlaybookCLI:
        def __init__(self):
            self.options = []

    class FakeCLI():
        def __init__(self):
            self.connpass = None

        def get_host_list(self, inventory, subset):
            self.inventory = inventory
            self.subset = subset
            return

        def ask_vault_passwords(self):
            pass

        def validate_conflicts(self, options, vault_opts=False, runas_opts=False,
                               fork_opts=False, connection_opts=False,
                               module_opts=False, become_opts=False,
                               check_opts=False):
            pass


# Generated at 2022-06-10 22:24:36.373025
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:24:37.335262
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-10 22:24:44.806730
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    def test_ask_passwords():
        return (None, None)

    class MockPlaybookCLI(PlaybookCLI):
        def ask_passwords(self):
            return test_ask_passwords()

    class MockOpts(object):
        def __init__(self):
            self.listhosts = True

    context.CLIARGS = MockOpts()
    cli = MockPlaybookCLI()
    cli.run()
    assert context.CLIARGS.listhosts

# Generated at 2022-06-10 22:24:54.740284
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Use a fake sub module class to see if execute is called
    class fake_sub_module:
        class Runner:
            def execute(self, **kw):
                invoke_kw = kw
                print(invoke_kw)

        def __init__(self):
            self.runner = fake_sub_module.Runner()

        def run(self, **kw):
            return self.runner.execute(**kw)

    # Use a fake ansible module class to see if execute method is called
    class fake_module:
        class Runner:
            def execute(self, **kw):
                invoke_kw = kw
                print(invoke_kw)
                # If a password is not set then just return 0
                if 'password' not in kw:
                    return 0

                # If a password is set then return 1
                return 1

       

# Generated at 2022-06-10 22:25:02.824318
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args = ['-i', 'hosts', 'site.yml', ]

    # Case1: when all the supplied arguments are correct
    options = opt_help.read_cli_args(args)
    options = PlaybookCLI.post_process_args(options)

    pb = PlaybookCLI(args)
    assert pb.run() == 0

    # Case2: when the given playbook not exists
    args = ['-i', 'hosts', 'non-existent.yml', ]
    options = opt_help.read_cli_args(args)
    options = PlaybookCLI.post_process_args(options)

    pb = PlaybookCLI(args)
    assert pb.run() != 0

# Generated at 2022-06-10 22:25:04.132650
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    raise NotImplementedError

# Generated at 2022-06-10 22:25:04.881780
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:27:08.077113
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    instance = PlaybookCLI()
    assert True

# Generated at 2022-06-10 22:27:08.743568
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:27:19.852824
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys
    import io
    import unittest
    from io import StringIO
    from unittest.mock import patch
    from ansible import context
    from ansible.cli.playbook import PlaybookCLI, PlaybookCLIErrorHandler

    context.CLIARGS = {'args': ['tests/test_data/sample.yml']}
    pcl = PlaybookCLI(args=context.CLIARGS['args'])

    orig_stdout = sys.stdout
    orig_stderr = sys.stderr


# Generated at 2022-06-10 22:27:30.145587
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys
    import unittest
    import ansible
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars, load_extra_vars, load_options_vars
    from ansible.inventory.manager import InventoryManager

    from unittest.mock import MagicMock, patch, Mock

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.display = MagicMock(spec=Display)
            self.display.verbosity = 4

            self.cli = MagicMock(spec=CLI)
            self.cli.run = Mock()
            self.cli.ask_passwords = Mock()

# Generated at 2022-06-10 22:27:32.837916
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("TESTING: Playbook CLI run")

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-10 22:27:43.734178
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    global display, config
    display = Display()
    # config is the dictionary holding the config data via ansible.cfg
    config = {'DEFAULT_MODULE_LANG': '',
              'DEPRECATION_WARNINGS': False,
              'HOST_KEY_CHECKING': 'False',
              'LOG_PATH': '/ansible.log',
              'RETRY_FILES_ENABLED': 'False',
              'SELINUX_SPECIAL_FS': 'fuse,lofs,nfs',
              'SELINUX_IGNORE_NEVERALLOWS': False,
              'SYSLOG_FACILITY': 'LOG_USER'}

# Generated at 2022-06-10 22:27:48.233105
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_files = [
        'ansible/test/integration/targets/notify_playbook.yml',
        'ansible/test/integration/targets/import_playbook.yml',
        'ansible/test/integration/targets/vault_single_template_playbook.yml',
        'ansible/test/integration/targets/inventory_manual_host_var_playbook.yml',
    ]
    if not os.path.isdir('ansible/test/integration/targets'):
        os.makedirs('ansible/test/integration/targets')
    file = open('ansible/test/integration/targets/notify_playbook.yml', 'w')

# Generated at 2022-06-10 22:27:56.446145
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class Options(object):
        verbosity = 0
        connection = 'local'
        module_path = None
        forks = 10
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = False
        become_method = 'sudo'
        become_user = None
        check = False
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        subset = None
        serial = None
        extra_vars = []
        extra_vars_file = None
        flush_cache = None
        start_at_task = None
        step = None
        inventory = None
        vault_password_files = []

# Generated at 2022-06-10 22:27:57.968600
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass


# Generated at 2022-06-10 22:27:58.623185
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass