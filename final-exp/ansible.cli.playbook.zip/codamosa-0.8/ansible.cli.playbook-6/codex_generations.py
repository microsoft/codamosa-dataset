

# Generated at 2022-06-10 22:19:53.624282
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    t_ansible = Ansible()

    # Need to enable running adhoc commands
    t_ansible._connect_ds = {}
    t_ds = AnsibleDS()
    t_ds._play_prereqs = lambda *args,**kwargs: (None,None,None)
    t_ds.call_module = lambda *args,**kwargs: {"rc": 0, "out": "test"}
    t_ds.get_module_path = lambda *args,**kwargs: "test"

    t_ansible._connect_ds[None] = t_ds

    # Run a playbook cli with a empty arguments
    args = []
    t_playbook_cli = PlaybookCLI(args)

    # Verify it returns 0
    assert 0 == t_playbook_cli.run()

    # Run a playbook cl

# Generated at 2022-06-10 22:19:54.209874
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:19:55.552692
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()
    cli.run()

# Generated at 2022-06-10 22:20:01.222367
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    py_obj = PlaybookCLI()

    # Testing with required args only
    args = []
    options = py_obj.parse(args)
    py_obj.post_process_args(options)
    py_obj.run()

    # Testing with all args
    args = []
    options = py_obj.parse(args)
    py_obj.post_process_args(options)
    py_obj.run()

# Generated at 2022-06-10 22:20:03.190795
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    pass

# Generated at 2022-06-10 22:20:17.434630
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:20:31.738485
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible import context
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # set up context.CLIARGS, context.display and context.options

# Generated at 2022-06-10 22:20:32.404206
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:20:33.570536
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    raise NotImplementedError

# Generated at 2022-06-10 22:20:45.270328
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockClass:
        def __init__(self):
            self.ask_passwords = lambda: (None, None)
            self.ask_vault_passwords = lambda: None
            self.ask_become_passwords = lambda: None
            self.ask_passwords = lambda: (None, None)
            self.ask_vault_passwords = lambda: None

            self.password = None
            self.vault_password = None

            self.become = False
            self.become_method = None
            self.become_user = None

            self.connection = 'ssh'
            self.timeout = 10

            self.remote_user = 'root'
            self.module_path = None
            self.module_language = 'C'
            self.module_name = 'command'


# Generated at 2022-06-10 22:20:58.714475
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # assertTrue(PlaybookCLI) # TODO: implement your test here
    raise NotImplementedError()


# Generated at 2022-06-10 22:21:09.297593
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:21:20.126450
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader

    c = PlaybookCLI(args=["/ansible/testdata/sample.yaml"])
    c.parser.parse_args()
    loader, inventory, variable_manager = c._play_prereqs()
    pbex = PlaybookExecutor(playbooks=["/ansible/testdata/sample.yaml"], inventory=inventory,
                            variable_manager=variable_manager, loader=loader, passwords={})
    pbex.run()
    assert isinstance(c, PlaybookCLI)
    assert isinstance(loader, DataLoader)

# Generated at 2022-06-10 22:21:23.506887
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI(args=['-vvv', 'playbook.yml'])
    cli.run()

# Generated at 2022-06-10 22:21:27.983733
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI([])
    cli._play_prereqs = lambda: ('loader', 'inventory', 'variable_manager')
    cli.ask_passwords = lambda: ('', '')

    cli.run()

# Generated at 2022-06-10 22:21:35.364506
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    options = BaseCLI._generate_options()
    options['module_path'] = 'test/module_path'
    loader = DataLoader()
    inv = InventoryManager(loader, 'inventories/byo/hosts')
    variable_manager = VariableManager(loader=loader, inventory=inv)
    pbcli = PlaybookCLI(options)

    pbcli._flush_cache(inv, variable_manager)

# Generated at 2022-06-10 22:21:39.496147
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import unittest
    class TestPlaybookCLI(unittest.TestCase):

        def setUp(self):
            self.playbook = PlaybookCLI()

        def test_run(self):
            self.assertRaises(NotImplementedError, self.playbook.run)

    unittest.main()


# Generated at 2022-06-10 22:21:50.988323
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # FIXME: need better testing for this
    import io
    import sys
    import json

    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class TestPlaybookCLI(PlaybookCLI):
        def ask_passwords(self):
            return None, None

        def _play_prereqs(self):
            inventory = InventoryManager()
            variable_manager = VariableManager
            loader = None
            return loader, inventory, variable_manager

    class TestDisplay(object):
        """
        Class to capture display output
        """
        output = ''


# Generated at 2022-06-10 22:21:59.844607
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    opts = PlaybookCLI.base_parser(constants=C, runas_opts=True, subset_opts=True, output_opts=True, check_opts=True, runtask_opts=True, vault_opts=True,
                                    fork_opts=True, module_opts=True, become_opts=True, connection_opts=True, remote_user_opt=True, meta_opts=True,
                                    runsubset_opts=True)
    opts.add_argument('args', help='Playbook(s)', metavar='playbook', nargs='+')
    opts.add_argument('--list-tasks', dest='listtasks', action='store_true',
                      help="list all tasks that would be executed")

# Generated at 2022-06-10 22:22:11.716766
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # for cases where we need to set global state
    # FIXME: remove this after we address the global state in other ways
    CLI.setup_app(None)


# Generated at 2022-06-10 22:22:24.711955
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI.run()


# Generated at 2022-06-10 22:22:27.116804
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    This function tests the run method of the class PlaybookCLI.
    '''
    pass

# Generated at 2022-06-10 22:22:41.870115
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:22:52.226051
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    test_PlaybookCLI = PlaybookCLI()
    test_PlaybookCLI._flush_cache = lambda a, b: None
    test_PlaybookCLI.ask_passwords = lambda: ("password1", "password2")
    test_PlaybookCLI._play_prereqs = lambda: ("loader", "inventory", "variable_manager")

    context.CLIARGS = {
        'verbosity': 2,
        'inventory': 'inventory',
        'listhosts': True,
        'listtags': True,
        'listtasks': True,
        'syntax': True,
        'flush_cache': True,
        'subset': None,
        'args': ['playbook1.yaml', 'playbook2.yaml']
    }

    test_PlaybookCLI.run()

# Generated at 2022-06-10 22:23:00.803323
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # use an empty inventory file to avoid populating the database
    # while running tests
    inv_file = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible-test-inventory')
    invfh = open(inv_file, 'w')
    invfh.close()

    test_instance = PlaybookCLI()
    test_instance.parse()
    test_instance.post_process_args({'inventory': [inv_file]})
    assert test_instance.run() == 0
    os.unlink(inv_file)

# Generated at 2022-06-10 22:23:02.246413
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI().run()

# Generated at 2022-06-10 22:23:09.543829
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # create base objects
    loader, inventory, variable_manager = _play_prereqs()

    # create the playbook executor, which manages running the plays via a task queue manager
    pbex = PlaybookExecutor(playbooks=["test/test_playbook.yml"], inventory=inventory, variable_manager=variable_manager, loader=loader, passwords={})

    results = pbex.run()

    assert isinstance(results, list), 'Return value must be a list of results'
    assert len(results) == 1, 'List must have exactly one result'
    assert isinstance(results[0], dict), 'Result must be a dictionary'
    assert 'playbook' in results[0], 'Results must contain a playbook key'
    assert 'plays' in results[0], 'Results must contain a plays key'

# Generated at 2022-06-10 22:23:11.344836
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbookcli = PlaybookCLI()
    playbookcli.run()


# Generated at 2022-06-10 22:23:24.064939
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    Unit test to check if the method run of class PlaybookCLI is working
    properly.
    """

# Generated at 2022-06-10 22:23:32.174258
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    import sys

    display.verbosity = 4

# Generated at 2022-06-10 22:24:13.039476
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # ansible-playbook --list-tags playbook.yml
    cli_args = ['ansible-playbook', '--list-tags', 'test_PlaybookCLI_run.yml']
    pb_cli = PlaybookCLI(args=cli_args)
    pb_cli.parse()
    assert cli_args[1] == '--list-tags'

    # ansible-playbook --list-tags -v playbook.yml
    cli_args = ['ansible-playbook', '--list-tags', '-v', 'test_PlaybookCLI_run.yml']
    pb_cli = PlaybookCLI(args=cli_args)
    pb_cli.parse()
    assert cli_args[1] == '--list-tags'

    # ansible-playbook

# Generated at 2022-06-10 22:24:27.001481
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.utils.display import Display
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager


    playbook_cli = PlaybookCLI()
    display = Display()
    # display.verbosity = 1
    inventory = InventoryManager(loader=None, sources=C.DEFAULT_HOST_LIST, vault_password=None)
    variable_manager = VariableManager(loader=None, inventory=None)
    playbook_cli._flush_cache(inventory, variable_manager)
    # playbook_cli.run(context.CLIARGS['args'])
    # playbook_cli.run(["-i", "hosts.yml", "test.yml"])

# Generated at 2022-06-10 22:24:28.930713
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert PlaybookCLI.run(PlaybookCLI()) == 0

# Generated at 2022-06-10 22:24:39.561703
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:24:50.654075
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class Options:
        become = False
        become_method = 'sudo'
        become_user = 'root'
        check = False
        connection = 'ssh'
        inventory = '/tmp/ansible/playbooks/inventory'
        module_path = None
        forks = 5
        listhosts = False
        listtags = False
        listtasks = False
        module_path = None
        subset = None
        syntax = False
        timeout = 10
        vault_password_file = '/tmp/ansible/playbooks/vaultpassfile'
        verbosity = 0

    playbook_dir = os.path.dirname(os.path.realpath(__file__)) + '/playbooks/vpn_playbook'
    playbooks = [playbook_dir + '/site-to-site-vpn-configuration.yml']



# Generated at 2022-06-10 22:24:59.154632
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import unittest
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader

    class PlaybookCLI_run(unittest.TestCase):

        def setUp(self):
            self.cli = PlaybookCLI(['playbook_dir'])
            self.cli.options = CLI.base_parser(constants=C).parse_args(args=['--list-tasks'])
            self.display = Display()
            self.loader = DataLoader()
            self.cli.loader = self.loader
            self.inventory = self.cli.inventory
            self.variable_manager = self.cli.variable_manager
            self.variable

# Generated at 2022-06-10 22:25:12.205813
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class FakePbex:
        def run(self):
            return True

    class FakeOption:
        def __init__(self, attrs):
            for k, v in attrs.items():
                setattr(self, k, v)

    class FakeOptParser:
        def __init__(self):
            self.options = FakeOption({'listtags': True, 'listtasks': True, 'args': ["test.yml"], 'verbosity': 1, 'flush_cache': False})

    class FakeInventory:
        def list_hosts(self):
            return [1, 2, 3]

    class FakeVariableManager:
        def clear_facts(self, hostname):
            return

    class FakeCLI:
        def get_host_list(inventory, subset):
            return True


# Generated at 2022-06-10 22:25:14.080269
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli=PlaybookCLI()
    playbook_cli.run()

# Generated at 2022-06-10 22:25:20.923408
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    p = PlaybookCLI([])
    p.options = {}
    p.options['listhosts'] = 1
    p.options['listtasks'] = 1
    p.options['listtags'] = 1
    p.options['syntax'] = 1
    p.options['flush_cache'] = 1
    p.options['verbosity'] = 0
    p.options['args'] = ['../../ansible_test_playbook.yaml']

    result = p.run()
    assert isinstance(result, int)

# Generated at 2022-06-10 22:25:34.161427
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:26:16.261507
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    from ansible.cli.arguments import OptionParser

    context._init_global_context(['ansible-playbook'])
    parser = OptionParser(
        usage='',
        add_help_option=False,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        inventory_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
    )
    pb_cli = PlaybookCLI(parser=parser)
    context.CLIARGS['args'] = ['unittest_playbook.yml']
    # Test run with empty inventory and no module_path

# Generated at 2022-06-10 22:26:26.857774
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Constants
    import sys

    CUR_PLATFORM=sys.platform

    if CUR_PLATFORM.startswith('win'):
        class PlaybookCLI(object):
            inventory_class = 'WindowsInventory'

    else:
        class PlaybookCLI(object):
            inventory_class = 'SSHInventory'


    # Prepare mocks
    class AnsibleError(Exception):
        def __init__(self, msg):
            self.message = msg

    class MockCLIARGS(dict):
        def __init__(self):
            self.update(**{
                'args': ['test_playbook']
            })

    class MockPlaybookExecutor(object):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-10 22:26:27.982947
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """Returns: None"""
    pass

# Generated at 2022-06-10 22:26:40.610718
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    python unit test for the PlaybookCLI class method run
    '''

# Generated at 2022-06-10 22:26:51.354236
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class MockPlaybookExecutor:
        def __init__(self, loader, inventory, variable_manager, callbacks=None, passwords=None, stdout_callback=None, run_additional_callbacks=None, run_tree=False, statistics=True, tags=None, skip_tags=None, check=False, diff=False, force_handlers=False, extra_vars=None, start_at_task=None):
            self.loader = loader

# Generated at 2022-06-10 22:26:52.177013
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-10 22:26:58.289499
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("Testing PlaybookCLI.run()")

    # Test no playbooks

# Generated at 2022-06-10 22:27:06.768080
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from collections import namedtuple

    class Options():
        listhosts = False
        listtasks = False
        listtags = False
        syntax = False
        subset = None
        verbosity = 0
        connection = 'smart'
        timeout = 10
        remote_user = 'root'
        ask_pass = False
        private_key_file = None
        become = False
        become_method = 'sudo'
        become_user = ''
        check = False
        inventory = None
        extra_vars = []
        vault_password = None
        module_path = None

# Generated at 2022-06-10 22:27:17.989077
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Mocking data for test
    class TestPluginLoader(object):
        def __init__(self):
            pass

        # Mocking method for test
        def add_directory(self, path, with_subdir=False):
            pass

        # Mocking method for test
        def add_all_plugin_dirs(self, path):
            pass

    cls = PlaybookCLI()
    cls.plugin_loader = TestPluginLoader()
    cls.plugin_loader.set_package_paths = Mock()
    cls.options = Mock()
    cls.options.verbosity = 3
    cls.options.connection = 'smart'
    cls.options.module_path = None
    cls.options.forks = 5
    cls.options.private_key_file = 'test_key'


# Generated at 2022-06-10 22:27:23.734203
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI(['-i', 'localhost,', 'test.yml'])
    cli.post_process_args()
    try:
        cli.run()
    except Exception as e:
        raise AssertionError(e)
    return True

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-10 22:28:32.305491
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # test with a valid playbook path
    test_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if test_path not in sys.path:
        sys.path.append(test_path)
    class MockCLI(object):
        def __init__(self):
            self.options=None

        def run(self):
            cli = PlaybookCLI(self)
            # enter a fake playbook path
            cli.run = ["/tmp/example.yml"]
            cli.options, args = cli.parser.parse_args()
            self.options = args
            return args

    with MockCLI() as pb:
        result = pb.run()

# Generated at 2022-06-10 22:28:33.173693
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI()
    playbook_cli.run()

# Generated at 2022-06-10 22:28:33.924543
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert 1 == 1

# Generated at 2022-06-10 22:28:40.368636
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    config_file = 'test-data/test_PlaybookCLI_run/ansible.cfg'
    playbook = 'test-data/test_PlaybookCLI_run/playbook.yml'
    with open(playbook, 'rb') as play:
        content = play.read()

# Generated at 2022-06-10 22:28:49.887382
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Initiate the class object
    pb = PlaybookCLI()

    # Create a loader object to load data
    loader = DataLoader()

    # Create a variable manager object to manage VariableManager
    variable_manager = VariableManager()

    # Create a InventoryManager object to manage InventoryManager
    inventory = InventoryManager(loader=loader, sources='localhost,')

    # Initiate a Play class object to manage Play
    play

# Generated at 2022-06-10 22:28:58.338761
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # stubs
    class MyCLI(PlaybookCLI):
        def _play_prereqs(self):
            return (1,2,3)

        def ask_passwords(self):
            return (4,5)

    # test setup
    args = ['--list-hosts', '-vvvv', './test-playbook', 'test-playbook2']
    cli = MyCLI(args)
    assert cli is not None
    assert cli.args == args

    # stub
    class StubDisplay:
        @staticmethod
        def display(msg):
            print("StubDisplay.display: {}".format(msg))

        @staticmethod
        def display(msg):
            print("StubDisplay.display: {}".format(msg))
    display = StubDisplay

    # test
    assert cl

# Generated at 2022-06-10 22:29:03.509541
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # set up patching
    pc = PlaybookCLI()
    pc.ask_passwords = lambda: ('sshpass', 'becomepass')
    pc.ask_vault_passwords = lambda: ('vaultpass', )
    pc._play_prereqs = lambda: (DataLoader(), InventoryManager(None, None), VariableManager(loader=DataLoader()))
    pc.post_process_args = lambda x: x

    # test run
    pc.run()

# Generated at 2022-06-10 22:29:09.111718
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-10 22:29:11.562786
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    context.CLIARGS = {'subset': ['localhost']}
    p = PlaybookCLI([])
    try:
        p.run()
    except AnsibleError as e:
        assert False, e



# Generated at 2022-06-10 22:29:19.680442
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: This unit test is not completed. And it has some problems.
    pass
#    command = 'ansible-playbook --help'
#    pbcli = PlaybookCLI(['--help'], command)
#
#    # Test when not successfully calling init_parser()
#    pbcli.init_parser = Mock(side_effect=AnsibleError)
#    assert pbcli.run() == 2
#
#    # Test when not successfully calling post_process_args()
#    pbcli.init_parser = Mock(return_value=0)
#    pbcli.post_process_args = Mock(side_effect=AnsibleError)
#    assert pbcli.run() == 5
#
#    # Test when not successfully calling _play_prereqs()
#    pbcli