

# Generated at 2022-06-24 17:54:29.099081
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 40.0
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.run()


if __name__ == "__main__":
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:30.578283
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Check that method run works
    try:
        test_case_0()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 17:54:32.574445
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # setup
    float_0 = 60.0
    playbook_c_l_i_0 = PlaybookCLI(float_0)

    # execution
    playbook_c_l_i_0.run()

    # verifying


# Generated at 2022-06-24 17:54:42.189487
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    #we have to create lots of mocks in this test to run PlaybookCLI.run()
    #To run PlaybookCLI.run(), we have to create a PlaybookExecutor instance, so we have to create a lot of objects.
    #Here we mock all these objects.
    #We do not test the method run of class PlaybookExecutor here because it is a long test. We test the method run of
    #class PlaybookExecutor in test_playbook_executor.py.

    #Create a mock for global variable CLIARGS.
    class Mock_CLIARGS():
        def __init__(self):
            self.args = ['playbook.yml', 'playbook2.yml']
            self.listhosts = False
            self.listtasks = False
            self.listtags = False
            self.syntax

# Generated at 2022-06-24 17:54:47.491577
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbooks = ['ansible/test/units/mock/playbook_test.yml']
    playbook_c_l_i_0 = PlaybookCLI(0.0)
    res = playbook_c_l_i_0.run()
    assert res==0

# Generated at 2022-06-24 17:54:56.820974
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 60.0
    # Input parameters testing
    # Item: int_0
    # Item: float_0
    # Item: int_0
    # Item: float_0
    # Item: int_0
    # Item: float_0
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    int_0 = 60
    float_0 = 60.0
    int_0 = 60
    float_0 = 60.0
    int_0 = 60
    float_0 = 60.0
    int_0 = 60
    playbook_c_l_i_0.run(int_0, float_0, int_0, float_0, int_0, float_0, int_0)



# Generated at 2022-06-24 17:55:10.794047
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 60.0
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    float_0 = 60.0
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    float_0 = 60.0
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    float_0 = 60.0
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    float_0 = 60.0
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    float_0 = 60.0
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    float_0 = 60.0
    playbook_c_l_i_0

# Generated at 2022-06-24 17:55:11.790187
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:19.894360
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 60.0
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.init_parser()
    playbook_c_l_i_0.post_process_args(playbook_c_l_i_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:22.682136
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 60.0
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:55:37.700202
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = '[$]4Q'
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1}
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1}
    playbook_c_l_i_1 = PlaybookCLI(str_1, dict_1)
    var_1 = playbook_c_l_i_1.run()
    assert var_1 == 0


# Generated at 2022-06-24 17:55:40.370196
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = ']Dd'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    playbook_c_l_i_0 = PlaybookCLI(str_0, dict_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:41.200536
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:43.401403
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 17:55:44.940122
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    for v in range(7):
        test_case_0()

# Generated at 2022-06-24 17:55:46.256803
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:54.829370
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # setup
    str_0 = '\\@[6"y'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    playbook_c_l_i_0 = PlaybookCLI(str_0, dict_0)

    # test
    var_0 = playbook_c_l_i_0.run()

    # cleanup
    del playbook_c_l_i_0

# Generated at 2022-06-24 17:55:56.442638
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    for i in range(0):
        test_case_0()



# Generated at 2022-06-24 17:56:03.409198
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\\@[6"y'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    playbook_c_l_i_0 = PlaybookCLI(str_0, dict_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:56:04.720245
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:16.403848
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()    
    

# Generated at 2022-06-24 17:56:20.595286
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except SystemExit as exit_0:
        if exit_0.args[0] == 0:
            pass
        else:
            assert False


# Generated at 2022-06-24 17:56:21.843053
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:25.734357
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\\@[6"y'
    playbook_c_l_i = PlaybookCLI(str_0, str_0)
    var_0 = playbook_c_l_i.run()
    assert var_0 == 0

# Generated at 2022-06-24 17:56:30.721550
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # One test case
    str_0 = '\\@[6"y'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_0)
    var_0 = playbook_c_l_i_0.run()


if __name__ == "__main__":
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:45.270978
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    arg_0 = '[]'
    arg_1 = '[]'
    arg_2 = 0
    arg_3 = 0
    arg_4 = 0
    arg_5 = 0
    arg_6 = 0
    arg_7 = 0
    arg_8 = 0
    arg_9 = 0
    arg_10 = 0
    arg_11 = 0
    arg_12 = 0
    arg_13 = '[]'
    arg_14 = 0
    arg_15 = '[]'
    arg_16 = 0
    arg_17 = 0
    arg_18 = 0
    arg_19 = 0
    arg_20 = 0
    arg_21 = 0
    arg_22 = 0
    arg_23 = 0
    arg_24 = 0
    arg_25 = 0
    arg_26 = 0
    arg

# Generated at 2022-06-24 17:56:48.535779
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('\\@[6"y', '\\@[6"y')
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:51.454067
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args_0 = "1"
    args_1 = "2"
    cli_args_0 = {'args': [args_0, args_1]}
    test_case_0()

# Generated at 2022-06-24 17:56:56.322119
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Initialization

    # Testing
    try:
        test_case_0()
    except Exception as e:
        print('Exception raised: ' + str(e))
        assert 1 == 0  # Test failed
    else:
        assert 1 == 1  # Test passed

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:57.437892
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:24.165483
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\\@[6"y'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:57:30.377056
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    module_0 = AnsibleError
    var_0 = PlaybookCLI('\{\*\+\$\?', '\{\*\+\$\?')
    print(str(var_0.run()), end = '')
    module_1 = AnsibleError
    var_1 = PlaybookCLI('A', 'A')
    print(str(var_1.run()), end = '')
    module_2 = AnsibleError
    var_2 = PlaybookCLI('B', 'B')
    print(str(var_2.run()), end = '')
    module_3 = AnsibleError
    var_3 = PlaybookCLI('C', 'C')
    print(str(var_3.run()), end = '')
    module_4 = AnsibleError
    var_4 = Play

# Generated at 2022-06-24 17:57:31.945077
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-24 17:57:36.293228
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:37.517644
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:38.523728
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:42.741076
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\\@[6"y'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_0)
    var_0 = playbook_c_l_i_0.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:57:48.148844
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\\@[6"y'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_0)
    var_0 = playbook_c_l_i_0.run()


# Test cases
# test_case_0()
test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:50.551676
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:51.848463
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:58:22.537840
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:25.267996
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try: test_case_0()
    except: print('Exception (test_PlaybookCLI_run)')
    else: pass
    finally: pass

# Generated at 2022-06-24 17:58:26.155617
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:30.834587
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dT\\w'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_0)
    int_0 = playbook_c_l_i_0.run()
    assert int_0 == 0


# Generated at 2022-06-24 17:58:32.483696
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:36.619901
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
        # create a new PlaybookCLI object
        playbookCLI = PlaybookCLI()

        # test the run method and test that it returns the expected result
        r = playbookCLI.run()
        assert(r == 0)

# Generated at 2022-06-24 17:58:37.251505
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:40.659125
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\\@[6"y'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_0)
    str_1 = 'yF)U'
    playbook_c_l_i_0.init_parser(str_1)
    var_1 = playbook_c_l_i_0.post_process_args(str_1)
    var_2 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:58:52.576936
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = 'PlaybookCLI'
    str_2 = '\\6~'
    str_3 = '\\#@'
    str_4 = 'PlaybookCLI'
    str_5 = '\\6~'
    str_6 = '\\#@'
    str_7 = '@[)'
    str_8 = 'PlaybookCLI'
    str_9 = '\\6~'
    str_10 = '\\#@'
    str_11 = '@[)'
    str_12 = 'PlaybookCLI'
    str_13 = '\\6~'
    str_14 = '\\#@'
    str_15 = '@[)'

    test_case_0()
    var_1 = PlaybookCLI(str_1, str_2)
    var_2 = var

# Generated at 2022-06-24 17:59:02.730716
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '`W'
    str_1 = 'NyN'
    str_2 = 'H'
    str_3 = 'aXt'
    str_4 = 'm'
    str_5 = 'm'
    str_6 = 'T3'
    str_7 = '4'
    str_8 = '!'
    str_9 = ';'
    str_10 = '%'
    str_11 = '{'
    str_12 = '('
    str_13 = '7'
    str_14 = 'A'
    str_15 = '|'
    str_16 = 'S'
    str_17 = 'D'
    str_18 = '4'
    str_19 = '-'
    str_20 = 't'

# Generated at 2022-06-24 17:59:37.426458
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Run all test cases

# Generated at 2022-06-24 17:59:40.430499
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # AnsibleError: the playbook: @"y could not be found
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:41.738475
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:43.054336
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:44.671567
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# vim:ft=python

# Generated at 2022-06-24 17:59:48.597659
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '?a'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:49.797741
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:51.140579
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert test_case_0() == None

# Generated at 2022-06-24 17:59:54.622660
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\\@[6"y'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:55.884457
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:32.426117
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:34.600277
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\\@[6"y'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:00:40.369142
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\\@[6"y'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_0)
    var_0 = playbook_c_l_i_0.run()

    # assert the results
    if var_0 == 0:
        print('# Test has passed')
    else:
        print('# Test has failed')


# Generated at 2022-06-24 18:00:41.326532
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:44.106517
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    try:
        test_case_0()
    except Exception as e:
        print("Exception in test case: {}".format(e))
        raise e

# Generated at 2022-06-24 18:00:45.349327
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:50.812517
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\\@[6"y'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_0)
    var_0 = playbook_c_l_i_0.run()
    var_1 = test_case_0()



# Generated at 2022-06-24 18:00:54.121631
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert callable(PlaybookCLI.run)

# Generated at 2022-06-24 18:00:56.902678
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        raise Exception('Assertion failed')
    except:
        PlaybookCLI_instance_0 = PlaybookCLI('"j_\\', 'Y"$')
        PlaybookCLI_instance_0.run()


# Generated at 2022-06-24 18:01:02.272359
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    param_0 = '\\@[6"y'
    param_1 = '\\@[6"y'
    playbook_c_l_i_0 = PlaybookCLI(param_0, param_1)
    assert playbook_c_l_i_0.run() == 0
    assert playbook_c_l_i_0.run() == 0
    assert playbook_c_l_i_0.run() == 0
    assert playbook_c_l_i_0.run() != 0
    assert playbook_c_l_i_0.run() == 0
    assert playbook_c_l_i_0.run() == 0
    assert playbook_c_l_i_0.run() == 0
    assert playbook_c_l_i_0.run() != 0

# Generated at 2022-06-24 18:02:28.147558
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI.run()

# Generated at 2022-06-24 18:02:30.163352
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:31.177092
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:02:33.447509
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:44.657311
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_playbook_path
    from ansible.utils.display import Display
    from .__main__ import AnsibleError
    from .__main__ import CLI
    from .__main__ import PlaybookExecutor
    from .__main__ import context
    from .__main__ import opt_help
    from .connection_plugins.local import Connection as Connection
    from .errors import AnsibleError
    from .inventory.manager import InventoryManager as InventoryManager
    from .parsing.plugin import parse_yaml_from_file as parse_yaml_from_file
    from .playbook.play_context import PlayContext as PlayContext

# Generated at 2022-06-24 18:02:48.603728
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:50.898592
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:52.541525
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("Testing PlaybookCLI.run")
    test_case_0()

# Generated at 2022-06-24 18:02:54.534822
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Call method run of class PlaybookCLI
    test_case_0()
    test_case_1()

# Generated at 2022-06-24 18:03:01.769747
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Arrange
    argv = ['ansible-playbook',
            '/home/david/PycharmProjects/Golem/ansible-golem/golem_deployment.yml',
            '--extra-vars', 'ansible_python_interpreter=/home/david/.virtualenvs/golem/bin/python']

    context.CLIARGS = context.CLI.parse(args=argv[1:])

    playbook_c_l_i = PlaybookCLI('', '')

    # Act
    var = playbook_c_l_i.run()

    # Assert
    assert var == 0