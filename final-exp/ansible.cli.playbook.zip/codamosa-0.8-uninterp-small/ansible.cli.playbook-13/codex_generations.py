

# Generated at 2022-06-24 17:54:27.950919
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = float()
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_result = playbook_c_l_i_0.run()
    assert playbook_c_l_i_result == 0

# Generated at 2022-06-24 17:54:29.998176
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    result = PlaybookCLI.run()

if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-24 17:54:38.152966
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli.arguments import option_helpers
    # Uncomment the following code and run the unit test.
    # test_case_0()
    ansible_cli_arguments_option_helpers_0 = option_helpers()
    # Instantiate the PlaybookCLI class.
    float_0 = -2123.082911
    playbook_c_l_i_0 = PlaybookCLI(ansible_cli_arguments_option_helpers_0)
    # Run the run method of the PlaybookCLI class.
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:54:48.223880
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = -2.84928571465E9
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.parser = _MagicMock(
        return_value=None
    )
    playbook_c_l_i_0._play_prereqs = _MagicMock(
        return_value=(
            _MagicMock(
                return_value=None
            ), _MagicMock(
                return_value=None
            ), _MagicMock(
                return_value=None
            )
        )
    )
    playbook_c_l_i_0.ask_passwords = _MagicMock(
        return_value=(
        None, None)
    )
    playbook_c_l_i_0.validate

# Generated at 2022-06-24 17:54:53.642144
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    arm_str_0 = "/etc/ansible/ansible.cfg"
    float_0 = -1286.6534
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.read_vault_encrypt_string(arm_str_0)


# Generated at 2022-06-24 17:54:54.670767
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:55:04.648789
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Set up test objects
    args = [
        '-vvvv',
        '-i', 'hosts',
        'site.yml'
    ]
    test_cli = PlaybookCLI(args)
    test_cli.post_process_args()
    test_cli.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:05.690170
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:07.563313
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  p = PlaybookCLI(0)
  p.run()


# Generated at 2022-06-24 17:55:14.029797
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    int_0 = 0
    array_0 = []
    float_0 = 0.510771775756
    int_1 = 17504
    playbook_c_l_i_0 = PlaybookCLI(int_0)
    playbook_c_l_i_0.setup_parser()
    playbook_c_l_i_0.playbook_path = array_0
    playbook_c_l_i_0.options = float_0
    playbook_c_l_i_0.args = int_1
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:26.965876
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test case 0
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:37.022762
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Setup
    float_0 = 2123.082911
    float_1 = -2123.082911
    float_2 = 2123.082911
    float_3 = -2123.082911
    float_4 = 2123.082911
    float_5 = -2123.082911
    float_6 = 2123.082911
    float_7 = -2123.082911
    float_8 = 2123.082911
    float_9 = -2123.082911
    str_0 = 'hello world'


    testcase_PlaybookCLI_run_1_0 = test_case_0()

    testcase_PlaybookCLI_run_2_0 = test_case_0()


# Generated at 2022-06-24 17:55:39.290761
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    p = PlaybookCLI(None)
    p.run()
    test_case_0()

# Generated at 2022-06-24 17:55:45.127125
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    global test_case_0_args
    global test_case_0_expected_result
    global test_case_0_expected_result_calls

    # Initialize test environment
    test_case_0_args = {"args": ['', 0]}

    # Call method run of class PlaybookCLI
    res = PlaybookCLI.run(**test_case_0_args)

    # assert results
    assert(res == None)

# Generated at 2022-06-24 17:55:53.430622
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    runner = PlaybookCLI()
    arguments_0 = {}
    opt = runner.init_parser()
    arguments_0 = opt.parse_args(["test"])
    runner.post_process_args(arguments_0)
    status = runner.run()
    assert status == 0, "Assertion failed"

if __name__ == "__main__":
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:55.288420
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI_instance = PlaybookCLI()
    PlaybookCLI_instance.run()


# Generated at 2022-06-24 17:55:57.706053
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    ansible_playbooks_cli = PlaybookCLI()
    ansible_playbooks_cli.run()

# Generated at 2022-06-24 17:56:00.184746
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()
    cli.run()


# Generated at 2022-06-24 17:56:10.912880
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = -12.3123
    instance = PlaybookCLI()

    # Tests are run from tests/runner/, so get parent directory.
    parent_directory = os.path.dirname(__file__)

    # Basic syntax test, no error should be raised
    instance.post_process_args(
        opt_help.parse_connection_opt(['-c', 'local',
                                       '-i', os.path.join(parent_directory, 'test_inventories/test_inventory_file'),
                                       '-e', '@' + os.path.join(parent_directory, 'test_extra_vars.yml')]))
    instance.run()


# Unit tests for method post_process_args of class PlaybookCLI

# Generated at 2022-06-24 17:56:13.289016
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbookcli_0 = PlaybookCLI()
    playbookcli_0.run()

# Generated at 2022-06-24 17:56:48.714242
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    loader = to_bytes = C = display = 1
    sshpass = context.CLIARGS['listhosts'] = None
    becomepass = context.CLIARGS['listtasks'] = None
    passwords = context.CLIARGS['listtags'] = None
    b_playbook_dirs = context.CLIARGS['subset'] = None
    context.CLIARGS['syntax'] = 1

    test_PlaybookCLI = PlaybookCLI()
    test_PlaybookCLI.post_process_args = test_case_0

    #Test with an exception in the post_process_args method
    try:
        test_PlaybookCLI.run()
    except:
        pass

    #Test without an exception in the post_process_args method

# Generated at 2022-06-24 17:56:50.519587
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI('ansible-playbook', [])
    cli.run()

# Generated at 2022-06-24 17:57:00.145526
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:02.147858
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create a Mock object
    class Mock_PlaybookCLI(PlaybookCLI):
        def __init__(self):
            pass

    Mock_PlaybookCLI.run(test_case_0)

# Generated at 2022-06-24 17:57:04.406479
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:15.834098
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("Test: Run method of class PlaybookCLI")
    print("Test Case 0: Case with required parameter playbook:")
    test_case_0()
    print("Test Case 1: Case with required parameter host_vars_path")
    test_case_1()
    print("Test Case 2: Case with required parameter retry_files_enabled")
    test_case_2()
    print("Test Case 3: Case with required parameter inventory_path")
    test_case_3()
    print("Test Case 4: Case with required parameter force_handlers")
    test_case_4()
    print("Test Case 5: Case with required parameter diff")
    test_case_5()
    print("Test Case 6: Case with required parameter private_key_file")
    test_case_6()

# Generated at 2022-06-24 17:57:18.117836
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI()
    assert playbook_cli.run() == 0


# Generated at 2022-06-24 17:57:20.365654
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbookCLI = PlaybookCLI()
    playbookCLI.run()


# Generated at 2022-06-24 17:57:26.319155
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  # Create an instance of PlaybookCLI
  PlaybookCLI_instance = PlaybookCLI()
  PlaybookCLI_instance.run()

# Create an instance of PlaybookCLI
PlaybookCLI_instance = PlaybookCLI()

# Create an instance of class CLI
CLI_instance = CLI()


# Generated at 2022-06-24 17:57:28.365612
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    x = PlaybookCLI()
    x.init_parser()
    x.run()


# Generated at 2022-06-24 17:57:59.699182
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # initialize CLI object
    pbc = PlaybookCLI()

    # initialize arguments
    args = ['tests/test_data/test_playbook.yml']
    pbc._options.__dict__['args'] = args

    # call method under test
    pbc.run()

    # get variable and check results
    tasks = pbc._tqm._unserialized_data['tasks']
    assert tasks


# Generated at 2022-06-24 17:58:08.963701
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("\n\nRunning tests for method run of class PlaybookCLI")

    for i in range(10):
        args = ['--vault-password-file', 'sample_vault_password_file']
        isinstance = ansible.cli.PlaybookCLI.run(PlaybookCLI, args)
        assert isinstance == None

if __name__ == '__main__':
    test_case_0()
    # test_PlaybookCLI_run()

    # print("\nAll tests have passed!")

# Generated at 2022-06-24 17:58:17.522905
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    inventory = Inventory(loader=CLI.loader, variable_manager=CLI.variable_manager, host_list=CLI.inventory)
    options = CLI.options
    passwords = {}
    loader = False
    pbex = PlaybookExecutor(playbooks=context.CLIARGS['args'], inventory=inventory,
                            variable_manager=variable_manager, loader=loader,
                            passwords=passwords)
    if (options.listhosts or options.listtasks or options.listtags or options.syntax):
        CLI.get_host_list(inventory, options.subset)

# Generated at 2022-06-24 17:58:27.045693
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Setup
    def ask_passwords():
        return 'ask_passwords return value', 'ask_passwords return value'

    def _play_prereqs():
        return '_play_prereqs return value', '_play_prereqs return value', '_play_prereqs return value'

    def _flush_cache(inventory, variable_manager):
        pass
    PlaybookCLI.__dict__['ask_passwords'] = ask_passwords
    PlaybookCLI.__dict__['_play_prereqs'] = _play_prereqs
    PlaybookCLI.__dict__['_flush_cache'] = _flush_cache

    context.CLIARGS = {'verbosity': 0, 'ask_passwords': True, 'flush_cache': False, 'listhosts': True}

# Generated at 2022-06-24 17:58:34.281643
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pbcli = PlaybookCLI()
    # Test with no argument
    assert pbcli.run() == 1, 'unexpected value for call'
    # Test with integer argument
    assert pbcli.run(0) == 1, 'unexpected value for call'
    # Test with float argument
    assert pbcli.run(0.0) == 1, 'unexpected value for call'
    # Test with list argument
    assert pbcli.run([]) == 1, 'unexpected value for call'
    # Test with dictionary argument
    assert pbcli.run({}) == 1, 'unexpected value for call'
    # Test with string argument
    assert pbcli.run('') == 1, 'unexpected value for call'
    # Test with invalid argument

# Generated at 2022-06-24 17:58:34.932398
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:35.604603
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert 1 == 1
    assert 1 == 1

# Generated at 2022-06-24 17:58:37.022896
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    r = None
    r = PlaybookCLI()
    r.run()

# Generated at 2022-06-24 17:58:39.336507
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    my_PlaybookCLI = PlaybookCLI()
    my_PlaybookCLI.run()


# Generated at 2022-06-24 17:58:42.123630
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_PlaybookCLI = PlaybookCLI()
    test_PlaybookCLI.run()


# Generated at 2022-06-24 17:59:14.523003
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:59:15.648414
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:16.891837
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:21.878709
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.cli import PlaybookCLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.playbook_include import PlaybookInclude
    #Testing case 0
    #Created on 31/08/2020 by U5DIXN
    str_0 = 'discovered_interpreter_%s'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()




# Generated at 2022-06-24 17:59:22.747267
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:27.522265
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cmd = ['ansible-playbook', '-i', './tests/utils/inventory', './tests/utils/ansible_module.yml']
    pb = PlaybookCLI(cmd)
    rc = pb.run()
    assert rc == 0

# Generated at 2022-06-24 17:59:29.737417
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('Test case 0')
    test_case_0()


if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:32.894589
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # playbook_c_l_i_0 = PlaybookCLI('discovered_interpreter_%s')
    # var_0 = playbook_c_l_i_0.run()
    pass


main = PlaybookCLI

# Generated at 2022-06-24 17:59:33.932554
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:35.132442
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:40.327779
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    playbook_c_l_i_0.post_process_args(None)
    playbook_c_l_i_0.run()

# Assert that the run method of class PlaybookCLI returns 0

# Generated at 2022-06-24 18:00:41.753626
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    PlaybookCLI.run()

# Generated at 2022-06-24 18:00:43.609411
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

test_PlaybookCLI_run()

# Generated at 2022-06-24 18:00:44.828156
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:00:51.700374
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except NameError as ne:
        print("NameError:", ne)
    except RuntimeError as re:
        print("RuntimeError:", re)
    except TypeError as te:
        print("TypeError:", te)
    except ValueError as ve:
        print("ValueError:", ve)
    except Exception as e:
        print("Exception:", e)

# end of PlaybookCLI class

# Generated at 2022-06-24 18:01:03.019423
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    inventory_path = 'test/hosts'
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=inventory_path)
    variable_manager.set_inventory(inventory)
    playbook_path = 'test/test_playbook.yml'
    if not os.path.exists(playbook_path):
        print('[INFO] The playbook does not exist')
        sys.exit()
    options = Options()
    options.verbosity = 1
    options.become = True
    options.become_method = ['sudo', 'su', 'pbrun', 'pfexec']
    options.become_user = 'root'
    options.connection = 'ssh'
    options.module_path = None

# Generated at 2022-06-24 18:01:04.462918
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:10.220392
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    param_0 = 'discovered_interpreter_%s'
    playbook_c_l_i_0 = PlaybookCLI(param_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0

# Generated at 2022-06-24 18:01:16.612724
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:01:19.418416
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:03:49.131417
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'discovered_interpreter_%s'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:03:49.841571
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:50.457213
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:03:51.743827
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:53.041991
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:54.206086
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:58.504014
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'discovered_interpreter_%s'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:03:59.102649
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:04:00.225812
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:04:05.967392
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'discovered_interpreter_%s'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()