

# Generated at 2022-06-24 17:54:31.650103
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test case that asserts that the method run doesn't throw any exceptions.
    args = ['---', 'play.yml']
    c = PlaybookCLI(args)
    try:
        c.run()
    except Exception as e:
        assert False, 'the method run should not throw an exception'

# Generated at 2022-06-24 17:54:33.536715
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("Test case run for method run of class PlaybookCLI")
    test_case_0()


if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-24 17:54:35.996693
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 706.383956
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:54:37.525029
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    ansible_0 = PlaybookCLI()
    ansible_0.run()


# Generated at 2022-06-24 17:54:40.842501
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_1 = 526.55348649
    playbook_c_l_i_1 = PlaybookCLI(float_1)
    assert playbook_c_l_i_1 is not None


# Generated at 2022-06-24 17:54:54.268313
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    display = Display()
    display.verbosity = 0
    display.set_verbosity(0)
    pb = PlaybookCLI()
    if pb.parser:
        if pb.parser.prog:
            pb.parser.prog = ""
        if pb.parser.description:
            pb.parser.description = ""
        if pb.parser.usage:
            pb.parser.usage = ""
    args = []

# Generated at 2022-06-24 17:54:56.472211
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 706.383956
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    try:
        playbook_c_l_i_0.run()
    except SystemExit:
        pass

# Generated at 2022-06-24 17:55:00.216598
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 1383.017932
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_0 = 'playbook.txt'
    str_0 = playbook_c_l_i_0.run(playbook_0)
    assert str_0 == 'playbook = playbook.txt, localhost'


# Generated at 2022-06-24 17:55:08.134797
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 26.98
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.parse()
    playbook_c_l_i_0.post_process_args()
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    # test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:10.569529
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI(True)
    playbook_c_l_i_0.run()

# Test case for class PlaybookCLI

# Generated at 2022-06-24 17:55:20.898052
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:22.839132
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass


# Generated at 2022-06-24 17:55:27.530693
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 706.383956
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:55:30.115551
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 706.383956
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    assert(playbook_c_l_i_0.run() == 0)

# Generated at 2022-06-24 17:55:37.702660
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import tempfile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.splitter import parse

    inventory = CLI.make_inventory([])
    variable_manager = CLI.make_variable_manager(inventory, context.CLIARGS)
    loader = CLI.make_loader(context.CLIARGS['module_path'], '', None, True)

    # create a dummy playbook
    fd, playbook = tempfile.mkstemp()
    os.close(fd)
    open(playbook, 'w').write('---\n- name: Testing\n  hosts: all\n  connection: local\n')
    pbcl = PlaybookCLI(['-i', 'localhost,' + playbook])

# Generated at 2022-06-24 17:55:39.239428
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 706.383956
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:44.984107
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()

    # Test with playbook CLI args
    cli_args = [
        'ansible-playbook',
        'playbook.yml',
        '--list-hosts',
        '--become',
        '--become-method=sudo',
        '--become-user=test',
        '--check',
        '--check-implicit-dependencies'
    ]
    # pylint: disable=unbalanced-tuple-unpacking
    (cli_args, _) = PlaybookCLI.parse(cli_args, None)
    context.CLIARGS = cli_args
    assert playbook_c_l_i_0.run() == 0

    # Test without playbook CLI args

# Generated at 2022-06-24 17:55:53.318126
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 615.602227
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    result = playbook_c_l_i_0.run()
    print('The result of test_PlaybookCLI_run is: ', result)
    assert result == 0


if __name__ == '__main__':
    # test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:55.779691
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 706.383956
    playbook_c_l_i_0 = PlaybookCLI(float_0)



# Generated at 2022-06-24 17:56:00.874743
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 454.857659
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    result = playbook_c_l_i_0.run()
    assert(result == 1)

# Generated at 2022-06-24 17:56:18.177212
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()
    print(var_0)

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:24.096174
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()
    var_1 = playbook_c_l_i_0.run()

# Testing if argparse is being called correctly

# Generated at 2022-06-24 17:56:27.647711
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:56:32.324292
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        bytes_0 = b'\xde'
        playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    except NameError:
        pass
    else:
        # Type error
        assert False, "unexpected behavior"

# Generated at 2022-06-24 17:56:35.102790
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.modules import some_module
    some_module.main()
    test_case_0()

# Generated at 2022-06-24 17:56:46.860472
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args = ['ansible-playbook', '-i', 'localhost,', 'playbook.yml']
    bytes_0 = b'\xde'

    with patch.object(PlaybookCLI, 'get_opt_parser') as patched_get_opt_parser:
        instance = PlaybookCLI()
        patched_get_opt_parser.return_value = instance.parse(args)
        instance.post_process_args = MagicMock(return_value=args)
        instance.init_parser = MagicMock(return_value=args)
        instance.run()
        assert instance.post_process_args.call_count == 1
        assert instance.init_parser.call_count == 1


# Generated at 2022-06-24 17:56:52.503220
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b''
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    playbook_c_l_i_0.init_parser()
    playbook_c_l_i_0.post_process_args('{}')
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:54.844359
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:57.615126
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:58.513068
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:27.881451
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    for _ in range(6):
        test_case_0()

# Generated at 2022-06-24 17:57:30.304823
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert True == True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:57:32.331568
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:33.743346
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:37.734874
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()

try:
    test_case_0()
except Exception as e:
    print(e)

# Generated at 2022-06-24 17:57:40.717931
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI(1)
    var_0 = playbook_c_l_i_0.run()

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:49.372389
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()
    # Print successful test result to standard output (text stream)
    print("Test successful")

if __name__ == '__main__':
    import sys
    try:
        # Setup test data
        test_PlaybookCLI_run()
    except Exception:
        # Output unexpected Exceptions
        print(traceback.format_exc())
        sys.exit(1)
    else:
        # Continue with next test(s)
        sys.exit(0)

# Generated at 2022-06-24 17:57:50.604463
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:54.247306
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:57:55.441605
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    pass


# Generated at 2022-06-24 17:58:56.481458
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()



# Generated at 2022-06-24 17:59:00.566543
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print(">> Test method run of class PlaybookCLI")
    print(">> Calling test case 0")
    test_case_0()
    print(">> Calling test case 1")
    test_case_1()



# Generated at 2022-06-24 17:59:06.612858
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:08.121261
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:13.129648
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:14.635941
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:18.894262
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:21.272124
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0


# Generated at 2022-06-24 17:59:32.511422
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    bytes_1 = b'\xe6'
    bytes_2 = b'\xab'
    bytes_3 = b'\xa1'
    bytes_4 = b'\xce'
    bytes_5 = b'\xce'
    bytes_6 = b'\xbe'
    bytes_7 = b'\xbe'
    bytes_8 = b'\xa5'
    bytes_9 = b'\xa5'
    bytes_10 = b'\xf5'
    bytes_11 = b'\xf5'
    bytes_12 = b'\xde'
    bytes_13 = b'\xde'
    bytes_14 = b'\xa5'
    bytes_15 = b'\xa5'

# Generated at 2022-06-24 17:59:33.307784
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test base case
    test_case_0()

# Generated at 2022-06-24 18:02:02.051252
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_1 = PlaybookCLI('bW8')
    var_1 = playbook_c_l_i_1.run()


# Generated at 2022-06-24 18:02:05.772908
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xc9\x83\xe6\x91\xff\x01@\x01\x14\xa2\x7f'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:02:09.151410
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-24 18:02:13.590260
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xde'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:02:18.424017
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# vim: expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

# Generated at 2022-06-24 18:02:22.095560
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
        assert True
    except Exception as ex:
        raise AssertionError("Test failed: " + str(ex))

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:25.272605
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # test_PlaybookCLI_run.py:8: error: 'PlaybookCLI' object has no attribute '_flush_cache'
    pass



# Generated at 2022-06-24 18:02:30.099883
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI(None)
    try:
        playbook_c_l_i_0.run()
    except Exception as e:
        print(str(e))
        assert False


# Generated at 2022-06-24 18:02:42.181284
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xae'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    playbook_c_l_i_0._flush_cache('ac9', 'ac9')
    playbook_c_l_i_0._flush_cache('ac9', 'ac9')
    playbook_c_l_i_0.run()
    playbook_c_l_i_0.run()
    bytes_1 = b'\xee'
    playbook_c_l_i_1 = PlaybookCLI(bytes_1)
    playbook_c_l_i_1.run()
    playbook_c_l_i_1.run()
    playbook_c_l_i_1.run()
    playbook_c_l_i_1.run()
    playbook_

# Generated at 2022-06-24 18:02:43.134006
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
