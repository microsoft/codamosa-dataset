

# Generated at 2022-06-24 17:54:24.521964
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except:
        assert True


# Generated at 2022-06-24 17:54:27.979338
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:54:31.872751
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "A"
    # Creating mock object of the class
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    # Calling the run method with mock object as param
    playbook_c_l_i_0.run()
    # Asserting the results of the run method
    assert playbook_c_l_i_0.run() == None

# end of Class PlaybookCLI

# Generated at 2022-06-24 17:54:34.913684
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)


# Generated at 2022-06-24 17:54:48.048034
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    str_0_0 = "playbook"
    str_0_1 = "--become"
    str_0_2 = "--list-tasks"
    str_0_3 = "--list-tags"
    str_0_4 = "--flush-cache"
    str_0_5 = "--inventory-file"
    str_0_6 = "--connection"
    str_0_7 = "--module-name"
    str_0_8 = "--version"
    str_0_9 = "--verbosity"
    str_0_10 = "--private-key"

# Generated at 2022-06-24 17:54:57.029370
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = ""
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    def side_effect_f_from_args(self):
        return "arg"

    # Mock method
    playbook_c_l_i_0.f_from_args = lambda self: "arg"
    playbook_c_l_i_0.f_from_args.side_effect = side_effect_f_from_args

    def side_effect_post_process_args(self):
        str_0 = ""
        return str_0

    # Mock method
    playbook_c_l_i_0.post_process_args = lambda self: str_0
    playbook_c_l_i_0.post_process_args.side_effect = side_effect_post_process_args

    #

# Generated at 2022-06-24 17:54:58.043626
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:02.060692
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('')
    print(playbook_c_l_i_0.run())


# Generated at 2022-06-24 17:55:08.718465
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        str_0 = "\\e'rb~DU<b{C]~.>Z"
        playbook_c_l_i_0 = PlaybookCLI(str_0)
        playbook_c_l_i_0.run()
    except AnsibleError:
        return 1
    except Exception:
        return 2

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:12.194811
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:55:24.098790
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    result_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:55:29.719295
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_1 = PlaybookCLI("[C'ZBd.]x|#Q")


if __name__ == "__main__":
    print(test_case_0())
    print(test_PlaybookCLI_run())

# Generated at 2022-06-24 17:55:33.771009
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except:
        print('An exception has occurred')

if __name__ == "__main__":

#    test_PlaybookCLI_run()

    parser = PlaybookCLI('s')
    parser.run()

# Generated at 2022-06-24 17:55:37.427387
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    str_1 = "\\e'rb~DU<b{C]~.>Z"
    str_2 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_1, str_2)



# Generated at 2022-06-24 17:55:41.740814
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:43.385652
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    test_case_1()

# Generated at 2022-06-24 17:55:48.236178
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>"
    int_0 = 0
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    result = playbook_c_l_i_0.run()
    assert result == int_0

# Generated at 2022-06-24 17:55:52.643452
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:54.757325
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("\n\nTesting run")
    test_case_0()
    test_PlaybookCLI_run.ow_assert = True

# Generated at 2022-06-24 17:56:05.716520
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """Test id: 5d0b62dd-4f6e-4a4f-af2d-a8e5a1ff7e71"""
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # Call method run of class PlaybookCLI
    result = playbook_c_l_i_0.run()
    assert result == 0

    playbook_c_l_i_0.main()

    class Inventory(object):

        def __init__(self):
            self.hosts = ['foo', 'bar']

    class Options(object):
        listhosts = True

    playbook_c_l_i_0.list_hosts(Inventory(), Options())


# Generated at 2022-06-24 17:56:21.084513
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()
    str_1 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    playbook_c_l_i_1.run()
    str_2 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_2 = PlaybookCLI(str_2)
    playbook_c_l_i_2.run()

# Generated at 2022-06-24 17:56:22.596428
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # test_case_0()
    pass

# Generated at 2022-06-24 17:56:33.337030
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.errors import AnsibleError
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _get_collection_name_from_path
    from ansible.utils.display import Display

    PlaybookCLI.run()

    try:
        PlaybookCLI.run()
    except AnsibleError:
        pass
    except:
        pass
    else:
        print('ExpectedException')

    try:
        PlaybookCLI.run()
    except AnsibleError:
        pass
    except:
        pass
    else:
        print('ExpectedException')

    try:
        PlaybookCLI.run()
    except AnsibleError:
        pass
    except:
        pass
    else:
        print('ExpectedException')



# Generated at 2022-06-24 17:56:39.754830
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        str_0 = "\"<Z&F3qm\""
        playbook_c_l_i_0 = PlaybookCLI(str_0)
        playbook_c_l_i_0.run()
    except (AnsibleError, SystemExit):
        pass
    else:
        throw('AssertionError')



# Generated at 2022-06-24 17:56:46.013840
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    '''
    Unit test for method run of class PlaybookCLI
    '''
    str_1 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 17:56:50.905264
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    try:
        playbook_c_l_i_0.run()
    except:
        pass

# Generated at 2022-06-24 17:56:57.656562
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI.get_option_parser()
    cli = cli.parse_args(["tests/test_playbook.yml"])
    context.CLIARGS = cli
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    return_value_0 = playbook_c_l_i_0.run()
    return return_value_0

# Generated at 2022-06-24 17:56:58.553716
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:01.346102
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    assert playbook_c_l_i_0.run() == 0


# Generated at 2022-06-24 17:57:03.719234
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:22.572193
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "qB~Q7@w8@n:r"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.init_parser()
    var_0 = playbook_c_l_i_0.post_process_args(context.CLIARGS)
    playbook_c_l_i_0.run()
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:57:27.372624
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:57:30.297750
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI("QP]\"SC+s")
    var_0 = playbook_c_l_i_0.init_parser()
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:57:37.395465
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:46.308703
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.init_parser()
    context.CLIARGS = {'listhosts':True, 'listtasks':True, 'listtags':True, 'syntax':False, 'flush_cache':True, 'step':False}
    try:
        var_0 = playbook_c_l_i_0.run()
        assert var_0 == True
    except:
        assert False == True


# Generated at 2022-06-24 17:57:53.495293
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # The class varibles are prefixed with _, thus using the following way to call the class variables
    # playbook_c_l_i_0._display = display

    # Call the run method to see whether raise an exception
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:57:59.169554
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Setup test fixture
    str_2 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_1 = PlaybookCLI(str_2)
    playbook_c_l_i_1.post_process_args(False)
    playbook_c_l_i_1.parse()
    playbook_c_l_i_1.run()

# Generated at 2022-06-24 17:58:00.494241
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    test_case_0()

# Generated at 2022-06-24 17:58:07.110492
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

test_case_0()
test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:14.036570
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.init_parser()
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:50.121833
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:58:53.361792
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()



# Generated at 2022-06-24 17:58:58.217320
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\9JWQ+0$f,6:;*wYsJ"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    print("%d" % var_0)


# Generated at 2022-06-24 17:59:06.330589
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:59:11.902673
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_1 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_1.run()
    assert var_0 == 0


# Generated at 2022-06-24 17:59:15.297023
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    assert playbook_c_l_i_0.run() == 0


# Generated at 2022-06-24 17:59:19.968416
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # No setup needed
    # Step 1 - Creation of the object
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # Step 2 - Call of the run method
    new_var_0 = playbook_c_l_i_0.run()

    # Check that the run method creates an output
    assert new_var_0 in [0, 1]

# Generated at 2022-06-24 17:59:27.306288
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    dict_0 = dict(a=1, b=2, c=3)
    str_1 = "k"
    int_0 = 1
    in_dict_0 = dict_0.get(str_1, int_0)
    if (in_dict_0 != 1):
        return 1
    int_1 = 1
    if (int_1 != 1):
        return 1
    int_2 = 1
    if (int_2 == 1):
        return 0
    int_3 = 1
    for in_int_0 in range(int_3):
        int_4 = 1

# Generated at 2022-06-24 17:59:31.020950
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    str_1 = 'b'
    var_0 = playbook_c_l_i_0.post_process_args(str_1)
    var_1 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:33.597231
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:00:14.119413
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        str_0 = "\\e'rb~DU<b{C]~.>Z"
        str_1 = "name=arg1,arg2"
        str_2 = "\\e'rb~DU<b{C]~.>Z"
        str_3 = "name=arg1,arg2"
        playbook_c_l_i = PlaybookCLI(str_0, str_1, str_2, str_3)
        var_0 = playbook_c_l_i.run()
        assert var_0 == None
    except Exception as exception:
        print("Error: " + str(exception))


# Generated at 2022-06-24 18:00:16.878686
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pb = PlaybookCLI('dummy')
    pb.run()


# Generated at 2022-06-24 18:00:23.693492
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.init_parser()
    var_1 = playbook_c_l_i_0.parse()
    var_2 = playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:00:27.322540
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: Make this test work
    exit_code = PlaybookCLI.run()
    assert exit_code == 0

# Generated at 2022-06-24 18:00:30.249008
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.init_parser()
    var_1 = playbook_c_l_i_0.run()

# Unit Test

# Generated at 2022-06-24 18:00:41.044403
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    argv_0 = ('ansible-playbook', '-i', './tests/inventory', './tests/test_cases/ansible-playbook/test_case_0.yml')
    try:
        with open('./tests/test_cases/ansible-playbook/test_case_0.ret') as f:
            ret = int.from_bytes(f.read(), byteorder='big')
    except Exception as e:
        print(e)
        ret = 255
    with open('./tests/test_cases/ansible-playbook/test_case_0.out', 'w') as output_file:
        with open('./tests/test_cases/ansible-playbook/test_case_0.err', 'w') as error_file:
            ansible_playbook_2_9_

# Generated at 2022-06-24 18:00:41.760084
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-24 18:00:50.499607
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    os.environ['ANSIBLE_VAULT_PASSWORD_FILE'] = 'ansible_vault_password_file_value'
    # Check invocation of __main__.PlaybookCLI.run with valid parameters
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    del os.environ['ANSIBLE_VAULT_PASSWORD_FILE']


# Generated at 2022-06-24 18:00:59.253681
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "x}gG'\\Rl1ZT'\"tTf<"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.init_parser()
    playbook_c_l_i_0.parse()
    var_0 = playbook_c_l_i_0.post_process_args(context.CLIARGS)
    var_1 = playbook_c_l_i_0.run()
    print('\ntest_case_0: Unit test for method run of class PlaybookCLI')
    print('DONE')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:01:02.604808
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    result = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:01:52.314042
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:01:55.166221
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 is None

# Generated at 2022-06-24 18:01:55.828355
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:01.155248
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:02:04.086215
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    test_case_0()

    print("\nTests complete\n")

    return 0

if __name__ == '__main__':
    sys.exit(test_PlaybookCLI_run())

# Generated at 2022-06-24 18:02:09.284306
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create a new PlaybookCLI object and test method run of it
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:02:13.893750
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:02:18.540912
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_1 = PlaybookCLI(str_0)
    playbook_c_l_i_1.run()


if __name__ == "__main__":
    import sys
    import logging
    import pytest

    logger = logging.getLogger()
    logger.level = logging.INFO
    logger.addHandler(logging.StreamHandler(sys.stdout))
    pytest.main('-n 0 test_ansible.py')

# Generated at 2022-06-24 18:02:31.088214
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    #
    # Python 3.7
    #
    str_0 = "\\c\\ro\\l\\le\\g\\t\\i\\o\\n\\w\\ar\\n\\e\\r\\o\\u\\t\\p\\u\\t"

# Generated at 2022-06-24 18:02:41.240493
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "\\e'rb~DU<b{C]~.>Z"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.parse()
    var_1 = playbook_c_l_i_0.post_process_args(var_0)
    var_2 = playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:04:11.413710
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # set up arguments used by the ansible-playbook command line.
    # create parser for CLI options
    parser = CLI.base_parser(constants.DEFAULT_MODULE_PATH, constants.DEFAULT_MODULE_NAME,
                             constants.DEFAULT_MODULE_PATH, 'network_cli')
    opt_help.add_vault_options(parser)
    opt_help.add_meta_options(parser)
    opt_help.add_runas_options(parser)
    opt_help.add_runtask_options(parser)
    opt_help.add_subset_options(parser)
    opt_help.add_check_options(parser)
    opt_help.add_inventory_options(parser)
    opt_help.add_fork_options(parser)
    opt_help.add_module