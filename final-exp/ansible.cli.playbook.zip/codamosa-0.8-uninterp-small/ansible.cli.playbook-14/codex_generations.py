

# Generated at 2022-06-24 17:54:27.377101
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:54:33.685900
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    complex_2 = None
    playbook_c_l_i_2 = PlaybookCLI(complex_2)
    # Test playbook_c_l_i_2.run() with keyword arguments
    # Execute playbook_c_l_i_2.run() with keyword arguments
    test_PlaybookCLI_run_kwargs_0(playbook_c_l_i_2)
    # Execute playbook_c_l_i_2.run() with keyword arguments
    test_PlaybookCLI_run_kwargs_1(playbook_c_l_i_2)
    # Execute playbook_c_l_i_2.run() with keyword arguments
    test_PlaybookCLI_run_kwargs_2(playbook_c_l_i_2)
    # Execute playbook_c_l_i

# Generated at 2022-06-24 17:54:35.213980
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playObj = PlaybookCLI()
    playObj.init_parser()
    playObj.run()

# Generated at 2022-06-24 17:54:36.073968
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:54:38.424232
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    complex_1 = None
    playbook_c_l_i_1 = PlaybookCLI(complex_1)
    assert playbook_c_l_i_1.run() == 0

# Generated at 2022-06-24 17:54:41.571571
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    complex_0 = None
    playbook_c_l_i_0 = PlaybookCLI(complex_0)
    result = playbook_c_l_i_0.run()
    assert result == 0

# Generated at 2022-06-24 17:54:46.013356
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    complex_0 = None
    playbook_c_l_i_0 = PlaybookCLI(complex_0)
    r = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:54:48.999159
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    complex_0 = None
    playbook_c_l_i_0 = PlaybookCLI(complex_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:54:58.139745
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:55:02.693297
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    complex_1 = None
    playbook_c_l_i_1 = PlaybookCLI(complex_1)

    # Validate arguments
    assert playbook_c_l_i_1.run()



# Generated at 2022-06-24 17:55:13.296863
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    complex_0 = None
    playbook_c_l_i_0 = PlaybookCLI(complex_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:20.557224
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    complex_0 = None
    playbook_c_l_i_0 = PlaybookCLI(complex_0)

    with pytest.raises(AnsibleError) as excinfo:
        playbook_c_l_i_0.run()
    assert 'the playbook: none could not be found' in str(excinfo.value)


# Generated at 2022-06-24 17:55:23.191676
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # PlaybookCLI.run()

    # TODO: Unit test
    pass

# Generated at 2022-06-24 17:55:28.457326
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    complex_0 = None
    playbook_c_l_i_0 = PlaybookCLI(complex_0)
    playbook_c_l_i_0.run()
    assert playbook_c_l_i_0.run() == 0

# Generated at 2022-06-24 17:55:32.460542
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test for raising exception when input argument is invalid
    with pytest.raises(AnsibleError):
        complex_0 = None
        playbook_c_l_i_0 = PlaybookCLI(complex_0)


# Generated at 2022-06-24 17:55:33.345826
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:38.744727
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create an object of class PlaybookCLI
    complex_playbook_cli = PlaybookCLI()
    # Try to run the method run and see if it runs without errors
    try:
        complex_playbook_cli.run()
    except Exception:
        raise AssertionError("PlaybookCLI: 'run' method test failed")
    else:
        print("PlaybookCLI: 'run' method test passed")

# Test the class PlaybookCLI
if __name__ == "__main__":
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:44.810839
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-24 17:55:45.545192
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:49.318227
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI(None)
    ret = playbook_cli.run()

    assert ret == 0, "play returns wrong value"

# Generated at 2022-06-24 17:56:01.622228
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:56:02.830664
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:04.112090
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:06.828249
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'wzH:8 N_u'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:10.441151
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as err:
        print('Failure: test_PlaybookCLI_run() raise exception: ' + str(err))
        raise

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:56:11.532813
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:13.550422
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:16.605706
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:18.093087
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:20.464689
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:49.276161
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Setup for test case 0
    test_case_0()

# Generated at 2022-06-24 17:56:50.699283
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:54.890263
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '4vf`W:D'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Entry point for testing this file

# Generated at 2022-06-24 17:56:56.648918
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:00.111899
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '@8>H0a"h'
    PlaybookCLI_0 = PlaybookCLI(str_0)
    PlaybookCLI_0.run()
    try:
        assert True
    except AssertionError as e:
        print("TEST 1 FAILED")


# Generated at 2022-06-24 17:57:03.588280
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cmd = 'wzH:8 N_u' # test with label
    p = PlaybookCLI(cmd)
    r = p.run()
    assert r == 0

# Generated at 2022-06-24 17:57:07.510911
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = ' _S:i:uV'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:57:09.602231
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:13.791448
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'yX7|L/I'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    str_1 = 'a,W8pv'
    var_0 = playbook_c_l_i_0.run(str_1)


# Generated at 2022-06-24 17:57:16.937232
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except:
        raise AssertionError('test_PlaybookCLI_run unit test failed')

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:49.267508
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    pass

# Generated at 2022-06-24 17:57:50.507667
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:57:52.274936
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:53.420722
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:01.145200
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    array_0 = ['wzH:8 N_u']
    array_0.append('vCX|')
    array_0.append('4ZO|')
    array_0.append('JW`{')
    array_0.append('JW`{')
    array_0.append('o`e[? ')
    array_0.append('nB+d#')
    array_0.append('nB+d#')
    str_0 = 'wzH:8 N_u'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:58:06.406220
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = 'wzH:8 N_u'
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    var_1 = playbook_c_l_i_1.run()

    # standard check for unit test
    assert var_1 == 0, "run method of PlaybookCLI class did not return 0 as expected"


# Generated at 2022-06-24 17:58:07.532929
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:09.054105
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    o_0 = PlaybookCLI('dNr')
    o_0.run()

# Generated at 2022-06-24 17:58:10.992873
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:11.950168
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 17:58:40.432315
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:42.123088
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:43.720642
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:58:46.297942
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:58:56.044386
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create base objects
    #loader, inventory, variable_manager = self._play_prereqs()

    # (which is not returned in list_hosts()) is taken into account for
    # warning if inventory is empty.  But it can't be taken into account for
    # checking if limit doesn't match any hosts.  Instead we don't worry about
    # limit if only implicit localhost was in inventory to start with.
    #
    # Fix this when we rewrite inventory by making localhost a real host (and thus show up in list_hosts())
    #CLI.get_host_list(inventory, context.CLIARGS['subset'])
    str_0 = '/root/work/ansible/myhosts'
    obj_0 = Inventory(str_0)

# Generated at 2022-06-24 17:58:58.394717
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# End of testing run method of class PlaybookCLI


# Generated at 2022-06-24 17:59:02.777862
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'wzH:8 N_u'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:04.608106
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as exp:
        print("Error during unit test method run of class PlaybookCLI")
        raise exp


# Generated at 2022-06-24 17:59:07.063270
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'wzH:8 N_u'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:12.415518
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'wzH:8 N_u'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 18:00:11.609843
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:00:12.726163
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:15.103523
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 18:00:17.878834
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    command = 'wzH:8 N_u'
    playbook_c_l_i_1 = PlaybookCLI(command)
    var_1 = playbook_c_l_i_1.run()

# We don't have a real test case for this function because it gets
# called in the setUp for test_case_0.

# Generated at 2022-06-24 18:00:20.074842
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('test_PlaybookCLI_run')
    test_case_0()

# Generated at 2022-06-24 18:00:20.924754
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:21.758419
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:22.819550
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# vim: set et st=4 sw=4 :

# Generated at 2022-06-24 18:00:26.318230
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:27.698472
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # FIXME:
    # test_case_0()
    pass

# Generated at 2022-06-24 18:01:43.604680
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:52.173818
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'wzH:8 N_u'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0, "PlaybookCLI.run() == 0"


# Generated at 2022-06-24 18:01:53.647539
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test for the method run of class PlaybookCLI
    test_case_0()


# Generated at 2022-06-24 18:01:54.435302
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:59.962758
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'wzH:8 N_u'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

test_case_0()

# Generated at 2022-06-24 18:02:01.342913
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:04.429716
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'PGM'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0

# Generated at 2022-06-24 18:02:05.297247
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:07.789589
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
	test_case_0()

if __name__ == '__main__':
	test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:11.702545
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:24.769173
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:25.651612
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:26.806974
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:27.844256
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:28.936762
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:30.523882
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()  # test case 0



# Generated at 2022-06-24 18:03:31.972963
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:33.043487
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:34.813082
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:03:38.085789
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'wzH:8 N_u'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()