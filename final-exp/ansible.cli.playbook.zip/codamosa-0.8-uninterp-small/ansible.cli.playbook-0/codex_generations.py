

# Generated at 2022-06-24 17:54:29.518120
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_run = PlaybookCLI.run()

# Generated at 2022-06-24 17:54:30.901872
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':

    # Run tests
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:34.120383
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0.run(str_0)

# Generated at 2022-06-24 17:54:40.307665
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:54:43.497270
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Unit test for method run of class PlaybookCLI
    assert True is True


# Generated at 2022-06-24 17:54:52.589150
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_params = ('BehiUf\txX}}|yrX(L',)
    return_value_1 = None
    return_value_2 = None
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    try:
        playbook_c_l_i_0.run()
    except Exception as e_1:
        return_value_2 = e_1
    assert return_value_2 is None


# Generated at 2022-06-24 17:54:54.249115
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.executor import task_queue_manager

    # FIXME: Replace with a real test
    pass

# Generated at 2022-06-24 17:54:59.606703
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    arg_0 = object()
    arg_1 = object()
    arg_2 = object()
    arg_3 = object()
    arg_4 = object()
    arg_5 = object()
    arg_6 = object()
    arg_7 = object()
    arg_8 = object()
    arg_9 = object()
    arg_10 = object()
    arg_11 = object()
    arg_12 = object()
    arg_13 = object()
    arg_14 = object()
    arg_15 = object()
    arg_16 = object()
    arg_17 = object()
    arg_18 = object()
    arg_19 = object()
    arg_20 = object()
    arg_21 = object()
    arg_22 = object()
    arg_23 = object()
    arg_24 = object()

# Generated at 2022-06-24 17:55:03.975436
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    test_case_0()

# Generated at 2022-06-24 17:55:05.872679
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:20.786023
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert PlaybookCLI.run(PlaybookCLI('the_string')) == 0
    assert PlaybookCLI.run(PlaybookCLI('the_string')) == 0

# Generated at 2022-06-24 17:55:22.840965
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:24.341224
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Unit test: test_case_0
    test_case_0()

# Generated at 2022-06-24 17:55:29.409226
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:32.417186
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test case 0
    test_case_0()


# Run unit tests
if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 17:55:33.115758
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:35.084458
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:39.177866
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI("[")
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:46.037480
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except(AnsibleError) as e:
        print("AnsibleError message: ")
        print(e.message)
        print("AnsibleError current_namespace: ")
        print(e.current_namespace)
        print("AnsibleError current_path: ")
        print(e.current_path)
        print("AnsibleError entry: ")
        print(e.entry)
    except(Exception) as e:
        print("Exception message: ")
        print(e.message)

# Generated at 2022-06-24 17:55:54.672023
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = ''
    try:
        test_case_0()
    except Exception as ex:
        var_0 = ex
    # print str(var_0)

    # Run class PlaybookCLI
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_1 = playbook_c_l_i_0.run()


if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:08.878842
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass


# Generated at 2022-06-24 17:56:09.858654
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:14.471751
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


if __name__ == '__main__':
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:17.078912
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:21.712011
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:22.956743
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass


# Generated at 2022-06-24 17:56:28.972718
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("test_PlaybookCLI_run")
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert isinstance(var_0, int)
    assert var_0 == 0


# Generated at 2022-06-24 17:56:31.790429
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except NameError as err:
        print('NameError: The variable test_case_0 is not defined')
    except UnboundLocalError as err:
        print('UnboundLocalError: Local variable \'test_case_0\' referenced before assignment')

# Generated at 2022-06-24 17:56:33.135865
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:37.312980
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    # place your unit test code here
    #
    # if __name__ == '__main__':
    #     unittest.main()

# Generated at 2022-06-24 17:57:15.771499
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager as PlaybookExecutor
    # Instantiate object PlaybookCLI
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    # Instantiate object Play
    str_1 = 'Y`qJjK_lU\x00\x1a\x1a\x17{y\n\x19z\x1a\x1c\x1c\x10\x1a\x1b\x1b\x1b'
    ansible_play_0 = Play(str_1)
    ansible_play_0.hosts = str_1
    # Instantiate object

# Generated at 2022-06-24 17:57:19.736897
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'C4LIH'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:57:24.860875
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    var_1 = playbook_c_l_i_1.run()


# Generated at 2022-06-24 17:57:26.092933
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:57:28.532512
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:57:31.791787
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:57:33.102822
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:38.829201
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-24 17:57:41.059200
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    return True

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:44.378482
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
        assert True
    except AssertionError as e:
        print(e)
        assert False
    return 0


##################################
#   Setup and Teardown Methods   #
##################################


# Generated at 2022-06-24 17:58:14.622618
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Test type of 'int' (line 933)
    assert isinstance(playbook_c_l_i_0.run(), int)


if __name__ == "__main__":
    import pytest
    pytest.main('-v')

# Generated at 2022-06-24 17:58:15.895005
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:17.083871
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:21.123715
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:58:25.608712
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '9lWc%R'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    if var_0 == 0:
        print('CORRECT')
    else:
        print('INCORRECT')


# Generated at 2022-06-24 17:58:28.951402
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '2S\x0c\x15\x19\x16\x1b\x1b\x1b'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:58:41.277348
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # setup the test
    test_dir = os.path.dirname(os.path.dirname(__file__))
    test_data_dir = os.path.join(test_dir, "testdata")
    test_module_dir = os.path.join(test_dir, "..", "..", "lib", "ansible", "modules")
    ansible_config_file = os.path.join(test_data_dir, "ansible.cfg")

    original_ansible_config = os.environ.get("ANSIBLE_CONFIG")
    original_ansible_module_utils = os.environ.get("ANSIBLE_MODULE_UTILS")

    os.environ["ANSIBLE_CONFIG"] = ansible_config_file
    os.environ["ANSIBLE_MODULE_UTILS"] = test

# Generated at 2022-06-24 17:58:42.662962
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:45.406594
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test cases
    test_case_0()


# Testing method ask_passwords from class PlaybookCLI

# Generated at 2022-06-24 17:58:49.563424
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:24.874752
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #test_case_0()
    #playbook_cli = PlaybookCLI('Have Fun')
    playbook_cli = PlaybookCLI('BehiUf\txX}}|yrX(L')
    playbook_cli.run()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:26.575082
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # From Ansible
    # case 0: nothing

    test_case_0()

# Generated at 2022-06-24 17:59:28.529735
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert True == True

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:34.922753
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from mock import Mock, patch

    class AnsibleUndisplayMock(object):
        verbosity = 3
        display = Mock()
        display.display = Mock(return_value=None)
        display.verbosity = verbosity
        default = display
        
    def run_wrapper(self):
        self.args = 'ansible-playbook --version'.split()
        self.exit_without_ignore = True
        with patch('ansible.cli.display.Display', AnsibleUndisplayMock):
            self.run()

    self = PlaybookCLI('ansible-playbook --version')
    run_wrapper(self)

# Main

# Generated at 2022-06-24 17:59:36.232968
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:40.010238
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:41.640847
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
# Testing 'PlaybookCLI.run'

# Generated at 2022-06-24 17:59:44.008875
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:45.095770
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:51.140607
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:00:22.114657
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'test'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:00:26.857145
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert True

# Test case for method init_parser of class PlaybookCLI

# Generated at 2022-06-24 18:00:28.920282
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()



# Generated at 2022-06-24 18:00:29.992321
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:00:39.481892
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    import sys
    from unittest import mock

    args = 'ansible-playbook -v playbook.yaml'
    sys.argv = args.split()

    with mock.patch.object(PlaybookCLI, 'ask_vault_passwords'):
        with mock.patch.object(PlaybookCLI, '_play_prereqs') as m_play_prereqs:
            with mock.patch.object(PlaybookExecutor, 'run') as m_playbook_executor:
                m_play_prereqs.return_value = (None, None, None)
                m_playbook_executor.return_value = 0
                test_case_0()

# Generated at 2022-06-24 18:00:41.910418
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("\n\n** test_PlaybookCLI_run **\n\n")
    test_case_0()

#test_PlaybookCLI_run()

# Generated at 2022-06-24 18:00:46.312238
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:00:51.952232
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    try:
        var_0 = playbook_c_l_i_0.run()
    except Exception:
        var_0 = False

    assert var_0 == False


# Generated at 2022-06-24 18:00:52.971796
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:00:56.275165
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    arg_0 = 'BehiUf\txX}}|yrX(L'
    aid_0 = PlaybookCLI(arg_0)
    aid_0.run()

# Generated at 2022-06-24 18:01:36.670392
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:37.932256
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:40.126692
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'C8Qk\tZh'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    int_0 = playbook_c_l_i_0.run()
    assert int_0 != 0

# Generated at 2022-06-24 18:01:41.004922
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:43.503562
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:01:46.736220
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:01:48.223090
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:50.640197
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    run_0 = 'ztPPM\xC3'
    test_case_0(run_0)

# Generated at 2022-06-24 18:01:53.295619
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Test using pytest outside the ansible-test framework
if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 18:01:55.429402
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('Testing run')
    test_case_0()

if __name__ == '__main__':
    # begin testing
    print('Testing the module')
    # test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:36.166531
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:02:37.490023
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:02:38.781809
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:41.006683
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:42.440563
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI()
    playbook_cli.run()

# Generated at 2022-06-24 18:02:43.824300
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()   # test case 1
    # add your test cases here



# Generated at 2022-06-24 18:02:49.561366
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:50.666310
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:56.722527
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '!\x0f\x0e\x0f\x13\x1f\x1c\x02\x10\x10\x05'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    print(var_0)


# Generated at 2022-06-24 18:02:58.402606
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('play_prereqs')
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:03:37.243729
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:38.435969
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:41.265581
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'HHdS6jv]IJ:eTm,;{iX.'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:03:42.100928
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:45.088396
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    return var_0


# Generated at 2022-06-24 18:03:50.448408
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'BehiUf\txX}}|yrX(L'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    # Verify type
    assert type(var_0) == int


# Generated at 2022-06-24 18:03:52.924146
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:04:04.458897
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    var_1 = 'C]c%a8}1q\x7f5g\\'
    var_2 = 'd\x7f7A&hL\tyQ8'
    playbook_c_l_i_1 = PlaybookCLI(var_1)
    var_3 = playbook_c_l_i_1.run()
    playbook_c_l_i_2 = PlaybookCLI(var_2)
    var_4 = playbook_c_l_i_2.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:04:05.507818
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:04:09.140446
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    for case_name in dir():
        if case_name.startswith('test_'):
            print(case_name)
            case_func = globals()[case_name]
            case_func()