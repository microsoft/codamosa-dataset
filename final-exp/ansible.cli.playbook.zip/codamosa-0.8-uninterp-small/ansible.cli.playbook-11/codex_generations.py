

# Generated at 2022-06-24 17:54:33.924952
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # We can use __main__.PlaybookCLI to approximate its usage.
    # We want to make sure it exists, is callable and equals PlaybookCLI.
    assert PlaybookCLI is getattr(__main__, 'PlaybookCLI', None)
    assert callable(PlaybookCLI)
    # Unit test Passes if run() is callable
    assert callable(PlaybookCLI.run)


# Generated at 2022-06-24 17:54:36.015959
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # pbex = PlaybookExecutor(playbooks=[], inventory=None, variable_manager=None, loader=None, passwords=None)
    # loader, inventory, variable_manager = PlaybookCLI._play_prereqs()
    # pbex.run()
    pass



# Generated at 2022-06-24 17:54:46.601228
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Define objects and variables
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    list_1 = [bool_0, bool_0]
    # Define methods
    def function_0(self_0, self_1):
        pass
    # Assign objects to variables
    var_0 = function_0
    var_1 = PlaybookCLI(list_0, list_0)
    # Call methods
    var_0(var_1, list_1)

# Generated at 2022-06-24 17:54:56.586646
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli_args_0 = ['./ansible', 'local', '-m', 'setup', './hosts']
    cli_args_1 = ['./ansible-playbook', './ansible-tmp/ansible-tmp6Udm33', '-i', './hosts', '-e', 'parsed=true', '--extra-vars', 'ansible_ssh_user=vagrant', 'ansible_ssh_pass=vagrant', 'ansible_sudo_pass=vagrant']
    cli_args_2 = ['./ansible-playbook', './test/test-ansible-playbook.yml', '-i', './hosts']

# Generated at 2022-06-24 17:55:03.517143
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    list_0 = [0, 0, 0, 0, 0]
    list_1 = [0, 0, 0, 0, 0]
    subset_0 = 0
    int_0 = 0
    list_2 = [0, 0, 0, 0, 0]
    list_3 = [0, 0, 0, 0, 0]
    bool_0 = False
    list_4 = [0, 0, 0, 0, 0]
    bool_1 = False
    list_5 = [0, 0, 0, 0, 0]
    bool_2 = False
    list_6 = [0, 0, 0, 0, 0]
    list_7 = [0, 0, 0, 0, 0]
    list_8 = [0, 0, 0, 0, 0]

# Generated at 2022-06-24 17:55:10.207001
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.errors import AnsibleError
    from ansible.cli import CLI
    import sys
    
    options = {}
    
    setattr(options, 'listhosts', False)
    setattr(options, 'listtasks', False)
    setattr(options, 'listtags', False)
    setattr(options, 'syntax', False)
    setattr(options, 'host_list', None)

# Generated at 2022-06-24 17:55:17.401469
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = False
    list_0 = []
    list_1 = [bool_0]
    list_2 = [list_1, list_1]
    list_3 = list_2[0]
    list_4 = list_2[1]
    list_5 = []
    list_6 = []
    list_7 = list_6
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict(**dict_3, **dict_2)
    dict_5 = dict()
    dict_6 = dict(**dict_5, **dict_4)
    dict_7 = dict()
    dict_8 = dict(**dict_7, **dict_6)
    list_8 = ['sshpass']


# Generated at 2022-06-24 17:55:26.418238
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()



# Generated at 2022-06-24 17:55:31.066624
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Initialization
    list_0 = []
    list_1 = []
    playbook_c_l_i_0 = PlaybookCLI(list_0, list_1)
    # Invocation
    result = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:55:35.166916
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    list_0 = [False, False, False, False]
    list_1 = [None, 'arg', False, False]
    playbook_c_l_i_0 = PlaybookCLI(list_0, list_1)
    int_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:50.328896
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    test_case_0()

# Generated at 2022-06-24 17:55:51.730886
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:52.649599
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test for when set_basedir raise exception
    pass

# Generated at 2022-06-24 17:55:53.676861
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:54.607658
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:56.702063
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
# SUT for calling static method static_func of class MyClass

# Generated at 2022-06-24 17:56:03.199247
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()



if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:05.089571
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('test_PlaybookCLI_run')
    test_case_0()

# Generated at 2022-06-24 17:56:08.129604
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:16.066213
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13\x04\xf8@\x86\n\xe5\xba\x18\x8a\x1c\xec\x90\x94'
    var_0 = PlaybookCLI(bytes_0)
    var_1 = var_0.run()
    assert var_1 == 0
    bytes_1 = b'\x13'
    var_2 = PlaybookCLI(bytes_1)
    var_3 = var_2.run()
    assert var_3 == 0
    bytes_2 = b'\x13\x04\xf8@\x86\n\xe5\xba\x18\x8a\x1c\xec\x90\x92'
    var_4 = PlaybookCLI(bytes_2)
    var

# Generated at 2022-06-24 17:56:39.858027
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:44.660601
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:47.908391
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:52.750402
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test 1
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


if __name__ == '__main__':
    test_PlaybookCLI_run()
    # test_case_0()

# Generated at 2022-06-24 17:56:56.446414
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:56:57.356845
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:05.099123
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    try:
        var_0 = playbook_c_l_i_0.run()
    except Exception as e:
        print("unexpected exception: ", str(e))


# Generated at 2022-06-24 17:57:15.834326
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys
    import os
    import tempfile

    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play import Play
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    sys.argv = [sys.argv[0], 'playbook.yml']
    variables = {}

# Generated at 2022-06-24 17:57:17.728232
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    pass



# Generated at 2022-06-24 17:57:29.617973
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


# Start test
if __name__ == '__main__':
    # For test coverage
    test_case_0()

    # For profiling
    import cProfile
    import pstats

    profile_filename = 'test_PlaybookCLI_profile.txt'
    cProfile.run('test_PlaybookCLI_run()', profile_filename)
    statsfile = open("profile_stats.txt", "wb")
    p = pstats.Stats(profile_filename, stream=statsfile)
    stats = p.strip_dirs().sort_stats('cumulative')
    stats.print_stats()

# Generated at 2022-06-24 17:57:58.117035
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()

test_case_0()
test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:04.363737
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:58:07.583250
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except exception as e:
        assert False, "Failed to run unit test for PlaybookCLI method run."
    else:
        assert True

# Generated at 2022-06-24 17:58:08.270115
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:58:13.551022
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_2 = b'\x13'
    playbook_c_l_i_2 = PlaybookCLI(bytes_2)
    playbook_c_l_i_2.run()


if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()
    sys.exit(0)

# Generated at 2022-06-24 17:58:14.698592
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:19.657526
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x12'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:58:20.951331
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:21.982630
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:25.608859
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x22'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    playbook_c_l_i_0.run()

# unit tests for the main method

# Generated at 2022-06-24 17:59:28.485708
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:31.575103
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\r'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:33.945069
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        test_case_0()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

# Generated at 2022-06-24 17:59:38.423805
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # FIXME: Fix this test
    return
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:43.430875
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_1 = b'\x13'
    playbook_c_l_i_1 = PlaybookCLI(bytes_1)
    try:
        playbook_c_l_i_1.run()
    except SystemExit as e:
        if e.code == None:
            raise Exception('SystemExit expected')


# Generated at 2022-06-24 17:59:55.276176
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test for listtasks

    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()
    # Test for listtags

    bytes_1 = b'\xf6'
    playbook_c_l_i_1 = PlaybookCLI(bytes_1)
    var_1 = playbook_c_l_i_1.run()

    # Test for step

    bytes_2 = b'\xa7'
    playbook_c_l_i_2 = PlaybookCLI(bytes_2)
    var_2 = playbook_c_l_i_2.run()

    # Test for start_at_task

    bytes_3 = b'Z'
    playbook_c_

# Generated at 2022-06-24 17:59:56.765156
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:59.568315
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert test_case_0() == 0


if __name__ == "__main__":
    print("Running tests ...")
    result = test_PlaybookCLI_run()
    print(result)

# Generated at 2022-06-24 18:00:02.009366
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    assert isinstance(playbook_c_l_i_0.run(), int)

# Generated at 2022-06-24 18:00:03.228529
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    test_case_1()

# Generated at 2022-06-24 18:02:29.831522
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:02:32.663275
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:02:37.622006
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:02:42.137261
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()
    assert(var_0 == 0)


# Generated at 2022-06-24 18:02:44.402606
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:02:49.559710
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_PlaybookCLI_run_0()
    test_PlaybookCLI_run_1()


# Generated at 2022-06-24 18:02:51.498854
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:55.289466
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('')
    print('*** Running tests ***')
    print('')
    print('test_case_0()')
    test_case_0()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:59.076315
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:03:00.122357
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()