

# Generated at 2022-06-24 17:54:27.485617
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:30.050633
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 2.26599113
    test_PlaybookCLI_run_0(float_0)

# Function test_PlaybookCLI_run_0 ensures that the following statements
# are true :
#

# Generated at 2022-06-24 17:54:32.346536
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 1480.922559
    playbook_c_l_i_0 = PlaybookCLI(float_0)

    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:54:35.030679
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 1480.922559
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    file_0 = open('/dev/null', 'w')
    with redirect_stdout(file_0):
        playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:54:37.908236
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Initialize necessary objects for PlaybookCLI run method
    PlaybookCLI.run()


# Generated at 2022-06-24 17:54:46.473465
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cmd = ['ansible-playbook', '-i', 'localhost,', 'playbook.yml']
    display.verbosity = 2
    pbex = PlaybookExecutor(playbooks=['test/integration/cli/playbooks/test_playbook.yml'], inventory=None, 
                            variable_manager=None, loader=None, options=None, passwords={})
    test_case_0()
    
if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:49.834778
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 1480.922559
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:54:53.178275
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Prepare test
    float_0 = 1480.922559
    playbook_c_l_i_0 = PlaybookCLI(float_0)

    # Invoke method
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:54:56.545963
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 1480.922559
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    try:
        playbook_c_l_i_0.run()
    except SystemExit:
        pass
    except Exception:
        pass

# Generated at 2022-06-24 17:55:00.012034
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Arguments:
    #   self: instance of class PlaybookCLI
    # Returns:
    #   -
    # Raises:
    #   None
    int_0 = 1480
    playbook_c_l_i_0 = PlaybookCLI(int_0)
    playbook_c_l_i_0.run() # exception expected

# Generated at 2022-06-24 17:55:13.578028
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("[+] test for method run of class PlaybookCLI ")

    # Set up object
    pb = PlaybookCLI()
    pb.init_parser()
    pb.parser.parse_args('-i inventory play.yml'.split())
    pb.parser = pb.post_process_args(pb.parser)

    # Test execution
    try:
        pb.run()
    except SystemExit as e:
        assert(e.code == 0)

# Generated at 2022-06-24 17:55:26.197919
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # test_case_0

    # test_case_1
    from ansible import constants
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.vars.manager import VariableManager

    ansible.constants.HOST_KEY_CHECKING = False
    check = True

# Generated at 2022-06-24 17:55:27.529737
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pb = PlaybookCLI()


# Generated at 2022-06-24 17:55:29.827599
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    foo = PlaybookCLI()

    print("# Test case 0")
    test_case_0()

# Generated at 2022-06-24 17:55:30.862018
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:55:33.982695
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # input args
    args = '--list-hosts [playbook.yml]'
    cli = PlaybookCLI(args)
    cli.parse()
    cli.run()


# Generated at 2022-06-24 17:55:39.540571
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI.__new__(PlaybookCLI)

    # test case 0
    args = ['arg_0', 'arg_1', 'arg_2', 'arg_3', 'arg_4', 'arg_5']
    opts = {'arg_0': 'arg_0', 'arg_1': 'arg_1', 'arg_2': 'arg_2', 'arg_3': 'arg_3', 'arg_4': 'arg_4', 'arg_5': 'arg_5'}
    cli.run(args, opts)

    # test case 1
    args = ['arg_0', 'arg_1', 'arg_2', 'arg_3', 'arg_4', 'arg_5']

# Generated at 2022-06-24 17:55:45.513318
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # test_case_0()
    # Init an object of class PlaybookCLI
    playbook_cli = PlaybookCLI()
    # init parser
    playbook_cli.init_parser()
    # Init options
    options = opt_help.create_default_options()
    # post process args
    options = playbook_cli.post_process_args(options)
    # run
    result = playbook_cli.run()
    # Verify result
    assert result == 0

# Generated at 2022-06-24 17:55:57.115611
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    if False:
        # Line.py:861
        # 'Mock' object
        class Mock():
            def __init__(self):
                self.__args = list()
            def __call__(self, *args, **kwargs):
                self.__args.append((args, kwargs))
                return 'Mock'
            def args(self):
                return self.__args

        # mock class builder
        def mock_class(class_name, class_parents, class_attrs):
            class MockClass(class_parents[0]):
                def __init__(self, *args, **kwargs):
                    class_parents[0].__init__(self, *args, **kwargs)
                    for key, value in class_attrs.items():
                        if value == 'Mock':
                            set

# Generated at 2022-06-24 17:55:59.751551
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:56:09.191252
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    test_case_0()

# Generated at 2022-06-24 17:56:12.681355
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    var_0 = PlaybookCLI()
    var_0.init_parser()
    var_1 = var_0.post_process_args({})
    var_2 = var_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:14.049655
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:20.092519
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/usr/local/bin/ansible'
    str_1 = '-i'
    str_2 = 'None'
    str_3 = '--syntax-check'
    str_4 = 'test_case/test_file_0.yml'
    arg_0 = os.getcwd()
    arg_0 = arg_0 + "/test_case/test_file_0.yml"
    sys.argv[1:] = [str_0, str_1, str_2, str_3, str_4]
    test_case_0()
    sys.argv[1:] = [str_0, str_1, str_2, str_3, arg_0]


# Generated at 2022-06-24 17:56:21.039980
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:22.539245
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    run_test_cases()


# Generated at 2022-06-24 17:56:25.545500
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    var_0 = PlaybookCLI('/usr/platform/')
    var_1 = var_0.run()


if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:27.066113
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    global test_case_0
    test_case_0()

# Generated at 2022-06-24 17:56:28.473016
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:31.680898
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Initialization of the test
    str_0 = '/usr/platform/'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    # Execution of the test
    var_0 = playbook_c_l_i_0.run()
    

# Generated at 2022-06-24 17:56:59.146961
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/usr/platform/'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:57:00.535214
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("test run")
    # assert(PlaybookCLI.run('/usr/platform/'))

# Generated at 2022-06-24 17:57:03.391315
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Read test case from file
    test_file = open("test0.txt", "r")
    test_case = test_file.read()
    test_file.close()

    new_test_case = test_case.replace("\n", ";")

    os.system(new_test_case)
    test_case_0()

# Generated at 2022-06-24 17:57:05.881858
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:07.273957
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:09.528691
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # pytest.param(var_0, 0)
    pytest.param(0, 0)

# Generated at 2022-06-24 17:57:12.089140
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("Testing run of class PlaybookCLI")
    test_case_0()

#  LocalWords:  run listhosts listtasks listtags verbosity runtask opts

# Generated at 2022-06-24 17:57:13.324704
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:14.248438
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:15.185808
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    assert 1

# Generated at 2022-06-24 17:58:08.940550
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:12.813211
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/usr/platform/'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
# Test fixture

# Generated at 2022-06-24 17:58:15.288321
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_1 = PlaybookCLI('')
    if playbook_c_l_i_1.run() is not None:
        raise Exception("Unit test failed: PlaybookCLI.run")
    return 0


# Generated at 2022-06-24 17:58:16.482050
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:21.001822
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('/usr/platform/')
    var_0 = playbook_c_l_i_0.run()

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:21.983305
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:27.545529
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/usr/platform/'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == None
    
# Testing with pylint
# pylint: disable=no-member
# pylint: disable=no-self-use
# pylint: disable=too-many-public-methods

# Generated at 2022-06-24 17:58:28.337638
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:32.276061
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/usr/platform/'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:58:33.770497
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:37.544203
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    for i in range(10):
        test_case_0()
    str_0 = '/Users/liyag/apps/ansible-t/ansible/'
    str_1 = 'abc'
    # str_1 = '-i'
    # str_2 = 'localhost,'
    # str_2 = '-m'
    # str_3 = 'setup'
    # str_3 = '-c'
    # str_4 = 'local'
    # str_5 = '-t'
    # str_6 = './ansible'
    # str_6 = '--list-tasks'
    # str_6 = '--list-tags'
    # str_6 = '--syntax-check'
    str_6 = './ansible/playbooks/playbook.yml'
    list

# Generated at 2022-06-24 17:59:39.555825
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:44.346278
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('/usr/platform/')
    result_0 = playbook_c_l_i_0.run()

    # Test for execution of __init__ for class PlaybookCLI
    test_case_0()



# Generated at 2022-06-24 17:59:48.715905
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/usr/platform/'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    return var_0

# Generated at 2022-06-24 17:59:58.974120
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/usr/platform/'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()
    var_0 = type(str_0)
    var_1 = type('/usr/platform/')
    var_2 = type(str_0)
    var_3 = type(str_0)
    var_4 = type(str_0)
    var_5 = type(str_0)
    var_6 = type(str_0)
    var_7 = type(str_0)
    var_8 = type('/usr/platform/')
    var_9 = type(str_0)
    var_10 = type(str_0)
    var_11 = type(str_0)
    var_12

# Generated at 2022-06-24 18:00:02.157403
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:03.582129
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:00:13.699863
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/usr/platform/'
    str_1 = '/tmp/playbook.yml'
    str_2 = '--check'
    str_3 = '-f'
    str_4 = '10'
    str_5 = '--list-tasks'
    str_6 = '--list-tags'
    playbook_c_l_i_0 = PlaybookCLI(str_0, str_1, str_2, str_3, str_4, str_5, str_6)
    playbook_c_l_i_0.run()

# Test case for class PlaybookCLI

# Generated at 2022-06-24 18:00:14.919584
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:15.643232
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:29.739746
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:01:32.459381
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    setup_0 = setup()
    playbook_c_l_i_0 = PlaybookCLI()
    result_0 = playbook_c_l_i_0.run()
    teardown_0 = teardown()
    return result_0


# Generated at 2022-06-24 18:01:37.232376
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/usr/platform/'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

test_case_0()
test_PlaybookCLI_run()

# Generated at 2022-06-24 18:01:38.461248
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:39.554544
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:01:41.838437
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = './'
    playbook_c_l_i_1 = PlaybookCLI(str_0)
    playbook_c_l_i_1.run()



# Generated at 2022-06-24 18:01:43.414359
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Testing whether the playbook is successfully executed.
    assert test_case_0() == None

test_PlaybookCLI_run()

# Generated at 2022-06-24 18:01:45.422238
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:47.212327
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:01:48.460907
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:59.640687
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert True

# Generated at 2022-06-24 18:03:00.515941
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:02.417693
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:03:08.309381
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/usr/platform/'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0


# Generated at 2022-06-24 18:03:20.378056
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import tempfile

    PLAYBOOK_UNIT_TEST_FILE = '/tmp/test_file_for_playbook'
    BECOME_PASS = 'fake become pass'

    # Test the default AnsibleParser exit condition.
    # Should raise SystemExit with rc 0.
    test_case_0()

    # Test that the --list-tasks doesn't require a playbook.
    context.CLIARGS = {'listtasks': True}
    test_case_0()

    # Test that fail_on_missing_host_key is set to False if not specified.
    context.CLIARGS = {'fail_on_missing_host_key': None}
    test_case_0()

    # Test that become_ask_pass is set to True if not specified.

# Generated at 2022-06-24 18:03:22.364630
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #expect few errors or invalid messages
    try:
        test_case_0()
    except Exception as exception:
        raise exception

# Generated at 2022-06-24 18:03:26.945199
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/usr/platform/'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

try:
    test_case_0()
except:
    pass

try:
    test_PlaybookCLI_run()
except:
    pass

# Generated at 2022-06-24 18:03:34.302188
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    str_0 = 'ansible_connection=network_cli ansible_network_os=ios ansible_user=cisco ansible_password=cisco'
    str_1 = 'vyos_system'
    str_2 = '/home/aastha/vyos_system/vyos_system/tasks/main.yml'
    list_0 = []
    list_0.append(str_2)
    dic_0 = {}
    str_3 = 'playbook_dir'
    dic_0[str_3] = str_0
    str_4 = 'playbook_path'
    dic_1 = {}
    dic_1[str_4] = list_0
    dic_2 = {}
    dic_

# Generated at 2022-06-24 18:03:35.736397
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('Testing run()')
    test_case_0()


# Generated at 2022-06-24 18:03:37.433550
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()