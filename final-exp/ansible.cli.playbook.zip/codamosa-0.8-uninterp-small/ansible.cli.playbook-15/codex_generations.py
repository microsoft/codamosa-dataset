

# Generated at 2022-06-24 17:54:30.278068
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    assert not playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:54:31.684526
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:33.568487
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Test playbook cli
if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:36.342603
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    # Case 0
    test_case_0()

# Generated at 2022-06-24 17:54:45.909212
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '$\x16{\x19\x1a\x1b2\x1d"\x154\x16l\x17x\x18~\x19\x80\x1a\x81\x1b\x82\x1c\x83\x1d\x84\x1e\x85\x1f\x86 \x87\x1a!\x88"\x89#\x8a\x14$\x8b\x15%\x8c\x16&\x8d\'\x8e\x18(\x8f\x19)\x90\x1a*\x91+\x92\x1c,\x93-\x94.\x95\x1e0\x961\x97'
    playbook_c_

# Generated at 2022-06-24 17:54:51.073957
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '"6\x0cU\x1b\x18}\\)$\x1a\x0c,\x16>\x0f`'
    obj_0 = PlaybookCLI(str_0)
    try:
        obj_0.run()
    except Exception as exc:
        print(exc)


# Generated at 2022-06-24 17:54:57.460128
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    str_1 = '[aZ@hnzc%(APtD^]t"*}t"Elbd'
    playbook_c_l_i_1 = PlaybookCLI(str_1)


if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:10.920757
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '/ /home/users/barnum/ansible_dir/ansible/lib/ansible/modules/packaging/os/portage.py'
    str_1 = '\x0b#\x0bB\x0b$\x0b@\x0bG\x0bQ\x0b[\x0b`\x0bj\x0bs\x0b}'

# Generated at 2022-06-24 17:55:13.997985
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:55:19.626175
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_1 = PlaybookCLI(None)
    try:
        playbook_c_l_i_1.run()
    except Exception as err:
        print(err.args)
    else:
        pass


# Generated at 2022-06-24 17:55:31.669075
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    params = []
    r = PlaybookCLI.run(params)
    assert r == 0

# Generated at 2022-06-24 17:55:32.489160
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()



# Generated at 2022-06-24 17:55:39.798337
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pbcl = PlaybookCLI()
    cl_args = {'listhosts': False, 'listtags': False, 'listtasks': False, 'connection': 'smart', 'syntax': False,
               'flush_cache': False, 'verbosity': 0, 'host_key_checking': False, 'check': False, 'start_at_task': None,
               'step': False, 'start_at_task': None, 'become': False, 'become_method': None, 'become_user': None,
               'become_ask_pass': False, 'extra_vars': [], 'private_key_file': None, 'args': ['example.yaml']}
    pbcl.run()


# Generated at 2022-06-24 17:55:41.616779
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("Start")
    print("End")


# Generated at 2022-06-24 17:55:50.268556
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '$\x16{\x19\x1a\x1b2\x1d"\x154\x16l\x17x\x18~\x19\x80\x1a\x81\x1b\x82\x1c\x83\x1d\x84\x1e\x85\x1f\x86 \x87\x1a!\x88"\x89#\x8a\x14$\x8b\x15%\x8c\x16&\x8d\'\x8e\x18(\x8f\x19)\x90\x1a*\x91+\x92\x1c,\x93-\x94.\x95\x1e0\x961\x97'

# Generated at 2022-06-24 17:55:58.238232
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('Test for method run of class PlaybookCLI')


# Generated at 2022-06-24 17:56:09.759461
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '$\x16{\x19\x1a\x1b2\x1d"\x154\x16l\x17x\x18~\x19\x80\x1a\x81\x1b\x82\x1c\x83\x1d\x84\x1e\x85\x1f\x86 \x87\x1a!\x88"\x89#\x8a\x14$\x8b\x15%\x8c\x16&\x8d\'\x8e\x18(\x8f\x19)\x90\x1a*\x91+\x92\x1c,\x93-\x94.\x95\x1e0\x961\x97'

# Generated at 2022-06-24 17:56:12.339036
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible import context
    from ansible.cli.playbook import PlaybookCLI

    pb_cli = PlaybookCLI(['/bin/false'])
    context.CLIARGS = {'args': [], 'verbosity': 1}

    assert pb_cli.run() == 4



# Generated at 2022-06-24 17:56:20.464524
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\x03\x0d0]\x1d\x1b\x1c\x1d\x1e\x1e\x1f \x1b!'

    # Input arguments from func call 
    # Get global variable context
    context_0 = None

    # Call method
    result = PlaybookCLI.run(str_0)


# Generated at 2022-06-24 17:56:24.224460
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('Executing test_PlaybookCLI_run...')
    PlaybookCLI.run(str_0)

if __name__ == "__main__":
    # Unit test
    test_case_0()

# Generated at 2022-06-24 17:56:36.589741
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    py_0 = PlaybookCLI()
    py_1 = py_0.run()
    return (py_1)

# Generated at 2022-06-24 17:56:38.306682
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()
    cli.run()

# Generated at 2022-06-24 17:56:49.363824
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    play_dir = os.path.dirname(os.path.abspath(__file__))
    play_path = os.path.join(play_dir, '..', '..', 'lib', 'ansible', 'playbooks')
    ansible_path = os.path.join(play_dir, '..', '..', 'lib')
    test_path = os.path.join(play_dir, '..', '..', 'test')

    sys.path.append(ansible_path)
    sys.path.append(test_path)
    sys.path.append(play_path)

    context.CLIARGS = {'args': 'echo.yml' }

    b_playbook_dirs = []

# Generated at 2022-06-24 17:56:55.834955
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    param_0 = {'listtags': True, 'listhosts': False, 'syntax': False, 'step': False, 'start_at_task': None, 'flush_cache': False, 'verbosity': 0, 'args': ['../ansible_collections/ansible_namespace/collection/playbook.yml']}
    context.CLIARGS = param_0
    obj_0 = PlaybookCLI()
    obj_0.run()


# Generated at 2022-06-24 17:56:56.841411
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    print('Not yet implemented')


# Generated at 2022-06-24 17:57:03.003730
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  print("Testing PlaybookCLI.run")
  obj = PlaybookCLI()
  obj.run()


# Generated at 2022-06-24 17:57:15.761849
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    mock_RunTask_run = MagicMock(return_value=None)
    mock_RunTask_add_cli_arguments = MagicMock(return_value=None)

    with patch("ansible.cli.PlaybookCLI.AskPassCLI", mock_RunTask_run):
        with patch("ansible.cli.PlaybookCLI.AskPassCLI", mock_RunTask_add_cli_arguments):
            # Copy args to a dict
            args = vars(CLI.base_parser.parse_args(str_0))
            cli = PlaybookCLI(args)
            assert cli.run() is None
            # Verify all calls
            assert mock_RunTask_run.call_count == 1
            assert mock_RunTask_add_cli_arguments.call_count == 1

# Generated at 2022-06-24 17:57:24.268261
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI(['ansible-playbook'])
    playbook_cli.parser = getattr(playbook_cli, "parser", Mock())
    playbook_cli.parser.parse_args = Mock(return_value=str_0)
    playbook_cli.ask_passwords = Mock(return_value=(str_0, str_0))
    playbook_cli._play_prereqs = Mock(return_value=(str_0, str_0, str_0))
    playbook_cli._flush_cache = Mock(return_value=None)
    playbook_cli.run()


# Generated at 2022-06-24 17:57:30.404093
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Input parameters testing
    args = '$\x16{\x19\x1a\x1b2\x1d"\x154\x16l\x17x\x18~\x19\x80\x1a\x81\x1b\x82\x1c\x83\x1d\x84\x1e\x85\x1f\x86 \x87\x1a!\x88"\x89#\x8a\x14$\x8b\x15%\x8c\x16&\x8d\'\x8e\x18(\x8f\x19)\x90\x1a*\x91+\x92\x1c,\x93-\x94.\x95\x1e0\x961\x97'

   

# Generated at 2022-06-24 17:57:41.491771
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI()

# Generated at 2022-06-24 17:58:01.594228
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\x08\x13\x07\x02\x018\x180\x1a\x1c\x1d\x1e\x1f!\x03\x17$0\x1a4\x18\x1c\x1d\x1e\x1f!\x03\x17$\x1b'
    str_1 = '\x16\x01\x124\x13\x1c\x1e\x1f"\x03\x17$\x000\x17\x1a\x1c\x1e\x1f"\x03\x17$\x1b'

# Generated at 2022-06-24 17:58:05.902346
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("Testing run of class PlaybookCLI")
    # FIXME: No way to test this method
    # cli = PlaybookCLI()
    # cli.run()
    assert True


# Generated at 2022-06-24 17:58:07.038158
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:58:09.328086
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli_obj_0 = PlaybookCLI()
    playbook_cli_obj_0.run()
    return playbook_cli_obj_0

# Generated at 2022-06-24 17:58:18.114723
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '?\x15@\x16A\x17B\x18C\x19D\x1aE\x1bF \x1c!\x1d"\x1e#\x1f$\x14%\x15&\x16\'\x17\x18(\x19)\x1a*\x1b+\x1c,\x1d-\x1e0\x1f1\x14'

# Generated at 2022-06-24 17:58:20.110117
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:58:25.224157
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    def test_case_0_stdin(self):
        return str_0
    with patch('sys.stdin', StringIO(str_0)):
        with patch('sys.stdin.readline', new=MagicMock(side_effect=test_case_0_stdin)):
            assert PlaybookCLI.run() == 0


# Generated at 2022-06-24 17:58:27.396809
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print(str_0.encode('latin-1').decode('unicode_escape'))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:58:29.720564
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Initialization of the class object
    cli = PlaybookCLI([])

    # Test the case when the method is called with the following arguments
    a = cli.run()



# Generated at 2022-06-24 17:58:32.347457
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pbcli = PlaybookCLI(None, None, None)
    assert pbcli.run() == 0


# Generated at 2022-06-24 17:58:49.116497
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:52.681848
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:53.766783
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:58:54.715340
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert True


# Generated at 2022-06-24 17:59:00.212368
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:59:06.360623
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()
    assert playbook_c_l_i_0
    assert var_0 == 0

# Generated at 2022-06-24 17:59:19.552924
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('\x1ehMv#')

# Generated at 2022-06-24 17:59:21.854919
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'zR@K.Q,1%.631&$\x00U(dY'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:23.083238
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:30.120145
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from pprint import pprint
    argv = ['ansible-playbook', '-t', 'listtasks', 'test.yml']
    options = PlaybookCLI(argv).parse()
    pprint(options)

    # Run the method
    ret = PlaybookCLI(argv).run()
    # Assert that the return type is correct
    assert isinstance(ret, int), 'Expected type: %s. Got: %s' % (int, type(ret))

# Generated at 2022-06-24 17:59:46.941849
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert callable(PlaybookCLI._flush_cache)

# Generated at 2022-06-24 17:59:50.422668
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('UxC6w')
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:51.566943
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:59:52.707172
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:59:57.943876
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class_0 = PlaybookCLI('')
    class_0.run()
    try:
        class_0.run()
    except:
        raise AssertionError()
    else:
        pass
    try:
        class_0.run()
    except:
        raise AssertionError()
    else:
        pass

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:00:05.142331
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:00:06.400079
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:00:07.098921
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:07.826322
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:10.882116
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:32.524508
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:33.252408
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:38.434195
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

test_case_0()

# Generated at 2022-06-24 18:00:41.832215
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'uP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:00:43.246393
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:44.463838
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:00:49.745097
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '{"playbook": [0]}'
    playbook_c_l_i_1 = PlaybookCLI(str_0)
    try:
        var_0 = playbook_c_l_i_1.run()
    except:
        pass

# Generated at 2022-06-24 18:00:51.336397
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-24 18:00:59.873553
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 18:01:02.810853
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:01:30.076357
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:01:31.124131
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:31.862546
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    test_case_0()

# Generated at 2022-06-24 18:01:34.891746
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('', '', '', '', '')
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0


# Generated at 2022-06-24 18:01:40.398632
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Scenario: execute test case with listtags option
# Input: -i ./inventory --listtags --verbose testcase.yml
# Expected result: list all available tags

# Generated at 2022-06-24 18:01:41.267306
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:01:42.125057
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:43.321431
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert isinstance(PlaybookCLI.run(), int)

# Generated at 2022-06-24 18:01:49.161415
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:01:50.590304
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:16.523390
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
        assert False, "unexpected exception"

test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:19.293859
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as e:
        raise e

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:20.451602
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:21.558283
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:22.267680
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:25.218582
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as raised_exception:
        print("Exception: <%s> occured at line <%d> in test case <%s>" % ( raised_exception,raised_exception.__traceback__.tb_lineno, test_case_0.__name__))


# Generated at 2022-06-24 18:02:30.099441
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()
    print(var_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 18:02:32.987279
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:02:35.692347
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:42.661523
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  try:
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    test_case_0(str_0)
  except SystemExit as e:
    log.error(e)
  except:
    log.error("unexpected exception: ", sys.exc_info()[0])
    raise
  else:
    print("Test run OK")
  finally:
    print("Test run complete")

# Generated at 2022-06-24 18:03:27.750818
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    
    # test_case_0()
    str_0 = 'dP_aO+k\x0c^v+ivJ"Elbd'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:03:29.659767
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as e:
        assert False, str(e)

# Generated at 2022-06-24 18:03:32.025053
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:03:33.456328
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Call method with arguments
    test_case_0()


# Generated at 2022-06-24 18:03:34.523091
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:39.122287
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Unit test for method run of class PlaybookCLI
    playbook_c_l_i_0 = PlaybookCLI()

    # Argument 1 (self)
    arg_0 = None

    # Invocation of method run of class PlaybookCLI
    var_0 = playbook_c_l_i_0.run(arg_0)

# Generated at 2022-06-24 18:03:39.883507
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    

# Generated at 2022-06-24 18:03:43.645738
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    arr_0 = []
    arr_1 = []
    str_0 = ''

    # Run the function
    test_case_0()
    # Check function output
    assert var_0 == 0
    # Check function output
    assert arr_0 == arr_1
    # Check function output
    assert str_0 == ''

# Generated at 2022-06-24 18:03:48.400647
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # This also tests method run of class CLI
    str_0 = 'e.`'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:03:49.671659
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()