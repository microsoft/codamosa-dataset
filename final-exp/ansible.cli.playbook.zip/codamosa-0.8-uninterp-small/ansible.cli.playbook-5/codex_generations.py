

# Generated at 2022-06-24 17:54:28.735124
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_1 = b'\xa4\x82\x07'
    PlaybookCLI(bytes_1)

# Generated at 2022-06-24 17:54:31.416141
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x1b\xd1'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    
    #Call the method
    playbook_c_l_i_0.run()
    
    pass

# Generated at 2022-06-24 17:54:33.110768
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xe6\x13'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)

# Generated at 2022-06-24 17:54:37.840620
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:54:41.437770
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x1b\xd1'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    try:
        playbook_c_l_i_0.run()
    except:
        pass

# Generated at 2022-06-24 17:54:47.056606
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\xf2\xda'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)

    # call method run
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()


# Generated at 2022-06-24 17:54:53.226407
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x1b\xd1'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    try:
        playbook_c_l_i_0.run()
    except SystemExit as exception_0:
        assert exception_0.code == 0

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:57.839448
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  argv = ['-i',
          'inventory',
          '-f',
          '10',
          '-k',
          '-K',
          '-u',
          'default_user',
          'play1.yml',
          'play2.yml']
  cli = PlaybookCLI(argv)
  result = cli.run()
  assert result == 0


# Generated at 2022-06-24 17:55:03.528778
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    options = {}
    context.CLIARGS = options
    context.CLIARGS['args'] = ['playbook.yml']
    playbook_c_l_i_1 = PlaybookCLI(options)
    assert playbook_c_l_i_1.run() == 0

# Generated at 2022-06-24 17:55:07.786008
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x1b\xd1'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    try:
        playbook_c_l_i_0.run()
    except Exception:
        pass


# Generated at 2022-06-24 17:55:28.589927
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x1b\xd1'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    command_line_options_0 = dict()
    command_line_options_0['connection'] = 'network_cli'
    command_line_options_0['diff'] = False
    command_line_options_0['become_method'] = 'enable'
    command_line_options_0['check'] = False
    command_line_options_0['module_path'] = ''
    command_line_options_0['forks'] = 5
    command_line_options_0['listhosts'] = False
    command_line_options_0['listtags'] = False
    command_line_options_0['verbosity'] = 0
    command_line_options_0

# Generated at 2022-06-24 17:55:34.676608
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a temporary directory for collections
    # Make sure any files/directories created under this directory is under control
    import tempfile
    from shutil import rmtree

    collection_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 17:55:38.931235
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    loader, inventory, variable_manager = PlaybookCLI._play_prereqs()

    pbex = PlaybookExecutor(playbooks=['/tmp/test_PlaybookCLI_run'], inventory=inventory,
                            variable_manager=variable_manager, loader=loader,
                            passwords={'conn_pass': None, 'become_pass': None})
    results = pbex.run()
    pass

test_PlaybookCLI_run()
test_case_0()

# Generated at 2022-06-24 17:55:42.067892
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x1b\xd1'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    try:
        playbook_c_l_i_0.run()
    except Exception as exc:
        exception_caught = exc



# Generated at 2022-06-24 17:55:44.702885
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
	pass


# Generated at 2022-06-24 17:55:47.884795
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x1b\xd1'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:55:55.362541
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x1b\xd1'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    # Call method run of playbook_c_l_i_0
    result = playbook_c_l_i_0.run()
    # print result.output
    # print result.exit_code
    assert (result.output == b'')
    assert (result.exit_code == -1)


# Generated at 2022-06-24 17:56:02.856299
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x1b\xd1'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    playbook_c_l_i_0.parse()
    playbook_c_l_i_0.post_process_args(context.CLIARGS)
    options_0 = context.CLIARGS
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:12.706937
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x1b\xd1'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)

    class AnsibleError_0:

        # __init__ of class AnsibleError
        def __init__(self, *args, **kwargs):
            pass
        
        class AnsibleError:
            pass

    playbook_c_l_i_0.AnsibleError = AnsibleError_0
    ansible_error_0 = playbook_c_l_i_0.AnsibleError()
    class Display_0:

        # __init__ of class Display
        def __init__(self, *args, **kwargs):
            pass

    playbook_c_l_i_0.Display = Display_0
    display_0 = playbook_c_l_i_

# Generated at 2022-06-24 17:56:26.259638
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bytes_0 = b'\x1b\xd1'
    bytes_1 = b'\x80XY'
    bytes_2 = b'\x1c\xbd'
    bytes_3 = b'\x80XY'
    playbook_c_l_i_0 = PlaybookCLI(bytes_0)
    _dir = 'test/test_data'

# Generated at 2022-06-24 17:56:40.122494
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:56:44.554371
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:45.449034
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-24 17:56:49.411830
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    playbook_c_l_i_0.post_process_args()
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:56:53.101968
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = False
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    x = playbook_c_l_i_0.run()
    assert x == 0, "Returned value does not equal expected value"
    test_case_0()

# Generated at 2022-06-24 17:56:56.886565
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("Test case begin...")
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    playbook_c_l_i_0.run()
    print("Test case end")


# Generated at 2022-06-24 17:56:59.110145
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:57:08.006199
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:57:08.866071
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:14.866255
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    bool_0 = True
    var_0 = playbook_c_l_i_0.init_parser()
    var_1 = playbook_c_l_i_0.parse()
    var_2 = playbook_c_l_i_0.post_process_args(var_1)
    var_3 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:57:43.048619
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.run()
    print(var_0)

# Generated at 2022-06-24 17:57:53.578165
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.init_parser()
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    import sys

# Generated at 2022-06-24 17:57:54.781786
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:57:57.622337
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_obj = PlaybookCLI()
    bool_0 = True
    playbook_c_l_i_obj.run(bool_0)


# Generated at 2022-06-24 17:58:04.119255
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_1 = playbook_c_l_i_0.run()
    var_2 = None
    var_3 = None
    if var_1 is var_2:
        var_3 = None
    else:
        var_3 = var_1
    return var_3

# Generated at 2022-06-24 17:58:06.370785
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  b_y = False
  playbook_c_l_i = PlaybookCLI(b_y)
  playbook_c_l_i.run()


# Generated at 2022-06-24 17:58:11.235998
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    expected = 0

    try:
        test_case_0()
    except Exception as e:
        assert False
    else:
        assert True

    try:
        test_case_0()
    except Exception as e:
        assert False
    else:
        assert True

# Generated at 2022-06-24 17:58:15.645340
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.init_parser()
    ansible_error = AnsibleError("error")
    with pytest.raises(AnsibleError) as ansible_error:
        playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:58:20.626409
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.run()

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:22.546916
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:29.304566
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:32.261496
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    int_0 = playbook_c_l_i_0.run()
    assert int_0 == 0

# Generated at 2022-06-24 17:59:34.479419
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_1 = True
    playbook_c_l_i_1 = PlaybookCLI(bool_1)
    var_1 = playbook_c_l_i_1.run()
    # print(var_1)
    assert var_1 == 0

# Generated at 2022-06-24 17:59:37.912386
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:40.076185
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:42.817665
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:45.336750
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_18 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:56.673426
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    os.environ['ANSIBLE_CONFIG'] = 'sample_ansible_cfg_2'
    # Instantiating a class of type PlaybookCLI
    playbook_c_l_i_0 = PlaybookCLI(False)
    # Call the method run of class PlaybookCLI

# Generated at 2022-06-24 17:59:59.182645
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:00:03.520903
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

test_PlaybookCLI_run()

if __name__ == '__main__':
    pass

# Generated at 2022-06-24 18:02:47.872171
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('unit test for method run of class PlaybookCLI')

# Generated at 2022-06-24 18:02:50.188290
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Check if the method run tests cases as expected 
    playbook_c_l_i_0 = PlaybookCLI(True)
    var_1 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:02:53.604788
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0

# Generated at 2022-06-24 18:02:57.771872
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.init_parser()
    var_1 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:02:59.960983
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    # test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:03:05.468845
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    int_0 = 0
    bool_0 = False
    bool_1 = True
    playbook_c_l_i_0 = PlaybookCLI(int_0)
    var_0 = playbook_c_l_i_0.run()
    assert not bool_1
    assert bool_0

test_PlaybookCLI_run()

# Generated at 2022-06-24 18:03:09.008969
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = False
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    test_case_0()


# Generated at 2022-06-24 18:03:20.413567
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    string_0 = to_bytes("ansible-playbook")
    dict_0 = {}
    dict_1 = {}
    dict_1['connection'] = 'local'
    dict_0['become'] = dict_1
    dict_0['become_method'] = 'sudo'
    dict_0['become_user'] = 'root'
    dict_0['check'] = False
    dict_0['diff'] = False
    dict_0['extra_vars'] = [{}]
    dict_0['help'] = False
    dict_0['inventory_file'] = './inventory.ini'
    dict_2 = {}
    dict_2['listhosts'] = True
    dict_0

# Generated at 2022-06-24 18:03:25.134103
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("test_PlaybookCLI_run")
    args = ['/home/david/ansible/ansible/test/integration/targets/centos/test_cred.yml']
    bool_0 = True
    playbook_c_l_i_0 = PlaybookCLI(bool_0)
    var_0 = playbook_c_l_i_0.run()



# Generated at 2022-06-24 18:03:33.054457
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Tests that the method run of class PlaybookCLI raises the AnsibleError exception
    # when the playbook file does not exist.
    from ansible.errors import AnsibleError
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = PlaybookExecutor.get_loader()
    # we need a valid path to use for the test playbook
    dir_path = os.path.dirname(os.path.realpath(__file__))
    test_playbook = os.path.join(dir_path, 'data/playbook_empty.yaml')
    try:
        ansible_playbook = PlaybookCLI([test_playbook], loader)
        ansible_playbook.run()
    except AnsibleError as e:
        assert 'the playbook: %s could not be found' % test_