

# Generated at 2022-06-24 17:54:31.238391
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.parse()
    playbook_c_l_i_0.post_process_args()
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:54:33.916609
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cmdLine = "./test_playbook_cli --version"
    playbookCLI = PlaybookCLI(cmdLine.split())
    playbookCLI.init_parser()
    playbookCLI.post_process_args(playbookCLI.parse())
    playbookCLI.run()

# Generated at 2022-06-24 17:54:37.954866
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    assert(playbook_c_l_i_0 is not None)
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:40.843709
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = ""
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:54:42.984695
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)


# Generated at 2022-06-24 17:54:54.836532
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    ansible_c_1 = AnsibleCollectionConfig

    ansible_c_1._playbook_paths = [b'/etc/ansible/hosts', b'ansible.cfg']
    ansible_c_1._roles_paths = [b'/usr/share/ansible/roles', b'/usr/share/ansible/roles']
    ansible_c_1._config = {}
    ansible_c_1.collections_paths = b'/usr/share/ansible/collections:/etc/ansible/collections'
    str_1 = "}Ig[79E"
    ansible_c_1._cache_path = str_1
    str_2 = "3c[p/Ki"
    ansible_c_1._cache_expire = str_2
    str_3

# Generated at 2022-06-24 17:55:00.346235
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = ''
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:12.051830
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:55:16.905568
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_1 = PlaybookCLI(str_0)
    playbook_c_l_i_1.run()


# Generated at 2022-06-24 17:55:19.423663
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Setup
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # Invocation
    result = playbook_c_l_i_0.run()

    # Verification
    assert result is not None

# Generated at 2022-06-24 17:55:32.921676
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# --------------------------------------------------------------------- #

# Call the main function
if __name__ == "__main__":

    stat = test_PlaybookCLI_run()
    sys.exit(stat)

# --------------------------------------------------------------------- #

# EOF

# Generated at 2022-06-24 17:55:40.814475
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # case0
    # test_playbook_cli.test_case_0()
    cli = PlaybookCLI(args=['./test_playbook_cli', '--version'])
    cli.run()
    cli = PlaybookCLI(args=['./test_playbook_cli', '-h'])
    cli.run()
    cli = PlaybookCLI(args=['./test_playbook_cli', '-hh'])
    cli.run()
    cli = PlaybookCLI(args=['./test_playbook_cli', '-hvv'])
    cli.run()
    cli = PlaybookCLI(args=['./test_playbook_cli', '-hvvvv'])
    cli.run()

# Generated at 2022-06-24 17:55:41.813251
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli_0 = PlaybookCLI()
    playbook_cli_0.run()

# Generated at 2022-06-24 17:55:43.251728
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    return PlaybookCLI.run()


# Generated at 2022-06-24 17:55:45.749529
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    string = './test_playbook_cli -i ./test_inventory.py --list-hosts'
    #sp = subprocess.call(string)



# Generated at 2022-06-24 17:55:57.195282
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # ARRANGE
    #
    # NOTE: This arranges a number of things, including
    # the initialization of global variables that are used in
    # the application.
    my_args = []
    context.CLIARGS = context.CLIARGS._replace(args=my_args)
    display.verbosity = 2
    cli = PlaybookCLI()

    # ACT
    #
    # NOTE: This call to run changes global variables.
    # Specifically, the current directory is changed, and
    # the values in context.CLIARGS are changed.
    cli.run()

    # ASSERT
    #
    # NOTE: These asserts depend on global variables,
    # and they are not preserved. The first assert passes,
    # but the second one fails.
    assert(display.verbosity == 2)
   

# Generated at 2022-06-24 17:56:09.647526
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli_args = ['--version']
    PlaybookCLI.run_cli([cli_args])
    # test_case_1()
    # test_case_2()
    # test_case_3()
    # test_case_4()
    # test_case_5()
    PlaybookCLI.run_cli([['-i','hosts','test_playbook_0.yml','-vvv']])
    PlaybookCLI.run_cli([['-i','hosts','test_playbook_0.yml','-vvv','--list-tasks']])
    PlaybookCLI.run_cli([['-i','hosts','test_playbook_0.yml','-vvv','--list-tags']])



if __name__ == '__main__':

    test

# Generated at 2022-06-24 17:56:10.657892
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# unit test for method run of class PlayBookCLI

# Generated at 2022-06-24 17:56:25.185594
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:56:27.818819
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    result = PlaybookCLI().run()
    assert  type(result) == bool


if __name__ == '__main__':
    pytest.main(__file__)

# Generated at 2022-06-24 17:56:40.182797
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:46.054573
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.init_parser()
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:56:56.843154
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:57:07.511034
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # dummy input args
    args = ["file.yml"]

    # dummy parser
    parser = optimist.Optimist(args)
    parser.add_option("-f", "--foo", dest="foo", default=False)
    parser.options.foo = "bar"
    parser.add_option("-v", dest="verbose", default=False)
    parser.options.verbose = True

    # initialise cli object
    cli = PlaybookCLI(parser)

    # run code under test
    ret = cli.run()

    assert "bar" == cli.options.foo
    assert True == cli.options.verbose
    assert ret == 0

# Generated at 2022-06-24 17:57:10.600876
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_1 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_1.run()

# Generated at 2022-06-24 17:57:13.356780
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Tests for method __init__ of class PlaybookCLI:
    ansible_vault_password_file = 'pw-file'
    test_case_0()

# Generated at 2022-06-24 17:57:15.577710
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.post_process_args(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:57:24.095542
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Initial test case
    str_1 = "~q[?A'I"
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    var_1 = playbook_c_l_i_1.run()
    assert var_1 == None

    # Test case with argument 'ansible_playbook_python' and '--version'
    str_2 = "~q[?A'I"
    playbook_c_l_i_2 = PlaybookCLI(str_2)
    var_2 = playbook_c_l_i_2.run('ansible_playbook_python', '--version')
    assert var_2 == None

    # Test case with argument '--help'
    str_3 = "~q[?A'I"
    playbook_c_l_i_3

# Generated at 2022-06-24 17:57:26.457840
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0


# Generated at 2022-06-24 17:57:30.336822
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.init_parser()
    var_1 = playbook_c_l_i_0.run()
    assert var_1 is None


# Generated at 2022-06-24 17:58:01.030587
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    if var_0 != None:
        var_0.pop('listhosts')
    if var_0 != None:
        var_0.pop('listtags')
    if var_0 != None:
        var_0.pop('syntax')
    str_1 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_1)
    var_1 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:58:07.268945
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI("~q[?A'I")
    var_0 = playbook_c_l_i_0.init_parser()
    var_1 = playbook_c_l_i_0.post_process_args(var_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:58:07.965458
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    obj = PlaybookCLI("test")
    assert obj.run() == 0

# Generated at 2022-06-24 17:58:13.716566
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "../t/data/playbooks/playbook.yml"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:17.810900
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:58:19.850030
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:58:24.214686
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI("dir_path=/etc")
    var_0 = playbook_c_l_i_0.init_parser()
    var_0 = playbook_c_l_i_0.post_process_args(var_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:58:27.356833
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = "~q[?A'I"
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    var_1 = playbook_c_l_i_1.run()

# Generated at 2022-06-24 17:58:29.682019
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:58:41.466729
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    str_0 = "~q[?A'I"
    playbook_c_l_i_0.init_parser(str_0)
    str_0 = "~q[?A'I"
    playbook_c_l_i_0.post_process_args(str_0)
    str_0 = "~q[?A'I"
    playbook_c_l_i_0.parse()
    playbook_c_l_i_0.run()


if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:20.340697
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.init_parser()
    var_1 = playbook_c_l_i_0.post_process_args(var_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:21.397955
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert PlaybookCLI._flush_cache

# Generated at 2022-06-24 17:59:29.173930
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.init_parser()
    playbook_c_l_i_0.parse()
    playbook_c_l_i_0.setup_logging()
    var_0 = playbook_c_l_i_0.post_process_args()
    var_1 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:33.020857
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "playbook.yml"
    arguments = [str_0]
    context.CLIARGS = {'args': arguments}
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:37.237713
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:40.355632
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = "~q[?A'I"
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    playbook_c_l_i_1.run()

# Generated at 2022-06-24 17:59:46.070466
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(args_0)
    var_0 = playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:57.032887
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI("qw")
    playbook_c_l_i_0.init_parser()
    playbook_c_l_i_0.base_parser = 0
    playbook_c_l_i_0.args = "Xr"
    playbook_c_l_i_0.parser = 0
    playbook_c_l_i_0.subparser = 0
    playbook_c_l_i_0.options = 0
    playbook_c_l_i_0.env_options = 0
    playbook_c_l_i_0.post_process_args(0)
    playbook_c_l_i_0.display_args = 0
    playbook_c_l_i_0.run()
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:00:00.371117
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


test_case_0()
test_case()

# Generated at 2022-06-24 18:00:05.466009
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.init_parser()
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:00:48.638123
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:00:51.556078
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    for i in range(10):
        try:
            ansible_playbook_cli_run()
        except NameError:
            print("NameError")
        else:
            print("No error")



# Generated at 2022-06-24 18:00:56.588827
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0
    return


# Generated at 2022-06-24 18:00:58.413614
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:01:02.820494
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    import argparse
    arg_parse_0 = argparse.ArgumentParser()
    playbook_c_l_i_0 = PlaybookCLI(arg_parse_0)
    # This is the code we are trying to test.
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:01:12.331599
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.options = str_0
    playbook_c_l_i_0.args = str_0
    ret_val_0 = playbook_c_l_i_0.run()
    assert len(ret_val_0) == 0


if __name__ == '__main__':
#    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:01:16.167755
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


if __name__ == "__main__":
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:01:21.358848
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    str_0 = "~q[?A'I"
    playbook_c_l_i_0.post_process_args(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:01:33.062643
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    file_0 = "playbook.yml"
    str_0 = "~q[?A'I"
    list_0 = ['d', 'a', 'b']
    dict_0 = dict()

    dict_0['Yd'] = file_0
    dict_0['list_hosts'] = False
    dict_0['become_pass'] = None
    dict_0['module_path'] = None
    dict_0['start_at_task'] = None
    dict_0['connection'] = 'smart'
    dict_0['args'] = list_0
    dict_0['private_key_file'] = None
    dict_0['vault_password_file'] = None
    dict_0['ssh_common_args'] = None
    dict_0['become'] = False

# Generated at 2022-06-24 18:01:36.975558
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:02:54.206584
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:03:01.308910
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('Test Start method run of class PlaybookCLI')
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    try:
        var_0 = playbook_c_l_i_0.run()
    except OSError as e:
        print(e)
    print('\nTest End method run of class PlaybookCLI\n')

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:03:10.141355
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.init_parser()
    p_1 = playbook_c_l_i_0.run()
    p_2 = playbook_c_l_i_0.post_process_args(var_0)


# Generated at 2022-06-24 18:03:13.908462
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    run_playbook_cli = PlaybookCLI()

    run_playbook_cli.run()

# Generated at 2022-06-24 18:03:16.971938
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # assert that the run method returns expected value to caller
    assert True, "run method of class PlaybookCLI did not return expected value"


# Generated at 2022-06-24 18:03:21.294508
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.init_parser()
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:03:23.969034
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:03:29.914442
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.init_parser()
    var_1 = playbook_c_l_i_0.run()
    if var_1:
        print('SUCCESS: %s' % var_1)
    else:
        print('FAILURE: %s' % var_1)


# Generated at 2022-06-24 18:03:33.458139
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "~q[?A'I"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    res = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:03:35.082469
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()