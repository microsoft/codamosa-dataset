

# Generated at 2022-06-24 17:54:29.697702
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:54:40.506595
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:54:43.028819
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    test_case_0 = PlaybookCLI(str_0)
    assert test_case_0.run() == None

# Generated at 2022-06-24 17:54:47.806878
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '!kx,gRfX/6H=r6@'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:54:53.402059
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    global playbook_c_l_i_0
    testcase = [{'when': 'when'}, {'when': 'when'}]
    for i in testcase:
        if i['when'] == 'when':
            str_0 = 'S~J))ReZ>jN1{'
            playbook_c_l_i_0 = PlaybookCLI(str_0)
            playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:00.011810
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    # Create an instance of the class
    playbook_c_l_i_1 = PlaybookCLI(str_0)
    playbook_c_l_i_1._flush_cache = lambda _1, _2: None
    playbook_c_l_i_1._play_prereqs = lambda: (1, 1, 1)
    playbook_c_l_i_1.post_process_args = lambda _1: _1
    playbook_c_l_i_1.run()

test_case_0()
test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:04.987580
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:08.040878
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    playbook_c_l_i_1.run()

# Generated at 2022-06-24 17:55:10.808152
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        if __name__ == '__main__':
            test_case_0()
    except SystemExit as e:
        print(e)
    except Exception as e:
        print(e)

# Generated at 2022-06-24 17:55:17.337119
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Set inventory to mock object
    mock_inventory = MagicMock()
    mock_inventory.get_hosts.return_value = ['host-1', 'host-2']
    mock_inventory.list_hosts.return_value = ['host-1', 'host-2']
    mock_inventory.get_host.return_value = 'host-2'

    # Set variable_manager to mock object
    mock_variable_manager = MagicMock()
    mock_variable_manager.get_host_variables.return_value = True
    mock_variable_manager.get_vars.return_value = False

    # Set loader to mock object
    mock_loader = MagicMock()

    # Set PlaybookCLI run method to mock object
    mock_playbook_c_l_i_run = MagicMock()

    #

# Generated at 2022-06-24 17:55:36.073874
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    stream = StringIO()
    args = ['ansible-playbook', '--check', '--list-hosts']
    with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream), mock.patch.object(sys, 'argv', args):
        with mock.patch.object(C, 'HOST_KEY_CHECKING', False), \
            mock.patch.object(Context, 'CLIARGS', {'listhosts': True, 'check': True, 'host_key_checking': False, 'timeout': 10}):
            test_case_0()
            assert stream.getvalue() == '''
playbook: test/ansible/playbooks/maptest.yml

  play #1 (): test

    pattern: all
    hosts (0):

'''

# Generated at 2022-06-24 17:55:42.041796
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # Test getting a 'to_text' object from a 'PlaybookCLI' object.
    ans_obj_0 = playbook_c_l_i_0.to_text()
    assert (isinstance(ans_obj_0, str))

    # Test getting a 'to_xml' object from a 'PlaybookCLI' object.
    ans_obj_1 = playbook_c_l_i_0.to_xml()
    assert (isinstance(ans_obj_1, str))

    # Test getting a 'to_yaml' object from a 'PlaybookCLI' object.
    ans_obj_2 = playbook_c_l_i_0.to

# Generated at 2022-06-24 17:55:48.575014
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:55:52.926147
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    test_case_0()

    test_case_0()


# Generated at 2022-06-24 17:56:00.586564
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Arrange
    argv = ['-K', '-i', 'myhost.com,']
    args = opt_help.parse_args(argv, context)
    context.CLIARGS = args
    str_0 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # Act
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:06.583344
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:09.901108
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:56:10.766548
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:56:12.288444
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:56:13.754421
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    test_case_0()

# Generated at 2022-06-24 17:56:30.504194
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:33.662047
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    x = 1
    y = 2
    assert PlaybookCLI.run(x, y) == (x+y)

# Generated at 2022-06-24 17:56:36.713690
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:42.260360
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('')
    playbook_c_l_i_0.post_process_args({})
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:56:53.706405
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    __tracebackhide__ = True
    str_0 = ':-6Uw,6CKi.2'
    str_1 = '~N/@i*'
    str_2 = 'N`/ya`E##r~'
    str_3 = 'T!TbFo:s'
    str_4 = 'Dv@}$el>Bx|'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    int_0 = getattr(playbook_c_l_i_0, str_1)()
    if int_0 != 0:
        return
    int_1 = getattr(playbook_c_l_i_0, str_2)()
    if int_1 != 0:
        raise AssertionError(str_3)
    int

# Generated at 2022-06-24 17:56:56.167254
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    t_s_0 = PlaybookCLI.run(str_0)
    return t_s_0


# Generated at 2022-06-24 17:57:00.356885
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    _argv = ['ansible-playbook', '-i', 'hosts.txt', 'playbook.yaml']
    _parser = PlaybookCLI(_argv).parser
    _options = _parser.parse_args(_argv)
    PlaybookCLI(_argv).post_process_options(_options)
    PlaybookCLI(_argv).run()

# Generated at 2022-06-24 17:57:08.064424
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('S~J))ReZ>jN1{')
    str_0 = 'S~J))ReZ>jN1{'
    str_1 = 'K>n6q?U'
    dict_0 = {'S~J))ReZ>jN1{': str_1}
    playbook_c_l_i_0.post_process_args(dict_0)
    # Run method of PlaybookCLI class
    str_2 = 'S~J))ReZ>jN1{'
    str_3 = 'K>n6q?U'
    dict_1 = {'S~J))ReZ>jN1{': str_3}
    playbook_c_l_i_0.run(dict_1)


# Generated at 2022-06-24 17:57:11.178922
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 17:57:21.375504
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    subprocess_p_o_p_e_n_0 = subprocess.Popen(str_0)
    subprocess_p_o_p_e_n_0 = subprocess.Popen(str_0)
    if subprocess_p_o_p_e_n_0:
        subprocess_p_o_p_e_n_0.kill()
    str_1 = ''
    str_2 = ''
    str_3 = 'VA(-}-YzU6Sx'
    str_4 = 'a'
    str_5 = 'VA(-}-YzU6Sx'
    str_6 = 'a'
    str_7 = 'VA(-}-YzU6Sx'
    str_

# Generated at 2022-06-24 17:57:38.136810
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Reset the arguments

# Generated at 2022-06-24 17:57:38.947595
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:40.177791
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    Test Case 0
    """
    test_case_0()


# Generated at 2022-06-24 17:57:44.288074
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    global display
    ansible_playbook_run = PlaybookCLI('ansible-playbook')
    playbook_c_l_i_0 = PlaybookCLI('test -v')
    playbook_c_l_i_0.run()
    ansible_playbook_run.run()

# Generated at 2022-06-24 17:57:49.548585
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:51.857623
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI(';_[pX9~b<')
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:58:01.280689
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli_args = {
        'check', 'connection', 'diff', 'extra-vars', 'force-handlers', 'flush-cache', 'help', 'inventory-file', 'limit', 'list-hosts', 'list-tags', 'list-tasks', 'module-path', 'new-vault-id', 'new-vault-password-file', 'output', 'private-key', 'recheck', 'remote-user', 'syntax', 'tags', 'timeout', 'tree', 'vault-password-file', 'verbose', 'version', 'vault-id', 'vault-password', 'version'
    }
    context.CLIARGS = cli_args
    str_0 = 'S~J))ReZ>jN1{'

# Generated at 2022-06-24 17:58:04.923091
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:58:08.058296
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Testing AnsibleCollectionConfig.playbook_path with method flush_cache of class PlaybookCLI

# Generated at 2022-06-24 17:58:10.649834
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    ar_0 = 'S~J))ReZ>jN1{'
    playbook_c_l_i_0 = PlaybookCLI(ar_0)
    res_0 = playbook_c_l_i_0.run()
    assert res_0 == 0, 'ValueError: 0 == -1'

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:31.963949
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("\nTest method run of class PlaybookCLI\n")
    ansible_playbook_cli = PlaybookCLI()
    result = ansible_playbook_cli.run()
    print("\nTest case 0\n")
    result = ansible_playbook_cli.run()
    # assert result == 0


if __name__ == "__main__":
    test_case_0()
    try:
        # test_PlaybookCLI_run()
        print("\nPlaybookCLI has no test cases\n")
    except SystemExit as e:
        if e.code == 0:
            print("Test case passed")
        else:
            print("Test case fail")

# Generated at 2022-06-24 17:58:33.422976
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:58:35.122681
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # run the case above
    test_case_0()

# Generated at 2022-06-24 17:58:44.170690
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:58:46.643118
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    ansible_run = PlaybookCLI()
    ansible_run.run()


# Generated at 2022-06-24 17:58:51.803155
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI([])
    debug_0 = cli.init_parser()
    debug_1 = cli.run()
    return debug_1

if __name__ == '__main__':
    # Begining of the script
    test_PlaybookCLI_run()
    test_case_0()

# Generated at 2022-06-24 17:59:02.417774
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case = 0

    str_0 = '\n    Test Case 0\n    '
    parser_obj = None
    options_obj = None

    print('Running Test Case %d: %s' % (test_case, str_0))
    ansible_path = '/home/username/.ansible/collections'
    data_path = '/home/username/.ansible/collections/ansible_collections/test_namespace/test_collection/tests/data'
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = ansible_path
    os.environ['ANSIBLE_COLLECTIONS_DATA_PATH'] = data_path

    playbook_cli_obj = PlaybookCLI(parser_obj, options_obj)
    playbook_cli_obj.post_process_args(options=None)


# Generated at 2022-06-24 17:59:09.984694
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('Testing PlaybookCLI.run()')

# Generated at 2022-06-24 17:59:11.308023
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:21.213865
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    argv_0 = []
    argv_0.append('ansible-playbook')
    argv_0.append('/etc/ansible/playbook.yml')
    pbcli_0 = PlaybookCLI(argv=argv_0)
    pbcli_0.options = pbcli_0.parse()
    pbcli_0.normalize_become_options()
    pbcli_0.post_process_args(pbcli_0.options)
    pbcli_0.generate_tags()
    pbcli_0.accumulate_vars()
    pbcli_0.run()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 17:59:51.832782
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print(str_0)

    # Test parameters

    # Test procedure

    # Check results

    # Return the result
    return 0


# Generated at 2022-06-24 17:59:55.670935
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI_0 = PlaybookCLI('test')
    PlaybookCLI_0.post_process_args()
    PlaybookCLI_0.parser
    PlaybookCLI_0.parser.set_usage()
    PlaybookCLI_0.run()


# Generated at 2022-06-24 18:00:06.349513
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    param_0 = itertools.ifilter(None, itertools.imap(int, itertools.repeat(None, -1)))
    param_1 = None
    param_2 = itertools.ifilter(None, itertools.imap(int, itertools.repeat(None, -1)))
    try:
        PlaybookCLI.run(param_0, param_1, param_2)
    except:
        raise AssertionError('Test Case 0 failed')



if __name__ == '__main__':
    import sys
    import itertools
    import logging
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

    test_cases = [
        (None, None, None)
    ]


# Generated at 2022-06-24 18:00:06.835326
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass



# Generated at 2022-06-24 18:00:13.386779
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    global str_0
    # Line 15
    str_1 = 'test_ansible_playbook_test.test_PlaybookCLI_run'
    # Line 16
    str_2 = '\n    Unit test for method run of class PlaybookCLI\n    '
    # Line 17
    str_3 = 'add_all_plugin_dirs'
    # Line 18
    str_4 = 'ask_passwords'
    # Line 19
    str_5 = '_play_prereqs'
    # Line 20
    str_6 = 'get_host_list'
    # Line 21
    str_7 = 'validate_conflicts'
    # Line 22
    str_8 = 'post_process_args'
    # Line 23
    str_9 = 'run'
    # Line 24
    str

# Generated at 2022-06-24 18:00:24.175427
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test Case 0
    print(str_0)

    # Test Case 1
    print('\n    Test Case 1\n    ')

    # Test Case 2
    print('\n    Test Case 2\n    ')

    # Test Case 3
    print('\n    Test Case 3\n    ')

    # Test Case 4
    print('\n    Test Case 4\n    ')

    # Test Case 5
    print('\n    Test Case 5\n    ')

    # Test Case 6
    print('\n    Test Case 6\n    ')

    # Test Case 7
    print('\n    Test Case 7\n    ')

    # Test Case 8
    print('\n    Test Case 8\n    ')

test_PlaybookCLI_run()

# Generated at 2022-06-24 18:00:31.748002
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print(str_0)
    print('Test when context.CLIARGS[\'listhosts\'] is True')
    context.CLIARGS = {'listhosts': True}
    pbcli = PlaybookCLI()
    pbcli.run()
    print('Test when context.CLIARGS[\'listtasks\'] is True')
    context.CLIARGS = {'listtasks': True}
    pbcli = PlaybookCLI()
    pbcli.run()
    print('Test when context.CLIARGS[\'listtags\'] is True')
    context.CLIARGS = {'listtags': True}
    pbcli = PlaybookCLI()
    pbcli.run()

# Generated at 2022-06-24 18:00:33.538134
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI_instance_0 = PlaybookCLI()
    var_0 = PlaybookCLI_instance_0.run()

# unit test to detect a regression in regression test

# Generated at 2022-06-24 18:00:43.441095
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '\n    Test Case 0\n    '
    str_1 = ''
    str_2 = '\n    playbook: playbook_0.yaml\n    play #1 ()\tTAGS: [test]\n'
    str_3 = '\n    play #2 ()\tTAGS: [test]\n'
    str_4 = '\n    playbook: playbook_1.yaml\n    play #1 ()\tTAGS: [test]\n'
    str_5 = '\n    play #2 ()\tTAGS: [test]\n'
    str_6 = '\n    playbook: playbook_2.yaml\n    play #1 ()\tTAGS: [test]\n'

# Generated at 2022-06-24 18:00:53.787023
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    playbook_cli = PlaybookCLI()

    #
    #
    # This test case tests following assertion(s):
    #
    # Unit test for method run of class PlaybookCLI
    #
    #
    # Used to adapt _write_data to use a file-like object for writing
    #
    #
    # Used to adapt _write_data to use a file-like object for writing
    #
    #
    # Used to adapt _write_data to use a file-like object for writing
    #
    #
    # Used to adapt _write_data to use a file-like object for writing
    #
    #
    # Used to adapt _write_data to use a file-like object for writing
    #
    #
    # Used to adapt _write_data to use a file-like object for writing
    #


# Generated at 2022-06-24 18:01:35.310141
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # test_case_0()
    a = PlaybookCLI('iscsi')
    print(a.run())


# Generated at 2022-06-24 18:01:36.490604
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:37.695552
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:40.119602
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'iscsi'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:01:42.820714
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()



# Generated at 2022-06-24 18:01:48.350671
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'iscsi'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0



# Generated at 2022-06-24 18:01:49.569548
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:50.828892
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:52.210240
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pbcli = PlaybookCLI('')
    pbcli.run()

# Generated at 2022-06-24 18:01:54.539032
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'iscsi'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:03:08.375135
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:03:10.606515
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:13.001887
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_cls_0 = 'iscsi'
    playbook_cli_0 = PlaybookCLI(str_cls_0)
    playbook_cli_0.run()


# Generated at 2022-06-24 18:03:15.320437
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:18.819596
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    import datetime
    start_time = datetime.datetime.now()
    test_PlaybookCLI_run()
    end_time = datetime.datetime.now()
    print(end_time - start_time)

# Generated at 2022-06-24 18:03:19.629630
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:23.689327
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'iscsi'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()
    # assert playbook_c_l_i_0._flush_cache(playbook_c_l_i_0.inventory, playbook_c_l_i_0.variable_manager) == 0


# Generated at 2022-06-24 18:03:25.093091
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# end class PlaybookCLI

# Generated at 2022-06-24 18:03:32.321530
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    main()
    main_0()
    main_1()
    main_2()
    main_3()
    main_4()
    main_5()
    main_6()
    main_7()
    main_8()
    main_9()
    main_10()
    main_11()
    main_12()
    main_13()
    main_14()
    main_15()
    main_16()
    main_17()
    main_18()
    main_19()
    main_20()
    main_21()
    main_22()
    main_23()
    main_24()
    main_25()
    main_26()
    main_27()

# Generated at 2022-06-24 18:03:35.368914
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'roles'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0
