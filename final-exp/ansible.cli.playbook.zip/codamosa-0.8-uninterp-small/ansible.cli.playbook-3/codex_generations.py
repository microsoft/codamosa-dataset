

# Generated at 2022-06-24 17:54:35.747244
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # function to run unit test
    def run_test(assert_val, assert_val2):
        playbook_str = ''

# Generated at 2022-06-24 17:54:48.049606
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = "g_utXKjLDfh\x7f\x7fD"
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    arg_0 = "W\x7f\x7fK\x7f\x7f"
    arg_1 = "k\x7f\x7fV\x7f\x7f"
    arg_2 = "\x7f\x7f\x7f\x7fO\x7f\x7f\x7f\x7f"
    CLI.setup_vars(playbook_c_l_i_1, [arg_0, arg_1, arg_2])
    arg_3 = "TV\x7fNe\x7f\x7f"

# Generated at 2022-06-24 17:54:52.723992
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "@Mk'cRBN\n\n_+h;"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.parse()
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:54:55.285623
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = "@Mk'cRBN\n\n_+h;"
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.init_parser()

# Generated at 2022-06-24 17:55:00.852693
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    result = playbook_c_l_i_0.run()
    assert result is None


# Generated at 2022-06-24 17:55:01.745375
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-24 17:55:08.996440
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI("*}z`/eXwo-V8/3G<")
    str_0 = "NIZV{fGVbA,=H$:Xh\t"

    try:
        playbook_c_l_i_0.run(str_0)
    except:
        f_e_0 = sys.exc_info
        raise Exception(f_e_0)



# Generated at 2022-06-24 17:55:16.566725
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    str_0 = "D@:0$"
    str_1 = "R#)"
    str_2 = "i]w,0"
    str_3 = "qh=X"
    str_4 = "W-rv,D"
    str_5 = "n$i,d"
    str_6 = '&%`'
    str_7 = '&%`'
    bool_1 = True
    str_8 = 'o!'
    str_9 = 'o!'
    str_10 = "jwhg"
    str_11 = '&%`'
    str_12 = '&%`'
    str_13 = "^v0L"
    str_14 = "^v0L"
    str_15 = '&%`'

# Generated at 2022-06-24 17:55:21.062826
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = "Qx?j\tWz"
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    playbook_c_l_i_1.run()

# Generated at 2022-06-24 17:55:25.898447
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = "&S*?Jc%l\n\nY>ok"
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    playbook_c_l_i_1.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:43.632431
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '-N'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()



# Generated at 2022-06-24 17:55:48.874623
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # str_0 = '@MkN\n\n_+h;'
    # playbook_c_l_i_0 = PlaybookCLI(str_0)
    # var_0 = playbook_c_l_i_0.run()
    pass

# Test case for method run of class PlaybookCLI

# Generated at 2022-06-24 17:55:52.243982
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    with pytest.raises(AnsibleError) as e:
        test_case_0()
    assert 'Unable to open: MkN' in str(e.value)

# Generated at 2022-06-24 17:55:53.256166
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass


# Generated at 2022-06-24 17:55:55.080493
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:01.139154
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    sourceFile = 'test_PlaybookCLI_run.py'
    lineNumber = 10
    module = 'test_PlaybookCLI_run'
    assert (var_0 == 0), 'Failed test for method run of class PlaybookCLI in file %s on line %d' % (sourceFile, lineNumber)

# Generated at 2022-06-24 17:56:02.830293
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:06.845489
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("Testing run of PlaybookCLI")
    test_case_0()

if __name__ == '__main__':
    print("Running tests")
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:13.647538
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    testPlaybook = os.path.join(os.path.split(os.path.realpath(__file__))[0], "test/fixtures/playbooks/testPlaybook.yml")
    os.chmod(testPlaybook, stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH)
    sys.argv = ['ansible-playbook', testPlaybook]
    test_case_0()


if __name__ == '__main__':
    # PlaybookCLI.run()
    # Display.display(sys.argv)
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:14.935099
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-24 17:56:29.645836
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:31.054251
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('Unit test for method run of class PlaybookCLI')
    test_PlaybookCLI_run_0()

# Generated at 2022-06-24 17:56:36.299178
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  str_0 = '@MkN\n\n_+h;'
  playbook_c_l_i_0 = PlaybookCLI(str_0)
  var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:40.324541
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'Y<M^\x02:"g'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:47.302471
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Setup
    str_0 = '@MkN\n\n_+h;'
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # Invocation
    var_1 = playbook_c_l_i_0.run()

    # Testing assertions
    print('Assertion 1: %s' % str(var_0 == 0))



# Generated at 2022-06-24 17:56:48.130368
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    return None

# Generated at 2022-06-24 17:56:51.079543
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:56:56.306637
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '@MkN\n\n_+h;'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:59.299420
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '$z-\u0003v\u0019W8Q'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:57:03.173984
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 17:57:19.927611
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:24.530546
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '@MkN\n\n_+h;'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:57:27.712908
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


if __name__ == "__main__":

    # Unit tests for class PlaybookCLI
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:35.091957
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Test case where args is None

    str_0 = ' '
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.init_parser()
    var_0 = playbook_c_l_i_0.post_process_args(playbook_c_l_i_0.parser.parse_args((), namespace=playbook_c_l_i_0))
    var_1 = playbook_c_l_i_0.run()

    # Test case where args is a single argument

    str_1 = ' '
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    playbook_c_l_i_1.init_parser()
    var_2 = playbook_c_l_i_1.post_process

# Generated at 2022-06-24 17:57:36.432302
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:37.414850
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:39.203736
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
        return 'pass'
    except:
        return 'fail'

# Generated at 2022-06-24 17:57:43.426815
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '@MkN\n\n_+h;'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    str_1 = '@MkN\n\n_+h;'
    playbook_c_l_i_0.run(str_1)

# Generated at 2022-06-24 17:57:46.851527
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('Unit test for PlaybookCLI - run')
    test_case_0()
    print('Test passed')

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:48.733670
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:06.640535
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # initialize setup
    str_0 = ''
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # try calling the run function
    try:
        playbook_c_l_i_0.run()
    except SystemExit:
        pass

# Generated at 2022-06-24 17:58:07.737986
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:12.365262
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = '@MkN\n\n_+h;'
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    var_1 = playbook_c_l_i_1.run()


# Generated at 2022-06-24 17:58:14.592666
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli_cmd = 'echo "Hello"'
    playbook_cli = PlaybookCLI(playbook_cli_cmd)
    result = playbook_cli.run()
    assert result == 0

# Generated at 2022-06-24 17:58:25.641450
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('@MkN\n\n_+h;')
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:58:28.420529
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:31.745639
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Arrange
    str_0 = '@MkN\n\n_+h;'
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # Act
    playbook_c_l_i_0.run()

    # Assert


# Generated at 2022-06-24 17:58:33.278986
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:35.018062
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:35.672617
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:52.800846
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:53.968163
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# End of generated tests

# Generated at 2022-06-24 17:58:55.570501
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:56.569956
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:01.567000
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '@MkN\n\n_+h;'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    # var_0 is None
    assert var_0 == 0

# Generated at 2022-06-24 17:59:04.476753
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:06.945262
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = '=wZ='
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    var_1 = playbook_c_l_i_1.run()


# Generated at 2022-06-24 17:59:09.720694
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    var_0 = PlaybookCLI()
    var_1 = var_0.run()

# Using run_playbook to test module run

# Generated at 2022-06-24 17:59:11.034922
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:15.447585
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as err:
        print ("Caught exception: " + str(err))
        assert False

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:34.532761
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("\n###### Running tests for method run of class PlaybookCLI ######")
    test_case_0()
    print("\n###### Finished tests for method run of class PlaybookCLI ######")

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:43.013806
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Issue: https://github.com/ansible/ansible/issues/42649
    try:
        test_case_0()
    except SystemExit as e:
        if e.code:
            if e.code != 2:
                print('Expected 2 == e.code')
                return False
            if e.code != 1:
                print('Expected 1 == e.code')
                return False
            return True

    print('Expected SystemExit Exception')
    return False

# Main
if __name__ == "__main__":
    result = test_PlaybookCLI_run()
    if result == True:
        print('Test succeeded')
        exit(0)
    else:
        print('Test failed')
        exit(1)

# Generated at 2022-06-24 17:59:45.120282
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    var_0 = PlaybookCLI('p')
    var_0.run()


# Generated at 2022-06-24 17:59:50.088483
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '@MkN\n\n_+h;'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:59:51.406808
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:59:54.121530
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as err:
        print("Caught exception in unit test: %s" % err)
        assert False

# Generated at 2022-06-24 18:00:04.363665
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '5$J\\yh\n\x0b\x1b@XE[.\r\x1e\x02\t*\x0e\x1a\x1ds'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    try:
        var_0 = playbook_c_l_i_0.run()
    except SystemExit as exception_0:
        var_0 = exception_0

    var_1 = var_0.code


# Generated at 2022-06-24 18:00:15.295023
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    d = {}
    playbook_c_l_i_0 = PlaybookCLI('J\r`]')
    d[0] = playbook_c_l_i_0
    str_0 = 'F5<'
    str_1 = '~d'
    str_2 = ')u'
    str_3 = 'Cm'
    str_4 = 'Gc'
    str_5 = '$g'
    str_6 = 'k4'
    str_7 = 'I'
    str_8 = '\''
    str_9 = ':C'
    str_10 = '=O'
    str_11 = 'Tg'
    str_12 = '@E'
    str_13 = '_s'
    str_14 = '\x0b'
    str_15

# Generated at 2022-06-24 18:00:16.026445
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_unit_case_0()


# Generated at 2022-06-24 18:00:17.488944
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:57.946896
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:02.729105
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test case for the subcase when for case when the argument args is empty
    str_0 = '@MkN\n\n_+h;'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:01:15.054187
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    argv = [
        'ansible-playbook',
        '-i',
        '{{inventory}}',
        '-l',
        '{{subset}}',
        '-e',
        '@{{extra_vars}}',
        '--diff',
        '--check',
        '-s',
        '--flush-cache',
        '{{playbook_path}}'
    ]

# Generated at 2022-06-24 18:01:16.224971
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:21.939577
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create the class
    playbook_c_l_i_0 = PlaybookCLI("A_*h_")

    # set the class attribute 'args'
    playbook_c_l_i_0.args = '~xNw'

    # call the method
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:01:23.258594
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:26.737352
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI(int_0)
    var_0 = playbook_c_l_i_0.run()
    assert(var_0 == int_0)

# Generated at 2022-06-24 18:01:28.334717
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:34.438106
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except SystemExit as e:
        # An error occurred while fetching the resource.
        #
        # If a resource with the given name cannot be found,
        # ``get_resource`` returns ``None``.
        assert e.code == 0
    except Exception as e:
        print('Caught exception: %s' % e)
        assert False

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:01:35.667173
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    test_case_0()

# Generated at 2022-06-24 18:02:19.019509
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 18:02:20.183111
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:21.337133
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:24.612264
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '``&{-Lw'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:02:34.532403
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    
    test_PlaybookCLI_run_0()
    test_PlaybookCLI_run_1()
    test_PlaybookCLI_run_2()
    test_PlaybookCLI_run_3()
    test_PlaybookCLI_run_4()
    test_PlaybookCLI_run_5()
    test_PlaybookCLI_run_6()
    test_PlaybookCLI_run_7()
    test_PlaybookCLI_run_8()
    test_PlaybookCLI_run_9()
    test_PlaybookCLI_run_10()
    test_PlaybookCLI_run_11()
    test_PlaybookCLI_run_12()
    test_PlaybookCLI_run_13()
    test_PlaybookCLI_run_14()
    test

# Generated at 2022-06-24 18:02:38.146268
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('Testing PlaybookCLI.run')

    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:42.487581
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'pRgZ'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 is None


# Generated at 2022-06-24 18:02:44.657736
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'xGnW'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:02:45.493389
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert test_case_0() == None

# Generated at 2022-06-24 18:02:46.365307
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:03:28.155746
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

test_PlaybookCLI_run()

# Generated at 2022-06-24 18:03:30.524487
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except AssertionError as err:
        print('AssertionError: ', err.args)

# Generated at 2022-06-24 18:03:38.697018
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 18:03:40.482974
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


if __name__ == '__main__':

    import data.test_data_PlaybookCLI as test_data

    test_case_0()

# Generated at 2022-06-24 18:03:41.421432
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:03:42.564779
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:45.517608
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '@MkN\n\n_+h;'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    # Check if return value equals 0
    assert var_0 == 0

# Generated at 2022-06-24 18:03:50.165700
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '@MkN\n\n_+h;'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:03:51.651563
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = ''
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:03:52.581477
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()