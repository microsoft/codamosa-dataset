

# Generated at 2022-06-24 17:54:33.110910
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'has_sslcontext'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    int_0 = -2570
    hash_0 = {'algorithm': 'SHA256', 'is_stream': False, 'digest_size': 128, 'name': 'SHA256'}
    str_1 = 'has_sslcontext'
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    str_2 = 'operation not supported'
    dict_0 = {'beginning of the request body after ': 'a 100-continue response was received'}
    str_3 = 'has_sslcontext'
    playbook_c_l_i_2 = PlaybookCLI(str_3)
    str_4 = 'has_sslcontext'
    playbook_

# Generated at 2022-06-24 17:54:42.269385
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:54:48.034461
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Parameters
    percentage_failure = float(0)

    # Results
    result = test_case_0()
    if result == 'hello world':
        print('Success')
    else:
        print('Fail')

    # Return
    return  result == 'hello world'

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:49.421761
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Run analysis with Coverage to collect missing blocks
    test_case_0()

# Generated at 2022-06-24 17:54:53.489279
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'has_sslcontext'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    ret_0 = playbook_c_l_i_0.run()


if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:55.138880
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    try:
        test_case_0()
        assert True
    except:
        assert False

# Generated at 2022-06-24 17:54:58.076885
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    int_0 = -1


# Generated at 2022-06-24 17:55:05.116605
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'deprecate_hostname'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    str_1 = 'ansible'
    str_2 = 'get_diffstat'
    str_3 = 'self'
    str_4 = 'ansible'
    str_5 = '_'
    str_6 = 'varlib'
    str_7 = 'ansible'
    str_8 = '_'
    str_9 = 'varlib'
    str_10 = 'ansible'
    str_11 = '_'
    str_12 = 'varlib'
    str_13 = 'ansible'
    str_14 = 'get_diffstat'
    str_15 = 'ansible'
    str_16 = 'get_diffstat'

# Generated at 2022-06-24 17:55:11.872739
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'has_sslcontext'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    int_0 = -2570
    int_1 = test_case_0()
    int_2 = 0
    int_3 = int_0 + int_1
    int_4 = int_3 + int_2
    int_5 = int_4 + int_0
    int_6 = int_4 + int_4
    int_7 = int_4 + int_0

# Generated at 2022-06-24 17:55:25.287503
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:55:39.781043
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    int_0 = -1
    test_case_0()
    print(int_0)

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:45.272813
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_cli = PlaybookCLI()
    playbook_cli.post_process_args(0)
    playbook_cli.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:55:51.205667
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Init test case
    test_case_0()
    cli = PlaybookCLI()
    cli.options = '-vvvv'
    cli.args = ['playbook.yml']
    cli.run()

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:54.212484
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()
    cli.run()
    test_case_0()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:59.462500
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # pbex = PlaybookExecutor(playbooks=context.CLIARGS['args'], inventory=inventory,
    #                         variable_manager=variable_manager, loader=loader,
    #                         passwords=passwords)
    assert True


# Generated at 2022-06-24 17:56:10.560177
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # create default arguments
    options = context.CLIARGS
    options['listhosts'] = True
    options['listtasks'] = True
    options['listtags'] = True
    options['step'] = True
    options['start_at_task'] = 'setup'
    options['args'] = ['../test/test_playbook.yml']
    options['syntax'] = False
    options['connection'] = 'ssh'
    options['timeout'] = 10
    options['forks'] = 10
    options['become'] = True
    options['become_method'] = 'sudo'
    options['become_user'] = 'root'
    options['check'] = True
    options['diff'] = True
    options['private_key_file'] = 'test_rsa_key'
    options['remote_user']

# Generated at 2022-06-24 17:56:14.994339
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Tests if the method run of the class PlaybookCLI is called
    cli_1 = PlaybookCLI()
    cli_1.run()
    assert True == True

# Generated at 2022-06-24 17:56:27.701518
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    playbook_cli = PlaybookCLI()

    # test case 1:
    context.CLIARGS['subset'] = None
    context.CLIARGS['listhosts'] = False
    context.CLIARGS['listtasks'] = False
    context.CLIARGS['listtags'] = False
    context.CLIARGS['syntax'] = False
    context.CLIARGS['flush_cache'] = False
    context.CLIARGS['module_path'] = None
    context.CLIARGS['forks'] = 0
   

# Generated at 2022-06-24 17:56:30.265079
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbookcli = PlaybookCLI()
    playbookcli.init_parser()
    playbookcli.post_process_args(playbookcli)
    playbookcli.run()

# Generated at 2022-06-24 17:56:35.375294
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Initalize playbooks
    context.CLIARGS['args'] = ['playbook_test_0.yml']
    test_case_0()
    # Run
    PlaybookCLI().run()
    test_case_0()

# Generated at 2022-06-24 17:56:49.367496
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from test.unit.cli.test_cli import test_case_0
    # TODO: Check that the function returns a numeric value.
    return_value = test_case_0()
    assert isinstance(return_value, int)

# Generated at 2022-06-24 17:56:51.447440
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Unit tests for method run of class PlaybookCLI

# Generated at 2022-06-24 17:56:53.614073
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-24 17:56:55.161872
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:56.134901
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:56:57.143962
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:56:58.388107
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    exit_0 = [0]
    return exit_0

# Generated at 2022-06-24 17:57:01.549959
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:03.798592
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:57:06.338039
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()



# Generated at 2022-06-24 17:57:33.228988
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  test_case_0()

# Generated at 2022-06-24 17:57:38.346692
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()
    assert not var_0
    # FIXME: figure out how to test the case where the above return value is true


# Generated at 2022-06-24 17:57:39.138407
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:43.742576
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'has_sslcontext'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:47.554339
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("****** Unit test for method run of class PlaybookCLI ******") 
    test_case_0() # Test case for argument is_str
    print ("\n****** End ******")

# Generated at 2022-06-24 17:57:48.966007
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:50.275397
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    pass

# Generated at 2022-06-24 17:57:51.506602
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:52.608303
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:53.765733
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:22.634481
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:24.130842
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('test_PlaybookCLI_run')
    test_case_0()

# Generated at 2022-06-24 17:58:25.608258
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:26.492457
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:30.585284
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'has_sslcontext'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    ret = playbook_c_l_i_0.run()
    print("ret ", ret)

# Generated at 2022-06-24 17:58:42.237012
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    import pytest
    import sys
    import os
    import json
    import base64
    import shutil


# Generated at 2022-06-24 17:58:43.855990
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:45.207896
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:46.626522
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:47.720249
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:59.344821
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible import context
    import json

    # inventory to host groups
    loader = DataLoader()
    hosts = loader.load_from_file('/etc/ansible/hosts')
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=hosts)
    variable_manager.set_inventory(inventory)

    # text that will be in the playbook
    name = 'Ansible Playbook'

    # actual playbook

# Generated at 2022-06-24 18:00:03.370833
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from test_fixtures.test_outputs.output_0 import output_0

    # Output of the following command:
    #   ansible-playbook -i hosts --list-hosts playbook.yml
    # Result in file:
    #  test_fixtures/test_outputs/output_0
    assert output_0 == test_case_0()


# Generated at 2022-06-24 18:00:04.596218
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:05.934260
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:00:06.921751
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:13.470460
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    context.CLIARGS = {}
    context.CLIARGS['listtags'] = False
    context.CLIARGS['listtasks'] = False
    context.CLIARGS['subset'] = ''
    context.CLIARGS['flush_cache'] = False
    context.CLIARGS['args'] = ['haproxy.yml']

    # Temporary work-around to avoid loading collections automatically
    import ansible.config.manager
    AnsibleConfigManager = ansible.config.manager.ConfigManager
    config_manager = AnsibleConfigManager('/etc/ansible/ansible.cfg')
    config_manager._config.data['DEFAULT']['collect_ignored_extensions'] = ''
    config_manager._config.data['DEFAULT']['collections_path'] = ':memory:'

    test_

# Generated at 2022-06-24 18:00:14.655130
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:17.383639
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # test case 0
    try:
        test_case_0()
    except Exception as inst:
        print(inst)

# Generated at 2022-06-24 18:00:19.120494
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:20.268821
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:04.979629
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:11.174567
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_1 = PlaybookCLI('"has_sslcontext"')

    # Call method run of playbook_c_l_i
    var_1 = playbook_c_l_i_1.run()
    print('var_1 = {}\n'.format(var_1))



# Generated at 2022-06-24 18:03:21.255531
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    import os
    import stat
    import sys
    import traceback
    ansible_base_dir = os.getenv('ANSIBLE_BASE_DIR', '~/ansible')
    ansible_base_dir = os.path.expanduser(ansible_base_dir)
    ansible_base_dir = os.path.expandvars(ansible_base_dir)
    ansible_base_dir = os.path.abspath(ansible_base_dir)
    if not os.path.isdir(ansible_base_dir):
        raise AnsibleError("Specified ANSIBLE_BASE_DIR is not a directory")
    if ansible_base_dir not in sys.path:
        sys.path.insert(0, ansible_base_dir)

# Generated at 2022-06-24 18:03:22.326048
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:24.972364
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'has_sslcontext'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:03:27.162464
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI()
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:03:28.156235
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:03:37.243023
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

	# Setup test 1
	str_1 = 'test_case_0'
	playbook_c_l_i_1 = PlaybookCLI(str_1)
	str_1 = 'has_sslcontext'
	int_1 = playbook_c_l_i_1.run(str_1)
	assert int_1 == None

	# Setup test 2
	str_1 = 'test_case_0'
	playbook_c_l_i_1 = PlaybookCLI(str_1)
	str_1 = 'has_sslcontext'
	int_1 = playbook_c_l_i_1.run(str_1)
	assert int_1 == None


	# Setup test 3
	str_1 = 'test_case_0'
	playbook_c_l_i_1 = Play

# Generated at 2022-06-24 18:03:38.981780
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:03:39.748660
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  test_case_0()