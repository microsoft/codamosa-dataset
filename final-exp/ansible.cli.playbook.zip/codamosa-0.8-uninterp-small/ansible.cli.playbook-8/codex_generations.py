

# Generated at 2022-06-24 17:54:30.605407
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Set up mock objects
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # Invoke method
    result = playbook_c_l_i_0.run()
    assert result == 0

# Generated at 2022-06-24 17:54:31.720160
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 17:54:34.510006
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    test_case_0()

main = test_PlaybookCLI_run

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 17:54:37.941954
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:54:43.526519
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:54:44.441423
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-24 17:54:54.696866
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    bash_0 = 'wVy_o'
    str_1 = 'QF&:df'
    str_2 = 'T#[-D'
    str_3 = 'iLR(9'
    str_4 = 'ZXjK#'
    str_5 = 'pVwY*'
    str_6 = '$rH>V'
    str_7 = '7_x;A'
    str_8 = 'k6,^`X'
    str_9 = '8[g_C'
    str_10 = 'K,W8\"v1'
    str_11 = 'h]<E'
    str_12 = 'QF&:df'
    str_13 = 'T#[-D'
    str_14 = 'iLR(9'

# Generated at 2022-06-24 17:55:10.398759
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
  str_1 = 'hdfjdshjhfj'
  str_2 = 'kjfhjds'
  str_3 = 'dsfkjhj'
  s_list_t_1 = [str_1, str_2, str_3]
  dict_2 = dict(zip(s_list_t_1, s_list_t_1))
  str_4 = 'kjfdhj'
  str_5 = 'dsjfhjds'
  str_6 = 'kfdjsh'
  s_list_t_2 = [str_4, str_5, str_6]
  dict_3 = dict(zip(s_list_t_2, s_list_t_2))
  dict_2['-C'] = dict_3

# Generated at 2022-06-24 17:55:13.645715
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    int_0 = playbook_c_l_i_0.run()
    assert int_0 == 0


# Generated at 2022-06-24 17:55:26.248168
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli_args = dict(
        ask_pass=False,
        ask_vault_pass=False,
        connection='local',
        forks=0,
        listhosts=False,
        listtags=False,
        listtasks=False,
        module_path=None,
        become=False,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        extra_vars=[],
        flush_cache=False,
        inventory=None,
        syntax=False,
        tags=[],
        skip_tags=[],
        verbosity=0,
        start_at_task=None,
        step=False,
        subset=None,
        vault_password_file=None,
        args=[]
    )

    # TEST CASES

   

# Generated at 2022-06-24 17:55:43.257731
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'N(5O5U@2'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 is None


# Generated at 2022-06-24 17:55:45.988324
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
        assert False


if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:49.319282
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    arg = 'P38F8D'
    ret = PlaybookCLI(arg).run()

    assert ret == 0

# Generated at 2022-06-24 17:55:51.164343
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:55:52.687266
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert test_case_0() == 0


# Generated at 2022-06-24 17:55:53.734476
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()



# Generated at 2022-06-24 17:55:54.652415
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert test_case_0() == 0

# Generated at 2022-06-24 17:56:00.042696
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:56:05.153934
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    # Using value for str_0.
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:06.583942
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    exit(0)

# Generated at 2022-06-24 17:56:23.607499
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:56:26.270898
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create a PlaybookCLI object
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # Run the method
    var_0 = playbook_c_l_i_0.run()
    assert var_0 is None


# Generated at 2022-06-24 17:56:27.490493
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:28.777121
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:29.645897
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:32.511889
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('j"-. #Nw72')
    assert(playbook_c_l_i_0 is not None)
    try:
        playbook_c_l_i_0.run()
    except SystemExit as e:
        assert(e.code == 0)

# Generated at 2022-06-24 17:56:39.548393
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Initialize the class
    str_0 = '6U@1mZpz6GoE'
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # Run the method
    var_1 = playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:56:44.804155
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except:
        print("Exception Raised - test_PlaybookCLI_run")

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:46.780290
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    var_0 = 'X9'
    test_case_0()


# Generated at 2022-06-24 17:56:48.002853
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:03.800219
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:10.634874
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_1 = PlaybookCLI()
    str_2 = 'j"-. #Nw72'
    result = playbook_c_l_i_1.run(str_2)
    str_2 = ';OO M L^'
    var_1 = playbook_c_l_i_1.run(str_2)


# Generated at 2022-06-24 17:57:14.044065
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:57:14.908522
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:15.761346
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:20.418885
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert(var_0 == 0)



# Generated at 2022-06-24 17:57:21.757322
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:25.682862
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '8Wy5Ph5v'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0.run()


# Generated at 2022-06-24 17:57:30.178970
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except:
        print('Error in %s' % (sys.exc_info()[0].__name__))
        raise
    else:
        print('%s ran successfully' % (sys.exc_info()[0].__name__))

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:32.189028
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:57:46.851542
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Tests for ansible-playbook --list-tags
    test_case_0()

# Generated at 2022-06-24 17:57:50.596679
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Define input variables

    # Invocate method 
    ansible_playbook_0 = PlaybookCLI(args=None)
    var_0 = ansible_playbook_0.run()

    # Check the results of the method
    assert var_0 == 0

# Generated at 2022-06-24 17:57:51.956870
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:53.592315
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print('Testing method run')
    test_case_0()


# Generated at 2022-06-24 17:57:57.928646
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:00.153900
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'g;Gs7*Sf>'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()



# Generated at 2022-06-24 17:58:01.918745
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    t_0 = PlaybookCLI()
    t_0.run()


# Generated at 2022-06-24 17:58:04.969862
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = 'r9i(Z0MP"$#'
    result = PlaybookCLI(str_1)
    assert result.run() is None


# Generated at 2022-06-24 17:58:06.405135
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:08.812884
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except SystemExit as e:
        pass
    except:
        raise

# Generated at 2022-06-24 17:58:23.310088
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print (test_case_0())

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:58:24.416921
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:58:27.396781
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:58:28.337825
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:33.934381
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Test 1: Normal conditions
    try:
        test_case_0()
    except Exception as err:
        assert False, err

    # Test 2: Exception conditions
    try:
        assert False, "Unreachable"
    except Exception as err:
        assert True, err

if __name__ == '__main__':
    # Test 1: Normal conditions
    try:
        test_case_0()
    except Exception as err:
        print(err)

    # Test 2: Exception conditions
    try:
        assert False, "Unreachable"
    except Exception as err:
        print(err)

# Generated at 2022-06-24 17:58:39.917483
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    test_case_0()

if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v", "-s"])

# Generated at 2022-06-24 17:58:41.732786
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:48.746326
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:58:52.681547
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:58:53.865269
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:59:12.306723
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert True == True

# Generated at 2022-06-24 17:59:13.138850
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-24 17:59:18.479838
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'EFaN$1}x/R/#/X9!Dj.k?6'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:59:22.053876
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as exception_0:
        exception_0.__traceback__ = None
        raise exception_0

# Generated at 2022-06-24 17:59:26.836014
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Expected values
    expected_var = 0

    # We use the test_case function to calculate the variables
    test_case_0()

    # We obtain the values
    var = var_0

    # Check the value of our variables
    assert var == expected_var

# Generated at 2022-06-24 17:59:30.245798
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0

# Generated at 2022-06-24 17:59:31.173450
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:31.886760
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Generate an exception
    test_case_0()

# Generated at 2022-06-24 17:59:34.192168
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    test_case_0()

# Generated at 2022-06-24 17:59:40.091083
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("\ntest_PlaybookCLI_run")
    # This will raise an error because the arguments are wrong.
    # We're not testing parsing here.
    try:
        test_case_0()
    except AnsibleError:
        print("AnsibleError detected")

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:56.322749
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except:
        pass

# Generated at 2022-06-24 18:00:00.085479
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('$\t1\x14\x01\x17\x0f\x03\x0e\x1e-W\x1c')
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:00:04.423982
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI(str('`6,g))6sIq[4#'))
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:00:09.986507
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'PI2(Nn-n+'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:00:12.277478
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('rB^')
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:00:13.582453
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:14.799096
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:16.360838
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:20.485048
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:00:21.293390
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:00:46.884227
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '|W8'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    #assert playbook_c_l_i_0.run() == 0


# Generated at 2022-06-24 18:00:48.636980
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:49.342070
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:00:56.767792
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        str_0 = 'j"-. #Nw72'
        playbook_c_l_i_0 = PlaybookCLI(str_0)
        test_case_0()
    except:
        print("Exception caught: ", sys.exc_info()[0])
        raise



# Generated at 2022-06-24 18:01:05.054691
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '_6M(z~iu|'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    var_0 = playbook_c_l_i_0.run()
    str_0 = '='
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    var_0 = playbook_c_l_i_0.run()
    str_0 = 'LTy7'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:01:12.136840
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI('y.= Q>bf9j')
    try:
        playbook_c_l_i_0.run()
    except KeyboardInterrupt:
        pass
    except:
        raise AssertionError

# Generated at 2022-06-24 18:01:15.118471
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:01:20.672869
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

test_case_0()
test_PlaybookCLI_run()

# Generated at 2022-06-24 18:01:24.111624
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    var_0 = './tests/test_playbook_cli.py'
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_1 = playbook_c_l_i_0.run()
    assert var_1 == 0
    assert var_0 != ''

# Generated at 2022-06-24 18:01:25.306234
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:01:45.813945
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:48.575702
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()
    return 0


# Generated at 2022-06-24 18:01:49.764150
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:50.973609
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:52.863835
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("test_PlaybookCLI_run(): START")
    test_case_0()
    print("test_PlaybookCLI_run(): END")

# Generated at 2022-06-24 18:01:53.761744
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:01:54.539663
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:02:03.452573
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import tempfile, os
    with tempfile.NamedTemporaryFile(mode='w+') as f:
        f.write('some test input text')
        f.flush()
        os.environ['ANSIBLE_INVENTORY'] = f.name
        str_0 = 'tAaDl'
        playbook_c_l_i_0 = PlaybookCLI(str_0)
        assert playbook_c_l_i_0.run() == 0

# Generated at 2022-06-24 18:02:05.071917
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:02:06.309187
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:02:34.917966
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    options_0 = dict()
    options_0['listtasks'] = False
    options_0['syntax'] = False
    options_0['connection'] = 'local'
    options_0['module_path'] = None
    options_0['forks'] = 5
    options_0['remote_user'] = None
    options_0['private_key_file'] = None
    options_0['ssh_common_args'] = None
    options_0['ssh_extra_args'] = None
    options_0['sftp_extra_args'] = None
    options_0['scp_extra_args'] = None
    options_0['become'] = False
    options_0['become_method'] = None
    options_0['become_user'] = None
    options_0['verbosity'] = 0


# Generated at 2022-06-24 18:02:35.703395
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:02:43.004783
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    #
    # Declarations of variables
    #
    _str_0 = ' ./[-T6w3=6D*U6'
    _playbook_c_l_i_0 = PlaybookCLI(_str_0)
    #
    # Execution of code
    #
    _playbook_c_l_i_0.run()
    #
    # Verification of assertions
    #
    assert play_book_c_l_i_0._flush_cache()

# Generated at 2022-06-24 18:02:45.720861
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)

    # Call method run of playbook_c_l_i_0
    test_case_0()

# Generated at 2022-06-24 18:02:48.034027
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args_0 = '--flush-cache --list-tasks playbook.yml'
    var_0 = PlaybookCLI(args_0)
    var_0.run()
    print('Unit test 1')


# Generated at 2022-06-24 18:02:50.046493
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except Exception as e:
        display.error(str(e))
        return False
    else:
        return True

# Generated at 2022-06-24 18:02:53.880593
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:03:00.344623
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # No such file or directory
    str_1 = 'playbook'
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    var_1 = playbook_c_l_i_1.run()
    # is not a playbook
    str_2 = 'playbook.yml'
    playbook_c_l_i_2 = PlaybookCLI(str_2)
    var_2 = playbook_c_l_i_2.run()
    # playbook exists and is a regular file
    str_3 = 'tests/units/action_plugins/script/'
    playbook_c_l_i_3 = PlaybookCLI(str_3)
    var_3 = playbook_c_l_i_3.run()
    # another playbook tests

# Generated at 2022-06-24 18:03:13.352580
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    from unittest.mock import MagicMock, patch

    # Arrange
    str_0 = 'D>|g`~{'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    playbook_c_l_i_0._flush_cache = MagicMock()
    playbook_c_l_i_0._play_prereqs = MagicMock()
    playbook_c_l_i_0._play_prereqs.return_value = (None, None, None)
    playbook_c_l_i_0.loader = MagicMock()
    playbook_c_l_i_0.loader.return_value = None
    playbook_c_l_i_0.inventory = MagicMock()

# Generated at 2022-06-24 18:03:18.034670
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '1`Q\tW(MMs'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0


# Generated at 2022-06-24 18:03:40.612821
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_1 = '~.7d_?,3+m'
    playbook_c_l_i_1 = PlaybookCLI(str_1)
    var_1 = playbook_c_l_i_1.run()


# Generated at 2022-06-24 18:03:41.575169
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()


# Generated at 2022-06-24 18:03:44.322823
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '$PH`YG`l*'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:03:45.578549
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 18:03:48.369542
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:03:52.023492
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'j"-. #Nw72'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:03:55.999870
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'f#%]O5C5{8qD@q'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:03:59.739848
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = '[a*<'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:04:06.953972
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # setup
    str_0 = '?'
    playbook_c_l_i_0 = PlaybookCLI(str_0)
    # testing
    test_case_0()
    # cleanup
    os.remove('./playbook.yml')
    return playbook_c_l_i_0

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 18:04:09.283482
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()