

# Generated at 2022-06-24 17:54:31.756731
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    int_0 = 682
    playbook_c_l_i_0 = PlaybookCLI(int_0)
    playbook_c_l_i_0.post_process_args(True)
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 17:54:38.152725
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Arrange
    d_0 = dict()
    d_1 = dict()
    pb_ex_1 = PlaybookExecutor(d_0, d_1)
    test_case_0()
    # Act
    result_0 = PlaybookCLI.run(pb_ex_1)
    # Assert
    c_0 = isinstance(result_0, int)
    assert c_0

# Generated at 2022-06-24 17:54:40.297929
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:43.450050
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    int_1 = 700
    playbook_c_l_i_1 = PlaybookCLI(int_1)
    try:
        playbook_c_l_i_1.run()
    except Exception as exception:
        raise AssertionError()


# Generated at 2022-06-24 17:54:48.092720
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    output_0 = 'ansible-playbook "playbook.yml"'
    assert PlaybookCLI.run(PlaybookCLI) == output_0, 'Expected different output from \'ansible-playbook "playbook.yml"\''

# Generated at 2022-06-24 17:54:52.613937
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # This is a simple test to check if it is possible to run the method run without passing any parameters
    # If the method does not need any parameters to be passed, you can use this test
    int_0 = 681
    playbook_c_l_i_0 = PlaybookCLI(int_0)
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 17:54:54.203358
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:54:58.944515
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    int_0 = PlaybookCLI(680)
    int_0.post_process_args({'listhosts': False, 'listtags': False, 'syntax': False, 'check': False, 'listtasks': False})
    int_0.run()

# For python3.7, see https://github.com/python/mypy/issues/5374
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:55:01.729743
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:06.864939
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    int_0 = 680
    playbook_c_l_i_0 = PlaybookCLI(int_0)
    playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:19.680892
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:26.586931
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    arguments = ['playbook.yml']
    options = C.config.parse_options(args=arguments)

    # create base objects
    loader, inventory, variable_manager = PlaybookCLI._play_prereqs()

    # initial error check, to make sure all specified playbooks are accessible
    # before we start running anything through the playbook executor
    # also prep plugin paths
    b_playbook_dirs = []
    for playbook in arguments:

        # resolve if it is collection playbook with FQCN notation, if not, leaves unchanged
        resource = _get_collection_playbook_path(playbook)
        if resource is not None:
            playbook_collection = resource[2]
        else:
            # not an FQCN so must be a file
            if not os.path.exists(playbook):
                raise Ansible

# Generated at 2022-06-24 17:55:36.823872
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli_args = {'listhosts': False, 'syntax': False, 'check': False, 'listtags': False, 'step': False, 'vault_password_file': '/home/huang/play/playbook.yml', 'start_at_task': False, 'tags': [], 'listtasks': False, 'subset': False, 'ask_vault_pass': False, 'args': ['/home/huang/play/playbook.yml']}
    ctx = context.CLIARGS = cli_args
    ctx.pop('args', None)
    import ansible
    ctx['VERSION'] = ansible.__version__
    ctx['help'] = None

# Generated at 2022-06-24 17:55:47.520970
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    rules = parse_rule("ansible-playbook 'playbook.yml'")
    assert len(rules) == 1
    expected = new_obj("ansible-playbook 'playbook.yml'", "ansible-playbook 'playbook.yml'")
    for i in rules:
        actual = i
        assert expected == actual

    rules_1 = parse_rule("ansible-playbook --module-path /home/ansible/modules 'playbook.yml'")
    assert len(rules_1) == 1
    expected_1 = new_obj("ansible-playbook --module-path /home/ansible/modules 'playbook.yml'",
                         "ansible-playbook --module-path /home/ansible/modules 'playbook.yml'")

# Generated at 2022-06-24 17:55:52.471593
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'ansible-playbook "playbook.yml"'


# Unit test entry
if __name__ == "__main__":
    PlaybookCLI().run()

    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:55:55.077729
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI().run()

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:00.316941
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("Test PlaybookCLI run")

    # Setup unit test
    ansible_args = [
        "--version"
    ]
    cli = PlaybookCLI(args=ansible_args)
    cli.run()

# Generated at 2022-06-24 17:56:06.523328
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'ansible-playbook "playbook.yml"'
    cli = PlaybookCLI(args=str_0)
    cli._play_prereqs()
    cli.run()

if __name__ == "__main__":
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:08.539715
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print("Test: run")
    #playbook_cli = PlaybookCLI(context)
    #playbook_cli.run()
    test_case_0()

# Generated at 2022-06-24 17:56:10.987622
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Try to parse the arguments
    args = PlaybookCLI.parse( argv=test_case_0() )
    # Call main function
    main( args )

if __name__ == '__main__':
    main()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:56:22.729684
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    c_0 = PlaybookCLI()
    c_0.run()


# Generated at 2022-06-24 17:56:33.530393
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = ''
    to_bytes_0 = str_0.encode()
    from ansible.cli import CLI
    from ansible.errors import AnsibleError
    from ansible.playbook.play import Play

    to_bytes_1 = str_0.encode()
    Play_0 = Play()
    Play_0.name = to_bytes_1
    Play_0.hosts = to_bytes_1


# Generated at 2022-06-24 17:56:35.233684
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:56:47.862389
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Initialize a temporary directory
    import tempfile
    temp_dir = tempfile.mkdtemp()

    # Initialize the argument specifications
    arg_spec = dict(
        connection='local',
        forks=100,
        inventory='/etc/ansible/hosts',
        module_path='/home/test/ansible/lib/ansible/modules',
        partial_vars=True,
        playbook='/home/test/ansible/my_playbook.yml',
        private_key_file='/etc/ansible/ssh_keys/ansible',
        step=False,
        syntax=False,
        verbosity=True
    )

    # Initialize the instances of class PlaybookCLI
    playbook_cli_instance = PlaybookCLI(**arg_spec)

    # Invoke method run of class Play

# Generated at 2022-06-24 17:56:51.637855
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Create an instance of option parser for method run of class PlaybookCLI
    options = optparse.OptionParser()

    # Create an instance of PlaybookCLI
    cli = PlaybookCLI()

    # Create an instance of AnsibleCLI
    options, args = cli.parse()

# Generated at 2022-06-24 17:57:00.955157
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli_arguments = ['ansible-playbook', 'playbook.yml']
    display.verbosity = 4
    cli_args = {}
    for x in cli_arguments[1:]:
        if x.split('=')[0] in ['-h', '--help']:
            usage()
            sys.exit(0)
        if x.split('=')[0] in ['-v', '--version']:
            version()
            sys.exit(0)
        if x.startswith('@'):
            cli_args = load_extra_vars(cli_args, x)
            continue
        if x.split('=')[0] in ['--extra-vars', '-e']:
            cli_args = load_extra_vars(cli_args, x)

# Generated at 2022-06-24 17:57:02.413167
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbookcli = PlaybookCLI()
    playbookcli.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:57:07.517831
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # zero argument
    test_case_0()
    # one argument
    # two arguments
    # three arguments
    # four arguments
    # five arguments
    # six arguments


# Generated at 2022-06-24 17:57:13.329606
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pb = PlaybookCLI()
    print(type(pb))
    print(dir(pb))
    # print pb.run(pb)
    print(pb.run())

if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:16.070547
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    arg_tuple =  tuple()

    test_obj = PlaybookCLI(arg_tuple)
    test_obj.run()

test_case_0()
test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:26.514650
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:57:29.114816
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    res = PlaybookCLI().run()
    print (res)

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:33.428857
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    command = 'ansible-playbook --list-hosts "playbook.yml"'
    #str_0 = subprocess.check_output(command)
    str_0 = '\nplaybook: playbook.yml\n  play #1 (): ***\n    pattern: all\n    hosts (1):\n      192.168.1.102\n      192.168.1.101\n'
    assert str_0

# Generated at 2022-06-24 17:57:35.638044
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI([])
    cli.run()

# Generated at 2022-06-24 17:57:46.572990
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-24 17:57:53.539893
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Test with git repo
    from ansible_collections.ansible_collections.playbook_tests.playbook_cli.playbook_cli import AnsibleCollectionCLI
    collection = "playbook_cli"
    git_uri = "https://github.com/jumpserver/ansible-collections-playbook_cli.git"
    git_branch = "master"
    cli = AnsibleCollectionCLI(collection, git_uri, git_branch)
    cli.install()
    cli.run('test_case_0')

# Generated at 2022-06-24 17:57:55.806495
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    print(inspect.getsource(PlaybookCLI.run))


# call function
test_PlaybookCLI_run()

# Generated at 2022-06-24 17:57:57.758430
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pbcli = PlaybookCLI()
    pbcli.run()


# Generated at 2022-06-24 17:58:01.902285
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    obj = PlaybookCLI()
    obj.run()

# Generated at 2022-06-24 17:58:14.192485
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    argv = ["ansible-playbook", "playbook.yml"]
    with patch.object(PlaybookCLI, 'post_process_args') as mock_post_process_args, \
            patch.object(PlaybookCLI, '_play_prereqs') as mock__play_prereqs, \
            patch.object(PlaybookCLI, 'ask_passwords') as mock_ask_passwords, \
            patch.object(CLI, 'get_host_list') as mock_get_host_list, \
            patch.object(PlaybookExecutor, 'run') as mock_run:
        cli = PlaybookCLI(args=argv)
        cli.run()
        assert mock_post_process_args.called
        assert mock__play_prereqs.called
        assert mock_ask

# Generated at 2022-06-24 17:58:39.646975
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # TODO: Implement actual unit test.
    assert True

# Generated at 2022-06-24 17:58:44.383542
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Instantiate an instance of PlaybookCLI to test
    pbcli = PlaybookCLI() 
    # Check that the run() method yields the expected value
    assert pbcli.run() == 0

# Generated at 2022-06-24 17:58:48.889442
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    context.CLIARGS['args'] = ['playbook.yml']
    PlaybookCLI.run(PlaybookCLI())

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:58:49.988983
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    p = PlaybookCLI()
    p.run()

# Generated at 2022-06-24 17:58:52.940604
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    """
    Define the test cases to run for method PlaybookCLI.run
    """
    
    # Test 1: Basic test
    def test_1():
        str_1 = 'ansible-playbook "playbook.yml"'

# Generated at 2022-06-24 17:58:57.016289
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    def test_case_0():
        test_args = '-k -K -u user -v --ask-vault-pass playbook.yml'
        cli = PlaybookCLI(["playbook", '-k', '-K', '-u', 'user', '-v', '--ask-vault-pass', 'playbook.yml'])
        cli._play_prereqs = test_play_prereqs
        cli.run()

    test_case_0()


# Generated at 2022-06-24 17:58:59.737316
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()
    cli.run()

test_case_0()

# Generated at 2022-06-24 17:59:02.033799
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Run the method PlaybookCLI.run() with one argument
    PlaybookCLI.run(test_case_0())

# Generated at 2022-06-24 17:59:07.813193
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    argv_0 = ['ansible', '-m', 'shell', '-a', 'echo 1', '-b', '-k', '--ask-become-pass', '-K', '--ask-pass', 'localhost']
    CLI.parse(argv_0)
    test_PlaybookCLI = PlaybookCLI(
    )
    test_PlaybookCLI.run()


# Generated at 2022-06-24 17:59:15.297393
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    str_0 = 'ansible-playbook "playbook.yml"'

if __name__ == "__main__":
    cli = PlaybookCLI(args="playbook.yml".split(" "))
    # cli.parse()
    cli.post_process_args()
    # cli.run()
    cli._play_prereqs()
    # cli.ask_passwords()

# Generated at 2022-06-24 17:59:51.832677
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    try:
        test_case_0()
    except (TypeError, SystemError, KeyError, ValueError, AttributeError, ImportError, IndexError,
            SyntaxError, UnicodeDecodeError, UnicodeEncodeError) as ex:
        print(ex)
        test_result = 1
    assert test_result == 0


if __name__ == "__main__":
    test_PlaybookCLI_run()

# Generated at 2022-06-24 17:59:54.448845
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 588.37
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    var_0 = playbook_c_l_i_0.init_parser()
    var_0 = playbook_c_l_i_0.post_process_args(var_0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:00:04.393694
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 1282.603
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.init_parser()
    playbook_c_l_i_0.parse()
    var_0 = playbook_c_l_i_0.post_process_args()
    playbook_c_l_i_0.run()

if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-24 18:00:06.225558
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert PlaybookCLI(0.1).run() is None

# Generated at 2022-06-24 18:00:11.201999
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 9802.3833
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    var_0 = playbook_c_l_i_0.run()


# Generated at 2022-06-24 18:00:14.427215
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # initialization
    p_c_l_i_1 = PlaybookCLI(1.10)
    p_c_l_i_1.init_parser()
    p_c_l_i_1.post_process_args()
    p_c_l_i_1.run()

# Generated at 2022-06-24 18:00:15.984713
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    assert isinstance(PlaybookCLI.run(), list)

# Generated at 2022-06-24 18:00:20.596835
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 715.89
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    result_0 = playbook_c_l_i_0.run()
    assert result_0 == 0

# Generated at 2022-06-24 18:00:21.417412
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    test = PlaybookCLI
    test.run()

# Generated at 2022-06-24 18:00:24.773164
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 1282.603
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    var_0 = playbook_c_l_i_0.run()

if __name__ == '__main__':
    test_PlaybookCLI_run()
    #test_case_0()

# Generated at 2022-06-24 18:01:52.823992
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 374.79
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    bool_0 = playbook_c_l_i_0.run()



# Generated at 2022-06-24 18:01:55.315719
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI(1282.603)
    var_0 = playbook_c_l_i_0.init_parser()
    var_1 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:02:01.970950
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 1282.603
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    var_1 = playbook_c_l_i_0.run()
    assert var_1 is not None
    assert isinstance(var_1, int)


# Generated at 2022-06-24 18:02:03.126385
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    PlaybookCLI.run(PlaybookCLI)

# Generated at 2022-06-24 18:02:14.353290
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_1 = 1282.603
    playbook_c_l_i_1 = PlaybookCLI(float_1)

# Generated at 2022-06-24 18:02:21.590479
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 1282.603
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.init_parser()
    var_0 = playbook_c_l_i_0.post_process_args(playbook_c_l_i_0)
    var_0 = playbook_c_l_i_0.run()
    assert var_0 == 0

if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-24 18:02:22.986518
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI(None)
    result_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:02:24.596863
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    playbook_c_l_i_0 = PlaybookCLI(0.0)
    var_0 = playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:02:31.457164
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 1282.603
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    playbook_c_l_i_0.init_parser()
    playbook_c_l_i_0.parse()
    playbook_c_l_i_0.post_process_args()
    playbook_c_l_i_0.run()

# Generated at 2022-06-24 18:02:37.687525
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    float_0 = 1220.519
    playbook_c_l_i_0 = PlaybookCLI(float_0)
    result = playbook_c_l_i_0.run()


if __name__ == '__main__':
    test_case_0()
    test_PlaybookCLI_run()