

# Generated at 2022-06-22 18:59:26.955005
# Unit test for method run of class PlaybookCLI

# Generated at 2022-06-22 18:59:35.492626
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Create an instance of class PlaybookCLI
    cli = PlaybookCLI()
    cli.init_parser()
    parser = cli.parser
    assert parser is not None
    assert parser._optionals._actions[0].dest == 'connection'
    assert parser._optionals._actions[1].dest == 'module_path'
    assert parser._optionals._actions[2].dest == 'forks'
    assert parser._optionals._actions[3].dest == 'remote_user'
    assert parser._optionals._actions[4].dest == 'private_key_file'
    assert parser._optionals._actions[5].dest == 'ssh_common_args'
    assert parser._optionals._actions[6].dest == 'ssh_extra_args'

# Generated at 2022-06-22 18:59:39.580883
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    assert cli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert cli.parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'

# Generated at 2022-06-22 18:59:44.830873
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # Setup test data
    args = ['--list-tasks']
    cli = PlaybookCLI(args)

# Generated at 2022-06-22 18:59:47.717384
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    """
    :return: PlaybookCLI instance
    """
    instance = PlaybookCLI()
    assert isinstance(instance, PlaybookCLI) is True

# Unit test if _flush_cache() raises error

# Generated at 2022-06-22 18:59:49.378511
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pb = PlaybookCLI([])
    # TODO: Add more tests

# Generated at 2022-06-22 18:59:59.941677
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(['playbook.yml', 'pb1.yml'])
    cli.parse()
    assert context.CLIARGS['listhosts'] is False
    assert context.CLIARGS['listtasks'] is False

    context.CLIARGS = {}
    cli = PlaybookCLI(['-l', 'playbook.yml', 'pb1.yml'])
    cli.parse()
    assert context.CLIARGS['listhosts'] is True

    context.CLIARGS = {}
    cli = PlaybookCLI(['--list-tasks', 'playbook.yml', 'pb1.yml'])
    cli.parse()
    assert context.CLIARGS['listtasks'] is True


# Generated at 2022-06-22 19:00:11.288083
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible import constants as C
    from ansible.cli.arguments import CLIArgumentParser
    from ansible.cli.playbook import PlaybookCLI

    optparse = CLIArgumentParser('')
    opts = optparse.parse_args([])[0]

    pb = PlaybookCLI(parser=optparse, args=[], runas_opts=True, vault_opts=True, fork_opts=True)
    pb._add_options(optparse)
    options, args = optparse.parse_args([])

    pb.post_process_args(options=options)
    assert C.DEFAULT_FORKS == 10


# Generated at 2022-06-22 19:00:23.347921
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Initialize the play
    play = PlaybookCLI()

    # Initialize the option parser
    play.init_parser()

    # Check if the parser arguments are correct
    assert play.parser._option_string_actions['--list-tasks'] is not None
    assert play.parser._option_string_actions['--list-tags'] is not None
    assert play.parser._option_string_actions['--step'] is not None
    assert play.parser._option_string_actions['--start-at-task'] is not None
    assert play.parser._option_string_actions['--syntax-check'] is not None
    assert play.parser._option_string_actions['--connection'] is not None
    assert play.parser._option_string_actions['--timeout'] is not None

# Generated at 2022-06-22 19:00:28.930483
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI(['my_playbook.yml'])
    assert len(cli.parser._actions) == 13
    assert len(cli.parser._actions[1].option_strings) == 2
    assert cli.parser._actions[1].dest == 'listhosts'
    cli.parse()
    cli.post_process_args(cli.args)
    assert cli.args.listhosts


# Generated at 2022-06-22 19:00:32.320428
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    '''
    unit test for constructor of class PlaybookCLI
    '''
    cli = PlaybookCLI()
    test = isinstance(cli, CLI)
    assert test is True

# Generated at 2022-06-22 19:00:33.335030
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    try:
        PlaybookCLI()
    except Exception:
        pass

# Generated at 2022-06-22 19:00:39.781748
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    test_instance_PlaybookCLI = PlaybookCLI(['ansible-playbook'])
    # test_instance_PlaybookCLI.init_parser()
    assert test_instance_PlaybookCLI.parser is not None

    # Unit test for method run of class PlaybookCLI

# Generated at 2022-06-22 19:00:43.882372
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class TestCLI(object):
        def __init__(self, args):
            self.args = args

        def run(self):
            return self.args

    test_cli = TestCLI(42)

    assert PlaybookCLI().run(test_cli) == 42

# Generated at 2022-06-22 19:00:55.255453
# Unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-22 19:01:07.746570
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    """ Unit test for method init_parser of class PlaybookCLI """

    parser = PlaybookCLI('/dev/null', '/dev/null', '/dev/null').init_parser()
    opt_help.add_connect_options(parser)
    opt_help.add_meta_options(parser)
    opt_help.add_runas_options(parser)
    opt_help.add_subset_options(parser)
    opt_help.add_check_options(parser)
    opt_help.add_inventory_options(parser)
    opt_help.add_runtask_options(parser)
    opt_help.add_vault_options(parser)
    opt_help.add_fork_options(parser)
    opt_help.add_module_options(parser)

# Generated at 2022-06-22 19:01:18.316869
# Unit test for method init_parser of class PlaybookCLI

# Generated at 2022-06-22 19:01:20.132294
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    """This is a fake test function to test the constructor of class PlaybookCLI"""


# Generated at 2022-06-22 19:01:26.653137
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Note: there are tests for arg parsing in functional/test_cli.py

    from ansible.cli import CLI

    p = PlaybookCLI(args=[])
    options = p.parse()
    options = p.post_process_args(options)
    assert options.verbosity == 0

    p = PlaybookCLI(args=['-v'])
    options = p.parse()
    options = p.post_process_args(options)
    assert options.verbosity == 1

    p = PlaybookCLI(args=['-vvvvv'])
    options = p.parse()
    options = p.post_process_args(options)
    assert options.verbosity == 5

    p = PlaybookCLI(args=['-v', '-q'])
    options = p.parse()
    options = p

# Generated at 2022-06-22 19:01:38.814773
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    def option_helpers_mock():
        opt_help.add_connect_options = lambda x: None
        opt_help.add_meta_options = lambda x: None
        opt_help.add_runas_options = lambda x: None
        opt_help.add_subset_options = lambda x: None
        opt_help.add_check_options = lambda x: None
        opt_help.add_inventory_options = lambda x: None
        opt_help.add_runtask_options = lambda x: None
        opt_help.add_vault_options = lambda x: None
        opt_help.add_fork_options = lambda x: None
        opt_help.add_module_options = lambda x: None

    cli = PlaybookCLI(option_helpers=option_helpers_mock)


# Generated at 2022-06-22 19:01:48.046014
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from collections import namedtuple

    test_args = namedtuple('TestArgs', 'args')
    test_opts = namedtuple('TestOpts', 'verbosity listhosts tags subset forks subset_hosts become_method')

    # empty args
    test_opts.verbosity = 0
    test_opts.listhosts = False
    test_opts.tags = []
    test_opts.subset = None
    test_opts.become_method = 'sudo'
    assert PlaybookCLI.post_process_args(PlaybookCLI(), test_opts) is None

    # only args
    test_opts.verbosity = 0
    test_opts.listhosts = False
    test_opts.tags = []
    test_opts.subset = None
    test_op

# Generated at 2022-06-22 19:01:59.287810
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    class Options():
        listhosts = False  # This is only for unit testing
        listtasks = False  # This is only for unit testing
        listtags = False  # This is only for unit testing
        subset = None  # This is only for unit testing
        verbosity = 0  # This is only for unit testing
        flush_cache = False  # This is only for unit testing
        step = False  # This is only for unit testing
        start_at_task = None  # This is only for unit testing
        args = ['testing_playbook.yml']

    class PlaybookCLI_run(PlaybookCLI):
        def __init__(self):
            super(PlaybookCLI_run, self).__init__()
            self.options = Options()

        def post_process_args(self, options):
            return options

# Generated at 2022-06-22 19:02:09.107746
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI([])
    args = cli.parser.parse_args([])
    result = cli.post_process_args(args)
    assert result.verbosity == 0

    args = cli.parser.parse_args(['-v'])
    result = cli.post_process_args(args)
    assert result.verbosity == 1

    args = cli.parser.parse_args(['-vvvv'])
    result = cli.post_process_args(args)
    assert result.verbosity == 4

    args = cli.parser.parse_args(['-vvvvv'])
    result = cli.post_process_args(args)
    assert result.verbosity == 4

    # invalid verbosity level

# Generated at 2022-06-22 19:02:15.118833
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    '''playbook_cli.py: Test PlaybookCLI class'''
    playbook_cli = PlaybookCLI()
    parser = playbook_cli.create_parser()
    for arg in ["-vvvv", "--host", "localhost", "--list-hosts", "test.yml"]:
        parser.parse_args(arg.split())

# Generated at 2022-06-22 19:02:25.575168
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import tempfile
    import os
    import shutil
    from ansible.playbook.play import Play

    b_dir = tempfile.mkdtemp()
    b_playbook = os.path.join(b_dir, 'test_playbook.yml')
    try:
        with open(b_playbook, 'wb') as f:
            f.write(b"---\n- hosts: localhost")
        cli = PlaybookCLI(['test_playbook.yml'])
        cli.post_process_args({})
        os.environ['ANSIBLE_HOST_KEY_CHECKING'] = 'False'
        results = cli.run()
        assert results == 0
    finally:
        shutil.rmtree(b_dir)

# Generated at 2022-06-22 19:02:35.788268
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    args = [
        '--private-key', '~/.ssh/id_rsa',
        '--extra-vars', '@vars.yml',
        '--verbose',
        '--inventory', 'localhost,',
        'site.yml',
    ]
    pbcli = PlaybookCLI(args)

    # Make sure command line arguments are properly set
    assert pbcli.options.private_key_file == '~/.ssh/id_rsa'
    assert pbcli.options.extra_vars == '@vars.yml'
    assert pbcli.options.verbosity == 2
    assert pbcli.options.inventory == 'localhost,'
    assert pbcli.args == ['site.yml']

# Generated at 2022-06-22 19:02:38.203138
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    cli = PlaybookCLI()
    cli.run()

# Generated at 2022-06-22 19:02:39.664727
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pl = PlaybookCLI()
    print(pl)

# Generated at 2022-06-22 19:02:40.328928
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    PlaybookCLI()

# Generated at 2022-06-22 19:02:51.852562
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    import tempfile
    tf = tempfile.mktemp()
    with open(tf, 'wb') as f:
        f.write(b'test')
    os.environ['HOME'] = os.path.dirname(tf)
    cli = PlaybookCLI(['-v', tf])
    os.remove(tf)

    assert len(cli.parser._actions) == 32
    assert cli.parser._actions[23].dest == 'subset'
    assert cli.parser._actions[23].metavar == 'SUBSET'
    assert cli.parser._actions[23].help  # ensure help is not empty

    assert len(cli.base_parser._actions) == 12
    assert cli.base_parser._actions[5].dest == 'verbose'

# Generated at 2022-06-22 19:02:54.641357
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    playbookcli = PlaybookCLI()
    assert isinstance(playbookcli, PlaybookCLI)

# Generated at 2022-06-22 19:03:00.606914
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    import sys
    from ansible.utils.display import Display
    from ansible.plugins.loader import module_loader, fragment_loader
    from ansible.plugins.lookup import LookupBase
    from ansible.parsing.plugin_docs import read_docstring
    from collections import namedtuple
    print(module_loader)
    # result= PlaybookCLI().run()
    # print(result)


# Generated at 2022-06-22 19:03:12.556650
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    # Note: The test_utils module is only available when running unit tests
    import ansible.utils.test_utils as test_utils

    # Set up args
    args = test_utils.mock_args()
    args.connection = 'local'
    args.private_key_file = ['/privateroot']
    args.verbosity = 1
    args.ask_pass = True
    args.ask_vault_pass = True
    args.args = ['playbook1.yml', 'playbook2.yml']
    args.vault_password_files = ['/vaultroot']
    args.remote_user = 'root'
    args.ask_sudo_pass = True
    args.ask_su_pass = True
    args.sudo = True
    args.sudo_user = 'root'

# Generated at 2022-06-22 19:03:19.426262
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    import mock
    import argparse

    args = ['ansible-playbook', '--version']
    pbcli=PlaybookCLI(args)
    assert isinstance(pbcli, CLI)
    assert isinstance(pbcli.parser, argparse.ArgumentParser)

    pbcli_args = ['ansible-playbook', 'playbook.yml']
    pbcli=PlaybookCLI(pbcli_args)
    assert isinstance(pbcli, CLI)
    assert isinstance(pbcli.parser, argparse.ArgumentParser)

    with mock.patch('ansible.cli.CLI._match_plugin_terms'):
        pbcli_args = ['ansible-playbook', 'playbook.yml']
        pbcli=PlaybookCLI(pbcli_args)

# Generated at 2022-06-22 19:03:26.878685
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    """
    Unit test for method init_parser of class PlaybookCLI

    :return:
    """
    playbook_cli = PlaybookCLI()
    playbook_cli.init_parser()
    assert playbook_cli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert playbook_cli.parser.description == 'Runs Ansible playbooks, executing the defined tasks on the targeted hosts.'

# Generated at 2022-06-22 19:03:37.863377
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    CLI.get_default_options()

    # verify that the parser contains all the options we expect
    parser = PlaybookCLI(['ansible-playbook', 'test.yml']).parser

# Generated at 2022-06-22 19:03:44.899719
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI()
    cli.parse()
    args = {'listhosts': False, 'syntax': False, 'connection': 'smart',
            'module_path': None, 'forks': None, 'private_key_file': None,
            'ssh_common_args': None, 'ssh_extra_args': None, 'sftp_extra_args': None,
            'scp_extra_args': None, 'become': False, 'become_method': None,
            'become_user': None, 'verbosity': 0, 'check': False, 'listtasks': False,
            'listtags': False, 'step': False, 'start_at_task': None,
            'args': ['examples/apache.yml']}

# Generated at 2022-06-22 19:03:48.096276
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    args = ['--ansible-config', './ansible.cfg', '--list-hosts']
    context.CLIARGS = CLIFactory.parse(args, reset=True)


# Generated at 2022-06-22 19:03:49.491292
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    obj = PlaybookCLI()
    obj.init_parser()

# Generated at 2022-06-22 19:03:51.586789
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    assert cli.parser

# Generated at 2022-06-22 19:04:00.985254
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    # Test various options for playbook
    args = "--list-hosts --list-tasks playbook.yml playbook2.yml"
    context._init_global_context(args.split())
    cli = PlaybookCLI(args.split())
    cli.run()
    context._clear_global_context()

    context._init_global_context("--list-hosts playbook.yml playbook2.yml".split())
    cli = PlaybookCLI("--list-hosts playbook.yml playbook2.yml".split())
    cli.run()
    context._clear_global_context()

# Generated at 2022-06-22 19:04:10.075063
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # setup test parser
    parser = CLI.base_parser(
        usage='%prog [options] playbook.yml [playbook2 ...]',
        desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts.")

    # add CLI options
    opt_help.add_connect_options(parser)
    opt_help.add_meta_options(parser)
    opt_help.add_runas_options(parser)
    opt_help.add_subset_options(parser)
    opt_help.add_check_options(parser)
    opt_help.add_inventory_options(parser)
    opt_help.add_runtask_options(parser)
    opt_help.add_vault_options(parser)
    opt_help.add_fork_options(parser)

# Generated at 2022-06-22 19:04:15.097208
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI([])
    cli.init_parser()

    assert cli.parser.description.startswith("Runs Ansible playbooks")
    assert cli.parser.epilog.startswith("For more examples, use")


# Generated at 2022-06-22 19:04:20.412039
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import sys
    sys.argv = ['ansible-playbook', 'test.yml', '-i', 'test_inventory']

if __name__ == '__main__':
    test_PlaybookCLI_run()

# Generated at 2022-06-22 19:04:29.852494
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class Opts(object):
        pass

    options = Opts()
    options.verbose = 0
    options.check = False
    options.syntax = False
    options.connection = 'ssh'
    options.module_path = None
    options.forks = 5
    options.remote_user = 'root'
    options.private_key_file = None
    options.ssh_common_args = None
    options.ssh_extra_args = None
    options.sftp_extra_args = None
    options.scp_extra_args = None
    options.become = False
    options.become_method = 'sudo'
    options.become_user = 'root'
    options.ask_become_pass = False
    options.verbosity = 0
    options.check = False
    options.inventory

# Generated at 2022-06-22 19:04:31.404646
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pbcli = PlaybookCLI(['test.PlaybookCLI.py'])
    assert pbcli is not None


# Generated at 2022-06-22 19:04:44.288641
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():

    parser = PlaybookCLI.init_parser(CLI(),
                                     usage="%prog [options] playbook.yml [playbook2 ...]",
                                     desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts.")

    # add_connect_options
    assert parser.has_option("-c"), "Parser does not have -c (--connection) option"
    assert parser.has_option("--connection"), "Parser does not have -c (--connection) option"
    assert parser.has_option("-T"), "Parser does not have -T (--timeout) option"
    assert parser.has_option("--timeout"), "Parser does not have -T (--timeout) option"
    assert parser.has_option("-k"), "Parser does not have -k (--ask-pass) option"
    assert parser.has

# Generated at 2022-06-22 19:04:53.841884
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    display = Display()

# Generated at 2022-06-22 19:05:01.033005
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # define playbooks
    playbooks = ['playbook.yml']

    # define inventory
    inventory = InventoryManager(loader=DataLoader(), sources='hosts')

    # define variable manager
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    # create PlaybookCLI object
    pbcli = PlaybookCLI()

    # define options
    options = ['--list-tasks']
    opts = pbcli.base_parser(options=options)

    # run
    pbcli.run()

# Generated at 2022-06-22 19:05:05.301453
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pb_cli = PlaybookCLI()
    pb_cli._play_prereqs = MagicMock()
    pb_cli.parser = MagicMock()
    pb_cli.parser.add_argument = MagicMock()
    pb_cli.post_process_args = MagicMock(return_value=True)

    pb_cli.init_parser()
    assert pb_cli.post_process_args.call_count == 1
    assert pb_cli.parser.add_argument.call_count == 11
    assert pb_cli._play_prereqs.call_count == 1

# Generated at 2022-06-22 19:05:11.498731
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import os
    import ansible.constants as C
    from ansible.playbook.play import Play
    from ansible.cli.playbook import PlaybookCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    myplaybook = os.path.join('test', 'units', 'fixtures', 'test_playbook.yml')
    myhosts = os.path.join('test', 'units', 'fixtures', 'test_inventory.yml')
    args = [myplaybook, '-i', myhosts, '-vvvvvv']
    C.HOST_KEY_CHECKING = False
    mydisplay = Display()
    mydisplay.verbosity = 7
    myoptions = PlaybookCLI.parse(args=args)
    my

# Generated at 2022-06-22 19:05:24.535986
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    # initialise command
    cli = PlaybookCLI()
    cli.parse()


    # create objects
    loader, inventory, variable_manager = cli._play_prereqs()
    # fake get_host_list
    CLI.get_host_list(inventory, '127.0.0.1')

    # test with no playbook path
    options = cli.post_process_args(cli.options)
    assert options.verbosity == 0
    assert len(AnsibleCollectionConfig.playbook_paths) == 0


    # test with playbook path

# Generated at 2022-06-22 19:05:29.125371
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    from ansible.parsing.dataloader import DataLoader

    p = PlaybookCLI([])
    assert p.inventory_manager is None
    assert isinstance(p.loader, DataLoader)

# Generated at 2022-06-22 19:05:40.844876
# Unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-22 19:05:42.107575
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pass


# Generated at 2022-06-22 19:05:44.816598
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI(['', 'constructor_test_.yml'])
    assert cli._playbook_files_paths == ['constructor_test_.yml']

# Generated at 2022-06-22 19:05:55.189585
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    class MockCLI(object):
        options = {
            'ask_vault_pass': False,
            'ask_pass': False,
            'ask_su_pass': False,
            'ask_sudo_pass': False,
            'module_path': None,
        }
        passwords = {}

    class MockArgs(object):
        def __init__(self, ask_vault_pass, ask_pass, ask_su_pass, ask_sudo_pass, module_path):
            self.ask_vault_pass = ask_vault_pass
            self.ask_pass = ask_pass
            self.ask_su_pass = ask_su_pass
            self.ask_sudo_pass = ask_sudo_pass
            self.module_path = module_path


# Generated at 2022-06-22 19:05:57.122236
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pbcli = PlaybookCLI()
    assert pbcli is not None

# Generated at 2022-06-22 19:05:58.909605
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    playbook = PlaybookCLI()
    playbook._play_prereqs()

# Generated at 2022-06-22 19:06:05.904282
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():

    # create base objects
    loader, inventory, variable_manager = None, None, None

    # create the playbook executor, which manages running the plays via a task queue manager
    pbex = PlaybookExecutor(playbooks=['test.yml'], inventory=inventory,
                            variable_manager=variable_manager, loader=loader)

    # create dummy class object
    dummy_class = PlaybookCLI()

    # call run method
    result = dummy_class.run()

    # check output
    assert result is 0

# Generated at 2022-06-22 19:06:07.094539
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():

    pbc = PlaybookCLI()
    assert pbc is not None

# Generated at 2022-06-22 19:06:08.719343
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    p = PlaybookCLI()
    assert isinstance(p, PlaybookCLI)


# Generated at 2022-06-22 19:06:11.317545
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    p = PlaybookCLI(['-i', 'localhost,', 'sites.yml', '-v'])
    assert p.parser


# Generated at 2022-06-22 19:06:15.457855
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Sanity test, we expect to fail with no args
    try:
        PlaybookCLI().run()
        ok = False
    except SystemExit:
        ok = True
    assert ok


# Generated at 2022-06-22 19:06:28.079748
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # pylint: disable=too-many-statements,too-many-locals,redefined-outer-name
    # Creating mock objects
    class Options:
        verbosity = 1
        listhosts = False
        listtasks = False
        listtags = False
        syntax = False
        subset = None
        check = False
        inventory = 'hosts'
        extra_vars = {}
        connection = 'smart'
        timeout = 30
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = False
        become_method = None
        become_user = None
        become_ask_pass = False
        become_ask_sudo_pass = False
        become_ask_su_pass = False
       

# Generated at 2022-06-22 19:06:31.850524
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    parser = PlaybookCLI(
        args=[],
    ).init_parser()
    args = parser.parse_args(['--extra-vars', 'foo=bar'])
    assert args.extra_vars == 'foo=bar'

# Generated at 2022-06-22 19:06:33.924377
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    args = [ 'playbook.yml' ]
    p = PlaybookCLI(args)
    assert args == p.args

# Generated at 2022-06-22 19:06:41.040289
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    import __main__
    import os
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError
    from ansible.playbook.play import Play

    playbook = PlaybookCLI()

    # test run when context.CLIARGS['subset'] is not specified
    # set context.CLIARGS['subset']

# Generated at 2022-06-22 19:06:43.754907
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI()
    cli.init_parser()
    assert cli.parser



# Generated at 2022-06-22 19:06:54.552933
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    def assert_correct(args):
        options = CLI.base_parser(
            usage="%prog [options] playbook.yml"
        ).parse_args(args)
        PlaybookCLI().post_process_args(options)
        assert options.check == True
        assert options.diff == True

    assert_correct(["--check", "--diff", "pb.yml"])
    assert_correct(["--check", "pb.yml", "--diff"])
    assert_correct(["--diff", "--check", "pb.yml"])
    assert_correct(["--diff", "pb.yml", "--check"])
    assert_correct(["pb.yml", "--check", "--diff"])
    assert_correct(["pb.yml", "--diff", "--check"])

# Generated at 2022-06-22 19:07:05.693184
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    p = PlaybookCLI(['-i', './hosts', '-v', 'playbook.yml'])
    assert p.parser.get_default_values().inventory == './hosts'
    assert p.parser.get_default_values().verbosity == 2
    assert p.parser.get_default_values().syntax == False
    assert p.parser.get_default_values().listhosts == False
    assert p.parser.get_default_values().listtasks == False
    assert p.parser.get_default_values().listtags == False
    assert p.parser.get_default_values().step == False
    assert p.parser.get_default_values().start_at_task == None

# Generated at 2022-06-22 19:07:16.784234
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    test_args = [
        '--private-key', 'priv.key',
        '--list-hosts',
        '--list-tasks',
        '--start-at-task', 'included_task',
        'playbook1', 'playbook2'
    ]
    cli = PlaybookCLI(args=test_args)
    cli.init_parser()
    opts, args = cli.parser.parse_args(test_args)
    assert opts.private_key == 'priv.key'
    assert opts.listhosts is True
    assert opts.listtasks is True
    assert opts.start_at_task == 'included_task'
    assert args == ['playbook1', 'playbook2']

# Generated at 2022-06-22 19:07:25.992384
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # Initialize a PlaybookCLI object
    this_cli = PlaybookCLI()

    options = dict()
    loader = dict()

    # Verify post_process_args when 'ask_vault_pass' is set to True
    options['ask_vault_pass'] = True
    options['connection'] = 'paramiko'
    options['become_ask_pass'] = False
    options['private_key_file'] = '~/.ssh/id_rsa'
    options['vault_password_file'] = '~/.vault_pass.txt'
    this_cli.post_process_args(options, loader)
    assert options['ask_vault_pass'] is True
    assert options['ask_pass'] is False

# Generated at 2022-06-22 19:07:38.989941
# Unit test for method post_process_args of class PlaybookCLI

# Generated at 2022-06-22 19:07:44.283837
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    playbook_cli = PlaybookCLI()
    playbook_cli.init_parser()
    argv = playbook_cli.parser.parse_args()
    playbook_cli.parser.parse_known_args(argv)
    assert playbook_cli.parser.prog == 'ansible-playbook'
    assert playbook_cli.parser.usage == '%prog [options] playbook.yml [playbook2 ...]'
    assert playbook_cli.parser.description == "Runs Ansible playbooks, executing the defined tasks on the targeted hosts."

# Generated at 2022-06-22 19:07:47.492694
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(['ansible-playbook'])
    assert cli is not None
    assert cli.parser is not None
    assert cli.parser._prog == 'ansible-playbook'

# Generated at 2022-06-22 19:07:58.128300
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    from ansible.utils.display import Display

    display = Display()
    options = CLI.base_parser(
        usage="%prog [options] playbook.yml [playbook2 ...]",
        connect_opts=True,
        meta_opts=True,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        inventory_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        desc="Runs Ansible playbooks, executing the defined tasks on the targeted hosts.")

    options, args = options.parse_args(['foo'])
    options = PlaybookCLI().post_process_args(options)

    assert options.ask_

# Generated at 2022-06-22 19:08:10.852630
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    class MockPlaybookCLI(PlaybookCLI):
        def __init__(self, args):
            self.args = args
            self.parser = MockParser()

    class MockParser(object):
        def __init__(self):
            self.values = None

        class MockValues(object):
            def __init__(self):
                self.connection = 'ssh'

            def __getattribute__(self, name):
                return object.__getattribute__(self, name)

        def parse_args(self, args=None, namespace=None):
            self.values = self.MockValues()
            return self.values

    def test_factory(args):
        return MockPlaybookCLI(args)


# Generated at 2022-06-22 19:08:13.695524
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pbc=PlaybookCLI()
    assert isinstance(pbc,PlaybookCLI)


# Generated at 2022-06-22 19:08:18.924902
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    import os
    import sys

    # Create an instance of class PlaybookCLI

# Generated at 2022-06-22 19:08:29.961758
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class MockCLI():
        def __init__(self):
            self.connection = 'mock'

        def async_executor_hook(self):
            return 0

    class MockInventory():
        def __init__(self):
            pass

        def add_host(self, host):
            pass

        def clear_pattern_cache(self):
            pass

        def add_group(self, group):
            pass

        def refresh_inventory(self):
            pass

        def get_hosts(self, pattern="all"):
            return ['host1']

    class MockVariableManager():
        def __init__(self, loader, inventory):
            pass

        def get_vars(self, host=None, task=None, play=None, string=True):
            return {}


# Generated at 2022-06-22 19:08:32.071506
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    pc = PlaybookCLI(['ansible-playbook'])
    pc.init_parser()
    assert pc.parser._optionals._actions[5].dest == 'listtasks'


# Generated at 2022-06-22 19:08:39.666849
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    # Unit test for method init_parser of class PlaybookCLI

    # Test empty command line argument
    cli = PlaybookCLI(None)
    opts = cli.parse()
    assert not opts.listhosts
    assert not opts.syntax
    assert not opts.listtasks
    assert not opts.listtags
    assert not opts.step
    assert not opts.start_at_task
    assert not opts.verbosity

    # Test --list-hosts
    cli = PlaybookCLI(['--list-hosts'])
    opts = cli.parse()
    assert opts.listhosts

    # Test --list-tasks
    cli = PlaybookCLI(['--list-tasks'])
    opts = cli.parse()
    assert opt

# Generated at 2022-06-22 19:08:42.016787
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(['-h'])
    #assert cli.options.version is False
    # TODO (akroshchenko):


# Generated at 2022-06-22 19:08:47.986992
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():
    cli = PlaybookCLI(['/bin/ansible-playbook', 'playbook.yaml'])
    args = cli.parser.parse_args(['playbook.yaml'])
    options = cli.post_process_args(args)
    assert len(options.args) > 0
    assert type(options.args) is list
    assert options.args[0] == 'playbook.yaml'

# Generated at 2022-06-22 19:08:49.109243
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-22 19:09:00.634697
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    # Dummy inventory file to use for tests
    INVENTORY_FILE = '''
    [all]
    dummyhost1
    dummyhost2
    [all:vars]
    dummyvar=dummyval
    '''

    # Dummy playbook to use for tests
    TEST_PLAYBOOK = '''---
    - name: Test-play
      hosts: all
      tasks:
      - debug:
          msg: "Hi"
    '''

    # Create a temporary inventory file
    import tempfile
    import os
    inventory_fp = tempfile.NamedTemporaryFile(delete=False)
    inventory_fp.write(to_bytes(INVENTORY_FILE, errors='surrogate_or_strict'))
    inventory_fp.close()
    class Args:
        inventory = inventory_fp.name


# Generated at 2022-06-22 19:09:02.561535
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    cli = PlaybookCLI(['playbook.yml'])
    cli.parse()

# Generated at 2022-06-22 19:09:04.351783
# Unit test for constructor of class PlaybookCLI
def test_PlaybookCLI():
    pbc = PlaybookCLI()

    # Test options is added correctly
    assert(len(pbc.options) > 0)

# Generated at 2022-06-22 19:09:04.866178
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pass

# Generated at 2022-06-22 19:09:11.016804
# Unit test for method post_process_args of class PlaybookCLI
def test_PlaybookCLI_post_process_args():

    # create a instance of class PlaybookCLI
    cli = PlaybookCLI()
    cli.init_parser()

    # all opts are set, including ask_pass and ask_sudo_pass
    options = cli.parser.parse_args(['-e', '{"test": "test"}', '-i', 'inventory', '--ask-pass', '--ask-sudo-pass', 'test.yml'])

    options = cli.post_process_args(options)
    assert options.ask_pass is False
    assert options.ask_sudo_pass is False
    assert options.verbosity == 0
    assert cli.parser.get_usage() == "%prog [options] playbook.yml [playbook2 ...]"

# Generated at 2022-06-22 19:09:11.790229
# Unit test for method init_parser of class PlaybookCLI
def test_PlaybookCLI_init_parser():
    cli = PlaybookCLI(['ansible-playbook',"--version"])



# Generated at 2022-06-22 19:09:14.371975
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    pcli = PlaybookCLI()
    pcli.post_process_args({'listhosts': True})


# Generated at 2022-06-22 19:09:24.580923
# Unit test for method run of class PlaybookCLI
def test_PlaybookCLI_run():
    class mock_options(object):
        def __init__(self):
            self.connection = None
            self.module_path = None
            self.forks = None
            self.remote_user = None
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = None
            self.become_method = None
            self.become_user = None
            self.verbosity = None
            self.check = None
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None
            self.diff = None
            self.host_key