

# Generated at 2022-06-12 12:22:16.817959
# Unit test for function match
def test_match():
    command = Command('tsuru hello', '/home/ilie/Documents/')
    output = 'tsuru: "hello" is not a tsuru command. See "tsuru help".\nDid you mean?\n\thelp'
    command.output = output
    assert match(command) is True
    # wrong output test
    command = Command('tsuru hello', '/home/ilie/Documents/')
    command.output = 'this is a wrong output'
    assert match(command) is False



# Generated at 2022-06-12 12:22:23.111271
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create asdasdasd', stderr='tsuru: "asdasdasd" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create'))
    assert not match(Command('tsuru app-create asdasdasd', stderr='tsuru: "asdasdasd" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-12 12:22:28.744969
# Unit test for function match
def test_match():
    broken_command1 = 'tsurug: "foo" is not a tsuru command.'
    broken_command2 = 'tsurug: "bar" is not a tsuru command. See "tsuru help".'
    broken_command3 = 'tsurug: "foo" is not a tsuru command. See "tsuru help".\nDid you mean?\n\trun'

    assert not match(Command(broken_command1, None))
    assert not match(Command(broken_command2, None))
    assert match(Command(broken_command3, None))


# Generated at 2022-06-12 12:22:32.318464
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("", "", "", 0, "tsuru: \"coma\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tcommand\n\n")
    assert get_new_command(command) == "tsuru command"

# Generated at 2022-06-12 12:22:40.109711
# Unit test for function match
def test_match():
    assert match(Command('tsru app-info', 'tsuru: "tsru" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n\tapp-run', ''))
    assert match(Command('test', 'tsuru: "test" is not a tsuru command. See "tsuru help".', '')) == False
    assert match(Command('tsru app-info', 'tsuru: "tsru" is not a tsuru command. See "tsuru help".\n\nDid you mean?', '')) == False
    assert match(Command('tsru app-info', 'tsuru: "tsru" is not a tsuru command. See "tsuru help".\n\nDid you mean?', '')) == False

# Generated at 2022-06-12 12:22:43.716660
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru app-info asfa',
                         stderr='tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-info\n\tapp-create',
                         ))


# Generated at 2022-06-12 12:22:46.753760
# Unit test for function get_new_command

# Generated at 2022-06-12 12:22:52.375311
# Unit test for function match
def test_match():
    # Assert true
    output_true = 'tsuru: "foo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoo'
    assert match(Command('tsuru foo', output_true))
    # Assert false
    output_false = 'tsuru: "foo" is not a tsuru command. See "tsuru help".'
    assert not match(Command('tsuru foo', output_false))


# Generated at 2022-06-12 12:22:55.709313
# Unit test for function get_new_command
def test_get_new_command():
    output = '''tsuru: "list" is not a tsuru command. See "tsuru help".

Did you mean?
        target-list'''
    assert get_new_command(Command("target", output)) == "target target-list"

# Generated at 2022-06-12 12:23:00.998749
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='tsuru target-set https://ad',
                                   output='tsuru: "target-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add\n\ttarget-remove')) == 'tsuru target-add https://ad'



# Generated at 2022-06-12 12:23:08.018773
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-list', '''tsuru: "app-list" is not a tsuru command. See "tsuru help".

Did you mean?
	app-list
''')) == 'tsuru app-list'


# Generated at 2022-06-12 12:23:17.471180
# Unit test for function match
def test_match():
    assert match(Command('tsuru key-add abcde', 'tsuru: "key-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tkey-add\n\tkey-list\n\tkey-remove', ''))
    assert not match(Command('tsuru key-add abcde', 'tsuru: "key-add" is not a tsuru command. See "tsuru help".\nNo suggestions', ''))
    assert not match(Command('tsuru key-add abcde', 'tsuru: "key-add" is not a tsuru command. See "tsuru help".', ''))


# Generated at 2022-06-12 12:23:20.688714
# Unit test for function match
def test_match():
    assert match(Command('test tsuru', 'test is not tsuru command'))
    assert not match(Command('tsuru app-create test', 'name is required'))


# Generated at 2022-06-12 12:23:24.340393
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-list-2', 'Command "tsuru app-list-2" not found.')
    assert get_new_command(command) == 'tsuru app-list'
    command = Command('tsuru app-list', 'Command "tsuru app-list" not found.')
    assert get_new_command(command) is None

# Generated at 2022-06-12 12:23:27.606650
# Unit test for function match
def test_match():
    command = Command('tsuru app-remove aslkdfj',
                      'tsuru: "aslkdfj" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-remove\n')
    assert match(command)



# Generated at 2022-06-12 12:23:33.612783
# Unit test for function match
def test_match():
    assert match(Command('tsuru', 'tsuru: "node" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tnode-list\ntsuru node-list\n'))
    assert not match(Command('tsuru', '\nDid you mean?\n\tnode-list'))
    assert not match(Command('tsuru', 'env'))


# Generated at 2022-06-12 12:23:38.102133
# Unit test for function match
def test_match():
    broken_command = Command('tsuruu target-list', "tsuru: 'tsuruu' is not a tsuru command. See 'tsuru help'.\n\nDid you mean?\n\tapps\n\n")
    assert match(broken_command)
    assert not match(Command('tsuru target-list', ''))



# Generated at 2022-06-12 12:23:46.330799
# Unit test for function match
def test_match():
    assert match(Command("tsuru ll", "tsuru: \"ll\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tlist-app\n\tlist-user\n"))
    assert match(Command("tsuru --app myapp", "tsuru: \"--app\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-create\n\tapp-delete\n\tapp-info\n\tapp-list\n\tapp-remove\n\tapp-restart\n\tapp-run\n"))

# Generated at 2022-06-12 12:23:51.257136
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("tsuru console", "tsuru: \"console\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-run")
    assert get_new_command(command) == "tsuru app-run"

    command = Command("tsuru console", "tsuru: \"console\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-run\n\tapp-restart")
    assert get_new_command(command) == "tsuru app-run"

# Generated at 2022-06-12 12:23:54.584489
# Unit test for function match
def test_match():
    output = 'tsuru: "foo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoo-bar'
    assert match(Command(script='', output=output))


# Generated at 2022-06-12 12:24:00.436762
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'
                         '\nDid you mean?\n\tapp-deploy\n\tapp-log\n\tapp-remove'))



# Generated at 2022-06-12 12:24:04.574590
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru target-add testing http://127.0.0.1:8080', 'tsuru: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-get')
    assert get_new_command(command) == 'tsuru target-get testing http://127.0.0.1:8080'

# Generated at 2022-06-12 12:24:07.174707
# Unit test for function match
def test_match():
    assert match(Command('tsuru: "start" is not a tsuru command. See "tsuru help".', ''))



# Generated at 2022-06-12 12:24:09.340767
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru foo', 'tsuru: "foo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoo-bar\n\tfoo-baz')) == 'tsuru foo-bar'


enabled_by_default = True

# Generated at 2022-06-12 12:24:11.779563
# Unit test for function match
def test_match():
    command = Command("tsuru app-pool-create testapp myapppool", "")
    assert match(command) is True

# Unit tests for function get_new_command

# Generated at 2022-06-12 12:24:18.240485
# Unit test for function match
def test_match():
    assert match(Command('tsuru permission-deny user1 myapp', ''))
    assert not match(Command('tsuru permission-deny user1 myapp',
                             'tsuru: "permission-deny" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru permission-deny user1 myapp',
                             """tsuru: "permission-deny" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tpermission-revoke""",
                             None))


# Generated at 2022-06-12 12:24:24.368812
# Unit test for function match
def test_match():
    assert match(Command('tsurur: "tsurur" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsurr', '', 1))
    assert not match(Command('tsurur: "tsurur" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsurr', '', 1))


# Generated at 2022-06-12 12:24:27.873747
# Unit test for function match
def test_match():
    match_output = "tsuru: \"name\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tname-app"
    assert match(Command("tsuru name", match_output))



# Generated at 2022-06-12 12:24:31.005003
# Unit test for function match
def test_match():
    output = u'ERROR: "tsuru targe" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-remove'
    assert match(Command('tsuru targe', output))



# Generated at 2022-06-12 12:24:35.357136
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info'))
    assert not match(Command('tsuru app-info', 'No node found'))
    assert not match(Command('tsuru app-info', 'tsuru: app-info is not a tsuru command'))


# Generated at 2022-06-12 12:24:47.764863
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create toto', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create-unit-add\n\tapp-create-unit-remove\n\tapp-create-unit-set-count\n\tapp-create-unit-status'))
    assert not match(Command('tsuru app-create toto', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create-unit-add\n\tapp-create-unit-remove\n\tapp-create-unit-set-count\n\tapp-create-unit-status\n\n'))

# Generated at 2022-06-12 12:24:51.238473
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('tsuru: "tsuru dep" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tdeploy-node') == 'tsuru deploy-node'
    assert get_new_command('tsuru: "tsuru aba" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tabort-node\n\tabort-node-after-deployment') == 'tsuru abort-node-after-deployment'

# Generated at 2022-06-12 12:24:59.796093
# Unit test for function get_new_command
def test_get_new_command():
    # output from tsuru
    output = ("tsuru: \"hello\" is not a tsuru command. See \"tsuru help\".\n"
              "Did you mean?\n"
              "\thelp")
    command = MagicMock(script='tsuru hello', output=output)

    assert get_all_matched_commands(command.output) == ['help']
    assert get_new_command(command) == 'tsuru help'

    # output from tsuru update

# Generated at 2022-06-12 12:25:03.516390
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-create my-app', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create')

    assert get_new_command(command) == 'tsuru app-create my-app'

# Generated at 2022-06-12 12:25:14.702806
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('tsuru help', 'tsuru: "help" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp-app\n\thelps\n')
    command2 = Command('tsuru hel', 'tsuru: "hel" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp\n\thelps\n')
    command3 = Command('tsuru hello', 'tsuru: "hello" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp-app\n\thelps\n')
    
    assert get_new_command(command1) == 'tsuru help-app'

# Generated at 2022-06-12 12:25:19.436173
# Unit test for function get_new_command
def test_get_new_command():
    broken_cmd = "tsuru: \"app-analitcs\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tapp-analytics\n\tapp-autoscale\n\tapp-change\n\tapp-create\n\tapp-deploy\n\tapp-deploy-list\n\tapp-deploy-rollback\n\tapp-remove\n\tapp-run"
    assert get_new_command(broken_cmd) == "tsuru app-analytics"

# Generated at 2022-06-12 12:25:25.751014
# Unit test for function match
def test_match():
    # test 1
    command = Command('tsuru servicess', 'tsuru: "servicess" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t services\n\n')
    assert match(command)

    # test 2
    command = Command('tsuru servicess', 'tsuru: "servicess" is not a tsuru command. See "tsuru help".\n')
    assert not match(command)


# Generated at 2022-06-12 12:25:28.550795
# Unit test for function match
def test_match():
    command = Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n')
    assert match(command)


# Generated at 2022-06-12 12:25:36.988077
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert (u'tsuru app-create --team <team-name> <app-name>'
            == get_new_command(Command('tsuru app-create --team <team-name> <app-name>',
                                 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n' +
                                 '\n' +
                                 'Did you mean?\n' +
                                 '\tapp-create',
                                 '')))


enabled_by_default = True

# Generated at 2022-06-12 12:25:46.242078
# Unit test for function match
def test_match():
    assert match(Command('tsuru node-list', 'tsuru: "node-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-cancel-restart\n\tnode-list\n\tnode-remove'))
    assert not match(Command('ls -1', 'tsuru: "ls" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-cancel-restart\n\tnode-list\n\tnode-remove'))
    assert not match(Command('tsuru node-list', 'tsuru: "node-list" is not a tsuru command. See "tsuru help".'))



# Generated at 2022-06-12 12:25:51.144316
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "abc" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapps-create\n\tapps-list'
    command = Command('tsuru abc', output)
    assert get_new_command(command) == 'tsuru apps-create'

# Generated at 2022-06-12 12:25:56.118344
# Unit test for function match
def test_match():
    assert match(Command('tsuru foo', 'tsuru: "foo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoo\n'))
    assert not match(Command('tsuru foo', 'tsuru: "foo" is not a tsuru command. See "tsuru help".\n\n'))


# Generated at 2022-06-12 12:26:05.070876
# Unit test for function match
def test_match():
    assert match(Command('tsuru help',
    'tsuru: "help" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp-doc\n\thelp-doc-remove\n\thelp-doc-set\n\thelphp') )
    assert not match(Command('tsuru help-doc', ''))
    assert not match(Command('tsuru helpdoc', ''))
    assert not match(Command('tsuru help-doc-remove', ''))
    assert not match(Command('tsuru help-doc-set', ''))
    assert not match(Command('tsuru help', ''))


# Generated at 2022-06-12 12:26:09.725830
# Unit test for function get_new_command
def test_get_new_command():
    command = MagicMock(output='tsuru: "app-lsit" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\n')
    assert get_new_command(command) ==  replace_command(command, 'app-lsit', ['app-list'])

# Generated at 2022-06-12 12:26:16.737012
# Unit test for function match
def test_match():
    assert match(Command("tsuru env-get unkownapp",
                         "tsuru: \"env-get\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tenv-set\n\tenv-unset"))
    assert match(Command("tsuru envi-get unkownapp",
                         "tsuru: \"envi-get\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tenv-set\n\tenv-unset"))


# Generated at 2022-06-12 12:26:26.998976
# Unit test for function match
def test_match():
    assert match(Command('tsruu node-list', 'tsuru: "tsruu" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-list\n'))
    assert match(Command('tsuru node-liss', 'tsuru: "node-liss" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-list\n'))
    assert not match(Command('tsuru node-list', 'tsuru: "node-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-list\n'))

# Generated at 2022-06-12 12:26:30.175403
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-info', 'tsuru: "service-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tunit-add'))



# Generated at 2022-06-12 12:26:32.057021
# Unit test for function match
def test_match():
    assert match(Command('tsuru help'))
    assert not match(Command('tsuru app-info'))


# Generated at 2022-06-12 12:26:35.966462
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru mycommand',
                                   'tsuru: "mycommand" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tmycmd\n\tmycmd1\n\tmycmd3\n\tmycmd4')) == Command('tsuru mycmd', '')

# Generated at 2022-06-12 12:26:41.211527
# Unit test for function match
def test_match():
    out1 = "tsuru: \"foo\" is not a tsuru command. See \"tsuru help\"."
    out2 = "tsuru: \"foo\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tfoo-bar"
    assert match(Command('foo', out1)) is False
    assert match(Command('foo', out2)) is True


# Generated at 2022-06-12 12:26:46.481116
# Unit test for function match
def test_match():
    command = 'tsuru jhgkjhgj is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttsuru app-info'
    assert  match(command)



# Generated at 2022-06-12 12:26:49.229009
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create'))


# Generated at 2022-06-12 12:26:53.777094
# Unit test for function match
def test_match():
    assert match(Command('tsuru some-invalid-command', '',
                         'tsuru: "some-invalid-command" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tdeploy\n\tlog', 1))



# Generated at 2022-06-12 12:26:58.221419
# Unit test for function match
def test_match():
    from tests.utils import Command

    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapplist\n'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))



# Generated at 2022-06-12 12:27:08.089562
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru plataform-add go1.6',
                         stderr='tsuru: "plataform-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-add'))
    assert not match(Command(script='tsuru plataform-add go1.6',
                   stderr='tsuru: "plataform-add" is not a tsuru command. See "tsuru help".\n'))
    assert not match(Command(script='tsuru plataform-add go1.6',
                   stderr='tsuru: "plataform-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-add\n\n\n'))


# Generated at 2022-06-12 12:27:16.713807
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru import get_new_command
    assert get_new_command(Command('tsuruu', 'tsuru: "tsuruu" is not a tsuru command.\nDid you mean?\n\ttsurur\n\ttsurub', 1)) == 'tsurub'
    assert get_new_command(Command('tsuru user-list uu', "tsuru: \"user-list\" is not a tsuru command.\nDid you mean?\n\tlogin\n\tuser-create", 1)) == 'tsuru user-create uu'

# Generated at 2022-06-12 12:27:24.773408
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info testapp', 'tsuru: "app-info" is not a tsuru command.\nSee "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-recover\n\tapp-remove\n\tapp-restart\n\tapp-run\n\tapp-start'))
    assert match(Command('tsuru app-run --help', 'tsuru: "app-run" is not a tsuru command.\nSee "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-recover\n\tapp-remove\n\tapp-restart\n\tapp-start'))
    assert not match(Command('command --foo', ''))
    assert not match

# Generated at 2022-06-12 12:27:30.767976
# Unit test for function match
def test_match():
	assert match(Command('tsuru app-create',
						 output="tsuru: " +
						 "\"app-create\" is not a tsuru command. See \"tsuru help\"." +
						 "\n\nDid you mean?\n" +
						 "\tapp-create\n" +
						 "\tapp-remove\n" +
						 "\tapp-restart\n" +
						 "\tapp-run"))


# Generated at 2022-06-12 12:27:34.928827
# Unit test for function match
def test_match():
    output = "tsuru: \"app-upgrade\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-deploy"
    result = match(Command('tsuru app-upgrade', output))
    assert result is True


# Generated at 2022-06-12 12:27:38.544775
# Unit test for function match
def test_match():
    assert not match(Command('tsuru app-info'))
    assert not match(Command('tsuru app-info --app app1'))
    assert match(Command('tsuru app-info --app app1 --whatever',
                         '\nDid you mean?\n\t--app'))



# Generated at 2022-06-12 12:27:44.063598
# Unit test for function get_new_command
def test_get_new_command():
    broken_cmd = "tsuru: \"hello\" is not a tsuru command. See \"tsuru help\"."
    broken_cmd += '\nDid you mean?\n\thelp'
    broken_cmd += '\n\thello-world-app-create'

    assert get_new_command(Command(broken_cmd)) == 'tsuru help'

# Generated at 2022-06-12 12:27:48.542722
# Unit test for function match
def test_match():
    assert not match(Command('tsuru version'))
    assert not match(Command('tsuruu version'))
    assert not match(Command('tsuru --help'))
    assert match(Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tversion-set'))
    assert match(Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-12 12:27:53.729903
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru command',
                         stderr='tsuru: "command" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tcommands'))

    assert not match(Command(script='tsuru command',
                             stderr='tsuru: "command" is not a tsuru command. See "tsuru help".'))



# Generated at 2022-06-12 12:28:01.662910
# Unit test for function get_new_command
def test_get_new_command():
    output_test = """tsuru: "target-list" is not a tsuru command. See "tsuru help".

Did you mean?
	client-list
	node-add
	node-remove
	target-add
	target-remove
	user-create
	user-list
	user-remove
	user-set-password
	user-set-quota"""
    assert get_new_command("tsuru target-list", output_test) == "tsuru target-list"
    assert get_new_command("tsuru target-list", output_test, output_test) == "tsuru target-list"
    assert get_new_command("tsuru target-list", output_test, output_test, output_test) == "tsuru target-list"

# Generated at 2022-06-12 12:28:08.120495
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    output = 'tsuru: "target-add" is not a tsuru command. '\
             'See "tsuru help".\n' \
             '\n' \
             'Did you mean?\n' \
             '\ttarget-get\n' \
             '\ttarget-remove\n' \
             '\ttarget-set\n' \
             '\ttargets-list'
    assert get_new_command(Command('tsuru target-add xxx', output)) == 'tsuru target-set xxx'
    assert get_new_command(Command('tsuru target-add xxx', 'target-add')) == 'target-set'

# Generated at 2022-06-12 12:28:11.458361
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcreate-app'))


# Generated at 2022-06-12 12:28:17.106948
# Unit test for function match
def test_match():
    msg = ("tsuru: \"app-deploy\" is not a tsuru command. See \"tsuru help\".\n"
           "Did you mean?\n"
           "\tapp-remove\n"
           "\tapp-deploy-list\n"
           "\tapp-info")
    cmd = Command("tsuru app-deploy", stderr = msg)
    assert match(cmd)


# Generated at 2022-06-12 12:28:22.521786
# Unit test for function match
def test_match():
  test_input = ['tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info',
                'tsuru: "user-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tuser-info']
  for test_case in test_input:
    assert match(Command('tsuru', test_case))


# Generated at 2022-06-12 12:28:26.312994
# Unit test for function match
def test_match():
    assert match(Command(script=("tsuru a b"),
                         stderr="tsuru: \"a b\" is not a tsuru command. See \"tsuru help\"."))

    assert not match(Command(script=("tsuru"),
                             stderr="tsuru: \"a b\" is not a tsuru command. See \"tsuru help\"."))


# Generated at 2022-06-12 12:28:29.318075
# Unit test for function match
def test_match():
    assert match(Command(script='Some output'))
    assert match(Command(script='tsuru: "some" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-12 12:28:37.280251
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuruu', '''tsuru: "tsuruu" is not a tsuru command. See "tsuru help".

Did you mean?
	tsurud''')) == "tsurud"

    assert get_new_command(Command('tsuru foo', '''tsuru: "foo" is not a tsuru command. See "tsuru help".

Did you mean?
	tsurud''')) == 'tsurud foo'

    assert get_new_command(Command('tsuru foo', '''tsuru: "foo" is not a tsuru command. See "tsuru help".

Did you mean?
	tsuru docker-exec
	tsuru docker-log''''')) == 'tsuru docker-log'


# Generated at 2022-06-12 12:28:46.434764
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru platform-list', 'tsuru: "platform-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tplatform-add\n\tplatform-create\n\tplatform-remove\n\tplatform-update')
    assert get_new_command(command) == 'tsuru platform-add'
    command = Command('tsuru platform-add', 'tsuru: "platform-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tplatform-create\n\tplatform-remove\n\tplatform-update')
    assert get_new_command(command) == 'tsuru platform-create'

# Generated at 2022-06-12 12:28:49.605785
# Unit test for function match
def test_match():
    assert match(Command("tsuru app-list", "tsuru: \"app-list\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tlist-apps"))


# Generated at 2022-06-12 12:28:54.777163
# Unit test for function match
def test_match():
    old_command = Command("""tsuru app-create myapp git git://github.com/username/appname""", """tsuru: "app-create git git://github.com/username/appname" is not a tsuru command. See "tsuru help".

Did you mean?
	app-create
""")
    assert match(old_command)

    new_command = Command("""tsuru is not a tsuru command""", "")
    assert not match(new_command)


# Generated at 2022-06-12 12:28:59.189962
# Unit test for function match
def test_match():
    assert match(Command('tsuru status', '', 'tsuru: "status" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-run\n\tapp-deploy\n\tapp-remove\n\tapp-create\n\tapp-info\n\tapp-list\n\tapp-log')) == True


# Generated at 2022-06-12 12:29:07.718177
# Unit test for function get_new_command
def test_get_new_command():
    commands = [
        "tsuru hello world-is-not-a-tsuru-command",
        "tsuru hello world-is-not-a-tsuru-command-and-is-not-another-command",
        "tsuru hello world-is-not-a-tsuru-command-and-is-not-another-command another-world-is-not-a-tsuru-command-and-is-not-another-command",
    ]

# Generated at 2022-06-12 12:29:11.987100
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-deploy .',
                                   'tsuru: "app-deploy" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-deploy\n\n')) == 'tsuru app-deploy .'

# Generated at 2022-06-12 12:29:16.442688
# Unit test for function match
def test_match():
    assert match(Command(script='tsur teste', stderr='tsuru: "teste" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-list',))


# Generated at 2022-06-12 12:29:22.881329
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "sad" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list\n\tapp\n\tapps\n'))
    assert match(Command('tsuru app-list', 'tsuru: "sad" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is a tsuru command. See "tsuru help".'))


# Generated at 2022-06-12 12:29:28.270624
# Unit test for function match
def test_match():
    assert match(Command('tsuru platf',
    'tsuru: "platf" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-add\n\tplatform-list\n\tplatform-remove\n\tplatform-update\n\tplatform-default'))
    assert match(Command('tsuru team-user-add',
    'tsuru: "team-user-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tteam-user-remove'))
    assert not match(Command('tsuru app-list', ''))

# Generated at 2022-06-12 12:29:34.868006
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("tsuru unit-add", "tsuru: \"unit-add\" is not a tsuru command. See \"tsuru help\"."
        "\n\nDid you mean?\n\tunit-add-app")) == "tsuru unit-add-app"

# Generated at 2022-06-12 12:29:43.122373
# Unit test for function match
def test_match():
    assert match(Command(script="tsuru app-lis", stderr='tsuru: "app-lis" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert match(Command(script="tsuru app-lis", stderr='tsuru: "app-lis" is not a tsuru command. See "tsuru help".'))
    assert not match(Command(script="tsuru app-list", stderr='tsuru: "app-lis" is not a tsuru command. See "tsuru help".'))
    assert not match(Command(script="teste", stderr='tsuru: "app-lis" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-12 12:29:49.199592
# Unit test for function match
def test_match():
    output = """tsuru: "app" is not a tsuru command. See "tsuru help".

Did you mean?
  app-info
  app-remove
  app-create
  app-list
  app-lock
  app-unlock
  app-restart
  app-run
  app-grant
  app-revoke
"""
    assert match(Command(script='tsuru app', stderr=output))



# Generated at 2022-06-12 12:29:52.633008
# Unit test for function match
def test_match():
    assert match(Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".' , '', ''))
    assert not match(Command('tsrur version', '', '', ''))



# Generated at 2022-06-12 12:29:58.912954
# Unit test for function match
def test_match():
    assert match(Command("tsuru app-list", "tsuru: \"app-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-node-list\n\tapp-create", ""))
    assert not match(Command("tsuru app-list", "tsuru: \"app-list\" is not a app-node-list. See \"tsuru help\".\n\nDid you mean?\n\tapp-node-list\n\tapp-create", ""))


# Generated at 2022-06-12 12:30:06.487395
# Unit test for function match

# Generated at 2022-06-12 12:30:14.881420
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-add', 'tsuru: "app-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-change\n\tapp-create\n\tapp-deploy\n\tapp-info\n\tapp-remove\n\tapp-restart\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-swap\n\tapp-upgrade'))
    assert not match(Command('lssssss', 'tsuru: "lssssss" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t'))


# Generated at 2022-06-12 12:30:21.481713
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    
    shell_mock = {'get_all_matched_commands': lambda x: ['tsuru app-list']}
    command = Command('tsuru app-list myapp --on', 'tsuru: "app-list myapp --on" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list', get_new_command, shell_mock)
    assert get_new_command(command) == 'tsuru app-list'

# Generated at 2022-06-12 12:30:26.917984
# Unit test for function match
def test_match():
    assert match(Command('tsuru b', 'tsuru: "b" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tbuild-app\n\tbuild-image\n\tbuild-service\n\tbuild-ssh\n'))
    assert match(Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-log\n\tapp-run\n\tapp-shell\n\tservice-instance-grant\n'))

# Generated at 2022-06-12 12:30:31.340296
# Unit test for function get_new_command
def test_get_new_command():
    output = """tsuru: "target" is not a tsuru command. See "tsuru help".

Did you mean?
	target-add
	target-remove
	target-set"""
    command = MagicMock(output=output)
    assert get_new_command(command) == "tsuru target-add"

# Generated at 2022-06-12 12:30:35.860946
# Unit test for function match
def test_match():
    match('tsuree is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp/start\n\tapp/restart\n\tapp/restore')


# Generated at 2022-06-12 12:30:39.649308
# Unit test for function get_new_command
def test_get_new_command():
    unit_test = Command('tsuru app-log -app testapp',
    '''tsuru: "app-log" is not a tsuru command. See "tsuru help".

Did you mean?
\tapp-run
\tapp-log-remove
\tapp-info
\tapp-deploy''')
    assert get_new_command(unit_test) == 'tsuru app-log-remove -app testapp'



# Generated at 2022-06-12 12:30:45.721889
# Unit test for function match
def test_match():
    # This test has no output yet
    assert match(Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapps-versions\n\tnode-version\n\tservice-echo-version\n\tversion-list'))
    assert not match(Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-12 12:30:48.189490
# Unit test for function match
def test_match():
    output = "tsuru: \"ssh\" is not a tsuru command. See \"tsuru help\"."
    assert match(Command(script="tsuru ssh", output=output))


# Generated at 2022-06-12 12:30:57.505630
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('tsuru create-app',
                                   u'\x1b[1;31;40mtsuru:\x1b[0m "create-app" is not a tsuru command. See "tsuru help".\n\n\x1b[1;37;40mDid you mean?\x1b[0m\n\tcreate-app',
                                   '')) == 'tsuru create-app'


# Generated at 2022-06-12 12:31:01.880028
# Unit test for function match
def test_match():
    command = Command('tsuru service-add mongodb mydb', 'tsuru: "service-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice-add-app\n\tservice-bind\n\tservice-instance-add\n\tservice-instance-remove')
    assert match(command)



# Generated at 2022-06-12 12:31:08.758634
# Unit test for function match
def test_match():
    output = ("tsuru app-list: \"app-list\" is not a tsuru command. See \"tsuru help\"." +
              "\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-remove\n\tapp-restart\n\tapp-start\n\tapp-stop\n\tapp-swap")

    command = Command('tsuru app-list', output=output)
    assert match(command)
    assert get_new_command(command) == 'tsuru app-create'

# Generated at 2022-06-12 12:31:16.225284
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('tsuru hello', 'tsuru: "hello" is not a tsuru command. See "tsuru help".\n'
                                                  '\n'
                                                  'Did you mean?\n'
                                                  '\tteam-user-add\n'
                                                  '\tapp-log\n'
                                                  '\tapp-run\n'
                                                  '\thelp\n'
                                                  '\tapp-remove\n'
                                                  '\thealthcheck\n'
                                                  '\thelp-topics',
                                   None,
                                   None,
                                   'tsuru hello',
                                   None)) == 'tsuru help-topics'

# Generated at 2022-06-12 12:31:19.189434
# Unit test for function match
def test_match():
    command = Command('tsuruu version',
                      'tsuru: "tsuruu" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttsuru version\n')
    assert match(command)



# Generated at 2022-06-12 12:31:25.781526
# Unit test for function match
def test_match():
    output1 = 'tsuru: "hello" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelper\n\thelp'
    output2 = 'tsuru: "tsru" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsuru'

    assert match(Command('tsuru hello', output=output1))
    assert match(Command('tsru', output=output2))

    assert not match(Command('tsuru hello', output=output2))
    assert not match(Command('tsru', output=output1))



# Generated at 2022-06-12 12:31:32.943663
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru', 'tsuru: "app-log" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-log-endpoint')
    assert get_new_command(command) == 'tsuru app-log-endpoint'

# Generated at 2022-06-12 12:31:41.361230
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-deploy app-deploy', 'tsuru: "app-deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-deploy'))
    assert match(Command('tsuru app-deploy2 app-deploy', 'tsuru: "app-deploy2" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-deploy'))
    assert match(Command('tsuru app-deploy app-deploy2', 'tsuru: "app-deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-deploy2, app-deploy'))

# Generated at 2022-06-12 12:31:46.958108
# Unit test for function match
def test_match():
    import re
    import mock
    vim = mock.MagicMock()
    vim.current.buffer.options.get.return_value = 'tsuru'
    vim.command.return_value = 'tsuru app-info testapp'
    vim.current.line = 'tsuru app-info testapp'
    vim.eval.return_value = 'app-info'
    command = mock.MagicMock()
    command.script = 'app-info'
    command.output = 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-add\n\tapp-remove\n\tapp-list\n\tapp-restart\n\tapp-start'
    assert match(command)



# Generated at 2022-06-12 12:31:48.188203
# Unit test for function match
def test_match():
    command = Command("tsuru blabla")
    assert match(command)


# Generated at 2022-06-12 12:31:51.918089
# Unit test for function match
def test_match():
    match_text = 'tsuru: "scale" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tdeploy-units\n\tremove-units\n\tadd-units\n'
    assert match(Command(script=match_text)) == True


# Generated at 2022-06-12 12:31:58.932055
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-bind testapp teste',
                'tsuru: "service-bind" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice-instance-bind\tBinds an app to an instance of service'))

    assert not match(Command('tsuru', ''))
    assert not match(Command('tsuru service-instance-bind testapp teste', 'tsuru: "service-instance-bind" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice-instance-bind\tBinds an app to an instance of service'))



# Generated at 2022-06-12 12:32:07.500965
# Unit test for function match

# Generated at 2022-06-12 12:32:13.259676
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-stop',
                         '''tsuru: "app-stop" is not a tsuru command. See "tsuru help".


Did you mean?
	app-remove
	app-lock'''))

    assert not match(Command('tsuru app-stop',
                             '''tsuru: "app-stop" is not a tsuru command. See "tsuru help".


Did you mean?
	app-delete
	repository-remove'''))

    assert not match(Command('tsuru app-stop',
                             '''tsuru: "app-stop" is not a tsuru command. See "tsuru help".'''))
