

# Generated at 2022-06-12 12:22:20.998687
# Unit test for function match
def test_match():
    assert match(Command('tsuru config-get -a asd', 'tsuru: "config-get" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tconfig'))
    assert match(Command('tsuru config-get -a asd', 'tsuru: "config-get" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tconfig'))
    assert not match(Command('tsuru config-get -a asd', 'tsuru: "config-get" is not a tsuru command. See "tsuru help".\nDid you mean?'))
    assert not match(Command('tsuru config-get -a asd'))


# Generated at 2022-06-12 12:22:25.487838
# Unit test for function match
def test_match():
    os.system("touch ~/.tsuru_target")
    command = Command("tsuru target-add test_target tsuru.io", "tsuru: \"target-add\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\ttarget-add")
    assert match(command)



# Generated at 2022-06-12 12:22:34.598892
# Unit test for function match
def test_match():
    output1 = 'tsuru: "foobar" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoo\n'
    output2 = 'tsuru: "foobar" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoo\n\tbar\n'
    output3 = 'tsuru: "foobar" is not a tsuru command. See "tsuru help".\n'

    AppCommand = namedtuple('AppCommand', ['script', 'output'])
    command1 = AppCommand(script='tsuru foobar', output=output1)
    command2 = AppCommand(script='tsuru foobar', output=output2)
    command3 = AppCommand(script='tsuru foobar', output=output3)

# Generated at 2022-06-12 12:22:36.660779
# Unit test for function match
def test_match():
    assert match(Command('tsuru alis list', ''))
    assert match(Command('tsuru target-list', ''))
    assert not match(Command('tsuru login', ''))



# Generated at 2022-06-12 12:22:44.839480
# Unit test for function match

# Generated at 2022-06-12 12:22:46.270716
# Unit test for function match
def test_match():
    assert match(Command('tsuruf', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-12 12:22:50.657929
# Unit test for function get_new_command
def test_get_new_command():
    output = u"""tsuru: "app-list" is not a tsuru command. See "tsuru help".

Did you mean?
	app-list
	app-info
	app-create
	app-remove
	app-run"""
    assert get_new_command(Command('''tsuru app-list''', output)) == 'tsuru app-list'

# Generated at 2022-06-12 12:23:01.127740
# Unit test for function match

# Generated at 2022-06-12 12:23:09.544545
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n'))
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tsh\n\telse\n\tsomething'))

# Generated at 2022-06-12 12:23:15.868982
# Unit test for function match
def test_match():
    from thefuck.rules.no_command import match
    output = ("tsuru: \"app-create\" is not a tsuru command. See "
              "\"tsuru help\".\n\nRun \"tsuru --help\" for usage.\n\n"
              "Additional information:\n\tDid you mean?\n\t\tapp-create")
    assert match(output)



# Generated at 2022-06-12 12:23:23.030785
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-infor', 'tsuru: "app-infor" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n\tapp-list\n\tapp-restart\n\tapp-start\n\tapp-stop\n\nRun \'tsuru help\' to see all available commands.'))


# Generated at 2022-06-12 12:23:27.191894
# Unit test for function match
def test_match():
    assert match(Command('tsuru help app-deploy',
                         'tsuru: "help" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-deploy\n\thelp-app'))


# Unit tests for function get_new_command

# Generated at 2022-06-12 12:23:34.684370
# Unit test for function match
def test_match():
    a = get_new_command(Command('tsuru app-deploy', "tsuru: \"app-deploy\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-create\n\tapp-delete\n\tapp-info\n\tapp-list\n\tapp-log\n\tapp-remove\n\tapp-run\n\tapp-start\n\tapp-stop\n"))
    assert a == 'tsuru app-create'

# Generated at 2022-06-12 12:23:39.399306
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    test_command = "tsuru: \"target-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\ttarget-add"
    assert get_new_command(test_command) is "tsuru target-add"


enabled_by_default = False

# Generated at 2022-06-12 12:23:44.888651
# Unit test for function match
def test_match():
    re_match = "tsuru: \"curl\" is not a tsuru command. See \"tsuru help\".\n" \
               "Did you mean?\n" \
               "\tcurl-app" \
               "\tapp-curl" \
               "\tapp-router-curl" \
               "\n" \
               "Run \"tsuru help\" for usage.\n"
    assert match(Command('tsuru curl', re_match))

# Generated at 2022-06-12 12:23:48.572978
# Unit test for function get_new_command
def test_get_new_command():
    output = "tsuru: \"tsuru app-create\" is not a tsuru command. See \"tsuru help\"."
    output += "\n\nDid you mean?\n\tapp-create\n\tapp-remove"
    assert get_new_command(Command(script='', output='', stderr='')) == ''
    assert get_new_command(Command(script='', output=output, stderr='')) == 'app-create'

# Generated at 2022-06-12 12:23:57.312515
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('tsuru llogin', ''))) == \
        'tsuru app-list'
    assert (get_new_command(Command('tsuru app-list', ''))) == \
        'tsuru app-list'
    assert (get_new_command(Command('tsuru app-list $TSURU_TARGET', ''))) == \
        'tsuru app-list $TSURU_TARGET'
    assert (get_new_command(Command('tsuru app-list $TSURU_TARGET/apps', ''))) == \
        'tsuru app-list $TSURU_TARGET/apps'

# Generated at 2022-06-12 12:24:02.293061
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('tsuru is not a tsuru command',
                                   'tsuru: "is" is not a tsuru command. See "tsuru help".\nMaybe you meant "login"?\n\nDid you mean?\n\tlogin',
                                   '')) == 'tsuru login'


enabled_by_default = False

# Generated at 2022-06-12 12:24:11.816263
# Unit test for function get_new_command
def test_get_new_command():
    thefuck_alias = 'fuck'
    output = '''tsuru: "2" is not a tsuru command. See "tsuru help".

Did you mean?
	target-add
	team-remove
	team-repository-remove
	team-user-remove
	team-user-role-remove
	target-remove
	team-repository-grant
	team-user-role-set
	team-user-role-add
	team-remove-user
	team-revoke
	team-user-role-list
	team-user-role-remove
	team-remove-user
	team-revoke
	team-user-role-list
	team-user-role-remove'''
    assert get_new_command(Shell('fuck 2', output)) == 'fuck team-remove'

# Generated at 2022-06-12 12:24:13.869061
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsurur target-machines', '')) == 'tsuru target-machine-add'

# Generated at 2022-06-12 12:24:18.701294
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru abc')
    command.output = 'tsuru: "abc" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-remove'
    assert get_new_command(command) == 'tsuru app-remove'

# Generated at 2022-06-12 12:24:22.740843
# Unit test for function match
def test_match():
    assert match(Command('tsuru eroor -h', 'tsuru: "eroor" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlogin', ''))


# Generated at 2022-06-12 12:24:31.884199
# Unit test for function match

# Generated at 2022-06-12 12:24:35.519942
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    fucked_output = 'tsuru: "app-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-list\n\tapp-remove\n\n'

    command = Command('app-add', fucked_output)
    new_cmd = get_new_command(command)

    assert 'app-create' in new_cmd
    assert 'app-list' in new_cmd
    assert 'app-remove' in new_cmd

# Generated at 2022-06-12 12:24:45.787187
# Unit test for function match
def test_match():
    command_output1 = 'tsuru: "nodeaa" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-list'
    command_output2 = 'tsuru: "node-listt" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-list'
    command_output3 = 'tsuru: "node-lsit" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-list'
    assert match(Command(script='tsuru nodeaa', output=command_output1)) is True
    assert match(Command(script='tsuru node-listt', output=command_output2)) is True

# Generated at 2022-06-12 12:24:49.715219
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create foo bar', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create'))
    assert not match(Command('tsuru app-create foo bar', ''))


# Generated at 2022-06-12 12:24:53.822500
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-register foo http://app.foo.com',
                         'tsuru: "app-register" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-run\n\tapp-restart'))


# Generated at 2022-06-12 12:24:57.361849
# Unit test for function match
def test_match():
    assert match(Command('tsuru --help', "tsuru: \"--help\" is not a tsuru command. See \"tsuru help\".", ''))
    assert not match(Command('sudo apt-get install vim', 'E: Unable to locate package vim', ''))



# Generated at 2022-06-12 12:25:05.876511
# Unit test for function get_new_command

# Generated at 2022-06-12 12:25:13.350519
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('tsuru app-add',
                                   output='tsuru: "app-add" is not a tsuru command\n'
                                          '\n'
                                          'Did you mean?\n'
                                          '\tapp-create\n'
                                          '\tapp-remove')) == 'tsuru app-create'



# Generated at 2022-06-12 12:25:19.374644
# Unit test for function match
def test_match():
    assert match(Command('tsuru ps:stop app', 'tsuru ps:stop: "app" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tps\n\tdelete-app\n'))
    assert not match(Command('tsuru ps:stop app', 'tsuru ps:stop: "app" is not a tsuru command. See "tsuru help".\n'))


# Generated at 2022-06-12 12:25:26.281035
# Unit test for function match
def test_match():
    output = 'tsuru: "deploy-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tdeploy-info-app\n'
    command = Command('tsuru deploy-info', output)
    assert match(command)

    # Test when there is no match
    output = 'tsuru: "deploy-info" is not a tsuru command. See "tsuru help".'
    command = Command('tsuru deploy-info', output)
    assert not match(command)



# Generated at 2022-06-12 12:25:28.872092
# Unit test for function match
def test_match():
    command = Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help"\nDid you mean?\n\tapp-list')
    assert match(command)


# Generated at 2022-06-12 12:25:34.621756
# Unit test for function match
def test_match():
    import pytest
    from thefuck.types import Command
    from thefuck.rules.tsuru_suggestion import match
    assert match(
        Command('tsuru deploy',
                "tsuru: 'deploy' is not a tsuru command. See 'tsuru help'.\n\nDid you mean?\n\tdeploy-app\n"))
    assert not match(Command('git status', '', ''))

# Generated at 2022-06-12 12:25:40.620969
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    err_msg = 'tsuru: "dok" is not a tsuru command. See "tsuru help".\n\n'\
              'Did you mean?\n\tdocumentation\n\tdocker-exec\n\tdocker-node-add'
    command = Command('dok', err_msg)
    assert get_new_command(command) == 'tsuru documentation'

# Generated at 2022-06-12 12:25:45.888932
# Unit test for function match
def test_match():
    assert match(Command('tsuru install', 'tsuru: "install" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tinstall-app'))
    assert not match(Command('tsuru install', 'tsuru: "install" is a tsuru command. See "tsuru help".\n\nDid you mean?\n\tinstall-app'))


# Generated at 2022-06-12 12:25:51.739278
# Unit test for function match
def test_match():
    assert match(Command('tsuru stt',
                         'tsuru: "stt" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tstart\n\n\n'))
    assert match(Command('tsuruh stt',
                         'tsuru: "stt" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tstart\n\n\n'))
    assert not match(Command('tsuru stt', ''))


# Generated at 2022-06-12 12:25:57.458364
# Unit test for function match
def test_match():
    assert match(Command('tsuru foo', 'tsuru: "foo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoobar'))
    assert match(Command('tsuru', 'tsuru: "" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoo'))
    assert not match(Command('foo bar', 'Command not found'))


# Generated at 2022-06-12 12:26:07.519735
# Unit test for function match
def test_match():
    cmd = Command('tsuru start', 'tsuru: "start" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tstart-app')
    assert match(cmd)
    assert match(cmd)

# Generated at 2022-06-12 12:26:12.535400
# Unit test for function match
def test_match():
    assert (match(Command('ts ru foo', 'tsuru: "ts ru" is not a tsuru command.'
                                         ' See "tsuru help".\n\nDid you mean?'
                                         '\n\ttsurud'))
            == (True, 'ts ru'))



# Generated at 2022-06-12 12:26:19.787859
# Unit test for function match
def test_match():
    assert match(Command('tsuru deploy -a myapp --no-wait',
                         'tsuru: "deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tdeploy-app'))
    assert not match(Command('ls', ''))

# Unit tests for function get_new_command

# Generated at 2022-06-12 12:26:26.027836
# Unit test for function match
def test_match():
    # When command output is right
    command = Command('tsuru target-add', 'tsuru: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t target-add\n\ttarget-list\n')
    assert match(command)

    # When command output is wrong
    command = Command('tsuru', '')
    assert not match(command)


# Generated at 2022-06-12 12:26:28.967681
# Unit test for function match
def test_match():
    user_input = "tsuru: \"test\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\trestart"
    expected_output = True

# Generated at 2022-06-12 12:26:30.306030
# Unit test for function match
def test_match():
    assert (match(Command('tsuru app-create base')) == True)



# Generated at 2022-06-12 12:26:34.551806
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlist'))
    assert not match(Command('tsuru app-create appname', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcreate'))


# Generated at 2022-06-12 12:26:38.195281
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("tsuru apa", "tsuru: \"apa\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp\n\tapps")
    assert get_new_command(command) == "tsuru app"

# Generated at 2022-06-12 12:26:42.870633
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-create e2e-tests', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n')
    assert get_new_command(command) == 'tsuru app-create e2e-tests'

# Generated at 2022-06-12 12:26:51.509355
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('tsuru service-add mongodb',
    '''tsuru: "service-add" is not a tsuru command. See "tsuru help".
    Did you mean?
        service-bind
        service-doc
        service-info
        service-list
        service-remove
        service-status
        service-unbind''')) == 'tsuru service-doc')

    assert (get_new_command(Command('tsuru service-doc',
    '''tsuru: "service-doc" is not a tsuru command. See "tsuru help".
    Did you mean?
        service-bind
        service-add
        service-info
        service-list
        service-remove
        service-status
        service-unbind''')) == 'tsuru service-add')

# Generated at 2022-06-12 12:26:58.872868
# Unit test for function get_new_command
def test_get_new_command():
    output = ["tsuru: \"sss\" is not a tsuru command. See \"tsuru help\".",
              "Did you mean?\n        target-add\n",
              "tsuru: \"aaa\" is not a tsuru command. See \"tsuru help\".",
              "Did you mean?\n        app-create"]
    command = Command('tsuru sss', '', output)
    new_command = get_new_command(command)
    assert new_command == 'tsuru target-add'

    output = ["tsuru: \"aaa\" is not a tsuru command. See \"tsuru help\".",
              "Did you mean?\n        app-create"]
    command = Command('tsuru aaa', '', output)
    new_command = get_new_command(command)

# Generated at 2022-06-12 12:27:00.910846
# Unit test for function match
def test_match():
    assert match(Command('tsuru help app-log'))
    assert not match(Command('tsuru app-log teste'))


# Generated at 2022-06-12 12:27:08.422316
# Unit test for function match
def test_match():
    assert match(Command('tsuru: "login" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tlog', ''))
    assert not match(Command('tsuru: "login" is not a tsuru command. See "tsuru help".\n', ''))


# Generated at 2022-06-12 12:27:12.275483
# Unit test for function match
def test_match():
    assert match(Command('tsuru foo', 'tsuru: "foo" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tfoo-bar'))
    assert not match(Command('tsuru foo', 'tsuru: "foo" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-12 12:27:17.031421
# Unit test for function match
def test_match():
    assert match(Command('tsuru node-list',
                         'tsuru: "node-list" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tnode list'))
    assert not match(Command('tsuru hello', 'tsuru: "hello" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-12 12:27:22.182619
# Unit test for function match
def test_match():
    # Test 'See "tsuru help".' in command.output
    assert match(Command('tsuru pwd',
                         'tsuru: "pwd" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-list'))
    # Test 'See "tsuru help".' in command.output
    assert not match(Command('tsuru target-add', 'Error: "target-add" is not a tsuru command.'))



# Generated at 2022-06-12 12:27:26.339769
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-info test-app -a test-app')
    command.output = 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n\tapp-create'
    assert get_new_command(command) == 'tsuru app-info test-app -a test-app'

# Generated at 2022-06-12 12:27:35.689304
# Unit test for function match
def test_match():
    assert match(Command('tsuru add-key asdfasdfasdfasdf', 'tsuru: "add-key" is not a tsuru command.'))
    assert match(Command('tsuru add-key asdfasdfasdfasdf', 'tsuru: "asdfasdfasdfasdf" is not a tsuru command.'))
    assert not match(Command('tsuru add-key asdfasdfasdfasdf', 'tsuru: "add-key" is a tsuru command.'))
    assert not match(Command('tsuru add-key asdfasdfasdfasdf', 'tsuru: "asdfasdfasdfasdf" is a tsuru command.'))

# Generated at 2022-06-12 12:27:41.219696
# Unit test for function match
def test_match():
    assert(match(Command("tsuru app-info", "tsuru: \"app-info\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-create\n\tapp-delete\n\tapp-info\n\tapp-list\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-swap\n\tapp-team-list\n\tapp-tsuru-run\n\tapp-update\n\tapp-update-cname\n\n")) is True)


# Generated at 2022-06-12 12:27:45.420191
# Unit test for function match
def test_match():
    com = Command('tsuru a2-list', 'tsuru: "a2-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n')
    assert match(com)

    com = Command('tsuru a2-list', 'tsuru: command not found')
    assert not match(com)


# Generated at 2022-06-12 12:27:50.438821
# Unit test for function get_new_command
def test_get_new_command():
    wrong_command = Command('tsuru sservice-list', "tsuru: " +
                            '"sservice-list" is not a tsuru command.' +
                            ' See "tsuru help".\n\nDid you mean?' +
                            '\n\tservice-list\n')

    assert get_new_command(wrong_command) == 'tsuru service-list'


# Generated at 2022-06-12 12:27:57.782333
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('tsuru acommand', 'tsuru: "acommand" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-add-unit\n\tapp-change\n\tapp-create', '')) == 'tsuru app-add-unit'
    # Note: the "app-change" command is not in tsuru's help because it is deprecated
    # See https://github.com/tsuru/tsuru/commit/e34fafdeeb81428919bb5c5fa5fbaef17f97ed5d

# Generated at 2022-06-12 12:28:06.514848
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command.'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-12 12:28:13.637833
# Unit test for function match
def test_match():
    output_true = 'tsuru: "abcd" is not a tsuru command. See "tsuru help".'
    output_true = output_true + '\nDid you mean?\n\tapp-run'
    output_false = 'tsuru: "tsuru app-run" is not a tsuru command. See "tsuru help".'
    output_false = output_false + '\nDid you mean?\n\tapp-run'
    assert match(Command('tsuru abcd', output_true))
    assert not match(Command('tsuru abcd', output_false))


# Generated at 2022-06-12 12:28:18.673695
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsurur target add', 'tsurur: "target" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add\n\ttarget-remove\n\tservice-instance-add\n\tservice-instance-remove\n')) == 'tsuru target-add'

# Generated at 2022-06-12 12:28:24.530182
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    output = """tsuru: "teste" is not a tsuru command. See "tsuru help".

Did you mean?
	target
	team-add
	team-create
	team-remove
	team-remove-user
	team-rename
	team-update
	user-add
	user-create
	user-remove
	user-remove-key
	user-update"""
    command = type('Command', (object,),
                   {'script': 'tsuru test', 'output': output})
    new_command = get_new_command(command)
    assert new_command == "tsuru team-add"

# Generated at 2022-06-12 12:28:29.218181
# Unit test for function match
def test_match():
    assert match(Command('tsuru sdf',
                         'tsuru: "sdf" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice-add\n\tservice-bind\n\tservice-doc\n\tservice-info\n\tservice-instances\n\tservice-list\n'))

# Generated at 2022-06-12 12:28:32.652384
# Unit test for function match
def test_match():
    #The output from tsuru when user enters wrong command.
    output = 'tsuru: "tsru" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsuru\n'
    assert match(Command('tsru', output))



# Generated at 2022-06-12 12:28:38.212562
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru permisson-roles-list appname', 'tsuru: "permisson-roles-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tpermission-list\n\tpermission-set\n\tpermission-remove')) == "tsuru permission-list appname"

# Generated at 2022-06-12 12:28:39.247965
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-12 12:28:43.566957
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-inf 1', 'tsuru: "app-inf" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n'))
    assert not match(Command('tsuru app-info 1', 'App not found.\n'))


# Generated at 2022-06-12 12:28:53.169974
# Unit test for function match
def test_match():
    assert match(Command('tsuruh app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tapp-create\n\tapp-list\n'))
    assert match(Command('tsuruh app-create', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tapp-create\n\tapp-list\n'))
    assert match(Command('tsuruh app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tapp-create\n\tapp-list\n'))

# Unit test

# Generated at 2022-06-12 12:29:00.284185
# Unit test for function match
def test_match():
    assert match(Command("tsuru app-list", ""))
    assert not match(Command("tsuru app-list", "tsuru: \"app-list\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tapp-info, app-list, app-restart, app-start"))


# Generated at 2022-06-12 12:29:07.059627
# Unit test for function get_new_command
def test_get_new_command():
    # command = Command('tsuru app-info TESTE-APP', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-start')
    command = Command('tsuru app-info TESTE-APP', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-start\n\tapp-restart')
    assert get_new_command(command) == 'tsuru app-start TESTE-APP'


# Generated at 2022-06-12 12:29:11.986659
# Unit test for function match
def test_match():
    # Testing true cases
    command_output = 'tsuru: "target-addblahblah" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add'
    assert(match(Command(script='tsuru target-addblahblah', output=command_output)) == True)



# Generated at 2022-06-12 12:29:15.928523
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru team add',
                                   'tsuru: "team" is not a tsuru command. See "tsuru help".'
                                   '\nDid you mean?\n\tteams-add')) == 'tsuru teams-add'

    assert get_new_command(Command('tsuru user-list',
                                   'tsuru: "user-list" is not a tsuru command. See "tsuru help".'
                                   '\nDid you mean?\n\tuser-change-password\n\tuser-create\n\tuser-info')) == 'tsuru user-list'

# Generated at 2022-06-12 12:29:19.534754
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-list | wc -l',
                                   "tsuru: \"app-list | wc -l\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tapp-list")) == 'tsuru app-list'


# Generated at 2022-06-12 12:29:25.982499
# Unit test for function match
def test_match():
    from thefuck.types import Command

    assert match(Command('tsuru app-list',
                         'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create'))

    # It's not a tsuru command
    assert not match(Command('ls'))
    # No suggestions
    assert not match(Command('tsuru abc',
                             'tsuru: "abc" is not a tsuru command. See "tsuru help".'))
    # No target command
    assert not match(Command('tsuru',
                             'tsuru: "abc" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list', ''))

# Generated at 2022-06-12 12:29:28.492396
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-info')
    result = get_new_command(command)
    assert result[0] == 'tsuru app-info'
    assert result[1] == 'tsuru app-info'

# Generated at 2022-06-12 12:29:37.926480
# Unit test for function match
def test_match():
    assert match(Command('tsuru help', u'Usage: tsuru [--version] [--help] '
                         u'<command> [<args>]\n\nSome useful tsuru commands are:\n    '
                         u'app-create  Creates a new app.\n    app-remove   Removes an '
                         u'app.\n\nSee "tsuru help <command>" for more information about '
                         u'a command.\n\ntsuru: "helo" is not a tsuru command. See "tsuru'
                         u' help".\n\nDid you mean?\n\thelp\n', '', 0)) is True


# Generated at 2022-06-12 12:29:42.703637
# Unit test for function match
def test_match():
    assert match(Command('tsuru a',
                         'tsuru: "a" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-add\n\tapp-change\n\tapp-create'))
    assert not match(Command('tsuru a', 'tsuru: "a" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-12 12:29:47.825086
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "router-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\trouter-add-app'
    assert get_new_command(Command('tsuru router-add blah blah blah', output=output)) == 'tsuru router-add-app blah blah blah'


enabled_by_default = True
priority = 5000

# Generated at 2022-06-12 12:30:02.420706
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\nRun "tsuru help" for usage.'))
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-log\n\nRun "tsuru help" for usage.'))

# Generated at 2022-06-12 12:30:08.280462
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-bind redis myapp',
                         stderr='tsuru: "service-bind" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice-add\n\tservice-add-instance\n\tservice-doc\n\tservice-list'))
    assert not match(Command('tsuru service-bind redis myapp',
                         stderr='tsuru: "service-bind" is not a tsuru command'))

# Generated at 2022-06-12 12:30:12.337320
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create asdfasdfasdf','''tsuru app-create: "asdfasdfasdf" is not a tsuru command. See "tsuru help".

Did you mean?
	app-create'''))



# Generated at 2022-06-12 12:30:16.161586
# Unit test for function match
def test_match():
    assert match(Command('tsuru oi',
                         'tsuru: "oi" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n\tapp-log',
                         ''))

    assert not match(Command('tsuru app-list',
                             'No apps available. Please create some with "tsuru app-create".',
                             ''))


# Generated at 2022-06-12 12:30:20.584934
# Unit test for function match
def test_match():
    command = Command(script='tsuru', stderr='tsuru: "tsururu" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttsuru')
    assert match(command)
    assert match(command) is True


# Generated at 2022-06-12 12:30:24.047051
# Unit test for function match
def test_match():
    command_output = """tsuru: "targz" is not a tsuru command. See "tsuru help".

Did you mean?
        target
"""
    assert match(Command('targz', '', command_output))
    assert not match(Command('targz', ''))
    assert not match(Command('targz', '', ''))



# Generated at 2022-06-12 12:30:34.057371
# Unit test for function match

# Generated at 2022-06-12 12:30:38.169283
# Unit test for function match
def test_match():
    assert match(Command('ignored tsuru permission-regrant', ''))
    assert match(Command('ignored tsuru permission-regrant', 'tsuru: "permission-regrant" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tpermission-regrant'))
    assert not match(Command('ignored tsuru', ''))



# Generated at 2022-06-12 12:30:47.366216
# Unit test for function match
def test_match():
    assert match(Command('tsuru config-change -a myapp',
                         'tsuru: "config-change" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tconfig-set; config-unset\n'))
    assert match(Command('tsuru config-set key2 val2',
                         'tsuru: "config-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tconfig-change; config-unset\n'))
    assert match(Command('tsuru config-unset key2',
                         'tsuru: "config-unset" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tconfig-change; config-set\n'))

# Generated at 2022-06-12 12:30:56.728820
# Unit test for function match
def test_match():
    assert match(Command('tsuru aaa', 'tsuru: "aaa" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-add\n\tapp-create\n\tapp-list\n\tapp-remove\n\tplan-add\n\tplan-create\n\tplan-list\n\tplan-remove\n\tplatform-add\n\tplatform-create\n\tplatform-list\n\tplatform-remove\n\trun', ''))

# Generated at 2022-06-12 12:31:14.363344
# Unit test for function match
def test_match():
    output = ('tsuru: "turtle" is not a tsuru command. See "tsuru help".\n'
    '\n'
    'Did you mean?\n'
    '\ttarget')
    assert match(Command('turtle', output=output)) is True
    assert match(Command('target', output=output)) is False
    assert match(Command('turtle', output='')) is False


# Generated at 2022-06-12 12:31:20.310899
# Unit test for function match
def test_match():
    # Check if function match calls the function re when the argument command
    # is a string
    assert match('tsuru: "comando" is not a tsuru command. See "tsuru help".\nDid you mean?\n  com\n  camando')
    # Check if function match returns False when the argument command is not a
    # string
    assert not match(None)
    # Check if function match returns False when the argument command is a
    # string
    assert not match('tsuru: Command "comando" is not a tsuru command. See "tsuru help".')


# Generated at 2022-06-12 12:31:22.950239
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru cmd1',
                                   'tsuru: "cmd1" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tcommand1')) == 'tsuru command1'

# Generated at 2022-06-12 12:31:31.518483
# Unit test for function match
def test_match():
    assert not match(Command('tsuru app-info'))
    assert match(Command('tsuru foo'))
    assert match(Command('tsuru version'))
    assert match(Command('tsuru version'))
    assert match(Command('tsuru app-create'))
    assert match(Command('tsuru app-remove'))
    assert match(Command('tsuru app-delete'))
    assert match(Command('tsuru app-update'))
    assert match(Command('tsuru app-deprovision'))
    assert match(Command('tsuru app-deprovision -a'))
    assert match(Command('tsuru app-deprovision -s'))
    assert match(Command('tsuru app-deprovision -f'))
    assert match(Command('tsuru app-run'))

# Generated at 2022-06-12 12:31:36.156635
# Unit test for function match
def test_match():
    match2 = False
    test_output = '''tsuru: "test" is not a tsuru command. See "tsuru help".

Did you mean?
        test
        test-ssh'''
    mock_command = type('obj', (object,), {'script': 'tsuru test', 'output': test_output, 'env': {}})
    match2 = match(mock_command)
    assert match2


# Generated at 2022-06-12 12:31:40.686537
# Unit test for function match
def test_match():
    assert match(Command('tsuru servicesssssssssssssssssss', '', '', 0, None))
    assert not match(Command('tsuru servicesssssssssssssssssss', '', '', 0, ''))
    assert not match(Command('tsuru servicesssssssssssssssssss', '', '', 0, '1'))


# Generated at 2022-06-12 12:31:43.439960
# Unit test for function match
def test_match():
    assert match('tsuru: "test" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tcreate-app\n\tcreate-permission')
    assert not match('tsuru: "test" is not a tsuru command. See "tsuru help".')
    assert not match('this command does not have a typo')


# Generated at 2022-06-12 12:31:45.449992
# Unit test for function match
def test_match():
    assert match(Command('tsuru wo-oh', 'tsuru: "wo-oh" is not a tsuru command. '
                         'See "tsuru help".'
                         '\nDid you mean?\n\twhoami'))
    assert not match(Command('tsuru wo-oh', ''))

# Generated at 2022-06-12 12:31:50.439638
# Unit test for function get_new_command
def test_get_new_command():
    output = ("tsuru: \"target-get\" is not a tsuru command. See \"tsuru help\"."+'\n'+
        "Did you mean?\n\ttarget-add\n\ttarget-remove\n\ttarget-list")
    command = Command("tsuru target-get", output)
    new_command = get_new_command(command)
    assert new_command == "tsuru target-add"

# Generated at 2022-06-12 12:31:58.051193
# Unit test for function match
def test_match():
    assert match(Command('tsuru env-set --app app -e NAME=VALUE',
                         'tsuru: "env-set --app" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tadd-key\n\tapp-create\n\tapp-info\n\tapp-log\n\tapp-remove\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-swap\n\tapp-team-set\n\tapp-unset\n\tapp-update\n\tapp-yaml\n\tassign-app-role\n\tbind-app'))
