

# Generated at 2022-06-12 12:22:19.423259
# Unit test for function get_new_command
def test_get_new_command():
    output = """tsuru: "app-create" is not a tsuru command. See "tsuru help".

Did you mean?
    app-add-unit
    app-remove-unit
    app-change-units"""

    assert get_new_command(FakeCommand("tsuru app-create", output)) == "tsuru app-add-unit"

# Generated at 2022-06-12 12:22:28.301375
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-stop', 'tsuru: "app-stop" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tapp-remove'))
    assert match(Command('tsuru hello-world-stop', 'tsuru: "hello-world-stop" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\thello-world-remove'))
    assert not match(Command('tsuru app-stop', 'tsuru: "app-remove" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsur', 'tsuru: "tsur" is not a tsuru command. See "tsuru help".'))



# Generated at 2022-06-12 12:22:32.995145
# Unit test for function match
def test_match():
    assert match(Command('tsuru user-create ceposta', 'tsuru: "user-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tuser-create\n\tuser-remove\n', '', 0))
    assert not match(Command('tsuru', '', '', 0))


# Generated at 2022-06-12 12:22:36.435798
# Unit test for function match
def test_match():
    command = Command("tsuru app-not-exists",
                      "tsuru: \"app-not-exists\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-remove")
    assert match(command)


# Generated at 2022-06-12 12:22:44.536562
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list testing-example',
                   'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\n\x1b[1;31mDid you mean?\n\tapp-list\x1b[0m\n\x1b[1;31m\n'))
    assert match(Command('tsuru app-list testing-example',
                   'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n')) == False

# Generated at 2022-06-12 12:22:48.779238
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('tsuru app-chpwn app-chpwn',
                         'tsuru: "app-chpwn" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-change-pool'))
    assert not match(Command('tsuru', ''))


# Generated at 2022-06-12 12:22:51.857227
# Unit test for function match
def test_match():
    assert match(Command('sudo tsuru app-list', "tsuru: \"app-list\" is not a tsuru command. See \"tsuru help\"."))
    assert not match(Command("ls", ""))


# Generated at 2022-06-12 12:22:59.139744
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info mongodb-sudosh',
                         'tsuru: "mongodb-sudosh" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n\tapp-log',
                         'tsuru app-log mongodb-sudosh',
                         'tsuru app-info mongodb-sudosh -a mongodb-sudosh'))


# Generated at 2022-06-12 12:23:02.012611
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'output': 'tsuru: "env" is not a tsuru command. See "tsuru help".'})

    assert get_new_command(command) == 'tsuru env'

# Generated at 2022-06-12 12:23:03.036136
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru app-create foo bar'))


# Generated at 2022-06-12 12:23:08.050394
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-create example-app', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcreate-app', '')
    assert get_new_command(command) == 'tsuru create-app example-app'

# Generated at 2022-06-12 12:23:11.112950
# Unit test for function match
def test_match():
    assert(match(Command('tsuru find', 'tsuru: "find" is not a tsuru command. See "tsuru help".')) is True)


# Generated at 2022-06-12 12:23:13.253767
# Unit test for function match
def test_match():
    assert not match(Command('tsuruu --help'))
    assert match(Command('tsuru asasas --help'))



# Generated at 2022-06-12 12:23:23.540861
# Unit test for function match
def test_match():
    # test output with single suggestion
    output_single = """tsuru: "he" is not a tsuru command. See "tsuru help".

Did you mean?
	help"""
    command = type('', (), {'output': output_single})()
    assert match(command) is True
    
    # test output with multiple suggestions
    output_multiple = """tsuru: "he" is not a tsuru command. See "tsuru help".

Did you mean?
	help
	node-list"""
    command = type('', (), {'output': output_multiple})()
    assert match(command) is True

    # test output with no suggestions
    output_no_suggestions = """tsuru: "he" is not a tsuru command. See "tsuru help"."""

# Generated at 2022-06-12 12:23:28.748153
# Unit test for function match
def test_match():
    output = """tsuru: "service-bind" is not a tsuru command. 
See "tsuru help".

Did you mean?
        service-doc
        service-instance-list
        service-info
        service-list
        service-remove
        service-add
        service-instance-add
        service-unbind
        service-instance-remove"""

    assert match(Command("tsuru service-bind", output))
    assert not match(Command("tsuru service-remove", output))



# Generated at 2022-06-12 12:23:34.253840
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-deploy somthing -a xpto', 'tsuru: "app-deploy" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tdeploy, deploy-doc\n')) == 'tsuru deploy somthing -a xpto'


enabled_by_default = True

# Generated at 2022-06-12 12:23:39.207269
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru hello', 'tsuru: "hello" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp\n\thealthcheck-bind\n\thealthcheck-unbind\n\tpermission-add\n\tpermission-remove\n\tpermission-set')
    assert get_new_command(command) == 'tsuru help'

# Generated at 2022-06-12 12:23:44.986289
# Unit test for function match
def test_match():
    assert match(Command("tsuru target-add 8.8.8.8:8080",
                         "tsuru: \"target-add\" is not a tsuru command. See \"tsuru help\"."
                         "\n\nDid you mean?\n\ttarget-add"))

# Generated at 2022-06-12 12:23:46.600255
# Unit test for function match
def test_match():
    assert match(Command('tsur: --help'))
    assert not match(Command('tsuru --help'))


# Generated at 2022-06-12 12:23:51.791934
# Unit test for function match
def test_match():
    output = 'Error: tsuru: "test" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-test\n\tapp-deploy\n\tapp-run-command'
    assert match(Command('test', output=output))
    output = 'Error: tsuru: "test" is not a tsuru command. See "tsuru help".'
    assert match(Command('test', output=output))
    output = 'tsuru: "test" is not a tsuru command. See "tsuru help".'
    assert not match(Command('test', output=output))


# Generated at 2022-06-12 12:24:01.434825
# Unit test for function match
def test_match():
    output="tsuru: \"gis\" is not a tsuru command. See \"tsuru help\".\n\n\nDid you mean?\n\tgit"
    command = type('obj', (object,), {'output': output})
    assert match(command)
    output="tsuru: \"git\" is not a tsuru command. See \"tsuru help\".\n\n\nDid you mean?\n\tgit"
    command = type('obj', (object,), {'output': output})
    assert match(command)


# Generated at 2022-06-12 12:24:06.999526
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command


# Generated at 2022-06-12 12:24:14.199032
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info ap', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-change\n\tapp-create\n\tapp-deploy\n\tapp-list\n\tapp-log\n\tapp-remove\n\tapp-restart\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-swap\n\tapp-update\n\tapp-info'))


# Generated at 2022-06-12 12:24:16.957941
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-add http://target', 'tsuru: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add'))
    assert not match(Command('tsuru target-add http://target', ''))


# Generated at 2022-06-12 12:24:19.883495
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    output = '''tsuru: "target-set" is not a tsuru command. See "tsuru help".

Did you mean?
	target
'''

    assert get_new_command(Command('tsuru target-set', output)) == 'tsuru target'

# Generated at 2022-06-12 12:24:30.074376
# Unit test for function get_new_command

# Generated at 2022-06-12 12:24:36.066501
# Unit test for function match
def test_match():
    # f = open("test_match.txt", "r")
    # output = f.read()
    output = "tsuru: \"renew\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tremove-key\n\tremove-key-file\n\tremove-key-repo\n\trollback\n\trouter-remove\n\trouter-set\n\trouter-update"
    command = Command('tasdasdasd', output)
    assert match(command)


# Generated at 2022-06-12 12:24:41.102941
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru unit-status', 'tsuru: "unit-status" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tunit-status')).script == 'tsuru unit-status'
    assert get_new_command(Command('tsuru unit-status a b c', 'tsuru: "unit-status" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tunit-status')).script == 'tsuru unit-status'

# Generated at 2022-06-12 12:24:47.616265
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    input_output = Command('tsuru target-set http://192.168.50.4:8080',
                           'tsuru: "target-set" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-add\ntarget-remove\n')
    assert get_new_command(input_output).script == 'tsuru target-add http://192.168.50.4:8080'

# Generated at 2022-06-12 12:24:49.982621
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-add saas foo.com', 'tsuru: "target-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-add'))
    assert not match(Command('tsuru --help', ''))


# Generated at 2022-06-12 12:24:54.888608
# Unit test for function match
def test_match():
    assert match(Command('tsuru logout', "tsuru: \"logout\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tlogin"))



# Generated at 2022-06-12 12:25:04.090891
# Unit test for function match
def test_match():
    # case 1: tsru: "target-list" is not a tsuru command. See "tsuru help".
    command1 = "tsuru: \"target-list\" is not a tsuru command. See \"tsuru help\"."
    assert match(command1)
    # case 2: tsuru: "deploy" is not a tsuru command. See "tsuru help".
    # Did you mean?
    # 	app-deploy
    command2 = "tsuru: \"deploy\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tapp-deploy\n"
    assert match(command2)
    # case 3: tsuru: "target" is not a tsuru command. See "tsuru help".
    # Did you mean?
    # 

# Generated at 2022-06-12 12:25:07.792186
# Unit test for function match
def test_match():
    output = 'tsuru: "user-create" is not a tsuru command.\n'
    output += 'See "tsuru help".\n\n'
    output += 'Did you mean?\n\t'
    assert match(Command('', output=output))



# Generated at 2022-06-12 12:25:14.572831
# Unit test for function match
def test_match():
    command = Command("tsuru-foo", "tsuru: \"tsuru-foo\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tteam-list\n\n")
    assert match(command)
    assert not match(Command("tsuru foo", "tsuru: \"tsuru foo\" is not a tsuru command"))


# Generated at 2022-06-12 12:25:18.723430
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Cmd', (), {'script': 'tsuru app-create app1',
                               'output': 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n'})()
    new_command = get_new_command(command)
    assert new_command == 'tsuru app-create app1'

# Generated at 2022-06-12 12:25:28.214910
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info', "tsuru app-info: 'app-info' is not a tsuru command. See 'tsuru help'.\n\nDid you mean?\n\tapp-info"))
    assert not match(Command('tsuru app-info', "tsuru app-info: 'app-info' is not a tsuru command. See 'tsuru help'.\n\n"))
    assert match(Command('tsuru app-info', 'tsuru app-info: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tinfo app\n\tinfo-app'))

# Generated at 2022-06-12 12:25:32.499885
# Unit test for function match
def test_match():
    expected = ('tsuru platform-add &lt;name&gt; &lt;dockerfile&gt; &lt;dockerfilepath&gt; ' +
                'is not a tsuru command. See "tsuru help".\n\n' +
                'Did you mean?\n\t' +
                'platform-add\n\tplatform-remove\n\tservice-add\n\tservice-remove')
    assert match(Command('tsuru foo bar baz', expected))
    assert not match(Command('tsuru foo bar baz', 'ERROR'))


# Generated at 2022-06-12 12:25:37.029675
# Unit test for function match
def test_match():
    command = Command('tsuru app-list', '''tsuru: "app-list" is not a tsuru command. See "tsuru help".


Did you mean?
    app-list
    app-log
    app-remove

''')
    assert match(command) == True


# Generated at 2022-06-12 12:25:43.298148
# Unit test for function match
def test_match():
    command = Command('tsuru service-bind myservice myapp', 'tsuru: "service-bind" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice-bind\n\nRun tsuru help for a full command list.')
    assert match(command) is True
    command = Command('tsuru servic-bind myservice myapp', '')
    assert match(command) is False


# Generated at 2022-06-12 12:25:50.652973
# Unit test for function get_new_command
def test_get_new_command():
    # Given
    tsuru_command = "tsuru app-list\nERROR: 'app-list' is not a tsuru command. See 'tsuru help'.\n\nDid you mean?\n\tapp-create\n\tapp-deploy\n\tapp-end\n\tapp-info\n\tapp-log\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapps-list"

    # When
    new_command = get_new_command(tsuru_command)

    # Then
    assert(new_command == "tsuru app-create")

# Generated at 2022-06-12 12:26:05.636806
# Unit test for function match
def test_match():
    # Check for match if output is invalid tsuru command
    match_output_1 = Command('tsuru aaplication-info',
                             error_output='tsuru: "aaplication-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapplication-info\n')

    assert match(match_output_1)

    # Check for no match if output is not invalid tsuru command
    false_match_output_1 = Command('tsuru app-info',
                                   output='app-foo')

    assert not match(false_match_output_1)

    # Check for match if output is invalid tsuru command and there are more than one corrections

# Generated at 2022-06-12 12:26:08.204187
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-add a.b.c', ''))
    assert not match(Command('tsuru target-add', ''))


# Generated at 2022-06-12 12:26:17.571573
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru create-app something', 'tsuru: "create-app" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcreate-app-router\n\tcreate-app-unit\n\tcreate-healer-unit\n\tcreate-node-container-unit\n\tcreate-swap-unit')) == 'tsuru create-app-router something'

# Generated at 2022-06-12 12:26:28.174255
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    new_command = get_new_command(Command('tsur test', 'tsuru: "test" is not a tsuru command. See "tsuru help".\nDid you mean?\\n\\tapp\\ntsuru app', ''))
    assert new_command == 'tsuru app'
    new_command = get_new_command(Command('tsur test', 'tsuru: "test" is not a tsuru command. See "tsuru help".\\nDid you mean?\\n\\tapp\\ntsuru app', ''))
    assert new_command == 'tsuru app'

# Generated at 2022-06-12 12:26:35.410980
# Unit test for function match
def test_match():
    assert match(Command('tsuru command', 'tsuru: "command" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp', '', 1))
    assert not match(Command('tsuru', 'tsuru: "tsuru" is not a tsuru command', '', 1))
    assert not match(Command('tsurur', 'tsuru: "tsuru" is not a tsuru command', '', 1))
    assert not match(Command('tsurur', 'tsuru: "tsurur" is not a tsuru command', '', 1))
    assert not match(Command('sturur', 'tsuru: "sturur" is not a tsuru command', '', 1))


# Generated at 2022-06-12 12:26:45.768289
# Unit test for function match
def test_match():
    assert match(Command('tsuru ap', 'tsuru: "ap" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps'))
    assert not match(Command('tsuru apps', 'tsuru: "apps" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps'))
    assert not match(Command('tsuru app', 'tsuru: "app" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps'))
    assert not match(Command('tsuru appa', 'tsuru: "appa" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps'))


# Generated at 2022-06-12 12:26:53.234700
# Unit test for function match
def test_match():
    """Match should only be true for commands given by the user that have
    typos and have the 'Did you mean?' phrase in the output"""
    # Correct command
    assert match(Command('tsuru app-create', '')) is False

    # Typos and 'Did you mean?'
    command = Command('tsuru app-creat', '')
    command.output = 'tsuru: "app-creat" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create'
    assert match(command) is True

    # No 'Did you mean?'
    command = Command('tsuru app-creat', '')
    command.output = 'tsuru: "app-creat" is not a tsuru command. See "tsuru help".'
    assert match(command) is False

    # No

# Generated at 2022-06-12 12:26:59.440005
# Unit test for function match
def test_match():
    from thefuck.rules.tsuru_command_not_found import match
    command = Command('tsuru search-app is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tsearch-rep', None)
    assert match(command) == True
    command = Command('tsuru search-app is not a tsuru command. See "tsuru help".\n\n', None)
    assert match(command) == False
    command  = Command('tsuru search-app is not a tsuru command.\n\nDid you mean?\n\tsearch-rep', None)
    assert match(command) == False


# Generated at 2022-06-12 12:27:09.084080
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    # expected output contains 'Did you mean?'
    output = '''tsuru: "events" is not a tsuru command. See "tsuru help".

Did you mean?
	events'''
    assert get_new_command(Command('events', output=output)) == 'tsuru events'

    # expected output without 'Did you mean?'
    output = '''tsuru: "events" is not a tsuru command. See "tsuru help".

This is a tsuru command:
	events'''
    assert get_new_command(Command('events', output=output)) == 'tsuru events'

    # expected output with '?' character
    output = '''tsuru: "?" is not a tsuru command. See "tsuru help".

Did you mean?
	events'''

# Generated at 2022-06-12 12:27:12.366392
# Unit test for function match
def test_match():
    output = 'tsuru: "logs" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlog-add'
    command = Command('tsuru logs', output)
    assert match(command)



# Generated at 2022-06-12 12:27:25.390550
# Unit test for function get_new_command
def test_get_new_command():
    assert ('tsuru app-list' == get_new_command(
        Command('tsuru app-lis',
                "tsuru: \"app-lis\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-list")))

# Generated at 2022-06-12 12:27:31.160792
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info  teste', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-remove\n\tapp-info\n\tapp-create\n\tapp-update\n\tapp-deploy\n\tapp-log\n\tapp-grant\n\tapp-revoke\n\tapp-restart\n'))


# Generated at 2022-06-12 12:27:37.584370
# Unit test for function get_new_command
def test_get_new_command():
    sample_output = """tsuru: "ttsuru" is not a tsuru command. See "tsuru help".


Did you mean?
	target-remove
	team-create
	team-destroy
	target-list
	team-list
	team-remove-user
	team-rename
	team-add-user
	target-set
"""

    sample_command = Command('tsuru ttsuru', sample_output)
    assert get_new_command(sample_command) == "tsuru target-remove"

# Generated at 2022-06-12 12:27:43.203170
# Unit test for function get_new_command
def test_get_new_command():
    output = ("ERROR: tsuru: \"app-lsit\" is not a tsuru command.\nSee "
              "\"tsuru help\".\n\nDid you mean?\n\tapp-list\n\tapp-log\n\tapp-"
              "run\n\tapp-update")

    assert get_new_command(Command('tsuru app-lsit', output))[0] == 'tsuru app-list'


enabled_by_default = True

# Generated at 2022-06-12 12:27:49.518566
# Unit test for function get_new_command

# Generated at 2022-06-12 12:27:58.634680
# Unit test for function match
def test_match():
    # Function match return True if command output
    # contains ' is not a tsuru command. See "tsuru help".'
    # AND '\nDid you mean?\n\t'
    assert match(Command('tsuru myapp-silva', 'tsuru: "myapp-silva" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-delete\n\tapp-remove\n\tapp-info\n\tapp-log\n\tapp-run\n\tapp-list\n\tapp-update'))
    assert not match(Command('tsuru myapp-silva', 'tsuru: "myapp-silva" is not a tsuru command. See "tsuru help".'))
    assert not match

# Generated at 2022-06-12 12:28:01.199135
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info'))
    assert match(Command('tsuru app-info', 'Did you mean?\n\tapp-info'))
    assert not match(Command('tsuru'))


# Generated at 2022-06-12 12:28:08.216802
# Unit test for function match
def test_match():
    # This is mocked out command object for unit testing.
    command = type('MockCommand', (object,), {
        'script': 'tsuru version',
        'output': 'tsuru: "version" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tversions',
        'stderr': ''
    })
    assert match(command)
    command = type('MockCommand', (object,), {
        'script': 'tsuru version',
        'output': 'tsuru: "version" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tversions',
        'stderr': ''
    })
    assert not match(command)



# Generated at 2022-06-12 12:28:17.818048
# Unit test for function match
def test_match():
    assert match(Command('tsuru env-set something DATABASE_HOST', 'tsuru: "env-set" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tenv-get\n\tenv-unset\n'))
    assert match(Command('tsuru env-set something DATABASE_HOST', 'tsuru: "env-set" is not a tsuru command. See "tsuru help".')) == False
    assert match(Command('tsuru env-set something DATABASE_HOST', 'tsuru: "env-set" is not a tsuru command.\nDid you mean?\n\tenv-get\n\tenv-unset\n')) == False


# Generated at 2022-06-12 12:28:20.794102
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create hello', u'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n'))


# Generated at 2022-06-12 12:28:43.726098
# Unit test for function match
def test_match():
    assert match(Command('tsuru bla', 'tsuru: "bla" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tblock', '', 0)) == True


# Generated at 2022-06-12 12:28:49.065280
# Unit test for function match
def test_match():
    output = 'tsuru: "tsuru not found" is not a tsuru command. See "tsuru help".\
    \n\nDid you mean?\n\tnot-found-service\n\tnode-container-info\n\tnode-list\
    \n\tnode-remove'
    assert match(Command('tsuru not found', output))


# Generated at 2022-06-12 12:28:52.598065
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-remove', 'tsuru: "app-remove" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-remove\n\tremove-app')
    assert get_new_command(command) == 'tsuru remove-app'

# Generated at 2022-06-12 12:28:56.225045
# Unit test for function match
def test_match():
    command="""tsuru: "doc" is not a tsuru command. See "tsuru help".

Did you mean?
	delete-key
	env-get
	key-add
	key-remove
	key-list
	deploy
	router-remove
	router-add"""
    assert match(Command(command, ""))
    assert not match(Command("foo", ""))


# Generated at 2022-06-12 12:29:00.494043
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('tsuru status',
                      'tsuru: "status" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tstatus-app')
    assert get_new_command(command) == 'tsuru status-app'


enabled_by_default = False
priority = 900

# Generated at 2022-06-12 12:29:06.059582
# Unit test for function match
def test_match():
    # Tsuru with no command
    assert match(Command('tsuru', ''))
    # Tsuru with a random command
    assert match(Command('tsuru', 'random'))
    # Tsuru with no command and a random output
    assert not match(Command('tsuru', '', 'Something completely random.'))
    # Tsuru with a random command and a random output
    assert not match(Command('tsuru', 'random', 'Something completely random.'))


# Generated at 2022-06-12 12:29:10.047675
# Unit test for function match
def test_match():
    output = ("tsuru: \"tsuru apps-deploy\" is not a tsuru command. See "
             "\"tsuru help\".\n\nDid you mean?\n\tapps-list\n\tapp-log")
    command = Command('tsuru app-deploy', output)
    assert match(command)

# Generated at 2022-06-12 12:29:16.937695
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='tsuru login tsuru.io',
                                   stdout="tsuru: \"login\" is not a tsuru"
                                   " command. See \"tsuru help\".\n"
                                   "Did you mean?\n"
                                   "\tlog-in\n"
                                   "\tlog-out")) == 'tsuru log-in tsuru.io'

# Generated at 2022-06-12 12:29:21.383438
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('tsuru app-list',
                         'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tremove-unit',
                         ''))
    assert not match(Command('tsuru', '', ''))
    assert not match(Command('tsuru app-list', '', ''))


# Generated at 2022-06-12 12:29:24.020308
# Unit test for function match
def test_match():
    assert match(Command('tsuru ola',
        "tsuru: \"ola\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-add\n\tapp-remove"))


# Generated at 2022-06-12 12:30:07.365221
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-remove '
                                   'test --force',
                                   'tsuru: "app-remove" is not a tsuru '
                                   'command. See "tsuru help".'
                                   '\nDid you mean?\n\tapp-remove')) == 'tsuru app-remove test --force'

# Generated at 2022-06-12 12:30:12.177168
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru log',
                      'tsuru: "log" is not a tsuru command. See "tsuru help".\n\n\tDid you mean?\n\t\tlogs\n\t\tlogin',
                      '', 0)
    assert get_new_command(command) == 'tsuru logs'

# Generated at 2022-06-12 12:30:14.123836
# Unit test for function match

# Generated at 2022-06-12 12:30:20.662678
# Unit test for function match
def test_match():
    output = 'tsuru: "hello" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp\n\tservice-add\n\tservice-bind\n\tservice-doc\n\tservice-info\n\tservice-list\n\tservice-remove\n\tservice-unbind\n\tservice-update\n'
    assert match(Command('tsuru hello', output, None))


# Generated at 2022-06-12 12:30:23.664736
# Unit test for function match
def test_match():
    assert match(Command('tsuru asd', 'tsuru: "asd" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp', ''))
    assert match(Command('tsuru asd', '', '')) is None



# Generated at 2022-06-12 12:30:30.158927
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-aaaaaasdasd', 'tsuru: "app-aaaaaasdasd" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-aaa\n')) == True
    assert match(Command('tsuru app-aaaaaasdasd', 'tsuru: "app-aaaaaasdasd" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n')) == True

# Generated at 2022-06-12 12:30:33.597456
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-info'))


# Generated at 2022-06-12 12:30:37.762336
# Unit test for function match
def test_match():
    # If there is no error message, it should return None
    assert match(Command('tsuru app-list', '')) is None

    # If there is an error message, it should return True
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create')) is not None



# Generated at 2022-06-12 12:30:44.834389
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-log', '', 1))
    assert not match(Command('tsuru', 'tsuru: "app" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-log', '', 1))
    assert not match(Command('tsuru app-list', '', '', 1))


# Generated at 2022-06-12 12:30:51.312168
# Unit test for function match
def test_match():
    assert match(Command('tsuru env-set DATABASE_HOST="localhost"',
                         'tsuru: "env-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tenv-get'))
    assert not match(Command('tsuruuuuu env-set',
                         'tsuru: "tsuruuuuu" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru env-set DATABASE_HOST="localhost"', ''))
