

# Generated at 2022-06-18 08:55:16.072164
# Unit test for function get_new_command

# Generated at 2022-06-18 08:55:22.144617
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-remove\n\tapp-deploy'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-18 08:55:31.736729
# Unit test for function match

# Generated at 2022-06-18 08:55:36.273587
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('tsuru app-info',
                                   'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info',
                                   '')) == 'tsuru app-info'

# Generated at 2022-06-18 08:55:43.137919
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command


# Generated at 2022-06-18 08:55:53.098299
# Unit test for function match

# Generated at 2022-06-18 08:55:58.424466
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-18 08:56:08.642294
# Unit test for function match

# Generated at 2022-06-18 08:56:18.934692
# Unit test for function match

# Generated at 2022-06-18 08:56:24.596227
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-remove\n\tapp-restart\n\tapp-start\n\tapp-stop\n\tapp-swap\n\tapp-update')
    assert get_new_command(command) == 'tsuru app-create'

# Generated at 2022-06-18 08:56:35.276016
# Unit test for function get_new_command

# Generated at 2022-06-18 08:56:43.655282
# Unit test for function match

# Generated at 2022-06-18 08:56:51.850216
# Unit test for function match

# Generated at 2022-06-18 08:57:00.480265
# Unit test for function match

# Generated at 2022-06-18 08:57:09.613484
# Unit test for function get_new_command

# Generated at 2022-06-18 08:57:17.754745
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-remove'))


# Generated at 2022-06-18 08:57:26.983051
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-info')) == 'tsuru app-info'
    assert get_new_command(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-info\n\tapp-list')) == 'tsuru app-list'

# Generated at 2022-06-18 08:57:36.802436
# Unit test for function match

# Generated at 2022-06-18 08:57:43.279718
# Unit test for function match

# Generated at 2022-06-18 08:57:52.697716
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-remove'))


# Generated at 2022-06-18 08:58:00.421974
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-18 08:58:10.483671
# Unit test for function match

# Generated at 2022-06-18 08:58:20.515124
# Unit test for function get_new_command

# Generated at 2022-06-18 08:58:30.062557
# Unit test for function get_new_command

# Generated at 2022-06-18 08:58:38.353373
# Unit test for function match

# Generated at 2022-06-18 08:58:45.568885
# Unit test for function match

# Generated at 2022-06-18 08:58:55.842108
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-create'))

# Generated at 2022-06-18 08:59:06.197225
# Unit test for function match

# Generated at 2022-06-18 08:59:15.632017
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-18 08:59:18.234436
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-18 08:59:32.387798
# Unit test for function match

# Generated at 2022-06-18 08:59:41.955710
# Unit test for function match

# Generated at 2022-06-18 08:59:49.355327
# Unit test for function match

# Generated at 2022-06-18 08:59:56.264464
# Unit test for function match

# Generated at 2022-06-18 09:00:03.900368
# Unit test for function get_new_command

# Generated at 2022-06-18 09:00:13.002712
# Unit test for function match

# Generated at 2022-06-18 09:00:22.794584
# Unit test for function match

# Generated at 2022-06-18 09:00:32.547410
# Unit test for function match

# Generated at 2022-06-18 09:00:37.319078
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-18 09:00:44.257458
# Unit test for function match

# Generated at 2022-06-18 09:01:04.524045
# Unit test for function match

# Generated at 2022-06-18 09:01:08.976704
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info'))
    assert not match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-18 09:01:17.019799
# Unit test for function match

# Generated at 2022-06-18 09:01:25.090570
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create'))
    assert not match(Command('tsuru app-create', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-create', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove'))


# Generated at 2022-06-18 09:01:31.107856
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info'))
    assert not match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-18 09:01:40.428374
# Unit test for function get_new_command

# Generated at 2022-06-18 09:01:47.009675
# Unit test for function get_new_command

# Generated at 2022-06-18 09:01:56.111034
# Unit test for function match

# Generated at 2022-06-18 09:02:05.859609
# Unit test for function match

# Generated at 2022-06-18 09:02:15.404509
# Unit test for function get_new_command

# Generated at 2022-06-18 09:02:45.471963
# Unit test for function match

# Generated at 2022-06-18 09:02:53.351474
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-remove'))

# Generated at 2022-06-18 09:03:01.946656
# Unit test for function match

# Generated at 2022-06-18 09:03:10.205862
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-remove'))

# Generated at 2022-06-18 09:03:20.314613
# Unit test for function match

# Generated at 2022-06-18 09:03:26.766045
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-log\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-restart\n\tapp-remove\n\tapp-info\n\tapp-create\n\tapp-deploy\n\tapp-grant\n\tapp-revoke\n\tapp-change-quota\n\n')) is True


# Generated at 2022-06-18 09:03:36.189796
# Unit test for function match

# Generated at 2022-06-18 09:03:40.219503
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    assert get_new_command(Command('tsuru app-info',
                                   'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info')) == 'tsuru app-info'

# Generated at 2022-06-18 09:03:46.481201
# Unit test for function match

# Generated at 2022-06-18 09:03:55.232675
# Unit test for function match

# Generated at 2022-06-18 09:04:51.375912
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-remove'))


# Generated at 2022-06-18 09:04:55.472499
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-18 09:05:03.525745
# Unit test for function get_new_command

# Generated at 2022-06-18 09:05:10.594028
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command