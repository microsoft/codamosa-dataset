

# Generated at 2022-06-22 02:27:19.023192
# Unit test for function get_new_command

# Generated at 2022-06-22 02:27:22.600353
# Unit test for function match
def test_match():
    command = Command('tsuruu app-list', 'tsuru: "tsuruu" is not a tsuru command. See "tsuru help"', '')
    assert match(command)


# Generated at 2022-06-22 02:27:30.476674
# Unit test for function match
def test_match():
    output = ('tsuru: "upgrade" is not a tsuru command. See "tsuru help".'
              '\n\nDid you mean?\n\tupdate\n')
    assert match(Command("tsuru upgrade", output))
    output = ('tsuru: "intantiate" is not a tsuru command. See "tsuru help".'
              '\n\nDid you mean?\n\tbuild-image\n')
    assert match(Command("tsuru intantiate", output))
    assert not match(Command("tsuru foo", "bar"))


# Generated at 2022-06-22 02:27:34.511262
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-lock', 'tsuru: "app-lock" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-log\n\tapp-list\n\tapp-deploy\n'))
    assert not match(Command('tsuru app-lock', 'tsuru: "app-lock" is not a tsuru command. See "tsuru help".', '', 1, None))


# Generated at 2022-06-22 02:27:40.291454
# Unit test for function match
def test_match():
    assert match(Command('tsuru test', 'tsuru: "test" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttest-repository'))
    assert not match(Command('', 'tsuru: "test" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('', ''))


# Generated at 2022-06-22 02:27:49.833892
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    command = Command("tsuru app-create app-test", "tsuru: \"app-create\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tapp-create-units\n\tapp-list")

    expected = r'tsuru app-list'

    assert get_new_command(command) == expected




# Generated at 2022-06-22 02:27:55.009503
# Unit test for function match
def test_match():
    assert match(Command('tsuru unit-add myapp',
                         'tsuru: "unit-add" is not a tsuru command. '
                         'See "tsuru help".\nDid you mean?\n\tunit-add'))



# Generated at 2022-06-22 02:27:59.961834
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('tsuru app-create -P greatapp',
                                    'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\n\n', 1))

    assert new_command == 'tsuru app-create -P greatapp'

# Generated at 2022-06-22 02:28:04.910921
# Unit test for function match
def test_match():
    assert match(Command('tsuru log-app', 'tsuru: "log-app" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tlog-app\n\tlog-unit\n\tlogs-app\n\tlogs-unit\n\tlog-listen'))
    assert not match(Command('tsuru log-app', 'a\nb\nc'))


# Generated at 2022-06-22 02:28:12.015839
# Unit test for function match

# Generated at 2022-06-22 02:28:19.889161
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru permission-list')) == 'tsuru permission-list'
    assert get_new_command(Command('tsuru permssion-list')) == 'tsuru permission-list'
    assert get_new_command(Command('tsuru permssion-list team-create')) == 'tsuru permission-create'



# Generated at 2022-06-22 02:28:30.940617
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('tsuru app', output='\
2014/12/05 16:31:15 ERROR: "app" is not a tsuru command. See "tsuru help".\
\n\nDid you mean?\n\tapps\tapp-create\n\tapp-remove\tapp-info',
                                       style=get_default_style())) == 'tsuru apps'


# Generated at 2022-06-22 02:28:36.986790
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    output = 'tsuru: "worng_command" is not a tsuru command. See "tsuru help".\nDid you mean?\n\t[worng_command] --help'
    command = Command('tsuru worng_command', output)
    assert get_new_command(command) == 'tsuru --help'

# Generated at 2022-06-22 02:28:44.748498
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru add-key my-key', "tsuru: \"add-key\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tadd-key\n\tremove-key")) == "tsuru add-key my-key"
    assert get_new_command(Command('tsuru add-key my-key', "tsuru: \"add-key\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tremove-key")) == "tsuru remove-key my-key"

# Generated at 2022-06-22 02:28:48.427115
# Unit test for function match
def test_match():
    assert match(Command('tsuru node-add test', ''))
    assert not match(Command('git commit', ''))
    assert not match(Command('tsuru help', ''))


# Generated at 2022-06-22 02:28:57.739300
# Unit test for function match
def test_match():
    # If the output is not like "tsuru: "foo" is not a tsuru command. See "tsuru help""
    assert not match(Command('tsuru foo', ''))
    # If it is like "tsuru: "foo" is not a tsuru command. See "tsuru help""
    assert match(Command('tsuru foo', 'tsuru: "foo" is not a tsuru command. See "tsuru help".'))
    # If it is like "tsuru: "foo" is not a tsuru command. See "tsuru help"" but there is no suggestion
    assert not match(Command('tsuru foo', 'tsuru: "foo" is not a tsuru command. See "tsuru help".\nNo tsuru commands match.'))
    # If it is like "tsuru: "foo" is not a t

# Generated at 2022-06-22 02:29:01.906499
# Unit test for function get_new_command
def test_get_new_command():
    actual = get_new_command(Command('tsuru run-as dinamic "ls /home"',
                'tsuru: "dinamic" is not a tsuru command. See "tsuru help".\n\n<3> Did you mean?\n\tcreating\n\tconfig\n\trun\n\tapp'))
    expected = 'tsuru run-as running "ls /home"'
    assert actual == expected

# Generated at 2022-06-22 02:29:07.267351
# Unit test for function get_new_command
def test_get_new_command():
    output = """tsuru: "tsuru-heo" is not a tsuru command. See "tsuru help".

Did you mean?
	tsuru-heo-add
	tsuru-heo-remove
	tsuru-heo-list"""
    assert (get_new_command(Command('tsuru tsuru-heo', '', output)) ==
            'tsuru tsuru-heo-add')


enabled_by_default = True

# Generated at 2022-06-22 02:29:11.357711
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru templates-list')) == 'tsuru template-list'
    assert get_new_command(Command('tsuru templates-list master')) == 'tsuru template-list master'



# Generated at 2022-06-22 02:29:18.699783
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-info',
                         "tsuru: \"service-info\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tservice instance-info\n\tservice-bind"))
    assert not match(Command('tsuru service',
                             """tsuru service-instance
A
B
C
D"""))
    assert not match(Command('tsuru service',
                             """tsuru
A
B
C
D"""))
    assert not match(Command('tsuru service',
                             """tsuru
A
B
C
D"""))


# Generated at 2022-06-22 02:29:29.869086
# Unit test for function match
def test_match():
    c = Command('tsuru list-apps', 'tsuru: "list-apps" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps-list\n\tapp-list')
    assert match(c)
    c = Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps-list\n\tapp-list')
    assert match(c)
    c = Command('tsuru add-key', 'tsuru: "add-key" is not a tsuru command. See "tsuru help".')
    assert not match(c)


# Generated at 2022-06-22 02:29:34.704810
# Unit test for function get_new_command
def test_get_new_command():
    output = "tsuru: \"app-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-list"
    command = Command('tsuru app-list', output)
    assert get_new_command(command) == "tsuru app-list"

# Generated at 2022-06-22 02:29:37.588564
# Unit test for function match
def test_match():
    assert match(Command('tsuru r', 'tsuru: "r" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\trestart'))
    assert not match(Command('tsuru r', ''))

# Generated at 2022-06-22 02:29:48.416363
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru start-app', 'tsuru: "start-app" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tstart-app-unit', '')
    new_commands = get_new_command(command)
    assert new_commands[0] == 'tsuru start-app-unit'
    command = Command('tsuru start-app', 'tsuru: "start-app" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tstart-app-unit\n\tstart-app-server', '')
    new_commands = get_new_command(command)
    assert new_commands[0] == 'tsuru start-app-unit'

# Generated at 2022-06-22 02:29:53.033528
# Unit test for function get_new_command
def test_get_new_command():
    output = '''tsuru: "app-ps" is not a tsuru command. See "tsuru help".

Did you mean?
	app-create  Create a new app
	app-remove  Remove an app
	apps-list   List user apps
'''
    cmd = Command('app-ps', output=output)
    assert get_new_command(cmd) == 'tsuru app-create'



# Generated at 2022-06-22 02:30:04.644055
# Unit test for function match

# Generated at 2022-06-22 02:30:15.276399
# Unit test for function match
def test_match():
    assert not match(Command('tsuru app-create app', ''))
    assert not match(Command('tsuru app-info app', ''))
    assert match(Command('tsuru app-create', '''tsuru: "app-create" is not a tsuru command. See "tsuru help".

        Did you mean?
                app-create
                app-remove
                app-restart
                app-run-command
                app-run-task'''))
    assert match(Command('tsuru app-remove', '''tsuru: "app-remove" is not a tsuru command. See "tsuru help".

        Did you mean?
                app-remove
                app-restart'''))


# Generated at 2022-06-22 02:30:20.636770
# Unit test for function match
def test_match():
    assert match(Command('tsuru config -- force', 'tsuru: "force" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tconfig'))
    assert not match(Command('tsuru config -s https://tsuru.domain.com', 'Setting tsuru host to https://tsuru.domain.com... done!\nYou can switch between multiple tsuru servers using "tsuru target-list" and "tsuru target-set".'))


# Generated at 2022-06-22 02:30:27.429590
# Unit test for function match
def test_match():
    command = Command('tsuru api-health',
                      'tsuru: "api-health" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapi-healthcheck\n')
    assert match(command)

    command = Command('tsuru api-heal',
                      'tsuru: "api-heal" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapi-healthcheck\n')
    assert match(command)

    command = Command('tsuru api-',
                      'tsuru: "api-" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapi-healthcheck\n')
    assert match(command)


# Generated at 2022-06-22 02:30:37.209521
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command('tsuru add-key', output='''tsuru: "add-key" is not a tsuru command. See "tsuru help".

Did you mean?
        add-key
        add-key-list
        add-unit
        api-doc''')) == 'tsuru add-key'
    assert get_new_command(Command('tsuru key-list', output='''tsuru: "key-list" is not a tsuru command. See "tsuru help".

Did you mean?
        add-key
        add-key-list
        add-unit
        api-doc''')) == 'tsuru key-list'

# Generated at 2022-06-22 02:30:45.706668
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('tsuru app-add', 'tsuru: "app-git" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-git-hook\n\tapp-info\n\tapp-log\n\tapp-list\n\tapp-deploy\n\tapp-run\n\tapp-remove\n')) ==
            'tsuru app-git-hook .')

# Generated at 2022-06-22 02:30:52.626137
# Unit test for function match
def test_match():
    command_1 = Command('tsuruh list-app', output='tsuru: "list-app" is not a tsuru command. See "tsuru help".')
    command_2 = Command('tsuruh list-app', output='tsuru: "list-app" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tlist-apps')
    command_3 = Command('tsuruh list-app', output='tsuru: "list-app" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tlist-apps\n')

# Generated at 2022-06-22 02:31:02.223470
# Unit test for function get_new_command
def test_get_new_command():
    output = str('''tsuru: "show" is not a tsuru command. See "tsuru help".

Did you mean?
	share
	shell
	stop
	svc-delete
	svc-doc
	ssh
	start''')
    assert get_new_command(Command('tsuru show', output)) == 'tsuru ssh'
    output = str('''tsuru: "deploy" is not a tsuru command. See "tsuru help".

Did you mean?
	delete
	deploys
	destroy-machine''')
    assert get_new_command(Command('tsuru deploy', output)) == 'tsuru deploys'

# Generated at 2022-06-22 02:31:11.862588
# Unit test for function get_new_command

# Generated at 2022-06-22 02:31:15.076570
# Unit test for function match
def test_match():
	test_match = "tsuru: \"version\" is not a tsuru command. See \"tsuru help\"."
	assert match(Command(test_match, ""))


# Generated at 2022-06-22 02:31:18.529551
# Unit test for function match
def test_match():
    command = Command("tsuru app-list")
    assert match(command)

    command = Command("tsuru target-list")
    assert not match(command)


# Generated at 2022-06-22 02:31:27.525635
# Unit test for function match
def test_match():
    match_object = match(Command('tsuru env-set', ''))
    assert match_object is None
    match_object = match(Command('tsuru abc', 'abc is not a tsuru command. See "tsuru help".'))
    assert match_object is None
    match_object = match(Command('tsuru abc', 'abc is not a tsuru command. See "tsuru help".\nDid you mean?\n\t'))
    assert match_object is not None
    assert match_object.script == 'tsuru abc'
    assert match_object.output == 'abc is not a tsuru command. See "tsuru help".\nDid you mean?\n\t'

# Generated at 2022-06-22 02:31:32.937351
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-list', "tsuru: \"app-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-restart", "")) == "tsuru app-create"

# Generated at 2022-06-22 02:31:41.204881
# Unit test for function match
def test_match():
    assert match(Command('tsuru rm myapp', 'tsuru: "rm" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tremove\n', 0))
    assert not match(Command('tsuru rm myapp', 'tsuru: "rm" is not a tsuru command. See "tsuru help".\n', 0))
    assert not match(Command('tsururm myapp', 'tsuru: "rm" is not a tsuru command. See "tsuru help".\n', 0))

# Unit tests for function get_new_command

# Generated at 2022-06-22 02:31:44.961786
# Unit test for function match
def test_match():
    assert match(Command('tsru service-instance-add test tsuru-mongodb'))
    assert not match(Command('tsuru service-instance-add test tsuru-mongodb',
                             '', '', '', '', '', 0))



# Generated at 2022-06-22 02:31:50.172262
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuruuu', 'tsuru: "tsuruuu" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-set')) == 'tsuru target-set'

# Generated at 2022-06-22 02:32:00.751633
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-create asd',
                                   'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n')) == Command('tsuru app-create asd', '')
    assert get_new_command(Command('tsuruu app-create asd',
                                   'tsuru: "tsuruu" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n')) == Command('tsuru app-create asd', '')

# Generated at 2022-06-22 02:32:09.228027
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('tsurur token-add',
                "tsuru: \"token-ad\" is not a tsuru command. See \"tsuru help\"")
    ) == 'tsuru token-add'
    assert get_new_command(
        Command('tsuru app-lis',
                """tsuru: "app-lis" is not a tsuru command. See "tsuru help".

Did you mean?
        app-list
        app-lock
        app-log
        app-logs
        app-run-command""")
    ) == 'tsuru app-list'

enabled_by_default = True

# Generated at 2022-06-22 02:32:15.019787
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    out = 'tsuru: "node" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-list\n\tnode-remove\n\n'  # noqa
    assert get_new_command(Command('node', '', out)) == 'tsuru node-list'

# Generated at 2022-06-22 02:32:23.023380
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru target-list',
                                   "Failed to list targets: tsuru: \"target-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\ttargets-list")).script == 'tsuru targets-list'

    assert get_new_command(Command('tsuru target-list',
                                   "Failed to list targets: tsuru: \"target-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\ttargets-list\n\ttargets-add")).script == 'tsuru targets-list'


# Generated at 2022-06-22 02:32:27.940272
# Unit test for function get_new_command
def test_get_new_command():
    output = "tsuru: \"app-lis\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-list"
    command = Command('tsuru app-lis', output)

    assert get_new_command(command) == 'tsuru app-list'

# Generated at 2022-06-22 02:32:36.061664
# Unit test for function match
def test_match():
    assert match(Command('tsuru aaa', 'tsuru: "aaa" is not a tsuru command. See "tsuru help".'))
    assert match(Command('tsuru aaa', 'tsuru: "aaa" is not a tsuru command. See "tsuru help".\nDid you mean?\ntsuru API-key-add'))
    assert not match(Command('tsuru aaa', 'tsuru: "aaa" is not a tsuru command. See "tsuru help"'))


# Generated at 2022-06-22 02:32:39.516339
# Unit test for function match
def test_match():
    output='''tsuru: "target" is not a tsuru command. See "tsuru help".

Did you mean?
        target-add

'''
    command = Command('tsuru target', output)
    assert match(command)



# Generated at 2022-06-22 02:32:41.728635
# Unit test for function match
def test_match():
    command="tsurtu: 'app' is not a tsuru command. See 'tsuru help'."
    assert match(command)



# Generated at 2022-06-22 02:32:46.560752
# Unit test for function match
def test_match():
    assert match(Command("tsur help app-create", "tsuru: \"help\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-create\ntsur help app-create", "tsuru help app-create"))


# Generated at 2022-06-22 02:32:52.695490
# Unit test for function match
def test_match():
    cmd = Command('tsury', 'tsury: "tsury" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice\n\tuser-create')
    assert match(cmd)


# Generated at 2022-06-22 02:32:56.726435
# Unit test for function match
def test_match():
    broken_command = Command('tsuru app-list', "tsuru: \"app-list\" is not a tsuru command. See \"tsuru help\".")
    assert match(broken_command)


# Generated at 2022-06-22 02:33:00.417862
# Unit test for function match
def test_match():
    command = Command("tsuru service-add -h && tsuru docker-envs", "")
    assert match(command)


# Generated at 2022-06-22 02:33:04.143797
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    assert get_new_command(Command('tsuru app-command', '')) == 'tsuru app-info'
    assert get_new_command(Command('tsuru app-command', ''))


enabled_by_default = True

# Generated at 2022-06-22 02:33:08.257133
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru a',
                         output='tsuru: "a" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tappend-unit\n\tadd-cname\n\tadd-key\n\tadd-unit',
                         stderr=' '))


# Generated at 2022-06-22 02:33:14.705411
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "fetch-app" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tfetch-app-log\n\tfetch-app-metric-envs\n\tfetch-env'
    assert get_new_command(Command('tsuru fetch-app', output)) == 'tsuru fetch-app-log'

# Generated at 2022-06-22 02:33:18.042241
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command(Command('tsuru client', 'tsuru: "client" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tclient-remove')))

# Generated at 2022-06-22 02:33:28.183541
# Unit test for function get_new_command
def test_get_new_command():
    output = "tsuru: \"cat\" is not a tsuru command. See \"tsuru help\".\n\n \
Did you mean?\n\ttarget-add\n\ttarget-remove\n\tversion\n\thelp"
    assert get_new_command(output) == ['target-add', 'target-remove', 'version', 'help']
    output = "tsuru: \"target\" is not a tsuru command. See \"tsuru help\".\n\n \
Did you mean?\n\ttarget-add\n\ttarget-remove\n\tversion\n\thelp"
    assert get_new_command(output) == ['target-add', 'target-remove', 'version', 'help']

# Generated at 2022-06-22 02:33:33.100746
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create', "tsuru: \"app-create\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tcreate-app\n\tcreate-user\n\tcreate-key\n\tcreate-unit"))


# Generated at 2022-06-22 02:33:43.690475
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru target-prod', output='tsuru: "target-prod" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add\n\ttarget-remove\n\ttarget-set\n')) == 'tsuru target-add'
    assert get_new_command(Command('tsuru target-prod', output='tsuru: "target-prod" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-remove\n\ttarget-set\n')) == 'tsuru target-remove'

# Generated at 2022-06-22 02:33:51.276661
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info teste',
                         'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-inf',
                         ''))
    assert not match(Command('tsuru app-info teste',
                             'tsuru: "app-info" is not a tsuru command. See "tsuru help".', ''))


# Generated at 2022-06-22 02:33:55.074461
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-test', 'tsuru: "app-test" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp  -- Create an app', ''))
    assert not match(Command('ls\n', ''))
    


# Generated at 2022-06-22 02:33:57.975655
# Unit test for function match
def test_match():
    assert match(Command('tsuru hello', 'Hello tsuru!\n'))
    assert not match(Command('tsuru version', 'tsuru version 1.1.0'))


# Generated at 2022-06-22 02:34:04.317996
# Unit test for function match
def test_match():
    assert match(Command('tsuru somecmd', 'tsuru: "somecmd" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice\n\tlist-service\n'))
    assert not match(Command('tsuru login', ''))
    assert not match(Command('tsuru help', ''))


# Generated at 2022-06-22 02:34:13.155928
# Unit test for function match
def test_match():
    output1 = 'tsuru: "hello" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlogin\n\tlogout\n\tconfig-get\n\tconfig-set\n\tconfig-unset'
    output2 = 'tsuru: "server" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlogin\n\tlogout\n\tconfig-get\n\tconfig-set\n\tconfig-unset'
    assert not match(Command('tsuru hello', output1))
    assert not match(Command('tsuru server', output2))


# Generated at 2022-06-22 02:34:16.700756
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('tsuruy', ''))
    assert new_command == 'tsuru help'
    new_command = get_new_command(Command('tsuruu', ''))
    assert new_command == 'tsuru'

# Generated at 2022-06-22 02:34:22.609474
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('tsuru foobar', "Warning: tsuru: \"foobar\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tfoo\n\tbar"))
    assert new_command == 'tsuru foo' or new_command == 'tsuru bar'


enabled_by_default = True

# Generated at 2022-06-22 02:34:32.999996
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru import _get_new_command as get_new_command
    assert get_new_command("tsuru: \"ap\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp\n\tapp-change\n\tapp-create\n\tapp-delete\n\tapp-lock\n\tapp-info\n\tapp-log\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-unlock\n\tapp-update\n\n") == "tsuru app-change"

# Generated at 2022-06-22 02:34:44.462701
# Unit test for function get_new_command
def test_get_new_command():
    # test command with one suggestion
    output = 'tsuru: "foo" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tbar'
    command = type('Command', (object,), {'script': 'tsuru foo', 'output': output})
    assert get_new_command(command) == 'tsuru bar'
    # test command with two suggestions
    output = 'tsuru: "foo" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tbar\n\tbaz'
    command = type('Command', (object,), {'script': 'tsuru foo', 'output': output})
    assert get_new_command(command) in ('tsuru bar', 'tsuru baz')

# Generated at 2022-06-22 02:34:47.449192
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output = 'tsuru: "add-key" is not a tsuru command. See "tsuru help".\n' \
             '\n' \
             'Did you mean?\n' \
             '\tadd-key\n'
    command = Command('tsuru add-key', output)
    assert get_new_command(command) == 'tsuru add-key'
    command = Command('tsuru key-add', output)
    assert get_new_command(command) == 'tsuru add-key'

# Generated at 2022-06-22 02:34:59.819315
# Unit test for function get_new_command
def test_get_new_command():
    # if output of command contains '\nDid you mean?\n\t', we know that the
    # user wants to fix his command
    output = 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list'
    assert get_new_command(Command('tsuru app-list', output)) == 'tsuru app-list'

    output = 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list\n\tapp-info'
    assert get_new_command(Command('tsuru app-list', output)) == 'tsuru app-list'


# Generated at 2022-06-22 02:35:09.971534
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    output = '\nDid you mean?\n\tcontainers-add\n\tclusters-list\n\tclusters-remove\n\tcluster-create\n\tcluster-remove\n\tcluster-list\n\tcluster-info\n\tclusters-info\n\nRun "tsuru help" for usage.\n'
    assert get_new_command(Command('tsuru clus', output=output)) == 'tsuru cluster-info'

# Generated at 2022-06-22 02:35:15.078098
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsurur app-info falcao', "tsuru: \"app-info\" is not a tsuru command. See \"tsuru help\".")
    assert get_new_command(command) == 'tsurur app-info --help'

# Generated at 2022-06-22 02:35:26.317567
# Unit test for function match
def test_match():
    # Looking for a specific command
    assert match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".'))
    assert match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp'))
    assert match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp\n\tapp-deploy'))

    # Looking for a command that is not in the list of suggestions

# Generated at 2022-06-22 02:35:31.737872
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    output = 'tsuru: "login" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlogout\n\tlogin-gitlab\n\tlogin-github\n'
    command = Command(script='', stderr=output)
    assert get_new_command(command) == 'tsuru logout'



# Generated at 2022-06-22 02:35:38.061514
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-info\n\tapp-list-units\n\tapp-log\n\tapp-run')) != None


# Generated at 2022-06-22 02:35:46.178531
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('tsuru help', 'tsuru: "help" is not a tsuru command. See "tsuru help".\nDid you mean?\n\thelp-app')) == 'tsuru help-app'
    assert get_new_command(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-info')) == 'tsuru app-create'

# Generated at 2022-06-22 02:35:51.524433
# Unit test for function get_new_command
def test_get_new_command():
    command_corrected = 'tsuru app-create'
    command = MagicMock(output="""tsuru: "app-create" is not a tsuru command. See "tsuru help".

Did you mean?
	app-create
	app-delete""")
    assert get_new_command(command) == command_corrected

# Generated at 2022-06-22 02:35:57.230672
# Unit test for function get_new_command
def test_get_new_command():
    output = '''tsuru: "tsuru plataform-add" is not a tsuru command. See "tsuru help".

Did you mean?
	platform-add
	platform-remove
	platform-list
        '''
    command = type('obj', (object,), {'output': output})
    assert get_new_command(command) == 'tsuru platform-add'

# Generated at 2022-06-22 02:36:03.776644
# Unit test for function match
def test_match():
    assert match(Command('airt --help', 'airt: "airt" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tair'))
    assert match(Command('airs --help', 'airs: "airs" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tair'))
    assert not match(Command('test --help', ''))
    assert not match(Command('test --help', 'test: "test" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-22 02:36:15.508347
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru something', '')) == 'tsuru something'

    output1 = ('tsuru: "something" is not a tsuru command. See "tsuru help".\n'
               '\n'
               'Did you mean?\n'
               '\tsomething')

    output2 = ('tsuru: "something" is not a tsuru command. See "tsuru help".\n'
               '\n'
               'Did you mean?\n'
               '\tsomething\n'
               '\tsomethingelse')

    assert get_new_command(Command('tsuru something', output1)) == 'tsuru something'
    assert get_new_command(Command('tsuru something', output2)) == 'tsuru something'

# Generated at 2022-06-22 02:36:19.970238
# Unit test for function get_new_command
def test_get_new_command():
    from .types import Command

    assert 'tsuru app-info myapp' == get_new_command(Command('tsuru app-info myapp',
        'tsuru: "appinf" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-info'))

# Generated at 2022-06-22 02:36:25.860465
# Unit test for function get_new_command
def test_get_new_command():
  command = Command('tsuru app-create my-app -t python',     'tsuru: "python" is not a tsuru command.'+
                                                              '\nDid you mean?\n\t'+
                                                              'python27\n\t'+
                                                              'python33  \n')
  new = get_new_command(command)
  assert new == 'tsuru app-create my-app -t python27'

# Generated at 2022-06-22 02:36:32.364515
# Unit test for function match
def test_match():
    assert match(Command('tsurud create-app in production TAG',
                         'tsurud: "create-app" is not a tsuru command. See '
                         '"tsuru help".\nDid you mean?\n\tcreate-app'))
    assert not match(Command('tsurud', 'Usage of tsurud:\n  -config-file='))
    assert not match(Command('touch /tmp/test', ''))
    assert not match(Command('tsurud create-app', ''))


# Generated at 2022-06-22 02:36:41.683151
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create','tsuru: "app-create" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create'))
    assert match(Command('tsuru service-add','tsuru: "service-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tservice-add'))
    assert match(Command('tsuru servic-add','tsuru: "servic-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tservice-add'))

# Generated at 2022-06-22 02:36:52.780176
# Unit test for function get_new_command

# Generated at 2022-06-22 02:36:59.279838
# Unit test for function match
def test_match():
    output = {
        'stdout': 'tsuru: "add-key" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tadd-key-to',
        'stderr': ''
    }
    command = Command('tsuru add-key 1', output)
    assert match(command)

    output = {
        'stdout': 'tsuru: "command" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-run',
        'stderr': ''
    }
    command = Command('tsuru command 1', output)
    assert match(command)



# Generated at 2022-06-22 02:37:02.409241
# Unit test for function match
def test_match():
    assert match(Command('tsu', '''tsuru: "tsu" is not a tsuru command. See "tsuru help".

Did you mean?
        target
'''))


# Generated at 2022-06-22 02:37:10.763554
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create fakeapp',
                         'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-remove\n\tapp-list\n\tapp-info\n\tapp-deploy\n\tapp-cancel-remove\n\tapp-grant\n\tapp-revoke\n\tapp-restart'))
    assert match(Command('tsuru app-remove fakeapp',
                         'tsuru: "app-remove" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create'))
