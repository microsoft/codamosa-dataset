

# Generated at 2022-06-22 02:27:18.460112
# Unit test for function match
def test_match():
    from tests.utils import Command

    assert match(Command('tsuru crash', 'tsuru: "crash" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tcreate\n\tcreate-app\n\tcreate-certificate\n\tcreate-key\n\tcreate-permission\n\tcreate-platform'))
    assert match(Command('tsuru crash-some-shit', 'tsuru: "crash-some-shit" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tcreate\n\tcreate-app\n\tcreate-certificate\n\tcreate-key\n\tcreate-permission\n\tcreate-platform'))

# Generated at 2022-06-22 02:27:28.724200
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-bind', 'tsuru: "service-bind" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-bind\n\tapp-info\n\tapp-unbind\n\tbind\n\tbind-service\n\n'))
    assert not match(Command('tsuru service-bind', 'tsuru: "service-bind" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-bind\n\tapp-info\n\tapp-unbind\n\tbind\n\tbind-service\n\n'))


# Generated at 2022-06-22 02:27:29.732307
# Unit test for function match
def test_match():
    pass



# Generated at 2022-06-22 02:27:35.397069
# Unit test for function match
def test_match():
    assert None != match(Command('tsuru target-add test http://tsuru.com',
                                 "tsuru: \"target-add\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\ttarget-add\n\ttarget-list\n\ttarget-remove\n"))
    assert None == match(Command('tsuru target-list', 'No target found.'))


# Generated at 2022-06-22 02:27:38.304179
# Unit test for function match
def test_match():
    output = 'tsuru: "AddUserToApp" is not a tsuru command. See "tsuru help".'
    assert match(Command(script='', output=output))


# Generated at 2022-06-22 02:27:42.055309
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-listan', 'tsuru: "app-listan" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list')
    assert get_new_command(command) == 'tsuru app-list'

# Generated at 2022-06-22 02:27:46.310361
# Unit test for function match
def test_match():
    assert match(Command('tsuru long', ''))
    assert match(Command('tsuru long', 'tsuru: "long" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tshort'))
    assert not match(Command('tsuru long', 'tsuru: "long" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-22 02:27:57.156315
# Unit test for function get_new_command
def test_get_new_command():

    # Test case 1
    command_wrong = Command('tsuru target-list', 'tsuru: "target-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add\n\ttarget-remove')
    assert get_new_command(command_wrong) == 'tsuru target-add'

    # Test case 2
    command_wrong = Command('tsuru user-create', 'tsuru: "user-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tuser-add\n\tuser-remove')
    assert get_new_command(command_wrong) == 'tsuru user-add'

    # Test case 2

# Generated at 2022-06-22 02:28:08.669337
# Unit test for function get_new_command
def test_get_new_command():
    #basic match
    assert get_new_command(Command('tsuru app-create', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-run\n\tapp-restart\n\tapp-start\n\tapp-stop', '', '')) == 'tsuru app-create'
    #match with flags

# Generated at 2022-06-22 02:28:16.133238
# Unit test for function match
def test_match():
    assert match(Command(
        script='tsuru app-create test4',
        stderr='ERROR: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-remove',
        ))
    assert not match(Command(
        script='tsuru app-info test4',
        stderr='ERROR: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-remove',
        ))


# Generated at 2022-06-22 02:28:24.278137
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create hello',
                         "tsuru: \"app-create\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-create"))
    assert match(Command('tsuru app-remove hello',
                         "tsuru: \"app-remove\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-remove"))
    assert match(Command('tsuru app-deploy hello',
                         "tsuru: \"app-deploy\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-deploy"))

# Generated at 2022-06-22 02:28:32.029366
# Unit test for function match
def test_match():
    cmd1 = Command('tsuru aaa bbb', "tsuru: \"aaa\" is not a tsuru command. See \"tsuru help\".")
    cmd2 = Command('tsuru aaa bbb', "tsuru: \"aaa\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tapp-add\n\tapp-remove")
    cmd3 = Command('tsuru aaa bbb', "")

    assert(match(cmd1))
    assert(match(cmd2))
    assert(not match(cmd3))


# Generated at 2022-06-22 02:28:39.171062
# Unit test for function match
def test_match():
    assert match(Command('tsru target-add', 'tsuru: "tsru" is not a tsuru command. See "tsuru help".', '', 0, None))
    assert not match(Command('tsr target-add', 'tsuru: "tsr" is not a tsuru command. See "tsuru help".', '', 0, None))
    assert match(Command('tsuru target-add', '', '', 0, None))


# Generated at 2022-06-22 02:28:44.573243
# Unit test for function match
def test_match():
    assert match(Command('tsuru commands', 'tsuru: "commands" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcommand'))

# Generated at 2022-06-22 02:28:54.961941
# Unit test for function match
def test_match():
    assert match(Command('tsur server list', 'tsuru: "server" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlist-units')) == True
    assert match(Command('tsur server list-units', 'tsuru: "server" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlist-units')) == True
    assert match(Command('tsur server list', 'tsuru: "server" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlist-units')) == True
    assert match(Command('', '')) == False

# Generated at 2022-06-22 02:29:01.176872
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-logout --app myapp',
                      'tsru: "app-logout" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-remove-log')
    assert get_new_command(command) == 'tsuru app-remove-log --app myapp'

# Generated at 2022-06-22 02:29:09.243630
# Unit test for function match

# Generated at 2022-06-22 02:29:14.420566
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("tsuru: \"hello\" is not a tsuru command") == "hello"
    assert get_new_command('''tsuru: "version" is not a tsuru command. See "tsuru help".

Did you mean?
   app-list
   node-list
''') == "app-list"

# Generated at 2022-06-22 02:29:18.664615
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("p", "tsuru: \"p\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tperm-get\n\tperm-remove\n\tperm-set\n\tpermission-list\n\tpermission-remove\n\tpermission-set")) == "tsuru perm-get"

# Generated at 2022-06-22 02:29:25.030510
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    output = '''tsuru: "asd" is not a tsuru command. See "tsuru help".

Did you mean?
        app-run
        app-shell
        app-ssh
        '''

    result = get_new_command(Command('asd', output))

    assert result == 'tsuru app-run'

# Generated at 2022-06-22 02:29:33.980381
# Unit test for function match
def test_match():

    # valid command
    test_command = Command('tsuru app-info')
    result = match(test_command)
    assert result == True

    # invalid command
    test_command = Command('tsuru appinfo')
    result = match(test_command)
    assert result == False

    # when tsuru command is not present in the command line
    test_command = Command('git --version')
    result = match(test_command)
    assert result == False


# Generated at 2022-06-22 02:29:38.222346
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "config" is not a tsuru command. See "tsuru help".\n' \
             'Did you mean?\n\tconfig-set\n\tconfig-unset\n\tconfig-get'
    command = Command('tsuru config', output)
    assert get_new_command(command) == 'tsuru config-set'

# Generated at 2022-06-22 02:29:47.699201
# Unit test for function match
def test_match():
    assert match(Command("tsuru app-remove",
                       "tsuru: \"app-remove\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-remove\n\tapp-log\n\tapp-run"))

    assert match(Command("tsuru teem-list",
                       "tsuru: \"teem-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tteam-list\n\tteam-user-add\n\tteam-user-remove"))
    assert not match(Command("tsuru", ""))


# Generated at 2022-06-22 02:29:51.424820
# Unit test for function match
def test_match():
    assert match(Command('tsuru do', 'tsuru: "do" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tdocker-node\n\tnode-add\n\tnode-remove\n\tnode-update'))


# Generated at 2022-06-22 02:29:55.915390
# Unit test for function match
def test_match():
    assert match(Command('''tsuru: "invalid-command" is not a tsuru command. See "tsuru help".
Did you mean?
\tenv-get
\tenv-set
\tenv-unset''', ''))


# Generated at 2022-06-22 02:30:03.497757
# Unit test for function match
def test_match():
    invalid_cmd = Command('tsuru invalid cmd', 'tsuru: "invalid" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t{invalid_1}\n\t{invalid_2}'.format(invalid_1="invalid-1", invalid_2="invalid-2"))
    valid_cmd = Command('tsuru valid cmd')
    assert match(invalid_cmd)
    assert not match(valid_cmd)

# Unit tests for function get_new_command

# Generated at 2022-06-22 02:30:07.482714
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru aoo',
                                   'tsuru: "aoo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp')) == 'tsuru app'

# Generated at 2022-06-22 02:30:14.086286
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info',
                         output='tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n\n'))
    assert not match(Command('tsuru app-info',
                             output='tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\n'))


# Generated at 2022-06-22 02:30:18.560788
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n\tapp-log\n\tapp-run\n\n')
    assert get_new_command(command) == 'tsuru app-info'

# Generated at 2022-06-22 02:30:25.694834
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsur list nodes', 'tsuru: "list" is not a tsuru command.\nDid you mean?\n\tlist-nodes')) == 'tsuru list-nodes'
    assert get_new_command(Command('tsur migrate', 'tsuru: "migrate" is not a tsuru command.\nDid you mean?\n\tmigrate-apps')) == 'tsuru migrate-apps'
    assert get_new_command(Command('tsur app-install install mongodb', 'tsuru: "install" is not a tsuru command.\nDid you mean?\n\tapp-install')) == 'tsuru app-install install mongodb'

# Generated at 2022-06-22 02:30:37.592850
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create testapp',
                         'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-list\n\tapp-remove\n\tapp-restart\n\tapp-start\n\tapp-stop',
                         ''))

    assert not match(Command('tsuru app-create testapp', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".', ''))



# Generated at 2022-06-22 02:30:47.449494
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuruu target-list',
                          'tsuru: "target-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-add\n\ttarget-list\n\ttarget-set\n')) == \
                          'tsuru target-list'

    assert get_new_command(Command('tsuru target-List',
                          'tsuru: "target-List" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-add\n\ttarget-list\n\ttarget-set\n')) == \
                          'tsuru target-list'

# Generated at 2022-06-22 02:30:53.343189
# Unit test for function get_new_command
def test_get_new_command():
    c1 = mock.Mock(output=(
        'tsuru: "node" is not a tsuru command. See "tsuru help".\n'
        '\n'
        'Did you mean?\n'
        '\tnode-list'))
    c2 = mock.Mock(output=(
        'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n'
        '\n'
        'Did you mean?\n'
        '\tapp-create\n'
        '\tapp-remove\n'
        '\tapp-info'))

# Generated at 2022-06-22 02:31:03.715764
# Unit test for function get_new_command
def test_get_new_command():
    output = u"tsuru: \"admin-rebuild\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tadm-rebuild\tRebuild an app."
    command = type('CommandObjectMock', (object,), {'output': output})
    assert get_new_command(command) == "admin-rebuild"

    output = u"tsuru: \"tenant-create\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tteanant-create\tcreates a new tenant."
    command = type('CommandObjectMock', (object,), {'output': output})
    assert get_new_command(command) == "tenant-create"

# Generated at 2022-06-22 02:31:12.375677
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-deployc',
                         'tsuru: "app-deployc" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-deploy\n\tapp-list\n'))
    assert match(Command('tsuru appd',
                         'tsuru: "appd" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-deploy\n\tapp-list\n'))
    assert not match(Command('tsuru app-deploy',
                             'tsuru: "app-deploy" is not a tsuru command. See "tsuru help"'))


# Generated at 2022-06-22 02:31:12.976866
# Unit test for function match
def test_match():
    assert match(Command('', ''))


# Generated at 2022-06-22 02:31:17.328326
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info',
                         'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-list\n\tapp-remove'))


# Generated at 2022-06-22 02:31:20.155435
# Unit test for function match
def test_match():
    assert match(Command('tsuru a', 'tsuru: "a" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-run\n\tapp-info'))
    assert not match(Command('tsuru', ''))

# Generated at 2022-06-22 02:31:25.395609
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    output = '''tsuru: "app-lisy" is not a tsuru command. See "tsuru help".

Did you mean?
        app-list
        app-info

'''
    assert get_new_command(Command(script='tsuru app-lisy', output=output)) == 'tsuru app-list'

# Generated at 2022-06-22 02:31:28.564359
# Unit test for function match
def test_match():
    assert match(Command('tsuru ts', 'tsuru: "ts" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n	target', ''))
    assert not match(Command('tsuru hello', '', ''))

# Generated at 2022-06-22 02:31:43.680208
# Unit test for function match
def test_match():
    output = 'tsuru: "curl" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcheck-data\n\tclient-credentials\n\tclient-remove\n\tclient-token\n'
    command = Command("tsuru curl", output)
    assert match(command)


# Generated at 2022-06-22 02:31:47.483909
# Unit test for function match
def test_match():
    assert match(Command('tsuru a', 'tsuru: "a" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tadd-key'))
    assert not match(Command('tsuru add-key', ''))



# Generated at 2022-06-22 02:31:51.316794
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "tsr" is not a tsuru command. See "tsuru help".\n'
    output += '\nDid you mean?\n\ttsurud-server\n'
    command = Command('tsr', output)
    assert get_new_command(command) == 'tsurud-server'



# Generated at 2022-06-22 02:31:57.078437
# Unit test for function match
def test_match():
    command = Command("tsuru app-list", "tsuru: \"app-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-list")
    assert match(command)


# Generated at 2022-06-22 02:32:01.003694
# Unit test for function get_new_command
def test_get_new_command():
    output = '''tsuru: "app-log" is not a tsuru command. See "tsuru help".

Did you mean?
	app-info
	app-remove'''
    command = Command('app-log', output=output)
    assert get_new_command(command) == 'app-info'



# Generated at 2022-06-22 02:32:06.528445
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.command_not_found import get_new_command
    assert get_new_command(Command('tsuru help')) == 'tsuru help'
    assert get_new_command(Command('tsuru helo')) == 'tsuru help'
    assert get_new_command(Command('tsuru docs')) == 'tsuru docs'

# Generated at 2022-06-22 02:32:15.271593
# Unit test for function match
def test_match():
    assert match('$ tsuru target-add http://192.168.50.4:8080/ zodman2\nError: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-list\n')
    assert not match('$ tsuru target-add http://192.168.50.4:8080/ zodman2\nError: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n')
    


# Generated at 2022-06-22 02:32:18.136613
# Unit test for function match

# Generated at 2022-06-22 02:32:21.966106
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {
        'script': 'tsuru app-info',
        'output': 'tsuru: "tsuru app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n'
    })

    assert get_new_command(command) == 'tsuru app-info'

# Generated at 2022-06-22 02:32:25.579020
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n'))
    assert not match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n'))



# Generated at 2022-06-22 02:32:50.630910
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('tsuru app-inf', 'tsuru: "app-inf" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info')
    assert get_new_command(cmd) == 'tsuru app-info'

# Generated at 2022-06-22 02:32:53.807039
# Unit test for function match
def test_match():
    command = 'tsuru: "foo" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tfoo-bar:bar foo bar'
    assert match(command)



# Generated at 2022-06-22 02:33:00.081274
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('tsuru app-info',
                                   'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create')) == 'tsuru app-create'

# Generated at 2022-06-22 02:33:02.481563
# Unit test for function match
def test_match():
    command = Command('tsuru compu', '')
    assert match(command)
    command = Command('tsuru computer', '')
    assert not match(command)


# Generated at 2022-06-22 02:33:06.481151
# Unit test for function match
def test_match():
    assert match(Command('tsuru ps:apps', "tsuru: \"ps:apps\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapps-list\n\tservice-add\n\tservice-bind\n\tservice-unbind\n"))


# Generated at 2022-06-22 02:33:11.260515
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    command = Command('tsuru hlep', 'tsuru: "hlep" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp\n\tpermission-list')
    assert get_new_command(command) == 'tsuru help'



# Generated at 2022-06-22 02:33:18.043134
# Unit test for function match
def test_match():
    output = 'tsuru: "node" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-add\n\tnode-list\n\tnode-remove\n\tnode-update'
    command = Command(script="tsuru node", output=output, stderr=None)
    assert match(command)


# Generated at 2022-06-22 02:33:20.207781
# Unit test for function match

# Generated at 2022-06-22 02:33:31.989354
# Unit test for function get_new_command
def test_get_new_command():
	out1 = '''tsuru: "turu" is not a tsuru command. See "tsuru help".

Did you mean?
	target-add
	target-remove'''

# Generated at 2022-06-22 02:33:42.433466
# Unit test for function get_new_command
def test_get_new_command():
    raw_output = 'tsuru: "token-bob" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t\ntoken-add\n\ttoken-show\n\ttoken-remove'
    out = Command('token-bob', raw_output)
    assert get_new_command(out) == 'tsuru token-add'

    raw_output = 'tsuru: "app-d" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t\napp-deploy\n\tapp-remove\n\tapp-available\n\tapp-log'
    out = Command('app-d', raw_output)
    assert get_new_command(out) == 'tsuru app-deploy'



# Generated at 2022-06-22 02:34:35.540691
# Unit test for function get_new_command
def test_get_new_command():

    class Command(object):

        def __init__(self, output):
            self.output = output

    assert get_new_command(Command(
        'tsuru: "tsuru keys-add" is not a tsuru command. See "tsuru help".\n'
        '\n'
        'Did you mean?\n'
        '\tkey-add\n'
        '\ttsuru config-set\n'
        '\tkey-list\n'
        '\ttsuru app-log\n'
        '\tkey-remove\n'
        '\tconfig-set\n'
        '\tapp-log\n'
        )) == 'tsuru key-add'

# Generated at 2022-06-22 02:34:41.836214
# Unit test for function get_new_command
def test_get_new_command():
    command_output = """tsuru: "poweroff" is not a tsuru command. See "tsuru help".

Did you mean?
	
	target-add
	target-remove
	target-set"""

    command = type('Command', (object,),
                   {'output': command_output, 'script': 'tsuru poweroff'})()

    assert get_new_command(command) == 'tsuru target-add'

# Generated at 2022-06-22 02:34:52.799362
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('tsuru version',
                                    "tsuru: \"versio\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tversion"))
                           == 'tsuru version')
    assert (get_new_command(Command('tsuru app-create myapp',
                                    'tsuru: "app-creat" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create'))
                           == 'tsuru app-create myapp')

# Generated at 2022-06-22 02:34:58.716079
# Unit test for function match
def test_match():
    assert match(Command('tsuru a', 'tsuru: "a" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tadd-permission\n\tadd-unit\n\tremove-permission\n\tremove-unit\n\tapp-run\n\tapp-log'))


# Generated at 2022-06-22 02:35:08.934314
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru env-set', 'tsuru: "env-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\n\tenv-get\n\tenv-unset\n\n')) == 'tsuru env-get'
    assert get_new_command(Command('tsuru team-team', 'tsuru: "team-team" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\n\tteam-create\n\tteam-remove\n\n')) == 'tsuru team-create'

# Generated at 2022-06-22 02:35:18.628548
# Unit test for function get_new_command
def test_get_new_command():
    output = (
        "tsuru: \"node\" is not a tsuru command. See \"tsuru help\".\n\n"
        "Did you mean?\n\tnode-add\n\tnode-remove\n\tnode-list\n\tnode-info")
    assert "node-add" in get_new_command(Command('tsuru node', output))
    assert "node-remove" in get_new_command(Command('tsuru node', output))
    assert "node-list" in get_new_command(Command('tsuru node', output))
    assert "node-info" in get_new_command(Command('tsuru node', output))

# Generated at 2022-06-22 02:35:22.983195
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('tsuru help',
                                   'tsuru: "help" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps')) == 'tsuru apps'

# Generated at 2022-06-22 02:35:27.884486
# Unit test for function match
def test_match():
    assert match(Command('tsuru help', 'tsuru: "help" is not a tsuru command. See "tsuru help".\nDid you mean?\n\thelp-app'))
    assert not match(Command('tsuru help', 'tsuru: "help" is not a tsuru command. See "tsuru help"'))


# Generated at 2022-06-22 02:35:32.849875
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-logs aaaaaaa', 'tsuru: "app-logs" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-log\n\tapp-remove\n\tapp-run'))
    assert not match(Command('git commit', ''))



# Generated at 2022-06-22 02:35:38.761178
# Unit test for function match
def test_match():
    assert match(Command('tsuru deploy', 'tsuru: "deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tdeploy-app    Deploys a new application\n\tdeploy-unit  deploys a unit to an app.'))
