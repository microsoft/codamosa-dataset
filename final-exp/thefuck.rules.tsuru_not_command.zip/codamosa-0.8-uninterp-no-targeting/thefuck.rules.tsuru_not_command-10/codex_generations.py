

# Generated at 2022-06-22 02:27:07.641514
# Unit test for function match
def test_match():
    cmd = type("Command", (), {"output": "tsuru: \"tsur server-list\" is not a tsuru command. See \"tsur help\".\n\nDid you mean?\n\ttsuru service-list"})
    assert(match(cmd))



# Generated at 2022-06-22 02:27:12.862725
# Unit test for function match
def test_match():
    assert match(Command('tsuruw app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list',
                         ""))
    assert not match(Command('tsuru a', ''))



# Generated at 2022-06-22 02:27:17.127531
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command = Command('tsuru crasy', 'tsuru: "crasy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcreate', '', 0, None)
    assert get_new_command(command) == 'tsuru create'

# Generated at 2022-06-22 02:27:22.379390
# Unit test for function match
def test_match():
    command = Command(script='tsuru AppList',
                      stderr='tsuru: "AppList" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list',)
    assert match(command)

    command = Command(script='tsuru AppList',
                      stderr='tsuru: "AppList" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list',)
    assert not match(command)


# Generated at 2022-06-22 02:27:29.532614
# Unit test for function match
def test_match():
    assert match(Command('tsur', '', ''))
    assert not match(Command('tsur', '', 'No command provided'))
    assert match(Command('tsur', '', 'tsuru version is not a tsuru command'))
    assert not match(Command('tsur', '', 'tsuru version is not a tsuru command. See "tsuru help"'))
    assert not match(Command('tsur', '', 'tsuru version is not a tsuru command. See "tsuru help"'))


# Generated at 2022-06-22 02:27:33.756384
# Unit test for function match
def test_match():
    assert match({'stderr': 'tsuru: "webservice" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tweb-service\n', 'stdout': "tsuru: 'webservice' is not a tsuru command. See 'tsuru help'.", 'script': 'tsuru webservice'})


# Generated at 2022-06-22 02:27:40.169758
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-create bbb', '', '')
    assert get_new_command(command) == replace_command(command, 'bbb', 'app-create')
    command = Command('tsuru app-create bbb', '', '', '', 5)
    assert get_new_command(command) == replace_command(command, 'bbb', 'app-create', 5)

enabled_by_default = True

priority = 1000

# Generated at 2022-06-22 02:27:50.821513
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    command = type("Command", (object,),
                   {"script": "tsuru platform-list",
                    "output": 'tsuru: "platform-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-add\n\tplatform-remove\n\n'})
    assert get_new_command(command) == "tsuru platform-add"

# Generated at 2022-06-22 02:27:59.246241
# Unit test for function match
def test_match():
    assert match(Command('tsuru-tsuru',
                'tsuru: "tsuru-tsuru" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tservice-add\n\tservice-bind\n\tservice-doc\n\tservice-info\n'))
    assert not match(Command('tsuru-tsuru-tsuru', 'tsuru: "tsuru-tsuru-tsuru" is not a tsuru command. See "tsuru help".\n'))



# Generated at 2022-06-22 02:28:03.900564
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-add http://localhost:8080',
                'tsuru: "tsuru target-add http://localhost:8080" is not a ' + \
                        'tsuru command. See "tsuru help".\n\nDid you mean?\n\t' + \
                        'target-add\n\n'))


# Generated at 2022-06-22 02:28:12.338728
# Unit test for function get_new_command
def test_get_new_command():
    c1 = Command('tsuru app-list', 'No $HOME found, using /tmp as temp dir.\ntsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-run\n\tapp-start\n\tapp-restart')
    c2 = Command('tsuru info', 'No $HOME found, using /tmp as temp dir.\ntsuru: "info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n\tservice-info\n\tstatus')
    assert get_new_command(c1) == 'tsuru app-list'

# Generated at 2022-06-22 02:28:23.140732
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command("tsuru badcommand",
                                   output="tsuru: \"badcommand\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tbad\n\tadd",)) == "tsuru bad"
    assert get_new_command(Command("tsuru badcommand",
                                   output="tsuru: \"badcommand\" is not a tsuru command. See \"tsuru help\".\n\nUnknown command \"badcommand\".",)) == "tsuru badcommand"

# Generated at 2022-06-22 02:28:25.645566
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru error-list -r', '', '', '', '')) == ('tsuru error-list --list', 'tsuru error --list')



# Generated at 2022-06-22 02:28:27.091019
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command("tsuru: \"participate\" is not a tsuru command. See tsuru help.") == "tsuru participate"


enabled_by_default = True

# Generated at 2022-06-22 02:28:34.056229
# Unit test for function match
def test_match():
    command = Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-list\n\tapp-remove\n\tapp-run\n\tapp-update\n\tapp-restart\n\tapp-start\n\tapp-stop\n')
    assert match(command)


# Generated at 2022-06-22 02:28:39.499705
# Unit test for function match
def test_match():
	# Test 1
	command = Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tversion-set')
	assert match(command) == True
	# Test 2
	command = Command('tsuru version', ' tsrapp')
	assert match(command) == False


# Generated at 2022-06-22 02:28:48.985901
# Unit test for function match
def test_match():
    assert (' is not a tsuru command. See "tsuru help".' in match("tsuru: \"app-create\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-autoscale")
            and '\nDid you mean?\n\t' in match("tsuru: \"app-create\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-autoscale"))



# Generated at 2022-06-22 02:28:54.320642
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('tsuru foo')) == 'tsuru foo'
    assert get_new_command(Command('tsuru list-apps')) == 'tsuru list-apps'
    assert get_new_command(Command('tsuru app-create')) == 'tsuru app-create'

# Generated at 2022-06-22 02:28:58.302608
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-list -i myapp', 'tsuru: "service-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tinstance-list'))
    assert match(Command('tsuru service-list', 'tsuru: "service-list" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru service-list'))


# Generated at 2022-06-22 02:29:03.419446
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    command = type('obj', (object,), {'output': '''tsuru: "app-edita" is not a tsuru command. See "tsuru help".

Did you mean?
	app-edit
	app-env-set
	app-info
	app-log
	app-log-reade
	app-remove
	app-run
	app-rund'''})
    assert get_new_command(command) == 'tsuru app-edit'

# Generated at 2022-06-22 02:29:11.641612
# Unit test for function match
def test_match():
    assert match(Command('tsuru assa help app-move',
                         "tsuru: \"assa\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-move\n",
                         2))
    assert not match(Command('tsuru app-move', "transferring app my-app to myotherteam... done!\n", 1))



# Generated at 2022-06-22 02:29:19.777851
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    command = type('Command', (object, ),
                   {'script': 'tsuru app-list',
                    'output': ('tsuru: "app-list" is not a tsuru command. '
                               'See "tsuru help".\nDid you mean?\ntarget'
                               '\nlogin')})
    # we want it to suggest 'target' first
    assert get_new_command(command) == 'tsuru target'
    command.output = ('tsuru: "app-list" is not a tsuru command. '
                      'See "tsuru help".\nDid you mean?\nlogin\ntarget')
    assert get_new_command(command) == 'tsuru login'



# Generated at 2022-06-22 02:29:24.254503
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru status', '')) == 'tsuru app-list'
    assert get_new_command(Command('tsuru logs-add', '')) == 'tsuru logs-add'

enabled_by_default = True

# Generated at 2022-06-22 02:29:26.774308
# Unit test for function get_new_command
def test_get_new_command():
    old_command = Command('tsuru app-create')
    new_command = get_new_command(old_command)
    assert new_command == 'tsuru create-app'



# Generated at 2022-06-22 02:29:32.912326
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list | head', 'tsuru: "app-list" is not a tsuru command.\nSee "tsuru help".\n\nDid you mean?\n\tapp-info\n\tapp-restart\n\tapp-start\n\tapp-stop\n\tapps-list'))
    assert match(Command('tsuru app-list | head', '')) is None


# Generated at 2022-06-22 02:29:39.035170
# Unit test for function get_new_command
def test_get_new_command():
    wrong_cmd = 'tsuru: "tusru" is not a tsuru command'\
                '. See "tsuru help".\nDid you mean?\n\ttarget-add'
    assert get_new_command(wrong_cmd) == 'target-add'

    wrong_cmd = 'tsuru: "tsru" is not a tsuru command'\
                '. See "tsuru help".\nDid you mean?\n\tdeploy'
    assert get_new_command(wrong_cmd) == 'deploy'

# Unit tests for function match (parsing the output)

# Generated at 2022-06-22 02:29:49.394066
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("tsuru app-info foo", "tsuru: \"app-info\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-info\n\tapp-info\n\tapp-info\n\tapp-info", 0)) == "tsuru app-info foo"
    assert get_new_command(Command("tsuru app-info", "tsuru: \"app-info\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-info\n\tapp-info\n\tapp-info\n\tapp-info", 0)) == "tsuru app-info"

# Generated at 2022-06-22 02:29:53.231029
# Unit test for function get_new_command
def test_get_new_command():
    command = type(
        'cmd',
        (object,),
        {'output': 'tsuru: "docker-exec" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tps\n\texec'}
    )
    assert get_new_command(command) == 'tsuru ps'

# Generated at 2022-06-22 02:30:04.522247
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('tsuru evn-set v1=1 v2=2', "tsuru: \"env-set\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tenv-get\n\tenv-unset")
    assert get_new_command(command1) == 'tsuru env-set v1=1 v2=2'
    command2 = Command('tsuru evn-unset v1=1', "tsuru: \"evn-unset\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tenv-unset")
    assert get_new_command(command2) == 'tsuru evn-unset v1=1'

# Generated at 2022-06-22 02:30:16.120816
# Unit test for function match
def test_match():
    output1 = u"tsuru: \"tartar\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tstart\n\n"
    output2 = u"tsuru: \"target\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tstart\n\ttarget-add\n\tservice-add\n\tapp-grant\n\tapp-revoke\n\n"
    output3 = u"tsuru: \"targ\" is not a tsuru command. See \"tsuru help\".\n"

    assert match(Command('tartar', output=output1))
    assert match(Command('target', output=output2))
    assert not match(Command('targ', output=output3))


# Generated at 2022-06-22 02:30:20.365775
# Unit test for function match
def test_match():
    match_t = match(Command('tsuru service-instance-bind'))
    assert match_t is True
    match_f = match(Command('tusru'))
    assert match_f is False


# Generated at 2022-06-22 02:30:22.393826
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('tsuru: "errase" is not a tsuru command.') == 'tsuru erase environment-variables -a myapp'

# Generated at 2022-06-22 02:30:25.964924
# Unit test for function match
def test_match():
    assert match(Command('tsuru function', 'tsuru: "function" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfunctions\n'))
    assert not match(Command('tsuru command', 'tsuru: "command" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-22 02:30:32.471287
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru deploy',
                                   'tsuru: "deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-deploy\n\tservice-deploy\n\tunit-add')) == 'tsuru app-deploy'

enabled_by_default = True
priority = 1000

# Generated at 2022-06-22 02:30:36.771080
# Unit test for function get_new_command
def test_get_new_command():
    expected = '/usr/local/bin/tsuru target '
    command = Command('tsuru targt',
            'tsuru: "targt" is not a tsuru command. See "tsuru help".\n'
            '\n'
            'Did you mean?\n'
            '\ttarget\n')
    assert expected == get_new_command(command)

# Generated at 2022-06-22 02:30:39.602524
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-run "ls"', "tsuru: \"ls\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-run\n\tapp-list")) == True  # noqa
    assert match(Command('tsuru app-run "ls"', "xxx")) == False


# Generated at 2022-06-22 02:30:49.506530
# Unit test for function match
def test_match():
    """Match function should return True when there is a typo in the command"""
    assert match(Command('tsuru dis teh app', "tsuru: \"dis\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\ntarget-add")) is True
    assert match(Command('tsuru dis teh app', "tsuru: \"dis\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\ntarget-remove")) is True
    assert match(Command('tsuru dis teh app', "tsuru: \"dis\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\ntarget-list")) is True

# Generated at 2022-06-22 02:30:54.063495
# Unit test for function match
def test_match():
    assert for_app('tsuru')(match)('tsuru: "log" is not a tsuru command.'
            '\nDid you mean?\n\tlogs\n\tlog-rebalance\n\tshow-logs')


# Generated at 2022-06-22 02:31:04.450398
# Unit test for function match
def test_match():
    invalid_output = """ERROR: "foo" is not a tsuru command. See "tsuru help".

Did you mean?
	target-list
	token-add
	token-remove
	token-info
	target-add
	target-remove
	target-info"""
    invalid_command = Command('tsuru foo', invalid_output)
    assert match(invalid_command)

    valid_output = """tsuru: "target-foo" is not a tsuru command. See "tsuru help".

Did you mean?
	target-list
	token-add
	token-remove
	token-info
	target-add
	target-remove
	target-info"""
    valid_command = Command('tsuru target-foo', valid_output)
    assert not match(valid_command)


# Generated at 2022-06-22 02:31:06.714362
# Unit test for function match
def test_match():
    match_tester = match('tsuru d action-list')
    assert match_tester is True


# Generated at 2022-06-22 02:31:18.642407
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru app-list',
                         stderr='tsuru: "app-list" is not a tsuru command. See "tsuru help".' + '\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-restart\n\tapp-start\n\tapp-stop\n\tapp-lock\n\tapp-unlock\n\tapp-info\n\tapp-deploy\n\tapp-log\n\tapp-grant',
                         output=''))


# Generated at 2022-06-22 02:31:22.478661
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru hello', 'tsuru: "hello" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp')) == 'tsuru help'

# Generated at 2022-06-22 02:31:32.981069
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-add postgr-9.4 jhonatan/postg-9r4',
                         'tsuru: "service-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-service-add'))
    assert match(Command('tsuru app-create -p php jhony',
                         'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create-task'))
    assert match(Command('tsuru db-remove postgres',
                         'tsuru: "db-remove" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tdb-remove-instance'))
    assert not match

# Generated at 2022-06-22 02:31:37.366388
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "cp" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tcreate-platform'
    assert get_new_command(Command('tsuru cp', output)) == 'tsuru create-platform'

# Generated at 2022-06-22 02:31:42.182214
# Unit test for function match
def test_match():
    assert match(Command('name', stderr="tsuru: \"name\" is not a tsuru command. See \"tsuru help\"."))
    assert not match(Command('name', stderr="tsuru: \"name\" is not a tsuru command"))
    assert not match(Command('name', stderr="tsuru: \"name\" is not a tsuru"))


# Generated at 2022-06-22 02:31:51.251562
# Unit test for function get_new_command
def test_get_new_command():
    temp_file = tempfile.NamedTemporaryFile(mode='w+t')
    temp_file.write(
        'tsuru: "tsuru-foo" is not a tsuru command. See "tsuru help".\n')
    temp_file.write('\nDid you mean?\n\ttsuru-bar\n\ttsuru-foo\n\ttsuru-foz')
    temp_file.flush()
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    from thefuck.shells import Shell
    from thefuck.types import Command

    assert get_new_command(Command('tsuru-foo', temp_file.name, Shell())) == \
        'tsuru-bar'

    temp_file.close()

# Generated at 2022-06-22 02:32:01.726304
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-list',
                      'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\n',
                      '')

    assert get_new_command(command) == 'tsuru app-list'

    command = Command('tsuru cat-file',
                      'tsuru: "cat-file" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcat\n\tnfs-create-file\n\tnfs-list-file\n\tnfs-remove-file\n\n',
                      '')

    assert get_new_command(command) == 'tsuru cat'

# Generated at 2022-06-22 02:32:09.070229
# Unit test for function get_new_command
def test_get_new_command():
    text = "tsuru: \"admin\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tadmin-team-remove\n\tadmin-team-add\n\n"
    assert get_new_command(Command('foo', text)) == 'tsuru admin-team-remove'
    assert get_new_command(Command('admin', text)) == 'tsuru admin-team-remove'
    assert get_new_command(Command('foo', '')) == ''
    assert get_new_command(Command('foo', 'a\nb')) == ''

# Generated at 2022-06-22 02:32:14.263930
# Unit test for function get_new_command
def test_get_new_command():
    command_output = 'tsuru: "tsrus" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tstatus\n\n'
    command = Command('tsrus', command_output)
    assert get_new_command(command) == 'tsuru status'

# Generated at 2022-06-22 02:32:19.170460
# Unit test for function get_new_command
def test_get_new_command():
    # Test get_new_command function return the fix command
    output = 'tsuru: "run" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\trun-container\n\trun-agent'
    command_to_test = Command('tsuru run', output)
    assert get_new_command(command_to_test) == 'tsuru run-container'



# Generated at 2022-06-22 02:32:29.240571
# Unit test for function match
def test_match():
    assert match('tsuru: "foo" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tfoo\n')


# Generated at 2022-06-22 02:32:39.286497
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("tsuruuu target-set a.b.c",
                                   output="tsuru: \"tsuruuu\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\ttsuru")) == \
           "tsuru target-set a.b.c"
    assert get_new_command(Command("tsuruuu target-set a.b.c",
                                   output="tsuru: \"tsuruuu\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\ttsuru\n\ttarget-set")) == \
           "tsuru target-set a.b.c"

# Generated at 2022-06-22 02:32:42.692904
# Unit test for function get_new_command
def test_get_new_command():
    command = 'tsuru: "aaa" is not a tsuru command. See "tsuru help".\nDid you mean?\n\taaa-bbb'
    get_new_command(command) == 'tsuru aaa-bbb'

# Generated at 2022-06-22 02:32:51.165924
# Unit test for function match
def test_match():
    out1 = 'tsuru: "test" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttest-command\n\ttest-config\n\ttarget-add\n\ttarget-remove\n\ttarget-set\n'
    out2 = 'tsuru: "test" is not a tsuru command. See "tsuru help".'
    assert match(Command('tsuru test', out1, '')) == True
    assert match(Command('tsuru test', out2, '')) == False


# Generated at 2022-06-22 02:32:56.116243
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru object test')
    command.output = """tsuru: "object" is not a tsuru command. See "tsuru help".

Did you mean?
	info"""
    assert get_new_command(command) == 'tsuru info'

# Generated at 2022-06-22 02:33:06.519968
# Unit test for function get_new_command
def test_get_new_command():
    output = 'ERROR: "tsuru-login" is not a tsuru command.\nSee "tsuru help".\n\nDid you mean?\n\tlogin\n'
    assert get_new_command('tsuru login', output) == 'tsuru login'

# Generated at 2022-06-22 02:33:10.941731
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru servicelists', 'tsuru: "servicelists" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tservice-list')
    assert get_new_command(command) == 'tsuru service-list'

# Generated at 2022-06-22 02:33:13.103710
# Unit test for function match
def test_match():
    assert match(Command('tsuru', 'hep'))



# Generated at 2022-06-22 02:33:20.656836
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru target-addtttt tsuru-test http://host.com', '')
    assert get_new_command(command) == 'tsuru target-add tsuru-test http://host.com'
    command = Command('tsuru target-listttt',
    'tsuru: "target-listttt" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-list')
    assert get_new_command(command) == 'tsuru target-list'

# Generated at 2022-06-22 02:33:23.056653
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsru app-creaate myapp', '')) == 'tsuru app-create myapp'

# Generated at 2022-06-22 02:33:41.704525
# Unit test for function match
def test_match():
    assert match(Command('tsuru env-set', 'tsuru: "env-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tenv-get\n\n'))

# Generated at 2022-06-22 02:33:52.349117
# Unit test for function get_new_command

# Generated at 2022-06-22 02:34:00.251899
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('tsurue',
    '''tsuru: "tsurue" is not a tsuru command. See "tsuru help".

Did you mean?
	team-add''', None)) == 'tsuru team-add'

    assert get_new_command(Command('tsurue',
    '''tsuru: "tsurue" is not a tsuru command. See "tsuru help".

Did you mean?
	team-add
	team-remove
	team-user-add
	team-user-remove''', None)) == 'tsuru team-add'

# Generated at 2022-06-22 02:34:06.930661
# Unit test for function get_new_command
def test_get_new_command():
    output_command = '''tsuru: "tsuru-list" is not a tsuru command. See "tsuru help".

Did you mean?
        target-list


Run tsru help for usage.

'''
    from thefuck.types import Command
    assert get_new_command(Command(script='tsuru tsuru-list',
                                   output=output_command)) == 'tsuru target-list'



# Generated at 2022-06-22 02:34:12.111542
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    output = "tsuru: \"install\" is not a tsuru command. See \"tsuru help\"."
    output += "\n\nDid you mean?\n\tcreate-app"
    new_command = get_new_command(Command('tsuru install', output))
    assert new_command == 'tsuru create-app'

# Generated at 2022-06-22 02:34:21.215162
# Unit test for function match
def test_match():
    assert match(Command('', 'tsuru: "admin" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-admin-add\n\tapp-admin-remove\n\tapp-admin-set\n\tapp-admin-show\n\tapp-allow\n\tapp-deny\n\tapp-pool-change\n\tapp-pool-list\n\tapp-remove\n\tapp-restart\n\tapp-start\n\tapp-stop\n\tapp-unbind\n\tapp-update', '')) == True


# Generated at 2022-06-22 02:34:26.683666
# Unit test for function get_new_command
def test_get_new_command():
    assert ('test' in get_new_command('tsuru: "test" is not a tsuru command.\n'
                                      'Did you mean?\n\tnot-test')[0])
    assert ('abc' in get_new_command('tsuru: "abc" is not a tsuru command.\n'
                                     'Did you mean?\n\tnot-abc')[0])

# Generated at 2022-06-22 02:34:37.605656
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output = """tsuru: "app-info" is not a tsuru command. See "tsuru help".

Did you mean?
    app-create
    app-deploy
    app-remove
    app-info
    app-list
    app-log
"""
    command = Command('tsuru app-info', output)
    assert get_new_command(command) == 'tsuru app-info'
    output = """tsuru: "app-info" is not a tsuru command. See "tsuru help".

Did you mean?
    app-create
    app-deploy
    app-remove
    app-info
    app-list
    app-log
"""
    command = Command('tsuru app-info', output)

# Generated at 2022-06-22 02:34:45.801885
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-create testapp',
                                   'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-remove\n\tapp-update')) == \
    Command('tsuru app-update testapp',
            'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-remove\n\tapp-update')

# Generated at 2022-06-22 02:34:49.855897
# Unit test for function match
def test_match():
    assert match(Command('tsurur user-create', 'tsuru: "user-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tuser-create')) is True


# Generated at 2022-06-22 02:35:13.887584
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(
        Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-remove', '')) == 'tsuru app-create'
    assert get_new_command(
        Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-info\n\tapp-remove', '')) == 'tsuru app-list'

# Generated at 2022-06-22 02:35:22.150134
# Unit test for function match
def test_match():
    wrong_command = Command('tsuru deis',
                            'tsuru: "deis" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tdeploy\n\tdocker-exec\n\tnode-container-add\n\tnode-container-list\n\tnode-container-remove\n\tnode-remove\n\tnode-update\n')
    correct_command = Command('tsuru docker-exec', '')

    assert match(wrong_command)
    assert not match(correct_command)


# Generated at 2022-06-22 02:35:30.375099
# Unit test for function get_new_command
def test_get_new_command():
    import collections
    Command = collections.namedtuple('Command', 'script')
    Output = collections.namedtuple('Output', 'stdout stderr')

    output = Output('tsuru: "app-remove" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-remove-units\n\tapp-remove-unit', None)
    command = Command('tsuru app-remove')
    assert 'tsuru app-remove-units' == get_new_command(command)
    assert 'tsuru app-remove-unit' == get_new_command(command)

# Generated at 2022-06-22 02:35:38.125333
# Unit test for function get_new_command
def test_get_new_command():
    context = None
    output = 'tsuru: "my" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tmy-app'
    command = type('Command', (object,), {
        'script': 'tsuru',
        'stdout': '',
        'stderr': '',
        'output': output,
        'context': context
    })
    assert get_new_command(command).script == 'tsuru my-app'

# Generated at 2022-06-22 02:35:42.319682
# Unit test for function get_new_command
def test_get_new_command():
    assert ('tsr admin-list' == get_new_command(
        Command('tsr admin-list', "tsuru: \"tsr\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n    admin-list")))

# Generated at 2022-06-22 02:35:47.030127
# Unit test for function get_new_command
def test_get_new_command():
    output = """tsuru: "cmd" is not a tsuru command. See "tsuru help".

Did you mean?
        cmd1
        cmd2

Run 'tsuru --help' for usage.
"""
    command = Command('tsuru cmd', output)
    assert get_new_command(command) == 'tsuru cmd1'

# Generated at 2022-06-22 02:35:49.223071
# Unit test for function match
def test_match():
    assert match(Command('tsuru sefasdfsa', ''))
    assert not match(Command('tsuru app-info --app=nossas', ''))

# Generated at 2022-06-22 02:35:53.710104
# Unit test for function match
def test_match():
    tsuru_command = "tsuru: 'app-run' is not a tsuru command. See 'tsuru help'."

    assert (match(Command(script=tsuru_command, stderr=tsuru_command)) ==
            True)


# Generated at 2022-06-22 02:36:01.265454
# Unit test for function match
def test_match():
	# Testing for successful situation
    assert (match(Command(script = "tsuru hello world is not a tsuru command. See tsuru help.",
                stderr = "",
                stdout = "Did you mean?\ntsuru help\n")) == True)

    # Testing for unsuccessful situation
    assert (match(Command(script = "tsuru hello world",
                stderr = "",
                stdout = "Did you mean?\ntsuru help\n")) == False)


# Generated at 2022-06-22 02:36:12.965293
# Unit test for function get_new_command

# Generated at 2022-06-22 02:36:33.859492
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'command': 'tsuru deploy',
                                          'output': 'tsuru: "deploy" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-deploy'})
    assert get_new_command(command).command == 'tsuru app-deploy'

# Generated at 2022-06-22 02:36:40.136244
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "tsuru add-unit" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tadd-key\n\tadd-perm\n\tadd-role\n\tadd-user\n\tadd-user-key\n\tadd-user-token'
    new_command = get_new_command(Command('tsuru add-unit user-foo', output))
    assert new_command == 'tsuru add-user user-foo'

# Generated at 2022-06-22 02:36:47.417758
# Unit test for function get_new_command
def test_get_new_command():
    error_msg = ('tsuru: "wrong_command" is not a tsuru command. See "tsuru help"'
                 '\nDid you mean?\n\tcreate-app\n\tapp-create\n\tapp-run\n\tapp-info')
    c = Command('tsuru wrong_command', error_msg)
    assert get_new_command(c) == "tsuru create-app"

# Generated at 2022-06-22 02:36:55.329988
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-log\n\tapp-run\n\tapp-info\n')) ==
            'tsuru app-run')
    assert (get_new_command(Command('tsuru team-user-remove', 'tsuru: "team-user-remove" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tteam-remove-user\n')) ==
            'tsuru team-remove-user')

# Generated at 2022-06-22 02:37:00.448665
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('tsuru target-list', 'tsuru: "target-list" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\ttarget-get\n\ttarget-list\n\ttarget-remove')) == 'tsuru target-list')
    assert(get_new_command(Command('tsuru target-list', 'tsuru: "target-list" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\ttarget-get\n\ttarget-list\n\ttarget-remove')) != 'tsuru target-list')



# Generated at 2022-06-22 02:37:10.515575
# Unit test for function get_new_command
def test_get_new_command():
    output = "tsuru: \"confg\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tconfigure"
    cmd = Command('tsuru confg', output)
    assert get_new_command(cmd)  == "tsuru configure"

# TODO: Output when there is more than one option in the list
# Unit test 2 for function get_new_command
# output = """tsuru: "app-delete" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-remove\n\trm\n\trm-app\n\trm-user"""
# cmd = Command('tsuru app-delete', output)
# assert get_new_command(cmd)  == "tsuru app-remove"