

# Generated at 2022-06-22 02:27:06.174211
# Unit test for function match
def test_match():
    command = Command("tsuru status", "tsuru: \"status\" is not a tsuru command. See \"tsuru help\".")
    assert match(command) is True
    command = Command("tsuru status", "tsuru: \"status\" is not a tsuru command. See \"tsuru help\".")
    assert match(command) is True



# Generated at 2022-06-22 02:27:11.099326
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-create test --team escambo', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create')
    assert get_new_command(command) == 'tsuru app-create test --team escambo'

# Generated at 2022-06-22 02:27:20.765504
# Unit test for function get_new_command
def test_get_new_command():
    assert get_all_matched_commands(
        u"tsuru: \"view-ouput\" is not a tsuru command. See \"tsuru help\".") == [u"view-ouput"]
    assert get_new_command(
        Command('tsuru view-ouput',
                'tsuru: "view-ouput" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tview-app\n\tview-node',
                '', '', '')) == Command('tsuru view-app',
                                        'tsuru: "view-ouput" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tview-app\n\tview-node',
                                        '', '', '')

# Generated at 2022-06-22 02:27:25.424851
# Unit test for function match
def test_match():
    broken_cmd = 'tsuru: "tsr" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsuru\n'
    assert match(Command('tsr', output=broken_cmd))



# Generated at 2022-06-22 02:27:33.159368
# Unit test for function match
def test_match():
    assert not match(Command('tsuru app-create ', ''))
    assert not match(Command('tsuru app-remove ', ''))
    assert match(Command('tsuru vvvvvvvvvvv',
                         'tsuru: "vvvvvvvvvvv" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-list\n\tapp-remove'))

# Generated at 2022-06-22 02:27:42.903420
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-list-units\n\tapp-remove'))
    assert not match(Command('tsuru app-list', ''))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-info'))

# Generated at 2022-06-22 02:27:45.297254
# Unit test for function match
def test_match():
    command = Command('tsurur config', 'tsuru: "config" is not a tsuru command. See "tsuru help"')
    output = match(command)
    assert output == True



# Generated at 2022-06-22 02:27:51.214196
# Unit test for function match
def test_match():
	# If tsuru command is not found, this function will always return True
	# Therefore, tsuru command can be considered with any word
	assert match(Command('tsuru hehe', 'tsuru: "hehe" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp\n\tversion')) == True


# Generated at 2022-06-22 02:27:57.856320
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {
        'script': "tsuru app-info app_test",
        'output': ("tsuru: \"app-info\" is not a tsuru command. See "
                   "\"tsuru help\".\n\nDid you mean?\n\tapp-info\n")})

    assert get_new_command(command) == 'tsuru app-info app_test'



# Generated at 2022-06-22 02:28:07.497163
# Unit test for function match
def test_match():
    output1 = ('tsuru: "target-remove" is not a tsuru command. See "tsuru help".\n'
              '\n'
              'Did you mean?\n'
              '\ttarget-list\n'
              '\ttarget-set\n'
              '\trotate-key-pair\n'
              '\tdeploy-key-add\n'
              '\tdeploy-key-remove')
    output2 = ('tsuru: "deploy-list" is not a tsuru command. See "tsuru help".\n'
              '\n'
              'Did you mean?\n'
              '\tdeploy-key-add\n'
              '\tdeploy-key-remove')

# Generated at 2022-06-22 02:28:13.253715
# Unit test for function get_new_command
def test_get_new_command():
    test_command = type('command', (object,), {'output': 'tsuru: "test" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttest\n\ntest\n'})
    assert get_new_command(test_command) == 'tsuru test'

# Generated at 2022-06-22 02:28:18.848646
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru token-add', 'tsuru: "token-ad" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t token-add')) == 'tsuru token-add'


# Generated at 2022-06-22 02:28:30.467162
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    # test when 'tsuru app-create' is typed
    command = Command('tsuru app-create',
        'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n')
    assert get_new_command(command) == 'tsuru app-create'

    # test when 'tsuru app-list' is typed
    command = Command('tsuru app-list',
    'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n')
    assert get_new_command(command) == 'tsuru app-list'

# Generated at 2022-06-22 02:28:38.059456
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='',
                                   stderr='tsuru: "creat" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tcreate')) == (
        Command(script='',
                stderr='tsuru: "creat" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tcreate'),
        ['create']
    )


enabled_by_default = True

# Generated at 2022-06-22 02:28:41.940880
# Unit test for function match
def test_match():
    assert not match(Command('tsuru app-list', stderr=' is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert match(Command('tsuru app-list', ' is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))

# Generated at 2022-06-22 02:28:49.522018
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('tsuru doctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoc',
                                    'tsuru: "doctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoctoc" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tdoctoc',
                                    '')) ==
            'tsuru doctoc')

# Generated at 2022-06-22 02:28:56.595557
# Unit test for function match
def test_match():
    assert match(Command('tsuru aaa', 'tsuru: "aaa" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tadd-key\n\tadd-unit\n\tadmin\n\tapp-create\n\tapp-delete\n\tapp-info\n\tapp-log\n\t...'))
    assert not match(Command('tsuru aaa', 'Unknown command: aaa\nRun tsuru help for usage.'))



# Generated at 2022-06-22 02:29:01.788224
# Unit test for function get_new_command
def test_get_new_command():
    tsuru_output = '''tsuru: "fake" is not a tsuru command. See "tsuru help".

Did you mean?
	app-list
	app-remove
	platform-list
'''
    assert get_new_command(Command('tsuru fake', tsuru_output)) == 'tsuru app-list'

# Generated at 2022-06-22 02:29:04.491875
# Unit test for function match
def test_match():
    assert match(Command('tsru', 'tsuru: "tsru" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsuru\n'))



# Generated at 2022-06-22 02:29:15.271229
# Unit test for function match
def test_match():
    command = Command('tsuru app-create test-app\n'
                      'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n'
                      '\nDid you mean?\n'
                      '\tadd-cname\n'
                      '\tapp-add-unit\n'
                      '\tapp-autoscale-list\n'
                      '\tapp-info\n'
                      '\tapp-list\n'
                      '\tapp-remove\n'
                      '\tapp-remove-unit\n'
                      '\tapp-restart\n'
                      '\tapp-run\n'
                      '\tapp-start\n')
    assert match(command)


# Generated at 2022-06-22 02:29:25.699929
# Unit test for function match
def test_match():
    assert not match(Command('tsuru app-create', '', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-create qqq', '', ''))
    assert match(Command('tsuru app-create', '', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-remove'))


# Generated at 2022-06-22 02:29:31.285913
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Shell
    output = ('tsuru: "target-add" is not a tsuru command. See "tsuru help"'
              '\nDid you mean?\n\t'
              'target-remove'
              'target-set')
    shell = Mock(spec=Shell)
    shell.system_output.return_value = output
    command = Command('tsuru target-add localhost', '', '', shell=shell)

    assert get_new_command(command) == 'tsuru target-remove localhost'

# Generated at 2022-06-22 02:29:32.856395
# Unit test for function match
def test_match():
    assert match("tsuru: \"he\" is not a tsuru command. See \"tsuru help\"."
                 "\nDid you mean?\n\thelp")



# Generated at 2022-06-22 02:29:36.786593
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info appname', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-info'))
    assert not match(Command('tsuru help', 'Usage of tsuru command line tool:\n'))



# Generated at 2022-06-22 02:29:46.049392
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-info\n\tapp-log\n\tapp-restart\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-grant\n\tapp-revoke\n\tapp-add\n\tapp-remove-unit\n\tapp-remove-unit-by-name', ""))
    assert result == 'tsuru app-create'

# Generated at 2022-06-22 02:29:50.563996
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('tsuru target-list', '')) == 'tsuru target-list'
    assert get_new_command(Command('tsuru service-doc', '')) == 'tsuru service-doc'

# Generated at 2022-06-22 02:29:56.571773
# Unit test for function match
def test_match():
    assert match(Command('tsuru doo', 'tsuru: "doo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tadd-key\n\tapp-create\n\tapp-list\n\tapp-run', '', 0))
    assert not match(Command('tsuru app-list', '', '', 0))



# Generated at 2022-06-22 02:30:07.708446
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import Command

    command = Command('tsuru zssss', 'tsuru: "zssss" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tlogin\n\tlogout\n\ttarget\n\thelp')
    assert get_new_command(command) == 'tsuru help'

    command = Command('tsuru zssss', 'tsuru: "zssss" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tlogin')
    assert get_new_command(command) == 'tsuru login'

    command = Command('tsuru zssss', 'tsuru: "zssss" is not a tsuru command. See "tsuru help".')
   

# Generated at 2022-06-22 02:30:13.220763
# Unit test for function get_new_command
def test_get_new_command():
    output = "tsuru: \"move\" is not a tsuru command. See \"tsuru help\". \
\nDid you mean?\n\tmove-units\tUnits management plugin for tsuru\n"
    command = Command(script="tsuru move", output=output)
    assert get_new_command(command) == "tsuru move-units"

# Generated at 2022-06-22 02:30:17.301710
# Unit test for function match
def test_match():
	assert match(Command('tsuru sevices-add', 'tsuru: "sevices-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservices-add'))
	assert not match(Command('tsuru login', ''))



# Generated at 2022-06-22 02:30:25.521156
# Unit test for function match
def test_match():
    assert match('tsuru: "potato" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-add\n\tplatform-create\n\tplatform-remove\n\ttemplate-list\n\tuser-create\n\tuser-remove') is True
    assert match('tsuru: "potato" is not a tsuru command. See "tsuru help".') is False


# Generated at 2022-06-22 02:30:32.085386
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-add default my.target.co', 'tsuru: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-add\n\tservice-add\n'))
    assert not match(Command('tsuru',''))
    assert not match(Command('tsuru app-create',''))


# Generated at 2022-06-22 02:30:35.138192
# Unit test for function match
def test_match():
    assert match(Command('tsuruuu login', 'tsuru: "tsuruuu" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tlogin')) == True



# Generated at 2022-06-22 02:30:38.226789
# Unit test for function match
def test_match():
    command = Command('tsuru unit:add my-app my-unit',
                      "tsuru: \"unit:add\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tunit-add")
    assert match(command)


# Generated at 2022-06-22 02:30:43.813268
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-create test',
                                   'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n')) == 'tsuru app-create test'

# Generated at 2022-06-22 02:30:46.994962
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('tsuru: "add-key" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tadd-key', 'add-key') == 'tsuru add-key'

# Generated at 2022-06-22 02:30:50.597236
# Unit test for function match
def test_match():
    assert match(Command('tsuru bs', 'tsuru: "bs" is not a tsuru command. See "tsuru help".\n\n\x1b[0;31;1mCommand error!\x1b[0m\n\nDid you mean?\n\tblock-remove\n\tblock-list'))


# Generated at 2022-06-22 02:30:59.867036
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create', 'tsuru app-create is not a tsuru command. See "tsuru help" for usage.'
        '\n\nDid you mean?\n\tapp-create'))
    assert match(Command('tsuru app-create', 'tsuru app-create is not a tsuru command. See "tsuru help" for usage.'
        '\n\nDid you mean?\n\tapp-create'))
    assert not match(Command('pwd', ''))
    assert not match(Command('tsuru app-create', 'tsuru app-create is not a tsuru command. See "tsuru help" for usage.'))


# Generated at 2022-06-22 02:31:04.736909
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru add-key user key',
                                   'tsuru: "add-key" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tkey-add')) \
        == 'tsuru key-add user key'

# Generated at 2022-06-22 02:31:13.028866
# Unit test for function match
def test_match():
    assert not match(Command())
    assert match(Command('tsuruu is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-run\n\tapp-info\n\tapp-list\n\tapp-restart\n\tapp-start\n\tapp-stop', '', 1, ''))
    assert match(Command('tsuru: "tsuruu" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-run\n\tapp-info\n\tapp-list\n\tapp-restart\n\tapp-start\n\tapp-stop', '', 1, ''))



# Generated at 2022-06-22 02:31:25.439265
# Unit test for function get_new_command
def test_get_new_command():
    assert ('tsuru app-get-env -a app-name' ==
            get_new_command({'output': 'tsuru: "tsuru app-get-evn" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-get-env\n\nSee "tsuru help [command]" for more information about a command.'}))
test_get_new_command()

# Generated at 2022-06-22 02:31:36.479362
# Unit test for function match
def test_match():
    assert match(Command('tsuru app', "tsuru: 'app' is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-info\n\tapp-lock\n\tapp-log\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-remove\n\tapp-list\n\tapp-create\n\tapp-change-units\n\tapp-grant-access\n\tapp-revoke-access\n\tapp-deploy\n\tapp-restart\n\tapp-info\n\tapp-list\n\tapp-remove\n\tapp-restart\n\tapp-start\n\tapp-stop", 'tsuru app'), None)

# Generated at 2022-06-22 02:31:40.031033
# Unit test for function match
def test_match():
    output = "tsuru: \"deploy-app\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tdeploy-unit\n"
    assert match(Command('turtle deploy-app', output))



# Generated at 2022-06-22 02:31:45.841951
# Unit test for function match
def test_match():
    broken_command = Command('tsru target-list', 'tsuru: "target-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add\n\ttarget-remove\n\n')
    not_broken_command = Command('tsuru help', 'huehue')
    assert match(broken_command)
    assert not match(not_broken_command)


# Generated at 2022-06-22 02:31:53.482648
# Unit test for function get_new_command
def test_get_new_command():
    out1 = 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n'\
           'Did you mean?\n'\
           '\tapp-info'
    out2 = 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n'\
           'Did you mean?\n'\
           '\tapp-info\n'\
           '\tapp-deploy'

# Generated at 2022-06-22 02:31:58.751769
# Unit test for function get_new_command
def test_get_new_command():
    command = type('', (), {})()
    command.output = ('tsuru: "targz-push" is not a tsuru command. See "tsuru '
                      'help".\nDid you mean?\n\t\ttargz-create')
    assert get_new_command(command) == 'tsur targz-create'

# Generated at 2022-06-22 02:32:01.726068
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru login', 'tsuru: "login" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlog-in')) == 'tsuru log-in'

# Generated at 2022-06-22 02:32:05.524345
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsurur help', 'tsuru: "tsurur" is not a tsuru command\n\nDid you mean?\n\t help')
    assert get_new_command(command) == 'tsuru help'

# Generated at 2022-06-22 02:32:12.172137
# Unit test for function get_new_command
def test_get_new_command():
    """
    assert if get_new_command returns command line [0] and the new command
    line is correct
    """
    command = Command(script='tsuru app-create foo',
                      stderr='tsuru: "app-create" is not a tsuru command. See "tsur\
u help".')
    assert get_new_command(command) == 'tsuru app-create foo'
    command = Command(script='tsuru a', stderr='tsuru: "a" is not a tsuru command. See "tsuru help".\
\n\nDid you mean?\n\tapp-add\n\tapp-remove')
    assert get_new_command(command) == 'tsuru app-add'


enabled_by_default = True

# Generated at 2022-06-22 02:32:14.726453
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-deploy -a app', "tsuru: \"app-deploy\" is not a tsuru command. See \"tsuru help\"."))


# Generated at 2022-06-22 02:32:36.821728
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Cmd('tsuru cat /bin/cat', '')) == \
        'tsuru cat /bin/cat'
    assert get_new_command(Cmd('tsuru caa /bin/cat', '')) == \
        'tsuru cat /bin/cat'
    assert get_new_command(Cmd('tsuru cat', '')) == \
        'tsuru app-run /bin/cat'
    assert get_new_command(Cmd('tsuru caa', '')) == \
        'tsuru app-run /bin/cat'

# Generated at 2022-06-22 02:32:47.840411
# Unit test for function get_new_command
def test_get_new_command():
    assert (
        get_new_command(Command('tsuru check',
            ''
            'tsuru: "check" is not a tsuru command. See "tsuru help".\n'
            '\n'
            'Did you mean?\n'
            '\tcheck-data\n'
            '\tcheck-heap\n'
            '\tcheck-lock\n'
            '\tcheck-mail\n'
            '\tcheck-memory\n'
            '\tcheck-regexp'
        )) == 'tsuru check-data'
    )


# Generated at 2022-06-22 02:32:52.303299
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list'))
    assert not match(Command('foo', ''))


# Generated at 2022-06-22 02:33:00.951948
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru -a myapp', 'tsuru: "-a" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-run\n\tapp-list\n\tapp-log\n\tapp-info\n\tapp-deploy\n\tapp-start\n\tapp-stop\n\tapp-remove\n')) == "tsuru app-info -a myapp"

# Generated at 2022-06-22 02:33:02.902356
# Unit test for function get_new_command
def test_get_new_command():
     command = Command('tsuru comand', '')
     assert get_new_command(command) == 'tsuru help'


enabled_by_default = True

# Generated at 2022-06-22 02:33:06.882816
# Unit test for function match
def test_match():
    assert match(Command('tsuru something', 'tsuru: "something" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tservice-instance\n\tservice-instance-add\n\tservice-instance-update\n\tservice-instance-remove'))


# Generated at 2022-06-22 02:33:11.356978
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('tsuru not-a-command', 'tsuru: "not-a-command" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnotify-remove')
    assert get_new_command(cmd) == 'tsuru notify-remove'

# Generated at 2022-06-22 02:33:22.584497
# Unit test for function get_new_command
def test_get_new_command():

    # Wrong command
    command = Command(script='tsur create-app myapp',
                      stderr=''
                            'tsuru: "create-app" is not a tsuru command. See "tsuru help".\n'
                            '\n'
                            'Did you mean?\n'
                            '	app-create\n')
    assert get_new_command(command) == 'tsur app-create myapp'

    # Wrong command with spaces in the beginning of command

# Generated at 2022-06-22 02:33:27.589161
# Unit test for function get_new_command
def test_get_new_command():
    output = "tsuru: \"myapp\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-create"
    assert get_new_command(Command('tsuru myapp', output)) == 'tsuru app-create'

# Generated at 2022-06-22 02:33:35.647768
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command('tsuru app-rm myapp', '', 'tsuru: "app-rm" is not a tsuru command\n\nDid you mean?\n    app-remove\n    app-remove-unit\n    app-run\n    app-start\n    app-swap\n    app-stop\n    app-metadata\n    app-update\n    app-update-cname\n    app-unbind\n'))
    assert result == 'tsuru app-remove myapp'


enabled_by_default = True

# Generated at 2022-06-22 02:34:09.864884
# Unit test for function match
def test_match():
    match_command = ('tsuru rollback app01\n'
                     'tsuru: "rollback" is not a tsuru command. See "tsuru '
                     'help".\n'
                     '\n'
                     'Did you mean?\n'
                     '\trestart')
    assert match(Command(match_command, ''))



# Generated at 2022-06-22 02:34:20.581489
# Unit test for function match
def test_match():
    assert (match(Command(script='tsuru app-delete ugly_app',
                         stderr=("tsuru: \"app-delete\" is not a tsuru command. See \"tsuru help\"."
                                 "\n\nDid you mean?\n\tapp-remove"))).stderr
            == ("tsuru: \"app-delete\" is not a tsuru command. See \"tsuru help\"."
                "\n\nDid you mean?\n\tapp-remove"))

    assert not match(Command(script='tsuru app-remove ugly_app',
                             stderr=("tsuru: \"app-remove\" is not a tsuru command. See \"tsuru help\"."
                                     "\n\nDid you mean?\n\tapp-remove"))).stderr


# Generated at 2022-06-22 02:34:25.362117
# Unit test for function match
def test_match():
    output = '''tsuru: "deploy-app" is not a tsuru command. See "tsuru help".

Did you mean?
        deploy-list
'''

    assert match(Command('tsuru deploy-app', output=output))
    assert not match(Command('tsuru help', output=output))



# Generated at 2022-06-22 02:34:28.177673
# Unit test for function get_new_command
def test_get_new_command():
    command = 'tsuru: "app-add" is not a tsuru command. See "tsuru help"'
    corrected_command =  'app-create'
    assert get_new_command(command) == corrected_command

# Generated at 2022-06-22 02:34:33.911405
# Unit test for function match
def test_match():
    output_error = 'tsuru: "tsuru privilege-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tprivileges\n'
    assert(match(Command(script='tsuru privilege-list', output=output_error)) == True)
    

# Generated at 2022-06-22 02:34:35.634741
# Unit test for function match
def test_match():
    assert match(Command('tsuru hello', ''))
    assert not match(Command('tsuru', ''))



# Generated at 2022-06-22 02:34:37.231434
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-list',
                         target_list_output))


# Generated at 2022-06-22 02:34:40.396349
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru prt', 'command not found tsuru prt')) == 'tsuru part'

# Unit test

# Generated at 2022-06-22 02:34:48.634422
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlist-apps\n\n'))
    assert not match(Command('tsuru app-create'))
    assert match(Command('tsuru app-create docker-registry', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcreate-app\n\n'))


# Generated at 2022-06-22 02:34:57.138856
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('foo',
                                  'error: "foo" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tfoo\n\tbar\n\tbaz\n')) == 'tsuru bar'
    assert get_new_command(Command('foo bar',
                                  'error: "foo bar" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tbar\n\tfoo\n\tbaz\n')) == 'tsuru foo'

# Generated at 2022-06-22 02:35:38.701889
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info abcdef',
                         "tsuru: \"app-info\" is not a tsuru command. See \"tsuru help\".\n\n\nDid you mean?\n\tapp-info\n\tapp-log\n\tapp-remove\n\tapp-run\n\tapp-start",'abcdef'))
    assert not match(Command('tsuru -a app-info abcdef',
                         "tsuru: \"app-info\" is not a tsuru command. See \"tsuru help\".\n\n\nDid you mean?\n\tapp-info\n\tapp-log\n\tapp-remove\n\tapp-run\n\tapp-start",'abcdef'))

# Generated at 2022-06-22 02:35:49.185849
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    command = type('Command', (object,), {'output': ("tsuru: \"app-list\" is"
                                                     " not a tsuru command."
                                                     " See \"tsuru help\"."
                                                     "\nDid you mean?"
                                                     "\n\tapp-deploy"
                                                     "\n\tapp-info"
                                                     "\n\tapp-remove"
                                                     "\n\tapp-repository-add"
                                                     "\n\tapp-repository-remove"
                                                     "\n\tapp-run"
                                                     "\n\tapp-start")})

# Generated at 2022-06-22 02:36:01.345338
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create a b c', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".'))
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))
    assert match(Command('tsuru  foo', 'tsuru: "foo" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-create', 'no nodes available for app deployment'))
    assert not match(Command('tsuru app-info', 'no nodes available for app deployment'))

# Generated at 2022-06-22 02:36:11.636069
# Unit test for function match
def test_match():
    # tsuru command not found
    assert match(Command('tsuru hello', 'tsuru: "hello" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcreate-app\n\thelp\n\tlist-apps\n\tlogin\n\tlogout\n\tset-default-env\n\tset-env\n\tset-team-owner\n\tset-team-user\n\tshow-app'))
    # tsuru command found
    assert not match(Command('tsuru hello', 'tsuru: "hello" is a tsuru command.'))


# Generated at 2022-06-22 02:36:13.160437
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck import types
    command = types.Command('tsuru app-list ', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tlist-apps\n')
    assert get_new_command(command) == 'tsuru list-apps '



# Generated at 2022-06-22 02:36:18.318715
# Unit test for function get_new_command

# Generated at 2022-06-22 02:36:27.404621
# Unit test for function get_new_command
def test_get_new_command():
    # Simple case for command typo
    assert get_new_command(Command("tsuru aplication-remove", "tsuru: \"aplication-remove\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapplication-remove")) == "tsuru application-remove"

    # Multiple options case
    assert get_new_command(Command("tsuru app-info", "tsuru: \"app-info\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-create\n\tapp-list\n\tapp-remove")) == "tsuru [app-create|app-list|app-remove]"


# Generated at 2022-06-22 02:36:36.061783
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    assert get_new_command(Command('tsuru do-something',
                                   'tsuru: "do-something" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tssh')) == 'tsuru ssh'
    assert get_new_command(Command('tsuru do-something',
                                   'tsuru: "do-something" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tssh\n\tversion')) == 'tsuru ssh'

# Generated at 2022-06-22 02:36:37.662053
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsurud', '')) == ('tsurud', 'tsurud')

# Generated at 2022-06-22 02:36:40.792555
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output = 'tsuru: "appes" is not a tsuru command. See "tsuru help".\n\n'
    assert get_new_command(Command('tsuru appes', output)) == 'tsuru apps'