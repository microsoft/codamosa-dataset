

# Generated at 2022-06-24 07:18:10.256329
# Unit test for function match
def test_match():
    # A typical tsuru command when you get a suggestion
    broken_command = Command('tsuru ck',
                             "tsuru: \"ck\" is not a tsuru command. See "
                             "\"tsuru help\".\n\nDid you mean?\n\tcheck\n\tcluster-info")
    # A typical tsuru command when you don't get a suggestion
    wrong_command = Command('tsuru k',
                            "tsuru: \"k\" is not a tsuru command. See "
                            "\"tsuru help\".")
    assert match(broken_command)
    assert not match(wrong_command)


# Generated at 2022-06-24 07:18:15.276471
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-create test', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-list')) == 'tsuru app-create test'

# Generated at 2022-06-24 07:18:24.593291
# Unit test for function match
def test_match():
    # Failure message list
    fail_msg_no_cmd = "tsuru: “init” is not a tsuru command. See “tsuru help”."
    fail_msg_no_cmd_no_suggest = "tsuru: “init” is not a tsuru command. See “tsuru help”.\n"

# Generated at 2022-06-24 07:18:29.508635
# Unit test for function get_new_command
def test_get_new_command():
    output = "tsuru: \"foo\" is not a tsuru command. See \"tsuru help\".\
\n\nDid you mean?\n\tfoo\n\tfoobar"
    assert get_new_command(type('Cmd', (object,),
                               {'script': 'tsuru foo', 'output': output})) == 'tsuru foobar'

# Generated at 2022-06-24 07:18:34.249290
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    assert get_new_command(Command('tsuru push', "tsuru: \"push\" is not a tsuru command. See \"tsuru help\"." + "\n\nDid you mean?\n\tpush-unit\n")) == 'tsuru push-unit'

# Generated at 2022-06-24 07:18:42.739080
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    assert get_new_command(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-delete\n\tapp-info\n\tapp-remove')) == 'tsuru app-create'
    assert get_new_command(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-remove')) == 'tsuru app-create'

# Generated at 2022-06-24 07:18:45.648802
# Unit test for function get_new_command
def test_get_new_command():
    tsuru_command = 'tsuru: "hepl" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp\n'
    assert get_new_command(tsuru_command) == 'tsuru help'

# Generated at 2022-06-24 07:18:49.774959
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command({'output': 'tsuru: "tsur2u" is not a tsuru command. See "tsuru help".\nDid you mean?\ntsuru'}) == 'tsuru'

# Generated at 2022-06-24 07:18:53.225819
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru perm-app', output="""tsuru: "perm-app" is not a tsuru command.
See "tsuru help".

Did you mean?
	permission-app""")
    ) == 'tsuru permission-app'

# Generated at 2022-06-24 07:19:03.569926
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru applist', None, u"""tsuru: "applist" is not a tsuru command. See "tsuru help".

Did you mean?
        app-list
        app-info
        app-remove""", '')) == 'tsuru app-list'
    assert get_new_command(Command('tsuru app-info', None, u"""tsuru: "app-info" is not a tsuru command. See "tsuru help".

Did you mean?
        app-info""", '')) == 'tsuru app-info'

# Generated at 2022-06-24 07:19:10.569261
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-ls', 'tsuru: "app-ls" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n')
    assert get_new_command(command) == 'tsuru app-list'
    command = Command('tsuru deploy', 'tsuru: "deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-deploy\n')
    assert get_new_command(command) == 'tsuru app-deploy'

# Generated at 2022-06-24 07:19:15.369319
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru app-list',
                         stderr='tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list-units\n\tapp-log',
                         side_effect=None,
                         stdout='list of apps',
                         return_code=1))


# Generated at 2022-06-24 07:19:18.962439
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-tsuru app-list', 'tsuru: "app-tsuru" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', ''))


# Generated at 2022-06-24 07:19:23.232130
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsr', None, 'tsr: "tsr" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsuru')
    assert get_new_command(command) == 'tsuru'

# Generated at 2022-06-24 07:19:32.630328
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.main import Command
    assert get_new_command(Command('tsuru ps -a myapp', '')) == 'tsuru ps -a myapp'
    assert get_new_command(Command('tsuru ps myapp', '')) == 'tsuru ps -a myapp'
    assert get_new_command(Command('tsuru ps myapp', '')) == 'tsuru ps -a myapp'
    assert get_new_command(Command('tsuru ps -a myapp2', '')) == 'tsuru ps -a myapp2'
    assert get_new_command(Command('tsuru ps -a myapp2', '')) == 'tsuru ps -a myapp2'

# Generated at 2022-06-24 07:19:38.952900
# Unit test for function match
def test_match():
    assert match(Command('tsuru cli', 'tsuru: "cli" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tclient-add\n\tclient-remove\n')) == True
    assert match(Command('tsuru cli', 'tsuru: "cli" is not a tsuru command with exit code 1')) == False


# Generated at 2022-06-24 07:19:43.554707
# Unit test for function get_new_command
def test_get_new_command():
    output = r'''tsuru: "api" is not a tsuru command. See "tsuru help".

Did you mean?
	app-run              runs a command in an app
	logout               removes tsuru from current command line
'''
    assert get_new_command(Command('tsuru api', output, None)) == 'tsuru app-run' or get_new_command(Command('tsuru api', output, None)) == 'tsuru logout'

# Generated at 2022-06-24 07:19:53.889450
# Unit test for function get_new_command

# Generated at 2022-06-24 07:20:04.143303
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-bind xxx teste',
                         'tsuru: "service-bind" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tservice-add',
                         ))
    assert match(Command('tsuru service-bind xxx teste',
                         'tsuru: "service-bindd" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tservice-add\n\tservice-bind',
                         ))
    assert not match(Command('tsuru service-bind xxx teste',
                             'tsuru: "service-bind" is not a tsuru command. See "tsuru help".'))

# Generated at 2022-06-24 07:20:07.447687
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-add', 'tsuru: "app-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create')) == 'tsuru app-create'

# Generated at 2022-06-24 07:20:11.429289
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output='''tsuru: "target-add" is not a tsuru command. See "tsuru help".

Did you mean?
    target-set'''
    assert get_new_command(Command('target-add', output)) == 'tsuru target-set'

# Generated at 2022-06-24 07:20:21.520299
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'tsuru login',
                    'output': 'tsuru: "login" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tlog-in\n\tlogout',
                    '_script_parts': ['tsuru', 'login']})
    assert get_new_command(command) == 'tsuru log-in'

# Generated at 2022-06-24 07:20:25.861850
# Unit test for function match
def test_match():
    assert match(Command('', '', 'tsuru: "run" is not a tsuru command. See "tsuru help".\nDid you mean?\n\trun-unit\n\trun-hook'))

# Generated at 2022-06-24 07:20:32.025509
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    command = type('Command', (object,),
                   {'script': 'tsuru app-deploy',
                    'output': u'tsuru: "app-deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-end-deploy\n\tapp-start-deploy'})()
    assert get_new_command(command) == 'tsuru app-create'

# Generated at 2022-06-24 07:20:35.389260
# Unit test for function match
def test_match():
    command = Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list')
    assert match(command)
    not_matching_command = Command('tsuru anyone', 'tsuru: "anyone" is not a tsuru command. See "tsuru help".')
    assert not match(not_matching_command)


# Generated at 2022-06-24 07:20:42.170274
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-bind test'))
    assert match(Command('tsuru env-set FOO=BAR env=prod'))
    assert not match(Command('tsuru env-set FOO=BAR env=prod', 'tsuru env-set FOO=BAR env=prod\nDid you mean?\n\tenv-unset\n\tenv-set\n\t'))

# Generated at 2022-06-24 07:20:46.659765
# Unit test for function match
def test_match():
    output = '''tsuru: "plat" is not a tsuru command. See "tsuru help".

Did you mean?
	platform-add
	platform-list'''
    assert match(Command('tsuru plat', output))
    assert not match(Command('tsuru something', 'No command provided.'))

# Generated at 2022-06-24 07:20:50.052591
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsiru target-list', 'tsiru: "tsiru" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-list\n\n')) == 'tsuru target-list'

# Generated at 2022-06-24 07:20:55.902220
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create tomilisto', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create'))
    assert not match(Command('tsuru app-create tomilisto', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:21:00.446125
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('tsuru: "team-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tteam-create') == 'tsuru team-create'

# Generated at 2022-06-24 07:21:08.277412
# Unit test for function get_new_command
def test_get_new_command():
    output = ('tsuru: "install" is not a tsuru command. See "tsuru help".\n'
              '\n'
              'Did you mean?\n'
              '\tinfo\n'
              '\tinfo-app\n'
              '\tinfo-service\n'
              '\tinstall-app-repository\n'
              '\tinstall-service')
    command = Command('tsuru install -h', output)
    assert get_new_command(command) == 'tsuru install-app-repository -h'



# Generated at 2022-06-24 07:21:11.744883
# Unit test for function match
def test_match():
    assert match(Command('tsuru user-remove', 'ttt: "ttt" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tuser-remove'))
    assert not match(Command('tsuru user-remove', ''))


# Generated at 2022-06-24 07:21:15.621573
# Unit test for function match
def test_match():
     command = Command('tsuru app-add web epic-application',
                       'tsuru: "app-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-add\n\tapp-appl',
                       '', 0)
     assert match(command)



# Generated at 2022-06-24 07:21:19.046909
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command'))


# Generated at 2022-06-24 07:21:25.580224
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-info\n\tapp-list-units\n\tapp-update\n\tapp-users\n\tapps-list')) == 'tsuru apps-list'
    assert get_new_command(Command('tsuru permission-list', 'tsuru: "permission-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tpermission-add\n\tpermission-remove\n\tpermissions-list')) == 'tsuru permissions-list'

# Generated at 2022-06-24 07:21:32.304967
# Unit test for function get_new_command
def test_get_new_command():
    _test_cases = [
        ('tsuru: "mycmd" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tmy',
         {'corrected_stdout': 'tsuru my', 'corrected_cmd': 'tsuru my'},
         'Function get_new_command should replace command that is not a tsuru command',
         )
    ]

    def test_f(test_case):
        stdout = test_case[0]
        expected_output = test_case[1]
        assert get_new_command(Mock(output=stdout)) == expected_output

    for test_case in _test_cases:
        yield test_f, test_case

# Generated at 2022-06-24 07:21:35.449839
# Unit test for function match
def test_match():
    output = 'tsuru: "target-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-remove\n\ttarget-add\n'
    assert match(Command('tsuru target-list', output))


# Generated at 2022-06-24 07:21:39.612447
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('tsuru appssssssss',
        'tsuru: "appssssssss" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps\n')) == 'tsuru apps'

# Generated at 2022-06-24 07:21:46.000052
# Unit test for function match
def test_match():
    assert match(Command('tsuru app1',
                         'tsuru: "app1" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-delete\n\tapp-list\n\t'))
    assert not match(Command('tsuru app-create', ''))
    assert not match(Command('tsuru app-create', 'Error: some error'))


# Generated at 2022-06-24 07:21:51.401731
# Unit test for function get_new_command
def test_get_new_command():
    def assert_command(output, expected):
        assert get_new_command(Command('tsuru env-set', output)) == expected

    assert_command('tsuru: "tsure" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsuru\n\ttsuru env-set\n',
                   'tsuru env-set')

# Generated at 2022-06-24 07:21:55.881216
# Unit test for function get_new_command
def test_get_new_command():
    output = '''tsuru: "app-provision" is not a tsuru command. See "tsuru help".

Did you mean?
	app-create
'''
    command = Command('tsuru app-provision myapp', output)
    assert get_new_command(command) == 'tsuru app-create myapp'



# Generated at 2022-06-24 07:22:01.192096
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('tsurudm foo',
                                   'tsurudm: "foo" is not a tsuru command. See "tsuru help".'
                                   '\n\nDid you mean?\n\tdeploy-machine\n\tlist-machines')) == 'tsuru deploy-machine'

# Generated at 2022-06-24 07:22:10.456497
# Unit test for function match

# Generated at 2022-06-24 07:22:15.254476
# Unit test for function match
def test_match():
    assert match(Command('tsuru cd', 'tsuru: "cd" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcommand-list\n\texec\n\tremove-unit'))
    assert not match(Command('tsuru cd', ''))



# Generated at 2022-06-24 07:22:26.005245
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\n' \
             'Did you mean?\n\tapp-create\n\tapp-delete\n\tapp-info\n\tapp-list' \
             '\n\tapp-remove\n\tapp-restart\n\tapp-start\n\tapp-stop\n\t' \
             'app-update'
    assert get_all_matched_commands(output) == ['app-create', 'app-delete', 'app-info', 'app-list',
                                                'app-remove', 'app-restart', 'app-start', 'app-stop', 'app-update']

# Generated at 2022-06-24 07:22:30.623717
# Unit test for function match
def test_match():
    assert not match(Command('tsuru app-list', '', '', 123))
    assert match(Command('tsuru app-list', 'tsuru: "foo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n', '', 123))


# Generated at 2022-06-24 07:22:39.519288
# Unit test for function match
def test_match():
    assert match(Command('tsuruuapp-list', 'tsuru: "tsuruuapp-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\n'))
    assert match(Command('tsuru app-lsit', 'tsuru: "tsuru app-lsit" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\n'))
    assert not match(Command('tsuru app-list', 'tsuru: "tsuru app-list" is not a tsuru command. See "tsuru help".\n\n'))
    assert not match(Command('tsuru app-list', 'tsuruuapp-list'))

# Generated at 2022-06-24 07:22:44.386543
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('tsuru ps', 'tsuru: "ps" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps-list\n\tapps-plans\n\tplan-list\n\tservice-list\n\tservice-instance-list\n\troutes-list')

    assert get_new_command(command1) == ['tsuru apps-list']

# Generated at 2022-06-24 07:22:49.385459
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command('tsuru plataform-add ruby19',
                                   output='tsuru: "plataform-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-add')) == 'tsuru platform-add ruby19'

# Generated at 2022-06-24 07:22:53.868389
# Unit test for function match
def test_match():
    m = match('tsuru: "target-add" is not a tsuru command. See "tsuru help".\n'
              '\n'
              'Did you mean?\n'
              '\ttarget-add')
    assert m == True

    m = not match('tsuru: "target" is not a tsuru command. See "tsuru help".\n'
              '\n'
              'Did you mean?\n'
              '\ttarget-list')
    assert m == True


# Generated at 2022-06-24 07:23:01.301822
# Unit test for function get_new_command

# Generated at 2022-06-24 07:23:06.140578
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'tsuru app-log',
                    'output': 'tsuru: "app-log" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlog-app\n'
                    })

    assert get_new_command(command) == 'tsuru log-app'

# Generated at 2022-06-24 07:23:11.677203
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='tsuru app-list',
                      stderr='tsuru: "app-listt" is not a tsuru command.\nSee "tsuru help".\n\nDid you mean?\n\tapp-listt')
    new_command = get_new_command(command)
    assert new_command == 'tsuru app-list'



# Generated at 2022-06-24 07:23:17.750665
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    output = "tsuru: \"gett\" is not a tsuru command. See \"tsuru help\".\n" \
             "Did you mean?\n" \
             "\tget\n" \
             "\tset\n" \
             "\trestart\n" \
             "\tremove\n" \
             "\tadd-cname"

    assert get_new_command(Command('tsuru gett', output)) == 'tsuru get'

# Generated at 2022-06-24 07:23:22.932207
# Unit test for function match
def test_match():
    assert match(Command("tsuru plataform-add java", "tsuru: \"plataform-add\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tplatform-add\n"))
    assert not match(Command("tsuru doit", "tsuru: \"doit\" is not a tsuru command. See \"tsuru help\"."))

# Generated at 2022-06-24 07:23:24.870754
# Unit test for function match
def test_match():
    assert match(Command('tsuru help', 'tsuru: "help" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-help'))


# Generated at 2022-06-24 07:23:31.312758
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    assert get_new_command(Command('tsuru app-create test "test"', 'tsuru: "tsuru app-creat" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n')) == 'tsuru app-create test "test"'

# Generated at 2022-06-24 07:23:35.866067
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru app-list', stderr='tsuru: "app-list" is not a tsuru command',
        stdout='Did you mean?\n\tapps-list',))

    assert match(Command(script='tsuru app-list',
        stderr='tsuru: "app-list" is not a tsuru command\nDid you mean?\n\tapp-list',))


# Generated at 2022-06-24 07:23:39.430592
# Unit test for function match
def test_match():
    output = 'tsuru: "target-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add'
    assert match(Command('tsuru target-list', output))



# Generated at 2022-06-24 07:23:47.407168
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    must_match = lambda *a, **k: 'Did you mean?' in Command(*a, **k).output

    assert must_match('tsuru app-info abc')
    assert must_match('tsuru app-unbind-service -a omg')
    assert must_match('tsuru app-info -a omg')
    assert must_match('tsuru app-unbind -a omg')
    assert must_match('tsuru app-breath-command')
    assert must_match('tsuru app-breath')
    assert must_match('tsuru app-breathe --help')
    assert must_match('tsuru app-breathe')
    assert must_match('tsuru app-create -p xxx')

# Generated at 2022-06-24 07:23:54.837833
# Unit test for function match
def test_match():
    output1 =  "tsuru: \"lala\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tlogin\n\tlog"
    output2 = "tsuru: \"lala\" is not a tsuru command. See \"tsuru help\"."
    assert match(Command("some lala", output1)) == True
    assert match(Command("some lala", output2)) == False
    assert match(Command("some lala")) == False


# Generated at 2022-06-24 07:24:01.740341
# Unit test for function match
def test_match():
    assert not match(Command('tsuru target-add', ''))
    assert not match(Command('tsuru target-add', 'Did you mean?'))
    assert not match(Command('tsuru target-add', 'is not a tsuru command.'))
    assert match(Command('tsuru target-add', 'tsuru: "target-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-list\n\ttarget-remove\n\tservice-add\n\tservice-update\n\tservice-remove'))


# Generated at 2022-06-24 07:24:05.755906
# Unit test for function match
def test_match():
    assert match(Command('tsuru heip',
                         'tsuru: "heip" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\thelp'))
    assert not match(Command('tsuru heip', 'tsuru: "heip" is not a tsuru command. See "tsuru help".'))



# Generated at 2022-06-24 07:24:10.191380
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuruu', 'tsuru: "tsuruu" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsuru')
    assert get_new_command(command) == 'tsuru'



# Generated at 2022-06-24 07:24:18.008910
# Unit test for function match
def test_match():
    match1 = "succeeded\" tsuru: \"random is not a tsuru command. See \"tsuru help\"."
    match2 = "\"tsuru app-create\" is a deprecated alias for \"tsuru app-create-using-recipe\", which will not be available anymore in the next major release.\n\nIn most cases you can simply remove \"app-create\" from the command invocation.\n\nSee \"tsuru help\"."
    no_match1 = "tsuru: \"app-list\" is a deprecated command. See \"tsuru help\"."
    test1 = Command(script=match1, stderr=match1, output="")
    test2 = Command(script=match2, stderr=match2, output="")

# Generated at 2022-06-24 07:24:25.057033
# Unit test for function match
def test_match():
    test_cases = [Command('tsuru foo', 'tsuru: "foo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoo-bar\n\tfoo-bar2\n\tfoo-bar3'),
                  Command('tsuru foobar', 'tsuru: "foobar" is not a tsuru command. See "tsuru help".'),
                  Command('tsuru', "tsuru: you must provide at least one argument")]
    for test_case in test_cases:
        assert match(test_case)


# Generated at 2022-06-24 07:24:28.554053
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "target-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add\ntarget-remove'
    command = type("Command", (object,), {"output": output})
    with patch('thefuck.specific.tsuru.get_all_matched_commands', return_value=['target-add', 'target-remove']):
        assert get_new_command(command) == ["target-remove"]

# Generated at 2022-06-24 07:24:40.408761
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('tsuru targe-list teste',
                                    'tsuru: "targe-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-list'))
            == 'tsuru target-list teste')
    assert (get_new_command(Command('tsuru targe-list teste',
                                    'tsuru: "targe-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-list\n\ttarget-remove'))
            == 'tsuru target-list teste')

# Generated at 2022-06-24 07:24:48.978260
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "a" is not a tsuru command. See "tsuru help".\n Did you mean?\n\tapp\n\tapp-recreate\n\tapp-run'
    command = type('Command', (object, ), {'output': output})
    command.script = 'tsuru a'
    assert get_new_command(command) == 'tsuru app'
    output2 = 'tsuru: "a" is not a tsuru command. See "tsuru help".'
    command2 = type('Command', (object, ), {'output': output2})
    command2.script = 'tsuru a'
    assert get_new_command(command2) == 'tsuru a'

# Generated at 2022-06-24 07:24:51.389804
# Unit test for function match
def test_match():
    match('tsuru: "log-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-list')


# Generated at 2022-06-24 07:24:55.224277
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('command', 'tsuru: "test-command" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tlist-apps\n\tversion')
    assert get_new_command(command) == 'tsuru list-apps'

# Generated at 2022-06-24 07:25:00.989728
# Unit test for function get_new_command
def test_get_new_command():
    broken_cmd = 'tsuru app-create'
    output = """tsuru: "app-create" is not a tsuru command. See "tsuru help".

Did you mean?
        app-add-unit"""
    command = type('Command', (object, ), {'script': broken_cmd, 'output': output})
    assert get_new_command(command) == 'tsuru app-add-unit'

# Generated at 2022-06-24 07:25:04.350668
# Unit test for function get_new_command
def test_get_new_command():
    sample_output = """tsuru: "pst" is not a tsuru command. See "tsuru help".

Did you mean?
	ps
	target-list
"""
    assert get_new_command(Command('tsuru pst', sample_output)) == 'tsuru ps'

# Generated at 2022-06-24 07:25:08.198569
# Unit test for function match
def test_match():
    assert match(Command('tsuru app', 'tsuru: "asssdasd" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp\n\tapps\n\ttarget-list\n\ttarget-remove\n'))
    assert not match(Command('tsuru app', 'tsuru: "not_found" is not a tsuru command'))


# Generated at 2022-06-24 07:25:09.384538
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsurur')) == 'tsuru'

# Generated at 2022-06-24 07:25:15.976955
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-list', 'tsuru: "target-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-info'))
    assert not match(Command('tsuru target-list', 'tsuru: "target-list" is not a tsuru subcommand. See "tsuru help".\n'))


# Generated at 2022-06-24 07:25:19.962793
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-bind test -a test', 'tsuru: "service-bind" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tbind-service\n'))



# Generated at 2022-06-24 07:25:23.649696
# Unit test for function match
def test_match():
    assert match(Command('tsuru help ',
                         'tsuru: "help" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t[no suggestions]\n\n'))
    assert not match(Command('tsuru help', 'you should use tsuru help'))


# Generated at 2022-06-24 07:25:32.795867
# Unit test for function get_new_command
def test_get_new_command():
    # Simple command replacement
    cmd = get_new_command(Command('tsuru app-list', ''))
    assert cmd == 'tsuru app-list'

    # Command that has the error output
    cmd = get_new_command(Command('tsuru app-content', 'tsuru: "app-content" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create'))
    assert cmd == 'tsuru app-create'

    # Command that  has the error output and some arguments
    cmd = get_new_command(Command('tsuru app-content -a myapp', 'tsuru: "app-content" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create'))

# Generated at 2022-06-24 07:25:39.585406
# Unit test for function match
def test_match():
    # RIGHT USAGE returns true
    output_1 = ("tsuru: \"myapp\" is not a tsuru command. See \"tsuru help\"\n"
                "Did you mean?\n\tmyapp-info")
    assert match(Command('tsuru myapp', output_1)) == True

    # WRONG USAGE returns false 
    output_2 = ("tsuru: \"ttt\" is not a tsuru command. See \"tsuru help\".\n")
    assert match(Command('tsuru ttt', output_2)) == False



# Generated at 2022-06-24 07:25:47.693459
# Unit test for function get_new_command
def test_get_new_command():
    def assert_command(cmd_str, expected):
        output = ("tsuru: \"{}\" is not a tsuru command. See \"tsuru help\"."
                  "\n\nDid you mean?\n\t{} version\n\t{}-{}".format(cmd_str,
                  cmd_str, cmd_str, cmd_str))
        assert get_new_command(Command(cmd_str, output)) == Command(expected, output)

    assert_command("mycmd", "mycmd version")
    assert_command("my-cmd", "my-cmd version")


# Generated at 2022-06-24 07:25:53.555774
# Unit test for function match
def test_match():
	assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-set\n\tapp-unset\n\trun'))
	assert match(Command('tsuruu app-list', 'tsuruu: "app-list" is not a tsuru command. See "tsuruu help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-set\n\tapp-unset\n\trun'))
	assert not match(Command('foolist', ''))
	assert not match(Command('tsuru app-list', ''))

# Generated at 2022-06-24 07:25:57.371394
# Unit test for function get_new_command
def test_get_new_command():
    command = type("command", (object,), {
                "output": 'tsuru: "team-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tteam-create\n'})
    assert get_new_command(command) == 'tsuru team-create'

# Generated at 2022-06-24 07:26:03.561463
# Unit test for function match
def test_match():
    # If broken_cmd not in command.output, return False
    assert not match(Mock(output='', script=''))

    # If 'Did you mean?' not in command.output, return False
    assert not match(Mock(output='tsuru: "app-create" is not a tsuru command', script=''))

    # If 'Did you mean?' in command.output, return True
    assert match(Mock(output='tsuru: "app-create"  is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create', script=''))



# Generated at 2022-06-24 07:26:05.946914
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "appl" is not a tsuru command. See "tsuru help".\n'+\
             '\nDid you mean?\n\tapp-list'
    command = 'tsuru appl'
    assert(get_new_command(type('obj', (object,),
                          {'output': output})) == ['tsuru app-list'])

# Generated at 2022-06-24 07:26:10.419581
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command, match
    command = type('Command', (object,),
                   {'script': 'tsuru sfasfasfdsaf',
                    'output': 'tsuru: "sfasfasfdsaf" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice-add'})
    assert match(command) 
    assert get_new_command(command) == 'tsuru service-add'

# Generated at 2022-06-24 07:26:16.036940
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output = "tsuru: \"targets-add\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tadd-permission\n\tadd-unit\n\tapp-run\n\tapp-start\n\tapp-stop"

    assert get_new_command(Command('targets-add',output)) == "tsuru add-permission"

# Generated at 2022-06-24 07:26:20.078419
# Unit test for function match
def test_match():
    assert match(Command('user-create', 'Possible completions:\n  app-create  app-remove  app-run'))
    assert not match(Command('tsuru', ''))


# Generated at 2022-06-24 07:26:26.601324
# Unit test for function match
def test_match():
  # Correct examples
  assert match(Command('tsuru app-list 2>&1',
                       'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-delete\n\tapp-info\n\tapp-rebuild\n\tapp-remove\n\tapp-run'))

  # Incorrect examples
  assert not match(Command('tsuru app-list 2>&1', ''))
  assert not match(Command('ls 2>&1', ''))



# Generated at 2022-06-24 07:26:29.182966
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "foo" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tbar\n\tfoo\n'
    command = type('Command', (object,), {'script': 'tsuru foo', 'output': output})
    assert get_new_command(command) == 'tsuru bar'
    assert get_new_command(command) == 'tsuru foo'

# Generated at 2022-06-24 07:26:34.745122
# Unit test for function match
def test_match():
    assert match(Command('tsuru forgot-credentials bla bla bla',
            "tsuru: \"forgot-credentials\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tforget-credentials"))


# Generated at 2022-06-24 07:26:43.621180
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru target', '')) == 'tsuru target-list'
    assert get_new_command(Command('tsuru app-remove', '')) == 'tsuru app-remove'
    assert get_new_command(Command('tsuru target-add', '')) == 'tsuru target-add'

    output = '''tsuru: "target-aws" is not a tsuru command. See "tsuru help".

Did you mean?
	target-add
	target-remove
	target-set
	target-list

	'''
    assert get_new_command(Command('tsuru target-aws', output)) == 'tsuru target-add'


# Generated at 2022-06-24 07:26:46.120245
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('tsuru app-create test') == 'tsuru app-create test'

# Generated at 2022-06-24 07:26:50.825608
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list'))
    assert not match(Command('tsuru app-info'))
    assert match(Command('tsuru app-create'))
    assert not match(Command('tsuru app-create django'))
    assert not match(Command('ls'))
    assert not match(Command('echo a'))


# Generated at 2022-06-24 07:26:53.699902
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-ihsutewa',
    'tsuru: "app-ihshuetewa" is not a tsuru command. See "tsuru help".\
     \n\nDid you mean?\n\tapp-instance-list\n\tapp-list\n\tapp-info',
     ''))


# Generated at 2022-06-24 07:26:59.612671
# Unit test for function get_new_command
def test_get_new_command():
    stdout = """tsuru: "app-log" is not a tsuru command. See "tsuru help".

Did you mean?
	app-deploy
	app-logs"""
    command = Command('', stdout)
    assert get_new_command(command) == 'tsuru app-logs'


enabled_by_default = True

# Generated at 2022-06-24 07:27:08.566847
# Unit test for function get_new_command
def test_get_new_command():
    from tests.shells import MockShell

    shell = MockShell()

# Generated at 2022-06-24 07:27:09.634088
# Unit test for function get_new_command

# Generated at 2022-06-24 07:27:15.322212
# Unit test for function get_new_command
def test_get_new_command():
    output = "ERROR: tsuru: \"run\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\trun-container"
    command = MagicMock()
    command.output = output
    command.script = "tsuru run"
    assert get_new_command(command) == "tsuru run-container"

# Generated at 2022-06-24 07:27:18.878508
# Unit test for function match
def test_match():
    assert match(Command('tsuru docker-bind', 'tsuru: "docker-bind" is not a tsuru command. See "tsuru help".\n\nDid you mean?\ntsuru docker-bind'))


# Generated at 2022-06-24 07:27:27.427421
# Unit test for function match
def test_match():
    assert match(CliMock('tsuru app-add', output='\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-info\n\tapp-list\tapp-grant\n\tapp-revoke\n\tapp-restart\n\tapp-start\tapp-stop\n\tapp-deploy\n\tapp-log\tapp-run\n\tapp-plan-change\n\tapp-remove-unit\tapp-set\n\tapp-swap\tapp-unit-add\n\tsuru app-add: "app-add" is not a tsuru command. See "tsuru help".\n')) == True
    assert match(CliMock('tsuru app-remove')) == False


#

# Generated at 2022-06-24 07:27:33.561127
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-create blabla', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create', '')) == 'tsuru app-create blabla'
    assert get_new_command(Command('tsuru app-create blabla', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-remove\n\tapp-info', '')) == 'tsuru app-remove blabla'

# Generated at 2022-06-24 07:27:40.074417
# Unit test for function match
def test_match():
    border = '\n'
    assert match(Command('tsuru app-files "/tmp" -a madoo', border +
            'tsuru: "app-files" is not a tsuru command. See "tsuru help".' +
            border +
            'Did you mean?' +
            border +
            '\tapp-create' +
            border +
            '\tapp-deploy' +
            border))



# Generated at 2022-06-24 07:27:42.360083
# Unit test for function get_new_command
def test_get_new_command():
    output = "tsuru: \"heroku\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tapps\n\tinfo\n\testablish-session\n\tversion"
    command = Command('tsuru heroku', output)
    assert get_new_command(command) == 'tsuru apps'

# Generated at 2022-06-24 07:27:46.729596
# Unit test for function match
def test_match():
    command = Command('tsuru app-list', "Sorry, \"app-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-list\n\tapp-create\n\tapp-remove")
    assert match(command)


# Generated at 2022-06-24 07:27:51.322224
# Unit test for function match
def test_match():
    assert match(Command('tsuru permision-app something',
                              'tsuru: "permision-app" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tpermission-app'))



# Generated at 2022-06-24 07:27:54.728122
# Unit test for function match
def test_match():
    assert match(Command('tsuru cred-add', output='tsuru: "cred-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcredential-add'))
    assert not match(Command('tsuru cred-add', output='tsuru: "cred-add" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('ls', '', ''))


# Generated at 2022-06-24 07:27:58.836618
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('tsuru permission', '''tsuru: "permission" is not a tsuru command. See "tsuru help".

Did you mean?
        permission-create
        permission-remove
        permission-set
''')) == 'tsuru permission-create'

# Generated at 2022-06-24 07:28:07.021145
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    from thefuck.types import Command

    assert get_new_command(Command('tsuru app-create',
                                   'tsuru: "app-create" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create', 0, 'tsuru app-create')) == 'tsuru app-create'
    assert get_new_command(Command('tsuru',
                                   'tsuru: "" is not a tsuru command. See "tsuru help".\nDid you mean?\n\t', 0, 'tsuru')) == 'tsuru'