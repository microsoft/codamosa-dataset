

# Generated at 2022-06-24 07:18:05.555305
# Unit test for function match
def test_match():
    assert match(Command('tsuru hello', 'tsuru: "hello" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps\n\tbootstrap\n\tcreate-app\n\tpermission'))


# Generated at 2022-06-24 07:18:13.509445
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-add',
                         Output(u"tsuru: \"app-add\" is not a tsuru command. See \"tsuru help\"."
                                u"\n\nDid you mean?\n\tapp-create\n\tadd-key")))\
        is True
    assert match(Command('tsuru app-add', Output(u"tsuru: \"app-add\" is not a tsuru command. See \"tsuru help\"."))) is False
    assert match(Command('tsuru app-add', Output(u"tsuru: \"app-add\" is not a tsuru command. See \"tsuru help\"."
                                                 u"\n\nDid you mean?\n\tapp-create\n\tadd-key"))) is True

# Generated at 2022-06-24 07:18:17.938497
# Unit test for function match
def test_match():
    assert match(Command('tsuru bad','tsuru: "bad" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tbackward-compatibility\n\tbackward-compatibility-remover\n\tbuild-info',123))



# Generated at 2022-06-24 07:18:23.002978
# Unit test for function match
def test_match():
    # Terminal output when first input is wrong
    output = """tsuru: "tsur abc" is not a tsuru command. See "tsuru help".

Did you mean?
	tsuru app-run"""
    command = Command('tsur abc', output)

    assert match(command)
    assert get_new_command(command) == 'tsuru app-run'



# Generated at 2022-06-24 07:18:27.931033
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru hello',
                                   'tsuru: "hello" is not a tsuru command. See "tsuru help".\nDid you mean?\n\thelp')) == 'tsuru help'

# Generated at 2022-06-24 07:18:32.509198
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru u', 'tsuru: "u" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tuser-change-password')) == 'tsuru user-change-password'

enabled_by_default = True
priority = 1000

rule = get_new_command

# Generated at 2022-06-24 07:18:34.814234
# Unit test for function match
def test_match():
    command = Command("tsuru app-silly-create 'fake.domain.com'")
    assert(match(command))



# Generated at 2022-06-24 07:18:43.730779
# Unit test for function match
def test_match():
    output = 'tsuru: "give" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tgive user-info access to a team\n\tdelete a team\n\tadd an app to a team\n\tremove an app from a team\n\tlist teams\n\tcreate a team\n'
    assert match(Command('tsuru give user-info access to a team --user some_user --team some_team', output))

# Generated at 2022-06-24 07:18:50.368544
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru p', 'tsuru: "p" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tpermission-add')).script == 'tsuru permission-add'
    assert get_new_command(Command('tsuru permisson-add', 'tsuru: "permisson-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tpermission-add')).script == 'tsuru permission-add'
    assert get_new_command(Command('tsuru remove-user-permission', 'tsuru: "remove-user-permission" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tpermission-remove\n\tuser-remove')).script

# Generated at 2022-06-24 07:18:52.395062
# Unit test for function match
def test_match():
    assert match("tsuru: \"app-remove\" is not a tsuru command. See \"tsuru help\".")


# Generated at 2022-06-24 07:18:56.482406
# Unit test for function get_new_command

# Generated at 2022-06-24 07:19:01.018165
# Unit test for function match
def test_match():
    output = ('tsuru: "api" is not a tsuru command. See "tsuru help".\n\n'
              'Did you mean?\n\tapi-doc')
    command = Command('tsuru api', output)

    assert match(command)



# Generated at 2022-06-24 07:19:03.055858
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'Did you mean?\n\tapp-create'))


# Generated at 2022-06-24 07:19:09.262728
# Unit test for function match
def test_match():
    assert match(Command('tsuru client-list',
                  'tsuru: "client-list" is not a tsuru command. See "tsuru help".\n'
                  'tsuru: Did you mean?\n'
                  '\tclient-remove\n'
                  '\tclient-register\n'
                  '\tclient-list\n'
                  '\tclient-update',
                  ''))
    assert not match(Command('tsuru client-list', 'something', ''))

# Generated at 2022-06-24 07:19:12.238785
# Unit test for function match
def test_match():
    assert match(Command('tsuru help',
                         'tsuru: "help" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tversion'))



# Generated at 2022-06-24 07:19:15.938409
# Unit test for function get_new_command
def test_get_new_command():
    command = type('command', (object,), {'script': 'tsuru cmd',
                                   'output': 'tsuru: "cmd" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tclient'})
    assert get_new_command(command) == 'tsuru client'

# Generated at 2022-06-24 07:19:20.569648
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru ' \
                                        'command. See "tsuru help".\nDid ' \
                                        'you mean?\n\tapp-create\n\tapp-remove\n\tapp-grant')
    assert get_new_command(command) == 'tsuru app-create'



# Generated at 2022-06-24 07:19:31.864838
# Unit test for function get_new_command
def test_get_new_command():
    output_1 = 'tsuru: "login" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlog\n'
    cmd_1 = Command('tsuru login', output_1)
    assert get_new_command(cmd_1) == 'tsuru log'

    output_2 = 'tsuru: "log" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlogin\tlong-running-process-add\n'
    cmd_2 = Command('tsuru log', output_2)
    assert get_new_command(cmd_2) == 'tsuru long-running-process-add'


# Generated at 2022-06-24 07:19:43.222244
# Unit test for function match

# Generated at 2022-06-24 07:19:52.460935
# Unit test for function match
def test_match():
    assert (match(Command('tru'))
            == ('tru' in 'tsuru: "tru" is not a tsuru command. '
                'See "tsuru help".\n\nDid you mean?\n\ttarget'))
    assert (match(Command('tsuru t'))
            == ('t' in 'tsuru t: "t" is not a tsuru command. '
                'See "tsuru help".\n\nDid you mean?\n\ttarget'))
    assert match(Command('tsuru abc target')) is False
    assert match(Command('tsuru')) is False
    assert match(Command('tsuru target')) is False



# Generated at 2022-06-24 07:19:56.177983
# Unit test for function get_new_command
def test_get_new_command():
    command_output = 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n\tapp-create\n\tapp-remove'
    command = type('Command', (object,), {'script': 'tsuru app-info',
                                          'output': command_output})

    assert get_new_command(command) == 'tsuru app-info'

# Generated at 2022-06-24 07:19:59.123305
# Unit test for function match
def test_match():
    assert match(Command('tsuru node-remove', 'tsuru: "node-remove" is not a tsuru command. See "tsuru help". \n\nDid you mean?\n\tnode-container-remove\n\tnode-update'))


# Generated at 2022-06-24 07:20:05.494268
# Unit test for function match
def test_match():
    command = Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tverify\n\tversions\n\tversion-set\n\n')
    assert(match(command)) is True
    command = Command('tsuru help', '')
    assert(match(command)) is False


# Generated at 2022-06-24 07:20:12.692648
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(
        Command('tsuru ap-crerate')) == 'tsuru app-create')
    assert(get_new_command(
        Command('tsuru app-crerate')) == 'tsuru app-create')
    assert(get_new_command(
        Command('tsuru app-create')) == 'tsuru app-create')
    assert(get_new_command(
        Command('tsuru servic-deletedb')) == 'tsuru service-delete-db')
    assert(get_new_command(
        Command('tsuru servic-dletedb')) == 'tsuru service-delete-db')
    assert(get_new_command(
        Command('tsuru servic-deletedb')) == 'tsuru service-delete-db')

# Generated at 2022-06-24 07:20:17.372029
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('tsuru: "service-repository-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice-instance-add') == 'service-instance-add'

# Generated at 2022-06-24 07:20:21.447039
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru target-add http://my.server.tsuru.com', 'tsuru: "target-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-add\n\ttarget-set')
    assert get_new_command(command) == 'tsuru target-add http://my.server.tsuru.com'

# Generated at 2022-06-24 07:20:28.191695
# Unit test for function match
def test_match():
    assert match(Command('tsuru env-set a=a b=b c=c d=d',
                'tsuru: "env-set" is not a tsuru command. See "tsuru help".\n\n'
                'Did you mean?\n\t'
                'env-set-unit\n\t'
                'env-unset\n\t'
                'env-get\n\t'
                'env-unset-unit'))


# Generated at 2022-06-24 07:20:34.870600
# Unit test for function get_new_command
def test_get_new_command():
    import mock
    output = ("tsuru: \"create\" is not a tsuru command. See \"tsuru help\" \
               \nDid you mean?\n\tadd-unit\n\tremove-unit\n\t\
               app-remove\n\tapp-restart\n\tapp-start\n\tapp-stop\n")

    with mock.patch('thefuck.rules.tsuru_command_not_found.replace_command',
                    return_value="tsuru app-remove my-app"):
        assert get_new_command(
            mock.Mock(output=output, script='tsuru create my-app'))

# Generated at 2022-06-24 07:20:40.736437
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru test',
                         stderr='tsuru: "test" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tteam-add\n\tteam-remove\n\tteam-user-add\n\tteam-user-remove'))


# Generated at 2022-06-24 07:20:45.596642
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-list', '', 'tsuru: "target-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add\n\ttarget-remove'))
    assert not match(Command('tsuru target-list', '', 'tsuru: "target-list" is not a tsuru command. See "tsuru help.'))


# Generated at 2022-06-24 07:20:51.266162
# Unit test for function match
def test_match():
    match_output = "tsuru: \"app-add\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-rename\n\tapp-run"
    not_match_output = "No apps available.\n"

    assert match(Command('tsuru app-add', match_output))
    assert not match(Command('tsuru app-list', not_match_output))


# Generated at 2022-06-24 07:20:58.031231
# Unit test for function match
def test_match():
    assert match(Command('tsuru do notexist', 'tsuru: "do" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-add\tapp-remove\thelp\tpermission-add\trun-command\tservice-add\tservice-bind\tservice-doc\tservice-info\tservice-unbind\tservice-update\tuser-create\tuser-remove'))
    assert not match(Command('tsuru app-create', ''))

# Generated at 2022-06-24 07:21:07.158426
# Unit test for function match
def test_match():
    assert match(Command('tsuruuuuu', 'tsuru: "tsuruuuuu" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttsuru', '', 1))
    assert match(Command('tsuru app-create', 'tsuru: "tsuru app-create" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttsuru app-create\n\ttsuru app-delete', '', 1))
    assert not match(Command('tsuru', 'tsuru: "tsuru" is not a tsuru command. See "tsuru help".', '', 1))

# Generated at 2022-06-24 07:21:13.938371
# Unit test for function match
def test_match():
    output_true = 'tsuru: "tsuruuuuuuu" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tdeploy\n\tenv-set\n\thelp\n'
    output_false = 'tsuru: "tsuruuuuuuu" is not a tsuru command. See "tsuru help".'
    command_true = type('Command', (object,), {'output': output_true})
    command_false = type('Command', (object,), {'output': output_false})
    assert match(command_true)
    assert not match(command_false)


# Generated at 2022-06-24 07:21:19.359382
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'tsuru service-add postgres mongodb',
                    'output': ('tsuru: "service-add" is not a tsuru command. '
                               'See "tsuru help".\n\nDid you mean?\n\t'
                               'service-bind\n\tservice-doc\n\tservice-info'),
                    'stderr': '',
                    'stdout': ''})
    assert get_new_command(command) == 'tsuru service-bind postgres mongodb'


# Generated at 2022-06-24 07:21:26.004501
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck import shells

# Generated at 2022-06-24 07:21:34.445811
# Unit test for function match
def test_match():
    broken_cmd_with_suggestions_output = '''tsuru: "app-run-command" is not a tsuru command. See "tsuru help".

Did you mean?
	app-create
	app-info
	app-list'''

    broken_cmd_wo_suggestions_output = '''tsuru: "app-run-command" is not a tsuru command. See "tsuru help".'''

    assert match(Command('tsuru app-run-command help', broken_cmd_with_suggestions_output))
    assert match(Command('tsuru app-run-command help', broken_cmd_wo_suggestions_output)) is not True
    assert match(Command('tsuru app-run-command help', ' ')) is not True


# Generated at 2022-06-24 07:21:43.142457
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('First broken command',
                      """First broken command
tsuru: "First" is not a tsuru command. See "tsuru help".

Did you mean?
        second command
        third command

""")
    output = "tsuru second-command"
    assert get_new_command(command) == output

    command = Command('Third broken command',
                      """Third broken command
tsuru: "Third" is not a tsuru command. See "tsuru help".

Did you mean?
        second command
        third command

""")
    output = "tsuru third-command"
    assert get_new_command(command) == output


# Generated at 2022-06-24 07:21:45.962803
# Unit test for function match
def test_match():
    # True
    assert match(Command('tsuru env-set e hello', 'tsuru: "env-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tenv-get'))
    # False
    assert not match(Command('tsuru env-get e hello', ''))

# Generated at 2022-06-24 07:21:52.216722
# Unit test for function get_new_command
def test_get_new_command():
    broken_command = Command('tsuru app-info asdf',
                             'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info  (app-info)\n\tapp-list  (app-list)')
    assert get_new_command(broken_command) == 'tsuru app-info'


enabled_by_default = True

# Generated at 2022-06-24 07:21:53.301683
# Unit test for function match
def test_match():
    # assert match(Command('tsuru service-doc bleh', ''))
    assert not match(Command('tsuru service-doc', ''))


# Generated at 2022-06-24 07:22:02.024732
# Unit test for function match
def test_match():
	# Match
	assert match(Command('tsuru app-info', '', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n'
		'\nDid you mean?\n\tapp-info\n\tapp-list\n\tapp-remove\n\tapp-restart\n\tapp-run\n'))
	# No Match
	assert not match(Command('tsuru app-info', ''))
	assert not match(Command('tsuru app-info', '', 'tsuru: "app-info" is a tsuru command. See "tsuru help".\n'))


# Generated at 2022-06-24 07:22:11.108234
# Unit test for function match
def test_match():
    assert match(Command('tsuru ap u', 
        'tsuru: "ap" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp\n'))
    assert match(Command('tsuru app-deploy u', 
        'tsuru: "app-deploy" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-deploy-list\n'))
    assert match(Command('tsur app-deploy-list u', 
        'tsur: "app-deploy-list" is not a tsuru command. See "tsur help".\nDid you mean?\n\tapp-deploy\n'))
    assert not match(Command('tsur app-user-add u', ''))

# Unit

# Generated at 2022-06-24 07:22:15.723557
# Unit test for function get_new_command
def test_get_new_command():
    assert 'tsuru role-remove manager user' == get_new_command(Command('tsuru role-remove manager  user', 'tsuru: "role-remove" is not a tsuru command. See "tsuru help".\nDid you mean?\n\trole-add', 'tsuru role-add manager user'))

# Generated at 2022-06-24 07:22:26.196768
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list\n\t', ''))
    assert match(Command('tsuru app-lis', 'tsuru: "app-lis" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list\n\t', ''))
    assert match(Command('tru app-lis', 'tru: "app-lis" is not a tsuru command. See "tru help".\nDid you mean?\n\tapp-list\n\t', ''))

# Generated at 2022-06-24 07:22:35.836676
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    command1 = Command("tsuru env-set APP_ENV=production", "tsuru: \"env-set\" is not a tsuru command. See \"tsuru help\".", "")
    command2 = Command("tsuru env-set APP_ENV=production", "tsuru: \"env-set\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\thedset\n\thev-get\n\thev-unset", "")
    assert get_new_command(command1) == "tsuru env-set APP_ENV=production"
    assert get_new_command(command2) == "tsuru hev-get APP_ENV=production"

# Generated at 2022-06-24 07:22:43.378731
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    command = type('Command', (object,),
                   {'script': 'tsu wrong-command',
                    'output': 'tsuru: "wrong-command" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tbigbro:info\n\tsystem-info\n\tunit-add\n\tunit-remove'})
    # The new command is the first of the suggestions
    assert get_new_command(command) == 'tsu bigbro:info'

# Generated at 2022-06-24 07:22:47.680418
# Unit test for function get_new_command
def test_get_new_command():
    output = "tsuru: \"target-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\ttarget-add\n\ttarget-remove"
    assert get_new_command(Command('target-list', output=output)) == 'tsuru target-add'

# Generated at 2022-06-24 07:22:51.171208
# Unit test for function match
def test_match():
    result = match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".'))

    assert result



# Generated at 2022-06-24 07:22:55.145182
# Unit test for function match
def test_match():
    assert match(Command('command tsuru --help', 'tsuru: "--help" is not a tsuru command. See "tsuru help".\nDid you mean?\n\thelp\n')) is True
    assert match(Command('command tsuru --help', 'tsuru: "command" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tendpoint-list\n')) is False


# Generated at 2022-06-24 07:22:57.449769
# Unit test for function match
def test_match():
    assert match(Command(script='tsuruu'))
    assert not match(Command(script='tsurur'))

# Generated at 2022-06-24 07:23:08.557758
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command('tsuru status', 'tsuru: "status" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tstatus-app')) == 'tsuru status-app'
    assert get_new_command(Command('tsuru status-app', 'tsuru: "status-app" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tstatus')) == 'tsuru status'
    assert get_new_command(Command('tsuruu status', 'tsuru: "tsuruu" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tstatus')) == 'tsuru status'

# Generated at 2022-06-24 07:23:16.453577
# Unit test for function match
def test_match():
    command_output_1 = "tsuru: /home/tsuru is not a tsuru command. See 'tsuru help'."
    command_output_2 = '/home/tsuru: tsuru is not a tsuru command. See "tsuru help".\nDid you mean?\n\t\n'

    assert match(Command('tsuru /home/tsuru', command_output_1))
    assert match(Command('tsuru /home/tsuru', command_output_2))
    assert not match(Command('tsuru', ''))

# Generated at 2022-06-24 07:23:24.354730
# Unit test for function match
def test_match():
    assert (match(Command('tsurur help', 'tsuru: "help" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp-app'))
            is True)
    assert (match(Command('tsurur help app', 'tsuru: "help" is not a tsuru command. See "tsuru help".'))
            is True)
    assert (match(Command('tsurur help', 'tsuru: "help" is not a tsuru command. See "tsuru help".'))
            is False)

# Generated at 2022-06-24 07:23:29.842349
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("tsuru app-lis",
                      output = "tsuru: \"app-lis\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-list\n\tapp-log")
    assert get_new_command(command) == "tsuru app-list"

# Generated at 2022-06-24 07:23:35.837209
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('tsuru app-info TheHive',
                  "tsuru: \"app-info\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-cancel-remove\n\tapp-create\n\tapp-change-platform\n\tapp-deploy\n\tapp-info\n\tapp-list-units\n\tapp-grant\n\tapp-log")
    assert get_new_command(cmd) == 'tsuru app-info TheHive'

# Generated at 2022-06-24 07:23:42.120165
# Unit test for function get_new_command
def test_get_new_command():
    assert('tsuru help' == get_new_command(FakeCommand('''tsuru command
tsuru: "command" is not a tsuru command. See "tsuru help".

Did you mean?
        tsuru help
''')))
    assert('tsuru target-list' == get_new_command(FakeCommand('''tsuru target
tsuru: "target" is not a tsuru command. See "tsuru help".

Did you mean?
        tsuru target-list
''')))

# Generated at 2022-06-24 07:23:46.989164
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru env-set -a myapp env1=env2', 'tsuru: "env-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tenv-set\n')
    assert get_new_command(command) == 'tsuru env-set --app myapp env1=env2'

# Generated at 2022-06-24 07:23:54.441590
# Unit test for function get_new_command
def test_get_new_command():
    broken_cmd = "tsuru: \"cleanup\" is not a tsuru command. See \"tsuru help\"."
    possible_cmds = "\nDid you mean?\n\tcleanup-units\n\tcleanup-apps\n"
    command = simplejson.dumps({"output": broken_cmd + possible_cmds})
    command = simplejson.loads(command)
    new_cmd = get_new_command(command)
    assert new_cmd == "tsuru cleanup-units"

# Generated at 2022-06-24 07:23:59.178285
# Unit test for function match
def test_match():
    assert match(Command('tsuru plataform-add dindin', ''))
    assert match(Command('tsuru plataform-add dindin', '', ''))
    assert not match(Command('tsuru platform-add dindin', ''))
    assert not match(Command('tsuru plataform-add dindin', '', ''))


# Generated at 2022-06-24 07:24:05.660457
# Unit test for function match
def test_match():
    assert match(
        Command('tsuru app-addsl-remove web', output='tsuru: "app-addsl-remove" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-add-ssl\n\tapp-remove\n'))
    assert not match(
        Command('tsuru app-addsl-remove web', output='tsuru: "app-addsl-remove" is not a tsuru command. See "tsuru help".'))
    assert not match(
        Command('tsuru app-addsl-remove web', output='tsuru: "app-addsl-remove" is not a tsuru command'))


# Generated at 2022-06-24 07:24:11.795568
# Unit test for function match
def test_match():
    # Validate the match if it's enabled
    enabled = match(Command('tsuru login', 'tsuru: "login" is not a tsuru command. See tsuru help.', ''))
    assert enabled

    # Validate the match if it's disabled
    disabled = match(Command('git commit', 'tsuru: "commit" is not a git command. See git help.', ''))
    assert not disabled


# Generated at 2022-06-24 07:24:15.624426
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command('tsuru users-create',
                                   'tsuru: "users-create" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tuser-create\n\n')) == 'tsuru user-create'

enabled_by_default = True

# Generated at 2022-06-24 07:24:25.872760
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'tsuru a',
                    'output': """tsuru: "a" is not a tsuru command. See "tsuru help".
Did you mean?
bt     account     app-info      app-log           app-remove          app-restart           app-run
tn     app-start       app-stop        authorize           app-grant      app-info-set           app-remove-unit
td     app-unit-add      app-unit-remove
		"""}) # noqa

    assert get_new_command(command) == 'tsuru app-info'


# Generated at 2022-06-24 07:24:30.521085
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-remove aa', 'tsuru: "app-remove" is not a tsuru command.'
                      'See "tsuru help".\n\nDid you mean?\n\tapp-remove\n')
    assert get_new_command(command) == ('tsuru app-remove aa', 'tsuru app-remove aa')

    command = Command('tsuru mycommand', 'tsuru: "mycommand" is not a tsuru command.'
                      'See "tsuru help".\n\nDid you mean?\n\tapp-remove\n\tmy-command\n')
    assert get_new_command(command) == ('tsuru mycommand', 'tsuru app-remove') or \
        get_new_command(command) == ('tsuru mycommand', 'tsuru my-command')

# Generated at 2022-06-24 07:24:33.426092
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-remove', '')) == 'tsuru app-remove'


# Generated at 2022-06-24 07:24:42.067951
# Unit test for function match
def test_match():
    # Test match function
    output_match = 'tsuru: "bleh" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tadd-key\n\tapp-create\n\tapp-list\n\tapp-remove\n\tapp-info'
    output_nomatch = 'nothing'

    command_match = Command(script="tsuru bleh", output=output_match)
    command_nomatch = Command(script="tsuru bleh", output=output_nomatch)

    assert match(command_match) == True
    assert match(command_nomatch) == False



# Generated at 2022-06-24 07:24:45.410388
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru create', 'tsuru: "create" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tcreate-app')) == 'tsuru create-app'

# Generated at 2022-06-24 07:24:49.020215
# Unit test for function match
def test_match():
    assert match(Command('tsuru run-as myapp bash', 'tsuru: "run-as" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\trun-attach\n\trun-process\n'))


# Generated at 2022-06-24 07:24:53.596065
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_spell_check import get_new_command

    output = 'tsuru: "reserv" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\trestart\n\treserve\n'
    right_command = 'tsuru reserve'
    assert get_new_command(output) == right_command

# Generated at 2022-06-24 07:24:58.047126
# Unit test for function match
def test_match():
    assert(match(Command('tsuru target-add local http://localhost:8080', ''))
           == True)
    assert(match(Command('tsuru ps', 'tsuru: "rp" is not a tsuru command. '
                         'See "tsuru help".\nDid you mean?\n\trp'))
           == True)
    assert(match(Command('tsuru ps', ''))
           == False)
    assert(match(Command('tsuru ps', 'tsuru: "rp" is not a tsuru command. '
                         'See "tsuru help".\nDid you mean?\n\trp', None))
           == False)



# Generated at 2022-06-24 07:25:07.387781
# Unit test for function match

# Generated at 2022-06-24 07:25:10.743601
# Unit test for function get_new_command
def test_get_new_command():
    assert("tsuru token-generate" == get_new_command(Command("tsuru token-gen",
                                                      "tsuru: \"token-gen\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\ttoken-generate")))


# Generated at 2022-06-24 07:25:13.836384
# Unit test for function match
def test_match():
    example_command = "tsuru: \"tsuru\" is not a tsuru command. See \"tsuru help\"."
    assert match(Command(example_command, ""))


# Generated at 2022-06-24 07:25:19.596183
# Unit test for function get_new_command
def test_get_new_command(): 
    test_output = """tsuru: "target" is not a tsuru command. See "tsuru help".

Did you mean?

\ttarget-list
\ttarget-remove
\ttarget-set
\ttarget-update\n"""
    result = get_all_matched_commands(test_output)
    assert(result == ["target-list", "target-remove",
                      "target-set", "target-update"])


# Generated at 2022-06-24 07:25:27.263028
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('tsuru user-list', '', "tsuru: \"user-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tuser-create")) == "tsuru user-create"
    assert get_new_command(Command('tsuru node', '', "tsuru: \"node\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tnode-list\tnode-remove")) == "tsuru node-list"

# Generated at 2022-06-24 07:25:31.389469
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru admin-list',
        "tsuru: \"admin-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tadmin-list-permissions")

    asser

# Generated at 2022-06-24 07:25:38.713671
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    #get_new_command(<object>)
    assert get_new_command('''tsuru: "app-list" is not a tsuru command. See "tsuru help".

Did you mean?
        app-create
        app-remove
        app-info
        app-deploy
        app-log
        app-run
        app-restart
        app-start
        app-stop
        app-restart
        app-unlock...''') == 'tsuru app-list'


# Generated at 2022-06-24 07:25:44.923976
# Unit test for function get_new_command
def test_get_new_command():
    test_output = """tsuru: "applet" is not a tsuru command. See "tsuru help".

Did you mean?
	app-log-retry
	app-log
	app-run
	app-info"""
    test_input = "tsuru applet"
    assert get_new_command(Command(test_input, test_output)) == "tsuru app-log-retry"


enabled_by_default = True

# Generated at 2022-06-24 07:25:47.803603
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru target-add dev https://api.tsuru.io')
    assert get_new_command(command) == "tsuru target-add dev https://api.tsuru.io -s dev"

# Generated at 2022-06-24 07:25:50.536143
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru help', 'tsuru: "help" is not  a tsuru command. See "tsuru --help".\nDid you mean?\n\thelp-app\n\thelp-service\n')) == 'tsuru --help'

# Generated at 2022-06-24 07:25:59.132444
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('tsuru test', 'tsuru: "test" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tteam-add\n\tteam-remove\n')
    command2 = Command('tsuru new', 'tsuru: "new" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tteam-add\n\tteam-remove\n')
    assert get_new_command(command1) == 'tsuru team-add'
    assert get_new_command(command2) == 'tsuru team-remove'

# Generated at 2022-06-24 07:26:04.316072
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru target-add http://tsr.example.org',
                      'tsuru: "target-ad" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add')
    assert get_new_command(command) == 'tsuru target-add http://tsr.example.org'



# Generated at 2022-06-24 07:26:05.624564
# Unit test for function match
def test_match():
    assert match(Command("tsurru target-list", "tsurru: \"target-list\" is not a tsuru command. See \"tsurru help\"."))


# Generated at 2022-06-24 07:26:09.068820
# Unit test for function match
def test_match():
    assert match(Command('tsuru ap is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp\n', ''))
    assert not match(Command('foo', ''))


# Generated at 2022-06-24 07:26:13.030360
# Unit test for function get_new_command
def test_get_new_command():
	assert ('app-li', ['app-list']) == get_new_command({'output': 'tsuru: "app-li" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'})


enabled_by_default = True

# Generated at 2022-06-24 07:26:24.527873
# Unit test for function match

# Generated at 2022-06-24 07:26:27.717014
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-list tes', 'tsuru: "tes" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapps-list')) == 'tsuru apps-list tes'

# Generated at 2022-06-24 07:26:33.841283
# Unit test for function match
def test_match():
    match('tsuru: "deploy" is not a tsuru command. See "tsuru help".\n') == True
    match('tsuru: "deploy" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tdocker-exec\n') == True

# Generated at 2022-06-24 07:26:39.677534
# Unit test for function get_new_command
def test_get_new_command():
	command = type('command', (), {'output': 'tsuru: "app-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tteam-add', 'script': 'tsuru app-add'})
	new_command = get_new_command(command)
	assert new_command == 'tsuru app-create'

# Generated at 2022-06-24 07:26:44.619006
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('tsuru app-run ls /app', '''tsuru: "app-run" is not a tsuru command. See "tsuru help".

Did you mean?
	app-create
	app-remove
	app-restart
	app-run''', '', 1))



# Generated at 2022-06-24 07:26:49.240744
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("tsuru app-remove teste", "tsuru: \"app-remove\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-remove")
    assert get_new_command(command) == "tsuru app-remove"



# Generated at 2022-06-24 07:26:52.829044
# Unit test for function match
def test_match():
    match_app = match(Command('tsur l'))
    assert match_app is True
    no_match_app = match(Command('apt-get install tsuru'))
    assert no_match_app is False


# Generated at 2022-06-24 07:26:59.156367
# Unit test for function match
def test_match():
    assert match(Command('tsuru unittest', 'tsuru: "unittest" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tunit-test'))
    assert not match(Command('tsuru unittest', 'tsuru: "unittest" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:27:05.883613
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'tsuru app-create app-name',
                    'output': 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\nSee "tsuru help -a" for all available commands.\n'})
    assert (get_new_command(command) == 'tsuru app-create app-name')

# Generated at 2022-06-24 07:27:10.415209
# Unit test for function match
def test_match():
    assert match(Command('tsuru deploy',
                         'tsuru: "deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tdeploy-app'))
    assert not match(Command('tsuru deploy-app name', ''))


# Generated at 2022-06-24 07:27:15.321456
# Unit test for function match
def test_match():
    output = output = u"tsuru: \"target-not-a-tsuru-command\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tremove-target"
    assert_true(match(Command('', output=output)))


# Generated at 2022-06-24 07:27:18.929913
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru heg')) == 'tsuru help'
    assert get_new_command(Command('tsuru heg app-create')) == 'tsuru app-create'


# Generated at 2022-06-24 07:27:27.482299
# Unit test for function match
def test_match():
    assert match(Command('tsuru a', ''))

# Generated at 2022-06-24 07:27:38.676364
# Unit test for function get_new_command

# Generated at 2022-06-24 07:27:45.630517
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    from thefuck.shells.bash import Shell
    command = Shell(script='tsuru app-infos myapp', stderr='tsuru: "app-infos" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-info')
    assert get_new_command(command) == 'tsuru app-info myapp'

# Generated at 2022-06-24 07:27:52.376962
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\
Did you mean?\n\
\tapp-create\n\
\tapp-list\n\
\tapp-remove\n\
\tapp-run'
    command = Command('tsuru app-info', output)
    new_command = get_new_command(command)
    assert new_command == 'tsuru app-run'

# Generated at 2022-06-24 07:27:59.235273
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-add test http://test.com',
                         'tsuru: "target-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-remove\n\ttarget-set\n'))
    assert not match(Command('tsuru target-add test http://test.com', ''))
    assert not match(Command('tsuru target-add test http://test.com', 'tsuru: "target-add" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:28:06.153397
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru import match, get_new_command
    from thefuck.types import Command
    assert get_new_command(Command('tsuru app-create', '')) == 'tsuru app-create'
    assert get_new_command(Command('tsuro app-create', '')) == 'tsuru app-create'
    assert get_new_command(Command('tsuru appcreate', '')) == 'tsuru app-create'
    assert get_new_command(Command('tsuru a create', '')) == 'tsuru app-create'
    assert get_new_command(Command('tsuru a create', '')) == 'tsuru app-create'
    assert get_new_command(Command('tsuru a create', '')) == 'tsuru app-create'