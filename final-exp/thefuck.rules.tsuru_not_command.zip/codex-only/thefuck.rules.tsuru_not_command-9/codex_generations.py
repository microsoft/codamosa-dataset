

# Generated at 2022-06-24 07:18:10.793244
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-deploy', 'tsuru: "app-deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-deploy\n'))
    assert match(Command('tsuru app-deploy', 'tsuru: "app-deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-deploy\n\tapp-remove\n\tapp-rollback\n'))

# Generated at 2022-06-24 07:18:18.752403
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapps-list', '', 1))
    assert not match(Command('tsuru not-tsuru', 'tsuru: "not-tsuru" is not a tsuru command. See "tsuru help".', '', 1))
    assert not match(Command('tsuru', 'tsuru: no command specified. Check tsuru help', '', 1))


# Generated at 2022-06-24 07:18:25.633481
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-info'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))

# Generated at 2022-06-24 07:18:31.505604
# Unit test for function get_new_command
def test_get_new_command():
    import sys
    import re
    from thefuck.utils import test_default_rule
    with test_default_rule(mock_commands=False):
        new_command = get_new_command(Command('tsuru do-something',
                                              'tsuru: "do" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tdo-something\n'))
    assert new_command == 'tsuru do-something'

# Generated at 2022-06-24 07:18:37.819300
# Unit test for function match
def test_match():
	output_match= 'tsuru: "tartaruga" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tdocker-exec\n'
	output_wrong= 'tsuru: "tartaruga" is not a tsuru command. See "tsuru help".\n'
	assert match(Command('tartaruga',output_match))
	assert not match(Command('tartaruga',output_wrong))



# Generated at 2022-06-24 07:18:40.742554
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-run', '''tsuru: "app-run" is not a tsuru command.
See "tsuru help".

Did you mean?
	app-list
	app-start'''))


# Generated at 2022-06-24 07:18:41.865639
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list'))
    assert not match(Command('tsuru version'))


# Generated at 2022-06-24 07:18:44.523768
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-add',
                         'tsuru: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add'))
    assert not match(Command('tsuru target-add',
                             'tsuru: "target-add" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:18:50.848000
# Unit test for function get_new_command
def test_get_new_command():
    broken_cmd = 'tsuru app-info my_app'
    output = 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info-get\n'
    command = Command(broken_cmd, output)
    assert get_new_command(command) == 'tsuru app-info-get my_app'

# Generated at 2022-06-24 07:18:55.345342
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_typo import get_new_command
    command=Command('tsuru app-create some_app', 'Error: "app-ceate" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create')
    assert('tsuru app-create some_app' == get_new_command(command))

# Generated at 2022-06-24 07:18:57.237203
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('foo bar', '\nDid you mean?\n\tfoo\n')) == 'foo'



# Generated at 2022-06-24 07:19:08.359190
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-create toto', '')) == 'tsuru app-create toto'
    assert get_new_command(Command('tsuru target-set ', 'tsuru: "target-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t target-add')) == 'tsuru target-add '
    assert get_new_command(Command('tsuru target-set ', 'tsuru: "target-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t target-add\n\t target-remove\n\t target-list')) == 'tsuru target-add '

# Generated at 2022-06-24 07:19:14.948666
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tapp-list\n\tapp-remove\n\tapp-create\n'))
    assert not match(Command('tsuru app-create', ''))
    assert not match(Command('tsuru app-create', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n'))



# Generated at 2022-06-24 07:19:17.488327
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create'))


# Generated at 2022-06-24 07:19:24.915968
# Unit test for function match
def test_match():
    class Command:
        def __init__(self, output):
            self.output = output

    assert match(Command(
            'tsuru: "tsuru-cmd" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tservice-add\n'))
    assert not match(Command('ERROR: ts: command not found'))
    assert not match(Command('ERROR: tsuru-cmd: command not found'))
    assert not match(Command('tsuru: "tsuru-cmd" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru: "tsuru-cmd" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttsuru-cmd\n'))


# Generated at 2022-06-24 07:19:28.641982
# Unit test for function match
def test_match():
    assert match(
        Command('tsr',
                output='tsuru: "tsr" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlist'))


# Generated at 2022-06-24 07:19:33.106152
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-remove appname', 'tsuru: `app-remove` is not a tsuru command. See "tsuru help".\n\ntsuru: Did you mean?\n\tapp-remove'))
    assert not match(Command('tsuru app-remove appname', 'tsuru: wrong command'))


# Generated at 2022-06-24 07:19:38.225891
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='tsuru use ./some_file/some_path',
                                   output='tsuru: "use" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tunit-add\n\n')) == 'tsuru unit-add ./some_file/some_path'

# Generated at 2022-06-24 07:19:45.507515
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create foo', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-list\n\tunit-remove'))
    assert not match(Command('foo', 'tsuru: "foo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-list\n\tunit-remove'))

# Generated at 2022-06-24 07:19:55.609913
# Unit test for function match
def test_match():
	assert match(Command('tsuru deploy -a APP_NAME', 
						 'tsuru: "deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t\tswap',
						 'tsuru deploy -a APP_NAME',
						 'tsuru: "deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t\tswap'))

# Generated at 2022-06-24 07:20:01.284138
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert (get_new_command(Command("tsuru target-add production http://tsuru2.globoi.com",
                          "tsuru: \"target-add\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\ttarget-add\n")) == "tsuru target-add production http://tsuru2.globoi.com")

# Generated at 2022-06-24 07:20:07.998335
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create --team=test testtt',
                         'tsuru: "app-create --team=test testtt" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-end\n\tapp-remove\n\tapp-restart\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-team-add\n\tapp-team-remove\n'))


# Generated at 2022-06-24 07:20:17.115882
# Unit test for function match
def test_match():
    assert match(Command('tsuru', 'tsuruna is not a tsuru command. See "tsuru help".\nDid you mean?\ntsuru node-add', '', 3))
    assert not match(Command('tsuru', '', '', 3))
    assert not match(Command('tsuru', 'tsuruna is not a tsuru command. See "tsuru help".\nDid you mean?\ntsuru node-add', '', 3))
    assert match(Command('tsuru', 'tsuruna is not a tsuru command. See "tsuru help".', '', 3))
    assert match(Command('tsuru', 'tsuruna is not a tsuru command. See "tsuru help".\nDid you mean?\ntsuru node-add', '', 3))

# Generated at 2022-06-24 07:20:24.982403
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("tsuru help", "tsuru: \"help\" is not a tsuru command. See \"tsuru help\".")) ==  "tsuru help"
    assert get_new_command(Command("tsuru help", "tsuru: \"help\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\thands\n\thook\n\thook-list\n\thooks-add\n\thooks-list")) ==  "tsuru hook-list"


# Generated at 2022-06-24 07:20:27.921933
# Unit test for function match
def test_match():
    # Positive test
    command=Command('tsuru log')
    assert match(command) is True

    # Negative test
    command=Command('tsuru app-info')
    assert  match(command) is False


# Generated at 2022-06-24 07:20:31.108660
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru target',
                                   'tsuru: "target" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-list')) == 'tsuru target-list'


enabled_by_default = True

# Generated at 2022-06-24 07:20:35.676337
# Unit test for function match
def test_match():
    # We need to fake some stuff for the unit test to work
    output = 'tsuru: "test" is not a tsuru command. See "tsuru help".\nDid you mean?\n\t'
    command = type('Command', (object,), {
        'script': '',
        'output': output,
        'stderr': '',
        'debug': {},
    })
    assert match(command)
    assert not match(command)



# Generated at 2022-06-24 07:20:41.230535
# Unit test for function get_new_command
def test_get_new_command():
    f = get_new_command
    out = '''tsuru: "ls" is not a tsuru command. See "tsuru help".\n
Did you mean?\n
	service-add
	target-add'''
    assert f(Command('tsuru ls', out)) == 'tsuru service-add'

# Generated at 2022-06-24 07:20:44.445475
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('tsuru user-list', 'tsuru: "user-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tuser-list')) ==
            'tsuru user-list')

# Generated at 2022-06-24 07:20:52.939685
# Unit test for function match
def test_match():
    assert match("tsuru: \"existis\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tuser-create\n\tuser-info\n\tuser-list\n\tuser-remove\n")
    assert match("tsuru: \"existis\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tuser-list\n\nSee \"tsuru help\".")
    assert not match("tsuru: \"existis\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tuser-list\n\tuser-remove\n\nSee \"tsuru help\".")

# Generated at 2022-06-24 07:20:57.200156
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru add-key', 'tsuru: "add-key" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tkey-add')).script == 'tsuru key-add'

enabled_by_default = True

# Generated at 2022-06-24 07:21:06.823192
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-change')) == 'tsuru app-list'
    assert get_new_command(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-change-owner')) == 'tsuru app-list'

# Generated at 2022-06-24 07:21:12.621711
# Unit test for function match
def test_match():
    assert match(Command('tsuru user-add', (
        "tsuru: \"user-add\" is not a tsuru command. See \"tsuru help\".",
        "Did you mean?\n\tuser-create"))
    )

    assert not match(Command('tsuru', (
        "tsuru: \"\" is not a tsuru command. See \"tsuru help\".",
        "Did you mean?"))
    )


# Generated at 2022-06-24 07:21:16.212015
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create teste',
                         'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-list\n\tapp-remove\n\tapp-info\t'))
    assert not match(Command('tsuru app-create teste', ''))



# Generated at 2022-06-24 07:21:22.262216
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru aad', 'tsuru: "aad" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tadd-key\n\tadd-user\n\tapp-add')) == 'tsuru add-key'
    assert get_new_command(Command('tsuru add-use', 'tsuru: "add-use" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tadd-key\n\tadd-user\n\tapp-add')) == 'tsuru add-user'

# Generated at 2022-06-24 07:21:30.568308
# Unit test for function match
def test_match():
    # return true when text match
    output = 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'
    command = type('Command', (object,), {'script':'tsuru app-list', 'output':output})
    assert match(command)

    # return false when text does not match
    output = 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'
    command = type('Command', (object,), {'script':'tsuru app-list', 'output':output})
    assert not match(command)



# Generated at 2022-06-24 07:21:34.444067
# Unit test for function match
def test_match():
    # Test no match
    assert match(Command('tsuru app-list', '')) is None

    # Test match with one command
    assert match(Command('tsuru app-ls', 'tsuru: "app-ls" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list')) == 'tsuru app-ls'

    # Test match with two commands
    assert match(Command('tsuru my-app-ls', 'tsuru: "my-app-ls" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tmy-app-list')) == 'tsuru my-app-ls'


# Generated at 2022-06-24 07:21:35.781365
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru crrate app')
    assert get_new_command(command) == 'tsuru create app'

# Generated at 2022-06-24 07:21:39.164626
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list')) == True


# Generated at 2022-06-24 07:21:45.110062
# Unit test for function match

# Generated at 2022-06-24 07:21:47.081754
# Unit test for function match
def test_match():
    assert match(Command('tsuru is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-list\n\ttarget-remove\n\ttarget-set', ''))
    assert not match(Command('tsuru target-list', ''))
    assert not match(Command('', ''))


# Generated at 2022-06-24 07:21:57.397809
# Unit test for function get_new_command

# Generated at 2022-06-24 07:22:02.146162
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-create', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-list\n')
    assert get_new_command(command) == 'tsuru app-create'


# Generated at 2022-06-24 07:22:10.425160
# Unit test for function get_new_command
def test_get_new_command():
    examples = (Command('tsuru platform-create python34',
                        'tsuru: "platform-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-add'),
                Command('tsuru platform-list platform34',
                        'tsuru: "platform-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-remove'))

    for example in examples:
        assert get_new_command(example) == example.script.replace('platform-create',
                                                                  'platform-add').replace('platform-list',
                                                                                           'platform-remove')


# Generated at 2022-06-24 07:22:16.706671
# Unit test for function match
def test_match():
    assert match(Command('tsuru sss', ''))
    assert match(Command('tsuru sss', 'tsuru: "sss" is not a tsuru command. \
                         See "tsuru help".\n\nDid you mean?\n\tstatus'))
    assert not match(Command('tsuru status', 'tsuru: "sss" is not a tsuru \
                        command. See "tsuru help".\n\nDid you mean?\n\tstatus'))


# Generated at 2022-06-24 07:22:25.339352
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.config import Config
    assert get_new_command(Command('tsuru access-list',
        output='tsuru: "access-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\taccess-add\n\taccess-remove')) == 'tsuru access-add'
    assert get_new_command(Command('tsuru acess-list',
        output='tsuru: "acess-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\taccess-add\n\taccess-remove')) == 'tsuru access-add'

# Generated at 2022-06-24 07:22:27.195680
# Unit test for function match
def test_match():
    command = Command("tsuru it create test")
    assert match(command)


# Generated at 2022-06-24 07:22:36.498664
# Unit test for function get_new_command
def test_get_new_command():
    # First test case
    output1 = """tsuru: "app-associate-unit" is not a tsuru command. See "tsuru help".

Did you mean?
	app-create
	app-remove
	app-remove-unit
	app-log"""
    command1 = Command('app-associate-unit app-name container=name', output1)
    assert get_new_command(command1) == 'tsuru app-log'

    # Second test case
    output2 = """tsuru: "app-associate-unit" is not a tsuru command. See "tsuru help".

Did you mean?
	app-create
	app-remove
	app-remove-unit
	app-log"""
    command2 = Command('app-associate-unit app-name container=name', output2)
   

# Generated at 2022-06-24 07:22:40.112504
# Unit test for function match
def test_match():
    assert match(Command('hello world', '''tsuru: "hello" is not a tsuru command. See "tsuru help".


Did you mean?
	app-create
	app-info
	app-list'''))



# Generated at 2022-06-24 07:22:50.486480
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "ps" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps-list\n\tapps-remove'
    command = Command(script="tsuru ps", stderr=output, stdout="")
    assert get_new_command(command) == "tsuru apps-list"

    output = 'tsuru: "app" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps-create\n\tapps-remove'
    command = Command(script="tsuru app", stderr=output, stdout="")
    assert get_new_command(command) == "tsuru apps-create"


# Generated at 2022-06-24 07:22:55.151263
# Unit test for function match
def test_match():
    # Test to verify that match returns False when there is no misspelled
    # tsuru command name
    assert not match("tsuru ps")

    # Test to verify that match returns True when there is a misspelled
    # tsuru command name
    assert match("tsuru: \"psu\" is not a tsuru command. See \"tsuru help\".")


# Generated at 2022-06-24 07:22:59.075324
# Unit test for function match
def test_match():
    command = Command('tsurur', 'tsuru: "tsurur" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsuru')
    assert match(command)
    command = Command('tsuru', '')
    assert not match(command)



# Generated at 2022-06-24 07:23:04.115544
# Unit test for function get_new_command
def test_get_new_command():
    output = '''tsuru: "target-set" is not a tsuru command. See "tsuru help".

Did you mean?
	target-get
	target-remove'''
    command = Command("tsuru target-set", output)
    assert get_new_command(command) == 'tsuru target-get'

# Generated at 2022-06-24 07:23:10.338763
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('tsuru app-create myapp', '')) == 'tsuru app-create myapp'

    assert get_new_command(Command('tsuru run echo hello', 'tsuru: "run" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\texecute\n\treserve\n')) == 'tsuru execute echo hello'

# Generated at 2022-06-24 07:23:16.538248
# Unit test for function get_new_command
def test_get_new_command():
    cmd = 'tsuru: "team" is not a tsuru command. See "tsuru help".\n\nDid you mean? \n\tteam-create\n\tteam-remove\n\tteam-user-add\n\tteam-user-remove'
    assert get_new_command(MagicMock(script='tsuru team', output=cmd)) == 'tsuru team-create'

# Generated at 2022-06-24 07:23:22.668345
# Unit test for function get_new_command
def test_get_new_command():
    right_cmd = 'tsuru app-info'
    wrong_cmd = 'tsuru app-info-test'
    output = (
        'tsuru: "app-info-test" is not a tsuru command. See "tsuru help".\n'
        '\n'
        'Did you mean?\n'
        '\tapp-info\n'
    )

    _command = type('Command', (object,), {
        'script': wrong_cmd,
        'output': output,
    })

    assert get_new_command(_command) == right_cmd

# Generated at 2022-06-24 07:23:24.629463
# Unit test for function match
def test_match():
    assert match(Command('tsurud ststs', ''))
    assert not match(Command('tsurud ststs', 'tsurud: "ststs" is not a tsuru command'))


# Generated at 2022-06-24 07:23:34.936908
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-remove'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create'))

# Generated at 2022-06-24 07:23:37.012684
# Unit test for function get_new_command
def test_get_new_command():
    command = MagicMock(output="tsuru: \"coucou\" is not a tsuru command")
    assert get_new_command(command) == "tsuru login"

# Generated at 2022-06-24 07:23:41.312269
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-remove testa',
                         'tsuru: "app-remove" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-remove\n\tapp-remove-unit\n'))


# Generated at 2022-06-24 07:23:43.666892
# Unit test for function match
def test_match():
    # test match function with valid command
    assert match(Command("tsuru permission-add app1 --team team1", ""))

    # test match function with valid command
    assert no

# Generated at 2022-06-24 07:23:49.753590
# Unit test for function match
def test_match():
    output = '''/usr/local/bin/tsuru: "not" is not a tsuru command. See "tsuru help".
Did you mean?
	network-list
	node-list
	node-remove
	node-info'''
    command1 = Command('tsuru not', output=output)
    assert match(command1)

    output = '''tsuru: "not" is not a tsuru command. See "tsuru help".
Did you mean?
	network-list
	node-list
	node-remove
	node-info'''
    command2 = Command('tsuru not', output=output)
    assert match(command2)

    output = '''/usr/local/bin/tsuru: "not" is not a tsuru command. See "tsuru help".'''
    command3 = Command

# Generated at 2022-06-24 07:23:51.686060
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list',
                         'tsuru: "app-list" is not a tsuru command. See '
                         '"tsuru help".\nDid you mean?\n\tapps-list'))
    assert not match(Command('tsuru app-list', ""))


# Generated at 2022-06-24 07:23:54.933781
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('tsuru: "app-remove" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-remove') == 'tsuru app-remove'

# Generated at 2022-06-24 07:24:03.476910
# Unit test for function get_new_command
def test_get_new_command():
    # Case 1: command has output that contains ' is not a tsuru command.
    #   See "tsuru help".' and contains the command that was mistyped
    command = Command('tsuru wrong-command', 'tsuru: "wrong-command" is not '
                      'a tsuru command. See "tsuru help".\nDid you mean?\n\t'
                      'set-heap-size\n\tcreate-user\n\trollback')
    assert get_new_command(command) == 'tsuru set-heap-size'

    # Case 2: command has output that contains ' is not a tsuru command.
    #   See "tsuru help".' but doesn't contain the mistyped command

# Generated at 2022-06-24 07:24:05.511844
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-ls', ''))
    assert match(Command('tsuru app-list', ''))
    assert not match(Command('tsuru app-list', '', ''))


# Generated at 2022-06-24 07:24:10.856314
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-deploy --app myapp .',
                         'tsuru: "app-deploy" is not a tsuru command.'
                         ' See "tsuru help".'
                         '\n\nDid you mean?\n\tdeploy\n\tcreate-unit\n'))


# Generated at 2022-06-24 07:24:18.269651
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command

    out1 = ('tsuru: "tsura" is not a tsuru command. See "tsuru help".\n'
            '\n'
            'Did you mean?\n'
            '\ttsuru --help')
    out2 = ('tsuru: "tsura" is not a tsuru command. See "tsuru help".\n'
            '\n'
            'Did you mean?\n'
            '\ttsuru --help\n'
            '\ttsuru --version')
    out3 = 'tsuru: "tsura" is not a tsuru command. See "tsuru help".\n'

    command1 = Command('tsura', out1)

# Generated at 2022-06-24 07:24:23.265265
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-add', 'tsuru: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add\n'))
    assert not match(Command('babel-node server.js', 'bash: babel-node: command not found\n'))

# Generated at 2022-06-24 07:24:25.460664
# Unit test for function match
def test_match():
	assert (match(Command('tsuru app-info')) == True)
	assert (match(Command('tsuru app-info wrong')) == False)


# Generated at 2022-06-24 07:24:27.721475
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    assert get_new_command(Command('tsuru env-get')) == ['tsuru env-set']

# Generated at 2022-06-24 07:24:31.540730
# Unit test for function match
def test_match():
    assert match(Command("tsuru pwalalala", "tsuru: \"pwalalala\" is not a tsuru command. See \"tsuru help\"."))
    assert not match(Command("tsuru", ""))


# Generated at 2022-06-24 07:24:40.270698
# Unit test for function get_new_command
def test_get_new_command():
    output = ('***** tsuru: "mycommand" is not a tsuru command. See "tsuru help".\n***** '
              '\n***** Did you mean?\n\t***** '
              'docker-exec\n\t***** logs\n\t***** node\n\t***** ps')

    command = type('Command', (object,),
                   {'script': 'mycommand', 'output': output})

    assert get_new_command(command) == \
           ('tsuru docker-exec; '
            'tsuru logs; '
            'tsuru node; '
            'tsuru ps')

# Generated at 2022-06-24 07:24:44.343707
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "app-p" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-pool-change'
    command = Command(script=None, output=output)
    assert get_new_command(command) == 'tsuru app-pool-change'

# Generated at 2022-06-24 07:24:52.496841
# Unit test for function match
def test_match():
    # Test with a command that doesn't match
    command = Command("tsuru help", "tsuru: \"help\" is not a tsuru command.\nSee \"tsuru help\".\n\nDid you mean?\n\tapp-add-team\n\tapp-change-team\n\tapp-remove-team\n\tkey-add\n\tkey-remove\n\tservice-add\n\tteam-create\n\tteam-delete\n\tteam-list\n\tuser-create")
    assert match(command)

    # Test with a command that does match
    command = Command("tsuru help", "tsuru: \"help\" is not a tsuru command.\nSee \"tsuru help\".\n\nDid you mean?\n\tapp-list")

# Generated at 2022-06-24 07:25:00.494331
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-run ls', 'The "app-run ls" command is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-log\n\tapp-info\n\tapp-list'))
    assert not match(Command('tsuru app-run ls', 'The "app-info ls" command is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-log\n\tapp-info\n\tapp-list'))


# Generated at 2022-06-24 07:25:03.239972
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('foo', 'foo: "bar" is not a foo command')) == 'foo bar'


priority = 1000
enabled_by_default = True

# Generated at 2022-06-24 07:25:09.227988
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru start', 'tsuru: "start" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tstart-app')) == 'tsuru start-app'
    assert get_new_command(Command('tsuru ps', 'tsuru: "ps" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tps:bind\n\tps:list\n\tps:unbind\n\tps:unbind-unit\n\tps:bind-unit')) == 'tsuru ps:list'

# Generated at 2022-06-24 07:25:15.824655
# Unit test for function match
def test_match():
    assert match(Command('xoxo', 'xoxo is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-list\n')) == True
    assert match(Command('hello world', 'hello: "world" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t\n')) == False


# Generated at 2022-06-24 07:25:19.781291
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru permission-add some-user some-app',
'''tsuru: "permission-add" is not a tsuru command. See "tsuru help".

Did you mean?
	permission-remove''')) == 'tsuru permission-remove some-user some-app'

# Generated at 2022-06-24 07:25:24.080847
# Unit test for function get_new_command
def test_get_new_command():
    brokent_cmd = 'tsuru app-create'
    output = 'tsuru: "app-createe" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n'
    new_command = get_new_command(Command(script=brokent_cmd, output=output))
    assert new_command == 'tsuru app-create'

# Generated at 2022-06-24 07:25:27.617775
# Unit test for function match
def test_match():
    output = 'tsuru: "add-unit" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tadd-unit'
    assert match(Command(script=None, output=output))


# Generated at 2022-06-24 07:25:36.966921
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-creathe app-name team-name',
                         "tsuru: \"app-creathe\" is not a tsuru command.\n" +
                         "See \"tsuru help\".\n\n" +
                         "Did you mean?\n\t app-create"))
    assert not match(Command('ls',
                             "tsuru: \"app-creathe\" is not a tsuru command.\n" +
                             "See \"tsuru help\".\n\n" +
                             "Did you mean?\n\t app-create"))
    assert not match(Command('ls -l', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-24 07:25:42.176724
# Unit test for function get_new_command
def test_get_new_command():
    assert 'knife' == get_new_command(Command(script='tsuru', output='tsuru: "knife" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tknife'))
    assert 'knife' == get_new_command(Command(script='tsuru knife', output='tsuru: "knife" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tknife'))


# Generated at 2022-06-24 07:25:46.320847
# Unit test for function match
def test_match():
    test_command = Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tversions')
    assert match(test_command)
    assert match(test_command) == True


# Generated at 2022-06-24 07:25:49.025861
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru', '', 'tsuru: "app-loist" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list')
    assert get_new_command(command) == 'tsuru app-list'

# Generated at 2022-06-24 07:25:56.998639
# Unit test for function match
def test_match():
    output  = 'tsuru: "ssh" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tssh-keys-add\n\tssh-keys-remove\n\tssh-key-add'
    command = Command('tsuru ssh -h', output)
    assert(match(command))
    output = 'tsuru: "ssh" is not a tsuru command. See "tsuru help".'
    command = Command('tsuru ssh -h', output)
    assert(not match(command))


# Generated at 2022-06-24 07:26:01.855868
# Unit test for function get_new_command
def test_get_new_command():
    output = "tsuru: \"events\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tactions\n\tapp\n\tkey-add\n\tkey-remove\n\tkey-show"
    command = "tsuru events app"
    new_command = get_new_command(Command(script=command, output=output))

    assert new_command == "tsuru actions app"

# Generated at 2022-06-24 07:26:03.920303
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru app-list',
                         stderr='tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list\n\tapp-remove\n',
                         stdout=''))


# Generated at 2022-06-24 07:26:10.357940
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-add', output='''tsuru: "app-add" is not a tsuru command. See "tsuru help".

Did you mean?
        app-create
''')) == 'tsuru app-create'
    assert get_new_command(Command('tsuruu app-add', output='''tsuru: "app-add" is not a tsuru command. See "tsuru help".

Did you mean?
        app-create
''')) == 'tsuruu app-create'

# Generated at 2022-06-24 07:26:13.076140
# Unit test for function match
def test_match():
    output = 'tsuru: "nonexistcommand" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tnode\n\tnode-list\n\tnode-remove\n\tnode-update\n'
    assert match(Command(script='tsuru nonexistcommand', output=output))


# Generated at 2022-06-24 07:26:21.876623
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru permission-add', '')
    new_command = get_new_command(command)
    assert new_command == 'tsuru permission-set'

    command = Command('tsuru permisson-add', '')
    new_command = get_new_command(command)
    assert new_command == 'tsuru permission-set'

    command = Command('tsuru perm-add', '')
    new_command = get_new_command(command)
    assert new_command == 'tsuru permission-set'



# Generated at 2022-06-24 07:26:25.328623
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "target-delete" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-remove\n'
    command = 'tsuru target-delete'
    assert get_new_command(Command(command, output)) == 'tsuru target-remove'

# Generated at 2022-06-24 07:26:29.465598
# Unit test for function match
def test_match():
    out =  "tsuru: \"target-add\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\ttarget-add\n\ntarget-remove\n\n"
    assert match(Command(script="tsuru target-add", output = out) )
    assert not match(Command(script="git add", output = "tsuru: \"git\" is not a tsuru command. See \"tsuru help\""))


#Unit test for function get_new_command

# Generated at 2022-06-24 07:26:37.484735
# Unit test for function get_new_command
def test_get_new_command():
    #GIVEN
    command_str = 'tsur-r: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create'
    command = Command(command_str, '', 0)
    #WHEN
    new_command_str = get_new_command(command)
    #THEN
    assert new_command_str == 'tsuru app-create'
    assert new_command_str == replace_command(command, 'tsur-r', ['tsuru'])

# Generated at 2022-06-24 07:26:44.569671
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info app1', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list\n\tapp-remove\n\tapp-lock'))
    assert not match(Command('tsuru app-list', ''))
    assert not match(Command('tsuru app-list', 'No tokens provided.'))
    assert not match(Command('tsuru app-list', 'No tokens provided.', error=True))


# Generated at 2022-06-24 07:26:48.576472
# Unit test for function get_new_command
def test_get_new_command():
    output = """tsuru: "tsr" is not a tsuru command. See "tsuru help".

Did you mean?
	tsuru"""
    command = type("Command", (object,), {"output": output})
    assert get_new_command(command) == "tsuru"

# Generated at 2022-06-24 07:26:56.624760
# Unit test for function match
def test_match():
    assert match(Command('tsuru login', None, 'tsuru: "login" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlogin-key\n\tlogin-token\n', '')) == True
    assert match(Command('tsuru login', None, 'tsuru: "login" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlogin-key\n\tlogin-token\n', '')) == True


# Generated at 2022-06-24 07:27:02.277700
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Cli('tsuru hepl')) == 'tsuru help')
    assert(get_new_command(Cli('tsuru proc-messag')) == 'tsuru proc-message')
    assert(get_new_command(Cli('tsuru proc-messag -h')) == 'tsuru proc-message -h')

# Generated at 2022-06-24 07:27:04.168965
# Unit test for function match
def test_match():
    assert match(Command('tsurur', ''))


# Generated at 2022-06-24 07:27:15.088858
# Unit test for function match
def test_match():
    assert match(Command('tsuru not-a-tsuru-cmd',
                 'tsuru: "not-a-tsuru-cmd" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcreate-app\n\tcreate-team\n\tdeploy',
                 '', 0))

    assert not match(Command('tsuru not-a-tsuru-cmd',
                 'tsuru: "not-a-tsuru-cmd" is not a tsuru command. See "tsuru help".\n\nDid you mean?',
                 '', 0))


# Generated at 2022-06-24 07:27:20.635529
# Unit test for function match
def test_match():
    assert match(Command('tsuru targt', ''))
    assert match(Command('tsuru targt', '', ''))
    assert match(Command('tsuru targt', '', ''))
    assert not match(Command('tsuru app-list', ''))
    assert not match(Command('tsuru app-list', '', ''))
    assert not match(Command('tsuru app-list', '', ''))

# Generated at 2022-06-24 07:27:25.839163
# Unit test for function get_new_command
def test_get_new_command():
    # command ts-something
    broken_cmd_name = "ts-something"
    output = 'tsuru: "{}" is not a tsuru command. See "tsuru help".\
             \n\nDid you mean?\n\t{}'.format(broken_cmd_name, broken_cmd_name)
    assert get_new_command(Command('ts-something', output=output)) ==\
            'ts-something'


# Generated at 2022-06-24 07:27:37.018545
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    command = Command('echo test', 'echo test\necho it is a test', '', 0)

    # If there is one matched command
    assert get_new_command(command) == 'echo it is a test'
    # If there isn't any matched command
    assert get_new_command(Command(command.script,
                                   'echo test\necho it\'s a test',
                                   '', 0)) == 'echo it\'s a test'
    # If there are more than one matched commands
    assert get_new_command(
        Command(command.script,
                'echo test\necho it is a test\necho it\'s a test',
                '', 0)) == 'echo it is a test'



# Generated at 2022-06-24 07:27:39.811613
# Unit test for function match
def test_match():
    assert match(Command('tsuruu'))
    assert not match(Command('ls'))
    assert not match(Command('tsuru'))


# Generated at 2022-06-24 07:27:42.138558
# Unit test for function get_new_command
def test_get_new_command():
    output = '''tsuru: "login" is not a tsuru command. See "tsuru help".

Did you mean?
	log-in
	long
	logs
	logout
'''
    command = Command('', output)
    assert get_new_command(command) == 'tsuru log-in'

# Generated at 2022-06-24 07:27:46.168604
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='tsuru sshdapp',
                                   output="""tsuru: "sshdapp" is not a tsuru command. See "tsuru help".


Did you mean?
	ssh-app""")) == 'tsuru ssh-app'

# Generated at 2022-06-24 07:27:51.063115
# Unit test for function match
def test_match():
    assert match(Command('tsuru asdf', 'tsuru: "asdf" is not a tsuru command. \
See "tsuru help". \
\nDid you mean?\n\tapp-run\n\tapp-list\n\tapp-log'))


# Generated at 2022-06-24 07:27:57.283262
# Unit test for function match
def test_match():
    examples = [
        Command('tsuru apa', 'tsuru: "apa" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps', '', ''),
        Command('tsuru login', 'tsuru: "login" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlog', '', '')
    ]

    for example in examples:
        assert match(example)


# Generated at 2022-06-24 07:28:06.726558
# Unit test for function match
def test_match():
    """
    Unit test for function match
    """
    assert match(Command('tsuru node-list', 'tsuru: "node-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-add\n\tnode-info\n\tnode-remove', ''))
    assert match(Command('tsuru server-list', 'tsuru: "node-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-add\n\tnode-info\n\tnode-remove', ''))