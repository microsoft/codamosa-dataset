

# Generated at 2022-06-24 07:18:05.827954
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-list',
                'tsuru: "service-list" is not a tsuru command. See "tsuru help".\n\nDid you mea' +
                'n?\n\tservice-info\n\tservice-list\n\tservice-remove'))


# Generated at 2022-06-24 07:18:10.164879
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru service-instance-add',
                                   'tsuru: "service-instance-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice-instance-bind')) == 'tsuru service-instance-bind'


# Generated at 2022-06-24 07:18:18.349933
# Unit test for function match
def test_match():
    # Case tsuru: "command" is not a tsuru command. See "tsuru help".
    output_1 = "tsuru: \"fake-cmd\" is not a tsuru command. See \"tsuru help\"."
    command_1 = Command("fake-cmd arg1 arg2", output=output_1)
    assert match(command_1) is True

    # Case tsuru app-list is not a tsuru command.
    command_2 = Command("tsuru app-list arg1 arg2", output=output_1)
    assert match(command_2) is False


# Generated at 2022-06-24 07:18:22.698005
# Unit test for function match
def test_match():
    assert (match(Command('tsuru help', 'tsuru: "help" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp-app\n\thelp-ssh')) != None)
    assert (match(Command('git help', '')) == None)



# Generated at 2022-06-24 07:18:28.819198
# Unit test for function match
def test_match():
    # Unit test when the string " is not a tsuru command. See "tsuru help".\nDid you mean?\n\t" is in the output
    output_string_1="""tsuru: "target" is not a tsuru command. See "tsuru help".
Did you mean?
	targit

"""
    output_string_2="""tsuru: "target" is not a tsuru command. See "tsuru help".
Did you mean?
	targit
"""
    output_string_3="""tsuru: "target" is not a tsuru command. See "tsuru help".
Did you mean?
	targit

"""

# Generated at 2022-06-24 07:18:38.793293
# Unit test for function match
def test_match():
    from mock import Mock
    assert match(Mock(output='tsuru: "app-deploy" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-deploy-ssh'))
    assert not match(Mock(output='foo'))
    assert match(Mock(output='tsuru: "run" is not a tsuru command. See "tsuru help".\nDid you mean?\n\trun-ssh'))
    assert match(Mock(output='tsuru: "run" is not a tsuru command. See "tsuru help".\nDid you mean?\n\trun-ssh\nrun-plugin'))

# Generated at 2022-06-24 07:18:42.493828
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-lis', """tsuru: "app-lis" is not a tsuru command. See "tsuru help".


Did you mean?
	tsuru app-list
""")
    assert get_new_command(command) == "tsuru app-list"



# Generated at 2022-06-24 07:18:53.308942
# Unit test for function match
def test_match():
    assert match(Command('tsuru unittest', 'tsuru: "unittest" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttest', '')) != None
    assert match(Command('tsurun', 'tsuru: "unittest" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttest', '')) != None
    assert match(Command('tsuru unittest', 'tsuru: "unittest"', '')) == None
    assert match(Command('tsuru-unittest', 'tsuru: "unittest" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttest', '')) == None


# Generated at 2022-06-24 07:18:58.792256
# Unit test for function match
def test_match():
    assert match(Command('tsru --version', 'tsuru: "tsru" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsuru'))
    assert not match(Command('tsuru --version', ''))
    assert not match(Command('tsru --version', 'tsuru: "tsru" is not a tsuru command.'))


# Generated at 2022-06-24 07:19:03.386003
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-add',
        'tsuru target-add: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add'))
    assert not match(Command('tsuru target-add', 'Error'))


# Generated at 2022-06-24 07:19:08.618684
# Unit test for function match
def test_match():
    assert match(Command('tsuru --help', 'tsuru: "--help" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp\n'))
    assert not match(Command('tsuru --help', 'tsuru: "--help" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:19:12.771982
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru client-rmeove jose', 'tsuru: "client-remove" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tclient-remove')
    assert get_new_command(command) == 'tsuru client-remove jose'



# Generated at 2022-06-24 07:19:20.911504
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-remove\n\tapp-restart\n\tapp-run\n\tapp-start')) == 'tsuru app-create'

# Generated at 2022-06-24 07:19:23.129548
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-li')) == 'tsuru app-list'

# Generated at 2022-06-24 07:19:28.062347
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsu app-create ap nam --team nte', 'tsuru: "app-creat" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create')
    assert get_new_command(command) == 'tsu app-create ap nam --team nte'

# Generated at 2022-06-24 07:19:31.767324
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info',
        "tsuru: 'app-info' is not a tsuru command. See 'tsuru help'.\n\nDid you mean?\n\tapp-info"))



# Generated at 2022-06-24 07:19:42.745345
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_command_not_found import get_new_command
    assert get_new_command("tsuru: \"xxx\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\txxx") == "tsuru xxx"
    assert get_new_command("tsuru: \"xxx\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tyyy\n\tzzz") == "tsuru yyy"
    assert get_new_command("tsuru: \"xxx\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tzzz") == "tsuru zzz"



# Generated at 2022-06-24 07:19:52.767831
# Unit test for function match
def test_match():
    # output of command:
    # tsuru hello
    # tsuru: "hello" is not a tsuru command. See "tsuru help".
    #
    # Did you mean?
    # 	hello-world
    # 	help
    output = ("tsuru: \"hello\" is not a tsuru command. See "
              "\"tsuru help\".\n\nDid you mean?\n\thello-world\n\thelp")
    assert not match(Command("tsuru hello", output))

    # output of command:
    # tsuru target-machine-add
    # tsuru: "target-machine-add" is not a tsuru command. See "tsuru help".
    #
    # Did you mean?
    # 	machine
    # 	permission
    # 

# Generated at 2022-06-24 07:19:55.257534
# Unit test for function match
def test_match():
    assert match(Command("tsuru help", "tsuru: \"help\" is not a tsuru command. See \"tsuru help\"."))
    assert not match(Command("tsuru help", "tsuru: \"help\" is not a tsuru command."))


# Generated at 2022-06-24 07:19:59.790309
# Unit test for function match
def test_match():
    command_output = 'tsuru: "tsuru admin-config-set false" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tadmin-credential-add\n'
    assert match(Command('tsuru admin-config-set false', command_output))
    assert not match(Command('tsuru admin-config-set false', ''))



# Generated at 2022-06-24 07:20:09.990094
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('tsuru: "bar" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoo', "bar") == "tsuru foo"
    assert get_new_command('tsuru: "bar" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoo\n\tbarf', "bar") == "tsuru foo"
    assert get_new_command('tsuru: "bar" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfoo\n\tbarf\n\tblah', "bar") == "tsuru foo"

# Generated at 2022-06-24 07:20:13.185311
# Unit test for function match
def test_match():
    assert match(Command(script='tsurru it',
                         stderr='''tsuru: "it" is not a tsuru command. See "tsuru help".

Did you mean?
   info
   token'''))


# Generated at 2022-06-24 07:20:20.926765
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='tsuru p')).script == 'tsuru platform-list'
    assert get_new_command(Command(script='tsuru help tsuru')).script == 'tsuru'
    assert not get_new_command(Command(script='tsuru p', output='tsuru: "p" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tplatform-list'))
    assert not get_new_command(Command(script='tsuru help tsuru', output='tsuru: "help tsuru" is not a tsuru command. See "tsuru help".\nDid you mean?'))

# Generated at 2022-06-24 07:20:27.445605
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru permision-add', '')
    assert get_new_command(command) == replace_command(command, 'permision-add', ['permission-add'])

    command = Command('tsuru permissio-add', '')
    assert get_new_command(command) == replace_command(command, 'permissio-add', ['permission-add'])



# Generated at 2022-06-24 07:20:31.910558
# Unit test for function match
def test_match():
    output = 'tsuru: "target-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add\n\ttarget-remove\n\n'
    assert match(Command('tsuru target-set localhost http://localhost:8080', output))

    assert not match(Command('tsuru target-set localhost http://localhost:8080'))


# Generated at 2022-06-24 07:20:38.395750
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru do something',
                                   'tsuru: "do" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tkey-add\n\tkey-remove')) == 'tsuru key-add something'
    assert get_new_command(Command('tsuru do key-remove something',
                                   'tsuru: "do" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tkey-add\n\tkey-remove')) == 'tsuru key-remove something'

# Generated at 2022-06-24 07:20:42.088827
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_typos import get_new_command
    output = """tsuru: "ttt" is not a tsuru command. See "tsuru help".

Did you mean?
        target-list
        target-remove
        target-set
        token-add
        token-remove
        token-regenerate
        token-revoke"""
    command = type("Command", (object,),
                   {'output': output, 'script': 'echo $0'})
    assert get_new_command(command) == 'tsuru target-list'

# Generated at 2022-06-24 07:20:44.186541
# Unit test for function match
def test_match():
    assert match("tsuru: \"app-run\" is not a tsuru command. See \"tsuru help\".")


# Generated at 2022-06-24 07:20:50.210767
# Unit test for function get_new_command
def test_get_new_command():
    broken_cmd = "tsuru accep"
    command = MagicMock(output='tsuru: "accep" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\taccept-invite\n\taccept-restriction', script=broken_cmd)
    assert get_new_command(command) == (broken_cmd, set(['accept-invite', 'accept-restriction']))

enabled_by_default = True

# Generated at 2022-06-24 07:20:55.078676
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru hlp',
                         stderr='tsuru: "hlp" is not a tsuru command. See "tsuru help".',
                         output='\nDid you mean?\n\thelp'))
    assert not match(Command(script='tsuru', stderr=''))
    assert not match(Command(script='tsuru hlp', stderr='tsuru: "hlp" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:21:00.020049
# Unit test for function match
def test_match():
    assert match(Command('tsuru login git.tsuru.io', 'tsuru: "login" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tlogin-ssh'))


# Generated at 2022-06-24 07:21:05.579853
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('tsuru create-app xpto2',
                                    'tsuru: "create-app" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcreate-units\n\tcreate-key\n\tcreate-team\n\tcreate-user\n\tcreate-service-instance\n\tcreate-service-key\n\tcreate-env', '', 0)) ==
            'tsuru create-app xpto2')


# Generated at 2022-06-24 07:21:07.861908
# Unit test for function match
def test_match():
    assert match(Command('tsuru status', ''))
    assert not match(Command('tsuru target-list', ''))



# Generated at 2022-06-24 07:21:15.433540
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('tsuru app-create',
                         'tsru: "tsuru app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-list\n\tapp-remove\n\n'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-list\n\tapp-remove\n\n'))

#

# Generated at 2022-06-24 07:21:22.181833
# Unit test for function match
def test_match():
    cmd1 = Command('tsuru asd', 'tsuru: "asd" is not a tsuru command')
    cmd2 = Command('tsuru asd', 'tsuru: "asd" is not a tsuru command.')
    cmd3 = Command('tsuru asd', 'tsuru: "asd" is not a tsuru command.\n')
    cmd4 = Command('tsuru asd', 'tsuru: "asd" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-run\n\tapp-start\n\tapp-teardown\n\tapp-unit-add\n\tapp-unit-remove\n')

# Generated at 2022-06-24 07:21:27.129732
# Unit test for function match
def test_match():
    command = Command('tsuru plataform-add java',
                      "tsuru: \"plataform-add\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tplataform-remove\n\tplatform-add\n\tplatform-update")
    assert(match(command))


# Generated at 2022-06-24 07:21:33.633813
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(types.Command(
        script='tsuru not_existing_command',
        stderr='tsuru: "not_existing_command" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnot_existing_command_1\n\tnot_existing_command_2\n',
        output='',
        env={}))
    assert new_command == ('tsuru not_existing_command_1 || ' +
                           'tsuru not_existing_command_2')



# Generated at 2022-06-24 07:21:36.982605
# Unit test for function match
def test_match():
    assert match(Command('tsuru env-set', 'env-set is not a tsuru command. See "tsuru help"'))
    assert not match(Command('tsur', 'tsur is not a tsuru command. See "tsuru help"'))
    assert not match(Command('tsuru help', 'help is not a tsuru command. See "tsuru help"'))


# Generated at 2022-06-24 07:21:46.527702
# Unit test for function match
def test_match():
    # Matching is mostly done for text in output.
    command = Command('tsrlllllllllllllll')
    command.output = "tsuru: \"tsrlllllllllllllll\" is not a tsuru command."\
                     " See \"tsuru help\"\nDid you mean?\n\treport-last"
    assert match(command)

    # No match if the output doesn't contain the 'did you mean' text
    command = Command('tsrlllllllllllllll')
    command.output = "tsuru: \"tsrlllllllllllllll\" is not a tsuru command."\
                     " See \"tsuru help\""
    assert not match(command)


# Generated at 2022-06-24 07:21:51.908233
# Unit test for function match
def test_match():
    assert match(Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapi-version'))
    assert not match(Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:21:54.393852
# Unit test for function match
def test_match():
    import os
    os.system("tsuru not-a-command")
    assert match(Command('tsuru not-a-command',
                         "tsuru: \"not-a-command\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tnotify-add\n\tnotify-send\n\tnotify-rm\n\tnotify-remove"))


# Generated at 2022-06-24 07:22:00.629197
# Unit test for function get_new_command
def test_get_new_command():
    from tests.comparators import AnyStringWith

    command = Command('tsuru app-change-unit 2', AnyStringWith('''tsuru: "app-change-unit" is not a tsuru command. See "tsuru help".

Did you mean?
        app-change-units
        app-grant
        app-info'''))
    assert get_new_command(command) == 'tsuru app-change-units 2'

# Generated at 2022-06-24 07:22:03.056600
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-deploy', ''))
    assert not match(Command('tsuru target-add', ''))

# Generated at 2022-06-24 07:22:07.942319
# Unit test for function match
def test_match():
    assert match(Command('tsuru login', 'tsuru: "login" is not a tsuru command.\nSee "tsuru help".\n\nDid you mean?\n\tlogin-git'))

    assert not match(Command('tsuru help', 'tsuru: "help" is not a tsuru command.\nSee "tsuru help".'))


# Generated at 2022-06-24 07:22:10.666127
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', "tsuru: \"app-list\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-list"))


# Generated at 2022-06-24 07:22:20.082927
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("tsuru: \"app-info\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-create\n\tapp-list\n\tapp-remove\n\tapp-update\n\tapp-grant\n\tapp-revoke\n\tapp-restart\n\tapp-start\n\tapp-stop") == "tsuru app-create"

# Generated at 2022-06-24 07:22:24.914167
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='tsuru team delete',
                      stderr='tsuru: "team" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tteam-remove\n\tteam-delete\n',
                      stdout='')
    assert get_new_command(command) == 'tsuru team-delete'

# Generated at 2022-06-24 07:22:30.569551
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.command_not_found import get_new_command
    assert get_new_command(Command('tsuru install',
      'tsuru: "install" is not a tsuru command. See "tsuru help".\n'
      '\nDid you mean?\n\tapps-deplo',
      'tsuru install')) == 'tsuru apps-deploy\n'


enabled_by_default = True

# Generated at 2022-06-24 07:22:35.177078
# Unit test for function match
def test_match():
    output = 'tsuru: "permission-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tpermission-list\n\tpermission-create\n\tpermission-remove\n\n'
    command = Command('tsuru permission-list', output)
    assert match(command)

# Generated at 2022-06-24 07:22:38.034149
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', ''))
    assert not match(Command('tsuru app-list', u'error: some error message'))



# Generated at 2022-06-24 07:22:45.849444
# Unit test for function get_new_command
def test_get_new_command():
    output ='tsuru: command not found: block\nDid you mean?\n\tblocks\n\tlogin\n\tlogout\n\ttarget-add\n\ttarget-remove\n\tuser-create\n\tversion'
    assert get_new_command(Command('bloc', '', output)) == 'blocks'
    output ='tsuru: "bla" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tblocks\n\tlogin\n\tlogout\n\ttarget-add\n\ttarget-remove\n\tuser-create\n\tversion'
    assert get_new_command(Command('bla', '', output)) == 'blocks'

# Generated at 2022-06-24 07:22:56.842958
# Unit test for function match
def test_match():
    # Positive case
    assert match({'output': 'tsuru: "user-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tuser-create'})
    # Negative case 1
    assert not match({'output': 'tsuru: "user-list" is not a tsuru command. See "tsuru help".'})
    # Negative case 2
    assert not match({'output': 'tsuru: "user-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?'})
    # Negative case 3

# Generated at 2022-06-24 07:22:59.424208
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('tsuru target-list', 'tsuru: "target" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-list')
    print(get_new_command(command))

# Generated at 2022-06-24 07:23:04.062954
# Unit test for function match
def test_match():
    assert match(Command('tsuru bla',
        '/bin/sh: tsuru: not found\n'
        'The program \'bla\' is currently not installed. You can install it by typing:\n'
        'sudo apt-get install bla'))


# Generated at 2022-06-24 07:23:12.189906
# Unit test for function match
def test_match():
    output = u'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\n\tDid you mean?\n\t\tapp-create\n\t\tapp-delete\n\t\tapp-info\n\t\tapp-list\n\t\tapp-log\n\t\tapp-rebuild\n\t\tapp-run\n\t\tapp-start\n\t\tapp-stop'
    assert match(Command('tsuru app-info', output=output))



# Generated at 2022-06-24 07:23:21.154678
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    command = type("command", (object,), {
        "output": '''tsuru: "node" is not a tsuru command. See "tsuru help".

Did you mean?
\tnode-add
\tnode-remove
\tnode-list'''
    })
    new_command = get_new_command(command)
    assert new_command == u'tsuru node-add'

    command = type("command", (object,), {
        "output": '''tsuru: "node" is not a tsuru command. See "tsuru help".

Did you mean?
\tnode-add
\tnode-remove
\tnode-list'''
    })
    new_command = get_new_command

# Generated at 2022-06-24 07:23:24.873268
# Unit test for function match
def test_match():
    # When match is True
    assert match(Command('tsruru app-create',
                         'tsuru: "tsruru" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create'))

    # When match is False
    assert not match(Command('tsuru app-list', 'tsuru: "tsuru" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', 'No such file or directory'))


# Generated at 2022-06-24 07:23:29.441979
# Unit test for function match
def test_match():
    command = Command(script='tsru', stdout='tsuru: "tsru" is not a tsuru command. See "tsuru help".\nDid you mean?\ntsuru')
    assert match(command)


# Generated at 2022-06-24 07:23:33.229380
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('tsuru', 'tsuru: "node" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-list\n')
    assert get_new_command(command) == 'tsuru node-list'

# Generated at 2022-06-24 07:23:39.382807
# Unit test for function match
def test_match():
    assert (match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-info\tinfo about an app')))
    assert (not match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n')))


# Generated at 2022-06-24 07:23:43.297913
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-liist',
                                   """tsuru: "app-liist" is not a tsuru command. See "tsuru
help".

Did you mean?
	app-list""", '', 1, '', '', '')).script == 'tsuru app-list'



# Generated at 2022-06-24 07:23:49.550705
# Unit test for function match
def test_match():
    assert match(Command('tsuru', 'tsuru zzzz'))
    assert not match(Command('tsuru h', 'tsuru h is not a tsuru command.'))
    assert not match(Command('tsuru', 'tsuru zzzz is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru', 'tsuru zzzz is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-list\n'))
    assert not match(Command('tsuru', 'tsuru zzzz is not a tsuru command. See "tsuru help".\nDid you mean?\n\thook-list\n'))

# Generated at 2022-06-24 07:23:57.882361
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\tapp-list-units\n\tapp-log\n\tapp-run'))
    assert not match(Command('tsuru app-list', ''))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".'))



# Generated at 2022-06-24 07:24:01.859198
# Unit test for function match
def test_match():
    """
    Test match function
    """
    assert match(Command('tsuru sada', 'tsuru: "sada" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tstatus'))
    assert not match(Command('git branch', ''))


# Generated at 2022-06-24 07:24:05.634447
# Unit test for function match
def test_match():
    test_com = type('Command', (), {})
    test_output = '''tsuru: "target-list" is not a tsuru command. See "tsuru help".

Did you mean?
\ttarget-add
\ttarget-remove'''

    test_com.output = test_output
    assert match(test_com)


# Generated at 2022-06-24 07:24:11.356113
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-lis', "tsuru: \"app-lis\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-list"))
    assert not match(Command('tsuru app-lis', "tsuru: \"app-lis\" is not a tsuru command."))



# Generated at 2022-06-24 07:24:13.410124
# Unit test for function match
def test_match():
    assert match(create_command('tsuru app-add test'))
    assert not match(create_command('git clone test'))


# Generated at 2022-06-24 07:24:24.667820
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-info app1', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list\n\tapp-log\n\tapp-run\n\tapp-unlock\n')) == 'tsuru app-list app1'
    assert get_new_command(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list\n\tapp-log\n\tapp-run\n\tapp-unlock\n')) == 'tsuru app-list'

# Generated at 2022-06-24 07:24:27.857552
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru help', 'tsuru: "help" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp-app\n\thelp-dockerfile\n\thelp-permission')) == 'tsuru help-app'

# Generated at 2022-06-24 07:24:31.899572
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-lis', 'Error: "app-lis" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list')) == 'tsuru app-list'

# Generated at 2022-06-24 07:24:37.666573
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "app-myapp" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tapp-create, app-info, app-list, app-remove'
    command = Command('tsuru app-myapp', output)
    assert get_new_command(command) == 'tsuru app-info'

# Generated at 2022-06-24 07:24:41.596553
# Unit test for function match
def test_match():
    command = Command('tsuru version', 'tsuru: "version" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tversion-list')
    assert match(command)



# Generated at 2022-06-24 07:24:46.653422
# Unit test for function get_new_command
def test_get_new_command():
	dummy_output = """tsuru: "app-info" is not a tsuru command. See "tsuru help".

Did you mean?
   app-create
   app-remove
   app-list"""

	dummy_command = type('', (object,), {'output': dummy_output})
	assert get_new_command(dummy_command) == 'tsuru app-list'

# Generated at 2022-06-24 07:24:50.442192
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru target-list', 'tsuru: "target-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-add\n\ttarget-remove')
    assert get_new_command(command) == 'tsuru target-add'

# Generated at 2022-06-24 07:24:55.417156
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "app" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps'
    expected = [('apps', 70)]
    assert expected == get_all_matched_commands(output)

    expected = "tsuru apps"
    assert get_new_command(Command(script = "", output = output)) == expected

# Generated at 2022-06-24 07:25:01.222368
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsur user-create',
                                   "tsuru: \"user-create\" is not a tsuru command. See \"tsuru help\"."
                                   "\nDid you mean?\n\tuser-add\n\tuser-remove\n\tuser-list\n\tteam-user-add\n\tteam-user-remove\n")) == 'tsur user-add'

# Generated at 2022-06-24 07:25:05.253517
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru command', 'tsuru: "command" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcommands\n\tcompletion\n\tdeploy-app\n\tswap\n\t')) == 'tsuru commands'



# Generated at 2022-06-24 07:25:10.983937
# Unit test for function match
def test_match():
	assert match(Command('tsuru hello',
						'\nERROR: "hello" is not a tsuru command. See "tsuru help". \n\nDid you mean?\n\t\nHelp topics, type "tsuru help topics" for more details:\n\ttsuru help\n',
						''))
	assert not match(Command('tsuru app-create myapp',
							 'app-create: Permission denied.\n',
							 ''))


# Generated at 2022-06-24 07:25:15.420547
# Unit test for function get_new_command
def test_get_new_command():
    output = r'tsuru: "foo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tfocom\n\tfoor'
    assert get_new_command(MagicMock(output=output)) == 'tsuru focom'

# Generated at 2022-06-24 07:25:19.402986
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    assert get_new_command('tsuru: "login" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tnode-add') == 'tsuru node-add'

# Generated at 2022-06-24 07:25:30.251670
# Unit test for function get_new_command
def test_get_new_command():
    original_command = 'tsuru app-create'
    cached_command = 'Command: tsuru app-create'

    output = 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n'\
             '\n'\
             'Did you mean?\n'\
             '\tapp-create\n'\
             '\tapp-remove\n'\
             '\tapp-restart\n'\
             '\n'\
             'Run tsuru app-create --help for usage.\n'\
             'tsuru version 1.4.1'
    command_output = CommandOutput(original_command, output, cached_command)

    assert get_new_command(command_output) == 'tsuru app-create'

# Generated at 2022-06-24 07:25:34.796749
# Unit test for function get_new_command
def test_get_new_command():
    command_output = ("tsuru: \"app-exec\" is not a tsuru command. See "
                      "\"tsuru help\".\n\nDid you mean?\n\tapp-run")

    assert get_new_command(Command("tsuru app-exec", "", command_output)) == \
        "tsuru app-run"

# Generated at 2022-06-24 07:25:41.407996
# Unit test for function match
def test_match():
    assert match(Command('tsuru somethingsomething',
                         'tsuru: "somethingsomething" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlog-add'))
    assert not match(Command('tsuru somethingsomething', 'tsuru: "somethingsomething" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru help somethingsomething', 'tsuru: "somethingsomething" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:25:49.935777
# Unit test for function match
def test_match():
    assert match(Command('tsuru help', 'tsuru: "help" is not a tsuru command. See "tsuru help".\nDid you mean?\n\thelp-app\n\thelp-ssh\n'))
    assert match(Command('tsuru help-app', 'tsuru: "help-app" is not a tsuru command. See "tsuru help".\nDid you mean?\n\thelp'))
    assert not match(Command('tsuru help-apps', 'tsuru: "help-apps" is not a tsuru command. See "tsuru help".'))
    assert not match(Command('tsuru help-app', 'tsuru: "help-app" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:25:55.805571
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru token-remove bla', 'tsuru: "token-remove" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tremove-token')
    assert get_new_command(command) == 'tsuru remove-token bla'

# Generated at 2022-06-24 07:26:01.650373
# Unit test for function get_new_command
def test_get_new_command():
    from collections import namedtuple
    Command = namedtuple('Command', ['script', 'output'])
    command = Command(script='tsuru giset', output='''tsuru: "giset" is not a tsuru command. See "tsuru help".

Did you mean?
	gist
	git
	gist-create
''')
    assert get_new_command(command) == 'tsuru gist'

# Generated at 2022-06-24 07:26:05.577711
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-devlopers app')) == 'tsuru app-deployed app'
    assert get_new_command(Command('tsuru app-deployed app')) == 'tsuru app-deployed app'

# Generated at 2022-06-24 07:26:15.389468
# Unit test for function match
def test_match():
    # Should match
    assert match(Command('tsuru app-info test -v',
                         'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-list\n\tapp-remove\n\tapp-update\n\n'))
    assert match(Command('tsuru service-bind mysql test',
                         'tsuru: "service-bind" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice-bind\n\tservice-create\n\tservice-unbind\n\tservice-update\n\n'))

# Generated at 2022-06-24 07:26:23.931184
# Unit test for function get_new_command
def test_get_new_command():
    import os
    import tempfile

    fd, temp_path = tempfile.mkstemp()
    # Create a temporary file
    with os.fdopen(fd, 'w') as f:
        f.write("""tsuru: "app-info" is not a tsuru command. See "tsuru help".

Did you mean?
        app-cname-list
        app-create
        app-list
        app-remove
        app-restart
        app-run""")

    expected_output = "tsuru app-info"
    assert get_new_command(temp_path) == expected_output

# Generated at 2022-06-24 07:26:26.810037
# Unit test for function match
def test_match():
	assert match(Command('tsuru add-key', 'tsuru: "add-key" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tadd-key\n\tadd-key-list'))


# Generated at 2022-06-24 07:26:32.784835
# Unit test for function match
def test_match():
    assert match(Command('tsuruu --help', "tsuru: \"tsuruu\" is not a tsuru command. See \"tsuru help\".")) == True
    assert match(Command('git bad', "tsuru: \"git\" is not a tsuru command. See \"tsuru help\".")) == False


# Generated at 2022-06-24 07:26:41.475542
# Unit test for function match
def test_match():
    #Test command mistyped
    command = Command('tsuru aplication-list', 'tsuru: "aplication-list" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\tapplication-list\n')
    assert match(command)
    #Test command not mistyped
    command = Command('tsuru aplication-list', 'tsuru: "aplication-list" is not a tsuru command')
    assert not match(command)
    #Test command syntax
    command = Command('tsuru', 'tsuru: "tsuru" is not a tsuru command. See "tsuru help".\n\n')
    assert not match(command)

# Generated at 2022-06-24 07:26:48.334953
# Unit test for function match
def test_match():
    # Should return False
    command_wrong = Command('tsuru app-list', '', '')
    assert not match(command_wrong)

    # Should return True
    command_wrong = Command('tsuru app-list', '', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-info\n\tapps-list')
    assert match(command_wrong)


# Generated at 2022-06-24 07:26:53.385421
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru paltform-add java',
                                   'tsuru: "paltform-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-add\n')) == 'tsuru platform-add java'

enabled_by_default = True

# Generated at 2022-06-24 07:26:58.812755
# Unit test for function get_new_command
def test_get_new_command():
    output = '''tsuru: "target-add" is not a tsuru command. See "tsuru help".

Did you mean?
	target-remove'''
    command = Command('target-add', output)
    assert get_new_command(command) == ['tsuru target-remove']

# Generated at 2022-06-24 07:27:02.277080
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".')) == 'tsuru app-list'

# Generated at 2022-06-24 07:27:04.203718
# Unit test for function match
def test_match():
    assert match(Command('tsrur', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-24 07:27:11.871754
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('tsuru app-deploy',
                                   output='tsuru: "app-deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-destroy\n\tapp-info\n\tapp-list\n\tapp-log\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-swap\n\tapp-update\n')) == 'tsuru app-create'

# Generated at 2022-06-24 07:27:16.178033
# Unit test for function match
def test_match():
    shell = Shell()
    command = Command('tsuru app-create myapp php', None)
    assert(match(command))
    command = Command('tsuru app-create myapp python', None)
    assert(not match(command))


# Generated at 2022-06-24 07:27:25.541293
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_didyoumean import get_new_command
    assert get_new_command(
        Command('tsuru app-move',
                'tsuru: "app-move" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-list')) == 'tsuru app-create'
    assert get_new_command(
        Command('tsuru app-move foo bar',
                'tsuru: "app-move" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-list')) == 'tsuru app-create foo bar'

# Generated at 2022-06-24 07:27:27.814234
# Unit test for function match
def test_match():
    assert match(Command('tsuru platform-add mysql', ''))
    assert not match(Command('tsuru help', ''))


# Generated at 2022-06-24 07:27:31.937120
# Unit test for function match
def test_match():
    assert match(Command(script='tsuru hello',
                         output='tsuru: "hello" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp\n\tdashboard\n\n'))


# Generated at 2022-06-24 07:27:37.060200
# Unit test for function match
def test_match():
    result = match(Command('tsuru hellotest', 'tsuru: "hellotest" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tcreate-app\n\tdelete-app\n\tapps-list\n\tapp-info'))
    assert result == True


# Generated at 2022-06-24 07:27:38.570427
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsurui', '')) == 'tsurui'

# Generated at 2022-06-24 07:27:48.974948
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert (get_new_command(Command('tsuru run python ../hello.py',
                                    'tsuru: "run" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tpermission-add\n\tuser-list\n\ttarget-set\n\tuser-remove\n\tuser-create\n'))
            == 'tsuru permission-add python ../hello.py')


# Generated at 2022-06-24 07:27:53.427055
# Unit test for function get_new_command
def test_get_new_command():
    output = '''tsuru: "remove-info" is not a tsuru command. See "tsuru help".

Did you mean?
	remove-keys

'''
    assert get_new_command(Command('tsuru remove-info', output)) == 'tsuru remove-keys'

# Generated at 2022-06-24 07:27:59.363131
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    command = Command('tsuru app-deploy .', 'tsuru: "app-deploy" is not a tsuru command.\n'
                                            'See "tsuru help".\n\n'
                                            'Did you mean?\n\tapp-deploy-sti',
                                            '', True, 1, Bash())
    assert get_new_command(command) == 'tsuru app-deploy-sti .'


enabled_by_default = False

# Generated at 2022-06-24 07:28:02.191076
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info', ''))
    assert not match(Command('tsuru help', ''))

