

# Generated at 2022-06-24 07:18:07.723099
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-info', 'tsuru: "service-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tservice-list'))


# Generated at 2022-06-24 07:18:11.090163
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('user-list', '', 'tsuru: "user-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tuser-list-users')) == 'tsuru user-list-users'

# Generated at 2022-06-24 07:18:14.323498
# Unit test for function match
def test_match():
	assert match(Command('tsuru ssh'))
	assert not match(Command('tsuru target-list'))
	assert not match(Command('ls'))


# Generated at 2022-06-24 07:18:19.377872
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
            {'output': 'tsuru: "app-deploy" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-deploy-host\n\tapp-deploy-unit'})
    assert 'tsuru app-deploy-host' == get_new_command(command)

# Generated at 2022-06-24 07:18:24.521847
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-create', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-add-unit\n\tapp-create-unit\n\tunit-add\n\tunit-create\n')
    assert get_new_command(command) == 'tsuru app-add-unit'


# Generated at 2022-06-24 07:18:31.816718
# Unit test for function get_new_command
def test_get_new_command():
    from tests.helpers import Command

    command = Command('tsuru aaa', 'tsuru: "aaa" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-add\n\tapp-list\n\tapp-remove\n\tapps-list\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-update\n\tapp-restart')
    assert get_new_command(command) == 'tsuru app-add'


enabled_by_default = True

# Generated at 2022-06-24 07:18:37.043320
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru unit-add git.com/app', '')) == 'tsuru service-add git.com/app'
    assert (get_new_command(Command('tsuru unit-add git.com/app', '')) !=
            get_new_command(Command('tsuru service-add git.com/app', '')))



# Generated at 2022-06-24 07:18:41.036473
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command(script='tsuru a',
                                   output='tsuru: "a" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-change-units')) == 'tsuru app-change-units')


enabled_by_default = True

# Generated at 2022-06-24 07:18:47.563564
# Unit test for function get_new_command
def test_get_new_command():
    import os
    # TODO: Add tests
    # os.environ['SHELL'] = 'bash'
    # assert (get_new_command([], 'yay is not a yay command', None)
    #         == 'sudo pacman -S yay')
    # assert (get_new_command([], 'elp is not a help command', None)
    #         == 'sudo pacman -S help2man')
    # assert (get_new_command([], 'mkdir /tmp/git/efgh', None)
    #         == 'mkdir -p /tmp/git/efgh')

# Generated at 2022-06-24 07:18:52.439135
# Unit test for function match
def test_match():
    broken_cmd = "tsuru: \"target-add\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\ttarget-add"
    command = Command(script=broken_cmd, output=broken_cmd)

    assert match(command)


# Generated at 2022-06-24 07:18:56.526843
# Unit test for function match
def test_match():
    assert match(Command('init', "tsuru: \"init\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tinit-token"))
    assert not match(Command('init', "tsuru: \"init\" is not a tsuru command. See \"tsuru help\"."))



# Generated at 2022-06-24 07:19:00.696274
# Unit test for function match
def test_match():
    assert match(Command('tsuru target-add', 'tsuru: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add'))


# Generated at 2022-06-24 07:19:02.011948
# Unit test for function match
def test_match():
	assert match(Command('tsru aaa', ''))


# Generated at 2022-06-24 07:19:06.672672
# Unit test for function get_new_command
def test_get_new_command():
    output = """tsuru: "login-git" is not a tsuru command. See "tsuru help".

Did you mean?
	login-gitlab
	login
	log
"""
    command = Command('tsuru login-git', output)
    assert get_new_command(command) == 'tsuru login-gitlab'



# Generated at 2022-06-24 07:19:14.815223
# Unit test for function get_new_command
def test_get_new_command():
    match(Command('tsuru target-add test http://localhost:8080 -s false -k',
                  output='tsuru: "target-ad" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\ttarget-add\n\n'))

    assert get_new_command(Command('tsuru target-add test http://localhost:8080 -s false -k',
        output='tsuru: "target-ad" is not a tsuru command. See "tsuru help".\n\n\nDid you mean?\n\ttarget-add\n\n')) == 'tsuru target-add test http://localhost:8080 -s false -k'



# Generated at 2022-06-24 07:19:17.207962
# Unit test for function match
def test_match():
    # Test match 1
    command_test = Command('tsuru pappas', '')
    assert match(command_test)

    # Test match 2
    command_test = Command('tsuru app create', '')
    assert match(command_test) == False


# Generated at 2022-06-24 07:19:20.369753
# Unit test for function match
def test_match():
    assert match(Command('tsuru service-doc', 'tsuru: "service-doc" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\t\tdocumentation'))


# Generated at 2022-06-24 07:19:25.649600
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(script="tsuru g app",
                                    output="tsuru: \"g\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tcreate-app\n\tapp-log\n"))
            == 'tsuru create-app app')


# Generated at 2022-06-24 07:19:32.313832
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    from tests.utils import CommandResult
    broken_cmd = 'tsuru permisions-list'
    output = 'tsuru: "permisions-list" is not a tsuru command. See "tsuru help".\n\
Did you mean?\n\tpermissions-list'
    command = Command(broken_cmd, CommandResult(stderr=output, error=1))
    assert get_new_command(command) == 'tsuru permissions-list'

# Generated at 2022-06-24 07:19:35.800653
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("tsuru: \"service-add\" is not a tsuru command. See \"tsuru help\".") == "tsuru service-add"

enabled_by_default = True

# Generated at 2022-06-24 07:19:41.754730
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create fake-app', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create'))
    assert not match(Command('tsuru app-create fake-app', 'tsuru: "app-create" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:19:45.782786
# Unit test for function get_new_command
def test_get_new_command():
  assert get_new_command(Command("tsuru admin-list-plans", "tsuru: \"admin-list-plans\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tadmin-list-plans\n")) == "tsuru admin-list-plans"


# Generated at 2022-06-24 07:19:51.699547
# Unit test for function match
def test_match():
    assert match('tsuruc: "tsuruc" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tcheck-data'
                 '\n\tcollect-data')
    assert not match('tsuruc: "tsuruc" is not a tsuru command. See "tsuru help".')


#Unit test for function get_new_command

# Generated at 2022-06-24 07:19:59.378238
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru target-add',
                                   'tsuru: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add\n\tapp-routes-set\n\tapp-ssh-host')) == 'tsuru target-add'
    assert get_new_command(Command('tsuru target-add',
                                   'tsuru: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-routes-set\n\tapp-ssh-host')) == 'tsuru target-add'

# Generated at 2022-06-24 07:20:04.097258
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("tsuru app-tsuru", "tsuru: \"app-tsuru\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp\n")) \
        == "tsuru app"

# Generated at 2022-06-24 07:20:10.992866
# Unit test for function match
def test_match():
    assert match(Command('tsuru ppp target-machine',  "tsuru: \"ppp\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tplatform-add\n\tplatform-remove\n\tplatform-update",  None))
    assert match(Command('tsuru app-plataform',  "tsuru: \"app-plataform\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-platform-add\n\tapp-platform-remove\n\tapp-platform-list",  None))


# Generated at 2022-06-24 07:20:21.433121
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('tsuru myapp-list',
                            '')) == 'tsuru app-list'
    assert get_new_command(Command('tsuru token-get',
                            'tsuru: "token-get" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttoken-add')) == 'tsuru token-add'
    assert get_new_command(Command('tsuru serv-get',
                            'tsuru: "serv-get" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tservice-add')) == 'tsuru service-add'

# Generated at 2022-06-24 07:20:31.769153
# Unit test for function match
def test_match():
    command = Command('tsuru status', '''tsuru: "status" is not a tsuru command. See "tsuru help".\n
Did you mean?\n
	status-container\n
	token-add\n
	token-remove\n
	token-show\n
	token-info\n
	token-regenerate''')
    assert match(command)
    command = Command('tsuru status', '''tsuru: "status" is not a tsuru command. See "tsuru help".\n
Did you mean?\n
	status-container\n
	token-add\n
	token-remove\n
	token-show\n
	token-info\n
	token-regenerate''')
    assert match(command)

# Generated at 2022-06-24 07:20:40.133294
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru ss -a myapp',
                      "tsuru: \"ss\" is not a tsuru command. "
                      "See \"tsuru help\".\n\nDid you mean?\n\tstart\n\tstop\n\tservice-list\n")
    assert get_new_command(command) == 'tsuru service-list -a myapp'
    command = Command('tsuru rr -a myapp',
                      "tsuru: \"rr\" is not a tsuru command. "
                      "See \"tsuru help\".\n\nDid you mean?\n\trun-as\n\trouter-remove\n")
    assert get_new_command(command) == 'tsuru run-as -a myapp'

# Generated at 2022-06-24 07:20:46.818737
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    output = """tsuru: "app-info" is not a tsuru command. See "tsuru help".

Did you mean?
        app-create
        app-list
        team-user-remove
        team-user-list
        user-create
        user-list
        team-remove
        team-list
        app-remove
        target-set
        target-remove
        app-grant"""
    command = Command("tsuru app-info", output)
    assert get_new_command(command) == "tsuru app-list"

# Generated at 2022-06-24 07:20:53.236387
# Unit test for function match
def test_match():
    assert match(Command('tsuru lsss', "tsuru: \"lsss\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tls\n"))
    assert not match(Command('tsuru ls', "tsuru: \"ls\" is not a tsuru command. See \"tsuru help\".\n\n"))
    assert not match(Command('tsuru ls', "tsuru: \"ls\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\t"))


# Generated at 2022-06-24 07:20:57.154708
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru app-create app',
        "tsuru: \"app\" is not a tsuru command. See \"tsuru help\"."
        "\n\nDid you mean?\n\tapp-create")) == 'tsuru app-create app'

# Generated at 2022-06-24 07:21:01.461188
# Unit test for function get_new_command
def test_get_new_command():
    command_output = 'tsuru: "node" is not a tsuru command. See "tsuru help".\n'\
                     '\nDid you mean?\n\tnode-list\n\tservice-node-list'
    command = Command('tsuru node', command_output)
    assert get_new_command(command) == "tsuru node-list"

# Generated at 2022-06-24 07:21:07.129077
# Unit test for function match
def test_match():
    # Wrong command
    assert not match(Command('tsuruuu app-create'))

    # Command does not exists
    output = "tsuru: \"tsuru uuu\" is not a tsuru command. See \"tsuru help\"."
    assert match(Command('tsuru uuu', output))

    # Command exists
    output = "tsuru: \"tsuru app-create\" is not a tsuru command. See \"tsuru help\"."
    assert not match(Command('tsuru app-create', output))


# Generated at 2022-06-24 07:21:15.758446
# Unit test for function match
def test_match():
    assert match(Command('tsru app-list paas',
                         'tsuru: "tsru" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list\n\n'))
    assert not match(Command('tsuru app-list paas',
                             'tsuru: "tsuru app-list paas" is not a tsuru command. See "tsuru help".\n'))
    assert not match(Command('tsuru app-list paas',
                             'tsuru: "tsuru app-list paas" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttoast\n\n'))



# Generated at 2022-06-24 07:21:18.927551
# Unit test for function match
def test_match():
    assert match(Command('tsuru help', 'tsuru: "help" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\thelp-app help-unit help'))


# Generated at 2022-06-24 07:21:22.801301
# Unit test for function get_new_command
def test_get_new_command():
    command=Command("tsuru platform-add some-plataform", "tsuru: \"platform-add\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tplatform-add\n\tplatform-create\n\tplatform-remove\n\tplatform-list\n\tplatform-update")
    assert(get_new_command(command) == "tsuru platform-add some-plataform")


# Generated at 2022-06-24 07:21:28.187184
# Unit test for function match
def test_match():
    assert match(Command('tsuruapp -v', 'tsuru: "tsuruapp" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapps\n'))
    assert not match(Command('tsurud', 'tsurud is not tsuru command. See "tsuru help".\n\nDid you mean?\n\ttsurud\n'))


# Generated at 2022-06-24 07:21:33.122247
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('tsuru app-list',
                             'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list')) == 'tsuru app-list'

    #assert not get_new_command(Command('tsuru app-list', 'foo bar'))



# Generated at 2022-06-24 07:21:37.113020
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru aaa', 'aa: "aaa" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp')
    assert get_new_command(command) == 'tsuru app'



# Generated at 2022-06-24 07:21:40.451419
# Unit test for function match
def test_match():
    assert match(Command('tsuru perm-user-set test@test.com test-app test:admin', ''))
    assert not match(Command('tsuru perm-user-set test@test.com test-app test:admin', 'tsuru: "perm-user-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tpermission-user-set'))


# Generated at 2022-06-24 07:21:42.044171
# Unit test for function match
def test_match():
    result = match('tsuru blah: "blah" is not a tsuru command.')
    assert result == True



# Generated at 2022-06-24 07:21:42.785054
# Unit test for function match

# Generated at 2022-06-24 07:21:48.191925
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-info')
    assert get_new_command(command) == 'tsuru app-create'


# Generated at 2022-06-24 07:21:54.434423
# Unit test for function match

# Generated at 2022-06-24 07:22:01.401253
# Unit test for function match
def test_match():
    output='''tsuru: "logs" is not a tsuru command. See "tsuru help".

Did you mean?
	lvm
	log
	logs-app'''
    # for_app() used in match() filters matches
    assert match(Command(script='tsuru logs', output=output))
    assert not match(Command(script='tsuru logs', output='not a tsuru command'))
    assert not match(Command(script='not-tsuru logs', output=output))



# Generated at 2022-06-24 07:22:05.181805
# Unit test for function match
def test_match():
    tsuru_out = 'tsuru: "app-plica" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-remove'
    assert match(Command(script=tsuru_out)) is True

# Generated at 2022-06-24 07:22:08.616880
# Unit test for function get_new_command
def test_get_new_command():
    output = """tsuru: "app-add" is not a tsuru command. See "tsuru help".


Did you mean?
	app-remove"""

    command = mock.Mock(output=output)
    assert get_new_command(command) == 'tsuru app-remove'

# Generated at 2022-06-24 07:22:14.379517
# Unit test for function get_new_command
def test_get_new_command():
    """ Example:
        $ tsuru plaff
        tsuru: "plaff" is not a tsuru command. See "tsuru help".

        Did you mean?
            platform-add
            platform-remove
    """

    def parse_output(command):
        return re.findall(r'tsuru: "([^"]*)" is not a tsuru command',
                          command.output)[0]

    cmd = MagicMock(output='tsuru: "plaff" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tplatform-add\n\tplatform-remove')
    assert get_new_command(cmd) == 'tsuru platform-add'


enabled_by_default = True

# Generated at 2022-06-24 07:22:24.356310
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean import get_new_command
    command = type('Command', (object,), {'script': 'tsuru app-list', 'output': """tsuru: "app-list" is not a tsuru command. See "tsuru help".

Did you mean?
        app-lock
        app-log
        app-remove
        app-restart
        app-run
        app-start
        app-stop
        app-swap
        app-unlock
        app-update

See "tsuru help" for more information.
"""})
    assert get_new_command(command) == 'tsuru app-list --help'

# Generated at 2022-06-24 07:22:30.449610
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('tsuru: "gimme" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tgimme-token\t\tReturns a valid token for an user.\n') == 'tsuru gimme-token'

# TODO: test for not a tsuru command
# 'tsuru: "gimme" is not a tsuru command. See "tsuru help".'

# Generated at 2022-06-24 07:22:34.369367
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("./tsuru env-set FOO=BAR",
                      "tsuru: \"env-set\" is not a tsuru command. See "
                      "\"tsuru help\".\n"
                      "\n"
                      "Did you mean?\n"
                      "\tset-env\n")
    assert get_new_command(command) == ["./tsuru set-env FOO=BAR"]

# Generated at 2022-06-24 07:22:42.580143
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsurui app-list')
    command.output = 'tsuru: "tsurui" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'
    assert get_new_command(command) == 'tsuru app-list'

    command = Command('tsuru version')
    command.output = 'tsuru: "version" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tversion'
    assert get_new_command(command) == 'tsuru version'


# Generated at 2022-06-24 07:22:48.908715
# Unit test for function match
def test_match():
    output='''tsuru: "heath" is not a tsuru command. See "tsuru help".

Did you mean?
\thelp'''
    output2='blabla: "unit-add" is not a tsuru command. See "tsuru help".'
    command = Command("env-set", output)
    assert match(command)
    command = Command("env-set", output2)
    assert not match(command)


# Generated at 2022-06-24 07:22:50.742231
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru foo', 'foo is not a tsuru command.\nDid you mean?\n\tApp')) == 'tsuru App'

# Generated at 2022-06-24 07:22:54.837859
# Unit test for function get_new_command
def test_get_new_command():
    command = types.Command('tsuru app-info app1',
                            'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info\n')
    assert get_new_command(command) == 'tsuru app-info app1'

# Generated at 2022-06-24 07:23:01.715701
# Unit test for function get_new_command

# Generated at 2022-06-24 07:23:08.310160
# Unit test for function get_new_command
def test_get_new_command():
    output1 = 'tsuru: "tsruu" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tsru'
    output2 = 'tsuru: "tsuru" is not a tsuru command. See "tsuru help".'
    command = type('Command', (object,),
                   {'script': 'tsuru', 'output': output1})
    assert "tsru" == get_new_command(command)
    command = type('Command', (object,),
                   {'script': 'tsuru', 'output': output2})
    assert "tsru" == get_new_command(command)


# Generated at 2022-06-24 07:23:10.086443
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-info'))



# Generated at 2022-06-24 07:23:15.660456
# Unit test for function match
def test_match():
	assert match(Command('tsuru foo bar', 'tsuru: "foo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tbar'))
	assert not match(Command('tsuru foo bar', 'tsuru: "foo" is not a tsuru command\n\nDid you mean?\n\tbar'))

# Generated at 2022-06-24 07:23:23.628806
# Unit test for function get_new_command

# Generated at 2022-06-24 07:23:28.451705
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create\n\tapp-remove\n\tapp-restart\n\tapp-run\n\tapp-start\n\tservice-add\n\tservice-bind\n\tservice-create\n\tservice-remove\n\tservice-remove-unit\n\tservice-status\n\tservice-unbind\n\n')) == True
    assert match(Command('tsuru app-list', '')) == False

# Generated at 2022-06-24 07:23:36.961898
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "token-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tpermission-add\n\tkey-add'
    command = type('', (), {'output': output})()
    assert get_new_command(command) == 'tsuru permission-add'

    output = 'tsuru: "target-remove" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-list'
    command = type('', (), {'output': output})()
    assert get_new_command(command) == 'tsuru target-list'

    output = 'tsuru: "target-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-remove'


# Generated at 2022-06-24 07:23:41.309643
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.tsuru_did_you_mean_this import get_new_command
    assert get_new_command(Command('tsurufoo bar')) == 'tsurufo bar'
    assert get_new_command(Command('tsuru foo bar')) == 'tsuru bar'


priority = 99999

# Generated at 2022-06-24 07:23:48.626777
# Unit test for function match
def test_match():
    assert match(Command('tsuru help a', 'tsuru: "help a" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-add\n\tapp-change-unit\n\tapp-info\n\tapp-list\n\tapp-remove\n\tapp-removeunit\n\tapp-run\n\tapp-start\n\tapp-stop\n\tapp-swap\n\tapp-units\n\tcreate-machine')) is True


# Generated at 2022-06-24 07:23:59.573242
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "tsuru app-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-info\n\tapp-list\n\tapp-remove\n\tapp-restart\n\tapp-start\n\tapp-stop'
    assert get_new_command(Command('tsuru app-add', output)) == ('tsuru app-create', [])
    output = 'tsuru: "tsuru target-add" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-remove'
    assert get_new_command(Command('tsuru target-add', output)) == ('tsuru target-remove', [])

# Generated at 2022-06-24 07:24:03.981030
# Unit test for function get_new_command
def test_get_new_command():
    output = """tsuru: "tsru" is not a tsuru command. See "tsuru help".

Did you mean?
	tsurud
	tsuru-server
	tsuru-admin
"""
    assert get_new_command('tsru', output) == 'tsurud'
    assert get_new_command('tsru', output) == 'tsurud'

# Generated at 2022-06-24 07:24:07.581015
# Unit test for function match
def test_match():
    assert not match(Command('tsuru help', ''))
    assert not match(Command('tsuru help', 'tsuru is help\nDid you mean?'))
    assert match(Command('tsuru help', 'tsuru is help\nDid you mean?\ntsuru app-list'))
    assert match(Command('tsuru app-create', 'tsuru app-create is help\ntsuru is help\nDid you mean?\ntsuru app-list'))



# Generated at 2022-06-24 07:24:13.289343
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-list',
                         'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-add\n\tapp-remove'))
    assert not match(Command('tsuru app-list', 'tsuru: "app-list" is not a tsuru command'))


# Generated at 2022-06-24 07:24:24.577323
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru app-list -a appName', 'tsuru: "app-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list, app-log, app-restart, app-start, app-stop, app-info, app-run, app-deploy, app-remove, app-create, app-grant, app-revoke, app-env-set, app-env-unset, app-env-get, app-info, app-log, app-run, app-deploy, app-remove, app-create, app-grant, app-revoke, app-env-set, app-env-unset, app-env-get')
    assert get_new_command(command) == 'tsuru app-list -a appName'

# Generated at 2022-06-24 07:24:31.034243
# Unit test for function match
def test_match():
    # Positive test
    assert match(Command('tsuru targ-list', "tsuru: \"targ-list\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\ttarget-list\n"))
    assert match(Command('tsuru targ-list', "tsuru: \"targ-list\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\ttarget-list\n\ttarget-get\n"))
    assert match(Command('tsuru targ-list', "tsuru: \"targ-list\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\ttarget-list\n\tlog-list\n\ttarget-get\n"))
    # Negative test

# Generated at 2022-06-24 07:24:36.989590
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.command_not_found import get_new_command
    new_command = get_new_command(Command('tsuru env-set', 'tsuru: "env-set" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tset-env', ''))
    assert new_command == 'tsuru set-env'

# Generated at 2022-06-24 07:24:46.896465
# Unit test for function match
def test_match():
    assert match(Command('tsuru user-list', 'tsuru: "user-list" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tuser-create\n\tuser-remove\n\tuser-set-quota\n\tuser-show', ''))
    assert match(Command('tsuru user-list', 'error: user-list is not a tsuru command', ''))
    assert not match(Command('tsuru user-list', 'tsuru: "user-list" is not a tsuru command. See "tsuru help".', ''))
    assert not match(Command('tsuru user-list', 'user-list is not a tsuru command. See "tsuru help".', ''))


# Generated at 2022-06-24 07:24:51.649520
# Unit test for function get_new_command
def test_get_new_command():
    output = ('tsuru: "create" is not a tsuru command. See "tsuru help".\n'
              '\n'
              'Did you mean?\n'
              '	create-app\n'
              '	create-certificate\n'
              '	create-key')
    new_command = 'tsuru create-app'
    assert new_command == get_new_command(Command('tsuru create', output))

# Generated at 2022-06-24 07:25:01.840799
# Unit test for function match
def test_match():
    assert match(Command('tsuru do something', ''))
    assert match(Command('tsuru do something',
                         'tsuru: "do" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tpermission-add\n\tpermission-app-add\n\tpermission-app-remove\n\tpermission-remove\n\tpermission-revoke\n\tpermission-set\n\tpermission-team-add\n\tpermission-team-remove\n\tperm-set\n\trole-add\n\trole-remove'))
    assert not match(Command('tsuru do something', 'tsuru: "do" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:25:09.759693
# Unit test for function match
def test_match():
    assert match(Command('tsuru create-team',
                         output='tsuru: "create-team" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcreate-token'))

# Generated at 2022-06-24 07:25:16.943914
# Unit test for function get_new_command
def test_get_new_command():
    output = (
        'tsuru: "node" is not a tsuru command. See "tsuru help".\n\n'
        'Did you mean?\n\tnode-add\n\tnode-exclude\n\tnode-list\n\tnode-update'
    )

    command = type('Obj', (object,), {"output": output})
    assert get_new_command(command) == 'tsuru node-add'

enabled_by_default = True

# Generated at 2022-06-24 07:25:18.607151
# Unit test for function match
def test_match():
    assert match(Command('tsuru first', ''))
    assert not match(Command('git commit', ''))



# Generated at 2022-06-24 07:25:25.438979
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command(\
                'tsuru app-info',\
                'tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-remove',\
                '')) == replace_command(Command(\
                'tsuru app-info',\
                'tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-remove',\
                ''), 'app-info', ['app-create', 'app-remove'])

# Generated at 2022-06-24 07:25:29.938267
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "test" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttest-file'
    command = type('Command', (object,), {'script': '', 'output': output})
    assert get_new_command(command) == 'tsuru test-file'

# Generated at 2022-06-24 07:25:33.132321
# Unit test for function match
def test_match():
    assert match(Command('stash pop', '', 'stash: "pop" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tpop'))


# Generated at 2022-06-24 07:25:37.795497
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-info'))
    assert not match(Command('tsuru app-info', 'tsuru: "app-info" is not a tsuru command. See "tsuru help".'))


# Generated at 2022-06-24 07:25:44.558466
# Unit test for function match
def test_match():
	assert match(Command('tsuru tset', 'tsuru: "tset" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttset'))
	assert match(Command('tsuru tset', 'tsuru: "tset" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttset\n\tte'))
	assert match(Command('tsuru tset', 'tsuru: "tset" is not a tsuru command. See "tsuru help".')) == False
	assert match(Command('tsuru tset', 'tsuru: tset is not a tsuru command. See tsuru help.')) == False


# Generated at 2022-06-24 07:25:48.553375
# Unit test for function match
def test_match():
    time_command = Command('tsuru time', 'tsuru: "time" is not a tsuru command. See "tsuru help".\nDid you mean?\n\ttarget-remove')

    assert match(time_command)

    wrong_command = Command('tsuru tim', 'tsuru: "tim" is not a tsuru command. See "tsuru help".')

    assert not match(wrong_command)



# Generated at 2022-06-24 07:25:54.273064
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "app-lis" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-list\n\tapp-log\n\tapp-run\n\tapp-info'
    command = Command("app-lis", output)
    assert get_new_command(command) == 'tsuru app-list'

# Generated at 2022-06-24 07:26:02.031043
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('tsuru: "target-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\ttarget-add\n') == 'tsuru target-add'
    assert get_new_command('tsuru: "event-add" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tevent-add\n') == 'tsuru event-add'
    assert get_new_command('tsuru: "team-remove" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tteam-remove\n') == 'tsuru team-remove'

# Generated at 2022-06-24 07:26:03.352178
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuruu env-get', '')
    assert get_new_command(command) == 'tsuru env-get'


enabled_by_default = True

# Generated at 2022-06-24 07:26:08.145792
# Unit test for function match
def test_match():
  from thefuck.types import Command
  assert match( Command('tsuruu app-create', 'tsuru: "tsuruu" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-deploy\n\tapp-remove\n\tapp-info') )
  assert match( Command('tsuruu app-cratey', 'tsuru: "tsuruu" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp-create\n\tapp-deploy\n\tapp-remove\n\tapp-info') )

# Generated at 2022-06-24 07:26:10.862997
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.specific.tsuru import get_new_command

    assert get_new_command('tsuru: "sad" is not a tsuru command. See "tsuru help".',
                           '\nDid you mean?\n\tservice-add') == 'tsuru service-add '

# Generated at 2022-06-24 07:26:13.690107
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-infow foo bar baz', "tsuru: \"app-infow\" is not a tsuru command. See \"tsuru help\".\n\nDid you mean?\n\tapp-info"))


# Generated at 2022-06-24 07:26:24.138363
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    output = "tsuru: \"tsruu\" is not a tsuru command. See \"tsuru help\".\nDid you mean?\n\tservice-add\n\tservice-bind\n\tservice-doc\n\tservice-info\n\tservice-instance-add\n\tservice-instance-remove\n\tservice-instance-status-set\n\tservice-list\n\tservice-remove\n\tservice-status\n\tservice-unbind"
    newcommand = get_new_command(Command(output=output))
    assert newcommand == "tsuru service-add"

# Generated at 2022-06-24 07:26:35.760027
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('tsuru status', 'tsuru: "status" is not a tsuru command')
    assert get_new_command(command) == ['tsuru status-autoscale', 'tsuru status-quota']

    command = Command('tsuru status', 'tsuru: "statu" is not a tsuru command')
    assert get_new_command(command) == []

    command = Command('tsuru status',
                      ('tsuru: "status" is not a tsuru command.\n'
                       'Did you mean?\n'
                       '\tstatus-autoscale\n'
                       '\tstatus-quota'))
    assert get_new_command(command) == ['tsuru status-autoscale', 'tsuru status-quota']


# Generated at 2022-06-24 07:26:43.553092
# Unit test for function match
def test_match():
    match_result = match(Command('tsuru help papp', ''))
    assert match_result
    match_result = match(Command('tsuru help papp', 'tsuru: "papp" is not a tsuru command.'))
    assert match_result
    match_result = match(Command('tsuru help papp', 'tsuru: "papp" is not a tsuru command. See "tsuru help".'))
    assert match_result
    match_result = match(Command('tsuru help papp', 'tsuru: "papp" is not a tsuru command. See "tsuru help".\nDid you mean?\n\tapp'))
    assert match_result


# Generated at 2022-06-24 07:26:49.411856
# Unit test for function get_new_command
def test_get_new_command():
    output = 'tsuru: "reovke" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\trevoke'
    command = Command('tsuru reovke -a ap1 admin1@email.com', output)
    assert get_new_command(command) == 'tsuru revoke -a ap1 admin1@email.com'

# Generated at 2022-06-24 07:26:55.986870
# Unit test for function get_new_command
def test_get_new_command():
    assert ('tsuruyoyo' in get_new_command(Command('tsuruyoyo' + ' ' + 'parameter',
                       'tsuru: "tsuruyoyo" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp\n\tapp-create\n\tapp-delete\n\tapp-list\n\tapp-log',
                       'desired output')))

# Generated at 2022-06-24 07:26:58.372250
# Unit test for function get_new_command
def test_get_new_command():
    command = 'tsuru: "c" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tcreate\n\n'
    assert get_new_command(command) == 'tsuru create'

# Generated at 2022-06-24 07:27:03.164914
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-lits', 'tsuru: "app-lits" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-list'))
    assert not match(Command('tsuru app-list', ''))


# Generated at 2022-06-24 07:27:14.175901
# Unit test for function match
def test_match():
    output_is_not_tsuru_command = "tsuru: \"tsruss\" is not a tsuru command. See \"tsuru help\"."
    output_is_not_tsuru_command_suggestions = """tsuru: "tsruss" is not a tsuru command. See "tsuru help".


Did you mean?
	tsuru service-instance
	tsuru service-list
	tsuru service-remove
	tsuru service-update
	tsuru service-doc
	tsuru service-template
	tsuru service-bind
	tsuru service-unbind"""

    assert not match(Command('tsruss', output=output_is_not_tsuru_command))
    assert match(Command('tsruss', output=output_is_not_tsuru_command_suggestions))



# Generated at 2022-06-24 07:27:18.737479
# Unit test for function match
def test_match():
    script = ("tsuru: \"autoscale-run\" is not a tsuru command. See \"tsuru help\"."
              "\n\nDid you mean?\n\tautoscale-run-once\n\tautoscale-set\n")

    assert match(Command(script, ""))


# Generated at 2022-06-24 07:27:26.119488
# Unit test for function match
def test_match():
    # It should return False if command ran successfully
    assert not match(Command('tsuru target-list', ''))

    # It should return False if no suggestion in output
    output = '''tsuru: "mycmd" is not a tsuru command. See "tsuru help".'''
    assert not match(Command('some command', output))

    # It should return True if suggestions are found
    output = '''tsuru: "mycmd" is not a tsuru command. See "tsuru help".
\nDid you mean?
        mycmd1
        mycmd2'''
    assert match(Command('tsuru mycmd', output))


# Generated at 2022-06-24 07:27:31.532689
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'tsuru app-create',
                    'output': 'tsuru: "app-create" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tapp-create'})
    assert get_new_command(command) == 'tsuru app-create'

# Generated at 2022-06-24 07:27:38.360404
# Unit test for function match
def test_match():
    assert match(Command('tsuru adm-platfom', 'tsuru: "adm-platfom" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tlist-platforms'))
    assert not match(Command('tsuru adm-platfom', 'tsuru: "adm-platfom" is not a tsuru command. See "tsuru help".'))



# Generated at 2022-06-24 07:27:44.077904
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-create myapp',
                         'tsuru: "app-createe" is not a tsuru command. See\
                         "tsuru help".\n\nDid you mean?\n\tapp-create'))
    assert not match(Command('tsuru app-create myapp', 'Created app "myapp"'))


# Generated at 2022-06-24 07:27:48.113950
# Unit test for function match
def test_match():
    assert match(Command('tsuru app-creaate dac', ''))
    assert not match(Command('tsuru app-creaate dac',
                             'tsuru: "app-creaate" is not a tsuru command. See "tsuru help".'))



# Generated at 2022-06-24 07:27:52.806478
# Unit test for function get_new_command
def test_get_new_command():
    output = """tsuru: "tsuru login" is not a tsuru command. See "tsuru help".

Did you mean?
	login-ssh"""
    assert get_new_command(Command('tsuru login', output)) == 'tsuru login-ssh'

# Generated at 2022-06-24 07:27:54.678047
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('tsuru command-does-not-exist', '')) == 'tsuru commands-list'

# Generated at 2022-06-24 07:27:59.440234
# Unit test for function match
def test_match():
    command = Command('tsuru app-info',
                      'tsuru: "app-info" is not a tsuru command.'
                      ' See "tsuru help".\n\n'
                      'Did you mean?\n\tapp-create\n\tapp-delete\n\tapp-list')
    assert match(command)
    assert get_new_command(command) == 'tsuru app-list'

# Generated at 2022-06-24 07:28:00.883531
# Unit test for function match
def test_match():
    command = 'tsurur mongo-list --app myapp'
    assert match(command)


# Generated at 2022-06-24 07:28:05.392642
# Unit test for function match
def test_match():
    # Unit test for function match
    assert match(Command('tsuru status', 'tsuru: "status" is not a tsuru command. See "tsuru help".\n\nDid you mean?\n\tstatus-app\n\tstatus-container\n'))
    assert not match(Command('', ''))

