

# Generated at 2022-06-11 17:24:14.420475
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = object()
    globals = {'a': 'A'}
    locals = {'b': 'B'}
    j2_vars_obj = AnsibleJ2Vars(templar, globals, locals)
    # test value in globals
    assert 'a' in j2_vars_obj
    # test value in locals
    assert 'b' in j2_vars_obj
    # test value in Templar
    j2_vars_obj._templar.available_variables = {'c': 'C'}
    assert 'c' in j2_vars_obj
    # test value not defined
    assert 'd' not in j2_vars_obj

# Generated at 2022-06-11 17:24:15.740398
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass


# Generated at 2022-06-11 17:24:25.463034
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None, shared_loader_obj=None, vault_password='password',
                      basedir='/foo', environment=None)
    templar.available_variables = {'a': 'ansible'}
    globals = {'g': 'globals'}
    locals = {'l': 'locals'}

    aj2v = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-11 17:24:32.413679
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    Test of method __len__ of class AnsibleJ2Vars

    Specific test:
    test_AnsibleJ2Vars___len__:test_AnsibleJ2Vars___len__ #1

    :param self:
    :return:
    """
    import ansible.vars.hostvars
    templar = AnsibleJ2Vars


# Generated at 2022-06-11 17:24:39.866803
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Tests for method __contains__ of class AnsibleJ2Vars
    from ansible.template import Templar

    # Basic test
    m = AnsibleJ2Vars(Templar(), {'var1': 'ABC'})
    assert 'var1' in m
    assert 'var2' not in m
    assert 'var3' not in m

    # Test with locals
    m = AnsibleJ2Vars(Templar(), {'var1': 'ABC'}, locals={'var2': 'DEF', 'var3': 'GHI'})
    assert 'var1' in m
    assert 'var2' in m
    assert 'var3' in m



# Generated at 2022-06-11 17:24:50.695891
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # Test data
    templar = None
    globals = {'gvar': 123}
    locals = {'lkey': 'lvalue'}
    vars_dic = {'key1': 'value1', 'key2': 'value2'}

    from ansible.vars.hostvars import HostVars
    hostvars = HostVars()
    for key, val in iteritems(vars_dic):
        hostvars[key] = val

    # Create object
    obj = AnsibleJ2Vars(templar, globals, locals)
    obj._templar = type('templar', (), vars_dic)
    obj._templar.available_variables = vars_dic
    obj._globals.update(vars_dic)
    obj._

# Generated at 2022-06-11 17:24:55.517428
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    locals = None

    templar = None
    globals = {'aaa':1, 'bbb':2}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'aaa' in j2vars
    assert 'xxx' not in j2vars


# Generated at 2022-06-11 17:25:02.959275
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class HostVars(object):
        def __init__(self):
            self.__UNSAFE__ = True
    class Templar(object):
        def __init__(self):
            self.available_variables = {'vars': {'foo': 'bar'}, 'vars1': {'foo': 'bar'}}
        def template(self, variable):
            return variable
    class AnsibleUndefinedVariable(object):
        def __init__(self, msg):
            self.message = msg

    # Variable 'vars'
    vars_ = {'vars': HostVars()}
    jvars = AnsibleJ2Vars(Templar(), {}, locals=vars_)
    assert jvars['vars'] == vars_['vars']
    # Variable 'vars' which value is

# Generated at 2022-06-11 17:25:09.878016
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    tmp = dict()
    tmp.update(globals())
    tmp['self'] = tmp
    for k, v in iteritems(tmp):
        if k == 'self' or k == 'tmp':
            continue
        print(k)

    print(len(tmp))
    print(len(iter(tmp)))
    print(len(AnsibleJ2Vars(None, None, None)))

if __name__ == '__main__':
    test_AnsibleJ2Vars___len__()

# Generated at 2022-06-11 17:25:20.519938
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template.safe_eval import ansible_safe_eval

    class MockTemplar():
        available_variables = {'a':3, 'b':4, 'c':5, 'd':6}
        def template(self, to_be_templated):
            return to_be_templated

    globals_dict = {'e': 7, 'f': 8}
    locals_dict = {'g': 9, 'h': 10}

    t = MockTemplar()
    proxy = AnsibleJ2Vars(t, globals_dict, locals_dict)

    # Test with a simple number
    assert len(proxy) == 8, "Wrong number of elements"

# Generated at 2022-06-11 17:25:35.276312
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext 
    from ansible.template import Templar 
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.module_utils.common._collections_compat import Mapping
    from jinja2.utils import missing

    vars = dict(
        dict_var = dict(key = "value"),
        list_var = ["value0", "value1"],
        str_var = "hello, world",
        int_var = 13579,
        float_var = 3.14159,
    )

    variable_manager = VariableManager()
    variable_manager.extra_vars.update(vars)
    inventory = InventoryManager(loader=None, sources='localhost,')
    play_context = PlayContext()

   

# Generated at 2022-06-11 17:25:47.257128
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-11 17:25:54.895113
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.plugins.loader import add_all_plugin_dirs

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    play_context = PlayContext()
    variable_manager.set_inventory(inventory)

    add_all_plugin_dirs()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=False)

    x = AnsibleJ2Vars(templar, {'foo': 'bar'})

# Generated at 2022-06-11 17:26:02.465132
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test case 1
    # input:  varname = 'ansible_test'
    #         varname not in _locals
    #         varname in _templar.available_variables
    #         varname not in _globals
    varname = 'ansible_test'
    templar = 'templar_test'
    globals = {}
    locals = {}
    available_variables = {varname: 'test'}
    templar.available_variables = available_variables
    vars = AnsibleJ2Vars(templar, locals, globals)
    assert 'test' == vars.__getitem__(varname)

    # Test case 2
    # input:  varname = 'l_ansible_test'
    #         varname in _locals


# Generated at 2022-06-11 17:26:10.957695
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    input_globals = {
        'foo': 'bar',
    }
    input_locals = {
        'l_baz': 'qux',
    }

    vars_proxy = AnsibleJ2Vars(Templar(play_context=PlayContext()), globals=input_globals, locals=input_locals)

    # Make sure the iteration by AnsibleJ2Vars.__iter__ is the same
    # as the iteration by iterkeys in AnsibleJ2Vars.__getitem__
    for key in vars_proxy:
        assert key in vars_proxy
        assert vars_proxy[key] == vars_proxy.__getitem__(key)

    # Make sure that the

# Generated at 2022-06-11 17:26:22.145862
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template import Templar
    import os

    j2v = AnsibleJ2Vars(
        Templar(
            get_basedir=lambda: os.getcwd()
        ), {}, dict(
            l_group_names=['group1', 'group2'],
            l_groups=dict(
                all=['group1', 'group2'],
                group1=['host1', 'host2'],
                group2=['host3', 'host4'],
                none=[]
            ),
            l_host_names=['host1', 'host2', 'host3', 'host4'],
            l_group_names_no_none=['group1', 'group2']
        )
    )

# Generated at 2022-06-11 17:26:30.985280
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar()

    vars = {'v': 'v'}
    h = HostVars(vars)
    u = AnsibleUnsafeText(vars)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals={'g': 'g'},
                                    locals={'l_l': 'l_l', 'h': h, 'u': u})

    assert 'v' in ansible_j2_vars
    assert 'g' in ansible_j2_vars
    assert 'l_l' in ansible_j2_vars

# Generated at 2022-06-11 17:26:40.987262
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(None)
    globals = {'foo': 'bar', 'testing': 'test'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    templar.available_variables = {'ansible_facts': {}, 'group_names': ['testing']}
    assert len(j2vars) == 3, "len(j2vars) should return 3, but it returned: %s" % len(j2vars)


# Generated at 2022-06-11 17:26:53.482644
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.unsafe_proxy import wrap_var
    wrap_var(dict(a=1), 'a')[0]
    wrap_var(dict(b=1), 'b')[0]
    wrap_var(dict(c=1), 'c')[0]

    import jinja2

    env = jinja2.Environment(undefined=jinja2.StrictUndefined)
    assert not env.from_string("{{ a }}").render(a=1)

    t = '''\
{% if a is missing %}
a is missing
{% elif b is missing %}
b is missing
{% elif c is defined %}
c is defined
{% else %}
no
{% endif %}'''


# Generated at 2022-06-11 17:27:04.443247
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from jinja2 import Environment
    from .templar import Templar
    templar = Templar(loader=None, variables={})
    locals = {'local_var': 'value1'}
    globals = {'global_var': 'value2'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # test lookup success
    assert ansible_j2_vars['local_var'] == 'value1'
    assert ansible_j2_vars['global_var'] == 'value2'

    # test lookup failure KeyError
    try:
        ansible_j2_vars['unknown_var']
    except KeyError as e:
        assert str(e) == "undefined variable: unknown_var"
    else:
        assert False #

# Generated at 2022-06-11 17:27:16.058100
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # Getting the module object.
    from ansible.plugins.loader import module_loader

    # Getting the object to test.
    from ansible.template.vars import AnsibleJ2Vars

    # Initializing the test object.
    obj = AnsibleJ2Vars(
        module_loader._create_template_environment(),
        globals=dict(),
        locals=dict(),
    )

    # Performing the test.
    for key in obj:
        pass

    # No errors during test.
    assert True

# Generated at 2022-06-11 17:27:22.824103
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    templar = Templar(variable_manager=VariableManager())
    assert 'key' not in AnsibleJ2Vars(templar, {})
    assert 'key' not in AnsibleJ2Vars(templar, {'key': 'value'})
    assert 'key' in AnsibleJ2Vars(templar, {'key': missing})


# Generated at 2022-06-11 17:27:32.232040
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved
    import ansible.module_utils.common._collections_compat

    j2_env = Environment(trim_blocks=True)
    templar = Templar(loader=None, variables={})
    globals_dict = dict()
    globals_dict['str1'] = 'str1'
    globals_dict['str2'] = 'str2'
    globals_dict['l_str3'] = 'str3'
    globals_dict['l_str4'] = 'str4'
    vars_proxy = AnsibleJ2Vars(templar, globals_dict)

# Generated at 2022-06-11 17:27:37.960677
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Test __contains__ function of class AnsibleJ2Vars.
    '''

    j = object()
    g = object()
    l = object()

    m = AnsibleJ2Vars(j, g, l)
    assert j == m._templar
    assert g == m._globals
    assert l == m._locals

# Generated at 2022-06-11 17:27:46.609603
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Just test some cases here, since __getitem__() is rather huge
    # and most cases are tested somewhere else anyway

    # Test access to item in templar
    templar = object()
    templar.available_variables = {'foo': 'bar'}
    j2vars = AnsibleJ2Vars(templar, {'bar': 'baz'})
    assert j2vars['foo'] == 'bar'

    # Test access to item in locals
    j2vars = AnsibleJ2Vars(templar, {'bar': 'baz'}, locals={'foo': 'qux'})
    assert j2vars['foo'] == 'qux'

    # Test access to item in globals

# Generated at 2022-06-11 17:27:52.203122
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class Templar(object):
        def __init__(self, available_variables):
            self.available_variables = available_variables

        def template(self, s):
            return s

    templar = Templar({'a': '1', 'b': '2', 'c': '3'})

    # test __contains__
    assert 'a' in AnsibleJ2Vars(templar, {'x': 'X'})
    assert 'x' in AnsibleJ2Vars(templar, {'x': 'X'})
    assert 'y' not in AnsibleJ2Vars(templar, {'x': 'X'})

    # test __iter__

# Generated at 2022-06-11 17:27:56.136178
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    locals = "test"
    globals = "test"
    templar = "test"
    v = AnsibleJ2Vars(templar,globals,locals)
    assert (v.__contains__() == True)
    assert (v.__contains__() == True)
    assert (v.__contains__() == True)
    

# Generated at 2022-06-11 17:28:04.228814
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict(foo='bar')
    locals = dict(boo='far')

    assert 'boo' in locals and 'foo' in globals

    context = AnsibleJ2Vars(templar, globals, locals)

    assert 'boo' in context
    assert 'foo' in context
    assert len(context) > 0

    for var in context:
        assert len(var) > 0

# Generated at 2022-06-11 17:28:12.403491
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import unittest
    import jinja2
    import ansible.inventory.host as host
    import ansible.vars.hostvars as hostvars
    import ansible.vars.unsafe_proxy as unsafe_proxy
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    class TestVars(object):
        def __init__(self, hosts=None, variables=None):
            hostvars._HOSTVARS = dict()

            if hosts is None:
                hosts = dict()

            if variables is None:
                variables = dict()

            self._hosts = hosts
            self._variables = variables


# Generated at 2022-06-11 17:28:24.058109
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, dict())
    j2vars._templar.available_variables = {
        'item': {
            'key1': 'value1',
            'key2': 'value2',
        },
        'vars': {
            'key1': 'value1',
            'key2': 'value2',
        },
    }
    assert j2vars['item'] == {'key1': 'value1', 'key2': 'value2'}
    assert j2vars['vars'] == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-11 17:28:40.844392
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    proxy = AnsibleJ2Vars()
    assert hasattr(proxy, '__iter__')


# Generated at 2022-06-11 17:28:46.224465
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = {}
    globals = {}
    locals = None

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars is not None
    assert ansible_j2_vars.__getitem__('test') == None

# Generated at 2022-06-11 17:28:55.625718
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    import sys
    import copy
    import pytest
    from ansible.vars import combine_vars
    from ansible.vars.hostvars import HostVars

    # Create an environment without AnsibleUndefinedVariable exception
    templar = AnsibleJ2Vars(
        templar=combine_vars(hostvars=HostVars())
    )

    # Test for keys that __contains__ should return True

# Generated at 2022-06-11 17:29:07.227398
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import sys
    if sys.version_info > (3, 0):
        # Python 3 code in this block
        from ansible.vars import HostVars
        from ansible.utils.vars import combine_vars
        from ansible.template import Templar
        from ansible.template import Display
        from ansible.vars.group_vars import GroupVars

        templar = Templar(loader=None, variables={})
        group_vars = GroupVars(templar)
        host_vars = HostVars(templar, group_vars)
        combined_vars = combine_vars(host_vars, group_vars)
        ansible_j2_vars = AnsibleJ2Vars(templar, combined_vars)


# Generated at 2022-06-11 17:29:11.109704
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
  from ansible.template import Templar
  templar = Templar(loader=None)
  vars = AnsibleJ2Vars(templar, {'a': 1}, {'b': 2})
  assert 'b' in vars


# Generated at 2022-06-11 17:29:23.030243
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import os

    basedir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    dataloader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.extra_vars = {"test_extra_vars": "test_extra_vars"}
    variable_manager.options_vars = {"test_options_vars": "test_options_vars"}

# Generated at 2022-06-11 17:29:32.101952
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    print("Test constructor of class AnsibleJ2Vars")
    globals_test={"global_key1":"global_value1", "global_key2":"global_value2"}
    locals_test={"local_key1":"local_value1", "local_key2":"local_value2"}
    templar_test={}
    j2var=AnsibleJ2Vars(templar_test, globals_test, locals_test)
    assert j2var._globals==globals_test
    assert j2var._locals.keys()== locals_test.keys()
    assert j2var._locals.values()== locals_test.values()
    #print("Dictionary %s" % j2var._locals)
    # Check dictionary
    key1_exist=False
    key2_

# Generated at 2022-06-11 17:29:43.827570
# Unit test for method __len__ of class AnsibleJ2Vars

# Generated at 2022-06-11 17:29:46.286234
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    a = AnsibleJ2Vars(Templar(), {'a':1})
    assert len(a) == 1


# Generated at 2022-06-11 17:29:57.519131
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    print()
    print('TEST: class AnsibleJ2Vars, method __contains__')

    # imports
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Create templar
    loader = DataLoader()
    templar = Templar(loader=loader)

    # Create globals
    j2_globals = dict()
    j2_globals['ansible'] = dict()
    j2_globals['ansible']['version'] = dict()
    j2_globals['ansible']['version']['full'] = '1.2.3'

    # Create locals
    j2_locals = dict()
    j2_locals['var1'] = 123

# Generated at 2022-06-11 17:30:27.814567
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass


# Generated at 2022-06-11 17:30:31.892960
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    #initialize the class with parameters
    var = AnsibleJ2Vars(Templar(), {}, {})
    #assert the class variables
    assert var._globals == {}
    assert var._locals == {}

# Generated at 2022-06-11 17:30:36.263437
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ansibleJ2Vars = AnsibleJ2Vars(templar=None,
                                  globals={'testVariable1': 'testValue1', 'testVariable2': 'testValue2', 'testVariable3': 'testValue3'})
    assert len(ansibleJ2Vars) == 3



# Generated at 2022-06-11 17:30:42.910735
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()

    ansible_j2_vars = AnsibleJ2Vars(templar, {'a': 'b'})

    # To test the KeyError exception
    try:
        ansible_j2_vars['test']
    except KeyError as e:
        assert(str(e) == 'test')

    # To test the return value
    assert(ansible_j2_vars['a'] == 'b')


# Generated at 2022-06-11 17:30:54.784310
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Test with empty values
    ansible_j2_vars_instance = AnsibleJ2Vars(None, None)
    len_ansible_j2_vars_instance = len(ansible_j2_vars_instance)
    assert len_ansible_j2_vars_instance >= 0

    # Test with valid values
    ansible_j2_vars_instance = AnsibleJ2Vars(None, {'key': 'value'})
    len_ansible_j2_vars_instance = len(ansible_j2_vars_instance)
    assert len_ansible_j2_vars_instance == 1

    ansible_j2_vars_instance = AnsibleJ2Vars(None, {'key1': 'value1', 'key2': 'value2'})
   

# Generated at 2022-06-11 17:31:06.107889
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    test for __contains__
    '''
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.hostvars import HostVars

    templar = Templar(unsafe_proxy=True)
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}

# Generated at 2022-06-11 17:31:11.530991
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables=None)
    local_vars = dict(a=1)
    globals = dict()
    v = AnsibleJ2Vars(templar, globals, locals=local_vars)
    assert 'a' in v
    assert 'b' not in v



# Generated at 2022-06-11 17:31:17.127232
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.templating import Templar
    templar = Templar(loader=None, variables={'a': 1})
    globals = {'b': 2}
    locals = {'c': 3}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert(vars['a'] == 1)
    assert(vars['b'] == 2)
    assert(vars['c'] == 3)

# Generated at 2022-06-11 17:31:28.438274
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    try:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    except ImportError:
        from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    def __vc(templar, globals, locals, varname):
        vars = AnsibleJ2Vars(templar, globals, locals)
        return varname in vars
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    vm = VariableManager()
    t = Templar(None, vm)
    globals = {'gv': 'x'}
    locals = {'lv': 'y', 'l_': 'z'}
    vm.set_available_variables(t.available_variables)
    vm.set_variable('av', 'a')
    vm

# Generated at 2022-06-11 17:31:39.368746
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'foo': 'bar'})
    globals = dict()
    locals = dict()
    proxy = AnsibleJ2Vars(templar, globals, locals)

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    error = False
    try:
        proxy['not_exist']
    except KeyError:
        error = True
    assert error

    value = proxy['foo']
    assert isinstance(value, (basestring, AnsibleUnsafeText))
    assert value == 'bar'

    # HostVars is special, return it as-is
    hostvars = HostVars(inventory=None, hostname='localhost')
    proxy

# Generated at 2022-06-11 17:32:46.106108
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import ansible_safe_eval

    templar = Templar(loader=None)
    globals = {
        "test_global_var": True
    }
    locals = {
        "test_local_var": True
    }
    vars_ = AnsibleJ2Vars(templar, globals, locals)

    assert "test_global_var" in vars_
    assert "test_local_var" in vars_



# Generated at 2022-06-11 17:32:50.161629
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    t = Templar(variable_manager=None, loader=None)
    my_dict = AnsibleJ2Vars(t, {})
    assert 'foo' in my_dict


# Generated at 2022-06-11 17:32:57.711732
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.hostvars import HostVars
    templar = Templar()
    vars = AnsibleJ2Vars(templar, {})
    assert vars['dict'] == dict
    assert vars['hostvars'] == HostVars
    assert vars['to_native'] == to_native
    assert vars['AnsibleUnicode'] == AnsibleUnicode

# Generated at 2022-06-11 17:33:09.247442
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.ajson import AnsibleJSONEncoder

    templar = Templar(loader=DictDataLoader({}), variables={})
    proxy = AnsibleJ2Vars(templar, {}, locals={})
    assert 'a_string' not in proxy
    assert 'a_unicode' not in proxy
    assert 'a_list' not in proxy
    assert 'a_dict' not in proxy
    assert 'a_number' not in proxy
    assert 'a_bool' not in proxy


# Generated at 2022-06-11 17:33:15.921586
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.template import Templar
    from ansible.plugins import filter_loader
    from jinja2.loaders import DictLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    vars = dict()
    options = dict()
    loader = DataLoader()
    j2_vars = AnsibleJ2Vars(Templar(loader=loader, variables=vars, filters=filter_loader, shared_loader_obj=DictLoader({})), options, locals=dict())
    result = j2_vars['test']
    #TODO: not implemented
    assert(True)

# Generated at 2022-06-11 17:33:18.896633
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.template
    templar = ansible.template.Templar(loader=None, variables=dict(variable='foo'), fail_on_undefined=False)
    vars = AnsibleJ2Vars(templar, dict(variable='bar'), locals=dict(variable='baz'))
    assert vars['variable'] == 'baz'
    assert vars['variable'] == 'baz'

# Generated at 2022-06-11 17:33:26.905900
# Unit test for method __iter__ of class AnsibleJ2Vars

# Generated at 2022-06-11 17:33:33.328865
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        from ansible.module_utils.common._collections_compat import Mapping
        from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
        from ansible.template import Templar
    except ImportError:
        from unittest import SkipTest
        raise SkipTest("ansible is required for this test")

    # This is a base class. No direct objects can be created
    with pytest.raises(TypeError):
        AnsibleJ2Vars(None, None)

    # We need to mock the Templer class
    class AnsibleJ2Vars_Templar(Templar):
        def __init__(self):
            pass

        def template(self, data):
            return data

    # We need to mock available_variables
    templar = AnsibleJ2Vars

# Generated at 2022-06-11 17:33:42.239103
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())
    globals = dict()

    locals = dict()
    locals['k1'] = 'v1'
    locals['k2'] = 'v2'
    locals['k3'] = 'v3'
    locals['k4'] = 'v4'
    locals['k5'] = 'v5'

    ansible_vars = AnsibleJ2Vars(templar, globals, locals=locals)

    assert len(ansible_vars) == 5, "AnsibleJ2Vars.__len__() should contains what we put in"

# Generated at 2022-06-11 17:33:48.603063
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    t = Templar(None)
    t.available_variables = {'foo': 'bar'}
    v = AnsibleJ2Vars(t, {'baz': 'boo'})
    assert 'foo' in v
    assert 'baz' in v
    assert 'unknown' not in v
    assert 'vars' not in v
    assert 'test_item' not in v
