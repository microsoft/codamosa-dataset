

# Generated at 2022-06-11 17:24:13.275268
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    var = AnsibleJ2Vars(Templar(), {}, locals={})

    hosts = ['host1', 'host2']
    hostvars = HostVars(hosts)
    hostvars['host1']['foo'] = 'bar'

    var._templar.available_variables = {
        'hostvars': hostvars,
        'hosts': hosts,
        'vars': {
            'foo': 'bar'
        },
        'lookup': {
            'foo': 'bar'
        }
    }

    assert (var['hostvars'] == hostvars)
    assert (var['hosts'] == hosts)

# Generated at 2022-06-11 17:24:24.048557
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    from ansible import constants as C
    from ansible.vars.hostvars import HostVars

    def __getitem__(self, varname):
        self.vars[varname] = None
        return self.vars[varname]

    # fake Templar
    class FakeTemplar(Templar):
        pass
    Templar.available_variables = __getitem__

    fake_templar = FakeTemplar(None)

    test_globals = {
        'foo': 'bar',
    }
    test_locals = {
        'foo': 'buz',
    }

    test_cases = [
        # (varname, expect)
        ('foo', 'bar'),
        ('bar', KeyError),
    ]

    ansible

# Generated at 2022-06-11 17:24:36.424153
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.inventory import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestTemplar(Templar):
        def __init__(self, loader, variables=None):
            super(Templar, self).__init__(loader)
            self.available_variables = variables

    test_vars = HostVars(
        host=Host(name='127.0.0.2'),
        variables=dict(
            test_key1='test_value1',
            test_key2='test_value2',
            test_key3='test_value3'
        )
    )
    variable_manager = VariableManager

# Generated at 2022-06-11 17:24:47.779768
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create variables objects
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create inventory, and add host test to it
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    host = inventory.add_host('test')

    # Set some variables in host
    hostvars = HostVars({})
    hostvars['test_var'] = 'test_value'
    hostvars['test_var_2'] = 'test_value_2'
    hostvars['hostvars'] = 'hostvars'

# Generated at 2022-06-11 17:24:58.254921
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    templar = Templar(play_context=PlayContext())
    j2vars = AnsibleJ2Vars(templar, globals=dict())

    origin_jinja2_include_vars = AnsibleJ2Vars.__getitem__

    def test_getitem_vars(self, varname):
        if varname == 'test':
            return 99
        elif varname == 'test_undefined':
            raise KeyError
        else:
            return origin_jinja2_include_vars(self, varname)

    AnsibleJ2Vars.__getitem__ = test_getitem_vars

    assert j2vars['test'] == 99


# Generated at 2022-06-11 17:25:08.980681
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    templar = Templar(loader=None)

    v1 = dict(var1='value1')
    v2 = dict(var2='value2')

    j2 = AnsibleJ2Vars(templar, locals=v1, globals=v2)


    if 'var1' in j2 and 'var2' in j2:
        # var1 has to be value1,
        # var2 has to be value2
        if j2['var1'] == 'value1' and j2['var2'] == 'value2':
            pass
        else:
            raise Exception('unit test failed')
    else:
        raise Exception('unit test failed')

    try:
        j2['var3']
    except:
        pass

# Generated at 2022-06-11 17:25:20.057012
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    h = Host('test')
    vars = {'inventory_hostname': 'test'}
    vm = VariableManager(loader=loader, hostvars=vars)
    vm.set_host_variable(h, 'foo', 123)

    from ansible.playbook.play_context import PlayContext
    jt = PlayContext(variable_manager=vm, loader=loader)

    # basic test case
    vars = AnsibleJ2Vars(jt, {}, {'inventory_hostname': 'test'})
    assert vars['inventory_hostname'] == 'test'

    # test case with nested complex var
   

# Generated at 2022-06-11 17:25:25.895284
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    test_j2vars = AnsibleJ2Vars(templar=None,
                         globals=None,
                         locals=None)

    assert test_j2vars._templar == None
    assert test_j2vars._globals == None
    assert test_j2vars._locals == {}

    test_j2vars = AnsibleJ2Vars(templar=None,
                         globals=None,
                         locals={"Test_1": "Value_1"})

    assert test_j2vars._templar == None
    assert test_j2vars._globals == None
    assert test_j2vars._locals == {"Test_1": "Value_1"}


# Generated at 2022-06-11 17:25:36.268373
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    from ansible.template import Templar

    templar = Templar(loader=None)

    def test_variable(value):
        templar._available_variables = dict(test_var=value)
        j2vars = AnsibleJ2Vars(templar, globals=dict())
        return 'test_var' in j2vars

    if not test_variable(AnsibleUnsafeText('TEST')):  # pylint: disable=unused-variable
        raise AssertionError()

    if not test_variable({'TEST': 'TEST'}):
        raise AssertionError()

    if test_variable({'TEST': AnsibleUnsafeText('TEST')}):
        raise AssertionError()


# Generated at 2022-06-11 17:25:48.447810
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Test for a Variable
    _AnsibleJ2Vars = AnsibleJ2Vars(templar=None, globals=None, locals=None)
    _AnsibleJ2Vars._templar = Templar()
    _AnsibleJ2Vars._templar.available_variables = {
        'varname': Variable('varname', loader=None, unsafe=False),
    }
    assert _AnsibleJ2Vars['varname'] == 'varname'

    # Test for a HostVars
    _AnsibleJ2Vars = AnsibleJ2Vars(templar=None, globals=None, locals=None)
    _AnsibleJ2Vars._templar = Templar()

# Generated at 2022-06-11 17:26:01.152233
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    play_context = PlayContext()

    vars_dict = dict(
        foo='1',
        bar='2',
        baz='3',
        dal='4'
    )

    variable_manager.set_nonpersistent_facts(vars_dict)

    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    aj2v = AnsibleJ2Vars(templar, vars_dict)

    assert 'foo' in aj2v

# Generated at 2022-06-11 17:26:10.107258
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    assert len(AnsibleJ2Vars(templar, globals, locals)) == 0
    assert len(AnsibleJ2Vars(templar, globals)) == 0
    assert len(AnsibleJ2Vars(templar, dict(a=1))) == 1
    assert len(AnsibleJ2Vars(templar, globals, dict(a=1))) == 1
    assert 'a' in AnsibleJ2Vars(templar, dict(a=1))
    assert 'a' in AnsibleJ2Vars(templar, globals, dict(a=1))

# Generated at 2022-06-11 17:26:21.496221
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import os
    import sys
    import yaml
    import importlib
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # skip test if python2
    if not PY3:
        return

    # load the task unit test class
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from lib.ansible.utils.unicode import to_bytes
    from lib.ansible.plugins.loader import scope_aliases, variable_loader
    from lib.ansible.parsing.vault import VaultLib
    from lib.ansible.template import Templar

    # load my module
    # TODO:

# Generated at 2022-06-11 17:26:26.954112
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
   from ansible.template import Templar
   from ansible.vars.unsafe_proxy import wrap_var

   class TestJ2Vars(AnsibleJ2Vars):
       def __init__(self, templar, globals):
           super(TestJ2Vars, self).__init__(templar, globals)

   templar = Templar()
   j2vars = TestJ2Vars(templar, globals={'glob_test': []})
   assert 'glob_test' in j2vars
   assert 'random_variable' not in j2vars
   templar.available_variables = {'avar_test': {}}
   assert 'avar_test' in j2vars
   assert 'random_variable' not in j2vars
   j2vars

# Generated at 2022-06-11 17:26:37.137440
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    import ansible.constants as C
    import os

    # Initialize AnsibleJ2Vars object
    aj2v = AnsibleJ2Vars(Templar(VariableManager()), {})

    # Check if AnsibleJ2Vars object contains invalid keys
    assert 'invalid_key' not in aj2v

    # Check if the AnsibleJ2Vars object contains environment variables
    assert os.environ.get('HOME') in aj2v

    # Check if AnsibleJ2Vars object contains constants
    assert C.DEFAULT_VAULT_PASSWORD_FILE in aj2v

    # Check if AnsibleJ2Vars object contains jinja2 default globals
    assert 'range' in aj2

# Generated at 2022-06-11 17:26:45.930394
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader, variables={})
    context = PlayContext()
    context._ansible_vars = {'foo': 1}

    vars = AnsibleJ2Vars(templar, {}, locals={'hostvars': {'hostvars': 1}}, context=context)

    assert vars['foo'] == 1
    assert vars['hostvars'] == {'hostvars': 1}
    assert vars['vars'] == context.get_variables()

    try:
        vars['c']
        assert False
    except KeyError as e:
        assert str(e)

# Generated at 2022-06-11 17:26:56.085647
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template.safe_eval import ANSIBLE_TEST_DATA_ROOT

    # Read vars file and add the vars to ansible_vars
    from ansible.template.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    templar._available_variables = {'ansible_check_mode': False}
    templar.basedir = ANSIBLE_TEST_DATA_ROOT
    templar.environment.filters = dict()

    invalid_path = '{{ ansible_test_vars_path }}/test'

# Generated at 2022-06-11 17:27:07.882220
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    locals = dict()
    globals = dict()
    locals['b'] = 'bb'
    locals['d'] = dict()
    locals['d']['e'] = 'ee'
    globals['a'] = 'aa'
    globals['c'] = dict()
    globals['c']['d'] = dict()
    globals['c']['d']['e'] = 'eee'
    templar = Templar(loader=None)
    templar._available_variables = dict()
    templar._available_variables['f'] = 'ff'
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == 'aa'

# Generated at 2022-06-11 17:27:17.771999
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import pytest
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.playcontext import PlayContext
    from ansible.template import Templar
    from ansible.template.safe_eval import SafeEval
    from ansible.template.template import AnsibleEnvironment

    connection_info = dict(
        network_os="ios",
        network_segment_os="ios",
        device_os="ios",
    )

    play_context = PlayContext(connection='local', network_os='ios', network_segment_os='ios', device_os='ios')

# Generated at 2022-06-11 17:27:28.670051
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    locals = dict()
    locals['l_test'] = 1
    locals.update({'context': None, 'environment': None, 'template': None})
    globals = dict()
    globals['g_test'] = 1
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_test' in vars, "Can't find key in global variables"
    assert 'l_test' in vars, "Can't find key in local variables"
    assert 'test' not in vars, "Can't find key in Templar's available_variables"
    templar.set_available_variables({'test': 1})

# Generated at 2022-06-11 17:27:36.672941
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    AnsibleJ2Vars.__len__() return the correct number of items
    """
    _len = len(AnsibleJ2Vars(templar=None, globals={'a':1, 'b':2}))
    assert(_len == 2)

# Generated at 2022-06-11 17:27:45.846326
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    import jinja2.utils
    import copy
    import pytest
    # create templar object
    context = PlayContext(TEST_HOST_VARS=HostVars({"test_hostvars_key": "test_hostvars_value"}))
    templar = Templar(loader=None, variables=context.extra_vars)
    # define variables
    varname = "test_varname"
    variable = "test_variable_value"
    globals_ = {"globals_key": "globals_value"}
    globals_with_varname = copy.deepcopy(globals_)
    globals_

# Generated at 2022-06-11 17:27:56.040670
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from jinja2 import Template
    source = """
{% if variable in j2vars %}
    variable is defined in j2vars
{% else %}
    variable is not defined in j2vars
{% endif %}
"""

    tpl = Template(source)
    j2vars = AnsibleJ2Vars(None, None)

    # variable is not defined
    out = tpl.render(variable='variable', j2vars=j2vars)
    assert out == "variable is not defined in j2vars\n"

    # variable is now defined (in the scope of j2vars)
    j2vars._locals['variable'] = "Some variable value"

    out = tpl.render(variable='variable', j2vars=j2vars)

# Generated at 2022-06-11 17:28:07.698283
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    j2_vars = AnsibleJ2Vars(Templar(loader=None), {'g': 'global'})
    j2_vars['l_local'] = 'locale'
    j2_vars._templar.set_available_variables({'a': 'available'})

    assert j2_vars['l_local']           == 'locale'
    assert j2_vars['local']             == 'locale'
    assert j2_vars['available']         == 'available'
    assert j2_vars['g']                 == 'global'

    j2_vars['a'] = HostVars(loader=None)

# Generated at 2022-06-11 17:28:18.420971
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.module_utils.common._collections_compat import Hashable

    # Create an AnsibleJ2Vars object
    obj = AnsibleJ2Vars(None, None, None)

    # Check if __iter__ is implemented
    assert hasattr(obj, "__iter__"), "AnsibleJ2Vars should have an __iter__ method"

    # Check __iter__ is correctly implemented
    it = obj.__iter__()
    assert isinstance(it, Iterator), "AnsibleJ2Vars.__iter__ should return an iterator"
    assert isinstance(list(it), list), "AnsibleJ2Vars.__iter__ should return a list"

# Generated at 2022-06-11 17:28:28.074942
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    pluginPath = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../lib/ansible/plugins')

    localhost = ansible.inventory.host.Host('localhost')
    templar = ansible.template.Templar(loader=ansible.parsing.dataloader.DataLoader())
    templar._basedir = '/tmp'
    templar._allowed_include_patterns = templar.get_allowed_include_paths(pluginPath)
    templar._add_host_vars(localhost, 'localhost', inject=dict(foo='bar'))

    # test plain AnsibleJ2Vars
    expected = {'foo'}
    j2vars = AnsibleJ2Vars(templar, dict())

# Generated at 2022-06-11 17:28:39.269745
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    try:
        from units.mock.loader import DictDataLoader
    except ImportError:
        return

    # Tests for AnsibleJ2Vars variable proxy
    # This allows us to adjust variable content before jinja2 sees it. This is
    # done by hijacking the variable storage that jinja2 uses.

    # Test contains: test if a variable exists in the following scopes:
    #    - locals
    #    - jinja2 context
    #    - jinja2 globals
    # And return True if found, False otherwise.

    # This test is using the private attribute _locals as-is as it is used
    # by AnsibleJ2Vars to store local variables.

    # Create a Templar() object
    from ansible.template import Templar
    from ansible.playbook.play_context import Play

# Generated at 2022-06-11 17:28:50.969782
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    ansible_host = 'host.example.com'

    globals = dict()
    globals['hostvars'][ansible_host] = dict(FACT1='a fact', FACT2='another fact')
    globals['group_names'] = dict(group1=['host1', 'host2'], group2=['host3', 'host4', 'host5'])
    globals['groups'] = dict(group1=['host1', 'host2'], group2=['host3', 'host4', 'host5'])
    globals['inventory_hostname'] = ansible_host
    globals['inventory_hostname_short'] = None
    globals['inventory_dir'] = '/tmp'

# Generated at 2022-06-11 17:29:03.177221
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class HostVarsDummy(object):
        def __init__(self, value):
            self.value = value

        def __getitem__(self, varname):
            return self.value[varname]

    class TemplarDummy(object):
        def __init__(self, value):
            self.value = value

        def template(self, variable):
            return self.value

    class AnsibleUndefinedVariableDummy(AnsibleUndefinedVariable):
        def __init__(self, message):
            self.message = message

    class AnsibleErrorDummy(AnsibleError):
        def __init__(self, message):
            self.message = message

    class KeyErrorDummy(KeyError):
        def __init__(self, message):
            self.message = message


# Generated at 2022-06-11 17:29:11.077444
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar

    import os.path
    import yaml

    def load_yaml(yaml_file):
        yaml_path = os.path.abspath(yaml_file)
        with open(yaml_path, 'r') as f:
            yaml_data = yaml.safe_load(f)
        return yaml_data

    test_vars = load_yaml('./test/unit/vars/vars_0.yml')
    test_locals = load_yaml('./test/unit/vars/vars_1.yml')
    test_globals = load_yaml('./test/unit/vars/vars_2.yml')

    templar = Templar(loader=None)
    templar.available_

# Generated at 2022-06-11 17:29:26.234266
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.templating import Templar

    loader = DataLoader()

    play = Play()
    play.context = PlayContext()
    play.context._use_temp_file_for_vault = False
    templar = Templar(loader=loader, variables=play.get_variable_manager())

    ajvars = AnsibleJ2Vars(templar, globals=dict())

    context.CLIARGS = {
        'host_key_checking': False,
    }

    # analyze the output of the following code without executing it:
    #
    #    ajvars['ansible_

# Generated at 2022-06-11 17:29:27.314652
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert (True == True)

# Generated at 2022-06-11 17:29:33.865036
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    fail = False
    data = {'a': {'b' : 'c', 'd': 'e'}}
    templar = Templar(loader=None)
    templar.set_available_variables(data)
    j2vars = AnsibleJ2Vars(templar, {}, {})
    if 'a' not in j2vars:
        fail = True
    if 'a.b' not in j2vars:
        fail = True
    if 'b' in j2vars:
        fail = True
    if fail:
        raise AssertionError("AnsibleJ2Vars.__contains__() test failed")

# Generated at 2022-06-11 17:29:44.612345
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    dict_var = dict()
    dict_var['test_var'] = 'test_value'

    dict_globals = dict()
    dict_globals['test_var'] = 'test_value'

    vocabulary = AnsibleJ2Vars(templar, dict_globals)

    # Test vars in __contains__
    assert ('test_var' in dict_var)
    assert ('test_var' in vocabulary)

    # Test vars not in __contains__
    assert ('test_varz' not in dict_var)
    assert ('test_varz' not in vocabulary)


# Generated at 2022-06-11 17:29:56.035393
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # import of the tested module
    from ansible.vars import AnsibleJ2Vars

    # import of the module we are testing
    from ansible.template import Templar
    from ansible.template import _merge_kv
    from ansible.vars.hostvars import HostVars

    # test object initialization
    templar = Templar(loader  = None, variables=dict())

    globals = {
        'google': "GOOGLE",
        'amazon': "AMAZON",
        'yahoo':  "YAHOO",
        'hostvars': HostVars(host_name = 'host', vars = None),
    }

    locals = { 'yahoo': "override for yahoo" }


# Generated at 2022-06-11 17:30:06.982647
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class DummyTemplar(object):
        def __init__(self):
            self.available_variables = {
                "a": 1,
                "b": 2,
            }
    dummy_templar = DummyTemplar()
    dummy_globals = {
        "c": 3,
        "d": 4
    }
    dummy_locals = {
        "e": 5,
        "f": 6
    }
    ansible_j2_vars = AnsibleJ2Vars(dummy_templar, dummy_globals, locals=dummy_locals)
    assert set(ansible_j2_vars) == {"a", "b", "c", "d", "e", "f"}

# Generated at 2022-06-11 17:30:17.837616
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    # Templating engine should be initialized
    templar = Templar(variable_manager=VariableManager(), loader=None)

    # Templating engine should initialize variables from inventory
    templar._add_host_vars_from_inventory(None)
    templar._add_host_group_vars_from_inventory(None)

    # Template all variable content before jinja2 sees it
    j2vars = AnsibleJ2Vars(templar, globals={})

    # Test case 1: variable is found in locals
    j2vars._locals = {"k": "v"}

# Generated at 2022-06-11 17:30:27.953166
# Unit test for constructor of class AnsibleJ2Vars

# Generated at 2022-06-11 17:30:39.228255
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.plugins.loader import vars_loader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None, variables=AnsibleJ2Vars(templar=None, globals={}))

    variables = dict(
        dict_with_unsafe=dict(
            a=1,
            b=2,
        ),
        hostvars=HostVars(hostname="host"),
    )
    for key, val in iteritems(variables):
        templar.set_available_variables({key: val})

    assert isinstance(templar._available_variables['dict_with_unsafe'], dict)

# Generated at 2022-06-11 17:30:46.801140
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)
    locals = {'l_key_1': 'l_value_1', 'l_key_2': 'l_value_2'}
    globals = {'g_key_1': 'g_value_1', 'g_key_2': 'g_value_2'}

    ansible_vars = AnsibleJ2Vars(templar, globals, locals=locals)

    host_vars = HostVars(vars={'key': 'value'}, inventory='inventory')

# Generated at 2022-06-11 17:31:03.851598
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def test_J2Vars(local_vars):
        templar = Templar(loader=None)
        globals = dict(one=1)
        locals = dict(two=2)
        locals.update(local_vars)
        vars = AnsibleJ2Vars(templar, globals, locals)
        return vars

    # Test cases
    #  0. local_vars: no
    #  1. local_vars: normal
    #  2. local_vars: vars
    #  3. local_vars: hostvars
    #  4. local_vars: unsafe
    #  5. local_vars: context
    #  6. local_

# Generated at 2022-06-11 17:31:13.966307
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import pytest

    ansible10_vars = {
        'string_var': 'this is a string variable',
        'int_var': 1,
        'list_var': ['this', 'is', 'a', 'list', 'variable'],
        'dict_var': {'this': {'is': {'a': {'dict': 'variable'}}},
                     'the': {'first': 'key', 'second': {'key': 'this is the second key'}}},
        'boolean_var': True,
        'non_overriden_var': 'v1'
    }


# Generated at 2022-06-11 17:31:22.451008
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Unit test for method __getitem__ of class AnsibleJ2Vars
    '''
    templar = None
    globals = None
    locals = None
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['var'] == 'value'
    assert j2vars['var2'] == 'value2'


if __name__ == '__main__':
    # Unit test for method __getitem__ of class AnsibleJ2Vars
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-11 17:31:29.158470
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_obj = AnsibleJ2Vars(None, None, None)
    assert 'foo' in test_obj
    test_obj._locals = {'foo': 'bar'}
    assert 'foo' in test_obj
    test_obj._templar = {'foo': 'bar'}
    assert 'foo' in test_obj
    test_obj._globals = {'foo': 'bar'}
    assert 'foo' in test_obj


# Generated at 2022-06-11 17:31:34.920034
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class MockTemplar:
        def __init__(self):
            self.available_variables = {'v1':1, 'v2':2, 'v3':3}

    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    t = MockTemplar()
    v = AnsibleJ2Vars(t, globals, locals)
    assert len(list(v.__iter__())) == 6
    assert 'v1' in v
    assert 'v3' in v
    assert 'l1' in v
    assert 'l2' in v
    assert 'g1' in v
    assert 'g2' in v


# Generated at 2022-06-11 17:31:44.513244
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    new_vars = AnsibleJ2Vars(templar, globals=dict(), locals=dict())
    new_vars['a'] = 1
    assert new_vars['a'] == 1
    assert new_vars['test'] == 'test'
    assert new_vars['test2'] == 'test2'
    assert new_vars['test3'] == 'test3'
    assert new_vars['test4'] == 'test4'
    assert new_vars['test5'] == 'test5'
    assert new_vars['test6'] == 'test6'
    assert new_vars['test7'] == 'test7'
    assert new_vars['test8'] == 'test8'

# Generated at 2022-06-11 17:31:54.696263
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.vault import VaultLib
    templar = Templar(vars_cache=dict())
    vars = AnsibleJ2Vars(templar, globals=dict())
    # make sure an error is raised on invalid keys
    try:
        vars['a_bogus_key']
        assert False, 'When key does not exist an exception should have been raised.'
    except KeyError:
        pass
    # make sure an error is raised on invalid variables
    try:
        vars['a_bogus_variable']
        assert False, 'When variable does not exist an exception should have been raised.'
    except AnsibleUndefinedVariable:
        pass
    # make sure the method returns the proper value for a valid key
    valid_key = 'a_valid_key'
    valid_value

# Generated at 2022-06-11 17:32:02.382944
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dictionary_for_test = {
        'hostvars': {}
    }

    templar = Templar(None, loader=None)
    globals = {
        'ansible_version': '1.0.0'
    }
    locals = {
        'hostvars': {
            'host1': {
                'hostname': 'host1'
            },
            'host2': {
                'hostname': 'host2'
            }
        },
        'inventory': None
    }

    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    if 'ansible_version' not in ansible_j2vars:
        raise AssertionError('key "ansible_version" from globals should be in AnsibleJ2Vars')


# Generated at 2022-06-11 17:32:12.218614
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    if PY3:
        from ansible.parsing.vault import VaultLib
        vault_secrets = VaultLib('ansible')
    else:
        from ansible.utils.vault import VaultLib
        vault_secrets = VaultLib()

    templar = Templar(loader=None, variables=dict(), vault_secrets=vault_secrets)
    AnsibleJ2Vars(templar, {'A': 'B'})['A']
    AnsibleJ2Vars(templar, {'A': 'B'})['B']
    AnsibleJ2Vars(templar, {'A': 'B'})['C']

# Generated at 2022-06-11 17:32:19.974667
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.template import Templar

    globals = dict(a=1)
    locals = dict(b=1)
    templar = Templar(loader=None)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in ansible_j2_vars
    assert 'b' in ansible_j2_vars
    assert 'c' not in ansible_j2_vars


# Generated at 2022-06-11 17:32:35.608321
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    v = AnsibleJ2Vars(Templar(), dict())
    assert(v['local'] == 'local' and v['local_key'] == 'local_value')

    # HostVars is special, return it as-is
    host_vars = HostVars(dict())
    assert(isinstance(v['hostvars'], HostVars))

    # 'vars' is also the special variable, return the vars structure
    assert(isinstance(v['vars'], dict))

    # return the value of a variable if the value is not a dictionary or an instance of HostVars,
    # otherwise return the dictionary or the HostVars object

# Generated at 2022-06-11 17:32:40.720389
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var

    # empty dict
    #
    v = AnsibleJ2Vars(Templar(), {}, {})
    assert len(v) == 0

    # empty dict
    #
    v = AnsibleJ2Vars(Templar(), {'g': wrap_var({})}, {})
    assert len(v) == 0

    # single item dict
    #
    v = AnsibleJ2Vars(Templar(), {'g': wrap_var({'g1':1})}, {})
    assert len(v) == 1

    # multiple item dict
    #

# Generated at 2022-06-11 17:32:51.689324
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Test __getitem__ for AnsibleJ2Vars
    '''
    import sys
    import types

    # Save reference to original python objects
    original_dict = __builtins__['dict']
    original_iteritems = dict.iteritems

    # Create mocks
    class MockTypeUndefinedVariable(Exception):
        '''
        Class Mock of Type UndefinedVariable
        '''
        def __init__(self, message):
            self.message = message

        def __str__(self):
            return str(self.message)

    class MockTemplar(object):
        '''
        Class Mock of Templar
        '''
        def __init__(self):
            self.available_variables = dict()
            self.template = lambda var: var

    mock_dict = {'proxy': {}}


# Generated at 2022-06-11 17:32:56.575043
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    c = AnsibleJ2Vars(None, {'a':1}, {'b':2, 'l_c':3})
    assert c.__contains__('a') is True
    assert c.__contains__('b') is False
    assert c.__contains__('c') is True

# Generated at 2022-06-11 17:33:08.448282
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar
    from ansible.vars import VariableManager

    templar = Templar()
    vm = VariableManager()

    # Create a test variable and set it in the VariableManager
    test_var = "This is a test variable"
    vm.set_variable('test_var', test_var)

    # Create instance of AnsibleJ2Vars with the created variable
    vars_obj = AnsibleJ2Vars(templar, vm.vars, vm.extra_vars)

    # Check if returned value is the same as the set variable
    assert vars_obj['test_var'] == test_var

    # Check what message is returned when variable doesn't exist

# Generated at 2022-06-11 17:33:17.534813
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    len_locals_0 = AnsibleJ2Vars(templar, globals, locals=locals).__len__()
    len_locals_1 = AnsibleJ2Vars(templar, globals, locals={'a': 1}).__len__()
    len_locals_2 = AnsibleJ2Vars(templar, globals, locals={'a': 1, 'b': HostVars(load_list=[])}).__len__()
    len_globals_0 = AnsibleJ2Vars(templar, dict(), locals=locals).__len__()
    len

# Generated at 2022-06-11 17:33:22.350689
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    globals = {'foo': 1}
    templar = Templar(loader=None, variables=globals)
    locals = dict()
    ansiblej2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ansiblej2vars


# Generated at 2022-06-11 17:33:32.211103
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import ansible.playbook.templar
    from ansible.template import Templar

    # Create a variable proxy without any variable
    var_proxy = AnsibleJ2Vars(Templar(loader=None), {}, {})
    assert len(var_proxy) == 0

    # Create a variable proxy with a variable a=1
    var_proxy = AnsibleJ2Vars(Templar(loader=None), {}, {'a': 1})
    assert len(var_proxy) == 1

    # Create a variable proxy with a variable a=1 and b=2
    var_proxy = AnsibleJ2Vars(Templar(loader=None), {}, {'a': 1, 'b': 2})
    assert len(var_proxy) == 2


# Generated at 2022-06-11 17:33:41.745046
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar
    templar = Templar(loader=None)
    d1 = {'a':1,'b':2,'c':3}
    d2 = {'a':'A','c':'C'}
    d3 = {'b':'B','d':'D'}
    ajv = AnsibleJ2Vars(templar, d3)
    ajv.available_variables = d1
    ajv.template_vars = d2
    assert 'a' in ajv
    assert 'h' not in ajv
    assert 'c' in ajv
    assert 'b' in ajv



# Generated at 2022-06-11 17:33:46.913233
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {}
    locals = None
    obj = AnsibleJ2Vars(templar, globals, locals)
    var = 'ansible_play_hosts'
    assert(var in obj)
