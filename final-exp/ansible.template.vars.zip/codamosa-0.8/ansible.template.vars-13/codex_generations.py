

# Generated at 2022-06-11 17:24:11.755513
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None, shared_loader_obj=None)
    globals = {"bar": "goodbye", "foo": "hello"}
    locals = {"bar": "hello", "foo": "goodbye"}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars["bar"] == "goodbye"
    assert j2vars["foo"] == "goodbye"
    try:
        j2vars["baz"]
    except Exception as e:
        assert isinstance(e, KeyError)

# Generated at 2022-06-11 17:24:22.584172
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.template import Templar

    def get_play_ds():
        play_source =  dict(
            name = "Ansible Play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args=''))
            ]
        )
        play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
        play._inject_facts = mock_inject_facts
        return play._ds


# Generated at 2022-06-11 17:24:35.488788
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import AnsibleVars
    from ansible.template import Templar

    vars1 = AnsibleVars()
    vars1.update({"a": "a", "b": "b", "c": "c"})

    vars2 = AnsibleVars()
    vars2.update({"d": "d", "e": "e", "c": "c"})

    vars3 = AnsibleVars()
    vars3.update({"a": "a", "b": "b", "c": "cc"})

    class FakeTemplar():
        available_variables = vars1

    ansible_j2vars = AnsibleJ2Vars(FakeTemplar(), vars2)

    # Test with a key that is in available_variables of Templar

# Generated at 2022-06-11 17:24:44.366605
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = { 'foo_var': 'foo' }
    templar = Templar(loader=loader, variables=variable_manager)
    variables = AnsibleJ2Vars(templar, dict(fact_one='one'))
    assert len(variables) == 2, "len(variables) should be 2"

# Generated at 2022-06-11 17:24:53.631757
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    j2vars = AnsibleJ2Vars(loader, variable_manager, locals=None)

    assert not ('foobar' in j2vars)

    j2vars = AnsibleJ2Vars(loader, {'foobar': 'fake'}, locals=None)

    assert ('foobar' in j2vars)

    j2vars = AnsibleJ2Vars(loader, variable_manager, {'foobar': 'fake'})

    assert ('foobar' in j2vars)


# Generated at 2022-06-11 17:25:02.097729
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    fake_globals = { "a": "This is global a", "b": "This is global b" }
    fake_locals = { "c": "This is local c" }

    # Create a fake Templar() object.
    # We have to do this since Templar() __init__() receives additional parameters
    # that are difficult to fake.
    templar = Templar(vault_password="Dummy_Vault_Password")
    templar.available_variables = { "d": "This is available d" }

    # Create the AnsibleJ2Vars object
    j2var = AnsibleJ2Vars(templar, fake_globals, fake_locals)


# Generated at 2022-06-11 17:25:06.346404
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)

    sut = AnsibleJ2Vars(templar, { 'global': 'value' } )
    # This should be False as the key is not in the dictionary.
    assert(False == 'non-existent' in sut)

    # This should be False as the key is in the dictionary but the value is undefined.
    templar.available_variables = { 'defined': missing }
    assert(False == 'defined' in sut)

    # This should be true as the key is in the dictionary and the value is defined.
    templar.available_variables = { 'defined': 'is defined' }
    assert(True == 'defined' in sut)
    assert('is defined' == sut['defined'])

    # This should be

# Generated at 2022-06-11 17:25:13.822417
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import pytest
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    locals = {'item': 'foo'}
    vars = AnsibleJ2Vars(Templar(PlayContext()), {}, locals)

    assert vars['item'] == 'foo'
    assert vars['l_item'] == 'foo'

    try:
        vars['not_exist']
        pytest.fail('AnsibleUndefinedVariable exception is not raised')
    except AnsibleUndefinedVariable:
        pass

    C.DEFAULT_HASH_BEHAVIOUR = 'replace'

# Generated at 2022-06-11 17:25:23.503726
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved

    context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variable_manager=variable_manager, context=context)
    variable_manager.set_templar(templar)

    # test variable_manager
    variable_manager.set_host_variable(host='127.0.0.1', varname='varname_host', value={'key_host': "value_host"})

# Generated at 2022-06-11 17:25:34.528399
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    vars_tmp = {'a': 1, 'b': 2}
    templar = Templar()
    templar._available_variables = vars_tmp.copy()
    templar._finalize = lambda x: x
    ans_j2_vars = AnsibleJ2Vars(templar, {})
    assert 'a' in ans_j2_vars
    assert 1 == ans_j2_vars['a']
    assert 2 == ans_j2_vars['b']
    try:
        ans_j2_vars['c']
        assert False
    except KeyError as e:
        assert "undefined variable: c" == str(e)
    assert {'a', 'b'} == set(ans_j2_vars)




# Generated at 2022-06-11 17:25:46.708438
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # init
    import jinja2
    env = jinja2.Environment()
    j2vars = AnsibleJ2Vars(env.engine.get_template("").new_context(), globals={'var1': 'test1', 'var2': 'test2'}, locals={'l_var1': 'test1', 'l_var2': 'test2'})

    # test
    # create hash for j2vars
    for key, value in j2vars:
        hash(key)
        hash(value)

# Generated at 2022-06-11 17:25:57.245262
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.template
    import ansible.template.safe_eval
    templar = ansible.template.Templar(loader=None)
    assert getattr(templar, '_available_variables')
    ajv = AnsibleJ2Vars(templar=templar, globals={})
    # test for varname in self._locals
    assert ajv['varname'] == 'varname'
    templar._available_variables = {'varname': 'varname'}
    # test for varname in self._templar.available_variables
    assert ajv['varname'] == 'varname'
    assert ajv['varname3'] == 'varname3'
    # test for varname in self._globals
   

# Generated at 2022-06-11 17:25:57.811862
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert True

# Generated at 2022-06-11 17:26:06.614498
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.safe_eval import fail_eval, fail_json
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {'foo': 'bar'}
    try:
        locals = {'foo': 'baz'}
    except:
        fail_eval("Option 'locals' is not supported with jinja2 versions older than 2.9")
    ajvars = AnsibleJ2Vars(templar, globals, locals)
    if 'foo' not in ajvars:
        fail_eval("Option 'locals' is not supported with jinja2 versions older than 2.9")


# ==============================================================================


# Generated at 2022-06-11 17:26:10.092964
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    templar = Templar(loader=None, variables=VariableManager())
    vars = AnsibleJ2Vars(templar, globals={'a': 'b'})
    assert 'a' in vars


# Generated at 2022-06-11 17:26:18.094522
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = Templar(loader=DictDataLoader(dict_data={}), variables={})
    j2vars = AnsibleJ2Vars(templar, {}, locals={})

    expected = False
    actual = 'x' in j2vars
    assert actual == expected, 'j2vars should not contain x'

    expected = True
    actual = 'ansible_play_hosts' in j2vars
    assert actual == expected, 'j2vars should contain ansible_play_hosts'

# Generated at 2022-06-11 17:26:25.143872
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = AnsibleJ2Vars({'key': 'value'})
    # test simple key existence
    assert 'key' in templar
    assert 'value' not in templar
    # test complex key existence
    assert 'complex.key' in templar
    assert 'complex.val' not in templar
    # test variable
    assert 'complex.key.is.var' in templar
    assert 'complex.val.is.var' not in templar
    # test dict key
    assert 'complex.key.is.dict' in templar
    assert 'complex.val.is.dict' not in templar
    # test unset key
    assert 'missing.key' not in templar


# Generated at 2022-06-11 17:26:34.922108
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    The AnsibleJ2Vars class is meant to ease the templating of variables.
    This test case tests the method '__contains__' of class AnsibleJ2Vars.
    '''
    from jinja2.runtime import StrictUndefined
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 1, 'b': 2, 'c': 3}

    #Normal test for method __contains__ of class AnsibleJ2Vars

# Generated at 2022-06-11 17:26:36.512959
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # TODO: write unit test
    pass



# Generated at 2022-06-11 17:26:45.598256
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-11 17:26:51.818085
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    result = AnsibleJ2Vars(templar=None, globals=None, locals=None)['Test']
    assert False


# Generated at 2022-06-11 17:27:01.965982
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # test with a variable that is referenced in available_variables
    # (available_variables is a dict (varname, variable) in Templar object)
    def test_getitem_ref_avail_variables(templar, globals, locals, varname='my_var', variable='my_value'):
        templar.available_variables[varname] = variable
        j2vars = AnsibleJ2Vars(templar, globals, locals)
        assert varname in j2vars
        assert j2vars[varname] == variable
    # test with a variable not referenced in available_variables
    def test_getitem_not_ref_avail_variables(templar, globals, locals, varname='my_var'):
        j2vars = AnsibleJ2

# Generated at 2022-06-11 17:27:02.567273
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass

# Generated at 2022-06-11 17:27:14.263744
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars

    templar = Templar()
    globals = {'g_var': 'global_var'}
    locals = {'l_var': 'local_var'}
    obj = AnsibleJ2Vars(templar, globals, locals=locals)

    assert obj['l_var'] == 'local_var'
    assert obj['g_var'] == 'global_var'

    templar.available_variables = wrap_var(dict(avars_var='avars_var'))
    assert obj['avars_var'] == 'avars_var'

    vars = obj['vars']

# Generated at 2022-06-11 17:27:21.943738
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None # TODO
    globals_ = {'g_1': 'g_1'}
    locals_ = {'l_1': 'l_1'}
    vars_ = {'v_1': 'v_1'}
    param = AnsibleJ2Vars(templar, globals_, locals_)

    assert 'g_1' in param
    assert 'l_1' in param
    assert 'v_1' in param

    assert 'other' not in param


# Generated at 2022-06-11 17:27:31.658640
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    globals_dict = dict()
    locals_dict = dict()
    templar_dict = dict()

    templar_dict['java.version'] = '1.7'
    templar_dict['java.home'] = '/usr/lib/java/jdk1.7.0_79'
    templar_dict['java.home.sub.string'] = '/usr/lib/java/jdk1.7.0'
    templar_dict['ansible_connection'] = 'local'
    templar_dict['ansible_check_mode'] = False
    templar_dict['ansible_playbook_python'] = '/usr/bin/python'
    templar_dict['ansible_play_hosts'] = [ '192.168.0.7' ]

    templar_dict

# Generated at 2022-06-11 17:27:32.758353
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass


# Generated at 2022-06-11 17:27:40.292111
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Mocking Templar
    class MockTemplar:
        def template(self, variable):
            return variable + 1

    class MockAnsible:
        def get_default_vars(self):
            return {}

    vars = AnsibleJ2Vars(MockTemplar(), {}, {'l_a': 1, 'b': 2, 'c': 3})
    assert 'a' in vars
    assert 'b' not in vars
    assert 'c' not in vars


# Generated at 2022-06-11 17:27:52.739213
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.loader import vars_loader
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext


    inventory = InventoryManager(loader=DataLoader())
    host_1 = Host(name='host_1')
    host_2 = Host(name='host_2')
    host_1.vars = {'a': '1'}

# Generated at 2022-06-11 17:28:03.351790
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    import jinja2
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, globals={'foo':'bar'})

    assert j2vars['foo'] == 'bar'
    assert jinja2.is_undefined(j2vars['notthere'])


# Generated at 2022-06-11 17:28:17.368455
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafevar import UnsafeProxy
    #UnsafeProxy
    upx =  UnsafeProxy(1)
    assert upx is upx['__UNSAFE__']
    #HostVars
    hv = HostVars(1)
    assert hv is hv['_hostvars']
    #dict
    dct = {'a':1}
    assert dct is dct['a']
    assert 1 == dct['a']
    #str
    v = 'a'
    t = v['a']

# Generated at 2022-06-11 17:28:22.887799
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    import jinja2
    class Templar():
        def __init__(self):
            self.available_variables = {u'foo': u'bar', u'baz': u'qux'}
        def template(self, obj):
            return obj
    class Globals():
        def __init__(self):
            self[u'foo'] = u'bar'
    try:
        vars = AnsibleJ2Vars(Templar(), Globals(), locals=dict())
        assert vars['foo'] == 'bar'
        assert vars['baz'] == 'qux'
    except Exception as e:
        print(e)
        raise e

# Generated at 2022-06-11 17:28:32.466168
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    # Expected parameters for testing
    test_vars = dict({"test_key": "test_value"}, **safe_eval("test_params"))
    test_var_name = "test_var_name"
    test_var_value = "test_var_value"
    # Expected calls and return values of mocked templar template method
    expected_call1 = dict({"test_key": "test_value"}, **safe_eval("test_params"))[test_var_name]
    expected_call2 = dict({"test_key": "test_value"}, **safe_eval("test_params"))[test_var_name]

# Generated at 2022-06-11 17:28:37.008925
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    t=Templar(loader=None, variables={'var1':'val1', 'var2':'val2'})
    from ansible.playbook import Playbook
    p=Playbook()
    return AnsibleJ2Vars(t, p.GLOBAL_VARS)

# Generated at 2022-06-11 17:28:43.598414
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.module_utils.jinja2 import Templar

    templar = Templar(loader=None, variables=dict())
    globals = {}

    a = AnsibleJ2Vars(templar, globals, locals=dict())

    assert('a' not in a)

    globals['a'] = 0

    assert('a' in a)

    # TODO: check the case locals has name
    #locals = {}
    #locals['a'] = 0

    #a = AnsibleJ2Vars(templar, globals, locals=locals)

    #assert('a' in a)



# Generated at 2022-06-11 17:28:54.372189
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.templating import Templar

    from units.mock.loader import DictDataLoader

    templar = Templar(loader=DictDataLoader({}))
    globals = dict()
    locals = dict()

    j2 = AnsibleJ2Vars(templar, globals, locals=locals)

    # Test if varname is in _locals
    locals["key"] = "value"
    assert j2["key"] == "value"

    # Test if varname is in available_variables
    templar.available_variables["key"] = "value"
    assert j2["key"] == "value"

    # Test if varname is in _globals

# Generated at 2022-06-11 17:29:06.264672
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.template import Templar
    # hostvars is a special variable, since AnsibleJ2Vars is
    # used to template the variables themselves, we must return
    # the HostVars object (which is a dict) without templating.
    # unset variable
    jvars = AnsibleJ2Vars(Templar(VariableManager()), {})
    assert jvars["foo"] == missing
    # variable from available_variables
    jvars._templar._available_variables = {"foo":"foo"}
    assert jvars["foo"] == "foo"
    # variable from globals

# Generated at 2022-06-11 17:29:18.246240
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar, TemplarError
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {}
    locals = {}
    j2var = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)
    # test return value when key is not in j2var
    try:
        j2var['key_not_exist']
        assert False
    except KeyError as e:
        assert e.args[0] == 'undefined variable: key_not_exist'

    # test return value for a key in j2var with value as a string
    key = 'a_key'
    value = 'a_value'

# Generated at 2022-06-11 17:29:26.136518
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = {'g1': 1, 'g2': 2}
    locals  = {'l1': 3}

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert vars.__contains__('g1')
    assert vars.__contains__('g2')
    assert vars.__contains__('l1')

    assert not vars.__contains__('l2')   # missing
    assert not vars.__contains__('not_exist')   # never exist



# Generated at 2022-06-11 17:29:31.466259
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    locals = {}
    globals = {}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    with pytest.raises(KeyError) as excinfo:
        aj2v.__getitem__("VAR_NOT_IN_TEMPLAR")
    assert 'VAR_NOT_IN_TEMPLAR' in str(excinfo.value)

# Generated at 2022-06-11 17:29:43.654821
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)

    globals['a'] = 'a'
    locals['b'] = 'b'
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' not in vars



# Generated at 2022-06-11 17:29:53.765671
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader

    vars_manager = None
    loader = DataLoader()

    available_variables = {"test1": "test1", "test2": "test2"}

    templar = Templar(loader=loader, variables=available_variables, shared_loader_obj=vars_manager)
    ansible_vars = AnsibleJ2Vars(templar, globals={}, locals=None)

    assert('test1' in ansible_vars)
    assert('test2' in ansible_vars)

    assert('test3' not in ansible_vars)


# Generated at 2022-06-11 17:30:01.022564
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.module_utils.six import string_types
    vm = VariableManager()
    t = Templar(loader=None, variables=vm)
    vm.set_globals(globals={'x': 'X', 'y': 'Y'})
    vm._host_vars = {'1.2.3.4': {'z': 'Z'}}
    vm._vars = {'a': 'A', 'b': 'B'}

    # test all cases
    av = t.available_variables
    assert 'x' in AnsibleJ2Vars(t, {}, {})
    assert 'y' in AnsibleJ2Vars(t, {}, {})
    assert 'a' in AnsibleJ2Vars

# Generated at 2022-06-11 17:30:10.457724
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib

    vault_secrets = VaultLib()

    templar = Templar(loader=None, variables={}, shared_loader_obj=None)
    vm = VariableManager()
    vm.set_host_variable({'some-key': 'some-value'})
    vm.set_host_variable({'some-other-key': 'some-other-value'})
    vm.set_host_variable({'third-key': 'third-value'})
    vm.set_host_variable({'fourth-key': 'fourth-value'})
    vm.set_host_variable({'fifth-key': 'fifth-value'})
    templar._available_variables = vm.get

# Generated at 2022-06-11 17:30:22.753926
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    templar = Templar()
    globals = {'g': 1}
    locals = {'l_a': HostVars(), 'l_b': 2, 'c': 3}

    # Test lookup of undefined variables
    v = AnsibleJ2Vars(templar, globals, locals)
    try:
        # Raises a KeyError because there is no such variable defined
        v['x']
        assert False, 'AnsibleJ2Vars exception not raised'
    except KeyError:
        pass

    # Test lookup of local variables
    assert v['l_a'] == locals['l_a'], 'Failed to lookup local var "l_a"'

# Generated at 2022-06-11 17:30:31.241872
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    def test_AnsibleJ2Vars___iter__(self, varname, expected):
        try:
            result = self.__getitem__(varname)
            if result != expected:
                return False
        except:
            if expected is not None:
                return False
        return True

    # Setup

# Generated at 2022-06-11 17:30:39.369685
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from jinja2._compat import string_types
    from jinja2 import meta as jinja_meta

    some_globals = {
        'some_global_var1': 'some_global_var1_value',
        'some_global_var2': 'some_global_var2_value',
        'some_global_var3': 'some_global_var3_value',
    }

    j2vars = AnsibleJ2Vars(None, some_globals, locals={})

    assert len(j2vars) == len(some_globals)


# Generated at 2022-06-11 17:30:43.662451
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # setUp()
    _templar = None
    _globals = {'_':{'mode':'0644'}}
    o = AnsibleJ2Vars(_templar, _globals, locals=None)

    # test
    length = len(o)

    # assert
    assert length == 1



# Generated at 2022-06-11 17:30:50.048100
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = Templar()
    globals = {
        "foo": "bar",
    }
    locals = {
        "l_foo": "bar"
    }
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 2


# Generated at 2022-06-11 17:30:53.641522
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Import here to avoid cyclical dependency
    from ansible.template import Templar

    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, {})

    assert j2vars['FOO'] is None

# Generated at 2022-06-11 17:31:15.489938
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    data = [
        # input, expected
        ({'vars': {'test': 'test'}}, 'test'),
        ({'test': 'test'}, 'test'),
        ({'vars': {'test': '{{test}}'}}, '{{test}}'),
        ({'test': '{{test}}'}, '{{test}}'),
        ({'vars': {'test': {'test': '{{test}}'}}}, {"test": "{{test}}"}),
        ({'test': {'test': '{{test}}'}}, {"test": "{{test}}"}),
        ({}, KeyError),
    ]

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager

# Generated at 2022-06-11 17:31:27.128025
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import unittest

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    class TestAnsibleJ2Vars(unittest.TestCase):

        def setUp(self):
            self._templar = 'self._templar'
            self._globals = 'self._globals'
            self._locals = {'self._locals': 'value'}
            self.templar_result = 'templar_result'
            self._templar_template = 'self._templar.template'
            self._templar_available_variables = {'self._templar.available_variables': 'value'}
            self.varname = 'self.varname'
            self.variable = 'self.variable'

# Generated at 2022-06-11 17:31:28.335471
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass


# Generated at 2022-06-11 17:31:39.217075
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import unittest2 as unittest
    from six.moves import StringIO

    # assertRaisesRegexp is deprecated and will be removed in Python 3.4
    assertRaisesRegexp = getattr(unittest.TestCase(), 'assertRaisesRegexp', unittest.TestCase().assertRaisesRegex)

    from ansible.vars.hostvars import HostVars
    from ansible.vars import AnsibleVars
    from ansible.module_utils.common.collections import Mapping
    from ansible.template import Templar

    class fake_play(object):
        class fake_ds(object):
            def __getitem__(self, item):
                return item

        def __init__(self):
            self.vars = AnsibleVars(self.fake_ds()).vars

# Generated at 2022-06-11 17:31:46.793044
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()

    var = AnsibleJ2Vars(templar, {})
    value = var['fact']
    assert value == 'fact_value'

    value = var['fact2']
    assert value == 'fact2_value'

    value = var['play_hosts']
    assert value == 'play_hosts_value'

    value = var['vars']
    assert value == 'vars_value'

    # value = var['_hostvars']
    # assert value == '_hostvar_value'

    value = var['_fact']
    assert value == '_fact_value'

    # value = var['_variable']
    # assert value == '_variable_value'

    value = var['_play_context']

# Generated at 2022-06-11 17:31:52.145560
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from jinja2.environment import Environment
    from jinja2.loaders import DictLoader
    templar = Templar(Environment(loader=DictLoader({})), None)
    j = AnsibleJ2Vars(templar, {})
    result = 'key' in j
    assert not result



# Generated at 2022-06-11 17:31:53.801617
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    t = AnsibleJ2Vars(None, None, locals={})
    assert isinstance(t, Mapping)

# Generated at 2022-06-11 17:31:54.914461
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    #TODO: write unit test
    pass


# Generated at 2022-06-11 17:32:02.743162
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class Templar():
        def template(self, variable):
            return variable

    # Test that variables in locals are returned
    j2vars = AnsibleJ2Vars(Templar(), {}, {'test': 'bla'})
    result = j2vars['test']
    assert result == 'bla'

    # Test that variables in self._templar.available_variables are returned
    j2vars = AnsibleJ2Vars(Templar(), {}, {})
    j2vars._templar.available_variables = {'test': 'bla'}
    result = j2vars['test']


# Generated at 2022-06-11 17:32:12.439860
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing import vault
    from ansible.vars import VariableManager
    from ansible.template import Templar

    # Create a variable manager that will be used to load all of the variables used in the play
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(foo="bar", baz="quz")

    # Make a new "Templar" object that will be used to render the template we're going to use
    # as part of our AnsibleJ2Vars class
    templar = Templar(loader=None, variables=variable_manager)

    # Now we can make our AnsibleJ2Vars class and use it to access variables
    ansible_vars = AnsibleJ2Vars(templar, globals={'foo': "qux"})
    assert 'foo' in ans

# Generated at 2022-06-11 17:32:34.165045
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    # Test that AnsibleJ2Vars returns the correct len
    """

    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    from ansible.errors import AnsibleError

    # Prepare the test case
    context = PlayContext()
    hostvars = HostVars(context=context)
    templar = Templar(loader=None, variables=dict(vars=hostvars))
    var_store = AnsibleJ2Vars(templar, dict(), dict())
    actual_len = len(var_store)
    excepted_len = 0


# Generated at 2022-06-11 17:32:41.566334
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template.safe_eval import safe_eval
    from ansible.template.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)

    v = dict(a=[1, 2, 3])
    assert AnsibleJ2Vars(templar, {}, locals=v)['a'] == v['a']

    v = dict(a=1)
    assert AnsibleJ2Vars(templar, {}, locals=v)['a'] == v['a']

    v = dict(a=['a', 'b', 'c'])
    assert AnsibleJ2Vars(templar, {}, locals=v)['a'] == v['a']


# Generated at 2022-06-11 17:32:52.407277
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)

    globals = {'g_key1': 'g_value1', 'g_key2': 'g_value2'}
    locals = {'l_key1': 'l_value1', 'l_key2': 'l_value2'}

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals=locals)

    assert 'g_key1' in ansible_j2_vars
    assert 'g_key2' in ansible_j2_vars

    assert 'l_key1' in ansible_j2_vars
    assert 'l_key2' in ansible_j2_vars

    assert 'undefined_key1' not in ansible_j

# Generated at 2022-06-11 17:33:04.254087
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    call AnsibleJ2Vars class to test __getitem__ method
    '''
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    templar = Templar(None, variables={})
    variables = {"hosts": [{"hostname": "isaac", "ip": "127.0.0.1"}]}
    # test with success
    j2_obj = AnsibleJ2Vars(templar, {})
    assert j2_obj["hosts"] == [{"hostname": "isaac", "ip": "127.0.0.1"}]
    # test with failed with AnsibleUndefinedVariable
    j2_obj = AnsibleJ2Vars(templar, {})

# Generated at 2022-06-11 17:33:14.199634
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    def test_templar(self):
        return Templar(self._play_context, self._loader)

    setattr(AnsibleJ2Vars, '_templar', test_templar)
    test_templar = AnsibleJ2Vars._templar

    t = test_templar(None)
    t._templar = None
    t._loader = None
    t._available_variables = dict(var1='var1')
    t._play_context = None
    a = AnsibleJ2Vars(t, {'var2': 'var2'})

    assert 'var1' in a
    assert 'var2' in a
    assert 'var3' not in a

    a = AnsibleJ2Vars(t, {'': ''})

# Generated at 2022-06-11 17:33:24.091085
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # Create some data to test on
    data = {
        'a': 'original_a',
        'b': 'original_b',
        'c': 'original_c',
    }

    # Create a 'templar' object (that is not a Templar instance) that has a method 'template'
    # and a data member named 'available_variables', exactly as defined in AnsibleJ2Vars
    templar = object()
    templar.template = lambda x: x
    templar.available_variables = data

    # Create a 'globals' object (that is not a dict) that has items 'a' and 'b'
    globals = object()
    globals.a = 'global_a'
    globals.b = 'global_b'

    # Create a 'locals' object (that

# Generated at 2022-06-11 17:33:26.942851
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = None
    globals = None
    locals = None
    ansibleJ2Vars = AnsibleJ2Vars(templar, globals, locals)


# Generated at 2022-06-11 17:33:32.166686
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import pytest
    from ansible.template import Templar

    variable_manager = ["a", "b", "c", "d"]
    j2vars = AnsibleJ2Vars(Templar(variable_manager), {})
    variable_manager.append("e")

    # check we get all the variable from variable_manager
    assert list(variable_manager) == list(j2vars)

    # make sure the variable_manager is not modified. I.E make sure
    # it's a copy
    result = list(variable_manager)
    result.append("f")

    assert result == list(variable_manager)

# Generated at 2022-06-11 17:33:42.603575
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    # Test1 :'vars' is a dict.
    vars = {'k':'v'}
    templar = Templar()
    templar.available_variables = {'vars':vars}
    globals = {}
    locals = {}
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2vars['vars'] == vars

    #Test2 : 'vars' is a hostvars.
    templar.available_variables = {'vars':HostVars()}
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-11 17:33:46.041784
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    try:
        assert len(AnsibleJ2Vars()) == 0
    except:
        assert False, "Method __len__ of class AnsibleJ2Vars failed"
    assert True
