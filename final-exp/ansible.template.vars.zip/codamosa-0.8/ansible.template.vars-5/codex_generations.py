

# Generated at 2022-06-11 17:24:03.886102
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    globals = {'g1': 'value', 'g2': 'value'}
    available_variables = {'av1': 'value', 'av2': 'value'}
    templar = Templar(loader=None)
    templar.available_variables = available_variables
    j2_env = AnsibleJ2Vars(templar, globals, locals={'l1': 'value', 'l2': 'value'})
    assert len(j2_env) == 6

# Generated at 2022-06-11 17:24:14.118388
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    # Set up globals
    globals = {'key': 'value'}

    # Set up locals
    locals = {'key': 'value'}

    # Set up available_variables
    available_variables = {'key': 'value'}

    templar = Templar(loader=None, variables=available_variables)
    assert templar.available_variables == available_variables

    # Create a AnsibleJ2Vars object
    ajv = AnsibleJ2Vars(templar, locals, globals)

    # Get an object from variable 'key' of AnsibleJ2Vars
    assert ajv['key'] == 'value'

    # Test an exception of KeyError
    import pytest
    with pytest.raises(KeyError):
        a

# Generated at 2022-06-11 17:24:19.432628
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # Create 2 empty dicts
    templar = {}
    globals = {}

    # Create a AnsibleJ2Vars instance using the dicts
    vars = AnsibleJ2Vars(templar, globals)

    # Nothing should be in the instance
    assert 'known_var' not in vars



# Generated at 2022-06-11 17:24:25.040108
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.plugins.loader import jinja2_loader
    from ansible.template import Templar

    templar = Templar(loader=jinja2_loader)
    globals = {}
    locals = {}

    ansibleJ2Vars = AnsibleJ2Vars(templar, globals, locals)
    #print(ansibleJ2Vars[''])

if __name__ == "__main__":
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-11 17:24:37.053813
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Create an object of class AnsibleJ2Vars to test
    j2vars = AnsibleJ2Vars(templar={'available_variables':{'a':'b'}, 'template':lambda x: x},
                        locals={'test':True},
                        globals={'test':True})

    # Test existing key in _globals
    try:
        j2vars.__getitem__('test')
    except Exception as e:
        print('FAILED: assert %s does not raise any exception' % repr(e))

    # Test non-existing key in _globals
    try:
        j2vars.__getitem__('test2')
    except KeyError as e:
        print('SUCCESS: assert %s raises KeyError' % repr(e))

    # Test existing key in

# Generated at 2022-06-11 17:24:39.796804
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test failure with exception KeyError
    # Test where unknown variable exists
    # Test with key item
    # Test with key item
    pass



# Generated at 2022-06-11 17:24:50.646551
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import tempfile
    import os

    (osf, vault_file) = tempfile.mkstemp()

    k = "password"
    v = "test"

    vault = VaultLib([])
    vault.encrypt(v, k, vault_file)
    test_encrypt = AnsibleVaultEncryptedUnicode(vault.decrypt(k, vault_file))

    test_encrypt_unsafe = AnsibleUnsafeText(test_encrypt)


# Generated at 2022-06-11 17:24:59.963911
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Test method __contains__ of class AnsibleJ2Vars by providing various
    arguments and verifying the returned value.
    '''

    # Create an instance of class AnsibleJ2Vars
    args = (None, None, None)
    obj = AnsibleJ2Vars(*args)

    # Test method __contains__
    for arg in (None, object()):
        with pytest.raises(TypeError):
            obj.__contains__(arg)

    # Test method __contains__
    args = (None, None, None)
    obj = AnsibleJ2Vars(*args)
    arg = ''
    expected = False
    actual = obj.__contains__(arg)
    assert expected == actual


# Generated at 2022-06-11 17:25:09.922166
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict0 = dict()
    dict1 = dict()
    dict0['foo'] = 'bar'
    dict1['foo'] = 'baz'
    dict2 = dict()
    dict2['foo'] = 'bak'
    vars = AnsibleJ2Vars('templar', dict0, dict1)
    assert ('foo' in vars) is True
    assert ('bar' in vars) is False
    # since dict1 overrides dict0, __contains__ does not iterate over dict0
    assert ('baz' in vars) is False
    assert ('bak' in vars) is False
    assert ('bak' in AnsibleJ2Vars('templar', dict0, dict1, dict2)) is True


# Generated at 2022-06-11 17:25:16.856426
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader

    # create empty templar
    loader = DataLoader()
    templar = Templar(loader=loader, variables={})

    # create test instance
    obj = AnsibleJ2Vars(templar, globals={})

    # test missing variable
    try:
        obj['missing_variable']
        assert False, 'Expected KeyError'
    except KeyError:
        pass

# Generated at 2022-06-11 17:25:28.477917
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    try:
        from ansible.playbook import Playbook
    except ImportError:
        raise AssertionError()

    playbook = Playbook()
    inventory = playbook.inventory
    loader = inventory.loader
    variable_manager = inventory.variable_manager

    vars = AnsibleJ2Vars(variable_manager._templar, variable_manager._globals, locals=None)

    assert isinstance(vars, AnsibleJ2Vars)
    assert isinstance(vars, Mapping)

    assert hasattr(vars, "__iter__")

    assert callable(vars.__iter__)


# Generated at 2022-06-11 17:25:36.199829
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(None, loader=None)
    globals = {'foo': 'bar'}
    ansible_vars = {'f_o_o': 'bar'}
    locals = {'l_foo': 'bar'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert  'foo' in ajv
    assert  'f_o_o' in ajv
    assert  'l_foo' in ajv
    assert  'bar' not in ajv

# Generated at 2022-06-11 17:25:48.405187
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    In the __contains__ method, the variable name is searched in the following order:
    1. local variables
    2. variables available to Ansible
    3. global variables
    '''
    import ansible.vars
    import jinja2.runtime
    # instantiate a Templar object with no parameters
    templar = ansible.vars.Templar()
    # locals will not be used in the contains test, can be ignored
    # let's define some fake variables
    some_var = {
        'a': '1',
        'b': '2',
        'c': '3',
    }
    globals = {
        'a': '1',
        'd': '4',
     }
    # instantiate a AnsibleJ2Vars object
    vars = AnsibleJ2V

# Generated at 2022-06-11 17:25:50.690216
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Test to check __contains__ method of class AnsibleJ2Vars
    '''
    assert True

# Generated at 2022-06-11 17:26:00.731236
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory("localhost"))
    variable_manager.extra_vars = dict()

    templar = Templar(variable_manager=variable_manager)
        
    print("--- test true")
    print("--- test dict")
    vars = AnsibleJ2Vars(templar, {}, {})
    vars['toto'] = 'titi'
    assert('toto' in vars)
    
    
    print("--- test dict with variable")
    vars = AnsibleJ2Vars(templar, {}, {})
    vars['toto'] = '{{titi}}'
    variable_manager

# Generated at 2022-06-11 17:26:05.589896
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    aj2vars = [AnsibleJ2Vars]
    assert AnsibleJ2Vars in aj2vars, "__contains__ on AnsibleJ2Vars class failed"


# Generated at 2022-06-11 17:26:09.145433
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    templar = "any_variable"
    globals = "any_variable2"
    locals = {"k1": "v1", "k2": "v2"}
    ansiblej2vars = AnsibleJ2Vars(templar, globals, locals)
    result = ansiblej2vars.__contains__("k1")
    assert result



# Generated at 2022-06-11 17:26:20.856108
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.plugins.loader
    templar = ansible.plugins.loader.templar_loader.get('Jinja2')
    vars_manager = ansible.plugins.loader.vars_loader.get('vars')
    var_manager = vars_manager.get('variable_manager')

    # inject is a singleton and should be reset between tests
    var_manager._fact_cache = dict()
    var_manager._vars_cache = dict()
    var_manager.set_variable_manager_includes(None)
    var_manager.set_variable_manager_includes('file')
    var_manager.set_variable_manager_includes('vars')
    var_manager.set_variable_manager_includes('hiera')

    var_manager.extra_vars = {"MYVAR":"myvalue"}

# Generated at 2022-06-11 17:26:30.519760
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ''' Unit test for method __contains__ of class AnsibleJ2Vars '''
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar()

    variables = {
        'foo': 1,
    }

    locals = {
        'l_foo': 2,
    }

    globals = {
        'g_foo': 3,
    }

    class Foo:
        pass

    # Case 1: the class attributes exists in locals but not in templar.available_variables, globals
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ansible_

# Generated at 2022-06-11 17:26:40.852610
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from units.mock.loader import DictDataLoader
    from ansible.template import Templar

    mock_var = {'value': 'foo'}
    mock_var_list = ['foo', 'bar', 'baz']
    mock_var_dict = {'a': 'A', 'b': 'B'}

    templar = Templar(loader=DictDataLoader({}))

    j2vars = AnsibleJ2Vars(templar, {
        'var_dict': mock_var_dict,
        'var_list': mock_var_list,
        'var': mock_var,
    })

    assert len(j2vars) == 3



# Generated at 2022-06-11 17:26:55.549275
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # Create two variables that are not equal
    # The contents of each variable are not important
    test_variable1 = 'testing1'
    test_variable2 = 'testing2'

    # Create an instance of the Templar class using a DummyLoader
    test_templar_variable1 = AnsibleJ2Vars(test_variable1, test_variable2)

    # Constructor is valid if has correct dictionary keys
    assert(test_templar_variable1 == {test_variable1, test_variable2})
    # Constructor is invalid if has incorrect dictionary keys
    # Remove the variable from the dictionary
    test_templar_variable2 = AnsibleJ2Vars(test_variable1, test_variable2)
    del test_templar_variable2[test_variable1]

# Generated at 2022-06-11 17:27:04.070264
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        # This is import statement is required for AnsibleJ2Vars to work
        from ansible.template import Templar
        templar = Templar(loader=None)
        ajv = AnsibleJ2Vars(templar, {}, {})
        ajv.__getitem__('test')

        assert False
    except KeyError as ke:
        assert str(ke) == "undefined variable: test"
    except Exception as ex:
        assert False, "Unexpected exception"


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 17:27:07.074203
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ans_j2vars = AnsibleJ2Vars(None, None)
    assert len(ans_j2vars) == 0


# Generated at 2022-06-11 17:27:13.787601
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from jinja2 import Environment, DictLoader

    env = Environment(loader=DictLoader({'a.j2': 'Hello world'}))
    templar = Templar(env.loader, env)

    vars = AnsibleJ2Vars(templar, dict(a=1, b=2, c=3))

    assert 3 == len(vars)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars

# Generated at 2022-06-11 17:27:20.899589
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from jinja2.loaders import DictLoader
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import json
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestCaseBase(unittest.TestCase):
        def setUp(self):
            self.loader = DataLoader()
            self.vars_loader = DictLoader({})
            self.env = Environment(loader=self.vars_loader)
            self.templar = Templar(loader=self.loader, variables={})


# Generated at 2022-06-11 17:27:31.050237
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # create an inventory, pass to variable manager
    inv_manager = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inv_manager)

    # create a play context
    play_context = PlayContext()

    # create the templar
    templar = Templar(loader=None, variables=variable_manager)

    vars_ = AnsibleJ2Vars(templar, {'globals': 'globals'}, locals={})
    assert 'globals' in vars_
    assert 'locals' in vars_

# Generated at 2022-06-11 17:27:37.567217
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    locals = dict(l_test='test')
    globals = dict()
    template = dict(template='{{test}}', variables=dict(test='test'))
    templar = Templar(loader=None, variables=template)
    vars = AnsibleJ2Vars(templar=templar, locals=locals, globals=globals)
    assert 'test' in vars


# Generated at 2022-06-11 17:27:41.537524
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_obj = AnsibleJ2Vars({'a': 1}, {'b': 2}, {'c': 3})
    assert 'a' in test_obj
    assert 'b' in test_obj
    assert 'c' in test_obj
    assert 'd' not in test_obj

# Generated at 2022-06-11 17:27:53.387312
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    pc = PlayContext()
    templar = Templar(loader=None, variables=None,
                      shared_loader_obj=None)
    ajv = AnsibleJ2Vars(templar=templar, globals={}, locals={})

    # test case 1
    variables = {'vars': {'foo': 'baz'}}
    templar._available_variables = variables

    ret = ajv['vars']
    assert ret == {'foo': 'baz'}

    # test case 2
    variables = {'hostvars': HostVars(loader=None, variable_manager=None)}
    templar._available_

# Generated at 2022-06-11 17:28:04.480743
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from jinja2.runtime import StrictUndefined

# Generated at 2022-06-11 17:28:14.646511
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    # Variable ansible_default_ipv4.address is present in module_utils/facts.py
    # Check if the value of ansible_default_ipv4.address is present
    j2vars = AnsibleJ2Vars(templar, None)
    assert "ansible_default_ipv4.address" in j2vars

# Generated at 2022-06-11 17:28:21.267833
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    templar = Templar(VariableManager())
    test_instance = AnsibleJ2Vars(templar, [])
    assert test_instance is not None
    print('class AnsibleJ2Vars unit test __getitem__ succeed')

if __name__ == '__main__':
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-11 17:28:30.035379
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Testing 'available_variables'
    templar = Templar(loader=None, variables={'variables': {'foo': 'foo'}})
    variables = AnsibleJ2Vars(templar, {})
    assert variables['foo'] == 'foo'

    # Testing 'locals'
    templar = Templar(loader=None, variables={'variables': {'foo': 'foo'}})
    variables = AnsibleJ2Vars(templar, {}, locals={'bar': 'bar'})
    assert variables['bar'] == 'bar'

    # Testing 'globals'
    templar = Templar(loader=None, variables={'variables': {'foo': 'foo'}})
    variables = AnsibleJ2Vars(templar, {'baz': 'baz'})
   

# Generated at 2022-06-11 17:28:40.636594
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from copy import deepcopy
    from ansible.template.safe_eval import safe_eval
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # setup data
    templar = Templar(loader=None)
    templar._available_variables = {
        "available_vars_var_a" : 1,
        "available_vars_var_b" : 2,
        "available_vars_var_c" : AnsibleUnsafeText("{{lookup('env','PATH')}}"),
        "available_vars_var_d" : 1,
    }

# Generated at 2022-06-11 17:28:52.111556
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = {
        "g_a": 1,
        "g_b": 2,
        "g_c": 3,
    }
    locals = {
        "a": 1,
        "b": 2,
        "c": 3,
    }
    j2vars = AnsibleJ2Vars(templar, globals, locals=locals)
    def assert_contains(key, expected):
        assert key in j2vars == expected
    assert_contains("a", True)
    assert_contains("b", True)
    assert_contains("c", True)
    assert_contains("g_a", True)
    assert_contains("g_b", True)
    assert_contains("g_c", True)

# Generated at 2022-06-11 17:29:03.972697
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    ansible_vars = {
        'foo': 'bar',
        'baz': 'qux'
    }
    env = {
        'environment': {
            'foo': 'env_baz'
        }
    }
    ansible_j2_vars = AnsibleJ2Vars(
        templar=Templar(loader=None, variables=ansible_vars),
        globals=env)
    assert hasattr(ansible_j2_vars, '__iter__')

    # Case 1: test iter of ansible_j2_vars
    it = iter(ansible_j2_vars)
    assert next(it) == 'foo'
    assert next(it) == 'baz'

# Generated at 2022-06-11 17:29:11.425774
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()

    globals = {'g_foo': 'g_bar', 'g_baz': 'g_qux'}

    locals = {'l_foo': 'l_bar', 'l_baz': 'l_qux'}

    class MockVars(dict):
        def __getitem__(self, key):
            return 'MockVars %s' % key

    templar.available_variables = {'v_foo': 'v_bar', 'v_baz': 'v_qux', 'vars': MockVars()}

    vars = AnsibleJ2Vars(templar, globals, locals)

    # first, test for variables in locals

# Generated at 2022-06-11 17:29:23.327994
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    templar = Templar(None, loader=None, variables={}, vault_secrets=VaultLib())

    globals = {"range": range}

    locals = {
        "l_var": "Variable",
        "context": "Context",
        "environment": "Environment",
        "template": "Template"
    }

    j2_vars = AnsibleJ2Vars(templar, globals, locals=locals)

    assert j2_vars['var'] == "Variable"
    assert j2_vars['range'] is range
    assert j2_vars['context'] == "Context"

# Generated at 2022-06-11 17:29:32.268103
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # Setup inventory and variables
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    variable_manager._extra_vars = dict(d=dict(e='{{f}}'))
    variable_manager._options_vars = dict(f='g')

    # Create template
    templar = Templar(loader=loader, variables=variable_manager)

    # create instance of AnsibleJ2Vars and test it

# Generated at 2022-06-11 17:29:43.990405
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Prepare unit test
    # This is needed to avoid errors in loading modules, due to missing '__file__'
    import sys, os
    sys.modules['__main__'].__file__ = os.path.realpath(__file__)

    # Prepare unit test
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import iteritems
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var

    class _AnsibleVarsModule:
        pass
    ansible_vars_module

# Generated at 2022-06-11 17:29:57.631395
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = { "g_var" : "g_value" }
    locals = { "l_var" : "l_value" }
    v = AnsibleJ2Vars(templar, globals, locals)

    v['playbook_dir'] = "/tmp"
    del v['playbook_dir']

    assert sorted(list(v)) == sorted(["g_var", "l_var"])

# Generated at 2022-06-11 17:29:58.249754
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-11 17:30:09.173710
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os
    import sys
    import tempfile
    import shutil

    # Make Ansible think it's executing as an ansible module so it will load the correct
    # plugins. There are tests elsewhere to verify this works
    sys.argv = [os.path.basename(__file__), '-m', 'dummy']

    # Import Ansible now that it thinks it's an ansible module
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Create temp directory for local variables
    tmp_dir = tempfile.mkdtemp()
    tmp_vars = tmp_dir + "/vars"
    os.mk

# Generated at 2022-06-11 17:30:10.691283
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # ToDo: Write a proper unit test for AnsibleJ2Vars
    pass

# Generated at 2022-06-11 17:30:22.950461
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/ansible/inventory/test_inventory.ini'])
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = {'hostname': 'configserver'}
    variable_manager.set_play_context(PlayContext())
    template_loader = variable_manager.get_loader()

# Generated at 2022-06-11 17:30:30.291460
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # test possible empty instance
    globals_dict = {}
    locals_dict = {}
    templar = None
    vars_inst = AnsibleJ2Vars(templar, globals_dict, locals_dict)
    assert len(vars_inst) == 0

    # test instance with few variables
    globals_dict = {}
    locals_dict = {}
    templar = None
    vars_inst = AnsibleJ2Vars(templar, globals_dict, locals_dict)
    vars_inst._locals = {1 : None, 2 : None}
    assert len(vars_inst) == 2


# Generated at 2022-06-11 17:30:36.064044
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar
    templar = Templar(loader=None, variables=None)

    globals = dict()

    locals = dict()
    locals["g_hostvars"] = dict()

    vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)

    assert("g_hostvars" in vars)
    

# Generated at 2022-06-11 17:30:45.148111
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    jv = AnsibleJ2Vars(Templar(), {})

    assert jv["vars"] == UnsafeProxy(jv)
    assert jv["vars.x"].__class__.__name__ == "Undefined"

    assert jv.get("vars") == UnsafeProxy(jv)
    assert jv.get("vars", "z") == UnsafeProxy(jv)
    assert jv.get("vars.x") == "z"

    try:
        jv["vars.x"]
        raise Exception("Here should be thrown exception.")
    except KeyError:
        pass


# Generated at 2022-06-11 17:30:53.180885
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = "some value"
    globals = { "one": 1, "two": 2 }
    locals = { "three": 3, "four": 4 }
    inst = AnsibleJ2Vars(templar, globals, locals)
    assert "one" in inst
    assert "two" in inst
    assert "three" in inst
    assert "four" in inst
    assert "not existing" not in inst


# Generated at 2022-06-11 17:31:04.009030
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.hostvars import HostVars
    host = HostVars(None, dict(k0="v0"))
    templar = object()
    globals = dict(gk0="gv0")
    locals = dict(lk0="lv0")

    a1 = AnsibleJ2Vars(templar, globals, locals)
    a1.__contains__ = lambda k: k in locals or k in globals or k == "k0"
    a1.__getitem__ = lambda k: locals[k] if k in locals else globals[k] if k in globals else hostVars[k]

    # len(a1) = len(locals) + len(globals) + len(hostVars) + 1  # 1==k0 which is not in locals or

# Generated at 2022-06-11 17:31:26.566971
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    globals = {}
    templar = object
    locals = {}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    j2vars._locals['fname'] = 'foo'
    assert(j2vars['fname'] == 'foo')
    try:
        j2vars['fname2']
    except KeyError:
        pass
    else:
        assert False, "fname2 is not an existing key"

# Generated at 2022-06-11 17:31:35.038087
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    # initialisation
    templar = Templar(None, loader=None)
    vars = AnsibleJ2Vars(templar, {}, {})
    assert "foo" not in vars

    # check that it works
    templar.environment.filters['tojson'] = lambda obj: obj
    templar._available_variables = dict(foo="bar", bar="baz")
    assert "foo" in vars
    assert "bar" in vars

    # check that it does not return object that does not exist
    assert "foobar" not in vars



# Generated at 2022-06-11 17:31:42.756411
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import safe_eval
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    hostvars = HostVars()
    context = PlayContext()
    context._vars_cache = hostvars
    templar = Templar(loader=None, variables=hostvars)
    globals = {}
    locals = {}
    a = AnsibleJ2Vars(templar, globals, locals)
    i = 0
    for k in a:
        i = i + 1
    assert len(a) == i

# Generated at 2022-06-11 17:31:48.270116
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import unsafe_proxy

    templar = Templar(loader=None, variables={'bar': 'baz'})
    x = AnsibleJ2Vars(templar, {'foo': unsafe_proxy('bar')})
    assert x['foo'] == 'baz'

# Generated at 2022-06-11 17:31:57.979973
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.plugins.loader import vars_loader

    from ansible.template import Templar

    templar = Templar(loader=None)
    templar._available_variables = dict(this='that')
    j2_vars = AnsibleJ2Vars(templar, vars_loader)

    # included variables
    assert 'this' in j2_vars, "this is not in AnsibleJ2Vars"
    assert j2_vars.__contains__('this') is True, "j2_vars.__contains__('this') is not True"

    # included globals
    assert 'vars' in j2_vars, "vars is not in AnsibleJ2Vars"

# Generated at 2022-06-11 17:32:05.411932
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    # test empty object does not contain anything
    templar = Templar(loader=None)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals=dict())
    assert 'test' not in ansible_j2_vars
    # test empty object does not contain anything 2
    ansible_j2_vars = AnsibleJ2Vars(templar, globals=dict(), locals=dict())
    assert 'test' not in ansible_j2_vars

    # test vars/loc

# Generated at 2022-06-11 17:32:06.712893
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert AnsibleJ2Vars(None, {}, None).__getitem__('missing')


# Generated at 2022-06-11 17:32:14.138929
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    class Templar():
        def __init__(self, value):
            self.available_variables = {'varname': value}

        def template(self, val):
            return val

    globals = {'varname_global': 10}

    varname_local = 0
    locals = {'varname_local': varname_local}

    # test case 1: local variable is returned
    # j2vars = AnsibleJ2Vars(Templar(value=10), globals, locals)
    # j2vars['varname_local'] == varname_local

    # test case 2: global variable is returned
    # j2vars = AnsibleJ2Vars(Templar(value=10), globals, locals)

# Generated at 2022-06-11 17:32:19.123774
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible import constants
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=DataLoader({'los': 'tres'}))
    templar.available_variables = {'foo': 'bar', 'baz': '%(los)s'}

    var1 = AnsibleJ2Vars(templar, {'bar': 'baz', 'los': 'tres'}, None)

    # HostVars is special, return it as-is, as is the special variable
    # 'vars', which contains the vars structure
    hostvars = HostVars()


# Generated at 2022-06-11 17:32:24.821439
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader  = DataLoader()
    context = PlayContext()
    templar = Templar(loader=loader, variables=dict())
    j2vars  = AnsibleJ2Vars(templar=templar, globals=dict(), locals=dict(l_test_key=1))

    tests = (
        ('test_key', True),
        ('l_test_key', True),
        ('test_key_not_existing', False),
        ('l_test_key_not_existing', False),
    )
    for t, expected in tests:
        assert expected == (t in j2vars)

# Generated at 2022-06-11 17:33:07.806808
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    templar = Templar(loader=None, variables={})
    variables = VariableManager()
    variables.reserved = Reserved()

    # Setup globals
    global_vars = {
        'g_foo': 'bar',
        'g_baz': 'qux',
    }

    # Setup locals
    local_vars = {
        'l_foo': 'bar',
        'l_baz': 'qux',
    }

    ansible_j2_vars = AnsibleJ2Vars(templar, global_vars, locals=local_vars)

    # Check __contains

# Generated at 2022-06-11 17:33:17.157929
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader

    templar = Templar(loader=DictDataLoader())
    globals = dict(f1=1, f2=2)
    locals = dict(l1=1, l2=2)
    variables = dict(v1=1, v2=2)

    play_context = PlayContext(variables=variables)
    templar.set_available_variables(play_context)

    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars.__iter__() == set(['v1', 'v2', 'l1', 'l2', 'f1', 'f2'])

# Generated at 2022-06-11 17:33:26.359826
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleError
    from ansible.templating import Templar

    vault = VaultLib(password_file='ansible/test/test_vault.txt')
    templar = Templar(loader=None, variables={}, vault_secrets=vault)

    assert to_native(templar.template("{{ vault_user }}")) == "foo"

    # test that we correctly dereference/template variable when {{vault_user}} is
    # in the vault_secrets dictionary, and test that we correctly dereference/template
    # variable when {{vault_user}} is in the Templar object

# Generated at 2022-06-11 17:33:30.852937
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    jvars = AnsibleJ2Vars(templar, {}, {'foo': 'bar'})
    assert jvars.__contains__('foo') is True
    # FIXME: to be tested once the templar will render variables
    #assert jvars.__contains__('myvar') is True
    assert jvars.__contains__('does_not_exist') is False

# Generated at 2022-06-11 17:33:33.249276
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    test = AnsibleJ2Vars('', {})
    assert len(test) == 1
    assert len(test) == 0


# Generated at 2022-06-11 17:33:37.655755
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.template import Templar
    templar = Templar(loader=None)
    aj = AnsibleJ2Vars(templar, {'a': 1, 'b': 2})
    assert len(aj) == 2



# Generated at 2022-06-11 17:33:45.431791
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}

    templar = Templar(loader=loader, variable_manager=variable_manager)
    variable_manager.set_globals({"string": "Test", "int": 1, "list": [1, 2, 3], "dict": {"key": "value"}})


# Generated at 2022-06-11 17:33:55.641003
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None))

    vars_1 = AnsibleJ2Vars(templar, {'one': 'two', 'three': 'four'})

    assert vars_1['one'] == 'two'
    assert vars_1['three'] == 'four'

    try:
        assert vars_1['two'] != 'one'
    except KeyError:
        assert True

    vars_2 = AnsibleJ2Vars(templar, {'one': 'two', 'three': 'four'}, locals={'one': 'one', 'two': 'two'})

    assert vars_2['one'] == 'one'
    assert vars_2