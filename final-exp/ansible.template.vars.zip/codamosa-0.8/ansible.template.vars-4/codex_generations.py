

# Generated at 2022-06-11 17:24:11.344069
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Get a default Templar and J2Vars
    from ansible.template.templar import Templar
    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, {})

    # Add some values to the variable set
    assert 'foo' not in templar.available_variables
    assert 'foo' not in j2vars
    templar.available_variables['foo'] = 'bar'
    assert 'foo' in templar.available_variables
    assert 'foo' in j2vars
    assert j2vars['foo'] == 'bar'

    # Add some locals
    loc = dict()
    loc['bar'] = 'baz'
    loc['bar2'] = 'baz2'

# Generated at 2022-06-11 17:24:22.197390
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.vars import VariableManager

    from ansible.utils.vars import combine_vars

    host_vars = {
        'foo': 'bar'
    }

    play_vars = {
        'baz': 'qux'
    }

    play_vars_file = 'dummy'

    def host_vars_file():
        return 'dummy'

    def group_vars_files(group):
        return 'dummy'

    variable_manager = VariableManager()

    variable_manager.extra_vars = combine_vars(play_vars, variable_manager.extra_vars)
    variable_manager.extra_vars = combine_vars(host_vars, variable_manager.extra_vars)

    variable_manager.host_vars_files = host_v

# Generated at 2022-06-11 17:24:29.780155
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
  from ansible.templating.template import Templar
  x = {'foo': 'bar'}
  var_manager = AnsibleJ2Vars(templar=Templar(), globals=x, locals=x)
  assert var_manager['foo'] == 'bar'
  try:
    var_manager['bar']
  except KeyError:
    # success
    pass
  else:
    assert False, "Should have failed."


# Generated at 2022-06-11 17:24:39.577557
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    import ansible.template.safe_eval as safe_eval

    play_context = Play()
    templar = Templar(loader=None, variables={}, shared_loader_obj=None)
    variable_manager = VariableManager(loader=None, inventory=None)
    ansible_vars = AnsibleJ2Vars(templar, {})

    # Test __getitem__ returns HostVars variables
    variable_manager._hostvars = {'hostvars': HostVars(variable_manager, play_context, templar)}
    ansible_vars = AnsibleJ2Vars(templar, {})

# Generated at 2022-06-11 17:24:50.153171
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    templar._available_variables = {'super': 'batman', 'spider': 'man'}
    current_locals = {'bat': 'man'}
    globals = {'super': 'man'}
    containing = AnsibleJ2Vars(templar, globals, locals=current_locals)

    assert 'bat' in containing
    assert 'batman' not in containing
    assert 'super' in containing
    assert 'spider' in containing

    containing._locals = {}
    assert 'bat' not in containing

    # If the variable is a HostVars, it will be returned
    # as-is from AnsibleJ2Vars.__

# Generated at 2022-06-11 17:24:57.604511
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    from ansible.template import Templar

    templar = Templar(None)
    vars = AnsibleJ2Vars(templar, globals={'c': 2})
    assert 'c' in vars
    assert 'b' not in vars
    assert 'a' not in vars
    templar.set_available_variables({'a': 1})
    assert 'c' in vars
    assert 'b' not in vars
    assert 'a' in vars


# Generated at 2022-06-11 17:25:00.656599
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    vars = AnsibleJ2Vars(templar, {'one': 1})
    assert 'one' in vars
    assert 'two' not in vars


# Generated at 2022-06-11 17:25:10.920298
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = None
    globals = {'g_undefined': 0}
    locals = {'l_dict': {}, 'l_list': []}
    av = {'v_i': 1, 'v_s': '{{g_undefined}}', 'v_u': '{{undefined}}', 'v_dict': {'k': '{{l_undefined}}'}, 'v_l': ['{{l_undefined}}']}

    # First test: all variables in av are known to templar
    v = AnsibleJ2Vars(templar, globals, locals=locals)
    assert v['l_dict'] == locals['l_dict']
    assert v['l_list'] == locals['l_list']
    assert v['g_undefined'] == globals['g_undefined']
   

# Generated at 2022-06-11 17:25:21.767200
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import safe_eval
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)

# Generated at 2022-06-11 17:25:28.525364
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    globals = { "test1": "test1", "test2": "test2" }
    vars = AnsibleJ2Vars(templar, globals)

    assert vars["test1"] == 'test1'
    assert vars["test2"] == 'test2'
    assert vars["not_exist"] == KeyError


# Generated at 2022-06-11 17:25:31.912853
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass

# Generated at 2022-06-11 17:25:33.195969
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # TODO: implement
    assert(False)


# Generated at 2022-06-11 17:25:43.642575
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    import os

    # Load some test data
    current_dir = os.path.dirname(os.path.realpath(__file__))
    vars_dir = os.path.join(current_dir, 'vars')
    loader = DataLoader()
    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory("%s/hosts" % vars_dir))

    # Create the j2vars object
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)
    j

# Generated at 2022-06-11 17:25:44.827708
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass


# Generated at 2022-06-11 17:25:53.046481
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    yaml_dict = {'a': 1}
    host_vars = HostVars(yaml_dict, 'localhost')
    yaml_dict = {'b': 2}
    host_vars_2 = HostVars(yaml_dict, 'localhost')
    # 1. test host_vars
    templar = Templar()
    ansible_j2_vars = AnsibleJ2Vars(templar, {}, {'vars': host_vars})
    var = ansible_j2_vars['vars']
    assert var == host_vars
    # 2. test host_vars_2

# Generated at 2022-06-11 17:26:00.414029
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    x = AnsibleJ2Vars(None, {'a': 2, 'b': 3}, locals={'l_x': 5, 'l_y': 6})
    assert x['a'] == 2
    assert x['b'] == 3
    assert x['l_x'] == 5
    assert x['l_y'] == 6
    assert x['c'] == missing
    x = AnsibleJ2Vars(None, {'a': HostVars({}), 'b': 3}, locals={'l_x': 5, 'l_y': 6})
    assert x['a'] == HostVars({})
    assert x['b'] == 3
    assert x['l_x'] == 5
    assert x['l_y'] == 6
    assert x['c']

# Generated at 2022-06-11 17:26:08.311930
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar({}, {}, None, None)
    globals = {'g1': 'g1_value'}
    locals = {'l1': 'l1_value'}
    j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in j2_vars
    assert 'l1' in j2_vars
    assert j2_vars['g1'] == 'g1_value'
    assert j2_vars['l1'] == 'l1_value'

# Generated at 2022-06-11 17:26:19.895331
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    templar = Templar(loader=None, variables={'test_var': AnsibleUnicode('test1')})
    # Test variable contained in templar, globals but not locals
    ans_j2_vars = AnsibleJ2Vars(templar, {'test_var': 'test2'})
    assert 'test_var' in ans_j2_vars
    # Test variable contained in templar and locals but not globals
    ans_j2_vars = AnsibleJ2Vars(templar, {'no_var': 'test'})
    assert 'test_var' in ans_j2_vars
    # Test variable contained in templar, globals and locals

# Generated at 2022-06-11 17:26:30.454900
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # AnsibleJ2Vars should support variable templates
    from ansible.template import Templar
    templar = Templar(loader=None)
    global_vars = dict(global_var = 'global_var_value')
    local_vars = dict(local_var = 'local_var_value')
    vars_proxy = AnsibleJ2Vars(templar, global_vars, local_vars)

    assert vars_proxy['global_var'] == global_vars['global_var']
    assert vars_proxy['local_var'] == local_vars['local_var']

    # Jinja2 globals should be available in templates
    templar.set_available_variables({'template_var': '{{ global_var }}'})

    assert vars_proxy['template_var'] == global_

# Generated at 2022-06-11 17:26:41.833470
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    var_dict = dict(temp_var_1='temp_value1', temp_var_2='temp_value2', temp_var_3='temp_value3')
    available_variables = dict(a_var='a value', b_var='b value')
    globals = dict(g_var='g value')
    obj = AnsibleJ2Vars('AnsibleJ2Vars:templar',
                        globals=globals,
                        locals=dict(local_var1='local value1',
                                    local_var2='local value2',
                                    local_var3='local value3')
                       )
    result = set([element for element in obj])
    expected_result = set(('local_var1', 'local_var2', 'local_var3', 'g_var'))
    assert result

# Generated at 2022-06-11 17:26:55.419229
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import os

    if not hasattr(os, 'set_inheritable'):
        set_inheritable = os.environment.setdefault
    else:
        def set_inheritable(d, k, v):
            d[k] = v

    os.environ['ANSIBLE_SYSTEM_TEMPLATES'] = os.getcwd() + '/lib/ansible/template/modules'
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'hostvars': HostVars(None,{})})
    my_vars = AnsibleJ2Vars(templar, {'my_global': 'hello'}, locals={})
    assert len(my_vars) == 3

# Generated at 2022-06-11 17:26:59.503933
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    templar = Templar(loader=None, variables={'a_var': 1})
    globals = {'a_global': 2}
    locals = {'a_local': 3}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'a_var' in vars
    assert 'a_global' in vars
    assert 'a_local' in vars
    # We can't use 'in' keyword to test for non existing variable
    assert ('a_non_existing' not in vars) or (False)

    # Test __contains__ with expression

# Generated at 2022-06-11 17:27:06.219456
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # TODO: Write unit test for __contains__ and __getitem__, too
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert(ajv is not None)


# Generated at 2022-06-11 17:27:16.726781
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # do not use "from ansible.parsing.dataloader import DataLoader"
    # it will load the inventory plugin too early
    from ansible.parsing.dataloader import DataLoader
    variable_manager = VariableManager()
    variable_manager.set_inventory(DataLoader().load_inventory(['localhost']))
    globals = dict(hello='world')
    locals = dict(foo='bar')
    v = AnsibleJ2Vars(Templar(variable_manager=variable_manager), globals, locals)
    assert v['hello'] == 'world'
    assert v['foo'] == 'bar'
    assert v['inventory_hostname'] == 'localhost'

# Generated at 2022-06-11 17:27:27.838657
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    # create an instance of Templar
    templar = Templar(loader=None)

    # create an instance of the variable 'vars'
    vars = {}
    # define some variable into variable 'vars'
    vars['var1'] = 'I am vars variable'
    vars['var2'] = 'I am vars variable'
    # create an instance of the variable 'hostvars'
    hostvars = HostVars(host=None, variables=None)
    # define some variable into variable 'hostvars'
    hostvars['var3'] = 'I am hostvars variable'
    hostvars['var4'] = 'I am hostvars variable'
    # create an instance of the variable 'gl

# Generated at 2022-06-11 17:27:38.717869
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import jinja2
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=DataLoader(), variables=VariableManager())
    magic_globals = {'foo': 'bar'}
    magic_locals = {'foo': 'baz'}
    magic_vars = {'foo': 'qux'}
    templar.available_variables = {'foo': AnsibleUnsafeText('qux')}
    vars_proxy = AnsibleJ2Vars(templar, magic_globals, magic_locals)

    ref = set(magic_vars).union(magic_globals)

    # New style

# Generated at 2022-06-11 17:27:44.030292
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.template
    templar = ansible.template.AnsibleJ2TemplateVars(loader=None)
    globals = dict()

    vars = AnsibleJ2Vars(templar, globals, locals=None)
    try:
        vars['undefined_var']
    except Exception as e:
        assert type(e) == KeyError
        assert "undefined variable: undefined_var" in str(e)

# Generated at 2022-06-11 17:27:54.992307
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # Create a simple AnsibleJ2Vars object to test
    templar = AnsibleTemplate()
    j2vars = AnsibleJ2Vars(templar, {})

    # Test a simple variable
    assert j2vars['name'] == 'John'

    # Test an undefined variable
    try:
        j2vars['surname']
    except KeyError:
        assert True
    except:
        assert False

    # Test a dictionary
    assert j2vars['address'] == {'city': 'New York', 'country': 'USA'}

    # Test a dictionary with undefined variables
    try:
        j2vars['address_with_undefined']
    except KeyError:
        assert True
    except:
        assert False

    # Test a defined variable inside a dictionary of undefined variables

# Generated at 2022-06-11 17:28:06.565083
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # test__contains__()
    from ansible.template.safe_eval import assert_expr
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import PY3

    from ansible.template import Templar

    class DummyVarsModule(object):
        def __init__(self, data):
            self._data = data

        def get_vars(self):
            return self._data

    class DummyHost(object):
        def __init__(self):
            self.vars = dict(a=1, b=2, c=3)

    class DummyPlayContext(object):
        def __init__(self):
            self.extra_vars = dict(a=5)

# Generated at 2022-06-11 17:28:18.669822
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import jinja2
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'var1':'var1Value', 'var2':'var2Value'}
    locals = {'var1':'var1LocalValue'}
    dut = AnsibleJ2Vars(templar, globals, locals)
    assert dut['var1'] == 'var1LocalValue'
    assert dut['var2'] == 'var2Value'
    #known to fail
    #assert dut['var3'] == KeyError("undefined variable: %s" % varname)
    assert 'var1' in dut
    assert 'var2' in d

# Generated at 2022-06-11 17:28:30.880115
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    vars_dict = {
        'var_a': 'var_a',
        'var_b': 'var_b',
        'var_c': 'var_c'
    }

    t = Templar(loader=None)
    t.set_available_variables(vars_dict)

    proxy = AnsibleJ2Vars(t, globals=None)
    assert len(proxy) == 3
    assert set(proxy) == set(vars_dict)

# Generated at 2022-06-11 17:28:41.246859
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import mock
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    templar = mock.Mock(spec=Templar)
    templar.template = mock.Mock()
    templar.template.return_value = 11

    hp = HostVars(None)
    globals = {'g': 9}
    locals = {'l_l': 10, 'context': 'test', 'environment': 'test', 'template': 'test'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert vars['g'] == 9
    assert vars['l'] == 10
    assert vars['hp'] == hp

    templar.template.assert_called_once_with(11)

# Generated at 2022-06-11 17:28:47.114237
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var
    templar = Templar(loader=None)

    vars = {'key1': {'key2': 'val2'}, wrap_var('dict'): {}}

    len(AnsibleJ2Vars(templar, vars))



# Generated at 2022-06-11 17:28:56.031543
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a':1, 'b':2}
    templar = Templar(loader=None, variables=variable_manager)
    j2vars = AnsibleJ2Vars(templar, {'c':3}, locals={'d':4})

    if 'a' not in j2vars:
        raise Exception("'a' should be in j2vars")
    if 'b' not in j2vars:
        raise Exception("'b' should be in j2vars")

# Generated at 2022-06-11 17:29:07.525732
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    # return a hostvars object
    hostvars = HostVars(hostvars='hostvars')
    templar = 'templar'
    globals = {'hostvars': hostvars}
    locals = {'hostvars': hostvars}
    # create a AnsibleJ2Vars object
    vars = AnsibleJ2Vars(templar, globals, locals)
    # check if __getitem__ can return a HostVars object
    assert isinstance(vars['hostvars'], HostVars)
    # check if __getitem__ returns a correct HostVars object
    assert vars['hostvars'].hostvars == 'hostvars'
    # return 'vars' variable

# Generated at 2022-06-11 17:29:19.469306
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import mock
    import ansible.playbook.templar

    templar = ansible.playbook.templar.Templar(loader=None)
    templar._available_variables = {'vars': {'a': '1'}, 'a': '2', 'b': '3', 'c': '4'}

    env = AnsibleJ2Vars(templar, {'b': '5', 'd': '6'})

    assert env['vars'] == {'a': '1'}
    assert env['a'] == '2'
    assert env['b'] == '5'
    assert env['d'] == '6'
    assert env['c'] == '4'


# Generated at 2022-06-11 17:29:23.787690
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    j2vars = AnsibleJ2Vars(Templar(VariableManager()), {})
    assert len(j2vars) == 0
    assert 'vars' not in j2vars

# Generated at 2022-06-11 17:29:32.542530
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class MockTemplar:
        def __init__(self, available_variables):
            self.available_variables = available_variables

        def template(self, variable):
            return variable

    mock_available_variables = {
            'test_available_var': 1,
            'test_available_var2': 1,
           }
    mock_locals = {
            'test_locals_var': 1,
            'test_locals_var2': 1,
           }
    mock_globals = {
            'test_globals_var': 1,
            'test_globals_var2': 1,
           }
    mock_templar = MockTemplar(mock_available_variables)

# Generated at 2022-06-11 17:29:44.270636
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.template
    from ansible.vars.hostvars import HostVars
    templar = ansible.template.AnsibleTemplar(loader=None)
    templar.available_variables = {
        'a':'b',
        'c': 'd',
        'x':[1,2,3,4],
        'y':{'a':'b','c':'d'}
    }
    globals = {
        'g1':'g1',
        'g2':'g2'
    }
    proxy = AnsibleJ2Vars(templar, globals)
    assert proxy['a'] == 'b'
    assert proxy['c'] == 'd'
    assert proxy['x'] == [1,2,3,4]

# Generated at 2022-06-11 17:29:55.691851
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    """Unit test for AnsibleJ2Vars"""
    from ansible.template.safe_eval import unsafe_eval
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    def __init__(self):
        self.inventory = None
        self.variable_manager = VariableManager()

    loader = DataLoader()
    context = PlayContext()
    context.connection = 'local'
    context.remote_addr = '127.0.0.1'
    context.remote_user = 'root'
    context.port = 1234
    context.become = True
    context.become_method = 'sudo'
    context.become_user = 'root'
   

# Generated at 2022-06-11 17:30:10.363386
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2
    temp = jinja2.Template('{{ var1 }}')
    glob = {"var1": 200}
    loc = {"var2": 300}
    aj2v = AnsibleJ2Vars(temp, glob, loc)
    assert len(aj2v) == 3

# Generated at 2022-06-11 17:30:18.081714
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    var_manager = VariableManager()
    templar = Templar(loader=loader, variables=var_manager)

    vars = AnsibleJ2Vars(templar, {})
    print(vars['inventory_hostname'])
    print(vars['foo'])


# Generated at 2022-06-11 17:30:28.154050
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    b_template = Templar(loader=None, variables={"var_a": "hello", "var_b": AnsibleUnsafeText("hello")})
    b_context = PlayContext()
    b_context._hostvars = HostVars(loader=None, inventory=None, hostname="myhost")
    b_context._hostvars.data["var_c"] = "hello"

    assert AnsibleJ2Vars(b_template, globals={}).__getitem__("var_a") == "hello"

# Generated at 2022-06-11 17:30:39.509102
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars


# Generated at 2022-06-11 17:30:46.733155
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import SafeEval
    from ansible.template import Templar
    import jinja2
    # create a globals dict, a Templar() object, and a AnsibleJ2Vars() object
    globals_dict = {'test_key': 'test_key_value'}
    templar = Templar(loader=jinja2.DictLoader({}))
    j2vars = AnsibleJ2Vars(templar, globals_dict)
    # j2vars should be a dict-like object
    assert isinstance(j2vars, dict)
    # the key 'test_key' is in globals dict,
    # so the length of j2vars should be 1
    assert len(j2vars) == 1


# Generated at 2022-06-11 17:30:51.082771
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = {'toto': 'tata'}
    locals = {'l_titi': 'tutu'}

    obj = AnsibleJ2Vars(templar, globals, locals=locals)
    if 'toto' in obj:
        print("OK")
    if 'titi' in obj:
        print("OK")
    try:
        print(obj['toto'])
    except KeyError:
        print("KeyError")
    try:
        print(obj['titi'])
    except KeyError:
        print("KeyError")

# Generated at 2022-06-11 17:30:58.184395
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # bingo -> 'bingo'
    globals = {'bingo': 'bingo'}
    locals = {'l_bango': 'bango'}
    from ansible.template import Templar
    templar = Templar(loader=None)
    # bingo -> 'bingo'
    templar.available_variables = globals
    x = AnsibleJ2Vars(templar, globals, locals)
    assert (x['bingo'] == 'bingo')

    # bango -> 'bango'
    assert (x['bango'] == 'bango')

    # bango -> 'bango'
    # bingo -> 'bingo'
    # NOTE: 'l_bango' is in the set.
    x = set(x)

# Generated at 2022-06-11 17:31:10.079554
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.safe_eval import safe_eval
    # test_dict = {"a": "{{b}}", "b": "{{c}}", "c": "Hello", "d": 123}

# Generated at 2022-06-11 17:31:13.555773
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    t = Templar(loader=None, variables=None)
    v = AnsibleJ2Vars(t, {}, {})
    assert 'foo' not in v
    v._locals['foo'] = 'bar'
    assert 'foo' in v


# Generated at 2022-06-11 17:31:24.870795
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar()
    templar.available_variables = {
            'foo': 'bar'
    }

    ajv = AnsibleJ2Vars(templar,
                        {'global_var': 'global_value'},
                        {'local_var': 'local_value'})

    assert ajv.__contains__('local_var')
    assert ajv.__contains__('local_var') == True
    assert 'local_var' in ajv
    assert ajv.__contains__('not_there') == False
    assert 'not_there' not in ajv
    assert ajv.__contains__('global_var')
    assert ajv.__contains__('global_var') == True

# Generated at 2022-06-11 17:32:06.452773
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_obj = AnsibleJ2Vars()
    loc = locals()
    # create a fake local variable
    loc['test_var'] = 1234
    assert(test_obj.__contains__('test_var'))
    # check if a wrong variable is properly detected
    assert(not test_obj.__contains__('wrong_var'))


# Generated at 2022-06-11 17:32:13.716636
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import jinja2
    from ansible.module_utils._text import to_bytes
    from io import BytesIO
    from ansible.parsing.vault import VaultLib

    _loader = jinja2.DictLoader({'t.j2': '{{a}}'})

    # Create jinja environment
    _environment = jinja2.Environment(loader=_loader, undefined=jinja2.StrictUndefined)

    # Create vars, consolodating vars, template vars
    _vars = VariableManager()
    _vars.extra_vars = {}
    _consolidate_vars = _vars._get_vars(loader=None)
    _template_vars = _environment.gl

# Generated at 2022-06-11 17:32:18.586267
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Get the class
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)

    vars_instance = AnsibleJ2Vars(
        templar=templar,
        globals=dict(),
    )

    # Case 1: defined variable, not special
    for var in ('foo', 'bar'):
        templar.available_variables[var] = var

    for var in ('foo', 'bar'):
        assert var == vars_instance[var]

    # Case 2: defined variable, special
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    templar.available_variables['vars'] = {'foo': 'foo'}

# Generated at 2022-06-11 17:32:19.249083
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-11 17:32:23.563699
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar1 = Templar(loader=None)
    ansible_j2vars1 = AnsibleJ2Vars(templar=templar1, globals={})

    assert 'testvar' not in ansible_j2vars1

    templar2 = Templar(loader=None)
    ansible_j2vars2 = AnsibleJ2Vars(templar=templar2, globals={'testvar': 'testval'})

    assert 'testvar' in ansible_j2vars2



# Generated at 2022-06-11 17:32:32.078528
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.inventory.host import Host
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    globals = {
        'foo': 'bar',
    }
    locals = {
        'baz': 'bam',
    }

    host = Host('test_template')
    hostvars = HostVars(host, lambda x: None)
    hostvars.set_variable('a', 'A')
    hostvars.set_variable('b', 'B')

    templar = Templar(loader=None)
    templar._available_variables = hostvars.get_vars()

    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # globals

# Generated at 2022-06-11 17:32:32.567477
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-11 17:32:40.692300
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class TestTemplar(object):
        available_variables = dict()

    # Initialize AnsibleJ2Vars with empty values
    test_vars_globals = dict()
    test_vars_locals = dict()
    test_vars_templar = TestTemplar()
    test_AnsibleJ2Vars = AnsibleJ2Vars(test_vars_templar, test_vars_globals, test_vars_locals)
    variable_name = 'var'
    variable_value = 0

    # Test the case that the variable is in the locals
    test_vars_locals[variable_name] = variable_value
    assert variable_name in test_AnsibleJ2Vars

    # Test the case that the variable is in the available_variables
   

# Generated at 2022-06-11 17:32:51.653791
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    v = AnsibleJ2Vars(templar, {'a':1, 'b':2, 'c':3}, locals={ 'd':4, 'e':5 })
    assert v['a'] == 1
    assert v['b'] == 2
    assert v['c'] == 3
    assert v['d'] == 4
    assert v['e'] == 5

    templar._available_variables = {'f':6, 'g':7}
    assert v['f'] == 6
    assert v['g'] == 7

    templar._available_variables = {'h':"{{ x }}"}

# Generated at 2022-06-11 17:33:03.220183
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.template import Templar

    vars_manager = VariableManager()
    hostvars = dict(test_hostvars_key='test_hostvars_val')
    variables = dict(test_variables_key='test_variables_val')
    group_vars = dict(test_group_vars_key='test_group_vars_val')
    play_vars = dict(test_play_vars_key='test_play_vars_val')
    module_vars = dict(test_module_vars_key='test_module_vars_val')

    vars_manager.set_host_variable(hostvars_key='test_hostvars_key', hostvars_val='test_hostvars_val')
    vars