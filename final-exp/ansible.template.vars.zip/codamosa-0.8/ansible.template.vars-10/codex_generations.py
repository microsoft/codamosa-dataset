

# Generated at 2022-06-11 17:24:14.176920
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Setup environment
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    locals["hostvars"] = HostVars(Host(name='testhost'), dict())
    locals["hostvars"]["testhost"]["var1"] = AnsibleUnicode('val1')
    vars = AnsibleJ2Vars(templar, globals, locals=locals)
    # Test checks
    assert 'hostvars' in vars
    assert 'var1' in vars
    assert 'var2' not in vars

#

# Generated at 2022-06-11 17:24:24.721804
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class Templar:
        def __init__(self, available_variables):
            self.available_variables = available_variables

    # Test creating an AnsibleJ2Vars object
    templar = Templar({'a':1,'b':2,'c':3})
    ansible_j2_vars = AnsibleJ2Vars(templar, {}, locals={})
    assert set(ansible_j2_vars.__iter__()) == set(['a','b','c']) == set(['a','b','c'])

    # Test creating an AnsibleJ2Vars object with globals
    templar = Templar({'a':1,'b':2,'c':3})

# Generated at 2022-06-11 17:24:35.385281
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'var1': 'value1'})
    vars_proxy = AnsibleJ2Vars(templar, globals={'g_var1': 'globals'}, locals={'l_var1': 'locals'})

    assert 'var1' in vars_proxy
    assert 'g_var1' in vars_proxy
    assert 'l_var1' in vars_proxy
    assert 'var2' not in vars_proxy
    assert 'g_var2' not in vars_proxy
    assert 'l_var2' not in vars_proxy

# Generated at 2022-06-11 17:24:47.611495
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import context
    import unittest
    import os
    import sys

    sys.modules['_ansible'] = context

    from ansible import module_utils
    from ansible.template import Templar

    mytemplar = Templar(loader=None)

    ##################################################################################
    # Test case #1: defined (local) variable
    ##################################################################################

    myvar = "localvar"
    mylocals = {myvar: "value"}
    myglobals = {}

    myvars = AnsibleJ2Vars(mytemplar, myglobals, locals=mylocals)

    assert myvars[myvar] == "value"

    ##################################################################################
    # Test case #2: defined (global) variable
    ##################################################################################

    myvar = "globalvar"
    my

# Generated at 2022-06-11 17:24:50.898544
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.errors import AnsibleUndefinedVariable
    __tracebackhide__ = True

    t = AnsibleJ2Vars()
    try:
        print(t['test'])
        raise Exception("AnsibleUndefinedVariable should have been riased")
    except AnsibleUndefinedVariable:
        pass


# Generated at 2022-06-11 17:24:53.928600
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        AnsibleJ2Vars(None, {})['abc']
    except KeyError as ke:
        if 'abc' in str(ke):
            exit(0)

    exit(1)

# Generated at 2022-06-11 17:25:02.867460
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Make sure AnsibleJ2Vars.__contains__ works as we expect.
    '''
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    globals = dict({'foo': 'bar'})
    locals = dict()
    jv = AnsibleJ2Vars(templar, globals, locals)

    assert 'foo' in jv
    assert 'bar' not in jv
    assert 'this_is_a_very_long_variable_name' not in jv

    locals = dict({'this_is_a_very_long_variable_name': 'foo'})
    jv = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-11 17:25:12.498450
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    play_context = PlayContext()
    play_context.update(dict(
        connection='local',
        network_os='dummy',
        become=False,
        become_method='dummy',
        become_user='dummy',
        module_name='dummy',
        module_path='dummy',
        tmpdir='dummy',
    ))
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)


# Generated at 2022-06-11 17:25:22.558825
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import sys
    import pytest

    @pytest.fixture
    def templar(request):
        from ansible.template import Templar
        request.cls.templar = Templar(loader=None)
        return request.cls.templar

    @pytest.fixture
    def my_vars(request):
        from ansible.vars.unsafe_proxy import AnsibleUnsafeText
        request.cls.my_vars = {}
        request.cls.my_vars['dummy'] = {'abc': 'def', 'ghi': 'jkl'}
        request.cls.my_vars['dummy2'] = {'abc': 'def', 'ghi': 'jkl'}

# Generated at 2022-06-11 17:25:31.302301
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    orig_templar = {}
    globals = {"g0": 1, "g1": 2, "g2": 3}
    locals = {"l0": 4, "l1": 5}
    ansible_j2vars = AnsibleJ2Vars(orig_templar, globals, locals=locals)
    a = list(ansible_j2vars.__iter__())
    assert a == ['g0', 'g1', 'g2', 'l0', 'l1'], "__iter__ method of class AnsibleJ2Vars failed"

# Generated at 2022-06-11 17:25:48.144567
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    my_globals = {
        'dict_1': {
            'key_1': 'value_1_original',
            'key_2': 'value_2_original',
        },
    }
    my_locals = {
        'dict_1': {
            'key_1': 'value_1_override',
            'key_3': 'value_3',
        },
    }

    from ansible.template import Templar
    my_templar = Templar(basedir=None, variables=None)
    my_j2vars = AnsibleJ2Vars(my_templar, my_globals, locals=my_locals)

    from ansible.vars.hostvars import HostVars
    hostvars_special = HostVars(HostVars.TRUE)
   

# Generated at 2022-06-11 17:25:59.207462
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.errors as errors
    import ansible.module_utils.facts as facts
    import ansible.template.templar as templar

    def exception_getitem(self, varname):
        if varname == 'exception_to_raise':
            raise errors.AnsibleError('AnsibleError raised to test method __contains__ of class AnsibleJ2Vars')
        raise KeyError('KeyError raised to test method __contains__ of class AnsibleJ2Vars')

    def exception_contains(self, k):
        raise errors.AnsibleError('AnsibleError raised to test method __contains__ of class AnsibleJ2Vars')


# Generated at 2022-06-11 17:26:08.313600
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.module_utils.common._collections_compat import Mapping

    class MyTestVars(Mapping):
        def __contains__(self, key):
            return True
        def __getitem__(self, key):
            return None
        def __iter__(self):
            return None
        def __len__(self):
            return 0

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.template import jinja2_native

    # initialize mytestvars, templar and context
    mytestvars = MyTestVars()
    templar    = Templar(loader=None, variables=mytestvars)
    context    = PlayContext()

    # create instance of AnsibleJ2Vars
    # keys and vars

# Generated at 2022-06-11 17:26:19.895366
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()

    templar = Templar(loader=None, variables=dict())

    # inject vars into templar
    templar._add_host_vars(dict())
    templar._add_host_group_vars(dict())
    templar._add_task_vars(dict())
    templar._add_extra_vars(dict())
    templar._add_included_var_files(dict())
    templar._add_extra_vars(dict())


    globals = dict()
    locals = dict()

    ansible_vars = AnsibleJ2Vars(templar, globals, locals)



# Generated at 2022-06-11 17:26:30.418409
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    It should return the length of the set of the available variables.
    It should raise a KeyError exception if the key does not exist.
    It should return the length of the set of the available variables.
    It should raise a KeyError exception if the key does not exist.
    It should return the length of the set of the available variables.
    """
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    # initialise the object
    J2Vars = AnsibleJ2Vars(Templar, {'one' : 1}, locals={'two' : 2})

    # test case 1
    assert len(J2Vars) == 3

    # test case 2

# Generated at 2022-06-11 17:26:41.793687
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    templar = Templar(None, None, None)
    globals = dict()
    locals = dict()
    aj2v = AnsibleJ2Vars(templar, globals, locals)

    # test when variable is in locals
    locals['my_var'] = 'foo'
    value = aj2v['my_var']
    assert value == 'foo'

    # test when variable is in available_variables
    templar.available_variables['my_var'] = 'baz'
    value = aj2v['my_var']
    assert value == 'baz'

    # test when variable is in globals
    globals['my_var'] = 'bar'
    value = aj2v['my_var']
    assert value == 'bar'



# Generated at 2022-06-11 17:26:51.222672
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
   from ansible.template import Templar
   templar = Templar()
   templar._available_variables = {'a':1, 'b':2, 'c':3}
   vars = AnsibleJ2Vars(templar, {'d':4, 'e':5})
   assert vars['a'] == 1
   assert vars['b'] == 2

   try:
     vars['f']
     assert False
   except KeyError:
     assert True

   assert 'c' in vars
   assert 'f' not in vars

# Generated at 2022-06-11 17:27:01.167433
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar()

    locals = {'l_mylocalvar': 'mylocalvarvalue'}
    globals = {'g_myglobalvar': 'myglobalvarvalue'}
    hostvars = HostVars(dict(h_myhostvar='myhostvarvalue'))
    available_variables = {'v_myavailablevar': 'myavailablevarvalue',
                           'hostvars': hostvars,
                           'vars': {'v_myvarsvar': 'myvarsvarvalue', 'mydict': {'mykey': 'myvalue'}}}
    # We have to mock like this, because available_variables is

# Generated at 2022-06-11 17:27:12.852667
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    #
    #
    # setup
    #
    templar = Templar(loader=DataLoader())
    variables = VariableManager()
    inventory = InventoryManager(loader=DataLoader(), sources=[])
    play_context = PlayContext()
    play_context.check_mode = True
    play_context.become = True
    #
    #
    # test
    #
    test_vars = AnsibleJ

# Generated at 2022-06-11 17:27:19.608947
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    j2_vars = AnsibleJ2Vars(
        templar.Templar(loader=None, variables={'v1': 1, 'v2': 2}),
        globals={'g1': 1, 'g2': 2},
        locals={'l1': 1, 'l2': 2})

    assert 'v1' in j2_vars
    assert 'l1' in j2_vars
    assert 'g1' in j2_vars
    assert 'v11' not in j2_vars
    assert 'l11' not in j2_vars
    assert 'g11' not in j2_vars

# Generated at 2022-06-11 17:27:45.035959
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import ansible.parsing.dataloader
    from ansible.vars.hostvars import HostVars
    a = dict(a=1)
    b = dict(b=2)
    c = dict(c=3)
    d = dict(d=4)
    e = dict(e=5)
    f = dict(f=6)
    g = dict(g=7)
    h = dict(h=8)
    i = dict(i=9)
    j = dict(j=10)
    k = dict(k=11)
    l = dict(l=12)
    m = dict(m=13)
    n = dict(n=14)
    o = dict(o=15)
    p = dict(p=16)
    q = dict(q=17)

# Generated at 2022-06-11 17:27:50.498027
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    mock_loader = None
    mock_inventory = InventoryManager(loader=mock_loader, sources='localhost,')
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)
    mock_vault_secrets = {}
    mock_vault_password_files = []
    mock_vault_secrets_only = False
    mock_vault = VaultLib(mock_vault_secrets, mock_vault_password_files, mock_vault_secrets_only)
    mock_play_context = PlayContext()
    mock_globals = {}

# Generated at 2022-06-11 17:27:58.364996
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    import pytest

    templar = Templar()

    # test __UNSAFE__ attribute
    globals = {'test': AnsibleUnsafeText('test')}
    locals = {'test': AnsibleUnsafeText('test')}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test'] == 'test'
    assert ansible_j2_vars['test'] == globals['test'] == locals['test']

    # test ansible_unsafe_text
    globals = {'test': 'test'}

# Generated at 2022-06-11 17:28:08.690284
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    locals_var = {'l_key1': 'value1', 'l_key2': 'value2'}
    given_globals = {'g_key1': 'value3', 'g_key2': 'value4'}
    given_vars = {'key1': 'value5', 'key2': 'value6'}

    templar.set_available_variables(given_vars)
    j2vars = AnsibleJ2Vars(templar, given_globals, locals=locals_var)
    assert len(j2vars) == 6


# Generated at 2022-06-11 17:28:20.925585
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.utils import context_objects as co

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'var_a':'var_a_value'}
    variable_manager._fact_cache = {'var_b':'var_b_value'}
    variable_manager._variable_manager = variable_manager
    variable_manager.options_vars = {'var_c':'var_c_value'}
    variable_manager._vars_from_files = {'var_d':'var_d_value'}
    variable_manager._host_vars_files = {'var_e':'var_e_value'}
    templar = co.AnsibleContext(variable_manager=variable_manager)
    j

# Generated at 2022-06-11 17:28:29.789548
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import sys
    import os

    import jinja2
    import ansible.playbook
    import ansible.inventory
    import ansible.template
    import ansible.vars
    import ansible.parsing.dataloader

    loader = DataLoader()
    inv = ansible.inventory.Inventory(loader=loader, variable_manager=ansible.vars.VariableManager(), host_list=['localhost'])
    variable_manager = ansible.vars.VariableManager()
    variable_manager.set_inventory(inv)
    playbook_path = os.path.join(os.path.dirname(sys.argv[0]), '../../../test/units/ansible/playlib/test_playbook.yml')

# Generated at 2022-06-11 17:28:40.554451
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import sys
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    from ansible.templating import Templar
    from ansible.vars import VariableManager

    from ansible.vars.hostvars import HostVars

    with patch.object(sys, 'modules', {'_ansible_action_plugins': object, 'ansible.plugins.action': object}):
        templar = Templar()
    vm = VariableManager()
    jv = AnsibleJ2Vars(templar, {'a': 1}, locals={'b': 2})

    assert jv['a'] == 1
    assert jv['b'] == 2

    vm.set_host_variable('127.0.0.1', 'c', 3)
    templar.set_available

# Generated at 2022-06-11 17:28:52.062411
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    templar = Templar(loader=None)

    globals = {'test_global':1}
    locals  = {'test_locals':2}
    vars = {'test_vars':3}

    ansible_vars = AnsibleJ2Vars(templar, globals, locals)

    assert(ansible_vars['test_global'] == 1)
    assert(ansible_vars['test_locals'] == 2)
    try:
        ansible_vars['test_vars']
    except Exception as e:
        assert(hasattr(e, 'message'))
        assert(e.message == "undefined variable: 'test_vars'")
    else:
        raise Exception("Exception failure: test_vars")

# Generated at 2022-06-11 17:29:03.853248
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    from ansible.vars.hostvars import HostVars

    flags = dict(
        no_log=False,
        no_lookup=False
    )
    templar = Templar(loader=None, variables=dict(), fail_on_undefined=True, flags=flags)
    globals = dict(
        hostvars=HostVars(templar, dict())
    )

    ansible_j2_vars = AnsibleJ2Vars(templar, globals)
    assert not ('undefined_variable' in ansible_j2_vars)

    variables = dict()
    variables['undefined_variable'] = dict(
        name='undefined_variable',
        value=''
    )

# Generated at 2022-06-11 17:29:11.372932
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Create a fake Templar class due to lack of public constructors
    class Templar:
        def __init__(self, vars):
            self.available_variables = vars
        def template(self, variable):
            return self.available_variables[variable]

    vars = {'hello': 'world', 'foo': {'some': 'stuff'}, 'bar': [1,2,3], 'baz': 42}
    templar = Templar(vars)

    # Test with a local variable in _locals
    j2 = AnsibleJ2Vars(templar, {}, {'l_hello': 'world'})
    assert j2['hello'] == 'world'

    # Test with a local variable in _locals and _globals

# Generated at 2022-06-11 17:29:42.127095
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar(loader=None)

    class DictSubclass(dict):
        def __init__(self, data=None, **kwargs):
            super(DictSubclass, self).__init__(**kwargs)
            if data is None:
                data = dict()
            self.update(data)

    templar._available_variables = DictSubclass({'var1': 'value1'})
    assert 'var1' in templar._available_variables

    globals = dict()
    locals = dict()
    globals['var2'] = 'value2'
    locals['var3'] = 'value3'

    vars_ = AnsibleJ2Vars(templar, globals, locals)
    assert 'var1' in vars_

# Generated at 2022-06-11 17:29:53.346272
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.playbook.play import Play
        from ansible.executor.task_queue_manager import TaskQueueManager
        from ansible.plugins.callback import CallbackBase
        from ansible.template import Templar
    except:
        print('Module import error. Please check library path.')
        return False

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-11 17:29:54.382337
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass



# Generated at 2022-06-11 17:30:06.022866
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test data
    class EmptyClass:
        pass
    obj_empty_class = EmptyClass()
    var_empty_class = EmptyClass()
    class Templar:
        available_variables = {
            'var_empty_dict': {},
            'var_empty_list': [],
            'var_empty_class': obj_empty_class,
        }
    templar = Templar()
    globals = {
        'var_empty_dict': {},
        'var_empty_list': [],
        'var_empty_class': var_empty_class,
    }
    locals = {
        'loc_empty_dict': {},
        'loc_empty_list': [],
        'loc_empty_class': obj_empty_class,
    }
    ansible_j2_vars = Ans

# Generated at 2022-06-11 17:30:09.022490
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar:
        available_variables = dict()

        def template(self, value):
            return 42

    vars = AnsibleJ2Vars(Templar(), globals=dict())
    assert vars['foo'] == 42



# Generated at 2022-06-11 17:30:21.170335
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.module_utils.common._collections_compat import Dict

    # Test the case varname exists in self._locals
    templar = None
    globals = None
    locals = Dict()
    locals['l_foo'] = "bar"
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == "bar"

    # Test the case varname exists in self._globals
    templar = None
    globals = Dict()
    globals['foo'] = "bar"
    locals  = None
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == "bar"

    # Test the case varname exists in self._templar.available_variables


# Generated at 2022-06-11 17:30:29.695930
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class DummyTemplar(object):
        def __init__(self, available_variables):
            self.available_variables = available_variables

    # expected value
    expected = {'host_ip': '127.0.0.1'}
    expected.update({'host_name':'localhost'})

    # actual value
    templar = DummyTemplar(
        {'host_ip': '127.0.0.1', 'host_name': 'localhost'})
    globals = {}
    locals = {}
    actual = AnsibleJ2Vars(templar, globals, locals=locals)
    assert expected.keys() == actual.keys()
    assert expected.values() == actual.values()

# Generated at 2022-06-11 17:30:41.058339
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.playbook.play_context import PlayContext
    from ansible.template.safe_eval import safe_eval
    from ansible.template.templar import Templar

    g = { 'inventory_hostname': 'foo' }
    p = PlayContext()
    p.CLIARGS = { 'inventory': 'fake_inventory' }
    t = Templar(loader=None, variables={ 'inventory_hostname': 'foo' }, shared_loader_obj=None, **p.CLIARGS)
    aj2v = AnsibleJ2Vars(templar=t, globals=g, locals=dict())
    assert 'inventory_hostname' in aj2v, 'inventory_hostname found in aj2v'

# Generated at 2022-06-11 17:30:45.081146
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    unit test for method __getitem__ of class AnsibleJ2Vars
    '''
    ansible_j2vars = AnsibleJ2Vars(None, {})
    #TODO
    #assert ansible_j2vars.__getitem__("test") is None

# Generated at 2022-06-11 17:30:56.235952
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template.template import Templar
    # initilize class
    ansible_vars_globals = {'ansible_all_ipv4_addresses': ['127.0.0.1', '10.66.152.232']}
    ansible_vars_locals = {'x': 'y'}
    ansiblej2vars = AnsibleJ2Vars(Templar(loader=None, variables=ansible_vars_globals),
                                  ansible_vars_globals,
                                  ansible_vars_locals)
    # test __contains__ of class
    assert 'ansible_all_ipv4_addresses' in ansiblej2vars

# Generated at 2022-06-11 17:32:12.138623
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Test __getitem__
    '''
    # set up
    import jinja2
    templar = jinja2.Environment()
    globals = {
        "foo": {},
    }
    locals = {
        "bar": {},
        "buz": [],
    }
    target = AnsibleJ2Vars(templar, globals, locals)

    # test
    assert target['bar'] == {}
    assert target['buz'] == []
    assert target['foo'] == {}
    try:
        target['none']
        raise Exception('Should raise exception.')
    except KeyError:
        pass
    except Exception:
        raise Exception('Should raise KeyError.')

# Generated at 2022-06-11 17:32:23.626969
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar() # A mock object
#   globals = {'result': {'contacted': {'127.0.0.1': {'invocation': {'module_args': 'echo "inputvar"', 'module_name': 'shell'}, 'rc': 0, 'stdout': 'inputvar\n'}, 'changed': False}}}
#   locals = {'hostvars': {'127.0.0.1': {'ansible_all_ipv4_addresses': ['127.0.0.1'], 'ansible_all_ipv6_addresses': [], 'ansible_default_ipv4': {'address': '127.0.0.1', 'alias': 'lo', '

# Generated at 2022-06-11 17:32:24.524843
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass


# Generated at 2022-06-11 17:32:32.844617
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.templating import Templar
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C

    # Creating a templar object
    jvars = AnsibleJ2Vars(Templar(None, play_context=PlayContext(C.DEFAULT_HASH_BEHAVIOUR)), {})
    assert jvars is not None
    assert jvars._templar is not None
    assert jvars._globals is not None
    assert jvars._locals is not None
    # Creating a templar object without passing a play_context parameter (none)
    # and without passing a variable manager (none)
    jvars = AnsibleJ2Vars(Templar(), {})
    assert j

# Generated at 2022-06-11 17:32:39.925796
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Test that AnsibleJ2Vars.__contains__ works

    Check that AnsibleJ2Vars.__contains__ returns True when the variable is present
    and False when the variable is not present.

    :returns: None
    '''

    from ansible.template import Templar
    templar = Templar(None)
    # Add a few variables to the template, specific to test_AnsibleJ2Vars___contains__
    templar.available_variables = {'foo': 'bar'}
    proxy = AnsibleJ2Vars(templar, {}, None)
    assert 'foo' in proxy
    assert 'bar' not in proxy

# Generated at 2022-06-11 17:32:49.859986
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    templar = Templar(loader=None)

    j2_vars = AnsibleJ2Vars(templar, globals = {})

    assert len(list(j2_vars.__iter__())) == 0

    j2_vars = AnsibleJ2Vars(templar, globals = {'a': 1})

    assert len(list(j2_vars.__iter__())) == 1

    j2_vars = AnsibleJ2Vars(templar, globals = {'a': 1, 'b': 2})

    assert len(list(j2_vars.__iter__())) == 2


# Generated at 2022-06-11 17:32:53.419502
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    t = Templar(VariableManager())
    ansible_vars = AnsibleJ2Vars(t, globals={})
    assert (ansible_vars["test"] == "")



# Generated at 2022-06-11 17:32:59.155680
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = None
    vars = AnsibleJ2Vars(templar, {'a': {'b': {'c': 3}}})
    assert vars['a'] == {'b': {'c': 3}}
    assert vars['a.b'] == {'c': 3}
    assert vars['a.b.c'] == 3


# Generated at 2022-06-11 17:33:10.746498
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import pytest

    templar = Templar(loader=None, variables={'a': 1})
    play_context = PlayContext()
    play_context.vars = {'a': 2}
    j2vars = AnsibleJ2Vars(templar=templar, globals=None, locals=play_context.vars)

    assert 1 == j2vars['a']
    assert 2 == j2vars.add_locals({})['a']
    assert 2 == j2vars.add_locals({'a': 3})['a']
    assert 3 == j2vars.add_locals({'a': 3}).add_locals({})['a']
    assert 4 == j2v

# Generated at 2022-06-11 17:33:20.330235
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar(loader=None)