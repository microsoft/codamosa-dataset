

# Generated at 2022-06-11 17:24:03.237225
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_vars = AnsibleJ2Vars(
        templar=None,
        globals=dict(),
        locals=dict()
    )
    assert '_templar' in test_vars
    assert 'invalid_key' not in test_vars


# Generated at 2022-06-11 17:24:13.562025
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
  from ansible.template import Templar
  from ansible.vars.unsafe_proxy import UnsafeProxy

  locals = {
    'l_a': 1,
    'l_b': 2,
  }

  templar = Templar({
    't_c': 3,
    't_d': UnsafeProxy({'a': 5})
  })

  globals = {
    'g_e': 6,
    'g_f': 7,
  }

  ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals=locals)

  assert('a' in ansible_j2_vars)
  assert('b' in ansible_j2_vars)
  assert('c' in ansible_j2_vars)

# Generated at 2022-06-11 17:24:23.045020
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    templar = "templar"
    globals = { 'key1' : 'value1' }
    locals = { 'key2' : 'value2' }
    var_name = 'key1'
    var_name_not_exists = 'key3'

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    if var_name in ansible_j2_vars:
        assert True
    else:
        assert False

    if var_name_not_exists in ansible_j2_vars:
        assert False
    else:
        assert True

    return



# Generated at 2022-06-11 17:24:35.885959
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # AnsibleJ2Vars.__getitem__, instance method
    # NOTE: We need to stub out Templar(), because we don't have a relevant
    # context for testing, and the existing tests rely on an AnsibleModule
    # from ansible.module_utils.basic
    import ansible.module_utils.basic
    from ansible.parsing.vault import VaultEditor
    class Templar(object):
        def __init__(self):
            self.available_variables = dict()
        def template(self, data):
            return data
    global templar
    templar = Templar()
    global vars_proxy
    vars_proxy = None

    global vault_pass
    vault_pass = VaultEditor(filename=None, password=None, kind='yaml')

    # This is a copy of a test case we

# Generated at 2022-06-11 17:24:47.698566
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.module_utils import basic
    templar = basic.AnsibleModule(
        argument_spec = dict(),
    )

    # Testing with empty variables
    vars = AnsibleJ2Vars(templar, dict())
    assert "ansible_ssh_host" not in vars

    templar._available_variables = dict(ansible_ssh_host="127.0.0.1")
    assert "ansible_ssh_host" in vars

    vars = AnsibleJ2Vars(templar, dict(), dict(ansible_ssh_host="127.0.0.1"))
    assert "ansible_ssh_host" in vars

    vars = AnsibleJ2Vars(templar, dict(ansible_ssh_host="127.0.0.1"))


# Generated at 2022-06-11 17:24:58.222940
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class DummyTemplar:
        def __init__(self, variable_manager, loader, fail_on_undefined=False):
            self.variable_manager = variable_manager
            self.loader = loader
            self.fail_on_undefined = fail_on_undefined
            self._available_variables = variable_manager._fact_cache
            self._available_variables.update(variable_manager.extra_vars)
            self.hostname = variable_manager.hostvars.keys()[0]

# Generated at 2022-06-11 17:25:08.933809
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    ansible_j2_vars = AnsibleJ2Vars(templar, globals={'key_g': 'val_g'})
    if 'key_g' in ansible_j2_vars:
        print('key_g found in ansible_j2_vars')
    else:
        print('key_g not exists')

    if 'key_l' not in ansible_j2_vars:
        print('key_l not exists')
    else:
        print('key_l found in ansible_j2_vars')
    ansible_j2_vars._locals['key_l'] = 'val_l'


# Generated at 2022-06-11 17:25:20.057713
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # create a simple fake inventory and play, enough for the templar to work
    host = InventoryManager().create_host('host')
    play = dict(hosts='[host]')

    # Now create some fake variables, as what would be in the context
    variables = {'var1': 'value1', 'var2': 'value2'}
    hostvars = HostVars(host, variables)

    # create the god class of ansible, the variable manager
    # the second instance of FakeHost would be a vars plugin if we had one
    # the third instance of FakeHost would be an inventory plugin
    vars_manager

# Generated at 2022-06-11 17:25:31.310065
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible import constants as C
    from ansible.vars.hostvars import HostVars

    my_vars = dict(
        foo = dict(
            bar = dict(
                baz = dict(
                    nested_key = "nested_value"
                )
            )
        ),
        test_dict = dict(
            test_key = "test_var"
        )
    )

    my_globals = dict(
        my_global = dict(
            my_nested_global = "hello"
        )
    )

    # Test that getitem template works as expected
    # Test 1: use variables from AnsibleJ2Vars
    templar = Templar(loader=None, variables=my_vars)
    an_ji_var = AnsibleJ

# Generated at 2022-06-11 17:25:38.760768
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    from ansible.templating import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # create a Templar object for the templar attribute
    templar = Templar(loader=None)

    # create a dict for the vars attribute
    vars = dict(a=1, b=2, c=3)

    # create a dict for the globals attribute
    globals = dict(x=11, y=12, z=13)

    # create a dict for the locals attribute
    locals = dict(e=21, f=22, g=23)

    # create a AnsibleJ2Vars object
    obj = AnsibleJ2Vars(templar, vars, globals=globals, locals=locals)

    # test __contains__()

# Generated at 2022-06-11 17:25:52.607095
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """ test __getitem__ method of AnsibleJ2Vars class
    """

    fake_templar = None
    fake_globals = dict()
    fake_locals = dict()
    anJ2Vars = AnsibleJ2Vars(fake_templar, fake_globals, fake_locals)

    # test case #1: self._templar.available_variables contains the key varname
    fake_templar = type('Fake',(object,),{'available_variables':{'foo':'bar'}})()
    fake_globals = dict()
    fake_locals = dict()
    anJ2Vars = AnsibleJ2Vars(fake_templar, fake_globals, fake_locals)

    # test case #2: self._locals contains

# Generated at 2022-06-11 17:26:01.476618
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    # test if the overriding method __contains__ works
    ansibleJ2Vars = AnsibleJ2Vars(Templar(), {'b': 1})
    assert ansibleJ2Vars.__contains__('b')
    # test if the overriding method __contains__ works with member variable _locals
    ansibleJ2Vars = AnsibleJ2Vars(Templar(), {'b': 1}, locals={'b': 1})
    assert ansibleJ2Vars.__contains__('b')
    # test the situation that the variable is not exists in _locals, _templar, and _globals
    ansibleJ2Vars = AnsibleJ2Vars(Templar(), {})
    assert ansibleJ2Vars.__contains__('b')

# Generated at 2022-06-11 17:26:08.536647
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Following unit test checks if correct default behavior of AnsibleJ2Class is returned -
    if a variable is defined, then no exception is raised and the variable is returned.
    If it is not defined, then an appropriate KeyError is raised
    '''

    # Init variables
    varname = "foo"
    variable = "bar"
    globals = dict()
    globals[varname] = variable

    # Create an instance of AnsibleJ2Vars
    vars = AnsibleJ2Vars(None, globals)

    # Test case where variable is defined
    test_result = vars.__getitem__(varname)
    assert test_result == variable

    # Test case where variable is not defined
    from builtins import KeyError
    exception_thrown = False

# Generated at 2022-06-11 17:26:20.211707
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars

    # test code
    print('Start AnsibleJ2Vars___iter__ test')
    print('Start create AnsibleJ2Vars instance')
    globals = {'ports': '10000-10010'}
    locals = {'ip': '10.0.0.1'}
    j2_vars = AnsibleJ2Vars(None, globals, locals)
    print('Start test iter method')
    print('j2_vars.globals: %s, j2_vars.locals: %s' % (str(j2_vars._globals), str(j2_vars._locals)))
    for k in j2_vars:
        print('k: %s' % k)



# Generated at 2022-06-11 17:26:28.020202
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager

    templar_obj = VariableManager()
    obj = AnsibleJ2Vars(templar_obj, globals={'globals': {}}, locals={'l_locals': {}})
    assert obj.__contains__('globals') is True
    assert obj.__contains__('locals') is True
    assert obj.__contains__('v') is False
    assert 'globals' in obj
    assert 'locals' in obj
    assert 'v' not in obj

# Generated at 2022-06-11 17:26:39.246659
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class testAnsibleModule(object):

        class _ansible_module(object):
            no_log = True
            args = {}

        def __init__(self, *args, **kwargs):
            self._ansible_module = self._ansible_module()

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    t = Templar("", testAnsibleModule())
    vars = AnsibleJ2Vars(t, {}, locals={ "l_i": 42 })

    # test with local
    assert vars.__getitem__("i") == 42

    # test with undefined variable

# Generated at 2022-06-11 17:26:52.080613
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import time_vars_plugin
    from ansible.template import Templar

    j2vars = AnsibleJ2Vars(Templar(), dict())


# Generated at 2022-06-11 17:27:02.359679
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import jinja2
    from ansible.template import Templar

    templar = Templar(loader=None)
    locals = dict(_hostvars={"hostvarsvalue"}, _role="rolevalue", _variable={"_variablevalue"})
    globals = {}
    aj2vars = AnsibleJ2Vars(templar, globals, locals)

    # Tests for non-empty iterables
    assert set(aj2vars) == {'hostvarsvalue', 'rolevalue', '_variablevalue'}

    # Tests for empty iterables
    locals = {}
    aj2vars = AnsibleJ2Vars(templar, globals, locals)
    assert not list(aj2vars)

    globals = {}

# Generated at 2022-06-11 17:27:14.082848
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars import static_vars

    class TestTemplateVars(object):
        def __init__(self, vars_template):
            self.vars_template = vars_template
        def get_vars(self, loader, path, entities, cache=True):
            return self.vars_template

    variable_manager = VariableManager()
    loader = DataLoader()
    host = Host('localhost')

   

# Generated at 2022-06-11 17:27:22.230860
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.templating import Templar
    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, globals={})
    j2vars._templar.available_variables = {'available_vars': 'value'}
    j2vars._locals = {'locals': 'value'}
    j2vars._globals = {'globals': 'value'}
    assert sorted(list(j2vars)) == sorted(['available_vars', 'locals', 'globals'])

# Generated at 2022-06-11 17:27:34.253079
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeVariable

    templar = Templar(loader=None, variables={'foo': 'bar'}, shared_loader_obj=None)
    j2vars = AnsibleJ2Vars(templar=templar, globals={'baz': 'qux'})

    assert j2vars['baz'] == 'qux'

    assert j2vars['vars'] == templar.available_variables

    assert j2vars['foo'] == 'bar'

    # Test that safe variables are automatically templated
    templar.available_variables = {
        'bar': 'car',
        'boo': UnsafeVariable('caw'),
    }
    j2vars = AnsibleJ2Vars

# Generated at 2022-06-11 17:27:44.545363
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import ansible_safe_eval

    test_globals = {'test_globals': 42}
    test_locals = {'test_locals': 84}
    test_available_variables = ansible_safe_eval("dict(test_available_variables=84/2)")

    test_templar = type('TestingTemplar', (), {
        'available_variables': test_available_variables,
    })()

    ajv = AnsibleJ2Vars(test_templar, test_globals, locals=test_locals)

    assert('test_globals' in ajv)
    assert('test_locals' in ajv)
    assert('test_available_variables' in ajv)

# Generated at 2022-06-11 17:27:55.340687
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import unsafe_eval

    vars = {
        'var1': 1,
        'var2': 2,
        'var3': 3,
        'var4': 4,
        'var5': 5,
        'var6': 6,
    }

    player_vars = {
        'inventory_hostname': 'localhost',
        'group_names': ['group1', 'group2', 'group3'],
        'omit': "__omit_place_holder__"
    }

    j2vars = AnsibleJ2Vars(unsafe_eval, player_vars, vars)

    assert len(j2vars) == 9, "__len__ method of AnsibleJ2Vars return wrong number of variables"


# Generated at 2022-06-11 17:28:06.952918
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    test_templar = Templar(loader=None, shared_loader_obj=None)
    test_globals = dict()
    test_locals = dict()
    test_var = AnsibleJ2Vars(test_templar, test_globals, test_locals)

    # Test case 1
    test_templar.available_variables = dict(a=1, b=2)
    test_globals = dict()
    test_locals = dict()
    test_var = AnsibleJ2Vars(test_templar, test_globals, test_locals)
    assert test_var['a'] == 1
    assert test_var['b'] == 2

    # Test case 2
    test_templar.available_variables = dict

# Generated at 2022-06-11 17:28:17.317919
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    global_vars = dict(host=dict(name="host.example.com"))
    locals_vars = dict(a=10, b=20)
    templar = Templar(loader=None, variables=global_vars)
    J2Vars = AnsibleJ2Vars(templar, globals=global_vars, locals=locals_vars)
    assert("host" in J2Vars)
    assert("name" in J2Vars)
    assert("a" in J2Vars)
    assert("b" in J2Vars)
    return

# Generated at 2022-06-11 17:28:20.293355
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = """Templar"""
    globals = {'A':1, 'B':2, 'C':3}
    locals = {'C':4, 'D':5}


    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert len(aj2v) == 5


# Generated at 2022-06-11 17:28:29.401276
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.manager import VariableManager
    from ansible.template.template import Templar

    # This will be called inside __getitem__ to retrieve a templated variable
    # value.
    def template_func(var):
        return var

    # The following vars object is the closest possible to a real object
    # returned by the VariableManager class.
    vars = HostVars({"a": wrap_var("b")}, "a")
    var_manager = VariableManager()
    var_manager.update_inventory(vars)
    templar = Templar(loader=None, variables=var_manager)


# Generated at 2022-06-11 17:28:40.304909
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars import VariableManager, get_vars

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    variable_manager.host_vars = dict()
    variable_manager.group_vars = dict()

    # Create a Templar() object
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    vault_secrets_file = "some_file"
    vault_password = "some_pass"
    vault_password_file = "some_file"

    loader = DataLoader()
    vault_lib = VaultLib([])
    vault_lib.secrets_load(vault_secrets_file, vault_password, vault_password_file)

# Generated at 2022-06-11 17:28:51.810591
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    def do_test_getitem(self, templar, name, expect):
        assert isinstance(templar, Templar)
        assert isinstance(name, (str, unicode))

        var = AnsibleJ2Vars(templar, dict(foo=1, bar=2, baz=dict(qux=1)))

        assert var[name] == expect

    def deindent(s):
        import textwrap
        return textwrap.dedent(s).strip()
    do_test_getitem(None, 'foo', 1)
    do_test_getitem(None, 'bar', 2)
    do_test_getitem(None, 'baz', dict(qux=1))
    do_test_getitem(None, 'baz.qux', 1)

# Generated at 2022-06-11 17:28:56.997678
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # test data
    templar = 123123
    globals = {}
    locals = {}

    # prepare
    subject = AnsibleJ2Vars(templar, globals, locals)

    # execute
    result = subject.__contains__("/tmp")

    # assert
    assert result is False


# Generated at 2022-06-11 17:29:15.256503
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory=None)

    play_context = Play().set_loader(loader=None)
    play_context._variable_manager = variable_manager

    templar = Templar(loader=None, shared_loader_obj=None, variables=variable_manager.get_vars(play=play_context, use_cache=False))


# Generated at 2022-06-11 17:29:26.863736
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Arrange

    import os
    import sys
    import tempfile
    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', '..', 'lib'))
    from jinja2.environment import Environment

    from ansible.template import Templar

    available_variables = {
        'inventory_hostname': 'test_host',
        'inventory_hostname_short': 'test_host',
    }
    vars_paths = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'vars_files')
    template_paths = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'templates')
    # Load dummy

# Generated at 2022-06-11 17:29:34.540458
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    #
    import sys

    sys.path.append('../lib')
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {}
    locals = {}
    locals["var1"] = "var1"
    locals["var2"] = "var2"
    locals["var3"] = "var3"
    locals["var4"] = AnsibleUnsafeText(u"var4 {{ var1 }}")
    locals["var5"] = HostVars(hostname="hostvars", variables={"var1":"var1"})
    vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-11 17:29:41.550077
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar()
    ansiblej2vars = AnsibleJ2Vars(templar, globals)
    print (ansiblej2vars._locals)
    print (ansiblej2vars._globals)
    print (ansiblej2vars._templar)

if __name__ == "__main__":
    test_AnsibleJ2Vars()

# Generated at 2022-06-11 17:29:53.136432
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(test_var_1 = 'var_1_value')
    inventory = InventoryManager(loader, variable_manager)
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    t = Templar(loader=loader, variables=variable_manager, play_context=play_context)
    task = Task()
    task._role = None
    variable_manager.set_play

# Generated at 2022-06-11 17:30:00.721656
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    import os
    import sys
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    class AnsibleJ2Vars_TestCase(unittest.TestCase):

        def setUp(self):
            loader = DataLoader()
            self.templar = Templar(loader=loader, variables={})

            self.globals = {
                'one': 'one',
                'two': 'two'
            }

            self.locals = {
                'three': 'three',
                'four': 'four'
            }

            self.j2vars = AnsibleJ2Vars(templar=self.templar, globals=self.globals, locals=self.locals)


# Generated at 2022-06-11 17:30:01.984825
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert False, "Tests not yet implemented"

# Generated at 2022-06-11 17:30:10.911890
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.template import Templar

    # Create fake inventory, play
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    host = inventory.get_host("localhost")

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_host_variable(host, 'foo', dict(baz=42))

    # Create fake task queue
    play = dict(vars=dict(foo=42))

# Generated at 2022-06-11 17:30:17.828925
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables=dict())
    # Test with first arg = Templar, second arg = dict and third arg = dict
    ansible_vars = AnsibleJ2Vars(templar, {"key1": "value1"}, {"key2": "value2"})
    assert("key1" in ansible_vars)

# Generated at 2022-06-11 17:30:27.951962
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    AnsibleJ2Vars.__len__() Test
    """

    templar = None

    globals = {}
    locals = None

    # Test with empty global and empty local
    ajv = AnsibleJ2Vars(templar, globals, locals)

    # Test with non-empty global, empty local
    globals['foo'] = 'bar'
    ajv = AnsibleJ2Vars(templar, globals, locals)

    # Test with empty global and non-empty local
    globals = {}
    locals = {'foo' : 'bar'}
    ajv = AnsibleJ2Vars(templar, globals, locals)

    # Test with non-empty global and non-empty local
    globals = {'foo' : 'bar'}

# Generated at 2022-06-11 17:30:42.488104
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    AnsibleJ2Vars appear to act as a merged dictionary of the variables in different scopes.

    >>> from ansible.template import Templar
    >>> templar = Templar(loader=None, variables={'test1': 'test1'})
    >>> aj2vars = AnsibleJ2Vars(templar, {'test2': 'test2'}, {'l_test3': 'test3'})
    >>> list(iter(aj2vars))
    ['test2', 'test1']
    '''


# Generated at 2022-06-11 17:30:47.477628
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    t = Templar()
    vpc = AnsibleJ2Vars(t, {"_ansible_remote_tmp": "/tmp"})

    assert("_ansible_remote_tmp" in vpc)


# Generated at 2022-06-11 17:30:49.919004
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Given
    globals = [{'a':1},{'b':2}]
    locals = {'c':3}
    templar = None
    a = AnsibleJ2Vars(templar, globals, locals)
    # Then
    assert len(a) == 3

# Generated at 2022-06-11 17:30:57.621396
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # Setup mock classes for Templar and templar.available_variables
    class Templar:
        def template(self, variable):
            return variable

# Generated at 2022-06-11 17:31:09.579816
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # arrange
    from ansible.template import Templar
    # Using None instead of {} to test None
    ansible_j2_vars = AnsibleJ2Vars(Templar(None, None), {})

    # act & assert
    # (1) assert __contains__ return True when the key exists in _locals
    locals = {'a': 1}
    ansible_j2_vars = ansible_j2_vars.add_locals(locals)
    assert ansible_j2_vars.__contains__('a') == True
    # (2) assert __contains__ return True when the key exists in _globals
    globals = {'a': 1}
    ansible_j2_vars = AnsibleJ2Vars(Templar(None, None), globals)

# Generated at 2022-06-11 17:31:10.066896
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass

# Generated at 2022-06-11 17:31:19.813390
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    for key, val in AnsibleJ2Vars(None, None):
        raise Exception('AnsibleJ2Vars should have no keys')
    try:
        for key, val in AnsibleJ2Vars(None, dict(a=1)):
            assert key == 'a' and val == 1
    except:
        raise Exception('AnsibleJ2Vars should have one "a" key')

# Generated at 2022-06-11 17:31:30.646526
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_1 = {'ansible_facts': {'a': 1, 'b': 2, 'c': 3}}
    dict_2 = {'ansible_facts': {'d': 4, 'e': 5, 'f': 6}}
    dict_3 = {'ansible_facts': {'g': 7, 'h': 8, 'i': 9}}
    ansible_j2_vars = AnsibleJ2Vars(templar=None, globals=dict_2, locals=dict_1)
    if ansible_j2_vars.__contains__('ansible_facts'):
        ansible_j2_vars.add_locals(dict_3)
        print(ansible_j2_vars['ansible_facts'])

# Generated at 2022-06-11 17:31:31.193990
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-11 17:31:42.271198
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import combine_vars

    # Prepare variables
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost'])

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-11 17:32:05.411174
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import jinja2
    from ansible.template import Templar

    globals = {"global_var": 42}
    locals = {"local_var": 42}
    templar = Templar(loader=jinja2.DictLoader({'test_template': '{{test_templar_var}}'}))
    templar._available_variables = {"test_templar_var": "{{test_templar_var}}"}
    templar._available_variables["test_templar_var"] = "test_templar_value"
    templar._available_variables["global_var"] = globals["global_var"]
    templar._available_variables["l_local_var"] = locals["local_var"]

# Generated at 2022-06-11 17:32:12.234504
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
        method __getitem__ of class AnsibleJ2Vars
    '''
    print("In method AnsibleJ2Vars___getitem__")
    # For example
    # vars:
    #     - var1: { a1: 1, a2: 2, a3: 3 }
    #     - var2: { b1: 11, b2: 22, b3: 33 }
    vars = {'var1': {'a1': 1, 'a2': 2, 'a3': 3}, 'var2': {'b1': 11, 'b2': 22, 'b3': 33}}
    templar = Templar(loader=None) # loader of Templar class is None
    templar._available_variables = vars # _available_variables of Templar class is dictionary vars
    ansible

# Generated at 2022-06-11 17:32:23.714162
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager.extra_vars = {'foo': 1, 'bar': 2}

    templar = Templar(loader=loader, variable_manager=variable_manager, shared_loader_obj=loader)

    assert ('foo' in AnsibleJ2Vars(templar, {}, {'l_foo': 1})) == True
    assert ('bar' in AnsibleJ2Vars(templar, {'bar': 1}, {'l_bar': 1})) == True

# Generated at 2022-06-11 17:32:32.176662
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import collections
    import ansible.utils
    from ansible.template import Templar
    from ansible.inventory.host import Host

    my_jinja_vars = {'foo': 'bar'}
    my_hostvars = collections.defaultdict(dict)
    my_hostvars['localhost'] = {'ansible_connection': 'local', 'ansible_host': 'localhost'}

    my_host = Host(name='localhost')
    my_host.vars = collections.defaultdict(dict)
    my_host.vars['myvar'] = 'foo'
    my_inventory = collections.defaultdict(dict)
    my_inventory['_meta'] = {'hostvars': my_hostvars}

    my_args = collections.defaultdict(dict)
    my_args['inventory'] = my_inventory


# Generated at 2022-06-11 17:32:40.368579
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Test case: AnsibleJ2Vars.__contains__()
    '''
    import sys
    from jinja2 import Template
    from ansible.template import Templar
    from ansible.utils.vars import flatten_hash_to_list

    fake_templar = Templar(loader={}, variables={'var1': 'value1'})
    fake_globals = {'gbl1': 'gbl_value1'}
    fake_locals = {}
    ansible_vars = AnsibleJ2Vars(fake_templar, fake_globals, fake_locals)

    if sys.version_info[0] < 3:
        assert ansible_vars.__contains__('') is False

# Generated at 2022-06-11 17:32:46.105289
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    vars_dict = {'a': 2, 'b': 3}
    locals_dict = {'a': 4, 'c': 5}

    ahv = AnsibleJ2Vars(None, vars_dict, locals_dict)

    assert 'a' in ahv
    assert 'b' in ahv
    assert 'c' in ahv
    assert 'd' not in ahv



# Generated at 2022-06-11 17:32:50.161521
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    vars = AnsibleJ2Vars('templar', 'globals', locals='locals')
    vars['name'] = 'example'
    res = vars['name']
    assert res == 'example'


# Generated at 2022-06-11 17:33:01.292956
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.config.manager import ConfigManager
    from ansible.utils.color import stringc
    #from ansible.plugins import vars_loader

    cfg = ConfigManager()
    cfg.initialize()
    # vars_loader.add_directory(cfg.get_plugin_dirs())
    add_all_plugin_dirs(cfg.get_plugin_dirs())
    t = Templar(loader=None, shared_loader_obj=None, variables=None, templar=None)
    
    vars = {'a': 'a',
            'b': 'b'}
    globals = {'c': 'c'}

# Generated at 2022-06-11 17:33:12.216348
# Unit test for constructor of class AnsibleJ2Vars

# Generated at 2022-06-11 17:33:22.613843
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar()
    vars = """
    key1: 'value1'
    key2: 'value2'
    """
    vars = yaml.load(vars) # AnsibleMapping
    assert(isinstance(vars, Mapping))
    assert(isinstance(vars, AnsibleBaseYAMLObject))
    assert(isinstance(vars, AnsibleMapping))
    vars = AnsibleJ2Vars(templar, vars, locals=None)