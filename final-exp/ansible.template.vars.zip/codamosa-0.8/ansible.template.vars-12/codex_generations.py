

# Generated at 2022-06-11 17:24:13.813479
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    templar = mock.MagicMock()

    def get_template_result(value):
        if value in ['foo', 'bar']:
            return value
        raise KeyError("undefined variable: %s" % value)

    templar.template.side_effect = get_template_result

    globals_ = {'foo':'foo'}
    locals_ = {'bar':'bar'}
    var_proxy = AnsibleJ2Vars(templar, globals_, locals_)

    assert var_proxy['foo'] == 'foo'
    assert var_proxy['bar'] == 'bar'
    assert var_proxy['baz'] == 'baz'
    assert var_proxy['foo'] == 'foo'
    assert var_proxy['bar'] == 'bar'
    assert var_proxy['baz']

# Generated at 2022-06-11 17:24:24.489912
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    data_loader = DataLoader()
    vault_secrets = VaultLib([])
    templar = Templar(loader=data_loader, variables={}, vault_secrets=vault_secrets)

    # Test case: variable names in 'locals' are not duplicated
    # Expected result: The length of __getitem__ should be equal to the total number of variables
    ansible_j2_vars = AnsibleJ2Vars(templar, globals={})
    assert len(ansible_j2_vars) == 0

    ansible_j2_vars._locals = {"foo": "bar"}

# Generated at 2022-06-11 17:24:36.727177
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Avoid loading module_utils/urls.py to ensure its absence
    #   to test __getitem__'s handling of missing modules
    def __getitem__(self, name):
        raise ModuleNotFoundError('No module named \'%s\'' % name)

    AnsibleJ2Vars.__dict__['_AnsibleJ2Vars__getitem__'] = __getitem__

    # Ensure a basic test is able to run
    assert 'file' in AnsibleJ2Vars
    assert 'file' in AnsibleJ2Vars

    # Ensure that a missing module gives a KeyError
    try:
        assert 'url' in AnsibleJ2Vars
    except KeyError as e:
        assert 'No module named \'url\'' in str(e)

    # Ensure that an error is raised when the module is missing


# Generated at 2022-06-11 17:24:40.651804
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = AnsibleJ2Vars(None, None, None)
    assert "__globals" in templar
    assert "__locals" in templar
    assert "__templar" in templar


# Generated at 2022-06-11 17:24:44.471412
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.plugins.loader import get_all_plugin_loaders

    myvars = AnsibleJ2Vars(templar=get_all_plugin_loaders(), globals=None, locals=None)
    myvars["item"]

# Generated at 2022-06-11 17:24:55.064316
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    j2vars = AnsibleJ2Vars()

    import ansible.module_utils.common._collections_compat as collections

    assert j2vars.__contains__('ansible_facts')
    assert j2vars.__contains__('hostvars')
    assert j2vars.__contains__('vars')
    assert j2vars.__contains__('groups')
    assert j2vars.__contains__('group_names')
    assert j2vars.__contains__('play_hosts')
    assert j2vars.__contains__('inventory_hostname')
    assert j2vars.__contains__('inventory_hostname_short')
    assert j2vars.__contains__('inventory_file')
    assert  j2vars.__cont

# Generated at 2022-06-11 17:25:02.756763
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)

    # Test handling of HostVars
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars(hostname='host', variables={
        'a': 'alpha',
        'b': 'bravo',
        'c': 'charlie',
    })
    t = AnsibleJ2Vars(templar, {}, {})
    assert t._templar.available_variables['hostvars'] == hostvars
    assert 'hostvars' in t
    assert t['hostvars'] == hostvars
    assert t['hostvars']['a'] == 'alpha'
    assert t['hostvars']['b'] == 'bravo'

# Generated at 2022-06-11 17:25:11.633122
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    ansible_vars = {'ansible_var': 'ansible_var_value'}
    j2_vars = {'j2_var': 'j2_var_value'}
    templar = Templar(loader=None, variables=ansible_vars)

    assert AnsibleJ2Vars(templar, j2_vars)._templar._available_variables == ansible_vars
    assert AnsibleJ2Vars(templar, j2_vars)._globals == j2_vars
    assert AnsibleJ2Vars(templar, j2_vars)._locals == {}


# Generated at 2022-06-11 17:25:18.195585
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # ansible.template.Templar() needs a DataLoader and a variable manager
    loader = DataLoader()
    inventory = None
    assert False

    templar = Templar(loader=loader, variables=None)
    vars = AnsibleJ2Vars(templar, dict((('a', 'b'),)))

# Generated at 2022-06-11 17:25:25.564174
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    # Using variable that is in available_variables
    templar = Templar(loader=None)
    templar._available_variables = {'foo': 'bar'}
    var = AnsibleJ2Vars(templar, {})
    assert var['foo'] == 'bar'

    # Using variable that is in available_variables, but has a non safe value
    # that needs to be templated
    templar = Templar(loader=None)
    templar._available_variables = {'foo': {'bar': ['baz']}}
    templar._available_variables['foo']['__ansible_unsafe'] = True
    var = AnsibleJ2Vars(templar, {})

# Generated at 2022-06-11 17:25:37.721802
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from io import StringIO

    task = dict(
        action = dict(
            __ansible_action_module_name = 'copy',
            __ansible_action_module_args = dict(
                dest = '/etc/foo/foo.conf',
                content = '## {{ foo_template_var }}'
            )
        )
    )
    new_stdout = StringIO()

# Generated at 2022-06-11 17:25:49.624493
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.context import AnsibleContext

    context = AnsibleContext()
    templar = Templar(loader=None, variables=context.global_vars)

    # Testing when the varname is in _locals
    j2vars = AnsibleJ2Vars(templar, {}, locals={'local_var': 'localvar_value'})
    assert j2vars['local_var'] == 'localvar_value'

    # Testing when the varname is in _templar.available_variables

# Generated at 2022-06-11 17:26:00.314836
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE
    from ansible.inventory import Inventory
    import os
    import sys

    script_path = os.path.realpath(__file__)
    script_dir = os.path.dirname(script_path)
    module_path = os.path.join(script_dir, "..", "..", "..", "..", "lib", "ansible", "modules")
    vault_path = os.path.join(script_dir, "..", "..", "..", "..", "bin", "ansible-vault")

# Generated at 2022-06-11 17:26:06.189081
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class Templar(object):
        pass
    templar = Templar()
    globals = {}
    locals = {}
    jv_obj = AnsibleJ2Vars(templar, globals, locals)
    assert jv_obj._templar == templar
    assert jv_obj._globals == globals
    assert jv_obj._locals == locals

# Unit tests for AnsibleJ2Vars.__contains__

# Generated at 2022-06-11 17:26:16.302820
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os
    import sys
    import pytest
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.playbook.play_context import PlayContext
    from ansible.template.templar import Templar

    locals = {
        'l_a': 1,
        'b': 2
    }
    globals = {
        'a': 3,
        'b': 4
    }
    templar = Templar(None, play_context=PlayContext())
    vars = AnsibleJ2Vars(templar, globals, locals)

    # check if vars proxy the locals
    assert 'a' not in vars
    assert 'b' in vars
    assert vars['b'] == 4
    assert 'l_a' in vars
    assert vars['l_a'] == 1



# Generated at 2022-06-11 17:26:24.911467
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    aj2v = AnsibleJ2Vars(templar, globals, locals)

    # Test undefined variable
    try:
        aj2v.__getitem__("foo")
        assert "Test should have failed"
    except KeyError as k:
        pass

    # Define variable using dictionary
    globals["foo"] = "bar"
    assert aj2v.__getitem__("foo") == "bar"

    # Define variable using Templar.available_variables
    templar.set_available_variables({ "baz" : "qux" })
    assert aj2v.__getitem__("baz") == "qux"

    # Def

# Generated at 2022-06-11 17:26:34.418717
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import unittest
    from ansible.template import Templar

    class AnsibleJ2VarsTestCase(unittest.TestCase):

        def test_AnsibleJ2Vars___getitem__(self):
            templar = Templar(loader=None, variables={'test_var': 'value1', 'test_var2': 'value2'})
            globals = {'test_var_globals': 'value1'}
            locals  = {'test_var_locals': 'value1'}
            ajv = AnsibleJ2Vars(templar, globals, locals=locals)
            self.assertEqual(ajv['test_var'], 'value1')
            self.assertEqual(ajv['test_var2'], 'value2')

# Generated at 2022-06-11 17:26:44.567764
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os
    import unittest

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    mock_loader = 'ansible.parsing.dataloader.DataLoader'
    mock_variable_manager = VariableManager()
    mock_variable_manager.extra_vars = {
        'myvar': {
            'var1': '1',
            'var2': 2,
            'var3': True,
        },
    }
    mock_templar = Templar(loader=mock_loader, variables=mock_variable_manager)


# Generated at 2022-06-11 17:26:51.670451
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansibleJ2Vars = AnsibleJ2Vars(templar=None, globals={'x': 1}, locals={'y': 2, 'z': 3})
    assert 'x' in ansibleJ2Vars
    assert 'y' in ansibleJ2Vars
    assert 'z' in ansibleJ2Vars
    assert 'invalid' not in ansibleJ2Vars


# Generated at 2022-06-11 17:27:01.353390
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    obj = None
    try:
        obj = AnsibleJ2Vars(None, None, None)
    except Exception:
        assert False, 'Unable to instantiate AnsibleJ2Vars'
    # ensure that AnsibleJ2Vars.__contains__ returns True
    # when the given key exists in one of the given dictionaries
    keys = ['foo', 'bar']
    for k in keys:
        assert obj.__contains__(k) == True
    # ensure that AnsibleJ2Vars.__contains__ returns False
    # when the given key does not exist in any of the given dictionaries
    keys = ['spam', 'eggs']
    for k in keys:
        assert obj.__contains__(k) == False


# Generated at 2022-06-11 17:27:14.218300
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager

    templar = Templar(VariableManager())
    variables = dict(hostv=dict(hostname="testhost"))
    variables = templar.template(variables, fail_on_undefined=False)
    aj2vars = AnsibleJ2Vars(templar, variables)

    # test template() function
    assert isinstance(aj2vars["hostv"], HostVars)
    assert aj2vars["hostv"]["hostname"] == "testhost"

# Generated at 2022-06-11 17:27:25.140585
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class Templar(object):
        def __init__(self, available_variables):
            self._available_variables = available_variables
        @property
        def available_variables(self):
            return self._available_variables

    class HostVars(object):
        def __init__(self):
            pass

    # Tests with error
    varname = 'foo'
    templar = Templar({})
    globals = {}
    locals = {}
    data = AnsibleJ2Vars(templar, globals, locals)
    try:
        data[varname]
    except KeyError as e:
        assert e.args[0] == "undefined variable: %s" % varname

    # Tests without error
    templar = Templar({varname:'bar'})
    data = Ansible

# Generated at 2022-06-11 17:27:33.832889
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Prepare data
    data = {}
    templar = {}
    templar['available_variables'] = {'var1': 'value1', 'var2': 'value2'}
    globals = {'global1': 'global_value1', 'global2': 'global_value2'}
    locals = {'local1': 'local_value1', 'local2': 'local_value2'}

    # Test success
    result = AnsibleJ2Vars(templar, globals, locals=locals)
    assert result.__contains__('var1') == True
    assert result.__contains__('var2') == True
    assert result.__contains__('var3') == False
    assert result.__contains__('local1') == True

# Generated at 2022-06-11 17:27:41.707458
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible
    from ansible.template import Templar

    t = Templar(loader=ansible.constants.DEFAULT_LOADER, variables={'var': 'value'})
    ansible_j2_vars = AnsibleJ2Vars(t, {})
    assert ansible_j2_vars['var'] == 'value'

    try:
        assert ansible_j2_vars['not_a_var']
    except KeyError as e:
        assert e.args[0] == "undefined variable: not_a_var"

# Generated at 2022-06-11 17:27:53.474904
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars

    vault_pass = VaultLib()
    vault_pass.default_vault_id = 'vault'

    templar = Templar(loader=None, variables=dict(), vault_password=vault_pass)
    hostvars_obj = HostVars(templar, vault_pass)

    vm = VariableManager()
    vm.extra_vars = dict(a='a')
    vm.set_host_variable('a', 'b')
    vm.set_host_variable('c', 'd')


# Generated at 2022-06-11 17:27:57.464047
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    templar = Templar(loader=None, shared_loader_obj=None)
    j2vars = AnsibleJ2Vars(templar, {})
    assert 'ansible_play_batch' in j2vars


# Generated at 2022-06-11 17:28:08.970533
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'test_item':'foo'})

    # Test if padding is added to a string
    proxy = AnsibleJ2Vars(templar=templar, globals={})
    assert proxy["test_item"] == "foo"

    # Test if padding is added to a list
    proxy = AnsibleJ2Vars(templar=templar, globals={})
    assert proxy["test_item"] == "foo"
    # Test if padding is added to a dict
    proxy = AnsibleJ2Vars(templar=templar, globals={})
    assert proxy["test_item"] == "foo"
    # Test if padding is added to a boolean value

# Generated at 2022-06-11 17:28:21.223279
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import jinja2

    # It's not possible to create an instance of Templar for testing,
    # but we can use a dict for our purposes
    templar = {'jinja2': {'available_variables': {'a': 'foo'}}}

    # Create a minimal AnsibleJ2Vars instance
    vars = AnsibleJ2Vars(templar, {})

    # Test __getitem__ to ensure it returns the value of
    # the variable named as the key
    assert vars['a'] == 'foo'

    # Test __getitem__ to ensure it throws a KeyError
    # if the specified key is not in the set of
    # available variables
    try:
        vars['b']
    except KeyError as e:
        assert str(e) == 'undefined variable: b'

# Generated at 2022-06-11 17:28:30.004817
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    template_variables = dict(
        foo='bar'
    )

    globals = dict(
        foo='bar'
    )

    locals = dict(
        foo='bar'
    )

    template = dict(
        foo = dict(
            bar = dict(
                baz = 'foo'
            )
        )
    )

    templar = Templar(loader=None, variables=template_variables)

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'foo' in ansible_j2_vars
    assert 'bar' not in ansible_j2_vars

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals=template)



# Generated at 2022-06-11 17:28:40.595117
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ad_hoc_vars = {"foo": "bar", "baz": "quux"}
    inventory_vars = {"foo": "quux"}
    play_vars = {}
    task_vars = {}
    jv = AnsibleJ2Vars(templar=None, globals={}, locals=None)
    jv._templar = TemplatingWithVars(ad_hoc_vars=ad_hoc_vars, inventory_vars=inventory_vars, play_vars=play_vars, task_vars=task_vars)

    # Variable defined in ad_hoc_vars
    assert "foo" in jv

    # Variable defined in inventory_vars
    assert "foo" in jv

    # Variable defined in play_vars
    assert "foo" in j

# Generated at 2022-06-11 17:28:54.473928
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # The following test checks the case 'return variable'
    templar = Templar(None, loader=None)
    hostvars = HostVars(host=None)
    j2_vars = AnsibleJ2Vars(templar, {}, {'vars': hostvars})
    # Test: vars is a HostVars instance
    assert isinstance(j2_vars['vars'], HostVars)

    # The following test checks the case 'return self._globals[varname]'
    j2_vars = AnsibleJ2Vars(templar, {'varname': 'value'}, {})
    # Test: varname is in globals dict by default
   

# Generated at 2022-06-11 17:29:06.348462
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'test' : 'test_value'})
    test_global_var = 'test_global_var_value'

    # test for contains in variables
    j2_vars = AnsibleJ2Vars(templar, globals={})
    assert ('test' in j2_vars) is True

    # test for contains in locals
    j2_vars = AnsibleJ2Vars(templar, globals={}, locals={'test' : 'test_value'})
    assert ('test' in j2_vars) is True

    # test for contains in globals
    j2_vars = AnsibleJ2Vars(templar, globals={'test' : 'test_value'})

# Generated at 2022-06-11 17:29:18.297967
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = dict()
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    # 1. Get items from locals
    locals = {
        'bar': 'foo'
    }
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['bar'] == locals['bar']
    # 2. Get items from templar
    templar.available_variables = locals
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['bar'] == locals['bar']
    # 3. Get items from globals
    globals = locals

# Generated at 2022-06-11 17:29:28.765314
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    import jinja2
    templar = Templar(loader=None, variables={'varia_x': "foo"})
    globals = {'global_x': "foo_global"}
    locals = {'local_x': "foo_local"}
    a = AnsibleJ2Vars(templar, globals, locals=locals)
    varname = 'varia_x'
    #Test 'vars' case
    if a[varname] != 'foo':
        raise(Exception("test_AnsibleJ2Vars___getitem__ failed to get templated value for %s" % varname))
    varname = 'local_x'

# Generated at 2022-06-11 17:29:40.156595
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleUnicode
    from ansible.playbook.base import Base as PlaybookBase
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    class Playbook(PlaybookBase):
        def get_variable_manager(self):
            class VariableManager:
                def __init__(self):
                    self.extra_vars = {}

# Generated at 2022-06-11 17:29:48.117756
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import ansible.template
    templar = ansible.template.Templar(loader=None)

    j2_vars = AnsibleJ2Vars(templar, {}, {})
    # len(j2_vars) should == 0
    assert len(j2_vars) == 0

    j2_vars = AnsibleJ2Vars(templar, {'k1':'v1'}, {})
    # len(j2_vars) should == 1
    assert len(j2_vars) == 1

    j2_vars = AnsibleJ2Vars(templar, {'k1':'v1'}, {'kk1':'vv1'})
    # len(j2_vars) should == 2
    assert len(j2_vars) == 2

# Generated at 2022-06-11 17:29:55.382247
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = Templar(loader=None, variables=dict(var=123))
    ajv = AnsibleJ2Vars(templar, globals=dict(glo=123))
    assert 'var' in ajv, "test_AnsibleJ2Vars___contains__, __contains__ method error"
    assert 'glo' in ajv, "test_AnsibleJ2Vars___contains__, __contains__ method error"

# Generated at 2022-06-11 17:30:05.606291
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    host = Host(name='test_AnsibleJ2Vars___getitem__')

    templar = Templar(loader=loader, variables=variable_manager)
    globals = dict()
    locals = dict()

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['_host'] == host

# Generated at 2022-06-11 17:30:12.174244
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    templar.available_variables = dict(
        foo='bar',
        foo_unsafe=AnsibleUnsafeText('bar'),
        foo_dict=dict(a=1, b=2),
        foo_dict_unsafe=dict(a=1, b=AnsibleUnsafeText('2')),
        foo_list=['a', 'b'],
        foo_list_unsafe=['a', AnsibleUnsafeText('b')],
    )
    vars = AnsibleJ2Vars(templar, dict())
    assert vars['foo'] == 'bar'
    assert vars['foo_unsafe'] == 'bar'

# Generated at 2022-06-11 17:30:24.177811
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class AnsibleUndefinedVariable:
        message = "the variable is not defined"

    class AnsibleError:
        message = "the variable is not defined"

    class HostVars:
        pass

    class Templar:
        available_variables = {"vars": "vars", "var": "var", "vars_1": "vars_1"}
        def __init__(self):
            self.template_count = 0
        def template(self, variable):
            self.template_count += 1
            if variable == "vars":
                return variable
            if variable == "var":
                raise AnsibleUndefinedVariable(variable)
            if variable == "vars_1":
                raise AnsibleError(variable)


# Generated at 2022-06-11 17:30:29.041239
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Not clear how to test this method without a better understanding of the inner workings of AnsibleJ2Vars
    return
    assert False

# Generated at 2022-06-11 17:30:30.751341
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert False, "not implemented yet"

# Generated at 2022-06-11 17:30:38.698102
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    test the class AnsibleJ2Vars
    '''
    # pylint: disable=unused-variable
    templar = 'templar'
    globals = 'globals'
    locals = 'locals'
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars._templar == templar
    assert ansible_j2_vars._globals == globals
    assert ansible_j2_vars._locals == locals

# Generated at 2022-06-11 17:30:46.569354
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class test_templar(object):
        def __init__(self, available_variables):
            self.available_variables = available_variables
        def __getitem__(self, v):
            return self.available_variables[v]
    available_variables = {'v1':'val1','v2':'val2','v3':'val3','v4':'val4','v5':'val5','v6':'val6'}
    globals = {'g1':'g_val1','g2':'g_val2'}
    locals = {'l1':'l_val1','l2':'l_val2'}
    j2v = AnsibleJ2Vars(test_templar(available_variables), globals)

# Generated at 2022-06-11 17:30:52.317461
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfracked_path
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({
        "host_vars": {},
        "group_vars": {},
        "vars": {
            'var1': 'value1',
            'var2': 'value2',
            'var3': 'value3'
        },
        "common.yml": "var4: 'value4'",
        "site.yml": "var5: 'value5'"
    })
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    j2_vars

# Generated at 2022-06-11 17:31:02.792383
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test with a non-defined key
    try:
        vars['undefined']
    except KeyError:
        pass
    else:
        assert False

    # Test with a key defined in locals
    vars._locals['valid'] = 'valid value'
    assert vars['valid'] == 'valid value'

    # Test with a key defined in templar
    class DummyVariable:
        def __init__(self):
            self.name = 'dummy'
    templar.available_variables = dict()
    templar.available_variables['valid'] = DummyVariable()
    assert vars['valid']

# Generated at 2022-06-11 17:31:07.505819
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.templating import Templar
    templar = Templar(loader=None, variables={})

    # Not testing this with actual values, so initialize empty variables
    _globals = {}
    _locals = {}

    j2_obj = AnsibleJ2Vars(templar, _globals, locals=_locals)
    assert 'foo' not in j2_obj
    _locals.update({'foo': 'bar'})
    assert 'foo' in j2_obj
    _globals.update({'foo': 'bar'})
    assert 'foo' in j2_obj



# Generated at 2022-06-11 17:31:11.692777
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = None
    globals = None
    locals = None
    ajv=AnsibleJ2Vars(templar, globals, locals)
    actual = len(ajv)
    expected = 0
    assert actual == expected


# Generated at 2022-06-11 17:31:20.264774
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    obj = AnsibleJ2Vars(None,None)
    key_set = None
    obj.__contains__ = MagicMock(return_value = False)
    obj.__contains__.side_effect = lambda key: key in key_set
    obj.__iter__ = AnsibleJ2Vars.__iter__
    obj._templar = None
    obj._globals = None
    obj._locals = None
    key_set = set()
    assert obj.__iter__() == iter(key_set)
    key_set = set([1, 2, 3])
    assert obj.__iter__() == iter(key_set)


# Generated at 2022-06-11 17:31:31.064094
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-11 17:31:45.930048
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)

    test_string = 'test_string'
    test_dict = {'test': 'dict'}
    test_dict2 = {'test2': 'dict2'}

    # test_dict will be used in available_variables dict and locals dict
    available_variables_dict = {'test_string': test_string, 'test_dict': test_dict}
    locals_dict = {'test_string': test_string, 'test_dict': test_dict}

    # test_dict2 will be used only in globals dict

# Generated at 2022-06-11 17:31:46.705324
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-11 17:31:56.563094
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import jinja2
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    context._init_vars()
    templar = context.get_default_templar()
    globals = {'user': 'root'}
    locals = {'env': 'prod'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert list(vars) == ['env', 'user']

    # Test if the value of list of vars is updated
    globals = {'user': 'root', 'password': 'secret'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert list(vars) == ['env', 'user', 'password']
    assert vars['user'] == 'root'

# Generated at 2022-06-11 17:32:02.738701
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    vars = AnsibleJ2Vars(None, {'a': 1}, {'b': 2})
    vars.__contains__ = lambda x: x in ['a', 'b']
    vars.__getitem__ = lambda x: x
    
    assert sorted(list(vars)) == ['a', 'b']

    vars = AnsibleJ2Vars(None, {'a': 1}, {'b': 2})
    vars.__contains__ = lambda x: False
    
    assert sorted(list(vars)) == []


# Generated at 2022-06-11 17:32:12.440646
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    import jinja2
    t = '''
{{ "data" in x }}
{{ "data" in y }}
{{ "data" in z }}
{{ "data" in a }}
{{ "data" in b }}
{{ "data" in c }}
'''
    template = jinja2.Template(t)
    tvars = template.new_context(AnsibleJ2Vars(None, {}, locals={"x": {}, "y": {"data": "x"}, "z": [], "a": [], "b": [{"data": "y"}, {"data": "x"}], "c": {"data": "x"}}))
    assert ''.join(template.root_render_func(tvars)) == 'FalseTrueFalseFalseTrueFalse'

# Generated at 2022-06-11 17:32:23.929473
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.template
    template_bits = dict(
        basedir='/etc/ansible',
        context={},
        environment={},
        new_vars={},
        archetype_name=None,
        block_list=[],
        complex_args={},
        use_block_for_tasks=False,
        loader=None,
        no_log=False,
        vault_password=None,
        fail_on_undefined_vars=False,
        use_jinja=True,
    )
    templar = ansible.template.AnsibleTemplar(
        **template_bits
    )
    globals_ = {
        'a': 1,
        'b': 2,
    }

# Generated at 2022-06-11 17:32:32.346715
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import jinja2
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UNSAFE_PROXY
    j2_env = jinja2.Environment(undefined=jinja2.StrictUndefined)
    templar = Templar(loader=None, variables={'ansible_managed': str()})

    j2_vars = AnsibleJ2Vars(templar, globals={}, locals={})
    hostvars = HostVars()
    hostvars_dict = {'ansible_managed': str()}
    for key in ['a', 'b', 'c']:
        hostvars[key] = hostvars_dict

# Generated at 2022-06-11 17:32:40.519034
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from jinja2 import DictLoader
    from ansible.parsing.dataloader import DataLoader

    import random
    import string

    vars1 = dict((letter, random.randrange(0, 256, 1)) for letter in string.ascii_lowercase)
    globals1 = dict((letter, random.randrange(0, 256, 1)) for letter in string.ascii_uppercase)
    locals1 = dict((letter, random.randrange(0, 25, 1)) for letter in string.ascii_letters)

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_vars(vars1)

# Generated at 2022-06-11 17:32:51.503317
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    def test_ansiblej2vars___getitem__():
        templar = Templar(loader=None)
        j2vars = AnsibleJ2Vars(templar, dict())
        # Test obtaining existing variable
        existing_variable = 'ansible_all_ipv4_addresses'
        existing_value = 'ansible_all_ipv4_addresses_value'
        templar.available_variables[existing_variable] = existing_value
        assert j2vars[existing_variable] == existing_value
        # Test obtaining non existing variable
        non_existing_variable = 'non_existing_variable'

# Generated at 2022-06-11 17:33:03.014122
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(None, None)

    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test __getitem__ when variable exists in locals
    locals = {'myvariable': 'myvalue'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    v = vars['myvariable']
    assert v == 'myvalue'

    # Test __getitem__ when variable name is not in AnsibleJ2Vars
    try:
        v = vars['mybadvariable']
    except KeyError:
        pass


# Generated at 2022-06-11 17:33:24.128503
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.vars import VariableManager
    from ansible.template import Templar

    # Test case
    v = { 'str_var': 'str_value',
          'list_var': ['list_value'],
          'dict_var': { 'dict_key': 'dict_value' },
          'none_var': None }

    vm = VariableManager()
    vm.extra_vars = v
    t = Templar(loader=None, variables=vm)

    var_proxy = AnsibleJ2Vars(t, {}, locals={})

    # Test E1
    assert var_proxy['none_var'] is None

    # Test E2
    assert var_proxy['str_var'] == 'str_value'

    # Test E3
    assert var_proxy['list_var'] == ['list_value']

    #

# Generated at 2022-06-11 17:33:35.028702
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.inventory import Inventory

    # create the inventory
    inventory = Inventory(loader=DataLoader())
    inventory.add_group('test_group1')
    inventory.add_host(Host('host1'))
    inventory.add_host(Host('host2'))
    inventory.add_host(Host('host3'))
    inventory.add_child('test_group1', 'host1')

# Generated at 2022-06-11 17:33:41.077572
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class tester(object):
        def template(self, variable):
            return variable
    templar = tester()
    globals = dict(a = 1)
    locals = dict(b = 2)
    j2_var = AnsibleJ2Vars(templar, globals, locals=locals)

    assert j2_var['a'] == globals['a']
    assert j2_var['b'] == locals['b']

# Generated at 2022-06-11 17:33:52.330368
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.plugins import filter_loader

    play_context = PlayContext()
    templar = Templar(loader=DataLoader(), variables=dict(), vault_secrets=VaultLib(), filter_fns=filter_loader.all())
    ansible_vars = AnsibleJ2Vars(templar, HostVars())
    assert 'inventory_hostname' not in ansible_vars

    test_variables = dict(inventory_hostname='localhost')
    templ