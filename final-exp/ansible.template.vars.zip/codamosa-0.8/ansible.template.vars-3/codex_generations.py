

# Generated at 2022-06-11 17:24:14.057964
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template.templar import Templar

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['test/ansible/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    variable_manager._extra_vars = {'test': 1, 'test1': 1}
    variable_manager.set_globals({'gtest': 1})
    variable_manager.set_host_variable(inv.get_host("test_0001"), 'htest', 1)

    templar = Templar(loader=loader, variables=variable_manager)
    j2vars = AnsibleJ2V

# Generated at 2022-06-11 17:24:24.661268
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    hosts = [Host(name='127.0.0.1', port=22)]
    inventory = Inventory(loader=None, hosts=hosts, groups=[])
    play_context = PlayContext(variables={'a_var1': 'a_value1'})

# Generated at 2022-06-11 17:24:36.812219
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    hosts_vars_proxy = UnsafeProxy({"foo": "bar"}, wrap=True)
    assert hosts_vars_proxy.foo == "bar"
    templar = Templar(loader=None, variables=hosts_vars_proxy)

    hosts_vars_proxy = UnsafeProxy({"foo": "bar"}, wrap=True)
    assert hosts_vars_proxy.foo == "bar"
    templar = Templar(loader=None, variables=hosts_vars_proxy)
    a = AnsibleJ2Vars(templar, {})
    assert a["foo"] == "bar"
    assert a.__getitem__("foo") == "bar"

    hosts_vars_proxy = Un

# Generated at 2022-06-11 17:24:47.967177
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    def _convert_to_dict(obj):
        if isinstance(obj, dict):
            for key, value in obj.items():
                obj[key] = _convert_to_dict(value)
            return obj

        if hasattr(obj, '__dict__'):
            data = dict([(key, _convert_to_dict(value))
                         for key, value in obj.__dict__.items()
                         if not callable(value) and not key.startswith('_')])
            return data

        return obj

    # Create template test file
    template = '''
{% for i in range(3) %}{{ i }}
{%- endfor %}
'''
    # Create AnsibleJ2Vars object
    j2vars = AnsibleJ2Vars(None, None)

   

# Generated at 2022-06-11 17:24:57.003990
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    templar = Templar(loader=None, variables=VariableManager())
    globals = {'foo': 'global_foo'}
    locals = {'bar': 'local_bar'}

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'foo' in vars
    assert 'bar' in vars
    assert 'foo' not in vars._locals
    assert 'bar' in vars._locals

    assert vars['foo'] == 'global_foo'
    assert vars['bar'] == 'local_bar'

    # FIXME: Add more tests

# Generated at 2022-06-11 17:25:00.688586
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(None, loader=None)
    globals = dict()
    j2vars = AnsibleJ2Vars(templar, globals)
    assert len(j2vars) == 0


# Generated at 2022-06-11 17:25:10.958914
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import compile_expression, unsafe_eval
    (templar, globals) = get_j2_templar()
    (vars, locals) = get_j2_variables()

    jvars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in jvars
    assert 'hostvars' in jvars
    assert 'vars' in jvars
    assert 'c' in jvars
    assert 'd' in jvars
    # TODO: how should this work with different python versions?
    #assert 'e.f' not in jvars
    assert 'e' in jvars
    assert 'e.f' in jvars
    assert 'e.g' not in jvars

# Generated at 2022-06-11 17:25:21.810670
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars import include_vars

    templar = Templar(loader=None, variables={})
    locals = include_vars(loader=None, templar=templar, terms=listify_lookup_plugin_terms('vars', '/etc/ansible/group_vars/all'))
    data = dict(var1='foo', var2='bar')
    proxy = AnsibleJ2Vars(templar, data, locals)
    assert 'var1' in proxy
    assert 'var2' in proxy
    assert 'var3' not in proxy

# Generated at 2022-06-11 17:25:32.514923
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template.safe_eval import safe_eval
    from ansible.template.templar import Templar

    templar = Templar(loader=None, variables={'vault': AnsibleVaultEncryptedUnicode(data='vault')}, shared_loader_obj=None, vault_secrets=None)
    globals = {'dumper': AnsibleDumper, 'safe_eval': safe_eval}
    locals = {}

    assert AnsibleJ2Vars(templar, globals, locals)['vault'] == 'vault'

# Generated at 2022-06-11 17:25:42.922787
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import pytest

    templar = dict(available_variables=dict(k1='v1', k2='v2', k3='v3'))

    # should return true if the key is in available_variables, globals or locals
    j2vars = AnsibleJ2Vars(templar, dict(k2='v2'))
    assert 'k1' in j2vars
    assert 'k2' in j2vars
    assert 'k3' in j2vars
    assert 'k4' not in j2vars

    # should return false if not in available_variables, globals or locals
    j2vars = AnsibleJ2Vars(templar, dict(k2='v2'), dict(k2='v2', k3='v3'))

# Generated at 2022-06-11 17:25:56.667686
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.playbook.play_context import PlayContext

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    class DummyHost():
        def __init__(self):
            self.name = "dummyhost"

    context = PlayContext()
    context.hostvars = HostVars(host=DummyHost())
    context.hostvars['dummy_var'] = 'dummy value'

    templar = Templar(loader=None, variables=context.hostvars, fail_on_undefined=True)
    locals = dict()
    locals['l_test'] = 'test'

    vars = AnsibleJ2Vars(templar, context.hostvars, locals)

    assert 'test' == vars['test']
    assert 'test'

# Generated at 2022-06-11 17:26:03.889742
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars import VariableManager

    variables = VariableManager()
    variables.extra_vars = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5,
    }

    from ansible.template import Templar

    templar = Templar(loader=None, variables=variables)

    globals = {
        'g1': 1,
        'g2': 2,
        'g3': 3,
    }

    proxy = AnsibleJ2Vars(templar, globals)
    assert len(proxy) == 8

# Generated at 2022-06-11 17:26:06.645636
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar()
    globals = dict()
    locals = dict()
    v = AnsibleJ2Vars(templar, globals, locals)
    assert('invalid_key' not in v)


# Generated at 2022-06-11 17:26:09.179880
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    variable = "test"
    templar  = "test"
    globals  = {}
    locals   = {}
    a = AnsibleJ2Vars(templar, globals, locals)
    a.__getitem__(variable)

# Generated at 2022-06-11 17:26:20.898144
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.module_utils.common._collections_compat import Mapping
    import ansible.template.template as template
    ansibleJ2Vars = AnsibleJ2Vars(template.Templar(), dict())
    dict_object = dict()
    dict_object['ansibleJ2Vars'+'_t'] = ansibleJ2Vars
    assert isinstance(dict_object['ansibleJ2Vars_t'], Mapping)
    ansibleJ2Vars = dict_object['ansibleJ2Vars_t']
    ansibleJ2Vars._templar = template.Templar()
    ansibleJ2Vars._globals = dict()
    ansibleJ2Vars._locals = None

# Generated at 2022-06-11 17:26:25.469108
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """test_AnsibleJ2Vars___contains__"""

    var_test = AnsibleJ2Vars(None, {"foo": 1})

    assert True is ("foo" in var_test)
    assert False is ("bar" in var_test)


# Generated at 2022-06-11 17:26:35.391480
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
  from ansible.template import Templar
  templar = Templar(loader=None, variables={'var1': 1, 'var2': 2, 'var3': 3, 'var4': 4, 'var5': 5})
  globals = {'varg1': 1, 'varg2': 2, 'varg3': 3, 'varg4': 4, 'varg5': 5}
  locals = {'varl1': 1, 'varl2': 2, 'varl3': 3, 'varl4': 4, 'varl5': 5}
  ans_j2vars = AnsibleJ2Vars(templar, globals, locals)
  assert ans_j2vars.__contains__('var1') == True
  assert ans_j2vars.__contains__('var2') == True


# Generated at 2022-06-11 17:26:43.499134
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.templar import Templar
    from ansible.template.vars import AnsibleVars
    templar = Templar(loader=None, variables=AnsibleVars(loader=None, basedir=None))
    globals = {}
    locals = {}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars._templar == templar
    assert ansible_j2_vars._globals == globals
    assert ansible_j2_vars._locals == locals

# Generated at 2022-06-11 17:26:54.761521
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.module_utils.six import PY3
    from six import bytes_types


    def _test_vs_dict(template, vars, expected_value):
        # Create the class object
        templar = Templar(variables=vars)
        vars_obj = AnsibleJ2Vars(templar, {}, {})
        # Run the code to be tested
        value = vars_obj[template]
        # Check the result
        if isinstance(value, bytes_types) and PY3:
            value = value.decode("utf-8")
        assert value == expected_value

    # Plain template, no variables
    _test_vs_dict("template", {}, "template")
    # Plain template, with a variable
    _test_vs_dict

# Generated at 2022-06-11 17:27:06.219694
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from units.mock.loader import DictDataLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    variable = dict()
    variable['varname'] = "{{ is_failed }}"
    variable['varname1'] = "{{ is_changed }}"
    variable['varname2'] = "{{ play_hosts }}"
    variable['varname3'] = "{{ foo }}"
    variable['varname4'] = "{{ foo.bar }}"
    variable['varname5'] = "{{ foo['bar'] }}"
    variable['varname6'] = ""

    hostvars = HostVars()

# Generated at 2022-06-11 17:27:17.540668
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    ds = DataLoader()
    vm = VariableManager()
    t = AnsibleJ2Vars(vm, {}, locals={'foo': 'bar'})

    assert isinstance(t, AnsibleJ2Vars)
    assert isinstance(t, Mapping)

    for key in t:
        assert key in ['foo', 'ansible_version']

# Generated at 2022-06-11 17:27:24.204540
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader

    # Arrange
    template = "test.j2"
    loader = DataLoader()
    templar = Templar(loader, variables={})
    globals = {}
    locals = {"test": "value"}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Act
    result = 'test' in vars

    # Assert
    assert result

# Generated at 2022-06-11 17:27:33.208812
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars

    # FIXME: use a real inventory or load from something?
    inventory = Inventory("localhost")
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    play_vars = {"a": "b", "c": "d"}
    play_

# Generated at 2022-06-11 17:27:40.801106
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    ad = AnsibleDumper()
    yaml_obj = AnsibleBaseYAMLObject()
    var_o = ad.represent_data(yaml_obj)
    assert var_o in AnsibleJ2Vars(yaml_obj, globals={"ansible_default_ipv4":{"interface":"lo"}})

# Generated at 2022-06-11 17:27:52.984825
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # initialized
    templar = {
        'available_variables': {
            'test_json': '{"a": "b"}',
            'test_yaml': 'a: b'
        }
    }
    globals = {
        'test': 'abc'
    }
    locals = {
        'test_local': 'abc'
    }
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    # test 'test_local' in locals
    assert ansible_j2vars['test_local'] == 'abc'
    # test 'test' in gloabls
    assert ansible_j2vars['test'] == 'abc'
    # test 'test_json' in available_variables

# Generated at 2022-06-11 17:27:57.543212
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = Templar(variables={'test_var': 'test'})
    j2vars = AnsibleJ2Vars(templar, globals={'test_glob': 'test'})
    assert 'test_var' in j2vars
    assert 'test_glob' in j2vars
    assert 'undef_var' not in j2vars


# Generated at 2022-06-11 17:28:09.049508
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    host = Host(name='testhost')
    group = Group(name='testgroup')
    group.hosts.add(host)

    inventory = InventoryManager([group.name])
    inventory.add_group(group)
    inventory.add_host(host)

    context = PlayContext()
    context.vars = {'host_specific_var': 1, 'hostvar': 2, 'groupvar': 3, 'inventory_hostname': host.name}

# Generated at 2022-06-11 17:28:21.223950
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import yaml

    # Method under test
    def AnsibleJ2Vars___contains__(self, k):
        if k in self._locals:
            return True
        if k in self._templar.available_variables:
            return True
        if k in self._globals:
            return True
        return False

    # Setup inputs
    vars = dict(_vars='vars')
    templar = Templar(VaultLib(), loader=None)
    templar._available_variables = vars
    templar.set_available_variables(vars)

# Generated at 2022-06-11 17:28:30.005006
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    import sys

    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar

    from ansible.parsing.plugin_docs import read_docstring, get_docstring
    from ansible.module_utils import basic

    # We need to build a mock templar with a non-empty list of available
    # variables.  The easiest way to do that is to read the docstring for
    # one of the modules.
    doc, plainexamples, returndocs, metadata = read_docstring(
        get_docstring(basic, True, True)
    )

    if not doc:
        sys.exit("ERROR: Failed to read docstring for a module")

    j2 = Templar(None, {})
    j2.available_variables = doc['options']

    vars = Ans

# Generated at 2022-06-11 17:28:40.595806
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.templating.templar
    import ansible.vars.hostvars

    # Test variable not in vars nor in globals nor in locals
    variable_name = 'undefined variable'
    templar = ansible.templating.templar.Templar(loader=ansible.parsing.dataloader.DataLoader())
    globals = dict()
    locals = dict()
    vars_ = AnsibleJ2Vars(templar, globals, locals)

    try:
        vars_[variable_name]
    except KeyError as e:
        assert e.message == "undefined variable: %s" % variable_name
    else:
        assert False

   

# Generated at 2022-06-11 17:28:55.202848
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils.six import PY3

    Templar = Templar(None, loader=None)

    # basic test
    vars = AnsibleJ2Vars(Templar, dict(), dict())
    assert 'dict' in vars

    # test the case when KeyError is raised
    try:
        assert vars['SomeKey']
        assert not True, 'AnsibleJ2Vars.__getitem__ method does not raise KeyError if a key is not found'
    except KeyError:
        assert True

    # test the case when AnsibleUndefinedVariable is raised

# Generated at 2022-06-11 17:29:06.951171
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class MyTempler:
        def __init__(self):
            self.available_variables = dict()

    class MyGlobals:
        def __init__(self):
            self._globals = dict()

    templar = MyTempler()
    globals = MyGlobals()
    locals = dict()

    templar.available_variables['templar_key'] = 'templar_value'

    globals._globals['foo'] = 'bar'
    globals._globals['bar'] = 'foo'
    globals._globals['fizz'] = 'buzz'

    locals['fizz'] = 'foo'
    locals['l_buzz'] = 'bar'
    locals['l_foo'] = 'fizz'


# Generated at 2022-06-11 17:29:18.952986
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import sys
    from jinja2.environment import Environment
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar

    # test for Python3
    if sys.version_info > (3,):
        my_str_type = str
        my_int_type = int
        my_list_type = list
        my_dict_type = dict
        my_tuple_type = tuple
    else:
        # test for Python2
        my_str_type = basestring
        my_int_type = (int, long)
        my_list_type = (list, tuple)
        my_dict_type = dict
        my_tuple_type = tuple


# Generated at 2022-06-11 17:29:29.356380
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import mock
    def test_getitem(self, varname):
        mock_AnsibleUndefinedVariable = mock.Mock()
        mock_AnsibleUndefinedVariable.message = 'undefined variable'
        with mock.patch.object(self._templar, 'available_variables', return_value={'foo':'test'}):
            with mock.patch.object(self._templar, 'template', return_value=42):
                with mock.patch.object(self._templar, 'get_final_value', return_value=42):
                    assert 42 == self['foo']

# Generated at 2022-06-11 17:29:40.693419
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import sys
    import yaml

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.module_utils.six import PY3
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    if PY3:
        mappings = {'dict': dict, 'AnsibleMapping': AnsibleMapping}
    else:
        mappings = {'dict': dict, 'AnsibleMapping': AnsibleMapping, 'unicode': unicode}


# Generated at 2022-06-11 17:29:51.964968
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    t = Templar(loader=None)
    v = AnsibleJ2Vars(templar=t, globals={})

    # Basic cases
    assert (v.__contains__("x") is False)
    v.__getitem__("x")
    assert (v.__contains__("x") is False)
    v.__getitem__("l_x")
    assert (v.__contains__("x") is True)
    v.__getitem__("g_x")
    assert (v.__contains__("x") is True)

    # Exceptions

# Generated at 2022-06-11 17:30:00.199670
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    templar = Templar(
        loader=AnsibleLoader,
        variables={
            'foo': 'FOO'
        },
        host_vars=HostVars(None, {})
    )

    globals = {
        'bar': 'BAR'
    }

    j2_vars = AnsibleJ2Vars(templar, globals)

    assert 'foo' in j2_vars
    assert 'bar' in j2_vars
    assert 'baz' not in j2_vars


# Generated at 2022-06-11 17:30:10.280673
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.clean import module_response_deepcopy

    templar = Templar(loader=None, variables={})
    varmgr = VariableManager()
    hostvars = HostVars(vars=dict(a=1, b=2, c=3))
    varmgr.set_host_variable(host='localhost', varname='hostvars', value=hostvars)
    varmgr.set_host_variable(host='localhost', varname='vars', value=UnsafeProxy(dict(x=1, y=2, z=3)))

    av = Ansible

# Generated at 2022-06-11 17:30:19.446602
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    # AnsibleJ2Vars is an alias of a Mapping
    ansible_j2_vars = AnsibleJ2Vars(object, {}, {})
    names = locals().copy()
    items = [(name, value) for name, value in names.items() if not name.startswith("_")]

    for name, value in items:
        assert len(ansible_j2_vars) == len(value),\
            "the number of items in the mapping is correct"

# Generated at 2022-06-11 17:30:23.143384
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = None
    globals = None
    locals = None
    j2v = AnsibleJ2Vars(templar, globals, locals)
    j2v['something']
    # no exception raised, so the test succeeded

# Generated at 2022-06-11 17:30:37.722785
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    my_globals = {
        'foo': 'bar',
        'this': 'that'
    }
    my_locals = {
        'inventory_hostname': 'node1.localdomain'
    }
    my_jinj2 = AnsibleJ2Vars(Templar(), my_globals, my_locals)
    assert list(my_jinj2.__iter__()) == ['foo', 'this']

# Generated at 2022-06-11 17:30:39.754934
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
  result = AnsibleJ2Vars(templar, globals, locals)
  assert isinstance(result, AnsibleJ2Vars)


# Generated at 2022-06-11 17:30:44.333417
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.utils import template

    templar = template.AnsibleTemplar(loader=None, variables=None)

    globals = {
        'cookie': 'chocolate'
    }
    j2Vars = AnsibleJ2Vars(templar, globals)

    locals = {
        'cookie': 'oatmeal'
    }
    j2Vars_with_locals = AnsibleJ2Vars(templar, globals, locals)


    # __getitem__() should default to returning locals first, as it is
    # the most restricted scope.
    #
    # If not found in locals, it should then check the templar's vars,
    # and if not there, it should then check the globally defined vars.
    #
    # Test that this happens as expected, in these

# Generated at 2022-06-11 17:30:55.682920
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.utils.unsafe_proxy

    templar = ansible.utils.unsafe_proxy.AnsibleUnsafeText
    globals = dict()
    locals = dict()

    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # Check __contains__ with a known key
    assert 'ansible_version' in j2vars

    # Check __contains__ with an unknown key
    assert '__contains__' not in j2vars

    # Check __contains__ with a known key in _locals
    locals['version'] = 2.3
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'version' in j2vars

    # Check __contains__ with a known key in _globals

# Generated at 2022-06-11 17:31:07.142185
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        import jinja2
    except ImportError:
        return

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    def test_var_templating(value, value_expected, ansible_vars=None,
                            errors_expected=None, is_unsafe=False):
        test_templar = Templar(loader=DataLoader())
        test_templar.available_variables = ansible_vars or {}
        value_actual = test_templar.template(value, is_unsafe=is_unsafe)
        if value_expected != value_actual:
            raise AssertionError("Failed to template %s to %s, got %s" %
                                 (value, value_expected, value_actual))

# Generated at 2022-06-11 17:31:12.970346
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    templar.available_variables = dict(a=1,b=2,c=3)
    ajv = AnsibleJ2Vars(templar, dict(a=1,b=2,c=3), dict(a=1,b=2,c=3))
    assert(('a' in ajv) == True)



# Generated at 2022-06-11 17:31:16.255757
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # parameters:
    #   varname - string
    # returns:
    #   object
    # raises:
    #   KeyError
    #   AnsibleError
    #   AnsibleUndefinedVariable

    # TODO
    pass

# Generated at 2022-06-11 17:31:27.721538
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import SafeEval
    from ansible.template import Templar
    from ansible.template.template import AnsibleEnvironment
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar(loader=None, variables={'foo': 'bar'}, environment=AnsibleEnvironment(), shared_loader_obj=None)
    j2v = AnsibleJ2Vars(templar, dict())
    j2v._templar.available_variables = {'foo': 'bar', 'vars': UnsafeProxy({'foo': 'bar'})}

    assert len(j2v) == 2
    assert 'foo' in j2v
    assert 'vars' in j2v
    assert isinstance(j2v['vars'], UnsafeProxy)

# Generated at 2022-06-11 17:31:34.530512
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    hosts = ["localhost"]
    vars = dict(a=1, b=2)
    play_context = dict(line_number=1)
    templar = Templar(loader=None, variables=vars)
    variable_manager = VariableManager()
    j2_vars = AnsibleJ2Vars(templar=templar, globals=dict(c=3, d=4))

    variable_manager.add_host_vars(host=hosts[0], host_vars=vars)
    variable_manager.set_play_context(play_context)
    variable_manager.add_playbook_vars(vars)
    variable_manager.set

# Generated at 2022-06-11 17:31:44.272898
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.vault import VaultLib
    from ansible.inventory import Inventory
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    vault_pass = 'fake'
    vault_id = '1234'
    inventory_file = 'tests/fake_inventory'

# Generated at 2022-06-11 17:31:58.421338
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C

    options = dict(connection='local', module_path=['/to/mymodules'], forks=10, become=None,
                  become_method=None, become_user=None, check=False, diff=False, listhosts=None, listtasks=None,
                  listtags=None, syntax=None,subset=None)
    loader = DataLoader()
    passwords = dict()

# Generated at 2022-06-11 17:32:01.603790
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Initializing statement
    a = AnsibleJ2Vars(templar='',globals='',locals='')
    # Checking if True is returned when 'a' is present in the array
    assert a.__contains__('a') == True


# Generated at 2022-06-11 17:32:11.456195
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars
    # Test if a variable is in AnsibleJ2Vars
    locals = {
        'my_var': 'bar',
        'l_my_var': 'foo',
        'l_not_defined': 'defined',
    }
    templar = Templar(loader=None)

    available_variables = {'my_var': wrap_var(HostVars({'my_var': 'bar'}))}
    templar.set_available_variables(available_variables)

    fabl = AnsibleJ2Vars(templar, globals={}, locals=locals)
    assert 'my_var' in fabl

# Generated at 2022-06-11 17:32:22.249336
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """Check the conditions that the method
    AnsibleJ2Vars.__getitem__(self, varname)
    must satisfy.
    """

    # simple test
    assert isinstance(object(), object)

    # test template key
    assert True

    # test recursive key
    assert True

    # test missing var
    assert True

    # test var with #
    assert True

    # test jinja2 vars
    assert True

    # test list
    assert True

    # test dict
    assert True

    # test var that template fails
    assert True

    # test var that unsafed
    assert True

    # test hostvars
    assert True

    # test
    assert True

    # test select attr
    assert True

# Generated at 2022-06-11 17:32:23.284348
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert False, "not implemented yet"

# Generated at 2022-06-11 17:32:29.804462
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    import os
    import tempfile
    my_env = dict(os.environ)
    my_env["ANSIBLE_CONFIG"] = ""
    templar = Templar(loader=None, variables=dict(hello='world'), env=my_env)
    globals = dict(hello_g='world')
    my_vars = AnsibleJ2Vars(templar, globals)
    assert len(my_vars) == 3


# Generated at 2022-06-11 17:32:36.820774
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()
    j2vars = AnsibleJ2Vars(templar, {'somekey': 'somevalue'}, locals={'someotherkey': 'someothervalue'})

    assert j2vars['somekey'] == 'somevalue'
    assert j2vars['someotherkey'] == 'someothervalue'
    assert j2vars.get('somekey') == 'somevalue'
    assert j2vars.get('someotherkey') == 'someothervalue'
    try:
        tmp = j2vars['somenonexistantkey']
        assert False
    except KeyError:
        assert True

    assert 'somekey' in j2vars
    assert 'someotherkey' in j2vars
    assert 'somenonexistantkey'

# Generated at 2022-06-11 17:32:37.671583
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass # nothing to be tested here

# Generated at 2022-06-11 17:32:48.973731
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import pytest

    # exception
    templar = Templar(loader=None)
    globals = { 'g': 'g' }
    locals = {'l_l': 'l' }
    var_proxy = AnsibleJ2Vars(templar, globals, locals)
    with pytest.raises(KeyError):
        some_variable = var_proxy['some_variable']

    # available_variables
    templar = Templar(loader=None)
    globals = { 'g': 'g' }
    locals = {'l_l': 'l' }
    templar.available_variables = { 'a': 'a' }
    var_proxy = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-11 17:32:59.436998
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})

# Generated at 2022-06-11 17:33:21.685851
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''Test __contains__ method of AnsibleJ2Vars class'''
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    hostvars = HostVars(dict())
    templar = Templar(loader=None, variables=dict(), shared_loader_obj=None)
    test_dict = dict()
    test_dict['test'] = 'test'
    test_dict['test_hostvars'] = hostvars
    globals = dict()
    globals['test_globals'] = 'test_globals'
    test_proxy = AnsibleJ2Vars(templar, globals, locals=test_dict)

    assert 'test' in test_proxy
    assert 'test_hostvars' in test_proxy

# Generated at 2022-06-11 17:33:25.607667
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar()
    globals = {'hello': 'world'}
    locals = {'andrew': 'mcmillan'}
    template = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-11 17:33:26.250905
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass


# Generated at 2022-06-11 17:33:31.482568
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    templar = Templar(None, loader=DataLoader(), variables=VariableManager(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader())), shared_loader_obj=None)

    assert AnsibleJ2Vars(templar, dict()) is not None

if __name__ == "__main__":
    test_AnsibleJ2Vars()

# Generated at 2022-06-11 17:33:42.091135
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    import collections
    from ansible.template import Templar

    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(loader=None)
    ajv = AnsibleJ2Vars(templar, globals={})
    assert isinstance(ajv, collections.Mapping)
    assert isinstance(ajv, object)

    locals_dict = {'name': AnsibleUnicode('Bob'), 'age': AnsibleUnicode('21')}
    ajv = AnsibleJ2Vars(templar, globals={}, locals=locals_dict)
    assert isinstance(ajv, collections.Mapping)
    assert isinstance(ajv, object)

    # test magic method __getitem__


# Generated at 2022-06-11 17:33:53.331828
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import sys
    import os
    import yaml
    cur_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append( os.path.join(cur_path, '..', '..', 'lib', 'ansible') )
    from ansible.template import Templar

    f = open(os.path.join(cur_path, 'vars.yml'))
    variables = yaml.load(f)
    f.close()

    j2vars = AnsibleJ2Vars(Templar(loader=None), variables)
    assert j2vars['services'] == variables['services']
    assert j2vars['services1'] == variables['services1']
    assert j2vars['services2'] == variables['services2']
    assert j2vars

# Generated at 2022-06-11 17:33:55.563020
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = None
    globals = None
    locals = None

    ajv = AnsibleJ2Vars(templar, globals, locals)