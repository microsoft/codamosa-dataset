

# Generated at 2022-06-11 17:24:02.976162
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-11 17:24:13.311910
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    manager = VariableManager()

    manager._fact_cache = dict(a=dict(b=dict(c=1)))
    manager._fact_cache_time = dict(a=dict(b=dict(c=1)))
    manager._variable_cache = dict(a=dict(b=dict(c=1)))
    manager._extra_vars = dict(a=dict(b=dict(c=1)))

    vars = dict(a=dict(b=dict(c=1)))

    context = PlayContext()

    avars = AnsibleJ2Vars(manager, context)

    assert(bool("a" in avars))
    assert(bool("a.b" in avars))

# Generated at 2022-06-11 17:24:22.443431
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class Templar(object):
        available_variables = {'a': 'A', 'b': 'B', 'c': 'C'}

    vars = AnsibleJ2Vars(Templar(), {'d': 'D'}, locals={'e': 'E'})
    assert len(vars) == 5
    # locals == 'e' and 'context'
    assert len(vars._locals) == 2
    # available_variables == 'a', 'b', and 'c'
    assert len(vars._templar.available_variables) == 3
    assert len(vars._globals) == 1

# Generated at 2022-06-11 17:24:35.335800
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Imports
    from ansible.vars.hostvars import HostVars
    import os

    # Setup
    templar = None
    globals = {'a': 'b', 'c': 'd'}

    # Define test
    def __getitem__(varname):
        # Declare
        j2vars = AnsibleJ2Vars(templar, globals)
        # Execute
        try:
            j2vars[varname]
        except KeyError as e:
            # Verify
            # Exception thrown by AnsibleJ2Vars.__getitem__
            assert e.args == ("undefined variable: %s" % varname,)

# Generated at 2022-06-11 17:24:47.524844
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ansible_vars = AnsibleJ2Vars(None, dict())
    assert len(ansible_vars) == 0
    ansible_vars._templar.available_variables = {"name": "ansible"}
    ansible_vars._globals = {"name": "ansible"}
    assert len(ansible_vars) == 1
    ansible_vars._locals = {"name": "ansible"}
    assert len(ansible_vars) == 1

    ansible_vars = AnsibleJ2Vars(None, dict(name="ansible"))
    assert len(ansible_vars) == 1
    ansible_vars._templar.available_variables = {"name": "ansible", "key": "value"}
    assert len(ansible_vars) == 2


# Generated at 2022-06-11 17:24:52.401460
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # create object of the class AnsibleJ2Vars and initialize it
    #   with a valid Templar() object, as well
    #   as several dictionaries of variables representing
    #   different scopes (in jinja2 terminology).
    ansible_j2_vars = AnsibleJ2Vars(object(), {'globals': 'globals'})

    # check: call method __len__
    #   and compare result (length of variables list)
    #   with expected one
    assert len(ansible_j2_vars) == 1

# Generated at 2022-06-11 17:25:01.358463
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # test1: variable not in template, variable in globals
    variable_not_in_template = 'ansible_test_variable1'
    variable_in_globals = 'ansible_test_variable2'
    variable_in_template = 'ansible_test_variable3'
    globals = {variable_in_globals: 'my value'}
    available_variables = {variable_in_template: 'my value'}
    templar = {'available_variables': available_variables}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals)
    try:
        ansible_j2_vars[variable_not_in_template]
    except KeyError as e:
        assert e.args[0] == 'undefined variable: %s'

# Generated at 2022-06-11 17:25:11.562543
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    d1 = {'a': '1', 'b': '2'}
    d2 = {'a': '3', 'c': '4'}
    d_combined = AnsibleMapping(d1, combine_vars(d1, d2))
    aj2v = AnsibleJ2Vars(templar, d_combined)

    assert 'a' in aj2v
    assert 'b' in aj2v
    assert 'c' in aj2v
    assert 'd' not in aj2v
    assert {} not in aj2v

# Generated at 2022-06-11 17:25:17.311940
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    content = dict(variable="{{ A }}")
    variable_manager = dict(A="B")

    templar = Templar(loader=None, variables=variable_manager)

    v = AnsibleJ2Vars(templar,dict())
    assert v.__getitem__("variable") == "B"

# Generated at 2022-06-11 17:25:19.865127
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Tests AnsibleJ2Vars.__getitem__()
    '''
    # simple test for existence of method
    assert AnsibleJ2Vars.__getitem__ is not None

# Generated at 2022-06-11 17:25:35.431805
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """AnsibleJ2Vars method ``__getitem__`` returns the value of the variable name
    :param varname:    name of variable
    :type varname:     str
    :returns:          a value of the variable name
    :raises:           KeyError
    """

    # Local variables
    av_kv_list = [("k1", "v1"), ("k2", "v2")]
    av_dict = {}
    for k, v in av_kv_list:
        av_dict[k] = v
    template = "X1"

    class Templar:

        """Templar is a mock class."""

        def __init__(self, av_dict):
            self.available_variables = av_dict

        def template(self, template):
            return template

    # Test code

# Generated at 2022-06-11 17:25:37.528062
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # An exception is raised if 'AnsibleJ2Vars' is an abstract class
    AnsibleJ2Vars(None, None)

# Generated at 2022-06-11 17:25:49.494305
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
	from ansible.parsing.dataloader import DataLoader
	from ansible.vars.manager import VariableManager
	from ansible.inventory.manager import InventoryManager
	from ansible.playbook.play import Play
	from ansible.executor.playbook_executor import PlaybookExecutor
	from ansible.plugins.callback import CallbackBase
	from ansible.template import Templar
	import jinja2

	template = """
	{% for host in groups['ungrouped'] %}{{ hostvars[host]['ansible_eth0']['ipv4']['address'] }} {% endfor %}
	"""

	results_raw = {}
	class ResultCallback(CallbackBase):
		def v2_runner_on_ok(self, result, **kwargs):
			host = result

# Generated at 2022-06-11 17:26:00.277816
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    templar = variable_manager._templar
    globals = variable_manager._variables.get_vars(play=None, host=None, task=None)

    j2vars = AnsibleJ2Vars(templar, globals)

    i = iter(j2vars)
    assert next(i) == 'group_names'
    assert next(i) == 'groups'
    assert next(i) == 'inventory_dir'
    assert next(i)

# Generated at 2022-06-11 17:26:09.437886
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar, TemplarError
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None, variables={
        # The value of some_variable is not a valid jinja2 expression.
        'some_variable': AnsibleUnsafeText('"aaa"'),
        'undefined_variable': '{{ undefined_variable }}',
    })

    # We expect the jinja2 expression to be evaluated to ensure the variable is defined.
    j2vars = AnsibleJ2Vars(templar, {})
    assert j2vars['undefined_variable'] == u''

    # The value of some_variable is not a valid jinja2 expression. We do not
    # expect the variable to be evaluated and the value to be returned as is.
    assert j

# Generated at 2022-06-11 17:26:21.108887
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Tests the AnsibleJ2Vars.__getitem__ method
    '''

    # import module snippets
    from ansible.module_utils.basic import AnsibleModule
    from ansible.template import Templar

    # initialize mock environment

    # init AnsibleJ2Vars object:
    mock_globals = dict()
    mock_locals = dict()

    # init AnsibleModule object
    mock_spec = None
    module = AnsibleModule(argument_spec=mock_spec)
    templar = Templar(loader=module._ansible_loader, variables=dict())
    ansible_j2vars = AnsibleJ2Vars(templar=templar, globals=mock_globals, locals=mock_locals)


    # fail if jinja_vars is

# Generated at 2022-06-11 17:26:21.852551
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass

# Generated at 2022-06-11 17:26:30.842237
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    templar = Templar(None, loader=None)

    globals = {
        'a': 'normal',
        'b': {'a': 'normal'},
        'c': ['a'],
    }

    vars = AnsibleJ2Vars(templar, globals)

    assert vars['a'] == 'normal' # normal variable
    assert vars['b']['a'] == 'normal' # also normal
    assert vars['c'][0] == 'a' # also normal

    locals = {
        'a': 'normal',
        'b': {'a': 'normal'},
        'c': ['a'],
    }

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert vars['a']

# Generated at 2022-06-11 17:26:41.834227
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    MOCK_TEMPLAR = Templar()
    MOCK_GLOBAL = {}
    MOCK_LOCALS = {'foo': 'foo'}
    ref_AnsibleJ2Vars = AnsibleJ2Vars(MOCK_TEMPLAR, MOCK_GLOBAL, locals=MOCK_LOCALS)
    assert 'foo' in ref_AnsibleJ2Vars
    assert 'bar' not in ref_AnsibleJ2Vars
    assert 'env' in ref_AnsibleJ2Vars
    assert 'l_env' not in ref_AnsibleJ2Vars
    assert 'loop' in ref_AnsibleJ2Vars
    assert 'l_loop' not in ref_AnsibleJ2Vars


# Generated at 2022-06-11 17:26:53.996901
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # Create instance of class AnsibleJ2Vars and then check if the __init__()
    # method has the correct type for param 'templar', 'globals' and 'locals' and
    # if the keys of the dictionaries given as params 'globals' and 'locals' are
    # overwritten with the prefix 'l_'.
    templar = Templation(loader=None)
    globals = {'one': 1, 'two': 2}
    locals = {'three': 3, 'four': 4}
    locals = {'three': 3, 'four': 4}
    j2vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)
    assert isinstance(j2vars._templar, Templation)
    assert isinstance

# Generated at 2022-06-11 17:27:14.488938
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """Test __iter__ method of class AnsibleJ2Vars"""

    from ansible.template import Templar
    import jinja2

    templar = Templar(loader=None, variables={'v': 0})
    j2_vars = AnsibleJ2Vars(templar, {'k1': 1, 'k2': 2})

    j2_vars_keys = [ key for key in j2_vars ]

    assert j2_vars_keys == ['k1', 'k2', 'v']


# Generated at 2022-06-11 17:27:21.626159
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    Test case for the method __len__ of AnsibleJ2Vars.
    '''
    from ansible.template import Templar
    templar = Templar(None, None)
    globals_ = {'a': 1, 'b': 2, 'c': 3}
    locals_ = {'a': 2, 'd': 4}
    result = AnsibleJ2Vars(templar, globals_, locals_)
    assert len(result) == 4



# Generated at 2022-06-11 17:27:31.542258
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_vars = {'a': 'A', 'b': 'B'}
    ansible_globals = {'g': 'G'}
    ansible_locals = {'l_local': 'L'}
    expect_output = {'a': 'A', 'b': 'B', 'g': 'G', 'local': 'L'}
    templar = tmplar_mock()
    ajv = AnsibleJ2Vars(templar, ansible_globals, ansible_locals)
    assert ajv['a'] == 'A'
    assert ajv['b'] == 'B'
    assert ajv['g'] == 'G'
    assert ajv['local'] == 'L'
    for k in expect_output.keys():
        assert k

# Generated at 2022-06-11 17:27:42.548615
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)

    d = {'vars': {'var': 'value'}, 'a': '1', 'b': 2, 'c': {'var': 'value'}}
    jv = AnsibleJ2Vars(templar, d)

    # HostVars is special, return it as-is
    hostvars = HostVars(dict())
    d = {'vars': hostvars}
    jv = AnsibleJ2Vars(templar, d)
    assert jv['vars'] is hostvars

    # vars is special
    d = {'vars': {'var': 'value', 'var2': 2}}
    jv = Ansible

# Generated at 2022-06-11 17:27:54.121376
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    mock_templar = Templar(None)
    mock_globals = {}
    mock_locals = {}
    mock_templar.available_variables = {'key0': 'value0'}
    ansible_vars = AnsibleJ2Vars(mock_templar, mock_globals, locals=mock_locals)
    assert 'key0' in ansible_vars
    mock_globals = {'key1': 'value1'}
    ansible_vars = AnsibleJ2Vars(mock_templar, mock_globals, locals=mock_locals)


# Generated at 2022-06-11 17:28:05.529619
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.hostvars import HostVars
    templar = object()
    globals = {}
    vars = AnsibleJ2Vars(templar, globals)
    assert len(vars) == 0
    globals['test_global'] = 'test_global'
    assert len(vars) == 1
    globals['test_global_2'] = 'test_global_2'
    assert len(vars) == 2
    templar.available_variables = {}
    assert len(vars) == 2
    templar.available_variables['test_templar_var'] = 'test_templar_var'
    assert len(vars) == 3

# Generated at 2022-06-11 17:28:16.146404
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password_file='/home/agrunberg/ansible-vault.txt')
    templar = Templar(loader=None, variables=VariableManager(), vault_secrets=vault)

    test_vars = {
        'var1': '{{var2}}',
        'var2': '{{var3}}',
        'var3': '{{var4}}',
        'var4': '{{var5}}',
        'var5': '{{var6}}',
        'var6': '{{var7}}',
        'var7': '{{var8}}',
        'var8': "{{'var8'}}",
    }

    ansible_

# Generated at 2022-06-11 17:28:22.561033
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.vars.hostvars as hostvars
    from ansible.vars.unsafe_proxy import wrap_var
    import ansible.template.safe_eval

    class TemplatesDirs(AnsibleJ2Vars):
        def __init__(self, templar, globals, locals):
            self._templar = templar
            self._templar.available_variables = {'a': 1, 'b': 2, 'c': 3}
            self._globals = globals
            self._locals = locals

        def __contains__(self, k):
            if k in self._locals:
                return True
            if k in self._templar.available_variables:
                return True
            if k in self._globals:
                return True
            return

# Generated at 2022-06-11 17:28:30.635406
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2.utils

    if not jinja2.__version__.startswith('2.'):
        return

    class testData:
        def __init__(self):
            self.available_variables = dict()
            self.available_variables['ansible_hostname'] = 'localhost'
            self.available_variables['ansible_ssh_host'] = '127.0.0.1'
            self.available_variables['ansible_ssh_pass'] = 'password'
            self.available_variables['ansible_service_mgr'] = 'systemd'
            self.available_variables['ansible_play_hosts'] = '10.0.1.1'
            self.available_variables['a'] = '10.0.1.1'
            self.available_vari

# Generated at 2022-06-11 17:28:41.100363
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.task import Task
    from ansible.template import Templar

    h = HostVars(hostname='host1')
    h.vars = {
        'foo': 'bar',
    }

    t = Task()
    t.vars = {
        'baz': 'qux',
    }

    templar = Templar(loader=None, variables=dict())
    templar.set_available_variables(variables=h.vars,
                                    sort_keys=True,
                                    context=t)

    aj2v = AnsibleJ2Vars(templar=templar, globals={})

    assert 'foo' in aj2v
    assert 'baz' in aj2v


# Generated at 2022-06-11 17:29:00.780316
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Test __getitem__ method of class AnsibleJ2Vars
    '''
    # TODO
    pass

# Generated at 2022-06-11 17:29:10.092205
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    __tracebackhide__ = True
    import os
    import sys
    import pdb
    from jinja2 import Environment
    from jinja2 import StrictUndefined
    from jinja2 import Template

    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import AnsibleVars
    from ansible.vars.hostvars import HostVars

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    # generate fake vars

# Generated at 2022-06-11 17:29:22.297084
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    from ansible.utils.path import unfrackpath

    vault_password = 'ansible'
    vault_secrets = [VaultSecret(vault_password, None)]
    vault = VaultLib(vault_secrets)

    secret_string = 'string_to_encrypt'
    non_secret_string = 'non_secret_string'

    secret_encrypted = vault.encrypt(secret_string)
    secret_decrypted = vault.decrypt(secret_encrypted)

    assert secret_decrypted == secret_string
    assert secret_encrypted != secret_

# Generated at 2022-06-11 17:29:30.603912
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping

    available_variables = AnsibleMapping()
    available_variables['k'] = 'v'

    templar = Templar(loader=None, variables=available_variables)
    globals = dict()
    globals['k'] = 'v'
    locals = dict()
    locals['k'] = 'v'
    locals['l_k'] = 'v'

    j2vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)
    assert 'k' in j2vars


# Generated at 2022-06-11 17:29:42.022433
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    def new_task(args):
        t = Task()
        t._role = None
        t._task = args
        return t

    def new_block(name, parent, args):
        b = Block(parent=parent)
        b._block = args
        b._role = None
        return b

    # function to test against variable names
    def assert_variable(varname, varvalue):
        variable = proxy[varname]
        assert variable == varvalue

    # create a new variable proxy
    templar = object
    globals = object
    locals = object
    proxy = AnsibleJ2Vars(templar, globals, locals)

    # test against variable name 'vars'

# Generated at 2022-06-11 17:29:42.909540
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
	pass



# Generated at 2022-06-11 17:29:47.928753
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = {'g': 'g'}
    locals = {'l': 'l'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert( 'g' in ajv )
    assert( 'l' in ajv )
    assert( 'unknown' not in ajv )

# Generated at 2022-06-11 17:29:58.414314
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    variable_manager = DummyVarsModule()
    variable_manager.setup_vars()
    templar = DummyTemplar(variable_manager)
    globals = {'my_global': 'my_global_value'}
    locals = {'my_local': 'my_local_value'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert ('my_global' in j2vars) == True
    assert ('my_global_value' in j2vars.values()) == False
    assert ('my_local' in j2vars) == True
    assert ('my_local_value' in j2vars.values()) == False
    assert (j2vars['my_global'] == 'my_global_value')

# Generated at 2022-06-11 17:30:09.319312
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.hostvars import HostVars
    test_locals = {'key1':'value1', 'key2':'value2'}
    test_globals = {'key3':'value3', 'key4':'value4'}
    test_HostVars = HostVars()
    test_host_vars = {'key5':'value5', 'key6':'value6'}
    test_HostVars.data = test_host_vars
    test_templar = None
    test_proxy = AnsibleJ2Vars(test_templar, test_globals, locals=test_locals)
    test_proxy.add_to_unfinalized_vars(test_HostVars)
    assert (len(test_proxy) == 6)

# Generated at 2022-06-11 17:30:21.424067
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Create a class
    class TestYAMLObject(AnsibleBaseYAMLObject):
        pass

    # Create a data structure
    data = {"a": 1, "b": {"x": "Test", "y": "Unsafe"}, "c": [3, 4, 5, 6], "d": TestYAMLObject()}

    # Test __init__
    AnsibleJ2Vars(None, data)

    # Test __contains__
    assert "a" in AnsibleJ2Vars(None, data)
    assert "b" in AnsibleJ2Vars(None, data)

# Generated at 2022-06-11 17:30:45.693451
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # test if AnsibleJ2Vars.__contains__() works
    def _contains_test(objs, keys, expected):
        for key in keys:
            if key in objs:
                if not expected:
                    raise Exception("unexpected hit on key: %s" % key)
            else:
                if expected:
                    raise Exception("key not found: %s" % key)

    # test if AnsibleJ2Vars.__contains__() works
    # with globals=None, locals=None
    ajv_globals_locals_none = AnsibleJ2Vars(None, None, None)
    objs = ajv_globals_locals_none

# Generated at 2022-06-11 17:30:56.354161
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.manager import _get_fact_cache

    templar = Templar(loader=None, variables=None, fact_cache=_get_fact_cache())
    # Empty parameter
    assert AnsibleJ2Vars(templar, globals={}).__contains__("")

    # Parameter with length 1 characters string
    assert AnsibleJ2Vars(templar, globals={}).__contains__("1") == False
    assert AnsibleJ2Vars(templar, globals={"1": 1}).__contains__("1") == True

    # Parameter with length 2 characters string
    assert AnsibleJ2Vars(templar, globals={}).__contains__("12") == False
    assert AnsibleJ2Vars

# Generated at 2022-06-11 17:31:03.095914
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Create an instance of class AnsibleJ2Vars
    ansible_j2_vars = AnsibleJ2Vars(None, None)
    # Test the default case
    try:
        ansible_j2_vars.__getitem__('test_default_case')
        assert False
    except KeyError as e:
        assert 'test_default_case' in str(e)
        assert True


# Generated at 2022-06-11 17:31:04.074135
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert __AnsibleJ2Vars___getitem__('') == False


# Generated at 2022-06-11 17:31:12.665571
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ..jinja2.environment import Environment
    from ..jinja2.runtime import Missing
    import pprint
    j2_env = Environment()
    templar = j2_env.from_string("")

    proxy_obj = AnsibleJ2Vars(templar, dict(), dict())
    for k, v in {"k": "v"}.items():
        assert len(proxy_obj) == 0
        templar.available_variables = {"k": "v"}
        assert len(proxy_obj) == 1
    templar.available_variables = Missing()
    assert len(proxy_obj) == 0

# Generated at 2022-06-11 17:31:23.668365
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class MyTemplar():
        def __init__(self):
            self.available_variables = {'var1':'value1', 'var2':'value2'}
        def template(self, var):
            return self.available_variables[var]

    class MyGlobals():
        def __init__(self, vars):
            self.globals = {}
            for var, val in vars.items():
                self.globals[var] = val
        def __contains__(self, k):
            return k in self.globals
        def __getitem__(self, k):
            if k in self.globals:
                return self.globals[k]
            else:
                raise KeyError("undefined variable: %s" % k)


# Generated at 2022-06-11 17:31:30.896936
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    test_templar = Templar(loader=loader, variables=variable_manager)

    j2vars = AnsibleJ2Vars(test_templar, globals=globals)

    assert len(j2vars) == len(self._templar.available_variables) + len(self._globals)


# Generated at 2022-06-11 17:31:37.986948
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.templar import Templar
    from ansible.template.vars import AnsibleJ2Vars
    jv = AnsibleJ2Vars(
        Templar(PlayContext()),
        {'test_key': 'test_value'},
        locals={'test_local': 'test_value'})
    for jv_key in jv:
        assert jv_key
    len(jv)

# Generated at 2022-06-11 17:31:41.821212
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    t = Templar(loader=None, variables={'blah_blah_blah': AnsibleUnsafeText('hello, world')})
    vars = AnsibleJ2Vars(templar=t, globals={}, locals={})
    assert 'blah_blah_blah' in vars
    assert 'non_existing_var' not in vars

# Generated at 2022-06-11 17:31:48.171538
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
  locals = {'l_var1': 'val1'}
  vars = {'var1': 'val1'}
  globals = {'g_var1': 'val1'}
  from ansible.template.template import Templar
  AnsibleJ2Vars(Templar, globals, locals)
  assert "var1" in locals.keys()
  assert "var1" in vars.keys()
  assert "g_var1" in globals.keys()


# Generated at 2022-06-11 17:32:25.078827
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs

    loader = DataLoader()
    add_all_plugin_dirs(loader)
    templar = Templar(loader=loader)

    j2vars = AnsibleJ2Vars(templar, {})

    assert "vars" not in j2vars
    assert "foo" not in j2vars
    with pytest.raises(KeyError):
        j2vars["vars"]

# Generated at 2022-06-11 17:32:29.878292
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    vars = AnsibleJ2Vars(Templar(VariableManager(InventoryManager())), dict(), locals=dict(foo='bar', bam=dict(baz=1)))

    assert sorted(list(vars)) == sorted(['foo', 'bam'])


# Generated at 2022-06-11 17:32:36.879434
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.plugins.loader import variable_loader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    my_vars = {
        "_ignore_errors": None,
        "inventory_hostname": "test-hostname",
        "inventory_hostname_short": "test-hostname",
        "inventory_dir": "test-inventory-dir",
        "foo": "test-foo",
    }

    my_globals = {
        "bar": "test-bar",
    }

    my_locals = {
        "baz": "test-baz",
    }

    my_variable_manager = VariableManager()
   

# Generated at 2022-06-11 17:32:37.555679
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    AnsibleJ2Vars(1)

# Generated at 2022-06-11 17:32:38.149192
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass

# Generated at 2022-06-11 17:32:49.512237
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context._vars_per_host = {}
    templar = Templar(loader=None, variables=combine_vars(loader=None, play=play_context), shared_loader_obj=None)

    a = {}
    b = {'name': 'my_var', 'value': 'my_val'}

    j2vars = AnsibleJ2Vars(templar, a, b)

    import pytest
    with pytest.raises(Exception) as excinfo:
        assert j2vars.__contains__('abc')
    assert isinstance(excinfo.value, KeyError)

   

# Generated at 2022-06-11 17:33:00.264202
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # test case when variable exists in available_variables
    yaml_data = """
    a:
        name: "variable_vailable_variables"
    """

    results = unsafe_eval(yaml_data)
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = results
    templar = Templar(loader, variable_manager)

    # test case when variable not exists in available_variables
    globals_dict = dict()
    globals_dict['variable_vailable_variables'] = 'value'
    ansible_vars = Ansible

# Generated at 2022-06-11 17:33:11.532379
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import json
    # prepare data for class init
    templar = ""
    globals = ""
    locals  = {"a":1, "b":2}

    j2vars = AnsibleJ2Vars(templar, globals, locals=locals)

    # test case 1
    k = "a"
    # print("AnsibleJ2Vars.__contains__: test case 1 begin")
    # print("k is %s" % k)
    assert (k in j2vars)
    # print("AnsibleJ2Vars.__contains__: test case 1 end\n")

    # test case 2
    k = "c"
    # print("AnsibleJ2Vars.__contains__: test case 2 begin")
    # print("k is %s" % k)

# Generated at 2022-06-11 17:33:14.194080
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    v = AnsibleJ2Vars(None, {'a':'1'})
    l = len(v)
    assert l > 0


# Generated at 2022-06-11 17:33:24.092780
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template.safe_eval import VARS
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(
        debug=dict(required=False, type='bool', choices=BOOLEANS, default=False),
    )
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    templar = Templar(loader=None)

    # Ansible variable in vars directory
    variable = VARS.hostvars['localhost']['ansible_variable']
    variable_name = "ansible_variable"
    globals = {}
    locals = {}

    # Test: variable we want to get is found in Ansible variables