

# Generated at 2022-06-11 17:24:14.118488
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Test for existing keys
    '''
    from jinja2.utils import MissingError
    from ansible.template.safe_eval import ansible_safe_eval

    # given
    templar_mock = FakeTemplar(
        dict(a=dict(aa=dict(aaa='AAA', aab='AAB')),
             b=dict(bb='BB')))
    j2_vars = AnsibleJ2Vars(templar_mock, dict())

    assert j2_vars.available_variables == dict(a=dict(aa=dict(aaa='AAA', aab='AAB')), b=dict(bb='BB'))

    # when
    j2_vars['a'] == dict(aa=dict(aaa='AAA', aab='AAB'))
    j2

# Generated at 2022-06-11 17:24:24.703971
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {}
    jinja2_vars = AnsibleJ2Vars(templar, globals, locals={})

    # test case 1
    locals = {"test1": "test1"}
    jinja2_vars.add_locals(locals)

    # test case 1.1
    assert "test1" in jinja2_vars
    
    # test case 1.2
    assert jinja2_vars["test1"] == "test1"

    # test case 2
    locals = {"test2": "test2"}
    jinja2_vars.add_locals(locals)

    # test case 2.1
    assert "test1" in jinja2_v

# Generated at 2022-06-11 17:24:28.420192
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    var = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-11 17:24:39.021390
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    my_templar = Templar(variable_manager=VariableManager())

    my_globals = dict()
    my_locals = dict()

    my_ansible_j2_vars = AnsibleJ2Vars(my_templar, my_globals, my_locals)

    # test with a valid key
    my_key = 'l_foo'
    assert my_key in my_ansible_j2_vars

    my_ansible_j2_vars[my_key] = 'bar'
    assert my_ansible_j2_vars[my_key] == 'bar'

    # test

# Generated at 2022-06-11 17:24:49.485894
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # setup:
    # 1. Create a jinja2 template
    # 2. Create a base AnsibleJ2Vars
    # 3. Create a child AnsibleJ2Vars
    # 4. Create a context for j2 rendering
    # 5. Create a templar and attach it to AnsibleJ2Vars
    # 6. Create a j2 environment and attach it to AnsibleJ2Vars

    from jinja2 import Template
    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.vars.hostvars import HostVars
    import ansible
    ansible = ansible
    t = Template('{{ a }}')
    obj = AnsibleJ2Vars(None, None)

# Generated at 2022-06-11 17:24:59.458756
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.module_utils.six import iteritems

    templar = Templar(loader=None)

    globals = dict()
    locals = dict()

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Check empty dict
    if set(ansible_j2_vars) != set():
        raise AssertionError('ansible_j2_vars not equaling set([])')

    # Add locals
    locals['a'] = 1

    # Check not empty dict
    if set(ansible_j2_vars) != set(['a']):
        raise AssertionError('ansible_j2_vars not equaling set([\'a\'])')

# Generated at 2022-06-11 17:25:08.630005
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Arrange
    templar = None
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Act & Assert
    assert len(list(vars)) == 4
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    try:
        assert 'e' in vars
        assert False, 'Should be raised an exception'
    except KeyError as e:
        assert str(e) == 'undefined variable: e'


# Generated at 2022-06-11 17:25:20.020534
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.template import Templar
    import jinja2
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    var_manager = VariableManager()

    var_manager.set_globals({u'foo': u'bar'})
    var_manager.set_host_variable(u'buzz', AnsibleUnsafeText(u'fizz'))
    var_manager.set_host_variable(u'empty', AnsibleUnicode(u''))
    var_manager.set_host_variable(u'none', None)


# Generated at 2022-06-11 17:25:31.243459
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    class A:
        pass
    a = A()
    del a
    templar = Templar(a, a)
    globals = dict()
    locals = dict()
    a = AnsibleJ2Vars(templar, globals, locals)
    from ansible.vars.hostvars import HostVars
    h = HostVars()
    import ansible.vars.manager
    m = ansible.vars.manager.VariableManager()
    m.add_loader(a)
    m.add_loader(h)
    h["__UNSAFE__"] = 1
    a["vars"] = dict()
    a["vars"]["__UNSAFE__"] = 1
    b = a.add_locals(locals)

# Generated at 2022-06-11 17:25:38.737078
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    templar = mock.MagicMock()
    globals = mock.MagicMock()
    locals = mock.MagicMock()

    # Test with templar.available_variables
    templar.available_variables = {'test': 'test'}
    vars_obj = AnsibleJ2Vars(templar, globals, locals)
    assert 'test' in vars_obj

    # Test with locals
    locals = {'test1': 'test1'}
    vars_obj = AnsibleJ2Vars(templar, globals, locals)
    assert 'test1' in vars_obj

    # Test with globals
    globals = {'test2': 'test2'}
    vars_obj = AnsibleJ2Vars(templar, globals, locals)


# Generated at 2022-06-11 17:25:46.639461
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    Test __len__() function of ansible.vars.unsafe_proxy.AnsibleJ2Vars class
    '''

    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    assert True is True

# Generated at 2022-06-11 17:25:54.241636
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    variables = dict(a=1, b=2)
    globals = dict(b=4, c=5)
    locals = dict(b=6, d=7)

    templar = Templar(loader=None, variables=variables)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'a' in ansible_j2_vars
    assert 'b' in ansible_j2_vars
    assert 'c' in ansible_j2_vars
    assert 'd' in ansible_j2_vars
    assert 'e' not in ansible_j2_vars


# Generated at 2022-06-11 17:26:02.225617
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """
    test_AnsibleJ2Vars___contains__() checks the __contains__ method of class AnsibleJ2Vars using the following steps:
    1. Create AnsibleJ2Vars object
    2. Check that object contains some keys
    3. Check that object does not contain some keys
    """
    from ansible.template import Templar
    templar = Templar(loader=None)
    templar._available_variables = {
        "hostvar1": "hostvar1value",
        "hostvar2": "hostvar2value"
    }
    globals = {}
    locals = {}
    a = AnsibleJ2Vars(templar, globals, locals)

    assert "hostvar1" in a
    assert "hostvar2" in a
    assert "locvar1" not in a

# Generated at 2022-06-11 17:26:10.804224
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var

    t = Templar(None, runner=None)
    ajson_encoder = AnsibleJSONEncoder()
    yaml_object = AnsibleBaseYAMLObject(None, t)
    ajson_encoder.register_yaml_object(yaml_object)

    # 1. Assert that __contains__ return True if a key is present
    # in the template and in the local vars
    # 1.1 no local vars

# Generated at 2022-06-11 17:26:18.937894
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    vars = {'var': 'variable'}
    templar = Templar(loader=None)
    globals = {}
    locals = {'var2': 'local'}

    ajv = AnsibleJ2Vars(templar, globals=globals, locals=locals)

    assert ajv['var'] == 'variable'
    assert ajv['var2'] == 'local'
    with pytest.raises(KeyError):
        ajv['var3']

# Generated at 2022-06-11 17:26:24.694980
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    """Constructor of class AnsibleJ2Vars."""
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    assert isinstance(templar, Templar)
    assert templar.available_variables == {}
    locals = {'var1': 'foo'}
    globals = {'var2': 'bar'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert isinstance(ansible_j2_vars, AnsibleJ2Vars)


# Generated at 2022-06-11 17:26:34.108150
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import iteritems

    templar = Templar(loader=None, shared_loader_obj=None, variables=dict())
    globals_ = VariableManager()
    locals_ = VariableManager()

    ansible_j2_vars = AnsibleJ2Vars(templar, globals_, locals_)

    # check if globals_ and locals_ have been initialized
    assert list(iteritems(ansible_j2_vars._templar.available_variables)) == []
    assert list(iteritems(ansible_j2_vars._globals)) == []

# Generated at 2022-06-11 17:26:41.461217
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    test_templar = Templar()
    test_globals = dict()
    test_locals = dict()

    test_AnsibleJ2Vars = AnsibleJ2Vars(test_templar, test_globals, test_locals)

    # test for undefined variable
    assert test_AnsibleJ2Vars.__getitem__("undefinedvariable") == KeyError("undefinedvariable")


# Generated at 2022-06-11 17:26:53.803749
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = type('templar', (), {
        'available_variables': dict(a=1, b=2)
    })()
    # [DEFAULT]
    a_var = dict(a=1)
    b_var = dict(b=2)
    c_var = dict(c=3)
    d_var = dict(d=4)
    # [all]
    e_var = dict(e=5)
    f_var = dict(f=6)
    g_var = dict(g=7)
    h_var = dict(h=8)
    # [play]
    i_var = dict(i=9)
    j_var = dict(j=10)
    k_var = dict(k=11)
    l_var = dict(l=12)


# Generated at 2022-06-11 17:27:04.779133
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    Check if the method __iter__ of class AnsibleJ2Vars works properly
    '''
    from ansible.template import Templar
    templar = Templar(loader=None)
    a_str = 'str'
    a_list = [1,2]
    a_dict = {'k1':'v1', 'k2':'v2'}
    a_tup = (1,2,3)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals=a_list, locals=a_dict)
    all_keys = set()
    all_keys.update(a_dict, a_list)
    assert isinstance(ansible_j2_vars.__iter__(), iter)

# Generated at 2022-06-11 17:27:14.878632
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    __my_templar = object
    __my_globals = object
    __my_locals = {}
    __my_locals['a'] = 'b'
    __my_locals['c'] = 'd'
    __my_locals['e'] = 'f'
    vars = AnsibleJ2Vars(__my_templar, __my_globals, locals=__my_locals)
    for key in vars:
        assert key in __my_locals.keys()

# Generated at 2022-06-11 17:27:25.582348
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import ansible.parsing.vault
    import ansible.playbook.play
    import ansible.playbook.role.definition
    import ansible.playbook.taggable
    import ansible.template

    ansible.module_utils.basic.AnsibleModule = None
    ansible.module_utils.six.binary_type = type(b'')
    ansible.module_utils.six.text_type = type(u'')
    ansible.parsing.vault.VaultLib = type('VaultLib', (object,), {})
    ansible.playbook.play.Play = type('Play', (object,), {})
    ansible.playbook.role.definition.Role

# Generated at 2022-06-11 17:27:34.073293
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    # case 1: the variable is defined in the dictionary
    instance = AnsibleJ2Vars(templar, {'foo':'bar'}, locals=None)
    assert instance['foo'] == 'bar'

    # case 2: the variable is defined in available_variables
    instance = AnsibleJ2Vars(templar, {}, locals=None)
    templar.available_variables = {'foo':'bar'}
    assert instance['foo'] == 'bar'

    # case 3: the variable is defined in globals
    instance = AnsibleJ2Vars(templar, {'foo':'bar'}, locals=None)
    assert instance['foo'] == 'bar'

# Generated at 2022-06-11 17:27:42.553636
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template.template import Templar

    t = Templar(variables=AnsibleJ2Vars(Templar(variables={}), {}))
    var = unsafe_eval("{{ 'foo' }}")
    assert t.template(var) == 'foo'

    t = Templar(variables={})
    var = unsafe_eval("{{ 'bar' }}")
    t.available_variables = AnsibleJ2Vars(Templar(variables={}), {})
    assert t.template(var) == 'bar'

# Generated at 2022-06-11 17:27:52.345783
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Test with None locals
    from ansible.template.safe_eval import safe_eval

    templar = safe_eval.AnsibleTemplar()
    globals = { 'fact1': 'fact1', 'fact2': 'fact2' }
    locals = None
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert len(vars) == 2

    # Test with locals
    locals = { 'local1': 'local1' }
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert len(vars) == 3



# Generated at 2022-06-11 17:28:02.270766
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    mock_available_variables = {'hostvars': {'host1': {'hostvar1': 'hostvar1value' }},
                                'group_names': {'group1': {'groupvar1': 'groupvar1value' }},
                                'vars': {'var1': 'var1value'},
                                'inventory_hostname': 'localhost',
                                'inventory_hostname_short': 'localhost'}

    import jinja2.filters
    print("Test for __getitem__ without locals")
    mock_templar = type('', (object,), {'available_variables': mock_available_variables, 'template': jinja2.filters.do_force})

    globals = {'global1': 'global1value', 'global2': 'global2value'}
   

# Generated at 2022-06-11 17:28:11.734567
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    #import pdb
    #pdb.set_trace()
    class X: pass
    class Y: pass
    class Z: pass
    x = X()
    x.a = 'a'
    x.b = 'b'
    x.c = {'c':'c'}
    y = Y()
    z = Z()
    z.e = 'e'
    x.d = {'d':z}

    t = AnsibleJ2Vars(templar=x, globals=y)

    assert 'a' in t
    assert 'b' in t
    assert 'c' in t
    assert 'd' in t
    assert 'e' in t
    assert 'f' not in t
    assert t['a'] == 'a'
    assert t['b'] == 'b'
   

# Generated at 2022-06-11 17:28:19.720372
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import safe_eval

    # init an AnsibleJ2Vars obj
    test_templar = safe_eval.AnsibleModule()
    test_globals = dict()
    test_locals = dict()
    test_obj = AnsibleJ2Vars(test_templar, test_globals, locals=test_locals)

    # get the length of the object
    len_ret = len(test_obj)

    assert len_ret == 0

# Generated at 2022-06-11 17:28:24.864573
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.templar import Templar

    templar = Templar(variables={})
    globals = {}
    locals = {}
    proxy  = AnsibleJ2Vars(templar, globals, locals)
    assert proxy._templar == templar
    assert proxy._globals == globals
    assert proxy._locals == locals

# Generated at 2022-06-11 17:28:31.781831
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import sys, os
    import pprint
    import yaml
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    host_vars = HostVars(host='localhost', variables={'foo': 'bar'})
    # python3 compatibility
    if sys.version_info[0] > 2:
        host_vars.__setattr__('__UNSAFE__', True)
    else:
        host_vars.__setattr__('__UNSAFE__', True)

# Generated at 2022-06-11 17:28:39.814265
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert AnsibleJ2Vars()

# Generated at 2022-06-11 17:28:51.466276
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.playbook.templar
    templar = ansible.playbook.templar.Templar(loader=None, variables={})

    # Check case __getitem__ raises KeyError
    j2_vars = AnsibleJ2Vars(templar, {})
    with pytest.raises(KeyError):
        j2_vars['VARIABLE']

    # Check case __getitem__ returns dict from self._locals
    j2_vars = AnsibleJ2Vars(templar, {}, {'VARIABLE': {}})
    assert isinstance(j2_vars['VARIABLE'], dict)

    # Check case __getitem__ returns dict from self._templar.available_variables
    j2_vars = AnsibleJ2Vars

# Generated at 2022-06-11 17:29:03.461381
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    # variables that will be available during the execution of the jinja2 filter
    # they are not the actual vars passed to the jinja2 filter
    from_task = {
        'var_from_task': 'from_task_value',
        'value_from_task': wrap_var(AnsibleUnsafeText('unsafe_from_task_value')),
        'unsafe_from_task': wrap_var(AnsibleUnsafeText('unsafe_from_task_value')),
    }

    # these are the vars passed to the jinja2 filter

# Generated at 2022-06-11 17:29:08.855331
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    t = Templar()

    j2v = AnsibleJ2Vars(t, {'a':1}, locals={'a':1})
    assert 'a' in j2v
    assert 'b' not in j2v
    assert not any(x in j2v for x in ['a', 'b', 'c'])
    assert all(x in j2v for x in ['a', 'b'])



# Generated at 2022-06-11 17:29:20.813947
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import os
    import sys
    import unittest

    sys.path.append(os.path.dirname(__file__) + '/../../../lib/')
    from ansible.template import Templar

    class AnsibleJ2VarsTestCase(unittest.TestCase):

        def setUp(self):
            self._templar = Templar(loader=None)

        def test_AnsibleJ2Vars___getitem__(self):
            j2vars = ansible_vars = AnsibleJ2Vars(templar=self._templar, globals={})

            self.assertRaises(KeyError, lambda: j2vars['invalid'])

            j2vars._templar.available_variables = {'valid': 'valid'}

# Generated at 2022-06-11 17:29:30.683876
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """
    Tests to see if AnsibleJ2Vars() can properly set and retrieve variables
    """

    # test instantiation
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    templar = Templar(variables={'vname': 'value'}, loader=None, shared_loader_obj=None,
                      exclude_parent=False, searchpath=[], variable_manager=None,
                      loader_basedir=".", context=PlayContext(), disable_lookups=False,
                      use_deprecated_auth=False,
                      jinja2_native=False,
                      jinja2_extensions=None)
    ajv = AnsibleJ2Vars(templar, globals={}, locals=None)

    # test setting and retrieving a variable

# Generated at 2022-06-11 17:29:36.608734
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = None
    globals = {'a': 3, 'b': 4, 'c': 5}
    locals = {'e': 6, 'f': 7, 'g': 8}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert(len(vars) == len(globals) + len(locals))


# Generated at 2022-06-11 17:29:45.327193
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    
    # Prepare test data
    vars_proxy = AnsibleJ2Vars(templar, globals={'a': 1, 'b': 2})
    vars_proxy._templar.available_variables = {'c': 3}
    
    # Test method code
    sut = vars_proxy['a']
    assert sut == 1
    sut = vars_proxy['c']
    assert sut == 3
    try:
        vars_proxy['d']
    except KeyError as e:
        assert e.args[0] == "undefined variable: d"

# Generated at 2022-06-11 17:29:56.078037
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    vars_manager = VariableManager()

    j2vars = AnsibleJ2Vars(Templar(loader=loader, variables=vars_manager), dict())
    assert isinstance(j2vars, AnsibleJ2Vars), 'AnsibleJ2Vars should be instance of AnsibleJ2Vars'
    assert isinstance(j2vars._templar, Templar), '_templar should be instance of Templar'

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-11 17:30:07.708164
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['test/units/vars/ansible_hosts'])
    variable_manager.set_inventory(inventory)

    variable_manager.extra_vars = {'hostvars': {'host_all': {'nested_var': 'goodbye'}}}


# Generated at 2022-06-11 17:30:23.817036
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={})
    globals = {'foo': 'bar'}
    locals = {'l_foo': 'barbar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['l_foo'] == 'barbar'
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars[AnsibleUnicode('foo')] == 'bar'

# Generated at 2022-06-11 17:30:31.878772
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Test if the __init__ method generates the instance attributes correctly, including whether
    # the templar object is instantiated correctly
    test_templar = Templar(loader=loader, variables={'somevar': 'somevalue'})
    test_proxy = AnsibleJ2Vars(test_templar, {'someglobals': 'globals'})
    assert test_proxy._templar._loader == loader
    assert test_proxy._templar.available_variables == {'somevar': 'somevalue'}
    assert test_proxy._globals == {'someglobals': 'globals'}

    # Test if the __init__ method generates the _locals attribute correctly

# Generated at 2022-06-11 17:30:41.142733
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    locals   = {}
    globals  = {}
    templar  = {}

    # Test empty var
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 0

    # Test local var
    locals["test"] = None
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 1

    # Test global var
    globals["test2"] = None
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 2


# Generated at 2022-06-11 17:30:53.307567
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib
    from ansible.template.varspecs import find_varspecs
    from ansible.template import Templar
    import ansible.module_utils.facts.system.distribution

    templar = Templar(
        loader=None,
        shared_loader_obj=None,
        variables={},
        vault_secrets=VaultLib(),
    )

    AnsibleJ2Vars(
        templar=templar,
        globals=ansible.module_utils.facts.system.distribution.DISTRIBUTION_FACTS,
    )
    assert len(templar.available_variables) == 1

    # test 'locals' variable

# Generated at 2022-06-11 17:31:04.274689
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from collections import namedtuple

    # Prepare a test case
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(test_var="test")
    variable_manager.set_fact = {"test_fact": "test"}
    variable_manager.set_host_variable = lambda host, var, value: None
    variable_manager.get_vars = lambda play=None: {"test_play": "test"}
    variable_manager.get_host_vars = lambda host: {"test_host": "test"}
    env = jinja2.Environment()
    taskvars = dict

# Generated at 2022-06-11 17:31:14.156513
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    import ansible.vars.hostvars

    test_var = ansible.vars.hostvars.HostVars(dict())
    test_var.vars = {"a": "b", "c": "d"}
    test_var.hostname = "test"
    test_var['vars'] = {'a': 'b', 'c': 'd'}

    test_templar = Templar()
    test_vars = AnsibleJ2Vars(test_templar, {}, {})

    test_vars._templar.available_variables = {'test_var':test_var}
    assert test_vars['test_var'] == test_var

    test_vars._loc

# Generated at 2022-06-11 17:31:25.800255
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # Test 1: variable with single quote
    variable = '{{ ansible_hostname }}-{{ ansible_hostname }}'
    loader = DataLoader()
    variable = loader.load_from_file(variable)
    templar = Templar(loader=loader, variables=dict())
    fvars = AnsibleJ2Vars(templar, dict())

    assert fvars['ansible_hostname'] == '{{ ansible_hostname }}'
    assert fvars[variable] == '{{ ansible_hostname }}-{{ ansible_hostname }}'

    # Test 2: variable with double quote
    variable = '"{{ ansible_hostname }}-{{ ansible_hostname }}"'
    loader = Data

# Generated at 2022-06-11 17:31:36.495067
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.vars.hostvars
    import ansible.vars.manager
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    vars_manager = VariableManager()
    vault_secrets = VaultLib()
    templar = Templar(vars_manager, vault_secrets.secrets)

    vars_manager.set_globals(ansible.vars.manager.get_vars(loader=None, play=None))
    vars_manager.set_inventory(None)
    vars_manager.set_play_context(None)

    j2vars = AnsibleJ2Vars(templar, {'v': 'global'})
    assert 'v' in j2vars

# Generated at 2022-06-11 17:31:39.317275
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_AnsibleJ2Vars = AnsibleJ2Vars({}, {}, {})
    assert test_AnsibleJ2Vars['a'] == {}

# Generated at 2022-06-11 17:31:46.869324
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeProxy
    import ansible.module_utils.common.removed

    # local variables
    l_a = "test_l_a"
    l_b = "test_l_b"
    l_c = "test_l_c"
    l_context = "test_l_context"
    l_environment = "test_l_environment"
    l_template = "test_l_template"

    # available variables
    a = "test_a"

    # globals
    g_a = "test_g_a"

    # dictionary of local variables

# Generated at 2022-06-11 17:32:00.081771
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    context = PlayContext()
    host = Host(name="test.example.org")
    group = Group(name="test_group")
    group.add_host(host)
    inventory = Inventory()
    inventory.add_group(group)

    variable_manager = VariableManager(loader=None, inventory=inventory, strongly_typed=False, host_vars={})
    templar = Templar(loader=None, variables=variable_manager)

    # Test __contains__ with a key in templar's available variables
    vars_

# Generated at 2022-06-11 17:32:09.953421
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import unsafe_eval

# Generated at 2022-06-11 17:32:16.675783
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.reserved import Reserved
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=None)
    templar.available_variables = combine_vars(dict(), dict(hostvars={}), dict(selfvars={}), dict(group_vars={}), dict(vars={}), dict(role_vars={}), dict(task_vars={}), dict(ansible_vars=Reserved(hostvars={})), None, None, variable_manager=VariableManager(loader=None, inventory=None), use_jinja=True)


# Generated at 2022-06-11 17:32:27.329490
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    templar = Templar(loader=None)

    globals = {
        'inventory_hostname': 'the host',
        'groups': { "group": [ "foo", "bar" ] }
    }

    # Add a custom test filter
    templar.environment.filters.update({
        'foo': lambda x: 'foo(%s)' % x,
    })

    # __getitem__ should just return the same value when the varname is not in _templar.available_variables
    vars = AnsibleJ2Vars(templar, globals)
    assert vars['inventory_hostname'] == 'the host'

# Generated at 2022-06-11 17:32:34.637731
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = Templar(loader=None)
    vars1 = AnsibleJ2Vars(templar,
                          {"g1":1, "g2":2},
                          locals={"l1":1})
    assert "l1" in vars1
    assert "g1" in vars1
    assert "1" not in vars1

    templar.set_available_variables({"vars": {"l2":2}})
    vars2 = AnsibleJ2Vars(templar,
                          {"g1":1, "g2":2},
                          locals={"l1":1})
    assert "l2" not in vars2
    assert "g1" in vars2
    assert "l1" in vars2
    assert "1" not in vars2

# Generated at 2022-06-11 17:32:41.852359
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    class MockJinja2Globals(dict):
        def __init__(self, *args, **kwargs):
            super(MockJinja2Globals, self).__init__(*args, **kwargs)
            self.update({'a': 'A', 'b': 'B', 'c': 'C'})

    class MockJinja2Locals(dict):
        def __init__(self, *args, **kwargs):
            super(MockJinja2Locals, self).__init__(*args, **kwargs)
            self.update({'x': 'X', 'y': 'Y', 'z': 'Z'})

    class MockTemplar(Templar):
        def __init__(self, *args, **kwargs):
            super

# Generated at 2022-06-11 17:32:52.597577
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    dataloader = DataLoader()
    host_vars = HostVars(inventory=None, loader=dataloader, variable_manager=None)

    # test undefined variable
    with pytest.raises(KeyError):
        AnsibleJ2Vars(Templar(loader=dataloader), dict()).__getitem__('inexistent_variable')

    # test already templated variable
    ansible_j2_vars = AnsibleJ2Vars(Templar(loader=dataloader), dict())
    ansible_j2_vars._templ

# Generated at 2022-06-11 17:32:55.313283
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert False, "Test not implemented"  # TODO: set up tests for testing AnsibleJ2Vars functions to cover branches



# Generated at 2022-06-11 17:33:02.711846
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = {"g1":"G1"}
    locals = {"g1":"G1", "l1":"L1"}
    aj2var = AnsibleJ2Vars(templar, globals, locals=locals)
    assert("g1" in aj2var)
    assert("l1" in aj2var)
    assert("g2" not in aj2var)
    assert("l2" not in aj2var)


# Generated at 2022-06-11 17:33:13.293269
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Prepare test data -
    Set variable with dotted key
    '''
    templar = "dummy"
    globals = {'dict_param': {'subdict_param': {'subsubdict_param': 3}}}
    locals = {'subsubdict_param': 4}

    # Create j2vars object with input data
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # Test if variable by dotted key
    assert j2vars['subsubdict_param'] == 4
    # Test if variable by dotted key
    assert j2vars['dict_param.subdict_param.subsubdict_param'] == 3
    # Tests for None
    assert j2vars['subsubdict_param_empty'] is None
    # Tests for KeyError exception


# Generated at 2022-06-11 17:33:26.470320
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_globals(dict(
        foo='blah',
        bar='gah',
        baz='ugh',
    ))

    variable_manager.set_host_variables(dict(hostvars='hostvars'), 'host1')
    variable_manager.set_host_variables(dict(hostvars='hostvars'), 'host2')
    variable_manager.set_host_variables(dict(hostvars='hostvars'), 'host3')
    variable_manager.set_host_variables(dict(hostvars='hostvars'), 'host4')

# Generated at 2022-06-11 17:33:33.091517
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    t = Templar(loader=None, variables=dict())

    class Dummy():
        def __init__(self, hostname):
            self.hostname = hostname
        def get_name(self):
            return 'localhost'

    # Test __contains__ with _globals
    vars = AnsibleJ2Vars(templar=t, globals={'_host': Dummy('localhost')})
    assert('_host' in vars)
    assert('_host' in vars)

    # Test __contains__ with _templar
    vars = AnsibleJ2Vars(templar=t, globals={'_host': Dummy('localhost')})

# Generated at 2022-06-11 17:33:40.502296
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    templar._available_variables = {'a': HostVars()}
    globals = {'b': HostVars(), 'context': {}}
    v = AnsibleJ2Vars(templar, globals, None)
    assert 'a' in v
    assert 'b' not in v
    assert 'c' not in v


# Generated at 2022-06-11 17:33:51.534556
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Test the method AnsibleJ2Vars.__contains__()
    '''
    # Test with a Templar() object with a list of variables
    templar = Templar([])
    # Templates to test
    globals = {'is_windows': True}
    locals = {'inventory_hostname': 'host1.example.com'}
    # Test with globals={}, locals={}
    j2_vars = AnsibleJ2Vars(templar, globals, locals)
    # Test with a non-existent var in globals, locals, var
    assert 'is_windows' in j2_vars
    # Test with a var in var
    templar.available_variables = {'inventory_hostname': 'host1.example.com'}
    assert 'inventory_hostname'

# Generated at 2022-06-11 17:33:59.350841
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # NOTE: We cannot load 'test_templar' here, cause loading it
    #       also loads the whole test framework, which is not what
    #       we want to test right now.

    def test_getitem_for_templar_class(templar_class):
        templar = templar_class({})
        from ansible.vars.unsafe_proxy import wrap_var
        unsafe_var = wrap_var(42, templar)
        unsafe_var.__UNSAFE__ = True
        vars = AnsibleJ2Vars(templar, {}, locals={'bar': unsafe_var})
        assert 42 == vars['bar']

    # Test Templar
    test_getitem_for_templar_class(AnsibleJ2Vars.Templar)

    #