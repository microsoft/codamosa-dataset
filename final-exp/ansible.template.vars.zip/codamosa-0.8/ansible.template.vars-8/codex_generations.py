

# Generated at 2022-06-11 17:24:13.702127
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import safe_eval
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    module_vars = dict(variable_1='value_1')
    templar = Templar(loader=None, variables=module_vars)
    globals = dict(globals_1='globals_1', globals_2='globals_2')
    ansible_v2vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=None)
    locals = dict(locals_1='locals_1', locals_2='locals_2')

    assert 'variable_1' in ansible_v

# Generated at 2022-06-11 17:24:14.297225
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass

# Generated at 2022-06-11 17:24:23.338702
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.utils.vars import merge_hash
    play_context = PlayContext()
    templar = Templar(loader=None, variables=dict(), play_context=play_context)
    _globals = {'foo': 'bar'}
    _locals = dict()
    a = AnsibleJ2Vars(templar, _globals, locals=_locals)
    assert 'foo' in a
    assert 'bar' not in a

# Generated at 2022-06-11 17:24:34.076733
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # TODO: Add unit tests

    #variable = 'item'
    #varname = 'varname'
    #value = 'value'

    #self._templar.template(variable)
    #self._templar.available_variables
    #self._locals

    import unittest
    class test_AnsibleJ2Vars(unittest.TestCase):
        def test_AnsibleJ2Vars_getitem_1(self):
            pass
        def test_AnsibleJ2Vars_getitem_2(self):
            pass

    unittest.main()



# Generated at 2022-06-11 17:24:39.517209
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)
    vars = AnsibleJ2Vars(templar, dict(), dict(a='abc', b=3))

    assert(len(vars) == 2)


# Generated at 2022-06-11 17:24:50.103895
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Test method __getitem__ of class AnsibleJ2Vars
    '''

    import os
    import string
    import tempfile
    import unittest
    import shutil
    import ansible.utils
    import ansible.inventory
    import ansible.playbook
    import ansible.runner
    import ansible.constants as C
    import ansible.errors
    from ansible.playbook.play_context import PlayContext

    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins

    # Create a temporary directory to use as the ansible base
    temp_dir = tempfile.mkdtemp()
    test_vars_dir = os.path.join(temp_dir, "vars")

# Generated at 2022-06-11 17:25:00.069089
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {}

    def test(locals, var, expected):
        j2vars = AnsibleJ2Vars(templar, globals, locals)
        actual = j2vars[var]
        if isinstance(expected, Exception):
            assert isinstance(actual, exception_types[expected])
        else:
            assert actual == expected
    locals = {'l_var': 'lol'}
    test(locals, 'var', KeyError)
    test(locals, 'l_var', 'lol')
    test(locals, 'unavailable', KeyError)


# Generated at 2022-06-11 17:25:10.405126
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    class AnsibleModule:
        def __init__(self, *args, **kwargs):
            self.params = {}
    import jinja2.sandbox
    class AnsibleTemplar:
        def __init__(self, *args, **kwargs):
            self.available_variables = {'vars': {'a': 'b'}, 'vars_a': 'b'}
            self.environment = jinja2.sandbox.SandboxedEnvironment()
            self.environment.loader = jinja2.DictLoader({})
            self.available_variables['vars_a'] = 'b'
        def template(self, variable):
            return variable
    ajv = Ansible

# Generated at 2022-06-11 17:25:17.067476
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None, variables={'test':'test'})
    globals = {'test':'test'}

    a = AnsibleJ2Vars(templar, globals)

    assert len(a) == 2
    assert __len__(a) == 2



# Generated at 2022-06-11 17:25:22.750508
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()
    globals = {}
    locals = {'myvar':'myvalue'}
    var_proxy = AnsibleJ2Vars(templar, globals, locals)

    assert var_proxy['myvar'] == 'myvalue'
    try:
        var_proxy['undefined']
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-11 17:25:36.538143
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    context = PlayContext()

    templar = Templar(loader=None, variables={})
    context._update_vars_files(templar)

    globals = {
        'ansible_version': {
            'full': '2.0.0.0',
            'major': 2,
            'minor': 0,
            'revision': 0,
            'string': '2.0.0.0',
        },
        'template_host': 'myhost',
        'template_uid': 1000,
    }

    j2_vars = AnsibleJ2Vars(templar, globals, locals=context.all_vars)
    assert j2_vars['template_host'] is not None

# Generated at 2022-06-11 17:25:48.361285
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class TestTemplar:
        def __init__(self, vars):
            self.vars = vars
            pass
        def available_variables(self, *args, **kwargs):
            return self.vars
        def template(self, *args, **kwargs):
            return None
    # Test data (dict of variable names and values)
    vars = {"a" : "A", "b" : "B", "c" : "C"}
    # Test code
    ansible_j2_vars = AnsibleJ2Vars(
        TestTemplar(vars),
        locals={},
        globals={}
    )
    assert len(ansible_j2_vars) == len(vars)
# Test end


# Generated at 2022-06-11 17:25:58.437309
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class Templar():
        available_variables = {"a":"v1","b":"v2","c":"v3"}

    class TestEmpty():
        def test_empty(self):
            test_vars = AnsibleJ2Vars(Templar(), {})
            assert list(test_vars) == ["a","b","c"]
    class TestNonEmpty():
        def test_non_empty(self):
            test_vars = AnsibleJ2Vars(Templar(), {"1":"one"})
            assert list(test_vars) == ["a","b","c", "1"]

    TestEmpty().test_empty()
    TestNonEmpty().test_non_empty()


# Generated at 2022-06-11 17:26:07.485536
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.playbook.play_context import PlayContext

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    host = inventory.get_host("localhost")
    play_context = PlayContext()

# Generated at 2022-06-11 17:26:18.883969
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import copy
    from ansible.template import Templar
    globals = {
        'xyz': '123',
        'abc': '456',
    }
    locals = {
        'l_foo': 'bar',
        'l_baz': 'quz',
    }

    my_templar = Templar(loader=None)
    my_templar.available_variables = { k:copy.deepcopy(v) for k,v in iteritems(globals) }
    for k,v in iteritems(locals):
        my_templar.available_variables[k] = copy.deepcopy(v)
    assert( len(my_templar.available_variables) == len(globals) + len(locals) )


# Generated at 2022-06-11 17:26:22.141066
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    t = AnsibleJ2Vars(None, None)
    assert t._templar == None
    assert t._globals == None
    assert t._locals == dict()

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-11 17:26:30.984714
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Test variables
    test_templar = None
    test_globals = None
    test_locals = None
    test_obj = None
    test_res = None
    test_exp = None

    # Attempt to iterate over empty object - Should return an empty set
    test_obj = AnsibleJ2Vars(test_templar, test_globals, locals=test_locals)
    test_res = set(iter(test_obj))
    test_exp = set()
    assert test_res == test_exp

    # Attempt to iterate over partially filled object - Should return non-empty set
    test_obj = AnsibleJ2Vars(test_templar, {'a': 0}, {'b': 1})
    test_res = set(iter(test_obj))
    test_exp

# Generated at 2022-06-11 17:26:34.107680
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        j2vars = AnsibleJ2Vars(None, {}, None)
        results = j2vars['foo']
    except Exception as e:
        return True
    return False


# Generated at 2022-06-11 17:26:44.389070
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template import Templar
    import os
    import pytest

    scope = {'unsafe_eval': unsafe_eval,
             'var1': 'a',
             'var2': 'b',
             'var3': '{{ var1 }}',
             'var4': '{{ var2 }}',
             'var5': '{{ var3 }}',
             'var6': '{{ var2 }}{{ var1 }}',
             'var7': True if os.path.exists('/tmp') else False,
             'var8': '{{ var7 }}',
             'var9': '{{ var7 }}',
             'var10': '{{ var8 }}'}

# Generated at 2022-06-11 17:26:55.311542
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # define jinja variables
    temp_locals = dict()
    temp_globals = dict()
    temp_globals["g_name"] = "global name"
    temp_globals["g_age"] = "global age"
    temp_globals["g_weight"] = "global weight"
    temp_locals["l_name"] = "local name"
    temp_locals["l_age"] = "local age"
    temp_locals["l_weight"] = "local weight"

    # define ansible variables
    ansible_vars = dict()
    ansible_vars["a_name"] = "ansible name"
    ansible_vars["a_age"] = "ansible age"
    ansible_vars["a_weight"] = "ansible weight"

    #

# Generated at 2022-06-11 17:27:12.780820
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    # vars is needed to be passed otherwise __iter__ function will recursively call itself
    vars = dict(k1="v1", k2=dict(k21="v21", k22="v22"), k3='v3')
    vars_proxy = AnsibleJ2Vars(Templar(), {}, locals=vars)
    vars_proxy_keys = dict([(key, True) for key in vars_proxy])

    # Test case 1: check is all keys are iterated over exactly once
    assert len(vars_proxy_keys) == len(vars_proxy), "All keys should be iterated over!"

    # Test case 2: check if all keys are present in iterated over keys

# Generated at 2022-06-11 17:27:20.424320
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'test_one': 'ok'}, fail_on_undefined=False)
    globals = {'test_two': 'ok'}
    locals = {'test_three': 'ok'}
    j2vars = AnsibleJ2Vars(templar, dict(globals), dict(locals))
    assert j2vars.__getitem__('test_one') == 'ok'
    assert j2vars.__getitem__('test_two') == 'ok'
    assert j2vars.__getitem__('test_three') == 'ok'
    j2vars = AnsibleJ2Vars(templar, dict(globals))

# Generated at 2022-06-11 17:27:30.702739
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class TestAnsibleJ2Vars(unittest.TestCase):

        def setUp(self):
            self.templar = Templar(loader=None, variables=None)
            self.fake_vars = {'a': 1, 'b': 2}

        def test___contains__(self):
            '''
            Tests if method __contains__ returns true if a var is in the object
            '''

            j2vars = AnsibleJ2Vars(self.templar, globals=self.fake_vars, locals={'c': 3})

            self.assertIn('a', j2vars)

            self.assertIn('b', j2vars)

# Generated at 2022-06-11 17:27:41.448581
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # check __contains__ is working
    test_dict = {}
    test = AnsibleJ2Vars(templar, test_dict)
    assert 'this_is_not_in_variables' not in test

    # check __contains__ is working
    test_dict = {'this_is_a_dict_key': ''}
    test = AnsibleJ2Vars(templar, test_dict)
    assert 'this_is_a_dict_key' in test

# Generated at 2022-06-11 17:27:53.342657
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    def get_value(var, value):
        if var == 'vars':
            return value
        else:
            return var + '=' + to_native(value)

    from ansible.template.safe_eval import ansible_safe_eval

# Generated at 2022-06-11 17:27:59.911447
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    hostvars = {"ansible_host": "192.1.1.1"}
    templar = Templar(loader=None, variables=hostvars, shared_loader_obj=None)
    av_vars = AnsibleJ2Vars(templar, globals={"something": "else"})
    assert(av_vars.__getitem__("ansible_host") == "192.1.1.1")
    assert(av_vars["something"] == "else")

# Generated at 2022-06-11 17:28:10.651419
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()

    # Templating
    vm = VariableManager(loader=dataloader)
    vm.set_vars({"a": {"b": {"c": 123}}})
    assert AnsibleJ2Vars(vm.get_vars, globals={}).__getitem__("a") == {"b": {"c": 123}}
    assert AnsibleJ2Vars(vm.get_vars, globals={}).__getitem__("a.b.c") == 123
    assert AnsibleJ2Vars(vm.get_vars, globals={}).__getitem__("a.b") == {"c": 123}


# Generated at 2022-06-11 17:28:22.663030
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import random
    vars_len = random.randint(1, 100)
    globals_len = random.randint(1, 100)
    locals_len = random.randint(1, 100)
    vars = {'vars_{}'.format(i): i for i in range(vars_len)}
    globals = {'globals_{}'.format(i): i for i in range(globals_len)}
    locals = {'locals_{}'.format(i): i for i in range(locals_len)}
    class FakeTemplar(object):
        def __init__(self):
            self.available_variables = {'vars_{}'.format(i): i for i in range(vars_len)}
            self.template = lambda x: x

# Generated at 2022-06-11 17:28:32.117247
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import datastructure_proxy_safe_eval
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager

    test_data = {
        "k1": "v1",
        "k2": [1, 2, 3],
        "k3": {
            "k4": "v4",
            "k5": [1, 2, 3],
            "k6": {
                "k7": "v7"
            }
        }
    }

    # make sure the test data is templatable
    j2_vars = AnsibleJ2Vars(Templar({}, variable_manager=VariableManager()), test_data)
    _test_data = datastructure_proxy_

# Generated at 2022-06-11 17:28:42.068754
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    import ansible.constants as C
    import ansible.vars.unsafe_proxy as unsafe_proxy
    import sys

    vars_dict = dict()
    vars_dict['vars'] = dict()
    vars_dict['vars']['name'] = 'bar'
    j2_globals = dict()
    j2_globals = {
        'hostvars': unsafe_proxy.HostVars(dict()),
        'group_names': [],
        'groups': {},
    }

# Generated at 2022-06-11 17:29:06.473218
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars


# Generated at 2022-06-11 17:29:15.848872
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    import ansible.constants as C
    import sys

    templar = Templar(loader=None, variables={})
    sys.modules['__builtin__'].__dict__['config'] = C

    m = AnsibleJ2Vars(templar, {'config': C, 'omit': jinja2.utils.missing})
    assert 'omit' in m
    assert m['config'] == C
    assert m['omit'] == jinja2.utils.missing



# Generated at 2022-06-11 17:29:25.812043
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = {
        'a_global': 'a global',
    }
    locals = {
        'a_local': 'a local',
    }
    j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # test with a_local
    result = 'a_local' in j2_vars
    assert result

    # test with a_global
    result = 'a_global' in j2_vars
    assert result

    # test with not_exists
    result = 'not_exists' in j2_vars
    assert not result


# Generated at 2022-06-11 17:29:33.896449
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    class Test_AnsibleJ2Vars:
        def __init__(self):
            self.available_variables = {'avail_test1': 'test1_value', 'avail_test2': 'test2_value'}

    templar = Test_AnsibleJ2Vars()
    globals = {'glob_test1': 'test1_value', 'glob_test2': 'test2_value'}
    locals = {'loc_test1': 'test1_value', 'loc_test2': 'test2_value'}

    ajv = AnsibleJ2Vars(templar, globals, locals)

    # Test if all the keys set in templar, globals and locals are present
    # This will test the complete code present in method __contains__ of
    #

# Generated at 2022-06-11 17:29:35.691863
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass


# Generated at 2022-06-11 17:29:45.890427
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    import jinja2
    from ansible.template import Templar

    jvars = AnsibleJ2Vars(
        Templar(loader=jinja2.DictLoader({}), variables={}),
        globals={},
        locals={}
    )

    # test __contains__
    assert 'a' not in jvars
    assert 'b' not in jvars
    assert 'c' not in jvars
    jvars._templar.available_variables = {'a': 'A', 'b': 'B'}
    jvars._locals = {'b': 'B2'}
    jvars._globals = {'c': 'C'}
    assert 'a' in jvars
    assert 'b' in jvars
    assert 'c' in jvars



# Generated at 2022-06-11 17:29:57.211436
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import __main__
    import ansible.plugins.loader.globals
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.play_context
    import ansible.template.template
    import ansible.vars.hostvars
    import ansible.vars.vars_cache
    import ansible.vars.manager
    import ansible.vars.hostvars
    import ansible.vars.hostvars

    __main__.__builtins__ = {}

    my_globals = ansible.plugins.loader.globals.GlobalLoader().all()

    my_play_context = ansible.playbook.play_context.PlayContext()

# Generated at 2022-06-11 17:30:08.318426
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    x = AnsibleJ2Vars(Templar(), {'vars': 'test'})

    # test __getitem__ with variable in self._templar.available_variables
    # vars should be already in self._templar.available_variables
    assert x['vars'] == 'test'

    # test __getitem__ with variable not in self._templar.available_variables
    # but in self._locals
    assert x.add_locals({'locals': 'test'})['locals'] == 'test'

    # test __getitem__ with variable in self._globals
    assert x['vars'] == 'test'

    # test __getitem__ with variable not in self._templar.available_variables
    # not in self._loc

# Generated at 2022-06-11 17:30:20.016876
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class DummyTemplar():
        def __init__(self, data):
            self.data = data

        def template(self, data):
            return data

    data = {
        'a': '1',
        'b': '2',
        'c': '3'
    }

    templar = DummyTemplar(dict(data))

    vars = AnsibleJ2Vars(templar, {}, {'a': 'a', 'b': 'b'})

    assert(len(vars) == len(data))
    assert('a' in vars)
    assert('b' in vars)
    assert('c' in vars)
    assert('d' not in vars)

    assert(vars['a'] == '1')

# Generated at 2022-06-11 17:30:29.542681
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleUndefinedVariable, AnsibleError

    # try raising AnsibleUndefinedVariable exception for a variable not in vars
    templar = Templar(loader=None)
    globals = {}
    locals = {}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    try:
        ajv['A']
    except AnsibleUndefinedVariable:
        pass
    else:
        assert False

    # try raising AnsibleError exception when something goes wrong in __getitem__
    templar = Templar(loader=None)
    globals = {}
    locals = {}

# Generated at 2022-06-11 17:31:05.391704
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.unsafe_proxy import unsafe_proxy
    fake_globals = {'foo': 'bar', 'xyzzy': 'zork'}
    fake_locals = {'hidden': 'trap', 'spam': 'egg', 'l_hidden': 'trap'}
    fake_var_templar = {'l_visible': 'stone'}
    proxy = AnsibleJ2Vars(fake_var_templar, fake_globals, fake_locals)
    assert 'foo' not in proxy
    assert 'xyzzy' not in proxy
    assert 'spam' not in proxy
    assert 'l_visible' not in proxy
    assert 'hidden' in proxy
    assert 'l_hidden' not in proxy
    v = unsafe_proxy(proxy)
    assert 'foo' in v
   

# Generated at 2022-06-11 17:31:14.728054
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    class AnsibleJ2Vars:
        def __getitem__(self, varname):
    '''

    # init
    templar = Templar()
    globals = {}
    locals = {}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # Case #1: has local variable
    j2vars._locals['foo'] = 'bar'
    result = j2vars.__getitem__('foo')
    assert(result == 'bar')

    # Case #2: has global variable
    templar.available_variables['foo'] = 'bar'
    result = j2vars.__getitem__('foo')
    assert(result == 'bar')

    # Case #3: has global variable

# Generated at 2022-06-11 17:31:26.566665
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import AnsibleUnsafe
    from ansible.template.templar import Templar
    from ansible.template.vars import AnsibleVars

    templar = Templar(loader=None, variables=dict(key='value', dict=dict(key='value')))
    vars = AnsibleJ2Vars(templar=templar, globals={}, locals={'l_key': 'value', 'context': 'context'})

    assert vars['key'] == 'value'
    assert vars['l_key'] == 'value'
    assert vars['context'] == 'context'
    assert isinstance(vars['context'], AnsibleVars)
    assert vars['dict'] == 'value'
    assert isinstance(vars['dict'], AnsibleUnsafe)

# Generated at 2022-06-11 17:31:30.379477
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    values = {"a": "val1", "b": "val2"}
    ansible_vars = AnsibleJ2Vars(values, values)
    assert "a" in ansible_vars
    assert "b" in ansible_vars
    assert "c" not in ansible_vars


# Generated at 2022-06-11 17:31:41.437465
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    #
    # Test scenario with valid local vars
    #
    # Setup AnsibleJ2Vars object
    _templar = None
    _globals = dict()
    _locals = dict()
    _locals['foo'] = 'bar'

    j2vars = AnsibleJ2Vars(_templar, _globals, _locals)

    # Get item from AnsibleJ2Vars object
    assert j2vars['foo'] == 'bar'

    #
    # Test scenario with invalid local vars
    #
    # Setup AnsibleJ2Vars object without local vars
    _templar = None
    _globals = dict()
    _locals = dict()


# Generated at 2022-06-11 17:31:51.264382
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import jinja2

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    l = DataLoader()
    module_vars = {
        'version': '1.0',
        'foo': 'bar'
    }
    a = AnsibleJ2Vars(Templar(loader=l), module_vars)
    assert a['version'] == '1.0'
    assert a['foo'] == 'bar'
    del module_vars['foo']
    assert a['version'] == '1.0'
    assert a['foo'] == 'bar'
    assert a['hostvars'] == a['vars'] == module_vars
    module_vars['bindir'] = '/usr/bin'

# Generated at 2022-06-11 17:32:00.461073
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.playbook.play  # import must be here otherwise AnsibleJ2Vars class is not yet populated in memory
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText  # We need the class definition to be done here
    import test.units.loader as units_loader

    varname = 'var'
    file_data = units_loader.get_data_from_file('variables/ansible_vars')
    available_variables = units_loader.get_data_from_file('variables/available_variables')
    vault_password_file = units_loader.get_data_from_file('vault/passwordfile')

# Generated at 2022-06-11 17:32:10.393128
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {}

    t = AnsibleJ2Vars(templar, globals, locals=None)

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    h = HostVars(variable_manager=VariableManager())
    def test_getitem(k, v):
        h[k] = v
        assert t[k] == v

    test_getitem('foo', 'bar')
    test_getitem('baz', AnsibleVaultEncryptedUnicode('password', 'baz'))
    # FIXME
    #test_getitem('hostv

# Generated at 2022-06-11 17:32:15.036125
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Unit test name: Test creation of AnsibleJ2Vars class
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    AnsibleJ2Vars(variable_manager, dict())



# Generated at 2022-06-11 17:32:25.782020
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # ansible_facts is saved as dict, but it is not hostvar
    ansible_facts = '{"ansible_facts": {"f1": "some facts"}}'
    unsafe_eval(ansible_facts)
    varmanager = VariableManager()
    varmanager.extra_vars = dict()
    varmanager.extra_vars['ansible_facts'] = unsafe_eval(ansible_facts)
    templar = Templar(varmanager)

    # ansible_facts is hostvar
    hostvars = {}
    j2vars = AnsibleJ2Vars(templar, globals=[], locals=hostvars)

# Generated at 2022-06-11 17:33:04.936298
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars

    templar = Templar(loader=None, variables={})
    plain_string = 'foo'
    encrypted_string = AnsibleVaultEncryptedUnicode('foo')
    plain_string_proxy = AnsibleUnsafeText(plain_string)
    hostvars = HostVars({"foo": plain_string})

# Generated at 2022-06-11 17:33:08.447259
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    var = AnsibleJ2Vars(templar, {}, {})
    assert 'test' not in var


# Generated at 2022-06-11 17:33:17.536675
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # test 1

    templar = None
    globals = {"g1":1, "g2":2}
    locals = {"l1":1, "l2":2}

    ajv = AnsibleJ2Vars(templar, globals, locals)

    assert "g1" in ajv
    assert "g2" in ajv
    assert "l1" in ajv
    assert "l2" in ajv
    assert "g1_" not in ajv
    assert "g2_" not in ajv
    assert "l1_" not in ajv
    assert "l2_" not in ajv

    # test 2

    templar = None
    globals = {}
    locals = {"l1":1, "l2":2}

    a

# Generated at 2022-06-11 17:33:26.659063
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-11 17:33:31.570183
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Test with empty AnsibleJ2Vars
    vars = AnsibleJ2Vars(templar=None, globals={}, locals={})
    assert iter(vars) == iter(set())

    # Test with populated AnsibleJ2Vars
    vars = AnsibleJ2Vars(templar=None, globals={},
                         locals={'a': '1', 'b': '2', 'c': '3'})
    assert set(iter(vars)) == {'a', 'b', 'c'}

# Generated at 2022-06-11 17:33:42.128567
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.vars.hostvars
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    test_hostvars = ansible.vars.hostvars.HostVars(hostname='test_hostname', vars=dict())
    test_hostvars.__UNSAFE__ = True
    test_hostvars.a = 'a'
    test_hostvars.b = 'b'
    test_dict = dict()
    test_dict['a'] = 'c'
    test_dict['b'] = 'd'
    test_dict['c'] = 'e'
    test_dict['d'] = 'f'
    test_available_variables = dict()


# Generated at 2022-06-11 17:33:53.332275
# Unit test for method __contains__ of class AnsibleJ2Vars

# Generated at 2022-06-11 17:34:00.083868
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils.six import text_type
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    templar = Templar(loader=None, variables=dict(foo='bar'))
    j2_vars = AnsibleJ2Vars(templar, globals=dict(g='g'), locals=dict(l='l'))

    # Test variables in __getitem__
    assert j2_vars['vars'] == {}
    assert j2_vars['foo'] == 'bar'
    assert j2_vars['l_'] == {}
    assert j2_vars['l'] == 'l'
    assert j2_vars['g'] == 'g'