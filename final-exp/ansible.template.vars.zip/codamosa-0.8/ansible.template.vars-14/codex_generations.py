

# Generated at 2022-06-11 17:24:10.876422
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    from ansible.template import Templar, template
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    vars = {u'alpha': AnsibleUnsafeText(u'alpha'), u'beta': 1, u'gamma': 2}
    tmp = Templar(loader=None, variables=vars)
    j2vars = AnsibleJ2Vars(tmp, {}, vars)

    results = j2vars.__len__()
    assert results == 0, 'expected 0, but got {result}'.format(result=to_text(results))

# Generated at 2022-06-11 17:24:21.592142
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible import context

    template_vars = dict(variable1='value1', variable2='value2', vars='value3')
    templar = Templar(loader=DataLoader(), variables=VariableManager(),
                      shared_loader_obj=None, disable_lookups=True,
                      jinja2_native=True)
    templar.set_available_variables(template_vars)

    globals = dict(global_variable1='global_value1', global_variable2='global_value2')
    locals = dict(local_variable1='local_value1', local_variable2='local_value2')
    var_obj = AnsibleJ2Vars

# Generated at 2022-06-11 17:24:22.647037
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
  # REPLACE pass below with unit tests
  pass

# Generated at 2022-06-11 17:24:35.539582
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from jinja2.utils import missing
    templar = {}

# Generated at 2022-06-11 17:24:39.490112
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

  (templar, globals, locals) = (None, None, None)
  AnsibleJ2Vars(templar, globals, locals)



# Generated at 2022-06-11 17:24:50.057908
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import jinja2

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.template import Templar

    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars

    from units.mock.vault_mock import create_file_vault_secret
    from ansible.utils.path import unfrackpath

    # set up a vault secret for testing
    create_file_vault_secret("/tmp/test_vault_file_enc", "testuser", "testpass")

    vault_secret = unfrackpath("/tmp/test_vault_file_enc")

# Generated at 2022-06-11 17:25:00.035876
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """
    Test case for __getitem__ of class AnsibleJ2Vars
    """

    from ansible.template import Templar
    templar = Templar(loader=None)
    proxy = AnsibleJ2Vars(templar, {}, locals={})

    # Test cases for when the varname exists
    assert proxy['vars'] == {}, "vars not empty"
    assert proxy['l_local'] == 'local'

    # Test cases for when the varname doesn't exist
    try:
        proxy['var']
    except KeyError:
        assert True, "KeyError raised: var not found"

    try:
        proxy['local']
    except KeyError:
        assert True, "KeyError raised: local not found"


# Generated at 2022-06-11 17:25:10.350917
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)

    globals = {
        'g_foo': 'foo',
    }

    locals = {
        'l_bar': 'bar',
    }

    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'bar' in vars
    assert 'g_foo' in vars
    assert 'l_bar' in vars
    assert 'baz' not in vars

    # Templates are pre-processed so the keys are not available.
    # Try to access processed key with the template
    templar.available_variables = {
        'foo': 'bar',
    }
    assert 'foo' in vars


# Generated at 2022-06-11 17:25:10.865409
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass

# Generated at 2022-06-11 17:25:21.726072
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    variable_manager, loader = mock_variable_manager_loader()
    templar = Templar(loader=loader, variables=variable_manager)

    ansible_vars = dict(a='b', b=2, c=['x','y','z'])
    ansible_globals = dict(d='e', f=3, g=['p','q','r'])
    ansible_locals = dict(h='i')

    ansible_vars_proxy = AnsibleJ2Vars(templar, ansible_globals, locals=ansible_locals)

    # ensure that keys of ansible_vars and ansible_locals are contained in ansible_vars_proxy
    for key in ansible_vars.keys():
        assert key in ansible_vars_proxy

# Generated at 2022-06-11 17:25:35.547555
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import yaml
    from ansible import constants as C
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    def run_getitem(variable, result=None, expect_fail=False):
        my_var = dict(foo='bar')
        my_vars = {'myvar': my_var}
        variable_manager = VariableManager()
        variable_manager._extra_vars = my_vars
        loader = yaml.SafeLoader
        loader.add_constructor('!include', load_include)
        loader.add_constructor('!include_vars', load_include_vars)

# Generated at 2022-06-11 17:25:47.698968
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    def __contains__(*args, **kwargs):
        return super(AnsibleJ2Vars, AnsibleJ2Vars(templar, *args, **kwargs)).__contains__(*args, **kwargs)

    # 1. Test __contains__ when the variable is not defined in any scope
    assert not __contains__({}, "var1")

    # 2. Test __contains__ when the variable is defined in templar
    templar.available_variables = {"var1": "foo1"}
    assert __contains__({}, "var1")

    # 3. Test __contains__ when the variable is defined in globals
    templar.available_variables = {}

# Generated at 2022-06-11 17:25:55.119757
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template.template import Templar
    test_AnsibleJ2Vars = AnsibleJ2Vars(templar=Templar(loader=None), globals=safe_eval.__globals__, locals={})
    assert('im_class' in test_AnsibleJ2Vars)
    assert('foo' not in test_AnsibleJ2Vars)


# Generated at 2022-06-11 17:26:03.737987
# Unit test for method __contains__ of class AnsibleJ2Vars

# Generated at 2022-06-11 17:26:12.248943
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ..template import Templar
    from six import PY2, string_types
    from ansible.vars.unsafe_proxy import wrap_var

    data = '{{ ansible_python_version }}'
    if PY2:
        data = unicode(data)

    if not isinstance(data, string_types):
        raise AssertionError("data not a string")

    templar = Templar(loader=None)

    # FIXME: should these be None?
    j2vars = AnsibleJ2Vars(templar, globals=None, locals=None)

    assert(data not in j2vars)

    try:
        value = j2vars[data]
    except KeyError:
        pass

# Generated at 2022-06-11 17:26:21.782801
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Setup of scenario "AnsibleJ2Vars contains available but undefined var"
    templar = object()
    globals = {"k1" : "v1"}
    locals =  {"k2" : "v2"}
    class fake_variable(dict):
        pass
    templar.available_variables = {"k3" : fake_variable()}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    result = ("k3" in ajv)    
    # Tests
    assert result == True
    # Teardown
    del result
    del ajv
    del templar


# Generated at 2022-06-11 17:26:30.842127
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    m_templar1 = MagicMock()
    m_templar1.available_variables = {}
    m_templar1.template.return_value = 'QQQ'
    m_globals1 = {}
    m_locals1 = {'A':'a', 'B':'b', 'C':'c'}
    j2vars1 = AnsibleJ2Vars(m_templar1, m_globals1, locals=m_locals1)
    assert j2vars1.__getitem__('A') == 'a'
    assert j2vars1.__getitem__('C') == 'c'
    m_templar1.template.assert_not_called()

    m_templar2 = MagicMock()
    m_templar

# Generated at 2022-06-11 17:26:39.581147
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    from ansible.template import Templar

    proxy = AnsibleJ2Vars(None, dict(a=1, b=2, c=3))
    assert len(proxy) == 3

    proxy = AnsibleJ2Vars(Templar(), dict(a=1, b=2, c=3))
    assert len(proxy) == 3

    proxy = AnsibleJ2Vars(Templar(), dict(a=1, b=2, c=3), locals=dict(d=4, e=5, f=6))
    assert len(proxy) == 6



# Generated at 2022-06-11 17:26:46.120987
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    return
#    '''
#    Unit test for method __getitem__ of class AnsibleJ2Vars
#    '''
#    print("test_AnsibleJ2Vars___getitem__()")
#    ajv = AnsibleJ2Vars()
#    item = ajv[varname]
#    print("item:", item)
#    return



# Generated at 2022-06-11 17:26:56.114244
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    #
    # Setup
    #
    # Create a simple dictionary with items in it.
    # Create a Templar object with the dictionary.
    #  Create an AnsibleJ2Vars object using that Templar object and the
    #  dictionary.
    #
    simple_dict = {'one': 1, 'two': 2, 'three': 3}
    templar    = Templar(simple_dict)
    j2vars     = AnsibleJ2Vars(templar, locals=simple_dict)

    #
    # Synthesis
    #
    # Assert that AnsibleJ2Vars.__contains__(item) == True if and only if
    # item is in the dictionary
    for item in simple_dict.keys():
        assert j2vars.__contains__(item)

# Generated at 2022-06-11 17:27:10.871306
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = {"name":"Alice","age":24,"true":True}
    locals = {"name":"Bob"}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(["name"]) == set(j2vars.__iter__())
    locals = {"name":"Carl","age":27,"false":False}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(["name","age","false"]) == set(j2vars.__iter__())
    locals = {"name":"David","age":37,"true":True}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-11 17:27:18.146612
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo':'bar'}
    locals = {'bar':'foo'}

    j2vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert len(j2vars) == 2

    # locals overwrite globals, so it counts as 1
    j2vars = AnsibleJ2Vars(templar, globals, locals={'foo':'baz'})
    assert len(j2vars) == 1



# Generated at 2022-06-11 17:27:28.880225
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars
    templar = Templar(loader=None)
    globals = {
        'foo' : 'bar',
        'dictionary' : {'a' : 1, 'b' : 2, 'c' : 3},
        'list' : [1,2,3],
        'unsafe' : '{{ not a real template }}',
    }
    locals = {
        'dictionary' : {'a' : 1, 'b' : 2, 'c' : 3},
        'list' : [1,2,3],
    }
    vars = AnsibleJ2Vars(templar, globals, locals)
   

# Generated at 2022-06-11 17:27:35.545888
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    v = AnsibleJ2Vars(Templar(), dict(one=1, two=2, three=3, four=4, five=5))

    assert v['one'] == 1
    assert v['three'] == 3

    for k in ['one', 'two', 'three', 'four', 'five']:
        try:
            v[k]
        except KeyError:
            print("Unit test failed!")
            return -1

    return 0

# Generated at 2022-06-11 17:27:45.240068
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class Templar(object):
        '''
        Templar mock
        '''
        def __init__(self, template_result):
            self.template_result = template_result
            self.available_variables = {'test': '{{test}}'}

        def template(self, variable):
            '''
            template mock
            '''
            return self.template_result

    class HostVars(object):
        '''
        HostVars mock
        '''
        pass

    # __getitem__ should return variable content,
    # without templating
    templar = Templar(template_result='foo')
    globals = {'bar': 'bar'}
    locals = None
    vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-11 17:27:50.390043
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    from ansible.template import Templar

    templar = Templar(loader=None)

    j2_vars = AnsibleJ2Vars(
        templar=templar,
        globals={}
    )

    assert len(j2_vars) == len(j2_vars._templar.available_variables)

# Generated at 2022-06-11 17:27:58.339595
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.inventory.host import Host

    templar = Templar(None, loader=None)
    hostvars = HostVars(None, Host('localhost'))
    hostvars.vars['bar'] = 'foo'
    hostvars.set_variable('baz', 'foo')
    templar.available_variables = {'bar': 'foo', 'baz': 'foo', 'hostvars': hostvars}

    # FIXME is this the intended behaviour of AnsibleJ2Vars?
    ansible_j2_vars = AnsibleJ2Vars(templar, globals=None)
    assert ansible_j2

# Generated at 2022-06-11 17:28:09.718797
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from jinja2.utils import missing

    assert len(AnsibleJ2Vars(templar=object(), globals={}, locals={})) == 0
    assert len(AnsibleJ2Vars(templar=object(), globals={}, locals={'l_x': missing})) == 0
    assert len(AnsibleJ2Vars(templar=object(), globals={'g_x': missing}, locals={})) == 1
    assert len(AnsibleJ2Vars(templar=object(), globals={'g_x': missing}, locals={'l_x': missing})) == 1
    assert len(AnsibleJ2Vars(templar=object(), globals={'g_x': missing, 'g_y': missing}, locals={'l_x': missing})) == 2

# Generated at 2022-06-11 17:28:20.484231
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    import pytest

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ajv = AnsibleJ2Vars(templar, globals, locals)

    # Test with invalid variable name
    with pytest.raises(KeyError) as exec_info:
        ajv['__invalid__']
    assert 'undefined variable' in str(exec_info.value)

    # Test with invalid variable type and valid variable name
    with pytest.raises(KeyError) as exec_info:
        ajv['template']
    assert 'undefined variable' in str(exec_info.value)

# Generated at 2022-06-11 17:28:29.499980
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from argument_parser import AnsibleParser
    from ansible import errors
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.vars.manager import DataLoader

    options = AnsibleParser(
        ['-i', '/etc/ansible/hosts'],
        usage='Ansible ad-hoc',
        inventory='/etc/ansible/hosts'
    ).parse_args()

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])

    play_context = Play

# Generated at 2022-06-11 17:28:42.475048
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
  from ansible.vars.hostvars import HostVars
  from ansible.template.safe_eval import safe_eval
  from ansible.template.text import Templar # Templar() object
  from ansible.template.vars import AnsibleJ2Vars # AnsibleJ2Vars() object
  from ansible.template.vars import AnsibleVars # AnsibleVars() object
  from ansible.vars.manager import VariableManager # VariableManager() object
  from ansible.vars.unsafe_proxy import AnsibleUnsafeText # AnsibleUnsafeText() object
  from ansible.vars.unsafe_proxy import wrap_var # wrap_var() function
  from ansible.plugins import vars_cache

  variable = None
  variable_manager = VariableManager()
  variable_manager._fact_cache = vars

# Generated at 2022-06-11 17:28:53.571463
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os
    os.environ['ANSIBLE_LIBRARY'] = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', '..', 'lib')

    from ansible.plugins import module_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    context = PlayContext()
    context.vars = {"test_var": "this_is_a_test_value"}
    context.remote_addr = "localhost"

    variables = VariableManager(loader=module_loader, inventory=None)
    templar = Templar(loader=module_loader, variables=variables)

    globals

# Generated at 2022-06-11 17:29:01.408581
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.template
    templar = ansible.template.Templar(loader=None)
    globals = dict()
    locals = dict(foo='bar')
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['vars']['foo'] == 'bar'

    try:
        vars['non_existent']
        assert False, "Should have raised KeyError for non_existent key"
    except KeyError:
        pass

# Generated at 2022-06-11 17:29:06.552193
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = object()
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert len(vars) == 4


# Generated at 2022-06-11 17:29:18.492593
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # For convenient debugging
    # python -m pytest -s tests/unit/vars/test_variable_manager.py -k test_AnsibleJ2Vars___contains__
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    a = AnsibleJ2Vars({'foo': 'bar'}, locals={'l_foo': 'gugus'})
    assert 'foo' in a
    assert 'gugus' not in a
    assert 'l_foo' in a
    a2 = AnsibleJ2Vars(a, {'foo': 'bar'}, locals={'l_foo': 'gugus'})
    assert 'foo' in a
    assert 'gugus' not in a
    assert 'l_foo' in a
    assert 'foo' in a2

# Generated at 2022-06-11 17:29:28.930895
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)

    # class-dict(available_variables)
    available_variables = {'varname1': 'variable1', 'varname2': 'variable2'}
    # class-dict(globals)
    globals = {'globalvar1': 'globalvar1', 'globalvar2': 'globalvar2'}
    # class-dict(locals)
    locals = {'localvar1': 'localvar1', 'localvar2': 'localvar2'}
    # class-obj(AnsibleJ2Vars)
    ansiblej2vars = AnsibleJ2Vars(templar, globals, locals)

    # not in class-dict(available_variables), not in class-dict(globals),

# Generated at 2022-06-11 17:29:33.258136
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    templar = Templar()
    globals = { 'g1': 1, 'g2': 2 }
    locals = { 'l1': 1, 'l2': 2 }
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert(sorted(ajv.__iter__()) == ['g1', 'g2', 'l1', 'l2'])



# Generated at 2022-06-11 17:29:44.798872
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar:
        pass
    templar = Templar()
    templar.template_result=None
    templar.template=lambda x: x
    templar.new_undefined=AnsibleUndefinedVariable
    templar.available_variables={"testkey": "testvalue"}
    globals = {"globalvalue": "globalvalue"}
    locals = {"localkey": "localvalue"}
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    test_dict = {
        "testkey": "testvalue",
        "localkey": "localvalue",
        "globalvalue": "globalvalue",
        "dict": {"foo": "bar"},
    }
    for key,value in ansible_j2vars.items():
        assert test

# Generated at 2022-06-11 17:29:56.205996
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    p = PlayContext()
    p.hostvars['host1'] = { "example" : "value" }

    inv = InventoryManager(loader=DataLoader(), sources="localhost,")
    v = VariableManager(loader=DataLoader(), inventory=inv)

    v.set_fact(key="example", value="value2")

    t = Templar(vars=v, loader=DataLoader())

    result = AnsibleJ2Vars(t, p._variables)
    assert "example" in result
    assert "example2" not in result

    assert result

# Generated at 2022-06-11 17:30:07.707872
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    variables = dict(
        one_var='one_value',
        two_var={'three_var': 'three_value'},
        four_var='{{ two_var.three_var }}',
        five_var='{{ five_var }}',
        six_var={'seven_var': '{{ five_var }}'},
    )
    hostvars = HostVars(loader=DataLoader(), variables=variables)
    templar = Templar(variables=variables, loader=DataLoader())

    play_context = PlayContext()
    ansible_variables = AnsibleJ2

# Generated at 2022-06-11 17:30:23.441465
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """
    Test AnsibleJ2Vars class
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    my_vars = dict(my_var1='foo', my_var2='2')
    my_host = 'host01'

    loader = DataLoader()
    templar = Templar(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=None)
    variable_manager.set_host_variable(my_host, my_vars)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
   

# Generated at 2022-06-11 17:30:30.401915
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert AnsibleJ2Vars(None, {
        'a': 1,
        'b': 2,
        'c': 3,
    }).__len__() == 3
    assert AnsibleJ2Vars(None, {}, {
        'a': 1,
        'b': 2,
        'c': 3,
    }).__len__() == 3
    assert AnsibleJ2Vars(None, {
        'a': 1,
        'b': 2,
        'c': 3,
    }, {
        'd': 4,
        'e': 5,
        'f': 6,
    }).__len__() == 6

# Generated at 2022-06-11 17:30:41.435900
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from jinja2.utils import undefined
    from ansible.vars.hostvars import HostVars
    class Templar:
        def __init__(self, available_variables):
            self.available_variables = available_variables
        def template(self, variable):
            return variable
    globals = {
        'global_var1': 'global value one',
        'global_var2': 'global value two',
    }
    locals = {
        'local_var1': 'local value one',
        'local_var2': 'local value two',
    }
    templar = Templar({
        'available_var1': 'available value one',
        'available_var2': 'available value two',
    })

# Generated at 2022-06-11 17:30:53.600913
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Jinja2Environment

    class DummyAnsibleJ2Vars(AnsibleJ2Vars):
        pass

    # Initialize variables
    variable_manager = VariableManager()
    loader = variable_manager.loader = DictDataLoader({})
    variable_manager.extra_vars = {'foo': 'foo_value'}
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, context=play_context)
    env = Jinja2Environment(templar, undefined=StrictUndefined)

    # Init class AnsibleJ2Vars
    vars_class = DummyAnsibleJ

# Generated at 2022-06-11 17:31:04.625322
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import sys
    import os
    import pytest
    import __builtin__ as builtins
    import ansible.vars.hostvars
    import ansible.vars.vars
    ansible_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    path_backup = sys.path
    sys.path.append(ansible_path)

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import vars

    sys.path = path_backup

    # case 1:
    # test the case where varname is in self._locals
    # In this case, value should be return directly
    templar = Templar()
    class_

# Generated at 2022-06-11 17:31:14.308579
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template.template import Templar
    from ansible.vars.hostvars import HostVars

    host_vars = HostVars({"hv1": "hval1", "hv2": {"hv21": "hvval21", "hv22": "hvval22"}})
    host_vars.__UNSAFE__ = True
    templar = Templar(loader=None, variables={'v1': 'val1', 'v2': {'v21': 'vval21', 'v22': 'vval22'}}, shared_loader_obj=[],
                      play_context=PlayContext())
    templar.set_available_variables

# Generated at 2022-06-11 17:31:26.045370
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import collections
    ansible_j2vars = AnsibleJ2Vars()
    ansible_j2vars._globals = {'glo_key1': 'glo_val1', 'glo_key2': 'glo_val2'}
    ansible_j2vars._locals = {'loc_key1': 'loc_val1', 'loc_key2': 'loc_val2'}
    ansible_j2vars._templar = {'avail_key1': 'avail_val1', 'avail_key2': 'avail_val2'}
    # Test items

# Generated at 2022-06-11 17:31:36.689799
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Init jinja2 Templor object
    templar = 'TEMPLAR OBJECT'

    # Init jinja2 globals
    globals = dict()
    globals['globals_key1'] = 'globals_val1'
    globals['globals_key2'] = 'globals_val2'

    # Init jinja2 locals
    locals = dict()
    locals['locals_key1'] = 'locals_val1'
    locals['l_locals_key2'] = 'l_locals_val2'

    # Create AnsibleJ2Vars object
    ansible_j2_vars_object = AnsibleJ2Vars(templar, globals, locals)

    # Check locals key
    assert 'locals_key1' in ansible_j

# Generated at 2022-06-11 17:31:40.202708
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import doctest
    results = doctest.testmod()
    if results.failed == 0:
        print("Success: %d tests passed." % results.attempted)
    else:
        sys.exit(1)

# Generated at 2022-06-11 17:31:47.327979
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os
    import sys
    import json
    import unittest

    from ansible import constants as C
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import lookup_loader, filter_loader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    from ansible.utils.unicode import to_unicode
    from ansible.utils.vars import merge_hash
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types, integer_types
    from ansible.vars.hostvars import HostVars


# Generated at 2022-06-11 17:32:01.601311
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    context = PlayContext()
    context._vars = {'a': 'a', 'b': 'b'}
    templar = Templar(loader=None, variables=context.get_vars(), fail_on_undefined=True)
    vars_proxy = AnsibleJ2Vars(templar, context.get_globals(), locals=context.get_locals())

    # Test proxy
    assert 'a' in vars_proxy
    assert 'b' in vars_proxy
    assert vars_proxy['a'] == 'a'
    assert vars_proxy['b'] == 'b'

    # Test fail
    try:
        vars_proxy['c']
    except KeyError:
        pass


# Generated at 2022-06-11 17:32:11.453826
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import os

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var

    templar = Templar(
        loader=None,
        variables={},
    )

    def test_cases(test_name, var_name, var_value, result):

        locals = {
            "var_name": var_name,
            "var_value": var_value,
        }

        if result is False:
            try:
                j2vars = AnsibleJ2Vars(templar, globals={}, locals=locals)
                j2vars[var_name]
            except KeyError:
                pass
            else:
                raise AssertionError("Test failed(%s): %s" % (test_name, locals))
        else:
            j2vars

# Generated at 2022-06-11 17:32:22.702608
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    j2_vars = AnsibleJ2Vars(Templar(), dict(), dict(l_value_of_a=None))
    # should not raise error
    assert (not ('a' in j2_vars))
    assert ('value_of_a' in j2_vars)
    assert ('value_of_a' in j2_vars)
    assert (not ('value_of_b' in j2_vars))
    assert (not ('b' in j2_vars))
    assert (not ('c' in j2_vars))
    assert ('globals_a' in j2_vars)
    assert ('globals_b' in j2_vars)

# Generated at 2022-06-11 17:32:30.733805
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None, variables=None)
    variables = VariableManager()
    variables.extra_vars = {'some_var': 'foobar'}

    j2vars = AnsibleJ2Vars(templar, dict(), {'l_some_var': 'foobar'})
    assert ('some_var' in j2vars) == True, "some_var should be in j2vars"
    assert ('some_other_var' in j2vars) == False, "some_other_var should not be in j2vars"

# Generated at 2022-06-11 17:32:37.522319
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    def mocked_template(data):
        return data

    class Templar():
        def __init__(self):
            self.available_variables = {}

        template = mocked_template

    templar = Templar()

    locals={}

    globals={
        'key1': 'global value 1',
        'key2': 'global value 2',
        'key3': 'global value 3',
    }

    # wrong input, should raise error
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    try:
        j2vars['wrong_key']
    except KeyError as e:
        assert str(e) == 'undefined variable: wrong_key'

    # only local available, no problem
    locals['key5'] = 'local value 5'

# Generated at 2022-06-11 17:32:46.345776
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(variables=dict(), loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert issubclass(ansible_j2_vars.__getitem__("foo").__class__, HostVars)
    assert ansible_j2_vars.__getitem__("foo").__class__.__name__ == "HostVars"

# Generated at 2022-06-11 17:32:54.279122
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Create a jinja2 instance
    import jinja2
    j2env = jinja2.Environment()

    # Create a templar instance
    import ansible.utils
    templar = ansible.utils.template.Templar(loader=None, variables=None)

    # Create variables
    globals = {}
    locals = {'l_test_var': 'l_value'}

    # Create a new AnsibleJ2Vars instance
    ajv = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)

    # Get a local variable
    value = ajv['l_test_var']

    # Result check
    assert value == 'l_value'


# Generated at 2022-06-11 17:33:01.394794
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import ansible.module_utils.common.collections
    vars = ansible.module_utils.common.collections.AnsibleJ2Vars(None, None, None)

    assert vars['a'] == 0, "Value of vars['a'] should be 0 but got {}".format(vars['a'])
    assert vars['b'] == 0, "Value of vars['b'] should be 0 but got {}".format(vars['b'])


# Generated at 2022-06-11 17:33:10.660943
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test for correct behaviour of method __contains__
    # GIVEN
    templar = Templar(loader=DataLoader())
    var_k = "variable_not_to_be_template"
    var_v = "value_of_variable_not_to_be_template"
    av = dict({var_k: var_v})
    j2vars = AnsibleJ2Vars(templar, av)
    # WHEN
    is_in = (var_k in j2vars)
    # THEN
    assert is_in, "AnsibleJ2Vars should contain key %s" % var_k


# Generated at 2022-06-11 17:33:20.797032
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """ AnsibleJ2Vars: test for method __iter__ """
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template.templar import Templar
    from ansible.template.template import ansible_hosts_vars
    from ansible.utils.context_objects import AnsibleContext
    from ansible.utils.display import Display

    L = {
        "a": 1,
        "b": 2,
        "c": 3
    }

    G = {
        "d": 1,
        "e": 2,
        "f": 3
    }

    display = Display()

# Generated at 2022-06-11 17:33:41.036230
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class Templar():
        def __init__(self):
            self.available_variables = dict()
        def template(self, value):
            return value
    templar = Templar()
    globals = dict()
    globals['item1'] = 'value1'
    globals['item2'] = 'value2'
    globals['item3'] = 'value3'
    ansible_j2_vars = AnsibleJ2Vars(templar, globals)
    assert(len(ansible_j2_vars) == 3)

# Generated at 2022-06-11 17:33:52.396477
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    # These variables are not the same as used in templates but are only used to test __len__
    new_vars = {
        'var1': True,
        'var2': 123,
        'var3': 'abc'
    }
    j2_new_vars_templated = AnsibleJ2Vars(templar, new_vars)
    assert len(j2_new_vars_templated) == 3

    # These variables are not the same as used in templates but are only used to test __

# Generated at 2022-06-11 17:33:59.729369
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)
    globals = {'ansible_version': '2.1.1.0'}
    locals = {'test_var_1': 'foo', 'test_var_2': 'bar'}

    ansiblej2vars = AnsibleJ2Vars(templar, globals, locals)

    # Test with existing local non-empty variable
    varname = 'test_var_1'
    expected_value = 'foo'
    assert ansiblej2vars[varname] == expected_value

    # Test with existing local empty variable
    varname = 'test_var_2'
    expected_value = 'bar'