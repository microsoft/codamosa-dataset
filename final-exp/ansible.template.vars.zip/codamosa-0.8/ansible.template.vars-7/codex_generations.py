

# Generated at 2022-06-11 17:24:14.343661
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import sys
    from io import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.errors import AnsibleError

    def test_AnsibleJ2Vars_1():
        """
        Test AnsibleJ2Vars with default vars.

        """
        # Setup
        sys.stdin.close()
        sys.stdin = StringIO()

        # Test
        templar = Templar(loader=None, variables=VariableManager(), vault_secrets=VaultLib())
        globals = dict()

        vars_j2 = AnsibleJ2Vars(templar, globals, locals=dict())
        vars_j2

# Generated at 2022-06-11 17:24:15.632268
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass


# Generated at 2022-06-11 17:24:25.417305
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    h = Host()
    t = Task()
    p = PlayContext(become_method='sudo')
    tqm = None
    templar = Templar(loader=None, variables={}, shared_loader_obj=None, tqm=tqm)

    v_templar = AnsibleJ2Vars(templar, globals={'foo': 'bar'})

    assert 'foo' in v_templar
    assert 'inventory_hostname' in v_templar

    # test that a value from locals is also returned as in __getitem__
    # using the same logic of __contains__
    v

# Generated at 2022-06-11 17:24:37.326859
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Set up the objects to proxy
    templar = Templar(loader=None, variables={'a': 'x', 'b': 'y', 'c': 'z'})
    globals = {'a': 'x', 'b': 'y', 'c': 'z'}
    locals = {'a': 'x', 'b': 'y', 'c': 'z'}
    # Create the proxy
    j2vars = AnsibleJ2Vars(templar, globals, locals=locals)

    # Test the proxy
    assert j2vars['a'] == 'x'
    assert j2vars['b'] == 'y'
    assert j2vars['c'] == 'z'

# Generated at 2022-06-11 17:24:48.051402
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    vars = AnsibleJ2Vars(templar, {'g1': 'G1'}, {'l1': 'L1'})

    # vars is a container
    assert('g1' in vars)
    assert('l1' in vars)

    # vars can be iterated
    keys = set(iter(vars))
    assert(keys == {'l1', 'g1'})
    assert(len(iter(vars)) == 2)

    # iter(vars) returns an iterator
    it = iter(vars)
    assert(next(it) == 'l1')
    assert(next(it) == 'g1')


# Generated at 2022-06-11 17:24:53.389914
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = object()
    globals = {"key0": "value0", "key1": "value1"}
    locals = {"key2": "value2"}

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert sorted(list(vars.__iter__())) == sorted(["key0", "key1", "key2"])

# Generated at 2022-06-11 17:25:01.914423
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # Test initializing the object with valid data
    try:
        templar = None
        globals = None
        locals = None
        ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
        assert False, "Should have raised an exception"
    except:
        assert True

    templar = "Invalid Templar"
    try:
        ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
        assert False, "Should have raised an exception"
    except:
        assert True

    # Test initializing the object with locals and globals set

# Generated at 2022-06-11 17:25:11.944064
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    import ansible.vars.hostvars

    globals={'some_global_key':'some_global_value'}

    templar = ansible.vars.hostvars.HostVars()
    vars = AnsibleJ2Vars(templar, globals)
    try:
        var = vars[some_local_key]
        assert False, 'AnsibleJ2Vars does not raise KeyError for undefined variables'
    except KeyError as e:
        assert isinstance(e,KeyError), 'KeyError expected for undefined variables'

    locals = {'some_local_key':'some_local_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-11 17:25:22.304429
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.hostvars import HostVars

    my_dict = dict(foo="bar")
    my_str = "foo"

    templar = Templar(loader=DictDataLoader({}))
    AnsibleJ2Vars(templar, globals=None)

    # Assert that __getitem__ raise KeyError with unknown key
    with pytest.raises(KeyError):
        AnsibleJ2Vars.__getitem__(my_dict, "bar")

    # Assert that __getitem__ return value associated with key 'foo'
    assert AnsibleJ2Vars.__getitem__(my_dict, "foo") == "bar"

    # Assert that __getitem__ works with dict
    assert AnsibleJ2

# Generated at 2022-06-11 17:25:33.695497
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    This is a unit test for the AnsibleJ2Vars __iter__ method
    '''

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import MagicMock

    class TestAnsibleJ2Vars(unittest.TestCase):
        '''
        Test the methods of class AnsibleJ2Vars
        '''
        def setUp(self):
            '''
            Setup test environment
            '''
            self.mock_templar = MagicMock()
            self.mock_globals = {'a': 'A', 'b': 'B', 'c': 'C'}
            self.mock_locals = {'d': 'D', 'e': 'E', 'f': 'F'}
            self.m

# Generated at 2022-06-11 17:25:48.670390
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template.templar import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    t = Templar(loader=None, variables=dict())
    g = dict()
    g['hello'] = 'world'
    v = AnsibleUnsafeText('foo')
    test_vars = AnsibleJ2Vars(t, g, locals=dict(l_vars=dict(test_key=v)))

    assert g == test_vars.get_globals()
    assert t == test_vars.get_templar()
    assert isinstance(test_vars.get_locals()['vars'], HostVars)

# Generated at 2022-06-11 17:25:59.747126
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
  class Templar:
    def __init__(self):
      self.available_variables = { "a": "avalue" }

  normal_vars = { "b": "bvalue", "c": "cvalue", "a": "avaluenew" }
  globals = { "d": "dvalue", "e": "evalue", "f": "fvalue" }
  locals = { "a": "avalueagain", "c": "cvaluenew", "g": "gvalue", "h": "hvalue" }
  templar = Templar()
  j2vars = AnsibleJ2Vars(templar, globals, locals)

  # Check that variables were correctly added
  # Expected: set(["h", "a", "b", "d", "e", "f", "g", "

# Generated at 2022-06-11 17:26:08.870772
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    vars = AnsibleJ2Vars(templar, {})

    # HostVars is special, return it as-is
    v, vars = [HostVars("test")], AnsibleJ2Vars(templar, {})
    #vars = AnsibleJ2Vars(templar, {})
    assert vars["v"] == v[0]
    #assert vars._globals == {}
    #assert vars._locals == {'v': v[0]}
    #assert vars._templar == templar
    #assert vars.v == v[0]
    var_name = "test"
    var_name

# Generated at 2022-06-11 17:26:20.600939
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    mock_vals = {
        'one': "value_one",
        'two': 2,
        'three': [ 3, 3, 3 ],
        'four': { 'five': "5", 'six': 6 },
        'seven': AnsibleUnicode("seven")
    }
    templar = Templar()
    v = AnsibleJ2Vars(templar, mock_vals)

    assert(v['one'] == "value_one")
    assert(v['two'] == 2)
    assert(v['three'] == [ 3, 3, 3 ])
    assert(v['four']['five'] == "5")

    # Ensure object is not changed by use of AnsibleJ2Vars


# Generated at 2022-06-11 17:26:30.487705
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    # The only thing we need for this test is the template function,
    # so we'll just mock that.
    templar = Templar(loader=None)
    templar._available_variables = {}
    templar.template = lambda x: str(x)

    def fake_available_variables(key):
        if key == 'vars':
            return {'nested': {'dictionary': 'value'}}
        elif key == 'nested_dict':
            return {'foo': 'bar'}
        elif key == 'nested_list':
            return ['apple', 'banana']
        elif key == 'boolean_value':
            return True

# Generated at 2022-06-11 17:26:41.832831
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # test with dict as variable
    j2 = AnsibleJ2Vars(object(), dict())
    varname = 'test'
    j2._templar.available_variables = {varname: {'foo': 'bar'}}
    assert j2[varname] == {'foo': 'bar'}

    # test with str as variable
    j2 = AnsibleJ2Vars(object(), dict())
    varname = 'test'
    j2._templar.available_variables = {varname: 'foo'}
    j2._templar.template = lambda x: x
    assert j2[varname] == 'foo'

    # test KeyError
    j2 = AnsibleJ2Vars(object(), dict())
    varname = 'test'

# Generated at 2022-06-11 17:26:53.996597
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Unit test for method __contains__ of class AnsibleJ2Vars
    class AnsibleJ2Vars_templar:
        def __init__(self, available_variables):
            self.available_variables=available_variables
    class AnsibleJ2Vars_variable:
        def __init__(self, variable):
            self.variable=variable
    ansiblej2vars_templar=AnsibleJ2Vars_templar({'x': AnsibleJ2Vars_variable('x')})
    ansiblej2vars_globals={'y': 'y'}
    ansiblej2vars_locals={'z': 'z'}

# Generated at 2022-06-11 17:27:05.125375
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()

    def _typename(obj):
        type_ = getattr(obj, '__class__', type(obj))
        if hasattr(type_, '__name__'):
            return type_.__name__
        return type_

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, play_context=play_context)
    globals = dict(
        A="Alpha",
        B="Beta",
        C="Charlie",
    )

# Generated at 2022-06-11 17:27:16.116321
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.templar import Templar
    from ansible.vars import VariableManager
    from ansible.template import AnsibleJ2Template
    from ansible.parsing.dataloader import DataLoader

    # Setup variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader=DataLoader())
    variable_manager.extra_vars = dict(
        foo="bar",
    )
    jinja2_env_vars = dict(
        foo="baz",
    )

    # Templating files
    templar = Templar(loader=DataLoader(), variables=variable_manager, environment=jinja2_env_vars)


# Generated at 2022-06-11 17:27:25.239403
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    Test case for AnsibleJ2Vars.__len__() method

    Test if AnsibleJ2Vars.__len__() returns a number greater than zero. This method is used when calculating
    the length of a list.
    """
    from ansible.template import Templar

    test_templar = Templar(loader=None)
    test_globals = {}
    test_AnsibleJ2Vars = AnsibleJ2Vars(test_templar, test_globals)
    test_AnsibleJ2Vars_length = len(test_AnsibleJ2Vars)
    assert test_AnsibleJ2Vars_length > 0

# Generated at 2022-06-11 17:27:38.148447
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """
    This function is used to test function __contains__() of class
    AnsibleJ2Vars.
    """
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = None
    locals = None
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' not in ansible_j2vars


# Generated at 2022-06-11 17:27:43.383935
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    from ansible.template import Templar

    empty_iter = AnsibleJ2Vars(Templar(), {}).__iter__()
    assert len(set(empty_iter)) == 0

    some_iter = AnsibleJ2Vars(Templar(), {'a': 1}, locals={'b': 2}).__iter__()
    assert set(some_iter) == set(['a', 'b'])

# Generated at 2022-06-11 17:27:54.668901
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars

    # test for HostVars
    templar = Templar(loader=None)
    globals_ = {'jinja2_hostvars': HostVars(host_name=None, variables={})}
    locals_ = {'hostvars': {}}
    j2vars = AnsibleJ2Vars(templar=templar, globals=globals_, locals=locals_)
    x = j2vars['jinja2_hostvars']
    assert x['_ansible_no_log'] is True
    assert x['_ansible_verbosity'] == 0

    # test for vars
    templar = Templar(loader=None)

# Generated at 2022-06-11 17:28:06.077051
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    inventory = [{'hostname': 'localhost', 'groups': [], 'vars': {'var2': 3}},
                 {'hostname': '127.0.0.1', 'groups': [], 'vars': {'var3': 4}}]
    play_context = PlayContext()
    inventory = loader.load_from_list(inventory)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    all_v

# Generated at 2022-06-11 17:28:13.222265
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar():
        def __init__(self):
            self.available_variables = {}
        def template(self, data):
            return data
    class Str(object):
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return self.value
        def __repr__(self):
            return self.value

    templar = Templar()
    globals = {'g_key': 'g_value'}
    locals = {'l_key': 'l_value'}

    # Testing for all supported types of data in __getitem__
    # Supported types:
    #   * Str
    #   * str
    #   * dict
    #   * list
    vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-11 17:28:24.615336
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    # Dict of all available variables
    available_variables = dict(
        foo=dict(bar='baz'), # A dict containing a dict
        answer=42, # An int
        hostvars=dict(
            localhost=dict(
                ansible_ssh_host='127.0.0.1',
                foo='bar',
            ),
        ),
        groups=dict(
            group1=dict(
                hostvars=dict(
                    localhost=dict(
                        ansible_ssh_host='127.0.0.1',
                        foo='bar',
                    ),
                ),
                hosts=['localhost'],
                foo='bar',
            ),
        ),
    )
    # Dict of all variables for the template's scope (the vars dict)
    vars

# Generated at 2022-06-11 17:28:25.099925
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass

# Generated at 2022-06-11 17:28:25.678237
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-11 17:28:36.715071
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.hostvars import HostVars

    test_hostvars = HostVars(hostname='sample_hostname')
    test_templar = Templar(loader=None, variables={'vars': {'test_hostvars': test_hostvars}})
    test_globals = {1: 1}
    test_locals = {'some_str': 'some_str'}

    test_AnsibleJ2Vars = AnsibleJ2Vars(test_templar, test_globals, test_locals)

    assert test_AnsibleJ2Vars[1] == 1

# Generated at 2022-06-11 17:28:44.504695
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    import pytest
    # (test_dir): the directory where the test is run
    test_dir = pytest.config.rootdir
    # (test_file): the name of the file which is tested
    test_file = "ansible/vars/ansible_vars.py"
    # data_loader: Data Loader object to load Ansible internal data
    data_loader = DataLoader()
    # display: Display class object to output test results
    display = Display()
    # inventory_list: list of Inventory objects

# Generated at 2022-06-11 17:28:59.715240
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    v = AnsibleJ2Vars(Templar(), dict())
    for i in v:
        print(i)


# Generated at 2022-06-11 17:29:05.634044
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    vars = AnsibleJ2Vars(Templar(), {"foo": "ok", "bar": "ok"})
    assert vars["foo"] == "ok"
    assert vars["bar"] == "ok"
    try:
        vars["baz"]
    except KeyError:
        assert True
    else:
        assert False

# Generated at 2022-06-11 17:29:17.417786
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Test AnsibleJ2Vars class method __getitem__
    '''

    class Templar:
        '''
        Temporary class used to mock Templar class
        '''
        def __init__(self):
            self.available_variables = dict()

        def template(self, variable):
            '''
            Template variable
            '''
            return variable

    templar = Templar()
    globals = dict()

    # Case #1: Variable is inside locals dictionary
    locals = dict(local_variable='value')
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['local_variable'] == 'value'

    # Case #2: Variable is inside available_variables dictionary
    templar.available_vari

# Generated at 2022-06-11 17:29:28.078301
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vars_loader
    from ansible.template import Templar
    import os
    import sys

    def _get_vars_proxy():
        loader = DataLoader()
        variable_manager = VariableManager()
        inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list='localhost')

        variable_manager.set_inventory(inventory)

        context = PlayContext()

        variable_manager.extra_vars = {'var1': 'hello', 'var2': 'world', 'var3': 'this is a line with \n'}



# Generated at 2022-06-11 17:29:30.808797
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    obj = AnsibleJ2Vars(templar, {'a': 33})
    assert len(obj) == 1

# Generated at 2022-06-11 17:29:39.260800
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar()
    global_test = {'test1': 'test1'}
    local_test = {'test2': 'test2'}

    vars_1 = AnsibleJ2Vars(templar, global_test, local_test)

    assert(vars_1.__contains__('test1') == True)
    assert(vars_1.__contains__('test2') == True)
    assert(vars_1.__contains__('test3') == False)


# Generated at 2022-06-11 17:29:44.269491
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)

    test_obj = AnsibleJ2Vars(templar, globals={})

    test_obj.__contains__ = MagicMock(return_value=True)

    test_obj.__iter__()
    assert test_obj.__contains__.call_count == 1



# Generated at 2022-06-11 17:29:55.691244
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    import jinja2

    loader = jinja2.DictLoader({
        'a.j2': '{{var}}',
        'b.j2': '{{var2}}',
    })
    env = jinja2.Environment(loader=loader)
    template = env.get_template('a.j2')
    template2 = env.get_template('b.j2')

    t = Templar(loader=loader)
    vars = AnsibleJ2Vars(t, {}, {'var': 'hello', 'var2': 'world'})
    assert(vars['var'] == 'hello')
    assert(vars['var2'] == 'world')


# Generated at 2022-06-11 17:30:07.532005
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    import ansible.constants as C
    import sys

    # Define class AnsibleUnsafe with attribute __UNSAFE__
    class AnsibleUnsafe:
        __UNSAFE__ = True

    # Create instance of AnsibleJ2Vars with attribute templar, globals, locals

# Generated at 2022-06-11 17:30:18.682992
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import ansible.vars.hostvars as HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from jinja2.runtime import Undefined

    hostvars = HostVars({'host': 'testhost'})

    # We do not want the default `default` group in our test
    VariableManager._groups = {}

    vm = VariableManager()
    vm.add_host_variable(host_name='testhost', variable='vars')
    vm.set_host_variable(host_name='testhost', varname='somevar', value='somevalue')
    vm.add_group_variable(group_name='server', variable='vars')
    # FIXME: should we be setting vars on group or host?

# Generated at 2022-06-11 17:30:54.189144
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.template.safe_environment import SafeEnvironment
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play_context import PlaybookContext

    # Make sure we're running in a single process and without a custom CWD
    # so that we can start the tests with a known state
    assert 'ANSIBLE_FORKS' not in os.environ
    assert 'ANSIBLE_PWD' not in os.environ


# Generated at 2022-06-11 17:31:05.339335
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variables = VariableManager()
    variables.extra_vars = combine_vars(loader=loader, variables=variables, perspective='task')

    templar = Templar(loader=loader, variables=variables)

    j2vars = AnsibleJ2Vars(templar=templar, globals={'a': 1, 'b': 2}, locals={'c': '3', 'd': '4'})
    assert set(j2vars) == set(['self', 'ansible', 'a', 'b', 'c', 'd'])

# Generated at 2022-06-11 17:31:14.698790
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # import class and function to be tested
    from ansible.template import Templar

    # create class object to be tested
    local_ansible_vars = {'local_var': 'local value'}
    ansible_vars = {'var': 'value'}
    templar = Templar(loader=None, variables=ansible_vars)
    ansible_j2_vars = AnsibleJ2Vars(templar=templar, globals={'global_var': 'global value'}, locals=local_ansible_vars)

    # test for locally defined variable
    assert 'local_var' in ansible_j2_vars, 'The tested method __contains__ of the class AnsibleJ2Vars does not work properly'

    # test for globally defined variable
    assert 'global_var' in ans

# Generated at 2022-06-11 17:31:18.689585
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_AJV = AnsibleJ2Vars(1,2,3)
    assert test_AJV._templar == 1
    assert test_AJV._globals == 2
    assert test_AJV._locals == 3

# Generated at 2022-06-11 17:31:28.620292
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    def my_templar_template(self, variable):
        return variable

    class my_templar(object):
        def __init__(self, *args, **kwargs):
            self.available_variables = {'my_dict': [1,2,3]}
        def template(self, variable):
            return variable

    a = AnsibleJ2Vars(my_templar(), {'global_variable': 'value'}, {'local_variable': 'other_value'})
    assert 'my_dict' in a
    assert 'global_variable' in a
    assert 'local_variable' in a
    assert 'no_such_variable' not in a


# Generated at 2022-06-11 17:31:35.284253
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    templar._available_variables = {'foo': 1}
    globals = {}
    locals = {'foo': 10, 'bar': 100}
    vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert 'foo' in vars
    assert 'bar' in vars
    assert 'baz' not in vars


# Generated at 2022-06-11 17:31:39.366592
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_obj = AnsibleJ2Vars(templar=0, globals=dict(x=0, y=0), locals=None)
    assert 'x' in test_obj
    assert 'y' in test_obj
    assert 'z' not in test_obj

# Generated at 2022-06-11 17:31:44.340242
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = object()
    globals = {'g1': 1}
    locals = {'l_l1': 2}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert('g1' in ajv)
    assert('l1' in ajv)
    assert('l_l1' not in ajv)
    assert('x' not in ajv)


# Generated at 2022-06-11 17:31:54.539299
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import jinja2.utils
    from ansible.template.safe_eval import safe_eval
    from ansible import constants as C
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar

    # building variables for test
    testvar1 = "testvar1"
    testvar2 = "testvar2"

    # result of safe_eval becames list of varibles
    template_vars = [testvar1, testvar2]
    # J2Vars will use this dictionary of variables

# Generated at 2022-06-11 17:32:02.225577
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(None, None, {})
    globals = {'var1': 'Not hostvars', 'var2': HostVars(None, '{{var1}}')}
    locals = {'var1': 'Not hostvars2'}

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'var1' in vars
    assert 'var2' in vars
    assert 'var1' in locals
    assert 'var2' in globals
    assert 'var1' not in globals
    assert 'var2' not in locals

    assert vars['var1'] == locals['var1']

# Generated at 2022-06-11 17:32:52.146723
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    obj = AnsibleJ2Vars(templar=None,globals=None,locals=None)
    assert not 'test' in obj


# Generated at 2022-06-11 17:32:53.773217
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # TODO implement unit test
    return True


# Generated at 2022-06-11 17:33:01.030332
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    host = HostVars()
    host["foo"] = "bar"
    templar = Templar(loader=None)
    templar._available_variables = {"foo": host}
    locals = {}
    globals = {}
    my_vars = AnsibleJ2Vars(templar, globals, locals)
    assert "foo" in my_vars

# Generated at 2022-06-11 17:33:09.863304
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    vars = VariableManager(loader=None)
    vars.extra_vars = {"varname":"varvalue"}
    templar = Templar(loader=None, variables=vars)
    a = AnsibleJ2Vars(templar,{"othervarname":"othervarvalue"})
    assert a['varname'] == "varvalue"
    assert a['othervarname'] == "othervarvalue"



# Generated at 2022-06-11 17:33:14.017130
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    input_variables = dict(a = "1")
    templar = Templar(loader=None, variables=input_variables)
    j2vars = AnsibleJ2Vars(templar, globals={})

    assert "a" in j2vars
    assert "b" not in j2vars


# Generated at 2022-06-11 17:33:20.691082
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar_mock = Mock()
    globals_mock = Mock()
    locals_mock = Mock()
    ansible_j2vars = AnsibleJ2Vars(templar_mock, globals_mock, locals_mock)
    assert len(ansible_j2vars) == 1
    templar_mock.available_variables.__contains__.assert_any_call("asdf")
# test_AnsibleJ2Vars___len__


# Generated at 2022-06-11 17:33:28.886968
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.utils import context_objects as co

    # Setup test scenario
    vars_dict = dict(x='x')
    templar = Templar(loader=None, variables=vars_dict)
    globals_dict = dict(y='y')
    locals_dict = dict(z='z')
    ansible_j2_vars = AnsibleJ2Vars(templar, globals_dict, locals_dict)

    # Test __getitem__
    # Positive tests
    assert ansible_j2_vars['x'] == 'x'
    assert ansible_j2_vars['y'] == 'y'
    assert ansible_j2_vars['z'] == 'z'
    # Negative tests
    # Nonexistent variable

# Generated at 2022-06-11 17:33:38.051836
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.plugins.loader import vars_loader
    templar = vars_loader._create_templar(loader=None)
    vars = AnsibleJ2Vars(templar, dict(this="is a test"), dict(
        context='the_context', environment='the_environment', template='the_template', l_vars='the_vars'))
    assert("vars" in vars)
    assert("context" not in vars)
    assert("environment" not in vars)
    assert("template" not in vars)
    assert("this" in vars)


# Generated at 2022-06-11 17:33:45.588839
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None, variables={})
    globals = {"hostvars": {"localhost": {}}}
    jvars = AnsibleJ2Vars(templar, globals, None)
    assert jvars["hostvars"] == {"localhost": {}}

    globals = {"hostvars": wrap_var(HostVars({"localhost": {}}), Templar(loader=None, variables={}))}

# Generated at 2022-06-11 17:33:55.750990
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 'apple', 'b': 'banana'}
    variable_manager.set_inventory(loader.load_from_file('tests/inventory'))
    templar = Templar(loader=loader, variables=variable_manager)
    p = PlayContext()
    p.vars = {'c': 'carrot'}
    ansible_vars = AnsibleJ2Vars(templar, p.vars)

    # varname not defined