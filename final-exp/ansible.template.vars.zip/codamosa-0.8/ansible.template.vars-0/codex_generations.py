

# Generated at 2022-06-11 17:24:03.901432
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # Empty input
    assert not AnsibleJ2Vars(
        templar     = None,
        globals     = {},
        locals      = None,
    ).__contains__('key1')

    # Empty input
    assert not AnsibleJ2Vars(
        templar     = None,
        globals     = {'key1': 'value1'},
        locals      = None
    ).__contains__('key2')

    # Empty input
    assert not AnsibleJ2Vars(
        templar     = None,
        globals     = None,
        locals      = {'key1': 'value1'}
    ).__contains__('key2')

    # Empty input

# Generated at 2022-06-11 17:24:13.014722
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # make a fake templar
    class FakeTemplar:
        def __init__(self):
            self.available_variables={'foo': 22, 'bar': {'baz': 'something'}}

    # create a fake jinja environment
    class FakeEnv:
        def __init__(self):
            self.globals = {}

    # create the object
    value = 10
    vars_ = AnsibleJ2Vars(FakeTemplar(), {'value': value})
    assert len(vars_) == 3
    assert 'foo' in vars_
    assert 'bar' in vars_
    assert 'value' in vars_

# Generated at 2022-06-11 17:24:23.858305
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    This method test the __getitem__() method of AnsibleJ2Vars() class.
    :return:
    '''
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager

    # 1. test case: if the varname contains in local scope
    templar = VariableManager()
    globals = {'path': '~'}
    locals = {'varname': 'local_variable'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    res = ajv.__getitem__('varname')
    assert res == 'local_variable', 'The test case 1 in AnsibleJ2Vars.__getitem__() failed!'

    # 2. test case: if the varname contains in tem

# Generated at 2022-06-11 17:24:35.687627
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    j2_vars = AnsibleJ2Vars(templar, {})
    assert len(j2_vars) == 0
    j2_vars._locals = {'test_key1': 'test_val1'}
    assert len(j2_vars) == 1
    j2_vars._templar.available_variables['test_key2'] = 'test_val2'
    assert len(j2_vars) == 2
    j2_vars._globals = {'test_key3': 'test_val3'}
    assert len(j2_vars) == 3


# Generated at 2022-06-11 17:24:47.697959
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import mock

    templar = mock.MagicMock()
    globals = {
        "g1": "g1",
    }
    locals = {
        "l1": "l1",
    }
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test KeyError
    try:
        vars["unknown"]
        raise AssertionError("Expected KeyError")

    except KeyError as e:
        assert "undefined variable: unknown" in str(e)

    # Test special case: vars
    templar.available_variables = {
        "vars": "vars",
    }

    assert vars["vars"] == "vars"

    # Test special case: HostVars

# Generated at 2022-06-11 17:24:58.170589
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.template import Templar
    import os
    import pytest
    # Create a dataloader, inventory, and variable manager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[os.path.join(os.path.dirname(__file__), "data/hosts")])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager.get_vars(host=Host("localhost")))

# Generated at 2022-06-11 17:25:01.242487
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2

    t = jinja2.Template("")
    vars_ = AnsibleJ2Vars(t, {'a': 1})

    assert 'a' in vars_


# Generated at 2022-06-11 17:25:11.451090
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.playbook.play_context import PlayContext
    import jinja2
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host

    pc = PlayContext()
    pc.remote_addr = 'localhost'
    variable_manager = VariableManager()
    variable_manager.extra_vars = { 'foo': 'bar' }

    variable_manager.set_inventory(VariableManager())
    variable_manager.set_host_parents({ 'localhost': Host(name='localhost', vars={ 'baz': 'quux' }) })

    templar = Templar(loader=jinja2.DictLoader({}), variables=variable_manager,
                      shared_loader_obj=variable_manager)


# Generated at 2022-06-11 17:25:17.312655
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={'var1': 'var1value'})

    result = AnsibleJ2Vars(templar, globals={}, locals={})['var1']

    assert result == 'var1value'

test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-11 17:25:23.858566
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = {'foo':'bar'}
    locals = {'fizz':'buzz'}
    vars = AnsibleJ2Vars(templar, globals, locals=locals)

    assert vars['fizz'] == 'buzz'
    assert vars['foo']  == 'bar'
    try:
        vars['nonexistent']
    except KeyError:
        pass
    else:
        assert False

# Generated at 2022-06-11 17:25:37.127242
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    import os

    loader = DataLoader()
    variable_manager = VariableManager()
    playbook_path = os.path.join(os.path.dirname(__file__), 'playbook_test/playbook.yml')

    try:
        # load the play from playbook.yml we created above
        play = Play.load(playbook_path, variable_manager=variable_manager, loader=loader)
    except AnsibleError as err:
        print(err.message)

    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play))

    aj2vars

# Generated at 2022-06-11 17:25:49.161773
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    def _test_with_env(env_str):
        # Prepare env
        if env_str == 'Chocolate':
            env = dict()
        elif env_str == 'Vanilla':
            env = dict(a='a')
        elif env_str == 'Strawberry':
            env = dict(a='b')
        elif env_str == 'Peach':
            env = dict(b='b')
        elif env_str == 'Banana':
            env = dict(a='b', b='b')
        elif env_str == 'Lemon':
            env = dict(a='b', b='b', c='c')
        elif env_str == 'Lime':
            env = dict(a='b', b='c', c='c')

# Generated at 2022-06-11 17:26:00.166844
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.template import Templar
    templar = Templar(loader=None)

    try:
        # test case 1
        # fail if the ansible variable is undefined

        AnsiJ2vars = AnsibleJ2Vars(templar, globals(), locals())
        value = AnsiJ2vars['undefined_var']
    except KeyError as e:
        assert e.args[0] == "undefined variable: undefined_var"

    # test case 2
    # return value of the ansible variable if it's defined

    the_var = 'the var'
    templar.set_available_variables(dict(defined_var=the_var))
    AnsiJ2vars = AnsibleJ2Vars(templar, globals(), locals())
    value = AnsiJ2vars

# Generated at 2022-06-11 17:26:06.696647
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    ajv = AnsibleJ2Vars(Templar(), dict())

    assert hasattr(ajv, '__iter__')
    assert hasattr(ajv, '__contains__')
    assert hasattr(ajv, '__len__')
    assert hasattr(ajv, '__getitem__')

    assert isinstance(ajv, Mapping)
    assert not isinstance(ajv, dict)
    assert not isinstance(ajv, set)
    assert not isinstance(ajv, list)

# Generated at 2022-06-11 17:26:17.255678
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = Templar(loader=DictDataLoader({}), variables={u'var': u'default'})
    globals_ = {u'global': u'override'}
    locals_ = {u'local': u'override'}

    #
    # Test case 1.
    #
    # 'local' is set then is used, global is not defined.
    #

    aj2v = AnsibleJ2Vars(templar, globals_, locals_)
    print("This test case should print 'override'")
    print("var = " + repr(aj2v['var']))
    print("global = " + repr(aj2v['global']))
    print("local = " + repr(aj2v['local']))

    #
    # Test case 2.
    #
   

# Generated at 2022-06-11 17:26:25.271633
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.templar import Templar
    # Set up the AnsibleJ2Vars object with valid parameters.
    templar = Templar(loader=None, variables={'key': 'value'}, shared_loader_obj=None)
    ansible_J2Vars_obj = AnsibleJ2Vars(templar, {'key': 'value'})

    # Calling __getitem__ for existing key: 'key'
    ansible_J2Vars_obj.__getitem__('key')

    # Calling __getitem__ for non-existing key: 'non-existing-key'

# Generated at 2022-06-11 17:26:29.805736
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = MagicMock()
    temp_obj = AnsibleJ2Vars(templar, globals={"g": 1}, locals={"l": 2})
    assert "g" in temp_obj
    assert "l" in temp_obj
    assert "v" in temp_obj
    assert "n" not in temp_obj



# Generated at 2022-06-11 17:26:41.205211
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import jinja2
    from ansible.template.safe_eval import safe_eval

    print("Testing AnsibleJ2Vars.__getitem__()")

    templar = jinja2.Environment().from_string("{{ a }}").make_template("Test")  # a must be in available_variables
    globals = {}
    locals = {"a": "P"}
    vars_ = AnsibleJ2Vars(templar, globals, locals)
    assert vars_["a"] == "P"

    # test that __UNSAFE__ attribute can be defined on any object to avoid templating
    class Unsafe:
        pass
    locals = {"a": Unsafe()}
    setattr(locals["a"], "__UNSAFE__", True)

# Generated at 2022-06-11 17:26:53.618431
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader(), variables=VariableManager(loader=DataLoader()), inventory=Inventory(loader=DataLoader()))

    # Case 1

    vars = {'test.baz': 'baz', 'foo': 'bar'}
    templar._available_variables = vars.copy()
    proxy = AnsibleJ2Vars(templar, {})
    assert proxy['test.baz'] == 'baz'

    # Case 2

    vars = {'test.baz': 'baz', 'foo': 'bar'}
    templar._available_variables = vars.copy

# Generated at 2022-06-11 17:27:04.569734
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Initialize test class
    import jinja2
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    templar = Templar(loader=jinja2.DictLoader({}), variables={})
    test_obj = AnsibleJ2Vars(templar, {})

    # Successfully retrieve an existing variable
    assert test_obj['ansible_default_ipv4'].get('address') == '127.0.0.1'

    # Raise KeyError for an undefined variable
    def key_error():
        test_obj['this_is_not_defined']
    from unittest.case import SkipTest
    try:
        key_error()
    except KeyError:
        pass
    else:
        raise SkipTest('KeyError not raised')

# Generated at 2022-06-11 17:27:13.369623
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {}
    locals = {}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars._templar == templar
    assert vars._globals == globals
    assert vars._locals == locals


# Generated at 2022-06-11 17:27:20.713769
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    templar = Templar(vault_secrets=dict(vault_password='vault_password'), loader=None)
    globals = dict()
    locals = dict()
    v = AnsibleJ2Vars(templar, globals, locals)
    assert v['vault_password'] == 'vault_password'

    # HostVars is special and should be returned as-is
    h = HostVars({'a': 1})
    assert v['h'] == h

    # dict and hasattr(

# Generated at 2022-06-11 17:27:26.700689
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    test_obj = AnsibleJ2Vars(None, locals = {'l_key':'l_val'}, globals = {})
    test_obj._templar.available_variables = { 'key': 'val' }
    len_obj = len(test_obj)
    if len_obj != 2:
        raise Exception('Failed to get length of object %s' % test_obj)


# Generated at 2022-06-11 17:27:34.562874
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    import os

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    play_context = PlayContext()
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ game }}')))
        ]
    )

    play = Play

# Generated at 2022-06-11 17:27:44.749271
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # Need mock objects here
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 17:27:55.412993
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    # Test for when the variable is not defined
    aj2vars = AnsibleJ2Vars(templar, globals={})
    assert not ('non' in aj2vars)

    # Test for when the variable is defined
    aj2vars = AnsibleJ2Vars(templar, globals={})
    templar.available_variables = {'yes': 'yes'}
    assert ('yes' in aj2vars)

    # Test for when the variable is defined as a global variable

# Generated at 2022-06-11 17:28:07.050190
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible import errors
    from ansible.template import Templar
    from ansible.vars import hostvars
    from ansible.vars import VariableManager
    from ansible.vars import variables

    class Templar_Dummy(Templar):

        def __init__(self, variable_manager=None, loader=None):
            self.template = "template"
            self.environment = "environment"
            self.context = "context"
            self.host_template_mapping = {}
            self.available_variables = variable_manager.get_vars(loader=loader, play=None)

        def template(self, variable):
            return variable

    # test dict variables
    variable_manager = VariableManager()

# Generated at 2022-06-11 17:28:19.392719
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    from ansible.module_utils.six import StringIO

    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Create play context and templar, then create test object
    context = PlayContext()
    context.vars = VariableManager()
    templar = Templar(loader=jinja2.DictLoader({}), variables=context.vars)
    test_obj = AnsibleJ2Vars(templar, {})

    # Test fails if item is in

# Generated at 2022-06-11 17:28:28.802977
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class DummyTemplar():
        def __init__(self):
            self.available_variables = dict(a=1, b=2, c=3)
    global_vars = dict(a=100, b=200, c=300)
    l_vars = dict(l_a=1000, l_b=2000, l_c=3000)
    l_vars_new = dict(l_a=10000, l_b=20000, l_c=30000)

    ansible_vars = AnsibleJ2Vars(DummyTemplar(), global_vars, locals=l_vars)
    assert ansible_vars.__contains__('a') == True
    assert ansible_vars.__contains__('d') == False
    assert ansible_vars.__cont

# Generated at 2022-06-11 17:28:39.750751
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import string_types
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    import os
    import json

    # Load Inventory, Load Play Context and create Templar Object
    vmanager = VariableManager()
    templar = Templar(loader=None, variables=vmanager)

    # Create all Ansible Vars and set them in the AnsibleJ2Vars Object
    all_vars = dict()

# Generated at 2022-06-11 17:28:46.792715
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    test_ansible_j2_vars = AnsibleJ2Vars(AnsibleJ2Vars._templar, {})
    assert type(test_ansible_j2_vars.__iter__()) is type(iter([]))

# Generated at 2022-06-11 17:28:55.677808
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    globals = {'one': 'two'}
    templar = None
    locals = {'one': 'two'}

    ajv = AnsibleJ2Vars(templar, globals, locals=locals)
    assert 'one' in locals and 'one' in ajv

    locals = {'one': 'two'}
    ajv = AnsibleJ2Vars(templar, globals, locals=locals)
    assert 'one' in locals and 'one' not in ajv

    locals = {'one': 'two'}
    ajv = AnsibleJ2Vars(templar, globals, locals=locals)
    assert 'one' not in locals and 'one' in ajv



# Generated at 2022-06-11 17:29:07.227277
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    AnsibleJ2Vars is a wrapper class that handles the Jinja2 templating
    process. The purpose of the method __contains__ is to return
    whether or not a variable exists. Method __contains__ should
    return True if the variable exists or False if the variable
    does not exist.
    '''
    # Create AnsibleJ2Vars object.
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)

    globals = dict()
    locals = dict()

    j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Tests for method __contains__
    # Test 1
    # Setup
    variable_name = 'valid_variable'

    # Exercise


# Generated at 2022-06-11 17:29:19.266326
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # Test method __contains__ with Templar(), globals={}, locals={}
    # Should return False
    templar = 'Templar_v'
    globals = {'globals_v': 1}
    locals = {'locals_v': 2}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    x = 'x'
    assert not x in ajv, "test AnsibleJ2Vars___contains__, case 1 failed!"

    # Test method __contains__ with Templar(), globals={'globals_v': 1}, locals={'locals_v': 2}
    # Should return True
    templar = 'Templar_v'
    globals = {'globals_v': 1}

# Generated at 2022-06-11 17:29:29.220852
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    templar = Templar(loader=None, variables=VariableManager())
    globals = {"my_var1": "my_value1"}
    locals = {"my_var2": "my_value2", "l_my_var3": "my_value3"}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert "my_var1" in ansible_j2_vars
    assert "my_var2" in ansible_j2_vars
    assert "my_var3" not in ansible_j2_vars
    assert "does_not_exist" not in ansible_j2_vars

# Generated at 2022-06-11 17:29:40.530506
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['locals_1'] == None
    locals['locals_1'] = 'locals_1'
    assert ajv['locals_1'] == 'locals_1'
    var = dict({'var_1': 'var_1', 'var_2': 'var_2'})
    templar._available_variables = dict({'var_1':'var_1', 'var_2':'var_2'})
    templar._templates = ajv
    assert ajv

# Generated at 2022-06-11 17:29:47.974469
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = object()
    globals = {"a" : "a", "b" : "b", "c" : "c"}
    locals = {"d" : "d", "e" : "e", "f" : "f"}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    test_vars = set()
    test_vars.update(ajv.keys())
    assert len(test_vars) == len(ajv)
    for var in test_vars:
        assert var in ajv

# Generated at 2022-06-11 17:29:52.874224
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.templating import Templar
    templar = Templar(loader=None, variables={'x': 'y'})
    vars = AnsibleJ2Vars(templar=templar,globals={})
    assert vars['x'] == 'y'

# Generated at 2022-06-11 17:29:59.045519
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import AnsibleJ2Vars
    templar = None
    globals = {"G_KEY":"G_VALUE"}
    locals = {"L_KEY":"L_VALUE"}
    ansible_vars = {"A_KEY":"A_VALUE"}
    ajvars = AnsibleJ2Vars(templar, globals, locals, ansible_vars)
    assert 'G_KEY' in ajvars
    assert 'L_KEY' in ajvars
    assert 'A_KEY' in ajvars


# Generated at 2022-06-11 17:30:09.781645
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from unittest import TestCase
    from ansible.parsing.yaml.objects import AnsibleMapping

    vars1 = AnsibleMapping()
    vars1['foo'] = 'bar'
    vars1['qux'] = []
    vars1['qux'].append(AnsibleMapping())
    vars1['qux'][0]['foo'] = 'bar'
    vars1['qux'][0]['bar'] = 'baz'

    vars2 = AnsibleMapping()
    vars2['foo'] = 'baz'
    vars2['qux'] = []

# Generated at 2022-06-11 17:30:14.184773
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert False, "not implemented"


# Generated at 2022-06-11 17:30:25.512308
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    This is a test method for the constructor of the class AnsibleJ2Vars.
    Here we simply check that the values that we defined will be saved in the correct variables
    :return:
    '''
    templar = "Test_Jinja2_Template"
    globals = {'test_var': 5, 'count': 7}
    locals = {'test_var': 4}
    ansible_j2_vars_test_obj = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars_test_obj._templar == templar
    assert ansible_j2_vars_test_obj._globals == globals
    assert ansible_j2_vars_test_obj._locals == locals

# Generated at 2022-06-11 17:30:32.814819
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # This is an example of using the AnsibleJ2Vars() class
    # it tests:
    #   * getting an item from available variables
    #   * adding locals
    #   * getting an item from locals
    #   * getting an item from globals

    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObj
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task import Task
    from ansible.template import Templar

    from ansible.module_utils.facts.system import SystemFacts
    from ansible.module_utils.facts.virtual.openvz import OpenVZFactCollector

# Generated at 2022-06-11 17:30:43.170927
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import mock
    from ansible.template import Templar
    from ansible.template.template import AnsibleEnvironment
    from ansible.vars.hostvars import HostVars

    templar = Templar(mock.Mock(), mock.Mock())
    env_vars = {'x': 'hostvars', 'y': 'vars'}
    env_vars.update(templar.available_variables)
    templar._available_variables = env_vars
    templar._jinja2_env = AnsibleEnvironment(mock.Mock(), loader=None)
    templar._templates = []

    aj2vars = AnsibleJ2Vars(templar, globals={'a': 'globals'})

    # __contains__

# Generated at 2022-06-11 17:30:54.856361
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class AnsibleJ2Vars_mock():
        class Templar():
            pass
        Templar = Templar()
        Templar.available_variables = {'k': None}
        def __init__(self, templar, globals, locals=None):
            pass

    # create mock object
    ansible_j2_vars = AnsibleJ2Vars_mock()

    # test: all 'globals', some in 'locals', some in 'available_variables'
    assert ansible_j2_vars.__contains__('k')
    assert ansible_j2_vars.__contains__('l')
    assert ansible_j2_vars.__contains__('p')

    # test: not in 'globals', not in 'locals', not in 'available_variables

# Generated at 2022-06-11 17:31:06.159127
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.utils.listify import listify_lookup_plugin_terms

    dataloader = DataLoader()
    variable_manager = VariableManager(loader=dataloader)
    templar = Templar(loader=dataloader, variables=variable_manager)
    av = {
        'ansible_version': {
            'full': '2.4.1.0',
            'major': 2,
            'minor': 4,
            'revision': 1,
            'string': '2.4.1.0',
        }
    }

# Generated at 2022-06-11 17:31:15.104703
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(None, {})

    globals = {"gkey1": "gval1", "gkey2": "gval2"}
    locals = {"lkey1": "lval1", "lkey2": "lval2"}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # simulate adding key1 to _templar.available_variables
    j2vars._templar.available_variables = {"key1": "val1", "key2": "val2"}

    # check that all keys are counted
    assert len(j2vars) == len(globals) + len(locals) + len(j2vars._templar.available_variables)

    # check that keys don't replicate

# Generated at 2022-06-11 17:31:26.924379
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
     test for method __contains__ of class AnsibleJ2Vars
    :return:
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    my_vars = {'foo': 'bar', 'baz': None}
    my_loader = DataLoader()
    my_inventory = None
    my_play_context = PlayContext(vars=my_vars)
    my_templar = Templar(loader = my_loader,
                         variables = my_vars,
                         fail_on_undefined = True,
                         disable_lookups = True,
                         inventory = my_inventory,
                         play_context = my_play_context)

    ajv = AnsibleJ

# Generated at 2022-06-11 17:31:34.208381
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar(loader=None, variables=dict(a=dict(b=dict(c=2))))
    vars = AnsibleJ2Vars(templar, dict(a=dict(b=dict(c=1))))
    assert('a' in vars)
    assert('b' in vars)
    assert('c' in vars)
    assert('a.b' in vars)
    assert('a.b.c' in vars)
    assert('a.b.c.d' not in vars)
    assert('b.c' in vars)
    assert('b.c.d' not in vars)
    assert('c' in vars)
    assert('c.d' not in vars)

# Generated at 2022-06-11 17:31:42.596839
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)

    check_vars = dict()
    src_vars = dict()
    j2vars = AnsibleJ2Vars(templar, src_vars, locals=check_vars)

    # Test for KeyError
    try:
        j2vars['Test1']
        assert False
    except KeyError:
        assert True

    templar._available_variables = {'Test2':'Test2'}
    try:
        j2vars['Test2']
        assert True
    except KeyError:
        assert False


# Generated at 2022-06-11 17:31:59.525194
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables={}, fail_on_undefined=False)

    # Test case 1: varname exists in locals
    varname = 'l_key1'
    # locals only contains the variables which start with 'l_'
    locals = {'l_key1': 'value1', 'l_key2': 'value2'}
    # globals is empty
    globals = {}

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals=locals)

# Generated at 2022-06-11 17:32:06.285212
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from jinja2 import Environment
    from ansible.module_utils.common._collections_compat import Mapping

    # creating a jinja2 environment
    j2_env = Environment()

    # creating AnsibleJ2Vars
    aj2v = AnsibleJ2Vars(j2_env, {'a': 'ansible'}, locals={'b': '2'})

    # verifying that AnsibleJ2Vars is an iterable
    assert hasattr(aj2v, '__iter__')

    # verify that AnsibleJ2Vars is an object of class AnsibleJ2Vars
    assert isinstance(aj2v, AnsibleJ2Vars)

    # verify that AnsibleJ2Vars is a Mapping type
    assert isinstance(aj2v, Mapping)

    # verify that items contained

# Generated at 2022-06-11 17:32:13.494798
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.templating import Templar
    from ansible.vars import VariableManager

    templar = Templar(VariableManager())
    templar._available_variables = {'myvar1': "myvalue1", 'myvar2': {'myvar2_2': "myvalue2_2"}}
    globals = {'myvar3': 'myvalue3'}

    # When there are no locals
    aj2v = AnsibleJ2Vars(templar, globals)

    # Then:
    #  - __contains__ should return True for variables
    assert 'myvar1' in aj2v
    assert 'myvar2' in aj2v
    assert 'myvar3' in aj2v

    #  - __contains__ should return False for variables that are not present
   

# Generated at 2022-06-11 17:32:18.349637
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Creating test objects
    ans_obj = AnsibleJ2Vars(templar={}, globals={}, locals={})
    # Creating expected output
    expected = set()
    # Checking if equals to expected output
    assert ans_obj.__iter__() == expected


# Generated at 2022-06-11 17:32:28.334524
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six.moves import builtins

    templar = Templar(DataLoader(), variables=VariableManager())

    # Test 1: test __len__ with partial and full data
    vars1 = AnsibleJ2Vars(templar, {})
    vars2 = AnsibleJ2Vars(templar, {'a': 1, 'b': None})
    vars3 = AnsibleJ2Vars(templar, {'a': 1, 'b': None, 'c': "test"})

    assert vars1.__len__() == len(builtins.__dict__)
    assert vars2.__len__

# Generated at 2022-06-11 17:32:35.555191
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import json

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()

    variable_manager = VariableManager()

    variable_manager.set_inventory(loader.load_inventory('tests/unit/inventory'))

    fh = open('tests/unit/vars/test.json')
    data = json.load(fh)
    fh.close()
    variable_manager.set_fact_cache(data)

    templar = Templar(loader=loader, variables=variable_manager)

    # FIXME: Test local variables
    variables = AnsibleJ2Vars(templar, dict())

    # Test length.
    # FIXME: Test length after adding local variables.
    test_len = len

# Generated at 2022-06-11 17:32:41.784003
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = Templar(loader=DataLoader())
    var_manager = VariableManager(loader=DataLoader())
    foo1, foo2, foo3 = "foo1", "foo2", "foo3"
    my_locals = {'foo1': foo1, 'foo2': foo2, 'foo3': foo3}
    my_globals = {foo1: foo1, foo2: foo2, foo3: foo3}
    vars = AnsibleJ2Vars(templar, my_globals, locals=my_locals)
    assert foo2 in vars
    assert foo1 in vars
    assert foo3 in vars
    assert "bar" not in vars

# Generated at 2022-06-11 17:32:52.536048
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.safe_eval import safe_eval
    import ansible.constants as C
    import ansible.template.template as template
    import ansible.template.vars as vars
    import ansible.vars.hostvars as hostvars

    loader = DataLoader()

    # FIXME prepare a real set of variables, e.g. something like this
    #    variables = vars.VarsModule().get_vars(loader=loader, play=play, host=host)
    #    variables['vars'] = variables
    #    variables['message'] = "bla"
    #    variables['item'] = "blub"


# Generated at 2022-06-11 17:33:04.327868
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Unit test for method __contains__ of class AnsibleJ2Vars.
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    test_vars = AnsibleJ2Vars(Templar(DataLoader()), {}, locals={})
    assert not ('aaa' in test_vars)
    assert ('_' in test_vars)
    assert ('self' in test_vars)

    test_vars = AnsibleJ2Vars(Templar(DataLoader()), {'aaa': 'aaa'}, locals={'bbb': 'bbb'})
    assert ('aaa' in test_vars)
    assert ('bbb' in test_vars)
    assert ('_' in test_vars)

# Generated at 2022-06-11 17:33:13.097247
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(None, loader=None)
    proxy = AnsibleJ2Vars(templar, {}, locals=None)
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars(dict(), None)
    hostvars.__UNSAFE__ = True
    proxy._templar.available_variables = {'test_var': 'test_var'}
    proxy._globals = {'test_var': hostvars}
    assert proxy['test_var'] == 'test_var'
    assert proxy['test_var'] == hostvars


# Generated at 2022-06-11 17:33:28.464994
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class TemplarMock():
        def __init__(self):
            self.available_variables = {
                'aaa': 'aaa',
                'bbb': 'bbb',
            }
        def template(self, variable):
            return variable

    class AnsibleUndefinedVariableMock():
        pass

    class HostVarsMock():
        pass

    def _test_AnsibleJ2Vars___getitem___case_1(self):
        self._locals = {'aaa': 'aaa', 'ccc': 'ccc'}
        self._globals = {'bbb': 'bbb', 'ccc': 'ccc'}
        self._templar.available_variables = {'aaa': 'aaa', 'bbb': 'bbb', 'ccc': 'ccc'}

        assert len

# Generated at 2022-06-11 17:33:33.790265
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    globals = dict(foo=dict(bar=dict(baz=list(range(4)))))
    templar = None
    ajv = AnsibleJ2Vars(templar, globals)
    assert ajv['foo']['bar']['baz'][2] == 2


# Generated at 2022-06-11 17:33:43.549241
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    t = Templar(None, loader=None)
    t._available_variables = {
        'myvar1': '1',
        'myvar2': '2',
        'myvar3': '3',
    }
    t._available_variables.pop('myvar2', None)
    g = {
        'myglob1': 'glob1',
        'myglob2': 'glob2',
        'myglob3': 'glob3',
    }
    l = {
        'mylocal1': 'local1',
        'mylocal2': 'local2',
        'mylocal3': 'local3',
    }

    vars = AnsibleJ2Vars(t, g, locals=l)


# Generated at 2022-06-11 17:33:54.590200
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    def test(test_data):
        templar_data = test_data['templar_data']
        globals_data = test_data['globals_data']
        locals_data  = test_data['locals_data']
        key_dict     = test_data['key_dict']
        expected     = test_data['expected']

        templar = MagicMock(spec=AnsibleJ2Template)
        templar.available_variables.__getitem__.side_effect = lambda key: templar_data[key]

        ansible_j2_vars = AnsibleJ2Vars(templar, globals_data, locals_data)
        for key in key_dict:
            ret = key in ansible_j2_vars
            assert ret == expected[key]

