

# Generated at 2022-06-11 17:24:10.140504
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = mock()
    gb = dict(hostvars=mock())
    loc = dict(test=mock())
    ajv = AnsibleJ2Vars(templar, gb, loc)
    assert ajv._templar is templar
    assert ajv._globals is gb
    assert ajv._locals is loc


# Generated at 2022-06-11 17:24:20.344452
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    # test with safe vars
    templar = Templar(loader=AnsibleLoader(None), variables={"my_dict": {"my_key": "my_value"}})
    env = Environment(extensions=['jinja2.ext.do', 'jinja2.ext.loopcontrols'], undefined=AnsibleUndefinedVariable)
    vars = AnsibleJ2Vars(templar, env.globals)
    vars["my_dict"]["my_key"] == "my_value"
    # test with unsafe vars

# Generated at 2022-06-11 17:24:21.488259
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass


# Generated at 2022-06-11 17:24:27.116742
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    t = Templar(loader=None, variables={'a':1})
    vars = AnsibleJ2Vars(templar=t, globals={})
    assert 'a' in vars
    assert 'b' not in vars
    assert 'c' not in vars


# Generated at 2022-06-11 17:24:28.489012
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # should return True
    assert True



# Generated at 2022-06-11 17:24:29.840770
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    assert True


# Generated at 2022-06-11 17:24:39.577134
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2
    from ansible.template import Templar
    templar = Templar(loader=None)
    j2_vars = AnsibleJ2Vars(templar, {}, locals={'l_joe': 'one', 'l_foo': 'bar', 'l_py': jinja2.Undefined})
    assert len(j2_vars) == 4
    assert 'joe' in j2_vars
    assert 'foo' in j2_vars
    assert 'py' in j2_vars
    assert 'py_class' in j2_vars
    assert j2_vars['joe'] == 'one'
    assert j2_vars['foo'] == 'bar'
    assert j2_vars['py'] == jinja2.Undefined
    assert j2

# Generated at 2022-06-11 17:24:50.152738
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible import templar
    from ansible.template import Templar

    class MyVarsModule(object):
        def get_vars(self, loader, path, entities):
            return dict(foo="bar", baz="qux")

    env_kwargs = dict(
        variable_start_string='[%',
        variable_end_string='%]',
        trim_blocks=True,
        lstrip_blocks=True,
    )

    tmplar = Templar(loader=None, variables=None, environment=None, env_kwargs=env_kwargs)
    tmplar._add_host_vars_from_dir(path="foobar", add_file_vars=True, use_cache=False)

# Generated at 2022-06-11 17:25:00.101710
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    host_vars_dict = dict()
    host_vars_dict['k1'] = 'v1'
    host_vars_dict['k2'] = AnsibleUnsafeText('v2')
    host_vars = HostVars(host_vars_dict)
    global_vars = dict()
    global_vars['k3'] = 'v3'
    global_vars['k4'] = AnsibleUnsafeText('v4')
    templar = Templar(basedir=None, variables=dict())
    locals = dict()
    locals['k5'] = 'v5'
    locals['k6'] = Ans

# Generated at 2022-06-11 17:25:00.650810
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert True

# Generated at 2022-06-11 17:25:12.311012
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import combine_vars

    templar = Templar(loader=None, variables=combine_vars(loader=None, variables=dict(foo='FOO')))

    assert 'foo' in AnsibleJ2Vars(templar, dict(bar='BAR'))
    assert 'bar' in AnsibleJ2Vars(templar, dict(bar='BAR'))
    assert 'CUSTOMVAR' not in AnsibleJ2Vars(templar, dict(bar='BAR'))



# Generated at 2022-06-11 17:25:22.474385
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # First, define a templar object
    from ansible.template import Templar
    templar = Templar()

    # Define some variables
    locals = {
        'bar': 'baz',
        'zaz': 'zaa',
        'a': 'b',
        'c': 'd',
        'x': 'y'
    }

    globals = {
        'a': 'b',
        'c': 'd',
        'x': 'y'
    }

    # Initialize the object
    myobj = AnsibleJ2Vars(templar, globals, locals)

    # Try out the method

# Generated at 2022-06-11 17:25:27.873716
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():    
    # Create AnsibleJ2Vars object
    templar = dict()
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Verify the length of the AnsibleJ2Vars class
    assert len(ansible_j2_vars) == 0

# Generated at 2022-06-11 17:25:28.639275
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-11 17:25:37.748730
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    inventory = DataLoader()
    context = PlayContext()
    context.CLIARGS = {}

    vm = VariableManager()
    vm.set_inventory(inventory)
    vm.set_loader(inventory)
    vm.set_globals(inventory.get_basedir())
    vm.set_environment(inventory.get_basedir())

    templar = Templar(loader=inventory, variables=vm, shared_loader_obj=inventory)

    my_dict = {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-11 17:25:47.388916
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    env = Environment()
    env.loader = loader

    t = Templar(loader=loader, variables={'a': 1, 'b': 2, 'c': 3}, env=env)
    aj2v = AnsibleJ2Vars(t, globals={'z': 26})
    keys = sorted(list(aj2v.keys()))
    assert keys == ['a', 'b', 'c', 'z']



# Generated at 2022-06-11 17:25:58.312153
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name = "Ansible Play J2Vars test",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{unixtime}}')))
         ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-11 17:26:01.882803
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = object()
    globals = {"a": 1, "b": 2, "c": 3}
    vars = AnsibleJ2Vars(templar, globals)
    for k in globals:
        assert k in vars
    assert "d" not in vars


# Generated at 2022-06-11 17:26:10.598082
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.template
    templar = ansible.template.AnsibleJ2Template(None, dict())
    globals = dict()
    locals = None
    ajv = AnsibleJ2Vars(templar, globals, locals)
    # basic test
    ajv['a'] = 'b'
    assert ajv['a'] == 'b'
    # Exception test
    ajv['a'] = '{{ b }}'
    try:
        ajv['a']
        assert False, 'should raise an exception'
    except AnsibleError as e:
        assert e.args[0] == "An unhandled exception occurred while templating '{{ b }}'. Error was a ansible.errors.AnsibleUndefinedVariable, original message: 'b' is undefined"
    # test null
   

# Generated at 2022-06-11 17:26:21.306622
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    context = PlayContext()

    loader = DataLoader()

    templar = Templar(loader=loader, variables=dict())

    vars_obj = AnsibleJ2Vars(templar, dict(a=1, b=3, c=2))

    assert 'a' in vars_obj
    assert 'b' in vars_obj
    assert 'c' in vars_obj

    assert 'a' in set(vars_obj)
    assert 'b' in set(vars_obj)
    assert 'c' in set(vars_obj)


# Generated at 2022-06-11 17:26:32.458550
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class Templar:
        def __init__(self):
            self.available_variables = ['test']
    templar = Templar()
    vars = AnsibleJ2Vars(templar, {'globals': 'globals'}, {'locals': 'locals'})
    assert set(vars) == set(['test', 'globals', 'locals'])

# Generated at 2022-06-11 17:26:43.355423
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible import constants as C
    from ansible.template import Templar

    # Create an AnsibleJ2Vars which contains one scalar variable
    templar = Templar(variables={'a': 'b'})
    j2_vars = AnsibleJ2Vars(templar, C.__dict__)
    assert j2_vars['a'] == 'b'

    # Create an AnsibleJ2Vars which contains one scalar variable and also one ansible variable
    templar = Templar(variables={'a': 'b', 'c': 123})
    j2_vars = AnsibleJ2Vars(templar, C.__dict__)
    assert j2_vars['a'] == 'b'
    assert j2_vars['c'] == 123

    # Create an AnsibleJ2

# Generated at 2022-06-11 17:26:44.394887
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass


# Generated at 2022-06-11 17:26:51.119925
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars

    assert isinstance({'a': 1, 'b': 2}['a'], int)
    assert isinstance(HostVars({'a': 1, 'b': 2})['a'], int)

    def test_func(x):
        return x

    assert test_func('abc') == 'abc'

# Generated at 2022-06-11 17:27:00.997256
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2

    env = jinja2.Environment()

    vars = [
        ('v1', 'a'),
        ('v2', 'b'),
        ('v3', {'k_v31': 'x', 'k_v32': 'y'}),
        ('v4', {'k_v41': {'k_v411': 'z'}})
    ]
    vars_dict = dict(vars)
    template = env.from_string('{{ v1 }} {{ v2 }} {{ v3["k_v31"] }} {{ v3["k_v32"] }} {{ v4["k_v41"]["k_v411"] }}')
    ansible_vars = AnsibleJ2Vars(template, vars_dict)

    assert len(ansible_vars) == 4

# Generated at 2022-06-11 17:27:12.644848
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar()
    globals = dict(a=1, b=2)
    locals = dict(c=3, d=4)
    AnsibleJ2Vars_ins = AnsibleJ2Vars(templar, globals, locals)

    # case 1: expect: get value
    assert AnsibleJ2Vars_ins.__getitem__('c') == 3
    assert AnsibleJ2Vars_ins.__getitem__('a') == 1

    # case 2: expect: get value
    assert AnsibleJ2Vars_ins.__getitem__('b')

# Generated at 2022-06-11 17:27:20.398556
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = Templar(loader=None, variables={})
    globals = {}
    locals = {}

    j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2_vars.__getitem__('foo') == None
    assert j2_vars.__getitem__('foo') == None

    templar = Templar(loader=None, variables={'foo': 123})
    j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2_vars.__getitem__('foo') == 123
    assert j2_vars.__getitem__('foo') == 123

    templar = Templar(loader=None, variables={'foo': '{{ bar }}'})

# Generated at 2022-06-11 17:27:30.663136
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # The contructor for AnsibleJ2Vars() takes three parameters:
    # templar, globals and locals.
    # The first parameter 'templar' is not None type, while the two
    # others are dict of dict.
    # In order to test the contructor, we setup some dummy data on
    # these types.
    # If a test fails, please fix that case first.
    VALID_TYPES = {
        'templar': dict(),
        'globals': dict(),
        'locals': dict(),
        'locals - list': list(),
        'locals - tuple': tuple(),
    }

# Generated at 2022-06-11 17:27:41.750590
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    result_success={"success": True}
    result_failure={"success": False}

    from ansible.template import Templar

    dummy_variables = {}
    dummy_templar = Templar(loader=None, variables=dummy_variables)
    tmp_obj = AnsibleJ2Vars(templar=dummy_templar, globals=dummy_variables, locals=dummy_variables)
    result = None
    try:
        "success" in tmp_obj
        result = result_success
    except:
        result = result_failure
    assert result["success"] is True, "Failed to test AnsibleJ2Vars.__contains__(): expected True, but got False"


# Generated at 2022-06-11 17:27:46.189888
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    import pytest

    templar = Templar(loader=None)
    templar._available_variables = {"var1":"aaa"}

    ansible_j2_vars = AnsibleJ2Vars(templar, {})

    assert ansible_j2_vars["var1"] == "aaa"
    assert ansible_j2_vars["undefined_var"] is None

# Generated at 2022-06-11 17:28:11.073791
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class DummyTemplar(object):
        available_variables = {'v1': '{{x}} {{y}}', 'v2': '{{x}}', 'v3': '{{y}}', 'v4': AnsibleUnsafeText('some unsafe text')}

        def template(self, variable):
            return variable

    test_vars = {
        'x': 'x1',
        'y': 'y1'
    }

    test_globals = {
        'global_x': 'global_x1',
        'global_y': 'global_y1'
    }


# Generated at 2022-06-11 17:28:23.108228
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible import plugins, module_utils
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.plugins.lookup import LookupBase
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import merge_hash
    from ansible.vars.hostvars import HostVars

    class FakeAnsibleHost(object):
        def __init__(self, get_vars_result):
            self.get_vars_result = get_vars_result
            self.vars = {}

        def get_vars(self):
            return self.get_vars_result

    fake_host = FakeAnsibleHost({'a': 1, 'b': 2, 'c': 3})
    fake_

# Generated at 2022-06-11 17:28:32.817947
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os
    import sys
    sys.path.append(os.path.dirname(__file__))
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = {}

    def test(varname):
        return AnsibleJ2Vars(templar, globals).__getitem__(varname)

    # scalars
    assert to_native(test('ansible_default_ipv4')) == u"ansible_default_ipv4"
    assert to_native(test('ansible_default_ipv4.address')) == u"ansible_default_ipv4.address"

    # hostvars
    assert to_native(test('inventory_hostname')) == u"inventory_hostname"

# Generated at 2022-06-11 17:28:42.503779
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import os
    import sys

    sys.path = [os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..')] + sys.path

    import unittest

    import ansible.template

    class TestAnsibleJ2Vars(unittest.TestCase):
        def test_AnsibleJ2Vars___contains__(self):
            templar = ansible.template.AnsibleJ2Vars(env=dict())

            self.assertTrue('loop' in ansible.template.AnsibleJ2Vars(templar, globals=dict()))

            vars_with_loop = dict()
            vars_with_loop['loop'] = 'loop'

# Generated at 2022-06-11 17:28:53.573500
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager(loader=None)
    variable_manager.set_globals({'var1': 'value1'})
    variable_manager.set_host_variable('127.0.0.1', 'var2', 'value2')
    variable_manager.set_host_variable('127.0.0.1', 'var3', {'var3_key': 'value3'})
    variable_manager.set_host_variable('127.0.0.1', 'var4', ['value4'])
    variable_manager.set_host_variable('127.0.0.1', 'var5', None)
    variable_manager.set_host

# Generated at 2022-06-11 17:29:00.572943
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.template import Templar
    templar = Templar(loader=None)
    globals = {"foo": "bar"}
    locals = {"l_baz": "foo"}

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert "foo" in vars
    assert "baz" not in vars
    assert vars["foo"] == "bar"
    assert vars["baz"] == "foo"

# Generated at 2022-06-11 17:29:09.974560
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    templar = Templar(loader=DataLoader(), variables=VariableManager(loader=DataLoader()),
                      shared_loader_obj=DataLoader())
    # Test with a simple var.
    globals = dict(debug=True)
    locals = dict()
    var_proxy = AnsibleJ2Vars(templar, globals, locals)
    assert 'debug' in var_proxy, 'var_proxy must contain "debug"'
   

# Generated at 2022-06-11 17:29:22.175109
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.vault import VaultAwareParameter

    vault_secret = VaultSecret(value='test secret', vault_id='test vault')
    vault_secret.__UNSAFE__ = True

    # Create fake dictionary of variable
    avail_vars = dict(vault_secret=vault_secret,
                      string="this is a string",
                      int=1234,
                      float=12.34,
                      boolean=True,
                      list=['one', 'two', 'three'],
                      dict={'key1': 'value1', 'key2': 'value2'})

    # Create

# Generated at 2022-06-11 17:29:23.232332
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
	assert False, "No implemented yet"


# Generated at 2022-06-11 17:29:32.196939
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var
    import pytest
    templar = Templar(loader=None, variables={'var1': {}, 'var2': True, 'var3': None, 'var4': wrap_var('var4')})
    pytest.raises(KeyError, lambda: AnsibleJ2Vars(templar, {})['var5'])
    assert AnsibleJ2Vars(templar, {})['var1'] == {}
    assert AnsibleJ2Vars(templar, {})['var2'] is True
    assert AnsibleJ2Vars(templar, {})['var3'] is None

# Generated at 2022-06-11 17:30:33.873745
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible import constants as C
    # test with available variables
    templar = Templar(loader=None, variables={'first': 'string'})
    assert AnsibleJ2Vars(templar, {}, {}).__contains__('first')
    # test contains with self._locals
    assert AnsibleJ2Vars(templar, {}, {'second': 'string'}).__contains__('second')
    # test contains with self._globals
    assert AnsibleJ2Vars(templar, {'third': 'string'}, {}).__contains__('third')
    # test contains with self._templar.available_variables

# Generated at 2022-06-11 17:30:43.887670
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar(key1='value1')
    j2vars = AnsibleJ2Vars(templar, globals)

    assert 'key1' in j2vars
    assert 'key2' not in j2vars

    templar = Templar(key1='value1', key2='value2')
    j2vars = AnsibleJ2Vars(templar, globals)

    assert 'key1' in j2vars
    assert 'key2' in j2vars
    assert 'key3' not in j2vars

    templar = Templar(key1='value1', key2='value2')
    j2vars = AnsibleJ2Vars(templar, globals, locals={'key3': 'value3'})



# Generated at 2022-06-11 17:30:55.393571
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.unsafe_proxy import wrap_var
    import jinja2
    import jinja2.sandbox
    from ansible.parsing.vault import VaultLib
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar


# Generated at 2022-06-11 17:31:06.773233
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # prepare args
    templar = None
    globals = {'g1': 'g1'}
    locals = {'l1': 'l1'}
    # create instance
    ajv = AnsibleJ2Vars(templar, globals, locals)

    # test 1
    assert 'g1' in ajv, '"g1" not in AnsibleJ2Vars instance'

    # test 2
    assert 'l1' in ajv, '"l1" not in AnsibleJ2Vars instance'

    # test 3
    assert 'g2' not in ajv, '"g2" in AnsibleJ2Vars instance'

    # test 4
    assert 'l2' not in ajv, '"l2" in AnsibleJ2Vars instance'

# Unit

# Generated at 2022-06-11 17:31:15.388583
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars

    # check for all values are expected
    hostname = 'localhost'
    inventory = []
    templar = []
    variables = HostVars(inventory=inventory)
    globals = {}
    locals = {}

    ansible_j2_vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)

    # No 'main.yml' in group_vars or host_vars
    # ansible/playbooks/vars/main.yml not exists
    # No dynamc group vars
    # hostname in group all
    variables.update([], [], hostname)
    variables.update(ansible_j2_vars, hostname)


# Generated at 2022-06-11 17:31:21.319483
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """
    Test of the method __contains__ of AnsibleJ2Vars class.
    """

    # TODO(Ramy): Add stubs for AnsibleJ2Vars and Templar instead of mocked objects
    AnsibleJ2Vars.__contains__(None, 'fake_var_name')
    AnsibleJ2Vars.__contains__(None, 'l_fake_local_var_name')

# Generated at 2022-06-11 17:31:32.116066
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import ansible.vars.hostvars as hostvars
    import jinja2.runtime
    import pytest

    # Arrange
    templar = AnsibleJ2Vars(templar=None, globals={}, locals={})

    # Act
    # Assert
    assert 'vars' in templar
    assert 'facts' in templar
    assert 'hostvars' in templar
    assert 'group_names' in templar
    assert 'groups' in templar
    assert 'playbook_dir' in templar
    assert 'playbook_file' in templar

# Generated at 2022-06-11 17:31:36.084356
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = None
    locals = None
    ans = AnsibleJ2Vars(templar, globals, locals)
    actual = iter(ans)
    assert actual is not None


# Generated at 2022-06-11 17:31:45.145875
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = type(str('Templar'),(object,),{'available_variables':{'var1':'var1_value'}})()
    globals = {'globals_var':'globals_value'}
    locals = {'locals_var':'locals_value'}

    # check if undefined variable is not present
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert('undefined_var' not in j2vars)

    # check if variable present in locals dict is present
    assert('locals_var' in j2vars)

    # check if variable present in templar.available_variables is present
    assert('var1' in j2vars)

    # check if variable present in globals dict is present
   

# Generated at 2022-06-11 17:31:49.117798
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    t = Templar("", {})
    a = AnsibleJ2Vars(t, {"globals": True})
    assert a["globals"] is True
    assert "globals" in a


# Generated at 2022-06-11 17:33:10.703589
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    context = PlayContext()

    variable_manager.extra_vars = { 'test_len_key1': 'test_len_value1' }
    variable_manager.host_vars = { 'test_len_host': { 'test_len_key2': 'test_len_value2' } }
    variable_manager.group_vars_files = [ './test/units/vars_files/group_vars' ]

# Generated at 2022-06-11 17:33:20.784608
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.parsing.yaml.objects
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import Variables
    from ansible.module_utils.common._collections_compat import MutableMapping

    templar = Templar(loader=None, variables=Variables(loader=None, play=PlayContext()))
    globals = HostVars(loader=None, play=None)
    locals = {'key1': 'value1', 'key2': 'value2'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert(isinstance(ajv['key1'], str))

# Generated at 2022-06-11 17:33:25.197252
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar()
    ansible_vars = {'a': '1'}

    v = AnsibleJ2Vars(templar, {})
    assert 'a' not in v

    v = AnsibleJ2Vars(templar, ansible_vars)
    assert 'a' in v


# Generated at 2022-06-11 17:33:35.886809
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    variable_manager = VariableManager()
    vault_secrets = VaultLib([], auto_prompt=True)
    loader = jinja2.FileSystemLoader('/etc/ansible/playbooks')
    jinja2_environment = jinja2.Environment(loader=loader)
    vault_secrets = VaultLib([], auto_prompt=True)
    templar = Templar(loader=loader, variables=variable_manager, vault_secrets=vault_secrets)

# Generated at 2022-06-11 17:33:41.393257
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    templar = Templar(loader=None, variables=variable_manager)
    vars = AnsibleJ2Vars(templar, {}, {})
    assert vars['foo'] == 'bar'

# Generated at 2022-06-11 17:33:48.100848
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import safe_eval
    ansible_j2_vars_instance = AnsibleJ2Vars(safe_eval, {})
    ansible_j2_vars_instance.add_locals({'a': 1, 'b': 2})
    assert set(ansible_j2_vars_instance.__iter__()) == set(['a', 'b'])


# Generated at 2022-06-11 17:33:57.485846
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    ansible_vars = {}
    ansible_vars['ansible_connection'] = 'local'
    ansible_vars['ansible_host'] = 'localhost'
    ansible_vars['groups'] = {}
    ansible_vars['groups']['all'] = ['localhost']
    ansible_vars['groups']['example_group'] = ['localhost']

    inject_vars = {}

    templar = Templar(loader=None, variables=ansible_vars, inject=inject_vars)
    j2vars = AnsibleJ2Vars(templar, {}, {})

    assert(j2vars.__contains__('ansible_connection'))