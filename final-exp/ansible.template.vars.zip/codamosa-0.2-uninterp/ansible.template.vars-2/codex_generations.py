

# Generated at 2022-06-17 14:32:53.468014
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_var': 'g_value'}
    locals = {'l_var': 'l_value'}
    vars = {'v_var': 'v_value'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['g_var'] == 'g_value'
    assert ansible_j2_vars['l_var'] == 'l_value'
    assert ansible_j2_v

# Generated at 2022-06-17 14:33:05.004539
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_bar': 'foo'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['bar'] == 'foo'
    assert vars['l_bar'] == 'foo'
    assert vars['l_foo'] == 'bar'
    assert vars['l_foo'] == 'bar'
    assert vars['l_bar'] == 'foo'
    assert vars['l_bar'] == 'foo'
    assert vars['l_bar'] == 'foo'

# Generated at 2022-06-17 14:33:12.273334
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4
    vars._templar.available_variables = {'e': 5, 'f': 6}
    assert len(vars) == 6
    vars._templar.available_variables = {'a': 7, 'b': 8}
    assert len(vars) == 6
    vars._templar.available_vari

# Generated at 2022-06-17 14:33:18.887304
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_a': 1, 'g_b': 2}
    locals = {'l_a': 3, 'l_b': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g_a', 'g_b', 'l_a', 'l_b'])


# Generated at 2022-06-17 14:33:23.761629
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'a': 1, 'b': 2})
    globals = {'c': 3, 'd': 4}
    locals = {'e': 5, 'f': 6}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['a', 'b', 'c', 'd', 'e', 'f'])


# Generated at 2022-06-17 14:33:34.599812
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    available_variables = {'a1': 'a1', 'a2': 'a2'}
    templar._available_variables = available_variables
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)


# Generated at 2022-06-17 14:33:40.105003
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookupVal
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironmentVariable
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja2Template
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja2Text

# Generated at 2022-06-17 14:33:50.340813
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateSnippet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:34:01.377079
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt


# Generated at 2022-06-17 14:34:12.802262
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test_global'] == 'test_global_value'
    assert ansible_j2_vars['test_local'] == 'test_local_value'
    templar.available_variables = {'test_available_variable': 'test_available_variable_value'}

# Generated at 2022-06-17 14:34:24.584619
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])
    assert set(vars.keys()) == set(['g1', 'g2', 'l1', 'l2'])
    assert set(vars.values()) == set(['g1', 'g2', 'l1', 'l2'])

# Generated at 2022-06-17 14:34:32.786487
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    proxy = AnsibleJ2Vars(templar, globals, locals)
    assert proxy['foo'] == 'bar'
    assert proxy['baz'] == 'qux'
    assert 'foo' in proxy
    assert 'baz' in proxy
    assert 'quux' not in proxy
    assert len(proxy) == 2
    assert list(proxy) == ['foo', 'baz']

# Generated at 2022-06-17 14:34:45.076503
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'fizz': 'buzz'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test if __getitem__ returns the expected value
    assert vars['foo'] == 'bar'
    assert vars['fizz'] == 'buzz'

    # test if __getitem__ raises the expected exception

# Generated at 2022-06-17 14:34:55.487942
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # Create a dummy inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a dummy templar
    templar = Templar(loader=loader, variables=variable_manager)

    # Create a dummy globals
    globals = {'foo': 'bar'}

    # Create a dummy locals
    locals = {'baz': 'qux'}



# Generated at 2022-06-17 14:35:04.969865
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # test for undefined variable
    try:
        ansible_j2_vars['undefined_variable']
    except KeyError as e:
        assert str(e) == "undefined variable: undefined_variable"
    else:
        assert False

    # test for variable in locals

# Generated at 2022-06-17 14:35:13.423476
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in ajv
    assert 'l_foo' in ajv
    assert 'foo' not in ajv


# Generated at 2022-06-17 14:35:25.361111
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'a': 1, 'b': 2})
    globals = {'c': 3, 'd': 4}
    locals = {'e': 5, 'f': 6}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['a', 'b', 'c', 'd', 'e', 'f'])
    assert set(vars.keys()) == set(['a', 'b', 'c', 'd', 'e', 'f'])
    assert set(vars.values()) == set([1, 2, 3, 4, 5, 6])
    assert set(vars.items()) == set

# Generated at 2022-06-17 14:35:33.694990
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['quux'] == AnsibleUnicode('quux')

# Generated at 2022-06-17 14:35:45.194260
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_var': 'g_value'}
    locals = {'l_var': 'l_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_var' in vars
    assert 'l_var' in vars
    assert 'h_var' not in vars
    templar.available_variables = {'h_var': HostVars(loader=None, variables={'h_var': 'h_value'})}
    assert 'h_var' in vars


# Generated at 2022-06-17 14:35:52.976107
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars'].__UNSAFE__

# Generated at 2022-06-17 14:36:07.081031
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'g2' in vars
    assert 'l1' in vars
    assert 'l2' in vars
    assert 'g3' not in vars
    assert 'l3' not in vars


# Generated at 2022-06-17 14:36:18.974728
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 3
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' in vars
    assert 'bar' in vars
    assert 'quux' not in vars
    assert 'quuz' not in vars
    assert 'corge' not in vars
    assert 'grault' not in vars

# Generated at 2022-06-17 14:36:28.573074
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 14:36:36.873159
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 0
    locals = dict(a=1)
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 1
    globals = dict(b=2)
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 2
    templar.available_variables = dict(c=3)
    j2vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:36:44.686378
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafePromptPassword
    from ansible.vars.unsafe_proxy import AnsibleUnsafePromptPrivateKey
    from ansible.vars.unsafe_proxy import AnsibleUnsafePromptYesNo

# Generated at 2022-06-17 14:36:52.473705
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

# Generated at 2022-06-17 14:37:00.036600
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test global variable
    assert vars['foo'] == 'bar'

    # test local variable
    assert vars['baz'] == 'qux'

    # test undefined variable
    try:
        vars['undefined']
        assert False, "AnsibleUndefinedVariable should be raised"
    except AnsibleUndefinedVariable:
        pass

    # test HostVars

# Generated at 2022-06-17 14:37:08.929313
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.hostvars import HostVars
    import os
    import json

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-17 14:37:16.218158
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'l_d': 4, 'l_e': 5, 'l_f': 6}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 6
    assert len(vars) == len(globals) + len(locals)


# Generated at 2022-06-17 14:37:27.234504
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'A', 'b': 'B'}
    locals = {'c': 'C', 'd': 'D'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['a'] == 'A'
    assert j2vars['b'] == 'B'
    assert j2vars['c'] == 'C'
    assert j2vars['d'] == 'D'
    assert j2vars['e'] == 'E'
    assert j2vars['f'] == 'F'
    assert j2vars['g'] == 'G'
    assert j2

# Generated at 2022-06-17 14:37:40.556313
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList


# Generated at 2022-06-17 14:37:47.510117
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars


# Generated at 2022-06-17 14:37:59.216925
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVariable
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList


# Generated at 2022-06-17 14:38:09.150218
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['foo'] == 'bar'
    assert j2vars['baz'] == 'qux'
    assert j2vars['vars'] == templar.available_variables
    assert j2vars['hostvars'] == HostVars(templar._available_variables['hostvars'])
    assert j2vars['inventory_hostname'] == templar.available_variables['inventory_hostname']
    assert j

# Generated at 2022-06-17 14:38:14.262754
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {}
    locals = {}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['vars'] == {}

# Generated at 2022-06-17 14:38:21.630328
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_a': 1, 'g_b': 2}
    locals = {'l_a': 3, 'l_b': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert sorted(list(vars)) == ['g_a', 'g_b', 'l_a', 'l_b']


# Generated at 2022-06-17 14:38:32.428353
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 4
    j2vars._templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    assert len(j2vars) == 6

# Generated at 2022-06-17 14:38:41.183669
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'a': 'b'})
    globals = {'c': 'd'}
    locals = {'e': 'f'}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in aj2v
    assert 'b' not in aj2v
    assert 'c' in aj2v
    assert 'd' not in aj2v
    assert 'e' in aj2v
    assert 'f' not in aj2v
    assert 'g' not in aj2v
    assert 'h' not in aj2v


# Generated at 2022-06-17 14:38:45.570978
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars


# Generated at 2022-06-17 14:38:50.071890
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars']['foo'] == 'bar'
    assert vars['vars']['baz'] == 'qux'
    assert vars.add_locals({'quux': 'quuz'})['quux'] == 'quuz'

# Generated at 2022-06-17 14:39:03.335256
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert set(j2vars) == set(['a', 'b', 'c', 'd'])

    # Test that AnsibleUnsafeText is not templated
    globals = {'a': AnsibleUnsafeText('{{b}}')}
    locals = {'b': 2}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert set(j2vars) == set

# Generated at 2022-06-17 14:39:12.142459
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables['vars']
    assert isinstance(vars['vars'], HostVars)

# Generated at 2022-06-17 14:39:18.088382
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ansible_j2_vars
    assert 'baz' in ansible_j2_vars
    assert 'qux' not in ansible_j2_vars


# Generated at 2022-06-17 14:39:28.859003
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var

    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test with locals
    assert vars['c'] == 'd'

    # test with available variables
    templar.available_variables = {'e': 'f'}
    assert vars['e'] == 'f'

    # test with glob

# Generated at 2022-06-17 14:39:39.365438
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone

    templar = Templar(loader=None)
    templar.available_

# Generated at 2022-06-17 14:39:50.045026
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_a': 'g_a'}
    locals = {'l_a': 'l_a'}
    vars = {'a': 'a'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in ansible_j2_vars
    assert 'l_a' in ansible_j2_vars
    assert 'g_a' in ansible_j2_vars
    assert 'b' not in ansible_j2_vars
    assert 'l_b' not in ansible

# Generated at 2022-06-17 14:39:57.300801
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_a': 1, 'g_b': 2}
    locals = {'l_a': 3, 'l_b': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g_a', 'g_b', 'l_a', 'l_b'])


# Generated at 2022-06-17 14:40:05.771504
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars
    assert 'f' not in vars


# Generated at 2022-06-17 14:40:16.944253
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g': 'g'}
    locals = {'l': 'l'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g' in vars
    assert 'l' in vars
    assert 'h' not in vars
    templar.available_variables = {'h': 'h'}
    assert 'h' in vars
    templar.available_variables = {'h': HostVars(loader=None, variables={'h': 'h'})}
    assert 'h' in vars


# Generated at 2022-06-17 14:40:27.728632
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_key1': 'g_val1', 'g_key2': 'g_val2'}
    locals = {'l_key1': 'l_val1', 'l_key2': 'l_val2'}
    templar.available_variables = {'a_key1': 'a_val1', 'a_key2': 'a_val2'}
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:40:40.146198
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2', 'v1', 'v2'])
    locals = {'l1': 'l1', 'l2': 'l2', 'l3': 'l3'}
   

# Generated at 2022-06-17 14:40:48.131188
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'a': 1, 'b': 2})
    globals = {'c': 3, 'd': 4}
    locals = {'e': 5, 'f': 6}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 6
    assert len(vars) == len(templar.available_variables) + len(globals) + len(locals)


# Generated at 2022-06-17 14:40:56.946567
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test_global'] == 'test_global_value'
    assert ansible_j2_vars['test_local'] == 'test_local_value'
    assert ansible_j2_vars['test_undefined'] == KeyError
    assert ansible_j2_vars['test_undefined'] == KeyError

# Generated at 2022-06-17 14:41:08.711085
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in j2vars
    templar.available_variables = dict(foo='bar')
    assert 'foo' in j2vars
    j2vars = AnsibleJ2Vars(templar, dict(foo='bar'), locals)
    assert 'foo' in j2vars
    j2vars = AnsibleJ2Vars(templar, globals, dict(foo='bar'))
    assert 'foo' in j2vars
    j2vars = AnsibleJ2

# Generated at 2022-06-17 14:41:14.002538
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'foo': 'baz'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'bar' not in vars


# Generated at 2022-06-17 14:41:23.542220
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global'}
    locals = {'test_local': 'test_local'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test_global' in ansible_j2_vars
    assert 'test_local' in ansible_j2_vars
    assert 'test_undefined' not in ansible_j2_vars
    templar.available_variables = {'test_available': 'test_available'}
    assert 'test_available'

# Generated at 2022-06-17 14:41:32.026303
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == 'b'
    assert ansible_j2_vars['c'] == 'd'
    assert ansible_j2_vars['vars'] == {}
    assert ansible_j2_vars['hostvars'] == {}
    assert ansible_j2_vars['groups'] == {}
    assert ansible_j2_vars['group_names'] == []
    assert ansible_

# Generated at 2022-06-17 14:41:39.700009
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars is not None

# Generated at 2022-06-17 14:41:45.267031
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:41:50.140468
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

# Generated at 2022-06-17 14:42:21.763488
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup

    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars

    templar.available_variables = {'foo': 'bar'}

# Generated at 2022-06-17 14:42:32.711134
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test with a variable defined in locals
    assert vars['baz'] == 'qux'

    # Test with a variable defined in globals
    assert vars['foo'] == 'bar'

    # Test with a variable defined in available_variables

# Generated at 2022-06-17 14:42:46.182177
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone

    templar = Templar(loader=None)
    globals = dict()
