

# Generated at 2022-06-17 14:32:54.187608
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_var': 'g_value'}
    locals = {'l_var': 'l_value'}
    vars = {'var': 'value'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_var' in ansible_j2_vars
    assert 'l_var' in ansible_j2_vars
    assert 'var' in ansible_j2_vars
    assert 'not_exist' not in ansible_j2_vars


# Generated at 2022-06-17 14:32:58.720148
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'c' in j2vars
    assert 'd' in j2vars
    assert 'e' not in j2vars


# Generated at 2022-06-17 14:33:01.844089
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars


# Generated at 2022-06-17 14:33:09.293361
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-17 14:33:20.215882
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'g_var': 'g_value'}
    locals = {'l_var': 'l_value'}
    vars = {'var': 'value'}
    templar._available_variables = vars

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # test if the variable is in locals
    assert ansible_j2_vars['l_var'] == 'l_value'

    # test if the variable

# Generated at 2022-06-17 14:33:26.588540
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in ansible_j2_vars
    assert 'b' in ansible_j2_vars
    assert 'c' in ansible_j2_vars
    assert 'd' in ansible_j2_vars
    assert 'e' not in ansible_j2_vars


# Generated at 2022-06-17 14:33:36.768739
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import jinja2
    import pytest

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Test if the key is in locals
    assert ansible_j2_vars['baz'] == 'qux'

    # Test if the key is in available_variables
    templar.available_variables = {'baz': 'qux'}

# Generated at 2022-06-17 14:33:42.942908
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=dict())

    # Test case 1:
    #   - varname is in self._locals
    #   - varname is in self._templar.available_variables
    #   - varname is in self._globals
    #   - variable is not a dict
    #   - variable is not a HostVars
    #   - variable is not a __UNSAFE__
    #   - variable is not a AnsibleUndefinedVariable
    #   - variable is not a Exception
    #   - variable is not a AnsibleError
   

# Generated at 2022-06-17 14:33:53.378569
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['vars'] == dict()
    assert ajv['hostvars'] == dict()
    assert ajv['groups'] == dict()
    assert ajv['group_names'] == list()
    assert ajv['inventory_hostname'] == ''
    assert ajv['inventory_hostname_short'] == ''
    assert ajv['playbook_dir'] == ''
    assert ajv['omit'] == 'omit'
    assert ajv['ansible_version'] == dict()
    assert ajv['ansible_play_hosts'] == list

# Generated at 2022-06-17 14:34:00.887297
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_var': 'g_value'}
    locals = {'l_var': 'l_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['g_var'] == 'g_value'
    assert vars['l_var'] == 'l_value'
    assert vars['vars'] == templar.available_variables['vars']
    assert vars['hostvars'] == templar.available_variables['hostvars']
    assert vars['group_names'] == templar.available_variables['group_names']

# Generated at 2022-06-17 14:34:10.448105
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in j2vars
    assert 'baz' in j2vars
    assert 'quux' not in j2vars


# Generated at 2022-06-17 14:34:20.186876
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    import os
    import sys
    import json
    import yaml
    import unittest


# Generated at 2022-06-17 14:34:27.781996
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars


# Generated at 2022-06-17 14:34:33.805595
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in j2vars
    assert 'baz' in j2vars
    assert 'quux' not in j2vars


# Generated at 2022-06-17 14:34:45.276006
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict


# Generated at 2022-06-17 14:34:55.597641
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert j2vars['foo'] == 'bar'
    assert j2vars['l_baz'] == 'qux'

    templar.available_variables = {'baz': 'qux'}


# Generated at 2022-06-17 14:35:05.028628
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeSet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBool
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt


# Generated at 2022-06-17 14:35:16.784551
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 0
    globals['a'] = 'b'
    assert len(ansible_j2_vars) == 1
    locals['c'] = 'd'
    assert len(ansible_j2_vars) == 2
    templar.available_variables = dict()
    templar.available_variables['e'] = 'f'
    assert len(ansible_j2_vars) == 3
    templar.available_variables['g'] = 'h'

# Generated at 2022-06-17 14:35:25.534781
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {'a': 1, 'b': 2}
    locals = {'l_c': 3, 'l_d': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'c' in j2vars
    assert 'd' in j2vars
    assert 'e' not in j2vars


# Generated at 2022-06-17 14:35:36.612830
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.set_available_variables({'foo': 'bar'})
    assert 'foo' in vars
    templar.set_available_variables({'foo': HostVars()})
    assert 'foo' in vars

# Generated at 2022-06-17 14:35:52.824069
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'g_bar'}
    locals = {'l_foo': 'l_bar'}
    vars = {'foo': 'bar'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ansible_j2_vars
    assert 'l_foo' in ansible_j2_vars
    assert 'g_foo' in ansible_j2_vars
    assert 'bar' not in ansible_j2_vars
    assert 'l_bar' not in ansible

# Generated at 2022-06-17 14:36:01.795715
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'

# Generated at 2022-06-17 14:36:08.203208
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['a', 'b', 'c', 'd'])


# Generated at 2022-06-17 14:36:19.509483
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateSnippet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:36:27.029873
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:36:33.523487
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'bar': 'baz'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ansible_j2_vars
    assert 'bar' in ansible_j2_vars
    assert 'baz' not in ansible_j2_vars


# Generated at 2022-06-17 14:36:38.553947
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:36:46.454130
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt


# Generated at 2022-06-17 14:36:57.441948
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_key': 'g_value'}
    locals = {'l_key': 'l_value'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_key' in j2vars
    assert 'l_key' in j2vars
    assert 'key' not in j2vars
    templar.available_variables = {'key': 'value'}
    assert 'key' in j2vars

# Generated at 2022-06-17 14:37:06.600103
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in ansible_j2_vars
    locals['foo'] = 'bar'
    assert 'foo' in ansible_j2_vars
    globals['foo'] = 'bar'
    assert 'foo' in ansible_j2_vars
    templar.available_variables['foo'] = 'bar'
    assert 'foo' in ansible_j2_vars


# Generated at 2022-06-17 14:37:18.367051
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars']['foo'] == 'bar'
    assert vars['vars']['baz'] == 'qux'

# Generated at 2022-06-17 14:37:28.239665
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeValue
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTuple

# Generated at 2022-06-17 14:37:38.992326
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars
    templar

# Generated at 2022-06-17 14:37:49.275990
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert len(ajv) == 3
    templar.available_variables = {'foo': 'bar'}
    assert len(ajv) == 3
    templar.available_variables = {'foo': 'bar', 'baz': 'qux'}
    assert len(ajv) == 3
    templar.available_variables = {'foo': 'bar', 'baz': 'qux', 'quux': 'quuz'}

# Generated at 2022-06-17 14:38:01.044850
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFile
   

# Generated at 2022-06-17 14:38:10.385215
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with locals
    locals['test'] = 'test'
    assert vars['test'] == 'test'

    # test __getitem__ with available_variables
    templar.available_variables = {'test': 'test'}
    assert vars['test'] == 'test'

    # test __getitem__ with globals
    globals['test'] = 'test'
    assert vars['test'] == 'test'

# Generated at 2022-06-17 14:38:21.845596
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}

# Generated at 2022-06-17 14:38:32.850375
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test': 'test'}
    locals = {'test': 'test'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['test'] == 'test'
    assert ajv['test'] == 'test'
    assert ajv['test'] == 'test'
    assert ajv['test'] == 'test'
    assert ajv['test'] == 'test'
    assert ajv['test'] == 'test'
    assert ajv['test'] == 'test'
    assert ajv['test'] == 'test'

# Generated at 2022-06-17 14:38:41.450698
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateDebug
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-17 14:38:52.282352
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:39:02.012340
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}


# Generated at 2022-06-17 14:39:13.029798
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables
    assert vars['hostvars'] == HostVars(templar)
    assert vars['inventory_hostname'] == templar.available_variables['inventory_hostname']

# Generated at 2022-06-17 14:39:20.532315
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars(loader=None, variables={'foo': 'bar'})}
    assert 'foo' in vars


# Generated at 2022-06-17 14:39:30.111618
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_var': 'g_value'}
    locals = {'l_var': 'l_value'}
    vars = {'v_var': 'v_value'}
    templar._available_variables = vars
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_var' in ajv
    assert 'l_var' in ajv
    assert 'v_var' in ajv
    assert 'g_var_' not in ajv
    assert 'l_var_' not in ajv
    assert 'v_var_' not in ajv

# Generated at 2022-06-17 14:39:39.813409
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeRoleParameters
    from ansible.vars.unsafe_proxy import AnsibleUnsafeRoleDefaults
    from ansible.vars.unsafe_proxy import Ansible

# Generated at 2022-06-17 14:39:50.356965
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFile
   

# Generated at 2022-06-17 14:39:59.995217
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['vars'] == templar.available_variables
    assert ajv['hostvars'] == HostVars(templar, templar.available_variables)

# Generated at 2022-06-17 14:40:09.085976
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_a': 1, 'g_b': 2, 'g_c': 3}
    locals = {'l_a': 1, 'l_b': 2, 'l_c': 3}
    vars = {'a': 1, 'b': 2, 'c': 3}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:40:13.981606
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 2


# Generated at 2022-06-17 14:40:21.451714
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml

    # Test case 1: variable is in locals
    locals = {'foo': 'bar'}
    templar = Templar(loader=None)
    globals = {}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_v

# Generated at 2022-06-17 14:40:32.768429
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['undefined'] == KeyError

# Generated at 2022-06-17 14:40:42.682811
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['foo'] == 'bar'
    assert j2vars['baz'] == 'qux'
    assert j2vars['undefined'] == KeyError

# Generated at 2022-06-17 14:40:53.042073
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInteger


# Generated at 2022-06-17 14:40:59.603888
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # test for local variable
    assert j2vars['l_foo'] == 'bar'

    # test for global variable
    assert j2vars['g_foo'] == 'bar'

    # test for variable in templar
    templar.available_variables = {'foo': 'bar'}
    assert j2vars['foo'] == 'bar'

    #

# Generated at 2022-06-17 14:41:06.468246
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['undefined'] == KeyError

# Generated at 2022-06-17 14:41:14.518273
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBool
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt



# Generated at 2022-06-17 14:41:23.754666
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 14:41:32.171732
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:41:45.474673
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 14:41:54.691382
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['a'] == 'b'
    assert ajv['c'] == 'd'
    assert ajv['vars'] == templar.available_variables['vars']
    assert ajv['hostvars'] == templar.available_variables['hostvars']
    assert ajv['inventory_hostname'] == templar.available_variables['inventory_hostname']
    assert ajv['groups'] == templar.available

# Generated at 2022-06-17 14:42:12.662003
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt


# Generated at 2022-06-17 14:42:20.342774
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert len(ajv) == 3
    locals = {'baz': 'qux', 'quux': 'quuz'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert len(ajv) == 4
    globals = {'foo': 'bar', 'corge': 'grault'}
    ajv = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:42:28.621558
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['vars'] == templar.available_variables
    assert ajv['hostvars'] == HostVars(templar._available_variables['hostvars'])
    assert ajv['hostvars']['localhost'] == templar._available_variables['hostvars']['localhost']
   

# Generated at 2022-06-17 14:42:39.434891
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_a': 1, 'g_b': 2}
    locals = {'l_a': 3, 'l_b': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_a' in vars
    assert 'g_b' in vars
    assert 'l_a' in vars
    assert 'l_b' in vars
    assert 'a' not in vars
    assert 'b' not in vars
    assert 'c' not in vars
    assert 'd' not in vars
    assert 'e' not in vars
    assert 'f' not in v

# Generated at 2022-06-17 14:42:47.845927
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    available_variables = {'v1': 'v1', 'v2': 'v2'}
    templar.set_available_variables(available_variables)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 6
