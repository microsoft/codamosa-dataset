

# Generated at 2022-06-17 14:32:58.610302
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = {'v1': 'v1', 'v2': 'v2'}
    templar._available_variables = vars
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in ansible_vars
    assert 'g2' in ansible_vars
    assert 'l1' in ansible_vars
    assert 'l2' in ansible_vars

# Generated at 2022-06-17 14:33:05.906819
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 4
    assert len(j2vars) == len(globals) + len(locals)


# Generated at 2022-06-17 14:33:09.868392
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4


# Generated at 2022-06-17 14:33:20.319914
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == 1
    assert ansible_j2_vars['b'] == 2
    assert ansible_j2_vars['c'] == 3
    assert ansible_j2_vars['d'] == 4

# Generated at 2022-06-17 14:33:27.615053
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_bar': 'foo'}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert aj2v['foo'] == 'bar'
    assert aj2v['bar'] == 'foo'
    assert aj2v['vars'] == {'foo': 'bar', 'bar': 'foo'}
    assert isinstance(aj2v['vars'], HostVars)
    assert aj2v['vars']['foo'] == 'bar'
    assert aj2v['vars']['bar'] == 'foo'

# Generated at 2022-06-17 14:33:37.464440
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_var1': 'g_var1_value'}
    locals = {'l_var1': 'l_var1_value'}
    ansible_vars = {'var1': 'var1_value'}
    templar._available_variables = ansible_vars
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_var1' in ansible_j2vars
    assert 'l_var1' in ansible_j2vars
    assert 'var1' in ansible_j2vars

# Generated at 2022-06-17 14:33:48.363889
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['vars'] == vars
    assert vars['hostvars'] == vars
    assert vars['inventory_hostname'] == vars
    assert vars['groups'] == vars
    assert vars['group_names'] == vars
    assert vars['omit'] == vars
    assert vars['play_hosts'] == vars
    assert vars['playbook_dir'] == vars

# Generated at 2022-06-17 14:33:54.648376
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList


# Generated at 2022-06-17 14:34:01.536251
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': '1', 'b': '2'}
    locals = {'c': '3', 'd': '4'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == '1'
    assert ansible_j2_vars['b'] == '2'
    assert ansible_j2_vars['c'] == '3'
    assert ansible_j2_vars['d'] == '4'
    assert ansible_j2_vars['e'] == missing
    assert ansible_j2_vars

# Generated at 2022-06-17 14:34:12.930893
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_j2_vars.__iter__()) == set(['a', 'c'])
    templar.available_variables = {'e': 'f'}
    assert set(ansible_j2_vars.__iter__()) == set(['a', 'c', 'e'])
    templar.available_variables = {'a': 'b'}

# Generated at 2022-06-17 14:34:22.446248
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'test': 'test'}
    locals = {'test': 'test'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test' in ansible_j2_vars


# Generated at 2022-06-17 14:34:33.484593
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Test case 1: variable is in locals
    locals['test_variable'] = 'test_value'
    assert ansible_j2_vars['test_variable'] == 'test_value'

    # Test case 2: variable is in available_variables
    templar.available_variables = dict()
    templar.available_variables['test_variable'] = 'test_value'
    assert ansible_j2_

# Generated at 2022-06-17 14:34:45.202115
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBool
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFloat


# Generated at 2022-06-17 14:34:55.596780
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 14:35:01.551192
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ajv
    assert 'baz' in ajv
    assert 'quux' not in ajv


# Generated at 2022-06-17 14:35:07.728603
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)

    # Test with a variable in locals
    assert ajv['baz'] == 'qux'

    # Test with a variable in available_variables
    templar.available_variables = {'baz': 'qux'}
    assert ajv['baz'] == 'qux'

    # Test with a variable in globals
    assert ajv['foo'] == 'bar'

# Generated at 2022-06-17 14:35:18.294260
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFile
   

# Generated at 2022-06-17 14:35:27.400234
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'d': 4, 'e': 5, 'f': 6}
    ansible_vars = {'g': 7, 'h': 8, 'i': 9}
    templar.set_available_variables(ansible_vars)
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'])


# Generated at 2022-06-17 14:35:37.808727
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        """
        A test callback module
        """
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'test'

        def __init__(self):
            super(TestCallbackModule, self).__init

# Generated at 2022-06-17 14:35:44.066560
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4


# Generated at 2022-06-17 14:36:01.590875
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTuple
    from ansible.vars.unsafe_proxy import AnsibleUnsafeSet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone

# Generated at 2022-06-17 14:36:11.492674
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'g2' in vars
    assert 'l1' in vars
    assert 'l2' in vars
    assert 'g3' not in vars
    assert 'l3' not in vars
    assert 'vars' not in vars

# Generated at 2022-06-17 14:36:21.554927
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'g_bar'}
    locals = {'l_foo': 'l_bar'}
    vars = {'vars': {'foo': 'bar'}}
    templar.set_available_variables(vars)
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['g_foo'] == 'g_bar'
    assert j2vars['l_foo'] == 'l_bar'
    assert j2vars['vars'] == {'foo': 'bar'}
    assert j2vars['foo'] == 'bar'

# Generated at 2022-06-17 14:36:27.513795
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:36:35.327266
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2', 'v1', 'v2'])

# Generated at 2022-06-17 14:36:43.598700
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1'}
    locals = {'l1': 'l1'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'l1' in vars
    assert 'g2' not in vars
    assert 'l2' not in vars
    templar.available_variables = {'a1': 'a1'}
    assert 'a1' in vars
    assert 'a2' not in vars
    templar.available_variables = {'a1': HostVars()}

# Generated at 2022-06-17 14:36:51.431626
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFloat

    templ

# Generated at 2022-06-17 14:36:59.574645
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'g_bar'}
    locals = {'l_foo': 'l_bar'}
    vars = {'foo': 'bar'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ansible_j2_vars
    assert 'l_foo' in ansible_j2_vars
    assert 'g_foo' in ansible_j2_vars
    assert 'bar' not in ansible_j2_vars
    assert 'l_bar' not in ansible

# Generated at 2022-06-17 14:37:08.540543
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    available_variables = {'v1': 'v1', 'v2': 'v2'}
    templar.set_available_variables(available_variables)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert sorted(list(ansible_j2_vars)) == sorted(['g1', 'g2', 'l1', 'l2', 'v1', 'v2'])

# Unit

# Generated at 2022-06-17 14:37:17.609645
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == HostVars()
    assert vars['vars']['foo'] == 'bar'
    assert vars['vars']['baz'] == 'qux'
    assert vars.add_locals({'l_quux': 'quuz'})['quux'] == 'quuz'

# Generated at 2022-06-17 14:37:29.940653
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['foo'] == 'bar'
    assert j2vars['baz'] == 'qux'

# Generated at 2022-06-17 14:37:40.124313
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['test_global'] == 'test_global_value'
    assert j2vars['test_local'] == 'test_local_value'
    assert j2vars['vars'] == templar.available_variables

# Generated at 2022-06-17 14:37:50.773204
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTuple

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ

# Generated at 2022-06-17 14:38:02.300896
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_a': 1, 'g_b': 2}
    locals = {'l_a': 3, 'l_b': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g_a', 'g_b', 'l_a', 'l_b'])
    templar.available_variables = {'a': 5, 'b': 6}
    assert set(vars) == set(['g_a', 'g_b', 'l_a', 'l_b', 'a', 'b'])

# Generated at 2022-06-17 14:38:12.599495
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeValue
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTuple

# Generated at 2022-06-17 14:38:23.434686
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['vars'] == templar.available_variables['vars']
    assert isinstance(ajv['vars'], HostVars)
    assert isinstance(ajv['vars']['foo'], AnsibleUnsafeText)
    assert a

# Generated at 2022-06-17 14:38:34.233574
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in vars
    locals['foo'] = 'bar'
    assert 'foo' in vars
    globals['foo'] = 'bar'
    assert 'foo' in vars
    templar.available_variables = dict()
    templar.available_variables['foo'] = 'bar'
    assert 'foo' in vars
    templar.available_variables['foo'] = HostVars()
    assert 'foo' in vars


# Generated at 2022-06-17 14:38:45.486038
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['foo'] == 'bar'
    assert j2vars['baz'] == 'qux'
    assert j2vars['vars'] == templar.available_variables
    assert j2vars['hostvars'] == HostVars(templar)
    try:
        j2vars['undefined']
    except KeyError as e:
        assert str(e) == "undefined variable: undefined"

# Generated at 2022-06-17 14:38:55.408543
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = {'v1': 'v1', 'v2': 'v2'}
    templar._available_variables = vars
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert len(ajv) == 6

# Generated at 2022-06-17 14:39:02.051977
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None, variables={})
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with a local variable
    assert vars['baz'] == 'qux'

    # test __getitem__ with a global variable
    assert vars['foo'] == 'bar'

    # test __getitem__ with a variable from Templar

# Generated at 2022-06-17 14:39:15.086105
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['a'] == 1
    assert vars['b'] == 2
    assert vars['c'] == 3
    assert vars['d'] == 4
    try:
        vars['e']
    except KeyError:
        pass
    else:
        assert False, 'KeyError not raised'

# Generated at 2022-06-17 14:39:26.875342
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'d': 4, 'e': 5, 'f': 6}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 6
    assert len(j2vars) == len(globals) + len(locals)
    j2vars._templar.available_variables = {'g': 7, 'h': 8, 'i': 9}
    assert len(j2vars) == 9


# Generated at 2022-06-17 14:39:37.620719
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = {'v1': 'v1', 'v2': 'v2'}
    hostvars = HostVars(vars)
    templar._available_variables = hostvars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:39:48.300813
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['l_foo'] == 'bar'
    assert vars['bar'] == 'bar'
    assert vars['l_bar'] == 'bar'
    assert vars['baz'] == 'baz'
    assert vars['l_baz'] == 'baz'
    assert vars['qux'] == 'qux'
    assert vars['l_qux'] == 'qux'

# Generated at 2022-06-17 14:39:59.389608
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInteger
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone

    templar = Templar(loader=None)
    globals = dict()

# Generated at 2022-06-17 14:40:08.531028
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['foo'] == 'bar'
    assert ansible_j2_vars['baz'] == 'qux'
    try:
        ansible_j2_vars['quux']
    except KeyError as e:
        assert str(e) == "undefined variable: quux"
    else:
        assert False, "KeyError should be raised"

# Generated at 2022-06-17 14:40:17.372191
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == HostVars()
    assert vars['vars']['foo'] == 'bar'
    assert vars['vars']['baz'] == 'qux'

# Generated at 2022-06-17 14:40:25.691101
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test_global' in ansible_j2_vars
    assert 'test_local' in ansible_j2_vars
    assert 'test_undefined' not in ansible_j2_vars


# Generated at 2022-06-17 14:40:32.679016
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    # Test case 1: varname in self._locals
    vars = AnsibleJ2Vars(templar, globals, locals)
    vars._locals = {'test': 'test'}
    assert vars['test'] == 'test'

    # Test case 2: varname in self._templar.available_variables
    vars = AnsibleJ2Vars(templar, globals, locals)
    vars._templar

# Generated at 2022-06-17 14:40:45.147587
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import os
    import json


# Generated at 2022-06-17 14:41:09.972137
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'g2' in vars
    assert 'l1' in vars
    assert 'l2' in vars
    assert 'g3' not in vars
    assert 'l3' not in vars
    templar.available_variables = {'v1': 1, 'v2': 2}
    assert 'v1' in vars
    assert 'v2' in vars


# Generated at 2022-06-17 14:41:18.826234
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in ansible_j2_vars
    locals['foo'] = 'bar'
    assert 'foo' in ansible_j2_vars
    globals['foo'] = 'bar'
    assert 'foo' in ansible_j2_vars
    templar.available_variables = dict()
    templar.available_variables['foo'] = 'bar'
    assert 'foo' in ansible_j2_vars


# Generated at 2022-06-17 14:41:26.458668
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_key1': 'g_val1', 'g_key2': 'g_val2'}
    locals = {'l_key1': 'l_val1', 'l_key2': 'l_val2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_key1' in vars
    assert 'g_key2' in vars
    assert 'l_key1' in vars
    assert 'l_key2' in vars
    assert 'key1' not in vars
    assert 'key2' not in vars
    assert 'key3' not in vars

# Generated at 2022-06-17 14:41:37.550613
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:41:46.722043
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    templar.available_variables = {'a1': 'a1', 'a2': 'a2'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in j2vars
    assert 'g2' in j2vars
    assert 'l1' in j2vars
    assert 'l2' in j2vars
    assert 'a1' in j2vars

# Generated at 2022-06-17 14:41:55.431731
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars
    assert len(vars) == 2
    assert list(vars) == ['foo', 'baz']
    assert vars.add_locals({'quux': 'quuz'})['quux'] == 'quuz'
    assert v

# Generated at 2022-06-17 14:42:00.180010
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    vars = AnsibleJ2Vars(templar, {}, locals={'a': 'b'})
    assert vars['a'] == 'b'

# Generated at 2022-06-17 14:42:12.435215
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import wrap_var

    yaml_str = """
    foo:
      - bar
      - baz
    """
    data = AnsibleLoader(yaml_str).get_single_data()
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2V

# Generated at 2022-06-17 14:42:23.047179
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

    templar.available_variables = {'foo': 'bar'}
    assert vars['foo'] == 'bar'


# Generated at 2022-06-17 14:42:27.624135
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars
