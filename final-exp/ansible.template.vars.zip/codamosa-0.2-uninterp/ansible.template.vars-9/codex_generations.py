

# Generated at 2022-06-17 14:32:56.774120
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:33:07.152869
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import jinja2
    import os
    import sys
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    with os.fdopen(fd, 'w') as tmp:
        tmp.write('foo:\n')
        tmp.write('    bar: 1\n')

    # Create a jinja2 environment
    loader = jinja2.FileSystemLoader(tmpdir)
    env = jinja2.Environment(loader=loader)

    # Create a templar

# Generated at 2022-06-17 14:33:15.806861
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables
    assert isinstance(vars['vars'], HostVars)

# Generated at 2022-06-17 14:33:23.657291
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_bar': 'foo'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['bar'] == 'foo'
    assert vars['l_bar'] == 'foo'
    assert vars['l_foo'] == 'bar'
    assert vars['l_baz'] == 'baz'
    assert vars['baz'] == 'baz'
    assert vars['l_baz'] == 'baz'
    assert vars['l_baz'] == 'baz'


# Generated at 2022-06-17 14:33:34.531310
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4
    vars._templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    assert len(vars) == 6

# Generated at 2022-06-17 14:33:41.546867
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateSnippet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:33:51.203527
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 3
    assert len(ansible_j2_vars) == len(globals) + len(locals) + len(templar.available_variables)
    templar.available_variables = {'foo': 'bar', 'baz': 'qux'}
    assert len(ansible_j2_vars) == 2

# Generated at 2022-06-17 14:34:02.068435
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])
    assert set(vars.keys()) == set(['g1', 'g2', 'l1', 'l2'])
    assert set(vars.values()) == set([1, 2])

# Generated at 2022-06-17 14:34:09.290430
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test_global' in vars
    assert 'test_local' in vars
    assert 'test_undefined' not in vars


# Generated at 2022-06-17 14:34:18.974679
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar(loader=None, variables=VariableManager())
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert 'foo' in ajv
    assert 'baz' in ajv
    assert 'qux' not in ajv
    assert len(ajv) == 2

# Generated at 2022-06-17 14:34:33.258214
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    hostvars = HostVars(loader=None, variables=None)
    hostvars.update({'h1': 'h1', 'h2': 'h2'})
    templar.available_variables = {'a1': 'a1', 'a2': 'a2', 'hostvars': hostvars}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 8


# Generated at 2022-06-17 14:34:45.162287
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])
    locals = {'l1': 1, 'l2': 2, 'l3': 3}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2', 'l3'])
    glob

# Generated at 2022-06-17 14:34:51.466233
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

# Generated at 2022-06-17 14:35:00.539520
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_a': 'g_a'}
    locals = {'l_a': 'l_a'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_a' in vars
    assert 'l_a' in vars
    assert 'a' not in vars
    templar.available_variables = {'a': 'a'}
    assert 'a' in vars


# Generated at 2022-06-17 14:35:09.583636
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars

# Generated at 2022-06-17 14:35:19.750714
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == 'b'
    assert ansible_j2_vars['c'] == 'd'
    templar.available_variables = {'e': 'f'}
    assert ansible_j2_vars['e'] == 'f'
    templar.available_variables = {'g': HostVars()}

# Generated at 2022-06-17 14:35:25.591356
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(j2vars) == set(['a', 'b', 'c', 'd'])


# Generated at 2022-06-17 14:35:36.612787
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:35:42.961468
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['vars'] == dict()

# Generated at 2022-06-17 14:35:53.211164
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList

# Generated at 2022-06-17 14:36:01.664924
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4


# Generated at 2022-06-17 14:36:11.524134
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFile
   

# Generated at 2022-06-17 14:36:21.553653
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in ansible_j2_vars
    assert 'b' in ansible_j2_vars
    assert 'c' in ansible_j2_vars
    assert 'd' in ansible_j2_vars
    assert 'e' not in ansible_j2_vars
    assert 'f' not in ansible_j2_vars
    assert 'g' not in ansible_j2

# Generated at 2022-06-17 14:36:30.326699
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:36:38.695548
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    templar = Templar(loader=None, variables=variable_manager)

    # test for HostVars
    hostvars = HostVars(host=None, variables=None)
    aj2v = AnsibleJ2Vars(templar, {}, locals={'hostvars': hostvars})
    assert aj2v['hostvars'] == hostvars

    # test for dict

# Generated at 2022-06-17 14:36:43.321203
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars


# Generated at 2022-06-17 14:36:50.795786
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['bar'] == 'baz'
    assert vars['qux'] == 'foo'
    assert vars['bar'] == 'baz'
    assert vars['qux'] == 'foo'
    assert vars['bar'] == 'baz'
    assert vars['qux'] == 'foo'
    assert vars['bar'] == 'baz'
    assert vars['qux'] == 'foo'


# Generated at 2022-06-17 14:36:59.503359
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'test_global_1': 'test_global_1', 'test_global_2': 'test_global_2'}
    locals = {'test_local_1': 'test_local_1', 'test_local_2': 'test_local_2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4
    templar.available_variables = {'test_available_1': 'test_available_1', 'test_available_2': 'test_available_2'}
    v

# Generated at 2022-06-17 14:37:05.558671
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars


# Generated at 2022-06-17 14:37:15.826990
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])
    assert set(vars) == set(vars.keys())
    assert set(vars) == set(vars.__iter__())
    assert set(vars) == set(iter(vars))

# Generated at 2022-06-17 14:37:28.303040
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

# Generated at 2022-06-17 14:37:39.071425
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['g_foo'] == 'bar'
    assert vars['l_foo'] == 'bar'
    assert vars['vars'] == templar.available_variables
    assert vars['hostvars'] == templar.available_variables['hostvars']

# Generated at 2022-06-17 14:37:43.851909
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4


# Generated at 2022-06-17 14:37:49.622272
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['vars'] == dict()
    assert j2vars['vars']['foo'] == 'bar'
    assert j2vars['vars']['foo'] == 'bar'
    assert j2vars['vars']['foo'] == 'bar'
    assert j2vars['vars']['foo'] == 'bar'
    assert j2vars['vars']['foo'] == 'bar'
    assert j2vars['vars']['foo'] == 'bar'
    assert j2vars['vars']['foo']

# Generated at 2022-06-17 14:38:01.473698
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'bar' in vars
    assert 'qux' in vars
    assert 'foobar' not in vars
    assert 'bazqux' not in vars
    assert 'foobar' not in vars
    assert 'bazqux' not in vars
    assert len(vars) == 2

# Generated at 2022-06-17 14:38:11.934533
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in j2vars
    assert 'l_foo' in j2vars
    assert 'foo' not in j2vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in j2vars
    templar.available_variables = {'foo': HostVars(loader=None, variables={'foo': 'bar'})}
    assert 'foo' in j2v

# Generated at 2022-06-17 14:38:18.093455
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars


# Generated at 2022-06-17 14:38:23.200723
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['a', 'c'])


# Generated at 2022-06-17 14:38:34.430333
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': AnsibleUnsafeText('bar')}
    assert 'foo' in vars


# Generated at 2022-06-17 14:38:42.542280
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEval
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja2Template
    from ansible.vars.unsafe_proxy import Ansible

# Generated at 2022-06-17 14:39:02.388338
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2_vars['foo'] == 'bar'
    assert j2_vars['baz'] == 'qux'
    assert j2_vars['vars'] == templar.available_variables
    assert j2_vars['hostvars'] == templar.available_variables['hostvars']
    assert isinstance(j2_vars['hostvars'], HostVars)

# Generated at 2022-06-17 14:39:13.065022
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = {'v1': 'v1', 'v2': 'v2'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_j2_vars) == set(['g1', 'g2', 'l1', 'l2', 'v1', 'v2'])


# Generated at 2022-06-17 14:39:17.923124
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars._templar == templar
    assert ansible_j2_vars._globals == globals
    assert ansible_j2_vars._locals == locals

# Generated at 2022-06-17 14:39:28.755928
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:39:39.309750
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4
    vars._templar.available_variables = {'a1': 1, 'a2': 2}
    assert len(vars) == 6
    vars._templar.available_variables = {'a1': 1, 'a2': 2, 'g1': 3, 'l1': 4}
    assert len(vars) == 6
    vars._templar.available_

# Generated at 2022-06-17 14:39:49.957372
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_key': 'g_value'}
    locals = {'l_key': 'l_value'}
    vars = {'v_key': 'v_value'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_key' in ansible_j2_vars
    assert 'l_key' in ansible_j2_vars
    assert 'v_key' in ansible_j2_vars
    assert 'key' not in ansible_j2_vars


# Generated at 2022-06-17 14:40:01.213823
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:40:09.983995
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test_global'] == 'test_global_value'
    assert ansible_j2_vars['test_local'] == 'test_local_value'
    hostvars = HostVars(loader=None, variables={'test_hostvars': 'test_hostvars_value'})

# Generated at 2022-06-17 14:40:19.065954
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'d': 4, 'e': 5, 'f': 6}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 6
    assert len(vars.add_locals({'g': 7, 'h': 8})) == 8
    assert len(vars.add_locals(None)) == 6
    assert len(vars.add_locals(HostVars())) == 6


# Generated at 2022-06-17 14:40:28.153970
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    available_variables = {'v1': 'v1', 'v2': 'v2'}
    templar.available_variables = available_variables
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 6


# Generated at 2022-06-17 14:41:07.816644
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
   

# Generated at 2022-06-17 14:41:15.630619
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 3, 'l2': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'g2' in vars
    assert 'l1' in vars
    assert 'l2' in vars
    assert 'g3' not in vars
    assert 'l3' not in vars


# Generated at 2022-06-17 14:41:24.512609
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeObject
    from ansible.vars.unsafe_proxy import AnsibleUnsafeRoleDeprecationWarning
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:41:32.055875
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'a': 1, 'b': 2, 'c': 3})
    globals = {'d': 4, 'e': 5, 'f': 6}
    locals = {'g': 7, 'h': 8, 'i': 9}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 9
    assert len(ansible_j2_vars) == len(templar.available_variables) + len(globals) + len(locals)


# Generated at 2022-06-17 14:41:41.474944
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'d': 4, 'e': 5, 'f': 6}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 6


# Generated at 2022-06-17 14:41:47.862173
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:41:57.997537
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars

# Generated at 2022-06-17 14:42:06.803343
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['foo'] == 'bar'
    assert ansible_j2_vars['baz'] == 'qux'
    assert ansible_j2_vars['quux'] == 'quuz'
    assert ansible_j2_vars['corge'] == 'grault'
    assert ansible_j2_vars['garply'] == 'waldo'
    assert ansible_j2_vars['fred'] == 'plugh'
    assert ansible_j2

# Generated at 2022-06-17 14:42:17.209201
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars
    assert len(vars) == 2
    assert list(vars) == ['foo', 'baz']
    assert vars.add_locals({'quux': 'quuz'})['quux'] == 'quuz'
    assert v

# Generated at 2022-06-17 14:42:21.946900
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'bar': 'foo'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(j2vars) == set(['foo', 'bar'])
