

# Generated at 2022-06-17 14:32:57.795077
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'a': 'global_a', 'b': 'global_b'}
    locals = {'a': 'local_a', 'c': 'local_c'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['a'] == 'local_a'
    assert vars['b'] == 'global_b'
    assert vars['c'] == 'local_c'
    assert vars['d'] == 'global_d'
    assert vars['e'] == 'global_e'
    assert vars['f']

# Generated at 2022-06-17 14:33:07.703878
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_bar': 'foo'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # Test __getitem__ with locals
    assert j2vars['l_bar'] == 'foo'

    # Test __getitem__ with globals
    assert j2vars['foo'] == 'bar'

    # Test __getitem__ with available_variables
    templar.available_variables = {'foo': 'bar'}

# Generated at 2022-06-17 14:33:18.257992
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}

    # Test with locals
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'

# Generated at 2022-06-17 14:33:30.384482
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in ansible_j2_vars
    ansible_j2_vars._templar.available_variables['foo'] = 'bar'
    assert 'foo' in ansible_j2_vars
    ansible_j2_vars._locals['foo'] = 'bar'
    assert 'foo' in ansible_j2_vars
    ansible_j2_vars._globals['foo'] = 'bar'
    assert 'foo' in ansible_j2_vars


# Generated at 2022-06-17 14:33:44.184463
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'bar': 'foo'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['bar'] == 'foo'
    assert vars['vars'] == templar.available_variables
    assert vars['hostvars'] == templar.available_variables['hostvars']
    assert vars['inventory_hostname'] == templar.available_variables['inventory_hostname']
    assert vars['groups'] == templar.available_variables['groups']

# Generated at 2022-06-17 14:33:52.623044
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None, variables={'a': 1, 'b': 2})
    globals = {'c': 3, 'd': 4}
    locals = {'e': 5, 'f': 6}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 6
    assert len(ansible_j2_vars) == 6
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 6

# Generated at 2022-06-17 14:33:55.995461
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    vars = AnsibleJ2Vars(templar, {'a': 1, 'b': 2, 'c': 3})
    assert set(vars) == set(['a', 'b', 'c'])


# Generated at 2022-06-17 14:34:01.587062
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'a': 'b'})
    globals = {'c': 'd'}
    locals = {'e': 'f'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == 'b'
    assert ansible_j2_vars['c'] == 'd'
    assert ansible_j2_vars['e'] == 'f'
    assert ansible_j2_vars['vars'] == {'a': 'b'}
    assert ansible_j2_vars['hostvars'] == HostVars()

# Generated at 2022-06-17 14:34:07.449557
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert len(ajv) == 3


# Generated at 2022-06-17 14:34:11.713427
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_var': 'g_value'}
    locals = {'l_var': 'l_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_var' in vars
    assert 'l_var' in vars
    assert 'var' not in vars


# Generated at 2022-06-17 14:34:23.958500
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in j2vars
    assert 'baz' in j2vars
    assert 'qux' not in j2vars
    assert 'bar' not in j2vars
    assert 'vars' in j2vars
    assert 'hostvars' in j2vars
    assert 'inventory_hostname' in j2vars
    assert 'inventory_hostname_short' in j2vars
    assert 'group_names' in j

# Generated at 2022-06-17 14:34:34.385856
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'d': 4, 'e': 5, 'f': 6}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert len(ajv) == 6
    assert len(ajv) == len(globals) + len(locals)
    templar.available_variables = {'g': 7, 'h': 8, 'i': 9}
    assert len(ajv) == 9

# Generated at 2022-06-17 14:34:40.316702
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4


# Generated at 2022-06-17 14:34:46.570915
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = {'v1': 'v1', 'v2': 'v2'}
    templar._available_variables = vars
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert set(ajv.__iter__()) == set(['g1', 'g2', 'l1', 'l2', 'v1', 'v2'])


# Generated at 2022-06-17 14:34:56.397667
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test': 'test'}
    locals = {'test': 'test'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['test'] == 'test'
    assert 'test' in ajv
    assert len(ajv) == 1
    assert list(iter(ajv)) == ['test']
    assert ajv.add_locals({'test': 'test'})['test'] == 'test'
    assert ajv.add_locals({'test': 'test'})['test'] == 'test'

# Generated at 2022-06-17 14:35:05.974199
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_j2_vars.__iter__()) == {'foo', 'baz'}
    templar.available_variables = {'quux': 'quuz'}
    assert set(ansible_j2_vars.__iter__()) == {'foo', 'baz', 'quux'}
    templar.available_variables = {'quux': HostVars()}

# Generated at 2022-06-17 14:35:12.860302
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'a': 'b'})
    globals = {'c': 'd'}
    locals = {'e': 'f'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' not in vars
    assert 'c' in vars
    assert 'd' not in vars
    assert 'e' in vars
    assert 'f' not in vars


# Generated at 2022-06-17 14:35:18.161031
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in aj2v
    assert 'baz' in aj2v
    assert 'qux' not in aj2v


# Generated at 2022-06-17 14:35:23.775826
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

# Generated at 2022-06-17 14:35:35.557132
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['l_foo'] == 'bar'
    assert vars['vars'] == templar.available_variables
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars']['foo'] == 'bar'
    assert vars['vars']['l_foo'] == 'bar'
    assert vars['vars']['vars'] == templar

# Generated at 2022-06-17 14:35:52.789458
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['vars'] == templar.available_variables
    assert ajv['hostvars'] == HostVars(templar)
    assert ajv['hostvars']['localhost'] == templar.available_variables

# Generated at 2022-06-17 14:36:01.767624
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBool
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone


# Generated at 2022-06-17 14:36:11.584358
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test with local variable
    assert vars['baz'] == 'qux'

    # test with global variable
    assert vars['foo'] == 'bar'

    # test with undefined variable
    try:
        vars['undefined']
        assert False
    except KeyError as e:
        assert str(e) == "undefined variable: undefined"

    # test with HostVars
   

# Generated at 2022-06-17 14:36:20.621653
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in ansible_j2_vars
    assert 'b' in ansible_j2_vars
    assert 'c' in ansible_j2_vars
    assert 'd' in ansible_j2_vars
    assert 'e' not in ansible_j2_vars


# Generated at 2022-06-17 14:36:29.753569
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar', 'g_baz': 'qux'}
    locals = {'l_foo': 'bar', 'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['foo', 'baz', 'g_foo', 'g_baz'])
    assert set(vars.keys()) == set(['foo', 'baz', 'g_foo', 'g_baz'])
    assert set(vars.values()) == set(['bar', 'qux', 'bar', 'qux'])

# Generated at 2022-06-17 14:36:38.213298
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a variable manager
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    # Create a templar
    templar = Templar(loader=loader, variables=variable_manager)

    # Create a AnsibleJ2Vars object
    ansible_j2_vars = AnsibleJ2Vars(templar, globals={})

    # Test __contains__
    assert 'inventory_hostname' in ansible_j2_vars

# Generated at 2022-06-17 14:36:43.930429
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'c' in j2vars
    assert 'd' in j2vars
    assert 'e' not in j2vars


# Generated at 2022-06-17 14:36:51.267607
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_v

# Generated at 2022-06-17 14:36:59.527777
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in j2vars
    assert 'g2' in j2vars
    assert 'l1' in j2vars
    assert 'l2' in j2vars
    assert 'g3' not in j2vars
    assert 'l3' not in j2vars
    assert 'g1' not in j2vars

# Generated at 2022-06-17 14:37:08.515501
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars

# Generated at 2022-06-17 14:37:20.769021
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars is not None

# Generated at 2022-06-17 14:37:29.115936
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:37:36.222526
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_var': 'g_value'}
    locals = {'l_var': 'l_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_var' in vars
    assert 'l_var' in vars
    assert 'var' not in vars


# Generated at 2022-06-17 14:37:42.528949
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4


# Generated at 2022-06-17 14:37:53.717462
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables
    assert vars['hostvars'] == HostVars()
    assert vars['hostvars'].__UNSAFE__ == True

# Generated at 2022-06-17 14:38:03.686616
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in j2vars
    assert 'g_foo' in j2vars
    assert 'l_foo' in j2vars
    assert 'bar' not in j2vars
    assert 'g_bar' not in j2vars
    assert 'l_bar' not in j2vars


# Generated at 2022-06-17 14:38:13.566171
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables['vars']
    assert vars['hostvars'] == templar.available_variables['hostvars']
    assert vars['group_names'] == templar.available_variables['group_names']

# Generated at 2022-06-17 14:38:24.505500
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:38:30.688336
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.path import unfrackpath
    from ansible.utils.sentinel import Sentinel

# Generated at 2022-06-17 14:38:43.890618
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in aj2v
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in aj2v
    templar.available_variables = dict()
    globals = {'foo': 'bar'}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in aj2v
    locals = {'foo': 'bar'}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo'

# Generated at 2022-06-17 14:39:06.545903
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars


# Generated at 2022-06-17 14:39:15.003301
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTuple

# Generated at 2022-06-17 14:39:22.284809
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_key': 'g_value'}
    locals = {'l_key': 'l_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_key' in vars
    assert 'l_key' in vars
    assert 'key' not in vars


# Generated at 2022-06-17 14:39:30.852173
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with locals
    assert vars['baz'] == 'qux'

    # test __getitem__ with available_variables
    templar.available_variables = {'quux': 'quuz'}
    assert vars['quux'] == 'quuz'

    # test __

# Generated at 2022-06-17 14:39:44.194439
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars

# Generated at 2022-06-17 14:39:53.522719
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBool
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFloat


# Generated at 2022-06-17 14:40:03.791158
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafePromptPassword
    from ansible.vars.unsafe_proxy import AnsibleUnsafePromptPrivateKey
    from ansible.vars.unsafe_proxy import AnsibleUnsafePromptYesNo

# Generated at 2022-06-17 14:40:11.395942
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_vars = dict()
    ansible_vars['test_var'] = 'test_value'
    ansible_vars['test_var2'] = 'test_value2'
    ansible_vars['test_var3'] = 'test_value3'
    ansible_vars['test_var4'] = 'test_value4'
    ansible_vars['test_var5'] = 'test_value5'
    ansible_vars['test_var6'] = 'test_value6'
    ansible_vars['test_var7'] = 'test_value7'
   

# Generated at 2022-06-17 14:40:17.180555
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'bar': 'foo'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ajv
    assert 'bar' in ajv
    assert 'baz' not in ajv


# Generated at 2022-06-17 14:40:27.924759
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict


# Generated at 2022-06-17 14:40:52.508023
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'global'}
    locals = {'test_local': 'local'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['test_global'] == 'global'
    assert vars['test_local'] == 'local'
    assert vars['vars'] == templar.available_variables
    assert vars['hostvars'] == HostVars(templar._available_variables['hostvars'])
    assert vars['inventory_hostname'] == templar.available_variables['inventory_hostname']

# Generated at 2022-06-17 14:40:56.215811
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

# Generated at 2022-06-17 14:41:03.811853
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:41:09.237667
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ajv
    assert 'baz' in ajv
    assert 'qux' not in ajv


# Generated at 2022-06-17 14:41:19.042233
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in ansible_j2_vars
    assert 'c' in ansible_j2_vars
    assert 'd' not in ansible_j2_vars
    assert 'e' not in ansible_j2_vars
    templar.available_variables = {'e': 'f'}
    assert 'e' in ansible_j

# Generated at 2022-06-17 14:41:23.316906
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 2

# Generated at 2022-06-17 14:41:31.875133
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # Test that we can get a global variable
    assert j2vars['foo'] == 'bar'

    # Test that we can get a local variable
    assert j2vars['baz'] == 'qux'

    # Test that we can get a variable from the templar
    templar.available_variables = {'foo': 'bar'}

# Generated at 2022-06-17 14:41:43.670459
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'c' in j2vars
    assert 'd' in j2vars
    assert 'e' not in j2vars


# Generated at 2022-06-17 14:41:53.489918
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_var': 'g_val'}
    locals = {'l_var': 'l_val'}
    vars = {'var': 'val'}
    templar._available_variables = vars
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['g_var'] == 'g_val'
    assert ajv['l_var'] == 'l_val'
    assert ajv['var'] == 'val'
    assert ajv['vars'] == vars

# Generated at 2022-06-17 14:42:03.521334
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['a'] == 'b'
    assert vars['c'] == 'd'
    assert isinstance(vars['vars'], HostVars)
    assert 'e' not in vars
    try:
        vars['e']
        assert False
    except KeyError:
        pass
    assert len(vars) == 3
    assert set(vars) == set(['a', 'c', 'vars'])

# Generated at 2022-06-17 14:42:41.275230
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    templar = Templar(loader=DataLoader(), variables=VariableManager(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader())))
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars

# Generated at 2022-06-17 14:42:48.908209
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_bar': 'foo'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['bar'] == 'foo'
    assert ajv['baz'] == 'baz'
    assert ajv['vars'] == {'foo': 'bar', 'bar': 'foo'}
    assert ajv['hostvars'] == HostVars()
    assert ajv['hostvars']['foo'] == 'bar'