

# Generated at 2022-06-17 14:32:55.720403
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global'}
    locals = {'test_local': 'test_local'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test_global' in j2vars
    assert 'test_local' in j2vars
    assert 'test_undefined' not in j2vars
    templar.available_variables = {'test_available': 'test_available'}
    assert 'test_available' in j2vars

# Generated at 2022-06-17 14:33:06.672889
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test if the variable is in locals
    assert vars['baz'] == 'qux'

    # Test if the variable is in available_variables
    templar.available_variables = {'baz': 'qux'}
    assert vars['baz'] == 'qux'

    #

# Generated at 2022-06-17 14:33:14.885705
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables['vars']
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars']['foo'] == 'bar'
    assert vars['vars']['baz'] == 'qux'

# Generated at 2022-06-17 14:33:23.219691
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    hostvars = HostVars(loader=None, variables=None)
    hostvars.update({'h1': 'h1', 'h2': 'h2'})
    templar.available_variables = {'t1': 't1', 't2': 't2'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:33:34.485227
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_var': 'g_val'}
    locals = {'l_var': 'l_val'}
    vars = {'var': 'val'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['g_var'] == 'g_val'
    assert ansible_j2_vars['l_var'] == 'l_val'
    assert ansible_j2_vars['var'] == 'val'

# Generated at 2022-06-17 14:33:44.944137
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in j2vars
    assert 'g2' in j2vars
    assert 'l1' in j2vars
    assert 'l2' in j2vars
    assert 'g3' not in j2vars
    assert 'l3' not in j2vars
    assert 'vars' not in j2vars
    assert 'hostvars' not in j2vars
    templ

# Generated at 2022-06-17 14:33:51.133826
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:34:02.068633
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test_global'] == 'test_global_value'
    assert ansible_j2_vars['test_local'] == 'test_local_value'
    assert ansible_j2_vars['vars'] == {}
    assert ansible_j2_vars['hostvars'] == HostVars()

# Generated at 2022-06-17 14:34:13.304428
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['test_global'] == 'test_global_value'
    assert vars['test_local'] == 'test_local_value'
    assert vars['vars'] == templar.available_variables
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars']['test_global'] == 'test_global_value'

# Generated at 2022-06-17 14:34:19.205263
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'bar': 'foo'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in j2vars
    assert 'bar' in j2vars
    assert 'baz' not in j2vars


# Generated at 2022-06-17 14:34:33.520889
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson

    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # test if the variable is in locals
    assert ansible_j2_vars['c'] == 'd'

    # test if the

# Generated at 2022-06-17 14:34:42.870091
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars.__iter__()) == set(['g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:34:53.329369
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_key1': 'g_value1', 'g_key2': 'g_value2'}
    locals = {'l_key1': 'l_value1', 'l_key2': 'l_value2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_key1' in vars
    assert 'g_key2' in vars
    assert 'l_key1' in vars
    assert 'l_key2' in vars
    assert 'key1' not in vars
    assert 'key2' not in vars


# Generated at 2022-06-17 14:35:03.930389
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}

    # Test for undefined variable
    ajv = AnsibleJ2Vars(templar, globals, locals)
    try:
        ajv['undefined']
    except KeyError as e:
        assert e.args[0] == "undefined variable: undefined"
    else:
        assert False, "KeyError not raised"

    # Test for variable in locals
    ajv = Ansible

# Generated at 2022-06-17 14:35:16.240123
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_test': 'g_test'}
    locals = {'l_test': 'l_test'}
    vars = {'v_test': 'v_test'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_test' in ansible_j2_vars
    assert 'l_test' in ansible_j2_vars
    assert 'v_test' in ansible_j2_vars

# Generated at 2022-06-17 14:35:27.313746
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    templar.available_variables['v3'] = HostVars()
    templar.available_variables['v4'] = AnsibleUnsafeText('v4')
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:35:37.741727
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global'}
    locals = {'test_local': 'test_local'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['test_global'] == 'test_global'
    assert vars['test_local'] == 'test_local'
    assert vars['vars'] == HostVars()
    assert vars['vars'].__UNSAFE__ == True
    assert vars['vars'].__UNSAFE__ == True
    try:
        vars['test_undefined']
    except KeyError as e:
        assert str(e)

# Generated at 2022-06-17 14:35:44.081788
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateSnippet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:35:53.812477
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateSnippet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:36:02.181190
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:36:13.726627
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars']['foo'] == 'bar'

# Generated at 2022-06-17 14:36:22.914883
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    # test with empty locals
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['vars'] == dict()

    # test with locals

# Generated at 2022-06-17 14:36:30.813355
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'g1' in vars
    assert 'g2' in vars
    assert 'l1' in vars
    assert 'l2' in vars
    assert 'g3' not in vars
    assert 'l3' not in vars

    templar.available_variables = {'v1': 'v1', 'v2': 'v2'}

# Generated at 2022-06-17 14:36:35.689002
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

# Generated at 2022-06-17 14:36:43.474858
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4
    # test with HostVars
    templar.available_variables = {'hv': HostVars()}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 5


# Generated at 2022-06-17 14:36:50.948935
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars(loader=None, variables={'foo': 'bar'})}
    assert 'foo' in vars

# Generated at 2022-06-17 14:36:56.212797
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'ansible_version' in ansible_j2_vars
    assert 'ansible_version' not in locals
    assert 'ansible_version' not in globals


# Generated at 2022-06-17 14:37:05.008976
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'a': 4, 'b': 5, 'c': 6}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 6
    assert len(ansible_j2_vars) == len(globals) + len(locals)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'a': 4, 'b': 5, 'c': 6}

# Generated at 2022-06-17 14:37:15.656863
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:37:26.851355
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:37:44.435907
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookupVal
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironmentVariable
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja2Text
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja2Bytes

# Generated at 2022-06-17 14:37:55.913798
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInteger
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFloat
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone

# Generated at 2022-06-17 14:38:06.604125
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'l_baz' in vars
    assert 'baz' in vars
    assert 'bar' not in vars
    assert 'qux' not in vars
    templar.available_variables = {'bar': 'baz'}
    assert 'bar' in vars
    assert 'baz' in vars
    tem

# Generated at 2022-06-17 14:38:12.075363
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1}
    locals = {'b': 2}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in ansible_j2_vars
    assert 'b' in ansible_j2_vars
    assert 'c' not in ansible_j2_vars


# Generated at 2022-06-17 14:38:22.982512
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test with a variable that is in locals

# Generated at 2022-06-17 14:38:29.791280
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'a': 1, 'b': 2, 'c': 3})
    j2vars = AnsibleJ2Vars(templar, {'d': 4, 'e': 5, 'f': 6})
    assert set(j2vars) == set(['a', 'b', 'c', 'd', 'e', 'f'])


# Generated at 2022-06-17 14:38:36.422181
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global'}
    locals = {'test_local': 'test_local'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test_global' in vars
    assert 'test_local' in vars
    assert 'test_undefined' not in vars
    templar.available_variables = {'test_available_variables': 'test_available_variables'}
    assert 'test_available_variables' in vars

# Generated at 2022-06-17 14:38:44.052959
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateSnippet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:38:53.535873
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 14:38:59.809770
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars


# Generated at 2022-06-17 14:39:29.029765
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:39:39.451307
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExec

# Generated at 2022-06-17 14:39:50.131130
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookupVal
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironmentVariable
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja2Text
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja2Bytes

# Generated at 2022-06-17 14:40:01.416451
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'c' in j2vars
    assert 'd' in j2vars
    assert 'e' not in j2vars
    templar.available_variables = {'f': 5, 'g': 6}
    assert 'f' in j2vars


# Generated at 2022-06-17 14:40:10.533056
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_var': 'g_value'}
    locals = {'l_var': 'l_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_var' in vars
    assert 'l_var' in vars
    assert 'var' not in vars
    templar.available_variables = {'var': 'value'}
    assert 'var' in vars
    templar.available_variables = {'var': HostVars()}
    assert 'var' in vars

# Generated at 2022-06-17 14:40:16.213388
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'a': 'b'})
    globals = {'c': 'd'}
    locals = {'e': 'f'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_j2_vars) == set(['a', 'c', 'e'])
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_j2_vars) == set(['a', 'c', 'e'])
    templar = Templar(loader=None, variables={'a': 'b'})

# Generated at 2022-06-17 14:40:27.607428
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars
    templar

# Generated at 2022-06-17 14:40:33.042051
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ajv
    assert 'baz' in ajv
    assert 'quux' not in ajv


# Generated at 2022-06-17 14:40:43.083198
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars


# Generated at 2022-06-17 14:40:52.672540
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars


# Generated at 2022-06-17 14:41:24.368400
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(list(vars.__iter__())) == 0
    globals['g1'] = 'g1'
    locals['l1'] = 'l1'
    templar.available_variables = dict(v1='v1')
    assert len(list(vars.__iter__())) == 3
    assert 'g1' in list(vars.__iter__())
    assert 'l1' in list(vars.__iter__())
    assert 'v1' in list(vars.__iter__())


# Generated at 2022-06-17 14:41:32.391905
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookupVal
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironmentVariable
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:41:45.554184
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['vars'] == templar.available_variables['vars']
    assert isinstance(ajv['vars'], HostVars)
    assert ajv['vars'].__UNSAFE__ == True

# Generated at 2022-06-17 14:41:54.722236
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar', 'baz': 'qux'}
    locals = {'l_one': 'two', 'l_three': 'four'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['foo', 'baz', 'one', 'three'])
    assert set(vars.keys()) == set(['foo', 'baz', 'one', 'three'])
    assert set(vars.values()) == set(['bar', 'qux', 'two', 'four'])

# Generated at 2022-06-17 14:41:59.791758
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars

# Generated at 2022-06-17 14:42:12.135582
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFile
   

# Generated at 2022-06-17 14:42:18.784652
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars


# Generated at 2022-06-17 14:42:28.972923
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate

# Generated at 2022-06-17 14:42:39.703388
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    import pytest

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test if the variable is in locals
    assert vars['baz'] == 'qux'

    # Test if the variable is in available_variables

# Generated at 2022-06-17 14:42:48.713411
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict(g_key1='g_value1', g_key2='g_value2')
    locals = dict(l_key1='l_value1', l_key2='l_value2')
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_key1' in ansible_j2_vars
    assert 'g_key2' in ansible_j2_vars
    assert 'l_key1' in ansible_j2_vars
    assert 'l_key2' in ansible_j2_vars
    assert 'g_key3' not in ansible_j2_vars