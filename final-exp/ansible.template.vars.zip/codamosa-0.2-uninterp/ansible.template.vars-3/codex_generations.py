

# Generated at 2022-06-17 14:33:04.924954
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global_1': 'test_global_1_value', 'test_global_2': 'test_global_2_value'}
    locals = {'test_local_1': 'test_local_1_value', 'test_local_2': 'test_local_2_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['test_global_1'] == 'test_global_1_value'
    assert vars['test_global_2'] == 'test_global_2_value'

# Generated at 2022-06-17 14:33:12.217453
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeValue
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTuple

# Generated at 2022-06-17 14:33:21.439481
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test with a key in locals
    assert vars['baz'] == 'qux'

    # Test with a key in available_variables
    templar.available_variables = {'baz': 'qux'}
    assert vars['baz'] == 'qux'

    # Test with a key

# Generated at 2022-06-17 14:33:32.724473
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'global_foo', 'g_bar': 'global_bar'}
    locals = {'l_foo': 'local_foo', 'l_bar': 'local_bar'}
    available_variables = {'v_foo': 'variable_foo', 'v_bar': 'variable_bar'}
    templar.set_available_variables(available_variables)
    j2vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:33:42.369725
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global'}
    locals = {'test_local': 'test_local'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test_global' in vars
    assert 'test_local' in vars
    assert 'test_undefined' not in vars


# Generated at 2022-06-17 14:33:48.260909
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:33:52.945006
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4


# Generated at 2022-06-17 14:34:02.769201
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFile
   

# Generated at 2022-06-17 14:34:10.431575
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeSet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBool
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone



# Generated at 2022-06-17 14:34:20.145781
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'global_a', 'b': 'global_b'}
    locals = {'a': 'local_a', 'c': 'local_c'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['a'] == 'local_a'
    assert vars['b'] == 'global_b'
    assert vars['c'] == 'local_c'
    assert vars['d'] == 'global_d'
    assert vars['e'] == 'global_e'
    assert vars['f'] == 'global_f'

# Generated at 2022-06-17 14:34:32.867006
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1_value', 'g2': 'g2_value'}
    locals = {'l1': 'l1_value', 'l2': 'l2_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:34:43.967697
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['vars'] == templar.available_variables
    assert ajv['hostvars'] == HostVars(templar)

# Generated at 2022-06-17 14:34:52.038406
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert len(ajv) == 6
    assert sorted(ajv) == ['g1', 'g2', 'l1', 'l2', 'v1', 'v2']
    assert aj

# Generated at 2022-06-17 14:35:03.620320
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'bar': 'baz'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test if the variable is in locals
    assert vars['bar'] == 'baz'

    # Test if the variable is in templar.available_variables
    templar.available_variables = {'bar': 'baz'}
    assert vars['bar'] == 'baz'

    # Test if the variable is in globals
    assert vars['foo'] == 'bar'



# Generated at 2022-06-17 14:35:16.093089
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars
    assert len(vars) == 2
    assert list(vars) == ['foo', 'baz']
    assert vars.add_locals({'quux': 'corge'})['quux'] == 'corge'
    assert v

# Generated at 2022-06-17 14:35:23.088858
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert len(vars) == 4


# Generated at 2022-06-17 14:35:31.489854
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateSnippet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:35:44.977092
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'foo': 'baz'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'baz'
    assert ajv['foo'] != 'bar'
    assert ajv['foo'] != 'qux'
    assert ajv['foo'] != 'quux'
    globals = {'foo': 'qux'}
    locals = {'foo': 'quux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:35:51.079392
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:35:56.357563
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars


# Generated at 2022-06-17 14:36:09.334593
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVariable

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    # Test case 1: variable is in locals
    locals['var1'] = 'value1'
    vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:36:16.691935
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'b': 4, 'd': 5, 'e': 6}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['a', 'b', 'c', 'd', 'e'])


# Generated at 2022-06-17 14:36:27.434201
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test_global'] == 'test_global_value'
    assert ansible_j2_vars['test_local'] == 'test_local_value'
    assert ansible_j2_vars['vars'] == {}
    assert ansible_j2_vars['hostvars'] == HostVars()

# Generated at 2022-06-17 14:36:36.175827
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'a': 'b'})
    globals = {'c': 'd'}
    locals = {'e': 'f'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['a'] == 'b'
    assert ajv['c'] == 'd'
    assert ajv['e'] == 'f'
    assert 'a' in ajv
    assert 'c' in ajv
    assert 'e' in ajv
    assert 'b' not in ajv
    assert 'd' not in ajv
    assert 'f' not in ajv
    assert len(ajv) == 3

# Generated at 2022-06-17 14:36:41.659840
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:36:46.006869
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {'g_a': 'g_a'}
    locals = {'l_a': 'l_a'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_a' in vars
    assert 'l_a' in vars
    assert 'a' not in vars


# Generated at 2022-06-17 14:36:52.730776
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:37:00.121402
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-17 14:37:08.952889
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost

    templar = Templar(loader=None)
    globals = {'a': 'A', 'b': 'B', 'c': 'C'}
    locals = {'d': 'D', 'e': 'E', 'f': 'F'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert vars['a'] == 'A'
    assert vars

# Generated at 2022-06-17 14:37:15.471053
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'g_bar'}
    locals = {'l_foo': 'l_bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars


# Generated at 2022-06-17 14:37:28.829871
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_key1': 'g_val1', 'g_key2': 'g_val2'}
    locals = {'l_key1': 'l_val1', 'l_key2': 'l_val2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g_key1', 'g_key2', 'l_key1', 'l_key2'])


# Generated at 2022-06-17 14:37:35.779075
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['undefined'] == KeyError

# Generated at 2022-06-17 14:37:44.903683
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['l_baz'] == 'qux'
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'l_baz' in vars
    assert 'quux' not in vars
    assert len(vars) == 3

# Generated at 2022-06-17 14:37:56.444242
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeUrl
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTimestamp
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict

# Generated at 2022-06-17 14:38:03.309367
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(j2vars) == set(['g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:38:13.347714
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'l_d': 4, 'l_e': 5, 'l_f': 6}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['a'] == 1
    assert vars['b'] == 2
    assert vars['c'] == 3
    assert vars['d'] == 4
    assert vars['e'] == 5
    assert vars['f'] == 6
    assert vars['g'] == missing
    assert vars['h'] == missing
    assert vars['i'] == missing
    assert vars

# Generated at 2022-06-17 14:38:24.389533
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars']['foo'] == 'bar'

# Generated at 2022-06-17 14:38:29.138419
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars
    assert 'f' not in vars


# Generated at 2022-06-17 14:38:38.503844
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)
    globals = {'foo': 'bar'}
    locals = {'bar': 'foo'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:38:45.523000
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVariable
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTuple

# Generated at 2022-06-17 14:39:03.809384
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    assert 'bar' not in vars


# Generated at 2022-06-17 14:39:13.859563
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['test_global'] == 'test_global_value'
    assert j2vars['test_local'] == 'test_local_value'
    templar.available_variables = {'test_available_variable': 'test_available_variable_value'}

# Generated at 2022-06-17 14:39:20.907339
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    available_variables = {'a1': 'a1', 'a2': 'a2'}
    templar.available_variables = available_variables
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_j2_vars) == set(['g1', 'g2', 'l1', 'l2', 'a1', 'a2'])
    # test with HostVars


# Generated at 2022-06-17 14:39:26.744358
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

# Generated at 2022-06-17 14:39:36.303090
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test for existing variable
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

    # Test for non-existing variable
    try:
        vars['quux']
    except KeyError as e:
        assert e.args[0] == "undefined variable: quux"
    else:
        assert False, 'KeyError not raised'

# Generated at 2022-06-17 14:39:46.708047
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateSnippet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:39:58.055102
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == vars
    assert isinstance(vars['vars'], AnsibleJ2Vars)
    assert isinstance(vars['hostvars'], HostVars)
    assert isinstance(vars['hostvars'], dict)
    assert isinstance(vars['hostvars'], Mapping)

# Generated at 2022-06-17 14:40:07.387456
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in ajv
    assert 'g2' in ajv
    assert 'l1' in ajv
    assert 'l2' in ajv

# Generated at 2022-06-17 14:40:18.116602
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_bar': 'foo'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['bar'] == 'foo'
    assert ajv['vars'] == templar.available_variables
    assert isinstance(ajv['vars'], HostVars)
    assert isinstance(ajv['vars']['foo'], AnsibleUnsafeText)

# Generated at 2022-06-17 14:40:28.416814
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert aj2v['a'] == 1
    assert aj2v['b'] == 2
    assert aj2v['c'] == 3
    assert aj2v['d'] == 4
    assert aj2v['e'] == 5
    assert aj2v['f'] == 6
    assert aj2v['g'] == 7
    assert aj2v['h'] == 8
    assert aj2v['i'] == 9


# Generated at 2022-06-17 14:41:08.592146
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar', 'baz': 'qux'}
    locals = {'l_foo': 'bar', 'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['l_foo'] == 'bar'
    assert vars['l_baz'] == 'qux'
    assert len(vars) == 4
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'l_foo' in vars


# Generated at 2022-06-17 14:41:18.621840
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4
    vars._templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    assert len(vars) == 6
    vars._templar.available_variables = {'v1': 'v1', 'v2': 'v2', 'l1': 'v1'}

# Generated at 2022-06-17 14:41:28.697288
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:41:31.804665
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars is not None

# Generated at 2022-06-17 14:41:43.435713
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 0
    globals['a'] = 1
    assert len(vars) == 1
    locals['b'] = 2
    assert len(vars) == 2
    templar.available_variables['c'] = 3
    assert len(vars) == 3


# Generated at 2022-06-17 14:41:53.373523
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateV

# Generated at 2022-06-17 14:42:00.991078
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'d': 4, 'e': 5, 'f': 6}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 6


# Generated at 2022-06-17 14:42:13.619995
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    templar = Templar(loader=None, variables={})
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with locals
    assert j2vars['test_local'] == 'test_local_value'

    # test __getitem__ with globals

# Generated at 2022-06-17 14:42:23.561793
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import jinja2
    import os
    import sys

    # Create a Templar object
    templar = Templar(loader=None, variables={})

    # Create a AnsibleJ2Vars object
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Test __getitem__ with a local variable
    assert ansible_j2_vars['baz'] == 'qux'

    # Test __getitem__ with a global variable
    assert ansible_j2_

# Generated at 2022-06-17 14:42:29.447911
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict(foo='bar')
    locals = dict(baz='qux')
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['quux'] == 'quux'