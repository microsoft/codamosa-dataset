

# Generated at 2022-06-17 14:32:56.207081
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:33:00.630094
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['quux'] == 'quux'
    try:
        vars['quuz']
    except KeyError as e:
        assert str(e) == 'undefined variable: quuz'
    else:
        raise AssertionError('KeyError not raised')

# Generated at 2022-06-17 14:33:08.981984
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['test_global'] == 'test_global_value'
    assert ajv['test_local'] == 'test_local_value'
    assert ajv['vars'] == {}
    assert ajv['hostvars'] == HostVars()
    assert ajv['test_undefined'] == KeyError

# Generated at 2022-06-17 14:33:19.999095
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None, variables={'foo': 'bar'})
    globals = {'baz': 'qux'}
    locals = {'l_quux': 'corge'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ajv
    assert 'baz' in ajv
    assert 'quux' in ajv
    assert 'corge' in ajv
    assert 'grault' not in ajv
    assert 'garply' not in ajv
    assert 'waldo' not in ajv

# Generated at 2022-06-17 14:33:26.416686
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1'}
    locals = {'l1': 'l1'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'l1' in vars
    assert 'v1' not in vars


# Generated at 2022-06-17 14:33:36.661459
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBool
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt


# Generated at 2022-06-17 14:33:45.227220
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in vars
    locals['foo'] = 'bar'
    assert 'foo' in vars
    globals['foo'] = 'bar'
    assert 'foo' in vars
    templar.available_variables['foo'] = 'bar'
    assert 'foo' in vars


# Generated at 2022-06-17 14:33:50.377761
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:34:01.414288
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == 'b'
    assert ansible_j2_vars['c'] == 'd'
    assert ansible_j2_vars['vars'] == {}
    assert ansible_j2_vars['hostvars'] == HostVars()
    assert ansible_j2_vars['hostvars']['a'] == 'b'

# Generated at 2022-06-17 14:34:09.204160
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Test case 1: variable is in locals


# Generated at 2022-06-17 14:34:21.193777
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in j2vars
    assert 'g2' in j2vars
    assert 'l1' in j2vars
    assert 'l2' in j2vars
    assert 'g3' not in j2vars
    assert 'l3' not in j2vars


# Generated at 2022-06-17 14:34:32.429029
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_var': 'g_value'}
    locals = {'l_var': 'l_value'}
    vars = {'v_var': 'v_value'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_var' in ansible_j2_vars
    assert 'l_var' in ansible_j2_vars
    assert 'v_var' in ansible_j2_vars
    assert 'not_var' not in ansible_j2_vars

# Unit

# Generated at 2022-06-17 14:34:41.643398
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars


# Generated at 2022-06-17 14:34:48.175755
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

    try:
        vars['quux']
        assert False
    except KeyError:
        pass

# Generated at 2022-06-17 14:34:53.407878
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['a', 'b', 'c', 'd'])

# Generated at 2022-06-17 14:35:03.931023
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test_global'] == 'test_global_value'
    assert ansible_j2_vars['test_local'] == 'test_local_value'
    assert ansible_j2_vars['vars'] == {}
    assert ansible_j2_vars['hostvars'] == HostVars()

# Generated at 2022-06-17 14:35:16.204305
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'a': 'b', 'c': 'd'}
    locals = {'e': 'f', 'g': 'h'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(j2vars) == set(['a', 'c', 'e', 'g'])
    templar.available_variables = {'i': 'j', 'k': 'l'}
    assert set(j2vars) == set(['a', 'c', 'e', 'g', 'i', 'k'])


# Generated at 2022-06-17 14:35:27.284429
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_key': 'g_value'}
    locals = {'l_key': 'l_value'}
    available_variables = {'av_key': 'av_value'}
    templar._available_variables = available_variables
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_key' in ansible_j2_vars
    assert 'l_key' in ansible_j2_vars
    assert 'av_key' in ansible_j2_vars
    assert 'not_exist' not in ansible_j2

# Generated at 2022-06-17 14:35:37.714230
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFile
   

# Generated at 2022-06-17 14:35:44.057111
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_foo': 'g_bar', 'g_baz': 'g_qux'}
    locals = {'l_foo': 'l_bar', 'l_baz': 'l_qux'}
    vars = {'foo': 'bar', 'baz': 'qux'}
    templar._available_variables = vars
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:36:00.492822
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in ajv
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in ajv
    templar.available_variables = {'foo': 'bar', 'baz': 'qux'}
    assert 'baz' in ajv
    templar.available_variables = {'foo': 'bar', 'baz': 'qux', 'quux': 'quuz'}
    assert 'quux' in ajv
    globals = {'foo': 'bar'}
    ajv = Ans

# Generated at 2022-06-17 14:36:09.779700
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 4
    ansible_j2_vars._templar.available_variables = {'e': 5, 'f': 6}
    assert len(ansible_j2_vars) == 6
    ansible_j2_vars._templar.available_variables = {'a': 7, 'b': 8}

# Generated at 2022-06-17 14:36:20.321427
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # Test with locals
    assert j2vars['l_baz'] == 'qux'

    # Test with globals
    assert j2vars['foo'] == 'bar'

    # Test with available variables
   

# Generated at 2022-06-17 14:36:27.646524
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateV

# Generated at 2022-06-17 14:36:33.644541
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'test_global': 'global'}
    locals = {'test_local': 'local'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test_global' in ansible_j2_vars
    assert 'test_local' in ansible_j2_vars
    assert 'test_undefined' not in ansible_j2_vars


# Generated at 2022-06-17 14:36:42.133402
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)
    # test for KeyError
    try:
        vars['undefined_variable']
    except KeyError as e:
        assert e.args[0] == "undefined variable: undefined_variable"
    # test for AnsibleUndefinedVariable
    try:
        vars['undefined_variable']
    except AnsibleUndefinedVariable as e:
        assert e.args[0] == "undefined_variable: 'undefined_variable' is undefined"
    # test for AnsibleError

# Generated at 2022-06-17 14:36:48.639335
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in ansible_j2_vars
    assert 'b' in ansible_j2_vars
    assert 'c' in ansible_j2_vars
    assert 'd' in ansible_j2_vars
    assert 'e' not in ansible_j2_vars


# Generated at 2022-06-17 14:36:58.857432
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'foo': 'bar'})
    globals = {'baz': 'qux'}
    locals = {'l_quux': 'quuz'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in j2vars
    assert 'baz' in j2vars
    assert 'quux' in j2vars
    assert 'quuz' not in j2vars
    assert 'quuz' not in j2vars
    assert 'quuz' not in j2vars
    assert 'quuz'

# Generated at 2022-06-17 14:37:05.557623
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars


# Generated at 2022-06-17 14:37:15.794368
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['a'] == 'b'
    assert j2vars['c'] == 'd'
    assert j2vars['vars'] == {}
    assert j2vars['hostvars'] == HostVars()
    assert j2vars['hostvars']['a'] == 'b'
    assert j2vars['hostvars']['c'] == 'd'
    assert j2vars['hostvars']['vars']

# Generated at 2022-06-17 14:37:31.609185
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeObject
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import unwrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeObject
    from ansible.vars.unsafe_proxy import wrap_var

# Generated at 2022-06-17 14:37:41.051055
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_key1': 'g_val1', 'g_key2': 'g_val2'}
    locals = {'l_key1': 'l_val1', 'l_key2': 'l_val2'}
    vars = {'key1': 'val1', 'key2': 'val2'}
    templar._available_variables = vars
    ajv = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:37:51.925223
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['foo'] == 'bar'
    assert ansible_j2_vars['baz'] == 'qux'
    assert ansible_j2_vars['vars'] == HostVars()
    assert ansible_j2_vars['vars']['inventory_hostname'] == 'localhost'

# Generated at 2022-06-17 14:37:59.371025
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars


# Generated at 2022-06-17 14:38:08.656234
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars


# Generated at 2022-06-17 14:38:18.512458
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_a': 'g_a', 'g_b': 'g_b'}
    locals = {'l_a': 'l_a', 'l_b': 'l_b'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_a' in vars
    assert 'g_b' in vars
    assert 'l_a' in vars
    assert 'l_b' in vars
    assert 'a' not in vars
    assert 'b' not in vars


# Generated at 2022-06-17 14:38:27.998211
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar()
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = {'v1': 'v1', 'v2': 'v2'}
    templar.set_available_variables(vars)
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in ajv
    assert 'g2' in ajv
    assert 'l1' in ajv
    assert 'l2' in a

# Generated at 2022-06-17 14:38:34.693396
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:38:45.186003
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_var1': 'g_val1', 'g_var2': 'g_val2'}
    locals = {'l_var1': 'l_val1', 'l_var2': 'l_val2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_var1' in vars
    assert 'g_var2' in vars
    assert 'l_var1' in vars
    assert 'l_var2' in vars
    assert 'var1' not in vars
    assert 'var2' not in vars


# Generated at 2022-06-17 14:38:55.036196
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'A'}
    locals = {'b': 'B'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['a'] == 'A'
    assert j2vars['b'] == 'B'
    assert j2vars['c'] == 'C'
    assert j2vars['d'] == 'D'
    assert j2vars['e'] == 'E'
    assert j2vars['f'] == 'F'
    assert j2vars['g'] == 'G'
    assert j2vars['h'] == 'H'

# Generated at 2022-06-17 14:39:12.808797
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ajv = AnsibleJ2Vars(templar, globals, locals)

    # test with a dict
    ajv._templar.available_variables = {'vars': {'a': 'b'}}
    assert ajv['vars'] == {'a': 'b'}

    # test with a HostVars
    ajv._templar.available_variables = {'vars': HostVars()}
    assert isinstance(ajv['vars'], HostVars)

    # test

# Generated at 2022-06-17 14:39:18.034997
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars


# Generated at 2022-06-17 14:39:25.586663
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_j2_vars) == set(['a', 'b', 'c', 'd'])


# Generated at 2022-06-17 14:39:32.064832
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global'}
    locals = {'test_local': 'test_local'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test_global' in j2vars
    assert 'test_local' in j2vars
    assert 'test_undefined' not in j2vars
    templar.available_variables = {'test_available_variables': 'test_available_variables'}
    assert 'test_available_variables' in j2vars
   

# Generated at 2022-06-17 14:39:44.445871
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_test': 'g_test'}
    locals = {'l_test': 'l_test'}
    vars = {'v_test': 'v_test'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_test' in ansible_j2_vars
    assert 'l_test' in ansible_j2_vars
    assert 'v_test' in ansible_j2_vars
    assert 'test' not in ansible_j2_vars


# Generated at 2022-06-17 14:39:53.710886
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.hostvars import HostVars
    import os
    import sys
    import json
    import pytest
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    cfgfile = os.path.join(tmpdir, "ansible.cfg")

# Generated at 2022-06-17 14:40:03.926994
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTimed

# Generated at 2022-06-17 14:40:11.422966
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == 1
    assert ansible_j2_vars['b'] == 2
    assert ansible_j2_vars['c'] == 3
    assert ansible_j2_vars['d'] == 4
    assert ansible_j2_vars['e'] == 5
    assert isinstance(ansible_j2_vars['vars'], HostVars)
   

# Generated at 2022-06-17 14:40:17.179691
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    try:
        vars['quux']
    except KeyError:
        pass
    else:
        assert False, 'KeyError not raised'

# Generated at 2022-06-17 14:40:26.936906
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'bar': 'foo'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['foo'] == 'bar'
    assert ansible_j2_vars['bar'] == 'foo'
    assert ansible_j2_vars.add_locals({'foo': 'bar'})['foo'] == 'bar'
    assert ansible_j2_vars.add_locals({'foo': 'bar'})['bar'] == 'foo'

# Generated at 2022-06-17 14:41:07.645876
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:41:17.790792
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['vars'] == templar.available_variables
    assert ajv['hostvars'] == HostVars(templar)
    assert ajv['hostvars']['localhost'] == templar.available_variables

# Generated at 2022-06-17 14:41:27.962823
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    templar.available_variables['v3'] = HostVars()
    templar.available_variables['v4'] = AnsibleUnsafeText('v4')
    ajv = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:41:38.121970
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {}
    locals = {}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in ajv
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in ajv
    templar.available_variables = {}
    globals = {'foo': 'bar'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ajv
    locals = {'foo': 'bar'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ajv

# Unit test

# Generated at 2022-06-17 14:41:45.057424
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test_global'] == 'test_global_value'
    assert ansible_j2_vars['test_local'] == 'test_local_value'

# Generated at 2022-06-17 14:41:54.408618
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:41:58.552908
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_bar': 'foo'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['bar'] == 'foo'
    assert vars['l_bar'] == 'foo'
    assert vars['l_foo'] == 'bar'
    assert vars['l_foo'] == 'bar'
    assert vars['l_bar'] == 'foo'
    assert vars['l_bar'] == 'foo'
    assert vars['l_bar'] == 'foo'

# Generated at 2022-06-17 14:42:07.099573
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'
    assert vars['undefined'] == 'undefined'

# Generated at 2022-06-17 14:42:17.417382
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Test case 1: varname in self._locals
    varname = 'test_varname'
    ansible_j2_vars._locals[varname] = 'test_value'
    assert ansible_j2_vars[varname] == 'test_value'

    # Test case 2: varname in self._templar.available_variables
    varname = 'test_varname'

# Generated at 2022-06-17 14:42:26.221288
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['l_foo'] == 'bar'
    assert vars['vars'] == templar.available_variables
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars'].__UNSAFE__ == True
    assert vars['vars']['foo'] == 'bar'
    assert vars['vars']['l_foo'] == 'bar'
