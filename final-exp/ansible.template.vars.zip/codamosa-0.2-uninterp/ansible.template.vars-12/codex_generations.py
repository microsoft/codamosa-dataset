

# Generated at 2022-06-17 14:32:58.094268
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars']['foo'] == 'bar'
    assert vars['vars']['baz'] == 'qux'
    assert vars['vars']['vars'] == templar

# Generated at 2022-06-17 14:33:07.854850
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['foo'] == 'bar'
    assert ansible_j2_vars['baz'] == 'qux'
    assert ansible_j2_vars['vars'] == {}
    assert ansible_j2_vars['hostvars'] == {}
    assert ansible_j2_vars['inventory_hostname'] == ''

# Generated at 2022-06-17 14:33:18.443198
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'g_key1': 'g_val1', 'g_key2': 'g_val2'}
    locals = {'l_key1': 'l_val1', 'l_key2': 'l_val2'}
    ansible_vars = {'key1': 'val1', 'key2': 'val2'}
    templar._available_variables = ansible_vars


# Generated at 2022-06-17 14:33:29.463981
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_a': 'g_a', 'g_b': 'g_b'}
    locals = {'l_a': 'l_a', 'l_b': 'l_b'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_a' in vars
    assert 'g_b' in vars
    assert 'l_a' in vars
    assert 'l_b' in vars
    assert 'g_c' not in vars
    assert 'l_c' not in vars


# Generated at 2022-06-17 14:33:37.099682
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'g2' in vars
    assert 'l1' in vars
    assert 'l2' in vars
    assert 'g3' not in vars
    assert 'l3' not in vars


# Generated at 2022-06-17 14:33:45.585708
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_bar': 'foo'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['foo'] == 'bar'
    assert j2vars['bar'] == 'foo'
    assert j2vars['vars'] == {}
    assert j2vars['hostvars'] == HostVars()
    assert j2vars['hostvars']['localhost'] == {}
    assert j2vars['hostvars']['localhost']['ansible_all_ipv4_addresses'] == []
    assert j2

# Generated at 2022-06-17 14:33:54.931622
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import wrap_var

    templar = Templar(loader=None)
    globals = {'test_global': 'global'}
    locals = {'test_local': 'local'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with locals
    assert j2vars['test_local'] == 'local'

    # test __getitem__ with globals

# Generated at 2022-06-17 14:34:03.789289
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative

    templar = Templar(loader=None, variables={})

    # Test for variable in locals
    locals = {'test': 'test'}
    vars = AnsibleJ2Vars(templar, {}, locals)
    assert vars['test'] == 'test'

    # Test for variable in available_variables
    templar._available_variables = {'test': 'test'}
    vars = AnsibleJ2Vars(templar, {})

# Generated at 2022-06-17 14:34:11.776576
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in j2vars
    assert 'baz' in j2vars
    assert 'qux' not in j2vars
    templar.available_variables = {'qux': 'quux'}
    assert 'qux' in j2vars
    templar.available_variables = {'qux': HostVars()}
    assert 'qux' in j2vars


# Generated at 2022-06-17 14:34:19.121809
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    available_variables = {'a1': 'a1', 'a2': 'a2'}
    templar.set_available_variables(available_variables)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_j2_vars) == set(['a1', 'a2', 'g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:34:36.865669
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'d': 4, 'e': 5, 'f': 6}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert len(ajv) == 6
    ajv._templar.available_variables = {'g': 7, 'h': 8, 'i': 9}
    assert len(ajv) == 9
    ajv._templar.available_variables = {'a': 1, 'b': 2, 'c': 3}
    assert len(ajv) == 9
    ajv._templ

# Generated at 2022-06-17 14:34:42.148848
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_j2_vars.__iter__()) == set(['a', 'c'])

# Generated at 2022-06-17 14:34:46.636488
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 4


# Generated at 2022-06-17 14:34:52.487163
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(j2vars) == set(['foo', 'baz'])

# Generated at 2022-06-17 14:35:01.094087
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'c' in j2vars
    assert 'd' in j2vars
    assert 'e' not in j2vars


# Generated at 2022-06-17 14:35:10.164992
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ajv = AnsibleJ2Vars(templar, globals, locals)
    # test for undefined variable
    try:
        ajv['undefined_variable']
    except KeyError as e:
        assert e.args[0] == "undefined variable: undefined_variable"
    # test for undefined variable
    try:
        ajv['undefined_variable']
    except KeyError as e:
        assert e.args[0] == "undefined variable: undefined_variable"
    # test for undefined variable

# Generated at 2022-06-17 14:35:17.058120
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == 'b'
    assert ansible_j2_vars['c'] == 'd'
    assert ansible_j2_vars['vars'] == {}
    assert ansible_j2_vars['hostvars'] == {}

# Generated at 2022-06-17 14:35:27.596196
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables['vars']
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars'].__UNSAFE__
    assert vars['vars'].__UNSAFE__ == templar.available_variables['vars'].__UNSAFE__


# Generated at 2022-06-17 14:35:35.155731
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'bar': 'foo'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ansible_j2_vars
    assert 'bar' in ansible_j2_vars
    assert 'baz' not in ansible_j2_vars


# Generated at 2022-06-17 14:35:46.083437
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test with a local variable
    assert vars['baz'] == 'qux'

    # Test with a global variable
    assert vars['foo'] == 'bar'

    # Test with a variable from the templar
    templar.available_variables = {'var': 'value'}
    assert v

# Generated at 2022-06-17 14:36:09.142625
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {
        'foo': 'bar',
        'baz': 'qux',
    }
    locals = {
        'foo': 'bar',
        'baz': 'qux',
    }
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['foo'] == 'bar'
    assert ansible_j2_vars['baz'] == 'qux'
    assert ansible_j2_vars['vars'] == {}
    assert ansible_j2_vars['hostvars'] == {}
    assert ansible_j2_v

# Generated at 2022-06-17 14:36:16.955067
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars


# Generated at 2022-06-17 14:36:19.172559
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['foo'] == 'bar'
    assert j2vars['baz'] == 'qux'

# Generated at 2022-06-17 14:36:28.743396
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:36:37.026704
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['foo'] == 'bar'
    assert ansible_j2_vars['baz'] == 'qux'
    assert ansible_j2_vars['vars'] == HostVars()
    assert ansible_j2_vars['vars']['inventory_hostname'] == 'localhost'

# Generated at 2022-06-17 14:36:43.495384
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert aj2v['a'] == 'b'
    assert aj2v['c'] == 'd'
    assert aj2v['vars'] == {}
    assert aj2v['hostvars'] == HostVars()
    assert aj2v['undefined'] == KeyError

# Generated at 2022-06-17 14:36:50.950620
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['foo'] == 'bar'
    assert ansible_j2_vars['baz'] == 'qux'
    assert ansible_j2_vars['vars'] == {}
    assert ansible_j2_vars['hostvars'] == {}
    assert ansible_j2_vars['groups'] == {}
    assert ansible_j2_vars['group_names'] == []
   

# Generated at 2022-06-17 14:36:53.914343
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert isinstance(ansible_j2_vars, AnsibleJ2Vars)
    assert isinstance(ansible_j2_vars, Mapping)


# Generated at 2022-06-17 14:37:03.820766
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, play_context=play_context)

    # test __getitem__ with locals
    locals

# Generated at 2022-06-17 14:37:14.697328
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'foo': 'baz'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'baz'
    assert vars['foo'] != 'bar'
    assert vars['foo'] != 'foo'
    assert vars['foo'] != 'foobar'
    assert vars['foo'] != 'foobaz'
    assert vars['foo'] != 'barbaz'
    assert vars['foo'] != 'barfoo'
    assert vars['foo'] != 'bazfoo'

# Generated at 2022-06-17 14:37:38.871734
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:37:45.741841
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'foo': 'baz'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'baz'
    assert vars['bar'] == 'baz'
    assert vars['foo'] == 'baz'
    assert vars['bar'] == 'baz'
    assert vars['foo'] == 'baz'
    assert vars['bar'] == 'baz'
    assert vars['foo'] == 'baz'
    assert vars['bar'] == 'baz'

# Generated at 2022-06-17 14:37:57.272336
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars

# Generated at 2022-06-17 14:38:07.773314
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVariable

    templar = Templar(loader=None, variables={})
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with locals

# Generated at 2022-06-17 14:38:14.968782
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['vars'] == templar.available_variables
    assert ajv['hostvars'] == HostVars(templar)
    assert ajv['hostvars']['localhost'] == templar.available_variables

# Generated at 2022-06-17 14:38:25.721511
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import iteritems

# Generated at 2022-06-17 14:38:36.064309
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=DataLoader(), sources='')
    host = Host(name='test_host')
    group = Group(name='test_group')
    inventory.add_host(host, group)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 14:38:43.320250
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars


# Generated at 2022-06-17 14:38:52.781565
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_a': 'g_a', 'g_b': 'g_b'}
    locals = {'l_a': 'l_a', 'l_b': 'l_b'}
    templar.available_variables = {'a': 'a', 'b': 'b'}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in aj2v
    assert 'b' in aj2v
    assert 'l_a' in aj2v
    assert 'l_b'

# Generated at 2022-06-17 14:39:01.963976
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars


# Generated at 2022-06-17 14:39:38.303545
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'bar': 'foo'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['bar'] == 'foo'
    assert vars['vars'] == templar.available_variables['vars']
    assert isinstance(vars['vars'], HostVars)
    assert isinstance(vars['foo'], AnsibleUnsafeText)

# Generated at 2022-06-17 14:39:49.022154
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_var': 'g_value'}
    locals = {'l_var': 'l_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['g_var'] == 'g_value'
    assert vars['l_var'] == 'l_value'
    assert vars['vars'] == templar.available_variables
    assert vars['hostvars'] == HostVars(templar._available_variables['hostvars'])
    assert vars['inventory_hostname'] == templar.available_variables['inventory_hostname']
    assert v

# Generated at 2022-06-17 14:39:56.113334
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = {'v1': 'v1', 'v2': 'v2'}
    templar._available_variables = vars
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert set(aj2v) == set(['g1', 'g2', 'l1', 'l2', 'v1', 'v2'])
    # test with HostVars
    templar._available_variables = HostVars

# Generated at 2022-06-17 14:40:05.849662
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeObject
    from ansible.vars.unsafe_proxy import wrap_var

    templar = Templar(loader=None, variables={})
    globals = {'foo': 'bar'}
    locals = {'l_bar': 'foo'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with locals
    assert j2vars['l_bar'] == 'foo'

    # test __getitem__ with glob

# Generated at 2022-06-17 14:40:17.258148
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test __contains__

# Generated at 2022-06-17 14:40:24.106560
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:40:31.734169
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'g_bar'}
    locals = {'l_foo': 'l_bar'}
    vars = {'foo': 'bar'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ansible_j2_vars
    assert 'l_foo' in ansible_j2_vars
    assert 'g_foo' in ansible_j2_vars
    assert 'bar' not in ansible_j2_vars
    assert 'l_bar' not in ansible

# Generated at 2022-06-17 14:40:44.864507
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}

    # Test with a HostVars object
    hostvars = HostVars(hostname='localhost')
    hostvars.update({'foo': 'bar'})
    hostvars.update({'baz': 'qux'})
    vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:40:53.363938
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in ajv
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in ajv
    templar.available_variables = dict()
    globals['foo'] = 'bar'
    assert 'foo' in ajv
    globals = dict()
    locals['foo'] = 'bar'
    assert 'foo' in ajv


# Generated at 2022-06-17 14:40:59.790302
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeSet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeObject

    templar = Templar(loader=None)
    globals = {}
    locals

# Generated at 2022-06-17 14:42:00.869463
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTemplateSnippet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:42:13.534740
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_key1': 'g_value1', 'g_key2': 'g_value2'}
    locals = {'l_key1': 'l_value1', 'l_key2': 'l_value2'}
    templar.available_variables = {'v_key1': 'v_value1', 'v_key2': 'v_value2'}
    ajv = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:42:19.507349
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'a': 1})
    vars = AnsibleJ2Vars(templar, {'b': 2}, locals={'c': 3})
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' not in vars


# Generated at 2022-06-17 14:42:29.678704
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNative
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import unwrap_var

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with locals

# Generated at 2022-06-17 14:42:40.267112
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList


# Generated at 2022-06-17 14:42:49.267838
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars
    try:
        vars['quux']
        assert False
    except KeyError:
        pass
    assert len(vars) == 2
    assert set(vars) == set(['foo', 'baz'])
    assert set(iter(vars)) == set(['foo', 'baz'])