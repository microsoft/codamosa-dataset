

# Generated at 2022-06-17 14:32:54.826365
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars


# Generated at 2022-06-17 14:33:00.862561
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'a': 'b'})
    j2vars = AnsibleJ2Vars(templar, {'a': 'b'})
    assert j2vars['a'] == 'b'
    assert j2vars['c'] == 'd'

# Generated at 2022-06-17 14:33:09.538104
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test locals
    assert vars['l_baz'] == 'qux'

    # test globals
    assert vars['foo'] == 'bar'

    # test available variables
    templar.available_variables = {'foo': 'bar'}
    assert vars['foo'] == 'bar'

    # test HostVars

# Generated at 2022-06-17 14:33:14.311222
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test_global' in vars
    assert 'test_local' in vars
    assert 'test_not_exist' not in vars


# Generated at 2022-06-17 14:33:21.854979
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 3
    assert len(ansible_j2_vars) == len(globals) + len(locals) + len(templar.available_variables)


# Generated at 2022-06-17 14:33:32.936153
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    import pytest
    # Test 1: Test if the variable is in locals
    templar = Templar(loader=None)
    globals = {}
    locals = {'test': 'test'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test'] == 'test'
    # Test 2: Test if the variable is in available_variables
    templar = Templar(loader=None)
    globals = {}
    locals = {}
    templar.available_variables = {'test': 'test'}

# Generated at 2022-06-17 14:33:38.703836
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars

# Generated at 2022-06-17 14:33:49.294280
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['a'] == 1
    assert ajv['b'] == 2
    assert ajv['c'] == 3
    assert ajv['d'] == 4
    assert ajv['e'] == 5
    assert ajv['f'] == 6
    assert ajv['g'] == 7
    assert ajv['h'] == 8
    assert ajv['i'] == 9
    assert ajv['j'] == 10

# Generated at 2022-06-17 14:33:55.129203
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedBytes
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleBytes

# Generated at 2022-06-17 14:34:00.277754
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars


# Generated at 2022-06-17 14:34:14.471063
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    templar.available_variables = {'a1': 'a1', 'a2': 'a2'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in ansible_j2_vars
    assert 'g2' in ansible_j2_vars
    assert 'l1' in ansible_j2_vars
    assert 'l2' in ansible_j2_

# Generated at 2022-06-17 14:34:23.664750
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt


# Generated at 2022-06-17 14:34:31.417073
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:34:41.355239
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])

# Generated at 2022-06-17 14:34:50.608711
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in ansible_j2_vars
    templar.available_variables = dict()
    assert 'foo' not in ansible_j2_vars
    templar.available_variables = dict(foo='bar')
    assert 'foo' in ansible_j2_vars
    templar.available_variables = dict()
    globals = dict(foo='bar')
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ansible_j

# Generated at 2022-06-17 14:34:59.720495
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookupVal
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with locals

# Generated at 2022-06-17 14:35:08.758288
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:35:14.504094
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert sorted(list(vars)) == sorted(['g1', 'g2', 'l1', 'l2'])

# Generated at 2022-06-17 14:35:26.233439
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test' not in ansible_j2_vars
    ansible_j2_vars._templar.available_variables['test'] = 'test'
    assert 'test' in ansible_j2_vars
    ansible_j2_vars._locals['test'] = 'test'
    assert 'test' in ansible_j2_vars
    ansible_j2_vars._globals['test'] = 'test'
    assert 'test' in ansible_j2_vars


# Generated at 2022-06-17 14:35:34.532563
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in ansible_j2_vars
    assert 'b' not in ansible_j2_vars
    assert 'c' in ansible_j2_vars
    assert 'd' not in ansible_j2_vars


# Generated at 2022-06-17 14:35:47.497962
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    globals = dict()
    locals = dict()

    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'inventory_hostname' in j2vars
    assert 'inventory_hostname_short' in j2vars
    assert 'groups' in j2vars
    assert 'group_names' in j2vars
    assert 'omit' in j2vars

# Generated at 2022-06-17 14:35:58.141652
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'fizz': 'buzz'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test for global variable
    assert vars['foo'] == 'bar'

    # test for local variable
    assert vars['fizz'] == 'buzz'

    # test for undefined variable
    try:
        vars['undefined']
    except KeyError as e:
        assert str(e) == "undefined variable: undefined"

# Generated at 2022-06-17 14:36:09.025193
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_var': 'g_var'}
    locals = {'l_var': 'l_var'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['g_var'] == 'g_var'
    assert vars['l_var'] == 'l_var'
    assert vars['vars'] == HostVars()
    assert vars['vars'].__UNSAFE__ == True
    assert vars['vars'].__UNSAFE__ == True
    assert vars['vars'].__UNSAFE__ == True
    assert vars['vars'].__UN

# Generated at 2022-06-17 14:36:19.978482
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt


# Generated at 2022-06-17 14:36:29.301022
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test_global'] == 'test_global_value'
    assert ansible_j2_vars['test_local'] == 'test_local_value'
    templar.available_variables = {'test_available_variable': 'test_available_variable_value'}

# Generated at 2022-06-17 14:36:33.343753
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 4


# Generated at 2022-06-17 14:36:41.254691
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_key1': 'g_value1', 'g_key2': 'g_value2'}
    locals = {'l_key1': 'l_value1', 'l_key2': 'l_value2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_key1' in vars
    assert 'g_key2' in vars
    assert 'l_key1' in vars
    assert 'l_key2' in vars
    assert 'key1' not in vars
    assert 'key2' not in vars


# Generated at 2022-06-17 14:36:45.334285
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['foo', 'baz'])


# Generated at 2022-06-17 14:36:53.006011
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.utils.unsafe_proxy import wrap_var

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    # Test with a dict
    vars = dict(a=1, b=2, c=3)
    locals['vars'] = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == 1
    assert ansible_j2_vars['b'] == 2

# Generated at 2022-06-17 14:37:02.430599
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 'a', 'b': 'b'}
    locals = {'c': 'c', 'd': 'd'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in ansible_j2_vars
    assert 'b' in ansible_j2_vars
    assert 'c' in ansible_j2_vars
    assert 'd' in ansible_j2_vars
    assert 'e' not in ansible_j2_vars


# Generated at 2022-06-17 14:37:27.093765
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['vars'] == templar.available_variables
    assert ajv['hostvars'] == HostVars(templar._available_variables['hostvars'])
    assert ajv['hostvars']['localhost'] == templar._available_variables['hostvars']['localhost']
    assert a

# Generated at 2022-06-17 14:37:33.582934
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}

    ajv = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ for locals
    assert ajv['baz'] == 'qux'

    # test __getitem__ for globals


# Generated at 2022-06-17 14:37:44.457111
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'a': 'b'})
    globals = {'a': 'b'}
    locals = {'a': 'b'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in j2vars
    assert 'b' not in j2vars
    assert 'c' not in j2vars
    assert 'd' not in j2vars
    assert 'e' not in j2vars
    assert 'f' not in j2vars
    assert 'g' not in j2vars
    assert 'h' not in j2vars
    assert 'i' not in j2v

# Generated at 2022-06-17 14:37:49.987535
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_foo': 'bar'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['foo'] == 'bar'
    assert j2vars['l_foo'] == 'bar'
    assert j2vars['vars'] == templar.available_variables
    assert j2vars['hostvars'] == HostVars(templar)
    assert j2vars['hostvars']['localhost'] == templar.available_variables

# Generated at 2022-06-17 14:38:01.366913
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in ajv
    templar.available_variables = dict(foo='bar')
    assert 'foo' in ajv
    locals = dict(foo='bar')
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ajv
    globals = dict(foo='bar')
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ajv


# Generated at 2022-06-17 14:38:10.668964
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars']['foo'] == 'bar'
    assert vars['vars']['baz'] == 'qux'

# Generated at 2022-06-17 14:38:22.102060
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:38:29.557379
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars


# Generated at 2022-06-17 14:38:36.322353
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == templar.available_variables['vars']
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars'].__UNSAFE__ == True

# Generated at 2022-06-17 14:38:40.681715
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'d': 4, 'e': 5, 'f': 6}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 6


# Generated at 2022-06-17 14:39:12.062198
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert set(ajv) == set(['a', 'b', 'c', 'd'])


# Generated at 2022-06-17 14:39:19.652635
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars
    assert len(vars) == 2
    assert set(vars.keys()) == set(['foo', 'baz'])
    assert set(vars.values()) == set(['bar', 'qux'])

# Generated at 2022-06-17 14:39:25.724286
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars
    assert len(vars) == 2
    assert set(vars) == set(['foo', 'baz'])
    assert set(iter(vars)) == set(['foo', 'baz'])

# Generated at 2022-06-17 14:39:32.640986
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['undefined'] == 'undefined'

# Generated at 2022-06-17 14:39:44.636505
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_a': 1, 'g_b': 2}
    locals = {'l_a': 1, 'l_b': 2}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4
    vars._templar.available_variables = {'a': 1, 'b': 2}
    assert len(vars) == 6

# Generated at 2022-06-17 14:39:53.739795
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'global_a'}
    locals = {'b': 'local_b'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['a'] == 'global_a'
    assert vars['b'] == 'local_b'
    assert vars['c'] == 'c'
    assert vars['d'] == 'd'
    assert vars['e'] == 'e'
    assert vars['f'] == 'f'
    assert vars['g'] == 'g'
    assert vars['h'] == 'h'
    assert vars['i'] == 'i'


# Generated at 2022-06-17 14:39:58.950026
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'foo': 'baz'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'bar' not in vars


# Generated at 2022-06-17 14:40:08.101419
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'foo': 'baz'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'baz'
    assert vars['foo'] != 'bar'
    assert vars['foo'] != 'qux'
    assert vars['foo'] != 'quux'
    assert vars['foo'] != 'corge'
    assert vars['foo'] != 'grault'
    assert vars['foo'] != 'garply'
    assert vars['foo'] != 'waldo'
    assert vars['foo'] != 'fred'


# Generated at 2022-06-17 14:40:18.568588
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    globals = {
        'foo': 'bar',
        'baz': 'qux',
    }

    locals = {
        'foo': 'baz',
        'baz': 'quux',
    }


# Generated at 2022-06-17 14:40:28.664851
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['vars'] == templar.available_variables
    assert isinstance(ajv['vars'], HostVars)
    assert ajv['vars'].__UNSAFE__
    assert ajv['vars']['foo'] == 'bar'

# Generated at 2022-06-17 14:41:27.430382
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'g_bar'}
    locals = {'l_foo': 'l_bar'}
    vars = {'foo': 'bar'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['foo'] == 'bar'
    assert ansible_j2_vars['l_foo'] == 'l_bar'
    assert ansible_j2_vars['g_foo'] == 'g_bar'
    assert ansible_j2_vars['vars']

# Generated at 2022-06-17 14:41:37.780381
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBool
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFloat


# Generated at 2022-06-17 14:41:42.452571
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'d': 4, 'e': 5, 'f': 6}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['a', 'b', 'c', 'd', 'e', 'f'])


# Generated at 2022-06-17 14:41:52.812102
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVariable

    # Test for HostVars
    templar = Templar(loader=None, variables={})
    globals = {}
    locals = {}
    hostvars = HostVars(loader=None, variables={})
    hostvars.update({'a': 'b'})

# Generated at 2022-06-17 14:42:00.446704
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:42:12.665173
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    # Test case 1:
    #   - varname is in self._locals
    #   - varname is in self._templar.available_variables
    #   - varname is in self._globals
    #   - variable is a dict and varname is 'vars'
    #   - variable is a HostVars
    #   - variable has attribute

# Generated at 2022-06-17 14:42:14.810632
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'d': 4, 'e': 5, 'f': 6}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert len(ajv) == 6

# Generated at 2022-06-17 14:42:24.119806
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with a variable in locals
    locals['test_var'] = 'test_value'
    assert vars['test_var'] == 'test_value'

    # test __getitem__ with

# Generated at 2022-06-17 14:42:34.816865
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 'A'}
    locals = {'b': 'B'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == 'A'
    assert ansible_j2_vars['b'] == 'B'
    assert ansible_j2_vars['c'] == 'C'
    assert ansible_j2_vars['d'] == 'D'
    assert ansible_j2_vars['e'] == 'E'
    assert ansible_j2_vars['f'] == 'F'

# Generated at 2022-06-17 14:42:47.095697
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars

    # Test that HostVars is special