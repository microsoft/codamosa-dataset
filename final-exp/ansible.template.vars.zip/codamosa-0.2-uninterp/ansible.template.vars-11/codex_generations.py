

# Generated at 2022-06-17 14:33:06.811101
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    templar = Templar(loader=None, variables={})
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'foo' in vars
    assert 'baz' in vars
    assert 'bar' not in vars

    # Test with HostVars

# Generated at 2022-06-17 14:33:14.976777
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_var': 'g_var'}
    locals = {'l_var': 'l_var'}
    vars = {'v_var': 'v_var'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_var' in ansible_j2_vars
    assert 'l_var' in ansible_j2_vars
    assert 'v_var' in ansible_j2_vars
    assert 'no_var' not in ansible_j2_vars

# Unit

# Generated at 2022-06-17 14:33:23.270367
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:33:34.487192
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # test case 1: varname in self._locals
    varname = 'test_varname'

# Generated at 2022-06-17 14:33:39.474074
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars
    assert 'e' not in vars


# Generated at 2022-06-17 14:33:49.931145
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookupVal
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    # Test case 1: variable is in locals
    locals['test_var'] = 'test_value'
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert aj

# Generated at 2022-06-17 14:33:56.335759
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars


# Generated at 2022-06-17 14:34:04.912110
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()
    globals = {'foo': 'bar', 'baz': 'qux'}
    locals = {'l_foo': 'bar', 'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['l_foo'] == 'bar'
    assert vars['l_baz'] == 'qux'
    try:
        vars['undefined']
    except KeyError as e:
        assert str(e) == "undefined variable: undefined"

# Generated at 2022-06-17 14:34:14.783469
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeObject
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeValue
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeT

# Generated at 2022-06-17 14:34:23.872754
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'g2' in vars
    assert 'l1' in vars
    assert 'l2' in vars
    assert 'g3' not in vars
    assert 'l3' not in vars
    assert 'vars' not in vars

# Generated at 2022-06-17 14:34:35.885594
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test_global'] == 'test_global_value'
    assert ansible_j2_vars['test_local'] == 'test_local_value'
    assert ansible_j2_vars['vars'] == {'test_global': 'test_global_value', 'test_local': 'test_local_value'}

# Generated at 2022-06-17 14:34:46.219619
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {}
    locals = {}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['vars'] == {}
    assert ansible_j2_vars['hostvars'] == {}
    assert ansible_j2_vars['groups'] == {}
    assert ansible_j2_vars['omit'] == '__omit_place_holder__'
    assert ansible_j2_vars['ansible_version'] == {}
    assert ansible_j2_vars['ansible_facts'] == {}
    assert ansible_j2_vars['ansible_play_hosts'] == {}
    assert ans

# Generated at 2022-06-17 14:34:56.091381
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in j2vars
    assert 'bar' not in j2vars
    assert 'baz' not in j2vars
    assert 'qux' not in j2vars
    assert 'quux' not in j2vars
    assert 'corge' not in j2vars
    assert 'grault' not in j2vars
    assert 'garply' not in j2vars
    assert 'waldo' not in j2vars
    assert 'fred' not in j2vars
    assert 'plugh' not in j2vars

# Generated at 2022-06-17 14:35:02.067203
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' not in vars


# Generated at 2022-06-17 14:35:10.614810
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars
    templar

# Generated at 2022-06-17 14:35:17.506041
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    available_variables = {'a1': 'a1', 'a2': 'a2'}
    templar.set_available_variables(available_variables)
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_vars) == set(['a1', 'a2', 'g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:35:25.790318
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'test_global' in ansible_j2_vars
    assert 'test_local' in ansible_j2_vars
    assert 'test_undefined' not in ansible_j2_vars


# Generated at 2022-06-17 14:35:35.195565
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    assert ajv['vars'] == templar.available_variables
    assert ajv['hostvars'] == HostVars(templar)

# Generated at 2022-06-17 14:35:38.665200
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

# Generated at 2022-06-17 14:35:46.956409
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars(loader=None, variables={'foo': 'bar'})}
    assert 'foo' in vars


# Generated at 2022-06-17 14:36:02.155267
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

    # HostVars is special, return it as-is, as is the special variable
    # 'vars', which contains the vars structure
    hostvars = HostVars(hostname='localhost')

# Generated at 2022-06-17 14:36:09.311407
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'foo': 'bar'})
    globals = {'baz': 'qux'}
    locals = {'l_quux': 'quuz'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'quux' in vars
    assert 'quuz' not in vars


# Generated at 2022-06-17 14:36:20.092895
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList



# Generated at 2022-06-17 14:36:27.476064
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'g_bar'}
    locals = {'l_foo': 'l_bar'}
    vars = {'foo': 'bar'}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['foo'] == 'bar'
    assert ansible_j2_vars['l_foo'] == 'l_bar'
    assert ansible_j2_vars['g_foo'] == 'g_bar'
    assert ansible_j2_vars['vars']

# Generated at 2022-06-17 14:36:35.265103
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:36:43.564623
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    # Test case 1: varname in self._locals
    # Expect: return self._locals[varname]
    locals['test_varname'] = 'test_value'
    vars = AnsibleJ

# Generated at 2022-06-17 14:36:51.008442
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeSet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTuple
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBool

# Generated at 2022-06-17 14:36:56.233312
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'d': 4, 'e': 5, 'f': 6}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_j2_vars.__iter__()) == set(['a', 'b', 'c', 'd', 'e', 'f'])
    ansible_j2_vars._templar.available_variables['g'] = AnsibleUnsafeText('7')

# Generated at 2022-06-17 14:37:05.036976
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'l_bar': 'foo'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['bar'] == 'foo'
    assert vars['vars'] == templar.available_variables
    assert isinstance(vars['vars'], HostVars)
    assert vars['vars']['foo'] == 'bar'
    assert vars['vars']['bar'] == 'foo'

# Generated at 2022-06-17 14:37:15.657924
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeObject
    from ansible.vars.unsafe_proxy import wrap_var

    templar = Templar(loader=None)
    globals = {}
    locals = {}

    # Test case 1: variable is in locals
    locals['test_var'] = 'test_value'
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['test_var'] == 'test_value'

    # Test case 2: variable is in available_

# Generated at 2022-06-17 14:37:39.693738
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:37:45.256973
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:37:56.807442
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test_global'] == 'test_global_value'
    assert ansible_j2_vars['test_local'] == 'test_local_value'
    templar.available_variables = {'test_available_variable': 'test_available_variable_value'}

# Generated at 2022-06-17 14:38:07.378634
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1'}
    locals = {'l1': 'l1'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'l1' in vars
    assert 'g2' not in vars
    assert 'l2' not in vars
    templar.available_variables = {'a1': 'a1'}
    assert 'a1' in vars
    assert 'a2' not in vars
    templar.available_variables = {'a2': HostVars()}

# Generated at 2022-06-17 14:38:15.530018
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'g2' in vars
    assert 'l1' in vars
    assert 'l2' in vars
    assert 'g3' not in vars
    assert 'l3' not in vars
    assert 'vars' not in vars

# Generated at 2022-06-17 14:38:26.205611
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with a local variable
    assert vars['baz'] == 'qux'

    # test __getitem__ with a global variable
    assert vars['foo'] == 'bar'

    # test __getitem__ with a variable from available_variables

# Generated at 2022-06-17 14:38:36.550515
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None, variables={'foo': 'bar'})
    globals = {'foo': 'bar'}
    locals = {'foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test for variable in locals
    assert vars['foo'] == 'bar'

    # test for variable in available_variables
    assert vars['foo'] == 'bar'

    # test for variable in globals
    assert vars['foo'] == 'bar'

    # test for variable

# Generated at 2022-06-17 14:38:46.216746
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeSet
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTuple
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBool

# Generated at 2022-06-17 14:38:56.047192
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None, variables={'test_var': 'test_value'})
    globals = {'test_global': 'test_global_value'}
    locals = {'test_local': 'test_local_value'}

    vars = AnsibleJ2Vars(templar, globals, locals)

    # test __getitem__ with a variable in locals
    assert vars['test_local'] == 'test_local_value'

    # test __getitem__ with a variable in templar
    assert vars['test_var'] == 'test_value'

    # test __getitem__ with a variable

# Generated at 2022-06-17 14:39:00.421419
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in j2vars
    assert 'l_foo' in j2vars
    assert 'foo' not in j2vars


# Generated at 2022-06-17 14:39:27.628354
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import colorize, hostcolor
    from ansible.utils.plugin_docs import get_docstring
    from ansible.utils.sentinel import Sentinel
   

# Generated at 2022-06-17 14:39:38.175948
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(j2vars) == set(['a', 'b', 'c', 'd'])
    assert set(j2vars.keys()) == set(['a', 'b', 'c', 'd'])
    assert set(j2vars.values()) == set([1, 2, 3, 4])

# Generated at 2022-06-17 14:39:48.887066
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeYaml
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUn

# Generated at 2022-06-17 14:39:55.360948
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_key1': 'g_val1', 'g_key2': 'g_val2'}
    locals = {'l_key1': 'l_val1', 'l_key2': 'l_val2'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_key1' in j2vars
    assert 'g_key2' in j2vars
    assert 'l_key1' in j2vars
    assert 'l_key2' in j2vars
    assert 'key1' not in j2vars
    assert 'key2' not in j

# Generated at 2022-06-17 14:40:06.453147
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFile
   

# Generated at 2022-06-17 14:40:17.805620
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in j2vars
    assert 'bar' not in j2vars
    assert 'baz' not in j2vars
    j2vars._locals = {'foo': 'bar'}
    assert 'foo' in j2vars
    assert 'bar' not in j2vars
    assert 'baz' not in j2vars
    j2vars._templar.available_variables = {'bar': 'baz'}
    assert 'foo' in j2vars
    assert 'bar' in j2vars

# Generated at 2022-06-17 14:40:24.499953
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars


# Generated at 2022-06-17 14:40:31.963854
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_a': 'g_a', 'g_b': 'g_b'}
    locals = {'l_a': 'l_a', 'l_b': 'l_b'}
    templar.available_variables = {'a': 'a', 'b': 'b'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' in vars
    assert 'l_a' in vars
    assert 'l_b' in vars

# Generated at 2022-06-17 14:40:44.919988
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 14:40:54.667878
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    available_variables = {'a1': 'a1', 'a2': 'a2'}
    templar.set_available_variables(available_variables)
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in ajv
    assert 'g2' in ajv
    assert 'l1' in ajv
    assert 'l2' in ajv
    assert 'a1' in a

# Generated at 2022-06-17 14:41:37.741617
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(None, None, None)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars['vars'] == HostVars()
    assert vars['vars']['foo'] == 'bar'
    assert vars['vars']['baz'] == 'qux'
    assert vars['vars']['vars'] == HostVars()

# Generated at 2022-06-17 14:41:44.879561
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.hostvars import HostVars
    import os
    import sys
    import json
    import yaml

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-17 14:41:54.021344
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_key1': 'g_val1', 'g_key2': 'g_val2'}
    locals = {'l_key1': 'l_val1', 'l_key2': 'l_val2'}
    vars = {'vars': {'key1': 'val1', 'key2': 'val2'}}
    templar._available_variables = vars
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'key1' in ansible_j2_vars
    assert 'key2' in ansible_j2_vars
   

# Generated at 2022-06-17 14:42:04.556480
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test case 1: varname in self._locals
    assert vars['l_foo'] == 'bar'

    # Test case 2: varname in self._templar.available_variables

# Generated at 2022-06-17 14:42:15.879210
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBool
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFloat


# Generated at 2022-06-17 14:42:22.866861
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'bar'
    assert ajv['baz'] == 'qux'
    try:
        ajv['quux']
    except KeyError:
        pass
    else:
        assert False, "KeyError not raised"

# Generated at 2022-06-17 14:42:30.250336
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'

    assert vars['vars'] == templar.available_variables
    assert vars['hostvars'] == templar.available_variables['hostvars']


# Generated at 2022-06-17 14:42:37.532937
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    assert vars.add_locals({'quux': 'quuz'})['quux'] == 'quuz'

# Generated at 2022-06-17 14:42:47.980283
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])
    vars._templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2', 'v1', 'v2'])
