

# Generated at 2022-06-17 14:32:59.741833
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(ansible_j2_vars.__iter__()) == set(['foo', 'baz'])
    templar.available_variables = {'quux': 'quuz'}
    assert set(ansible_j2_vars.__iter__()) == set(['foo', 'baz', 'quux'])
    templar.available_variables = {'quux': HostVars()}

# Generated at 2022-06-17 14:33:09.381549
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': AnsibleUnsafeText('bar')}
    assert 'foo' in vars


# Generated at 2022-06-17 14:33:20.290226
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVariable
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeTuple

# Generated at 2022-06-17 14:33:27.590647
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['a'] == 1
    assert ansible_j2_vars['b'] == 2
    assert ansible_j2_vars['c'] == 3
    assert ansible_j2_vars['d'] == 4
    assert ansible_j2_vars.add_locals({'e': 5, 'f': 6})['e'] == 5
    assert ansible_j2_

# Generated at 2022-06-17 14:33:37.421739
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    ansible_vars = {'foo': 'bar'}
    templar._available_variables = ansible_vars
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'bar' not in vars
    assert 'g_bar' not in vars
    assert 'l_bar' not in vars
    assert 'foo' in ansible_vars

# Generated at 2022-06-17 14:33:42.393363
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars
    assert 'bar' not in vars
    assert 'bar' in HostVars(vars)
    assert 'qux' in HostVars(vars)


# Generated at 2022-06-17 14:33:50.749786
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    templar = Templar(loader=loader, variables=variable_manager)

    j2vars = AnsibleJ2Vars(templar, {'a': 1, 'b': 2, 'c': 3})
    assert len(j2vars) == 3


# Generated at 2022-06-17 14:33:58.822146
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:34:03.797695
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars is not None


# Generated at 2022-06-17 14:34:08.004258
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars


# Generated at 2022-06-17 14:34:21.234262
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    variable_manager = VariableManager()
    host = Host(name='localhost')
    host.set_variable('ansible_ssh_host', '127.0.0.1')
    group = Group(name='group')
    group.add_host(host)
    variable_manager.set_inventory(host.get_inventory())
    variable_manager.add_group_vars(group, {'group_var': 'group_var_value'})
    variable_manager.add_host_vars(host, {'host_var': 'host_var_value'})
    templar = Templar(loader=None, variables=variable_manager)

    ans

# Generated at 2022-06-17 14:34:32.469993
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # test for undefined variable
    try:
        ansible_j2_vars['undefined_variable']
    except KeyError as e:
        assert str(e) == "undefined variable: undefined_variable"
    else:
        assert False

    # test for variable in locals
    locals['var1'] = 'var1'
    assert ansible

# Generated at 2022-06-17 14:34:38.712983
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'qux' not in vars


# Generated at 2022-06-17 14:34:45.772351
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'c' in j2vars
    assert 'd' in j2vars
    assert 'e' not in j2vars


# Generated at 2022-06-17 14:34:55.773899
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars
    templar

# Generated at 2022-06-17 14:35:05.101352
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4
    vars._templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    assert len(vars) == 6

# Generated at 2022-06-17 14:35:14.902387
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'
    assert vars['baz'] == 'qux'
    try:
        vars['undefined']
    except KeyError as e:
        assert e.args[0] == "undefined variable: undefined"
    else:
        assert False, "KeyError not raised"

# Generated at 2022-06-17 14:35:26.643538
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'foo': 'baz'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv['foo'] == 'baz'
    assert ajv['foo'] != 'bar'
    assert ajv['foo'] != 'qux'
    assert ajv['foo'] != 'quux'
    assert ajv['foo'] != 'corge'
    assert ajv['foo'] != 'grault'
    assert ajv['foo'] != 'garply'
    assert ajv['foo'] != 'waldo'
    assert a

# Generated at 2022-06-17 14:35:37.336628
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in ajv
    assert 'g2' in ajv
    assert 'l1' in ajv
    assert 'l2' in ajv
    assert 'v1' in ajv
    assert 'v2' in ajv


# Generated at 2022-06-17 14:35:43.004008
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_j2_vars) == 0
    globals['foo'] = 'bar'
    assert len(ansible_j2_vars) == 1
    locals['foo'] = 'bar'
    assert len(ansible_j2_vars) == 1
    locals['bar'] = 'foo'
    assert len(ansible_j2_vars) == 2


# Generated at 2022-06-17 14:35:58.977570
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_key1': 'g_value1', 'g_key2': 'g_value2'}
    locals = {'l_key1': 'l_value1', 'l_key2': 'l_value2'}
    templar.available_variables = {'v_key1': 'v_value1', 'v_key2': 'v_value2'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-17 14:36:09.144032
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in j2vars
    assert 'g2' in j2vars
    assert 'l1' in j2vars
    assert 'l2' in j2vars
    assert 'g3' not in j2vars
    assert 'l3' not in j2vars
    assert 'vars' not in j2vars
    assert 'hostvars'

# Generated at 2022-06-17 14:36:19.386779
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars


# Generated at 2022-06-17 14:36:28.904821
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInt


# Generated at 2022-06-17 14:36:34.497721
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['g1', 'g2', 'l1', 'l2'])


# Generated at 2022-06-17 14:36:45.100733
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4
    assert 'g1' in vars
    assert 'g2' in vars
    assert 'l1' in vars
    assert 'l2' in vars
    assert vars['g1'] == 'g1'
    assert vars['g2'] == 'g2'
    assert vars['l1'] == 'l1'
    assert vars['l2'] == 'l2'
    assert 'g3'

# Generated at 2022-06-17 14:36:52.847470
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVariable
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinjaEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinjaTemplate
    from ansible.vars.unsafe_proxy import AnsibleUnsafeContext
    from ansible.vars.unsafe_proxy import Ansible

# Generated at 2022-06-17 14:37:03.648728
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    # Test case 1:
    #   varname in self._locals
    #   return self._locals[varname]
    locals['test_key'] = 'test_value'
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['test_key'] == 'test_value'

    # Test case 2:
    #   varname in self._tem

# Generated at 2022-06-17 14:37:14.696893
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafePromptPassword
    from ansible.vars.unsafe_proxy import AnsibleUnsafePromptPrivateKey
    from ansible.vars.unsafe_proxy import AnsibleUnsafePromptYesNo

# Generated at 2022-06-17 14:37:26.638084
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars
    templar.available_variables = {'foo': 'bar'}
    assert 'foo' in vars
    templar.available_variables = {'foo': HostVars()}
    assert 'foo' in vars

# Generated at 2022-06-17 14:37:48.676679
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansible_vars) == 0
    globals['g_key'] = 'g_value'
    assert len(ansible_vars) == 1
    locals['l_key'] = 'l_value'
    assert len(ansible_vars) == 2
    templar.available_variables['a_key'] = 'a_value'
    assert len(ansible_vars) == 3
    templar.available_variables['a_key'] = HostVars()
    assert len

# Generated at 2022-06-17 14:38:00.416119
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g_a': 1, 'g_b': 2, 'g_c': 3}
    locals = {'l_a': 1, 'l_b': 2, 'l_c': 3}
    vars = AnsibleJ2Vars(templar, globals, locals)
    vars['vars'] = HostVars(loader=None, hostname='localhost')
    vars['vars']['v_a'] = 1
    vars['vars']['v_b'] = 2
    vars['vars']['v_c'] = 3

# Generated at 2022-06-17 14:38:09.914215
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'g2' in vars
    assert 'l1' in vars
    assert 'l2' in vars
    assert 'g3' not in vars
    assert 'l3' not in vars
    assert 'vars' not in vars
    templar.available_variables = {'vars': HostVars()}
    assert 'vars' in vars

#

# Generated at 2022-06-17 14:38:18.094060
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'a': 1, 'b': 2, 'c': 3})
    vars = AnsibleJ2Vars(templar, {'d': 4, 'e': 5, 'f': 6}, locals={'g': 7, 'h': 8, 'i': 9})
    assert set(vars) == set(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'])


# Generated at 2022-06-17 14:38:28.623556
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {
        'g_foo': 'bar',
        'g_baz': 'qux',
    }
    locals = {
        'l_foo': 'bar',
        'l_baz': 'qux',
    }
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'g_foo' in vars
    assert 'g_baz' in vars
    assert 'l_foo' in vars
    assert 'l_baz' in vars
    assert 'foo' not in vars

# Generated at 2022-06-17 14:38:38.087455
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFile
   

# Generated at 2022-06-17 14:38:45.238605
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:38:55.078901
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'foo': 'baz'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'baz'
    assert vars['bar'] == 'baz'
    assert vars['baz'] == 'baz'
    assert vars['foo'] == 'baz'
    assert vars['bar'] == 'baz'
    assert vars['baz'] == 'baz'
    assert vars['foo'] == 'baz'
    assert vars['bar'] == 'baz'

# Generated at 2022-06-17 14:38:58.753717
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert iter(ansible_j2_vars) is not None


# Generated at 2022-06-17 14:39:06.091618
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInteger
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFloat
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}


# Generated at 2022-06-17 14:39:35.879986
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'c': 'd'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in vars
    assert 'b' not in vars
    assert 'c' in vars
    assert 'd' not in vars


# Generated at 2022-06-17 14:39:46.402955
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeInteger
    from ansible.vars.unsafe_proxy import AnsibleUnsafeFloat


# Generated at 2022-06-17 14:39:57.752696
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4
    vars._templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    assert len(vars) == 6
    vars._templar.available_variables = {'v1': 'v1', 'v2': 'v2', 'l1': 'l1'}

# Generated at 2022-06-17 14:40:08.531867
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in ansible_j2_vars
    ansible_j2_vars._templar.available_variables = {'foo': 'bar'}
    assert 'foo' in ansible_j2_vars
    ansible_j2_vars._locals = {'foo': 'bar'}
    assert 'foo' in ansible_j2_vars
    ansible_j2_vars._globals = {'foo': 'bar'}
    assert 'foo' in ansible_j2_vars

# Unit test

# Generated at 2022-06-17 14:40:14.943614
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafeIPAddress
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeList
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.vars.unsafe_proxy import AnsibleUnsafeNone

    templar = Templar(loader=None)
    globals = dict()


# Generated at 2022-06-17 14:40:21.807384
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    templar._available_variables = {'a': 'A', 'b': 'B'}
    globals = {'g': 'G'}
    locals = {'l_c': 'C', 'l_d': 'D'}

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'a' in vars
    assert 'b' in vars
    assert 'g' in vars
    assert 'c' in vars
    assert 'd' in vars

    assert 'e' not in vars

# Generated at 2022-06-17 14:40:28.592931
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in ansible_j2_vars
    assert 'baz' in ansible_j2_vars
    assert 'qux' not in ansible_j2_vars


# Generated at 2022-06-17 14:40:35.772680
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Test if the value of the variable is returned
    assert ansible_j2_vars['baz'] == 'qux'

    # Test if the value of the variable is returned
    assert ansible_j2_vars['foo'] == 'bar'

    # Test if the value of the variable is returned

# Generated at 2022-06-17 14:40:45.708058
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar()
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'c' in j2vars
    assert 'd' in j2vars
    assert 'e' not in j2vars
    assert 'f' not in j2vars
    assert 'g' not in j2vars
    assert 'h' not in j2vars
    assert 'i' not in j2vars
    assert 'j' not in j

# Generated at 2022-06-17 14:40:55.257484
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    templar = Templar(loader=None)
    globals = {'g_foo': 'g_bar'}
    locals = {'l_foo': 'l_bar'}
    vars = {'vars': {'foo': 'bar'}}
    hostvars = HostVars(vars)
    unsafe_text = AnsibleUnsafeText('unsafe_text')
    unsafe_bytes = AnsibleUnsafeBytes('unsafe_bytes')

    aj2v = AnsibleJ2Vars(templar, globals, locals)

    # test

# Generated at 2022-06-17 14:41:55.517158
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeLookup
    from ansible.vars.unsafe_proxy import AnsibleUnsafeHost
    from ansible.vars.unsafe_proxy import AnsibleUnsafePrompt
    from ansible.vars.unsafe_proxy import AnsibleUnsafeEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeCommand
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import AnsibleUnsafeJinja

# Generated at 2022-06-17 14:42:04.870248
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['foo'] == 'bar'
    assert j2vars['baz'] == 'qux'
    assert j2vars['vars'] == templar.available_variables
    assert isinstance(j2vars['vars'], HostVars)
    assert j2vars['vars'].__UNSAFE__ is True

# Generated at 2022-06-17 14:42:11.633636
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 3


# Generated at 2022-06-17 14:42:18.256040
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in vars
    assert 'l_foo' in vars
    assert 'foo' not in vars


# Generated at 2022-06-17 14:42:28.796183
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' not in ansible_j2_vars
    assert 'bar' not in ansible_j2_vars
    assert 'baz' not in ansible_j2_vars
    assert 'qux' not in ansible_j2_vars
    assert 'quux' not in ansible_j2_vars
    assert 'corge' not in ansible_j2_vars
    assert 'grault' not in ansible_j2_vars
    assert 'garply' not in ansible_j2_vars

# Generated at 2022-06-17 14:42:39.595323
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    # Test case 1
    # Test when varname is in self._locals
    # Expected result: return self._locals[varname]
    varname = 'test_varname'
    locals[varname] = 'test_value'
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars[varname] == locals[varname]

    # Test case 2
    # Test when varname is in self._templ

# Generated at 2022-06-17 14:42:46.252377
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g_foo': 'bar'}
    locals = {'l_foo': 'bar'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_foo' in j2vars
    assert 'l_foo' in j2vars
    assert 'foo' not in j2vars
