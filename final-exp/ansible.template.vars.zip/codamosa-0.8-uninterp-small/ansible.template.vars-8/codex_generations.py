

# Generated at 2022-06-25 12:29:43.700639
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # tests that variables in the locals scope take precedence over other
    # variables
    tuple_0 = ()
    str_0 = 'x'
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0, {'x': True})
    test_bool_0 = ansible_j2_vars_0.__contains__(str_0)
    assert test_bool_0


# Generated at 2022-06-25 12:29:48.555848
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    str_0 = 'S'
    bool_1 = ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:29:54.712542
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    str_0 = "n9$g%j"
    bool_1 = ansible_j2_vars_0.__contains__(str_0)
    assert bool_1 is False


# Generated at 2022-06-25 12:29:57.058998
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    x = AnsibleJ2Vars(tuple_0, list_0)
    assert x == AnsibleJ2Vars(tuple_0, list_0)


# Generated at 2022-06-25 12:30:02.260997
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    assert ansible_j2_vars_0.__len__() == 0


# Generated at 2022-06-25 12:30:05.637647
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    tuple_1 = (True,)
    ansible_j2_vars_1 = AnsibleJ2Vars(tuple_1, tuple_1)
    ansible_j2_vars_1._locals = {}
    ansible_j2_vars_1.add_locals(tuple_1)


# Generated at 2022-06-25 12:30:09.551810
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    str_0 = ""
    assert ansible_j2_vars_0.__contains__(str_0) == True
    assert ansible_j2_vars_0.__contains__(tuple_0) == True


# Generated at 2022-06-25 12:30:14.403605
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_0.__contains__()


# Generated at 2022-06-25 12:30:18.722747
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    # loop0
    string_0 = 'x'
    ansible_j2_vars_0.__getitem__(string_0)


# Generated at 2022-06-25 12:30:21.210539
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()


# Generated at 2022-06-25 12:30:26.711771
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = AnsibleJ2Vars()


# Generated at 2022-06-25 12:30:32.098858
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    str_9 = ''
    str_10 = ''
    str_11 = ''
    str_12 = ''



# Generated at 2022-06-25 12:30:33.194174
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:30:35.416842
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = ''
    # unit test for __iter__ of class AnsibleJ2Vars
    # unit test for __iter__ of class AnsibleJ2Vars



# Generated at 2022-06-25 12:30:37.861310
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case = AnsibleJ2Vars(templar=object(), globals={})
    assert 'str_0' not in test_case


# Generated at 2022-06-25 12:30:45.688901
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    hostvars = HostVars()
    hostvars.__UNSAFE__ = True
    templar = Templar(loader=None, variables=dict({"vars": hostvars}))
    result = AnsibleJ2Vars(templar, dict())
    assert type(result) is AnsibleJ2Vars


# Generated at 2022-06-25 12:30:55.185857
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.safe_eval import safe_eval
    from ansible.template.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    vars_mgr = VariableManager(loader=loader)

    templar = Templar(loader=loader, variables=vars_mgr)

    templar.set_available_variables(vars_mgr.get_vars(loader=loader))

    # The value of templar.available_variables is not empty here, but None.
    assert templar.available_variables is not None

    templar.available_variables.update(vars_mgr.get_vars(loader=loader))

    # The value of templar.

# Generated at 2022-06-25 12:30:56.241761
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()


# Generated at 2022-06-25 12:31:03.608242
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    templar = Templar(loader=None)

    var_vault_password = str_0
    var_globals = {'vault_password': var_vault_password}
    var_vault = VaultLib(var_vault_password)
    var_loader = str_0
    var_self = AnsibleJ2Vars(templar=templar, globals=var_globals)
    # Exception - variable undefined
    try:
        var_self.__getitem__(str_0)
    except AnsibleUndefinedVariable:
        pass
    except Exception as e:
        print(e)

# Generated at 2022-06-25 12:31:08.127756
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()
    globals = {}
    locals = {}
    test = AnsibleJ2Vars(templar, globals, locals)
    with pytest.raises(KeyError) as excinfo:
        str_0 = test['a']
        print(str_0)
    print(excinfo)
    assert str(excinfo.value) == "undefined variable: a"


# Generated at 2022-06-25 12:31:12.927445
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()



# Generated at 2022-06-25 12:31:14.360137
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert False # If you want to test this function please supply proper parameters


# Generated at 2022-06-25 12:31:15.368392
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:31:24.019415
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:31:29.987187
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    result = run_unit_test(test_case_0)
    print(result)

if __name__ == '__main__':
    args = sys.argv
    # if len(args) != 1:
    #     print("Usage: python test.py")
    #     sys.exit(1)
    result = test_AnsibleJ2Vars___getitem__()
    print(result)

# Generated at 2022-06-25 12:31:35.743589
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ansible_j2vars_0 = AnsibleJ2Vars(templar, globals)
    ansible_j2vars_0_len = len(ansible_j2vars_0)
    assert ansible_j2vars_0_len == 2, 'ansible_j2vars_0_len = %r, expected: %r' % (ansible_j2vars_0_len, 2)


# Generated at 2022-06-25 12:31:39.172359
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansiblej2vars_0 = AnsibleJ2Vars(templar_0, globals_0, locals_0)
    str_0 = ansiblej2vars_0['ansible_memtotal_mb']
    return str_0


# Generated at 2022-06-25 12:31:43.897460
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    temp_templar = None
    temp_globals = dict()
    temp_locals = None
    temp_AnsibleJ2Vars = AnsibleJ2Vars(temp_templar, temp_globals, temp_locals)
    temp_varname = str()

    test_case_0()
    #assert

# Generated at 2022-06-25 12:31:46.975561
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    my_vars = AnsibleJ2Vars(None, None, None)
    test_case_0()
    assert True


# Generated at 2022-06-25 12:31:54.449184
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template.safe_eval import test_data
    from ansible.plugins.loader import template_loader

    j2_env = template_loader.get_jinja2_environment()
    templar = template_loader._create_template_loader(j2_env)
    templar.set_available_variables(test_data.EXAMPLE_VARS)
    vars_obj = AnsibleJ2Vars(templar, test_data.EXAMPLE_VARS)
    assert vars_obj.__contains__('foo')


# Generated at 2022-06-25 12:32:01.972282
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_0.__contains__("test_key", )
    ansible_j2_vars_0.__contains__("", )


# Generated at 2022-06-25 12:32:10.946861
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_1 = ()
    int_0 = 10
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_1, int_0)
    ansible_undefined_variable_0 = AnsibleUndefinedVariable('AnsibleUndefinedVariable')
    ansible_error_0 = AnsibleError('AnsibleError')
    tuple_2 = (ansible_undefined_variable_0, ansible_error_0)
    tuple_3 = (ansible_j2_vars_0.__getitem__("varname"),)
    assert isinstance(tuple_3, tuple)
    assert tuple_2 == tuple_3

# Generated at 2022-06-25 12:32:14.797051
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    print('Unit test for constructor of class AnsibleJ2Vars')
    test_case_0()
    print('Test completed\n')

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:32:20.966125
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    str_0 = 'UNDY`NpN<,W:9!'
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_0.__contains__(str_0)

# Generated at 2022-06-25 12:32:25.227536
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Given - a tuple with no elements and a bool
    tuple_0 = ()
    bool_0 = True

    # When - AnsibleJ2Vars is constructed with the tuple and bool
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)


# Generated at 2022-06-25 12:32:32.192074
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    #undefined variable: test
    #try:
    #    ansible_j2_vars_0.__getitem__('test')
    #except KeyError as e:
    #    print(e)
    #    #self.assertEqual(e.message, 'undefined variable: test')

# Generated at 2022-06-25 12:32:34.957195
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_0.__iter__()



# Generated at 2022-06-25 12:32:38.478519
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = 'aidlzq9q'
    int_0 = 1656
    tuple_0 = (int_0,)
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    str_1 = 'iqt'
    str_2 = ansible_j2_vars_0[str_1]
    assert str_2 == 'iqt'

# Generated at 2022-06-25 12:32:43.305106
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    str_0 = "varname"
    exception_0 = None
    try:
        ansible_j2_vars_0.__getitem__(str_0)
    except Exception as exception_0:
        pass
    assert isinstance(exception_0, KeyError)


# Generated at 2022-06-25 12:32:44.865430
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    s0 = AnsibleJ2Vars(None, None)
    assert True

test_case_0()

# Generated at 2022-06-25 12:32:57.368321
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # FIXME: create a real test case here
    tuple_1 = ()
    bool_1 = True
    ansible_j2_vars_1 = AnsibleJ2Vars(tuple_1, bool_1)
    set_1 = set()
    assert set_1 == ansible_j2_vars_1.__iter__()


# Generated at 2022-06-25 12:32:59.889583
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)

# Generated at 2022-06-25 12:33:03.789330
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)

    try:
        ansible_j2_vars_0['unicode_0']
    except KeyError:
        pass



# Generated at 2022-06-25 12:33:07.219004
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_0.__getitem__()


# Generated at 2022-06-25 12:33:14.644020
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    str_0 = 'inject'
    result_0 = ansible_j2_vars_0.__getitem__(str_0)
    result_1 = ansible_j2_vars_0.__getitem__(str_0)
    assert result_0 is result_1

test_case_0()
test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:33:20.840101
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    bool_0 = True
    # Creation of the object AnsibleJ2Vars with arguments
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    # Assertion whether the object AnsibleJ2Vars "contains" the element str_0
    assert ansible_j2_vars_0.__contains__("str_0") == False


# Generated at 2022-06-25 12:33:24.705041
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    int_0 = 15
    str_0 = ansible_j2_vars_0[int_0]


# Generated at 2022-06-25 12:33:28.430521
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    bool_0 = ansible_j2_vars_0.__contains__()
    assert bool_0 is False



# Generated at 2022-06-25 12:33:32.121340
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    str_0 = "a"
    try:
        ansible_j2_vars_0.__contains__(str_0)
        # FIXME: Test fails here, assertion error.
    except KeyError:
        pass


# Generated at 2022-06-25 12:33:34.493240
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_0.__getitem__("Var1")


# Generated at 2022-06-25 12:33:52.444484
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_0.__contains__("'1f")


# Generated at 2022-06-25 12:33:58.263738
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    # TypeError: __getitem__() takes exactly one argument (2 given)
    #ansible_j2_vars_0[0,0]
    ansible_j2_vars_0['l_foo']

    # KeyError: 'l_foo'
    #ansible_j2_vars_0['l_foo']



# Generated at 2022-06-25 12:34:03.188781
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)


# Generated at 2022-06-25 12:34:10.023763
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, dict_0)
    # Call method __getitem__ of class AnsibleJ2Vars with argument 'ansible_j2_vars_0'
    ansible_j2_vars___getitem___0 = ansible_j2_vars_0.__getitem__(ansible_j2_vars_0)
    assert ansible_j2_vars___getitem___0 == None

# Generated at 2022-06-25 12:34:12.849625
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
  tuple_0 = ()
  bool_0 = True
  ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)


# Generated at 2022-06-25 12:34:15.143132
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    ansible_j2_vars_0.add_locals()


# Generated at 2022-06-25 12:34:18.889827
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    varname_0 = ''
    ansible_j2_vars_0.__getitem__(varname_0)


# Generated at 2022-06-25 12:34:23.162436
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    bool_1 = ansible_j2_vars_0.__contains__('fqTm$NTmW`+')
    assert bool_1 == True
    bool_2 = ansible_j2_vars_0.__contains__('lax~Io')
    assert bool_2 == True
    bool_3 = ansible_j2_vars_0.__contains__('dn*5$`')
    assert bool_3 == True


# Generated at 2022-06-25 12:34:28.567010
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    assert bool_0 == bool(ansible_j2_vars_0.__iter__())


# Generated at 2022-06-25 12:34:32.496910
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    var_0 = ansible_j2_vars_0['a']


# Generated at 2022-06-25 12:35:35.211217
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    tuple_0 = ()
    str_0 = 'str'
    bool_0 = False
    ansible_j2_vars_1 = AnsibleJ2Vars(tuple_0, str_0, bool_0)
    assert False


# Generated at 2022-06-25 12:35:37.954224
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    iter_0 = ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:35:40.359072
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    str_0 = ansible_j2_vars_0.__contains__(tuple_0)


# Generated at 2022-06-25 12:35:44.528980
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_0.__getitem__('foo')
    ansible_j2_vars_0.__getitem__('foo')


# Generated at 2022-06-25 12:35:50.781554
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, dict_0)
    KeyError_0 = False
    try:
        ansible_j2_vars_0.__getitem__(dict_0)
    except KeyError:
        KeyError_0 = True
    assert KeyError_0


if __name__ == '__main__':
    test_case_0()
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:35:57.999458
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_1.exist_dict = {'foo': 'bar', 'baz': 'foobar'}
    ansible_j2_vars_1.__contains__('foo')
    ansible_j2_vars_1.__contains__('baz')



# Generated at 2022-06-25 12:36:04.468539
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_0._templar = None
    str_0 = 'f'
    # Verify that KeyError is raised
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__(str_0)

# Generated at 2022-06-25 12:36:07.346877
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    assert ansible_j2_vars_0 is not None


# Generated at 2022-06-25 12:36:10.996000
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    str_0 = "}"
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:36:15.209051
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Verifies that getdents() returns the correct value
    from tests.unit.module_utils.common.testdata.ansible_module_data.vars.hostvars.hostvars import getdents
    assert getdents() == 'getdents_return'

# Generated at 2022-06-25 12:37:25.808027
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars___iter___0 = ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:37:30.870375
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    try:
        tuple_0 = ()
        bool_0 = True
        ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
        ansible_j2_vars_0.__getitem__('mykey')
    except KeyError:
        pass


# Generated at 2022-06-25 12:37:34.710121
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)


# Generated at 2022-06-25 12:37:38.896609
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    str_0 = "vars"
    try:
        ansible_j2_vars_0[str_0]
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 12:37:41.335668
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    with pytest.raises(KeyError):
        ansible_j2_vars_0['varname']

# Generated at 2022-06-25 12:37:45.062160
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    assert len(list(ansible_j2_vars_0.__iter__())) == 0


# Generated at 2022-06-25 12:37:55.787494
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    dict_0 = dict()
    str_0 = ansible_j2_vars_0[dict_0]
    # TODO: change assert to assert_equal
    assert str_0 != None
    # Unit test for method __getitem__ of class AnsibleJ2Vars
    def test_AnsibleJ2Vars___getitem__():
        tuple_0 = ()
        bool_0 = True
        ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
        dict_0 = dict()
        str_0 = ansible_j2_vars_0[dict_0]

# Generated at 2022-06-25 12:38:00.201027
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)

    # Call function __getitem__ of class AnsibleJ2Vars
    ret = ansible_j2_vars_0.__getitem__(ansible_j2_vars_0)
    assert ret is None or len(ret) == 0


# Generated at 2022-06-25 12:38:10.540018
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Test it when the variable name is available in locals or globals, or it is available in the templar
    '''
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    ansible_j2_vars_0.__contains__("varname")
    # The value of the variable should be True
    assert (ansible_j2_vars_0["varname"]) == bool_0
    # Test exception of type AttributeError
    with pytest.raises(AttributeError):
        ansible_j2_vars_0.__getitem__(1)
    # Test exception of type KeyError
    with pytest.raises(KeyError):
        ansible

# Generated at 2022-06-25 12:38:16.984960
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, bool_0)
    str_0 = 'd%Z7qw/p8gv'
    try:
        ansible_j2_vars_0.__getitem__(str_0)
    except KeyError:
        raise Exception('Test Exception')
