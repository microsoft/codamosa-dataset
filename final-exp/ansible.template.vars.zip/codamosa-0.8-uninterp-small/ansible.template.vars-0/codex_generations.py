

# Generated at 2022-06-25 12:29:40.893873
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    try:
        ansible_j2_vars_0.__getitem__('varname')
    except KeyError:
        pass


# Generated at 2022-06-25 12:29:43.422524
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()

if __name__ == "__main__":
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:29:54.530014
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    dict_0['varname'] = dict_0
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    assert not (ansible_j2_vars_0.__contains__('varname'))
    dict_0['varname'] = dict_0
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    assert not (ansible_j2_vars_0.__contains__('varname'))
    dict_0['varname'] = dict_0
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)

# Generated at 2022-06-25 12:30:02.878093
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    # RuntimeError: invalid argument type for built-in operation
    # self.assertEqual(ansible_j2_vars_0.add_locals(dict_0), dict_0)
    dict_1 = {'var_1': 3}
    # RuntimeError: invalid argument type for built-in operation
    # self.assertEqual(ansible_j2_vars_0.add_locals(dict_1), dict_1)
    # RuntimeError: invalid argument type for built-in operation
    # self.assertIn('var_1', ansible_j2_vars_0)

    # RuntimeError: invalid argument type for built-in operation
    # self.assert

# Generated at 2022-06-25 12:30:05.296292
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
  dict_0 = {}
  ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
  ansible_j2_vars_0.__contains__("")


# Generated at 2022-06-25 12:30:12.624834
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    str_0 = "vars"
    varname = str_0
    try:
        ansible_j2_vars_0[varname]
    except KeyError as inst:
        str_1 = "undefined variable: vars"
        str_2 = getattr(inst, "args")
        msg_0 = str_1
        assert str_2 == msg_0
    except Exception as inst:
        str_1 = "undefined variable: vars"
        str_2 = getattr(inst, "args")
        msg_0 = str_1
        assert str_2 == msg_0


# Generated at 2022-06-25 12:30:21.430805
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.template.template

    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(ansible.template.template.Str(), dict_0, dict_0)

    # Verify the exception is raised
    with pytest.raises(KeyError) as error:
        var_1 = ansible_j2_vars_0.__getitem__(dict_0)
    assert 'undefined variable' in str(error)

    # Verify the exception is raised
    with pytest.raises(AnsibleError) as error:
        var_2 = ansible_j2_vars_0.__getitem__(dict_0)
    assert 'An unhandled exception occurred while templating' in str(error)

# Generated at 2022-06-25 12:30:23.701007
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    assert (AnsibleJ2Vars.__contains__(dict_0, dict_0))


# Generated at 2022-06-25 12:30:25.560169
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()

# Generated at 2022-06-25 12:30:35.416837
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_3 = {}
    dict_2['0'] = dict_3
    dict_1['0'] = dict_2
    dict_0['0'] = dict_1
    dict_4 = {}
    dict_4 = {}
    dict_4['0'] = dict_4
    dict_1['1'] = dict_4
    dict_5 = {}
    dict_5 = {}
    dict_5['1'] = dict_5
    dict_4['1'] = dict_5
    dict_2['1'] = dict_4
    dict_6 = {}
    dict_6 = {}
    dict_6['0'] = dict_6
    dict_5['0'] = dict_6
    ans

# Generated at 2022-06-25 12:30:40.845824
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    var_1 = AnsibleJ2Vars
    assert var_1 == AnsibleJ2Vars

# Generated at 2022-06-25 12:30:42.661197
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    var_0 = AnsibleJ2Vars()
    len(var_0)
    var_0.__len__()

# Generated at 2022-06-25 12:30:47.501655
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    template_0 = Templar(loader=None)
    globals_0 = {}
    locals_0 = {}
    ansible_j2vars_0 = AnsibleJ2Vars(template_0, globals_0, locals_0)

    ansible_j2vars_0.__getitem__('a key')

# Generated at 2022-06-25 12:30:48.056165
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-25 12:30:49.548124
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # 'Jinja2' is missing from test case 0
    raise Exception("KeyError not raised as expected")



# Generated at 2022-06-25 12:30:51.542844
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    var_0 = AnsibleJ2Vars(var_0)
    assert len(var_0) == 0


# Generated at 2022-06-25 12:30:52.737758
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # has to be implemented
    raise NotImplementedError


# Generated at 2022-06-25 12:30:55.150141
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    assert AnsibleJ2Vars(var_0,var_1,var_2).__contains__() == None


# Generated at 2022-06-25 12:31:00.332847
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        var_0 = {}
        var_0 = AnsibleJ2Vars(var_0)
        var_1 = var_0[0]
        assert True
    except KeyError:
        assert True
    except AnsibleUndefinedVariable:
        assert True
    except Exception as e:
        assert False, str(e)
    else:
        assert False, "Unexpected exception thrown"

test_case_0()
test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:31:02.123446
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_0_instance = AnsibleJ2Vars(test_case_0())

    var_1 = {}


# Generated at 2022-06-25 12:31:07.857448
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    dict_1 = {}
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_1, dict_1)
    len_1 = ansible_j2_vars_1.__len__()
    assert len_1 is 0


# Generated at 2022-06-25 12:31:14.550974
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    dict_0 = {}
    dict_1 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_1.add_locals(dict_1)


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-s', __file__]))

# Generated at 2022-06-25 12:31:16.825115
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    dict_0 = {}
    dict_1 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1)
    ansible_j2_vars_1 = ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:31:25.134209
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    
    from ansible.vars.hostvars import HostVars
    
    try:
        ansible_j2_vars_0.__getitem__('vars')
    except KeyError:
        pass
    except Exception as e:
        print(e)
    
    try:
        ansible_j2_vars_0.__getitem__('vars')
    except KeyError:
        pass
    except Exception as e:
        print(e)
    
    try:
        ansible_j2_vars_0.__getitem__('vars')
    except KeyError:
        pass
    except Exception as e:
        print(e)
    

# Generated at 2022-06-25 12:31:30.796238
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    excpt = False
    try:
        ansible_j2_vars_0.__getitem__("hostvars")
    except KeyError:
        excpt = True
    assert excpt


# Generated at 2022-06-25 12:31:32.704356
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    int_0 = ansible_j2_vars_0.__len__()
    long_0 = long(int_0)
    long_1 = long_0


# Generated at 2022-06-25 12:31:41.803134
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    varname = ''
    assert isinstance(ansible_j2_vars_0.__getitem__(varname), KeyError)
    dict_1 = {}
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_1, dict_1)
    var_dict = {}
    varname = 'vars'
    ansible_j2_vars_1._templar.available_variables = var_dict
    assert ansible_j2_vars_1.__getitem__(varname) == var_dict
    dict_2 = {}

# Generated at 2022-06-25 12:31:53.181659
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_0.__contains__('var_0')
    if theano.config.mode == 'FAST_COMPILE':
        theano.function([], [], updates=theano.ProfileMode(optimizer='fast_run', linker=theano.gof.OpWiseCLinker()))
    else:
        theano.function([], [], updates=theano.ProfileMode(optimizer=None, linker=None))


# Generated at 2022-06-25 12:31:55.280942
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    assert ansible_j2_vars_0.__len__() == 0



# Generated at 2022-06-25 12:31:56.946330
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    pass


# Generated at 2022-06-25 12:32:04.961749
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert ansible_j2_vars_0._AnsibleJ2Vars__getitem__() is None


# Generated at 2022-06-25 12:32:15.157682
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    
    # Test exception raised
    try:
        ansible_j2_vars_0.__getitem__('somevalue')
    except KeyError as e:
        msg = getattr(e, 'message', None) or to_native(e)
        assert msg == "undefined variable: somevalue"
    except Exception as e:
        msg = getattr(e, 'message', None) or to_native(e)
        raise AssertionError("Unexpected exception raised: %s" % msg)
    else:
        raise AssertionError("Exception not raised")

# Generated at 2022-06-25 12:32:26.266704
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    templar_0 = Templar()
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(templar_0, dict_0)
    assert ansible_j2_vars_0._templar == templar_0
    assert ansible_j2_vars_0._globals == dict_0
    assert ansible_j2_vars_0._locals == {}

    distributionfactcollector_0 = DistributionFactCollector()
    host_0 = Host(name = 'localhost')

# Generated at 2022-06-25 12:32:27.904594
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:32:37.749168
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    dict_0['l_test'] = {}
    dict_0['test'] = 'test'
    dict_0['context'] = 'context'
    dict_0['environment'] = 'environment'
    dict_0['template'] = 'template'
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    assert ansible_j2_vars_0['test'] == 'test'
    assert ansible_j2_vars_0['l_test'] == {}
    assert ansible_j2_vars_0['context'] is None
    assert ansible_j2_vars_0['environment'] is None
    assert ansible_j2_vars_0['template'] is None
    assert ansible_j2_vars

# Generated at 2022-06-25 12:32:40.458868
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    assert not ansible_j2_vars_0.__contains__('a')


# Generated at 2022-06-25 12:32:41.264551
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()

# Generated at 2022-06-25 12:32:44.692250
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_0.__contains__('vars')
    ansible_j2_vars_0.__contains__('inventory_hostname')


# Generated at 2022-06-25 12:32:46.859552
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert True


# Generated at 2022-06-25 12:32:53.981607
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    dict_1 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_1, dict_1)
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_1, dict_1)
    dict_2 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_2, dict_2)


# Generated at 2022-06-25 12:33:04.225107
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:33:07.584816
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    dict_1 = {}
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_1, dict_1)
    assert isinstance(ansible_j2_vars_1, AnsibleJ2Vars)


# Generated at 2022-06-25 12:33:12.920517
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    varname_0 = None
    try:
        retval_0 = ansible_j2_vars_0[varname_0]
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-25 12:33:19.360116
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_1 = {}
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_1, dict_1)
    varname_1 = 'ansible_check_mode'
    assert ansible_j2_vars_1[varname_1] == False


# Generated at 2022-06-25 12:33:25.260364
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    assert not (ansible_j2_vars_0.__contains__('override'))
    ansible_j2_vars_0._templar.available_variables['override'] = {}
    assert ansible_j2_vars_0.__contains__('override')


# Generated at 2022-06-25 12:33:32.804136
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    (dict_0, dict_1, str_0, str_1, str_2, str_3) = (dict(), dict(), 'qrstuvwxyzabcdefghijklmnop', 'abcd', 'abcd', 'abcdefghijklmnopqrstuvwxyz')
    (list_0, list_1, list_2, str_4) = ([None for _ in range(20)], [None for _ in range(8)], [None for _ in range(19)], 'abcd')
    (dict_2, dict_3, dict_4, dict_5, dict_6, dict_7, dict_8, dict_9, dict_10, dict_11) = (dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict())

# Generated at 2022-06-25 12:33:38.750723
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    varname_0 = ""
    assert ansible_j2_vars_0.__getitem__(varname_0) == None


# Generated at 2022-06-25 12:33:43.636544
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    test_0 = 'test_key'
    if test_0 not in ansible_j2_vars_0:
        raise Exception('AnsibleJ2Vars.__contains__() failed')


# Generated at 2022-06-25 12:33:50.957861
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_error_0 = None
    try:
        ansible_j2_vars_0['vars']
    except AnsibleError:
        ansible_error_0 = e
    except Exception as e:
        raise
    if ansible_error_0 is None:
        print('Expected exception')
        print('[PASS]')
    else:
        print('Expected exception')
        print('[FAIL]')


# Generated at 2022-06-25 12:33:54.745628
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    try:
        assert ansible_j2_vars_0.__contains__('dict_0')
    except:
        pass



# Generated at 2022-06-25 12:34:14.484488
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {'v': {'v': 'b'}}
    dict_1 = {'l_v': 'b'}
    dict_2 = {'k': {'k': 'b'}}
    dict_3 = {'k': 'b'}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1)
    assert(ansible_j2_vars_0['v'] == 'b')
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_2, dict_3)
    assert(ansible_j2_vars_0['k'] == 'b')


# Generated at 2022-06-25 12:34:18.266234
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    str_0 = ansible_j2_vars_0[str()]
    int_0 = ansible_j2_vars_0[int()]


# Generated at 2022-06-25 12:34:21.276015
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Test if AnsibleJ2Vars get an item correctly
    '''
    ansible_j2_vars = AnsibleJ2Vars(dict(), dict())
    assert ansible_j2_vars['abc'] == None 


# Generated at 2022-06-25 12:34:25.342991
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)


# Generated at 2022-06-25 12:34:32.925767
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    iterator_0 = ansible_j2_vars_0.__iter__()
    val_0 = isinstance(iterator_0, type(iter([])))
    try:
        next(iterator_0)
    except StopIteration:
        val_1 = True
    else:
        val_1 = False
    if val_0 and val_1:
        assert True
    else:
        assert False


# Generated at 2022-06-25 12:34:41.330845
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    jinja2_environment_0 = jinja2.Environment()
    from ansible.template import Templar
    templar_0 = Templar(jinja2_environment_0,
                        loader=None)
    locals_0 = {'a': 1, 'b': 2}
    globals_0 = {'c': 3, 'd': 4}
    ansible_j2_vars_0 = AnsibleJ2Vars(templar_0, globals_0, locals=locals_0)
    ansible_j2_vars_0.__contains__('a')
    ansible_j2_vars_0.__contains__('c')


# Generated at 2022-06-25 12:34:45.064664
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_0.__getitem__('')


# Generated at 2022-06-25 12:34:48.581858
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    try:
        ansible_j2_vars_0.__getitem__('foo')
        assert False
    except KeyError:
        pass


# Generated at 2022-06-25 12:34:54.577602
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    assert ansible_j2_vars_0.__getitem__('str_0') == 'str_1'
    assert ansible_j2_vars_0.__getitem__('str_2') == 'str_3'
    assert ansible_j2_vars_0.__getitem__('str_4') == 'str_5'
    assert Exception('str_6')
    assert Exception('str_7')
    assert ansible_j2_vars_0.__getitem__('str_8') == 'str_9'
    assert ansible_j2_vars_0.__getitem__('str_10') == 'str_11'
   

# Generated at 2022-06-25 12:34:57.534174
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_0.__getitem__ = {}


# Generated at 2022-06-25 12:35:17.912778
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Test if method __getitem__ in AnsibleJ2Vars behaves correctly
    when setting self.vars[item] = value
    '''
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    test_item = 'item'
    test_value = 0
    ansible_j2_vars_0[test_item] = test_value
    assert ansible_j2_vars_0[test_item] == test_value



# Generated at 2022-06-25 12:35:28.269835
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_0.__contains__('abc')
    ansible_j2_vars_0.__contains__('abc')
    ansible_j2_vars_0.__contains__('abc')
    ansible_j2_vars_0.__contains__('abc')
    ansible_j2_vars_0.__contains__('abc')
    ansible_j2_vars_0.__contains__('abc')
    ansible_j2_vars_0.__contains__('abc')
    ansible_j2_vars_0.__contains__('abc')
    ansible_

# Generated at 2022-06-25 12:35:38.808933
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_1, dict_1)
    # State
    dict_1['qscd'] = 'b;e'
    dict_1['qscd'] = 'g]I'
    dict_1['qscd'] = 'g]I'
    dict_1['qscd'] = 'b;e'
    dict_1['qscd'] = 'g]I'
    dict_1['qscd'] = 'b;e'
    # Code
    ansible_j2_vars_0.__cont

# Generated at 2022-06-25 12:35:41.947002
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Tests for exceptions raised in __contains__
    # Passed parameters
    # str

    # Test if exception raised
    assert test_case_0()

# Generated at 2022-06-25 12:35:43.365626
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}

    test_case_0()
    test_case_1()


# Generated at 2022-06-25 12:35:44.175798
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass


# Generated at 2022-06-25 12:35:46.980923
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_0.__contains__('key_0')


# Generated at 2022-06-25 12:35:51.425421
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    # key = 'TEST-01'
    # __getitem__ = ansible_j2_vars_0.__getitem__(key)
    # print(getitem)



# Generated at 2022-06-25 12:35:54.972602
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    str_0 = ansible_j2_vars_0['abc']
    assert str_0 == 'abc'

# Generated at 2022-06-25 12:36:00.314644
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    # __getitem__ throws KeyError for non-existing items
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__("l_not_a_key")


# Generated at 2022-06-25 12:36:34.667348
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_0.__contains__(dict_1)
    ansible_j2_vars_0.__contains__(dict_2)


# Generated at 2022-06-25 12:36:37.080700
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    assert True


# Generated at 2022-06-25 12:36:43.333097
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    #ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_0 = AnsibleJ2Vars({}, dict_0)
    token_0 = False
    try:
        ansible_j2_vars_0.__getitem__(token_0)
    except KeyError as exception_0:
        pass
    else:
        raise Exception('AssertionError')


# Generated at 2022-06-25 12:36:46.206607
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    int_0 = ansible_j2_vars_0.__len__()
    assert int_0 == 0


# Generated at 2022-06-25 12:36:49.444330
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    set_0 = set()
    set_0.update(dict_0, dict_0)
    assert_equal(ansible_j2_vars_0.__iter__(), iter(set_0))


# Generated at 2022-06-25 12:36:56.616983
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_1 = {'AnsibleUndefinedVariable': dict_0}
    dict_2 = {'AnsibleError': dict_1}
    dict_3 = {}
    dict_4 = {}
    ansible_j2_vars_2 = AnsibleJ2Vars(dict_0, dict_1)
    assert ansible_j2_vars_2.test_case_0() == None
    assert ansible_j2_vars_2.test_AnsibleJ2Vars___contains__() == None
    ansible_j2_vars_3 = AnsibleJ2Vars(dict_0, dict_1)
    assert ansible_j2_vars_3.test_case_0() == None
    assert ansible_j2_vars_3.test_AnsibleJ

# Generated at 2022-06-25 12:37:02.262511
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        locals = {'var_name': 'something'}
        # I'm not sure how to mock this
        ansible_j2_vars_0 = AnsibleJ2Vars(locals, locals)
        ansible_j2_vars_0['var_name']
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-25 12:37:12.754923
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1)
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_0, dict_2)
    var_0 = set()
    var_1 = set()
    var_0.update(dict_0, dict_1, dict_2)
    var_1.update(dict_0, dict_1, dict_2)
    assert len(var_0) == len(var_1)
    itr_0 = iter(var_0)
    set_0 = set(itr_0)
    assert len(set_0) == len(set(itr_0))
    itr_1

# Generated at 2022-06-25 12:37:18.992550
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.module_utils.six import PY3
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils.six import StringIO

    dict_0 = {}
    dict_1 = {}
    dict_1['test_dict'] = 'test_dict'
    dict_1['test_list_0'] = ['test_list_0_0', 'test_list_0_1']
    dict_1['test_list_1'] = ['test_list_1_0', 'test_list_1_1']
    dict_1['test_str'] = 'test_str'
    dict_1['test_int'] = 42
    dict_1['test_bool'] = False
    dict_1['test_none'] = None

# Generated at 2022-06-25 12:37:24.931883
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_2 = {
        'varname': 'value',
    }
    dict_1 = {}
    dict_0 = {
        'varname': dict_1,
    }
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1)
    assert ansible_j2_vars_0.__getitem__('varname') == dict_2


# Generated at 2022-06-25 12:38:23.866821
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ansible_j2_vars = AnsibleJ2Vars()


# Generated at 2022-06-25 12:38:29.534880
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {'v': 'w'}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    assert ansible_j2_vars_0._locals == dict_0
    assert ansible_j2_vars_0._globals == dict_0
    ansible_j2_vars_0.__contains__('v')


# Generated at 2022-06-25 12:38:39.823612
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    value_0 = ansible_j2_vars_0.__contains__(dict_0)
    if value_0 != NotImplemented:
        value_0 = True
    value_1 = ansible_j2_vars_0.__contains__(dict_0)
    if value_1 != NotImplemented:
        value_1 = True
    value_2 = ansible_j2_vars_0.__contains__(dict_0)
    if value_2 != NotImplemented:
        value_2 = True
    value_3 = ansible_j2_vars_0.__contains__(dict_0)

# Generated at 2022-06-25 12:38:42.871393
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    assert not ansible_j2_vars_0.__contains__(dict_0)


# Generated at 2022-06-25 12:38:45.903256
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    int_0 = ansible_j2_vars_0.__len__()
    assert int_0 == 0


# Generated at 2022-06-25 12:38:50.706051
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    dict_1 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    ansible_j2_vars_0[dict_1] = dict_0
    try:
        ansible_j2_vars_0.__getitem__(dict_0)
    except KeyError as e:
        assert(False)
    except Exception as e:
        assert(True)
    else:
        assert(False)


# Generated at 2022-06-25 12:38:55.671318
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    try:
        ansible_j2_vars_0.__getitem__('')
    except KeyError as e:
        # test if exception is thrown
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 12:38:56.918701
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 12:39:00.867017
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    assert isinstance(ansible_j2_vars_0['missing_var'], KeyError)


# Generated at 2022-06-25 12:39:04.503176
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    try:
        result = ansible_j2_vars_0.__getitem__(dict_0)
        assert False
    except NotImplementedError:
        assert True
