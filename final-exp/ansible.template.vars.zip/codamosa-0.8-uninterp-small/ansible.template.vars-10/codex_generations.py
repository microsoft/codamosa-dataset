

# Generated at 2022-06-25 12:29:51.013359
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    res = ansible_j2_vars_0.__contains__(str_0)
    sys.stderr.write('%s\n' % res)
    ansible_j2_vars_0.__contains__('%s is not a valid option')
    ansible_j2_vars_0.__contains__('%s is not a valid option')
    ansible_j2_vars_0.__contains__('%s is not a valid option')

# Generated at 2022-06-25 12:29:56.680552
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:30:01.130335
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    assert ansible_j2_vars_0['msg']


# Generated at 2022-06-25 12:30:05.815236
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    len_0 = ansible_j2_vars_0.__len__()
    assert len_0 == 0


# Generated at 2022-06-25 12:30:11.615560
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    assert_equal(list(ansible_j2_vars_0), [])


# Generated at 2022-06-25 12:30:17.624574
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = '%s is not a valid option'
    assert ansible_j2_vars_0.__contains__(str_1)


# Generated at 2022-06-25 12:30:22.025757
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)

    str_1 = ansible_j2_vars_0.__getitem__(ansible_j2_vars_0)

    assert str_0 == str_1


# Generated at 2022-06-25 12:30:30.728314
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_0 = 'lookup'
    # Unit test for exception KeyError (dict.__getitem__)
    with pytest.raises(KeyError) as err:
        ansible_j2_vars_0.__getitem__(str_0)
    assert err.match(r'undefined variable: lookup')


# Generated at 2022-06-25 12:30:37.387328
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = 'string'
    ansible_error_0 = AnsibleError(str_1, str_1)
    ansible_undefined_variable_0 = AnsibleUndefinedVariable(str_1, exception=ansible_error_0)
    ansible_j2_vars_0.__getitem__(str_1)

# Generated at 2022-06-25 12:30:38.282052
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()

# Generated at 2022-06-25 12:30:48.865260
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    try:
        ansible_j2_vars_0.__getitem__(str_0)
    except KeyError as e:
        print(e)
    # Exception: undefined variable: %s is not a valid option


# Generated at 2022-06-25 12:30:57.510033
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    with pytest.raises(Exception) as e_0:
        varname = '*w'
        ansible_j2_vars_0.__getitem__(varname)
    e_0.match(r".*is not a valid option: UndefinedError: 'str' object has no attribute '_templar'")
    str_1 = '%s is not a valid option'
    list_1 = [str_1, str_1, str_1]

# Generated at 2022-06-25 12:31:01.348054
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:31:06.089016
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Unit test for method __getitem__ of class AnsibleJ2Vars
    '''
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    result = ansible_j2_vars_0.__getitem__('%s is not a valid option')


# Generated at 2022-06-25 12:31:10.018541
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '*'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    assert ansible_j2_vars_0.__len__() == 3



# Generated at 2022-06-25 12:31:16.040321
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''Unit test for method __len__ of class AnsibleJ2Vars
    '''

    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)

    ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:31:24.554762
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test Cases
    for test_case_idx in range(0, 1):
        test_case = AnsibleJ2Vars.test_cases[test_case_idx]
        # Perform test
        try:
            test_case()
        except Exception as test_exception:
            print(test_exception)

# Test Cases
AnsibleJ2Vars.test_cases = [test_case_0]


if __name__ == "__main__":
    arg_count = len(sys.argv) - 1

# Generated at 2022-06-25 12:31:35.408462
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = 'enable_pam'
    varname_0 = None
    str_2 = 'playbooks/properties.yml'
    ansible_error_0 = AnsibleError('An unhandled exception occurred while templating \'enable_pam\'. Error was a <class \'ansible.errors.AnsibleUndefinedVariable\'>, original message: \'AnsibleUndefinedVariable: \'enable_pam\' is undefined\'')
    str_3 = 'enable_pam is not a valid option'

# Generated at 2022-06-25 12:31:44.048487
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # Just to make sure this test is valid.
    assert True

    # The following example is from test_case_0.
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)

    # The return type of __getitem__ is unknown, but it should not be None.
    # Testing the return value is not straightforward, so let's just make sure
    # it doesn't raise an exception.
    try:
        ansible_j2_vars_0.__getitem__(str_0)
    except Exception:
        assert False

    # The following example is from test_case_0.

# Generated at 2022-06-25 12:31:47.926021
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = '%s is not a valid option'
    list_1 = [str_1, str_1, str_1]
    bool_0 = ansible_j2_vars_0.__contains__(list_1)


# Generated at 2022-06-25 12:31:58.156649
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    with pytest.raises(AnsibleError):
        ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:32:04.682409
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = ansible_j2_vars_0['key']
    print(str_1)

if __name__ == "__main__":
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:32:13.755849
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = 'Z'
    try:
        if str_1 in ansible_j2_vars_0:
            pass
    except KeyError as e:
        pass
    except Exception as e:
        assert False, "Failed with error: %s" % e
    else:
        assert False, "No exception was raised"


# Generated at 2022-06-25 12:32:15.882549
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    try:
        test_case_0()
        success = True
    except:
        success = False
    assert(success)



# Generated at 2022-06-25 12:32:22.899415
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '!#'
    list_0 = ['HkF', 'zj', 'lN']
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_j2_vars_0.__contains__('lN')
    ansible_j2_vars_0.__contains__('zj')


# Generated at 2022-06-25 12:32:29.521621
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    try:
        ansible_j2_vars_0['test']
        raise Exception("Can't handle exception")
    except KeyError as exception_0:
        str_1 = exception_0.message
        assert str_1 == 'test'


# Generated at 2022-06-25 12:32:36.141294
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)

    str_1 = '%s is not a valid option'
    list_1 = [str_1, str_1, str_1]
    ansible_undefined_variable_0 = AnsibleUndefinedVariable(str_1, list_1)
    try:
        ansible_j2_vars_0[str_1]
    except AnsibleUndefinedVariable as e:
        str_2 = 'An unhandled exception occurred while templating \'%s\'. Error was a %s, original message: %s'

# Generated at 2022-06-25 12:32:37.785671
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Right now this method is not tested
    pass


# Generated at 2022-06-25 12:32:42.635073
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__('|')
    ansible_j2_vars_0.__getitem__('context')


# Generated at 2022-06-25 12:32:48.735711
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_j2_vars_0_0 = ansible_j2_vars_0[str_0]



# Generated at 2022-06-25 12:32:55.831798
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    list_0 = ['z', 'X', '5']
    ansible_j2_vars_0 = AnsibleJ2Vars(str, list_0)
    int_0 = ansible_j2_vars_0.__len__()
    assert int_0 >= 0


# Generated at 2022-06-25 12:33:01.636087
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Setting up the test
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:33:07.088693
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_j2_vars_1 = ansible_j2_vars_0.__iter__()
    assert ansible_j2_vars_1 is not None


# Generated at 2022-06-25 12:33:16.662189
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # missing var
    ansible_j2_vars_0 = AnsibleJ2Vars('spam', {})
    ansible_j2_vars_0._templar.available_variables['spam'] = 'spam'
    try:
        print(ansible_j2_vars_0['spam'])
        print('failed')
    except:
        print('failed')
    else:
        print('failed')
    # works
    ansible_j2_vars_0 = AnsibleJ2Vars('spam', {})
    ansible_j2_vars_0._templar.available_variables['spam'] = 'spam'

# Generated at 2022-06-25 12:33:23.239579
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:33:31.767054
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:33:34.634714
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_j2_vars_0.__getitem__('4')


# Generated at 2022-06-25 12:33:41.139831
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    assert ansible_j2_vars_0.__len__() == 4


# Generated at 2022-06-25 12:33:45.784595
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)

    str_0 = 'equals'
    ansible_j2_vars_0[str_0]


# Generated at 2022-06-25 12:33:47.187702
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert test_case_0() is None

if __name__ == '__main__':
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:33:58.084062
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_j2_vars_0.__getitem__(str_0)

# Generated at 2022-06-25 12:34:06.322476
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = '%s is not a valid option'
    # __contains__(str)
    success_0 = ansible_j2_vars_0.__contains__(str_1)



# Generated at 2022-06-25 12:34:11.834444
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    try:
        ansible_j2_vars_0.__getitem__(str_0)
    except KeyError as e:
        assert type(e) == KeyError


# Generated at 2022-06-25 12:34:17.009263
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    # Case 1 - AttributeError
    try:
        ansible_j2_vars_0[-1]
    except AttributeError:
        pass


# Generated at 2022-06-25 12:34:21.230913
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'prediction'
    dict_0 = dict(str_0=str_0, str_1=str_0, str_2=str_0)
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    str_1 = 'str_0'
    ansible_j2_vars_0.__getitem__(str_1)


# Generated at 2022-06-25 12:34:33.079706
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = '%s is not a valid option'
    str_2 = '%s is not a valid option'
    str_3 = '%s is not a valid option'
    ansible_j2_vars_1 = AnsibleJ2Vars(str_0, list_0)
    result_0 = ansible_j2_vars_1.__contains__(str_1)
    result_1 = ansible_j2_vars_1.__contains__(str_2)
    result_2 = ansible_j2_v

# Generated at 2022-06-25 12:34:38.368813
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = 'a'
    bool_0 = str_1 in ansible_j2_vars_0
    ansible_j2_vars_0.__getitem__(str_1)


# Generated at 2022-06-25 12:34:45.521968
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    assert str_0 in ansible_j2_vars_0
    assert str_0 not in ansible_j2_vars_0
    assert list_0 not in ansible_j2_vars_0


# Generated at 2022-06-25 12:34:48.686847
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Initialization
    ansible_j2_vars_0 = AnsibleJ2Vars('1', '2', '3')
    # test
    assert not ansible_j2_vars_0.__contains__('4')


# Generated at 2022-06-25 12:34:51.323445
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)


# Generated at 2022-06-25 12:35:13.248247
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    varname_0 = 'ansible_j2_vars_0'
    ansible_j2_vars_0.__getitem__(varname_0)


# Generated at 2022-06-25 12:35:16.971338
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:35:20.456327
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    int_0 = ansible_j2_vars_0.__len__()
    assert int_0 > 0


# Generated at 2022-06-25 12:35:29.831673
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = '%s is not a valid option'
    str_2 = '%s is not a valid option'
    str_3 = '%s is not a valid option'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    boolean_0 = ansible_j2_vars_0.__contains__(str_1)
    assert boolean_0
    boolean_1 = ansible_j2_vars_0.__contains__(str_2)
    assert not boolean_1

# Generated at 2022-06-25 12:35:37.948560
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    int_0 = ansible_j2_vars_0.__len__()
    # Ensure that you are getting a number
    assert isinstance(int_0, int)
    # Ensure the value returned from __len__ correctly reflects the number of variables in the collection.
    assert int_0 == 0


# Generated at 2022-06-25 12:35:43.112140
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_undefined_variable_0=None
    try:
        ansible_j2_vars_0.__getitem__('<template-string-4>')
    except AnsibleUndefinedVariable as e:
        ansible_undefined_variable_0=e

    assert 'undefined variable: %s' in str(ansible_undefined_variable_0)


# Generated at 2022-06-25 12:35:49.796610
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)

    # Test for method __iter__(0) of class AnsibleJ2Vars
    try:
        assert(isinstance(ansible_j2_vars_0.__iter__(), (list, tuple, dict, set)))
    except AssertionError as e:
        raise AssertionError(str(e))



# Generated at 2022-06-25 12:35:51.167453
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 12:35:55.712340
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    int_0 = ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:36:04.124984
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = '%s is not a valid option'
    list_0 = [str_0, str_1, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    ansible_j2_vars_0.__getitem__("n3s2z9s6s")

# Generated at 2022-06-25 12:36:42.059573
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """Check if str_0 is an instance of AnsibleJ2Vars """
    if isinstance(str_0, AnsibleJ2Vars):
        str_0.__getitem__('str_0')


# Generated at 2022-06-25 12:36:47.927060
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    j2vars = AnsibleJ2Vars(None, None)
    j2vars._globals = {
        'a': 1,
        'b': 2,
    }
    j2vars._locals = {
        'a': 10,
        'c': 3,
    }
    assert j2vars.__contains__('a') == True
    assert j2vars.__contains__('b') == True
    assert j2vars.__contains__('c') == True
    assert j2vars.__contains__('d') == False

# Generated at 2022-06-25 12:36:51.867100
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    int_0 = ansible_j2_vars_0.__len__()
    assert int_0 == 3


# Generated at 2022-06-25 12:36:58.417303
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    yaml_data = """
        ---
        notify:
          options: [debug, verbose]
          message: changed={{changed}}
          when: changed
        stat:
          path: /etc/hosts
          changed_when: "ansible_facts['stat']['exists']"
        debug: msg="{{inventory_hostname}} >> {{hostvars[inventory_hostname]}}"
        """


# Generated at 2022-06-25 12:37:04.144084
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = '%s is not a valid option'
    list_1 = [str_1, str_1, str_1]
    ansible_j2_vars_0.__contains__(list_1)


# Generated at 2022-06-25 12:37:08.982631
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    assert ansible_j2_vars_0.__contains__('Access-Control-Allow-Methods') != 1454


# Generated at 2022-06-25 12:37:15.056843
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    assert ansible_j2_vars_0.__getitem__(str_0) == list_0

# Generated at 2022-06-25 12:37:23.258411
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # Case 0
    try:
        str_0 = '%s is not a valid option'
        list_0 = [str_0, str_0, str_0]
        ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
        ansible_j2_vars_0.__contains__(str_0)
    except Exception as err:
        assert str(err) == "AnsibleJ2Vars TypeError: __contains__"

    # Case 1

# Generated at 2022-06-25 12:37:32.875487
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = ansible_j2_vars_0[str_0]
    str_2 = 'failure while parsing the inventory'
    str_3 = '%s: %s' % (str_0, str_2)
    try:
        ansible_j2_vars_0[str_2]
        assert False
    except KeyError as e:
        if str_3 != str(e):
            assert False


test_case_0()
test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:37:37.749052
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    assert ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:38:45.396715
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = "^l2G@R!%cL(jhf#n"
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()


# Generated at 2022-06-25 12:38:48.024211
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    f_0 = ansible_j2_vars_0.__len__()

# Generated at 2022-06-25 12:38:57.019390
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    locals_0 = {'c': 3}
    locals_1 = {'b': 2}
    locals_2 = {'a': 1}
    ansible_j2_vars_0.add_locals(locals_0)
    ansible_j2_vars_0.add_locals(locals_1)
    ansible_j2_vars_0.add_locals(locals_2)
    assert True



# Generated at 2022-06-25 12:39:01.614930
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    # TEST START
    ansible_j2_vars_0[0]


# Generated at 2022-06-25 12:39:03.724649
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # TestCase0:
    test_case_0()

if __name__ == "__main__":
    # test_AnsibleJ2Vars()
    pass

# Generated at 2022-06-25 12:39:08.563779
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%s is not a valid option'
    list_0 = [str_0, str_0, str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    str_1 = '%s is not a valid option'
    list_1 = [str_1, str_1, str_1]
    ansible_j2_vars_0._templar.template(list_1)

# Generated at 2022-06-25 12:39:12.814765
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
   str_0 = 'tests/test_AnsibleJ2Vars.py'
   list_0 = [str_0, str_0, str_0]
   ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
   assert ansible_j2_vars_0.__len__() == 3


# Generated at 2022-06-25 12:39:17.674625
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = ''
    list_0 = [str_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, list_0)
    if len(ansible_j2_vars_0) != 1:
        raise AssertionError('len of AnsibleJ2Vars is not 1')


# Generated at 2022-06-25 12:39:19.713679
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    ansible_j2_vars_0 = AnsibleJ2Vars(list_0, list_0)
    assert ansible_j2_vars_0



# Generated at 2022-06-25 12:39:20.481748
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    test_case_0()