

# Generated at 2022-06-25 12:29:37.057857
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test with success - Unimplemented
    pass


# Generated at 2022-06-25 12:29:42.064508
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    ansible_j2_vars_1 = ansible_j2_vars_0.__iter__()
    assert isinstance(ansible_j2_vars_1, iter) == True


# Generated at 2022-06-25 12:29:46.805557
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    k_0 = None
    # bool_1 = bool_0.__contains__(k_0)
    # bool_2 = ansible_j2_vars_0.__contains__(k_0)
    # assert bool_1 == bool_2


# Generated at 2022-06-25 12:29:57.249699
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    ansible_j2_vars_0._templar.template = lambda variable: variable
    ansible_j2_vars_0._templar.available_variables = {'vars': {'vars': 'vars'}, 'HostVars': HostVars({})}
    ansible_j2_vars_0._locals = {'AnsibleJ2Vars': AnsibleJ2Vars, 'HostVars': HostVars}

# Generated at 2022-06-25 12:30:05.599853
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    Tests the AnsibleJ2Vars class method __len__.
    """

    # The test below is a user defined test case, replace it with the
    # test cases above and add more test cases here if you need to

    # Note that the test method MUST be called 'test_'.
    # If you want to change the test case name, please change the method name.
    # For example, change test_case_0 to test_My_test_case_name
    #
    # You can use this template to add your test case, which is a simple
    # method that you can use to test a specific functionality of your
    # code.
    #
    # For example, let's say that the method you want to test is add,
    # and you expect 2+2 to return 4.
    #
    # def test_add():
   

# Generated at 2022-06-25 12:30:10.070447
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)

    assert ansible_j2_vars_0.__contains__("str_1") == False
    assert ansible_j2_vars_0.__contains__("str_2") == False


# Generated at 2022-06-25 12:30:12.843810
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    ansible_j2_vars_0.__contains__()


# Generated at 2022-06-25 12:30:20.697457
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Input data
    bool_0 = True
    tuple_0 = ()
    str_0 = None

    # Expected output
    # assertEqual can not be used because the instances of the class AnsibleJ2Vars
    # have the different addresses in the memory

    # Actual output
    try:
        ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    except:
        ansible_j2_vars_0 = None

    # Check if the instances of AnsibleJ2Vars are different
    assert id(ansible_j2_vars_0) != id(None)


# Generated at 2022-06-25 12:30:26.862653
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    int_0 = ansible_j2_vars_0.__len__()
    assert int_0 == 0, "int_0 is not 0"


# Generated at 2022-06-25 12:30:30.390687
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)


# Generated at 2022-06-25 12:30:39.042920
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    assert_equal(ansible_j2_vars_0.__getitem__('v1'), 'b')



# Generated at 2022-06-25 12:30:46.834905
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)

    assert ansible_j2_vars_0.__getitem__('foo_0') is None
    assert ansible_j2_vars_0.__getitem__('foo_1') is None
    assert ansible_j2_vars_0.__getitem__('foo_2') is None
    assert ansible_j2_vars_0.__getitem__('foo_3') is None


# Generated at 2022-06-25 12:30:53.497706
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # FIXME: This test has a known bug in CPython 3.4:
    # `test_AnsibleJ2Vars___contains__` is never reached, even though it appears in
    # the disassembly. The bug is filed against CPython (https://bugs.python.org/issue24495).
    # Note that the same test functions perfectly in Python 2.7 and 3.5.
    # We skip the test for now.
    # If this test is updated, please also update test_case_0.
    #test_case_0()
    pass


# Generated at 2022-06-25 12:31:00.738665
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Generate a fake 'templar'
    templar = [object, object, object]
    # Generate a fake 'globals'
    globals = [object]
    # Generate a fake 'locals'
    locals = {'k_0': [object, object, object], 'k_1': [object, object, object], 'k_2': [object, object, object]}
    ansible_j2_vars_0 = AnsibleJ2Vars(templar, globals, locals=locals)
    # Generate a fake 'key'
    key = [object, object, object]
    # Test the method
    ansible_j2_vars_0.__contains__(key)


# Generated at 2022-06-25 12:31:02.775270
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)


# Generated at 2022-06-25 12:31:07.908520
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    dict_0 = {}
    dict_0['varname'] = 'foo'
    str_1 = ansible_j2_vars_0.__getitem__(dict_0['varname'])
    assert str_1 == 'foo'


# Generated at 2022-06-25 12:31:15.045191
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # I'm going to leave this here for awhile as it gives me a quick
    # way to see if a failure running the unit tests is a test framework
    # bug or not.
    # assert True is True
    try:
        test_case_0()
    except Exception as e:
        print("\nERROR: Running the unit tests failed. See 'tests/test_utils.log' for a traceback.")
        f = open("tests/test_utils_failed", "w")
        import traceback
        traceback.print_exc(file=f)
        f.close()
        raise

# Generated at 2022-06-25 12:31:23.798226
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # varname =
    # value =
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    try:
        ansible_j2_vars_0.__getitem__(varname)
    except KeyError as exception_0:
        pass

    # varname =
    # value =
    bool_1 = True
    tuple_1 = ()
    str_1 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(bool_1, tuple_1, str_1)

# Generated at 2022-06-25 12:31:25.945456
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)


# Generated at 2022-06-25 12:31:28.641201
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert AnsibleJ2Vars.__getitem__('self', 'k') == None


# Generated at 2022-06-25 12:31:37.943391
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Create an object of AnsibleJ2Vars class
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)

    # Get AnsibleJ2Vars iterator
    iter_0 = ansible_j2_vars_0.__iter__()

    # Call iter_0.next
    iter_0.next()



# Generated at 2022-06-25 12:31:42.823604
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Initialize mock for AnsibleJ2Vars

    # Construct AnsibleJ2Vars instance without passing in any arguments
    ansible_j2_vars_0 = AnsibleJ2Vars()
    str_0 = 'key'

    # Call AnsibleJ2Vars.__getitem__
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:31:46.439769
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    print("ansiblej2vars.py __getitem__")
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    try:
        ansible_j2_vars_0.__getitem__('vars')
    except KeyError as e:
        print(e)


# Generated at 2022-06-25 12:31:47.534278
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass



# Generated at 2022-06-25 12:31:52.841954
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    bool_1 = ansible_j2_vars_0.__contains__(str_0)
    assert bool_1 is False


# Generated at 2022-06-25 12:31:56.059438
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    int_1 = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:32:02.697983
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
  bool_0 = True
  tuple_0 = ()
  str_0 = None
  ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
  ansible_j2_vars_0.__getitem__()


# Generated at 2022-06-25 12:32:07.360324
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    length_0 = ansible_j2_vars_0.__len__()
    length_1 = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:32:12.937097
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    length = len(ansible_j2_vars_0)


# Generated at 2022-06-25 12:32:18.009101
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = True
    tuple_0 = ()
    str_0 = ""
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    try:
        ansible_j2_vars_0.__getitem__(str_0)
    except KeyError:
        pass
    except Exception as exception_0:
        raise Exception("Exception occurred")


# Generated at 2022-06-25 12:32:22.810994
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Create an instance of AnsibleJ2Vars
    # Test template __contains__()
    pass


# Generated at 2022-06-25 12:32:29.150830
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Initialize an AnsibleJ2Vars object
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)

    # Call __contains__ method of AnsibleJ2Vars with arguments
    str_0 = None
    __contains___0_retval = ansible_j2_vars_0.__contains__(str_0)

    # Assert the results of __contains__ are as expected
    assert __contains___0_retval is None


# Generated at 2022-06-25 12:32:38.245398
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    dict_0 = dict()
    dict_0['key_0'] = 'value_0'
    dict_0['key_1'] = 'value_1'

    dict_1 = dict()
    dict_1['key_0'] = 'value_0'
    dict_1['key_1'] = 'value_1'

    dict_2 = dict()
    dict_2['key_0'] = 'value_0'
    dict_2['key_1'] = 'value_1'

    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1, dict_2)

    # Check the case that returns 'True'
    assert (True)

    # Check the case that returns 'False'
    assert (False)


# Generated at 2022-06-25 12:32:39.707573
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    print("test_AnsibleJ2Vars___iter__ will be skipped in OpenStack CI")


# Generated at 2022-06-25 12:32:42.063161
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        test_case_0()
    except Exception as e:
        raise Exception(e)

if __name__ == "__main__":
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:32:49.226204
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    int_0 = 0
    try:
        int_3 = ansible_j2_vars_0.__getitem__(int_0)
        raise RuntimeError('Exception should have been thrown')
    except Exception as e:
        str_0 = str(e)


# Generated at 2022-06-25 12:32:50.110513
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    test_case_0()


# Generated at 2022-06-25 12:32:54.019274
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:33:02.718500
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = True
    tuple_0 = ()
    str_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, tuple_0, str_0)
    bool_1 = ansible_j2_vars_0.__contains__(str_0)
    assert bool_1 == False
    bool_2 = ansible_j2_vars_0.__contains__(tuple_0)
    assert bool_2 == False
    bool_3 = ansible_j2_vars_0.__contains__(bool_0)
    assert bool_3 == False


# Generated at 2022-06-25 12:33:03.761641
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # FIXME
    pass


# Generated at 2022-06-25 12:33:17.526582
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '1'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0 = ansible_j2_vars_0


# Generated at 2022-06-25 12:33:21.581593
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    if 'Za' in ansible_j2_vars_0:
        print('True')
    else:
        print('False')
    if 'Za' in ansible_j2_vars_0:
        print('True')
    else:
        print('False')


if __name__ == '__main__':
    test_case_0()
    test_AnsibleJ2Vars___contains__()

# Generated at 2022-06-25 12:33:22.444440
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass


# Generated at 2022-06-25 12:33:31.104072
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'n+nWgYf$w'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_1 = ansible_j2_vars_0.add_locals(dict_1)

    assert ansible_j2_vars_0.__contains__('!') == False
    assert ansible_j2_vars_1.__contains__('!') == False


# Generated at 2022-06-25 12:33:34.291410
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'ZKx0bpe1fOcN'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 12:33:44.333327
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'Oc%wZhN^*(!N'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    bool_0 = ansible_j2_vars_0.__contains__(str_0)
    # unit test for bug #34443, test __contains__ for all values
    for _ in dict_0:
        _ # check for usage
    # end unit test for bug #34443
    return


# Generated at 2022-06-25 12:33:52.078149
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '%T_ sV<sF*-mH^dL\n'
    str_1 = 'Y'
    str_2 = 'D'
    str_3 = '<'
    str_4 = 'n'
    str_5 = 'DpMM'
    str_6 = '5'

    dict_0 = {str_0: str_1, str_2: str_3, str_4: str_5, str_6: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 12:33:54.773965
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = 'VQxnxH3vyG'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    for x in iter(ansible_j2_vars_0):
        print(x)


# Generated at 2022-06-25 12:33:57.305279
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    assert not isinstance(ansible_j2_vars_0.__iter__(), type(dict()))


# Generated at 2022-06-25 12:34:03.967748
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = 'xB=mymKt;YpS'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert(ansible_j2_vars_0.__contains__('xB=mymKt;YpS'))
    assert(ansible_j2_vars_0.__getitem__('xB=mymKt;YpS') == 'xB=mymKt;YpS')
    assert(ansible_j2_vars_0.__len__() == 3)


# Generated at 2022-06-25 12:34:13.841204
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    int_0 = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:34:18.052151
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)

    return


# Generated at 2022-06-25 12:34:18.825277
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()


# Generated at 2022-06-25 12:34:22.525734
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = 'cGk0mCBxGVj6T'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    print(ansible_j2_vars_0)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:34:30.718030
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert callable(AnsibleJ2Vars.__len__)
    str_0 = 'U{b6@'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    int_0 = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:34:35.167891
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 12:34:41.224657
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    dict_0['test_getitem_default'] = 'default'
    dict_0['test_getitem_overridden'] = 'default'
    dict_0['test_getitem_overridden_both'] = 'default'

    dict_1 = {}
    dict_1['test_getitem_overridden'] = 'overridden'
    dict_1['test_getitem_overridden_both'] = 'overridden_first'

    dict_2 = {}
    dict_2['test_getitem_overridden_both'] = 'overridden_second'

    dict_3 = {}
    dict_3['test_getitem_overridden_both'] = 'overridden_both'


# Generated at 2022-06-25 12:34:42.144194
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert False


# Generated at 2022-06-25 12:34:47.862371
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:34:55.345035
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'O*XQCfZG^0'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__contains__('O*XQCfZG^0')



# Generated at 2022-06-25 12:35:05.536147
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'Gv2TjTlJm9fz'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    str_1 = '3AzSgSQlREnW'
    ansible_j2_vars_0.__getitem__(str_1)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:35:13.871887
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'IDQ5c5KxG5Q*'
    str_1 = 'Uo4H4G4JU6*&'
    str_2 = 'x2Q'
    dict_0 = {str_0: str_0, str_1: str_1, str_2: str_2}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    int_0 = ansible_j2_vars_0.__len__()
    int_1 = len(dict_0)
    int_2 = int_1
    assert int_2 == int_0


# Generated at 2022-06-25 12:35:20.684591
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    value_0 = ansible_j2_vars_0.__contains__(str_0)
    value_1 = ansible_j2_vars_0.__contains__('Z*PvJVt0RM7Ia')
    value_2 = ansible_j2_vars_0.__contains__('Z*PvJVt0RM7Ia')

# Generated at 2022-06-25 12:35:26.092269
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert not ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:35:33.164633
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    dict_0 = {'0': 'D', '1': 'T'}
    dict_1 = {'0': 'D', '1': 'T'}
    dict_2 = {'0': 'D', '1': 'T'}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1, dict_2)
    for i in ansible_j2_vars_0:
        print(i)


# Generated at 2022-06-25 12:35:40.564190
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'U8F*f@=sxA'
    str_1 = '^!exC@AX'
    dict_0 = {str_1: str_0, str_0: str_1, str_1: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    dict_1 = {str_0: str_0, str_1: str_1, str_0: str_0}
    str_2 = ansible_j2_vars_0[str_0]
    str_3 = ansible_j2_vars_0[str_1]



# Generated at 2022-06-25 12:35:49.308225
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = 'IbNzvf8u1W5U5'
    str_1 = 'r8U6ldkp9XEoM'
    str_2 = '1C5d5UOZ6rPi7'
    dict_0 = {str_0: str_0, str_1: str_1, str_2: str_2}
    str_3 = 'JbHdzz1DpAosk'
    str_4 = 'wRnfiSwjbHgQm'
    str_5 = '4wk4b4zc4PoZd'
    dict_1 = {str_3: str_3, str_4: str_4, str_5: str_5}

# Generated at 2022-06-25 12:35:53.972083
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '5r5Zn8nfjKIF'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bool_0 = ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:36:00.314117
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'jT0IkTkEQGZrB'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert ansible_j2_vars_0.__getitem__(str_0) == str_0


# Generated at 2022-06-25 12:36:02.071170
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()

# Run test cases
test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:36:10.786010
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'v'
    str_1 = 'y)EzFhd'
    str_2 = ' %XfA'
    int_0 = 4
    getitem_0 = ('',)
    ansible_j2_vars_0 = AnsibleJ2Vars(dict(), {str_1: 0, str_2: int_0}, {str_0: str_0})
    assert ansible_j2_vars_0.__getitem__(getitem_0) == int_0

# Generated at 2022-06-25 12:36:14.645088
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        test_case_0()
    except Exception as exception:
        print('triggered an exception: ', exception)
        assert False, 'Failed to create AnsibleJ2Vars object using AnsibleJ2Vars()'

# Generated at 2022-06-25 12:36:23.074236
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    try:
        str_0 = 'PuS'
        dict_0 = ansible_j2_vars_0[str_0]
    except KeyError as e_obj:
        str_0 = 'sjzusUG'
        str_1 = e_obj.args[0]
        str_1 = str_1[:0]
    else:
        str_0 = 'jFv'

# Generated at 2022-06-25 12:36:30.215417
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Initialization of objects
    try:
        # Test case update/creation
        str_0 = 'Z*PvJVt0RM7Ia'
        dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
        ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
        ansible_j2_vars_0.__getitem__(str_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 12:36:34.034044
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = 'WL'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_1 = ansible_j2_vars_0.add_locals(dict_1)
    ansible_j2_vars_2 = AnsibleJ2Vars(dict_1, dict_1, dict_1)


# Generated at 2022-06-25 12:36:37.308509
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test case for getitem (__getitem__)
    try:
        ansible_j2_vars___getitem__ = AnsibleJ2Vars()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 12:36:38.162137
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()

# Generated at 2022-06-25 12:36:43.372231
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'ansible_facts'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__()

# Generated at 2022-06-25 12:36:46.276938
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert ansible_j2_vars_0.__len__() == 3


# Generated at 2022-06-25 12:36:50.839882
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'Tdz.HvJZW0M8E4'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0[str_0]


# Generated at 2022-06-25 12:37:02.131967
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'd3'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_1, dict_1, dict_1)
    ansible_j2_vars_1 = ansible_j2_vars_0[str_0]


# Generated at 2022-06-25 12:37:06.634085
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 12:37:13.835029
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'x6Uh9U6'
    dict_0 = {str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)

# Generated at 2022-06-25 12:37:22.477486
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'NghuxRn8'
    str_1 = 'C1=_0'
    str_2 = 'j%'
    str_3 = 'b!z-L'
    str_4 = '7QX9e^'
    str_5 = 'yxBz-'
    str_6 = 'V%+$S'
    str_7 = 'p&1'
    str_8 = 'W8FwMb'
    str_9 = 'Hc%l'
    str_10 = '{5n'
    str_11 = '3qLv$'
    str_12 = 'gn(D<'
    str_13 = 'OI8}U'
    str_14 = 'xO6r\_'
    str_15 = ';C~'
   

# Generated at 2022-06-25 12:37:30.665436
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # TEST CASE: test_case_0
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    try:
        ansible_j2_vars_0.__getitem__(str_0)
    except Exception as e:
        if type(e) is KeyError:
            pass


# Generated at 2022-06-25 12:37:37.315115
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Test case with "Z*PvJVt0RM7Ia" as str_0
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert ansible_j2_vars_0._templar == dict_0
    assert ansible_j2_vars_0._globals == dict_0
    assert ansible_j2_vars_0._locals == dict_0
    # Test case with "l^\tB4}#-YvY]" as str_0

# Generated at 2022-06-25 12:37:41.010525
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        str_0 = 'Z*PvJVt0RM7Ia'
        dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
        ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
        ansible_j2_vars_0.__getitem__('Z*PvJVt0RM7Ia')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 12:37:48.944266
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'sPfTnPxTU*D'
    list_0 = ['6', 'n6U*D']
    int_0 = -2258930997439
    float_0 = 0.0557291355000545
    dict_0 = {list_0[1]: float_0, float_0: float_0, 2: float_0, float_0: float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:37:57.897649
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'Ev8WwM'
    from ansible.vars.hostvars import HostVars
    host_vars_0 = HostVars()
    ansible_j2_vars_0 = AnsibleJ2Vars(host_vars_0, 'fWwK8e')
    varname_0 = 'pE6qxU'
    try:
        value_0 = ansible_j2_vars_0[varname_0]
    except KeyError as e:
        if not isinstance(e.args[0], str):
            raise TypeError()


# Generated at 2022-06-25 12:38:05.187258
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '\\t\\sgl`)'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert(ansible_j2_vars_0.__iter__() == iter({str_0, str_0, str_0}.union({str_0, str_0, str_0}).union({str_0, str_0, str_0})))


# Generated at 2022-06-25 12:38:16.450137
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '&nQ'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)

    # No exception should be raised
    ansible_j2_vars_0['&nQ']

# Generated at 2022-06-25 12:38:27.428748
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = 's)s/0glpOJ6x^U'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    str_1 = '9d;W@+G:a{]QMw'
    str_2 = str_0
    dict_1 = {str_2: str_2, str_0: str_1, str_1: str_1}
    ansible_j2_vars_0._locals = dict_1
    str_3 = '$'

# Generated at 2022-06-25 12:38:36.947131
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # Test for method __contains__ of class AnsibleJ2Vars
    # Test for method __contains__ of class AnsibleJ2Vars

    str_0 = '#V8Bv%cHnue'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    str_1 = 'M'
    str_2 = '@g<?nxL-Eo'
    num_0 = -99221254
    num_1 = 0

# Generated at 2022-06-25 12:38:45.280614
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    bool_0 = ansible_j2_vars_0.__contains__(str_0)
    ansible_j2_vars_0.__getitem__(str_0)
    bool_1 = ansible_j2_vars_0.__contains__(str_0)
    ansible_j2_vars_0.__getitem__(str_0)

# Generated at 2022-06-25 12:38:52.850677
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '5ZCk5ZCk5ZCk5ZCk'
    str_1 = 'PvJVt0RM7Ia'
    str_2 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_1, str_1: str_2, str_2: str_2}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__(str_2)
    ansible_j2_vars_0.__getitem__(str_0)
    ansible_j2_vars_0.__getitem__(str_1)


# Generated at 2022-06-25 12:38:59.138669
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '_!Z!**M#F'
    dict_0 = {str_0: str_0, str_0: str_0}
    dict_1 = {str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__contains__(str_0)
    assert True


# Generated at 2022-06-25 12:39:07.832266
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'Y?'
    str_1 = '#'
    str_2 = '~XzL$95>|'
    lis_0 = ['Y?', 't', '~XzL$95>|']
    tup_0 = (str_0, str_1, str_2)
    set_0 = set(lis_0)
    frozenset_0 = frozenset(lis_0)
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_1, str_2)

    # Testing constructor __init__()...
    assert ansible_j2_vars_0.__init__() == None

    # Testing method __contains__()...

# Generated at 2022-06-25 12:39:08.928107
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
  try:
     test_case_0()
  except Exception as err:
    print(err)


# Generated at 2022-06-25 12:39:15.504961
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'Z*PvJVt0RM7Ia'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    try:
        ansible_j2_vars_0['Z*PvJVt0RM7Ia']
    except KeyError:
        pass


# Generated at 2022-06-25 12:39:22.825595
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = 'V3q6hcLK1OyOc'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    dict_2 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1, dict_2)
    ansible_j2_vars_0.__iter__()
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_0, dict_1, dict_2)
    ansible_

# Generated at 2022-06-25 12:39:31.725098
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = 'z4LdTDaA43*L'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__iter__()
