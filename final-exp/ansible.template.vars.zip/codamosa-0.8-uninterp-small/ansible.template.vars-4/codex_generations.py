

# Generated at 2022-06-25 12:29:37.097277
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    int_0 = ansible_j2_vars_0.__contains__('42')



# Generated at 2022-06-25 12:29:41.520457
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    dict_0 = dict()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, dict_0)
    try:
        assert ansible_j2_vars_0.__contains__(set_0) == False
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 12:29:47.003926
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    ansible_j2_vars_0.__contains__(float_0)


# Generated at 2022-06-25 12:29:57.398388
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    int_0 = 564
    bool_0 = bool(0)
    str_0 = str('')
    bool_1 = bool(0)
    str_1 = str('')
    list_0 = [int_0, bool_0, str_0, bool_1, str_1]
    str_2 = str('')
    float_0 = 744.0338
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()

# Generated at 2022-06-25 12:30:02.173761
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # AssertionError: expected exception not raised
    with pytest.raises(AssertionError):
        test_case_0()

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-25 12:30:07.839926
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    assert ansible_j2_vars_0.__contains__(float_0) == True
    assert ansible_j2_vars_0.__contains__(float_0) == True
    assert ansible_j2_vars_0.__contains__(float_0) == True


# Generated at 2022-06-25 12:30:11.455419
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    int_0 = ansible_j2_vars_0.__contains__(float_0)


# Generated at 2022-06-25 12:30:18.552753
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    # Test method __contains__
    # Expected exception: KeyError
    try:
        ansible_j2_vars_0.__contains__('var_1')
    except KeyError as e:
        pass
    else:
        raise Exception('ExpectedKeyError not raised')


# Generated at 2022-06-25 12:30:21.529025
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # No exceptions have been thrown
    assert True


# Generated at 2022-06-25 12:30:32.557804
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 134.0724
    float_1 = -930.163
    float_2 = -37.2941
    float_3 = -139.333
    int_0 = 0
    str_0 = 'i&%c<'
    str_1 = 'EgR'
    str_2 = '8'
    str_3 = 'D4P'
    tuple_0 = (str_1, int_0, str_3)
    tuple_1 = (float_2, int_0)
    tuple_2 = (float_1, str_0)
    tuple_3 = (int_0, float_0, float_1)
    tuple_4 = (int_0, )
    tuple_5 = (float_1, int_0, str_3)

# Generated at 2022-06-25 12:30:41.487920
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)

    #TODO:
    #assert(ansible_j2_vars_0.__getitem__() == tuple_0)
    #assert(ansible_j2_vars_0.__getitem__(()) == tuple_1)


# Generated at 2022-06-25 12:30:45.730887
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars(744.0338, {744.0338, 744.0338, 744.0338})
    ansible_j2_vars_0.__getitem__(744.0338)


# Generated at 2022-06-25 12:30:49.941608
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    float_0 = float_0
    assert float_0 in ansible_j2_vars_0


# Generated at 2022-06-25 12:30:59.444025
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    float_0 = 4.039
    str_0 = 'G'
    str_1 = '{'
    str_2 = '>|a.i'
    str_3 = 'Uz'
    int_0 = 16
    str_4 = ':'
    float_1 = 703.9
    float_2 = 0.0
    str_5 = 'jS8}'
    str_6 = 'kR'
    set_0 = {str_1, str_1, str_3, str_3}
    str_7 = 'F'
    str_8 = 'pj+}'
    str_9 = '{'
    int_1 = 3
    str_10 = 'X'
    str_11 = 'k'
    str_12 = '$<'
    str_13

# Generated at 2022-06-25 12:31:03.287990
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    #  The __contains__ method does not have a return value
    #  must be called for coverage
    ansible_j2_vars_0.__contains__('dict_0')

    ansible_j2_vars_0.__getitem__('dict_0')



# Generated at 2022-06-25 12:31:06.670045
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 15.8447265625
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    assert (ansible_j2_vars_0 == {})


# Generated at 2022-06-25 12:31:12.928244
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_1 = 824.299
    set_1 = {float_1, float_1, float_1}
    ansible_j2_vars_1 = AnsibleJ2Vars(float_1, set_1)

    # Act: Invoke the method on the class object with a known set of values
    bool_0 = ansible_j2_vars_1.__contains__(float_1)

    # Assert: Ensure that the values are correct
    assert bool_0 == True



# Generated at 2022-06-25 12:31:16.965068
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import random
    import string

    alphabet = string.ascii_letters + string.digits
    varname = ''.join(random.choice(alphabet) for i in range(6))

    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    value = ansible_j2_vars_0[varname]


# Generated at 2022-06-25 12:31:25.220862
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 284.8030
    int_1 = 7
    float_1 = 9.94
    int_0 = 2
    float_2 = 9.8585
    set_0 = {int_1, int_0, int_1}
    ansible_j2_vars_1 = AnsibleJ2Vars(int_0, set_0)
    ansible_j2_vars_1.__getitem__(int_0)
    ansible_j2_vars_1.copy()
    ansible_j2_vars_1.__getitem__(int_1)
    ansible_j2_vars_1.clear()

# Generated at 2022-06-25 12:31:30.557255
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    ansible_j2_vars_0.__contains__('<module>')


# Generated at 2022-06-25 12:31:41.802456
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = dict()
    dict_0['AnsibleJ2Vars___getitem__float_0'] = 744.0338
    dict_0['AnsibleJ2Vars___getitem__set_0'] = set({744.0338, 744.0338, 744.0338})
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0['AnsibleJ2Vars___getitem__float_0'], dict_0['AnsibleJ2Vars___getitem__set_0'])
    assert ansible_j2_vars_0.__getitem__('float_0') == dict_0['AnsibleJ2Vars___getitem__float_0']

# Generated at 2022-06-25 12:31:47.742183
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from collections import defaultdict
    from copy import copy
    from datetime import date, datetime, timedelta
    from decimal import Decimal
    from numbers import Number
    from random import randint, choice
    from textwrap import dedent
    from unittest import TestCase
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping
    from ansible.module_utils.common.text.converters import to_text

    # initialize vars
    case_num_0 = 23
    case_num_1 = 27
    case_num_2 = 37
    case_num_3 = 7
    case_num_4 = 29
    case_num_5 = 15
    case_num_6 = 16
    case_num

# Generated at 2022-06-25 12:31:59.359668
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    float_0 = 537.9984
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    # Iterating through ansible_j2_vars_0 using __iter__
    assert len(ansible_j2_vars_0) == 0
    ansible_j2_vars_0.__iter__()
    ansible_j2_vars_0.__iter__()
    ansible_j2_vars_0.__iter__()
    ansible_j2_vars_0.__iter__()
    ansible_j2_vars_0.__iter__()
    ansible_j2_vars_0.__iter__()
   

# Generated at 2022-06-25 12:32:07.814323
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    print('Testing method AnsibleJ2Vars.__getitem__ of class AnsibleJ2Vars')

    # initialize test values
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)

    # run test
    try:
        ansible_j2_vars_0['set_0']
        print('\nERROR: Expected exception, but AnsibleJ2Vars.__getitem__ did not throw an exception')
    except KeyError:
        pass


# Generated at 2022-06-25 12:32:14.797199
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    bool_0 = ansible_j2_vars_0.__contains__(float_0)
    assert bool_0 is False


# Generated at 2022-06-25 12:32:23.523221
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    ansible_j2_vars_0.__getitem__(float_0)
    #assert keyerror_0 == to_ensure_no_exception_is_raised(ansible_j2_vars_0.__getitem__, float_0)



# Generated at 2022-06-25 12:32:33.457083
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_8 = 744.0338
    set_1 = {float_8, float_8, float_8}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_8, set_1)
    # Test case __getitem__ of class AnsibleJ2Vars
    ansible_j2_vars_0.__getitem__(ansible_j2_vars_0)
    # Test case __getitem__ of class AnsibleJ2Vars
    ansible_j2_vars_0.__getitem__(ansible_j2_vars_0)
    # Test case __getitem__ of class AnsibleJ2Vars
    ansible_j2_vars_0.__getitem__(ansible_j2_vars_0)

# Generated at 2022-06-25 12:32:38.320806
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    float_1 = ansible_j2_vars_0[float_0]
    assert float_1 == float_0


# Generated at 2022-06-25 12:32:45.791299
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 68.4908
    tuple_0 = (float_0, 'wCH=', float_0)
    dict_0 = collections.OrderedDict()
    dict_0['HostVars'] = dict_0
    dict_0['vars'] = tuple_0
    int_0 = 0
    float_1 = float()
    float_2 = float()
    float_2 = float_2
    dict_1 = dict(vars=dict_0, HostVars=dict_0)
    float_3 = float_1 + float_2
    float_3 = float_3
    float_3 = float_3
    dict_2 = dict(HostVars=dict_0, vars=dict_0)
    float_4 = float_2 / float_3
    float_4 = float_

# Generated at 2022-06-25 12:32:57.346088
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 899.8729
    set_0 = {float_0, float_0, float_0}
    float_1 = 293.8567
    float_2 = 892.1269
    int_0 = 6351
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    str_0 = ansible_j2_vars_0.__contains__(float_1)
    try:
        str_1 = ansible_j2_vars_0.__contains__(float_2)
        if str_1:
            int_1 = ansible_j2_vars_0[int_0]

    except KeyError:
        pass


# Generated at 2022-06-25 12:33:03.484976
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 535.5598
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)


# Generated at 2022-06-25 12:33:07.584452
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    assert len(ansible_j2_vars_0) == 1


# Generated at 2022-06-25 12:33:08.467617
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    AnsibleJ2Vars()


# Generated at 2022-06-25 12:33:15.193808
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(set_0, set_0, set_0)
    list_0 = list(ansible_j2_vars_1)
    set_0.add(list_0)
    list_0 = list(ansible_j2_vars_0)


# Generated at 2022-06-25 12:33:22.804854
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    str_0 = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:33:29.139006
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    class_0 = type(ansible_j2_vars_0)
    try:
        class_0.__iter__(ansible_j2_vars_0)
    except Exception as exception_0:
        print('EXCEPTION: {0}'.format(exception_0))


# Generated at 2022-06-25 12:33:32.496217
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 30.73
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    str_0 = 'long_line'
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:33:37.292731
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars(AnsibleJ2Vars, set())
    ansible_j2_vars_0.add_locals(dict((('ansible_ssh_host', '10.0.2.15'), ('ansible_ssh_port', '22'), ('ansible_connection', 'ssh'), ('ansible_user', 'vagrant'), ('ansible_ssh_pass', 'vagrant')),))
    str_0 = 'ansible_ssh_host'
    bool_0 = ansible_j2_vars_0.__contains__(str_0)
    assert bool_0


# Generated at 2022-06-25 12:33:43.462310
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    float_1 = -811.0
    set_1 = {float_1, float_1, float_1}
    ansible_j2_vars_1 = AnsibleJ2Vars(float_1, set_1)
    str_1 = ansible_j2_vars_1.__len__()
    str_1 = str(str_1)
    return str_1


# Generated at 2022-06-25 12:33:47.393743
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    float_0 = 744.0338
    list_0 = [set(), float_0]
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, list_0)
    #assert set([float_0, set()]) == ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:34:10.072811
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 905.0622
    dict_0 = {"0": float_0, "1": float_0, "2": float_0, "3": float_0, "4": float_0}
    float_1 = float_0
    float_1 = float_0
    float_1 = float_0
    float_1 = float_0
    float_1 = float_0
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, dict_0)

    # Call the method with invalid argument types
#     try:
#         ansible_j2_vars_0.__getitem__(dict_0)
#         assert False
#     except TypeError:
#         assert True
#     try:
#         ansible_j2_vars_0.__

# Generated at 2022-06-25 12:34:18.828536
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0) # Type: AnsibleJ2Vars
    ansible_j2_vars_1 = AnsibleJ2Vars(ansible_j2_vars_0, set_0) # Type: AnsibleJ2Vars

    # Test for __contains__ in class AnsibleJ2Vars with valid arg
    if ansible_j2_vars_1.__contains__(float_0):
        print("__contains__ test PASSED")
    else:
        print("__contains__ test FAILED")

    # Test for __contains__ in class AnsibleJ2Vars

# Generated at 2022-06-25 12:34:30.173494
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # This variables are used for test
    set_0 = set()
    list_0 = list()
    list_0.append(False)
    list_0.append(True)
    list_0.append(True)
    list_0.append(True)
    list_0.append(False)
    list_0.append(True)
    list_0.append(True)
    list_0.append(False)
    list_0.append(False)
    list_0.append(False)
    float_0 = 0.059734883722271866
    dict_0 = dict()
    dict_0["0"] = True
    dict_0["1"] = True
    dict_0["2"] = True
    dict_0["3"] = True
    dict_0["4"] = True

# Generated at 2022-06-25 12:34:36.118970
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 589.6571
    set_0 = {float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)

# Generated at 2022-06-25 12:34:42.971164
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)

    # Negative case
    try:
        ansible_j2_vars_0['']
    except KeyError:
        assert True
    else:
        assert False



# Generated at 2022-06-25 12:34:47.904617
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    ansible_j2_vars_0.__getitem__("undefined variable: %s")



# Generated at 2022-06-25 12:34:51.565708
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # FIXME: Modify the test case to make it pass
    assert False


# Generated at 2022-06-25 12:34:55.626128
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)

    ansible_j2_vars_0.__getitem__(float_0)


# Generated at 2022-06-25 12:34:58.596638
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    ansible_j2_vars_0.__contains__(float_0)
    assert True


# Generated at 2022-06-25 12:35:06.859268
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    integer_0 = 5
    str_0 = '"q\'\\'

# Generated at 2022-06-25 12:35:30.506813
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = {string___tuple__, string___tuple__, string___tuple__}
    tuple_0 = (float_0, globals(), float_0, float_0)
    tuple_1 = (string___tuple__, globals(), float_0, set_0)
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, tuple_1)
    assert ansible_j2_vars_0.__contains__(string___tuple__) == False
    ansible_j2_vars_0.__contains__(float_0)
    ansible_j2_vars_0.__contains__()


# Generated at 2022-06-25 12:35:37.410297
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    iterator_0 = ansible_j2_vars_0.__iter__()



# Generated at 2022-06-25 12:35:40.411393
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    if str(ansible_j2_vars_0.__getitem__(str_0)) != 'a':
        raise AssertionError("Incorrect behavior of __getitem__")

# Generated at 2022-06-25 12:35:45.128678
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Setup
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)

    # Invocation
    result = ansible_j2_vars_0.__iter__()

    # Verification
    assert result is not None


# Generated at 2022-06-25 12:35:51.987585
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 866.9
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, float_0, float_0)
    float_1 = float_0
    # Check that exception is raised and of correct type,
    # and that the value of the exception is correct
    with pytest.raises(KeyError) as err:
        ansible_j2_vars_0.__getitem__(float_0)
    assert err.value.args[0] == 'undefined variable: %s' % float_1


# Generated at 2022-06-25 12:35:56.127076
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:36:06.020018
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = {'t', 'q', 'q'}
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__getitem__(set_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(set_0, set_0)
    try:
        ansible_j2_vars_1.__getitem__(set_0)
    except KeyError:
        pass
    else:
        raise AssertionError('AnsibleJ2Vars', '__getitem__')
    ansible_j2_vars_2 = AnsibleJ2Vars(set_0, set_0)

# Generated at 2022-06-25 12:36:09.513519
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    string_0 = 'f8S#W]RvBhx_'
    set_0 = {'G', set_0.remove, 'G'}
    list_0 = [set_0.pop, 'G', list_0.pop, 'G']
    ansible_j2_vars_0 = AnsibleJ2Vars(list_0, list_0)


# Generated at 2022-06-25 12:36:14.560713
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    # asserts
    assert ansible_j2_vars_0.__getitem__(float_0) == float_0


# Generated at 2022-06-25 12:36:23.014300
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Initialization of a float variable
    float_0 = 744.0338
    # Initialization of a set variable
    set_0 = {float_0, float_0, float_0}

    # The value of the variable set_0 is used to initialize the variable ansible_j2_vars_0
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    # AssertionError: assert 'float_0' in ansible_j2_vars_0 failed
    assert 'float_0' in ansible_j2_vars_0
    # AssertionError: assert float_0 not in ansible_j2_vars_0 failed
    assert float_0 not in ansible_j2_vars_0


# Generated at 2022-06-25 12:37:01.093502
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 598.0
    set_0 = {float_0, float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)

    assert ansible_j2_vars_0.__getitem__() == float_0

# Generated at 2022-06-25 12:37:07.114363
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    # test with a variable
    assert ansible_j2_vars_0.__contains__('vars')
    assert not ansible_j2_vars_0.__contains__('undefined_variable')


# Generated at 2022-06-25 12:37:12.340041
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    ansible_j2_vars_0.__contains__(float_0)


# Generated at 2022-06-25 12:37:17.886852
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Test method __getitem__ of class AnsibleJ2Vars
    '''
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)

    ansible_j2_vars_0.__getitem__(1)


# Generated at 2022-06-25 12:37:18.779121
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # FIXME
    assert True


# Generated at 2022-06-25 12:37:26.101323
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    param_0 = 438
    param_0 = ansible_j2_vars_0.__getitem__(param_0)
    ansible_j2_vars_0.__contains__(param_0)
    ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:37:30.870717
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    ansible_j2_vars_0[float_0]

# Generated at 2022-06-25 12:37:40.610124
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Test case 1:
    float_0 = 744.0338
    float_1 = float(float_0)
    list_0 = [float_1, float_1, float_1]
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    # Test case 2:
    float_0 = 558.1606
    float_1 = float(float_0)
    str_0 = str(float_1)
    str_1 = str(float_1)
    list_0 = [str_1, str_1, str_1]
    set_0 = {str_0, str_0, str_0}
    ansible_j2_vars_0

# Generated at 2022-06-25 12:37:43.739031
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    ansible_j2_vars_0[float_0]



# Generated at 2022-06-25 12:37:48.452392
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    assert ansible_j2_vars_0.__contains__(744.0338)


# Generated at 2022-06-25 12:39:24.528767
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert '?' not in test_case_0()


# Generated at 2022-06-25 12:39:27.152866
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    float_0 = 744.0338
    set_0 = {float_0, float_0, float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, set_0)
    ansible_j2_vars_0_len_0 = len(ansible_j2_vars_0)
    assert ansible_j2_vars_0_len_0 == 3
