

# Generated at 2022-06-25 12:29:41.400197
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    bool_1 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_1)
    str_0 = "inventory_hostname"
    try:
        ansible_j2_vars_0.__contains__(str_0)
    except NotImplementedError:
        str_1 = "inventory_hostname"
        bool_2 = ansible_j2_vars_0.__contains__(str_1)
        assert bool_2 == False


# Generated at 2022-06-25 12:29:47.403112
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = False
    bool_1 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_1)
    temp_0 = None
    ansible_j2_vars_0.__iter__()
    temp_1 = None
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:29:51.767396
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    bool_1 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_1)
    str_0 = 'V'

    assert ansible_j2_vars_0[str_0] == None

# Test: __getitem___1

# Generated at 2022-06-25 12:29:56.340271
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    bool_1 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_1)
    ansible_j2_vars_0.__contains__()


# Generated at 2022-06-25 12:30:03.912369
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_1)
    with pytest.raises(AnsibleUndefinedVariable):
        ansible_j2_vars_0.__contains__(str_0)
    with pytest.raises(AnsibleError):
        ansible_j2_vars_0.__contains__(str_1)
    with pytest.raises(AnsibleError):
        ansible_j2_vars_0.__contains__(str_2)
    with pytest.raises(AnsibleError):
        ansible_j2_vars_0.__contains__(str_3)
    with pytest.raises(AnsibleError):
        ansible_j2_vars_0

# Generated at 2022-06-25 12:30:09.623501
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = False
    bool_1 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_1)
    assert len(ansible_j2_vars_0) == 0
    ansible_j2_vars_1 = AnsibleJ2Vars(bool_0, bool_1)
    ansible_j2_vars_1.__iter__()


# Generated at 2022-06-25 12:30:14.453519
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = False
    bool_1 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_1)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:30:17.350280
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    print("test_AnsibleJ2Vars")
    test_case_0()
    print("test_AnsibleJ2Vars: completed")

# test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:30:23.875073
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    my_str_0 = "vars"
    my_str_1 = "ansible"
    my_str_2 = "yum"
    my_str_3 = "pkg"
    ansible_j2_vars_0 = AnsibleJ2Vars(my_str_0, my_str_1)
    try:
        ansible_j2_vars_0.__getitem__(my_str_2)
    except UndefinedError as exc:
        print("Exception thrown: ", type(exc), exc.args)
    except Exception as exc:
        print("Exception thrown: ", type(exc), exc.args)

    ansible_j2_vars_0 = AnsibleJ2Vars(my_str_0, my_str_1)

# Generated at 2022-06-25 12:30:30.680335
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = False
    bool_1 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_1)
    ansible_j2_vars_0.__getitem__(str_0)
    ansible_j2_vars_0.__contains__(str_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:30:42.853788
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
  bool_0 = False
  bool_1 = bool_0
  bool_2 = bool_0
  ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
  assert ansible_j2_vars_0.__contains__(bool_0) == bool_0


# Generated at 2022-06-25 12:30:45.896349
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # get instance
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    # assert return value
    assert False


# Generated at 2022-06-25 12:30:49.207960
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        AnsibleJ2Vars.__getitem__(AnsibleJ2Vars,None)
    except AnsibleUndefinedVariable:
        assert True
    else:
        fail("AnsibleUndefinedVariable not raised")
        

# Generated at 2022-06-25 12:30:52.698806
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = bool()
    bool_1 = bool()
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__getitem__(bool_1)


# Generated at 2022-06-25 12:30:56.015946
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    str_0 = "vars"
    assert not ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:31:01.013424
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    z = {"key1": "value1", "key2": "value2"}
    ansible_j2_vars_0 = AnsibleJ2Vars(z, z, z)
    # First test to see that a value that exists in the dict is in the dict
    if True:
        pass
    # Next test to see that a value that doesn't exist in the dict is not in the dict
    elif False:
        pass
    # We expect that this test will fail
    else:
        pass


# Generated at 2022-06-25 12:31:03.617028
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    int_0 = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:31:06.312307
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    int_0 = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:31:15.947692
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    bool_0 = False
    # from importlib import reload
    # from ansible.template import Templar
    # reload(Templar)
    # class AnsibleJ2Vars(Mapping):
    #     '''
    #     Helper class to template all variable content before jinja2 sees it. This is
    #     done by hijacking the variable storage that jinja2 uses, and overriding __contains__
    #     and __getitem__ to look like a dict. Added bonus is avoiding duplicating the large
    #     hashes that inject tends to be.
    #
    #     To facilitate using builtin jinja2 things like range, globals are also handled here.
    #     '''
    #
    #     def __init__(self, templar, globals, locals=None):
    #         '''
   

# Generated at 2022-06-25 12:31:20.477963
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    bool_1 = True
    str_0 = "abc"
    bool_2 = ansible_j2_vars_0.__contains__(str_0)
    assert True == bool_2


# Generated at 2022-06-25 12:31:25.088003
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ans_j2vars = AnsibleJ2Vars(templar=None, globals=None, locals=None)
    assert test_case_0()

# Generated at 2022-06-25 12:31:27.808973
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """Check case for False."""
    assert test_case_0() == False, "test_case_0()"


# Generated at 2022-06-25 12:31:37.819541
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Create an instance of AnsibleJ2Vars
    #
    # The following call to the AnsibleJ2Vars constructor is commented out
    # because we don't have any of the arguments to pass to it.  We could
    # use dummy variables, but that might trigger other tests.
    #
    #ansiblej2vars_obj = AnsibleJ2Vars(templar, globals, locals=locals)

    # Attempt to invoke the __contains__ method
    try:
        #ansiblej2vars_obj.__contains__(k)
        assert False # The following line is reachable if the test failed
        assert True # The following line is reachable if the test passed
    except:
        # An exception was raised during invocation of the __contains__ method
        assert False # The following line is reachable if the

# Generated at 2022-06-25 12:31:41.143898
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    obj = AnsibleJ2Vars()

    # In case of exception being raised during execution of the method being tested,
    # this method must return False here. Otherwise True will be returned by default.
    return bool_0


# Generated at 2022-06-25 12:31:44.100059
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars("templar=templar_0, globals=globals_0")
    ansible_j2_vars_0.__len__()
    return bool_0




# Generated at 2022-06-25 12:31:49.467458
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:31:53.054335
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = True
    try:
        ansible_jvars_0 = AnsibleJ2Vars()
        ansible_jvars_0.__iter__()
    except Exception as e_0:
        bool_0 = False
    return bool_0


# Generated at 2022-06-25 12:31:56.466320
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    try:
        test_case_0()
    except:
        print("Exception in testcase_AnsibleJ2Vars__contains__0()")
        raise


# Generated at 2022-06-25 12:32:05.848835
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case = 0

    if test_case == 0:
        varname = 'myvar'
        if True:
            pass

    if False:
        pass
    if False:
        pass
    if False:
        pass
    if False:
        pass
    if False:
        pass
    if False:
        pass
    if False:
        pass
    if False:
        pass
    if False:
        pass
    if False:
        pass
    if False:
        pass
    if False:
        pass
    if False:
        pass
    if False:
        pass



# Generated at 2022-06-25 12:32:06.390065
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert True

# Generated at 2022-06-25 12:32:17.787759
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test case with no vars defined
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    with pytest.raises(KeyError):
        ansible_j2_vars_0['foo']

    # Test case with one var defined
    bool_1 = True
    ansible_j2_vars_1 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_1['bar'] = bool_1
    assert ansible_j2_vars_1['bar'] == bool_1


# Generated at 2022-06-25 12:32:19.235792
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    test_case_0()


# Generated at 2022-06-25 12:32:22.733224
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Aliases
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    bool_1 = ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:32:26.748804
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    # AnsibleJ2Vars.__contains__(varname) implementation
    ansible_j2_vars_0.__contains__(bool_0)


# Generated at 2022-06-25 12:32:29.845165
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)


# Generated at 2022-06-25 12:32:30.889811
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Setup
    test_case_0()

    # Teardown
    pass


# Generated at 2022-06-25 12:32:37.133259
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    print("test_AnsibleJ2Vars___getitem__")
    locals_0 = {"test_key_0": "test_value_0"}
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0, locals=locals_0)
    ansible_j2_vars_0.__getitem__("test_key_0")
    ansible_j2_vars_0.__getitem__("ansible_facts")
    ansible_j2_vars_0.__getitem__("test_key_1")
    ansible_j2_vars_0.__getitem__("ansible_facts")


# Generated at 2022-06-25 12:32:40.534615
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    try:
        len(ansible_j2_vars_0)
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 12:32:44.171953
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    #def __iter__(self):
    #    keys = set()
    #    keys.update(self._templar.available_variables, self._locals, self._globals)
    #    return iter(keys)

    test_case_0()


# Generated at 2022-06-25 12:32:50.228668
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    try:
        str_0 = str(ansible_j2_vars_0.__iter__(bool_0, bool_0))
    except Exception as e_0:
        raise
    return str_0


# Generated at 2022-06-25 12:32:55.201081
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    result = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:32:59.005148
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:33:00.329965
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 12:33:04.222696
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_obj = AnsibleJ2Vars()
    arg_0 = 'foo'
    ret_obj = ansible_j2_vars_obj.__contains__(arg_0)
    assert ret_obj == False


# Generated at 2022-06-25 12:33:06.299534
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = False
    object_AnsibleJ2Vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    int_0 = len(object_AnsibleJ2Vars_0)


# Generated at 2022-06-25 12:33:11.487727
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0._templar.available_variables

    # should return True
    assert ansible_j2_vars_0.__contains__('foo')

    # should return False
    assert not ansible_j2_vars_0.__contains__('bar')


# Generated at 2022-06-25 12:33:14.994571
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    # Verify the expected behavior
    assert isinstance(True, bool)


# Generated at 2022-06-25 12:33:22.805287
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    # Exception case
    try:
        ansible_j2_vars_0.__getitem__(bool_0)
    except TypeError:
        pass


# Generated at 2022-06-25 12:33:25.385313
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        assert False
    else:
        assert True




# Generated at 2022-06-25 12:33:29.029199
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    # AssertionError: False != True : Expected '__contains__' to return 'True' for dict key 'bool_0'



# Generated at 2022-06-25 12:33:42.547026
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    assert ansible_j2_vars_0._templar is bool_0
    assert ansible_j2_vars_0._globals is bool_0
    assert ansible_j2_vars_0._locals is not None
    assert len(ansible_j2_vars_0._locals) == 0


# Generated at 2022-06-25 12:33:46.033898
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    test_case_0()

# vim: set expandtab:

# Generated at 2022-06-25 12:33:48.083990
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__getitem__("")


# Generated at 2022-06-25 12:33:51.088372
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # test for AnsibleJ2Vars.__getitem__('foo')
    # assert ansible_j2_vars_0.__getitem__('foo')
    raise Exception('Test not implemented')


# Generated at 2022-06-25 12:33:54.542206
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Setup mock object
    instance = AnsibleJ2Vars(bool_0, bool_0)

    # Setup assertion
    # For example: assert isinstance(exp_result, type(ans))
    assert callable(getattr(instance, "__contains__"))



# Generated at 2022-06-25 12:33:57.434288
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = True
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__getitem__('foo')


# Generated at 2022-06-25 12:33:59.780466
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__getitem__(bool_0)


# Generated at 2022-06-25 12:34:10.298887
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    while 0:
        str_0 = None
        print(ansible_j2_vars_0.__getitem__(str_0))

# unit tests.
if __name__ == '__main__':
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), 'lib'))
    from ansible.module_utils import basic
    from ansible.module_utils.six.moves import builtins
    basic._ANSIBLE_ARGS = (True, builtins, False)
    test_case_0()
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:34:13.122991
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__getitem__('key')

# Generated at 2022-06-25 12:34:20.659280
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 0
    bool_0 = False
    bool_1 = True
    int_1 = 0
    int_2 = 0
    int_3 = 0
    int_4 = 0
    int_5 = 0
    int_6 = 0
    int_7 = 0
    int_8 = 0
    str_0 = ''
    str_1 = 'do not confuse'

    # Constructor test
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, bool_0)
    assert type(ansible_j2_vars_0) == AnsibleJ2Vars

    # Constructor test
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, bool_1)

# Generated at 2022-06-25 12:34:33.965505
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:34:34.512260
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass



# Generated at 2022-06-25 12:34:40.071728
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0, bool_0)
    str_0 = (ansible_j2_vars_0.__getitem__("test_case_0"))


#if __name__ == "__main__":
#  test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:34:41.370459
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # PASS
    test_case_0()


# Generated at 2022-06-25 12:34:50.169973
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    assert(ansible_j2_vars_0.add_locals(bool_0) == ansible_j2_vars_0)
    assert(ansible_j2_vars_0.add_locals(bool_0).add_locals(bool_0) == ansible_j2_vars_0.add_locals(bool_0))
    assert(ansible_j2_vars_0.add_locals(bool_0) == ansible_j2_vars_0.add_locals(bool_0))
    assert(ansible_j2_vars_0 == ansible_j2_vars_0)

# Generated at 2022-06-25 12:34:53.142762
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__contains__(bool_0)


# Generated at 2022-06-25 12:34:55.910077
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__getitem__('3')

# Generated at 2022-06-25 12:34:58.762895
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class AnsibleJ2Vars:
        def __init__(self, templar, globals, locals=None):
            pass

    with pytest.raises(Exception):
        ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
        ansible_j2_vars_0.__getitem__(bool_0)

# Generated at 2022-06-25 12:35:02.626086
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__contains__()


# Generated at 2022-06-25 12:35:05.597327
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    # Call method __iter__ of class AnsibleJ2Vars
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:35:35.091614
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # The following call to AnsibleJ2Vars_0 instantiates an object of AnsibleJ2Vars
    ansible_j2_vars_0 = test_case_0()
    # The following call to __len__ of AnsibleJ2Vars_0 returns the length of the said object
    ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:35:37.642126
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__iter__()



# Generated at 2022-06-25 12:35:40.854106
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    exception = None
    try:
        ansible_j2_vars_0[bool_0]
    except Exception as e:
        exception = e
    assert exception


# Generated at 2022-06-25 12:35:43.297705
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    str_0 = 'hostvars'
    result = ansible_j2_vars_0.__getitem__(str_0)
    return code


# Generated at 2022-06-25 12:35:47.358562
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    try:
        ansible_j2_vars_0.__contains__("l_a")
    except KeyError as e:
        print("KeyError - Argument: {}".format(e.args[0]))


# Generated at 2022-06-25 12:35:51.893515
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    # verify the variable ansible_j2_vars_0.__contains__(20) exists
    try:
        assert bool_0
    except:
        pass


# Generated at 2022-06-25 12:35:56.037168
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    assert not ansible_j2_vars_0.__contains__("j2")
    assert not ansible_j2_vars_0.__contains__("*")


# Generated at 2022-06-25 12:36:03.184250
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Example from code comment
    result = AnsibleJ2Vars(None, None).__contains__('ansible_all_ipv4_addresses')
    assert result == True
    # Example from code comment
    result = AnsibleJ2Vars(None, None).__contains__('foo')
    assert result == False
    # User provided example test
    result = AnsibleJ2Vars(None, None).__contains__(None)
    assert result == KeyError


# Generated at 2022-06-25 12:36:07.875556
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    str_0 = 'Yw[GJUV]$R'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0)
    # Calling the method __getitem__ of class AnsibleJ2Vars
    try:
        ansible_j2_vars_0[bool_0]
        ansible_j2_vars_0[bool_0]
    except:
        pass


# Generated at 2022-06-25 12:36:10.255240
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # ansible_j2_vars__0 = AnsibleJ2Vars(bool_0, bool_0)
    # result = ansible_j2_vars__0.__iter__()
    pass

# Generated at 2022-06-25 12:37:01.188877
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    bool_1 = False
    try:
        ansible_j2_vars_0.__getitem__(bool_1)
    except KeyError as e:
        print(str(e))

# Generated at 2022-06-25 12:37:04.692842
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    assert isinstance(ansible_j2_vars_0.__iter__(), iter)


# Generated at 2022-06-25 12:37:10.433379
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    set_1 = set()
    set_0.update(set_1)
    ansible_j2_vars_0 = AnsibleJ2Vars(_templar=set_0, _globals=set_1, _locals=set_0)
    set_0 = ansible_j2_vars_0.__iter__()
    return set_0


# Generated at 2022-06-25 12:37:14.504240
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_1 = True
    bool_0 = False
    ansible_j2_vars_1 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_1.__contains__(bool_1)


# Generated at 2022-06-25 12:37:17.626025
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:37:18.196700
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False

# Generated at 2022-06-25 12:37:24.330949
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)
    str_0 = ""
    bool_0 = False
    bool_1 = ansible_j2_vars_0.__contains__(str_0)
    assert bool_0 == bool_1, 'Return value mismatch. Expected : {0}, got: {1}'.format(bool_0, bool_1)


# Generated at 2022-06-25 12:37:31.795244
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    template = dict()
    template['a'] = 'b'
    local_vars = dict()
    local_vars['b'] = 'c'
    globals_ = dict()
    globals_['c'] = 'd'
    name = 'a'
    value = 'b'
    ansible_j2_vars_0 = AnsibleJ2Vars(template, local_vars, globals_)
    value = ansible_j2_vars_0.__getitem__(name)
    assert value == 'b'


# Generated at 2022-06-25 12:37:37.503958
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    result_0 = ansible_j2_vars_0.__iter__()
    # assert result_0 == ???
    if result_0 != True:
        raise Exception( "AssertionError: result_0 == True" )


# Generated at 2022-06-25 12:37:39.421582
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    ansible_j2_vars_0.__getitem__("<string>")


# Generated at 2022-06-25 12:39:21.768367
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    bool_1 = bool_0
    bool_2 = bool_1
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_1, bool_0)
    ansible_j2_vars_0.__getitem__(bool_2)


# Generated at 2022-06-25 12:39:23.759143
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    int_0 = int(ansible_j2_vars_0.__len__())


# Generated at 2022-06-25 12:39:26.096794
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    bool_1 = bool_0
    str_0 = ''
    bool_1 = ansible_j2_vars_0.__contains__(str_0)
    assert bool_1


# Generated at 2022-06-25 12:39:28.983760
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bool_0 = False
    ansible_j2_vars_0 = AnsibleJ2Vars(bool_0, bool_0)
    str_0 = "vars"
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:39:34.831998
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.hostvars import HostVars
    import jinja2

    #from ansible.playbook.helpers import load_list_of_blocks
    #from ansible.template import Templar

    #from ansible.playbook.task import Task
    #from ansible.playbook.role.include import RoleInclude
    #from ansible.playbook.block import Block
    #from ansible.playbook.handler import Handler
    #from ansible.playbook.task_include import TaskInclude
    #from ansible.playbook.play_context import PlayContext
    #from ansible.utils.vars import combine_vars
    #from ansible.playbook.play import Play
    #from ansible.inventory.host import Host
    #from ansible.inventory.group import Group
    #from ans