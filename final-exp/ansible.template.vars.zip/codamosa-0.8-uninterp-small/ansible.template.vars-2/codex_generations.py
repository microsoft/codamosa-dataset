

# Generated at 2022-06-25 12:29:41.910034
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, var_0)
    assert ansible_j2_vars_0.__getitem__(ansible_j2_vars_0, var_0) == b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'



# Generated at 2022-06-25 12:29:48.508394
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:29:55.399415
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    assert ansible_j2_vars_0.__len__() == 0


# Generated at 2022-06-25 12:30:03.395196
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    var_0 = ansible_j2_vars_0.__getitem__(ansible_j2_vars_0)



# Generated at 2022-06-25 12:30:11.860965
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Initialize a Templar() object.
    templar = Templar()
    # Initialize a dictionary with various keys and values.
    dictionary = {'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_2'}
    # Initialize an AnsibleJ2Vars object with templar and dictionary.
    ansible_j2_vars_0 = AnsibleJ2Vars(templar, dictionary)
    # Check if ansible_j2_vars_0 contains key_1 from dictionary.
    assert_true(ansible_j2_vars_0.__contains__('key_1'))
    # Check if ansible_j2_vars_0 contains key_3.

# Generated at 2022-06-25 12:30:18.337527
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    var_0 = ansible_j2_vars_0.__contains__(ansible_j2_vars_0)


# Generated at 2022-06-25 12:30:31.278257
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    bytes_1 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_1 = AnsibleJ2Vars(bytes_1, bytes_1)
    ansible_j2_vars_1.__contains__(ansible_j2_vars_1)
    ansible_j2_vars_1.__iter__(ansible_j2_vars_1)
    ansible_j2_vars_1.__iter__(ansible_j2_vars_1)

# Generated at 2022-06-25 12:30:39.321880
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_1 = AnsibleJ2Vars(bytes_0, bytes_0)
    bytes_1 = b'\xc1\x0c\xef\x8c\x12\xb1w\n\xef\x8e\x1dj\x16\x9e\x8d\x0b\xaf\xf2'
    bytes_2 = b'\x9f\x9e\xb6\x08___\xa4\xe2Q\x1b\x1e\xa7\xa4\x9c\x91\x11\x90'

# Generated at 2022-06-25 12:30:40.522112
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()

# Test all methods

# Generated at 2022-06-25 12:30:43.068124
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # args: Templar(), dict(), dict()
    test_case_0()

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:30:47.179071
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass



# Generated at 2022-06-25 12:30:51.695327
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = Templar()
    globals = dict()
    locals = None
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    key = 'key_6'
    result = ansible_j2vars.__contains__(key)
    assert result is False


# Generated at 2022-06-25 12:30:55.421770
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars___contains___obj = AnsibleJ2Vars()
    assert ansible_j2_vars___contains___obj.__contains__(bytes_0) == False
    assert ansible_j2_vars___contains___obj.__contains__(bytes_1) == False


# Generated at 2022-06-25 12:30:57.839090
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    obj_0 = AnsibleJ2Vars(bytes_0, bytes_1)
    int_0 = len(obj_0)
    assert int_0 == 51


# Generated at 2022-06-25 12:31:04.545701
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy


# Generated at 2022-06-25 12:31:10.811969
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.module_utils.common._collections_compat import Mapping
    path_0 = '/tmp/ansible_test_module_utils_common_collections_compat_test_AnsibleJ2Vars/test_AnsibleJ2Vars___contains__/test_case_0/test_0'
    args_0= load_json(path_0 + '.in.json')
    res_0 = test_case_0(args_0)
    dump_json(res_0, path_0 + '.out.json')
    dump_yaml(res_0, path_0 + '.out.yaml')
    assert res_0 == load_json(path_0 + '.expected.json')
    assert res_0 == load_yaml(path_0 + '.expected.yaml')


################################

# Generated at 2022-06-25 12:31:13.391521
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert globals()['AnsibleJ2Vars'].__getitem__(bytes_0) == bytes_1


# Generated at 2022-06-25 12:31:19.569761
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Generate test data
    templar_0 = mock.MagicMock(spec=Templar)
    globals_0 = {}
    locals_0 = None
    ansiblej2vars_0 = AnsibleJ2Vars(templar_0, globals_0, locals=locals_0)
    # Perform the test
    result = ansiblej2vars_0.__iter__()
    # Verify the results
    assert result == NotImplemented


# Generated at 2022-06-25 12:31:24.483811
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # No-arguments constructor call
    obj = AnsibleJ2Vars()
    # assert 'obj' is of class 'AnsibleJ2Vars'
    assert isinstance(obj, AnsibleJ2Vars)
    # assert 'obj' is of type AnsibleJ2Vars
    assert type(obj) is AnsibleJ2Vars
    # Assert that 'obj' is of type Mapping
    assert isinstance(obj, Mapping)


# Generated at 2022-06-25 12:31:25.752228
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 12:31:30.028270
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()


# Generated at 2022-06-25 12:31:36.463991
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    str_0 = ansible_j2_vars_0[bytes_0]
    assert str_0 is None


# Generated at 2022-06-25 12:31:40.786274
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x02\x00\x00\x00\x01'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    b_0 = ansible_j2_vars_0.__contains__(bytes_0)


# Generated at 2022-06-25 12:31:45.096167
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:31:50.605834
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    assert(str(ansible_j2_vars_0) == "AnsibleJ2Vars")
    str_0 = ansible_j2_vars_0["undefined variable: %s"]
    str_1 = ansible_j2_vars_0["undefined variable: %s"]
    str_2 = ansible_j2_vars_0["undefined variable: %s"]
    str_3 = ansible_j2_v

# Generated at 2022-06-25 12:31:53.263813
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    int_0 = ansible_j2_vars_0.__len__()
    assert int_0 == 2


# Generated at 2022-06-25 12:32:04.677928
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    globals_0 = dict()
    locals_0 = dict()
    ansible_j2_vars_0 = AnsibleJ2Vars(globals_0, locals_0)
    str_0 = str(ansible_j2_vars_0)
    length_0 = len(ansible_j2_vars_0)
    str_1 = str(ansible_j2_vars_0)
    length_1 = len(ansible_j2_vars_0)
    str_2 = str(ansible_j2_vars_0)
    length_2 = len(ansible_j2_vars_0)
    str_3 = str(ansible_j2_vars_0)
    length_3 = len(ansible_j2_vars_0)


# Generated at 2022-06-25 12:32:05.537189
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    test_case_0()

# Generated at 2022-06-25 12:32:09.450435
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # call the function
    try:
        assert test_case_0()
    except Exception as exc:
        print('Exception: ' + str(exc) + '\n')
        raise Exception

test_case_1 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
test_case_2 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'


# Generated at 2022-06-25 12:32:19.153466
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:32:24.137291
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    with pytest.raises(AnsibleUndefinedVariable):
        test_case_0()


# Generated at 2022-06-25 12:32:28.457921
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    ansible_j2_vars_0.__contains__()


# Generated at 2022-06-25 12:32:32.360480
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'A\xcf\x16\x1d\xdf\xc6\x81\x1f\x8b\xdb\x9d\xe5U6\x88\xc5\xf2\xab\x95'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    varname_0 = None
    assert (varname_0 in ansible_j2_vars_0)



# Generated at 2022-06-25 12:32:37.082590
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    # asserts that the length of AnsibleJ2Vars is equal to 0
    assert 0 == len(ansible_j2_vars_0)


# Generated at 2022-06-25 12:32:37.971444
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:32:39.115435
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    if test_case_0():
        assert False


# Generated at 2022-06-25 12:32:48.872682
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Initialize test values and expected results
    bytes_05xe210o88a1ce22af811e1e8184ac4b0db_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    bytes_05xe210o88a1ce22af811e1e8184ac4b0db_1 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    bytes_05xe210o88a1ce22af811e1e8184ac4b

# Generated at 2022-06-25 12:32:55.510836
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    ansible_j2_vars_0.__iter__()



# Generated at 2022-06-25 12:33:04.862204
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    bytes_1 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    assert ansible_j2_vars_0[bytes_1] == bytes_1

# Generated at 2022-06-25 12:33:14.709225
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    str_0 = ansible_j2_vars_0.__getitem__('foo')
    str_1 = ansible_j2_vars_0.__getitem__('bar')
    str_2 = ansible_j2_vars_0.__getitem__('foo')
    str_3 = ansible_j2_vars_0.__getitem__('bar')
    str_4 = ansible_j2_vars_0

# Generated at 2022-06-25 12:33:29.140394
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    string_0 = '\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 12:33:29.839830
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:33:34.544440
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    # Execute the method __len__ of class AnsibleJ2Vars with the arguments provided
    # Use assertEqual to verify the result
    assertEqual(ansible_j2_vars_0.__len__(), 0)



# Generated at 2022-06-25 12:33:39.592867
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:33:44.552073
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    try:
        ansible_j2_vars_0.__getitem__('varname')
        raise Exception("Failed to raise exception when accessing undefined variable")
    except KeyError as e:
        if "'varname'" not in str(e):
            raise Exception("Failed to raise correct exception when accessing undefined variable")

# Generated at 2022-06-25 12:33:53.948026
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    bytes_1 = b'\xef\x02\xad\x05\x03L\xe8\x10HV\x05\x91\xa7\x8c\x1e\x0f\x81\x04\x14Q&\x0f\x9d\x8b'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_1)
    ansible_j2_vars_1 = AnsibleJ2Vars

# Generated at 2022-06-25 12:33:58.995252
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    assert not (ansible_j2_vars_0.__contains__(bytes_0))


# Generated at 2022-06-25 12:34:06.769400
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)

    try:
        ansible_j2_vars_0.__contains__(bytes_0)
    except Exception:
        pass



# Generated at 2022-06-25 12:34:11.490459
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    bool_0 = ansible_j2_vars_0.__contains__(bytes_0)
    assert bool_0
    return


# Generated at 2022-06-25 12:34:16.760960
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars(b'\x06\x00\x00\x00\x01\x00\x00\x00', b'\x06\x00\x00\x00\x01\x00\x00\x00')
    str_0 = ansible_j2_vars_0.__contains__('y')
    print(str_0)


# Generated at 2022-06-25 12:34:36.121193
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test case parameters
    varname = b'\\\xcf\x10\xe4\x8d~\x9f\x00\x9f\xcc\x8b\x05\xe0\xf1\xd7b\x1e'

    # Test code
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    result = ansible_j2_vars_0.__contains__(varname)


# Generated at 2022-06-25 12:34:44.719583
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    try:
        ansible_j2_vars_0.__contains__()
    except TypeError as e:
        print(e)


# Generated at 2022-06-25 12:34:50.801682
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    try:
        ansible_j2_vars_0['hostvars']
    except KeyError as error:
        print(error)


# Generated at 2022-06-25 12:34:56.416346
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    int_0 = ansible_j2_vars_0.__len__()
    assert int_0 == 0


# Generated at 2022-06-25 12:35:05.443215
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    int_0 = -29382
    int_1 = -29437
    int_2 = -28884
    int_3 = -29038
    str_0 = ansible_j2_vars_0[int_0]
    str_2 = ansible_j2_vars_0[int_1]
    str_4 = ansible_j2_vars_0[int_2]
    str_6 = ansible_j2_v

# Generated at 2022-06-25 12:35:11.617249
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    assert 0 == ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:35:12.406492
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    test_case_0()


# Generated at 2022-06-25 12:35:13.600931
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # run unit test
    #test_case_0()

    pass


# Generated at 2022-06-25 12:35:18.630311
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    host = 'ip-192-168-0-3'
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    ansible_j2_vars_0.__contains__(host)


# Generated at 2022-06-25 12:35:26.432200
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    int_0, bool_0 = (bytes_0, ansible_j2_vars_0)
    assert bool_0 == ansible_j2_vars_0.__contains__(bytes_0)


# Generated at 2022-06-25 12:35:42.317088
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:35:47.599339
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    ansible_j2_vars_1 = ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:35:57.307262
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    print('Testing method AnsibleJ2Vars.__contains__')

    bytes_0 = b'\t\x12\x0b\xaf\x1c\x03\x84\xe6\xa8\x12\xa2\x13\xf7\xd8\x83\xf1\xfe\xa0\xfc\x8c\x9d\xa2}'
    bytes_1 = b'\x1b\xca\xa2\xe3\x9c\xbc\xb7\xbc\xd8\x0b\xda\x7f\x1f\x9c\xdb\xd5)\x15\xb5\x88\xde\xcd'

# Generated at 2022-06-25 12:35:59.145749
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test case #0
    test_case_0()


# Generated at 2022-06-25 12:36:06.168704
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    # FIXME should be InvocationError
    with pytest.raises(KeyError, match=".*'undefined variable: .+'"):
        ansible_j2_vars_0.__getitem__(bytes_0)


# Generated at 2022-06-25 12:36:07.272264
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    assert __iter__(test_case_0) == None


# Generated at 2022-06-25 12:36:16.104412
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)

# Generated at 2022-06-25 12:36:17.303388
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test case with no arguements
    test_case_0()


# Generated at 2022-06-25 12:36:19.291344
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)


# Generated at 2022-06-25 12:36:24.505472
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    str_0 = ansible_j2_vars_0[errors]
    str_1 = ansible_j2_vars_0[errors]


# Generated at 2022-06-25 12:37:02.485527
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    templar = Templar()
    globals = {'myvar': 123}
    locals = {'l_var': 345 }
    obj = AnsibleJ2Vars(templar, globals, locals)

    # _templar should be an instance of Templar
    assert isinstance(obj._templar, Templar)
    # _globals should be a dictionary
    assert isinstance(obj._globals, dict)
    # _locals should be a dictionary
    assert isinstance(obj._locals, dict)

    # test __contains__ method
    # 1) test with a valid global variable
    assert 'myvar' in obj
    # 2) test with a valid local variable
    assert 'var' in obj

# Generated at 2022-06-25 12:37:03.373577
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass


# Generated at 2022-06-25 12:37:14.147735
# Unit test for method __contains__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:37:20.955034
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
        ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
        ansible_j2_vars_1 = ansible_j2_vars_0.__getitem__(bytes_0)
    except AnsibleError:
        pass
    except Exception:
        pass


# Generated at 2022-06-25 12:37:30.870662
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = (
        b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    )
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)

    with pytest.raises(KeyError) as excinfo:
        # __getitem__ raises KeyError with message: undefined variable: foo
        ansible_j2_vars_0.__getitem__('foo')
    assert excinfo.value.args == ('undefined variable: foo',)


# Generated at 2022-06-25 12:37:34.949847
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    assert len(ansible_j2_vars_0) == 1


# Generated at 2022-06-25 12:37:36.495022
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    result = AnsibleJ2Vars.__iter__()
    assert isinstance(result, Iterator)


# Generated at 2022-06-25 12:37:41.537832
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    result = ansible_j2_vars_0.__iter__()
    assert result is not None


# Generated at 2022-06-25 12:37:43.914741
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()

if __name__ == '__main__':
    test_AnsibleJ2Vars___getitem__()
    print("All tests passed")

# Generated at 2022-06-25 12:37:54.453736
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    test_case_0()
    f = AnsibleJ2Vars.__iter__
    ansible_j2_vars_0 = AnsibleJ2Vars(dict(), dict())
    ansible_j2_vars_1 = AnsibleJ2Vars(dict(), dict())
    # The method call to __iter__ of class AnsibleJ2Vars is not usable for testing.
    # The method call to __iter__ of class AnsibleJ2Vars is not usable for testing.
    # The method call to __iter__ of class AnsibleJ2Vars is not usable for testing.
    # The method call to __iter__ of class AnsibleJ2Vars is not usable for testing.
    # The method call to __iter__ of class AnsibleJ2Vars is not usable for testing.


# Generated at 2022-06-25 12:39:00.814487
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    var_1 = ansible_j2_vars_0.__contains__(b'\x10')
    assert var_1 == False
    var_2 = ansible_j2_vars_0.__contains__(b'\xe5\xa9\x9f')
    assert var_2 == False
    var_3 = ansible_j2_vars_0.__contains__(b'\n')
    assert var_3

# Generated at 2022-06-25 12:39:08.780159
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    bytes_1 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    ansible_j2_vars_1 = ansible_j2_vars_0[bytes_0]

# Generated at 2022-06-25 12:39:16.834953
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)

    # Test with a valid key
    assert ansible_j2_vars_0.__contains__(bytes_0) == True

    # Test with an invalid key
    assert ansible_j2_vars_0.__contains__(b"invalid") == False


# Generated at 2022-06-25 12:39:21.320600
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:39:25.152968
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    assert ansible_j2_vars_0
    ansible_j2_vars_0.__getitem__(bytes_0)


# Generated at 2022-06-25 12:39:30.760380
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x05/\xe2\x10o\x88\xa1\xce2\xaf\x81\x1e\x1e\x81\x84*\xc4\xb0\xdb-'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, bytes_0)
    value = ansible_j2_vars_0.__contains__(bytes_0)
    if value:
        raise Exception("__contains__ of class AnsibleJ2Vars failed!")
