

# Generated at 2022-06-25 12:29:45.584328
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 4246.297
    set_0 = {float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, float_0)


# Generated at 2022-06-25 12:29:46.481093
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert True


# Generated at 2022-06-25 12:29:51.196501
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    float_0 = 4246.297
    set_0 = {float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, float_0)
    ansible_j2_vars_0.__iter__()


test_case_0()
test_AnsibleJ2Vars___iter__()

# Generated at 2022-06-25 12:30:01.515910
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = float('.16')
    str_0 = str('\t>&xWO}r{vbT]YC#7\u0015^\x7f')
    bool_0 = bool(False)
    int_0 = int('-5')
    str_1 = str('J[D\x1fV\tvn2xZ\x7fmu\x5b6a=3')

    # Test with successor
    ansible_j2_vars_0 = AnsibleJ2Vars({str_0: bool_0, int_0: bool_0, bool_0: bool_0}, {str_0: int_0})
    assert bool_0 is not ansible_j2_vars_0.__contains__(str_1)

    # Test with void return
    ans

# Generated at 2022-06-25 12:30:04.761851
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 4246.297
    set_0 = {float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, float_0)
    ansible_j2_vars_0[float_0]


# Generated at 2022-06-25 12:30:09.044911
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 4246.297
    set_0 = {float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, float_0)
    # Return the value of a variable.
    value = ansible_j2_vars_0.__getitem__("foo")


# Generated at 2022-06-25 12:30:14.886978
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    float_0 = 8799.15
    set_0 = {float_0}
    list_0 = [ float_0 ]
    tuple_0 = ( list_0, set_0, float_0 )
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, float_0)
    float_1 = 7556.81
    ansible_j2_vars_0 = AnsibleJ2Vars(float_1, list_0)
    float_2 = 8292.56
    ansible_j2_vars_1 = AnsibleJ2Vars(float_2, float_1, list_0)
    ansible_j2_vars_2 = AnsibleJ2Vars(float_2, list_0, tuple_0)

# Generated at 2022-06-25 12:30:22.791525
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    def template(set_0, float_0):
        float_2 = 6347.26
        float_3 = 8201.407
        float_4 = 3.1033
        float_1 = 6622.234
        ansible_j2_vars_0 = AnsibleJ2Vars(set_0, float_0)
        set_1 = set()
        # FIXME: each parenthesized expression is a nested call
        #   provided to facilitate future evaluation of this method
        # (ansible_j2_vars_0.__contains__(float_0))
        # (ansible_j2_vars_0.__contains__(float_1))
        # (ansible_j2_vars_0.__contains__(float_2))
        # (ansible_j2_vars

# Generated at 2022-06-25 12:30:24.964999
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert not ansible_j2_vars_0.__contains__({})


# Generated at 2022-06-25 12:30:35.216108
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {str_0: float_0 for str_0, float_0 in dict_0.items()}
    dict_0 = {str_0: float_0 for str_0, float_0 in dict_0.items()}
    float_0 = 4246.297
    float_1 = -17.697
    float_1 = float_0 / float_0
    dict_3 = {str_0: float_0 for str_0, float_0 in dict_0.items()}
    dict_3 = {str_0: float_0 for str_0, float_0 in dict_0.items()}
    dict_1 = {str_0: float_0 for str_0, float_0 in dict_0.items()}

# Generated at 2022-06-25 12:30:40.888251
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, dict_0)

    ansible_j2_vars_0.__getitem__(set_0)


# Generated at 2022-06-25 12:30:45.111151
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    dict_0 = dict()
    dict_0[42] = None
    dict_0[43] = 43
    dict_0[44] = 44
    test_case_0()
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)


# Generated at 2022-06-25 12:30:48.903605
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 4246.297
    set_0 = {float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, float_0)
    ansible_j2_vars_0.__getitem__(set_0)

# Generated at 2022-06-25 12:30:55.150577
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 4246.297
    set_0 = {float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, float_0)
    try:
        ansible_j2_vars_0[float_0]
    except KeyError as exception_0:
        # Verify the error
        assert str(exception_0) == 'undefined variable: 4246.297'
    # clean up
    del ansible_j2_vars_0


# Generated at 2022-06-25 12:30:57.581453
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_0 = 4246.297
    set_0 = {float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, float_0)
    ansible_j2_vars_0.__contains__(float_0)


# Generated at 2022-06-25 12:31:01.658291
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 4246.297
    set_0 = {float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, float_0)
    # ValueError: could not convert string to float: abc
    ansible_j2_vars_0.__getitem__('abc')


# Generated at 2022-06-25 12:31:08.334766
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 4246.297
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0)
    float_1 = -145699.78
    ansible_j2_vars_0.__getitem__(float_1)
    ansible_j2_vars_0.get(float_0)
    str_0 = "Id"
    ansible_j2_vars_0.__getitem__(str_0)
    ansible_j2_vars_0.get(str_0)
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:31:16.313072
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    float_2 = 7174.48
    set_2 = {float_2}
    ansible_j2_vars_1 = AnsibleJ2Vars(set_2, float_2)
    # Test of method __contains__
    # _result = ansible_j2_vars_1.__contains__(ansible_j2_vars_1)
    _result = (ansible_j2_vars_1.__contains__(ansible_j2_vars_1) == ansible_j2_vars_1)
    assert _result, 'Method __contains__ failed'


# Generated at 2022-06-25 12:31:20.131274
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 4246.297
    set_0 = {float_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, float_0)
    ansible_j2_vars_0.__getitem__(float_0)


# Generated at 2022-06-25 12:31:24.093476
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Setup
    ansible_j2_vars_0 = AnsibleJ2Vars("", {}, {
        'a': 'b'
    })
    # Exercise/Verify
    assert ansible_j2_vars_0.__contains__('a')
    assert not ansible_j2_vars_0.__contains__('b')


# Generated at 2022-06-25 12:31:37.436637
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test case 0
    str_0 = 'jz_\rO'
    str_2 = 'jz_\rO'
    dict_0 = {str_0: str_2}
    str_8 = 'jz_\rO'
    dict_1 = {str_8: str_8}
    str_11 = 'jz_\rO'
    dict_2 = {str_11: str_11}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1, dict_2)
    str_19 = 'jz_\rO'
    assert (str_19 in ansible_j2_vars_0)
    # Test case 1
    str_0 = 'jz_\rO'

# Generated at 2022-06-25 12:31:42.613347
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '?\x11\x02\x0f\x1f\x00\x1d\x1c\n'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:31:45.756250
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()


# Generated at 2022-06-25 12:31:52.003779
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__('jz_\rO')

test_case_0()
test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:31:57.196697
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'zZO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:32:04.875717
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'eC`\x0bY\x1bR\x16'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    str_1 = 'eC`\x0bY\x1bR\x16'
    assert ansible_j2_vars_0.__getitem__(str_1) == str_1

# Generated at 2022-06-25 12:32:11.061077
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '&~\x1d'
    list_0 = ['&~\x1d', '&~\x1d']
    ansible_j2_vars_0 = AnsibleJ2Vars(list_0, list_0, list_0)
    for x in ansible_j2_vars_0:
        assert x == '&~\x1d'


# Generated at 2022-06-25 12:32:19.583851
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'r'
    for str_1 in str_0:
        str_4 = 'o\x13'
        str_2 = str_4 + to_native(str_1)
        str_3 = str_2 * 2
        list_0 = [str_3]
        str_5 = 'I\x1f:P'
        str_6 = str_5 * 2
        str_7 = str_6 * 2
        str_8 = str_7 * 2
        str_9 = str_8 * 2
        str_10 = str_9 * 2
        str_11 = str_10 * 2
        str_12 = str_11 * 2
        str_13 = str_12 * 2
        int_0 = hash(str_6)
        int_1 = int_0
        int_

# Generated at 2022-06-25 12:32:23.935001
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    int_0 = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:32:27.594119
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        test_case_0()
    except Exception as err:
        print("Caught error [%s]" % err)

if __name__ == "__main__":
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:32:41.457985
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'lU\x0b'
    dict_0 = {str_0: str_0}
    str_1 = '\x11'
    str_2 = '\x11'
    dict_1 = {str_1: str_2}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_1)
    str_3 = '\x11'
    ansible_j2_vars_0[str_3]

# Generated at 2022-06-25 12:32:45.343836
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert ansible_j2_vars_0.__contains__(str_0) == true


# Generated at 2022-06-25 12:32:48.599019
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # FIXME: Implement test cases for method __getitem__ of class AnsibleJ2Vars
    pass


# Generated at 2022-06-25 12:32:54.791696
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    int_0 = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:32:59.650056
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:33:00.602779
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    test_case_0()


# Generated at 2022-06-25 12:33:03.369959
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_1 = '0_\x11'
    dict_1 = {str_1: str_1}
    dict_1[str_1]

# Generated at 2022-06-25 12:33:08.866752
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'g\t'
    dict_0 = {str_0: str_0}
    str_1 = 't\x0bx'
    dict_1 = {str_1: str_1}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_1)
    ansible_j2_vars_0.__contains__('L0')


# Generated at 2022-06-25 12:33:18.043693
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    r1 = None
    r2 = None
    r3 = None
    
    # d is a dict
    d = {}
    ansible_j2_vars_1 = AnsibleJ2Vars(d, d, d)
    assert ansible_j2_vars_1
    
    # d is a dict

# Generated at 2022-06-25 12:33:22.601612
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Create an object of the AnsibleJ2Vars class
    ansible_j2_vars_obj = AnsibleJ2Vars()

    # Using the object print the value of variable 't'
    print(ansible_j2_vars_obj['t'])



# Generated at 2022-06-25 12:33:35.681936
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\xe8\x95\x95>!\xbc\x1d\x14'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    str_0 = '[\xdc\xaf\xf5\xbb\xc2y\x9e\xfe\x98\x19\xcbg\xea\x1d\x0c\x1e\xdf\xb7R\xda'

# Generated at 2022-06-25 12:33:47.493764
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_1 = ansible_j2_vars_0
    str_1 = str_0
    str_2 = 'jz_\rO'

    # Test with a known valid varname
    assert ansible_j2_vars_0[str_1] == str_2

    # Test with an unknown varname
    str_3 = ansible_j2_vars_1['\x1b_!\\\x10\x03\t^\x14']
    # The value of the new key should be None

# Generated at 2022-06-25 12:33:56.762685
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = 'vTF'
    int_0 = 0x11a
    dict_0 = {str_0 : int_0}
    dict_1 = dict_0
    dict_2 = dict_0
    # print('dict0: %s' % dict_0)
    # print('dict1: %s' % dict_1)
    # print('dict2: %s' % dict_2)
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1, dict_2)
    # print('ansible_j2_vars_0: %s' % ansible_j2_vars_0)
    # print('str_0: %s' % str_0)
    # print('ansible_j2_vars_0: %s'

# Generated at 2022-06-25 12:34:08.318684
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = dict()
    dict_0['_templar'] = str()
    dict_0['_globals'] = dict()
    dict_0['_locals'] = dict()
    str_0 = '}'
    str_1 = ':'
    str_2 = '%c'
    str_3 = '('
    str_4 = 'F'
    str_5 = '`'
    str_6 = '='
    str_7 = '\x1d'
    str_8 = '!'
    str_9 = '#'
    str_10 = 'u'
    str_11 = 'q'
    str_12 = '%s'
    str_13 = 'e'
    str_14 = 'j'
    str_15 = 'I'

# Generated at 2022-06-25 12:34:12.298576
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'Lu'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:34:15.774616
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '_\x19'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    str_1 = '\x03P\x0c'
    assert not ansible_j2_vars_0.__contains__(str_1)


# Generated at 2022-06-25 12:34:17.197936
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    __contains__('jz_\rO')


# Generated at 2022-06-25 12:34:20.827704
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = "0x%x_%s_%d_%c_%f_%e_%g_%s_%r_%x"
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 12:34:28.170517
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'zx\nh'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    try:
        ansible_j2_vars_0.__getitem__('\x1e')
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 12:34:33.952217
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '{i@r'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__('x')
    ansible_j2_vars_0.__getitem__('c3P@k2')


# Generated at 2022-06-25 12:34:47.324472
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'zR?\x0f'
    dict_0 = {str_0: str_0}
    dict_1 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_1)
    ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:34:51.713831
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'PZLH9'
    str_1 = '5O5\n!f'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    str_2 = ansible_j2_vars_0[str_1]; print(str_2)



# Generated at 2022-06-25 12:34:53.186005
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    for i in range(0, 10):
        test_case_0()


# Generated at 2022-06-25 12:35:02.896243
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'H\x0c'
    str_1 = 'H\x0c'
    dict_0 = {str_0: str_0, str_1: str_1}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    str_2 = 'U\x0b'
    str_3 = 'U\x0b'
    str_4 = 'U\x0b'
    assert(not ansible_j2_vars_0.__contains__(str_2))
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)

# Generated at 2022-06-25 12:35:07.182538
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert (str_0 == str_0)
    assert (str_0 in dict_0)
    assert (str_0 in ansible_j2_vars_0)
    assert (str_0 == ansible_j2_vars_0[str_0])


# Generated at 2022-06-25 12:35:15.760224
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'b1Df'
    str_1 = 'q3^V'
    str_2 = 'jz_\rO'
    str_3 = 'd9#s'
    int_0 = 700
    int_1 = 927
    list_0 = [str_0, str_1]
    tuple_0 = (int_0, int_1)
    dict_0 = {str_2: tuple_0, str_3: str_2}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, list_0)
    ansible_j2_vars_0.__getitem__(str_3)


# Generated at 2022-06-25 12:35:20.748037
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    err = 0
    str_0 = 'ohDG'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    try:
        ansible_j2_vars_0.add_locals(dict_0)
        try:
            ansible_j2_vars_0.__getitem__(str_0)
        except KeyError:
            err += 1
    except AttributeError:
        err += 1
    assert err == 0


# Generated at 2022-06-25 12:35:26.133363
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    dict_1 = {}
    dict_0['jz_\rO'] = 'jz_\rO'
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1, dict_0)
    str_0 = 'jz_\rO'
    assert str_0 == ansible_j2_vars_0[str_0]


# Generated at 2022-06-25 12:35:32.431216
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars('rJ\t')
    ansible_j2_vars_0.__getitem__('D>M+')
    ansible_j2_vars_0.__getitem__('Y4D')
    ansible_j2_vars_0.__getitem__('6kz')


# Generated at 2022-06-25 12:35:42.107017
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'bQ_&t{'
    str_1 = 'K}P-L\''
    str_2 = 'jz_\rO'
    str_3 = 'zlF)>'
    dict_0 = {str_0: str_1, str_2: str_3}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__(str_0)
    ansible_j2_vars_0.__getitem__(str_2)
    ansible_j2_vars_0.__getitem__('f}')


# Generated at 2022-06-25 12:35:51.023714
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()


# Generated at 2022-06-25 12:35:55.291340
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = 'f"+#0'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:36:00.325469
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'Ai@'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:36:02.165851
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '\x0b\x0b\x14\x14'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:36:06.933593
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    try:
        ansible_j2_vars_0.__getitem__('jz_\rO')
    except KeyError as e:
        pass


# Generated at 2022-06-25 12:36:09.221443
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Initialize test walker
    walker = Walker(5)
    # Initialize test interfaces
    i1 = Interface(1, 1, walker)
    assert not isinstance(i1, dict)



# Generated at 2022-06-25 12:36:14.438025
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '7'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    str_1 = '7'
    str_2 = '7'
    assert ansible_j2_vars_0[str_1] == str_2


# Generated at 2022-06-25 12:36:15.610194
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 12:36:20.244642
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'f\x15\x14\x18p\x0b'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:36:26.017600
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'U6'
    str_1 = 'r^\r'
    dict_0 = {str_0: str_1}
    str_2 = '='
    dict_1 = {str_2: str_2}
    str_3 = '>'
    dict_2 = {str_3: str_3}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1, dict_2)
    ansible_j2_vars_1 = ansible_j2_vars_0.__getitem__(str_0)
    #assert ansible_j2_vars_1 == str_1


# Generated at 2022-06-25 12:36:46.912994
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = '3_1W<'
    str_1 = "jA@&"
    str_2 = 'Vm9|Cv'
    dict_0 = {str_0: str_1, str_2: str_2}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.add_locals(None)


# Generated at 2022-06-25 12:36:51.920686
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """
    Test method __contains__ of class AnsibleJ2Vars
    """
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert ansible_j2_vars_0.__contains__(str_0) is True
    assert ansible_j2_vars_0.__contains__(str_0) is True



# Generated at 2022-06-25 12:37:02.022182
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = "m\x00\x7f\x0c\x9d\x06\xa2\x1f\xed\x1d\x0b\x88\x06\x9a\x0c\x9d\x06\xa2\x1f\xed\xad\x06\x9a\x0c\x9d\x06\xa2\x1f\xed\x88\x06\x9a\x0c\x9d\x06\xa2\x1f\xed"

# Generated at 2022-06-25 12:37:09.568807
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''Test case for AnsibleJ2Vars.__contains__ method
    Test AnsibleJ2Vars.__contains__ function
    '''
    jz_0 = 'jz_\rO'
    dict_0 = {jz_0: jz_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)

    if(ansible_j2_vars_0.__contains__(jz_0)):
        raise AssertionError('AnsibleJ2Vars.__contains__ method is not working properly')


# Generated at 2022-06-25 12:37:20.003240
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_1 = 'bN|3\x0c'
    dict_1 = {str_1: str_1}
    str_2 = 'b!23\x0c'
    dict_2 = {str_2: str_2}
    str_3 = 'b>|2\x0c'
    dict_3 = {str_3: str_3}
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_1, dict_2, dict_3)
    assert(ansible_j2_vars_1._globals == dict_2)
    assert(ansible_j2_vars_1._locals == dict_3)
    assert(ansible_j2_vars_1._templar == dict_1)


# Generated at 2022-06-25 12:37:30.790598
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'W'
    str_1 = '6\x1f;\x1b\x1d\x07\x05\x02\x0e\x11\x01\x0b\x0e'
    str_2 = '\x14\x0f\x0e\x16\x07\x0c\x12\x0c\x0f\x00\x04\x12\x0a\x0a'
    dict_0 = {}
    dict_0['l_auto_escape'] = False
    dict_0[str_0] = str_1
    dict_0[str_2] = str_0
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)

# Generated at 2022-06-25 12:37:35.116734
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'J'
    dict_1 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_1, dict_1, dict_1)
    str_1 = '?'
    dict_2 = {str_1: str_1}
    ansible_j2_vars_1 = ansible_j2_vars_0.add_locals(dict_2)

# Generated at 2022-06-25 12:37:38.654407
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '\x17<G\x04'
    dict_0 = {str_0: str_0}
    dict_1 = dict()
    assert AnsibleJ2Vars(dict_0, dict_1, dict_0).__len__() == 3


# Generated at 2022-06-25 12:37:45.966482
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    list_0 = [True, True, True, True, False, False]
    str_0 = 'jz_\rO'
    str_1 = 'y\tC'
    str_2 = "vxl'ZzG"
    str_3 = '=mB'
    str_4 = 'c`s'
    str_5 = 'I#_'
    str_6 = 'HtG'
    str_7 = 'w_'
    str_8 = '#+k'
    list_2 = [list_0, list_0]
    list_3  = [list_0]
    #print eval(list_3)
    str_9 = 'e^G*'

# Generated at 2022-06-25 12:37:57.364929
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Input variables used for the unit test
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}

    # Call the constructor of the class AnsibleJ2Vars
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)

    try:
        # Check the values of the variables obtained
        assert (ansible_j2_vars_0._globals == dict_0)
        assert (ansible_j2_vars_0._locals == dict_0)
        assert (ansible_j2_vars_0._templar == dict_0)
    except AssertionError as e:
        print("Test failed: AssertionError")

# Generated at 2022-06-25 12:38:18.474344
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'Zt_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 12:38:23.560003
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'Oe'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert 3 == ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:38:31.335696
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'z\x05\x84'
    list_0 = [1, 2, 3, 4, 5]
    str_1 = 'y\x1e\xcd\xb6\xea\xe1\x8d\xfc\x14'
    dict_0 = {str_0: str_1, 'list_0': list_0}
    dict_1 = {'list_0': list_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    dict_2 = locals()
    dict_2 = dict_2[str_1]
    ansible_j2_vars_0.__getitem__(str_0)

# Generated at 2022-06-25 12:38:37.156677
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    str_2 = 'jz_\rO'
    str_3 = ansible_j2_vars_0[str_2]
    assert str_3 == str_0

# Generated at 2022-06-25 12:38:42.640211
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1, dict_2)
    str_0 = 'nQA'
    dict_1[str_0] = dict_0
    dict_2[str_0] = dict_1
    assert ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:38:48.604946
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'jz_\rO'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    varname_0 = 'jz_\rO'
    assert ansible_j2_vars_0.__getitem__(varname_0) == 'jz_\rO'

if __name__ == "__main__":
    test_case_0()
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:38:53.073578
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'h!U\x0C'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0)
    result = ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:38:58.753687
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '#\x04\x02\x0b\x1d'
    str_1 = '\x1d\n\x04\x02#'
    dict_0 = {str_0: str_0, str_1: str_1}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 12:39:04.152275
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\x0f#'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__(str_0)
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:39:11.430253
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    dict_0 = dict()
    dict_0['b'] = 1
    dict_0['a'] = 2
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    dict_1 = dict()
    dict_0['b'] = 1
    dict_0['a'] = 2
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    dict_2 = dict()
    dict_0['b'] = 1
    dict_0['a'] = 2
    ansible_j2_vars_2 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    dict_3 = dict()
    dict_0['b'] = 1
   