

# Generated at 2022-06-25 12:29:40.628045
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 328.4318
    bool_0 = True
    tuple_0 = (bool_0,)
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, tuple_0)
    with pytest.raises(NotImplementedError) as excinfo:
        ansible_j2_vars_0.__getitem__(str_0)
    assert 'Method not implemented.' in str(excinfo.value)


# Generated at 2022-06-25 12:29:43.961522
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    float_0 = 328.4318
    bool_0 = True
    tuple_0 = (bool_0,)
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, tuple_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:29:47.709708
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    float_0 = 328.4318
    bool_0 = True
    tuple_0 = (bool_0,)
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, tuple_0)
    # parameter int_0 (int) tests whether the method correctly handles when parameter is an int
    int_0 = 1
    assert ansible_j2_vars_0.__len__(int_0)


# Generated at 2022-06-25 12:29:54.253751
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    assert ansible_j2_vars_0.__getitem__('varname') == 'varname'
    bool_0 = True
    ansible_j2_vars_1 = AnsibleJ2Vars()
    assert ansible_j2_vars_1.__getitem__(bool_0) == bool_0


# Generated at 2022-06-25 12:30:00.095124
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 328.4318
    bool_0 = True
    tuple_0 = (bool_0,)
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, tuple_0)
    ansible_j2_vars_0.__getitem__()


if __name__ == '__main__':
    test_case_0()
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:30:09.677461
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 328.4318
    bool_0 = True
    tuple_0 = (bool_0,)
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, tuple_0)
    # TEST begin
    # Make sure we can get the values we added
    assert ansible_j2_vars_0[0] == bool_0
    # Make sure we can't get values we didn't add
    try:
        ansible_j2_vars_0[1]
        # Should throw an IndexOutOfRange exception
        assert False
    except IndexError:
        pass
    # TEST end

# Test unit for method add_locals of class AnsibleJ2Vars

# Generated at 2022-06-25 12:30:19.242088
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = 328.4318
    bool_0 = True
    tuple_0 = (bool_0,)
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, tuple_0)
    ansible_j2_vars_1 = ansible_j2_vars_0
    ansible_j2_vars_2 = ansible_j2_vars_1
    ansible_j2_vars_3 = ansible_j2_vars_2
    ansible_j2_vars_4 = ansible_j2_vars_3
    ansible_j2_vars_4.__getitem__()


# Generated at 2022-06-25 12:30:29.084719
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    str_0 = to_bytes('test')
    if PY3:
        str_0 = str('test')

    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0)
    str_1 = to_bytes('test')
    if PY3:
        str_1 = str('test')

    bool_0 = ansible_j2_vars_0.__contains__(str_1)


# Generated at 2022-06-25 12:30:32.138826
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # Create the object
    float_0 = 328.4318
    bool_0 = True
    tuple_0 = (bool_0,)
    ansible_j2_vars_0 = AnsibleJ2Vars(float_0, tuple_0)

    # Test the method
    assert ansible_j2_vars_0.__iter__() is not None


# Generated at 2022-06-25 12:30:39.001836
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        float_0 = 328.4318
        bool_0 = True
        tuple_0 = (bool_0,)
        ansible_j2_vars_0 = AnsibleJ2Vars(float_0, tuple_0)
        ansible_j2_vars_0.__getitem__(bool_0)
    except KeyError as e:
        print(to_native(e))
    except AnsibleError as e:
        print(to_native(e))
    except TypeError as e:
        print(to_native(e))

# Generated at 2022-06-25 12:30:47.179563
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Test error handling
    try:
        set_0 = set()
        ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
        ansible_j2_vars_0 = ansible_j2_vars_0.__iter__()
    except Exception as err:
        pass


# Generated at 2022-06-25 12:30:52.181881
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)

    # AssertionError
    try:
        ansible_j2_vars_0.__getitem__()
    except AssertionError:
        pass
    else:
        raise AssertionError('AssertionError expected, not raised')



# Generated at 2022-06-25 12:30:56.455895
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    try:
        value_0 = ansible_j2_vars_0.__getitem__(set_0)
    except KeyError:
        pass
    else:
        print("Expected exception not thrown" + value_0)


# Generated at 2022-06-25 12:31:00.118938
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    Constructor for class AnsibleJ2Vars
    '''
    # Create an instance of class AnsibleJ2Vars with default values
    ansible_j2_vars = AnsibleJ2Vars(set(), set())
    assert isinstance(ansible_j2_vars, AnsibleJ2Vars)


# Generated at 2022-06-25 12:31:03.093277
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)

    try:
        assert not ansible_j2_vars_0[0]
    except KeyError:
        pass

# Generated at 2022-06-25 12:31:06.749140
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    # FIXME: This should be a iterator in stead of a set
    ansible_j2_vars_0___iter___0 = ansible_j2_vars_0.__iter__()
    assert False


# Generated at 2022-06-25 12:31:10.057263
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    __tracebackhide__ = True

    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert ansible_j2_vars_0.__len__() == 0


# Generated at 2022-06-25 12:31:14.505370
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    itervalue = ansible_j2_vars_0.__iter__()
    assert itervalue == itervalue


# Generated at 2022-06-25 12:31:17.295404
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    # FIXME skipping test
    pass


# Generated at 2022-06-25 12:31:20.765772
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_1 = set()
    ansible_j2_vars_1 = AnsibleJ2Vars(set_1, set_1)
    assert ansible_j2_vars_1.__contains__("k") == False


# Generated at 2022-06-25 12:31:28.728216
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    bool_0 = ansible_j2_vars_0.__contains__("")
    assert bool_0 is True


# Generated at 2022-06-25 12:31:31.209891
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)


# Generated at 2022-06-25 12:31:35.266156
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert not ansible_j2_vars_0.__contains__('KHxI6o')


# Generated at 2022-06-25 12:31:38.201196
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    set_1 = set()
    ansible_j2_vars_1 = AnsibleJ2Vars(set_1, set_1)
    len(ansible_j2_vars_1)


# Generated at 2022-06-25 12:31:45.455574
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    set_1 = set()
    ansible_j2_vars_1 = AnsibleJ2Vars(set_0, set_0)
    # Test that the execution of this method does not raise any exceptions
    try:
        ansible_j2_vars_1.__iter__()
    except Exception as e:
        failure = True
        print(e)
    success = True
    if not success:
        raise Exception('Failed to ensure that __iter__ on class AnsibleJ2Vars does not raise any exceptions')


# Generated at 2022-06-25 12:31:51.438918
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__getitem__('_')

    # coverage for the above KeyError
    try:
        ansible_j2_vars_0.__getitem__('_')
    except KeyError:
        pass


# Generated at 2022-06-25 12:31:54.373385
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0[str_0] = str_0

# Generated at 2022-06-25 12:31:58.540653
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    # Run the method under test
    result = AnsibleJ2Vars(set_0, set_0).__getitem__('s_0')

# Generated at 2022-06-25 12:32:01.389636
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    result = ansible_j2_vars_0.__iter__()
    assert result is not None


# Generated at 2022-06-25 12:32:04.796137
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert not ansible_j2_vars_0.__contains__(set_0)


# Generated at 2022-06-25 12:32:12.801376
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:32:20.373145
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    str_0 = ''
    try:
        ansible_j2_vars_0.__getitem__(str_0)
    except KeyError as exception_0:
        pass

    # FIXME - this needs test data, doesn't seem to be used beyond this point
    try:
        ansible_j2_vars_0.__getitem__(str_0)
    except KeyError as exception_0:
        pass
    except AnsibleError as exception_1:
        pass
    except AnsibleUndefinedVariable as exception_2:
        pass

    set_2 = set()
    ansible_

# Generated at 2022-06-25 12:32:30.815947
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vars_0 = dict()
    vars_1 = dict(a=1)
    vars_2 = dict(c=2)
    vars_3 = dict(d=3)
    vars_4 = dict()
    vars_5 = dict(a=1)
    vars_6 = dict(c=2)
    vars_7 = dict(d=3)
    vars_8 = dict()

    # Template the first set of globals
    templar_0 = Templar(variable_manager=VariableManager(loader=None),
                        shared_loader_obj=None,
                        available_variables=vars_0)

# Generated at 2022-06-25 12:32:33.195440
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set0 = set()
    ansible_j2_vars0 = AnsibleJ2Vars(set0, set0)
    ret_val0 = ansible_j2_vars0.__iter__()


# Generated at 2022-06-25 12:32:33.916706
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert True


# Generated at 2022-06-25 12:32:37.203220
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert ansiballz_0 is None


# Generated at 2022-06-25 12:32:39.352660
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)


# Generated at 2022-06-25 12:32:42.334759
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert ansible_j2_vars_0.__iter__() == set_0.__iter__()


# Generated at 2022-06-25 12:32:46.747385
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.module_utils.common._collections_compat
    from ansible.vars.hostvars import HostVars
    hostvars_0 = HostVars(ansible_j2_vars_0, ansible.module_utils.common._collections_compat)
    ansible_j2_vars_1 = AnsibleJ2Vars(set_0, set_0)
    assert ansible_j2_vars_1.__getitem__(set_0) == None



# Generated at 2022-06-25 12:32:54.034865
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__getitem__("Li")


# Generated at 2022-06-25 12:33:02.893476
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    varname = 0
    try:
        value = ansible_j2_vars_0.__getitem__(varname)
    except Exception as exception:
        assert isinstance(exception, KeyError)
        assert exception.args[0] == 'undefined variable: 0'


# Generated at 2022-06-25 12:33:08.725489
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    # Test for 2nd element of tuple passed to func __contains__ for multiple
    # cases with different types of values
    str_0 = str()
    str_1 = str()
    str_2 = str()
    str_3 = str()
    assert not ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:33:13.406082
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    str_0 = 'abc'
    assert ansible_j2_vars_0.__contains__(str_0) == False



# Generated at 2022-06-25 12:33:19.700778
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    str_0 = ''
    result_0 = ansible_j2_vars_0.__contains__ (str_0)
    assert result_0


# Generated at 2022-06-25 12:33:23.357075
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__(str_0)

test_case_0()

# Generated at 2022-06-25 12:33:27.123954
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    try:
        ansible_j2_vars_0['a']
    except KeyError as e:
        pass



# Generated at 2022-06-25 12:33:29.782422
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__getitem__(set_0)


# Generated at 2022-06-25 12:33:32.548084
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert ansible_j2_vars_0.__iter__() == ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:33:35.524591
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:33:41.187220
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__contains__(set_0)


# Generated at 2022-06-25 12:33:48.283030
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)

    # Test the case where attribute is missing
    try:
        ansible_j2_vars_0.__iter__()
    except:
        pass

    # Test the case where attribute __contains__ is missing
    try:
        ansible_j2_vars_0.__iter__()
    except:
        pass

# Generated at 2022-06-25 12:33:52.518690
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.ansible_j2_vars.globals.update({'foo': 'bar'})
    ansible_j2_vars_0.ansible_j2_vars.globals.update({'baz': 'quux'})
    assert ansible_j2_vars_0.__contains__('baz')
    assert ansible_j2_vars_0.__contains__('foo')


# Generated at 2022-06-25 12:33:57.152278
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    keys = set()
    assert list(ansible_j2_vars_0.__iter__()) == list(iter(keys))
    assert list(ansible_j2_vars_0.__iter__()) == list(iter(keys))


# Generated at 2022-06-25 12:34:09.067062
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert not ansible_j2_vars_0.__contains__('key_0')
    assert not ansible_j2_vars_0.__contains__('key_0') == False
    assert not ansible_j2_vars_0.__contains__('key_1')
    assert not ansible_j2_vars_0.__contains__('key_1') == False
    assert not ansible_j2_vars_0.__contains__('key_2')
    assert not ansible_j2_vars_0.__contains__('key_2') == False
    assert not ansible_j2_vars_0

# Generated at 2022-06-25 12:34:12.298196
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars(templar = Templar(), globals = dict())
    ansible_j2_vars_0.__getitem__(varname = 'varmame')


# Generated at 2022-06-25 12:34:17.827744
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import random
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.vars.hostvars import HostVars
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.template.template import AnsibleUndefinedVariable

    # TODO: implement tests for this class
    templar = Templar('/path/to/file', mock_loader, None, None, None, None)
    ansible_j2_vars = AnsibleJ2Vars(templar,random.choice(string_types))
    ansible_hostvars = HostVars(templar,safe_eval('/path/to/file', mock_loader, None, None, None, None))
    ansible_j2

# Generated at 2022-06-25 12:34:22.098993
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)

    ansible_j2_vars_1 = AnsibleJ2Vars(set_0, set_0)

    assert ansible_j2_vars_1.__len__() == ansible_j2_vars_0.__len__()



# Generated at 2022-06-25 12:34:33.952779
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    set_1 = set()
    set_1.add('d')
    ansible_j2_vars_0._templar.available_variables = set_1
    ansible_j2_vars_0._locals = set_1
    ansible_j2_vars_0._globals = set_1
    set_2 = set()
    ansible_j2_vars_0._templar.available_variables = set_2
    ansible_j2_vars_0._locals = set_2
    ansible_j2_vars_0._globals = set_2
    set_3 = set()
   

# Generated at 2022-06-25 12:34:35.898674
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_1 = set()
    ansible_j2_vars_1 = AnsibleJ2Vars(set_1, set_1)
    ansible_j2_vars_1.__getitem__('key')


# Generated at 2022-06-25 12:34:41.120583
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    template_str_0 = 'blah:'
    filter_str_0 = '{{ blah }}'
    ansible_j2_vars_0 = AnsibleJ2Vars(template_str_0, filter_str_0)
    ansible_j2_vars_0.__getitem__()

# Generated at 2022-06-25 12:34:52.275182
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_2 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_3 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_4 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_5 = AnsibleJ2Vars(set_0, set_0)

# Generated at 2022-06-25 12:35:01.979695
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from templar import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    set_0 = set()
    templar_1 = Templar(None, loader=DataLoader())
    variable_manager_0 = VariableManager()
    variable_manager_0._extra_vars = dict()
    variable_manager_0._extra_vars["foo"] = AnsibleUnsafeText("bar")
    variable_manager_0._host_vars = dict()
    variable_manager_0._host_vars["host1"] = dict()
    variable_manager_0._host_vars["host1"]["foo"] = AnsibleUnsafeText("bar")
    variable_manager

# Generated at 2022-06-25 12:35:11.784339
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    with pytest.raises(AnsibleError):
        set_0 = set()
        set_1 = set()
        ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_1)
        ansible_j2_vars_0.__getitem__('set_0')
    set_0 = set()
    set_1 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_1)
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__('set_0')

# Generated at 2022-06-25 12:35:16.230126
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    # FIXME: Need to add an exception test here.
    ansible_j2_vars_0.__getitem__(str_0)


if __name__ == "__main__":
    test_case_0()
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:35:18.354810
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    x = AnsibleJ2Vars(Stash(), Stash())
    assert(foo in x)
    '''
    assert(True)  # TODO: implement your test here


# Generated at 2022-06-25 12:35:20.411040
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__contains__(str())


# Generated at 2022-06-25 12:35:29.790739
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,',])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-25 12:35:39.893970
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0._templar.available_variables = set_0
    ansible_j2_vars_0._templar.template = lambda x: x
    ansible_j2_vars_0._globals = set_0
    ansible_j2_vars_0._locals = set_0
    ansible_undefined_variable_0 = AnsibleUndefinedVariable()
    ansible_error_0 = AnsibleError()
    ansible_j2_vars_0._templar.template = lambda x: ansible_error_0
    ansible_j2_vars_0._templar.template

# Generated at 2022-06-25 12:35:43.197011
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__getitem__()


# Generated at 2022-06-25 12:35:52.266679
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    set_1 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_1)
    # test case for incorrect type in the first parameter
    # ansible_j2_vars_0.__getitem__(set_0)
    # test case for incorrect type in the second parameter
    # ansible_j2_vars_0.__getitem__(set_1, set_0)
    # test case for incorrect type in the second parameter
    # ansible_j2_vars_0.__getitem__(set_1, set_1)
    # test case for incorrect type in the second parameter
    # ansible_j2_vars_0.__getitem__(set_0, set_0)
    # test

# Generated at 2022-06-25 12:35:56.406488
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    raise ValueError("No test implemented for method __getitem__")



# Generated at 2022-06-25 12:36:00.455757
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:36:08.570131
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # TESTCASE 1
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)

    # TESTCASE 2
    set_1 = set()
    ansible_j2_vars_1 = AnsibleJ2Vars(set_1, set_1)

    # TESTCASE 3
    set_2 = set()
    dict_0 = dict()
    ansible_j2_vars_2 = AnsibleJ2Vars(set_2, dict_0)

    # TESTCASE 4
    set_3 = set()
    dict_1 = dict()
    ansible_j2_vars_3 = AnsibleJ2Vars(set_3, dict_1)

    # TESTCASE 5

# Generated at 2022-06-25 12:36:11.228110
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    return ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:36:16.766205
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    try:
        ansible_j2_vars_0.__getitem__("9Z@RLGE^'e")
    except Exception as exception_0:
        print("Exception: " + str(exception_0))


# Generated at 2022-06-25 12:36:19.541796
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    set_0 = set()
    ansible_j2_var_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_var_0.__len__()


# Generated at 2022-06-25 12:36:25.088710
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_undefined_variable_0 = AnsibleUndefinedVariable()
    dict_0 = dict()
    bool_0 = bool(varname in dict_0)
    bool_1 = bool(varname in ansible_undefined_variable_0)
    ansible_j2_vars_0.__getitem__(varname)
    bool_2 = bool(varname == "vars")


# Generated at 2022-06-25 12:36:28.908175
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert ansible_j2_vars_0.__contains__(False)


# Generated at 2022-06-25 12:36:31.893096
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    key = 'key'
    value = ansible_j2_vars_0.__contains__(key)


# Generated at 2022-06-25 12:36:35.762385
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert ansible_j2_vars_0 is not None


# Generated at 2022-06-25 12:36:45.018313
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)

    # Call the method
    # Use a known value
    call_result_0 = ansible_j2_vars_0.__contains__(set_0)

    # We expect to see False here
    success = False
    if not False:
        raise AssertionError("expected False, got %s" % repr(call_result_0))



# Generated at 2022-06-25 12:36:46.947246
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)


# Generated at 2022-06-25 12:36:49.215606
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:36:52.026485
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    iterator = ansible_j2_vars_0.__iter__()
    assert isinstance(iterator, Iterator)


# Generated at 2022-06-25 12:36:57.130510
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    unit_test = unittest.TestCase()
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    try:
        ansible_j2_vars_0.__getitem__(set_0)
    except KeyError as e:
        unit_test.assertIsInstance(e, KeyError, 'KeyError raised.')


# Generated at 2022-06-25 12:37:04.042267
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    with pytest.raises(KeyError, match=r'.*'):
        ansible_j2_vars_0.__getitem__(str_0)
    set_1 = set()
    ansible_j2_vars_1 = AnsibleJ2Vars(set_1, set_1, locals=dict_0)
    ansible_j2_vars_1.__getitem__(str_0)


# Generated at 2022-06-25 12:37:07.901020
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    # In this unit test, we assume that the following preconditions are true:
    assert len(set()) == 0

    ansible_j2_vars_0 = AnsibleJ2Vars(set(), set())
    ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:37:13.733499
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    variable_0 = ''
    try:
        ansible_j2_vars_0[variable_0]
    except KeyError as exception_0:
        print(exception_0)


# Generated at 2022-06-25 12:37:22.444577
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_2 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_3 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_4 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_5 = AnsibleJ2Vars(set_0, set_0)

# Generated at 2022-06-25 12:37:25.766428
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert ansible_j2_vars_0.__iter__() is not None


# Generated at 2022-06-25 12:37:33.055291
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    with pytest.raises(KeyError) as excinfo:
        ansible_j2_vars_0.__getitem__(str_0)
    assert 'key' in str(excinfo)

# Generated at 2022-06-25 12:37:40.182628
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    dict_0 = dict()
    dict_0['foo'] = 'bar'
    dict_0['baz'] = 'qux'
    ansible_j2_vars_0._templar.available_variables = dict_0

    ansible_j2_vars_0.__getitem__('foo') # expected exception

    ansible_j2_vars_0.__getitem__('baz') # expected exception


# Generated at 2022-06-25 12:37:43.908812
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    # ansible_j2_vars_0.__getitem__ is not implemented
    with raises(NotImplementedError):
        ansible_j2_vars_0.__getitem__()


# Generated at 2022-06-25 12:37:49.362353
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    # Tests might need these
    dict_0 = dict()
    dict_1 = dict()
    key_0 = "An integer: %d"
    key_1 = "An integer: %d"
    ansible_j2_vars_0.add("vars", dict_0)
    ansible_j2_vars_0.add("vars", dict_1)
    ansible_j2_vars_0.add("vars", dict_1)
    from ansible.vars.hostvars import HostVars
    hostvars_0 = HostVars(dict_1)

# Generated at 2022-06-25 12:37:55.028759
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__getitem__(0)


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(sys.argv))

# Generated at 2022-06-25 12:38:06.246674
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)

    class Dict_0(dict):
        def __init__(self):
            self.str_0 = "str_0"
        def __missing__(self, str_0):
            return None

    dict_0 = Dict_0()
    dict_1 = {'__getitem__': {}}
    dict_2 = dict()
    dict_2['key_0'] = dict_1['__getitem__']
    dict_3 = dict(dict_2)
    dict_3['key_1'] = dict_2
    dict_4 = {'key_2': dict_2}
    dict_4['key_3'] = dict_3
    dict_4

# Generated at 2022-06-25 12:38:09.075066
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    str_0 = ansible_j2_vars_0[0]


# Generated at 2022-06-25 12:38:14.282608
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert ansible_j2_vars_0.__contains__() == NotImplemented


# Generated at 2022-06-25 12:38:20.901297
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    str_0 = ansible_j2_vars_0[str_0]
    try:
        ansible_j2_vars_0[str_0]
    except KeyError:
        print('KeyError')



# Generated at 2022-06-25 12:38:24.199934
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert type(ansible_j2_vars_0._AnsibleJ2Vars__iter__()) is generator


# Generated at 2022-06-25 12:38:30.090983
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    __expected = None  # The expected value is unspecified.
    __actual = test_case_0()
    try:
        assert __expected == __actual
    except AssertionError as e:
        print('AssertionError raised: ', e)





# Generated at 2022-06-25 12:38:33.686381
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    str_0 = ansible_j2_vars_0['vars']


# Generated at 2022-06-25 12:38:38.948924
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # ansible.module_utils.jinja2_objects.AnsibleJ2Vars.__getitem__(set_0, set_1, set_2)
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_1, set_2)
    ansible_j2_vars_0.__getitem__(set_3)

# Generated at 2022-06-25 12:38:41.851759
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    # __contains__ of class AnsibleJ2Vars
    assert ansible_j2_vars_0.__contains__(0) == False


# Generated at 2022-06-25 12:38:42.678412
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()


# Generated at 2022-06-25 12:38:43.866583
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # FIXME: remove this test
    pass

# Generated at 2022-06-25 12:38:46.570127
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_0.__getitem__(str())


# Generated at 2022-06-25 12:38:49.031965
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    str_0 = ansible_j2_vars_0[0]


# Generated at 2022-06-25 12:38:51.144463
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert not ansible_j2_vars_0.__contains__('foo')


# Generated at 2022-06-25 12:38:52.408223
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ansible_j2_vars_0 = AnsibleJ2Vars('set_0', 'set_0')


# Generated at 2022-06-25 12:39:02.915606
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    varname_0 = 'varname'
    try:
        ansible_j2_vars_0.__getitem__(varname_0)
    except KeyError:
        pass


# Generated at 2022-06-25 12:39:08.118944
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_2 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_1.add_locals(ansible_j2_vars_2)


# Generated at 2022-06-25 12:39:09.623508
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        test_case_0()
    except:
        print('Exception raised in class AnsibleJ2Vars')

# Generated at 2022-06-25 12:39:12.567748
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    assert not ansible_j2_vars_0.__contains__(set_0)


# Generated at 2022-06-25 12:39:19.693879
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(set_0, set_0)

    str_0 = unicode__getitem__(ansible_j2_vars_0, ansible_j2_vars_1)
    # self.assertEqual(str_0, "undefined variable: %s")
    # self.assertRaisesRegex(KeyError, "undefined variable: %s")


# Generated at 2022-06-25 12:39:22.907869
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    set_0 = set()
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    try:
        ansible_j2_vars_0.__getitem__('test')
    except KeyError as e:
        print("HANDLED KEYERROR")
        exit(1)


# Generated at 2022-06-25 12:39:30.323967
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
  jinja2_environment_0 = jinja2.Environment(loader=jinja2.FileSystemLoader([]), extensions=[], undefined=jinja2.StrictUndefined, cache_size=50, bytecode_cache=jinja2.FileSystemBytecodeCache([], './template', 'jinja2.cache'))
  ansible_builtin_vars_0 = dict(globals={'template': 'template', 'environment': jinja2_environment_0})
  ansible_builtin_vars_1 = dict(ansible_check_mode=False, ansible_loop='l_0')
  ansible_j2_vars_0 = AnsibleJ2Vars(jinja2_environment_0, ansible_builtin_vars_0)
  assert ansible_j2_vars_0