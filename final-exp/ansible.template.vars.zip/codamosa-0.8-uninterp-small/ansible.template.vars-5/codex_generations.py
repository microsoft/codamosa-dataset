

# Generated at 2022-06-25 12:29:42.026226
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    # print(ansible_j2_vars_0)


# Generated at 2022-06-25 12:29:48.605724
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert isinstance(ansible_j2_vars_0, AnsibleJ2Vars) == True



# Generated at 2022-06-25 12:29:49.584982
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert True


# Generated at 2022-06-25 12:29:56.427294
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)

    assert_equals(type(ansible_j2_vars_0.__iter__()), type(set().__iter__()))


# Generated at 2022-06-25 12:30:03.961088
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Init
    str_0 = '1W\r"Yi\x0e\x7f\x17\x0bU\nks'
    list_0 = ['k0N\x15\x11\x1d\x03\x7f\x0f', '\x1b\x0cA\x13\x1c\x19\x0f\x16\x01']
    str_1 = '\rqF"k\n*~a71I'

# Generated at 2022-06-25 12:30:09.692496
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'fYCy83c]7'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    int_end_0 = len(ansible_j2_vars_0)
    return int_end_0


# Generated at 2022-06-25 12:30:17.158731
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '|>`}bhp#<'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)

    assert active_validation
    with pytest.raises(Exception):
        assert ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:30:21.500987
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '`S}'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:30:32.556339
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '"\x12\x1b\r\rQ\x19\x14\x1f\x1f'

# Generated at 2022-06-25 12:30:38.847570
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    str_2 = '\rqF"k\n*~a71I'
    ansible_j2_vars_0_result = ansible_j2_vars_0.__getitem__(str_2)
    print(ansible_j2_vars_0_result)


# Generated at 2022-06-25 12:30:43.611157
# Unit test for method __contains__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:30:49.547690
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # create ansible_j2_vars object:
    dict_0 = {}
    dict_0[0] = "k+"
    dict_0[0] = "*"
    dict_0[0] = "|5"
    ansible_j2_vars_0 = AnsibleJ2Vars("#97", dict_0, dict_0)
    # call the method:
    ansible_j2_vars_0.__contains__(0)


# Generated at 2022-06-25 12:30:57.735272
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '\x16\x00\t\x04(/\x1a\x00\x1b\x00\x04\x04\x00\x00s\x03\x16\x00\x04\x04\x00\x00s\x01\x16\x00\n\x04\x00\x00s\x02'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)

# Generated at 2022-06-25 12:31:04.374840
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    with pytest.raises(KeyError) as exception_info:
        ansible_j2_vars_0.__getitem__('\rqF"k\n*~a71I')
    assert "undefined variable: '\rqF\"k\n*~a71I'" in str(exception_info)


# Generated at 2022-06-25 12:31:09.428760
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '$?yI\x7f\x19\x7f\x0e'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    list_0 = [str_0, str_0, str_0, str_0]
    ansible_j2_vars_0.__contains__(list_0)


# Generated at 2022-06-25 12:31:15.655569
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '<Twa2uV7'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    result = ansible_j2_vars_0.__iter__()
    assert len(result) == 0
    assert result == set()


# Generated at 2022-06-25 12:31:24.271365
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'z\x0b'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    int_0 = ansible_j2_vars_0.__len__()
    assert int_0 == 4
    str_1 = '\x0b9F&'
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1}
    ansible_j2_vars_1 = AnsibleJ2Vars(str_1, dict_1, locals=dict_0)
    int_1 = ansible_j2

# Generated at 2022-06-25 12:31:31.292351
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)

    # Test with type assertion
    assert isinstance(ansible_j2_vars_0.__getitem__(str_0), str)


# Generated at 2022-06-25 12:31:34.734976
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = dict()
    dict_0['n'] = 'n'
    dict_0['o'] = 'o'
    dict_0['c'] = 'c'
    dict_0['p'] = 'p'
    dict_0['k'] = 'k'
    dict_0['e'] = 'e'
    dict_0['y'] = 'y'
    str_0 = 'ph7d/]'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert (ansible_j2_vars_0.__contains__(dict_0['k']) == True)


# Generated at 2022-06-25 12:31:39.295734
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    a = 0
    b = 0
    # a > b
    if ( a > b ):
        b = a
    # b < a
    if ( b < a ):
        b = a
    # a != b
    if ( a != b ):
        a = b
    # a == b
    if ( a == b ):
        a = b


# Generated at 2022-06-25 12:31:53.181493
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = b'\x06\x0f\x08\x1d\x1f\x0c\x0f\r\r!\n\x1a\x19\x1e\x15'
    list_0 = [str_0, str_0, str_0]
    dict_0 = {str_0: list_0, str_0: list_0, str_0: list_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:31:59.534101
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'U6f'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    var_0 = ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:32:10.681365
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '9\x1f\x1fy\x00\x0b\x02z\x0f'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    str_2 = str_0
    str_1 = str_0
    str_3 = str_0
    str_4 = str_0
    str_5 = str_0
    str_6 = str_0

    assert ansible_j2_vars_0.__contains__(str_2)
    assert not ansible_j2_vars_0.__contains__(str_1)
    assert ansible_j2

# Generated at 2022-06-25 12:32:19.398108
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_1 = '\x13T"y#\n)Yj\x0f_\x03Z\x1dj1bb7\x1a\x1c.1^\x17'
    str_0 = '\x10\x00\x11Va\x12\x0f|\x1b\x1c\x1d^\x03x\x08\x00'
    str_2 = '\t\n\x0f\x1f\x03\x15\x19\x1a\x1c\x1d\x0c\x96\x98\x92_\x03'
    dict_0 = {str_0: str_1, str_1: str_0, str_2: str_1}
    ansible_j2_vars_0

# Generated at 2022-06-25 12:32:25.759333
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    result = ansible_j2_vars_0['\rqF"k\n*~a71I']
    assert (result == '\rqF"k\n*~a71I')


# Generated at 2022-06-25 12:32:30.305199
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'n3\t|\x0cn>cY'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    bool_0 = ansible_j2_vars_0.__contains__(str_0)

test_case_0()
test_AnsibleJ2Vars___contains__()

# Generated at 2022-06-25 12:32:34.179918
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert ansible_j2_vars_0.__contains__(str_0) == True


# Generated at 2022-06-25 12:32:39.430661
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert 1 == 1
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert 1 == 1


# Generated at 2022-06-25 12:32:43.886529
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:32:51.263056
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)

    try:
        ansible_j2_vars_0.__getitem__(str_0)
        assert False
    except KeyError:
        pass


# Generated at 2022-06-25 12:33:03.042934
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert ansible_j2_vars_0.__contains__(str_0) == False


# Generated at 2022-06-25 12:33:06.926655
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'nD${\x17l'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)


# Generated at 2022-06-25 12:33:10.501644
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '\x00'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)



# Generated at 2022-06-25 12:33:19.058347
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    dict_0 = dict()
    str_0 = '\rqF"k\n*~a71I'
    dict_0[str_0] = str_0
    dict_0[str_0] = str_0
    dict_0[str_0] = str_0
    dict_0[str_0] = str_0
    dict_0[str_0] = str_0
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert len(ansible_j2_vars_0) == 3
    dict_0 = dict()
    dict_1 = dict()
    dict_1[str_0] = str_0
    dict_1[str_0] = str_0

# Generated at 2022-06-25 12:33:25.344029
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_1 = '\rqF"k\n*~a71I'
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1}
    ansible_j2_vars_1 = AnsibleJ2Vars(str_1, dict_1)

    ansible_error_1 = AnsibleJ2Vars(str_1, dict_1)
    ansible_error_1.__getitem__(str_1)


# Generated at 2022-06-25 12:33:29.854596
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_2 = '<o"v\x1d'
    dict_0 = {str_2: str_2, str_2: str_2, str_2: str_2}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_2, dict_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:33:33.381766
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert len(list(ansible_j2_vars_0.__iter__())) == 3


# Generated at 2022-06-25 12:33:43.593732
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '\nk\x10\x0e7\x14\x10\x0e\r\r'
    int_0 = 20
    dict_0 = {str_0: int_0, str_0: int_0, str_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    bool_0 = ansible_j2_vars_0.__contains__(str_0)
    print('bool_0 = ' + str(bool_0))
    print('str_0 = ' + str(str_0))


# Generated at 2022-06-25 12:33:49.789079
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {'u]X9': '7G', 'MVA~': '7G', 'H[w': '7G', ';ki': '7G'}
    ansible_j2_vars_0 = AnsibleJ2Vars(0, dict_0)
    try:
        ansible_j2_vars_0[0]
    except KeyError:
        pass
    else:
        raise Exception("Failed: expected Exception when trying to access key 0")


# Generated at 2022-06-25 12:33:58.512675
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    ansible_j2_vars_0.__contains__('y')
    ansible_j2_vars_0.__contains__('y')
    ansible_j2_vars_0.__contains__('y')
    ansible_j2_vars_0.__contains__('y')
    ansible_j2_vars_0.__contains__('y')
    ansible_j2_vars_0.__contains__('y')

# Generated at 2022-06-25 12:34:28.102239
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:34:34.608189
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Create a test object
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)

    # No exception raised
    assert ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:34:45.265509
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    #check value
    bool_0 = ansible_j2_vars_0.__contains__(str_0)
    #check type
    assert type(bool_0) == bool
    #check value
    bool_1 = ansible_j2_vars_0.__contains__(str_0)
    #check type
    assert type(bool_1) == bool
    #check value
    bool_2 = ansible_j2_vars_0.__contains__

# Generated at 2022-06-25 12:34:52.163965
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'vG8r\\Ww'
    dict_0 = {str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    ansible_error_0 = None
    try:
        str_1 = ansible_j2_vars_0[str_0]
    except AnsibleError as ansible_error_0:
        pass

    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    try:
        str_1 = ansible_j2_vars_0[str_0]
    except AnsibleError as ansible_error_0:
        pass


# Generated at 2022-06-25 12:35:01.223201
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    ansible_j2_vars_0.__getitem__('Y\u001bVnC\x1e"_\x13\u0000\x0e\x07\x12\r')
    ansible_j2_vars_0.__getitem__("\x1e\x0c\x0cS'\u001dM\x14\u0016")

# Generated at 2022-06-25 12:35:08.980891
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'f;]q3~N'
    set_0 = set()
    set_0.add(str_0)
    ansible_j2_vars_0 = AnsibleJ2Vars(set_0, set_0)
    str_1 = 't@@i'
    bool_0 = ansible_j2_vars_0.__contains__(str_1)


# Generated at 2022-06-25 12:35:15.458340
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    str_1 = '\rqF"k\n*~a71I'
    try:
        object_0 = ansible_j2_vars_0[str_1]
    except KeyError as exception_0:
        assert True
    else:
        assert False


# Generated at 2022-06-25 12:35:20.531893
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert ansible_j2_vars_0[str_0] == str_0
    assert ansible_j2_vars_0[str_0] == str_0
    assert ansible_j2_vars_0[str_0] == str_0


# Generated at 2022-06-25 12:35:28.394684
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '\x00\x1a\x03\x01\x0c\x13\x1e\t\x0f\x0e'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0, dict_0)
    assert ansible_j2_vars_0.__len__() == 9


# Generated at 2022-06-25 12:35:29.413018
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass


# Generated at 2022-06-25 12:36:14.795841
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)
    result = ansible_j2_vars_0.__contains__('K>')
    assert result is None


# Generated at 2022-06-25 12:36:23.198670
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    str_1 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_1, str_1: str_0, str_1: str_1}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_1, dict_0)
    ansible_j2_vars_0._templar.template_data.hidden_fields[str_1] = str_1
    ansible_j2_vars_0._templar.template_data.hidden_fields['vars'] = str_0
    ansible_j2_vars_0._templar.template_data.hidden_fields['vars'] = ansible_j2

# Generated at 2022-06-25 12:36:32.403196
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '\x1d\x1e\x1f\x1c&\x07\x17\x15\x181\x07C\x1cBp\x1c\x1a\x1a'
    str_1 = '\x1d\x1e\x1f\x1a\x16&\x07\x17\x15\x181\x07C\x1cBp\x1c\x1a\x1a'
    str_2 = '\x1d\x1e\x1f\x1c&\x07\x17\x15\x181\x07C\x1cBp\x1c\x1a\x1a'

# Generated at 2022-06-25 12:36:37.959948
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    ansible_j2_vars_0[str_0]


# Generated at 2022-06-25 12:36:47.084856
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '9'
    str_1 = 'U6`'
    str_2 = ''
    str_3 = '\'|b'
    str_4 = '~'
    str_5 = '61#'
    str_6 = '7'
    str_7 = 'Q'
    str_8 = 'N>'
    str_9 = 'x#'
    str_10 = 'P'
    list_0 = list()
    list_1 = list()
    str_11 = 's'
    str_12 = 'I>'
    str_13 = 'iN'
    str_14 = 'H'
    str_15 = 'Wg`'
    str_16 = '_'
    dict_0 = dict()
    dict_1 = dict()

# Generated at 2022-06-25 12:36:47.758842
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # FIXME
    pass


# Generated at 2022-06-25 12:36:48.477699
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass


# Generated at 2022-06-25 12:36:53.174217
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)

    # Test if object contains str_0
    if str_0 in ansible_j2_vars_0:
        return True
    return False


# Generated at 2022-06-25 12:37:03.169698
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    str_1 = '\rqF"k\n*~a71I'
    key_error_0 = None
    try:
        ansible_j2_vars_0[str_1]
    except KeyError as exception_0:
        key_error_0 = exception_0
    str_2 = '\rqF"k\n*~a71I'
    str_3 = '\rqF"k\n*~a71I'
    assert str_3

# Generated at 2022-06-25 12:37:12.244757
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    str_0 = '\n'
    dict_1 = {}
    dict_2 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_1, dict_2)


# Generated at 2022-06-25 12:37:48.112384
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    varname = '\rqF"k\n*~a71I'
    assert ansible_j2_vars_0.__contains__(varname)


# Generated at 2022-06-25 12:37:58.172209
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_1 = '\rqF"k\n*~a71I'
    list_0 = ['\rqF"k\n*~a71I', '\rqF"k\n*~a71I', '\rqF"k\n*~a71I']
    dict_1 = {list_0[2]: list_0[2], list_0[2]: list_0[2], list_0[2]: list_0[2]}
    ansible_j2_vars_1 = AnsibleJ2Vars(str_1, dict_1)

    with pytest.raises(AnsibleUndefinedVariable):
        ansible_j2_vars_1.__getitem__(list_0[2])


# Generated at 2022-06-25 12:38:04.169591
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    ansible_j2_vars_0.add_locals(dict_0)


# Generated at 2022-06-25 12:38:09.294602
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # setup
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)

    # assert
    assert not ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:38:16.865495
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    ansible_j2_vars_0.__getitem__(str_0)
    ansible_j2_vars_0.__getitem__(str_0) # Should raise an exception


# Generated at 2022-06-25 12:38:27.779047
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Valid inputs for constructor
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)

    # Invalid inputs for contructor
    # Invalid inputs for constructor
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}

# Generated at 2022-06-25 12:38:34.205137
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    array_0 = []
    assert len(array_0) == 0                                                                                                     # Test 1
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert len(ansible_j2_vars_0) == 3                                                                                           # Test 2


# Generated at 2022-06-25 12:38:43.556175
# Unit test for method __contains__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:38:48.005164
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert ansible_j2_vars_0[str_0] == str_0


# Generated at 2022-06-25 12:38:48.777156
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert False, "No implementation provided"


# Generated at 2022-06-25 12:39:19.851098
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    print('Test AnsibleJ2Vars::__getitem__')


# Generated at 2022-06-25 12:39:23.472829
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    assert ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:39:27.216794
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '\rqF"k\n*~a71I'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_0)
    return ansible_j2_vars_0
