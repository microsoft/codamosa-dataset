

# Generated at 2022-06-25 12:29:39.120944
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test 1
    try:
        test_case_0()
    except Exception as err:
        assert()



# Generated at 2022-06-25 12:29:40.060505
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:29:46.332576
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(bytes_0, ansible_j2_vars_0)
    int_0 = ansible_j2_vars_1.__contains__(bytes_0)
    assert int_0 == 1



# Generated at 2022-06-25 12:29:54.391463
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(bytes_0, ansible_j2_vars_0)
    ansible_j2_vars_1.__getitem__(float_0)


# Generated at 2022-06-25 12:30:01.455694
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(bytes_0, ansible_j2_vars_0)
    str_0 = ansible_j2_vars_1[ansible_j2_vars_0]


# Generated at 2022-06-25 12:30:02.761410
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()

# Generated at 2022-06-25 12:30:07.375561
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    int_0 = ansible_j2_vars_0.__len__()



# Generated at 2022-06-25 12:30:12.093196
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(bytes_0, ansible_j2_vars_0)


# Generated at 2022-06-25 12:30:19.513794
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(bytes_0, ansible_j2_vars_0)
    assert ansible_j2_vars_0.__contains__('fiz') == False


# Generated at 2022-06-25 12:30:23.654595
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # uncomment the following line to test the class
    test_case_0()

if __name__ == '__main__':
    # uncomment the following lines to test the class
    #test_AnsibleJ2Vars()
    pass

# Generated at 2022-06-25 12:30:33.016593
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'7>\x96\xfd\x0f\xe4\x8e\x9e\xcd\xc2\xd7\x8e\xa3'
    float_0 = 0.223042759196
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_0.__getitem__(float_0)


# Generated at 2022-06-25 12:30:40.300189
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\xa5\x08\xa5\x99\x14\x9e\xad\xdc\x7fF\xcc\x8e\x80\x1f\x9f\\\x9f\xdc\x13F\xa2\x00\xd8\x96\x01fc\xd6\x9d\xcc\x00\xa4\xfb\xa4\x05\x80\x07\x9c\x05\x9f\x83\xde\x0e\xc5H'
    float_0 = -1244.828386
    int_0 = -1163049128
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)

# Generated at 2022-06-25 12:30:49.764998
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\r\x8a\xac\x1c\xdd\xfe\x8b\xb0\xec\x12\x9b'
    float_0 = -1.2
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)

# Generated at 2022-06-25 12:30:54.335891
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)

    # No exception, pass the test case
    test_case_0()



# Generated at 2022-06-25 12:30:56.053077
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:31:01.345811
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    __iter__0 = ansible_j2_vars_0.__iter__()
    assert __iter__0 == iter((float_0, bytes_0))



# Generated at 2022-06-25 12:31:04.469387
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)


# Generated at 2022-06-25 12:31:09.105795
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    int_0 = ansible_j2_vars_0.__getitem__(bytes_0)
    assert int_0 == -1959




# Generated at 2022-06-25 12:31:16.037494
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    for i in range(0, 10, 2):
        with pytest.raises(Exception):
            ansible_j2_vars_0.__getitem__(i)


# Generated at 2022-06-25 12:31:24.554057
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    for_0 = ansible_j2_vars_0.__iter__()
    str_0 = '\x24\x3b\xdf\x0b\x10\xec\x19\xbe\xbe\x14\x80\x92'
    str_1 = '\x24\x3b\xdf\x0b\x10\xec\x19\xbe\xbe\x14\x80\x92'
    dict_0 = dict

# Generated at 2022-06-25 12:31:37.560237
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)

    ansible_j2_vars_0.__getitem__(b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83')
    ansible_j2_vars_0.__getitem__((b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'))

# Generated at 2022-06-25 12:31:45.710204
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:31:51.609378
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x1b\xe2\x11\xad\x9c\xe8\xb1\xbf\xedp\x1d\xbc\xf5\x83'
    float_0 = -14.7245092
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)


# Generated at 2022-06-25 12:31:56.797301
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)


# Generated at 2022-06-25 12:32:01.863525
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_0.__contains__(bytes_0)


# Generated at 2022-06-25 12:32:05.930127
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)


# Generated at 2022-06-25 12:32:06.794903
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass


# Generated at 2022-06-25 12:32:16.696499
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        test_case_0()
    except Exception as err:
        assert isinstance(err, AnsibleUndefinedVariable)
        assert str(err) == "undefined variable: '\\x0f\\x16\\x91\\xda\\x9c|k\\xa8D\\xb83\\xd8\\x83'"
    try:
        test_case_0()
    except Exception as err:
        assert isinstance(err, AnsibleUndefinedVariable)
        assert str(err) == "undefined variable: '\\x0f\\x16\\x91\\xda\\x9c|k\\xa8D\\xb83\\xd8\\x83'"


# Generated at 2022-06-25 12:32:23.390643
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    template = "{{ x }}"
    templar = Templar(loader=None, variables={'x': 'A'})
    ansible_j2_vars_0 = AnsibleJ2Vars(templar, {}, {})
    ansible_j2_vars_0.__getitem__('x')
    ansible_j2_vars_0.__getitem__('y')


# Generated at 2022-06-25 12:32:30.469127
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'X\x13\x04\x1cV\x8c\xb5\xc1\x03\xba\x8a\x9d\x06\x1a\xf8\xa1'
    float_0 = -224.01
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    dict_0 = dict( value1 = "foo", value2 = "bar" )
    ansible_j2_vars_0.add_locals(dict_0)
    ansible_j2_vars_0.__getitem__("value2")

# Generated at 2022-06-25 12:32:39.797056
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert "varname" in (b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83', -1959.46364)
    assert "varname" in ['test', 'value']
    assert "varname" in ['test', 12345]
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)

# Generated at 2022-06-25 12:32:46.709667
# Unit test for method __contains__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:32:52.271507
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_1 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_1 = -1959.46364
    ansible_j2_vars_1 = AnsibleJ2Vars(bytes_1, float_1)
    float_2 = -71.42741
    ansible_j2_vars_1.__getitem__(float_2)


# Generated at 2022-06-25 12:32:55.413514
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    try:
        test_case_0()
    except Exception as exception:
        print('Exception caught in test_AnsibleJ2Vars___contains__')
        print(str(exception))


# Generated at 2022-06-25 12:33:01.040310
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_0.__contains__()


# Generated at 2022-06-25 12:33:08.729100
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    int_0 = 0
    assert (ansible_j2_vars_0.__contains__(int_0) == True)
    int_0 = 1
    assert (ansible_j2_vars_0.__contains__(int_0) == False)



# Generated at 2022-06-25 12:33:17.957011
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    var_0 = '\xda\x0c'
    var_1 = '\x04\x15\x10\x01\x1b\n\n\x90\x10\x03\x16\x18\x1a\x0e\x11\x1c\x12\x13\x15\x03\x04\x15\x1b\x10\x02' * 20

# Generated at 2022-06-25 12:33:23.932083
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:33:28.668507
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_0.__getitem__(0)

# Generated at 2022-06-25 12:33:32.372426
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
   bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
   float_0 = -1959.46364
   ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
   assert len(set(ansible_j2_vars_0))


# Generated at 2022-06-25 12:33:48.136219
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert True
    # FIXME
    #print("HELP ME")
    #ansible_j2_vars_0.__contains__(data_0)
    #assert False


# Generated at 2022-06-25 12:33:51.181026
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    iterator_0 = ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:33:56.639759
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    float_1 = float_0
    ansible_j2_vars_0.__contains__(float_1)


# Generated at 2022-06-25 12:34:01.905928
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    str_0 = '\x0f\x16\x91\xda\x9c'
    try:
        assert str_0 in ansible_j2_vars_0
        assert False
    except Exception as exc:
        assert type(exc) == KeyError


# Generated at 2022-06-25 12:34:07.052227
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_0.__getitem__(str())


# Generated at 2022-06-25 12:34:10.262865
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)


# Generated at 2022-06-25 12:34:15.434041
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_0.__getitem__(bytes_0)
    

# Generated at 2022-06-25 12:34:19.820374
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_0.__getitem__(float_0)


# Generated at 2022-06-25 12:34:31.604080
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        test_case_0()
    except Exception as err:
        print("Caught exception in test case:")
        print(err)
        sys.exit(1)

# Import module containing the test case functions
from . import system_tests_testcase_ansible_j2_vars_testcase_0

# Import module containing helper functions
from . import system_tests_testcase_ansible_j2_vars_testcase_helper_functions

# Pick up all test functions
from inspect import getmembers, isfunction
testcase_funcs = [o[1] for o in getmembers(system_tests_testcase_ansible_j2_vars_testcase_0) if isfunction(o[1])]

# Generated at 2022-06-25 12:34:39.645725
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    try:

        bytes_0 = b'\xc1\xc7\x94\xb8\xb8\xaf\xb2\x1b\xbd!\x84\xb9\xaa'
        float_0 = -1992.4866
        ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
        vars_0 = set()
        vars_0.update(bytes_0, float_0)
        assert list(ansible_j2_vars_0.__iter__()) == vars_0, \
            'Expected %s, got %s' % (vars_0, list(ansible_j2_vars_0.__iter__()))
    except AssertionError:
        raise


# Generated at 2022-06-25 12:35:03.458988
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\xd7\x87\x8dK\x00\xb4y\x08\x81\x89\x1dk\x1a\xc3\x8f\x9d'
    float_0 = -216.27791
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    str_0 = ansible_j2_vars_0.__contains__('%*B')
    assert(str_0 == False)


# Generated at 2022-06-25 12:35:06.420316
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    float_0 = -1959.46364
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)


# Generated at 2022-06-25 12:35:07.219215
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:35:11.234633
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    try:
        test_case_0()
    except Exception as e:
        assert False


# Generated at 2022-06-25 12:35:18.832896
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    bytes_1 = b'r\xb2\x1d)G\x18\xc9\x99\xfe\x95\x11\x83'
    int_0 = -85427
    str_0 = 'g^EfB\x9f\x07\x0f\x19'
    int_1 = -17179
    dict_0 = dict()
    dict_0[int_1] = float_0
    dict_0[bytes_0] = str_0
    dict_0[bytes_1] = int_0
    ansible_j2_vars_0

# Generated at 2022-06-25 12:35:28.689893
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    bytes_1 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_1 = -1959.46364
    ansible_j2_vars_1 = AnsibleJ2Vars(bytes_1, float_1)

# Generated at 2022-06-25 12:35:34.883829
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'7\xba\xb4\xbc'
    str_1 = '0'
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, str_1)
    assert next(ansible_j2_vars_0.__iter__()) == '0'


# Generated at 2022-06-25 12:35:40.423405
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    float_1 = ansible_j2_vars_0[-1959.46364]
    assert float_1 == -1959.46364


# Generated at 2022-06-25 12:35:44.023573
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)

    # Set up mock
    class mock_object_0(object):
        def __init__(self, name0):
            self.name0 = name0

        def __contains__(self, key):
            if key == 'str_0':
                return True
            return False

    mock_object_0_0 = mock_object_0('')

    # Set up mock
    class mock_object_1(object):
        def __init__(self, name0):
            self.name0 = name0

        def __contains__(self, key):
            if key == 'str_0':
                return True
            return False

    mock_object_1_0 = mock_object_1('')

    # Set

# Generated at 2022-06-25 12:35:45.800858
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        test_case_0()
    except:
        assert False, 'Failed to instantiate AnsibleJ2Vars'


# Generated at 2022-06-25 12:36:43.740207
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    str_0 = ' V\x94\x9d\x1d\x90\\\x1d\x04\xc6\xfb\x0b\xde\x9b\x99\xa6\xdf\x10\xc3'
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:36:46.605528
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    x_0 = ansible_j2_vars_0.__contains__()


# Generated at 2022-06-25 12:36:49.475797
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert ansible_j2_vars_0.__contains__(
        ansible_j2_vars_0) == bytes_0
    assert ansible_j2_vars_0.__contains__(
        ansible_j2_vars_0) == float_0


# Generated at 2022-06-25 12:36:53.984655
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__(1)


# Generated at 2022-06-25 12:36:59.140473
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)

    # Tested function
    result = ansible_j2_vars_0.__contains__(b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83')

    # Validation
    assert ((result == True) == True)


# Generated at 2022-06-25 12:37:02.090417
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:37:11.041046
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # FIXME this might be an upstream bug, where groups[0] shouldn't be required
    # in order for groups to be defined, but want to make sure it is correct
    # behavior before reporting it
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    result = ansible_j2_vars_0.__contains__('groups[0]')
    assert (result == False)


# Generated at 2022-06-25 12:37:17.413627
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    bytes_0 = b'\x9d\x11\xea\xfa\xcc\x8e>\xba/\x93\xe4\x9b\xcb'
    float_0 = -2087.87977308
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    int_0 = ansible_j2_vars_0.__len__()
    assert int_0 > -1662585856


# Generated at 2022-06-25 12:37:18.011539
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    test_case_0()


# Generated at 2022-06-25 12:37:23.143049
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\r\x82\xcb\x86\xf4\x03\xe4\x9a\xec\x05\x87\x9b'
    float_0 = 709.1426
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)



# Generated at 2022-06-25 12:38:31.845534
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)

    assert ansible_j2_vars_0['byte_0'] == ansible_j2_vars_0._templar.template(bytes_0)
    assert ansible_j2_vars_0['float_0'] == ansible_j2_vars_0._templar.template(float_0)


# Generated at 2022-06-25 12:38:38.235248
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    varname_0 = ansible_j2_vars_0.__getitem__(float_0)


# Generated at 2022-06-25 12:38:42.096659
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    bool_0 = ansible_j2_vars_0.__contains__(float_0)


# Generated at 2022-06-25 12:38:47.279931
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    ansible_j2_vars_0.__iter__()
    ansible_j2_vars_0.add_locals(float_0)


# Generated at 2022-06-25 12:38:50.213634
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    float_0 = float(1.6353751)
    assert ansible_j2_vars_0._AnsibleJ2Vars__getitem__(float_0), "__getitem__ returned incorrect value"


# Generated at 2022-06-25 12:38:58.336746
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    assert_equal(next(iter(ansible_j2_vars_0)), b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83')
    assert_equal(next(iter(ansible_j2_vars_0)), -1959.46364)


# Generated at 2022-06-25 12:39:03.922235
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)

# Generated at 2022-06-25 12:39:08.526924
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    bytes_0 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_0 = -1959.46364
    ansible_j2_vars_0 = AnsibleJ2Vars(bytes_0, float_0)
    assert ansible_j2_vars_0.__contains__(0)


# Generated at 2022-06-25 12:39:12.363589
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    bytes_2 = b'\x0f\x16\x91\xda\x9c|k\xa8D\xb83\xd8\x83'
    float_2 = -1959.46364
    ansible_j2_vars_2 = AnsibleJ2Vars(bytes_2, float_2)
    float_1 = ansible_j2_vars_2['f']
    assert float_1 is False


# Generated at 2022-06-25 12:39:14.742824
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # TODO: implement this
    raise NotImplementedError('test_AnsibleJ2Vars___getitem__ not implemented')
