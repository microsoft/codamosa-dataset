

# Generated at 2022-06-25 12:29:52.277511
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:29:58.483280
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = None
    str_0 = 'kL"(n[cn)?g*8.{E'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0)
    with pytest.raises(AnsibleError) as raised_exception:
        ansible_j2_vars_0.__getitem__('set')


# Generated at 2022-06-25 12:30:01.985795
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    obj = AnsibleJ2Vars(None, None)
    assert obj.__getitem__ is not None, "__getitem__ of AnsibleJ2Vars not implemented."


# Generated at 2022-06-25 12:30:05.741133
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = None
    str_0 = 'kL"(n[cn)?g*8.{E'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0)
    ansible_j2_vars_0.__setitem__('abc') #FIXME: Was expecting a KeyError?


# Generated at 2022-06-25 12:30:09.623336
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = None
    str_0 = '\'"]|>f?'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0)
    str_1 = '1VyR"/j{1G('
    ansible_j2_vars_0.__getitem__(str_1)


# Generated at 2022-06-25 12:30:12.720586
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = None
    str_0 = 'kL"(n[cn)?g*8.{E'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0)
    assert ansible_j2_vars_0.__getitem__(str_0) == None


# Generated at 2022-06-25 12:30:18.467621
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = None
    str_0 = 'kL"(n[cn)?g*8.{E'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0)
    str_1 = 'kL"(n[cn)?g*8.{E'
    assert ansible_j2_vars_0.__contains__(str_1) == True


# Generated at 2022-06-25 12:30:25.560427
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = None
    str_0 = 'pS+7VuKv}0l,>|_'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0)
    ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:30:31.516401
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    varname = 'J0}0+~JD:gQ[|oBj8f'
    try:
        ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0)
        ansible_j2_vars_0.__getitem__(varname)
        print('\n')
    except KeyError as e:
        print(e)
        print('\n')


# Generated at 2022-06-25 12:30:39.473934
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:30:44.632817
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    var_0 = AnsibleJ2Vars(var_0, var_0)
    var_0.__len__()


# Generated at 2022-06-25 12:30:51.614873
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    var_1 = AnsibleUndefinedVariable("AnsibleUndefinedVariable('1',)")
    var_2 = dict()
    try:
        ansible_j2_vars_0.__getitem__(var_1)
    except AnsibleUndefinedVariable as exception:
        print('Exception message (1):', exception.message)
        var_2 = exception.message
    print('var_2:', var_2)


# Generated at 2022-06-25 12:30:54.727743
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    var_1 = None
    ansible_j2_vars_0.__getitem__(var_1)

# Generated at 2022-06-25 12:30:56.947053
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    obj = AnsibleJ2Vars(None, None)
    varname = b'ansible_user_dir'
    assert obj.__getitem__(varname) is None

# Generated at 2022-06-25 12:31:01.307035
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        var_0 = None
        var_2 = None
        var_3 = None
        ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_2, var_3)
        ansible_j2_vars___getitem___0 = ansible_j2_vars_0['varname']
    except:
        pass


# Generated at 2022-06-25 12:31:08.475170
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.module_utils.six.moves.builtins import str
    from ansible.module_utils.six import iteritems
    var_0 = None
    var_1 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0, var_0)
    var_2 = None
    var = ansible_j2_vars_0.__contains__(var_2)
    var_3 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(var_3, var_0, var_0)
    var_4 = None
    var = ansible_j2_vars_1.__contains__(var_4)
    var_5 = None

# Generated at 2022-06-25 12:31:18.161876
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_values = dict(globals = dict(), locals = dict(), templar = dict(), variable = dict(), value = dict(), varname = dict())
    var_values["globals"]["ansible_check_mode"] = ansible_check_mode = dict()
    var_values["globals"]["ansible_connection"] = ansible_connection = dict()
    var_values["globals"]["ansible_facts"] = ansible_facts = dict()
    var_values["globals"]["ansible_forks"] = ansible_forks = dict()
    var_values["globals"]["ansible_host_pattern"] = ansible_host_pattern = dict()
    var_values["globals"]["ansible_host_pattern_specificity"] = ansible_host_

# Generated at 2022-06-25 12:31:25.538388
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''Unit test for method __contains__ of class AnsibleJ2Vars'''
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)

    # If the passed variable name is found in the local variables dictionary, return the
    # result of calling the built-in function __contains__ on the local variables
    # dictionary for the passed variable name.
    # If the passed variable name is found in the list of available variable names,
    # return the result of calling the built-in function __contains__ on the list of
    # available variable names for the passed variable name.

# Generated at 2022-06-25 12:31:36.383780
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class TestException(Exception):
        pass

    class MockTemplar:
        def __init__(self):
            self.available_variables = {
                'test_val': 'test_val'
            }

        def template(self, val):
            if isinstance(val, Exception):
                raise val
            else:
                return val
    test_val = 'test_val'

    # Test case with an undefined variable
    ansible_j2_vars_0 = AnsibleJ2Vars(MockTemplar(), {}, {})
    with pytest.raises(KeyError) as excinfo:
        ansible_j2_vars_0['missing_key']

    # Test case with a normal variable

# Generated at 2022-06-25 12:31:44.902884
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    ansible_j2_vars_0._templar = var_0
    ansible_j2_vars_0._locals = {}
    var_1 = True
    var_2 = None
    var_3 = None
    assert ansible_j2_vars_0._templar._is_unsafe_variable(var_0) == var_1
    assert ansible_j2_vars_0._templar._is_unsafe_variable(var_1) == var_1
    assert ansible_j2_vars_0._templar._is_unsafe_variable(var_2) == var_3

    var_0 = None


# Generated at 2022-06-25 12:31:54.524125
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # setup test variables
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    
    # run code to be tested
    ansible_j2_vars_0___len__()


# Generated at 2022-06-25 12:31:56.659983
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
  pass


# Generated at 2022-06-25 12:32:01.516357
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import pytest
    var_0 = None
    var_1 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_1)
    ansible_j2_vars_0.__contains__(var_1)
    # TODO: Need to write some tests
    # TODO: Need to write some tests


# Generated at 2022-06-25 12:32:04.921195
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    var_1 = None
    var_1 = ansible_j2_vars_0.__getitem__(var_1)


# Generated at 2022-06-25 12:32:05.501716
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert True

# Generated at 2022-06-25 12:32:11.646080
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    try:
        assert ansible_j2_vars_0.__contains__(var_0) == True
    except AssertionError as e:
        raise AssertionError(e)


# Generated at 2022-06-25 12:32:19.802704
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import hostvars
    from ansible.vars.hostvars import HostVars

    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    ansible_j2_vars_0._templar.available_variables = None
    ansible_j2_vars_0._globals = None
    ansible_j2_vars_0._locals = None
    ansible_j2_vars_0._templar.available_variables = None
    ansible_j2_vars_0._globals = None
    ansible_j2_vars_0._locals = None
    ansible_j2_vars_0._templar.available_variables

# Generated at 2022-06-25 12:32:25.111998
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_1 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(var_1, var_1)
    var_2 = "AnsibleJ2Vars"
    var_3 = "assertTrue"
    var_4 = "assertFalse"
    ansible_j2_vars_1.__contains__((var_2 or var_3 or var_4))


# Generated at 2022-06-25 12:32:26.185342
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert 0 == 0



# Generated at 2022-06-25 12:32:29.172270
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Assert that this is a function
    assert_equal(callable(AnsibleJ2Vars.__contains__), True)


# Generated at 2022-06-25 12:32:40.231379
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_1 = None
    var_2 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(var_1, var_2)
    try:
        ansible_j2_vars_1['varname']
        # No exception thrown: Test has failed
        assert False
    except KeyError:
        # Exception thrown: Test has passed
        pass


# Generated at 2022-06-25 12:32:43.490056
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    try:
        ansible_j2_vars_0.__getitem__('foo')
        assert(False)
    except KeyError:
        pass


# Generated at 2022-06-25 12:32:48.948547
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = "a"
    var_1 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_1, var_1)
    var_2 = ansible_j2_vars_0.__getitem__(var_0)


# Generated at 2022-06-25 12:32:53.577411
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    ansible_j2_vars_1 = ansible_j2_vars_0.__contains__(var_0)
    print(ansible_j2_vars_1)


# Generated at 2022-06-25 12:33:03.648206
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible_collections.ansible.community.plugins.module_utils.facts.system.distribution.el import El
    from ansible.vars.hostvars import HostVars
    templar_0 = Templar(loader=None, variables={})
    ansible_j2_vars_0 = AnsibleJ2Vars(templar_0, None)
    ansible_j2_vars_0._templar.available_variables = {"vars": HostVars(ansible_facts=None)}
    ansible_j2_vars = ansible_j2_vars_0.__getitem__("vars")
    assert isinstance(ansible_j2_vars, HostVars) == True, "Value not as expected"

# Generated at 2022-06-25 12:33:07.382154
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    with pytest.raises(AnsibleUndefinedVariable):
        ansible_j2_vars_0.__getitem__('varname')


# Generated at 2022-06-25 12:33:13.404496
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    try:
        ansible_j2_vars = AnsibleJ2Vars(None, None)
    except Exception as e:
        print(f'Failed to create object: {e}')
        raise

    try:
        print(ansible_j2_vars.__iter__())
    except Exception as e:
        print(f'Exception caught when calling method __iter__: {e}')
        raise



# Generated at 2022-06-25 12:33:16.236421
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    assert ansible_j2_vars_0.__len__() >= 0


# Generated at 2022-06-25 12:33:23.163663
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_1, var_2)
    assert (ansible_j2_vars_0.__contains__(var_3) == False)


# Generated at 2022-06-25 12:33:30.891506
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)
    ansible_j2_vars_1 = AnsibleJ2Vars(None, None)
    ansible_j2_vars_2 = AnsibleJ2Vars(None, None)
    ansible_j2_vars_3 = AnsibleJ2Vars(None, None)
    ansible_j2_vars_4 = AnsibleJ2Vars(None, None)

if __name__ == "__main__":
    test_case_0()

    # Unit test for method __getitem__ of class AnsibleJ2Vars
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:33:50.200730
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import ansible.parsing.dataloader
    import ansible.vars.hostvars

    var_0 = None
    var_1 = ansible.vars.hostvars.HostVars()
    var_2 = ansible.parsing.dataloader.DataLoader(var_0)
    var_3 = dict()

    # Test __init__
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(var_0, var_1)
    ansible_j2_vars_2 = AnsibleJ2Vars(var_0, var_2)

# Generated at 2022-06-25 12:33:53.951592
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    var_1 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(var_1, var_1)
    var_2 = None
    var_3 = None
    ansible_j2_vars_2 = AnsibleJ2Vars(var_2, var_3)

# Generated at 2022-06-25 12:33:55.332126
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert test_case_0() is None


# Generated at 2022-06-25 12:33:58.655539
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = None
    var_1 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    ansible_j2_vars_0 = AnsibleJ2Vars(var_1, var_1)


# Generated at 2022-06-25 12:34:06.725037
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:34:09.146729
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    var_1 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(var_1, var_1)
    ansible_j2_vars_1.__len__()


# Generated at 2022-06-25 12:34:18.158057
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_0 = {
        'ansible_variable_path': '.ansible/tmp',
        'environment': {},
        'template': None,
    }
    var_1 = '/private/tmp/ansible/test'
    var_2 = {
        'ansible_forks': 5,
        'ansible_tmpdir': '/tmp/ansible-tmp-',
    }
    var_3 = {'ansible_variable_path': '.ansible/tmp'}
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_1, var_2)
    assert ansible_j2_vars_0.__contains__('ansible_tmpdir') == True

# Generated at 2022-06-25 12:34:21.185087
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    var_1 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(var_1, var_1)
    var_2 = ansible_j2_vars_1.__iter__()
    assert var_2 is not None


# Generated at 2022-06-25 12:34:25.232212
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    assert True


# Generated at 2022-06-25 12:34:35.341751
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Create an object of AnsibleJ2Vars
    var_1 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(var_1, var_1)

    # Create an instance of KeyError with exception value
    key_error_exception_value = 'undefined variable: %s'

    # Call method __getitem__ with an instance of KeyError
    try:
        ansible_j2_vars_1.__getitem__(None)
    except KeyError as instance:
        if instance.args[0] != key_error_exception_value:
            print('Exception different from expected.\nExpected: {}.\nReceived: {}.'.format(key_error_exception_value, instance.args[0]))
        else:
            print('Exception as expected.')

# Generated at 2022-06-25 12:35:02.363156
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    ansible_j2_vars_0.__getitem__(var_0)


# Generated at 2022-06-25 12:35:06.807602
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    ansible_j2_vars_0.__contains__('a')


# Generated at 2022-06-25 12:35:11.017411
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    size = ansible_j2_vars_0.__len__()
    assert size == 0


# Generated at 2022-06-25 12:35:13.526743
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
  var_0 = None
  ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
  assert ansible_j2_vars_0 == None


# Generated at 2022-06-25 12:35:15.502338
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_0 = None
    assert (AnsibleJ2Vars.__contains__(var_0, var_0) == NotImplemented)


# Generated at 2022-06-25 12:35:19.949393
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    var_0 = None
    var_1 = None
    var_2 = "test"
    ansible_j2_vars_0.__contains__(var_0)
    ansible_j2_vars_0.__contains__(var_1)
    ansible_j2_vars_0.__contains__(var_2)


# Generated at 2022-06-25 12:35:22.261039
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    assert ansible_j2_vars_0.__getitem__("fV$1_") == None


# Generated at 2022-06-25 12:35:23.263153
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass


# Generated at 2022-06-25 12:35:26.390205
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    varname = None # TODO
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)
    ansible_j2_vars_0.__getitem__(varname)


# Generated at 2022-06-25 12:35:29.581046
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    assert ansible_j2_vars_0.__len__() == 0


# Generated at 2022-06-25 12:36:22.886351
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_1 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(var_1, var_1)
    # Test for raise of AnsibleUndefinedVariable in case of exception
    from ansible.parsing.vault import VaultLib
    vault_lib_1 = VaultLib()
    ansible_j2_vars_1._templar._vault = vault_lib_1
    try:
        for var_2 in range(1):
            try:
                # Test for AnsibleUndefinedVariable in case of exception
                ansible_j2_vars_1['']
            except KeyError:
                raise AssertionError('AnsibleUndefinedVariable not raised')
    except AnsibleUndefinedVariable:
        pass


# Generated at 2022-06-25 12:36:26.530776
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = None
    var_1 = None
    assert "undefined variable: %s" % var_0 == ansible_j2_vars_0[var_0]


# Generated at 2022-06-25 12:36:27.400294
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert 1 == 1



# Generated at 2022-06-25 12:36:36.564619
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = EvalEnvironment()
    var_1 = None
    var_0.j2_vars = var_1
    var_0.vars = var_1
    var_0.searchpath = var_1
    var_0.available_variables = var_1
    var_0.hostvars = var_1
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    try:
        var_2 = "vars"
        ansible_j2_vars_0.__getitem__(var_2)
        assert False # This line should never be reached
    except KeyError:
        var_3 = True
    else:
        var_3 = False
    assert var_3


# Generated at 2022-06-25 12:36:45.809708
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    args = {"AnsibleJ2Vars": {"vars": {"str": "str", "list": ["A", "B"]}}}
    obj = args["AnsibleJ2Vars"]
    ansible_j2_vars_0 = AnsibleJ2Vars(obj["templar"], obj["globals"], obj["locals"])
    var_1 = ansible_j2_vars_0.__getitem__("vars")
    var_1_0 = var_1
    var_1_1 = var_1_0["str"]
    var_2 = ansible_j2_vars_0.__getitem__("vars")
    var_2_0 = var_2
    var_2_1 = var_2_0["list"]
    var_3 = var_1_1

# Generated at 2022-06-25 12:36:48.582643
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_1 = None
    var_2 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(var_1, var_1, var_2)
    assert type(ansible_j2_vars_1) == AnsibleJ2Vars


# Generated at 2022-06-25 12:36:51.592218
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    params0 = {'a': 'b'}
    var_0 = AnsibleJ2Vars(params0, params0)
    var_1 = 'a'
    result = var_0.__getitem__(var_1)
    assert result == 'b'


# Generated at 2022-06-25 12:36:58.243958
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_1 = None
    var_2 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(var_1, var_1, var_2)
    var_3 = None
    var_4 = None
    ansible_j2_vars_2 = AnsibleJ2Vars(var_3, var_3, var_4)
    var_5 = None
    var_6 = None
    ansible_j2_vars_3 = AnsibleJ2Vars(var_5, var_5, var_6)
    var_7 = None
    var_8 = None
    ansible_j2_vars_4 = AnsibleJ2Vars(var_7, var_7, var_8)
    var_9 = None
    ansible_j2_v

# Generated at 2022-06-25 12:37:02.573231
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        # FIXME
        # this test is not correct and should be fixed
        return
        '''
        AnsibleJ2Vars.__getitem__(self, varname)
        '''
        pass
    except Exception:
        return


# Generated at 2022-06-25 12:37:11.228490
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Run method in a try except to capture any exceptions
    try:
        # Instantiate object
        var_0 = AnsibleJ2Vars(None)
        # Test __contains__ of class AnsibleJ2Vars
        ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
        if ansible_j2_vars_0.__contains__(var_0):
            # Test __getitem__ of class AnsibleJ2Vars
            ansible_j2_vars_0.__getitem__(var_0)
    except Exception as e:
        raise(e)


# Generated at 2022-06-25 12:39:18.953808
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    var_1 = None
    ansible_j2_vars_1 = AnsibleJ2Vars(var_1, var_1)
    ansible_j2_vars_1.__getitem__(var_1)


# Generated at 2022-06-25 12:39:21.357670
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = None
    var_1 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    with pytest.raises(Exception):
        ansible_j2_vars_0[var_1]


# Generated at 2022-06-25 12:39:23.905813
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # Pass var_0 and var_1 to AnsibleJ2Vars.__getitem__
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    ansible_j2_vars_0.__getitem__(var_1)


# Generated at 2022-06-25 12:39:26.230723
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    try:
        ansible_j2_vars_0.__iter__()
    except:
        pass


# Generated at 2022-06-25 12:39:28.888778
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)
    ansible_j2_vars_0.__contains__(str(''))


# Generated at 2022-06-25 12:39:31.050198
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    var_0 = None
    ansible_j2_vars_0 = AnsibleJ2Vars(var_0, var_0)


# Generated at 2022-06-25 12:39:32.580670
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    var_0 = None
    ansible_j2_vars_obj_0 = AnsibleJ2Vars(var_0, var_0)
    assert callable(getattr(ansible_j2_vars_obj_0, "__iter__"))
