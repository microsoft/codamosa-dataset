

# Generated at 2022-06-25 12:29:41.521188
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'vblJEtjmiCe8'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, dict_0)
    try:
        ansible_j2_vars_0[str_0]
        assert False, "AnsibleUndefinedVariable not raised"
    except AnsibleUndefinedVariable as e:
        assert str(e) == "undefined variable: vblJEtjmiCe8"


# Generated at 2022-06-25 12:29:50.007092
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'asRtBjm4DBva'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_1 = AnsibleJ2Vars(str_0, str_0, dict_0)

    assert ansible_j2_vars_1.__contains__(str_0) == True
    assert ansible_j2_vars_1.__contains__(str_0) != False


# Generated at 2022-06-25 12:29:57.137109
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'eIIckSLjk8y8'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, dict_0)
    assert ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:30:04.048784
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = 'eIIckSLjk8y8'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, dict_0)
    assert ansible_j2_vars_0.__init__(str_0, str_0, dict_0) == None


# Generated at 2022-06-25 12:30:12.654227
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars(AnsibleJ2Vars, AnsibleJ2Vars, AnsibleJ2Vars)
    ansible_j2_vars_1 = ansible_j2_vars_0.add_locals(AnsibleJ2Vars)
    str_0 = 'eIIckSLjk8y8'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_2 = AnsibleJ2Vars(str_0, str_0, dict_0)
    ansible_j2_vars_3 = ansible_j2_vars_2.add

# Generated at 2022-06-25 12:30:20.010411
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'eIIckSLjk8y8'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, dict_0)
    # assert_equal
    assert_equal(ansible_j2_vars_0['eIIckSLjk8y8'], 'eIIckSLjk8y8')


# Generated at 2022-06-25 12:30:24.549274
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # Case 1:
    test_case_0()

    # Case 2:
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)


# Generated at 2022-06-25 12:30:33.870194
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    dict_0 = {'eIIckSLjk8y8': 'eIIckSLjk8y8', 'eIIckSLjk8y8': 'eIIckSLjk8y8', 'eIIckSLjk8y8': 'eIIckSLjk8y8', 'eIIckSLjk8y8': 'eIIckSLjk8y8', 'eIIckSLjk8y8': 'eIIckSLjk8y8'}
    ansible_j2_vars_0 = AnsibleJ2Vars('eIIckSLjk8y8', 'eIIckSLjk8y8', dict_0)

# Generated at 2022-06-25 12:30:44.378805
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'eIIckSLjk8y8'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, dict_0)

    #substitute ansible_j2_vars_0.__getitem__(str_0) with str_0
    #substitute str_0 with str_0
    #substitute str_0 with str_0
    #substitute ansible_j2_vars_0.__getitem__(str_0) with str_0
    #substitute str_0 with str_0
    #subst

# Generated at 2022-06-25 12:30:52.342164
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    ansible_j2_vars_0 = None
    str_0 = 'eIIckSLjk8y8'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    dict_2 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}

# Generated at 2022-06-25 12:31:02.159302
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'eaYFZ1BVq4l4'
    str_1 = 'HwGz6S8wrCdR'
    ansible_j2_vars_2 = AnsibleJ2Vars(str_0, str_0, str_0)
    ansible_undefined_variable_3 = AnsibleUndefinedVariable(str_0)
    ansible_error_4 = AnsibleError(str_0)
    ansible_j2_vars_2.__getitem__(str_1)


# Generated at 2022-06-25 12:31:05.118514
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:31:08.353194
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None, None)

    assert ansible_j2_vars_0._templar == None
    assert ansible_j2_vars_0._globals == None
    assert ansible_j2_vars_0._locals == None


# Generated at 2022-06-25 12:31:11.858953
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str = 'jx6wHp6movWT'
    ansible_j2_vars = AnsibleJ2Vars(str, str, str)
    assert ansible_j2_vars.__iter__() is not None


# Generated at 2022-06-25 12:31:15.014672
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:31:18.925089
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    ansible_j2_vars_0.__getitem__('jx6wHp6movWT')

# Generated at 2022-06-25 12:31:26.297353
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    def test_AnsibleJ2Vars___getitem___local_vars():
        @patch('ansible.template.AnsibleJ2Vars._templar', new_callable=PropertyMock, create=True)
        @patch('ansible.template.AnsibleJ2Vars._globals', new_callable=PropertyMock, create=True)
        @patch('ansible.template.AnsibleJ2Vars._locals', new_callable=PropertyMock, create=True)
        def test_AnsibleJ2Vars___getitem___local_vars_impl(self, _locals, _globals, _templar):
            _locals.get.return_value = 'local'
            assert _locals.get.call_count == 0
            assert _tem

# Generated at 2022-06-25 12:31:34.001505
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Set up test parameters
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)

    # Call the tested method
    ansible_j2_vars_0_iter = ansible_j2_vars_0.__iter__()

    # Check the results
    assert( str_0 == ansible_j2_vars_0_iter )

# Generated at 2022-06-25 12:31:39.681467
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '\x1c\x0c\x01\x16\x1f\x00\r\x0b\x1f\x14\x0f\x11\x00\x0e\x12'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:31:44.858827
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    varname_0 = 'jx6wHp6movWT'
    # Check that 'jx6wHp6movWT'  is in ansible_j2_vars_0
    assert varname_0  in ansible_j2_vars_0
   


# Generated at 2022-06-25 12:31:53.895264
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    k = 'HsQCs8f7Kj72'
    ansible_j2_vars_0.__getitem__(k)


# Generated at 2022-06-25 12:31:59.711364
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    # Test case 0
    assert (ansible_j2_vars_0.__contains__(str_0)) == True



# Generated at 2022-06-25 12:32:10.789826
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    for x in ansible_j2_vars_0:
        pass

    # Taint variables
    if isinstance(x, str):
        x = str_0

    # Unit test for method __len__ of class AnsibleJ2Vars
    ansible_j2_vars_0.__len__()

    # Taint variables
    x = str_0

    # Unit test for method __contains__ of class AnsibleJ2Vars
    ansible_j2_vars_0.__contains__(x)

    # Taint variables
    if isinstance(x, str):
        x = str

# Generated at 2022-06-25 12:32:16.903668
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '9XOq3qGrTwHW'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    varname_0 = 'JopSwn'
    print(ansible_j2_vars_0.__getitem__(varname_0))


# Generated at 2022-06-25 12:32:20.434581
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'X6OdsT6VpU6P'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)


# Generated at 2022-06-25 12:32:24.139431
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_0 = 'oGw3qDNgiCz8'
    ansible_j2_vars_1 = AnsibleJ2Vars(str_0, str_0, str_0)
    test_case_0()

# Generated at 2022-06-25 12:32:29.521358
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    result_0 = ansible_j2_vars_0.__contains__(str_0)
    assert result_0 == False



# Generated at 2022-06-25 12:32:32.021116
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)

    result = ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:32:32.888825
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()


# Generated at 2022-06-25 12:32:39.274212
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # __contains__
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    if ansible_j2_vars_0.__contains__(str_0):
        ansible_j2_vars_0.__contains__(str_0)
    else:
        ansible_j2_vars_0.__contains__(str_0)

# Generated at 2022-06-25 12:32:52.166726
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'l4p4d4w4k4'
    str_1 = 'P5r5v5V5y5'
    str_2 = 'dlbh7GYFZNo8'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    ansible_j2_vars_0.add_locals(ansible_j2_vars_0)
    ansible_j2_vars_0.__contains__(str_1)
    ansible_j2_vars_0.__getitem__(str_2)


# Generated at 2022-06-25 12:32:54.068094
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Call the test function

    test_case_0()

# Generate unit test for each test case

# Generated at 2022-06-25 12:32:58.823477
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    len_0 = ansible_j2_vars_0.__len__()
    print(len_0)


# Generated at 2022-06-25 12:33:06.678665
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    str_1 = 'yVE6U0PbOAnl'
    str_2 = 'VsrEgH8C1VJK'
    str_3 = 'N6o0dVzh0FJZ'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_1, str_2, str_3)
    assert ansible_j2_vars_0._templar == str_1
    assert ansible_j2_vars_0._globals == str_2
    assert ansible_j2_vars_0._locals == str_3


# Generated at 2022-06-25 12:33:08.869116
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'O3qbFFD6M2'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    assert ansible_j2_vars_0.__getitem__(str_0) == str_0

# Generated at 2022-06-25 12:33:12.870359
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    try:
        str_0 = 'pGJsqVj0L0qs'
        test_case_0()
    except Exception as exception:
        assert type(exception) == ValueError or type(exception) == NameError


# Generated at 2022-06-25 12:33:23.098675
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:33:31.673323
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = 'jx6wHp6movWT'
    dict_0 = dict()
    dict_0['x'] = str_0
    dict_1 = dict()
    dict_1['h'] = str_0
    dict_2 = dict()
    dict_2['f'] = str_0
    dict_3 = dict()
    dict_3['x'] = dict_0
    dict_3['h'] = dict_1
    dict_3['f'] = dict_2
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, dict_3)
    iterator = iter(ansible_j2_vars_0)
    returned_value = next(iterator)
    assert returned_value == 'x'
    returned_value = next(iterator)

# Generated at 2022-06-25 12:33:35.421139
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    #
    result = ansible_j2_vars_0.__len__()
    assert result >= -1


# Generated at 2022-06-25 12:33:42.154069
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_1 = 'M9XqE3iSssZS'
    ansible_j2_vars_1 = AnsibleJ2Vars(str_1, str_1, str_1)
    ansible_j2_vars_2 = ansible_j2_vars_1.__iter__()


# Generated at 2022-06-25 12:33:56.019086
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
  str_0 = 'pGJsqVj0L0qs'
  test_AnsibleJ2Vars = AnsibleJ2Vars(str_0, str_0, str_0)
  str_1 = 'sV7pHZvYUNn7'
  test_AnsibleJ2Vars_0 = test_AnsibleJ2Vars._templar
  test_AnsibleJ2Vars_1 = test_AnsibleJ2Vars._globals
  test_AnsibleJ2Vars_2 = test_AnsibleJ2Vars._locals
  test_AnsibleJ2Vars_3 = test_AnsibleJ2Vars.__iter__()

# Generated at 2022-06-25 12:33:59.865727
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'pGJsqVj0L0qs'
    str_1 = 'lcxuBI0oKjX9kYMGpnRZ'
    str_2 = 'd3qf3unwzp5B5CIPI5p9YcfkN7d1UfI'
    str_3 = 'C1wD29x6xKM6'
    str_4 = 'TgkcT0Zo0p8W0szGvxCx'
    str_5 = 'qZ0EWvkp92pDtOJzHKWdPtRvztMy'
    str_6 = 'Yf3vEjaPxiFCaDmZtKlztPvRxKNL'

# Generated at 2022-06-25 12:34:03.338687
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'pGJsqVj0L0qs'
    str_1 = 'WMFvYUi0YUyf'
    str_2 = 'pGJsqVj0L0qs'

# Generated at 2022-06-25 12:34:05.522433
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:34:14.411671
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # In this test, we assume we have a dictionary
    # my_dict = { 'key1': value1, 'key2': value2}
    # and the dictionary key we want to retrieve is 'key1'
    my_dict = {}
    key = 'key1'
    value1 = test_case_0()
    value2 = 'value2'
    my_dict[key] = value1
    my_dict[key] = value2
    # Create an instance of AnsibleJ2Vars
    my_J2Vars = AnsibleJ2Vars(my_dict, key)
    # Get the value corresponding to the key
    key_value = my_J2Vars['key1']
    assert key_value == 'value2'

# Generated at 2022-06-25 12:34:18.387315
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'pGJsqVj0L0qs'
    str_1 = '\x5C\x5C\x5C\x5C\x5C\x5C'
    str_2 = '\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C\x5C'


# Generated at 2022-06-25 12:34:20.008661
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    case_test_0 = AnsibleJ2Vars()
    case_test_0.__getitem__(str_0)
    return


# Generated at 2022-06-25 12:34:21.598932
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansibleJ2Vars_inst = AnsibleJ2Vars()
    assert ansibleJ2Vars_inst.__contains__() == 'pGJsqVj0L0qs'


# Generated at 2022-06-25 12:34:33.455848
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from jinja2.runtime import Context
    from jinja2.loaders import DictLoader
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager.__setitem__(str_0, None)
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}
    variable_manager.host_vars = {}
    variable_manager.group_vars = {}
    variable_manager.set_available_variables(loader=DictLoader({}), variables=variable_manager.get_vars(loader=DictLoader({})))
    templar = Templar(loader=DictLoader({}), variables=variable_manager.get_vars(loader=DictLoader({})))
    globals = {}
    locals_ = {}
    ans

# Generated at 2022-06-25 12:34:42.494022
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    vault_pass = 'Abcd1234'
    # create a vault secret to test with
    vault_file_path = 'test.secret'
    vault_secret = 'hello, this is a secret'

    with open(vault_file_path, 'wb') as f:
        f.write(VaultLib(vault_pass).encrypt(vault_secret))

    # test
    templar = Templar(vault_passwords=[vault_pass])
    ansible_j2_vars = AnsibleJ2Vars(templar, dict(junk='junk', secret_file=vault_file_path))
    assert 'junk' in ansible_j2_vars
    assert 'secret'

# Generated at 2022-06-25 12:34:51.552785
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        obj_test_0 = AnsibleJ2Vars()
        obj_test_1 = AnsibleJ2Vars()
        obj_test_2 = AnsibleJ2Vars()
        obj_test_3 =  obj_test_0. __getitem__(str_0)
        obj_test_4 =  obj_test_1. __getitem__(str_0)
        obj_test_5 =  obj_test_2. __getitem__(str_0)
        assert True
    except KeyError as e:
        print(e)
        assert True
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 12:34:52.749322
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'pGJsqVj0L0qs'


# Generated at 2022-06-25 12:35:02.440141
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:35:05.160349
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'pGJsqVj0L0qs'


# Generated at 2022-06-25 12:35:07.293494
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        str_0 = 'uKsHs0sVu2E0'
    except:
        return False
    else:
        return True


# Generated at 2022-06-25 12:35:15.796455
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'pGJsqVj0L0qs'
    str_1 = 'U0LjFpfBBL6H'
    str_2 = 'xgvFZ7YKCRgl'
    str_3 = 'f3y7DQKQ5X5S'
    str_4 = '77Y8GkfpdnBw'
    str_5 = '8tB9JtXuPtTk'
    str_6 = 'wjDKdTpWG8Jv'
    str_7 = 's51CFkY8HidZ'
    str_8 = 'vgUHW8U6yCp6'


# Generated at 2022-06-25 12:35:17.029042
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'R/Rj/AQN/wkxDVg=='


# Generated at 2022-06-25 12:35:17.693800
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'pGJsqVj0L0qs'


# Generated at 2022-06-25 12:35:18.209423
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert (test_case_0())



# Generated at 2022-06-25 12:35:18.885934
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'cG2My'


# Generated at 2022-06-25 12:35:33.018720
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'pGJsqVj0L0qs'
    str_1 = 'F0J6UfhQ9XW6'
    str_2 = 'GZ7V1Zc6B0T6'
    str_3 = 'pXE0zG7Vyu4O'
    str_4 = 'AKHJ7pt5rBzg'
    # str_5 = 'HriRKkRnkIgP'
    str_5 = 'pXE0zG7Vyu4O'
    str_6 = 'kGQ2Y8ZJYwYw'
    str_7 = 'pXE0zG7Vyu4O'
    str_8 = 'kGQ2Y8ZJYwYw'

# Generated at 2022-06-25 12:35:33.948856
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    test_case_0()


# Generated at 2022-06-25 12:35:40.316314
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    params = {
        'templar': Templar(loader=DataLoader(), variables={}),
        'globals': {},
        'locals': {}
    }
    ansible_j2_vars = AnsibleJ2Vars(**params)
    varname = 'pGJsqVj0L0qs'

    try:
        ansible_j2_vars[varname]
        assert False, 'expected KeyError'
    except KeyError as e:
        assert True, 'expected KeyError'
        assert varname in e.message, 'varname in e.message'


# Generated at 2022-06-25 12:35:49.146948
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'pGJsqVj0L0qs'
    str_1 = 'pGJsqVj0L0qs'
    str_2 = 'pGJsqVj0L0qs'
    str_3 = 'pGJsqVj0L0qs'
    str_4 = 'pGJsqVj0L0qs'
    str_5 = 'pGJsqVj0L0qs'
    str_6 = 'pGJsqVj0L0qs'
    str_7 = 'pGJsqVj0L0qs'
    str_8 = 'pGJsqVj0L0qs'
    str_9 = 'pGJsqVj0L0qs'
    str_10 = 'pGJsqVj0L0qs'
   

# Generated at 2022-06-25 12:35:55.133485
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'pGJsqVj0L0qs'

    #
    # ansible.module_utils.jinja2.AnsibleJ2Vars.__contains__ test case 0 (unittest_data/ansible_module_utils_jinja2_AnsibleJ2Vars_contains_0.txt)
    #
    str_0 = 'pGJsqVj0L0qs'
    return str_0


# Generated at 2022-06-25 12:36:01.005922
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = Templar()
    globals = {}
    locals = {}
    a = AnsibleJ2Vars(templar, globals, locals)
    str_1 = str(a.__getitem__(str_0))

    assert "Secrets are" in str_1, "Assertion error: expected <Secrets are> in <%s>" % (str_1)


# Generated at 2022-06-25 12:36:03.144709
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_1 = test_case_0()
    str_2 = 'Zt0DZNwrypmE'


# Generated at 2022-06-25 12:36:04.591631
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        test_case_0()
    except:
        return False
    else:
        return True

# Generated at 2022-06-25 12:36:06.933617
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    obj = AnsibleJ2Vars('p8VspW', {})
    str_0 = 'pGJsqVj0L0qs'
    obj.__getitem__(str_0)


# Generated at 2022-06-25 12:36:08.844144
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'pGJsqVj0L0qs'
    assert test_case_0() == str_0


# Generated at 2022-06-25 12:36:14.680085
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    try:
        test_case_0()
    except:
        print('AnsibleJ2Vars.test_case_0 failed')


# Generated at 2022-06-25 12:36:20.282513
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test 0: Test no args
    try:
        test_case_0()
    except NameError as ne:
        print('Name error: %s' % ne)
    except StringError as se:
        print('String error: %s' % se)
    except AssertionError:
        print('Assertion error')
    except TypeError:
        print('Type error')
    except:
        print('Unexpected error: %s' % sys.exc_info()[0])
        raise


# Generated at 2022-06-25 12:36:26.595804
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'pGJsqVj0L0qs'
    str_1 = 'pGJsqVj0L0qs'
    str_2 = 'pGJsqVj0L0qs'
    str_3 = 'pGJsqVj0L0qs'
    str_4 = 'pGJsqVj0L0qs'
    str_5 = 'pGJsqVj0L0qs'
    str_6 = 'pGJsqVj0L0qs'
    str_7 = 'pGJsqVj0L0qs'
    str_8 = 'pGJsqVj0L0qs'
    str_9 = 'pGJsqVj0L0qs'
    str_10 = 'pGJsqVj0L0qs'
   

# Generated at 2022-06-25 12:36:27.831992
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'hbEjgX9Fpe'


# Generated at 2022-06-25 12:36:28.789482
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    
    pass



# Generated at 2022-06-25 12:36:30.595430
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ansible_j2vars_0 = AnsibleJ2Vars()
    assert ansible_j2vars_0 is not None

# Generated at 2022-06-25 12:36:32.020835
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert (test_case_0()) == 'pGJsqVj0L0qs'


# Generated at 2022-06-25 12:36:42.224270
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    if str_0:
        assert str_0
        assert str_0 is not None
    str_1 = 'FnPJOHdA9Xhq'
    if str_1:
        assert str_1
        assert str_1 is not None
    ansible_j2vars_0 = AnsibleJ2Vars()
    ansible_j2vars_1 = ansible_j2vars_0[str_0]
    assert ansible_j2vars_1
    assert ansible_j2vars_1 is not None
    ansible_j2vars_2 = ansible_j2vars_1[str_1]
    assert ansible_j2vars_2
    assert ansible_j2vars_2 is not None

# Generated at 2022-06-25 12:36:44.972649
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansiblej2vars = AnsibleJ2Vars(str_0)
    key = 'key'
    assert ansiblej2vars.__getitem__(key) == 'value'


# Generated at 2022-06-25 12:36:45.773416
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    locals()


# Generated at 2022-06-25 12:36:56.254921
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # __getitem__ is a special method, to use it you need to use myObjectName[myKey] instead of myObjectName.__getitem__(myKey)
    ansible_j2_vars_1 = AnsibleJ2Vars(1, 1, 1)
    ansible_j2_vars_1[1]
    ansible_j2_vars_1[""]
    ansible_j2_vars_1[1]
    ansible_j2_vars_1[1]
    ansible_j2_vars_1[""]
    ansible_j2_vars_1[1]
    ansible_j2_vars_1[1]
    ansible_j2_vars_1[""]
    ansible_j2_vars_1[1]
   

# Generated at 2022-06-25 12:37:01.043103
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'Zrfv'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    str_1 = 'NjbsQ2n0'
    #__getitem__(str_1)

# Generated at 2022-06-25 12:37:11.725370
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    str_0 = 'dYzY1gTVcoF'
    int_0 = 13
    str_1 = 'a9X0xmH4O4Q'
    str_2 = 'sWySlSqSbxy'
    str_3 = 'qZN6zgymi6h'
    str_4 = '8U6rJ2flVhU'
    str_5 = 'CukGn7VhYyA'
    str_6 = 'uHAJ1BdZl9X'
    str_7 = 'YU6zBJAFGF8'
    str_8 = 'r6N9RJZ8xNx'
    str_9 = str_2
    int_1 = 11


# Generated at 2022-06-25 12:37:15.552849
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'J3mT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:37:18.901788
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    str_0 = 'afJY'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)

    assert ansible_j2_vars_0[str_0] == str_0


# Generated at 2022-06-25 12:37:23.171411
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:37:25.766732
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    try:
        ansible_j2_vars_0.__contains__(str_0)
    except Exception as e:
        assert False


# Generated at 2022-06-25 12:37:28.053304
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # FIXME: this isn't really a unit test...
    test_case_0()


# Generated at 2022-06-25 12:37:31.679661
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:37:38.490860
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'QXC1cX7XXY'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0)
    ansible_j2_vars_0 = ansible_j2_vars_0.add_locals(str_0)
    ansible_j2_vars_0.__getitem__(str_0)
    ansible_j2_vars_0.__contains__(str_0)

# Generated at 2022-06-25 12:37:48.070725
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    print(__file__)
    test_case_0()


if __name__ == "__main__":          # pragma: no cover
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:37:58.376393
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'wzcKPiq'
    str_1 = 'RjKg6U1l0U'
    str_2 = 'd4yq3D'
    str_3 = '8ijr9Eq3'
    str_4 = 'uRkD1k7'
    str_5 = 'VQeWl'
    str_6 = 'i75hKwm'
    str_7 = 'aYamK'
    str_8 = '9vMjDh'
    str_9 = '5c5pOeO'
    str_10 = 'PbuXVC3q'
    str_11 = 'lNgWVOzSN'
    
    # Test with a key in self._locals
    ansible_j2_vars_0 = Ans

# Generated at 2022-06-25 12:38:03.793682
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    str_1 = '9M4n4F'
    ansible_j2_vars_0.__contains__(str_1)


# Generated at 2022-06-25 12:38:07.608887
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    try:
        ansible_j2_vars_0.__contains__(str_0)
    except NameError:
        pass


# Generated at 2022-06-25 12:38:14.564125
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '8nqT9TvhYjEi'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    # FIXME broken, what should this be returning?
    # keys expected to be <type 'set'> got dict instead
    #ansible_j2_vars_0.__getitem__(str_0)


# Generated at 2022-06-25 12:38:21.420631
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '*'
    str_1 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_1, str_1)
    str_2 = 'GnksBGbIwDol'
    assert ansible_j2_vars_0[str_2] == 'GnksBGbIwDol'


# Generated at 2022-06-25 12:38:27.047122
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'jx6wHp6movWT'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)

    ret_a = ansible_j2_vars_0.__contains__('orlFJD')
    return ret_a


# Generated at 2022-06-25 12:38:29.623193
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    varname = 'wzzw'
    result_0 = ansible_j2_vars_0.__getitem__(varname)


# Generated at 2022-06-25 12:38:31.253996
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass


# Generated at 2022-06-25 12:38:34.871207
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = 'O9MYmLt95O'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0)
    int_0 = ansible_j2_vars_0.__len__()
    print(int_0)


# Generated at 2022-06-25 12:38:58.908825
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_1 = '7BkCj2uI7AgPoC'
    str_2 = '07BZIn9vY8'
    str_3 = 'LJKKqz3qr5'
    str_4 = 'Z5Y0Vgjo55'
    str_5 = 'KjPdzAtwUB'
    str_6 = 'Nx1YX9DR0C'
    str_7 = 'Lq3qGwQr0m'
    str_8 = '6U9QW8qn6U20J6'

    ansible_j2_vars_0 = AnsibleJ2Vars(str_1, str_2, str_3, str_4, str_5, str_6, str_2, str_7, str_8)


# Generated at 2022-06-25 12:39:07.706937
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert 'error' in globals()  # name error will exist if __getitem__ raises an exception
    try:
        ansible_j2_vars_0 = AnsibleJ2Vars(error, error, error)
    except Exception as e:
        assert isinstance(e, KeyError)
    try:
        ansible_j2_vars_1 = AnsibleJ2Vars(error, error, error)
    except Exception as e:
        assert isinstance(e, KeyError)
    try:
        ansible_j2_vars_2 = AnsibleJ2Vars(error, error, error)
    except Exception as e:
        assert isinstance(e, KeyError)

# Generated at 2022-06-25 12:39:10.013894
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    keys = set()
    keys.update(self._templar.available_variables, self._locals, self._globals)
    return iter(keys)


# Generated at 2022-06-25 12:39:17.554458
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = 'jx6wHp6movWT'
    dict_0 = dict()
    dict_0['ansible_facts'] = dict_0
    dict_1 = dict()
    dict_1['ansible_facts'] = dict_1
    dict_2 = dict()
    dict_2['ansible_facts'] = dict_2
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1, dict_2)
    assert not (ansible_j2_vars_0.__iter__())

test_case_0()
test_AnsibleJ2Vars___iter__()

# Generated at 2022-06-25 12:39:24.151795
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # first check that we can access a variable that comes from the
    # hostvars dict and not the templar object, which should return a
    # direct lookup on the variable name w/o calling template
    hostvars = dict(foo='bar')
    templar = dict()
    templar.available_variables = dict(bar='baz')
    ans_j2_vars = AnsibleJ2Vars(templar, hostvars, locals=None)
    assert ans_j2_vars['foo'] == 'bar'

    # next check that we can access a variable that comes from the
    # templar object and not the hostvars dict, which should call
    # the template method on the templar object.
    hostvars = dict()
    templar = dict()

# Generated at 2022-06-25 12:39:29.645955
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'lgOw1q3bV5Q5'
    str_1 = 'gX9OtIrmH0Lp'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_1, str_1)
    str_2 = '8s1MjKvhxzZ2'
    bool_0 = ansible_j2_vars_0.__contains__(str_2)
    print('Test output: ' + str(bool_0))
