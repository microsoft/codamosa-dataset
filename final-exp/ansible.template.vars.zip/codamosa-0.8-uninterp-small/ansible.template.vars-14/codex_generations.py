

# Generated at 2022-06-25 12:29:43.441123
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -99
    dict_0 = {int_0: int_0}
    list_0 = ['0']
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    ansible_j2_vars_0.__contains__(list_0)
    ansible_j2_vars_0.__contains__(int_0)
    ansible_j2_vars_0.__contains__(dict_0)
    ansible_j2_vars_0.__contains__(list_0)
    ansible_j2_vars_0.__contains__(list_0)
    ansible_j2_vars_0.__contains__(int_0)
    ansible_j2_

# Generated at 2022-06-25 12:29:48.275788
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = -476
    dict_0 = {int_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    int_1 = ansible_j2_vars_0.__len__()
    assert(int_1 == 1)


# Generated at 2022-06-25 12:29:59.470340
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 863
    float_0 = 0.5743
    byte_0 = bytes([byte_0])
    byte_1 = bytes([byte_1])
    byte_2 = bytes([byte_2])
    byte_3 = bytes([byte_3])
    byte_4 = bytes([byte_4])
    byte_5 = bytes([byte_5])
    byte_6 = bytes([byte_6])
    byte_7 = bytes([byte_7])
    byte_8 = bytes([byte_8])
    byte_9 = bytes([byte_9])
    byte_10 = bytes([byte_10])

# Generated at 2022-06-25 12:30:03.816088
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -287
    dict_0 = {int_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    try:
        assert ansible_j2_vars_0.__contains__(int_0)
    except AssertionError:
        raise AssertionError(str(ansible_j2_vars_0))



# Generated at 2022-06-25 12:30:08.348947
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    int_0 = -476
    dict_0 = {int_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:30:10.547622
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = -476
    dict_0 = {int_0: int_0}
    AnsibleJ2Vars(int_0, dict_0)
    assert True


# Generated at 2022-06-25 12:30:13.175336
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -476
    dict_0 = {int_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    ansible_j2_vars_0.__getitem__()


# Generated at 2022-06-25 12:30:17.722877
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -730
    dict_0 = {int_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)


if __name__ == "__main__":

    test_AnsibleJ2Vars___getitem__()
    test_case_0()

# Generated at 2022-06-25 12:30:20.507126
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    ansible_j2_vars = AnsibleJ2Vars(int_0, dict_0)
    res = ansible_j2_vars.__iter__()
    print(res)
    assert True


# Generated at 2022-06-25 12:30:26.662111
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -476
    dict_0 = {int_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    ansible_j2_vars_0.__contains__('int_0')
    ansible_j2_vars_0.__contains__('int_0')


# Generated at 2022-06-25 12:30:35.640427
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Init AnsibleJ2Vars
    test_case_0()
    int_0 = 863
    float_0 = 0.5743
    ansible_j2_vars_instance = AnsibleJ2Vars(int_0, float_0)
    # Test method
    # assert an exception for 'AnsibleJ2Vars' object doesn't have attribute '__getitem__'
    with pytest.raises(AttributeError) as excinfo:
        ansible_j2_vars_instance.__getitem__()

# Generated at 2022-06-25 12:30:45.111060
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.plugins.loader import vars_loader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    test_case_0()
    test_inventory_manager = InventoryManager(loader=None, sources=["127.0.0.1"])
    test_variable_manager = VariableManager(loader=DataLoader(), inventory=test_inventory_manager)
    test_variable_manager.set_complex_vars(HostVars({}, None))

# Generated at 2022-06-25 12:30:54.098496
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.template import Templar

    templar_0 = Templar()
    test_case_0()
    assert templar_0._available_variables.get(u'int_0') == 863
    assert templar_0._available_variables.get(u'float_0') == 0.5743
    globals = {u'str_0': u'{"test_list_0": [u"v0", u"v1", u"v2"]}'}
    test_case_0()
    assert templar_0._available_variables.get(u'str_0') == u'{"test_list_0": [u"v0", u"v1", u"v2"]}'
    ansible_j2_vars_0 = AnsibleJ2Vars

# Generated at 2022-06-25 12:30:59.804479
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars(templar_0, None)
    assert (ansible_j2_vars_0['variable_0'] == int_0)
    assert (ansible_j2_vars_0['variable_0'] == 863)
    assert (ansible_j2_vars_0['variable_0'] == int_0)
    assert (ansible_j2_vars_0['variable_1'] == float_0)
    assert (ansible_j2_vars_0['variable_1'] == 0.5743)
    assert (ansible_j2_vars_0['variable_1'] == float_0)
    assert (ansible_j2_vars_0['variable_1'] == float_0)

# Generated at 2022-06-25 12:31:03.387015
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_object = AnsibleJ2Vars(None, None)
    assert ansible_j2_vars_object.__contains__(int_0) == bool_0
    assert ansible_j2_vars_object.__contains__(float_0) == bool_0


# Generated at 2022-06-25 12:31:07.327600
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_0 = AnsibleJ2Vars(templar, globals, locals)
    str_0 = 'YKQP'
    int_0 = 576
    try:
        str_1 = test_0[str_0]
        assert(False)
    except KeyError as e:
        assert(str(e) == "undefined variable: %s" % str_0)


# Generated at 2022-06-25 12:31:13.861183
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ansible_j2_vars_0 = AnsibleJ2Vars(templar = Templar(variables = {'key1': 'value1', 'key2': 'value2'}),globals = {'key1': 'value1', 'key2': 'value2'}, locals = {'key1': 'value1', 'key2': 'value2'})
    assert isinstance(ansible_j2_vars_0, AnsibleJ2Vars)


# Generated at 2022-06-25 12:31:17.379772
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # local variable test for method __getitem__
    j2vars = AnsibleJ2Vars()
    assert j2vars['int_0'] == int_0 
    assert j2vars['float_0'] == float_0


# Generated at 2022-06-25 12:31:25.503341
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = 863
    float_0 = 0.5743
    tuple_0 = (float_0, int_0)
    str_0 = 'g)'
    dict_0 = {'SSSSSSSSSSSSSSSSSSSSSSSSSSSS': 'SSSSSSSSSSSSSSSSSSSSSSSSSSSS', 'SSSSSSSSSSSSSSSSSSSSSSSSSSSS': 'SSSSSSSSSSSSSSSSSSSSSSSSSSSS', 'SSSSSSSSSSSSSSSSSSSSSSSSSSSS': 'SSSSSSSSSSSSSSSSSSSSSSSSSSSS'}
    str_1 = 'Xs.s'

# Generated at 2022-06-25 12:31:35.999126
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()
    # Test case for method __contains__ of class AnsibleJ2Vars.

    # locate module source code
    import os
    from ansible.parsing import jinja2_annotate
    from ansible.inventory.host import Host
    from ansible.template import Templar

    environment = jinja2_annotate.make_environment()

    # initialize needed objects
    targets = [Host(name='localhost', port=22)]
    templar = Templar(loader=None, variable_manager=None)
    o = AnsibleJ2Vars(templar, dict(template_dir='.', environment=environment, hostvars=dict()), dict())

    # test cases
    assert o.__contains__('') is False



# Generated at 2022-06-25 12:31:46.895263
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars()

    assert ansible_j2_vars_0.__getitem__("vars") == "__getitem__"


# Generated at 2022-06-25 12:31:52.712474
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars(templar=None, globals=None, locals=None)
    exception = None
    try:
        ansible_j2_vars_0.__getitem__(varname=None)
    except Exception as returned_exception:
        exception = returned_exception
    assert isinstance(exception, KeyError)


# Generated at 2022-06-25 12:32:04.226441
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.module_utils._text import to_native
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    test_play_context = PlayContext()
    template_data = '''
    foo: "{{ a.b }}"
    '''
    test_vars = dict(
        a = dict(
            b = 'c'
        ),
        a_b = 'd',
    )

    ansible_j2_vars_0 = AnsibleJ2Vars(Templar(loader=DataLoader()), test_play_context, test_vars)
    for x_i in ansible_j2_vars_0:
        x_key = to_native(x_i)

# Generated at 2022-06-25 12:32:06.752534
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    ansible_j2_vars_0 = AnsibleJ2Vars()

    # FIXME: Unit test not implemented
    #ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:32:09.707790
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_1 = AnsibleJ2Vars()
    ansible_j2_vars_1.__contains__("some_key")

# Generated at 2022-06-25 12:32:11.703980
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:32:14.567464
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    assert len(ansible_j2_vars_0) == 0


# Generated at 2022-06-25 12:32:17.377948
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars___getitem___0 = AnsibleJ2Vars()
    ansible_j2_vars___getitem___1 = ansible_j2_vars___getitem___0['foo']


# Generated at 2022-06-25 12:32:18.537404
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    test_case_0()

# Generated at 2022-06-25 12:32:21.740868
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_3 = AnsibleJ2Vars()
    print(vars(ansible_j2_vars_3))
    ansible_j2_vars_3.__getitem__(varname='vars')

# Generated at 2022-06-25 12:32:27.672561
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    # This will test the __contains__ method of object AnsibleJ2Vars
    ansible_j2_vars_0.__contains__()


# Generated at 2022-06-25 12:32:28.396132
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass


# Generated at 2022-06-25 12:32:30.452783
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__('foo')


# Generated at 2022-06-25 12:32:31.844794
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import jinja2

    # Test our proxy objects before and after conversion to python types

    # Test code goes here


# Generated at 2022-06-25 12:32:38.451930
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    var_manager = VariableManager()
    var_manager.add_group_vars("all", {"a": 1, "b": 2, "c": 9, "d": 10})

    templar = Templar(var_manager=var_manager, loader=None)

    ansible_j2_vars = AnsibleJ2Vars(templar, safe_eval)
    assert ansible_j2_vars.get("a") == 1
    assert ansible_j2_vars.get("b") == 2
    assert ansible_j2_vars.get("c") == 9
    assert ansible_j2_vars.get("d") == 10



# Generated at 2022-06-25 12:32:39.946991
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    assert not (ansible_j2_vars_0.__contains__('varname'))


# Generated at 2022-06-25 12:32:41.992520
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars()


# Generated at 2022-06-25 12:32:44.271583
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_ = AnsibleJ2Vars()
    assert ansible_j2_vars_.__contains__() == "__contains__"


# Generated at 2022-06-25 12:32:48.599339
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    var_1 = __builtins__.len(ansible_j2_vars_0)


# Generated at 2022-06-25 12:32:49.906367
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ansible_j2_vars = AnsibleJ2Vars()

# Generated at 2022-06-25 12:32:56.431348
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -476
    dict_0 = {int_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    varname_0 = 'varname_0'
    bool_0 = ansible_j2_vars_0.__contains__(varname_0)


# Generated at 2022-06-25 12:32:57.801776
# Unit test for method __iter__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:33:04.586131
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -476
    int_1 = -840
    dict_0 = {int_1: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0, int_1)
    str_0 = 'ansible_play_batch'
    
    # Invoke method
    result = ansible_j2_vars_0.__getitem__(str_0)

    assert result == 36, "result does not match expected value"



# Generated at 2022-06-25 12:33:08.601715
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -428
    dict_0 = {int_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    value_0 = ansible_j2_vars_0.__contains__(int_0)
    assert value_0 is False

# Generated at 2022-06-25 12:33:13.652654
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -80
    dict_0 = {int_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    assert ansible_j2_vars_0.__contains__(int_0) == True


# Generated at 2022-06-25 12:33:20.233132
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    my_tuples = [
        ('a', 'b', 'c'),
        ('1', '2', '3'),
    ]

    my_dict = dict(my_tuples)
    ansible_j2_vars = AnsibleJ2Vars(my_dict, my_dict)
    assert sorted(ansible_j2_vars) == sorted(my_dict)


# Generated at 2022-06-25 12:33:22.808161
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Check if the number of items in instance of AnsibleJ2Vars is equal to 100
    assert AnsibleJ2Vars(int_0, dict_0).__len__() == 100


# Generated at 2022-06-25 12:33:31.416284
# Unit test for method __iter__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:33:37.041403
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -237
    dict_0 = {int_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    class_type = type(ansible_j2_vars_0)
    assert class_type.__getitem__(ansible_j2_vars_0, int_0) == int_0
    int_1 = -814
    with pytest.raises(KeyError) as excinfo:
        class_type.__getitem__(ansible_j2_vars_0, int_1) == int_1
    assert str(excinfo.value) == str(int_1)

# Generated at 2022-06-25 12:33:47.783805
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # Passed parameters checking
    int_0 = -476
    dict_0 = {int_0: int_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)

    # Call the method
    result = ansible_j2_vars_0.__getitem__(int_0)

    # SSA join for if statement (line 66)
    module_type_store = module_type_store.join_ssa_context()
    module_type_store.store_return_type_of_current_context(stypy_return_type_118092)
    
    # Destroy the current context
    module_type_store = module_type_store.close_function_context()
    
    # Return type of the function 'test_AnsibleJ2

# Generated at 2022-06-25 12:34:02.115119
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    int_0 = 0
    str_0 = ""
    tuple_1 = (1, )

    # Test cases
    try:
        ansible_j2_vars_0.__getitem__(ansible_j2_vars_0)
    except KeyError as e:
        print("Exception in test case 0 (undefined variable: %s)" % e.message)

# Generated at 2022-06-25 12:34:06.771239
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    varname_0 = tuple_0
    try:
        ansible_j2_vars_0[varname_0]
    except:
        pass

# Generated at 2022-06-25 12:34:10.745890
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.add_locals(tuple_0)
    ansible_j2_vars_0.__getitem__(tuple_0)


# Generated at 2022-06-25 12:34:14.915452
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert (tuple_0 in ansible_j2_vars_0) == True


# Generated at 2022-06-25 12:34:20.897200
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_1 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_1, dict_1, dict_1)
    str_0 = '0'
    exception_0 = None
    try:
        ansible_j2_vars_0.__getitem__(str_0)
    except Exception as e:
        exception_0 = e
    try:
        assert exception_0 is not None
    except AssertionError:
        print('expected: <%s>, actual: <%s>' % (None, exception_0))


# Generated at 2022-06-25 12:34:32.737728
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None, None)
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None)
    ansible_j

# Generated at 2022-06-25 12:34:38.122556
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ();
    tuple_1 = (tuple_0,);
    str_0 = to_native(tuple_1);
    dict_0 = {str_0: str_0};
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0);
    assert True == ansible_j2_vars_0.__contains__(str_0);


# Generated at 2022-06-25 12:34:48.507021
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    dict_0 = {'a': '', 'b': 'g', 'c': '%', 'd': '\\z', 'e': '\\'}
    dict_1 = {'a': '_', 'b': '\\H', 'c': '#@>', 'd': 'E', 'e': 't!q'}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1, dict_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(dict_1, dict_1, dict_0)
    ansible_j2_vars_2 = AnsibleJ2Vars(dict_0, dict_0, dict_1)

# Generated at 2022-06-25 12:34:53.799260
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__contains__(tuple_0)


# Generated at 2022-06-25 12:35:03.351408
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ('src', 'dst', 'key')
    dict_0 = {tuple_0: tuple_0}
    dict_1 = {}
    dict_2 = {}
    dict_1[''] = dict_2
    dict_1['']['value'] = 'constants'
    dict_1['']['value_list'] = ['closed', 'open']
    dict_1['']['value_dict'] = dict_0
    dict_1[''] = dict_1['']
    dict_1[''] = dict_1['']
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_1, dict_1, dict_1)
    ansible_j2_vars_0['']

# Generated at 2022-06-25 12:35:10.858361
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    test_case_0()


# Generated at 2022-06-25 12:35:14.280504
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__()


# Generated at 2022-06-25 12:35:17.912624
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert ansible_j2_vars_0.__getitem__(tuple_0) == tuple_0


# Generated at 2022-06-25 12:35:23.509362
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    value = ansible_j2_vars_0.__getitem__(tuple_0)
    assert value == tuple_0


# Generated at 2022-06-25 12:35:34.883852
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ('', {}, (), [])
    list_0 = []
    list_1 = []
    tuple_1 = (list_1, list_1)
    tuple_2 = ()
    tuple_3 = ()
    tuple_4 = ()
    tuple_5 = ()
    tuple_6 = ()
    tuple_7 = ()
    tuple_8 = (list_1, list_1)
    tuple_9 = ()
    tuple_10 = ()
    tuple_11 = ()
    tuple_12 = ()
    tuple_13 = ()
    tuple_14 = ()
    tuple_15 = ()
    tuple_16 = ()
    tuple_17 = ()
    tuple_18 = ()
    tuple_19 = ()
    tuple_20 = ()
    tuple_21 = ()
    tuple_22 = ()
    tuple

# Generated at 2022-06-25 12:35:38.013465
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:35:43.013682
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    value = ansible_j2_vars_0.__getitem__(tuple_0)
    assert(tuple_0 == value)

# Generated at 2022-06-25 12:35:47.095015
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    # Instantiate an object
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)

    # Invoke method
    len_0 = ansible_j2_vars_0.__len__()

# Generated at 2022-06-25 12:35:55.870582
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    # First obtain the value of method __getitem__ from class AnsibleJ2Vars
    method_0 = getattr(ansible_j2_vars_0.__class__, "__getitem__", None)
    # Assert the type of the obtained method is function
    assert(isinstance(method_0, FunctionType))
    # Call the retrieved method and assert the returned result
    assert(method_0(ansible_j2_vars_0, tuple_0) == tuple_0)


# Generated at 2022-06-25 12:35:58.931991
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()

# Unit test execution
if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:36:16.643822
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert ansible_j2_vars_0.__len__() == 0


# Generated at 2022-06-25 12:36:20.325914
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert tuple_0 in ansible_j2_vars_0


# Generated at 2022-06-25 12:36:26.642012
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ('a', 'b')
    tuple_1 = ()
    tuple_2 = ()
    tuple_3 = ()
    tuple_4 = ('a', 'b')
    tuple_5 = ('a', 'a')
    tuple_6 = ()
    tuple_7 = ()
    tuple_8 = ()
    tuple_9 = ('a', 'b')
    tuple_10 = ('a', 'a')
    tuple_11 = ('a', 'b')
    tuple_12 = ()
    tuple_13 = ()
    tuple_14 = ()
    tuple_15 = ('a', 'b')
    tuple_16 = ('a', 'a')
    tuple_17 = ()
    tuple_18 = ()
    tuple_19 = ()
    tuple_20 = ('a', 'b')

# Generated at 2022-06-25 12:36:27.197948
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass

# Generated at 2022-06-25 12:36:31.331163
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    if ansible_j2_vars_0.__iter__() is None:
        raise RuntimeError('assert_equal failed')


# Generated at 2022-06-25 12:36:36.616884
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_1 = AnsibleJ2Vars(dict(), dict(), dict())

    # Test case 1
    assert(ansible_j2_vars_1.__contains__({'name': 'foo'}))
    # Test case 2
    assert(ansible_j2_vars_1.__contains__("foo"))


# Generated at 2022-06-25 12:36:44.172365
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)

    ansible_error_0 = None
    try:
        ansible_j2_vars_0['test_key']
    except AnsibleError as e:
        ansible_error_0 = e
    try:
        assert ansible_error_0.message == "undefined variable: test_key"
    except AssertionError as e:
        raise AssertionError(e)


# Generated at 2022-06-25 12:36:47.579703
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    varname = ""
    # No exception is thrown
    ansible_j2_vars_0.__getitem__(varname)
    # No exception is thrown
    ansible_j2_vars_0.__getitem__(varname)


# Generated at 2022-06-25 12:36:51.397073
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    tuple_1 = ()
    assert not ansible_j2_vars_0.__contains__(tuple_1)



# Generated at 2022-06-25 12:36:57.859889
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)

    # getting item existing in locals
    assert ansible_j2_vars_0['()'] == ()
    # getting item existing in available_variables
    assert ansible_j2_vars_0['()'] == ()
    # getting item existing in globals
    assert ansible_j2_vars_0['()'] == ()
    # getting item not existing in locals, available_variables and globals
    try:
        assert ansible_j2_vars_0['()']
    except KeyError:
        pass


# Generated at 2022-06-25 12:37:17.836742
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    set_0 = set()
    set_1 = set()
    set_0.update(dict_0, dict_0, dict_0)
    set_1.update(dict_0, dict_0, dict_0)
    assert set_1 == set_0, "Fail"


# Generated at 2022-06-25 12:37:21.601479
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    print("%s " % ansible_j2_vars_0.__getitem__(""))

# Generated at 2022-06-25 12:37:28.317380
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    varname_0 = None
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__(varname_0)



# Generated at 2022-06-25 12:37:32.765263
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)

    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, None)

    assert True

# Generated at 2022-06-25 12:37:37.291080
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert ansible_j2_vars_0.__contains__(tuple_0)


# Generated at 2022-06-25 12:37:39.802951
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    try:
        ansible_j2_vars_0['vars']
    except KeyError:
        pass


# Generated at 2022-06-25 12:37:43.067229
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__(tuple_0)

# Generated at 2022-06-25 12:37:46.273759
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    varname = None
    assert ansible_j2_vars_0.__getitem__(varname) == tuple_0



# Generated at 2022-06-25 12:37:51.298779
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    integer_0 = ansible_j2_vars_0.__len__()
    del integer_0


# Generated at 2022-06-25 12:38:00.278721
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    tuple_1 = ()
    try:
        assert (tuple_1 in ansible_j2_vars_0) == True
        assert ansible_j2_vars_0[tuple_1] == None
    except:
        assert False

    # good enough, but should be a unittest
    #from jinja2 import Environment, FileSystemLoader
    #from ansible.playbook.play import Play
    #from ansible.template import Templar
    #from ansible.vars.hostvars import HostVars
    #env = Environment(loader=FileSystemLoader('./'),

# Generated at 2022-06-25 12:38:33.336453
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:38:39.278103
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    varname_0 = 'varname_0'
    try:
        ansible_j2_vars_0[varname_0] # KeyError
    except KeyError:
        pass


# Generated at 2022-06-25 12:38:42.961817
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    str_0 = ansible_j2_vars_0.__getitem__(tuple_0)


# Generated at 2022-06-25 12:38:50.380335
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = dict()
    dict_0['templar'] = dict()
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0['templar'], dict_0, dict_0)

    # keys: 1
    dict_0['templar']['available_variables'] = {'foo': 'bar'}
    assert ansible_j2_vars_0.__getitem__('foo') == dict_0['templar']['available_variables']['foo']

    # key not found in the vars
    dict_0['templar']['available_variables'] = {'foo': 'bar'}

# Generated at 2022-06-25 12:38:56.421116
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_error_0 = None
    try:
        ansible_j2_vars_0.__getitem__(tuple_0)
    except AnsibleError as ansible_error_0:
        pass


# Generated at 2022-06-25 12:39:03.185691
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    class_0 = dict_0 if True else dict_0
    for var_name_0 in class_0:
        ansible_j2_vars_0[var_name_0]

if __name__ == '__main__':
    # test_case_0()
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:39:07.469458
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    str_0 = ansible_j2_vars_0.__getitem__()
    # assert
    assert str_0 is not None
    assert str_0 == tuple_0

# Generated at 2022-06-25 12:39:10.890369
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    assert_equal(isinstance(ansible_j2_vars_0.__iter__(), types.GeneratorType), True)


# Generated at 2022-06-25 12:39:15.618841
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    varname_0 = tuple_0
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    ansible_j2_vars_0.__getitem__(varname_0)

# Generated at 2022-06-25 12:39:19.569762
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)
    var_0 = ansible_j2_vars_0.__contains__(dict_0)
    assert var_0 == True
