

# Generated at 2022-06-25 12:29:39.359048
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    tuple_0 = ()
    int_0 = -1983
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, int_0)
    assert len(ansible_j2_vars_0) == 2


# Generated at 2022-06-25 12:29:46.077617
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Unit test for method add_locals of class AnsibleJ2Vars
    '''

    # Input params
    tuple_0 = ()
    int_0 = -1983

    # Instantiate AnsibleJ2Vars
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, int_0)

    # Test AnsibleJ2Vars.__contains__()
    tuple_1 = ()
    int_1 = 542
    str_0 = 'abc'
    ansible_j2_vars_0.__contains__(tuple_1, int_1, str_0)


# Generated at 2022-06-25 12:29:55.941972
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    int_0 = -1983
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, int_0)
    # TODO: it is possible that this test will fail when run in the development environment
    #       due to the way that the exception is created. It uses the data from the
    #       calling method to populate the name of the variable in the error message.
    #       This means that the test will pass when run from the command line, but will
    #       fail when run from within the IDE.
    with pytest.raises(AnsibleUndefinedVariable):
        ansible_j2_vars_0.__getitem__((-1770))


# Generated at 2022-06-25 12:30:02.792009
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    int_0 = -1983
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, int_0)
    ansible_j2_vars_0.__getitem__('int_0')


if __name__ == '__main__':
    test_case_0()
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:30:05.774444
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    int_0 = -1983
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, int_0)
    with pytest.raises(Exception):
        ansible_j2_vars_0.__getitem__("`z9")

# Generated at 2022-06-25 12:30:08.794239
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    tuple_0 = ()
    int_0 = -1983
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, int_0)
    assert len(ansible_j2_vars_0) == 1


# Generated at 2022-06-25 12:30:18.680689
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Init AnsibleJ2Vars instance
    try:
        tuple_0 = ()
        int_0 = -1983
        ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, int_0)
    # AssertionError exception
    except AssertionError as error:
        print(error)
    else:
        try:
            # __getitem__ call with param int_0
            ansible_j2_vars_0.__getitem__(int_0)
        except KeyError as error:
            print(error)
        else:
            # __getitem__ call with param str_0
            ansible_j2_vars_0.__getitem__(str_0)

# Generated at 2022-06-25 12:30:30.152457
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    tuple_0 = ()
    int_0 = -1983
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, int_0)
    dict_0 = dict()
    dict_0['foo'] = -3239
    dict_0['bar'] = 2797
    dict_0['baz'] = -976
    a = ansible_j2_vars_0[dict_0]
    assert a == -3239
    a = ansible_j2_vars_0['bar']
    assert a == 2797
    a = ansible_j2_vars_0['baz']
    assert a == -976


# Generated at 2022-06-25 12:30:35.456619
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    tuple_0 = ()
    int_0 = -1983
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, int_0)
    str_0 = ''
    ansible_j2_vars_0.__contains__(str_0)
    str_1 = ''
    ansible_j2_vars_0.__contains__(str_1)


# Generated at 2022-06-25 12:30:44.210926
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.module_utils.common._collections_compat import Mapping
    tuple_0 = ()
    int_0 = 82319628
    ansible_j2_vars_0 = AnsibleJ2Vars(tuple_0, int_0)
    int_1 = ansible_j2_vars_0.__len__()
    assert isinstance(ansible_j2_vars_0, Mapping)
    try:
        assert int_1 == ansible_j2_vars_0.__len__
    except AssertionError:
        raise AssertionError("len(ansible_j2_vars_0) != ansible_j2_vars_0")


# Generated at 2022-06-25 12:30:51.505062
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = 0
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_0._locals['__UNSAFE__'] = 0
    assert ansible_j2_vars_0.__contains__('__UNSAFE__')


# Generated at 2022-06-25 12:30:59.700377
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    result_0 = ansible_j2_vars_0.__getitem__(int_0)
    result_1 = ansible_j2_vars_0.__getitem__(int_0)
    result_2 = ansible_j2_vars_0.__getitem__(int_0)
    result_3 = ansible_j2_vars_0.__getitem__(int_0)
    result_4 = ansible_j2_vars_0.__getitem__(int_0)
    result_5 = ansible_j2_vars_0.__getitem__(int_0)
    result_6 = ansible

# Generated at 2022-06-25 12:31:02.723453
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    int_2 = ansible_j2_vars_0.__contains__(int_0)


# Generated at 2022-06-25 12:31:04.679258
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    length = len(ansible_j2_vars_0)


# Generated at 2022-06-25 12:31:08.819248
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    # First call to __getitem__
    # Second call to __getitem__
    # Third call to __getitem__
    try:
        ansible_j2_vars_0.__getitem__(int_1)
    except KeyError as e_2:
        pass
# END unit test for method __getitem__ of class AnsibleJ2Vars


# Generated at 2022-06-25 12:31:14.505501
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = 0
    str_0 = 'AnsibleJ2Vars'
    AnsibleJ2Vars_inst_0 = AnsibleJ2Vars(int_0, int_0)
    try:
        AnsibleJ2Vars_inst_0.__contains__(None)
    except TypeError:
        pass
    AnsibleJ2Vars_inst_0.__contains__(str_0)


# Generated at 2022-06-25 12:31:23.379049
# Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-25 12:31:25.878556
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Test for constructor of obj(class AnsibleJ2Vars)
    test_case_0()

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:31:32.902045
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """
    AnsibleJ2Vars.__getitem__ test case
    """

    int_0 = 684215254
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    varname_0 = -62086
    new_dict = ansible_j2_vars_0.__getitem__(varname_0)



# Generated at 2022-06-25 12:31:36.634656
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    call_0 = test_case_0()
    variable_0 = call_0
    variable_1 = variable_0.__getitem__("y")
    variable_1 = variable_0.__getitem__("men")
    variable_2 = variable_0.__getitem__(1991)



# Generated at 2022-06-25 12:31:40.112313
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert True


# Generated at 2022-06-25 12:31:42.651304
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    if ansible_j2_vars_0.__contains__():
        raise Exception('')


# Generated at 2022-06-25 12:31:48.141214
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    result = AnsibleJ2Vars.__getitem__(ansible_j2_vars_0, 'vars')
    assert result == 'vars'

# Generated at 2022-06-25 12:31:52.344518
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars = AnsibleJ2Vars()
    assert isinstance(ansible_j2_vars, AnsibleJ2Vars)
    # assert ansible_j2_vars.__getitem__('f') == None



# Generated at 2022-06-25 12:31:54.561088
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    ansible_j2_vars_0.__contains__(None)


# Generated at 2022-06-25 12:31:59.439995
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    if ansible_j2_vars_0.__contains__('my_vars'):
        pass
    else:
        pass


# Generated at 2022-06-25 12:32:09.088524
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    ansible_j2_vars_0 = AnsibleJ2Vars()
    ansible_j2_vars_0.__contains__ = mock.MagicMock()
    ansible_j2_vars_0.__contains__.return_value = missing
    ansible_j2_vars_0.__getitem__ = mock.MagicMock()
    ansible_j2_vars_0.__getitem__.return_value = missing
    ansible_j2_vars_0.__len__ = mock.MagicMock()
    ansible_j2_vars_0.__len__.return_value = missing
    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:32:15.247781
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        ansible_j2_vars_0 = AnsibleJ2Vars()
        if ansible_j2_vars_0.__getitem__:
            ansible_j2_vars_0.__getitem__("foobar")
    except:
        print("AnsibleJ2Vars.__getitem__(): Unit test failed")


# Generated at 2022-06-25 12:32:20.174844
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ansible_j2_vars = AnsibleJ2Vars()
    assert ansible_j2_vars.__len__() == 0
    assert len(ansible_j2_vars) == 0



# Generated at 2022-06-25 12:32:21.110389
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()

# Generated at 2022-06-25 12:32:25.826545
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    # __iter__ is not implemented


# Generated at 2022-06-25 12:32:34.429180
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    assert ansible_j2_vars_0.__getitem__("yT") == -1991
    assert ansible_j2_vars_0.__getitem__("v") == -1991
    assert ansible_j2_vars_0.__getitem__("V") == -1991
    assert ansible_j2_vars_0.__getitem__("Eu4") == -1991
    assert ansible_j2_vars_0.__getitem__("J") == -1991


# Generated at 2022-06-25 12:32:38.437314
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Setup
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_0.__contains__(int_0)



# Generated at 2022-06-25 12:32:45.871537
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    context = PlayContext()
    context.CLIARGS = dict()
    loader = DataLoader()
    display = None
    templar = Templar(loader=loader, variables={})
    templar.set_available_variables(variable_manager=None, loader=loader, play_context=context, all_vars={})
    templar.set_available_variables(variable_manager=None, loader=loader, play_context=context, all_vars={})
    templar.set_available_variables(variable_manager=None, loader=loader, play_context=context, all_vars={})
    templar.set_available

# Generated at 2022-06-25 12:32:54.000833
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    for i in ansible_j2_vars_0:
        print (i)


# Generated at 2022-06-25 12:32:56.413168
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -4875
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_0.__getitem__(int_0)

# Generated at 2022-06-25 12:33:01.085787
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Create a new AnsibleJ2Vars object
    ansible_j2_vars = AnsibleJ2Vars(AnsibleJ2Vars, AnsibleJ2Vars)
    ansible_j2_vars.__contains__(AnsibleJ2Vars)


# Generated at 2022-06-25 12:33:04.630555
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = -2455
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    assert ansible_j2_vars_0.__len__() == 0


# Generated at 2022-06-25 12:33:08.302859
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -2655
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    str_0 = ansible_j2_vars_0.__contains__()
    assert str_0 == '-2655'


# Generated at 2022-06-25 12:33:13.696367
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # Setup args and create instance
    int_0 = 1
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)

    # Invoke method
    result = ansible_j2_vars_0.__getitem__('varname')
    assert result is None
    # Return value assertion
    assert True


# Generated at 2022-06-25 12:33:19.739810
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()


# Generated at 2022-06-25 12:33:23.392427
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1003
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    str_1 = ansible_j2_vars_0[int_0]
    assert str_1 == -1003
    pass


# Generated at 2022-06-25 12:33:26.237541
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    str_0 = '1M`s*s^0GcUojn<2&ZB$'
    result_0 = ansible_j2_vars_0.__contains__(str_0)
    assert abs(result_0) == 1991


# Generated at 2022-06-25 12:33:32.121685
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Unit test for method __getitem__ of class AnsibleJ2Vars
    '''
    int_0 = -2044
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    varname_0 = str()
    try:
        ansible_j2_vars_0.__getitem__(varname_0)
    except KeyError as exc_0:
        assert str(exc_0) == "undefined variable: ", "AnsibleJ2Vars.__getitem__ raises unexpected exception"

if __name__ == '__main__':
    # Unit test for class AnsibleJ2Vars
    test_AnsibleJ2Vars___getitem__()
    # Unit test for method __getitem__ of class AnsibleJ

# Generated at 2022-06-25 12:33:35.122309
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)

    ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:33:41.746262
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    int_1 = -1991
    ansible_j2_vars_1 = AnsibleJ2Vars(int_1, int_1)
    it_3 = ansible_j2_vars_1.__iter__()
    assert isinstance(it_3, iter)
    assert it_3.__next__() == -1991


# Generated at 2022-06-25 12:33:45.778523
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Create an instance of AnsibleJ2Vars with dummy data
    obj = AnsibleJ2Vars("dummy", "dummy")
    # Call method on instance
    step_0 = obj.__contains__("dummy")
    assert step_0 is False


# Generated at 2022-06-25 12:33:51.296879
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test case -1
    # only class constructor
    int_0 = -1992
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__('str_0')
    # Test case -2
    # only class constructor
    int_0 = -1993
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__('ansible_j2_vars_0')
    # Test case -3
    # only class constructor
    int_0 = -1994
    ansible_j

# Generated at 2022-06-25 12:33:52.262709
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass


# Generated at 2022-06-25 12:33:55.607068
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    varname_0 = ansible_j2_vars_0.__contains__((-1))


# Generated at 2022-06-25 12:34:10.157656
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    assert not ansible_j2_vars_0.__contains__('context')
    assert not ansible_j2_vars_0.__contains__('template')
    assert not ansible_j2_vars_0.__contains__('environment')
    assert not ansible_j2_vars_0.__contains__('context')
    assert not ansible_j2_vars_0.__contains__('template')
    assert not ansible_j2_vars_0.__contains__('environment')
    assert not ansible_j2_vars_0.__contains__('context')
    assert not ansible_j2_

# Generated at 2022-06-25 12:34:12.565873
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)

    ansible_j2_vars_0.__contains__(int_0)



# Generated at 2022-06-25 12:34:14.214824
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    result = ansible_j2_vars_0.__contains__(int_0)
    assert True


# Generated at 2022-06-25 12:34:15.397942
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Make sure that you have added some test cases.
    assert False



# Generated at 2022-06-25 12:34:19.572424
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 1644
    int_1 = -6
    dict_0 = dict()
    dict_0['int_1'] = int_1
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, dict_0)
    assert ansible_j2_vars_0.__getitem__('int_1') == None


# Generated at 2022-06-25 12:34:22.977301
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    assert len(ansible_j2_vars_0) == int_0


# Generated at 2022-06-25 12:34:28.467711
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    int_0 = 12
    int_1 = 14
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_0 = AnsibleJ2Vars(int_1, int_1)


# Generated at 2022-06-25 12:34:33.127714
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    ansible_j2_vars_0 = AnsibleJ2Vars(-30, 'q')
    ansible_j2_vars_1 = AnsibleJ2Vars('str', -1272)
    ansible_j2_vars_0.__iter__(ansible_j2_vars_1)


# Generated at 2022-06-25 12:34:33.835722
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()

# Generated at 2022-06-25 12:34:43.839709
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case = test_case_0()
    assert test_case is not None, "class AnsibleJ2Vars() unit test case '__contains__' setup failed, test_case is None"
    ansible_j2_vars_0 = test_case

    # TODO: Add test code for AnsibleJ2Vars.__contains__(self, k)
    assert False, "class AnsibleJ2Vars() unit test case '__contains__' not implemented"
    # TODO: Add test code for rest of AnsibleJ2Vars() class and methods

if __name__ == '__main__':

    # Unit test this file
    import os
    import sys

# Generated at 2022-06-25 12:34:58.410547
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    int_0 = -1987
    int_1 = -1989
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_1)
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_0 = AnsibleJ2Vars(int_1, int_0)
    int_2 = -1990
    ansible_j2_vars_0 = AnsibleJ2Vars(int_1, int_2)
    ansible_j2_vars_0 = AnsibleJ2Vars(int_2, int_2)
    ansible_j2_vars_0 = AnsibleJ2Vars(int_1, int_1)
    ansible_j2_

# Generated at 2022-06-25 12:35:03.274798
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_3 = -1991
    ansible_j2_vars_1 = AnsibleJ2Vars(int_3, int_3)
    ans_bool_0 = ansible_j2_vars_1.__contains__(int_3)
    # The value should be True
    assert ans_bool_0 == True


# Generated at 2022-06-25 12:35:13.407598
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    str_0 = "l_UIbTl2_U6e3q6zpkC(4nfWGKs:PJ&!"

    # Test with a string.
    try:
        str_1 = ansible_j2_vars_0.__getitem__(str_0)
    except Exception as e:
        str_1 = str(e)
    print(str_1)

    int_1 = -1030
    ansible_j2_vars_0 = AnsibleJ2Vars(int_1, int_1)

    # Test with an integer.

# Generated at 2022-06-25 12:35:17.856927
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    int_1 = -14235
    int_2 = -199
    ansible_j2_vars_0.set_ansible_vars(int_2, int_1)
    ansible_j2_vars_0.__contains__(int_1)
    ansible_j2_vars_0.__contains__(int_2)
    

# Generated at 2022-06-25 12:35:22.199698
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'p'
    int_0 = -1991
    str_1 = 'kx'
    str_2 = 'X'
    str_3 = 'hc'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, int_0)
    ansible_j2_vars_0.__getitem__(str_1)
    ansible_j2_vars_0.__getitem__(str_2)
    ansible_j2_vars_0.__getitem__(str_3)


# Generated at 2022-06-25 12:35:25.789375
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars(to_native, to_native, to_native)
    ansible_j2_vars_0.__getitem__(to_native)



# Generated at 2022-06-25 12:35:26.715983
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:35:29.976453
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:35:35.007407
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_0.__getitem__()


# Generated at 2022-06-25 12:35:38.070783
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_1 = ansible_j2_vars_0.__contains__(int_0)


# Generated at 2022-06-25 12:35:44.304312
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    str_0 = "i-01e567a"
    ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:35:48.340339
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    # Verify that ansible_j2_vars_0 does not contain the key 'int_0'
    assert not (ansible_j2_vars_0.__contains__(int_0))


# Generated at 2022-06-25 12:35:51.940802
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    assert ansible_j2_vars_0.__len__() == 1


# Generated at 2022-06-25 12:35:52.887459
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert True


# Generated at 2022-06-25 12:35:55.624257
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    v0 = AnsibleJ2Vars(int_0, int_0)
    v1 = v0.__getitem__(int_0)


# Generated at 2022-06-25 12:35:59.497450
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    j2_vars_0 = AnsibleJ2Vars()
    j2_vars_0.__contains__('')
    j2_vars_0.__contains__('abc')


# Generated at 2022-06-25 12:36:08.033554
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_1991 = 1991

    # class AnsibleJ2Vars, __init__(self, templar, globals, locals=None)
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)

    # class AnsibleJ2Vars, __init__(self, templar, globals, locals=None)
    ansible_j2_vars_1 = AnsibleJ2Vars(int_1, int_0)

    # class AnsibleJ2Vars, __init__(self, templar, globals, locals=None)
    ansible_j2_vars_2 = AnsibleJ2Vars(int_2, int_0)

    # class

# Generated at 2022-06-25 12:36:11.228410
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    str_0 = string.digits
    assert(ansible_j2_vars_0[str_0] == int_0)


# Generated at 2022-06-25 12:36:16.426439
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    try:
        ansible_j2_vars_0.__getitem__(int_0)
    except AnsibleError as e:
        print('Expected exception thrown, got AnsiError exception: ', e)



# Generated at 2022-06-25 12:36:21.571266
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
  int_0 = -1991
  ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)

  # Test
  # Case 1:
  #   varname = int_0
  #   expected output:
  #     None
  varname = int_0
  assert ansible_j2_vars_0.__getitem__(varname) is None



# Generated at 2022-06-25 12:36:29.857618
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)

    # Run method __getitem__ of class AnsibleJ2Vars with arguments :
    ansible_j2_vars_0.__getitem__(int_0)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:36:34.277892
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    str_0 = '%c'
    with pytest.raises(Exception) as exception_0:
        ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:36:34.924978
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert True

# Generated at 2022-06-25 12:36:37.920651
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test case 0
    # Test case 1
    # Test case 2
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)


# Generated at 2022-06-25 12:36:41.459385
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)

    ansible_j2_vars_0.__contains__(int_0)


# Generated at 2022-06-25 12:36:45.211057
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    ansible_j2_vars_1 = AnsibleJ2Vars(int(), int())
    assert(isinstance(ansible_j2_vars_1.__iter__(), type(AnsibleJ2Vars.__iter__(ansible_j2_vars_1))))


# Generated at 2022-06-25 12:36:47.373019
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:36:49.561111
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    try:
        ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0)
    except Exception as e:
        print(e)
        raise Exception('TestCase is failed')


# Generated at 2022-06-25 12:36:56.702787
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    int_1 = -1540
    int_2 = -964
    int_3 = -4
    int_4 = 2029
    int_5 = 3985
    int_6 = 4234
    int_7 = 157
    int_8 = -664
    int_9 = -996
    int_10 = -9804
    int_11 = -8688
    int_12 = -3620
    int_13 = -2675
    int_14 = -3167
    int_15 = -3884
    int_16 = -6896
    int_17 = -9148
    int_18 = -6655
    int_19 = -9994
    int_20 = -7356
    int_21 = -9456
    int_22 = -3957


# Generated at 2022-06-25 12:36:57.685111
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert 0


# Generated at 2022-06-25 12:37:06.368551
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    user_input = "int,dict,str"
    ansible_j2_vars_0 = AnsibleJ2Vars(user_input, user_input)
    print(ansible_j2_vars_0)
    #assert False # TODO: implement your test here

if __name__ == '__main__':
    test_case_0()
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:37:12.244574
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    ansible_j2_vars_0 = AnsibleJ2Vars(ansible_j2_vars_0, list_0, list_0)
    int_0 = ansible_j2_vars_0.__iter__()
    int_1 = ansible_j2_vars_0.__iter__()
    assert int_0 == int_1



# Generated at 2022-06-25 12:37:14.963340
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    print(__name__)
    test_case_0()

if __name__ == "__main__":
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:37:17.363405
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Should fail with KeyError
    try:
        ansible_j2_vars_1 = AnsibleJ2Vars(int, int)
        ansible_j2_vars_1.__getitem__('str_1')
    except KeyError as e:
        e = e


# Generated at 2022-06-25 12:37:20.600493
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    int_0 = -2228
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    result = ansible_j2_vars_0.__iter__()
    assert result is not None


# Generated at 2022-06-25 12:37:25.974054
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    str_0 = 'Z4R1cMwE8zhF2ld'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0)
    int_1 = ansible_j2_vars_0.__contains__(str_0)
    return int_1



# Generated at 2022-06-25 12:37:30.706191
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    int_0 = -1424
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    assert iter(ansible_j2_vars_0) == iter(ansible_j2_vars_0)



# Generated at 2022-06-25 12:37:31.563125
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass


# Generated at 2022-06-25 12:37:39.803374
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.module_utils.common._collections_compat import Mapping

    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    int_1 = -1801
    int_2 = -3
    assert ansible_j2_vars_0.__len__() == ansible_j2_vars_0.__len__()
    assert Mapping.__len__(ansible_j2_vars_0) == int_1
    assert len(ansible_j2_vars_0) == int_2


# Generated at 2022-06-25 12:37:41.791251
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(int_0, int_0)


# Generated at 2022-06-25 12:37:50.868252
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Unit test for method __getitem__ of class AnsibleJ2Vars
    # int_0 = -1991
    # ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    pass



# Generated at 2022-06-25 12:37:55.226693
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    int_0 = int()
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    assert isinstance(ansible_j2_vars_0.__iter__(), Iterator) and True


# Generated at 2022-06-25 12:38:01.488644
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import pytest
    from collections import OrderedDict, Mapping
    from ansible.parsing.jinja2.compat import ansible_native_filters
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template.safe_eval import safe_eval

    with pytest.raises(TypeError):
        ansible_j2_vars_0 = AnsibleJ2Vars(str(), int())

# Generated at 2022-06-25 12:38:05.168511
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    int_1 = -945
    ansible_j2_vars_0.__getitem__(int_1)


# Generated at 2022-06-25 12:38:09.256085
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    str_0 = '_'
    assert ansible_j2_vars_0.__contains__(str_0)



# Generated at 2022-06-25 12:38:14.896966
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    try:
        ansible_j2_vars_0.__getitem__(int_0)
    except KeyError as e:
        # KeyError raised
        pass


# Generated at 2022-06-25 12:38:26.515461
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    int_1 = -91
    string_0 = "undefined variable: -1991"
    string_1 = "undefined variable: -91"
    string_2 = "b_u_n__a_n_s_i_b_l_e_"
    string_3 = "a_n_s_i_b_l_e_u_n_s_a_f_e"
    string_4 = "a_n_s_i_b_l_e_u_n_s_a_f_e"

    # Test branching: 0

# Generated at 2022-06-25 12:38:29.867352
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    int_1 = -868
    str_0 = "utv23_WQ"
    ansible_j2_vars_0.__contains__(int_1)
    ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:38:32.689387
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars = AnsibleJ2Vars(None, None)
    ansible_j2_vars.__contains__()


# Generated at 2022-06-25 12:38:40.357184
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -3141
    int_1 = 5094
    AnsibleJ2Vars_class_0 = AnsibleJ2Vars(int_0, int_1)
    with pytest.raises(KeyError) as ansible_j2_vars___getitem___exception:
        AnsibleJ2Vars_class_0.__getitem__("fq`sP#-4}Dd")
    assert  "undefined variable: fq`sP#-4}Dd" in ansible_j2_vars___getitem___exception.value.args[0]


# Generated at 2022-06-25 12:38:52.291205
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    pass



# Generated at 2022-06-25 12:39:02.150524
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    # Test template string with '%s'
    int_1 = -1991
    str_0 = '%s'
    str_1 = '%s'
    str_2 = str_0 % (str_1)
    ansible_j2_vars_0.__contains__(str_2)
    # Test template string with '%s %s'
    str_0 = '%s %s'
    str_1 = '%s'
    str_2 = '%s'
    str_3 = str_0 % (str_1, str_2)
    ansible_j2_vars_0.__contains__(str_3)
   

# Generated at 2022-06-25 12:39:06.124100
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_0.add_locals(int_0)
    # assert
    assert ansible_j2_vars_0.__contains__(int_0)


# Generated at 2022-06-25 12:39:09.569540
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = -2683
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    try:
        ansible_j2_vars_0.__len__()
    except Exception as exc:
        assert True
    else:
        assert False


# Generated at 2022-06-25 12:39:10.339342
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    assert 1 == 1

# Generated at 2022-06-25 12:39:13.164401
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    print('*************')
    print('Test: test_AnsibleJ2Vars')
    print('*************')
    test_case_0()

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:39:14.880016
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    ansible_j2_vars_0.__getitem__(int_0)


# Generated at 2022-06-25 12:39:18.043704
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    int_1 = ansible_j2_vars_0.__getitem__(int_0)


# Generated at 2022-06-25 12:39:20.618213
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = -1991
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, int_0)
    assert ansible_j2_vars_0.__len__() == 0


# Generated at 2022-06-25 12:39:26.553422
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 1
    str_0 = ""
    str_1 = "}}"
    str_2 = "}"
    str_3 = "{"
    str_4 = "{{ "
    str_5 = "{{ "
    str_6 = "{{"
    str_7 = "}}"
    str_8 = "test_AnsibleJ2Vars___getitem__"
    str_9 = "test_AnsibleJ2Vars___getitem__"
    str_10 = "test_AnsibleJ2Vars___getitem__"
    str_11 = "test_AnsibleJ2Vars___getitem__"
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    list_4 = []
    list_5 = []