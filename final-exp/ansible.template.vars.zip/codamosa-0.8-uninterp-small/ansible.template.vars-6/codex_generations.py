

# Generated at 2022-06-25 12:29:41.278741
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 7010
    str_0 = 'I_i6U5H]S5_?/<'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)

    assert ansible_j2_vars_0['ELlPf^x(*k#d!ZiXe'] == 7010


# Generated at 2022-06-25 12:29:48.789013
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)

    # Check '__getitem__' method for exceptions
    # No exception should be thrown
    ansible_j2_vars_0.__getitem__('F>@T|JGvO]pLa')


# Generated at 2022-06-25 12:29:59.826911
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = 6578
    str_0 = '|$'
    str_1 = ':'
    str_2 = 'ym%)"D&8Sn'
    str_3 = '%oI^v(.W}*=P:2"='
    str_4 = 'W'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0)
    assert ansible_j2_vars_0.__contains__(str_1) is False
    assert ansible_j2_vars_0.__contains__(str_2) is False
    assert ansible_j2_vars_0.__contains__(str_3) is False

# Generated at 2022-06-25 12:30:05.971857
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    str_1 = ';'
    assert (ansible_j2_vars_0.__contains__(str_1) == 0)


# Generated at 2022-06-25 12:30:10.582153
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 3638
    str_0 = 'u|[B1i.H;8SV"jX9y'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    str_1 = 'H}-i!!$Ux/D{w3;h6'
    assert ansible_j2_vars_0[str_1] == None


# Generated at 2022-06-25 12:30:14.758766
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 8709
    str_0 = 'UgrJStR8kceE+$'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)


# Generated at 2022-06-25 12:30:18.722334
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_1 = 5111
    str_1 = 's|82~Yj)I!Z(!$T@z\x7f'
    ansible_j2_vars_1 = AnsibleJ2Vars(int_1, str_1, str_1)


# Generated at 2022-06-25 12:30:29.385945
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    varname_0 = '&6@h*l%cS=b#qxdB9p'
    try:
        ansible_j2_vars_0.__getitem__(varname_0)
    except Exception as e:
        # check that exception has expected message
        assert e.message == "undefined variable: %s" % varname_0


# Generated at 2022-06-25 12:30:36.588169
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Define a dictionary with task data
    data = dict()
    data['debug'] = None
    data['msg'] = ''
    # Construct an object of class AnsibleJ2Vars with argument int_0, str_0, str_0
    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    result = ansible_j2_vars_0.__contains__(str_0)
    assert result == True, "Expected True, got {0}".format(result)


# Generated at 2022-06-25 12:30:39.242136
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # FIXME add test code for '__getitem__' method
    raise Exception(
        "Missing test code for '__getitem__' method of AnsibleJ2Vars class."
    )


# Generated at 2022-06-25 12:30:52.356748
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from jinja2.utils import missing

    # Check exception is raised if one of the arguments is None.
    with pytest.raises(TypeError):
        x = AnsibleJ2Vars(None, {'test': 'value'})

    with pytest.raises(TypeError):
        x = AnsibleJ2Vars('Templar', None)

    with pytest.raises(TypeError):
        x = AnsibleJ2Vars('Templar', {'test': 'value'}, None)

    # Check exception is raised if one of the arguments isn't the expected type.
    with pytest.raises(TypeError):
        x = AnsibleJ2Vars(AnsibleJ2Vars('Templar', {'test': 'value'}), {'not a templar': 'value'})



# Generated at 2022-06-25 12:30:53.227555
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    test_case_0()

# Generated at 2022-06-25 12:30:55.607843
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    x = AnsibleJ2Vars({}, {}, None)
    try:
        x.__getitem__('')
    except Exception as e:
        assert type(e) == AnsibleUndefinedVariable


# Generated at 2022-06-25 12:30:57.306308
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        test_case_0()
    except Exception as var_0:
        assert False, var_0


# Generated at 2022-06-25 12:30:59.445028
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = "Missing test code for '__iter__' method of AnsibleJ2Vars class."
    var_0 = Exception(str_0)


# Generated at 2022-06-25 12:31:05.358982
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars()
    templar = "templar"
    globals = {}
    aj2v = AnsibleJ2Vars(templar, globals)
    assert aj2v._locals == {}
    assert aj2v._templar == templar
    assert aj2v._globals == {}
    dummy_key = 'dummy_key'
    dummy_val = 'dummy_val'
    aj2v._locals[dummy_key] = dummy_val
    assert aj2v._locals[dummy_key] == dummy_val
    aj2v._templar = dummy_val
    assert aj2v._templar == dummy_val
    aj

# Generated at 2022-06-25 12:31:06.739679
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert isinstance(test_case_0(), Exception)


# Generated at 2022-06-25 12:31:09.164874
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = "Missing test code for '__getitem__' method of AnsibleJ2Vars class."
    var_0 = Exception(str_0)


# Generated at 2022-06-25 12:31:11.394068
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = "Missing test code for '__contains__' method of AnsibleJ2Vars class."
    var_0 = Exception(str_0)


# Generated at 2022-06-25 12:31:21.263305
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # [INPUT] str varname = 'x'
    varname = 'x'
    # [INPUT] dict self._templar.available_variables = {'x': u'x'}
    self._templar.available_variables = {'x': u'x'}
    # [INPUT] dict self._locals = {'x': u'x'}
    locals = {'x': u'x'}
    # [INPUT] dict self._globals = {'x': u'x'}
    globals = {'x': u'x'}
    # [EXPECT] bool result = True
    result = True
    obj = AnsibleJ2Vars(self._templar, globs=globals, locals=locals)
    assert result == result

# Unit test

# Generated at 2022-06-25 12:31:26.642604
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = "Missing test code for '__contains__' method of AnsibleJ2Vars class."
    var_0 = Exception(str_0)

# Generated at 2022-06-25 12:31:30.796604
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        __getitem__(self, varname)
        assert False
    except Exception as e:
        assert type(e) == var_0
    else:
        raise Exception('AssertionError: TypeError')


# Generated at 2022-06-25 12:31:33.749067
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = "Missing test code for '__contains__' method of AnsibleJ2Vars class."
    var_0 = Exception(str_0)


# Generated at 2022-06-25 12:31:35.742911
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    print()
    print(test_case_0.__doc__.format(**locals()))
    print()
    print(var_0)

# Generated at 2022-06-25 12:31:39.170555
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    Test_code_0 = False
    if Test_code_0 == True :
        try :
            test_AnsibleJ2Vars___getitem__()
        except Exception as e_0 :
            raise e_0
    else :
        pass



# Generated at 2022-06-25 12:31:40.253487
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = "Missing test code for '__getitem__' method of AnsibleJ2Vars class."
    var_0 = Exception(str_0)

# Generated at 2022-06-25 12:31:42.866497
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = "Missing test code for '__len__' method of AnsibleJ2Vars class."
    var_0 = Exception(str_0)


# Generated at 2022-06-25 12:31:43.892108
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = "Missing test case for __getitem__ call in ansible/utils/vars.py"
    var_0 = Exception(str_0)


# Generated at 2022-06-25 12:31:48.355519
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        # Init class AnsibleJ2Vars instance
        ansiblej2vars = AnsibleJ2Vars('templar', 'globals', 'locals')
        # Add an assert to verify the existence of method '__getitem__'
        assert (ansiblej2vars.__getitem__)
        # Call __getitem__ method
        ansiblej2vars.__getitem__()
    except Exception as var_0:
        print ('Assertion error: %s' % var_0)
    except:
        print ('\n')


# Generated at 2022-06-25 12:31:49.156224
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass


# Generated at 2022-06-25 12:32:02.961968
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    str_1 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_1)
    ansible_j2_vars_0.__getitem__('<VALUE>')
    ansible_j2_vars_0.__getitem__('f`qL|(#$1:n')
    ansible_j2_vars_0.__getitem__('D>aV7"')


# Generated at 2022-06-25 12:32:14.210669
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = 4990
    str_0 = 'b7?$+Lx}W&z0wvqD__I'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    str_1 = 'OX:Z]*Y.e[.QmLy+x(c'
    if ansible_j2_vars_0.__contains__(str_1):
        assert False
    else:
        assert True
    str_2 = '!<S|>Q$JU;g+U?|5}uA'
    if ansible_j2_vars_0.__contains__(str_2):
        assert False
    else:
        assert True

# Generated at 2022-06-25 12:32:23.521775
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = 3890
    str_0 = 'p)Cr<'
    str_1 = '%'
    str_2 = 'IOC#&'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_1)
    int_1 = AnsibleJ2Vars.__contains__(ansible_j2_vars_0, str_2)
    assert int_1 == 'A$#'


# Generated at 2022-06-25 12:32:29.172044
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    int_0 = 3038
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    ansible_j2_vars_0.__len__()
    ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:32:38.599134
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    int_0 = 2104
    str_0 = '+_C2'.encode('utf-8')
    str_1 = '@EpT8`R'
    str_2 = 'I1$9{:BpH#%'
    str_3 = '=+1(n/'
    str_4 = 'GD0hc8^'.encode('utf-8')
    str_5 = '_eWgsfuf'
    str_6 = ';+uR'
    str_7 = 'h`'
    str_8 = 'qr'
    str_9 = 'g0'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_1)
    str_10 = str_2 + str_3
    str_

# Generated at 2022-06-25 12:32:45.976242
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = -6705
    str_0 = ':}-k0]!<)%0'
    str_1 = 'zd+0x1{w}(;'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_1)
    varname = 'f3KO\x03'
    assert not ansible_j2_vars_0.__contains__(varname)
    int_1 = 9640
    str_2 = 'iE?!x*%G'
    str_3 = '\x19'
    ansible_j2_vars_1 = AnsibleJ2Vars(int_1, str_2, str_3)
    varname = 'k-UmB'
    assert not ansible_

# Generated at 2022-06-25 12:32:54.256197
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)


# Generated at 2022-06-25 12:32:59.061888
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 78
    str_0 = 'tqY#=zg!;M^0H'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    ansible_j2_vars_0.__getitem__(int_0)

# Generated at 2022-06-25 12:33:08.036489
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    # self.failUnlessRaises(AnsibleError, ansible_j2_vars_0.__getitem__, 'etf', 'pfg')
    # with self.assertRaises(AnsibleError):
        # ansible_j2_vars_0.__getitem__('etf', 'pfg')
    # self.failUnlessRaises(AnsibleError, ansible_j2_vars_0.__getitem__, 'etf', 'pfg')
    # with self.assertRaises(AnsibleError):
       

# Generated at 2022-06-25 12:33:17.424242
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Instantiation
    int_1 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_1, str_0, str_0)
    assert len(ansible_j2_vars_0) == 2, "Test ansible_j2_vars_0 is not of type AnsibleJ2Vars"
    # Setup variables
    str_0 = 'Q2=>1am-ZKdzXp'
    # Call method __getitem__
    ansible_j2_vars_0.__getitem__(str_0)
    # Verify TypeError is raised

# Generated at 2022-06-25 12:33:32.397590
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = 82218
    str_0 = '8hc%3q'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    int_0 = 6293
    str_0 = 'x|<2Ld'
    ansible_j2_vars_1 = AnsibleJ2Vars(int_0, str_0, str_0)
    str_2 = '_'
    str_3 = '4'
    str_4 = '3'
    str_5 = '9'
    str_6 = '='
    str_7 = '6'
    str_8 = '7'
    str_9 = '2'
    str_10 = '5'
    str_11 = '1'
   

# Generated at 2022-06-25 12:33:36.316836
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    ansible_j2_vars_0 = AnsibleJ2Vars()
    keys = set()
    keys.update(ansible_j2_vars_0._templar.available_variables, ansible_j2_vars_0._locals, ansible_j2_vars_0._globals)
    assert len(keys) == 0


# Generated at 2022-06-25 12:33:47.701752
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    dict_0 = dict()
    dict_0['k_0'] = 'r_0'
    ansible_j2_vars_0._locals = dict_0
    ansible_j2_vars_0._templar.available_variables = dict_0
    dict_0 = dict()
    dict_0['k_0'] = 'r_0'
    ansible_j2_vars_0._globals = dict_0

# Generated at 2022-06-25 12:33:56.310646
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = 990
    str_0 = '^^i\x1c\x0e\x058W\x1c,l\x0e'
    str_1 = '=\n\t\x1f`\x0f\x0b_'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_1)
    str_2 = '\x10\x1b\x0b\x11\x1dt\x1f\x1e\x10u'
    bool_0 = ansible_j2_vars_0.__contains__(str_2)
    assert bool_0 == False


# Generated at 2022-06-25 12:34:02.720235
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    bool_0 = ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:34:08.801264
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    ansible_j2_vars_1 = AnsibleJ2Vars(int_0, str_0, str_0)
    ansible_j2_vars_1.__getitem__()

# Generated at 2022-06-25 12:34:12.282815
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    int_0 = 5565
    str_0 = '&r@r)$^-T}=%c9*!_s'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)
    set_0 = ansible_j2_vars_0.__iter__()


# Generated at 2022-06-25 12:34:20.168690
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    int_0 = 3890
    str_0 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)

    str_1 = 'zK2@!|'
    ansible_j2_vars_0.__contains__(str_1)

    str_1 = '=zG!f+!x1.v/1<Q{Jh'
    ansible_j2_vars_0.__contains__(str_1)

    str_1 = 'qY,=s:s'
    ansible_j2_vars_0.__contains__(str_1)

    str_1 = 's!)'
    ansible_

# Generated at 2022-06-25 12:34:30.315595
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 4928
    str_0 = '8W,HU0v5n5pRb^oK!J'
    str_1 = '=2+F)aXjKk-x>+I`4Y'
    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_1)
    int_1 = 3890
    str_2 = '?EG%t|Y7E|15m(H*$M'
    ansible_j2_vars_1 = AnsibleJ2Vars(int_1, str_1, str_2)


# Generated at 2022-06-25 12:34:37.523576
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    int_0 = 8
    str_0 = 'UrQ{i[GjH7qE4!1m$7Q'

    ansible_j2_vars_0 = AnsibleJ2Vars(int_0, str_0, str_0)

    # Call method __getitem__ of AnsibleJ2Vars with argument str_0 and return its results
    # assert <cond>, <err message>
    assert ansible_j2_vars_0.__getitem__(str_0) == str_0, 'Failed to get item str_0 of AnsibleJ2Vars'


# Generated at 2022-06-25 12:34:52.924806
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-25 12:34:58.951504
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = 'Uz0;'
    str_1 = 'hg#'
    str_2 = 'w'
    dict_0 = {str_2: str_0}
    dict_1 = {str_0: str_2}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_1, dict_0)
    with pytest.raises(KeyError):
        ansible_j2_vars_0.__getitem__(str_1)


# Generated at 2022-06-25 12:35:03.458175
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    assert len(ansible_j2_vars_0) == 3


# Generated at 2022-06-25 12:35:11.894178
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Declaration of test variables
    str_0 = '~'
    str_1 = '!'
    str_2 = '~'
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_1)
    # Initialization test
    # Call the tested method
    try:
        result_mapped = ansible_j2_vars_0.__getitem__(str_2)
    except KeyError as error:
        result_mapped = error.args[0]
    except Exception as error:
        raise
    assert result_mapped == 'undefined variable: ~'



# Generated at 2022-06-25 12:35:17.174695
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # Setup Test 1
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)

    try:
        # Test 1

        # Verify
        assert ansible_j2_vars_0[str_0] == str_0
        print_success(test_name)
    except Exception:
        print_failure(test_name)
        raise Exception


# Generated at 2022-06-25 12:35:17.796681
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    assert True == True


# Generated at 2022-06-25 12:35:23.304977
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    with pytest.raises(KeyError):
        ansible_j2_vars_0['~']        


# Generated at 2022-06-25 12:35:30.220038
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '/home/ansible/ansible'
    dict_0 = {str_0: str_0}
    dict_1 = dict()
    dict_1[str_0] = str_0
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_1)
    int_0 = ansible_j2_vars_0.__getitem__('/home/ansible/ansible')
    assert int_0 == '/home/ansible/ansible'


# Generated at 2022-06-25 12:35:35.874359
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ansible_j2_vars_0 = AnsibleJ2Vars(None, None, None)
    assert ansible_j2_vars_0.__contains__('.') == 1
    assert ansible_j2_vars_0.__contains__(' ') == 1


# Generated at 2022-06-25 12:35:40.348310
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    str_1 = '~'
    str_2 = '~'
    int_0 = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:36:02.503031
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    #print(vars(ansible_j2_vars_0))
    #print(ansible_j2_vars_0.__dict__)
    #print(ansible_j2_vars_0.__class__)
    #print(dir(ansible_j2_vars_0))
    #print(dir(ansible_j2_vars_0.__class__))
    print(ansible_j2_vars_0._globals)
    print(ansible_j2_vars_0._locals)

# Generated at 2022-06-25 12:36:04.353010
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    print(__name__)
    print("Constructor is not callable, so no unit test for constructor")
    test_case_0()


# Generated at 2022-06-25 12:36:05.161924
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass


# Generated at 2022-06-25 12:36:10.978871
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    ansible_j2_vars = AnsibleJ2Vars({"a":0}, {"a":1}, {"a":2})

    # Case 1: test __contains__
    assert("a" in ansible_j2_vars)
    assert("b" not in ansible_j2_vars)

    # Case 2: test __iter__
    ansible_j2_vars_iter = iter(ansible_j2_vars)
    lst = []
    for it in ansible_j2_vars_iter:
        lst.append(it)
    assert("a" in lst)
    assert(lst == ["a", "a", "a"])

    # Case 3: test __len__
    assert(len(ansible_j2_vars) == 3)

    #

# Generated at 2022-06-25 12:36:11.809759
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_case_0()


# Generated at 2022-06-25 12:36:20.667354
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '^'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    str_1 = 'kVea'
    dict_1 = {str_1: str_1}
    str_2 = 'Vc%j'
    dict_2 = {str_2: dict_1}
    str_3 = '['
    dict_3 = {str_3: dict_2}
    str_4 = '6e/T'
    dict_4 = {str_4: dict_3}
    ansible_j2_vars_0.__getitem__(dict_4)

# Generated at 2022-06-25 12:36:25.101832
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    bool_0 = ansible_j2_vars_0.__contains__(str_0)
    print(bool_0)


# Generated at 2022-06-25 12:36:27.850541
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_case_0()

if __name__ == '__main__':
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:36:37.314404
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    obj_0 = None
    def __init__(self, ansible_j2_vars_0, str_0, dict_0):
        return
    ansible_j2_vars_0.__init__(ansible_j2_vars_0, str_0, dict_0)
    try:
        obj_0 = ansible_j2_vars_0.__getitem__(dict_0)
        print("Failed: Exception not thrown")
    except AttributeError as e:
        print("Caught expected exception: %s" % e)

# Generated at 2022-06-25 12:36:40.077235
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ansible_j2_vars_0 = AnsibleJ2Vars(str_0, str_0, str_0)
    test_case_0()


# Generated at 2022-06-25 12:37:08.039919
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:37:13.117451
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        import traceback
        traceback.print_exc()
        return 1

if __name__ == '__main__':
    import sys
    sys.exit(test_AnsibleJ2Vars())

# Generated at 2022-06-25 12:37:17.497478
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    str_1 = ansible_j2_vars_0[str_0]



# Generated at 2022-06-25 12:37:18.736789
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert 1 # TODO: implement your test here


# Generated at 2022-06-25 12:37:25.723276
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        str_0 = '~'
        dict_0 = {str_0: str_0}
        ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
        str_1 = None
        str_2 = ansible_j2_vars_0.__getitem__(str_1)
        assert str_0 == str_2
    except (AnsibleError, AnsibleUndefinedVariable, KeyError) as e:
        raise Exception(e)


# Generated at 2022-06-25 12:37:27.331766
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
  test_case_0()

# Generated at 2022-06-25 12:37:29.989306
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = {}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 12:37:35.249671
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from jinja2.utils import undefined
    
    str_0 = '~'
    dict_0 = {str_0: undefined}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)

    str_1 = '~'
    print(ansible_j2_vars_0.__getitem__(str_1))


if __name__ == '__main__':
    test_case_0()
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-25 12:37:39.426561
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = ''
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)

    val = ansible_j2_vars_0[str_0]
    assert isinstance(val, str)


# Generated at 2022-06-25 12:37:44.836349
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import unsafe_eval
    # Setup test data
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    str_1 = '~'

    # Invoke method
    result = ansible_j2_vars_0.__contains__(str_1)

    # Verify expected result
    assert result == True, "Result does not match expected value"

# Generated at 2022-06-25 12:38:16.227770
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    count = ansible_j2_vars_0.__len__()
    assert count == 1


# Generated at 2022-06-25 12:38:18.544613
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    dict_0 = {'vars': 'vars'}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, dict_0, dict_0)


# Generated at 2022-06-25 12:38:22.412472
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'zO&'
    dict_0 = {str_0: str_0}
    AnsibleJ2Vars(dict_0, str_0, dict_0)


# Generated at 2022-06-25 12:38:27.675793
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)

    assert list(ansible_j2_vars_0.__iter__()) == [str_0]


# Generated at 2022-06-25 12:38:31.989281
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = 'X'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    str_1 = 'F'
    assert (str_1 in ansible_j2_vars_0) == False


# Generated at 2022-06-25 12:38:38.676759
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dict_0 = dict()
    dict_0['value'] = 'value'
    str_0 = 'test_AnsibleJ2Vars___getitem__'
    ansible_j2_vars_0 = AnsibleJ2Vars(None, str_0, dict_0)
    str_1 = 'value'
    str_2 = ansible_j2_vars_0.__getitem__(str_1)
    assert str_2 == str_1


# Generated at 2022-06-25 12:38:42.319605
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Python 3.6.2
    assert AnsibleJ2Vars(None, None)['z'] == 'z'
    # Python 3.6.2
    try:
        AnsibleJ2Vars(None, None)['z']
    except KeyError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 12:38:45.970595
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    assert ansible_j2_vars_0.__contains__(str_0) == True


# Generated at 2022-06-25 12:38:49.283583
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    dict_0 = {'~': '~'}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, '~', dict_0)
    str_0 = '~'
    assert ansible_j2_vars_0.__contains__(str_0)


# Generated at 2022-06-25 12:38:50.600609
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_case_0()


# Generated at 2022-06-25 12:39:18.629327
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    int_0 = ansible_j2_vars_0.__len__()


# Generated at 2022-06-25 12:39:22.836262
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    str_0 = '~'
    dict_0 = {str_0: str_0}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_0)
    try:
        ansible_j2_vars_0[str_0]
    except KeyError as err:
        assert str(err) == 'undefined variable: ~'
    else:
        assert False, 'Expected exception'



# Generated at 2022-06-25 12:39:26.016683
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    str_1 = '`'
    str_0 = '"'
    dict_0 = {str_0: str_0}
    dict_1 = {str_0: str_1}
    ansible_j2_vars_0 = AnsibleJ2Vars(dict_0, str_0, dict_1)
    ansible_j2_vars_0.__iter__()

