

# Generated at 2022-06-21 07:50:59.146801
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.vars.finder import VariableFinder

    templar = Templar(loader=None, variables={'bar': 'baz'})

    vars = AnsibleJ2Vars(templar, dict())

    assert len(vars) == 2



# Generated at 2022-06-21 07:51:11.149200
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    import ansible.vars.hostvars as hostvars
    import ansible.vars.unsafe_proxy as unsafe_proxy

    templar = Templar()
    globals = { 'g': 1 }
    locals  = { 'l': 2 }

    # Test AnsibleJ2Vars with empty locals
    vars = AnsibleJ2Vars(templar, globals)
    assert(len(vars) == 1)
    assert(isinstance(vars['context'], dict))

    # Test AnsibleJ2Vars with locals
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert(len(vars) == 3)
    assert(isinstance(vars['context'], dict))
    assert(vars['l'] == 2)

# Generated at 2022-06-21 07:51:17.696588
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    test_globals = {'name':'test'}
    test_locals = {'test':'testvar'}
    test_available_variables = {'test':'testvar2'}
    test_templar = object()
    test_instance = AnsibleJ2Vars(test_templar, test_globals, locals=test_locals)
    assert test_instance._globals == test_globals
    assert test_instance._locals == test_locals
    assert test_instance._templar == test_templar


# Generated at 2022-06-21 07:51:22.269221
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    yaml_dict = dict(key1='value1', key2='value2')
    templar = Templar(loader=None)
    templar.available_variables = dict(key1='value1', key2='value2')
    j2_vars = AnsibleJ2Vars(templar, yaml_dict)
    assert 'key1' in j2_vars
    assert 'key2' in j2_vars
    assert 'key3' not in j2_vars



# Generated at 2022-06-21 07:51:33.860980
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    data_loader = DataLoader()
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    from ansible.template import Templar
    templar = Templar(loader=data_loader, variables=variable_manager)

    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict()
    variable_manager._options_vars = dict()
    variable_manager._hostvars = dict()
    variable_manager._group_vars = dict()
    variable_manager._task_vars = dict()

    variable_manager._extra_vars['a_var'] = 1
    variable_manager._extra_vars['b_var'] = 2

    variable_manager

# Generated at 2022-06-21 07:51:39.754812
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class Templar:
        available_variables = set(['a', 'b'])

    globals = {'c':'C', 'd':'D'}
    locals = {'e':'E', 'f':'F'}
    item = AnsibleJ2Vars(Templar(), globals, locals)

    assert len(item) == 6



# Generated at 2022-06-21 07:51:47.988441
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleUnicode
    templar = Templar(loader=None)
    hostVars = HostVars(dict())
    hostVars['someVar'] = 42
    hostVars['someVarStr'] = 'forty two'
    hostVars['someVarUnsafe'] = AnsibleUnsafeText('forty two')
    globals = dict()
    globals['globalVar'] = 'globalVarValue'
    globals['globalVarUnsafe'] = AnsibleUnsafeText('globalVarUnsafeValue')
    globals

# Generated at 2022-06-21 07:51:59.210618
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DictDataLoader({
        'a.j2': '{{ a }}',
        'b.j2': '{% include "a.j2" %}',
        'c.j2': '{% include "b.j2" %}',
    })


# Generated at 2022-06-21 07:52:06.653624
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar=None
    globals=["g1"]
    locals={'l_some_var':'test_value', 'another_var':'test_value'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert "g1" in ajv
    assert "another_var" in ajv
    assert "l_some_var" in ajv

# Generated at 2022-06-21 07:52:17.921843
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    hostvars = HostVars(host=None, variables={'foo': 'foo', 'bar': 'bar'})
    globals = dict()
    j2vars = AnsibleJ2Vars(templar, globals, locals={'baz': 'baz'})
    assert 'foo' in j2vars
    assert 'bar' in j2vars
    assert 'baz' in j2vars
    assert 'bar' in AnsibleJ2Vars(templar, globals, locals=hostvars)
    assert 'baz' not in AnsibleJ2Vars(templar, globals, locals=hostvars)

# Generated at 2022-06-21 07:52:31.657110
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.template import Templar
    templar = Templar()

    vars = dict()
    vars['my_var'] = 'my_value'
    vars['your_var'] = 'your_value'

    globals = dict()
    globals['my_var'] = 'my_value'
    globals['your_var'] = 'your_value'

    locals = dict()
    locals['my_var'] = 'another_value'

    v = AnsibleJ2Vars(templar, globals, locals=locals)

    assert('my_var' in v)
    assert('your_var' in v)
    assert('some_other_var' not in v)



# Generated at 2022-06-21 07:52:39.678034
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import jinja2

    templar = jinja2.Environment()
    j2vars = AnsibleJ2Vars(templar, {}, locals={'l_key_in_locals': 42, 'l_key_not_in_locals': None})

    assert 'key_in_locals' in j2vars
    assert 'l_key_in_locals' in j2vars
    assert 'key_not_in_locals' not in j2vars
    assert 'l_key_not_in_locals' not in j2vars

    assert j2vars['key_in_locals'] == 42
    assert j2vars['l_key_in_locals'] == 42


# Generated at 2022-06-21 07:52:50.794273
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.play_context import PlayContext

    # init with valid values
    import ansible.template
    templar = ansible.template.Templar(play_context=PlayContext(variable_manager={}))
    globals = {}
    locals = {'foo': 'bar'}
    ansible_j2vars = AnsibleJ2Vars(templar, globals=globals, locals=locals)
    assert ansible_j2vars._templar is templar
    del templar
    assert ansible_j2vars._globals is globals
    assert locals == ansible_j2vars._locals

    # init with valid values and no locals

# Generated at 2022-06-21 07:53:00.459323
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    global_var = 'global_var'
    local_var = 'local_var'
    templar = None
    globals = {global_var: 'global_value'}
    locals = {local_var: 'local_value'}

    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert j2vars[global_var] == 'global_value'
    assert j2vars.get(global_var) == 'global_value'
    assert j2vars[local_var] == 'local_value'
    assert j2vars.get(local_var) == 'local_value'

    j2vars = j2vars.add_locals(locals)

    assert j2vars[global_var] == 'global_value'

# Generated at 2022-06-21 07:53:12.249847
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar(object):
        def __init__(self):
            self.available_variables = {
                'some_dict': {'key': 'value'}
            }

        def template(self, variable):
            return variable['key']

    templar = Templar()

    vars = AnsibleJ2Vars(templar, {}, {'l_key': 'mocked_value'})
    assert vars['some_dict'] == 'value'
    assert vars['key'] == 'mocked_value'

    # If the key is not found, the AnsibleJ2Vars.__getitem__ should throw KeyError exception
    try:
        vars['bad_key']
        assert False
    except KeyError as e:
        assert str(e) == 'undefined variable: bad_key'

# Generated at 2022-06-21 07:53:25.506838
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    templar = Templar()
    globals = dict()
    locals1 = dict()
    locals2 = dict()
    locals3 = dict()

    # first case
    ajv1 = AnsibleJ2Vars(templar, globals, locals=locals1)
    globals['one'] = 1
    locals1['two'] = 2
    locals1['three'] = 3
    templar.available_variables = dict()
    templar.available_variables['four'] = 4
    assert 'one' in ajv1
    assert 'two' in ajv1
    assert 'three' in ajv1
    assert 'four' in ajv1
    assert 'five' not in ajv1

# Generated at 2022-06-21 07:53:38.116241
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    variable = 'var'
    templar = Templar(loader=None)
    globals = {'g_var': 0}
    locals = {'l_var': 1}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert variable not in vars

    templar.available_variables = {variable: 1}
    assert variable in vars

    templar.available_variables = {variable: AnsibleBaseYAMLObject()}
    assert variable in vars

    templar.available_variables = {variable: HostVars([], [])}

# Generated at 2022-06-21 07:53:48.112615
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class Templar(object):
        def __init__(self, variables):
            self.available_variables = variables
        def template(self, value):
            if isinstance(value, str):
                return '{0}_tmpl'.format(value)

    # Create a simple Templar
    variables = {
        "a": "0",
        "b": "1",
    }

    templar = Templar(variables)

    test_dict = {
        "c": "2",
        "b": "3",
    }

    # Create a simple AnsibleJ2Vars
    ansible_j2_vars = AnsibleJ2Vars(templar, test_dict)

    # Get values and keys of simple AnsibleJ2Vars

# Generated at 2022-06-21 07:53:58.414089
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    Test: method __len__
    Expected result: get all elments of AnsibleJ2vars
    '''
    # create a mock templar
    templar = {'a': 'A', 'b': 'B', 'c': 'C'}
    # create a mock globals
    globals = {'a': 'A', 'b': 'B', 'c': 'C'}
    # create a mock locals
    locals = {'a': 'A', 'b': 'B', 'c': 'C'}
    # create AnsibleJ2vars
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # get length of AnsibleJ2vars
    result = len(j2vars)
    # assert result is int
    assert isinstance

# Generated at 2022-06-21 07:54:09.912484
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import AnsibleJ2Template
    from jinja2.utils import missing
    import json

    templar = AnsibleJ2Template(extra_vars=dict(
        a=dict(b=dict(c=1)),
        d=dict(e=dict(f=2)),
        g=dict(h=3),
        i=4,
        j=5,
        k=6,
        vars=dict(l=7),
        env_vars=dict(m=8),
        ansible_vars=dict(n=9),
    ))

    globals = dict(j=10)


# Generated at 2022-06-21 07:54:25.093784
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None, variables={'hostvars': {'127.0.0.1': {'name': 'test_AnsibleJ2Vars___getitem__'}}})

    # test get hostvars
    globals = {'hostvars': HostVars(Host("127.0.0.1"), templar._shared_loader_obj)}
    assert AnsibleJ2Vars(templar, globals).__getitem__('hostvars')['127.0.0.1']['name'] == 'test_AnsibleJ2Vars___getitem__'

    # test get vars
    globals = {}

# Generated at 2022-06-21 07:54:31.529275
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    var_manager = VariableManager()
    var_manager.setup_cache()
    templar = Templar(loader=None, variables=var_manager)
    vars = AnsibleJ2Vars(templar, globals=dict(a=[1,2,3], b=[1,2,3]), locals=dict(l_c=[1,2,3]))
    assert len(vars) == 3

# Generated at 2022-06-21 07:54:40.881422
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Create object with initialized variables
    template = Templar(loader=None, variables={'a': '1', 'b': '2', 'c': '3'})
    globals = {'a': '1', 'b': '2', 'c': '3'}
    locals = {'a': '1', 'b': '2', 'c': '3'}
    ansible_j2_vars = AnsibleJ2Vars(template, globals, locals)

    # Get the iterator and convert it to a list
    iter = ansible_j2_vars.__iter__()
    keys = list(iter)

    # Assert that all the variables are present in the list
    assert 'a' in keys
    assert 'b' in keys
    assert 'c' in keys
    assert 'd' not in keys

# Generated at 2022-06-21 07:54:53.165815
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import unittest
    import sys
    import os

    # mock jinja2 and ansible module, so that it is possible to mock object Templar()
    class module_utils_jinja2_environment:
        class Environment:
            def __init__(self, variable_start_string, variable_end_string, undefined='',
                         extensions=None, bytecode_cache=None, cache_size=50,
                         auto_reload=False, finalize=None, optimized=False, trim_blocks=False,
                         lstrip_blocks=False, newline_sequence='\n', keep_trailing_newline=False,
                         extensions_list=None, bytecode_cache_class=None, filesystem_checks=True,
                         templates=None, default_filters=None, autoescape=True):
                pass


# Generated at 2022-06-21 07:54:58.239298
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)
    assert hasattr(ansible_j2_vars, '__iter__')
    assert callable(ansible_j2_vars.__iter__)

# Generated at 2022-06-21 07:55:03.403753
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import os
    j2vars = AnsibleJ2Vars()
    assert 'HOME' in j2vars
    assert 'home' in j2vars
    assert 'HOME_DIR' not in j2vars
    assert 'home_dir' not in j2vars


# Generated at 2022-06-21 07:55:11.606435
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    yaml_data = '''
    test:
      name:  mytest
    '''
    yaml_dict = yaml.load(yaml_data)
    templar = Templar(loader=None)
    locals = {'test': 'localtest'}
    c = AnsibleJ2Vars(templar, yaml_dict, locals)
    print (c)

if __name__ == "__main__":
    import yaml
    test_AnsibleJ2Vars()

# Generated at 2022-06-21 07:55:20.745107
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Length for empty AnsibleJ2Vars
    j2vars = AnsibleJ2Vars(None, None, None)
    assert len(j2vars) == 0

    # Length for AnsibleJ2Vars with all empty attributes
    j2vars = AnsibleJ2Vars({}, {}, {})
    assert len(j2vars) == 0

    # Length for AnsibleJ2Vars with all attributes having same element
    j2vars = AnsibleJ2Vars({'a':'a'}, {'a':'a'}, {'a':'a'})
    assert len(j2vars) == 1

# Generated at 2022-06-21 07:55:22.294181
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert hasattr(AnsibleJ2Vars, '__len__')

# Generated at 2022-06-21 07:55:34.535182
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    class Host():
        pass
    host = Host()
    host.name = "host1"
    templar = Templar(loader=None, variables={host.name: host})

    globals = dict(foo=1, bar="2", baz=3)
    locals = dict(foo=4, bar="5", baz=6)

    j2vars = AnsibleJ2Vars(templar, globals=globals, locals=locals)

    assert j2vars["foo"] == 4
    assert j2vars["bar"] == "5"
    assert j2vars["baz"] == 6

    assert j2vars["host1"] is host

    # Before Ansible 2.9,

# Generated at 2022-06-21 07:55:45.937048
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class Templar(object):
        def __init__(self):
            self._available_variables = {'x':1, 'y':2}
        @property
        def available_variables(self):
            return self._available_variables

    class Iter(object):
        def __init__(self, iterable):
            self._iterable = iterable
        def __iter__(self):
            return iter(self._iterable)

    ajv = AnsibleJ2Vars(Templar(), Iter(['z1', 'z2', 'z3']))
    assert sorted(ajv) == ['x', 'y', 'z1', 'z2', 'z3']

# Generated at 2022-06-21 07:55:58.835073
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    # case 1:
    #   AnsibleJ2Vars( templar, globals, locals = {'a': 'b'} )
    #   x.__contains__('a') -> True
    #   x.__contains__('b') -> False
    #   x.__contains__('c') -> False
    x = AnsibleJ2Vars( Templar({'b':'c'}), {'a':'b'}, {'a':'b'})
    if x.__contains__('a') != True:   raise Exception("Test Failed")
    if x.__contains__('b') != False:  raise Exception("Test Failed")
    if x.__contains__('c') != False : raise Exception("Test Failed")

    # case 2:
    #

# Generated at 2022-06-21 07:56:06.577321
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Set up a test environment
    vars_dict = dict(a="a", b="b", c="c")
    vars_dict["ansible_local"] = dict(
        d="d", e="e", f="f"
    )
    vm = VariableManager()
    vm.extra_vars = dict(g="g", h="h", i="i")
    templar = Templar(loader=None, variables=vm)
    # Create a new AnsibleJ2Vars instance
    j2vars = AnsibleJ2Vars(templar, vars_dict)

    # Test the four cases in add_locals function
    locals1 = dict(d="d", e="e", f="f")
    j2v

# Generated at 2022-06-21 07:56:14.710973
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
	from ansible.template import Templar
	from ansible.parsing.dataloader import DataLoader

	j2vars = AnsibleJ2Vars(Templar(loader=DataLoader()), dict(a=1, b=2))
	assert j2vars['a'] == 1
	assert j2vars['b'] == 2
	try:
		j2vars['c']
		assert False, 'KeyError should be thrown'
	except KeyError:
		pass

# Generated at 2022-06-21 07:56:25.618038
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.templating import Templar
    from ansible.template import Templar as Templetor
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.reserved import Reserved
    from ansible.vars.manager import VariableManager
    import pytest
    import constants
    import sys

    # Use colors if the output is a tty and the terminal supports it.
    colors = (sys.stdout.isatty() and hasattr(sys.stdout, 'fileno') and termcolor.is_supported(sys.stdout.fileno()))
    # get unittest settings
    settings = constants.__dict__
    settings["TESTS_RUNTIME_VARS"] = {}

    # create Templar() object
   

# Generated at 2022-06-21 07:56:33.562902
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import os
    import time
    import yaml
    import json
    import jinja2
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    test_dir = './tests/sanity/core/ansible_module_utils/tests/test_module_utils_common_ansible_j2_vars/'
    test_vars = json.load(open(os.path.join(test_dir, "test_vars.json")))
    test_vars_complex = yaml.load(open(os.path.join(test_dir, "test_vars_complex.yaml")))

# Generated at 2022-06-21 07:56:44.490029
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Checks, if the locals are updated when calling method add_locals.
    '''
    templar = object()
    globals = {
        "a": 1,
        "b": 2
    }
    locals = {
        "b": 3,
        "c": 4
    }

    proxy = AnsibleJ2Vars(templar, globals, locals)
    assert len(proxy.items()) == 3
    assert proxy["b"] == 3

    locals = {
        "d": 5
    }
    result = proxy.add_locals(locals)
    assert len(result.items()) == 4
    assert result["d"] == 5

# Generated at 2022-06-21 07:56:54.355745
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = {
        'gbl1': 1,
        'gbl2': 2,
        'gbl3': 3,
    }
    locals = {
        'lcl1': 1,
        'lcl2': 2,
        'lcl3': 3,
    }
    vars = AnsibleJ2Vars(templar, globals, locals=locals)

    # Check __iter__ iterates over the correct keys
    # start with empty set and add each key from __iter__
    keys = set()
    for key in vars:
        keys.add(key)

    # check if all the keys are in the set
    assert(len(keys) == 6)
    assert('gbl1' in keys)
    assert('gbl2' in keys)

# Generated at 2022-06-21 07:57:06.083103
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    proxy = AnsibleJ2Vars(templar, dict())

    def check_locals(locals):
        new_proxy = proxy.add_locals(locals)
        for key, value in iteritems(locals):
            if key[:2] == 'l_':
                key = key[2:]
            assert key in new_proxy._locals
            assert new_proxy._locals[key] is value

    check_locals(None)
    check_locals(dict())
    check_locals(dict(a=1))
    check_locals(dict(l_=1))
    check_locals(dict(l_a=1))

# Generated at 2022-06-21 07:57:14.605643
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test case: Variable name is available in both, local variables and templar
    templar = None
    globals = dict()
    locals = dict(l_action=dict(connection='local'))
    v = AnsibleJ2Vars(templar, globals, locals)
    assert 'action' in v

    # Test case: Variable name is not available in both, local variables and templar
    templar = None
    globals = dict()
    locals = dict(l_action=dict(connection='local'))
    v = AnsibleJ2Vars(templar, globals, locals)
    assert 'ansible_managed' not in v

    # Test case: Variable name is available in locals, but not templar
    templar = None
    globals = dict()

# Generated at 2022-06-21 07:57:32.206656
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # this test is a bit heavy-handed but there doesn't seem to be a
    # smaller way of setting up the values in the AnsibleJ2Vars object
    # to test __len__.
    templar = AnsibleJ2Vars.AnsibleJ2Vars._templar
    globals = AnsibleJ2Vars.AnsibleJ2Vars._globals
    locals = AnsibleJ2Vars.AnsibleJ2Vars._locals
    # First test is testing the dict containing the globals
    # this should return 2 since it contains 2 keys
    globals_dict = {'g_a': 'b', 'g_c': 'd'}
    vars = AnsibleJ2Vars(templar, globals_dict)
    len_vars = len(vars)
   

# Generated at 2022-06-21 07:57:39.881344
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import ansible.vars.hostvars
    from ansible.parsing.vault import VaultLib
    from ansible.template.safe_eval import safe_eval
    from ansible.template.templar import Templar

    from ansible.plugins.loader import vars_loader, filter_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    vault_secrets = VaultLib(['password'], ['password'])
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory, vault_secrets=vault_secrets)

# Generated at 2022-06-21 07:57:44.527202
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import jinja2
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vars = dict()
    vars["ansible_architecture"] = "x86_64"
    vars["ansible_bios_date"] = "03/14/2014"
    vars["ansible_bios_version"] = "Google"
    vars["ansible_cmdline"] = {
        'BOOT_IMAGE': '/boot/vmlinuz-3.13.0-37-generic'
    }

# Generated at 2022-06-21 07:57:49.541523
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.vars.unsafe_proxy

    templar = None
    globals = {'A': '1'}
    locals = {'B': '2'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'A' in j2vars


# Generated at 2022-06-21 07:58:01.577926
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class MyTemplar:
        def __init__(self):
            self.available_variables = dict(a=1, b=2, c=3)
        def template(self, variable):
            if isinstance(variable, dict):
                return variable
            else:
                return str(variable)

    d = dict(a=10, b=20, c=30)
    globals = dict(x=1, y=2, z=3)
    def test(varname, expected):
        assert varname in v
        assert v[varname] == expected

    t = MyTemplar()
    v = AnsibleJ2Vars(t, globals, locals=d)
    test('a', 10)
    test('b', 20)
    test('c', 30)

# Generated at 2022-06-21 07:58:06.271243
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import ansible.playbook.play_context
    import ansible.template.template
    obj = AnsibleJ2Vars(ansible.template.template.Templar(loader=None, variables=None), ansible.playbook.play_context.PlayContext())
    ret = obj.__len__()
    assert ret == 0


# Generated at 2022-06-21 07:58:12.920924
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.config

    templar = ansible.template.Templar(loader=ansible.config.loader)
    globals = {'a': 1}
    locals = {'b': 2}

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert vars['a'] == 1
    assert vars['b'] == 2

# Generated at 2022-06-21 07:58:21.622915
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    templar = object()
    globals = { 'gvar': 1 }
    locals = { 'lvar1': 2, 'lvar2': 3 }
    hostvars = { 'hvar1': 4, 'hvar2': 5 }
    available_variables = {'avar1': 6, 'avar2': 7, 'avar3': 8, 'avar4': HostVars(hostvars)}

    class Templar(object):
        def __init__(self, avvars):
            self.available_variables = avvars
            return

    def _to_native(item):
        return str(item)

    ansiblej2vars = AnsibleJ2Vars(Templar(available_variables), globals, locals)

# Generated at 2022-06-21 07:58:32.697256
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # Test with empty constructor
    ansible_j2vars = AnsibleJ2Vars()
    assert 'test' not in ansible_j2vars

    # Test with basic variables
    # Setup
    templar = None
    globals = {'test': 1}
    locals = {'test': 2}
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    # Test
    assert 'test' in ansible_j2vars

    # Test with unknown variables
    # Setup
    templar = None
    globals = {}
    locals = {}
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    # Test
    assert 'test' not in ansible_j2vars

# Unit

# Generated at 2022-06-21 07:58:41.609169
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    assert isinstance(templar, Templar), 'AnsibleJ2Vars constructor failed to create instance of Templar'
    # AnsibleJ2Vars(templar, globals, locals=None)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals=None)
    assert isinstance(ansible_j2_vars, AnsibleJ2Vars), 'AnsibleJ2Vars constructor failed to create instance of AnsibleJ2Vars'

# Test method add_locals()

# Generated at 2022-06-21 07:59:04.445610
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVars

    templar_instance = Templar()

# Generated at 2022-06-21 07:59:12.208106
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'fooval', 'bar': 'barval'}
    variable_manager.options_vars = {'opt': 'optval'}
    loader = DataLoader()
    context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, context=context)


# Generated at 2022-06-21 07:59:22.619409
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    Test function __len__ of class AnsibleJ2Vars.
    '''
    #import pdb;pdb.set_trace()
    class TemplarClass:
        def template(self, var):
            return var
    templar = TemplarClass()
    globals = {}
    locals = {}
    j2_vars = AnsibleJ2Vars(templar, globals, locals)

    assert len(j2_vars) == 0

    templar.available_variables = {'key1': 'value1', 'key2': 'value2'}
    locals['key3'] = 'value3'
    locals['key4'] = 'value4'
    assert len(j2_vars) == 4

    j2_vars['key5'] = 'value5'
    assert len

# Generated at 2022-06-21 07:59:33.453812
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    proxy = AnsibleJ2Vars(templar, dict())

    # len of empty proxy equals zero
    assert len(proxy) == 0

    # len of proxy after append equals len of appended thing
    proxy._templar.available_variables = dict(a=1)
    assert len(proxy) == 1
    proxy._templar.available_variables = dict(('a', 1), ('b', 2))
    assert len(proxy) == 2

    # len of proxy after append equals len of appended thing
    proxy._templar.available_variables = dict(a=1)
    assert len(proxy) == 1
    proxy._templar.available_variables = dict((('a', 1), ('b', 2)))


# Generated at 2022-06-21 07:59:44.898630
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import collection_loader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    fake_vars = {'play_hosts': ['fakehostname']}
    fake_hostvars = HostVars(fake_vars)
    fake_loader = DataLoader()
    fake_variable_manager = VariableManager()
    fake_variable_manager.extra_vars = {'fake_extra_vars': True}
    fake_options = {}
    fake_context = PlayContext(**fake_options)

# Generated at 2022-06-21 07:59:49.696425
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import wrap_var

    templar = Templar(loader=None, variables={})
    dict_with_unsafetext = dict(dict1=AnsibleUnsafeText('value'))
    dict_without_unsafetext = dict(dict2=wrap_var('value'))
    ansible_args = dict(
        templar=templar,
        globals=wrap_var(dict_with_unsafetext),
        locals=wrap_var(dict_without_unsafetext),
    )
    ansible_j2vars = AnsibleJ2Vars(**ansible_args)

    # 'dict1' and 'dict2'

# Generated at 2022-06-21 07:59:58.472799
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    j2_vars = AnsibleJ2Vars(templar=Templar(),
                            globals={'test_global': 'test global'},
                            locals={'test_local': 'test local'})
    # get the keys
    keys = set()
    for k in j2_vars:
        keys.add(k)
    assert keys == {'test_global', 'test_local'}


# Generated at 2022-06-21 08:00:06.817467
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    def mock_template(data):
        return data

    fake_templar = type('', (), {
        'available_variables': {
            'a': 1,
            'b': 2,
            'c': 3,
            'd': 4,
            'e': 5,
        },
        'template': mock_template
    })()

    vars = AnsibleJ2Vars(fake_templar, {'a': 1, 'b': 2})
    assert len(vars) == 5

# Generated at 2022-06-21 08:00:14.357811
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars import VariableManager, HostVars
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    hostvars = HostVars(play_context=PlayContext())
    variable_manager = VariableManager(loader=DataLoader(), host_vars=hostvars)
    templar = Templar(loader=DataLoader(), variables=variable_manager)
    globals = {'foo': 'bar'}
    locals = {'l_baz': 'qux'}

    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['foo'] == 'bar'

# Generated at 2022-06-21 08:00:25.943891
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Arrange
    # Creating dummy class Templar
    class Templar(object):
        def __init__(self, template):
            self.available_variables = {'test_variable':
                                        {'message': 'Hello {{ test_variable }}',
                                         'unreachable_message': 'I am unreachable',
                                         'cannot_reach': '{{ test_variable }}',
                                         'cannot_reach_unreachable_message': '{{ unreachable_message }}'}}

        def template(self, data):
            return data['message']

    templar = Templar(template='Hello {{ test_variable }}')


# Generated at 2022-06-21 08:00:51.306279
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """
    AnsibleJ2Vars: __contains__ method
    """
    pass
