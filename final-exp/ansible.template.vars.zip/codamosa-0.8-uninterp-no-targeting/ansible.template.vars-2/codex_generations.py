

# Generated at 2022-06-21 07:51:11.585349
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar()

    j2vars = AnsibleJ2Vars(templar, {}, locals={'local_var': 'local_value'})

    j2vars_with_locals = j2vars.add_locals({'local_var2': 'local_value2'})
    assert 'local_var2' in j2vars_with_locals._locals
    assert j2vars_with_locals._locals['local_var2'] == 'local_value2'

    j2vars_with_existing_locals = j2vars.add_locals({'local_var': 'local_value2'})
    assert j2vars_with_existing_locals._locals['local_var'] == 'local_value2'

# Generated at 2022-06-21 07:51:18.188519
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar
    from ansible.vars.manager import VariableManager

    # test the constructor of AnsibleJ2Vars
    p = PlayContext()
    m = VariableManager()
    t = Templar(m, p)
    a = AnsibleJ2Vars(t, {})
    assert len(a._templar.available_variables) > 0
    assert len(a._locals) == 0
    assert a._globals == {}
    assert len(a) > 0
    for x in a:
        assert x in a

# Generated at 2022-06-21 07:51:28.500989
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class Templar:
        def __init__(self, avs):
            self.available_variables = avs

    t = Templar({'foo':1, 'bar':2, 'baz':3})
    g = {'alpha':1, 'beta':2, 'gamma':3}
    l = {'joe':1, 'jack':2, 'jim':3}

    ajv = AnsibleJ2Vars(t, g, l)

    # single values in each set
    assert 'foo' in ajv
    assert 'alpha' in ajv
    assert 'joe' in ajv

    # make sure the __iter__ method returns an iterable
    assert hasattr(ajv.__iter__(), '__iter__')

    # make sure the __iter__ method returns the correct length

# Generated at 2022-06-21 07:51:40.554666
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar

    templar = Templar()

    available_variables = {'var1': 'var1', 'var2': 'var2'}
    globals = {'g1': 'g1', 'g2': 'g2'}

    # Test with __contains__(var) return a True result
    vars = AnsibleJ2Vars(templar, globals=globals, locals={'var1': 'var1'})
    assert('var1' in vars)

    # Test with __contains__(var) return a False result
    vars = AnsibleJ2Vars(templar, globals=globals, locals={'var1': 'var1'})
    assert('var3' not in vars)


# Generated at 2022-06-21 07:51:48.366825
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    templar = jinja2.Environment(undefined=jinja2.StrictUndefined).from_string("").template.environment.undefined_singleton

    var_proxy = AnsibleJ2Vars(templar, {}, locals={'l_foo': 'l_bar'})
    assert all(k in var_proxy for k in ('foo', 'l_foo'))
    assert 'foo' not in var_proxy

    # with locals parameter
    var_proxy = AnsibleJ2Vars(templar, {}, locals={'l_foo': 'l_bar'}).add_locals({'l_bar': 'l_baz'})
    assert all(k in var_proxy for k in ('foo', 'l_foo', 'l_bar'))
    assert 'foo'

# Generated at 2022-06-21 07:51:59.600830
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    def test_iter():
        j2vars = AnsibleJ2Vars(templar, globals, locals=locals)
        for key, var in iteritems(j2vars):
            # test_dict_from_ansible_vars is an example from the unit test of
            # method test_dict_to_ansible_vars in module unit_test_utils.py
            # of the ansible package.
            if isinstance(var, dict) and key in test_dict_from_ansible_vars:
                if var != test_dict_from_ansible_vars[key]:
                    raise AssertionError('%s set to %s instead of %s' % (key, var, test_dict_from_ansible_vars[key]))

# Generated at 2022-06-21 07:52:12.564702
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManagerOptions
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    loader = DataLoader()
    variable_manager_options = VariableManagerOptions()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory, options=variable_manager_options)
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=dict(name='test_play')))

# Generated at 2022-06-21 07:52:21.662784
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)
    globals = dict()
    locals = dict(b='2', l_c='3', d='4')

    v = AnsibleJ2Vars(templar, globals, locals=locals)
    assert v['b'] == '2'
    assert v['c'] == '3'
    assert v['d'] == '4'

    v = v.add_locals(dict(e='5', l_f='6'))
    assert v['b'] == '2'
    assert v['c'] == '3'
    assert v['d'] == '4'
    assert v['e'] == '5'
    assert v['f'] == '6'


# Generated at 2022-06-21 07:52:32.763072
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.hostvars import HostVars

    templ = AnsibleJ2Vars(None, {'g': 'G', 'h': 'H'}, locals({'l': 'L'}))

    # Simple use case
    v = {'a': 'A', 'b': 'B'}
    templ._templar.available_variables = v
    assert len(templ) == 5
    assert len(templ) == len(frozenset([x for x in v] + ['l', 'g', 'h']))

    # Special cases
    v = {'a': 'A', 'b': 'B', 'vars': {'a': 'A', 'b': 'B'}}
    templ._templar.available_variables = v

# Generated at 2022-06-21 07:52:41.053930
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Unit test for method __getitem__ of class AnsibleJ2Vars
    # j2variables = AnsibleJ2Vars(vars)
    # hostvars = dict()
    # for host in groups['host']:
    #     hostvars[host] = dict()
    #     hostvars[host]['vars'] = dict()
    #     hostvars[host]['vars']['hostgroup'] = inventory.get_group(host).name
    # vars = dict()
    # vars['group_names'] = group_names
    # vars['groups'] = groups
    # vars['hostvars'] = hostvars
    # j2variables['vars'] = vars
    # pprint(j2variables['vars'])
    pass

# Generated at 2022-06-21 07:52:52.384874
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    a = AnsibleJ2Vars(None, {'abc':123}, locals={'abc':321})
    assert len(a) == 1

    b = AnsibleJ2Vars(None, {'abc':123}, locals={'def':321})
    assert len(b) == 2

    c = AnsibleJ2Vars(None, {'abc':123})
    assert len(c) == 1


# Generated at 2022-06-21 07:53:01.580244
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    class Templar:
        ''' dummy class to pass to class AnsibleJ2Vars constructor '''
        def __init__(self, locals):
            self.available_variables = dict()
            self._templar = locals

        def template(self, var):
            return self._templar.get(var)

    # test a dict containing only locals
    globals = dict()
    locals = dict(var0='0', var1='1')
    templar = Templar(locals)
    aj2v = AnsibleJ2Vars(templar, globals, locals=locals)
    assert locals == dict(aj2v.items())

    # test a dict containing only globals
    globals = dict(var2='2', var3='3')
    locals = dict()

# Generated at 2022-06-21 07:53:05.145455
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    mapping = AnsibleJ2Vars(None, dict(a=1, b=2, c=3))
    assert { x for x in mapping } == { 'a', 'b', 'c' }

# Generated at 2022-06-21 07:53:17.728227
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Initialize required variables
    templar = Templar(loader=None, variables=dict())
    globals = dict()
    locals = dict()

    # Test the empty class first.
    ansible_J2_vars = AnsibleJ2Vars(templar, globals, locals)

    # test empty set
    assert len(list(ansible_J2_vars.__iter__())) == 0

    # Test class containing all expected variables.
    locals['var1'] = 1
    locals['var2'] = 2

    globals['gvar1'] = 1
    globals['gvar2'] = 2

    templar.available_variables['var3'] = 3
    templar.available_vari

# Generated at 2022-06-21 07:53:21.493001
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    [ {}, {}, {}]
    '''
    proxy = AnsibleJ2Vars(templar=None, globals={}, locals={})
    assert [{}, {}, {}] == proxy



# Generated at 2022-06-21 07:53:33.582451
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    test_hosts = HostVars({"testhost1": {"ansible_host": "192.168.0.1"},
                           "testhost2": {"ansible_host": "192.168.0.2"}})
    test_vars = {"testvar1": "testval1", "testvar2": "testval2", "testvar3": "testval3"}
    test_playcontext = PlayContext(play_hosts=test_hosts, variable_manager=test_vars)
    test_templar = Templar(loader=None, variables=test_playcontext)

# Generated at 2022-06-21 07:53:44.705189
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None, shared_loader_searchpath=None)
    globals = dict(answer=42)
    locals = dict(foo='bar')

    v = AnsibleJ2Vars(templar, globals, locals)
    assert v['foo'] == 'bar'
    assert v['answer'] == 42
    assert 'foo' in v
    assert 'answer' in v
    assert 'foo' in v.keys()
    assert 'answer' in v.keys()
    assert len(v) == 2
    assert list(v.keys()) == ['foo', 'answer']
    assert list(v) == ['foo', 'answer']

    # now add some 'locals'
    v2 = v.add_locals(locals)

# Generated at 2022-06-21 07:53:49.470526
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={}, failsafe=True)
    locals_ = {
        'key': 'value',
    }
    globals_ = {
        'key': 'value',
    }
    j2vars = AnsibleJ2Vars(templar, globals_, locals_)

    # Make validation
    assert 'key' in j2vars


# Generated at 2022-06-21 07:54:00.074742
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    # __contains__ is called with a missing key and return False
    ansible_j2_vars = AnsibleJ2Vars(templar, {}, {})
    assert not ansible_j2_vars.__contains__("a")

    # __contains__ is called with a key present in _locals
    assert ansible_j2_vars.__contains__("b")

    # __contains__ is called with a key present in available_variables
    templar.set_available_variables(dict(c=1))
    assert ansible_j2_vars.__contains__("c")

    # __contains__ is called with a key present in _globals
    assert ansible_j

# Generated at 2022-06-21 07:54:10.754206
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar

    root_vars = dict(
        foo='root',
        bar='root',
    )
    vars = AnsibleJ2Vars(Templar(loader=None), root_vars)

    level1_vars = dict(
        foo='level1',
        bar='level1',
    )
    level2_vars = dict(
        foo='level2',
        bar='level2',
    )

    vars = vars.add_locals(level1_vars)
    assert vars['foo'] == 'level1'
    assert vars['bar'] == 'level1'

    vars = vars.add_locals(level2_vars)
    assert vars['foo'] == 'level2'

# Generated at 2022-06-21 07:54:23.507793
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar

    # Prepare test data
    fake_loader = DataLoader()
    fake_host = Host(name='fake_host')
    fake_host.vars = HostVars(fake_host, {})
    fake_host.groups = []

    fake_variable_manager = VariableManager()
    fake_variable_manager.set_host_variable(fake_host, 'fake_host_var_1', 'fake_host_var_1_value')
    fake_variable_manager.set_host

# Generated at 2022-06-21 07:54:27.863736
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    t = Templar(loader=None)
    d = {'c': 'C'}

    v = AnsibleJ2Vars(t, d)
    assert not ('a' in v)
    assert 'c' in v


# Generated at 2022-06-21 07:54:33.437774
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    t = Templar(None)
    a = AnsibleJ2Vars(t, {})
    assert a is a.add_locals(None)
    b = a.add_locals({'x': 1})
    assert isinstance(b, AnsibleJ2Vars)
    assert b is not a
    assert a['x'] is missing
    assert b['x'] == 1


# Generated at 2022-06-21 07:54:34.762708
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert False, "No tests for AnsibleJ2Vars.__getitem__"

# Generated at 2022-06-21 07:54:43.161735
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Arrange
    var1 = 'foo'
    var2 = 'bar'
    templar = Templar(loader=None, variables={var1: var1, var2: var2})
    globals = {var1: var1, var2: var2}
    locals = {'a': 1, 'b': 2}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # Act and Assert
    assert(var1 in j2vars)
    assert(var2 in j2vars)
    assert('a' in j2vars)
    assert('b' in j2vars)
    assert('z' not in j2vars)

    # Arrange
    templar = Templar(loader=None, variables={})
    globals = {}
    locals

# Generated at 2022-06-21 07:54:53.688597
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = Templar(Loader(), variables={'var1': 'a', 'var2': 'b'})
    vars = AnsibleJ2Vars(templar, {'var3': 'c'}, locals={'var4': 'd'})
    assert set(vars) == {'var1', 'var2', 'var3', 'var4'}
    assert 'var1' in vars
    assert 'var2' in vars
    assert 'var3' in vars
    assert 'var4' in vars
    assert 'var5' not in vars


# Generated at 2022-06-21 07:55:01.009700
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Test object creation
    proxy = AnsibleJ2Vars(None, None)
    # Pass locals to add_locals - with one element in the locals dict
    locals = {'test':'value'}
    proxy = proxy.add_locals(locals)
    assert proxy is not None
    # Test __getitem__ - the locals dict should be available
    assert proxy['test'] == 'value'
    # Test __getitem__ - the locals dict should be available - this time with a different element
    locals = {'test2':'value2'}
    proxy = proxy.add_locals(locals)
    assert proxy is not None
    # Test __getitem__ - the locals dict should be available
    assert proxy['test2'] == 'value2'
    # Test __getitem__ - the locals dict should be available - same

# Generated at 2022-06-21 07:55:13.379542
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.vars.hostvars import HostVars
    import jinja2
    # Test for constructor with different arguments
    str_arg = "default"
    int_arg = 2
    dict_arg = {'key': 'value'}
    list_arg = ['1', '2']
    AnsibleJ2Vars(str_arg, dict_arg)
    AnsibleJ2Vars(str_arg, dict_arg, locals = dict_arg)
    AnsibleJ2Vars(str_arg, dict_arg, locals = list_arg)
    AnsibleJ2Vars(str_arg, dict_arg, locals = None)

# Generated at 2022-06-21 07:55:23.767562
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import pytest
    from ansible.vars.hostvars import HostVars
    j2vars = AnsibleJ2Vars(None, None, locals=None)
    j2vars._templar.available_variables = {'a': 'b'}
    assert j2vars.__getitem__('a') == 'b'

    j2vars = AnsibleJ2Vars(None, None, locals=None)
    j2vars._templar.available_variables = {'a': 'b'}
    assert j2vars.__getitem__('z') is None

    j2vars = AnsibleJ2Vars(None, None, locals=None)
    j2vars._templar.available_variables = {'a': 'b'}
    j2v

# Generated at 2022-06-21 07:55:32.878931
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars_combiner
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import sys

    fake_loader = DictDataLoader({
        "test.j2": "hello {{ test_var }}",
    })
    templar = Templar(loader=fake_loader, variables=dict(test_var='world'))

    vars = AnsibleJ2Vars(templar, dict())

    assert vars['test_var'] == "world"
    assert 'test_var' in vars

# Generated at 2022-06-21 07:55:41.728758
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    globals = dict({'a': 'test_globals_a'})
    locals = dict({'a': 'test_locals_a'})
    templar = object()
    obj = AnsibleJ2Vars(templar, globals, locals)

    assert len(obj) == 3

# Generated at 2022-06-21 07:55:48.013691
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    try:
        from ansible.plugins.loader import action_loader
    except ImportError:
        from ansible.utils.plugins import action_loader
    from ansible.vars.manager import VariableManager

    templar = action_loader._create_templar(VariableManager())
    globals = {"test_globals": "test_globals"}

    vars = AnsibleJ2Vars(templar, globals)

    assert len(vars) == 0



# Generated at 2022-06-21 07:55:51.586925
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import jinja2
    from ansible.templating import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    templar = Templar(loader=None)
    locals = dict(l_1='1', l_2='2')
    globals = dict(g_1='1', g_2='2')
    variables = dict(v_1='1', v_2='2')
    templar._available_variables = UnsafeProxy(variables)

    obj = AnsibleJ2Vars(templar, globals, locals=locals)
    assert sorted(obj.__iter__()) == sorted(list(variables) + list(locals) + list(globals))

# Generated at 2022-06-21 07:56:02.960060
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2
    import ansible.parsing.vault

    t = ansible.template.AnsibleJ2Vars(
        [],
        dict(a=0, b=1)
    )

    # init
    assert isinstance(t, dict)
    assert 'a' in t
    assert 'b' in t
    assert 'c' not in t
    assert t['a'] == 0
    assert t['b'] == 1

    # add locals
    locals = dict(a=10, c=30)
    t1 = t.add_locals(locals)
    assert t1['a'] == 10
    assert t1['b'] == 1
    assert t1['c'] == 30

    # NOTE: Keep it for later use if needed
#    env = jinja2.Environment(

# Generated at 2022-06-21 07:56:14.970301
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    # Setup
    template_vars_data = {}
    template_vars_data['hostvars'] = HostVars(dict())
    template_vars_data['omit'] = 'omit_value'
    template_vars_data['me'] = 'myself'
    template_vars_data['vars'] = 'vars_value'

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = Variable

# Generated at 2022-06-21 07:56:25.837555
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import copy
    import jinja2
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template.safe_eval import safe_eval
    from ansible.template.templar import Templar

    def make_vars(obj):
        return AnsibleJ2Vars(Templar(loader=None), obj)

    def assert_contains(vars, item):
        assert vars.__contains__(item) == contains(vars, item)
        assert vars.__contains__(item) == contains(vars, item)
        assert vars.__contains__(item) == contains(vars, item)


# Generated at 2022-06-21 07:56:31.510925
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import ansible.module_utils.common._collections_compat
    from ansible.template import Templar

    templar = Templar(None)
    j2vars = AnsibleJ2Vars(templar, dict(gvar="gval"), dict(lvar="lval"))
    assert ansible.module_utils.common._collections_compat.is_iterable(j2vars)

    for k in j2vars:
        assert k in ("gvar", "lvar")

# Generated at 2022-06-21 07:56:38.377226
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = {}
    globals = {}
    locals = {}
    # initialize an object of class AnsibleJ2Vars
    vars = AnsibleJ2Vars(templar, globals, locals)
    # check if the instance is an object of class AnsibleJ2Vars
    assert isinstance(vars, AnsibleJ2Vars), \
        'Object initialization of AnsibleJ2Vars is invalid'

# Generated at 2022-06-21 07:56:46.117306
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar():
        def template(self, variable):
            return variable

        def available_variables(self, variable):
            return variable

        def _is_unsafe_var(self, variable):
            return variable

    templar = Templar()
    globals = dict()

    locals = dict()
    locals["key"] = "value"

    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert j2vars["key"] == "value"

# Generated at 2022-06-21 07:56:47.114437
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert False, "Test not implemented"

# Generated at 2022-06-21 07:56:54.196832
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    jv = AnsibleJ2Vars(templar=None, globals=dict(a=1, b=2))
    assert 'a' in jv
    assert 'b' in jv
    assert 'c' not in jv

# Generated at 2022-06-21 07:57:06.287994
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from utils.listify import listify_lookup_plugin_terms

    templar = Templar(loader=None, variables={'foo': 'bar'})
    j2vars = AnsibleJ2Vars(templar, {'bar': 'foo'}, {})

    assert 'foo' in j2vars
    assert 'bar' in j2vars
    assert 'ansible_installed_packages' in j2vars
    assert 'ansible_installed_package' not in j2vars
    assert 'ansible_installed_package_' not in j2vars
    assert 'baz' not in j2vars

# Generated at 2022-06-21 07:57:14.297304
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """ test method AnsibleJ2Vars.__iter__ """
    from ansible.template import Templar
    templar = Templar(None)
    locals = {'b': 2, 'a': 1}
    available_variables = {'c': 3, 'd': 4}
    globals = {'e': 5, 'f': 6}
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    templar.available_variables = available_variables
    expected_keys = set(['b', 'a', 'c', 'd', 'e', 'f'])
    actual_keys = set(ansible_j2vars.__iter__())
    assert expected_keys == actual_keys

# Generated at 2022-06-21 07:57:26.884129
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    t = Templar(loader=None, shared_loader_obj=None)
    a = AnsibleJ2Vars(templar=t, globals={"g1":"v1", "g2":"v2"}, locals={"l1":"v1", "l2":"v2"})
    assert set(a) == set(["g1", "g2", "l1", "l2"])

    # not in locals, globals
    try:
        set(a) == set(["g1", "g2", "l1", "l2", "a"])
    except:
        pass
    else:
        raise AssertionError("__iter__ should raise error for not in locals, globals")

    # not in locals, in globals

# Generated at 2022-06-21 07:57:30.120608
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    proxy = AnsibleJ2Vars(Templar(), {'a': 1})
    assert len(proxy) == 1


# Generated at 2022-06-21 07:57:30.709062
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-21 07:57:39.882644
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class Templar:
        def __init__(self, available_variables, template):
            self.available_variables = available_variables
            self.template = template
    def template(x): return x
    templar = Templar(['var1'], template)
    globals = {'glob1': 'glob1'}
    locals = {'l_loc1': 'loc1'}
    jv = AnsibleJ2Vars(templar, globals, locals)
    assert jv['var1'] == 'var1'
    assert jv['glob1'] == 'glob1'
    assert jv['loc1'] == 'loc1'
    new_locals = {'l_loc2': 'loc2'}

# Generated at 2022-06-21 07:57:41.975554
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class Templar:
        available_variables = {
            'var1': 1,
            'var2': 2,
        }

        def template(self, variable):
            return variable

    from ansible.compat.tests.mock import MagicMock
    globals = {'glob1': 1, 'glob2': 2}

    var = AnsibleJ2Vars(Templar(), globals)
    assert len(var) == 4

# Generated at 2022-06-21 07:57:43.481434
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # TODO: Add unit test
    pass

# Generated at 2022-06-21 07:57:53.668292
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    # New object
    templar = Templar()
    globals = {}
    locals = {}
    obj = AnsibleJ2Vars(templar, globals, locals)

    # Templating result of HostVars is HostVars
    import copy
    x = copy.deepcopy(obj)
    x['vars'] = HostVars(templar, {}, {}, {}, {})
    assert type(x['vars']) is HostVars

    # Templating result of dict is dict
    x['vars'] = {'test': 'test'}
    assert type(x['vars']) is dict

    # Templating result of string is string
    x['vars'] = 'test'

# Generated at 2022-06-21 07:58:11.531257
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = Templar(loader=None, variables={})
    j2vars = AnsibleJ2Vars(templar, globals={})
    locals = {'a': 'A', 'b': 'B'}
    new_j2vars = j2vars.add_locals(locals)
    # make sure the original object is not modified
    assert 'a' not in j2vars
    assert 'b' not in j2vars
    # make sure the new object contains the locals
    assert 'a' in new_j2vars
    assert 'b' in new_j2vars
    assert new_j2vars['a'] == 'A'
    assert new_j2vars['b'] == 'B'

# Generated at 2022-06-21 07:58:20.809293
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    import string
    import random

    test_variables = {
        "v_%s" % ''.join(random.choice(string.ascii_lowercase) for _ in range(8)): 
            ''.join(random.choice(string.ascii_lowercase) for _ in range(8)) for _ in range(10)
    }
    test_globals = {
        "g_%s" % ''.join(random.choice(string.ascii_lowercase) for _ in range(8)): 
            ''.join(random.choice(string.ascii_lowercase) for _ in range(8)) for _ in range(10)
    }

# Generated at 2022-06-21 07:58:31.727812
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # 1
    templar = {}
    globals = {}
    locals = {}
    ansible_j2vars_obj = AnsibleJ2Vars(templar, globals, locals)
    assert not ansible_j2vars_obj.__contains__('k')
    # 2
    templar = {}
    globals = {'k': 'v'}
    locals = {}
    ansible_j2vars_obj = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2vars_obj.__contains__('k')
    # 3
    templar = {'k': 'v'}
    globals = {}
    locals = {}

# Generated at 2022-06-21 07:58:41.650871
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar

    templar = Templar()
    globals = dict(
        k8s_type='pod',
        k8s_name='foo',
    )

    locals = dict(
        k8s_state='present',
        k8s_force=False,
    )
    vars1 = AnsibleJ2Vars(templar, globals, locals)
    assert 'k8s_type' in vars1
    assert 'k8s_name' in vars1
    assert 'k8s_state' in vars1
    assert 'k8s_force' in vars1
    assert not vars1['k8s_force']



# Generated at 2022-06-21 07:58:46.525651
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Variable containing empty dictionary
    locals = {}
    # Object containing data to __getitem__ and __contains__
    globals = {}
    # Creating Templar() object
    templar = Templar(basedir=None)

    # Creating object of AnsibleJ2Vars
    vars_object = AnsibleJ2Vars(templar, globals, locals)

    # Testing object created or not
    assert isinstance(vars_object, AnsibleJ2Vars)

# Generated at 2022-06-21 07:58:58.282142
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    os = __import__('os')
    glob = __import__('glob')
    path = __import__('path')
    from ansible.template.safe_eval import safe_eval

    templar = __import__('ansible.template.templar').template.templar
    templar = templar.Templar(loader={}, variables={})
    vars_proxy = AnsibleJ2Vars(templar, globals={'os': os, 'path': path, 'glob': glob, 'str': str}, locals={'l_str': str})
    # os.path.join(base, "hostvars.yml")
    # glob.glob(os.path.join(base, "hostvars.yml*"))

# Generated at 2022-06-21 07:59:09.921997
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'ansible_host': 'host1', 'ansible_user': 'user1'})
    cvars = AnsibleJ2Vars(templar, {'hostvars': {}, 'groups': {'ungrouped': {'hosts': ['host1']}}}, locals={'l_vars': {'x': 'localx', 'y': 'localy'}})
    # create the list of variables, it should contain locals and available_variables but not globals
    var_list = [v for v in cvars]
    assert 'ansible_host' in var_list
    assert 'ansible_user' in var_list
    assert 'x' in var_list
    assert 'y' in var_list

# Generated at 2022-06-21 07:59:18.360011
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    template_vars = {'var1': 'foo', 'var2': 'bar'}
    globals_vars = {'globals1': 'globals foo', 'globals2': 'globals bar'}
    locals_vars = {'vars': {'var1': 'locals foo'}}

    v = AnsibleJ2Vars(Templar(loader=None), globals_vars, locals_vars)

    assert  'var1' in v
    assert 'var2' in v
    assert 'globals2' in v
    assert 'globals3' not in v

# Generated at 2022-06-21 07:59:20.078377
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # TODO implement this test
    pass


# Generated at 2022-06-21 07:59:31.345006
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.core import FactManager
    from ansible.module_utils.facts import default_collectors as dflt_cltrs
    from ansible.vars.manager import load_extra_vars
    import pytest

    fm = FactManager(dflt_cltrs)
    fm.collect()
    facts = fm._facts
    available_vars = load_extra_vars(loader=None, variables=facts)

# Generated at 2022-06-21 07:59:50.302777
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    global_vars = dict(foo=dict(bar=AnsibleUnsafeText('bar')))
    local_vars = dict(l_p=AnsibleUnsafeText('p'), l_q=AnsibleUnsafeText('q'))

    dict_under_test = AnsibleJ2Vars(templar=templar, globals=global_vars, locals=local_vars)
    assert len(dict_under_test) == 3
    assert 'foo' in dict_under_test
    assert 'p' in dict_under_test
    assert 'q' in dict_under_test


# Generated at 2022-06-21 07:59:53.518942
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # This function is here to make pyflakes happy, so it can detect the docstring
    # defining the unit test as a test, otherwhise it would complain that it is
    # unused
    return True


# Generated at 2022-06-21 08:00:00.128831
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.task_include import TaskInclude

    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    from ansible.parsing.jinja2.objects import AnsibleVars
    from ansible.template.template import Templar

    from ansible.vars.hostvars import HostVars

    rolename = "test"

    j2_var_manager = AnsibleVars([], [])
    j2_var_manager._vars_cache['role_{}'.format(rolename)] = {'some': 'thing'}
    j2_var_manager._vars_cache['some'] = 'other thing'


# Generated at 2022-06-21 08:00:09.129616
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import wrap_var

    variable_manager = DataLoader()

    variable_manager.set_vars({"outerfoo": "outerbar"})
    variable_manager.set_vars({"innerfoo": "innerbar"})

    wrap_var(variable_manager, "outerfoo")
    wrap_var(variable_manager, "innerfoo")

    vars = AnsibleJ2Vars(variable_manager, {"outer": "bar"})

    assert len(vars) == 2

# Generated at 2022-06-21 08:00:21.325674
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import pytest

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence

    with pytest.raises(AnsibleError):
        AnsibleJ2Vars(Templar(VariableManager(), loader=DataLoader()), {}, locals={})

    class j2:
        def __init__(self):
            self.environment = dict()
            self.environment.loader = DataLoader()


# Generated at 2022-06-21 08:00:24.820094
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    j2vars = AnsibleJ2Vars({}, globals=dict(), locals=None)
    assert len(j2vars) == 0, "The number of variables should be 0"

# Generated at 2022-06-21 08:00:25.602584
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert AnsibleJ2Vars(None, None)

# Generated at 2022-06-21 08:00:36.405418
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    # setup object
    templar = Templar()
    templar.available_variables = {}
    globals = {}
    locals = {}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    # call the method to test
    result = aj2v.__iter__()
    assert result == iter([])
    aj2v._templar.available_variables = {'A': 'a'}
    result = aj2v.__iter__()
    assert result == iter(['A'])
    aj2v._locals = {'B': 'b'}
    result = aj2v.__iter__()
    assert result == iter(['B', 'A'])
    aj2v._globals

# Generated at 2022-06-21 08:00:41.614408
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play as PlayBook
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from io import open
    import pytest
    import os
    import tempfile
    import shutil
    import sys

    local_vars = dict()
    local_vars['a'] = 1
    local_vars['b'] = 2
    local_vars['c'] = 3

    # Create AnsibleJ2Vars
    data_loader = DataLoader()
    variable_manager = VariableManager()
    inner_

# Generated at 2022-06-21 08:00:51.686228
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar

    # AnsibleJ2Vars variable that has the template variable 'myvar'
    j2vars1 = AnsibleJ2Vars(Templar(), {}, {"myvar": "myval"})
    assert('myvar' in j2vars1)
    assert('myvar1' not in j2vars1)

    # AnsibleJ2Vars variable that has the template variable 'myvar' and global variable 'mygvar'
    j2vars2 = AnsibleJ2Vars(Templar(), {"mygvar": "mygval"}, {"myvar": "myval"})
    assert('myvar' in j2vars2)
    assert('myvar1' not in j2vars2)
    assert('mygvar' in j2vars2)
   