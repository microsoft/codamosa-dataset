

# Generated at 2022-06-21 07:51:01.426820
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    globals = {
        'g1': 1,
        'g2': 2,
        'g3': 3,
    }

    locals = {
        'l1': 1,
        'l2': 2,
        'l3': 3,
    }

    j2vars = AnsibleJ2Vars(templar, globals, locals)
    result = len(j2vars)
    assert result == 6


# Generated at 2022-06-21 07:51:13.252409
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar()
    globals = templar.available_variables
    locals = {'a_varname': 'a_varvalue', 'b_varname': 'b_varvalue'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    expected_result = {'a_varname': 'a_varvalue', 'b_varname': 'b_varvalue'}
    assert j2vars.add_locals({'c_varname': 'c_varvalue'})._locals == expected_result
    assert j2vars._locals == locals
    assert j2vars.add_locals(None)._locals == locals

# Generated at 2022-06-21 07:51:25.817847
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.module_utils import basic
    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        "vars": """
            test_var = 'test_val'
        """,
        "task": """
            {% if test_var is defined %}
                foo = 'bar'
            {% else %}
                baz = 'bax'
            {% endif %}
            {{ foo }}
        """,
    })

    env = Environment(loader=loader)
    env._templates['vars']._do_substitutions = False  # so we can test variables

    template = env.get_template('task')

    result = template.render(
        test_var = 'test_val',
    )

    assert result == 'bar'

# Unit test

# Generated at 2022-06-21 07:51:32.187457
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = 'templar'
    globals = 'globals'
    locals = 'locals'
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert(ajv._templar == templar)
    assert(ajv._globals == globals)
    assert(ajv._locals == locals)

# Generated at 2022-06-21 07:51:43.272312
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.vault import VaultLib
    import json
    import random
    import string
    import tempfile
    import yaml

    vault_pass = ''.join(random.sample(string.ascii_letters + string.digits, 10))

    with tempfile.NamedTemporaryFile(prefix='ansible-vault-input-') as f_vaultinput:
        f_vaultinput.write(vault_pass)
        f_vaultinput.flush()

        vault = VaultLib(f_vaultinput.name)
        plain_data = {'key': 'value'}
        cipher_data = vault.encrypt(yaml.dump(plain_data, default_flow_style=False))

    templar = DummyTemplar()
    aj2v = AnsibleJ

# Generated at 2022-06-21 07:51:50.921145
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Assume two variables sets with two variables.
    templar = dict(['a', 1], ['b', 2])
    globals = dict(['c', 3], ['d', 4])
    locals = dict()

    # Create the new object and check the lenght of it
    variables = AnsibleJ2Vars(templar, globals, locals)
    assert(4 == len(variables))


# Generated at 2022-06-21 07:52:02.036854
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar():
        def __init__(self):
            pass

        def template(self, value):
            return value

    class HostVars():
        pass

    # test case 1:
    templar = Templar()
    globals = {}
    locals = None
    j2_vars = AnsibleJ2Vars(templar, globals, locals)
    key = "aa"
    value = "aa"
    templar.available_variables = {key: value}
    assert j2_vars[key] == value

    # test case 2:
    templar = Templar()
    globals = {}
    locals = {"bb": "bb"}
    j2_vars = AnsibleJ2Vars(templar, globals, locals)
    key = "bb"

# Generated at 2022-06-21 07:52:14.779319
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.unsafe_proxy import wrap_var

    templar = AnsibleJ2Vars({}, None, None)

# Generated at 2022-06-21 07:52:19.845302
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    templar = None
    globals_= {'b': [1, 2, 3], 'c': 'string'}
    locals_= {'a': True}

    vars = AnsibleJ2Vars(templar, globals_, locals_)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' not in vars



# Generated at 2022-06-21 07:52:30.813298
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    class Templar:

        def template(self, variable):
            return variable

    templar = Templar()

    globals = {
        'global1': 'global1 value',
        'global2': 'global2 value',
        'global3': 'global3 value',
    }
    locals = {
        'local1': 'local1 value',
        'local2': 'local2 value',
        'local3': 'local3 value',
    }

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'local1' in vars
    assert 'local2' in vars
    assert 'local3' in vars
    assert 'global1' in vars
    assert 'global2' in vars
    assert 'global3' in vars
    assert 'notexist' not in v

# Generated at 2022-06-21 07:52:35.016683
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert isinstance(AnsibleJ2Vars({}, {}, locals=None), AnsibleJ2Vars)

# Generated at 2022-06-21 07:52:45.404404
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Set up context
    from ansible.template import Templar
    templar = Templar(None, None)
    # locals = dict(
    #     foo="bar",
    #     baz=dict(
    #         quux=dict(
    #             quuz="bar",
    #             corge="bar",
    #         ),
    #     ),
    # )
    # vars = AnsibleJ2Vars(templar, {}, locals)
    #
    # # Execute test method
    # new_locals = dict(
    #     baz=dict(
    #         quux=dict(
    #             corge="quux",
    #         ),
    #     ),
    # )
    # vars2 = vars.add_locals(new_locals)
    #


# Generated at 2022-06-21 07:52:56.562424
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    ###############################################################
    # test_AnsibleJ2Vars.test_for_undefined_variable
    ###############################################################
    def test_for_undefined_variable():
        templar = Templar(loader=DictDataLoader({}), variables={})
        vars_object = AnsibleJ2Vars(templar, globals={})

        try:
            vars_object['undefined_foo']
            raise Exception('AnsibleJ2Vars.__getitem__ did not throw exception for undefined variable')
        except KeyError as e:
            assert str(e)

# Generated at 2022-06-21 07:53:07.293051
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Setup
    import jinja2
    env = jinja2.Environment(loader=jinja2.DictLoader({'a.j2': '{{ a }}'}), undefined=jinja2.StrictUndefined)
    templar = 'a'

    def _templar_mock(template):
        assert template == templar
        return templar

    class Templar(object):
        def __init__(self, env, variables):
            self.environment = env
            self.available_variables = variables
            self.template = _templar_mock

    globals = {'a': 1}
    locals = {'a': 2}

    def _getitem_mock(varname):
        assert varname == templar
        raise AnsibleUndefinedVariable(varname)



# Generated at 2022-06-21 07:53:19.709026
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template.templar import Templar

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = dict(foo=dict(a=1))
    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=True)

    proxy = AnsibleJ2Vars(templar=templar, globals={})

    assert 'a' in proxy['foo']


# Generated at 2022-06-21 07:53:27.109683
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    Unit test: test method __len__ of AnsibleJ2Vars
    '''

    # initialize with good parameters
    locals = {}
    globals = {}
    templar = {}

    variables = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)
    assert len(variables) == 0

    # add variables in all data members
    variables._locals['variable1'] = 'some_value1'
    variables._templar.available_variables['variable2'] = 'some_value2'
    variables._globals['variable3'] = 'some_value3'

    assert len(variables) == 3

# Generated at 2022-06-21 07:53:38.158098
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import ansible.template.safe_eval

    globals = {
        'foo': 'foo',
        'bar': 'bar',
        'baz': 'baz',
    }
    locals = {
        'foo': 'FOO',
        'baz': 'BAZ',
    }
    templar = ansible.template.safe_eval.AnsibleJ2Template("test", "", {})
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)
    assert sorted(v for v in ansible_vars) == ['bar', 'baz', 'foo']

# Generated at 2022-06-21 07:53:40.515289
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import ansible.module_utils.basic as basic
    templar = basic.AnsibleModule(argument_spec={})
    globals = {}
    locals = {}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    len_ajv = len(ajv)
    assert len_ajv == 2


# Generated at 2022-06-21 07:53:49.025633
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.vars import Templar
    from ansible.template.templar import AnsibleUndefinedVariable

    (d, t) = dict(), dict()
    tmp = VariableManager()
    tmp.add_host_vars(host=None, hostvars=d)
    tpl = Templar(loader=DataLoader(), variables=tmp)
    av = AnsibleJ2Vars(tpl, t)

    assert not ('a' in av)
    d['a'] = 1
    assert 'a' in av
    assert av['a'] == 1


# Generated at 2022-06-21 07:53:59.861137
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.templating import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar("/path/to/basedir", loader=None)
    templar.set_available_variables(dict(foo="foo_value",bar="bar_value"))
    globals = dict(bam="bam_value", baz="baz_value")
    locals = dict(xxx="xxx_value", yyy="yyy_value")

    # test AnsibleJ2Vars initialization
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert(len(j2vars) == 7)

# Generated at 2022-06-21 07:54:12.484470
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''test AnsibleJ2Vars class method __contains__'''
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    var_manager = VariableManager()
    var_manager._extra_vars = {'var1': 'value1'}

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=var_manager, fail_on_undefined=False)

    j2vars = AnsibleJ2Vars(templar, {}, {})
    assert 'var1' in j2vars


# Generated at 2022-06-21 07:54:15.931460
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2
    assert AnsibleJ2Vars
    assert jinja2
    templar = None
    globals = {}
    locals = { 'a': 'A' }
    a = AnsibleJ2Vars(templar, globals, locals)
    assert a == {'a': 'A'}

# Generated at 2022-06-21 07:54:24.771078
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible import constants as C
    from ansible.plugins.loader import fragment_loader
    from ansible.template import Templar

    templar = Templar(fragment_loader, variables={u'var': u'foo'}, fail_on_undefined=False, disable_lookups=False, failsafe=False, env={u'BAR': u'foo'})
    j2vars = AnsibleJ2Vars(templar, {u'bar': u'foo'})

    assert u'var' in j2vars
    assert u'BAR' in j2vars
    assert u'bar' in j2vars
    assert u'foo' not in j2vars


# Generated at 2022-06-21 07:54:34.719404
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.hostvars import HostVars

    templar = type('Templar', (), {})
    templar.available_variables = {'a': 1, 'b': 2, 'c': {'d': 3}}
    templar.template = lambda x: x

    vars = AnsibleJ2Vars(templar, {'x': 4, 'y': 5})

    assert len(vars) == 5
    assert vars['a'] == 1
    assert vars['b'] == 2
    assert vars['c'] == {'d': 3}
    assert vars['x'] == 4
    assert vars['y'] == 5

    # non existing variable
    try:
        vars['z']
        assert False
    except KeyError:
        pass

    assert type

# Generated at 2022-06-21 07:54:43.161733
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible import constants as C
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar

    def set_vars(vars_dict):
        '''
        Set variable for test
        :param vars_dict: variable name and variable value
        :return:
        '''
        variable_manager = VariableManager()
        variable_manager.extra_vars = vars_dict
        variable_manager._options = Options(tags={}, listtags=False, listtasks=False, listhosts=False, syntax=False, diff=False)
        variable_manager.options_vars = {}
        variable_manager.set_inventory(InventoryManager(loader=None, sources=''))

# Generated at 2022-06-21 07:54:48.558564
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    tmp_jab = AnsibleJ2Vars(None, None, locals = {'a': 1, 'b': 2})
    tmp_jab.add_locals({'b': 3, 'c': 4})
    assert tmp_jab._locals == {'a': 1, 'b': 3, 'c': 4}

# Generated at 2022-06-21 07:54:58.722975
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import test_loader
    from ansible.vars.hostvars import HostVars

    test_loader.add_directory(os.path.join(os.path.dirname(__file__), 'filter_plugins'))

    vault_secret = VaultLib([])

# Generated at 2022-06-21 07:55:11.160981
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.strategy import get_strategy
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a play that does nothing
    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = []
    )

# Generated at 2022-06-21 07:55:22.338789
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
	from ansible.parsing.yaml.objects import AnsibleUnicode
	from ansible.template.safe_eval import ansible_eval

	my_templar = ansible_eval
	my_globals = {}

	my_locals = {}
	my_templar.available_variables = {
		"foo": AnsibleUnicode("bar"),
		"baz": AnsibleUnicode("42"),
		"bam": AnsibleUnicode("toto")
	}

	my_vars = AnsibleJ2Vars(my_templar, my_globals, locals=my_locals)

	assert my_vars["foo"] == "bar"
	assert my_vars["baz"] == "42"
	assert my_vars["bam"]

# Generated at 2022-06-21 07:55:27.375404
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    Test for method __len__ of class AnsibleJ2Vars
    """
    templar = Templar(loader=None)
    vars = AnsibleJ2Vars(templar, globals={})
    actual = len(vars)
    assert actual == 0


# Generated at 2022-06-21 07:55:43.733038
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    # Initializing AnsibleJ2Vars object
    templar = None
    globals = {'g_var': 'g_val'}
    locals = {'l_var': 'l_val'}
    aj2v = AnsibleJ2Vars(templar, globals, locals)

    # Test with locals
    locals = {'l_var1': 'l_val1'}
    ans = aj2v.add_locals(locals)
    assert 'g_var' in ans._globals
    assert 'l_var' in ans._locals
    assert 'l_var1' in ans._locals

    # Test without locals
    ans = aj2v.add_locals(None)
    assert 'g_var' in ans._globals

# Generated at 2022-06-21 07:55:55.314014
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.template
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)

    globals = dict()
    vars = AnsibleJ2Vars(templar, globals=globals)

    assert 'test123' not in vars

    globals['test123'] = 'hello123'
    assert 'test123' in vars

    globals['test123'] = 123
    assert 'test123' in vars

    globals['test123'] = HostVars(name='test123')
    assert 'test123' in vars

    globals['test123'] = None
    assert 'test123' in vars


# Generated at 2022-06-21 07:56:04.930395
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os

    import unittest
    from unittest.mock import MagicMock

    from ansible.vars import hostvars

    from ansible.templating import Templar
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.serializer.safe_yaml import SafeDumper
    from ansible.vars.manager import VariableManager

    from ansible.playbook.included_file import IncludedFile


# Generated at 2022-06-21 07:56:17.676083
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import mock
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class FakeVarManager:
        def __init__(self):
            self.vars = dict()

    vm = FakeVarManager()

    # Init data
    available_variables = dict()
    available_variables['var1'] = 'var1'
    available_variables['var2'] = 'var2'

    locals = dict()
    locals['var1'] = 'var_local1'
    locals['var2'] = 'var_local2'
    locals['var3'] = 'var_local3'

    globals = dict()
    globals['var2'] = 'var_global2'
    globals['var4']

# Generated at 2022-06-21 07:56:25.095970
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import sys, os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from ansible.template import Templar
    templar = Templar(loader=None)

    vars = AnsibleJ2Vars(templar, globals=dict(a=1))
    assert ('a' in vars) == True
    assert ('b' in vars) == False

# Generated at 2022-06-21 07:56:33.282324
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class MockVaultSecret(AnsibleVaultEncryptedUnicode):
        def __init__(self):
            pass

    variable_manager = VariableManager()
    variable_manager.set_inventory(None)
    play_context = PlayContext()

    templar = Templar(loader=None, variables=variable_manager, loader=None,
                      shared_loader_obj=None, vault_secrets=None)
    globals = dict()
    locals = dict()

    var = AnsibleJ2Vars(templar, globals, locals)
    var.load_vars

# Generated at 2022-06-21 07:56:44.230012
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    dataloader = DataLoader()
    variable_manager = VariableManager()

    module_data = '{"foo": "bar"}'

    from ansible.template import Templar
    templar = Templar(loader=dataloader, variables=variable_manager, fail_on_undefined=True)

    ajvv = AnsibleJ2Vars(templar, None)
    ajvv_with_locals = ajvv.add_locals(module_data)
    assert ajvv_with_locals['foo'] == module_data['foo']

# Generated at 2022-06-21 07:56:54.197150
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variables = dict(a=1, b=2, c=3, d=4)

    p = PlayContext(vars=variables)
    t = Templar(loader=loader, variables=variables)
    v = AnsibleJ2Vars(templar=t, globals=dict())

    assert v['a'] == 1
    assert v['b'] == 2
    assert v['c'] == 3
    assert v['d'] == 4

    p.vars = dict(x=42)
    assert v['a'] == 1
    assert v['b'] == 2
    assert v['c'] == 3
    assert v

# Generated at 2022-06-21 07:57:06.286813
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loading=None)
    globals = {'item1': 1, 'item2': 2, 'item3': 3, 'item4': 4, 'item5': 5}
    locals = {'item1': 10, 'item2': 20, 'item3': 30}
    unsafe = AnsibleUnsafeText('this is an unsafe string')
    hostvars = HostVars(None, unsafe)
    variables = {'item1': 10, 'item2': unsafe, 'item3': hostvars}
    templar._available_variables = variables

# Generated at 2022-06-21 07:57:14.020989
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # __len__ returns the number of all variables (AvailableVariables, Locals and Globals)
    # Check that it returns the right number when there are no variables at all
    templar = "fake_templar"
    globals = "fake_globals"
    locals = {'l_hostvars': 'hostvars'}
    v = AnsibleJ2Vars(templar, globals, locals)
    assert len(v) == 1

    # Check that it returns the right number when there is one variable
    locals = {'l_hostvars': 'hostvars', 'l_var': 'var'}
    v = AnsibleJ2Vars(templar, globals, locals)
    assert len(v) == 2

    # Check that it returns the right number when there are two variables
    locals

# Generated at 2022-06-21 07:57:29.903433
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Create a simple Templar object to use as a mock
    class Templar:
        available_variables = {'var1': 'value1', 'var2': 'value2'}

    class TemplatesModule:
        pass

    templar = Templar()
    templar.set_available_variables({'var1': 'value1', 'var2': 'value2'})
    templar._templates = TemplatesModule()
    # Create a simple locals to use as a mock
    locals = {'key1': 'value1', 'key2': 'value2'}
    # Create a simple globals to use as a mock
    globals = {'glob_key1': 'glob_value1', 'glob_key2': 'glob_value2'}
    # Create an instance of AnsibleJ2Vars


# Generated at 2022-06-21 07:57:39.881918
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # TemplateEngine is used to get a Templar object
    from ansible.template import Templar
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    # Build a Templar object to be used by AnsibleJ2Vars
    # We need a Play(), a Task(), a Host() and a VariableManager()
    # As a consequence, the file_vars_spec and group_vars_spec must be defined
    # and they can not be empty

# Generated at 2022-06-21 07:57:40.849044
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass

# Generated at 2022-06-21 07:57:50.785314
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    ansible_j2vars = AnsibleJ2Vars(Templar(loader=loader, variables=variable_manager), globals=None)

    ansible_j2vars['test_var'] = 'test_value'
    
    assert ansible_j2vars['test_var'] == 'test_value'

# Generated at 2022-06-21 07:57:52.006092
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert False

# Generated at 2022-06-21 07:58:03.997839
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import six
    import json
    import os

    # try to find fixtures
    fixtures_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    if not os.path.exists(fixtures_path):
        # used from ansible-test
        fixtures_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'fixtures')

    with open(os.path.join(fixtures_path, 'j2vars_iter.json')) as j2data:
        data = json.load(j2data)

    globals = data.get('globals')
    locals = data.get('locals')
    j2vars = AnsibleJ2Vars(None, globals, locals)



# Generated at 2022-06-21 07:58:11.575888
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        import jinja2

        templar = jinja2.Environment().from_string('{{ abacate }}').make_module({})
    except ImportError:
        templar = None

    globals = {}
    locals = {'abacate': 'banana'}

    gen_vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert gen_vars['abacate'] == 'banana'

# Generated at 2022-06-21 07:58:20.268463
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """ Unit test for method __iter__ of class AnsibleJ2Vars """
    from collections import Iterable
    import ansible
    import ansible.playbook.play
    import ansible.template

    # Create instance of AnsibleJ2Vars
    templar = ansible.template.Templar(loader=ansible.playbook.play._load_listofblocks, variables={'test':'value'})
    var = AnsibleJ2Vars(templar, {'testX':'valueX'})

    # Test if returned variable is an Iterable
    assert isinstance(var.__iter__(), Iterable)
    assert set(var.__iter__()) == set(['test', 'testX'])


# Generated at 2022-06-21 07:58:26.737326
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    templar = "templ"
    globals = "globs"
    locals = "locs"

    a = AnsibleJ2Vars(templar, globals, locals)

    locals2 = "newlocs"
    b = a.add_locals(locals2)

    assert a._templar == b._templar
    assert a._globals == b._globals
    assert a._locals != b._locals
    assert a._locals == locals
    assert b._locals == locals2

# Generated at 2022-06-21 07:58:38.958219
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import safe_eval
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    add_all_plugin_dirs()
    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=loader)

    globals = {'test': 'test'}
    locals = {'test': 'test'}


# Generated at 2022-06-21 07:58:48.338257
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    context = PlayContext()
    context._vars_per_host = {}
    templar._available_variables = {}
    templar.set_available_variables(context.get_vars())

    context.vars = {"a": 1, "b": 5, "c": 7}
    context.vars['vars'] = {"a": 1, "b": 5, "c": 7}
    hvars = HostVars()
    hvars.update({"a": 1, "b": 5, "c": 7})
    context.vars['hostvars'] = hvars



# Generated at 2022-06-21 07:58:59.639301
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ansible_vars = dict(
        hostvars=dict(),
        group_names=dict(),
        groups=dict(),
        inventory_hostnames=['host1', 'host2'],
        inventory_hostname_short='host2',
        playbook_dir='/playbooks'
    )
    templar = Templar(loader=DataLoader(), variables=ansible_vars)
    assert len(AnsibleJ2Vars(templar, {})) == 7
    assert len(AnsibleJ2Vars(templar, {}, locals={'a': 1})) == 8
    assert len(AnsibleJ2Vars(templar, {'a': 1}, locals={'b': 2})) == 9

# Generated at 2022-06-21 07:59:03.475158
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = None # type: Templar
    globals = None # type: dict
    vars = AnsibleJ2Vars(templar, globals, locals=dict())
    new_locals = vars.add_locals(dict())

# Generated at 2022-06-21 07:59:11.689362
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.playbook.included_file import IncludedFile

    # Fixture
    templar = Templar(loader=None,
                      variables={'foo': 'baz'},
                      fail_on_undefined=True,
                      include_meta=True,
                      runner_enabled=True,
                      action_loader=action_loader,
                      disable_lookups=False,
                      included_file=IncludedFile(path='&', name='&'),
                      disable_template=False)
    globals = {'bar': 'baz'}
    locals = {'foo': 'baz'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Test with key in

# Generated at 2022-06-21 07:59:21.973898
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar()

    vars1 = AnsibleJ2Vars(templar, {})
    vars2 = AnsibleJ2Vars(templar, {'a': 1})
    vars3 = AnsibleJ2Vars(templar, {'b': 1})

    assert set(vars1) == set()
    assert set(vars2) == set(['a'])
    assert set(vars3) == set(['b'])

    # Check that variables are ordered after being added
    vars_combined = AnsibleJ2Vars(templar, {})
    vars_combined._locals = {'a': 1, 'b': 2}
    vars_combined._globals = {'c': 3}
   

# Generated at 2022-06-21 07:59:32.977354
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.module_utils.common._collections_compat import OrderedDict

    from ansible.plugins.loader import lookup_loader

    from ansible.template import Templar
    from ansible.vars import VariableManager

    vm = VariableManager()
    vm.set_globals(globals())

    class TestVarsModule(object):
        def vars(self):
            return {'foo': 'foo'}

    module_loader = lookup_loader.get('vars')
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), 'vars_plugins'))
    for name in ('testvars',):
        if name not in module_loader._modules:
            module_loader.find_plugin(name)

# Generated at 2022-06-21 07:59:39.423999
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # The test expects that AnsibleJ2Vars is initialized with the following arguments.
    # It is not possible to pass all the required initial objects into the class,
    # so only the minimum values which are required by the __init__ method are passed in.
    # * templar
    # * globals
    # * locals=None

    # Initialize the required objects
    # (a) Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    templar = Templar(None, vault_secrets=['password1'])

# Generated at 2022-06-21 07:59:51.549067
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars

    test_vars = dict(
        fqdn="www.example.com",
        ansible_connection="local",
        ansible_user="test",
        ansible_ssh_pass="test",
        ansible_sudo_pass="test",
        ansible_ssh_private_key_file="test",
        ansible_ssh_extra_args="test",
        test_vars="test",
        test_vault_variable="test",
        )

    vault_id = 'test'
    vault_pass = 'test'
    mock_vault_

# Generated at 2022-06-21 07:59:59.347434
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    inventory = VariableManager()
    inventory.set_inventory(inventory.loader.load_from_file('test/unit/ansible/inventory/test_inventory.yml'))

    variables = inventory.get_vars(inventory.get_host('foobaz'))
    templar = Templar(loader=None, variables=variables)

    from ansible.template.safe_eval import safe_eval
    from ansible.module_utils import basic
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    context = PlayContext()
    context.CLIARGS = dict(module_path='/dev/null')
    context.remote_addr = 'localhost'

# Generated at 2022-06-21 08:00:10.731550
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # mocking
    class TestAnsibleJ2Vars(AnsibleJ2Vars):
        def __init__(self):
            self._templar = DataLoader()
            self._globals = {"dummy_globals_key": "dummy_globals_value"}
            self._locals = {"dummy_locals_key": "dummy_locals_value"}

    # test 1
    result = len(TestAnsibleJ2Vars())
    assert result == 3, "unexpected value: %s" % result

    # test 2

# Generated at 2022-06-21 08:00:25.627259
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # Load up an empty inventory and make a vars object
    inventory = InventoryManager(loader=DataLoader(), sources="")
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    vars = AnsibleJ2Vars(variable_manager, dict())

    # Do some setup
    vars['foo'] = 'foo'
    vars['bar'] = 'bar'
    vars['baz'] = 'baz'
    vars['quux'] = 'quux'

    # Check that vars['foo'] is 'foo'
    assert vars['foo'] == 'foo'

    #

# Generated at 2022-06-21 08:00:36.405240
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    class Templar(object):
        def __init__(self, available_variables):
            self.available_variables = available_variables
        def template(self, value):
            # Used to simulate the template() method of class ansible.parsing.yaml.objects.AnsibleUnicode
            return value
    available_variables = {
        "a": "available_variables_a",
        "b": "available_variables_b",
    }
    globals = {
        "a": "globals_a",
        "b": "globals_b",
        "c": "globals_c",
        "template": "globals_template",
    }

# Generated at 2022-06-21 08:00:46.217981
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar()
    variable_manager = VariableManager(loader=None, variables=dict(var1=1, var2=2, var3=3))
    templar.set_available_variables(variable_manager.get_vars(loader=None, play=None, host=None))
    value1 = AnsibleUnsafeText('value1')
    value2 = AnsibleUnsafeText('value2')
    g_var1 = {'g_key1': value1, 'g_key2': value2}

    # 1. test no globals
    sut = AnsibleJ2Vars(templar, None)

# Generated at 2022-06-21 08:00:57.737185
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.template.vars import AnsibleJ2Vars
    templar = Templar(loader=None)
    host_vars = HostVars(dict())
    host_vars.update(dict(k1='v1'))
    host_vars.update(dict(k2='v2'))
    host_vars.update(dict(k3='v3'))
    globals = {'gk1': 'gv1', 'gk2': 'gv2', 'gk3': 'gv3'}
    locals = {'lk1': 'lv1', 'lk2': 'lv2', 'lk3': 'lv3'}
    aj2