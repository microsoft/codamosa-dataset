

# Generated at 2022-06-21 07:51:10.702862
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    var1 = dict(k1=dict(nested1=dict(v1='v1.1')))
    var2 = dict(k1=dict(nested1=dict(v1='v1.2')))
    test_templar = Templar(loader=jinja2.DictLoader(dict()), variables=var1,
                           shared_loader_obj=None, play_context=PlayContext())
    test_globals = dict()

    test_vars = AnsibleJ2Vars(test_templar, test_globals)
    assert test_vars['k1']['nested1']['v1'] == 'v1.1'

    test_

# Generated at 2022-06-21 07:51:18.798960
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test case for AnsibleJ2Vars.__getitem__() when variable is in _locals
    templar = {
    }
    globals = {
    }
    locals = {
        "foo": "bar"
    }
    proxy = AnsibleJ2Vars(templar, globals, locals);

    assert proxy['foo'] == "bar"

    # Test case for AnsibleJ2Vars.__getitem__() when variable is in _templar.available_variables
    templar = {
        "foo": "bar"
    }
    globals = {
    }
    locals = {
    }
    proxy = AnsibleJ2Vars(templar, globals, locals);

    assert proxy['foo'] == "bar"

    # Test case for AnsibleJ2Vars

# Generated at 2022-06-21 07:51:27.722337
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class MyTemplar():
        def __init__(self):
            self.available_variables = dict()
            self.available_variables['test'] = 'test'
    my_templar = MyTemplar()
    my_available_vars = {'test': 'test'}
    my_globals = {'test': 'test'}
    my_obj = AnsibleJ2Vars(my_templar, my_globals)
    if isinstance(my_obj, Mapping):
        assert len(my_obj) == 3
        assert 'test' in my_obj
    else:
        assert False


# Generated at 2022-06-21 07:51:40.084739
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from jinja2 import Environment
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    playbook = PlaybookExecutor(playbooks=['/dev/null'], inventory=inventory, variable_manager=variable_manager, loader=loader,
                                options=None, passwords=None)
    templar = playbook._templar

    globals = dict()


# Generated at 2022-06-21 07:51:47.126206
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    vars1 = {'a': 1, 'b': 2, 'c': 3}
    vars2 = {'a': 1, 'b': 2, 'd': 3}
    vars3 = {'e': 1, 'f': 2, 'g': 3}

    templar = Templar()
    jv = AnsibleJ2Vars(templar, locals=vars1, globals=vars2)

    for key in vars1:
        assert key in jv

    for key in vars2:
        assert key in jv

    for key in vars3:
        assert key not in jv


# Generated at 2022-06-21 07:51:58.540976
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    from ansible.vars.hostvars import HostVars
    vars_dict = {'some_var': 'some_var_value'}

    templar = Templar(loader=None)
    proxy = AnsibleJ2Vars(templar, vars_dict)

    assert(len(proxy))

    assert('some_var' in proxy)

    assert(proxy['some_var'] == 'some_var_value')

    vars_dict = {'some_var': HostVars(loader=None, variables=None)}
    templar = Templar(loader=None)
    proxy = AnsibleJ2Vars(templar, vars_dict)

    assert(proxy['some_var'].__class__.__name__ == 'HostVars')


# Generated at 2022-06-21 07:52:11.595361
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # create some locals
    test_locals = dict(bar='bar')
    assert len(test_locals) == 1

    # create a new instance of AnsibleJ2Vars with the locals
    test_obj = AnsibleJ2Vars(None, None, test_locals)

    # test that the first locals made it into the object
    assert len(test_obj._locals) == 1
    assert test_obj._locals['bar'] == test_locals['bar']

    # now make a second set of locals and add them to the object
    test_locals2 = dict(foo='foo')
    assert len(test_locals2) == 1

    # the internal locals should match the new set
    assert test_obj._locals == test_locals2

    # create a new locals object from the existing object
   

# Generated at 2022-06-21 07:52:19.362768
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from .templar import Templar
    from .vars import AnsibleVars
    t = Templar(loader=None, shared_loader_obj=None, variables=AnsibleVars())
    a = AnsibleJ2Vars(templar=t, globals={'test': 'test_value'}, locals={'test_local': 'test_local_value'})
    new_a = a.add_locals({'test_local_2': 'test_local_2_value'})
    assert 'test_local' in new_a._locals
    assert 'test_local_2' in new_a._locals

# Generated at 2022-06-21 07:52:30.172056
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    inventory = InventoryManager(loader=DataLoader())

    template_host = Host(name="127.0.0.1")
    group1 = Group(name="group1")
    group2 = Group(name="group2")
    group2.add_host(template_host)
    inventory.add_group(group1)
    inventory.add_group(group2)
    template_host.set_variable('ansible_connection', 'local')
    variable_

# Generated at 2022-06-21 07:52:39.492598
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar

    def _templar_template(variable):
        return variable

    templar = Templar(None, None, None, None, None)
    templar._templar = _templar_template

    def assert_equal_AnsibleJ2Vars(x, y):
        assert isinstance(x, AnsibleJ2Vars)
        assert isinstance(y, AnsibleJ2Vars)
        assert x.__dict__ == y.__dict__

    vars1 = AnsibleJ2Vars(templar, globals={'k1': 'v1'})
    vars2 = AnsibleJ2Vars(templar, globals={'k1': 'v1'}, locals={'k2': 'v2'})

    assert_equal_Ansible

# Generated at 2022-06-21 07:52:56.562503
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from unittest import TestCase
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import variable_manager
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    class MockTemplar(Templar):

        def __init__(self):
            self._available_variables = {
                "v1": "v1",
                "v2": "v2",
                "v3": "v3",
            }

        @property
        def available_variables(self):
            return self._available_

# Generated at 2022-06-21 07:53:03.693356
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    test constructor of class AnsibleJ2Vars
    '''
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from jinja2 import Environment
    from jinja2 import DictLoader
    from jinja2.runtime import Context
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=DictLoader({'test.j2':'test'}), variables=dict(), env=Environment())
    templar.set_available_variables(HostVars(dict()))

    # default behavior
    proxy1 = AnsibleJ2Vars(templar, dict())
    assert(proxy1.__contains__('vars') == False)

   

# Generated at 2022-06-21 07:53:04.829398
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # TODO
    pass

# Generated at 2022-06-21 07:53:12.871484
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'one': 1, 'two': 2, 'three': 3}
    locals = {'two': 20, 'four': 4}
    my_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'one' in my_vars
    assert 'two' in my_vars
    assert 'twenty' not in my_vars


# Generated at 2022-06-21 07:53:20.835339
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    var_manager = VariableManager()
    var_manager.extra_vars = dict(a=1, b=2)
    templar = Templar(loader=None, shared_loader_obj=None, variables=var_manager)

    v = AnsibleJ2Vars(templar, globals=dict(c=3))

    assert set(v.__iter__())== set(['a', 'b', 'c'])

# Generated at 2022-06-21 07:53:28.097757
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    from ansible.template import Templar

    vars1 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    vars2 = {'c': 3, 'd': 5, 'e': 6, 'f': 7}

    templar = Templar(loader=None)

    j2_vars = AnsibleJ2Vars(templar, {})
    j2_vars2 = j2_vars.add_locals(vars1)
    assert isinstance(j2_vars2, AnsibleJ2Vars)
    assert sorted(list(j2_vars.keys())) == sorted(list(vars1.keys()))
    assert sorted(list(j2_vars2.keys())) == sorted(['a','b','c','d'])

   

# Generated at 2022-06-21 07:53:40.022306
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    from ansible.template import Templar

    def test_templar(v):
        return v

    templar = Templar(loader=None, variables={}, fail_on_undefined=True)
    templar.template = test_templar

    ajv = AnsibleJ2Vars(templar, globals=dict())

    assert ajv['a'] == 'a'
    assert ajv['b'] == 'b'
    assert True == ajv.__contains__('b')

    assert ajv.__getitem__('c') == 'c'
    assert ajv.__contains__('c') == True

    assert True == ajv.__contains__('d')
    assert ajv.__getitem__('d') == 'd'

    # Test error handling in

# Generated at 2022-06-21 07:53:49.441837
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import os

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Create self._templar.available_variables

# Generated at 2022-06-21 07:54:00.033722
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from jinja2 import Environment

    environment = Environment()
    templar = Templar(loader=None, variables={})
    globals = {'inventory_hostname': 'host', 'inventory_hostname_short': 'host_short'}
    j2_vars = AnsibleJ2Vars(templar, globals)

    assert list(j2_vars) == ['inventory_hostname', 'inventory_hostname_short']

    # Test behavior with a class that has __iter__ method
    class MyAnsibleBaseYAMLObject(AnsibleBaseYAMLObject):
        def __iter__(self):
            return iter(['test'])


# Generated at 2022-06-21 07:54:10.711805
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class Templar:
        available_variables = {}

    from ansible.parsing.dataloader import DataLoader

    templar = Templar()
    globals = {}
    jvars = AnsibleJ2Vars(templar, globals)
    assert 'ansible_play_hosts' in jvars
    assert 'some_variable' not in jvars

    templar.available_variables = { 'some_variable': 'test' }
    assert 'some_variable' in jvars

    templar.available_variables = { 'ansible_play_hosts': 'test' }
    assert 'ansible_play_hosts' in jvars


# Generated at 2022-06-21 07:54:23.678555
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # create a simple set of data to represent variables
    templars = dict()
    templars["templar1"] = "This is the value of templar1"
    templars["templar2"] = "This is the value of templar2"
    globals = dict()
    globals["global1"] = "This is the value of global1"
    globals["global2"] = "This is the value of global2"

    # create a dummy templar object
    templar = type('templar', (object,), { 'available_variables': templars })()
    # create an AnsibleJ2Vars object
    j2v = AnsibleJ2Vars(templar, globals)
    iterated_keys = set()
    for key in j2v:
        iter

# Generated at 2022-06-21 07:54:34.019900
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = dict()
    locals = dict()

    j2vars = AnsibleJ2Vars(templar, globals, locals)
    j2vars.__getitem__ = lambda x: 1

    # Valid item in _locals
    locals['foo'] = 0
    assert 'foo' in j2vars

    # Valid item in _templar.available_variables
    j2vars._templar.available_variables = dict()
    j2vars._templar.available_variables['foo'] = 0
    assert 'foo' in j2vars

    # Valid item in _globals
    globals['foo'] = 0
    assert 'foo' in j2vars

    # Invalid item
    assert 'bar' not in j2vars



# Generated at 2022-06-21 07:54:38.308748
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=DataLoader())

# Generated at 2022-06-21 07:54:44.081201
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # Init the dataloader
    dl = DataLoader()

    # Init the templar
    templar = Templar(dl)

    # Init the AnsibleJ2Vars
    j2v = AnsibleJ2Vars(templar, dict(), dict())

    assert j2v


# Generated at 2022-06-21 07:54:51.256194
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = None
    globals = {}
    locals = {'i': 'a', 'k': 'c'}
    vars_obj = AnsibleJ2Vars(templar, globals, locals)
    true_locals = locals.copy()
    true_locals.update({'j': 'b'})
    assert vars_obj.add_locals({'j': 'b'})._locals == true_locals

# Generated at 2022-06-21 07:55:00.118806
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import combine_vars

    templar = Templar(loader=None, variables={'a':'b'})
    vars = update({'foo':'bar'}, None, 'inventory_hostname')
    ajv = AnsibleJ2Vars(templar, combine_vars(loader=None, variables=vars))

    # test __init__
    assert type(ajv._templar) == type(templar)
    assert ajv._locals == {}
    assert ajv._globals == vars

    # test __contains__
    assert 'a' in ajv
    assert 'foo' in ajv
    assert 'inventory_hostname' in ajv
    assert 'bar' not in ajv

   

# Generated at 2022-06-21 07:55:12.722155
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test in cas of a variable defined in the class AnsibleJ2Vars
    j2_vars = AnsibleJ2Vars(None, None, locals={'test': 'value1'})
    assert 'test' in j2_vars
    # Test in cas of a variable defined in any variable scope (templar, globals, locals)
    j2_vars = AnsibleJ2Vars(AnsibleJ2Vars(None, None, locals={'test': 'value2'}), {'test': 'value3'}, locals={'test': 'value4'})
    assert 'test' in j2_vars
    # Test in cas of an undefined variable
    j2_vars = AnsibleJ2Vars(None, None, locals={'test': 'value5'})

# Generated at 2022-06-21 07:55:20.985614
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader(), variables={ "hostvars": HostVars(Host(name="127.0.0.1"), {}) })
    aj2v = AnsibleJ2Vars(templar, globals="globals")

    assert "globals" in aj2v
    assert "hostvars" in aj2v


# Generated at 2022-06-21 07:55:26.709615
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = type('Templar', (), dict(available_variables=dict(), template=lambda x: x))()
    globals = dict()
    locals = dict(var1=1)
    vars = AnsibleJ2Vars(templar, globals, locals)
    locals2 = dict(var2=2)
    vars2 = vars.add_locals(locals2)
    assert vars._locals == locals
    assert vars2._locals == locals.copy()
    vars2._locals.update(locals2)
    assert vars2._locals == vars2._locals

# Generated at 2022-06-21 07:55:38.846047
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    from ansible.template import Templar
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    templar = Templar(loader=None, variables={})

    my_test_variables = dict(
        key1="val1",
        key2="val2",
        key3="val3",
    )

    my_test_locals = dict(
        l_key1="l_val1",
        l_key2="l_val2",
        l_key3="l_val3",
    )

    j2v = AnsibleJ2Vars(templar, my_test_variables, my_test_locals)
    j2v_with_locals = j2v.add_locals(my_test_locals)


# Generated at 2022-06-21 07:55:45.963696
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    t = Templar(loader=None)
    data = {'a': 1, 'b': 2}
    v = AnsibleJ2Vars(templar = t, globals = data)
    assert len(v) == len(data)
    data['c'] = 3
    assert len(v) == len(data)

# Generated at 2022-06-21 07:55:58.835250
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = MagicMock()
    globals = {'g1': 'g1'}
    locals = {'l1': 'l1'}

    def _get_vars(var_name):
        if var_name == 'v1':
            return 'v1'

        return None

    templar_available_variables = {'v1': _get_vars('v1')}
    templar.available_variables = templar_available_variables

    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in ajv
    assert 'l1' in ajv
    assert 'v1' in ajv
    assert 'g2' not in ajv
    assert 'l2' not in ajv
   

# Generated at 2022-06-21 07:56:08.394039
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.ajson import AnsibleJSONEncoder

    templar = Templar(loader=None, variables={})

    json_encoder = AnsibleJSONEncoder()
    host_vars = HostVars(dict(a='a', b='b', c='c'))
    globals = dict(d1='d1', d2='d2', d3='d3')
    locals = dict(l1='l1', l2='l2')

    vars = AnsibleJ2Vars(templar, globals, locals)


# Generated at 2022-06-21 07:56:20.867368
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar

    # create a Templar
    t = Templar(loader=None, variables={'i': 1, 'j': 2})

    v = AnsibleJ2Vars(t, {})
    assert v['i'] == 1
    assert v['j'] == 2

    # a global variable
    v = AnsibleJ2Vars(t, {'x': "hello"})
    assert v['x'] == "hello"

    # global variable overrides Ansible variable
    v = AnsibleJ2Vars(t, {'i': "hello"})
    assert v['i'] == "hello"

    # template substitution
    v = AnsibleJ2Vars(t, {})
    assert v['i'] == 1

# Generated at 2022-06-21 07:56:28.271698
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    values = {'a': 1, 'b': 2, 'c': 3}
    templar = Templar(loader=None, variables=values)

    # create a new object of class AnsibleJ2Vars
    obj = AnsibleJ2Vars(templar, values)

    # iterate through the AnsibleJ2Vars object
    result = [i for i in obj]

    # assert the result, expected value should equal the actual value
    assert result == ['a', 'b', 'c'], 'AnsibleJ2Vars object can be iterated successfully'



# Generated at 2022-06-21 07:56:40.042842
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(basedir='/tmp/', loader=None)
    d = {
        'x': 'myx',
        'y': 'myy',
        'z': 'myz',
        'a': HostVars({'b': 'c'}),
        'vars': {
            'a': 1,
            'b': 2,
            'c': '{{ 1 }}'
        }
    }
    aj2v = AnsibleJ2Vars(templar, d)
    assert aj2v['vars'] == {'a': 1, 'b': 2, 'c': '{{ 1 }}'}
    assert aj2v['x'] == 'myx'

# Generated at 2022-06-21 07:56:48.594691
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.vault import VaultLib
    templar = Templar(vars=dict(), vault_secrets=None, loader=None, shared_loader_obj=None, vault_password_files=None,
                      vault_identity_list=[])
    globals = dict()
    locals = dict()
    ansibleJ2Vars = AnsibleJ2Vars(templar, globals, locals)
    new_locals = {"value":"value", "value2":"value2"}

    ansibleJ2Vars.add_locals(new_locals)


# Generated at 2022-06-21 07:56:56.966895
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from unittest import TestCase
    from ansible.template import Templar
    from ansible.template.safe_eval import variable

    class TestAnsibleJ2Vars(TestCase):
        def test___iter__(self):
            # Test empty dictionary
            vars = AnsibleJ2Vars(Templar(loader=None), globals={}, locals={})
            self.assertEqual(len(list(iter(vars))), 0)
            # Test one element dictionary
            vars = AnsibleJ2Vars(Templar(loader=None), globals={'a': 1}, locals={})
            self.assertEqual(len(list(iter(vars))), 1)
            self.assertIn('a', vars)
            self.assertEqual(vars['a'], 1)
            # Test multi

# Generated at 2022-06-21 07:57:09.531822
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # ----- Setup -----
    # copied from jinja2/testsuite/templates/api_vars.py
    globals_ = {"this": "THIS", "that": "THAT", "true": True, "false": False,
                "none": None, "array": [1, 2, 3], "mapping": {"key": "value"},
                "number": 42, "url": 'http://example.org/'}
    locals_ = {"_this": "THIS", "_that": "THAT", "_true": True, "_false": False,
               "_none": None, "_array": [1, 2, 3], "_mapping": {"key": "value"},
               "_number": 42, "_url": 'http://example.org/'}
    vars = AnsibleJ2Vars(None, globals_, locals_)

# Generated at 2022-06-21 07:57:16.235484
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import jinja2.runtime

    class Templar:
        available_variables = {'a': 1, 'b': 2}

        def template(self, variable):
            return variable

    class Globals:
        def __contains__(self, k):
            return k == 'c'

    a = AnsibleJ2Vars(Templar(), Globals(), locals={'x': 3, 'y': 4})
    assert(len(a) == 5)
    assert(len(set([i for i in a])) == 5)

# Generated at 2022-06-21 07:57:33.347782
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template.template import Templar
    # Create variables
    A='a'
    B='b'
    C='c'
    D='d'
    templar=Templar(loader=None)
    # define a jinja2 template that has only one variable,
    # 'c', and evaluate it.
    templar.set_available_variables({'A':A, 'B':B, 'C':C})
    result = templar.template(variable="{{ C }}", convert_bare=False)
    assert result == 'c'
    # We create an AnsibleJ2Vars instance with the newly created Templar.
    # This is akin to the implementation in ansible/runner/template.py.
    # We add a

# Generated at 2022-06-21 07:57:43.648488
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
  from ansible.vars.manager import VariableManager
  from ansible.vars.hostvars import HostVars
  from ansible.parsing.dataloader import DataLoader
  from ansible.playbook.play_context import PlayContext
  from ansible.template import Templar

  variable_manager = VariableManager()
  variable_manager.loader = DataLoader()
  variable_manager.options_vars = {
    'ansible_verbosity': 10,
  }
  variable_manager.extra_vars = {
    'debug': 1,
    'ansible_verbosity': 99,
    'user': 'admin',
  }

  context = PlayContext()


# Generated at 2022-06-21 07:57:53.784228
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    def test_getitem(test_input, expected_output):
        result = AnsibleJ2Vars(templar, globals).__getitem__(test_input)
        assert result == expected_output, \
            "AnsibleJ2Vars.__getitem__(%s) returned '%s', expected '%s'" % (test_input, result, expected_output)

    templar = None
    globals = {'foo': 'bar'}

    test_getitem('foo', 'bar')
    test_getitem('baz', 'echo')

    templar = {'baz': 'echo'}
    test_getitem('baz', 'echo')

    templar = {'baz': {'echo': 'echo'}}

# Generated at 2022-06-21 07:58:05.332499
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    import os
    import sys

    templar = Templar(loader=None)

    globals = {'__file__': 'test_file'}
    docs = {'lookup_file': 'lookup_file_func'}

    vars = AnsibleJ2Vars(templar, globals, locals={'o': 'o_value', 'so': 'so_value'})

    assert vars['__file__'] == 'test_file'
    assert vars['o'] == 'o_value'
    assert vars['so'] == 'so_value'
    assert vars['lookup_file'] == 'lookup_file_func'

    vars['__file__'] = 'test_file_value'

# Generated at 2022-06-21 07:58:16.997778
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import sys
    import os
    import random
    import string
    sys.path.append(os.path.abspath('../'))
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.facts.system import distro
    from ansible.module_utils.facts.system import dnf
    from ansible.module_utils.facts.system import apt
    from ansible.module_utils.facts.system import os_family
    from ansible.module_utils.facts.system import system
    from ansible.module_utils.facts.system import virtual
    from ansible.module_utils.facts.system import selinux

# Generated at 2022-06-21 07:58:23.303727
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from unittest import TestCase
    from mock import MagicMock
    class TestAnsibleJ2Vars(TestCase):
        def test_key_exists(self):
            templar = MagicMock()
            globals = {'key1' : 'value1'}
            ansible_j2_vars = AnsibleJ2Vars(templar, globals)
            self.assertEqual(len(ansible_j2_vars), 1)

    from ansible.utils.pytest_runner import run_tests_for_ut
    run_tests_for_ut(TestAnsibleJ2Vars)


# Generated at 2022-06-21 07:58:34.902470
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Return true if the key is in self
    '''

    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    # set template variables
    template_variables = dict()
    template_variables['foo'] = 'bar'

    # set object variables
    object_variables = dict()
    object_variables['bar'] = 'foo'

    # set globals variables
    globals_variables = dict()
    globals_variables['abc'] = 'xyz'

    # build object
    ansible_j2_vars = AnsibleJ2Vars(Templar(loader=None), globals_variables, locals=object_variables)

    # test
    result = ansible_j2_vars.__contains__('bar')

   

# Generated at 2022-06-21 07:58:44.868732
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.j2 import Templar
    j2_templar = Templar(loader=None, variables={'a': 2, 'b': 3, 'c': {'d': 4, 'e': 5}})

    # a simple test, locals is None
    assert AnsibleJ2Vars(j2_templar, globals={}, locals={'a': 1}) \
        .add_locals(None) == {'a': 2, 'b': 3, 'c': {'d': 4, 'e': 5}}

    # a simple test, some locals

# Generated at 2022-06-21 07:58:56.419410
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    globals = {
        'g_a': 'globals_a'
    }

    locals = {
        # locals is just a fancy name for variables for jinja2
        'b': 'locals_b',
        'c': 'locals_c'
    }

    templar = type('Templar', (object,), {
        'available_variables': {
            'a': 'available_variables_a',
            'd': 'available_variables_d',
        },
        'template': lambda x: x,
    })()

    proxy = AnsibleJ2Vars(templar, globals, locals)

    # first check if everything is in our proxy object
    assert proxy['a'] == 'available_variables_a', 'a value should be "available_variables_a"'


# Generated at 2022-06-21 07:59:07.363449
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    dataloader = DataLoader()
    my_inventory = InventoryManager(loader=dataloader, sources='/dev/null')
    variable_manager = VariableManager(loader=dataloader, inventory=my_inventory)
    play_context = PlayContext()
    my_templar = Templar(loader=dataloader, variables=variable_manager, playcontext=play_context)
    ansible_vars = AnsibleJ2Vars(my_templar, {})

# Generated at 2022-06-21 07:59:29.512487
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    fake_module_vars = dict(
        a=dict(b=dict(c=[dict(d=1), dict(d=2)])),
        e=dict(f=dict(g=[dict(h=1), dict(h=2)])),
        i=0,
    )

# Generated at 2022-06-21 07:59:37.665128
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import tempfile
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Add a dictionary with variables to be available
    available_variables = dict(key1='value1', key2='value2')

    # Add a temporary directory with a file which will be used as a variable in the test
    tmp_dir = tempfile.TemporaryDirectory()

    # Create a variable proxy
    variable_proxy = AnsibleJ2Vars(
        Templar(loader=loader, variables=available_variables),
        globals={},
        locals={}
    )

    # Test that the iterator returns the appropriate keys
    assert sorted(list(variable_proxy)) == sorted(['key1', 'key2'])

    # Test that the iterator is not reentrant
   

# Generated at 2022-06-21 07:59:42.132136
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = None
    globals = None
    locals = None
    var = AnsibleJ2Vars(templar, globals, locals)

    assert var._templar == None
    assert var._globals == None
    assert var._locals == {}

# Generated at 2022-06-21 07:59:43.619104
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert False, "Need to write tests for AnsibleJ2Vars"

# Generated at 2022-06-21 07:59:51.195855
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import ansible_safe_eval
    templar = ansible_safe_eval.AnsibleTemplar(loader=None)
    vars = AnsibleJ2Vars(templar, None)
    vars['key1'] = 'value1'
    vars['key2'] = 'value2'
    vars['key3'] = 'value3'
    assert len(vars) == 3


# Generated at 2022-06-21 07:59:57.863514
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # testing without globals and locals parameters
    obj = AnsibleJ2Vars(None, None)
    list1 = ['a', 'b', 'c']
    set1 = set(list1)
    obj.available_variables = set1
    obj._locals = {}
    obj2 = iter(obj)
    assert isinstance(obj2, type(iter(set())))
    counter = 0
    for i in obj2:
        assert i in set1
        counter += 1
    assert counter == len(set1)

    # testing with globals and locals parameters
    obj = AnsibleJ2Vars(None, None)
    obj._templar.available_variables = {'foo': 'bar'}
    obj._globals = {'hello': 'world'}

# Generated at 2022-06-21 08:00:09.934671
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    locals = dict(a=1, b='c')
    l = AnsibleJ2Vars(templar, locals)
    assert locals == l._locals
    new_locals = dict(d='e', f=3)
    l2 = l.add_locals(new_locals)
    assert locals == l._locals  # should not change l
    assert new_locals == l2._locals
    locals.update(new_locals)
    assert locals == l2._locals

if __name__ == '__main__':
    import sys

    def run_test(method):
        method.__name__ = sys.argv[1]
        method()


# Generated at 2022-06-21 08:00:22.652486
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from jinja2.utils import missing
    from ansible.template import Templar
    from ansible.template.safe_eval import SafeEval
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var
    import copy

    data = {}
    data['av'] = ['a', 'v']
    data['dict'] = {'a': 'dict_a', 'b': 'dict_b'}
    data['list'] = ['list1', 'list2']
    data['nested_list'] = [['nested_list[0][0]', 'nested_list[0][1]'], ['nested_list[1][0]', 'nested_list[1][1]']]

# Generated at 2022-06-21 08:00:30.134289
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    host = Inventory().get_host('localhost')

# Generated at 2022-06-21 08:00:35.791078
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = {'g': 42}
    locals = {'l': 42}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert ('l' in aj2v) == True
    assert ('g' in aj2v) == True
    assert ('xyz' in aj2v) == False



# Generated at 2022-06-21 08:00:57.631474
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    env = Mock
    env.name = 'jinja2'

    templar = Templar(env, loader=None)
    globals = dict()

    proxy = AnsibleJ2Vars(templar, globals)

    # assert that __contains__ returns 'False' when key doesn't exist
    assert 'non_existent_var' not in proxy

    templar.available_variables = dict(ansible_version='2.9.0.0')

    proxy = AnsibleJ2Vars(templar, globals)

    # assert that __contains__ returns 'True' when key exists
    assert 'ansible_version' in proxy

    templar.available