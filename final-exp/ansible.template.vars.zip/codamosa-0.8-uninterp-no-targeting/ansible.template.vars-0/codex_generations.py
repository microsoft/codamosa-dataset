

# Generated at 2022-06-21 07:51:06.728900
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = None
    globals = {'a' : 'b'}
    locals1 = {'b' : 'c'}
    locals2 = {'c' : 'd'}

    vars = AnsibleJ2Vars(templar, globals, locals=locals1)
    vars = vars.add_locals(locals2)

    assert vars._locals == dict(list(locals1.items()) + list(locals2.items()))

# Generated at 2022-06-21 07:51:16.839207
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import unittest
    import ansible.template

    class AnsibleJ2Vars(object):

        def __init__(self, templar, globals, locals=None):
            self.locals = locals
            self.globals = globals
            self.templar = templar

        def __contains__(self, k):
            return True

        def __iter__(self):
            return iter([1, 2, 3])

        def __len__(self):
            keys = set()
            keys.update(self.templar.available_variables, self.locals, self.globals)
            return len(keys)

        def __getitem__(self, varname):
            return varname


# Generated at 2022-06-21 07:51:27.911388
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.playbook.play_context

    templar = ansible.playbook.play_context.Templar("/home/dw/ansible", None)
    templar.loader = ansible.parsing.dataloader.DataLoader()
    templar.available_variables = dict(a=1, b=2, c=3, d=4)

    # add_locals with no argument
    j2VarsObject = AnsibleJ2Vars(templar, dict(x=1, y=2, z=3))
    result = j2VarsObject.add_locals(None)
    assert result == j2VarsObject
    assert len(result) == 6 # globals keys + templar vars

    # add_locals with some arguments
    j2Vars

# Generated at 2022-06-21 07:51:40.231456
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.module_utils.hashivault
    templar = ansible.module_utils.hashivault.HashiVaultJ2Vars
    globals = {'foo':'bar'}
    locals = {'loc':'al'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert (str(j2vars) == "{'al': 'l', 'o': 'c', 'l': 'a'}")
    assert (j2vars.get('al') == 'l')
    assert (j2vars.get('o') == 'c')
    assert (j2vars.get('l') == 'a')
    assert (j2vars.get('loc') == 'al')

# Generated at 2022-06-21 07:51:48.210996
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    locals = {}
    locals['test_str'] = 'test_str'
    j2vars = AnsibleJ2Vars(Templar(), {}, locals=locals)
    assert 'test_str' in j2vars
    j2vars['test_str'] == 'test_str'
    try:
        j2vars['test_undefined']
    except KeyError:
        pass
    else:
        assert False
    locals['test_unsafe'] = UnsafeProxy({})
    try:
        j2vars['test_unsafe']
    except AnsibleError:
        pass
    else:
        assert False
   

# Generated at 2022-06-21 07:51:56.795898
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    templar = Templar(None, variable_manager=VariableManager())
    j2vars = AnsibleJ2Vars(templar, globals={'a': 1})
    assert set(j2vars) == {'a'}
    j2vars = AnsibleJ2Vars(templar, globals={'b': 1})
    j2vars = j2vars.add_locals({'a': 1})
    assert set(j2vars) == {'a', 'b'}

# Generated at 2022-06-21 07:52:08.062200
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.hostvars import HostVars
    templar = _EmptyTemplar()
    globals = dict()
    jv = AnsibleJ2Vars(templar, globals)
    assert templar is jv._templar
    assert globals is jv._globals
    assert dict() is jv._locals
    locals_ = dict(x='x')
    jv_locals = jv.add_locals(locals_)
    assert templar is jv_locals._templar
    assert globals is jv_locals._globals
    assert dict(x='x') is jv_locals._locals


# Generated at 2022-06-21 07:52:12.611402
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    vars1 = AnsibleJ2Vars(templar, {}, {})
    try:
        iter(vars1)
    except:
        raise


# Generated at 2022-06-21 07:52:15.448828
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar=dict()
    globals=dict()
    locals=dict()
    instance = AnsibleJ2Vars(templar, globals, locals)



# Generated at 2022-06-21 07:52:23.292399
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    templar = Templar(loader=None)

    varname1 = 'foo'
    variable1 = 'foobar'
    varname2 = 'foo2'
    variable2 = 'foobar2'
    varname3 = 'foo3'
    variable3 = 'foobar3'
    globals1 = HostVars()
    globals1._data = dict(foo2='foobar2_in_globals')
    locals1 = dict(l_foo3='foobar3_in_locals')

    ans = AnsibleJ2Vars(templar, globals1, locals=locals1)
    assert ans[varname1] == variable1
    assert ans[varname2] == variable2

# Generated at 2022-06-21 07:52:36.119351
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    def getdict(a=None, b=None, c=None, d=None):
        d = {}
        if a:
            d['a'] = a
        if b:
            d['b'] = b
        if c:
            d['c'] = c
        if d:
            d['d'] = d
        return d

    class FakeModuleUtils():
        def __init__(self, o):
            self._o = o
        def template(self, v, **kwargs):
            return v
    class FakeModule():
        def __init__(self, vars, tmp):
            self.vars = vars
            self.tmp = {'available_variables':getdict(**vars)}
            self._shared_loader_obj = FakeModuleUtils(self)

# Generated at 2022-06-21 07:52:46.736299
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    AnsibleJ2Vars class method __contains__()
    '''

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar(loader=None)

    globals = {'var_a': 1, 'var_b': 'b'}

    locals = {'var_c': [1, 2], 'var_d': "d"}
    locals['var_e'] = UnsafeProxy('var_e', locals)

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'var_a' in vars
    assert 'var_b' in vars
    assert 'var_c' in vars
    assert 'var_d' in vars
    assert 'var_e' in v

# Generated at 2022-06-21 07:52:53.604191
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    j2vars = AnsibleJ2Vars(Templar(), dict(), dict())
    j2vars.add_locals({'a':1})
    assert j2vars['a'] == 1
    j2vars.add_locals({'a':2})
    assert j2vars['a'] == 2
    j2vars.add_locals({'b':3})
    assert j2vars['b'] == 3

# Generated at 2022-06-21 07:53:02.258354
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        from ansible.parsing.dataloader import DataLoader
    except:
        from ansible.inventory.host import Host
        from ansible.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import pytest
    import copy

    my_vars = dict()
    my_vars['foo'] = "bar"
    my_vars['bax'] = "baz"
    my_vars['fum'] = "foe"
    play_context = PlayContext()
    dataloader = None
    if hasattr(DataLoader, '__init__'):
        dataloader = DataLoader()
        templar = Templar(loader=dataloader)

# Generated at 2022-06-21 07:53:14.271095
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from units.mock.loader import DictDataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # create the loader, inventory, and variable manager
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    host = inventory.get_host('localhost')

    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create the templar
    from ansible.playbook.play_context import PlayContext
    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=True)

    # create the vars

# Generated at 2022-06-21 07:53:25.281700
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.module_utils.six import string_types

    templar = Templar(loader=None) #--- Templar class needs a loader to function
    ansible_vars = {'foo':'bar', 'baz':'qux'}
    ansible_globals = {'g_foo':'g_bar'}
    ansible_globals1 = {'g_foo':'g_bar1'}

    #--- Testing when variables are in templar.available_variables
    v = AnsibleJ2Vars(templar, ansible_globals, locals=None)
    templar.available_variables = ansible_vars.copy()

# Generated at 2022-06-21 07:53:37.835823
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    
    globals = {} # empty global variables
    locals = None # no local variables
    templar = Templar(None, None, None)

# Generated at 2022-06-21 07:53:46.467814
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    local_vars = {'a':1,'b':2,'c':3}
    global_vars = {'d':4,'e':5,'f':6}
    available_vars = {'g':7,'h':8,'i':9}
    templar = Templar(loader=None, variables=available_vars)
    vars = AnsibleJ2Vars(templar, global_vars, local_vars)
    actual = set(vars.__iter__())
    expected = set(local_vars.keys() + global_vars.keys() + available_vars.keys())
    assert actual == expected


# Generated at 2022-06-21 07:53:52.635466
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    import ansible.vars
    import ansible.templating
    #import ansible.template

    # https://docs.python.org/3/library/unittest.html#assert-methods
    from unittest import TestCase

    class AnsibleJ2Vars_test_(AnsibleJ2Vars, TestCase):
        def test_basic(self):
            '''
            Basic test if method returns a non-empty number of vars
            '''
            templar = ansible.templating.Templar(loader=None)
            dict_ = ansible.vars.host_vars(to_native('ExampleGroup'), to_native('ExampleHost'))
            self.assertGreater(len(AnsibleJ2Vars(templar, {}, locals=dict_)), 0)


# Generated at 2022-06-21 07:54:02.926985
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=False)
    ansible_j2_vars = AnsibleJ2Vars(templar, {}, locals={'l_foo': 'bar', 'l_baz': 'qux'})

    assert 'foo' not in ansible_j

# Generated at 2022-06-21 07:54:12.997294
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import compile_from_file, compile_from_string

    env = {}
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'inventory_hostname': 'test-host', 'foo': 'bar'}, shared_loader_obj=env)

    jv = AnsibleJ2Vars(templar, {})
    assert 'inventory_hostname' in jv
    assert 'foo' in jv
    assert 'no_such_key' not in jv



# Generated at 2022-06-21 07:54:19.241690
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar

    templar = Templar(loader=None)

    # Set of variables for testing
    vars_global = {
        'g_var1': 'global var 1',
        'g_var2': 'global var 2',
    }
    vars_local = {
        'l_var1': 'local var 1',
        'l_var2': 'local var 2',
    }
    vars_avail = {
        'a_var1': 'available var 1',
        'a_var2': 'available var 2',
    }

    # Create a new AnsibleJ2Vars instance
    aj2vars_obj   = AnsibleJ2Vars(templar, vars_global, vars_local)

    # Temporarily populate the available_variables attribute


# Generated at 2022-06-21 07:54:29.500864
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.templar import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    assert AnsibleJ2Vars(templar, {}, {}).__len__() == 0

    variables = dict(
        test_boolean=True,
        test_integer=1,
        test_float=1.0,
        test_string='string',
        test_list=[1, '2', 3],
        test_dict=dict(a='a', b='B', c='c'),
    )

    assert AnsibleJ2Vars(templar, variables, {}).__len__() == len(variables)
    assert AnsibleJ2Vars(templar, {}, variables).__

# Generated at 2022-06-21 07:54:39.146121
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar(object):
        def __init__(self, variables):
            self._variables = variables

        def _available_variables(self):
            return self._variables

    def template(self, data):
        return data

    Templar._available_variables = property(Templar._available_variables)
    Templar.template = template


# Generated at 2022-06-21 07:54:50.820769
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars()

    templar = Templar(loader=None, variables={'var': 'a'})
    globals = {'g_a': 'A'}
    proxy = AnsibleJ2Vars(templar, globals, locals={'l_a': 'A'})

    # test with no locals
    proxy_no_locals = proxy.add_locals(None)
    assert proxy_no_locals._globals is globals
    assert proxy_no_locals._locals is proxy._locals
    assert proxy_no_locals._templar is templar

    # test with locals

# Generated at 2022-06-21 07:54:56.341884
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # test non-sense variables to see if the method can handle it
    locals = {'undefined_var' : True}
    templar = None
    globals_ = None
    j2vars = AnsibleJ2Vars(templar, globals_, locals)

    assert j2vars.add_locals(locals) != None


# Generated at 2022-06-21 07:55:09.521029
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    mytemplar = Templar(loader=None, variables={'dict': {'a': 'b'}, 'int': 2, 'str': 'str'})
    local_vars = AnsibleJ2Vars(mytemplar, {'extra_var': 'extra_value'})
    # set a value to a local variable
    local_vars._locals={'str':'custom_str'}
    # add extra locals
    local_vars.add_locals({'new_var': AnsibleBaseYAMLObject(None, 'new_value', True)})
    # the result is a new value for the new local variable
    new_local_vars = local_vars.add_

# Generated at 2022-06-21 07:55:11.429292
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # FIXME
    # test AnsibleJ2Vars(templar, globals, locals=None)
    pass

# Generated at 2022-06-21 07:55:13.279478
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert False, "No unit tests for class AnsibleJ2Vars written yet"

# Generated at 2022-06-21 07:55:20.743505
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)

    globals_vars = {"g_var": "g_value", "g_list": [1,2,3]}

    variables = {"var": "value", "list": [1,2,3]}

    jvars = AnsibleJ2Vars(templar, globals_vars, variables)

    assert set(iter(jvars)) == set(["var", "list", "g_var", "g_list"])


# Generated at 2022-06-21 07:55:37.081944
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()

    # Set up context
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='127.0.0.1')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    context = PlayContext()

    # Set up templar
    from ansible.template.template import Templar
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=context))

    # Declare globals
    globals_ = {
        'foo': 'bar'
    }

    # Declare locals

# Generated at 2022-06-21 07:55:38.496980
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    obj = AnsibleJ2Vars()
    assert obj is not None


# Generated at 2022-06-21 07:55:43.420176
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.vault import VaultLib

    templar = Templar(vault_password='secret', loader=DictDataLoader())
    variables = {'foo': 'bar'}
    j2vars = AnsibleJ2Vars(templar, variables)

    assert list(j2vars) == ['foo']



# Generated at 2022-06-21 07:55:47.647304
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    j2_vars = AnsibleJ2Vars(Templar(None), globals={})
    assert j2_vars.add_locals(None) is j2_vars
    assert j2_vars.add_locals({}) is not j2_vars
    assert isinstance(j2_vars.add_locals({}), AnsibleJ2Vars)


# Generated at 2022-06-21 07:56:00.463561
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar_object = None
    globals_object = {"var_1": 10, "var_2": 20, "var_3": 30, "var_4": 40}
    locals_object = {"var_1": 100, "var_2": 200, "var_3": 300, "var_4": 400}
    try:
        jvars = AnsibleJ2Vars(templar_object, globals_object, locals_object)
        key_list = ["var_1", "var_2", "var_3", "var_4"]
        for key in key_list:
            if key in jvars:
               assert True
            else:
               assert False
    except AssertionError as e:
        print("test_AnsibleJ2Vars___contains__: Exception:\n", e)

# Generated at 2022-06-21 07:56:12.523558
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import os
    import tempfile
    import shutil

    from jinja2 import Environment
    from jinja2.loaders import FileSystemLoader

    sample_dir = os.path.dirname(__file__) + '/../../../module_utils/basic/vars/'
    j2_env = Environment(loader=FileSystemLoader(sample_dir))

    locals = {'a': 'b', 'b': 'c'}

    # Test using a temporary directory to create a FileSystemLoader
    tmpdir = tempfile.mkdtemp()
    j2_env = Environment(loader=FileSystemLoader(tmpdir))
    proxy = AnsibleJ2Vars(j2_env.get_template('sample.tpl'), {'a': 'd'}, locals)
    assert proxy['a'] == 'b'
    assert proxy

# Generated at 2022-06-21 07:56:23.904306
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.vars import VariableManager
    from jinja2 import Environment
    from ansible.module_utils.common._collections_compat import Sequence

    variable_manager = VariableManager()
    variable_manager.set_host_variable('localhost', 'host_var_1', 'host_var_1_value')
    variable_manager.set_host_variable('localhost', 'host_var_2', 'host_var_2_value')

    env = Environment()
    j2vars = AnsibleJ2Vars(variable_manager.get_vars, env.globals, locals={'local_var_1': 'local_var_1_value', 'local_var_2': 'local_var_2_value'})

    # Test if method works like expected when var is a string

# Generated at 2022-06-21 07:56:25.573258
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # FIXME: can't be tested because of the dependency to Templar class
    raise NotImplementedError


# Generated at 2022-06-21 07:56:33.542482
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_host_variable(host=None, variable=u'locals_key', value=u'locals_value')

    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)
    templar.available_variables = variable_manager.get_vars(host=None)

    # create a copy of locals with both simple and 'HostVars' values

# Generated at 2022-06-21 07:56:43.613902
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import compile_jinja2_replacement_expression

    # test object
    templar = compile_jinja2_replacement_expression('foo')
    globals = {'a': 'b'}
    locals = {'b': 'c'}

    # test with no locals
    vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert len(vars) == 2

    # test with locals
    vars = AnsibleJ2Vars(templar, globals, locals=None)
    assert len(vars) == 1

# Generated at 2022-06-21 07:56:52.390739
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    a = AnsibleJ2Vars(None, {'a': 'b', 'c':'d', 'gk': 'gv'}, {'e': 'f', 'hk': 'hv'})
    assert set(['a', 'c', 'gk', 'e', 'hk']) == set(iter(a))


# Generated at 2022-06-21 07:56:58.684463
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    play_context = PlayContext()
    templar = Templar(loader=None, variables={})
    host = Host(name='test_host')
    group = Group(name='test_group')
    group.vars = {'new_group_var_key': 'new_group_var_value'}
    host.groups += [group]
    hostvars = HostVars(host=host, play_context=play_context)
    locals = {'new_host_var_key': 'new_host_var_value'}
    local_vars = Ans

# Generated at 2022-06-21 07:57:03.173505
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    vars = AnsibleJ2Vars(Templar(),"","")
    ret = False
    if len(vars) == 0:
        ret = True
    assert ret == True


# Generated at 2022-06-21 07:57:13.178743
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    t = Templar(loader=None, variables={'test_var': 'test_value'})
    # locals is not defined
    v = AnsibleJ2Vars(t, {'global_var': 'global_value'})
    # locals are defined
    # locals are prefixed with "l_"
    v2 = v.add_locals({'l_local_var': 'local_value'})
    # locals are not prefixed with "l_"
    v3 = v.add_locals({'local_var': 'local_value'})
    # locals are a dictionary
    v4 = v.add_locals({'local_var': 'local_value', 'other_var': 'other_value'})

    assert 'test_var' in v
    assert 'test_var' in v2

# Generated at 2022-06-21 07:57:25.832366
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    import pytest
    import os

    play_context = PlayContext()
    variable_manager = VariableManager()

    fake_templar = Templar(loader=None, variables=variable_manager, fail_on_undefined=True)
    fake_templar.available_variables = {
        "existing_variable": "foo"
    }

    globals = {}

    ansible_j2_vars = AnsibleJ2Vars(fake_templar, globals)

    # Test for __getitem__ with inside existing_variable
    assert ans

# Generated at 2022-06-21 07:57:36.335072
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ''' This function will test the __len__ method of AnsibleJ2Vars
    class i.e. it will check the number of keys present in the AnsibleJ2Vars class
    '''
    # create an instance of AnsibleJ2Vars class
    ansible_j2_vars_instance = AnsibleJ2Vars('templar', 'globals')
    if len(ansible_j2_vars_instance) == 0:
        print("Number of keys present in the AnsibleJ2Vars class is 0")
    else:
        print("Number of keys present in the AnsibleJ2Vars class is not 0")
    print("Length of the keys present in the AnsibleJ2Vars class is", len(ansible_j2_vars_instance))


# Generated at 2022-06-21 07:57:48.968676
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2

    ansible_vars = dict(
        fqdn = 'server1.example.com',
        groups = ['foo', 'bar'],
        interfaces = ['eth0', 'eth1'],
    )

    jinja2_vars = dict(
        ansible_host = '192.168.1.1',
        ansible_port = '22',
        ansible_user = 'root'
    )

    ansible_template = jinja2.Template('''
fqdn={{fqdn}}
ansible_host={{ansible_host}}
''')

    jinja2_template = jinja2.Template('''
ansible_fqdn={{fqdn}}
ansible_host={{ansible_host}}
''')

    # init

# Generated at 2022-06-21 07:57:57.183705
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """
    Test the __iter__ function of AnsibleJ2Vars
    """
    from ansible.template import Templar
    templar = Templar({})
    host_vars = {'test_host_var': 'test_host_var_value'}
    host_vars_mapping = {'test_host_var_mapping': 'test_host_var_mapping_value'}
    ansible_vars = {'test_ansible_var': 'test_ansible_var_value'}
    task_vars = {'test_task_var': 'test_task_var_value'}
    vars_obj = AnsibleJ2Vars(templar, host_vars, locals=task_vars)

# Generated at 2022-06-21 07:58:01.660976
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.constants as C
    from ansible.vars.manager import VariableManager
    from ansible.vars import include_vars
    from ansible.template import Templar
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.data import AnsibleUnsafeLoader


    current

# Generated at 2022-06-21 07:58:13.478084
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    hostvars = HostVars({"var1": "value1", "var2": "value2"})
    loader = DataLoader()
    inventory = Inventory(loader=loader)
    inventory.add_host(host=Host(name="host_name"))
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_host_variable(host="host_name", varname="hostvars", value=hostvars)

# Generated at 2022-06-21 07:58:31.018630
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    globals = dict()
    locals = None
    templar = Templar(loader=None)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars is not None, 'unable to create AnsibleJ2Vars instance'

# Retrieve the contents of this file as a str
__content = None
with open(__file__, 'r') as __file:
    __content = __file.read()

# run unit tests if we're NOT called from Ansible
if __name__ == '__main__':
    import sys
    import json
    import base64

    sys.path.insert(0, '..')
    from ansible.module_utils import json_utils

    env_pass

# Generated at 2022-06-21 07:58:42.100172
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = None
    locals = None
    ajv = AnsibleJ2Vars(templar, globals, locals)
    ajv._templar.available_variables = {'key1': 1, 'key2': 2, 'key3': 3}
    ajv._globals = {'globKey1': 1, 'globKey2': 2}
    ajv._locals = {'locKey1': 1, 'locKey2': 2}
    keys = {'key1', 'key2', 'key3', 'globKey1', 'globKey2', 'locKey1', 'locKey2'}
    i = ajv.__iter__()
    for j in i:
        keys.discard(j)
    assert len(keys)

# Generated at 2022-06-21 07:58:51.752276
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # no locals => no change
    proxy = AnsibleJ2Vars('templar', dict(foo='bar', baz='spam'))
    assert proxy.add_locals(dict()) is proxy

    # adding locals does not alter the original object
    proxy = AnsibleJ2Vars('templar', dict(foo='bar', baz='spam'))
    copy = proxy.add_locals(dict(bar='spam'))
    assert copy is not proxy
    assert copy._locals == dict(bar='spam')
    assert proxy._locals == dict()

    # adding locals does not alter the original object
    proxy = AnsibleJ2Vars('templar', dict(foo='bar', baz='spam'), locals=dict(one='1', two='2'))
    copy = proxy.add_loc

# Generated at 2022-06-21 07:59:00.439342
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # create the test object
    class Templar:
        available_variables = {'hostvars': {'host1': {'k1': 1}}}

    class Globals:
        pass

    templar = Templar()
    globals = Globals()
    locals = {}
    aj2v = AnsibleJ2Vars(templar, globals, locals)

    # create the test result
    result = 0

    # call the method under the test
    result = len(aj2v)

    # assert
    assert result == 2


# Generated at 2022-06-21 07:59:09.988889
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class T:
        def __init__(self):
            self.available_variables = dict(key1='val1', key2='val2')
        def template(self, v):
            if v == self.available_variables['key1']:
                return self.available_variables['key1']
            else:
                raise Exception("could not template %s" % v)

    v = dict(key1='val1', key2='val2')
    g = dict(key3='val3')
    p = AnsibleJ2Vars(T(), g)

    assert 'key1' in p
    assert 'key2' in p
    assert 'key3' in p

    assert len(p) == 3

    assert p['key1'] == p['key1']

# Generated at 2022-06-21 07:59:19.879583
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    globals = {
        'g_var1': 1,
        'g_var2': 2,
        'g_var3': 3,
        'g_var4': 4,
    }
    locals = {
        'l_var1': 1,
        'l_var2': 2,
        'l_var3': 3,
        'l_var4': 4,
    }

    j2vars = AnsibleJ2Vars(globals, locals)

    # Check the variables from globals and locals
    assert set(j2vars) == {'g_var1', 'g_var2', 'g_var3', 'g_var4', 'l_var1', 'l_var2', 'l_var3', 'l_var4'}

# Generated at 2022-06-21 07:59:20.933655
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
  pass


# Generated at 2022-06-21 07:59:25.196656
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    vars = AnsibleJ2Vars(Templar(), {}, {'foo':'bar'})

    assert vars['foo'] == 'bar'
    assert vars['fake_key'] == '{{fake_key}}'

# Generated at 2022-06-21 07:59:35.128977
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import sys
    import unittest

    class TestClass(unittest.TestCase):
        def test_result(self):
            templar = Templar(loader=None, variables={"aaa": 111}, fail_on_undefined=True)
            aj = AnsibleJ2Vars(templar, {"bbb": 222})
            self.assertTrue("aaa" in aj)
            self.assertTrue("bbb" in aj)
            self.assertFalse("ccc" in aj)

    s = unittest.TestSuite()
    s.addTest(unittest.makeSuite(TestClass))
    runner = unittest.TextTestRunner()
    runner.run(s)

#

# Generated at 2022-06-21 07:59:45.342740
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    j2vars = AnsibleJ2Vars(None, {
        'ansible_variables': {
            'ansible_play_hosts': ['localhost'],
            'groups': {
                'group': [
                    'localhost',
                    'hostname']
            }
        }})
    assert (j2vars.__getitem__('ansible_play_hosts') == ['localhost'])
    assert (j2vars.__getitem__('groups')['group'][0] == 'localhost')
    try:
        j2vars.__getitem__('invalid_key')
        assert False  # Should have raised exception
    except KeyError:
        pass

# Generated at 2022-06-21 07:59:54.049695
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    t = Templar()
    a = AnsibleJ2Vars(t, dict(), dict())

    a['key1'] = 'value1'
    a['key2'] = 'value2'

    assert a.__iter__() == ['key1', 'key2']

# Generated at 2022-06-21 07:59:59.829487
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class Templar(object):
        def __init__(self):
            self.available_variables = {'one':1, 'two':2, 'tree':3}

    v = AnsibleJ2Vars(
        Templar(),
        globals={'the':42},
        locals={'foo':'bar'}
    )
    assert sorted(list(v)) == sorted(['one', 'two', 'tree', 'the', 'foo'])

# Generated at 2022-06-21 08:00:10.903465
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = {} # TODO: Check if this argument is mandatory or not. (Might be necessary for the AnsibleJ2Vars.__getitem__(var) method)

    # Test if any value of the locals dict can be accessed.
    globals = dict()
    locals = dict()
    locals['test'] = 'testvalue'
    locals['test2'] = 'testvalue2'
    ansiblej2vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansiblej2vars['test'] == 'testvalue'
    assert ansiblej2vars['test2'] == 'testvalue2'

    # Test if the values of the global dict can be accessed.
    globals = dict()
    globals['test1'] = 'testvalue1'
    globals['test2']

# Generated at 2022-06-21 08:00:23.335862
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    template_variables = variable_manager.get_vars(loader=loader, cache=dict())
    j2_vars = AnsibleJ2Vars(Templar(loader=loader), template_variables)

    assert len(j2_vars) == len(template_variables)

    variable_manager.set_variable('test', '{{ ansible_hostname }}')
    template_variables = variable_manager.get_vars(loader=loader, cache=dict())
    j2_vars = AnsibleJ2Vars(Templar(loader=loader), template_variables)


# Generated at 2022-06-21 08:00:32.728750
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    for data_dict in [{'a':'b', 'c':'d'}, {'a':'b', 'c':'d', 'e':'f'}, {'a':'b', 'c':'d', 'e':'f', 'g':'h'}]:
        for data_dict2 in [{'a':'b', 'c':'d'}, {'a':'b', 'c':'d', 'e':'f'}, {'a':'b', 'c':'d', 'e':'f', 'g':'h'}]:
            vars = AnsibleJ2Vars(templar=None, globals=None, locals=data_dict)
            vars.update(data_dict2)

# Generated at 2022-06-21 08:00:39.050985
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class A(object):
        def __init__(self, a):
            self.a = a

    a = A(1)
    locals = {"a":a, "b":None}
    new_locals = AnsibleJ2Vars._add_locals(locals)
    assert new_locals["a"]._locals == locals
    assert new_locals["b"]._locals == locals

# Generated at 2022-06-21 08:00:47.625567
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    j2vars = AnsibleJ2Vars(Templar({'a': 1}), {}, {})
    assert j2vars['a'] == 1

    j2vars = AnsibleJ2Vars(Templar({'a': '{{a}}'}), {}, {})
    assert j2vars['a'] == 1

    j2vars = AnsibleJ2Vars(Templar({'a': '{{b}}'}), {}, {})
    try:
        assert j2vars['a'] == 1
    except KeyError:
        pass
    else:
        assert False, "KeyError was not raised"


# Generated at 2022-06-21 08:00:50.774993
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = AnsibleJ2Vars(templar=None, globals={}, locals={})
    assert len(templar) == 0

# Generated at 2022-06-21 08:00:51.771678
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert len(AnsibleJ2Vars()) == 0

# Generated at 2022-06-21 08:01:00.613494
# Unit test for method __iter__ of class AnsibleJ2Vars