

# Generated at 2022-06-21 07:51:08.165905
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test cases: Get variable from different variable scope
    # Case 1: Variable is not in self._locals and neither in self._templar.available_variables and self._globals
    test_AnsibleJ2Vars = AnsibleJ2Vars(None, {}, {})

    with open('test_AnsibleJ2Vars___getitem___1.txt', 'w') as f:
        try:
            test_AnsibleJ2Vars.__getitem__('varname1')
        except Exception as e:
            f.write(repr(e))

    # Case 2: Variable is not in self._locals but in self._templar.available_variables (type of value is dict)

# Generated at 2022-06-21 07:51:17.727231
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_host_variable("test_host", "test_host_var", value="host_var_val")
    variable_manager.set_host_variable("test_host", "test_host_var2", value="host_var_val2")
    variable_manager.set_host_variable("test_host", "test_host_var3", value="host_var_val3")
    variable_manager.set_host_variable("test_host", "test_host_var4", value="host_var_val4")

# Generated at 2022-06-21 07:51:28.170061
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(facts=dict(foo='bar')))
    templar = Templar(loader=None, variables=variable_manager)
    variable_manager.set_globals(dict(globals=dict(foo='bar')))

    vars = AnsibleJ2Vars(templar, dict(globals=dict(bar='baz')))
    assert 'foo' in vars
    assert 'globals' in vars
    assert 'bar' in vars
    assert 'facts' in vars
    assert 'invalid_var' not in vars



# Generated at 2022-06-21 07:51:40.279977
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.template import Templar
    import os
    import tempfile

    my_data_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data')
    templar = Templar(loader=None, variables={}, shared_loader_obj=None)
    all_vars = dict()
    templar._available_variables = dict()
    templar._final_only = True
    templar.set_available_variables(all_vars)
    templar.basedir = my_data_dir
    templar.environment = Environment(loader=templar.get_loader(), undefined=StrictUndefined)
    templar.environment.filters['to_nice_yaml'] = templar._to_nice_yaml


# Generated at 2022-06-21 07:51:51.496021
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    vars = {u'vars': {u'ansible_connection': u'ssh', u'ansible_host': u'127.0.0.1', u'ansible_ssh_pass': u'123'}, u'inventory_hostname': u'test'}
    vars_manager = VariableManager()
    vars_manager.extra_vars = vars

    # the extra vars should be merged into the host vars after templating,
    # and the result should be stored in the _host_vars cache.


# Generated at 2022-06-21 07:52:03.222550
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    class Templar():
        available_variables = {
            'dict_key_1': 'dict_val_1',
            'dict_key_2': 'dict_val_2',
            'dict_key_3': 'dict_val_3',
        }

    globals = {
        'global_key_1': 'global_val_1',
        'global_key_2': 'global_val_2',
        'global_key_3': 'global_val_3',
    }

    locals = {
        'local_key_1': 'local_val_1',
        'local_key_2': 'local_val_2',
        'local_key_3': 'local_val_3',
    }

    ajv = AnsibleJ2Vars(Templar(), globals, locals)


# Generated at 2022-06-21 07:52:12.320853
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'})
    j2vars = AnsibleJ2Vars(templar, {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'})
    assert set(j2vars.__iter__()) == set(['a', 'b', 'c', 'd', 'a', 'b', 'c', 'd'])



# Generated at 2022-06-21 07:52:21.453465
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.reserved import Reserved

    #Local variables
    l_var1 = 'local_var_1'
    l_var2 = 'local_var_2'

    #Make globals and locals
    locals_ = dict()
    locals_['l_var1'] = l_var1
    locals_['l_var2'] = l_var2
    globals_ = dict()
    globals_['g_var1'] = 'global_var_1'
    globals_['g_var2'] = 'global_var_2'
    globals_[Reserved.DEFAULT_UNDEFINED] = Und

# Generated at 2022-06-21 07:52:23.163560
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert not AnsibleJ2Vars(None, None, None)

# Generated at 2022-06-21 07:52:24.399122
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert False, "No implemented"

# Generated at 2022-06-21 07:52:37.397798
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    a = dict(a=1)
    b = dict(b=1)
    c = dict(c=1)
    ansible_j2_vars = AnsibleJ2Vars(templar, a, b)
    assert 'a' in ansible_j2_vars
    assert 'b' in ansible_j2_vars
    assert 'c' in ansible_j2_vars
    assert 'd' not in ansible_j2_vars
    assert 'e' not in ansible_j2_vars
    d = dict(d=1)
    ansible_j2_vars.add_locals(c)
   

# Generated at 2022-06-21 07:52:48.773910
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from units.mock.loader import DictDataLoader
    from ansible.template import Templar
    from ansible import constants as C

    loader = DictDataLoader({'vars.yml': 'a: "{{ b }}"', 'vars2.yml': 'a: "{{ b }}"'})
    templar = Templar(loader=loader, variables={'b': 'B'})

    global_vars = {'g1': '{{a}} {{g2}}', 'g2': 'G2'}
    local_vars = {'l1': '{{a}} {{b}}', 'b': 'B2'}

    proxy = AnsibleJ2Vars(templar, global_vars)
    assert 'a' not in proxy

    proxy = proxy.add_locals(local_vars)
   

# Generated at 2022-06-21 07:52:54.023046
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        from ansible.template import Templar
    except ImportError:
        print("skipping due to missing import")
        return

    try:
        vars = AnsibleJ2Vars(Templar(), globals={})
        assert(vars is not None)
    except:
        assert(False)


# Generated at 2022-06-21 07:53:02.436821
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None, variables={})
    j2vars = AnsibleJ2Vars(templar=templar, globals={})
    assert "foo" not in j2vars

    j2vars._globals["foo"] = "bar"
    assert "foo" in j2vars

    j2vars._templar.available_variables["foo"] = "42"
    assert "foo" in j2vars

    j2vars._locals["foo"] = "baz"
    assert "foo" in j2vars

    # special dict type that was removed in Ansible 2.8
    j2vars._templar.available_variables["foo"]

# Generated at 2022-06-21 07:53:14.370073
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    vars_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=vars_manager)
    vars_manager._extra_vars = { 'a': 'A', 'b': 'B' }
    locals = { 'c': 'C', 'd': 'D' }
    proxy = AnsibleJ2Vars(templar, globals={ 'e': 'E', 'f': 'F' })
    p1 = proxy.add_locals(locals)
    assert set(p1.keys()) == { 'a', 'b', 'c', 'd', 'e', 'f' }

# Unit

# Generated at 2022-06-21 07:53:25.347758
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from jinja2.utils import missing
    from ansible.templating import Templar
    templar = Templar(loader=None)
    templar.available_variables = {"foo": "bar"}
    globals = {"baz": "foobar"}
    locals = {"newlocal": "newval"} # to be added to class instance

    instance = AnsibleJ2Vars(templar, globals)
    assert locals.get("newlocal") == instance.add_locals(locals).get("newlocal")
    assert "newlocal" in instance.add_locals(locals)
    assert "newlocal" not in instance
    assert locals.get("newlocal") is not missing

# Generated at 2022-06-21 07:53:37.935257
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible import module_utils
    from ansible.template import Templar

    def run_test(func):
        def fn():
            # text fixture
            playbook_vars = dict(myplayvars=dict(myplaykey='myplayval'))
            available_vars = dict(myvarkey='myvarval',
                                  hostvars=dict(myhost='myhostval'),
                                  group_names=['mygroup'],
                                  myvars=dict(mykey='myval'),
                                  vars=dict(mykey='myval'))
            j2vars = AnsibleJ2Vars(template=Templar(module_utils.module_builder.module_args(),
                                                     available_vars=available_vars,
                                                     variables=playbook_vars))
            # test fixture

# Generated at 2022-06-21 07:53:47.948242
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # Create test object
    templar = unittest.mock.MagicMock()
    globals = unittest.mock.MagicMock()
    locals = unittest.mock.MagicMock()
    test_object = AnsibleJ2Vars(templar, globals, locals)

    # Run test
    # Ensure that a KeyError is raised if a template variable is undefined
    with pytest.raises(KeyError) as excinfo:
        # Template variable is undefined
        test_object.__getitem__('foo')
    assert excinfo.value.args[0] == 'undefined variable: foo'

    # Reset mocks
    templar.reset_mock()
    globals.reset_mock()
    locals.reset_mock()

    # Run test
    # Ensure that an

# Generated at 2022-06-21 07:53:50.694810
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Create a new instance of class AnsibleJ2Vars
    vars = AnsibleJ2Vars(None, {})
    # Test that it return an iterator
    iter(vars)


# Generated at 2022-06-21 07:53:57.915522
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible import constants as C
    templar = Templar(None, C.DEFAULT_JINJA2_NATIVE)

    var_list = {'a': 1, 'b': 2}
    global_var_list = {'c': 3}

    vars = AnsibleJ2Vars(templar, global_var_list, var_list)
    assert len(var_list) == len(vars)
    assert len(global_var_list) + 2 == len(vars)

# Generated at 2022-06-21 07:54:12.606393
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import PY2

    task = Task()
    var_manager = VariableManager(loader=None)
    templar = Templar(var_manager, loader=None, shared_loader_obj=None)

    vars = AnsibleJ2Vars(templar, None, locals=None)
    assert len(vars) == 0
    assert vars.add_locals({'a': 1, 'b': 2}) == vars

    vars = AnsibleJ2Vars(templar, {'a': 1, 'b': 2}, locals=None)
    assert len(vars) == 2
    if PY2:
        assert sorted

# Generated at 2022-06-21 07:54:15.913627
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    _templar = Templar()
    _globals = {'test': 'global'}

    _obj = AnsibleJ2Vars(_templar, _globals)
    assert sorted(list(_obj)) == ['test']

# Generated at 2022-06-21 07:54:25.829363
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory import Inventory
    import pytest

    loader = DataLoader()
    variable_manager = VariableManager()
    host = Host(name='localhost')
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[host])
    variable_manager.set_inventory(inventory)

    variables = dict(one=1, two=2, vars=dict(foo='bar'))
    variable_manager.set_host_variable(host, variables)

    templar

# Generated at 2022-06-21 07:54:35.771772
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.inventory.host import Host

    given_globals = dict(
        foo='bar',
        baz=[1, 2, 3],
        wub=Host(inventory=None, name='wub'),
    )
    given_locals = dict(
        # "l_" prefix is stripped in AnsibleJ2Vars.__init__
        l_fizz='buzz',
        l_blip=AnsibleSequence([1, 2, 3], unsafe=True),
        l_sonic=Host(inventory=None, name='sonic'),
    )
    given_host

# Generated at 2022-06-21 07:54:43.711468
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()

    templar = Templar(loader=loader, variables=variable_manager)

    vars = AnsibleJ2Vars(templar, {})
    assert len(vars) == 0

    variable_manager.set_host_variable(host=Inventory().get_host(u'localhost'), varname=u'foo', value=u'FOO')

    assert len(vars) == 1

    variable_manager.set_host_variable(host=Inventory().get_host(u'localhost'), varname=u'quux', value=u'QUUX')


# Generated at 2022-06-21 07:54:50.873495
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    globals  = {'g1': 'g1'}
    locals = {'l1': 'l1'}

    templar = None # FIXME: implement mock Templar()
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g1' in vars
    assert 'l1' in vars
    assert 'g2' not in vars
    assert 'l2' not in vars

# Generated at 2022-06-21 07:54:59.940410
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import ansible.vars.manager
    import ansible.vars.hostvars
    import ansible.template
    import ansible.playbook.play_context
    import ansible.playbook.task
    import ansible.playbook.play
    import ansible.playbook.role
    from jinja2.runtime import Context
    from jinja2.environment import Environment

    manager = ansible.vars.manager.VariableManager()
    host = ansible.inventory.host.Host(name="localhost")
    hostvars = ansible.vars.hostvars.HostVars(
        host=host,
        variable_manager=manager
    )
    manager._hostvars[host.get_name()] = hostvars
    manager._hostvars["_meta"] = dict()

    vars_dict

# Generated at 2022-06-21 07:55:12.474739
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.plugins.loader import vault_secret

    # create variables that our templates will use
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'secret_key': vault_secret('secret-key')}
    variable_manager.set_fact('self_references_variable', variable_manager['secret_key'])
    variable_manager.set_fact('playbook_dir', 'playbook')
    variable_manager.set_fact('ansible_playbook_python', 'python')
    variable_manager.set_fact('ansible_system', 'Linux')
    variable_manager.add_host_vars_from_inventory(Host('test-host'), {'test_var': 'test-value'})

# Generated at 2022-06-21 07:55:21.168139
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars(dict(ansible_all_ipv4_addresses=['172.16.0.34'],
                             ansible_all_ipv6_addresses=[]),
                        '127.0.0.1')
    templar = Templar(loader=None, variables=dict(hostvars=hostvars))
    j2vars = AnsibleJ2Vars(templar, globals=dict(hostvars=hostvars))
    assert len(j2vars) == 21

# Generated at 2022-06-21 07:55:24.129979
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    Unit test for constructor of class AnsibleJ2Vars
    '''
    templar = None
    globals = None
    locals = None
    abc = AnsibleJ2Vars(templar,globals,locals)

# Generated at 2022-06-21 07:55:33.693050
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    test_dict = {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

    test_jinja2_vars = AnsibleJ2Vars(None, None, locals=test_dict)

    assert(set(test_jinja2_vars) == set(test_dict.keys()))

# Generated at 2022-06-21 07:55:37.293441
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    j2vars = AnsibleJ2Vars(None, {'a':'a'})
    assert j2vars['a'] == 'a'


# Generated at 2022-06-21 07:55:46.320388
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    class Templar:
        def __init__(self, available_variables):
            self.available_variables = available_variables

    # tested variable
    ansible_j2_vars = AnsibleJ2Vars(Templar({'foo': 1}), {'bar': 2})

    # global scope: {'bar': 2}
    assert 'bar' in ansible_j2_vars
    assert ansible_j2_vars['bar'] == 2

    # local scope:  {}
    assert 'baz' not in ansible_j2_vars

    # templar scope: class Templar
    assert 'foo' in ansible_j2_vars
    assert ansible_j2_vars['foo'] == 1


# Generated at 2022-06-21 07:55:55.473573
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'some_var': 'global_value'}
    locals = {'some_var': 'local_value'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # Test (positive)
    assert len(list(j2vars)) == 3
    assert 'some_var' in list(j2vars)
    assert 'other_var' in list(j2vars)


# Generated at 2022-06-21 07:56:03.150741
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ds = DataLoader()
    t = Templar(loader=ds)
    v = VariableManager()
    vars = AnsibleJ2Vars(t, globals=dict())

    vars['test_key1'] = 'test_value1'
    vars['test_key2'] = 'test_value2'

    assert set(vars.__iter__()) == set(['test_key1', 'test_key2'])

# Generated at 2022-06-21 07:56:12.524451
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.manager import VariableManager

    vars = dict(dict(a=1,b=2,c=3))
    vars_proxy = wrap_var(vars)

    t = Templar(loader=None, variables=vars_proxy)
    d = dict(dict(a=1,b=2,c=3,d=4))
    v = AnsibleJ2Vars(t, d)
    assert len(vars) == len(v)


# Generated at 2022-06-21 07:56:15.912769
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    b = AnsibleJ2Vars('hello', 'world')
    assert(b._templar == 'hello')
    assert(b._globals == 'world')
    assert(b._locals == dict())

# Generated at 2022-06-21 07:56:26.604773
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={
        'a': 1,
        'b': 2,
    })

    assert 'a' in AnsibleJ2Vars(templar, {})
    assert 'b' in AnsibleJ2Vars(templar, {})
    assert 'c' not in AnsibleJ2Vars(templar, {})
    assert 'd' not in AnsibleJ2Vars(templar, {})

    assert 'a' in AnsibleJ2Vars(templar, {'c': 1})
    assert 'b' in AnsibleJ2Vars(templar, {'c': 1})
    assert 'c' in AnsibleJ2Vars(templar, {'c': 1})
    assert 'd'

# Generated at 2022-06-21 07:56:32.399613
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    import copy
    globals = copy.deepcopy(templar.available_variables)
    locals = copy.deepcopy(templar.available_variables)
    ansibleJ2Vars = AnsibleJ2Vars(templar, globals, locals)
    if not isinstance(ansibleJ2Vars, list):
        raise Exception('unittest: AnsibleJ2Vars.__iter__ is not iter(list)')

# Generated at 2022-06-21 07:56:33.458163
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # no tests at this time
    return

# Generated at 2022-06-21 07:56:48.594781
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.playbook.attribute import Attribute, FieldAttribute, HostAttribute
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_dependency import RoleDependency

    templar = Templar(loader=None)
    # play_context
    templar._available_variables = dict()
    templar._available_variables['play_hosts'] = dict()
    templar._available_variables['inventory_hostname'] = 'test1.example.com'

# Generated at 2022-06-21 07:56:56.968285
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.utils.unsafe_proxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Create variable proxy object
    proxy = AnsibleJ2Vars(None, dict(a='global a'))
    proxy._templar.available_variables = dict(b='available b')
    proxy._locals = dict(c='local c', d=dict(e='e of d'))

    # Test for missing variable
    try:
        proxy['nonexistent_variable']
        raise Exception('Proxy should throw KeyError when variable is not found')
    except KeyError:
        pass

    # Test for variable in _locals
    assert proxy['c'] == 'local c'

    # Test for variable in _templar.

# Generated at 2022-06-21 07:57:09.531573
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from units.mock.loader import DictDataLoader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    locals = {'l_foo': 'bar'}
    globals = {'g_foo': 'bar'}
    templar = Templar(loader=DictDataLoader({}), variables={'v_foo' : 'bar', 'foo': {'bar': 'baz'}})

    ajv = AnsibleJ2Vars(templar, globals, locals)

    assert sorted(list(ajv)) == sorted(['foo', 'l_foo', 'v_foo', 'g_foo'])
    assert ajv['l_foo'] == 'bar'
    assert aj

# Generated at 2022-06-21 07:57:20.004310
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    
    fake_templar = {
        'available_variables': {
            'hostvars': dict(),
            'inventory_hostname': 'test server',
            'ansible_ssh_host': '127.0.0.1',
        }
    
    }
    fake_locals = {
        'task': 'Install Apache service'
    }
    fake_globals = {
        'hostvars': dict(),
        'inventory_hostname': 'test server',
        'ansible_ssh_host': '127.0.0.1',
    }
    
    aj = AnsibleJ2Vars(fake_templar, fake_globals, locals=fake_locals)
    assert(isinstance(aj, AnsibleJ2Vars))

    # test task var

# Generated at 2022-06-21 07:57:26.987241
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # Setup test object
    from ansible.template.safe_eval import compile_to_ast
    from ansible.template import Templar
    templar = Templar(loader=None)
    test_instance = AnsibleJ2Vars(templar, {}, {"locals" : {}})

    # Method call under test
    result = test_instance.__contains__("locals")

    # Evaluate results
    assert result is True

# Generated at 2022-06-21 07:57:37.160757
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class Templar(object):
        def __init__(self, available_variables):
            self.available_variables = available_variables
    available_variables = {'key1': 'value1'}
    templar = Templar(available_variables)
    global_vars = {'key2': 'value2'}
    local_vars = {'key3': 'value3'}
    j2_vars = AnsibleJ2Vars(templar, globals=global_vars, locals=local_vars)

    assert 'key1' in j2_vars
    assert 'key2' in j2_vars
    assert 'key3' in j2_vars
    assert 'key4' not in j2_vars


# Generated at 2022-06-21 07:57:49.984609
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """
    Make sure iter on AnsibleJ2Vars is working.
    """
    globals_dict = {'string_glob': 'global_string',
                    'dict_glob': {'a': 1, 'b': 2},
                    'list_glob': [1, 2, 3, 4]}

    locals_dict = {'string_loc': 'local_string',
                   'dict_loc': {'a': 1, 'b': 2},
                   'list_loc': [1, 2, 3, 4]}

    templar_dict = {'string_templar': 'templar_string',
                    'dict_templar': {'a': 1, 'b': 2},
                    'list_templar': [1, 2, 3, 4]}


# Generated at 2022-06-21 07:57:57.858759
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables=None)
    globals = dict(g_var="globals_variable")
    locals = dict(l_var="locals_variable")
    ansible_vars = dict(a_var="ansible_variable")
    templar._available_variables = ansible_vars

    assert (ansible_vars["a_var"] == "ansible_variable")
    assert ("a_var" in ansible_vars)

    aj2v = AnsibleJ2Vars(templar, globals, locals)

    assert (aj2v["g_var"] == "globals_variable")
    assert ("g_var" in aj2v)


# Generated at 2022-06-21 07:58:09.981570
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, use_vault=False)
    templar = Templar(loader=loader, variables=variable_manager)

    base_path = "./test/unit/templating/"
    templar_folder = os.path.join(base_path, 'templar')
    variable_folder = os.path.join(base_path, 'vars')

    # Setup fixture data
    variable_manager._vars_from_files(variable_folder)
    variable_manager._vars_from_files(templar_folder)

    variable_manager._vars_from_files(base_path)


# Generated at 2022-06-21 07:58:19.637351
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar

    loader = DataLoader()
    host_list = [u'localhost', u'localhost']
    inventory = InventoryManager(loader=loader, sources=host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{test_var}}')))
             ]
        )

# Generated at 2022-06-21 07:58:33.896550
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    globals = {"g": 123, "gg": 456}
    locals = {"l": 1, "ll": 2, "lll": 3}
    templar = None

    obj = AnsibleJ2Vars(templar, globals, locals)

    for k in globals:
        assert k in obj
    for k in locals:
        assert k in obj

    assert "__contains__" not in obj
    assert "__init__" not in obj


# Generated at 2022-06-21 07:58:44.132479
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # Test scalar values.
    def test():
        keys = ('foo', 'bar')
        values = ('Hello', 42)
        locals = dict()
        for key, value in zip(keys, values):
            locals['l_' + key] = value
        vars = AnsibleJ2Vars(None, None, locals=locals)
        for key, value in zip(keys, values):
            assert vars[key] == value

    test()

    # Test structure with scalar values.
    def test():
        keys = ('foo', 'bar')
        values = ('Hello', 42)
        locals = dict(
            l_structure=dict(
                zip(keys, values)
            )
        )
        vars = AnsibleJ2Vars(None, None, locals=locals)
        assert vars

# Generated at 2022-06-21 07:58:55.399893
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # create the objects to test with
    lh = DataLoader()
    inventory = {
        'all': {
            'children': ['ungrouped']
        },
        'ungrouped': {
            'hosts': {
                'testhost': {
                    'ansible_connection': 'local',
                },
                'testhost2': {
                    'ansible_connection': 'local',
                }
            }
        },
    }
    v = VariableManager(loader=lh, inventory=inventory)
    t = Templar(loader=lh, variables=v)

# Generated at 2022-06-21 07:59:02.498272
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = Templar(loader=DictDataLoader(dict()))
    globals = dict(g1='g1')
    locals = dict(l1='l1')

    j2_vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)

    assert 'g1' in j2_vars
    assert 'l1' in j2_vars
    assert 'l_1' not in j2_vars

# Generated at 2022-06-21 07:59:11.140271
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test when key is in locals
    templar = object
    globals = object
    locals = {'l1': 'value1', 'l2': 'value2'}
    djv = AnsibleJ2Vars(templar, globals, locals)
    assert 'l1' in djv
    # Test when key is in available_variables
    djv._templar.available_variables = {'v1': 'value1', 'v2': 'value2'}
    assert 'v1' in djv
    # Test when key is in globals
    djv._globals = {'g1': 'value1', 'g2': 'value2'}
    assert 'g1' in djv
    # Test when key is not present
    assert 'g3' not in djv

# Generated at 2022-06-21 07:59:21.685304
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.templar import Templar

    globals = {
        'one': 1,
    }
    locals = {
        'two': 2,
        'three': 3,
        'context': {'four': 4},
        'environment': {'five': 5},
        'template': 'six',
    }
    templar = Templar()
    templar.available_variables = {
        'seven': 7,
    }

    j2vars = AnsibleJ2Vars(templar, globals, locals=locals)

    assert 'one' in j2vars
    assert 'two' in j2vars
    assert 'three' in j2vars
    assert 'four' in j2vars
    assert 'five' in j2vars
    assert 'six' in j

# Generated at 2022-06-21 07:59:32.774721
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class TestTemplar():
        def variable(self, variable):
            return variable

        @property
        def available_variables(self):
            return {
                'test_var': 'test_value',
                'test_var2': 'test_value2'
            }


    j2vars = AnsibleJ2Vars(TestTemplar(), {}, locals={
        'l_test_local_name': 'test_local_value',
    })

    # Test keys
    assert list(j2vars.keys()) == [
        'test_var', 'test_var2',
        'test_local_name'
    ]

    # Test values

# Generated at 2022-06-21 07:59:43.311076
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # FIXME: written as a random unit tests that needs to be converted to proper python unit test
    #        see AnsibleJ2Vars class above

    templar = None
    globals = {}
    locals = {}

    # Test constructor with None value
    vars_proxy = AnsibleJ2Vars(templar, globals)
    assert vars_proxy._templar == None
    assert vars_proxy._globals == globals

    # Test constructor with valid Templar, globals and locals
    vars_proxy = AnsibleJ2Vars(templar, globals, locals)
    assert vars_proxy._templar == templar
    assert vars_proxy._globals == globals
    assert vars_proxy._locals == locals

# Generated at 2022-06-21 07:59:54.597891
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    Test `__len__()` method of class AnsibleJ2Vars()
    '''
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Get the class definition for which being tested
    _class = AnsibleJ2Vars

    # Setup a PlayContext object
    context = PlayContext()
    context._data_loader = DataLoader()

    #

# Generated at 2022-06-21 08:00:05.679437
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = dict(a=1, b=2)

# Generated at 2022-06-21 08:00:19.267751
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    my_test = AnsibleJ2Vars(Templar({}), {'v1':'v1', 'v2':'v2'})
    my_len = len(my_test)
    if my_len != 2:
        raise AssertionError("Expected len(my_test) == 2, got '%s'" % my_len)


# Generated at 2022-06-21 08:00:25.461030
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = object()
    locals={'a':1,'b':2,'c':3}
    globals={'g':'gvar'}
    vars1 = AnsibleJ2Vars(templar, globals, locals)
    vars2 = vars1.add_locals(locals)
    assert len(vars1) == 5
    assert len(vars2) == 5

# Generated at 2022-06-21 08:00:28.913913
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    new = AnsibleJ2Vars(None, None, None).add_locals(locals={'a': 1})
    assert type(new) == AnsibleJ2Vars and new._locals['a'] == 1


# Generated at 2022-06-21 08:00:40.593707
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=DataLoader())
    templar.available_variables = dict()
    templar.available_variables['vars'] = dict()
    templar.available_variables['vars']['foo1'] = 'foo1'
    templar.available_variables['vars']['foo2'] = 'foo2'
    locals = dict()
    locals['l_var1'] = 'var1'
    locals['l_var2'] = 'var2'
    globals = dict()
    globals['g_var1'] = 'gvar1'
    globals['g_var2'] = 'gvar2'

# Generated at 2022-06-21 08:00:48.267419
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = dict(globals_1='globals_1', globals_2='globals_2')
    locals = dict(locals_1='locals_1', locals_2='locals_2')
    # test without available_variables
    test_obj = AnsibleJ2Vars(templar, globals, locals)
    expected = sorted(['locals_1', 'locals_2', 'globals_1', 'globals_2'])
    assert sorted(list(test_obj)) == expected
    # test with available_variables
    templar = object()
    templar.available_variables = dict(av_1='av_1', av_2='av_2')

# Generated at 2022-06-21 08:00:58.820112
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    mock_globals = None
    mock_available_variables = { 'x': 'y' }
    mock_template = lambda variable: variable

    mock_templar = Templar(available_variables=mock_available_variables)

    mock_templar.template = mock_template

    vars1 = AnsibleJ2Vars(templar=mock_templar, globals=mock_globals)

    # test __getitem__
    assert vars1['x'] == 'y'

    # test __getitem__ raise KeyError
    try:
        vars1['x1']
    except KeyError:
        pass
    else:
        assert False, "Expected exception not raised!"
