

# Generated at 2022-06-21 07:51:06.781262
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    class TemplarMock:
        def __init__(self, data):
            self.available_variables = data
            self.template = lambda x: x

    globals = dict(g1='g1 value')
    locals = dict(l1='l1 value')
    data = dict(v1='v1 value', v2='v2 value')

    # check for expected __getitem__() result for locals, globals and data
    aj2vars = AnsibleJ2Vars(TemplarMock(data), globals, locals)

    assert aj2vars['l1'] == 'l1 value'
    assert aj2vars['g1'] == 'g1 value'
    assert aj2vars['v1'] == 'v1 value'

    # check that new locals are added to existing locals
   

# Generated at 2022-06-21 07:51:16.872430
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    host = Host(name="somehost")
    variable_manager = VariableManager(loader=loader)
    variable_manager.set_host_variable(host, "ansible_ssh_host", "1.2.3.4")
    variable_manager.set_host_variable(host, "ansible_ssh_port", "22")
    variable_manager.set_host_variable(host, "ansible_ssh_user", "test")
    templar = Templar(loader=loader, variables=variable_manager)

    vars = AnsibleJ2Vars(templar, dict(), dict())

# Generated at 2022-06-21 07:51:17.519397
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-21 07:51:28.279424
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    # Create an object of class AnsibleJ2Vars
    templar = Templar(loader=None, variables=None)
    globals = dict(A='A', B='B', C='C', D='D')
    locals = dict(a='a', b='b', c='c')
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Add locals to the object
    new_locals = dict(d='d', e='e', f='f')
    new_ansible_j2_vars = ansible_j2_vars.add_locals(new_locals)

    # Check that the local variables are copied as expected
    assert ansible_j2_vars._templar == new_ansible_j2_vars._templ

# Generated at 2022-06-21 07:51:40.373496
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class UndefinedVariable(str):
        def __init__(self, name):
            self.name = name
            super(UndefinedVariable, self).__init__()

    class AnsibleUndefinedVariable(AnsibleError):
        pass

    class HostVars(object):
        __UNSAFE__ = True

    class Templar(object):
        def __init__(self):
            self.available_variables = dict()

        def template(self, variable):
            if isinstance(variable, UndefinedVariable):
                raise AnsibleUndefinedVariable(variable.name)
            return variable

    templar = Templar()
    globals = dict()
    locals = dict(l_a = 1, l_b = 2)
    vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-21 07:51:48.282749
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    variable_manager = None
    variable_manager = variable_manager or {}
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=None, template_ds=None)

    globals = {}
    locals = {}

    aj2v = AnsibleJ2Vars(templar, globals, locals)

    # Test invalid variable

# Generated at 2022-06-21 07:51:51.545320
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    j2vars = AnsibleJ2Vars(Templar(loader=None), None)
    assert j2vars != None



# Generated at 2022-06-21 07:52:02.311440
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from jinja2 import DictLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    dataloader = DataLoader()
    jinja_env = Templar._get_jinja_env(loader=dataloader)
    jinja_env.loader = DictLoader(dict())
    templar = Templar(loader=dataloader, variables={}, jinja2_env=jinja_env)
    aj2v = AnsibleJ2Vars(templar, {'var1': 'foo'})
    assert 'var1' in aj2v
    assert 'var2' not in aj2v
    assert 'var3' not in aj2v


# Generated at 2022-06-21 07:52:14.970805
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext

    vault_pass = 'password'
    vault_id = VaultLib.get_vault_secret(vault_pass)
    play_context = PlayContext()
    play_context._vault_password = vault_pass
    play_context._vault_id = vault_id

    templar = Templar(vault_secrets=[vault_pass], loader=dict(), play_context=play_context)

    v = AnsibleJ2Vars(templar, {'foo': 'bar'})

    assert 'foo' in v

    assert 'foo' not in v._globals
    assert 'foo' in v._locals

    v._locals = {}
    assert 'foo' not in v

# Generated at 2022-06-21 07:52:23.012816
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    import sys

    # Unit test for method __iter__ of class AnsibleJ2Vars
    class mock_templar:
        class mock_available_variables:

            def __init__(self):
                self.dict = set()

            def add(self, thing):
                self.dict.add(thing)

            def __getitem__(self, item):
                return self.dict.get(item)

            def __len__(self):
                return len(self.dict)

            def __contains__(self, k):
                return k in self.dict

            def __iter__(self):
                return iter(self.dict)

        def __init__(self):
            self.available_variables = self.mock_available_variables()

    test_templar = mock_templar()
   

# Generated at 2022-06-21 07:52:39.112114
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    # We need a playbook to pass to the variable manager so let's create a minimal one
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    playbook_path = "test_playbook.yml"

# Generated at 2022-06-21 07:52:44.244596
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import ansible_safe_eval

    scope = {'vars': {}}
    templar = Templar(loader=None, variables=scope)
    globals = {'range': range}

    vars = AnsibleJ2Vars(templar, globals)

    assert len(vars) == 0


# Generated at 2022-06-21 07:52:48.825921
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    some_vars = {'a': 'a', 'b': 'b'}
    j2v = AnsibleJ2Vars(Templar(), {}, some_vars)

    keys = set(some_vars.keys())
    assert keys == set(j2v)

# Generated at 2022-06-21 07:52:54.837427
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar

    globals = dict(a=1)
    locals = dict(b=2)

    templar = Templar(loader=None)

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'a' in vars
    assert 'b' in vars
    assert 'c' not in vars



# Generated at 2022-06-21 07:53:00.569115
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.templar import Templar

    try:
        loader = DataLoader()
        my_templar = Templar(loader=loader, variables=dict())
        j2vars = AnsibleJ2Vars(my_templar, dict())
        j2vars.__contains__(dict())
    except AnsibleError:
        pass


# Generated at 2022-06-21 07:53:12.358381
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar()
    j2vars = AnsibleJ2Vars(templar, {}, {'hello':'world'})
    assert j2vars.add_locals({'foo':'bar'})._locals == {'hello':'world', 'foo':'bar'}
    assert len(j2vars.add_locals({'foo':'bar'})._locals) == 2
    assert j2vars.add_locals({'hello':'world', 'foo':'bar'})._locals == {'hello':'world', 'foo':'bar'}
    assert len(j2vars.add_locals({'hello':'world', 'foo':'bar'})._locals) == 2

# Generated at 2022-06-21 07:53:24.008858
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = dict()
    globals["g1"] = "g1_val"
    globals["g2"] = "g2_val"
    locals = dict()
    locals["l1"] = "l1_val"
    locals["l2"] = "l2_val"
    locals["l_g1"] = "l_g1_val"
    ansible_vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert len(ansible_vars) == 6
    count = 0
    for name in ansible_vars:
        count = count + 1
    assert count == 6
    assert ansible

# Generated at 2022-06-21 07:53:36.008481
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    from ansible.template import Templar
    templar = Templar()

    globals = dict(g='global')
    locals = dict(li='local')

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert vars['li'] == 'local'

    # We expect to get a copy of vars with different locals
    new_vars = vars.add_locals(dict(lo='local'))

    assert new_vars['li'] == 'local'
    assert new_vars['lo'] == 'local'
    assert not hasattr(vars, 'lo')

    # We expect to get the same instance of vars if passed None as locals
    for _ in range(10):
        new_vars = vars.add_locals(None)
        assert new_vars

# Generated at 2022-06-21 07:53:39.706746
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    var = dict(a=1)
    t = Templar(basedir='/', variables=var)  # creates AnsibleJ2Vars implicitly
    print(t.available_variables)


# Generated at 2022-06-21 07:53:49.200607
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import pytest

    def get_vars(host):
        '''
        Helper function to get variables in varnamespace "hostvars"
        '''
        hvars=VariableManager(loader=loader).get_vars(host=host, include_hostvars=True)['hostvars'][host.name]
        return hvars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-21 07:54:02.877421
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import pytest
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    vault_pass = 'secret'
    vault = VaultLib(vault_pass)

    templar = Templar(loader=None, variables={'secret': 'value'}, vault_secrets=[vault])

    # based on this setup, variable secret is defined under Templar class
    assert 'secret' in AnsibleJ2Vars(templar, {})
    assert 'secret' in AnsibleJ2Vars(templar, {'globals': 'defined'})

    # variable not_defined is not defined anywhere
    assert 'not_defined' not in AnsibleJ2Vars(templar, {})

# Generated at 2022-06-21 07:54:09.155126
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    class test: pass
    test.available_variables = dict()
    test.available_variables['test'] = 23
    test.template_ds = dict()
    test.template_ds['test2'] = ""
    test.environment = dict()
    test.environment['test3'] = set()

    ansible_vars = AnsibleJ2Vars(test, dict())
    len(ansible_vars)

# Generated at 2022-06-21 07:54:16.421000
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    real_globals = dict()
    global_vars = dict(a='global', b='global')
    global_vars.update(dict(a='global', b='global'))

    t = lambda x: x
    t.environment = None
    t.set_available_variables(dict(c='var'))

    j2vars = AnsibleJ2Vars(t, global_vars)

    assert len(j2vars) == 3
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'c' in j2vars

    for key in j2vars:
        assert key in ('a', 'b', 'c')

# Generated at 2022-06-21 07:54:19.612230
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    temp = Templar(variables={'foo': 'bar'})
    var = AnsibleJ2Vars(temp, {})
    assert var['foo'] == 'bar'


# Generated at 2022-06-21 07:54:29.821778
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from jinja2.loaders import DictLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader, shared_loader_obj=DictLoader({}))

    ansible_j2_vars = AnsibleJ2Vars(
        templar=templar,
        globals={'log_path': '{{ inventory_dir }}/log'}
    )

    assert ansible_j2_vars['inventory_dir'] == 'my_inventory_directory'
    assert ansible_j2_vars['log_path'] == '{{ inventory_dir }}/log'
    assert 'foo' not in ansible_j

# Generated at 2022-06-21 07:54:32.502893
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    AnsibleJ2Vars(templar, {}, locals=None)

# Generated at 2022-06-21 07:54:38.188539
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(None)
    globals = {'globals': {'a': 1, 'b': 2}}
    locals = {'locals': {'c': 3, 'd': 4}}
    proxy = AnsibleJ2Vars(templar, globals, locals)
    assert len(proxy) == 4


# Generated at 2022-06-21 07:54:42.758027
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    print("Testing AnsibleJ2Vars()")
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    play_context = PlayContext()
    templar = Templar(loader=None, variables=play_context.variables)
    vars = AnsibleJ2Vars(templar, {})
    assert len(vars) > 0
    print("Testing AnsibleJ2Vars() success!")

# Generated at 2022-06-21 07:54:55.131445
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class Templar(object):
        def __init__(self, variables):
            self.available_variables = variables
        def template(self, value):
            return value

    templar = Templar({"a": 1, "b": 2})

    vars_1 = AnsibleJ2Vars(templar, {})
    assert vars_1['a'] == 1
    assert vars_1['b'] == 2
    assert vars_1['c'] is None

    vars_2 = AnsibleJ2Vars(templar, {"d": "abcd"})
    assert vars_2['a'] == 1
    assert vars_2['b'] == 2
    assert vars_2['c'] is None
    assert vars_2['d'] == "abcd"

    vars_3 = Ans

# Generated at 2022-06-21 07:55:04.350782
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
        import mock
        # Create mock objects
        templar = mock.Mock()
        templar.available_variables = dict()
        templar.available_variables[u'variable1'] = u'value1'
        templar.available_variables[u'variable2'] = u'value2'
        templar.available_variables[u'variable3'] = u'value3'
        j2_vars = AnsibleJ2Vars(templar, dict(), dict())
        # Dummy test
        i = 0
        for key in j2_vars:
                i = i + 1
        assert i == 3

# Generated at 2022-06-21 07:55:19.245000
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    templar = Templar(loader=DataLoader(), variables=VariableManager(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader())))
    j2vars = AnsibleJ2Vars(templar, dict(), locals={'a': 1})
    new_locals = {'b': 2}
    j2vars_new = j2vars.add_locals(new_locals)
    assert len(j2vars_new) == 3
    assert j2vars_new['a'] == 1
    assert j2vars

# Generated at 2022-06-21 07:55:25.281368
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Execute the function under test
    test = AnsibleJ2Vars(None, {})
    assert len(test) == 0

    test = AnsibleJ2Vars(None, {'var1': 'value1', 'var2': 'value2'})
    assert len(test) == 2

    test = AnsibleJ2Vars(None, {'var1': 'value1', 'var2': 'value2'}, {'var3': 'value3'})
    assert len(test) == 3

    # cleanup
    pass



# Generated at 2022-06-21 07:55:37.395199
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    print('\nSample test case of AnsibleJ2Vars')
    import sys, os
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, root_dir)

    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars

    from ansible.template import Templar

    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    sample

# Generated at 2022-06-21 07:55:46.727685
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Fixture for add_locals of class AnsibleJ2Vars
    # For example:
    # parent_proxy = AnsibleJ2Vars(templar, globals, locals={'a': 10, 'b': 20})
    # child_proxy = parent_proxy.add_locals({'c': 30, 'd': 40})
    # self._get_render_metadata(child_proxy)
    parent_locals = {'a': 10, 'b': 20}
    child_locals = {'c': 30, 'd': 40}
    expected_locals = {'a': 10, 'b': 20, 'c': 30, 'd': 40}

    class Templar(object):
        def __init__(self):
            self.available_variables = {}

        '''Return template value as it is.'''

# Generated at 2022-06-21 07:55:48.347883
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass


# Generated at 2022-06-21 07:56:00.743387
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.vault import VaultLib

    def make_vault(password, data):
        v = VaultLib(password)
        v.decrypt(data)
        return v.decrypted_data

    class TestTemplar(object):
        def __init__(self):
            self.available_variables = {}


# Generated at 2022-06-21 07:56:04.273729
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = {'allowed_unsafe': ['needs_to_be_this'], 'needs_to_be_this': 'vars'}
    locals_ = None
    obj = AnsibleJ2Vars(templar, globals, locals_)

    assert 'needs_to_be_this' in obj



# Generated at 2022-06-21 07:56:10.287798
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    j2vars = AnsibleJ2Vars(templar, globals)
    if 'ansible_check_mode' in j2vars:
        assert True
    else:
        assert False
    if 'ansible_check_mode1' in j2vars:
        assert False
    else:
        assert True


# Generated at 2022-06-21 07:56:21.992073
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar, DictData
    from ansible.parsing.yaml.objects import AnsibleUnicode

    templar = Templar(variables={}, loader=None)
    locals = dict(a='foo', b='bar', l_c='baz', d=AnsibleUnicode('qux'))
    globals = dict(e='bam', f='xyzzy', g=AnsibleUnicode('thud'))
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars['a'] == 'foo'
    assert vars['b'] == 'bar'
    assert vars['c'] == 'baz'
    assert vars['d'] == 'qux'
    assert vars['e'] == 'bam'

# Generated at 2022-06-21 07:56:31.187838
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.templating import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Setup the variable manager
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(""))

    host = Host('localhost')
    variable_manager.set_host_variable(host, 'ansible_connection', 'ssh')
    variable_manager.set_host_variable(host, 'ansible_ssh_user', 'mburns')
    variable_manager.set_host_variable(host, 'ansible_ssh_pass', 'foo')
    variable_manager.set_host

# Generated at 2022-06-21 07:56:46.414521
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Create valid class with locals
    templar = Templar()
    assert templar is not None
    globals = dict()
    assert globals is not None
    locals = dict()
    assert locals is not None
    locals['a'] = 'A'
    locals['b'] = 'B'
    # Create new object
    j2vars = AnsibleJ2Vars(templar, globals, locals=locals)
    # Add new locals to j2vars
    locals1 = dict()
    assert locals1 is not None
    locals1['c'] = 'C'
    locals1['d'] = 'D'
    j2vars1 = j2vars.add_locals(locals1)
    # Verify that new locals are correctly added to the new object
    assert locals1['c'] in j2

# Generated at 2022-06-21 07:56:55.734734
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible import variables
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible import context

    var_manager = VariableManager()
    var_manager.extra_vars = {'a': 'b', 'c': 'd'}
    host_vars = HostVars()
    host_vars.add_host('localhost', {'a': 'b'})
    var_manager.host_vars = host_vars
    templar = Templar(
        loader=DataLoader(),
        variables=var_manager,
        shared_loader_obj=None,
    )
    globals = {'c': 'd'}



# Generated at 2022-06-21 07:57:08.391466
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # Mockup a Templar object by only implementing the `template` method
    class Templar:
        def template(self, v):
            return v
        def available_variables(self, v):
            return v

    templar = Templar()

    # 
    ajv = AnsibleJ2Vars(templar, dict(), dict())
    assert(len(ajv) == 0)
    assert(type(iter(ajv)) == type(iter([])))

    # make sure that ajv['a'] fails on an empty dict
    try:
        ajv['a']
        assert(False)
    except:
        pass
    # make sure that ajv['a'] fails on an empty dict, even if there are empty dicts in the templar
    templar = Templar()
    templar.available

# Generated at 2022-06-21 07:57:17.331947
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar

    test_locals = dict()
    test_locals['test_var'] = 'test_value'

    test_globals = dict()
    test_globals['test_global'] = 'test_global'

    templar = Templar()

    test_vars = AnsibleJ2Vars(templar, test_globals)
    test_vars = test_vars.add_locals(test_locals)

    # ensure locals was properly added
    assert test_vars['test_var'] == test_locals['test_var']

    # ensure globals weren't modified
    assert test_vars['test_global'] == test_globals['test_global']

# Generated at 2022-06-21 07:57:29.947655
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    try:
        # testing that variable is loaded only from locals when variable exists only in locals
        templar = None
        globals = {}
        locals = {'var1': {'var1.1':'value'}, 'var2': 'value2'}
        vars = AnsibleJ2Vars(templar, globals, locals=locals)
        result = vars['var1']
        assert result == {'var1.1':'value'}
        result = vars['var2']
        assert result == 'value2'
    except Exception as e:
        assert "1" == "1", "An exception was raised: %s" % str(e)


# Generated at 2022-06-21 07:57:37.896639
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
	pass
	# templar = Templar(loader=None, variables=None)
	# globals = {
	# 	'a': 'b',
	# 	'c': 'd'
	# }
	# locals = {
	# 	'e': 'f',
	# 	'g': 'h'
	# }
	# var = AnsibleJ2Vars(templar, globals, locals)
	# var['a'] # should return 'b'
	# var['c'] # should return 'd'
	# var['e'] # should return 'f'
	# var['g'] # should return 'h'
	# var['i'] # should raise KeyError

# Generated at 2022-06-21 07:57:47.142967
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # Setup the parameters
    templar = None
    globals = {'a': 'b'}
    locals = {'c': 'd'}

    # Create the AnsibleJ2Vars object and make sure the parameters
    aj2v_object = AnsibleJ2Vars(templar, globals, locals)
    assert aj2v_object._templar == None
    assert aj2v_object._globals == {'a': 'b'}
    assert aj2v_object._locals == {'c': 'd'}


# Generated at 2022-06-21 07:57:56.066186
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars=dict(v1='foo')
    variable_manager.options_vars=dict(v2='bar')

    aj2vars = AnsibleJ2Vars(variable_manager.get_vars, globals=dict(v3='baz'))

    assert('v1' in aj2vars)
    assert(aj2vars['v1'] == 'foo')

    assert('v2' in aj2vars)
    assert(aj2vars['v2'] == 'bar')


# Generated at 2022-06-21 07:58:06.317437
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    vars_manager = VariableManager()
    vars_manager.set_host_variable('inventory_hostname', 'localhost')
    vars_manager.add_extra_vars(dict(a=1, b=2, c=3))
    templar = Templar(loader=loader, variables=vars_manager)

    j2vars = AnsibleJ2Vars(templar, {})

    assert j2vars.add_locals(dict(a=1, b=2, c=3))



# Generated at 2022-06-21 07:58:17.654368
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    import collections
    import inspect
    import os
    import sys
    import types

    class _VarsModule(collections.Mapping):
        def __getitem__(self, key):
            return key

        def __iter__(self):
            return iter([])

        def __len__(self):
            return 0

    assert AnsibleJ2Vars(None, None, None) is not None

    assert AnsibleJ2Vars(None, None, {}) is not None

    assert AnsibleJ2Vars(None, None, []) is not None

    assert not isinstance(AnsibleJ2Vars(None, None, [1, 2, 3]), collections.MutableSequence)


# Generated at 2022-06-21 07:58:26.454581
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class __TestVars(AnsibleJ2Vars):
        def __init__(self):
            super(__TestVars, self).__init__(None, {'foo': 'Foo', 'bar': 'Bar'}, locals=None)

    assert len(__TestVars()) == 2
    assert len(__TestVars()) == 2
    assert len(__TestVars()) == 2
    assert len(__TestVars()) == 2


# Generated at 2022-06-21 07:58:38.713778
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible import module_utils
    from ansible.parsing.dataloader import DataLoader

    ansible_vars1 = {'a':11, 'b':False}
    ansible_vars2 = {'a':22, 'c':True}
    ansible_vars = {}
    ansible_vars.update(ansible_vars1)
    ansible_vars.update(ansible_vars2)

    templar = module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode=True, bypass_checks=True).load_file_common_arguments(None)
    templar.set_available_variables(ansible_vars)


# Generated at 2022-06-21 07:58:46.702774
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.vars.hostvars as HostVars

    mock_variables = {
        'test1': 'test1',
        'test2': 'test2',
        'test3': 'test3',
        'test4': 'test4',
        'test5': 'test5',
    }
    mock_locals = {
        'test1': 'mock1',
        'test2': 'mock2',
    }
    mock_globals = {
        'test3': 'mock3',
        'test4': 'mock4',
    }
    mock_vars = {
        'test5': 'mock5',
    }
    mock_hostvars = HostVars({'test1': 'mock1'})

    j2vars = AnsibleJ2V

# Generated at 2022-06-21 07:58:58.534500
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'hostvars': HostVars(loader=None, variables={})})
    test_proxy = AnsibleJ2Vars(templar=templar, globals={}, locals={})
    # test_proxy.add_locals(locals=None)
    assert(test_proxy.add_locals(locals=None) == test_proxy)
    # test_proxy.add_locals(locals={})
    assert(test_proxy.add_locals(locals={}) == test_proxy)
    # test_proxy.add_locals(locals={'var':'value'})

# Generated at 2022-06-21 07:59:08.990638
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.vault import VaultLib
    hostvars = HostVars({"test1": "test1"})
    templar = Templar(vault_secrets=VaultLib({}))
    test_J2Vars = AnsibleJ2Vars(templar, {}, {"test2": "test2"})
    assert "test1" not in test_J2Vars
    assert "test2" in test_J2Vars
    templar.set_available_variables({'hostvars': hostvars})
    assert "hostvars" in test_J2Vars
    assert "test1" not in test_J2Vars
    assert test_J2Vars["hostvars"] == hostvars

# Generated at 2022-06-21 07:59:18.487913
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    host_vars = dict(x=1, y=2)
    variables = ansible.utils.template.combine_vars(host_vars, dict(x=2, z=3))
    variables.update(dict(x=3, z=4, foo='foobar'))
    globals = dict(foo='bar')

    j2vars = AnsibleJ2Vars(ansible.utils.template.AnsibleTemplar(), globals, locals=variables)

    # HostVars is special, return it as-is, as is the special variable
    # 'vars', which contains the vars structure
    assert isinstance(j2vars['vars'], dict)
    assert j2vars['vars'] == dict(x=3, y=2, z=4, foo='foobar')



# Generated at 2022-06-21 07:59:29.966005
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.templating import Templar
    from collections import OrderedDict

    test_vars = {'foo': 'bar', 'bar': 'baz'}
    test_globals = {'baz': 'qux', 'qux': 'quux'}

    templar = Templar(loader=None, variables=test_vars)
    j2vars = AnsibleJ2Vars(templar, test_globals)

    assert set(iter(j2vars)) == set((x for x in test_vars.keys()) + (x for x in test_globals.keys()))

    test_locals = {'bar': 'quux', 'quux': 'quuux'}

# Generated at 2022-06-21 07:59:36.740622
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar

    templar = Templar(loader=None)
    templar.available_variables = dict()
    test = AnsibleJ2Vars(templar, dict())

    # Keys that are in templar.available_variables.
    test._templar.available_variables['var'] = 'val'
    assert test['var'] == 'val'

    # Keys that are in self._globals.
    test._globals['var'] = 'val'
    assert test['var'] == 'val'

    # Keys that are not in templar.available_variables and self._globals.

# Generated at 2022-06-21 07:59:45.907858
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from units.mock.loader import DictDataLoader
    from units.mock.vars import VariableManager

    templar = Templar(loader=DictDataLoader({}), variables=VariableManager())
    vars = AnsibleJ2Vars(templar, {})

    # check when locals is None
    assert vars == vars.add_locals(None)

    # check when locals is passed
    new_vars = vars.add_locals({"key": "value"})
    assert new_vars._locals == {"key": "value"}

# Generated at 2022-06-21 07:59:50.424744
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    def test_var_templating(v):
        return v.lower()


# Generated at 2022-06-21 08:00:07.018729
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Create an AnsibleJ2Vars object with the following content
    templar = None
    globals = {u'runtime': u'one', u'xyz': u'hello'}
    locals = {u'runtime': u'two', u'abc': u'world'}
    j2_vars = AnsibleJ2Vars(templar, globals, locals=locals)

    # Test method __contains__ with valid keys and invalid keys
    # Valid keys
    assert(j2_vars.__contains__('runtime'))
    assert(j2_vars.__contains__('abc'))
    assert(j2_vars.__contains__('xyz'))
    # Invalid keys
    assert(not j2_vars.__contains__('invalid'))

# Unit

# Generated at 2022-06-21 08:00:12.269671
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    t = Templar(None, None)
    vars = AnsibleJ2Vars(templar=t,globals= {'gvar': 'global'})
    vars.add_locals({'lvar': 'local'})

    assert vars['gvar'] == 'global'
    assert vars['lvar'] == 'local'
    assert vars.get('not_exist', 'default') == 'default'

# Generated at 2022-06-21 08:00:21.495879
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    dataloader = DataLoader()
    inv_manager = InventoryManager(loader=dataloader)

    variable_manager = VariableManager(loader=dataloader, inventory=inv_manager)
    templar = Templar(loader=dataloader, variables=variable_manager)

    j2_vars = AnsibleJ2Vars(templar, {'foo': 'bar'})
    assert('foo' in j2_vars)

# Generated at 2022-06-21 08:00:29.553798
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Host(name="foohost")
    play_context = PlayContext()
    templar = Templar(loader, variable_manager, play_context)
    globals = dict(a=1, b=2)

    j2vars = AnsibleJ2Vars(templar, globals)
    assert all(var in j2vars for var in ('a', 'b'))

# Generated at 2022-06-21 08:00:36.795342
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    templar = Templar(loader=None, variables={'a': 1, 'b': 2, 'c': 3, 'd': 4})
    ajv = AnsibleJ2Vars(templar, {})
    assert len(ajv) == 4

# Generated at 2022-06-21 08:00:46.251879
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class mock_templar(object):

        available_variables = {'foo': 'bar'}

        def template(self, variable):
            return variable

    globals = {'a': 'b'}
    locals = {'c': 'd'}

    vars = AnsibleJ2Vars(mock_templar(), globals, locals)
    assert len(vars) == 3
    assert vars['foo'] == 'bar'
    assert vars.get('foo', 'bogus') == 'bar'
    assert vars.get('bogus', 'bogus') == 'bogus'
    assert vars['a'] == 'b'
    assert vars['c'] == 'd'

    new_locals = vars.add_locals({'e': 'f'})
   

# Generated at 2022-06-21 08:00:57.771630
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    globals = {
        "some_global": AnsibleUnsafeText("globals are unsafe"),
        "list_global": [1, 2, 3]
    }
    locals = {
        "some_local": AnsibleUnsafeText("locals are unsafe"),
        "list_local": [1, 2, 3]
    }
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'some_global' in ansible_vars
    assert 'list_global' in ansible_vars
    assert 'some_local' in ansible_vars
    assert 'list_local' in ansible_