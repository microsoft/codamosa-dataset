

# Generated at 2022-06-21 07:51:10.691200
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)
    globals = {'a': wrap_var(10)}
    locals = {'a': wrap_var(11), 'b': wrap_var(12)}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Important: locals must take precedence over globals
    assert set(vars) == set(['a', 'b'])

    # Test that HostVars is preserved
    globals['hostvars'] = HostVars({'a': wrap_var(10), 'b': wrap_var(11)})

# Generated at 2022-06-21 07:51:22.168741
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)

    globals = {
        'foo': 'foo',
        'bar': 'bar',
        'baz': HostVars(loader=None, variables=dict(baz='baz')),
    }

    locals1 = {
        'foo': 'FOO',
        'baz': 'BAZ',
    }

    locals2 = {
        'bar': 'BAR',
        'baz': 'BAZ',
    }

    vars = AnsibleJ2Vars(templar, globals)

    vars_with_locals1 = vars.add_locals(locals1)

    assert 'foo' in vars_with_locals1

# Generated at 2022-06-21 07:51:33.675484
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    j2vars = None

    test_tmpl = '{{ foo }}'
    test_vars = dict(foo='bar')

   # test with no vars
    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, test_vars)
    assert 'foo' not in j2vars

   # test with fake vars
    templar.set_available_variables(test_vars)

    assert 'foo' in j2vars

    # test with real vars
    templar = Templar(loader=None)
    variables = VariableManager()
    variables.extra_vars = test_vars

# Generated at 2022-06-21 07:51:34.302682
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass

# Generated at 2022-06-21 07:51:34.927406
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-21 07:51:42.660829
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    vars_manager = VariableManager()
    vars_manager.extra_vars = dict(a=1,b=2,c=3)
    templar = Templar(loader=None, variables=vars_manager)
    vars = AnsibleJ2Vars(templar, None)
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' not in vars

# Generated at 2022-06-21 07:51:53.635039
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    a = 'abc'
    b = {'d': 'efg'}
    c = {'a': 'bcd'}
    d = {'h': 'ijk'}

    ansible_j2vars = AnsibleJ2Vars(a, b, c)
    assert len(ansible_j2vars) == 3

    # test for correct behaviour if one of the parameters is not a dictionary
    ansible_j2vars2 = AnsibleJ2Vars(a, b, d)
    assert len(ansible_j2vars2) == 2

# Generated at 2022-06-21 07:52:05.983197
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    from ansible.vars.hostvars import HostVars

    from ansible.module_utils.six import string_types

    # test data
    vault_secret = 'testdata'
    vault_password = 'testdata'
    vault_data = {'a': '1', 'b': [2, 3] }
    vault_encrypted = VaultLib(vault_password).encrypt(vault_data)

    vault_secret_2 = 'testdata2'
    vault_password_2 = 'testdata2'
    vault_data_2 = {'c': 5, 'd': 7 }
    vault_encrypted_2 = VaultLib(vault_password_2).encrypt(vault_data_2)

    #

# Generated at 2022-06-21 07:52:17.390490
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # These are "mock" Templar, Globals, and Locals classes.  The methods and
    # attributes exist only because they are used in the AnsibleJ2Vars class.
    class Templar():
        def __init__(self):
            self.available_variables = {'test': {}}

    class Globals():
        def __init__(self):
            self.test = 'test'

    class Locals():
        def __init__(self):
            self.test = 'test'

    templar = Templar()
    globals = Globals()
    locals = Locals()

    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv.__contains__('test')
    assert ajv.__getitem__('test') == 'test'

# Generated at 2022-06-21 07:52:22.676429
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import jinja2
    dataloader = DataLoader()
    templar = Templar(loader=dataloader)
    ansible_j2_vars = AnsibleJ2Vars(templar=templar, globals=jinja2.Template.globals)
    assert ansible_j2_vars is not None

# Generated at 2022-06-21 07:52:36.157817
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert True == isinstance(AnsibleJ2Vars(None, None, None), Mapping)
    assert True == isinstance(AnsibleJ2Vars(None, None), Mapping)
    assert True == isinstance(AnsibleJ2Vars(None, None, {}), Mapping)

    # test __contains__, __iter__, __len__
    templar = VaultLib()
    globals = combine_vars(templar, None, {})
    hostvars = HostVars(templar, [])
    var1

# Generated at 2022-06-21 07:52:39.492474
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    result = AnsibleJ2Vars.__contains__(AnsibleJ2Vars,object())
    assert result == False


# Generated at 2022-06-21 07:52:50.551252
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 07:53:00.272263
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.hostvars import HostVars
    templar = None
    globals = { 'g1': 'globals1'}
    locals = { 'l1': 'locals1'}

    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars.__getitem__('l1') == 'locals1'
    assert j2vars.__getitem__('g1') == 'globals1'
    assert j2vars.__getitem__('l1') == 'locals1'
    assert j2vars.__getitem__('g1') == 'globals1'

    new_locals = { 'l1': 'locals1-replaced', 'l2': 'locals2'}
   

# Generated at 2022-06-21 07:53:05.533011
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = {'gvar': 1}
    locals = {'lvar': 2, 'l_': 3}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert set(vars) == set(['l_', 'gvar', 'lvar', 'l'])


# Generated at 2022-06-21 07:53:18.078931
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    templar = Templar(loader=None, variables=dict())

    v_1 = AnsibleJ2Vars(templar, dict())
    assert isinstance(v_1, Mapping)
    assert hasattr(v_1, '_templar')
    assert hasattr(v_1, '_globals')


# Generated at 2022-06-21 07:53:25.968201
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    j2vars = AnsibleJ2Vars(Templar(), {})
    assert isinstance(j2vars["foo"], KeyError)
    assert isinstance(j2vars["foo"], KeyError)
    j2vars = AnsibleJ2Vars(Templar(), {"foo": "bar"})
    assert j2vars["foo"] == "bar"
    j2vars = AnsibleJ2Vars(Templar(), {"foo": "bar"}, {"l_bar": "baz"})
    assert j2vars["bar"] == "baz"

# Generated at 2022-06-21 07:53:38.505680
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import sys
    import os
    import json

    sys.path.append('./lib')

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar, AnsibleEnvironment
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    if not os.path.exists("./unit/vars/a.json"):
        print("This Unit test needs a ./unit/vars/a.json file.")
        exit(1)


# Generated at 2022-06-21 07:53:48.415877
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import inventory_loader, lookup_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    import jinja2
    from unit.mock.loader import DictDataLoader

    templar = Templar(loader=DataLoader())


# Generated at 2022-06-21 07:53:55.537192
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    vars = dict(
        one="1",
        two="2",
        three="3",
        four="4",
        five="5",
    )
    templar = Templar(loader=None, variables=vars)
    j2vars = AnsibleJ2Vars(templar, dict())
    if not isinstance(j2vars, Mapping):
        raise TypeError("AnsibleJ2Vars should be a Mapping but is not")

# Generated at 2022-06-21 07:54:03.707097
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    j2 = AnsibleJ2Vars({'a': 'x', 'b': 'y'}, {})
    assert 'a' in j2
    assert 'c' not in j2
    assert 'a' == next(iter(j2))


# Generated at 2022-06-21 07:54:11.340000
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    def get_vars(host=None, inventory=None):
        return dict(a=1, b=2)

    templar = Templar(loader=None, variables=dict())
    templar._get_vars_from_inventory(host=None, inventory=None)

    p = AnsibleJ2Vars(templar, dict(c=3), dict(l_d=4))

    assert 'a' in p
    assert 'b' in p
    assert 'c' in p
    assert 'd' in p
    assert 'e' not in p

# Generated at 2022-06-21 07:54:18.508108
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from jinja2.utils import missing

    loader = DataLoader()

    var_manager = VariableManager()
    var_manager.extra_vars = { "var3": "var3", "var4": "var4" }

    # Setup jinja2 env
    jinja_globals = combine_vars(loader=loader,
        variables=var_manager.extra_vars)
    jinja_globals['omit'] = missing

    templar = Templar(loader=loader, variables=var_manager)

    # Initialize AnsibleJ2Vars with empty variables
   

# Generated at 2022-06-21 07:54:27.203594
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    # TODO: mock Templar, globals and locals objects
    templar = None
    globals = None
    locals = None

    # create AnsibleJ2Vars object
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals=locals)

    # create new locals
    locals2 = {'l_x': 1, 'l_y': 2}

    # create new object using method add_locals
    ansible_j2_vars2 = ansible_j2_vars.add_locals(locals2)

    # check locals
    assert locals2 == ansible_j2_vars2._locals

# Generated at 2022-06-21 07:54:37.224119
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)

    class FakeVars(Mapping):
        def __contains__(self, k):
            if k == 'not_item':
                return False
            else:
                return True

        def __iter__(self):
            keys = ['vars', 'item', 'not_item', 'dict', 'HostVars', 'has_unsafe', 'unknown']
            return iter(keys)

        def __len__(self):
            keys = ['vars', 'item', 'not_item', 'dict', 'HostVars', 'has_unsafe', 'unknown']
            return len(keys)

        def __getitem__(self, k):
            if k == 'vars':
                return 'bar'

# Generated at 2022-06-21 07:54:44.380825
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import ansible.template
    from ansible.template import Templar

    templar = Templar()

    globals = {
        'one': 1,
        'two': '2'
    }

    locals = {
        'three': 3,
        'four': '4'
    }

    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert j2vars['one'] == 1
    assert j2vars['two'] == '2'
    assert j2vars['three'] == 3
    assert j2vars['four'] == '4'

    # Test undefined key raises KeyError
    try:
        j2vars['five']
    except KeyError:
        pass
    else:
        raise AssertionError('Test did not raise KeyError')

    # Test

# Generated at 2022-06-21 07:54:56.465568
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from collections import OrderedDict
    from ansible.template import Templar
    from ansible.module_utils.six import PY3

    vars_holder = {
        'v':'vv',
        'v2':'vv2',
        'v3':'vv3'
    }

    templar = Templar(None, loader=None, variables=OrderedDict(vars_holder))

    locals = {'l_v':'lv', 'l_v2':'lv2', 'l_v3':'lv3'}
    globals = {'g_v':'gv', 'g_v2':'gv2', 'g_v3':'gv3'}

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)


# Generated at 2022-06-21 07:55:02.872668
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    templar = Templar(loader=None)

    globals = {'one': 1, 'two': 2, 'three': 3}

    a = AnsibleJ2Vars(templar, globals)
    assert len(a) == 3

    a = AnsibleJ2Vars(templar, globals, locals={'four': 4})
    assert len(a) == 4

# Generated at 2022-06-21 07:55:13.994566
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None, variables={ "vars": AnsibleMapping({"name": "value"})})

    proxy = AnsibleJ2Vars(templar, { "vars": HostVars({"name": "value"}) })

    assert proxy["vars"] == { "name": "value" }
    assert proxy["name"] == "value"

    # FIXME: how is the below item supposed to behave ?

    #assert proxy["vars"]["name"] == "value"
    #assert proxy["name"]["name"] == "value"

# Generated at 2022-06-21 07:55:19.879547
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """Unit test for the __iter__ of class AnsibleJ2Vars"""
    templar = None
    globals = dict(a=3, b=4)
    locals = dict(d=8, e=9)
    vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert sorted(list(vars)) == ['a', 'b', 'd', 'e']

# Generated at 2022-06-21 07:55:39.426955
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.vars.hostvars import HostVars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)

    globals1 = {'hi': 'hi'}
    locals1 = {'there': 'there'}
    variables1 = {'vars': {'foo': 'bar'}}
    injected_vars1 = {}
    unsafe_proxy1 = AnsibleUnsafeText('unsafe_proxy')
    unsafe_proxy_dict1 = AnsibleUnsafeText('unsafe_proxy_dict')
    vars1 = AnsibleJ2Vars(templar, globals=globals1, locals=locals1)
    v

# Generated at 2022-06-21 07:55:41.283540
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    parser = AnsibleJ2Vars(templar=None, globals=None)
    assert parser

# Generated at 2022-06-21 07:55:46.882137
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = AnsibleUnsafeText("{{ 'a' }}")
    globals = {"a": AnsibleUnsafeText("{{ 'a' }}")}
    locals = {"b": AnsibleUnsafeText("{{ 'b' }}")}
    var = AnsibleJ2Vars(templar, globals, locals)
    assert var["a"] == "a", "Error in test_AnsibleJ2Vars"

# Generated at 2022-06-21 07:55:59.908245
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    varname = "varname"
    variable = "variable"
    from ansible.vars.hostvars import HostVars
    _templar = "templar"
    _globals = "globals"
    _locals = dict()
    _locals.update({
        "available_variables": variable
    })
    _templar.available_variables = _locals
    ansible_j2_vars = AnsibleJ2Vars(
        _templar,
        _globals
    )
    assert ansible_j2_vars[varname] == variable

    _locals = dict()
    _locals.update({
        "available_variables": "another variable"
    })
    _templar.available_variables = _locals
   

# Generated at 2022-06-21 07:56:11.642828
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    my_dict = dict()
    my_dict['foo'] = 'bar'
    my_dict['bar'] = '{{ baz }}'
    my_dict['baz'] = 'quux'

    t = Templar(variables=my_dict)
    ajv = AnsibleJ2Vars(t, {})

    actual = ajv['foo']
    assert actual == 'bar'

    actual = ajv['bar']
    assert actual == 'quux'

    actual = ajv['baz']
    assert actual == 'quux'

    import pytest
    with pytest.raises(AnsibleUndefinedVariable) as e:
        actual = ajv['nope']
    assert to_native(e.value) == 'undefined variable: nope'

# Generated at 2022-06-21 07:56:23.140599
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import pytest

# Generated at 2022-06-21 07:56:29.904690
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    derp = {}
    herp = AnsibleJ2Vars(derp, derp)
    assert herp._templar == derp
    assert herp._globals == derp
    assert herp._locals == {}
    herp = AnsibleJ2Vars(derp, derp, locals={'meow': 2, 'herp': 'derp'})
    assert herp._templar == derp
    assert herp._globals == derp
    assert herp._locals == {'meow': 2, 'herp': 'derp'}

# Generated at 2022-06-21 07:56:35.230248
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Create an instance of class AnsibleJ2Vars
    ansible_j2_vars = AnsibleJ2Vars(templar=None, globals=None, locals=None)

    # Check if the method __contains__ is implemented
    assert callable(getattr(ansible_j2_vars, "__contains__", None))

# Generated at 2022-06-21 07:56:47.214666
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.templar import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'test_variable': HostVars(loader=None, variable_manager=None)})
    # test_globals_dict = {'test_variable_1': 'test_value_1', 'test_variable_2': 'test_value_2'}
    test_globals_dict = {}
    test_locals_dict = {'test_variable_3': 'test_value_3', 'test_variable_4': 'test_value_4'}

# Generated at 2022-06-21 07:56:56.199846
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.parsing.vault as vault
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # setup templar test
    args = dict()
    args['vault_password'] = "secret"
    args['errors'] = []
    context = PlayContext(become=False)
    context._vault_password = args['vault_password']
    loader = DataLoader()
    templar = Templar(loader=loader, variables={'vault_password': 'secret'},
                      vault_password='secret')

    # setup context variables
    globals = dict()
    locals = dict()

    # initialize AnsibleJ2Vars
    ansible_j2vars = AnsibleJ2

# Generated at 2022-06-21 07:57:13.521801
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template import Templar
    x = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': {
            'e': 4,
            'f': 5
            },
        'g': 6
        }
    templar = Templar(loader=None)
    vars = AnsibleJ2Vars(templar, globals={}, locals=x)
    for k in x.keys():
        try:
            assert vars[k] == x[k]
        except KeyError as e:
            print(e)
        try:
            assert vars.__getitem__(k) == x[k]
        except KeyError as e:
            print(e)

# Generated at 2022-06-21 07:57:17.729693
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    self = AnsibleJ2Vars(Templar(), {})
    assert not self.__contains__(None)
    assert not self.__contains__("")


# Generated at 2022-06-21 07:57:20.164054
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Return value of method __getitem__ of class AnsibleJ2Vars
    pass

# Generated at 2022-06-21 07:57:29.807298
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.module_utils._text import to_text
    vars_obj = {'a': 'foo'}
    globals_obj = {'b':'bar'}
    templar = Templar(loader=None, variables=vars_obj)
    vars = AnsibleJ2Vars(templar, globals_obj)
    assert len(vars) == 3
    assert vars['a'] == 'foo'
    assert vars['b'] == 'bar'
    assert list(vars.keys()) == ['a', 'b', 'template']

# Generated at 2022-06-21 07:57:35.796022
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import filter_loader
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    templar._available_variables = {'var': ""}
    templar.environment = filter_loader.environment(play_context=PlayContext())
    var = AnsibleJ2Vars(templar, {})
    assert len(var) == 1

# Generated at 2022-06-21 07:57:48.267217
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import json

    from ansible.errors import AnsibleError
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    try:
        templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)
    except AnsibleError as e:
        raise AnsibleError('Error in templating module: %s' % to_native(e))


# Generated at 2022-06-21 07:57:49.302786
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    raise NotImplementedError()

# Generated at 2022-06-21 07:57:57.457964
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_data = [
        # test_name, expected_result, test_data
        ('normal', 'foo', {'bar': 'foo'}),
        ('complex', 'foo', {'bar': {'baz': 'foo'}}),
        ('complex_list', 'foo', {'bar': ['foo', {'baz': False}]}),
        ('complex_list', False, {'bar': ['foo', {'baz': False}]}),
        ('variable', 'foo', {'bar': '{{ var_1 }}'}),
    ]
    for test_name, expected_result, test_data in test_data:
        templar = Templar(loader=DictDataLoader({'existing_file.j2': ''}))

# Generated at 2022-06-21 07:58:09.488983
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.clean import module_response_deepcopy
    from ansible.template.template import Templar
    my_context = PlayContext(vars=dict(key1='value1', key2='value2'))
    my_templar = Templar(loader=None, variables=my_context)
    my_ansible_j2_vars = AnsibleJ2Vars(templar=my_templar, globals=dict(), locals=dict(l_local_key3='value3'))
    #test value from locals
    assert(my_ansible_j2_vars['local_key3'] == 'value3')
    #test value from context

# Generated at 2022-06-21 07:58:14.247563
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    import pytest

    j2v = AnsibleJ2Vars(Templar(loader=None), globals=None)

    j2v.available_variables = {
        "user": "admin"
    }
    assert "user" in j2v
    assert "password" not in j2v

# Generated at 2022-06-21 07:58:29.320609
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
  pass

# Generated at 2022-06-21 07:58:33.495157
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.plugins.loader import vars_loader
    from ansible.template import Templar

    for _ in AnsibleJ2Vars(Templar(loader=vars_loader), locals=None):
        pass


# Generated at 2022-06-21 07:58:43.858405
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    # Create variable proxy with no locals provided
    variable_proxy = AnsibleJ2Vars(templar, {})
    variable_proxy_new = variable_proxy.add_locals(locals={})
    assert variable_proxy_new == variable_proxy
    variable_proxy_new = variable_proxy.add_locals(locals=None)
    assert variable_proxy_new == variable_proxy

    # Create variable proxy with locals provided
    variable_proxy = AnsibleJ2Vars(templar, {})
    locals = { 'item': 10 }
    variable_proxy_new = variable_proxy.add_locals(locals=locals)
    assert variable

# Generated at 2022-06-21 07:58:54.914661
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    env = dict(vars=dict(a=1, b=2, c=3, d=4, e=5))
    globals = dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8)
    locals = dict(a=1, b=2, c=3, d=4, e=5)
    vars = AnsibleJ2Vars(templar, env, locals=locals)

    assert len(vars) == 5

    vars = AnsibleJ2Vars(templar, globals, locals=locals)

    assert len(vars) == 8


# Generated at 2022-06-21 07:59:06.092880
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    locals = dict(a=5)
    hostvars = HostVars(dict(_hostvars_=True), False)
    available_variables = dict(b=1)
    variable_manager = VariableManager(loader=None)
    variable_manager.get_vars = lambda: available_variables
    variable_manager.get_vars_as_template_error = lambda x: available_variables
    variable_manager.extra_vars = dict(c=17)
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)
    templar._available_variables = available_variables

    proxy = Ansible

# Generated at 2022-06-21 07:59:10.722207
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    test __contains__() in AnsibleJ2Vars class
    '''

    import jinja2
    templar = jinja2.Environment().from_string('ansible_template').globals['vars']
    j2vars_1 = AnsibleJ2Vars(templar, {'test1':'test1'})
    assert 'test1' in j2vars_1
    assert 'test2' not in j2vars_1


# Generated at 2022-06-21 07:59:21.034143
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import sys
    import types
    import unittest

    sys.modules['ansible'] = types.ModuleType('ansible')
    sys.modules['ansible.errors'] = types.ModuleType('ansible.errors')
    sys.modules['ansible.errors'].AnsibleError = AnsibleError

    class TestJ2Vars(unittest.TestCase):
        def test_add_locals(self):
            j2vars = AnsibleJ2Vars(None, None)
            j2vars2 = j2vars.add_locals([{'a': 1}])
            self.assertIsInstance(j2vars, AnsibleJ2Vars)
            self.assertIsInstance(j2vars2, AnsibleJ2Vars)

# Generated at 2022-06-21 07:59:32.209626
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.cli.playbook.play_context import PlayContext
    from ansible.plugins.loader import template_loader

    # create a valid AnsibleJ2Vars object
    #
    # prerequisites:
    # - jinja2>=2.9.4
    # - ansible>=2.8.4
    #
    # in Ansible 2.8.4 and earlier, the _variable_cache was an OrderedDict
    # in Ansible 2.8.5 and later, the _variable_cache is a MappingProxyType
    #
    # If you want to experiment with this code, you may need to install a
    # patched version of ansible. Refer to the README.md file for more details
    _play_context = PlayContext()

# Generated at 2022-06-21 07:59:42.604385
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    templar = Templar()
    hostvars = HostVars(dict(ansible_fqdn='localhost'))
    globals = dict(foo='bar')
    j2vars = AnsibleJ2Vars(templar, globals)
    try:
        print("j2vars['foo']: %s" % j2vars['foo'])
        assert False
    except KeyError:
        pass
    j2vars._templar.available_variables = dict(foo='{{ foo }}')
    assert j2vars['foo'] == 'foo'

# Generated at 2022-06-21 07:59:43.220825
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass

# Generated at 2022-06-21 08:00:16.513407
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    global_vars = dict()
    local_vars = dict()

    vars = AnsibleJ2Vars("", global_vars, local_vars)
    assert vars["key"] == "value"

if __name__ == '__main__':
    import pytest

    pytest.main()

# Generated at 2022-06-21 08:00:26.998725
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    locals = {'x': 'yes'}
    templar = None
    globals = {'y': 'yes'}

    ex = AnsibleJ2Vars(templar, globals, locals)

    assert ex.__contains__('x')
    assert ex.__contains__('y')
    assert ex.__contains__('z') is False
    assert ex.__contains__('foo') is False

    assert list(ex.__iter__()) == ['x', 'y']

    assert ex.__getitem__('x') == 'yes'
    assert ex.__getitem__('y') == 'yes'
    try:
        assert ex.__getitem__('z')
    except KeyError:
        pass

    assert ex.__len__() == 2

# vim: set et fenc=

# Generated at 2022-06-21 08:00:38.762952
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    t = Templar(loader=None)
    t.available_variables = dict(
        ansible_hostname = 'somehost',
        ansible_play_batch = [ "batch1", "batch2" ],
        vars = { 'var1': 'value1', 'var2': 'value2' }
    )
    t.set_available_variables(variables=dict(var1='value1', var2='value2'))
    v = AnsibleJ2Vars(templar=t, globals={}, locals={})


# Generated at 2022-06-21 08:00:47.448329
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import sys
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory, Host, Group
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'webservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args='')),
            ]
        )

    # create the playbook object, based on the play, and (empty) inventory
    play = Play().load(play_source, variable_manager=VariableManager(), loader=None)
    inventory = Inventory(loader=None)
    playbook = Playbook()
    playbook._entries.append(play)

# Generated at 2022-06-21 08:00:58.710699
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars
    import os

    templar = Templar()
    hostvars = HostVars(templar, dict(testing="this works"))
    testvar = dict(testing="this works")
    testvar['unsafe'] = UnsafeProxy(testvar['testing'], is_unsafe=True)

    # this is the typical locals from ansible/playbook/block.py