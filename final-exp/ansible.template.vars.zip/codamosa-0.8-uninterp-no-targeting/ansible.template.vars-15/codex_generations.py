

# Generated at 2022-06-21 07:51:06.153146
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template.safe_eval import safe_eval

    def _assert_value_from_variable_content(variable, templar, value):

        try:
            # If a value is provided then assert that the variable content is templated to yield the provided value
            if value is not None:
                assert value == templar.template(variable)
            # Else assert that the variable content is templated to yield its original value
            else:
                assert variable == templar.template(variable)
        except:
            templated_variable = templar.template(variable)

# Generated at 2022-06-21 07:51:16.489903
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.module_utils.jinja2.utils import TestJinjaVariable
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None)
    proxy = AnsibleJ2Vars(templar=templar, globals={'a': 1})
    assert proxy['a'] is 1
    assert proxy['b'] is None

    templar._available_variables = {'c': TestJinjaVariable('c', 'c', 'c'),
                                    'd': TestJinjaVariable('d', 'd', 'd')}
    assert proxy['c'] == 'cc'
    assert proxy['d'] == 'dd'
    assert proxy['e'] is None


# Generated at 2022-06-21 07:51:27.689326
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.plugins import module_loader
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    module_loader.add_directory('./lib')
    templar_obj = Templar(loader=None)
    locals_1 = {'var': 0}
    j2vars_obj = AnsibleJ2Vars(templar_obj, locals_1)

    assert j2vars_obj['var'] == 0
    assert j2vars_obj['var'] == locals_1['var']

    locals_2 = {'var': 1}
    j2vars_obj_locals = j2vars_obj.add_locals(locals_2)
    assert j2vars_obj_locals['var'] == 1
    assert j2

# Generated at 2022-06-21 07:51:36.209490
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = object()
    globals = dict(globals_value=True)
    locals = dict(locals_value=True)
    ajv = AnsibleJ2Vars(templar, globals, locals)

    assert len(ajv) == len(globals) + len(locals)
    keys = ajv.__iter__()
    assert next(keys) == 'globals_value'
    assert next(keys) == 'locals_value'

# Generated at 2022-06-21 07:51:43.110925
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    from ansible.template import Templar

    templar = Templar(loader=None, variables={'aaa': 1, 'bbb': {'aaa': 2}})
    globals = {'zzz': 1, 'bbb': {'zzz': 2}}

    aj2v = AnsibleJ2Vars(templar, globals, locals={'ccc': 3})
    assert sorted(['aaa', 'bbb', 'ccc', 'zzz']) == sorted(aj2v.__iter__())


# Generated at 2022-06-21 07:51:47.809416
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
     """
     [ansible-project] Test case for method __iter__ of class AnsibleJ2Vars
     """
     j2vars = AnsibleJ2Vars(None, {})
     assert j2vars.__iter__() == []

# Generated at 2022-06-21 07:51:59.105235
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = Templar()
    globals = dict()
    jvars = AnsibleJ2Vars(templar, globals, locals=dict())

    locals = dict()
    locals["v1"] = 10
    locals["v2"] = 20

    # create new AnsibleJ2Vars object with locals
    updated_vars = jvars.add_locals(locals)

    assert len(updated_vars) == len(locals), "the length of the updated_vars object should be equal to the length of locals"
    for key, value in locals.items():
        assert key in updated_vars, "the key '{0}' should be in the updated_vars object".format(key)

# Generated at 2022-06-21 07:52:06.955710
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    from ansible.template.template import Templar
    templar = Templar(loader=loader)
    ansible_j2_vars = AnsibleJ2Vars(templar, {'a': 1}, {'b': 2})

    # Test __iter__
    assert sorted(ansible_j2_vars.__iter__()) == ['a', 'b']


# Generated at 2022-06-21 07:52:07.958397
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass

# Generated at 2022-06-21 07:52:13.747077
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    dict1 = dict(var1='val1')
    dict2 = dict(var2='val2')
    ansj2vars = AnsibleJ2Vars('templar', dict1, dict2)

    assert(ansj2vars['var1'] == 'val1')
    assert(ansj2vars['var2'] == 'val2')


# Generated at 2022-06-21 07:52:28.620200
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    globals = dict({
        'a': 'a',
        'b': AnsibleUnsafeText('b')
    })

    locals = dict({
        'c': 'c',
        'd': AnsibleUnsafeText('d')
    })

    templar = Templar()
    templar.available_variables = dict({
        'e': 'e',
        'f': AnsibleUnsafeText('f')
    })

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    assert ansible_j2_vars['a'] == 'a'
    assert ansible

# Generated at 2022-06-21 07:52:38.399224
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()
    globals = {}
    locals = {}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # available_variables doesn't contain varname, raise KeyError
    test_failed = False
    try:
        j2vars['varname']
    except KeyError:
        test_failed = True
    assert test_failed

    # available_variables contains varname, return value after template
    templar.available_variables = {'varname': 'value'}
    assert j2vars['varname'] == 'value'

    # available_variables contains varname, return value if template failed
    templar.available_variables = {'varname': '{{ value }}'}


# Generated at 2022-06-21 07:52:49.269039
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    locals = dict(hello='world', foo='bar')
    class MockTemplar(object):
        '''
        Templar is the class responsible to store variables used in templates (available_variables).
        It is created in constructor of AnsibleJ2Vars()
        '''
        def __init__(self, variables):
            self.available_variables = variables

    class MockAnsibleJ2Vars(AnsibleJ2Vars):
        '''
        To test add_locals(), we need to mock AnsibleJ2Vars, and override constructor.
        '''
        def __init__(self, locals):
            '''
            For testing purpose, we need to pass locals only to the class and should not be
            templating it as done in original constructor.
            '''

# Generated at 2022-06-21 07:52:58.177409
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import random
    from jinja2.utils import missing

    def random_fill_dict(d):
        d['a'] = random.random()
        d['b'] = random.random()
        d['c'] = random.random()
        d['d'] = random.random()

    templar = None
    globals = {}
    locals = {}

    random_fill_dict(globals)
    random_fill_dict(locals)

    aj2v = AnsibleJ2Vars(templar, globals, locals)
    for k in aj2v:
        assert k in ['a', 'b', 'c', 'd']



# Generated at 2022-06-21 07:53:08.515994
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class Dummy_Templar:
        def __init__(self, available_variables):
            self.available_variables = available_variables
        def template(self, variable):
            return variable
    v = {"x": "xval", "y": "yval"}
    t = Dummy_Templar(v)
    varproxy = AnsibleJ2Vars(t, {"z": "zval"})
    assert varproxy["x"] == "xval"
    assert varproxy["y"] == "yval"
    assert varproxy["z"] == "zval"

    l = {"y": "yvalx", "z": "zvalx"}
    varproxy_l = varproxy.add_locals(l)
    assert varproxy_l["x"] == "xval"
    assert varproxy_

# Generated at 2022-06-21 07:53:21.043308
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():  
    import os
    import tempfile
    import ansible.plugins.loader as plugin_loader
    from ansible.template import Templar

    mock_loader = plugin_loader.module_loader.get('jsonfile')

    (fd, src_file) = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-21 07:53:25.495142
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar

    from units.mock.loader import DictDataLoader

    templar = Templar(None, loader=DictDataLoader({}))

    ansible_j2_vars = AnsibleJ2Vars(templar, globals={})

    # empty available_variables
    ansible_j2_vars._templar.available_variables = {}
    assert 'test' not in ansible_j2_vars

    # available_variables contains test
    ansible_j2_vars._templar.available_variables = {'test': 'test'}
    assert 'test' in ansible_j2_vars

    # empty _locals
    ansible_j2_vars._locals = {}
    assert 'test' not in ansible_j2

# Generated at 2022-06-21 07:53:38.071606
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VarsModule
    from ansible.module_utils.six import PY3

    # testdata:
    test_vars_known = {
        'test_variable1':'test_value1',
        'test_variable2':'test_value2',
        'test_variable3':'test_value3',
        }
    test_globals_known = {
        'known_global1':'known_value1',
        'known_global2':'known_value2',
        'known_global3':'known_value3',
        }

# Generated at 2022-06-21 07:53:48.072445
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    # Set up our objects for testing
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=False)
    globals = {
        'omg': 'lol'
    }
    locals = None

    # Check it works

# Generated at 2022-06-21 07:53:49.141647
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert False, "unimplemented"


# Generated at 2022-06-21 07:54:05.862610
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    templar = Templar(None, {}, None)
    globvars = {"test_global_var": "global"}
    locvars = {"test_local_var": "local"}
    ajv = AnsibleJ2Vars(templar, globvars, locvars)

    # 1. test_AnsibleJ2Vars___getitem___1
    # 1.1. test_AnsibleJ2Vars___getitem___1_vars
    avars = {"test_var1": "value1", "test_var2": "value2"}
    templar._available_variables = avars

    # 1.1.1. test_AnsibleJ2Vars___getitem__

# Generated at 2022-06-21 07:54:14.109818
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar

    ajv = AnsibleJ2Vars(Templar(), {'a':1}, {'b':2})
    assert len(ajv) == 2
    assert ajv['a'] == 1
    assert ajv['b'] == 2
    assert 'b' in ajv
    assert 'a' not in ajv

    ajv = AnsibleJ2Vars(Templar(), dict())
    assert len(ajv) == 0
    try:
        ajv['b']
        raise AssertionError('Should have thrown KeyError')
    except KeyError:
        pass
    assert 'a' not in ajv

# Generated at 2022-06-21 07:54:25.093476
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=True, play_context=context)

    test_variables = AnsibleJ2Vars(templar, globals=dict(a=2, b=3))
    assert 'a' in test_variables
    assert test_variables['a'] == 2
    assert 'b' in test_variables
    assert test_variables['b'] == 3

# Generated at 2022-06-21 07:54:35.075421
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=play_context)

    globals = {}
    var_proxy = AnsibleJ2Vars(templar, globals)

    # Check that 'vars' class members are defined
    assert hasattr(var_proxy, '_templar')
   

# Generated at 2022-06-21 07:54:38.573244
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar()
    for param_locals in [{}, {'testing': 'foo'}]:
        vars = AnsibleJ2Vars(templar, globals={'testing': 'bar'}, locals=param_locals)
        vars_with_locals = vars.add_locals({'test': 'some_value'})
        assert vars_with_locals._locals == {'test': 'some_value'}

# Generated at 2022-06-21 07:54:50.257478
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # test with empty attributes
    data = AnsibleJ2Vars(None, None, None)
    assert len(data) == 0
    assert data.__contains__(None) is False
    assert data.__getitem__(None) is KeyError

    # test with empty attributes
    templar = Templar(None, None, None, None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'b': 4, 'd': 5}
    data = AnsibleJ2Vars(templar, globals, locals)
    assert len(data) == 4
    assert data.__contains__('b')
    assert data.__getitem__('b') == 4
    assert len(data._globals) == 3

# Generated at 2022-06-21 07:54:59.594256
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.template.safe_eval
    templar = ansible.template.safe_eval.AnsibleJ2TemplateLite(loader=None)

# Generated at 2022-06-21 07:55:11.736001
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import safe_eval
    from ansible.template.template import Templar

    jinja_vars = {'foo': 'bar', 'bar': 'baz'}
    globals = {'range1': range(10)}

    templar = Templar(loader=None, variables={})
    templar.set_available_variables(jinja_vars)

    aj2v = AnsibleJ2Vars(templar, globals)
    assert 'foo' in aj2v
    assert 'bar' in aj2v
    assert 'baz' not in aj2v
    assert 'range1' in aj2v

    locals = {'baz': 'boo'}

    aj2v_with_locals = aj2v.add_loc

# Generated at 2022-06-21 07:55:23.614094
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    j_vars = AnsibleJ2Vars(
        Templar(
            loader=None,
            variables=VariableManager(),
            shared_loader_obj=None
        ),
        {}
    )

    # KeyError
    try:
        j_vars['inexistent_variable']
    except KeyError as e:
        assert str(e) == 'undefined variable: inexistent_variable'

    # HostVars
    assert isinstance(j_vars['hostvars'], HostVars)

    # Ansible

# Generated at 2022-06-21 07:55:33.180135
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    j2vars = AnsibleJ2Vars(Templar(loader=None), dict())
    assert 'foobar' not in j2vars
    assert 'ansible_play_hosts' not in j2vars
    j2vars = AnsibleJ2Vars(Templar(loader=None, variables={'ansible_play_hosts': ['a', 'b', 'c']}), dict())
    assert 'foobar' not in j2vars
    assert 'ansible_play_hosts' in j2vars


# Generated at 2022-06-21 07:56:05.308646
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    data_loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_host_variable('test', HostVars({'var1': 1, 'var2': 2}))
    variable_manager.set_host_variable('test', HostVars({'var3': 3, 'var4': 4}))
    variable_manager.set_nonpersistent_facts(dict(var5=5, var6=6))
    templar = Templar(loader=data_loader, variables=variable_manager)

# Generated at 2022-06-21 07:56:17.926685
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # All cases
    def __len__(self):
        keys = set()
        keys.update(self._templar.available_variables, self._locals, self._globals)
        return len(keys)

    # All cases
    def __getitem__(self, varname):
        if varname in self._locals:
            return self._locals[varname]
        if varname in self._templar.available_variables:
            variable = self._templar.available_variables[varname]
        elif varname in self._globals:
            return self._globals[varname]
        else:
            raise KeyError("undefined variable: %s" % varname)

        # HostVars is special, return it as-is, as is the special variable


# Generated at 2022-06-21 07:56:25.297356
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    var1 = 'TESTVAR1'
    var2 = 'TESTVAR2'
    var3 = 'TESTVAR3'
    class Templar():
        available_variables = {var1: '1', var2: '2'}
    globals = {var3: '3'}
    locals = {var1: '4'}
    x = AnsibleJ2Vars(Templar(), globals, locals=locals)
    assert sorted(x) == sorted([var1, var2, var3])

# Generated at 2022-06-21 07:56:33.405801
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import os
    import sys
    import json
    import tempfile
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.plugins.loader import add_all_plugin_dirs

    # AnsibleJ2Vars not supported in python < 2.6
    if (sys.version_info[0] == 2 and sys.version_info[1] < 6):
        raise unittest.SkipTest("AnsibleJ2Vars not supported in python < 2.6")

    add

# Generated at 2022-06-21 07:56:45.953198
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    basic constructor test
    '''
    gvar = "globals_value"
    globs = { "_ansible_globals": gvar }
    lvars = { "_ansible_locals": "locals_value" }
    tvar = "templar_value"
    tvars = { "_ansible_templar_variable": tvar }
    templar = Templar(tvars)
    try:
        AnsibleJ2Vars(templar, "BadGlobals")
    except TypeError:
        pass
    try:
        AnsibleJ2Vars(templar, globs, "BadLocals")
    except TypeError:
        pass

# Generated at 2022-06-21 07:56:48.202811
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ansiblej2vars = AnsibleJ2Vars(None, None)
    assert ansiblej2vars is not None


# Generated at 2022-06-21 07:56:56.727214
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import safe_eval
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext
    ctx = PlayContext()
    templar = ctx.templar
    globals = {'vars': {'var1': 'foo', 'var2': 'bar'}}
    locals = {'foo': 'bar', 'l_var2': 'l_bar'}
    ans_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Check __getitem__ when there is no locals
    ans_j2_vars._locals = {}
    assert ans_j2_vars['var2'] == 'bar'
    assert ans_j2_vars

# Generated at 2022-06-21 07:57:08.689612
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class TestVars(object):
        def test(self):
            return 'test'
    templar = TestVars()
    locals = dict(foo='bar', baz='quux')
    globals = dict(bar='baz', quux='foo')

    var = AnsibleJ2Vars(templar, globals, locals=locals)

    assert 'test' == var['test']
    assert 'bar' == var['foo']
    assert 'quux' == var['baz']
    assert 'baz' == var['bar']
    assert 'foo' == var['quux']

    assert len(var) == 6
    assert ['foo', 'bar', 'quux', 'baz', 'test'] == sorted(list(var))

# Generated at 2022-06-21 07:57:18.130900
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    try:
        x = safe_eval("[1, 2, 3]")
    except AnsibleUndefinedVariable:
        assert False

    try:
        x = safe_eval("{1, 2, 3}")
    except AnsibleUndefinedVariable:
        assert False

    templar = Templar(loader=None, variables={'a': 1, 'b': 2, 'c': 3})
    v = AnsibleJ2Vars(templar, globals={'d': 4, 'e': 5, 'f': 6})
    assert len(v) is 6

    templar2 = Templar(loader=None, variables={'a': 1, 'b': 2})

# Generated at 2022-06-21 07:57:30.614967
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    assert AnsibleJ2Vars(templar, globals={}).add_locals({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert AnsibleJ2Vars(templar, globals={'a': 2}).add_locals({'b': 1, 'c': 2}) == {'a': 2, 'b': 1, 'c': 2}
    assert AnsibleJ2Vars(templar, globals={'a': 2}).add_locals({'a': 1, 'c': 2}) == {'a': 1, 'c': 2}
    # locals still contain 'var' from the globals

# Generated at 2022-06-21 07:58:07.636603
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.playbook.templar import Templar
    global_vars = {'global_a':'global_a_value'}
    templar = Templar(loader=None, variables=global_vars)
    j2vars = AnsibleJ2Vars(templar, global_vars)

    locals1 = {'locals_a':'locals_a_value'}
    j2vars1 = j2vars.add_locals(locals1)
    assert isinstance(j2vars1, AnsibleJ2Vars)
    assert j2vars1._locals == {'locals_a':'locals_a_value'}
    assert j2vars1._globals == {'global_a':'global_a_value'}


# Generated at 2022-06-21 07:58:18.469350
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    When a variable is used in a template it gets dereferenced by AnsibleJ2Vars.
    In the dereference process it loops over the scope of the variable and returns
    the value if found.
    """
    templar = Templar(loader=None, shared_loader_obj=None)
    # Intentionally-empty dicts
    globals = dict()
    locals = dict()
    # Initialize the AnsibleJ2Vars with empty dicts
    jvars = AnsibleJ2Vars(templar, globals, locals)
    # Available variables in check_vars_count.yml
    av_vars_count = 7
    # The dict has 5 keys on the first level, each of them with two
    # keys on the second level. All levels combined give 7 variables
    # that AnsibleJ

# Generated at 2022-06-21 07:58:20.773710
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class Templar(object):
        available_variables = {'x': 'blah'}

    a = AnsibleJ2Vars(Templar(), {})

    assert len(a) == 1

# Generated at 2022-06-21 07:58:31.727561
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    ansible_j2_vars = AnsibleJ2Vars(None, {"a":1}, {"b":2})
    assert len(ansible_j2_vars) == 3

    ansible_j2_vars = AnsibleJ2Vars(None, {"a":1, "b":2}, {"c":3})
    assert len(ansible_j2_vars) == 4
    assert list(ansible_j2_vars) == ["a", "b", "c"]

    ansible_j2_vars = AnsibleJ2Vars(None, {"b":1}, {"a":2, "c":3})
    assert len(ansible_j2_vars) == 4
    assert list(ansible_j2_vars) == ["a", "c", "b"]

# Generated at 2022-06-21 07:58:35.559710
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = None
    globals = {}
    locals = {'foo':'bar'}

    instance = AnsibleJ2Vars(templar, globals, locals)
    assert(instance['foo'] == 'bar')


# Generated at 2022-06-21 07:58:45.233183
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var
    import jinja2

    globals_dict={'sample_val': 'sample value'}
    locals_dict={'locals_val': 'locals value'}
    templar = Templar(host_vars=wrap_var([1, 2, 3, 4]))
    jinja_vars = AnsibleJ2Vars(templar, globals_dict, locals_dict)
    # test varname in jinja_vars
    assert 'sample_val' in jinja_vars
    assert 'locals_val' in jinja_vars
    assert 'hostvars' in jinja_vars
    assert 'novalue_val' not in jinja_vars

# Generated at 2022-06-21 07:58:56.884697
# Unit test for method __len__ of class AnsibleJ2Vars

# Generated at 2022-06-21 07:58:58.339707
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # TODO: implement this unit test!
    pass


# Generated at 2022-06-21 07:59:08.839390
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host

    variables = dict(
        a='a',
        b='b',
    )
    host = Host(name="127.0.0.1")
    j2vars = AnsibleJ2Vars(templar=Templar(), globals=variables, locals=dict(c='c'))
    j2vars = j2vars.add_locals(dict(d='d'))
    j2vars = j2vars.add_locals(dict(c='c2'))

    assert(sorted(j2vars.keys()) == ['a', 'b', 'c', 'd'])

# Generated at 2022-06-21 07:59:13.997573
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    var1 = {
        "key": "value",
        "key2": "value2"
    }
    var2 = AnsibleJ2Vars(var1, var1)
    for k in var1.keys():
        assert var2[k] == var1[k]

    var3 = AnsibleJ2Vars(var1, var1)
    for k in var1.keys():
        assert var3[k] == var1[k]

# Generated at 2022-06-21 08:00:13.124445
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Arrange
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    test_input_unknown_variable = 'unknown_variable'

    # Act
    ajv = AnsibleJ2Vars(templar, globals, locals)

    # Assert
    try:
        ajv.__getitem__(test_input_unknown_variable)
        assert False
    except KeyError as err:
        assert err.args[0] == 'undefined variable: unknown_variable'
    except:
        assert False



# Generated at 2022-06-21 08:00:13.769938
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert 1

# Generated at 2022-06-21 08:00:18.505489
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    t = jinja2.Environment(undefined=jinja2.StrictUndefined)
    g=dict()
    l=dict()
    j2 = AnsibleJ2Vars(t, g, l)
    assert j2.__iter__() is None


# Generated at 2022-06-21 08:00:26.344357
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    class TestTemplar(Templar):
        def __init__(self, variables):
            self.available_variables = variables

    t = TestTemplar({'test_variable': 'test_value'})
    ajv = AnsibleJ2Vars(t, {}, locals={'test_local': 'test_local_value'})
    assert('test_local' in ajv)
    assert('test_variable' in ajv)
    assert('test_missing' not in ajv)


# Generated at 2022-06-21 08:00:35.349832
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.hostvars import HostVars
    try:
        from unittest import mock
    except ImportError:
        import mock
    import jinja2
    from jinja2.environment import Environment
    from jinja2.loaders import DictLoader

    templar = mock.MagicMock()
    templar.available_variables = {'foobar': 3}

    j2vars = AnsibleJ2Vars(templar, globals={'foobar': 'baz'}, locals={'foobar': 'baz'})

    assert(len(j2vars) == 1)



# Generated at 2022-06-21 08:00:45.815527
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar

    globals = {'a': 'a', 'b': 'b'}
    locals = {'c': 'c'}
    templar = Templar(None, loader=None, variables=dict())
    aj2v = AnsibleJ2Vars(templar, globals, locals=locals)

    assert isinstance(aj2v, Mapping)
    assert 'a' in aj2v
    assert 'b' in aj2v
    assert 'c' in aj2v
    assert 'd' not in aj2v

    assert aj2v['a'] == 'a'
    assert aj2v['b'] == 'b'

# Generated at 2022-06-21 08:00:57.274987
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars
    templar = Templar(loader=None)
    globals = {"g1": "v1"}
    locals  = {"l3": "v3"}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals=locals)

    # add some vars to templar
    templar.set_available_variables({
        "va_0": "va_v0",
        "va_1": "va_v1",
        "va_2": "va_v2",
        "va_3": "va_v3",
    })

    # test empty
    assert ansible_j2_vars.__contains__("") is False

   