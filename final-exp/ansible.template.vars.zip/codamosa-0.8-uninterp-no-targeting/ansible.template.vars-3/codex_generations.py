

# Generated at 2022-06-21 07:50:59.523537
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class Templar():
        def __init__(self):
            self.available_variables = {'foo': 'bar'}

    templar = Templar()
    ansible_j2_vars = AnsibleJ2Vars(templar, {}, {})
    assert 'foo' in ansible_j2_vars
    assert 'bar' not in ansible_j2_vars


# Generated at 2022-06-21 07:51:10.423481
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.templating import Templar
    class FakeAnsibleModule:
        def __init__(self, debug=False):
            self.debug = True
        def fail_json(self, msg):
            raise Exception(msg)

    t = Templar(loader=None, variables={})
    t.set_available_variables(FakeAnsibleModule())
    proxy = AnsibleJ2Vars(t, {}, locals={'l_foo': 'foo value'})
    assert proxy['foo'] == 'foo value'
    proxy2 = proxy.add_locals({'l_bar': 'bar value'})
    assert proxy2['bar'] == 'bar value'
    assert proxy['bar'] != 'bar value'

# Generated at 2022-06-21 07:51:18.637080
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    from ansible.playbook.play_context import PlayContext
    class MockTemplar(object):
        def __init__(self):
            self.available_variables = dict(a=1)

        def template(self, variable):
            return variable

    locals = dict(b=2, l_m=3)
    globals = dict(g=4)

    vars = AnsibleJ2Vars(MockTemplar(), globals, locals)
    assert vars.add_locals(None) == vars
    assert vars.add_locals(dict()) == vars

    new_locals = dict(l_n=5)
    new_vars = vars.add_locals(new_locals)

    assert isinstance(new_vars, AnsibleJ2Vars)

# Generated at 2022-06-21 07:51:26.234407
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    from ansible.vars.hostvars import HostVars
    templar = jinja2.Environment()
    # test item in self._locals
    vars1 = AnsibleJ2Vars(templar, {}, locals={ 'a': '1' })
    vars2 = vars1.add_locals({ 'b': '2' })
    assert vars2['a'] == '1'
    assert vars2['b'] == '2'
    # test item in self._templar.available_variables
    vars1 = AnsibleJ2Vars(templar, {}, locals={ 'c': '3' })
    vars2 = vars1.add_locals({ 'd': '4' })

# Generated at 2022-06-21 07:51:26.992712
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    assert True

# Generated at 2022-06-21 07:51:39.814066
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # a variable is defined in a group and host variable
    locals = {'var_to_template': '{{ var_from_host_var }}'}

    templar = Templar(loader=DataLoader())
    templar._available_variables = {'var_from_host_var': 'value from host var'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals=None, locals=locals)
    ansible_j2_vars = ansible_j2_vars.add_locals({'var_to_template': '{{ var_from_group_var }}'})

    # the host variable should override the group one
    assert ansible_j2_vars['var_to_template'] == 'value from host var'



# Generated at 2022-06-21 07:51:48.013947
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Note: This test currently only verifies that AnsibleJ2Vars can be instantiated.
    # It is not testing any functionality at this time.
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import sys

    # Create a fake host object
    class Host:
        def __init__(self, name):
            self.name = name

    # Create a fake inventory object, which is required for PlayContext
    class Inventory:
        def __init__(self, host):
            self.hosts = [host]

    # Create a play_context object
    mock_var_manager = {
        'all': {},
        'hostvars': {
            'host1': {}
        },
        'omit_token': False
    }
    play_context = PlayContext()

# Generated at 2022-06-21 07:51:59.209385
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    Unit test for constructor of class AnsibleJ2Vars
    '''
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    host = Host(name='test_host')
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host=host, varname='test_var', value='test_value')
    templar = Templar(loader=None, variables=variable_manager)

    test_obj = AnsibleJ2Vars(templar, globals={'test_global': 'test_global_value'})

    assert 'test_global' in test_obj
    assert test_obj['test_global'] == 'test_global_value'

    assert 'test_var' in test_obj


# Generated at 2022-06-21 07:52:07.054183
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = "templar_test"
    globals = {"a": "A"}
    locals = {"b": "B"}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars._templar == templar
    assert ansible_j2_vars._globals == globals
    assert ansible_j2_vars._locals == locals

# Generated at 2022-06-21 07:52:16.537356
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=None)

    combined_vars = combine_vars(
        {},
        dict(hostvars={'foo': 'bar'}),
        dict(vars={'foo': 'BAR'}),
        dict(delegate_vars={'foo': 'baz'}),
    )

    assert AnsibleJ2Vars(templar, combined_vars)

    AnsibleJ2Vars(templar, combined_vars, locals=dict(foo=None))


# Generated at 2022-06-21 07:52:31.199928
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    host = Host(name="testhost")
    host.vars = dict()
    templar = Templar(variables=VariableManager(loader=DataLoader()),
                      shared_loader_obj=None,
                      host=host)
    globals_ = dict()
    vars_ = AnsibleJ2Vars(templar, globals_)
    # test 1
    assert len(vars_) == 0
    # test 2
    globals_["var1"] = "value"

# Generated at 2022-06-21 07:52:39.410067
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    from ansible.template.safe_eval import unsafe_eval

    fake_loader = DataLoader()
    test_vars = VariableManager()
    templar = Templar(loader=fake_loader, variables=test_vars)

    locals = {}
    globals_ = {}
    template_vars = AnsibleJ2Vars(templar, globals_, locals)

    # locals, globals_ and templar.available_variables are empty

# Generated at 2022-06-21 07:52:50.501856
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())
    # test locals is None
    ajv = AnsibleJ2Vars(templar, {})
    assert ajv.add_locals(locals=None) == ajv
    # test locals is {'a': 123}
    ajv = AnsibleJ2Vars(templar, {})
    ajv.add_locals({'a': 123})
    assert ajv['a'] == 123
    # test locals is {'a': {'b': 234}}
    a

# Generated at 2022-06-21 07:53:00.199931
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import pytest
    try:
        import __main__ as main
    except ImportError:
        import sys
        import os
        __file__ = sys.argv[0]
        main = main = globals()
        main.__file__ = os.path.abspath(__file__)
        main.__package__ = None
        main.__name__ = os.path.splitext(os.path.basename(__file__))[0]
        main.__loader__ = None
    try:
        from ansible import constants
    except ImportError:
        constants = None
    try:
        from ansible.errors import AnsibleError
    except ImportError:
        AnsibleError = None

# Generated at 2022-06-21 07:53:11.856889
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # noinspection PyUnresolvedReferences
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar

    assert AnsibleJ2Vars.__name__ == 'AnsibleJ2Vars'

    # noinspection PyMissingConstructor
    class TestTemplar(Templar):
        def __init__(self):
            pass
        # noinspection PyMethodMayBeStatic
        def available_variables(self):
            return dict()
        # noinspection PyMethodMayBeStatic
        def template(self, variable):
            return variable

    test_globals = dict()
    test_locals = dict()
    test_vars = AnsibleJ2Vars(TestTemplar(), test_globals, locals=test_locals)
    assert test_vars.__

# Generated at 2022-06-21 07:53:21.543266
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar=templar,
                           globals={},
                           locals={"key1": "VAL1",
                                   "key2": "VAL2"})
    j2vars2 = j2vars.add_locals(locals={"key3": "VAL3"})
    assert(j2vars2["key1"] == "VAL1")
    assert(j2vars2["key2"] == "VAL2")
    assert(j2vars2["key3"] == "VAL3")

# Generated at 2022-06-21 07:53:33.631559
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import unittest
    from ansible.template import Templar

    # Configure a Mock Template class with a fake templar
    class MockAnsibleJ2Vars(AnsibleJ2Vars):
        def __init__(self):
            self._locals = { 'a':1, 'b':2 }
            self._globals = { 'a':3, 'b':4, 'c':5 }
            self._templar = 2
    # Configure a Mock Template class
    class MockTemplate():
        def __init__(self, template, vars):
            self.template = template
            self.vars = vars
        def __repr__(self):
            return '<MockTemplate %s %s>' % (self.template, self.vars)


# Generated at 2022-06-21 07:53:38.076489
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = jinja2.Environment()
    vars = AnsibleJ2Vars(templar, {})
    assert 'test' not in vars
    vars._templar.available_variables['test'] = 'test'
    assert 'test' in vars

# Generated at 2022-06-21 07:53:48.072716
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import mock
    import __builtin__

    templar = mock.MagicMock()
    globals = {'some_global' : 'val1'}
    locals = {'some_local' : 'val2'}

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    templar.available_variables = {'some_available_variable': 'val3'}

    assert 'some_global' in ansible_j2_vars
    assert 'some_local' in ansible_j2_vars
    assert 'some_available_variable' in ansible_j2_vars
    assert 'some_non_existent_variable' not in ansible_j2_vars


# Generated at 2022-06-21 07:53:58.412617
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from collections import namedtuple
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    # Setup mock Templar
    mock_vars = {
        'hostvars': HostVars(dict()),
        'a_non_mapping': namedtuple('mock', ['field'])(),
        'a_mapping': {'field': 'value'},
        'a_list': ['value1', 'value2'],
        'a_string': 'value',
        'a_number': 42
    }
    mock_vars_copy = dict(mock_vars)
    mock_templar = Templar(fail_on_undefined=True, variables=mock_vars)

# Generated at 2022-06-21 07:54:06.113150
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = None
    globals = {'g1' : 'value1'}
    locals = {'l1' : 'value2'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert len(vars) == 2


# Generated at 2022-06-21 07:54:13.390876
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'hello': 'world'})
    j2vars = AnsibleJ2Vars(templar, {'a': 1, 'b': 2})
    assert j2vars['hello'] == 'world'
    assert j2vars['a'] == 1
    assert j2vars['b'] == 2
    assert isinstance(j2vars['a'], AnsibleUnsafeText)


# Generated at 2022-06-21 07:54:22.412222
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class Templar:
        available_variables = {
            'var1': True,
            'var2': True,
            'var3': True,
            'var4': True,
            'var5': True,
        }

    globals = {'glo1': True, 'glo2': True, 'glo3': True}
    locals = {'var3': True, 'var4': True, 'var5': True}
    instance = AnsibleJ2Vars(Templar(), globals, locals=locals)

# Generated at 2022-06-21 07:54:33.068453
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    #ansible 2.3
    class AnsibleModule(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None, required_one_of=None, add_file_common_args=False,
                     supports_check_mode=False, required_if=None):
            self.params = {}
            self.tags = []

    #ansible 2.4

# Generated at 2022-06-21 07:54:41.936654
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
  from ansible.utils.vars import combine_vars
  from ansible.template import Templar
  from ansible.template.safe_eval import safe_eval
  from ansible.playbook.play_context import PlayContext
  from ansible.inventory.host import Host

  context = {
    'play_hosts': ['127.0.0.1'],
    'vars': {
      'inventory_hostname': '127.0.0.1',
      'inventory_hostname_short': '127.0.0.1',
    },
    'variable_manager': {},
    'loader': None,
    '_variable_manager': '',
    '_hostvars': {},
    '_host': Host(name='127.0.0.1'),
    '_play': '',
  }


# Generated at 2022-06-21 07:54:54.264455
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os
    import tempfile
    import ansible.template
    import ansible.vars.hostvars

    class TestTemplar(ansible.template.Templar):
        def __init__(self, variables):
            self.available_variables = variables


# Generated at 2022-06-21 07:55:05.379254
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from six import StringIO
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.errors import AnsibleUndefinedVariable

    class Dummy(object):
        pass

# Generated at 2022-06-21 07:55:17.463273
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.base import Base
    import ansible.template.safe_eval as safe_eval
    import os
    import jinja2
    m1 = { "k1": "v1", "k2": "v2" }
    m2 = { "k1": "v1", "k2": "v2", "k3": "v3" }
    a1 = Attribute(m1)
    a2 = Attribute(m2)
    b1 = Base(a1)
    b2 = Base(a2)
    t1 = AnsibleJ2Vars(b1, safe_eval.get_context())
    t2 = AnsibleJ2Vars(b2, safe_eval.get_context())

# Generated at 2022-06-21 07:55:24.275236
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass


# Generated at 2022-06-21 07:55:35.777113
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import safe_eval
    from ansible.plugins.loader import plugin_loader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.module_utils.common._collections_compat import MutableSequence

    templar = Templar(loader=None, variables={
        'x': AnsibleUnicode(u'1'),
        'y': AnsibleUnicode(u'2'),
        'z': AnsibleUnicode(u'3'),
    })


# Generated at 2022-06-21 07:55:44.721203
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.templar import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    AnsibleJ2Vars(templar, globals, locals=locals)



# Generated at 2022-06-21 07:55:50.209521
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = object()
    globals = dict(a=1, b=2)
    locals = dict(c=3, d=4)
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars['a'] == 1
    assert j2vars['b'] == 2
    assert j2vars['c'] == 3
    assert j2vars['d'] == 4

    locals2 = dict(e=5, f=6)
    j2vars2 = j2vars.add_locals(locals2)
    assert j2vars2['a'] == 1
    assert j2vars2['b'] == 2
    assert j2vars2['c'] == 3
    assert j2vars2['d'] == 4

# Generated at 2022-06-21 07:56:02.027039
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from jinja2.environment import Environment
    from jinja2.loaders import DictLoader
    from jinja2.meta import find_undeclared_variables
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    test_globals = {'jinja2_builtins': 'present'}
    test_data = {'first': '1st', 'second': '2nd', 'third': '3rd'}
    test_vars = {'first': '1st', 'second': test_data, 'third': '3rd'}
    test_env_vars = {'env_var': 'present'}

    # initialize jinja2 environment

# Generated at 2022-06-21 07:56:13.814146
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.hostvars import HostVars
    my_vars = {'name': 'TEST'}
    my_globals = {'g_name': 'TEST'}
    my_locals = {'view': 'TEST'}
    my_hostvars = HostVars(my_vars)
    my_hostvars_unsafe = HostVars(my_vars, unsafe=True)
    from ansible.template import Templar
    my_templar = Templar(loader=None)
    my_templar.available_variables = my_vars

    my_AnsibleJ2Vars = AnsibleJ2Vars(my_templar, my_globals, my_locals)

    assert 'name' in my_AnsibleJ2Vars

# Generated at 2022-06-21 07:56:19.511034
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    Tests for AnsibleJ2Vars.__len__()
    '''
    test_ansible_j2_vars_obj1 = AnsibleJ2Vars(0, {'module_name': 'test_module'})
    assert len(test_ansible_j2_vars_obj1) == 1


# Generated at 2022-06-21 07:56:29.206212
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import pytest
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    class MockAnsibleJ2Vars(AnsibleJ2Vars):

        def __getitem__(self, varname):
            if varname == 'vars':
                return {}

            return AnsibleJ2Vars.__getitem__(self, varname)

    #-----
    # Basic test
    #-----

    locals_ = {
        'l_a': 'test',
        'l_b': ['test1', 'test2']
    }

    j2vars = MockAnsibleJ2Vars(Templar(), {}, locals=locals_)
    assert j2vars['a'] == 'test'

# Generated at 2022-06-21 07:56:41.400010
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # Test the AnsibleJ2Vars constructor
    #
    # The call to the AnsibleJ2Vars constructor will raise AnsibleAssertionError
    # if the constructor fails

    # Create a dictionary of variables with a single element named key1 with a value of value1
    dict_of_vars = dict(key1="value1")

    # Create an instance of the AnsibleJ2Vars class
    from ansible.template import Templar
    from ansible.inventory.host import Host
    templar = Templar(loader=None, variables=dict_of_vars)
    host = Host(name="localhost")
    ansible_vars = AnsibleJ2Vars(templar=templar, globals=dict_of_vars, locals=dict_of_vars)

    # The call to the AnsibleJ

# Generated at 2022-06-21 07:56:52.262223
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    t = Templar(loader=None, variables={}, shared_loader_obj=None)
    v = AnsibleJ2Vars(t, {}, locals={})
    assert ('a' in v) == False
    v = AnsibleJ2Vars(t, {'a': 'b'}, locals={})
    assert ('a' in v) == True
    assert ('b' in v) == False
    v = AnsibleJ2Vars(t, {'a': 'b'}, locals={'c': 'd'})
    assert ('a' in v) == True
    assert ('b' in v) == False
    assert ('c' in v) == True
    assert ('d' in v) == False

# Generated at 2022-06-21 07:56:58.634418
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.injector import inject_vars

    variable_manager = DummyVariableManager()
    variable_manager_get_vars_return = {'hostvars': {}, 'group_names': ['ungrouped'],
                                        'groups': {'all': {'hosts': [], 'vars': []}, 'ungrouped': {'hosts': [], 'vars': []}}}
    variable_manager_get_vars_return['groups']['all']['hosts'] = ['test_AnsibleJ2Vars']
    variable_manager_get_vars_return['groups']['ungrouped']['hosts'] = ['test_AnsibleJ2Vars']

# Generated at 2022-06-21 07:57:10.499131
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar()

    # Create a fake set of variables
    all_vars = {}
    all_vars["test"] = templar.template("{{ foo }}")
    all_vars["test2"] = "{{ foo }}"
    all_vars["test3"] = AnsibleUnsafeText("{{ foo }}")

    # Create a fake set of locals
    locals = {}
    locals["foo"] = templar.template("bar")
    locals["baz"] = templar.template("quz")

    # Create an AnsibleJ2Vars object
    j2vars = AnsibleJ2Vars(templar, locals, locals)

    # Get the updated locals
    updated

# Generated at 2022-06-21 07:57:26.674283
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import json
    import jinja2
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_globals({
        "a": "global var"
    })

    varlist = {"b": "local var", "l_c": "local var", "context": "local var"}
    templar = Templar(loader=None, variables=varlist, shared_loader_obj=None,
                      variable_manager=variable_manager,
                      all_vars=varlist,
                      fail_on_undefined=True)

# Generated at 2022-06-21 07:57:36.976086
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import safe_eval
    from ansible.template.templar import Templar
    templar = Templar(loader=None, variables={}, shared_loader_obj=None)

    # Use safe_eval to construct a valid AnsibleJ2Vars object.
    # Unfortunately, a full-blown test setup is not possible without
    # some magic, as AnsibleJ2Vars depends on protected members of Ansible which
    # can only be accessed safely by Ansible itself.
    # The way to avoid is to use sate_eval to simulate what Ansible does.
    #
    # Here is how Ansible does it:
    #   self._variable_manager.set_templar(self._templar)
    #   self._templar.set_available_variables(self._variable_manager.get

# Generated at 2022-06-21 07:57:46.615848
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # The Templar class is not available in the global namespace when
    # this unit test is invoked. So we have to do some magic to get
    # an instance of that class:
    from ansible.playbook import PlayContext
    from ansible.template import Templar
    pc = PlayContext()
    t = Templar(loader=None, variables=None)

    # Now that we have an instance of Templar, we can create an instance
    # of AnsibleJ2Vars to unit test:
    var = AnsibleJ2Vars(t, dict())
    assert not var          # variable reference is empty

# Generated at 2022-06-21 07:57:55.759032
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # just try to run all the code and you will see the error if it is there
    from ansible.template.safe_eval import ansible_eval
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    globals = {
        'my_var': 'my_value',
        'my_dict': {
            'my_key': 'my_value_2',
            'my_key_2': 'my_value_3',
        },
        'my_list': ['my_value_4', 'my_value_5'],
    }

# Generated at 2022-06-21 07:58:07.515554
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Object of class AnsibleJ2Vars should properly handle __contains__.
    '''
    try:
        from ansible.template import Templar
        import jinja2
        templar = Templar(directory=None)
        globals = {'foo': 'foo'}
        locals = {'bar': 'bar'}
        ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
        if 'foo' in ansible_j2vars:
            assert True
        elif 'bar' in ansible_j2vars:
            assert True
        elif 'baz' in ansible_j2vars:
            assert True
        else:
            assert False
    except AssertionError as e:
        print(e)
        raise Assertion

# Generated at 2022-06-21 07:58:18.392617
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar():
        available_variables = {}
        def template(self, variable):
            pass
    templar = Templar()

    # Case 1: key exist in locals
    idict = {'a1': 'A1-value'}
    gdict = {}
    ldict = {}
    ansible_j2_vars = AnsibleJ2Vars(templar, gdict, ldict)
    ansible_j2_vars.update(idict)
    assert(ansible_j2_vars.get('a1') == 'A1-value')

    # Case 2: key does not exist in locals and exist in available_variables
    idict = {'a2': 'A2-value'}
    gdict = {}
    ldict = {}

# Generated at 2022-06-21 07:58:27.916520
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import SafeEval
    from ansible.template.templar import Templar
    import ansible.module_utils.urls

# Generated at 2022-06-21 07:58:34.755260
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'a': 4, 'd': 5, 'f': 6}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'd' in j2vars


# Generated at 2022-06-21 07:58:44.729923
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.module_utils._text import to_unicode
    from ansible.template import Templar
    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, dict(), dict(a=1))
    assert j2vars['a'] == 1
    assert j2vars.get('a') == 1
    assert j2vars.get('a', '') == 1
    assert j2vars.get('b', '') == ''
    assert j2vars.get('b', '-') == '-'
    assert j2vars.get('b') is None
    assert j2vars.get('b', None) is None
    assert 'a' in j2vars
    assert 'b' not in j2vars

    templar._available_

# Generated at 2022-06-21 07:58:55.897774
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.plugins.loader import template_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    my_templar = Templar(loader=template_loader)
    my_templar.set_available_variables({ 'a': 1, 'b': 2 })
    my_var_proxy = AnsibleJ2Vars(my_templar, { 'c': 3 }, { 'a': 4, 'd': 5 })
    my_expected = set(['c', 'd', 'a', 'b'])
    my_result = set(my_var_proxy)
    assert my_result == my_expected, 'Result: %s Expected: %s' % (my_result, my_expected)


# Generated at 2022-06-21 07:59:11.718297
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook import Playbook
    from ansible.template.vars import AnsibleJ2Vars
    p = Playbook()
    p.host_file_parser = p.inventory_loader.loader.get('script')

    j2vars = AnsibleJ2Vars(Templar(p), {})
    j2vars._templar.available_variables = {'name': 'test', 'names':['test1', 'test2']}
    j2vars._templar._vault.password = 'blah'
    j2vars._locals = {'test': 'value'}
    i = j2v

# Generated at 2022-06-21 07:59:18.868654
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    v = AnsibleJ2Vars(Templar(), {})
    assert len(v) == 0

    v = AnsibleJ2Vars(Templar(), {'a': 1})
    assert len(v) == 1

    v = AnsibleJ2Vars(Templar(), {'a': 1, 'b': 2})
    assert len(v) == 2

    v = AnsibleJ2Vars(Templar(), {'a': 1, 'b': 2, 'c': 3})
    assert len(v) == 3

# Generated at 2022-06-21 07:59:25.492786
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # Create mock objects
    templar = object()
    globals = object()
    locals = object()

    # Create object
    obj = AnsibleJ2Vars(templar, globals, locals)

    # Run test
    test_value = None
    result = obj.__iter__()

    # Check result
    assert isinstance(result, object)

# Generated at 2022-06-21 07:59:35.340003
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars import add_host_var, add_group_var
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import Mapping
    import os
    import unittest

    # Create a list of all vars
    #

# Generated at 2022-06-21 07:59:47.546617
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # import required modules for testing
    import pytest
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = {
        'key'   : 'global_value'
    }
    locals = {
        'key'   : 'local_value'
    }

    # create a variable proxy
    var_proxy = AnsibleJ2Vars(templar, globals, locals)

    # check the method add_locals return properly a vars proxy with the new locals
    assert isinstance(var_proxy.add_locals(locals), AnsibleJ2Vars)

    # check if the second level of nested vars proxy return properly the value of the locals
    assert var_proxy.add_locals(locals)['key'] == 'local_value'

    # check the locals is

# Generated at 2022-06-21 07:59:57.431967
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars import VariableManager
    from ansible.template import Templar

    local_vars = {'a': 'c', 'b': 'd'}
    global_vars = {'e': 'f', 'g': {'h': 'i'}}
    v = VariableManager()
    v.add_host_var('localhost', local_vars)
    v.set_globals(global_vars)
    t = Templar(v)
    c = AnsibleJ2Vars(t, global_vars)
    assert c['a'] == 'c'
    assert c['b'] == 'd'
    assert c['e'] == 'f'
    assert c['g'] == {'h': 'i'}

# Generated at 2022-06-21 08:00:07.789431
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_data = { 'a': 1,
                  'b': 2,
                  'c': 3,
                  'd': 4,
                  'e': 5 }

    templar = Templar(loader=None)
    templar.available_variables = test_data

    vars_obj = AnsibleJ2Vars(templar, globals=test_data)
    assert 'a' in vars_obj
    assert 'b' in vars_obj
    assert 'c' in vars_obj
    assert 'd' in vars_obj
    assert 'e' in vars_obj
    assert 'f' not in vars_obj



# Generated at 2022-06-21 08:00:20.586624
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    myobj = templar = Templar()
    myobj.available_variables = AnsibleMapping()
    globals = AnsibleMapping()
    locals = AnsibleMapping()
    myobj = AnsibleJ2Vars(templar,globals,locals)
    mylen = myobj.__len__()
    print("len= ",mylen)
    del myobj
    myobj = templar = Templar()
    myobj.available_variables = AnsibleMapping( {"var1":"v1","var2":"v2"} )

# Generated at 2022-06-21 08:00:29.416491
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-21 08:00:41.175561
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    def tryexcept(inp, exp, ansible_j2_vars):
        try:
            result = ansible_j2_vars[inp]
            assert result == exp
        except:
            assert False

    templar = None
    globals = {'g1': 1, 'g2': 2, 'g3': 3}
    locals = {'l1': 4, 'l2': 5, 'l3': 6}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # locals hit first
    tryexcept('l1', 4, ansible_j2_vars)
    tryexcept('l2', 5, ansible_j2_vars)
    tryexcept('l3', 6, ansible_j2_vars)

   