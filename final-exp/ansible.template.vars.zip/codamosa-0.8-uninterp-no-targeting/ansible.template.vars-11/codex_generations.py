

# Generated at 2022-06-21 07:51:09.469981
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    dict_1 = {'a': '1', 'b': '2', 'c': '3'}
    dict_2 = {'a': '1', 'b': '2', 'c': '3'}
    dict_3 = {'a': '1', 'b': '2', 'c': '3'}
    assert 3 == len(dict_1), "Dict_1 length incorrect"
    assert 3 == len(dict_2), "Dict_2 length incorrect"
    assert 3 == len(dict_3), "Dict_3 length incorrect"
    j2v = AnsibleJ2Vars(templar, dict_1, locals=dict_2)

# Generated at 2022-06-21 07:51:18.360734
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """
    This function executes unit test for method __getitem__ of class AnsibleJ2Vars
    """
    templar = None
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test no exception raised when variable exists
    variable = "test_var"
    templar = { variable: "test_variable_value" }
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars[variable] == "test_variable_value"

    # Test exception raised when variable does not exist
    variable = "test_var"
    templar = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars[variable] == None

# Generated at 2022-06-21 07:51:23.570156
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    print("Testing __contains__ method of class AnsibleJ2Vars")

    # Create a temporary Templar object, used by AnsibleJ2Vars
    t = jinja2.Environment().from_string('').globals['templar']
    p = AnsibleJ2Vars(t, globals={})

    # Test if the word 'range' is in the global jinja2 variables
    if 'range' in p:
        print("'range' is in the global jinja2 variables. Test passed.")
    else:
        print("'range' is not in the global jinja2 variables. Test failed.")

# Generated at 2022-06-21 07:51:30.536104
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test for undefined variable
    from ansible.template import Templar
    test_templar = Templar(loader=None)
    test_globals = {}
    test_locals = {}
    test_vars = AnsibleJ2Vars(test_templar, test_globals, locals=test_locals)
    try:
        test_vars["undefined_var"]
        raise AssertionError("Test of undefined_var should fail")
    except KeyError as e:
        assert str(e) == "undefined variable: undefined_var",\
            "Error raised not correct"
    # Test for key_var = 'val'
    setattr(test_templar, "available_variables", {"key_var": "val"})

# Generated at 2022-06-21 07:51:41.979763
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.unsafe_proxy import create_unsafe_proxy
    from ansible.template import Templar

    globals1 = dict(
        a="A",
        b="B")

    globals2 = dict(
        a="A",
        b="B",
        c="C")

    locals1 = dict(
        c="C")

    locals2 = dict(
        a="A",
        c="C")

    templar = Templar(loader=None, variables=dict(a=1, b=2, c=3))

    # filled test
    obj = AnsibleJ2Vars(templar, globals1, locals1)
    filled_keys = [k for k in obj]
    assert len(filled_keys) == 3
    assert "a" in filled_keys

# Generated at 2022-06-21 07:51:49.641049
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None  # placeholder, not relevant for this test
    globals = {'g_foo': 1}
    locals = {'l_bar': 2}

    vars = AnsibleJ2Vars(templar, globals, locals=locals)

    # Ensure AnsibleJ2Vars.__iter__() returns a list of all keys from locals, globals and templar
    assert set(vars) == set(['g_foo', 'l_bar'])

# Generated at 2022-06-21 07:51:56.607512
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import collections
    import ansible.template
    t = ansible.template.Templar()
    # Variable 'varname' is correctly replaced by the __getitem__ method of class AnsibleJ2Vars
    jvars = AnsibleJ2Vars(t, {}, locals={"varname": "value"})
    assert jvars['varname'] == "value"
    # Variable 'varname2' is not found in the class locals and so raises a KeyError exception. The
    # exception message must be as expected.
    with expected('undefined variable: varname2'):
        jvars['varname2']
    # The exception message must be as expected.
    with expected('exception'):
        jvars['exception']
    # Variable 'exception2' raises an AnsibleUndefinedVariable

# Generated at 2022-06-21 07:52:06.703674
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    from ansible.template import Templar

    j2_locals = {'l_cat': 'kitten'}
    j2_globals = {'g1': 'one', 'g2': 'two'}
    j2_vars = {'cat': 'kitty', 'dog': 'puppy'}


    j2_vars_obj = AnsibleJ2Vars(Templar(), j2_globals, locals=j2_locals)
    j2_vars_obj._templar.available_variables = j2_vars

    assert len(j2_vars_obj) == 5

# Generated at 2022-06-21 07:52:15.880317
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import types
    from ansible.template import Templar
    from ansible.template.safe_eval import SafeEval

    t = Templar(loader=None, variables={})
    g = types.ModuleType("ansible.template.globals")
    v = AnsibleJ2Vars(t, g.globals)
    l = {'a': 1, 'b': 2, 'c': 3}
    vv = v.add_locals(l)

    assert vv._locals == l
    assert vv._templar == t
    assert vv._globals == g.globals

# Generated at 2022-06-21 07:52:23.529865
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.template.template import Templar

    # Initialize objects
    templar = Templar(loader=None, variables={
        'hostvars': {'host.example.com': {'boo': 'far'}},
        'inventory_hostname': 'host.example.com',
    })
    ansible_vars = AnsibleJ2Vars(templar, {
        'from_globals': 'I come from globals',
    })
    locals = {
        'from_locals': 'I come from locals',
    }

    # Check that we can access items from AnsibleJ2Vars
    assert ansible_vars['from_globals'] == 'I come from globals'
    assert ansible_vars

# Generated at 2022-06-21 07:52:36.731566
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.manager import VariableManager

    from units.mock.loader import DictDataLoader

    from units.mock.path import mock_unfrackpath_noop


# Generated at 2022-06-21 07:52:40.683310
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
  from ansible.template import Templar
  from ansible.vars.hostvars import HostVars

  templar = Templar(loader=None, variables={})
  globals_ = {'global':'global'}
  locals_ = {'local':'local'}

  n = AnsibleJ2Vars(templar, globals_, locals=locals_)
  assert list(iter(n)) == ['global', 'local', 'hostvars']

# Generated at 2022-06-21 07:52:52.047429
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    from ansible.template import Templar
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible import constants as C

    add_all_plugin_dirs()
    templar = Templar(loader=None, variables={})

    var_value = {"abc": 1}
    assert 'abc' not in AnsibleJ2Vars(templar, {}, locals=None)
    assert 'abc' not in AnsibleJ2Vars(templar, {}, locals=var_value)

    import os
    import sys
    if C.DEFAULT_KEEP_REMOTE_FILES:
        C.DEFAULT_KEEP_REMOTE_FILES

# Generated at 2022-06-21 07:53:01.334082
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.errors import AnsibleUndefinedVariable

    templar = Templar(loader=None, shared_loader_obj=None, variables={})
    templar._available_variables = {'varname': 'value'}

    vars = AnsibleJ2Vars(templar, {})

# Generated at 2022-06-21 07:53:13.509488
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    from ansible.template import Templar

    from ansible.template.safe_eval import safe_eval
    from ansible.vars.unsafe_proxy import wrap_var

    T = jinja2.Template("{{inner_test}}")

    # the following is not the regular use of a dict with a dict but the
    # actual test data. The right hand side is the jinja2 variable
    # structure, the left hand side is the expected outcome

# Generated at 2022-06-21 07:53:24.752157
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.template.templar import Templar
    import os

    class Options(object):
        def __init__(self, verbosity=0, connection='local', module_path=None, forks=100, become=None,
                     become_method=None, become_user=None, check=False, listhosts=None, listtasks=None, listtags=None, syntax=None,
                     diff=False, vault_password=None):
            self.verbosity = verbosity
            self.connection = connection

# Generated at 2022-06-21 07:53:37.450344
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    context = PlayContext()
    templar = Templar(loader=None, variables={}, shared_loader_obj=None, context=context, disable_lookups=False, vault_password=None)
    globals = {'test': 'test_value'}
    locals  = {'locals': 'locals_value'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    variable = 'test'
    assert(j2vars.__getitem__(variable) == globals[variable])

    variable = 'locals'
    assert(j2vars.__getitem__(variable) == locals[variable])

    variable = 'fake_variable'

# Generated at 2022-06-21 07:53:41.401936
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.hostvars import HostVars 
    test_dict = {'hostvars': HostVars(dict())}
    test_vars = AnsibleJ2Vars('', test_dict)
    assert test_vars == test_dict

# Generated at 2022-06-21 07:53:50.179819
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play_context import PlayContext

    inventory = InventoryManager(loader=None, sources=["localhost"])

    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.set_inventory(inventory)
    variable_manager.set_play_context(PlayContext(variable_manager=variable_manager))

    templar = Templar(loader=None, variables=variable_manager)

    old_vars = AnsibleJ2Vars(templar, variable_manager._fact_cache._plugin_cache, locals=None)


# Generated at 2022-06-21 07:54:00.115979
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.templating import Templar
    globals = dict(g1=1, g2=2)
    locals = dict(l1=3, l2=4)
    templar = Templar(loader=None, variables=dict(v1=5, v2=6))
    aj2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'g2' in aj2vars
    assert 'l1' in aj2vars
    assert 'v1' in aj2vars
    assert 'g3' not in aj2vars
    assert 'l3' not in aj2vars
    assert 'v3' not in aj2vars

# Generated at 2022-06-21 07:54:15.088178
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.vault import VaultLib  # FIXME: need a better way to do this without direct import

    # Make sure the locals are properly added to a new AnsibleJ2Vars object
    vault_secrets = VaultLib("test", "", False, False)
    assert vault_secrets
    templar = Templar(loader=None, variables=dict(), vault_secrets=vault_secrets)
    assert templar

    locals = {'test_var': 'test_value'}
    aj2v = AnsibleJ2Vars(templar, locals=locals)
    assert aj2v
    assert 'test_var' in aj2v
    assert aj2v['test_var'] == 'test_value'


# Generated at 2022-06-21 07:54:24.946795
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import pytest
    from io import StringIO

    # Test Case 1
    context = PlayContext()
    context.vars = dict(var1="abc")
    context.vars.update(dict(var2="def", var3="ghi"))
    templar = Templar(loader=None, variables=context.vars, shared_loader_obj=None)
    ansible_vars = AnsibleJ2Vars(templar=templar, globals=dict(glob1="abc", glob2="def", glob3="ghi"), locals=dict(l_var1="abc"))
    assert "var1" in ansible_vars
    assert "var2" in ansible_vars

# Generated at 2022-06-21 07:54:34.932577
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.templating import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars import hostvars

    loader = DataLoader()
    templar = Templar(loader=loader)
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create variables structure

# Generated at 2022-06-21 07:54:43.268929
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    templar = Templar(loader=None, variables={'key': 'value'}, shared_loader_obj=None)
    j2vars = AnsibleJ2Vars(templar, globals=None)
    # jinja2.utils.missing is not subscriptable, so we have to actually use a dict
    locals_dict = dict()
    # Test that AnsibleJ2Vars works the same as a dict
    locals_dict.update({'value'})
    j2vars.add_locals(locals_dict)

# Generated at 2022-06-21 07:54:55.624859
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    available_variables = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    templar = Templar(loader=None, variables=available_variables)

    globals = {'b': 11, 'c': 12, 'd': 13, 'e': 14, 'f': 15}
    locals = {'c': 21, 'd': 22, 'e': 23, 'f': 24, 'g': 25}

    result = list(AnsibleJ2Vars(templar, globals, locals=locals))
    expected = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 15, 'g': 25}

    assert len(result) == len(expected)

# Generated at 2022-06-21 07:55:07.714662
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.playbook import PlayContext
    play_context = PlayContext()

    templar = Templar(loader=None, variables={}, vault_secrets=[], fail_on_undefined=True)
    templar._link_vault_secrets(VaultLib(password_files=[], passwords={}))

    empty_vars = {}
    vars = [{}, {'foo': 'bar'}, {'hello': 'world', 'foo': 'bar'}]

    for vars_ in vars:
        ansible_vars = AnsibleJ2Vars(templar, vars_)
        assert set(ansible_vars.__iter__()) == set(vars_)

    ansible_

# Generated at 2022-06-21 07:55:11.548101
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # __getitem__ returns the value of a variable if it is available in available_variables
    def test_case_1():
        templar_mock = MagicMock()
        templar_mock.available_variables = {'variable_1': 'value_1'}
        result = AnsibleJ2Vars(templar_mock, {}, {}).__getitem__('variable_1')
        assert result == 'value_1'

    # __getitem__ raises KeyError if variable is not available in available_variables and not in locals
    def test_case_2():
        templar_mock = MagicMock()
        templar_mock.available_variables = {'variable_1': 'value_1'}

# Generated at 2022-06-21 07:55:23.614054
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar:
        def __init__(self):
            self.available_variables = { "var" : "value" }
        def template(self, variable):
            return variable

    class Globals:
        def __init__(self):
            self.glob_var = "glob_value"

    from ansible.vars.hostvars import HostVars
    import mock
    with mock.patch.object(Templar, 'template') as template_mock:
        ansible_j2_vars = AnsibleJ2Vars(Templar(), Globals(), locals={"l_var" : "l_value"})
        template_mock.side_effect = [ "var" , "l_var" ]
        assert ansible_j2_vars["var"] == "value"

# Generated at 2022-06-21 07:55:35.176361
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    # Test 1
    # The method should return 2 when self._locals = {'this_key': 'this_value'},
    # self._templar.available_variables = {'key': 'value'}, self._globals = {'dict_key': 'dict_value'}
    class TestAnsibleJ2Vars1(AnsibleJ2Vars):
        def __init__(self, templar_to_use, globals_to_use):
            self._templar = templar_to_use
            self._globals = globals_to_use
            self._locals = {'this_key': 'this_value'}
    test_object = TestAnsibleJ2

# Generated at 2022-06-21 07:55:45.181222
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    # Arrange: Create object with templar, globals, locals
    locals = dict(varname1='value1', varname2='value2')
    templar = Templar(loader=None, variables=dict(varname1='value1', varname2='value2', varname3='value3'))
    obj = AnsibleJ2Vars(templar, dict(varname1='value1', varname2='value2'), locals)

    # Act: Get an existing variable in locals
    actual = obj['varname2']

    # Assert: Return value of existing variable
    assert actual == 'value2'
    print('test_AnsibleJ2Vars___getitem__: ', actual)


# Generated at 2022-06-21 07:56:04.445717
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader(), variables=VariableManager(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader())))

    globals = {"globals_a": "globals_b"}
    locals = {"locals_a": "locals_b"}

    a = AnsibleJ2Vars(templar, globals, locals)
    it = iter(a)
    d = dict(zip(it, it))

# Generated at 2022-06-21 07:56:16.808456
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.template import Templar

    # prepare input to AnsibleJ2Vars object
    templar = Templar(loader=None, variables={'a': 1})
    globals = jinja2.StrictUndefined('globals')
    locals = {'b': 2}

    # create AnsibleJ2Vars object
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # add more locals
    new_locals = {'c': 3, 'd': 4}
    j2vars_with_new_locals = j2vars.add_locals(new_locals)

    # test if the locals are added properly
    assert j2vars_

# Generated at 2022-06-21 07:56:27.451692
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template.safe_eval import compile_unsafe, unsafe_eval
    from ansible.template import Templar
    from ansible.module_utils.six import PY3
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    # initialize templar
    unquoted_string_to_render = "toto"
    # We have to use variables to render with the templar because of
    # the way the templar works. Variables are provided to the templar
    # as dictionaries.
    variables = dict()
    variables['toto'] = unquoted_string_to_render
    templar = Templar(variables=variables)
    # initialize globals
    globals = dict()
    # define

# Generated at 2022-06-21 07:56:32.110065
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    j2vars = AnsibleJ2Vars( mock_templar, {} )
    locals = { 'v1' : 'value1', 'v2' : ['a', 'b'] }
    proxy = j2vars.add_locals( locals )
    assert locals == proxy._locals
    assert isinstance(proxy, AnsibleJ2Vars)


# Generated at 2022-06-21 07:56:44.861126
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['127.0.0.1,'])

# Generated at 2022-06-21 07:56:54.664675
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class ExampleTemplar(object):
        def template(self, variable):
            return variable

    # Test is to verify that add_locals() correctly creates a copy of
    # self and returns it with updated locals.
    templar = ExampleTemplar()
    globals = {'foo': 'bar'}
    locals = {'bar': 'foo'}

    aj2v = AnsibleJ2Vars(templar, globals)
    assert aj2v == {'foo': 'bar'}

    locals_inject = {'foo': 'foo'}
    new_aj2v = aj2v.add_locals(locals_inject)
    assert new_aj2v == {'foo': 'foo', 'bar': 'foo'}
    # Verify aj2v is an unchanged copy of

# Generated at 2022-06-21 07:57:06.881081
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.template.template import AnsibleEnvironment

    templar = Templar(variables={}, loader=None)
    j2vars = AnsibleJ2Vars(templar, globals={}, locals={})
    assert j2vars is j2vars.add_locals(None)

    j2vars = AnsibleJ2Vars(templar, globals={}, locals={'foo': 'bar'})
    j2vars = j2vars.add_locals(None)
    assert j2vars['foo'] == 'bar'

    j2vars = AnsibleJ2Vars(templar, globals={}, locals={'foo': 'bar'})

# Generated at 2022-06-21 07:57:07.488414
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass

# Generated at 2022-06-21 07:57:12.765830
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    vm = VariableManager()
    vm.extra_vars = {'a' : 'foo', 'b' : 'bar'}
    vars = AnsibleJ2Vars(Templar(loader=None, variables=vm), globals())
    assert 'a' in vars and 'b' in vars and 'foo' in vars and 'bar' in vars

# Generated at 2022-06-21 07:57:22.057258
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    templar = 'something magical'
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux', 'l_bop': AnsibleUnsafeText('bam'), 'context': 'context'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 3
    assert len(vars.add_locals({'a': 'b'})) == 4
    assert len(vars.add_locals(None)) == 3

# Generated at 2022-06-21 07:58:10.729824
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    vars_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=vars_manager, play_context=play_context)
    vars = AnsibleJ2Vars(templar=templar, globals={})
    j2_vars_list = list(vars)

# Generated at 2022-06-21 07:58:20.195352
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    # Check data
    template_data = {
        'a': 1,
        'b': 'text',
        'c': "{{'text'}}",
        'd': True,
        'e': False,
        'f': ['item1', 'item2', 'item3'],
        'g': {'key1': 'value1', 'key2': 'value2'},
        'h': None,
        'i': '{{text}}',
        'j': '{{ansible_play_hosts_all}}'
    }

    # Templating variables
    templar = Templar(loader=None)
    templar.template_data = template_data

    # Globals
    global_vars = {}

    # Create AnsibleJ2Vars
    ansiblej

# Generated at 2022-06-21 07:58:25.569640
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # Test simple use case
    templar = None
    globals = {'a':1, 'b':2, 'c':3}
    locals = {'c':5, 'd':6}
    v = AnsibleJ2Vars(templar, globals, locals)
    assert set(v.__iter__()) == set(['a', 'b', 'c', 'd'])

    # If a variable does not exist, do not fail
    templar = None
    globals = {'a':1, 'b':2, 'c':3}
    locals = {'c':5, 'd':6}
    v = AnsibleJ2Vars(templar, globals, locals)
    assert set(v.__iter__()) == set(['a', 'b', 'c', 'd'])

# Generated at 2022-06-21 07:58:37.899075
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from units.mock.loader import DictDataLoader
    from units.mock.vars import MockVarsModule

    loader = DictDataLoader({
        'parent': '{{ variable1 }}',
        'child': '{{ variable2 }}'
    })
    mock_vars = MockVarsModule({
        'variable1': 'foo',
        'variable2': 'bar'
    })

    from ansible.template.safe_environment import SafeEnvironment
    from ansible.template.templar import Templar
    env = SafeEnvironment(loader=loader)

    templar = Templar(loader=loader, variables=mock_vars)
    locals = {'variable2': 'baz'}
    j2_vars = AnsibleJ2Vars(templar, {}, locals=locals)
    j2_v

# Generated at 2022-06-21 07:58:42.879417
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'a': 1, 'b': 2, 'c': 3})
    globals = safe_eval.__globals__
    proxy = AnsibleJ2Vars(templar, globals)
    assert len(proxy) == 3


# Generated at 2022-06-21 07:58:43.697460
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass


# Generated at 2022-06-21 07:58:45.856360
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    from ansible.template import Templar

    t = Templar(loader=None)
    v = AnsibleJ2Vars(t, dict(a=1))

    assert len(v) == 2

# Generated at 2022-06-21 07:58:57.464651
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.parsing.yaml.objects as AnsibleYAMLObject
    import ansible.playbook.play_context as AnsiblePlayContext
    import ansible.templating.templar as AnsibleTemplar
    import ansible.templating.vars as AnsibleTemplatingVars
    import ansible.vars.hostvars as AnsibleVarsHostVars
    import ansible.vars.unsafe_proxy as AnsibleVarsUnsafeProxy
    import ansible.inventory.host as AnsibleInventoryHost
    import ansible.template as AnsibleTemplate
    object_loader = AnsibleYAMLObject.AnsibleBaseYAMLLoader.load
    from ansible.template import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-21 07:59:08.185398
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    import os
    import tempfile

    # create a temporary data directory
    data_dir = tempfile.TemporaryDirectory()
    # create the inventory file and write a static inventory to the temporary inventory file
    invent_dict = """
    localhost ansible_connection=local
    localhost2 ansible_host=127.0.0.1 ansible_port=2222 ansible_user=test
    """
    invent_file = open(os.path.join(data_dir.name, 'hosts'), 'w')
    invent_file.write(invent_dict)
    invent_file.close()
    # create

# Generated at 2022-06-21 07:59:17.446616
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import boolean
    templar = Templar()
    glob = {}
    var = AnsibleJ2Vars(templar, glob, locals={'a': 1, 'b': 2})
    assert var['a'] == 1
    assert var['b'] == 2
    assert 'c' not in var
    var = AnsibleJ2Vars(templar, glob, locals={'a': 1, 'b': HostVars({'h1.example.org': {'c': 3}})})
    assert var['b']['h1.example.org']['c'] == 3
    try:
        assert var['c']
    except AnsibleUndefinedVariable:
        pass

# Generated at 2022-06-21 07:59:54.965059
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.safe_eval import safe_eval
    import os
    import sys

    # pylint: disable=unused-variable,unused-argument
    loader = DataLoader()
    templar = Templar(loader=loader)

    available_varialbes = dict()
    available_varialbes['var_1'] = 1
    available_varialbes['var_2'] = 2
    available_varialbes['var_dict_1'] = {'key_1': 1, 'key_2': 2}

# Generated at 2022-06-21 08:00:06.148449
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    proxy = AnsibleJ2Vars(templar, globals={})
    assert not proxy.__contains__('test_var')
    assert not proxy.__contains__('test_var_2')
    assert not proxy.__contains__('test_var_3')
    assert not proxy.__contains__('test_var_4')
    proxy._templar.available_variables.update({'test_var': 'test_value'})
    assert proxy.__contains__('test_var')
    assert not proxy.__contains__('test_var_2')
    assert not proxy.__contains__('test_var_3')
    assert not proxy.__contains__('test_var_4')

# Generated at 2022-06-21 08:00:14.126301
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    test_templar = Templar(loader=None)

    # Test cases
    test_globals = {'var1': 'value1'}
    test_locals_1 = {'var2': 'value2'}
    test_locals_2 = {'var3': 'value3'}

    # Define test
    test_AnsibleJ2Vars = AnsibleJ2Vars(test_templar, test_globals, test_locals_1)
    assert 'var1' in test_AnsibleJ2Vars
    assert 'var2' in test_AnsibleJ2Vars
    assert not 'var3' in test_AnsibleJ2Vars

    # Redefine test
    test_AnsibleJ2Vars = Ans

# Generated at 2022-06-21 08:00:25.749512
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """ AnsibleJ2Vars.__iter__() sanity checks """
    var_list = ['foo','bar','baz','quux','baz','quux','foo','bar']

    # simple tests
    x = AnsibleJ2Vars(None, {}, {})
    assert x.__iter__().__length_hint__() == 0
    x = AnsibleJ2Vars(None, {'foo': 1, 'bar': 2}, {})
    assert x.__iter__().__length_hint__() == 2
    x = AnsibleJ2Vars(None, {}, {'foo': 1, 'bar': 2})
    assert x.__iter__().__length_hint__() == 2

# Generated at 2022-06-21 08:00:28.913545
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    globals = dict()
    j2vars = AnsibleJ2Vars(Templar(), globals, locals=None)
    assert j2vars is not None

# Generated at 2022-06-21 08:00:33.690719
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.template import Templar
    templar = Templar(loader=None)

    test_dict = {'a': '1', 'b': '2'}

    a_j2Vars = AnsibleJ2Vars(templar, test_dict)
    assert a_j2Vars['a'] == '1'

# Generated at 2022-06-21 08:00:44.509750
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ''' Unit test for constructor of class AnsibleJ2Vars '''
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    # test case 1 - set initial locals
    j2_vars_1 = AnsibleJ2Vars(Templar(loader=None), dict(), dict(one=1, two=2, three=3))
    assert j2_vars_1['one'] == 1
    assert j2_vars_1['two'] == 2
    assert j2_vars_1['three'] == 3

    # test case 2 - use locals as template variables in template expression
    j2_vars_2 = AnsibleJ2Vars(Templar(loader=None), dict())

# Generated at 2022-06-21 08:00:55.100576
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.module_utils.jinja2.templar import Templar
    templar = Templar(loader=None, variables={'test_var': '42'})
    var_proxy = AnsibleJ2Vars(templar, globals={'test_global': '69'}, locals={'test_local': '1337'})

    assert 'test_global' in var_proxy
    assert 'test_var' in var_proxy
    assert 'test_local' in var_proxy

    assert len(var_proxy) == 3

    assert list(var_proxy) == ['test_global', 'test_local', 'test_var']