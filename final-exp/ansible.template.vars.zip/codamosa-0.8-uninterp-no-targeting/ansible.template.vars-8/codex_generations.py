

# Generated at 2022-06-21 07:51:09.470296
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import sys
    import pytest
    from io import StringIO

    original_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)
    play_context = PlayContext()
    
    variables = dict()
    variables['testvar'] = "test"
    variable_manager.set_nonpersistent_facts(variables)
    del variables

    j2vars = AnsibleJ2Vars(templar, dict())

   

# Generated at 2022-06-21 07:51:18.370549
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.module_utils.six import string_types
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    g_expected_dict = {
        "a1": "v1",
        "a2": {
            "aa1": "vv1",
            "aa2": "vv2"
        },
        "a3": "v3",
        "a4": "v4",
        "a5": {
            "aa5": "vv5"
        }
    }
    g_expected_list = ["a1", "a2", "a3"]
    g_expected_str = "{{ a1 }}"
    p_expected_dict = {"p1": "vp1", "p2": "vp2"}

# Generated at 2022-06-21 07:51:23.325600
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    test_templar = object()
    test_globals = {'ansible_check_mode': False}
    test_locals = {'l_answer': 42}
    available_variables = {'ansible_check_mode': False, 'vars': {'answer': 42}}
    test_templar.available_variables = available_variables

    test_obj = AnsibleJ2Vars(test_templar, test_globals, locals=test_locals)
    assert len(test_obj) == 3



# Generated at 2022-06-21 07:51:30.470730
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.templating import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    play_context = dict()

    host1 = inventory.get_host('host1')
    host2 = inventory.get_host('host2')
    test_hosts = [host1, host2]

    loader.set_basedir('.')

# Generated at 2022-06-21 07:51:41.936860
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.template
    import ansible.vars
    import ansible.vars.hostvars
    import copy
    import jinja2

    m = ansible.template.AnsibleModule(
        argument_spec = dict(),
    )
    t = ansible.template.Templar(loader=jinja2.DictLoader(dict()), variables=ansible.vars.VariableManager(loader=None, host_list=[], inventory=None))
    g = {
        'ANSIBLE_MODULE_ARGS':m.params,
        'ANSIBLE_MODULE_NAME':m.params['ANSIBLE_MODULE_NAME'],
        'True':True,
        'False':False,
    }
    x = ansible.template.AnsibleJ2Vars(t, g)


# Generated at 2022-06-21 07:51:53.156014
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.play_context import PlayContext

    templar = Templar(loader=None, variables=None, shared_loader_obj=None)
    globals = dict(selfobj=AnsibleUnsafeText('selfobj'))
    locals = dict(localobj=AnsibleUnsafeText('localobj'))
    varsitm = AnsibleJ2Vars(templar, globals, locals=locals)

    assert varsitm['localobj'] == 'localobj'
    assert varsitm['selfobj'] == 'selfobj'

    assert varsitm['vars'] == varsitm

# Generated at 2022-06-21 07:52:05.402276
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import safe_eval
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template.templar import Templar
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    templar = Templar(loader=None, variables={}, shared_loader_obj=None)


# Generated at 2022-06-21 07:52:16.960710
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible import templar
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    templar = Templar(variables={'name':'Ansible'}, vault_secrets=VaultLib())
    locals = {'name':'Ansible'}
    globals_ = {'name':'Ansible'}
    a = AnsibleJ2Vars(templar, globals_, locals)
    assert a['name'] == 'Ansible'
    try:
        assert a['lastname']
    except KeyError as e:
        assert "undefined variable" in str(e)
    # Test if the method returns an instance of HostVars
    temp_hostvars = HostVars

# Generated at 2022-06-21 07:52:27.662920
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """
    Test return value of method __iter__ of class AnsibleJ2Vars

    Return value should follow the following rules:
        1. Variables in self._locals should be included
        2. Variables in self._templar.available_variables (representing variables
            for a specific host inventory item) should be included
        3. Variables in self._globals should be included
        4. No variable should be included twice (even if it exists in multiple
            variable scopes/sources)
        5. Return value type should be a type compatible with iter()
    """
    import jinja2
    import ansible.inventory.host

    templar = jinja2.Environment()
    globals = dict(name='Global')
    locals = dict(name='Local')
    hostvars = dict(name='Hostvar')

# Generated at 2022-06-21 07:52:37.069915
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2.runtime
    import jinja2.environment
    import jinja2.compiler
    import jinja2.exceptions
    import jinja2.lexer
    import jinja2.loaders
    import jinja2.nodes
    import jinja2.parser
    import jinja2.utils
    from ansible.template import Templar

    class MockTemplar(Templar):
        def __init__(self, *args, **kwargs):
            super(MockTemplar, self).__init__(*args, **kwargs)

    available_variables = {'var': 'val'}
    mock_templar = MockTemplar(loader=None, shared_loader_obj=None, variables=available_variables)

# Generated at 2022-06-21 07:52:53.668397
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
	# Test with varname in _locals
	locals_dict = {"varname1": "value1", "varname2": "value2", "varname3": "value3"}
	ansible_vars = AnsibleJ2Vars("templar", "globals", locals_dict)
	assert ansible_vars["varname1"] == "value1"
	assert ansible_vars["varname2"] == "value2"
	assert ansible_vars["varname3"] == "value3"

	# Test with varname in _templar.available_variables
	ansible_vars = AnsibleJ2Vars("templar", "globals", locals_dict)
	assert ansible_vars["varname1"] == "value1"

# Generated at 2022-06-21 07:53:02.258425
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import sys
    import os
    import pytest

    top_level_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    sys.path.append(top_level_path)

    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # Initiate AnsibleJ2Vars
    templar = Templar(loader=None, variables={})
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # Test case 1:
    # Test __len__ with empty available_variables, empty self

# Generated at 2022-06-21 07:53:09.883052
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = {'g_a': 1, 'g_b': 2}
    locals = {'l_a': 3, 'l_b': 4, 'context': 5, 'environment': 6, 'template': 7}
    test_obj = AnsibleJ2Vars(templar, globals, locals=locals)
    ans = {'l_b', 'l_a', 'g_a', 'g_b'}
    assert set(test_obj) == ans

# Generated at 2022-06-21 07:53:22.128914
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    import jinja2
    from ansible.parsing.vault import VaultLib

    class Templar(object):

        def __init__(self, vars_hash):
            self.available_variables = vars_hash

        def template(self, variable):
            return variable

    vault = VaultLib([])
    var_hash = {'vault': vault, 'foo': 'bar', 'baz': {'qux': 'quux'}, 'lis': [1, 2, 3, 4]}
    var_hash = vault.encrypt_unsafe_vars(var_hash)
    templar = Templar(var_hash)

# Generated at 2022-06-21 07:53:28.578365
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import unittest

    class TestAnsibleJ2Vars(unittest.TestCase):
        class Templar():
            def __init__(self):
                self.available_variables = {
                    'a' : 'aval',
                    'c' : 'cval',
                }
            def template(self, varname):
                return "t_" + varname

        def test_add_locals(self):
            templar = self.Templar()

            globals = {
                'b' : 'bval',
            }

            locals = {
                'b' : 'blocval',
            }

            ansible_vars = AnsibleJ2Vars(templar, globals, locals)


# Generated at 2022-06-21 07:53:40.405622
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    import jinja2

    # Mock container class Templar
    templar = jinja2.Environment()

    # Prepare global variables
    globals = {
        'foo': 'bar',
        'a': 'b'
    }

    # Initialize the variable proxy
    j2_vars = AnsibleJ2Vars(templar, globals)

    # Test local variables
    locals = {
        'one': 'two',
        'three': 'four'
    }
    proxy = j2_vars.add_locals(locals)
    assert locals == proxy._locals

    # Test local variables
    locals = {
        'one': 'two',
        'three': 'four',
        'a': 'c'
    }

# Generated at 2022-06-21 07:53:49.701400
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.plugins.loader import vars_loader
    from ansible.template import Templar

    templar = Templar(loader=vars_loader)

    proxy = AnsibleJ2Vars(templar, dict(magic='globals'))
    assert 'magic' in proxy

    proxy = AnsibleJ2Vars(templar, dict(magic='globals'), locals=dict(voodoo='locals'))
    assert 'magic' in proxy
    assert 'voodoo' in proxy

    templar.available_variables = dict(charms='charms')
    proxy = AnsibleJ2Vars(templar, dict(magic='globals'), locals=dict(voodoo='locals'))
    assert 'magic' in proxy
    assert 'voodoo' in proxy
    assert 'charms' in proxy

# Generated at 2022-06-21 07:54:00.280816
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import safe_eval
    source = """
    #!/usr/bin/env python
    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars
    templar = Templar()
    globals = {'foo': 'somevalue'}
    locals = {'bar': 'anothervalue',
              'baz': 'yetanothervalue'}
    varsp = AnsibleJ2Vars(templar, globals)
    varsp = varsp.add_locals(locals=locals)
    """
    locals = {}
    result = safe_eval(source, locals=locals, include_exceptions=True)
    assert result[0] is None
    varsp = locals['varsp']
    assert varsp

# Generated at 2022-06-21 07:54:04.667563
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {}
    locals = {}
    var = AnsibleJ2Vars(templar, globals, locals)
    var['test'] = 'test'
    assert 'test' in var


# Generated at 2022-06-21 07:54:10.796955
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    jvars = AnsibleJ2Vars(Templar(), {})
    assert jvars["vars"] == {}
    assert jvars["vars"]["test"] is None
    assert jvars["vars"]["test"]["test"] is None
    assert jvars["vars"]["test"]["test"]["test"] is None


# Generated at 2022-06-21 07:54:23.639666
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Unit test the method __getitem__ of the class AnsibleJ2Vars.
    '''
    # Test the method __getitem__ of class AnsibleJ2Vars in normal case
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    templar = Templar(loader=None, variables=None)
    templar.available_variables = {'vars': {}, 'hostvars': {}}
    j2_vars = AnsibleJ2Vars(templar, {}, {})

    # Test the method __getitem__ of class AnsibleJ2Vars with parameter 'vars'
    value = j2_vars['vars']
    assert value == {}

    # Test the method __getitem__ of class AnsibleJ2Vars with parameter

# Generated at 2022-06-21 07:54:34.021759
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    print("Executing test_AnsibleJ2Vars___len__...")
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    vault_pass = "secret"

    inventory = InventoryManager(loader=None, sources=None, vault_password=None)
    host = Host("localhost")
    group = Group("local_group")
    group.add_host(host)
    inventory.add_group(group)

    variable_manager = VariableManager(loader=None, inventory=inventory)
    variable_manager.extra_vars = {'vault_password': vault_pass}
    variable_

# Generated at 2022-06-21 07:54:42.691908
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template.safe_eval import unsafe_eval

    templar = AnsibleUnsafeText
    var = AnsibleJ2Vars(templar, dict(host=HostVars('localhost')))
    var.set_available_variables(dict(a='a', b='b', c='c'))
    locals = dict(a='a', d='d')
    nvar = var.add_locals(locals)
    assert nvar['a'] == 'a'
    assert nvar['b'] == 'b'
    assert nvar['c'] == 'c'
    assert nvar['d'] == 'd'


# Generated at 2022-06-21 07:54:55.092383
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    import pytest

    templar = Templar(variables = dict())

    # Initialize j2vars object
    j2vars = AnsibleJ2Vars(templar = templar, globals = dict())

    # Check if value is not found
    with pytest.raises(KeyError) as excinfo:
        j2vars.__getitem__('missing')
    assert excinfo.value.args[0] == "undefined variable: missing"

    # Check if value is found in available variables

# Generated at 2022-06-21 07:55:02.548630
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    b = {"y":2, "z":3}
    a = {"a":1, "b":b}
    c = {"c":1, "b":b}

    vars = AnsibleJ2Vars(templar=None, globals=c, locals=a)
    assert 'c' in vars
    assert 'b' in vars
    assert 'a' in vars
    assert 'x' not in vars
    assert 'y' in vars
    assert 'z' in vars

# Generated at 2022-06-21 07:55:08.156303
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = 'Templar'
    globals = {}
    locals = {'one': 1, 'two': 2, 'three': 3}

    ajv = AnsibleJ2Vars(templar, globals)
    ajv = ajv.add_locals(locals)
    assert ajv._locals == locals

# Generated at 2022-06-21 07:55:19.588404
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import complex_args_to_dict
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=DataLoader(), variables=complex_args_to_dict(dict()))
    varmanager = VariableManager()

    host = Host(name='foo')
    varmanager.set_nonpersistent_facts(host, dict(l_a=1))

    all_vars = varmanager.get_vars(host=host)
    all_vars['template'] = host

    aj

# Generated at 2022-06-21 07:55:29.276518
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import json

    globals = { 'g_a': 1, 'g_b': 2 }
    locals = { 'l_a': 3, 'l_b': 4 }
    available_variables = { 'h_a': 5, 'h_b': 6 }

    class Templar:
        def __init__(self, globals, locals):
            self._globals = globals
            self._locals = locals

        def available_variables(self):
            return available_variables

    templar = Templar(globals, locals)
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    keys = list(j2vars.__iter__())
    result = {}

# Generated at 2022-06-21 07:55:40.636748
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vars_manager = VariableManager()
    templar = Templar(loader=None, variables=vars_manager)

    globals = dict(a=1)
    locals = dict(b=2)

    vars_manager.set_globals(globals)
    vars_manager.set_host_variable(host='host1', varname='c', value=3)

    test_vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in test_vars
    assert 'b' in test_vars
    assert 'c' in test_vars
    assert 'd' not in test_vars


# Generated at 2022-06-21 07:55:45.265241
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.template
    templar = ansible.template.Templar()
    j2vars = AnsibleJ2Vars(templar, {})
    j2vars_new = j2vars.add_locals({'key': 'value'})
    assert j2vars_new._locals == {'key': 'value'}

# Generated at 2022-06-21 07:56:02.998710
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class FakeTemplar():
        def __init__(self):
            self.available_variables = {'my_av_1': 'val1', 'my_av_2': 'val2'}
    class FakeTask():
        def __init__(self):
            self.environment = {'my_env_1': 'val3', 'my_env_2': 'val4'}
            self.args = {}
    t = FakeTemplar()
    task = FakeTask()
    vr = AnsibleJ2Vars(t, task.environment, locals=task.args)
    assert set(vr.__iter__()) == set(['my_av_1', 'my_av_2', 'my_env_1', 'my_env_2'])

# Generated at 2022-06-21 07:56:09.726107
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.templating import Templar
    templar = Templar(loader=None, variables={'foo': 'bar'})
    gb = AnsibleJ2Vars(templar, globals={})
    assert 'foo' in gb
    assert 'bar' not in gb

if __name__ == '__main__':
    plugin = AnsibleJ2Vars(templar, globals)
    assert 'foo' in plugin

# Generated at 2022-06-21 07:56:14.513477
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = {}
    locals = {'l_a': 'a', 'b': 'b'}

    m = AnsibleJ2Vars(templar, globals, locals)
    keys = set()
    for k in m:
        keys.add(k)

    assert len(keys) == 3, "Unexpected number of keys: %d" % len(keys)
    assert 'a' in keys, "'a' key is missing"
    assert 'b' in keys, "'b' key is missing"
    assert 'c' in keys, "'c' key is missing"


# Generated at 2022-06-21 07:56:25.483120
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars

    e = AnsibleError('foo')
    import types
    def _get_templar(wrapped_func, variable="{{ foo }}"):
        def fn(self, variable):
            return wrapped_func(self, variable)
        return types.MethodType(fn, e)

    e.template = types.MethodType(_get_templar(_return_variable), e)

    assert { 'foo': 'bar' } == AnsibleJ2Vars(e, {}, locals={'foo': 'bar'})
    assert { 'foo': 'bar' } == AnsibleJ2Vars(e, {'foo': 'bar'}, locals={})

    e.template = _get_templar(lambda self, variable: raise_AnsibleUndefinedVariable())
   

# Generated at 2022-06-21 07:56:33.498852
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """Test for AnsibleJ2Vars.__iter__ method.
    """

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(None)
    globals = {'test_globals': 'test_globals_val'}
    locals = {'test_locals': 'test_locals_val'}
    hostvars = HostVars({"localhost": {"test_hostvars": "test_hostvars_val"}})
    templar.available_variables = {'test_available_variables': 'test_available_variables_val', "hostvars": hostvars}

    j2 = AnsibleJ2Vars(templar, globals, locals)


# Generated at 2022-06-21 07:56:46.063329
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible.playbook.play_context
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.module_utils.facts.system import Distribution
    from ansible.utils.display import Display

    expected_distribution = Distribution(id='CentOS', major_version=7)
    display = Display()
    templar = Templar(variables={"test": "isok"}, display=display)
    globals = {"testglobal": "globalisok"}
    locals = {"aglobal": "a globals", "local": "a locals"}
    j2vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)



# Generated at 2022-06-21 07:56:55.532683
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    templar._available_variables = {'vars':'test'}

    j2_vars = AnsibleJ2Vars(templar, {}, {})
    j2_vars._templar.available_variables = {'vars':'test'}
    j2_vars['vars']

    temporary_host = HostVars()
    temporary_host = {"inventory_hostname":"localhost", "variable": "value"}
    j2_vars = AnsibleJ2Vars(templar, {}, locals=temporary_host)
    j2_vars['variable']

# Generated at 2022-06-21 07:57:03.072881
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    vars = AnsibleJ2Vars(templar, {})
    with pytest.raises(KeyError):
        vars['test']

    # Test with non-empty local vars
    vars = AnsibleJ2Vars(templar, dict(), dict(test=1))
    assert vars['test'] == 1

# Generated at 2022-06-21 07:57:13.109044
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Test method __getitem__ of class AnsibleJ2Vars.
    First test if dict is returned as-is when input is dict type.
    Next test if HostVars is returned as-is when input is HostVars
    type.
    Next test if object is returned as-is when it has the attribute
    __UNSAFE__.
    Last, test if templated version of the object is returned when
    object is not dict, HostVars or has the attribute __UNSAFE__.
    '''
    from ansible.vars.hostvars import HostVars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    test_templar = Templar('.')

# Generated at 2022-06-21 07:57:15.500972
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    _ = AnsibleJ2Vars(None, {}, {'myvar': 'myval'})

# Generated at 2022-06-21 07:57:35.638100
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    vars_obj = AnsibleJ2Vars(templar, dict(aaa=1), locals=dict(bbb=2))
    assert vars_obj.get('bbb') == 2
    assert vars_obj.get('aaa') == 1
    assert vars_obj.get('ccc') is None

# Unit tests for all methods of class AnsibleJ2Vars

# Generated at 2022-06-21 07:57:48.065345
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class DummyTemplar(object):
        available_variables = { 'var1': 'value1', 'var2': 'value2' }

    proxy = AnsibleJ2Vars(DummyTemplar(), globals={'global1': 'global1'}, locals={'local1': 'local1'})

    # test len when all 3 types of variables are present
    assert len(proxy) == 4

    # test when only locals present
    proxy2 = AnsibleJ2Vars(DummyTemplar(), globals={}, locals={'local1': 'local1'})
    assert len(proxy2) == 1

    # test when only globals present
    proxy3 = AnsibleJ2Vars(DummyTemplar(), globals={'global1': 'global1'}, locals={})

# Generated at 2022-06-21 07:57:56.671697
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    globals = {}
    templar = None
    vproxy = AnsibleJ2Vars(templar, globals)

    assert vproxy['template_host'] == "{{ template_host }}"

    # Test variable undefined
    try:
        vproxy['_undefined_var']
    except KeyError:
        pass
    else:
        assert False

    # Test variable on a host
    globals['template_host'] = 'template_host'
    assert vproxy['template_host'] == "template_host"

    # Test variable vars
    globals['vars'] = {'vars1': 'vars1', 'vars2': '{{ vars2 }}'}

# Generated at 2022-06-21 07:58:07.511775
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader, variables=dict())

    j2vars = AnsibleJ2Vars(templar, dict())

    assert len(j2vars) == 0

    templar._available_variables = dict(foo='bar', baz='qux')
    assert len(j2vars) == 2

    j2vars._templar._available_variables = dict(bar=None)
    assert len(j2vars) == 3

    j2vars._globals = dict(baz=None, qux=None)
    assert len(j2vars) == 5


# Generated at 2022-06-21 07:58:18.403254
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import copy
    hostvars = {'foo':'bar'}
    inj = {'lookup':'lookup', 'inventory_hostname':'inventory_hostname', 'group_names':'group_names'}
    imports = {'sys':'sys', 'json':'json'}
    templar = dict(available_variables=copy.deepcopy(hostvars), imports=copy.deepcopy(imports))
    templar['available_variables'].update(inj)
    templar['available_variables'].update(hostvars)
    templar['available_variables'].setdefault('inventory_hostname', 'inventory_hostname')
    templar['available_variables'].setdefault('group_names', 'group_names')

    vars_obj = AnsibleJ2

# Generated at 2022-06-21 07:58:18.943522
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass

# Generated at 2022-06-21 07:58:24.997704
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # '__iter__' function should return an iterator with all
    # keys from the three following sources:
    # 1. self._locals
    # 2. self._templar.available_variables
    # 3. self._globals
    mock_templar = {}
    mock_templar.available_variables = {'key1': 'value1'}
    mock_globals = {'key2': 'value2', 'key3': 'value3'}
    mock_locals = {'key4': 'value4'}
    obj = AnsibleJ2Vars(mock_templar, mock_globals, locals=mock_locals)


# Generated at 2022-06-21 07:58:37.048134
# Unit test for method add_locals of class AnsibleJ2Vars

# Generated at 2022-06-21 07:58:37.564693
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass


# Generated at 2022-06-21 07:58:39.248898
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = { 'test': 'globals' }

    j2_vars = AnsibleJ2Vars(templar, globals)

    assert 'test' in j2_vars



# Generated at 2022-06-21 07:59:04.496434
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars import AnsibleHostVars
    vl = VaultLib('foo')
    variable_manager = VariableManager()
    variable_manager.add_host_vars({'localhost': AnsibleHostVars(hostname='localhost', vault_password='foo')})
    variable_manager.add_group_vars('all', {'foo':'bar'})
    variable_manager.add_group_vars('all', {'bam':'boo'})

    templar = Templar(loader=None, variables=variable_manager)

# Generated at 2022-06-21 07:59:12.236029
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 42}

    mock_loader = DictDataLoader({
        'test.j2': 'test var has value {{ test_var }}'
    })

    jinja_environment = variable_manager.get_j2_environment()
    jinja_environment.loader = mock_loader

    templar = Templar(loader=mock_loader, variables=variable_manager)
    j2_var_proxy = AnsibleJ2Vars(templar, {})

    assert list(j2_var_proxy) == [u'test_var']

# Generated at 2022-06-21 07:59:17.174061
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    variable_manager = dict(hostvars=dict())
    templar = Templar(loader=None, variables=variable_manager)

    ansible_vars = AnsibleJ2Vars(templar, dict())
    ansible_vars['existing_variable'] = 'existing_value'
    assert 'existing_variable' in ansible_vars

# Generated at 2022-06-21 07:59:28.390093
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import copy
    import random
    import string
    from collections import OrderedDict

    class TestData:
        def __init__(self):
            self.data = None
            self.new_data = None
            self.data_keys = None
            self.data_values = None
            self.expected_result = None
            self.expected_result_keys = None
            self.expected_result_values = None
            self.item_keys = None
            self.item_values = None

        def _gen_random_str(self, length=12):
            chars = string.ascii_letters
            return ''.join([random.choice(chars) for i in range(length)])


# Generated at 2022-06-21 07:59:37.025471
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # This test is only executed when running this module in stand alone mode
    def dict_with_missing(d):
        if isinstance(d, dict):
            return dict(('k_' + k, dict_with_missing(v)) for k, v in d.items())
        else:
            return missing

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host

    variable_manager = VariableManager()
    variable_manager.set_host_variable(Host("testhost"), "testhostvar", 42)
    variable_manager.set_host_variable(Host("testhost"), "testhostvar2", dict(a=dict(b=42, c=dict(d=43)), e='foobar'))

# Generated at 2022-06-21 07:59:43.163524
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = type('Templar', (object,), {})()
    templar.available_variables = {'a': 1, 'b': 2}
    j2vars = AnsibleJ2Vars(templar, {'c': 3, 'd': 4})

    assert list(j2vars) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-21 07:59:53.819423
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Create an empty dict and a dict with one key
    empty_dict = dict()
    one_key_dict = dict()
    one_key_dict["one_key"] = 1

    from ansible.plugins.loader import plugin_loader
    templar = plugin_loader.get('template_loader').get('templar')
    ansible_j2vars = AnsibleJ2Vars(templar, one_key_dict)

    # Test with an empty dict
    result = len(AnsibleJ2Vars(templar, empty_dict))
    assert(result == 0)

    # Test when the dict has one key
    result = len(ansible_j2vars)
    assert(result == 1)



# Generated at 2022-06-21 08:00:04.513935
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestModule:
        pass

    module_vars = dict(a="a")
    global_vars = dict(b="b")
    host_vars = dict(c="c")
    playbook_vars = dict(d="d")
    play_vars = dict(e="e")
    task_vars = dict(f="f")
    templar = Templar(basedir=None, loader=None, variables=global_vars)

    test_module = TestModule()
    test_module._hostvars = host_vars
    test_context = PlayContext()
    test_context.play = playbook_vars
    test_context.hostvars = module_vars
    test_context.v

# Generated at 2022-06-21 08:00:11.447334
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    mock_templar = "mock_templar"
    mock_globals = "mock_globals"
    mock_locals = "mock_locals"
    vars = AnsibleJ2Vars(mock_templar,mock_globals,mock_locals)
    assert vars._templar == mock_templar
    assert vars._globals == mock_globals
    assert vars._locals == mock_locals


# Generated at 2022-06-21 08:00:17.800907
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.template import Templar

    templar = Templar(loader=None)
    vars = {'foo': 'bar', 'baz': 'qux'}

    v = AnsibleJ2Vars(templar, {}, locals=vars)
    assert v.add_locals({'fez': 'norf'})['fez'] == 'norf'

# Generated at 2022-06-21 08:00:57.042257
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    Test whether the method __iter__ of class AnsibleJ2Vars works as expected.

    This test is not parameterized because it tests the internal implementation of __iter__,
    not its results.

    A major point is to test the use of "set" in __iter__ to only use distinct values from the
    different variables, as this could be impacted by Ansible changes.

    :returns: assertion error if __iter__ does not behave as expected
    :rtype: None
    '''

    # Define the input variables
    g = {'a': 1, 'b': 2, 'c': 3}
    l = {'x': 4, 'y': 5, 'z': 6}
    v = dict(g, **l)
    templar = object()

    # Test __iter__
    av = AnsibleJ2