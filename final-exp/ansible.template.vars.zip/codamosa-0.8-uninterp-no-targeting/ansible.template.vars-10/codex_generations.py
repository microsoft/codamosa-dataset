

# Generated at 2022-06-21 07:51:10.693435
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible import templar
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    import copy

    dict_ = dict()
    dict_["playbook_dir"] = "/tmp/"
    dict_["inventory_dir"] = "/tmp/hosts"
    dict_["group_names"] = ["g1", "g2", "g3"]
    dict_["groups"] = dict()
    dict_["groups"]["g1"] = dict()
    dict_["groups"]["g1"]["hosts"] = ["host1", "host2", "host3"]
    dict_["groups"]["g2"] = dict()
    dict_["groups"]["g2"]["hosts"] = ["host4", "host5", "host6"]
    dict

# Generated at 2022-06-21 07:51:22.217891
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import ansible.module_utils.jinja2_utils
    from ansible.playbook.play_context import PlayContext
    test_play_context = PlayContext()
    test_AnsibleJ2Vars = ansible.module_utils.jinja2_utils.AnsibleJ2Vars(test_play_context, {})

    assert isinstance(test_AnsibleJ2Vars, dict)
    test_dict = dict()
    for key in test_AnsibleJ2Vars:
        test_dict[key] = test_AnsibleJ2Vars[key]
    assert len(test_dict) == 0
    assert len(test_AnsibleJ2Vars) == 0
    assert test_dict == test_AnsibleJ2Vars

    test_play_context.extra_vars

# Generated at 2022-06-21 07:51:33.725733
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar
    from ansible.template.static_loader import StaticLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class DummyTemplar(Templar):
        def __init__(self, loader, variables):
            self.loader = loader
            self.available_variables = variables

        def template(self, variable, convert_bare=False, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True):
            return variable

    ############################################################################
    # test_AnsibleJ2Vars___getitem__.__getitem__:
    ############################################################################

# Generated at 2022-06-21 07:51:44.195554
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.playbook.templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.reserved import Reserved

    A_STRING_1 = 'a string'
    A_STRING_2 = 'a different string'
    A_DICT = {
        'one': 1,
        'two': 2,
    }

    def __test_AnsibleJ2Vars___getitem__(test):
        variables = {
            'a_string': A_STRING_1,
            'a_dict'  : A_DICT,
        }
        templar = ansible.playbook.templar.Templar(loader=None, variables=variables)

        j2vars

# Generated at 2022-06-21 07:51:55.775817
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    # setup
    globals = dict(
        g1='g1',
        g2='g2'
    )
    # locals will be overridden by locals1
    locals_dict = dict(
        l1='l1',
        l2='l2'
    )
    local_vars = dict(
        vars = locals_dict
    )
    locals1 = dict(
        l1='locals 1',
        l2='l2'
    )
    locals2 = dict(
        l1='l1',
        l3='l3'
    )
    templar = jinja2.Environment().from_string('{{ l1 }}').new_context()

# Generated at 2022-06-21 07:52:04.109527
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    globals = dict(a=dict(b=1))
    locals = dict(x=dict(y=2), z=3)
    templar = mock_templar()
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 5
    assert 'a' in vars
    assert 'x' in vars
    assert 'z' in vars
    assert 'b' in vars
    assert 'y' in vars


# Generated at 2022-06-21 07:52:13.797061
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # given: AnsibleJ2Vars with 'a' and 'b' local variables
    o = AnsibleJ2Vars(None, None, locals={'a': 1, 'b': 2})
    # when: add locals with 'c' and 'd'
    # then: must not alter original object
    d = o.add_locals({'c': 3, 'd': 4})
    assert d is not o
    # and: AnsibleJ2Vars must have 'a', 'b', 'c', and 'd' locals
    assert set(d._locals.keys()) == {'a', 'b', 'c', 'd'}

# Generated at 2022-06-21 07:52:22.404950
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    templar = Templar()
    globals = { 'a': 1, 'b': 2 }

    # HostVar should be return as-is
    hostvars = HostVars({'a': 1, 'b': 2})
    vars = AnsibleJ2Vars(templar, globals)
    assert vars['vars'] == hostvars
    assert vars.__getitem__('vars') == hostvars

    # when globals is None, vars is empty
    vars = AnsibleJ2Vars(templar, globals=None)
    assert len(vars) == 0

    # when globals is dict, vars has the globals
    vars = AnsibleJ2Vars

# Generated at 2022-06-21 07:52:24.249168
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-21 07:52:31.710152
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    # The test code for method __iter__ of class AnsibleJ2Vars is taken from
    # the end of the function AnsibleJ2Vars in ansible/template/__init__.py.
    j2vars = AnsibleJ2Vars(
        Templar(None),
        {},
        locals={
            'l_names': ['alice', 'bob', 'john'],
        })
    assert list(iter(j2vars)) == list(iter(set(['names', 'l_names'])))

# Generated at 2022-06-21 07:52:45.556089
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = object()
    globals = {'gk1': 'gv1', 'gk2': 'gv2', 'gk3': 'gv3'}
    locals = {'lk1': 'lv1', 'lk2': 'lv2', 'lk3': 'lv3'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    keys = list(vars)
    assert len(keys) == 6
    assert set(keys).intersection(globals.keys()) == set(globals.keys())
    assert set(keys).intersection(locals.keys()) == set(locals.keys())


# Generated at 2022-06-21 07:52:56.732339
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = { 'somedict': {'foo': 'bar'},
                'somevalue': 'bar' }
    locals = { 'somevalue': 'loo',
               'l_foo': 'bar' }
    vars = AnsibleJ2Vars(templar, globals, locals=locals)
    for key in globals:
        assert(key in vars)
    for key in locals:
        assert(key in vars)
    assert('somedict' in vars)
    assert('vars' in vars)
    assert('hostvars' in vars)
    # When using with dict, 'l_foo' is not in vars
    assert('l_foo' not in vars)


# Unit

# Generated at 2022-06-21 07:53:07.396948
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.unsafe_proxy import wrap_var, UnsafeProxy
    from ansible.template import Templar

    from ansible.vars import combine_vars
    from ansible.playbook.play_context import PlayContext

    templar = Templar(loader=None)

    combine_vars(play_context=PlayContext(), loader=None, template=templar)

    globals_ = {'foo': 'bar', 'baz': 'qux'}
    locals_ = {'moo': 'milk', 'cow': 'moo'}
    proxy = AnsibleJ2Vars(templar=templar, globals=globals_, locals=locals_)

    # Test variable with value string
    var = 'foo'
    assert var in proxy

# Generated at 2022-06-21 07:53:16.621120
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    class Templar():
        def __init__(self):
            self.available_variables = {"test_key": "test_value"}

    templar = Templar()
    globals = {"global_key": "global_value"}
    locals = {"local_key": "local_value"}
    context = AnsibleJ2Vars(templar, globals, locals)

    for value in context.__iter__():
        assert value in ["local_key", "global_key", "test_key"]
    else:
        assert False, "no iteration over __iter__()"

# Generated at 2022-06-21 07:53:26.349208
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {}
    locals = {'context': 'context'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    # test get from globals
    globals['var'] = 'global'
    assert j2vars['var'] == 'global'
    # test get from locals
    locals['local'] = 'local'
    assert j2vars['local'] == 'local'
    # test get from templar
    templar.available_variables = {'test': safe_eval('test')}
    assert j2vars['test'] == 'test'
    # test KeyError

# Generated at 2022-06-21 07:53:38.779950
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play.load(dict(name="test"), variable_manager=variable_manager, loader=loader)

    # play defines a hostvars dict, which will be merged into the globals
    globals = { "test_global_key": "test_global_value" }
    locals = { "test_local_key": "test_local_value" }

    templar = Templar(loader=loader, variables=variable_manager)

    aj2v = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-21 07:53:48.637280
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    vars = {
        'a': 'A',
        'b': '{{ c }}',
        'c': '{{ d }}',
        'd': 'D',
    }
    j2vars = AnsibleJ2Vars(templar, vars)
    assert j2vars['b'] == 'D'

    locals = {
        'c': 'C',
    }
    j2vars = j2vars.add_locals(locals)
    assert j2vars['b'] == 'C'

    locals = {
        'a': 'a',
    }
    j2vars = j2vars.add_locals(locals)

# Generated at 2022-06-21 07:53:58.453720
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class Templar:
        available_variables = {'key1': {}}

    Globals = {}
    locals_ = {'key2': {}}
    vars_ = AnsibleJ2Vars(Templar, Globals, locals_)

    if 'key1' not in vars_:
        raise AssertionError("The key 'key1' should be found in AnsibleJ2Vars")
    if 'key2' not in vars_:
        raise AssertionError("The key 'key2' should be found in AnsibleJ2Vars")
    if 'key3' in vars_:
        raise AssertionError("The key 'key3' should not be found in AnsibleJ2Vars")


# Generated at 2022-06-21 07:54:09.377237
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.safe_eval import AnsibleJ2Vars as SafeJ2Vars
    from ansible.template.safe_eval import Templar
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader

    test_dataset = dict(
        hostvars=dict(
            host1=dict(
                ansible_host='192.168.1.1'
            )
        ),
        variables=dict(
            galaxy=dict(
                star=dict(
                    sun_mass=1000
                )
            )
        ),
        jinja_globals=dict(
            len=len,
            range=range
        )
    )


# Generated at 2022-06-21 07:54:17.339055
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None, variables=dict(var1='test'))
    globals = dict(glo1='test2')

    vars = AnsibleJ2Vars(templar, globals, locals=None)
    text = vars['var1']
    assert(text == 'test')

    vars = AnsibleJ2Vars(templar, globals, locals=dict(var2='test2'))
    text = vars['var2']
    assert(text == 'test2')

    vars = AnsibleJ2Vars(templar, globals, locals=dict(var1='test3'))
    text = vars['var1']

# Generated at 2022-06-21 07:54:31.529250
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    
    mock_variables = {
    }

    # No locals
    mock_globals = {}
    mock_locals = {}
    var_proxy = AnsibleJ2Vars(Templar(variables=mock_variables), mock_globals, locals=mock_locals)
    assert list(var_proxy.__iter__()) == list(mock_variables)

    # locals with different values
    mock_globals = {}
    mock_locals = {'test': 'value'}
    var_proxy = AnsibleJ2Vars(Templar(variables=mock_variables), mock_globals, locals=mock_locals)

# Generated at 2022-06-21 07:54:37.881372
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = 'templat'
    globals = {'g_key': 'g_val'}
    locals = {'l_key': 'l_val'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    exception_msg = 'undefined variable: no_var'
    try:
        j2vars.__getitem__('no_var')
    except KeyError as e:
        assert str(e) == exception_msg

# Generated at 2022-06-21 07:54:44.643469
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.playbook.play
    import ansible.template.template
    import ansible.template.templar

    def _mock_templar_available_variables_getitem(self, item):
        if item in ('var_a', 'var_b', 'var_c'):
            return item
        raise KeyError()

    def _mock_templar_template(self, data):
        return data

    # Mock AnsibleJ2Vars
    AnsibleJ2Vars._templar.available_variables.__getitem__ = _mock_templar_available_variables_getitem
    AnsibleJ2Vars._templar.template = _mock_templar_template

    # Create a AnsibleJ2Vars object

# Generated at 2022-06-21 07:54:56.048858
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Unit test for method __iter__ of class AnsibleJ2Vars
    # set up objects
    j2vars = AnsibleJ2Vars(None, {'globals1': True, 'globals2': False})
    j2vars._locals.update({'local1': 3, 'local2': 5.3})
    j2vars._templar.available_variables.update({'var1': None, 'var2': 'foo'})
    placeholders = ['local1', 'local2', 'globals1', 'globals2', 'var1', 'var2']
    assert sorted(list(j2vars.__iter__())) == sorted(placeholders)


# Generated at 2022-06-21 07:55:07.205808
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import pytest
    from ansible.template import Templar
    templar = Templar(loader=None)
    vars = AnsibleJ2Vars(templar, globals={}, locals={})

    # Test key in locals
    vars._locals = {'key':'value'}
    assert vars['key'] == 'value'

    # Test key in globals
    vars._globals = {'key':'value'}
    assert vars['key'] == 'value'

    # Test key not in locals and not in globals
    with pytest.raises(KeyError) as e:
        vars['key']
    assert to_native(e.value) == "undefined variable: key"


# Generated at 2022-06-21 07:55:18.490574
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Unittest for method AnsibleJ2Vars.add_locals
    '''
    import unittest
    import copy

    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var

    class TestJ2Vars(unittest.TestCase):
        '''
        Test class for AnsibleJ2Vars.add_locals method
        '''

        def test_no_locals(self):
            '''
            Test method for AnsibleJ2Vars.add_locals with no locals

            :return:
            '''
            test_obj = AnsibleJ2Vars({}, {})
            self.assertEquals(test_obj.add_locals(None), test_obj)


# Generated at 2022-06-21 07:55:26.552312
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    # Test initialization of a Templar object

# Generated at 2022-06-21 07:55:33.230493
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert AnsibleJ2Vars(None, {}).__len__() == 0
    assert AnsibleJ2Vars(None, {}, locals=dict()).__len__() == 0
    assert AnsibleJ2Vars(None, {}, locals=dict(one=1)).__len__() == 1
    assert AnsibleJ2Vars(None, {}, locals=dict(one=1, two=2)).__len__() == 2



# Generated at 2022-06-21 07:55:44.222825
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
  from ansible.parsing.vault import VaultLib
  from ansible.template import Templar
  from ansible.vars.manager import VariableManager
  from ansible.vars.hostvars import HostVars
  import os
  variable_manager = VariableManager()
  variable_manager.extra_vars = {'test_decrypt_variable': 'test'}
  variable_manager.extra_vars['test_decrypt_variable'] = VaultLib().encrypt("test")
  variable_manager.extra_vars['ansible_python_interpreter'] = "/usr/bin/python"
  variable_manager.extra_vars['ansible_connection'] = "ssh"
  variable_manager.extra_vars['ansible_ssh_user'] = "ubuntu"

# Generated at 2022-06-21 07:55:47.347096
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    import os

    templar = Templar(loader=None)
    j2_vars = AnsibleJ2Vars(templar, globals=dict())
    assert os in j2_vars

# Generated at 2022-06-21 07:56:01.418948
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template.template import Templar
    templar = Templar(None, loader=None)
    proxy = AnsibleJ2Vars(templar, None, None)
    as_mapping_instance = AnsibleMapping()
    as_mapping_instance['key'] = 'value'
    assert proxy['vars'] == dict()
    assert proxy['hostvars'] == dict()
    assert proxy['inventory_hostname'] == ''
    assert proxy['groups'] == dict()
    assert proxy['key'] == 'value'
    assert proxy['as_mapping_instance'] == as_mapping_instance

# Generated at 2022-06-21 07:56:13.174876
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.utils.vars import combine_vars

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar

    plain_text = '{"hello": "world", "this": "is plaintext"}'
    cipher_text = VaultLib().encrypt(plain_text)
    plain_data = {'hello': 'world', 'this': 'is plaintext'}
    vaulted_data = {'hello': 'world', 'this': AnsibleVaultEncryptedUnicode(cipher_text)}

    templar = Templar(loader=None)

    def get(data, key, expected, expected_type=None, expected_class=None):
        data_vars = AnsibleJ

# Generated at 2022-06-21 07:56:25.096529
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    play_context = PlayContext()
    # Log the exception to stdout instead of raising
    play_context._log_exception = lambda exception: print(exception)
    templar = Templar(loader=None, variables={}, shared_loader_obj=None, play_context=play_context)
    ansible_vars = AnsibleJ2Vars(templar, {}, locals={'test_locals': 2})
    assert ansible_vars.add_locals({'test_local': 1})['test_local'] == 1
    assert ansible_vars.add_locals({'test_local': 1})['test_locals'] == 2

# Generated at 2022-06-21 07:56:33.308440
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.templating import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {'g_a': 'a', 'g_b': 'b'}
    locals = {'l_a': 'a', 'l_b': 'b'}

    v = AnsibleJ2Vars(templar, globals, locals)
    v.update(vars(locals=locals))

    assert (v['l_a'] == 'a')
    assert (v['l_b'] == 'b')
    assert (v['g_a'] == 'a')
    assert (v['g_b'] == 'b')

# Generated at 2022-06-21 07:56:41.297407
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    globals = dict()
    locals = dict()
    ajv = AnsibleJ2Vars(templar, globals, locals)

    assert("blah" not in ajv)
    templar.available_variables["blah"] = "test"
    assert("blah" in ajv)



# Generated at 2022-06-21 07:56:52.130512
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.templating import Templar
    templar = Templar(loader=None, variables=None)
    j2vars = AnsibleJ2Vars(templar, {'x': 1, 'y': 2, 'z': 3}, locals={'z': 4, 'w': 5})
    # locals={} should not change anything
    j2vars_new = j2vars.add_locals({})
    assert j2vars_new._locals == j2vars._locals
    # locals={'y': 6, 'w': 7} should change 'w' and 'y'
    j2vars_new = j2vars.add_locals({'y': 6, 'w': 7})

# Generated at 2022-06-21 07:56:58.577693
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from collections import Iterable
    from ansible.vars.hostvars import HostVars
    templar = Samaritan(available_variables={'var1': 'val1', 'var2': 'val2'})
    # test iter with globals and locals
    globals = {'glob1': 'glob1', 'glob2': 'glob2'}
    locals = {'local1': 'val1', 'local2': 'val2'}
    j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert isinstance(j2_vars.__iter__(), Iterable)
    assert j2_vars.__iter__() == set(['local1', 'local2', 'glob1', 'glob2', 'var1', 'var2'])


# Generated at 2022-06-21 07:57:10.460200
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    Test simple case of __len__
    """
    imp_mock_templar = AnsibleMockTemplar()
    imp_mock_jinja2env = AnsibleMockJinja2Env()
    imp_mock_jinja2env.globals = {'g_1': 'g1', 'g_2': 'g2', 'g_3': 'g3'}

    aj2v = AnsibleJ2Vars(templar=imp_mock_templar, globals=imp_mock_jinja2env.globals)
    assert len(aj2v) == 3

    imp_mock_templar.available_variables = {'av1': 'av1', 'av2': 'av2', 'av3': 'av3'}


# Generated at 2022-06-21 07:57:21.312864
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # The initial value of attribute _templar
    assert hasattr(AnsibleJ2Vars(1, 2), '_templar')
    assert(AnsibleJ2Vars(1, 2)._templar == 1)
    # The initial value of attribute _globals
    assert hasattr(AnsibleJ2Vars(1, 2), '_globals')
    assert(AnsibleJ2Vars(1, 2)._globals == 2)
    # The initial value of attribute _locals
    assert hasattr(AnsibleJ2Vars(1, 2), '_locals')
    assert(AnsibleJ2Vars(1, 2)._locals == {})
    # Test the update of attribute _locals

# Generated at 2022-06-21 07:57:33.112728
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    pc = PlayContext()
    vars_manager = VariableManager()
    templar = Templar(loader=None, variables=vars_manager)
    aj2v = AnsibleJ2Vars(templar, {}, {'a':1, 'b':2, 'c':3, 'd':4})
    new_locals = {'a':1, 'b':2, 'c':3, 'd':4, 'e':5}
    pc.vars_dict = {'a':1, 'b':2, 'c':3, 'd':4, 'e':5, 'f':6}

# Generated at 2022-06-21 07:57:50.408882
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = []
    globals = {'g1':'g1val', 'g2':'g2val'}
    locals = {'l1':'l1val', 'l2':'l2val'}

    aj2v = AnsibleJ2Vars(templar, globals, locals)

    return (aj2v.__contains__('g1'), aj2v.__contains__('l1'),
            aj2v.__contains__('g2'), aj2v.__contains__('l2'),
            aj2v.__contains__('xxx')) == (True, True, True, True, False)


# Generated at 2022-06-21 07:57:58.025000
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    m = AnsibleJ2Vars(Templar(PlayContext()), {
                       'one': 1, 'two': 2}, {'three': 3, 'four': 4})
    assert len(m) == 4
    assert sorted([i for i in m]) == ['four', 'one', 'three', 'two']



# Generated at 2022-06-21 07:58:10.198949
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import safe_eval

    templar = safe_eval
    globals = {
        'myglobal': {
            'key': 'value'
        }
    }
    locals = {
        'mylocal': {
            'key': 'value'
        }
    }
    proxy = AnsibleJ2Vars(templar, globals, locals)

    assert {
        'myglobal': {
            'key': 'value'
        },
        'mylocal': {
            'key': 'value'
        }
    } == proxy

    new_locals = {
        'mylocal': {
            'key': 'new value'
        },
        'anotherlocal': {
            'key': 'value'
        }
    }

    proxy = proxy.add_locals

# Generated at 2022-06-21 07:58:10.831602
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert True

# Generated at 2022-06-21 07:58:20.303605
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Testing __getitem__
    #
    # -- NOTE --
    # This unit test is incomplete! It will test only that __getitem__
    # raises an KeyError when expected.
    from jinja2.runtime import Undefined
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar

    # Setup a Templar for use by the AnsibleJ2Vars object.
    templar = Templar(loader=None, variables=dict())

    # Setup dictionaries for globals, vars and registers.
    globals = dict(
        AnsibleUndefinedVariable=AnsibleUndefinedVariable,
    )
    vars = dict(
        foo='1',
        bar='2',
    )
    registers = dict(
        foo='3',
        bar='4',
    )

    aj

# Generated at 2022-06-21 07:58:30.772573
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # class Templar
    class Templar:
        template = lambda self, var: var

    # class VariableError
    class VariableError(AnsibleUndefinedVariable):
        pass

    # class AnsibleJ2Vars
    class AnsibleJ2Vars:
        def __init__(self, templar, globals, locals=None): pass

    locals = { "key1": "value1" }
    globals = { "key2": "value2", "key3": "value3" }

    template = Templar()
    locals = locals
    globals = globals

    # expected
    expected = True, "value2"

    # actual
    actual = AnsibleJ2Vars(template, globals, locals).__contains__("key2"), AnsibleJ2Vars(template, globals, locals).__getitem__

# Generated at 2022-06-21 07:58:39.834631
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    cla = AnsibleJ2Vars
    ansible_j2_vars_obj = cla(None, None, None)
    dict_output = dict(ansible_j2_vars_obj)
    keys_set = set(ansible_j2_vars_obj)
    keys_set.update(ansible_j2_vars_obj)
    for j in iter(ansible_j2_vars_obj):
        assert j in dict_output
        assert j in keys_set
        assert j in 'ansible_j2_vars_obj'


# Generated at 2022-06-21 07:58:47.226396
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    # This is really an integration test, not a unit test.
    # For the purposes of these tests, we'll assume that
    # everything iterator over in these cases should be
    # a string.
    myhost = Host(name='myhost')
    group = Group(name='mygroup')

    group.add_host(myhost)
    group.set_variable('foo', 'bar')

    # allVars is a dict containing a host_vars and group_vars
    # of all variables for all hosts, as well as all group
    # variables for all groups, including for the group
    # mygroup above.
    allVars = {}
    varM

# Generated at 2022-06-21 07:58:56.377554
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleMapping

    templar = Templar(loader=None)

    j2_vars = AnsibleJ2Vars(templar, {'ansible_connection': 'local'}, {'role_name': 'example'})

    assert j2_vars['role_name'] == 'example'

    it = iter(j2_vars)
    assert 'role_name' in it

    it = iter(j2_vars)
    assert 'ansible_connection' in it



# Generated at 2022-06-21 07:59:07.362131
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert AnsibleJ2Vars({}, {}).__contains__(None) == False
    assert AnsibleJ2Vars({}, {}).__contains__(True) == False
    assert AnsibleJ2Vars({}, {}).__contains__(3) == False
    assert AnsibleJ2Vars({}, {})['test_contains'] == True
    assert AnsibleJ2Vars({}, {'test_contains': True, 'test_contains2': False})['test_contains'] == True
    assert AnsibleJ2Vars({'test_contains': True}, {})['test_contains'] == True
    assert AnsibleJ2Vars({'test_contains': True}, {'test_contains2': False})['test_contains'] == True

# Generated at 2022-06-21 07:59:32.561080
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import os

    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.playbook.task
    import ansible.playbook.template

    class MockTemplar(object):
        def __init__(self):
            self.available_variables = dict()

        def template(self, variable):
            return variable

    templar = MockTemplar()

    class MockPlay(ansible.playbook.play.Play):
        def __init__(self):
            self._ds = dict()

    class Task(ansible.playbook.task.Task):
        def __init__(self, play):
            self._play = play

    class PlayContext(ansible.playbook.play_context.PlayContext):
        def __init__(self, path):
            self._

# Generated at 2022-06-21 07:59:39.206136
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Note that this test is not strictly necessary.
    But by testing method add_locals we ensure that no accidental code changes break
    the working code and thus silently break the ansible playbooks.
    '''

    import ansible.vars
    ansible_vars = ansible.vars.VarsModule()

    templar = ansible.vars.Templar(loader=None)
    locals = {'a': 1, 'b': 2}

    ansible_j2vars = AnsibleJ2Vars(templar, ansible_vars.get_vars(loader=None, play=None), locals=locals)
    assert ansible_j2vars['a'] == 1
    assert ansible_j2vars['b'] == 2


# Generated at 2022-06-21 07:59:39.832482
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
	pass

# Generated at 2022-06-21 07:59:46.611623
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # ansible.vars.hostvars.HostVars is a subclass of dict
    assert issubclass(ansible.vars.hostvars.HostVars, dict)
    # AnsibleJ2Vars is a subclass of dict
    assert issubclass(AnsibleJ2Vars, dict)
    # AnsibleJ2Vars is a subclass of collections.Mapping
    assert issubclass(AnsibleJ2Vars, Mapping)

# Generated at 2022-06-21 07:59:56.916083
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.module_utils.six import BytesIO
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.parsing.quoted import quoted_tokenize
    from ansible.utils.vars import combine_vars

    templar = Templar(loader=None, variables=combine_vars(loader=None, variables={}), cb_fail_on_undefined=None, fail_on_undefined=None)

# Generated at 2022-06-21 08:00:09.080251
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar()
    # Init case with no locals
    vars = AnsibleJ2Vars(templar, {}, {})
    # Try to add some locals
    vars_locals = vars.add_locals()
    assert (len(vars) == len(vars_locals))
    # Init case with locals
    vars = AnsibleJ2Vars(templar, {}, {"foo": "bar"})
    # Try to add some locals
    vars_locals = vars.add_locals()
    assert (len(vars) == len(vars_locals))
    # Try to add some locals
    vars_locals = vars.add_locals({'bar': 'foo'})

# Generated at 2022-06-21 08:00:21.326465
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    t = Templar(loader=None, variables={'test_variable': 'test_value'})
    v = AnsibleJ2Vars(t, {})
    assert 'test_variable' in v
    assert v['test_variable'] == 'test_value'

###############################################################
# method overrides for the Mapping class, which
# allows objects of this class to behave like dictionaries
# for the purposes of jinja2.  This is done so that the vars
# can be used in the template directly, but the variables
# inside are templated before being used, so that variable
# names and strings can contain jinja2.  We use the low level
# __contains__, __getitem__, etc... to avoid potential recursion
###############################################################

#    def __del

# Generated at 2022-06-21 08:00:29.869776
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import safe_eval

    # pylint: disable=line-too-long

# Generated at 2022-06-21 08:00:41.573601
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible import errors
    from ansible.template import Templar

    class AnsibleUndefinedVariableClass(errors.AnsibleUndefinedVariable):
        pass

    """
    Test with missing variable
    """
    key = "UNDEFINED_VARIABLE"
    templar = Templar(None)
    globals = dict()
    locals = dict()
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    with pytest.raises(KeyError):
        ansible_j2_vars.__getitem__(key)

    """
    Test with a non dict variable
    """
    key = "DEFINED_VARIABLE"
    value = "defined_variable"
    templar = Templar(None)
    templar.available_

# Generated at 2022-06-21 08:00:46.216421
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # init
    class mock_templar:
        available_variables = ['var1', 'var2', 'var3']

    globals = ['global1', 'global2']

    locals = {'local1': 'value1', 'local2': 'value2'}

    vars = AnsibleJ2Vars(mock_templar, globals, locals)

    # assert
    assert len(vars) == 5

