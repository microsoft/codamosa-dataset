

# Generated at 2022-06-21 07:50:58.441661
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    assert True

# Generated at 2022-06-21 07:51:10.692352
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import json
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # create a HostVars
    hostvars = HostVars(vars={'test': 1})

    # create a AnsibleUnsafeText
    unsafe_text = AnsibleUnsafeText(text="test unsafe text")

    # create a templar
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    vault_secrets = VaultLib([], None)
    variables = {'test_vars_variable': 'test vars variable'}
    play_context = PlayContext()

# Generated at 2022-06-21 07:51:23.645468
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    #  verifications=verifications
    templar = Templar(loader=None, variables={}, shared_loader_obj=None)
    #  templar._available_variables
    globals = {}
    #  locals
    vars = AnsibleJ2Vars(templar=templar, globals=globals, locals={})

    #  simple valid call to __getitem__
    #  print vars['xyz']
    #  simple invalid call to __getitem__
    #  print vars['xyz']
    assert vars.get('available_variables') is not None

    # valid call to __getitem__ returning a dict
    assert isinstance(vars['vars'], dict)

# Generated at 2022-06-21 07:51:30.556058
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import copy
    import jinja2

    def _dict(**kwargs):
        return kwargs

    def _value(value):
        return value
    from ansible.template.safe_eval import safe_eval

    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Test with jinja2 vars
    templar = jinja2.Environment()
    vars = AnsibleJ2Vars(templar, _dict(a=1, b=2, c=3))
    assert set(vars) == set(['a', 'b', 'c'])

    # Test with available variables
    templar = jinja2.Environment()

# Generated at 2022-06-21 07:51:39.708424
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    import ansible.template.safe_eval

    templar = ansible.template.safe_eval.AnsibleTemplar()
    vars = AnsibleJ2Vars(templar, globals=None, locals=None)
    assert not ('foo' in vars)
    vars._locals['foo'] = 'bar'
    assert ('foo' in vars)
    vars._templar.available_variables['foo'] = 'bar'
    assert ('foo' in vars)
    vars._globals['foo'] = 'bar'
    assert ('foo' in vars)

# Generated at 2022-06-21 07:51:47.934481
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import merge_hash
    from ansible.template.vars import AnsibleJ2Vars

    hostvars = HostVars(dict(a=1, b=2))
    variables = dict(c=dict(d=3))
    merged = merge_hash(variables, hostvars)
    merged = AnsibleUnsafeText(merged)
    templar = Templar(loader=None, variables=merged)
    ansible_j2_vars = AnsibleJ2Vars(templar, dict(e=4), locals=merged)
    assert len(ansible_j2_vars) == 4

# Generated at 2022-06-21 07:51:53.981211
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    vars_manager = VariableManager(loader=loader)
    templar = Templar(loader=loader, variables=vars_manager)

    ajv = AnsibleJ2Vars(templar, dict())

# Generated at 2022-06-21 07:52:04.893574
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class Templar(object):
        def __init__(self, vars):
            self.available_variables = vars
        def template(self, v):
            return v

    from ansible.utils.unsafe_proxy import wrap_var

    vars_ = { 1: wrap_var(1), 2: wrap_var(2), 3 : wrap_var(3) }
    templar = Templar(vars_)
    vars_j2 = AnsibleJ2Vars(templar, {})

    assert 1 in vars_j2
    assert 2 in vars_j2
    assert 3 in vars_j2
    assert 4 not in vars_j2


# Generated at 2022-06-21 07:52:15.739258
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    from unit.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    fake_loader = DictDataLoader({})
    fake_variable_manager = VariableManager()
    fake_inventory = None
    fake_play_context = PlayContext()
    fake_templar = Templar(fake_loader, fake_variable_manager, fake_play_context)

    globals = {'foo': 'foo'}
    locals = {'bar': 'bar'}

    proxy = AnsibleJ2Vars(fake_templar, globals, locals)

    assert len(proxy) == 2



# Generated at 2022-06-21 07:52:23.452338
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from tests.unit.parsing.dataloader import load_fixture
    from ansible.template import Templar

    templar = Templar(variables=load_fixture('var_expansion_success.yml'))
    templar._available_variables = templar.available_variables
    j2_vars = AnsibleJ2Vars(templar=templar, globals={}, locals={})

    assert 'myvar' in j2_vars
    assert 'evil_with_underscores' in j2_vars
    assert 'myvar2' not in j2_vars
    assert 'myvar3' not in j2_vars
    assert 'hoge_dict_key' not in j2_vars
    assert 'hoge_dict_key2' not in j2

# Generated at 2022-06-21 07:52:36.234834
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import sys
    import StringIO
    import json

    class Templar(object):
        def __init__(self):
            self.available_variables = {}

    templar = Templar()
    globals = {}
    vars = AnsibleJ2Vars(templar, globals, locals=None)
    assert len(vars) == 0
    varname = "varname"
    globals[varname] = "value"
    assert len(vars) == 1
    assert varname in vars
    assert vars[varname] == "value"
    vars._locals = {"local": "local value"}
    assert len(vars) == 2
    assert "local" in vars
    assert vars["local"] == "local value"

# Generated at 2022-06-21 07:52:40.789264
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Arrange
    templar = None
    globals = {}
    locals = {}
    obj = AnsibleJ2Vars(templar, globals, locals)

    # Act
    iter_val = iter(obj)

    # Assert
    assert iter_val is not None
    assert iter_val is not missing


# Generated at 2022-06-21 07:52:47.462563
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = None
    globals = dict()
    locals = dict()

    def mock_template():
        return None

    templar.template = mock_template

    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)

    def mock_len(arg):
        return 0

    set.__len__ = mock_len

    n = ansible_j2vars.__len__()

    assert n == 0

# Generated at 2022-06-21 07:52:58.256847
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    AnsibleJ2Vars.__len__()
      When called with empty dicts for both locals and globals
        returns the length of available_variables from the templar
    """

    from ansible.template import Templar
    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, dict(), dict())
    # available_variables starts out empty
    assert len(j2vars) == 0
    # let's add a bunch of variables
    templar.available_variables = dict(
        one=1,
        two=2,
        three=3,
        four=4,
        five=5,
        six=6,
        seven=7,
        eight=8,
        nine=9,
    )

# Generated at 2022-06-21 07:53:04.510215
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    tmpl_vars = dict(
        color='green',
        car_details='Car is green',
        car_body='Car is {{ color }}',
        color_body='Car is {{ color }}',
        nested_cars = [dict(color='blue'), dict(color='{{ color }}')],
        color_body_nested='Car is {{ car.color }}'
    )
    templar = Templar(loader=None, variables=tmpl_vars)
    an = AnsibleJ2Vars(templar, tmpl_vars, tmpl_vars)
    locals_ = dict(nested_cars=[dict(color='blue'), dict(color='orange')], car=dict(color='red'))

# Generated at 2022-06-21 07:53:16.128723
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    globals = dict(a=1, b=2, c=3)
    locals = dict(c=4, d=5, e=6)
    inv_vars = dict(d=5, e=6, f=7)
    vpc = AnsibleJ2Vars(None, globals=globals)
    vpc_locals = vpc.add_locals(locals)
    vars = inv_vars.copy()
    vars.update(locals)
    vars.update(globals)
    for key in vars:
        assert vars[key] == vpc_locals[key], 'Variable proxy does not contain variable %s with value %s' % (key, vars[key])

# Generated at 2022-06-21 07:53:19.050115
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    vv = AnsibleJ2Vars('a', 'b', 'c')
    vv.add_locals({'x':1})
    assert vv['x'] == 1

# Generated at 2022-06-21 07:53:25.691967
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    class FakeVars(object):
        def __init__(self):
            self.available_variables = dict()

    data = dict({ 'all_hosts': { '1': {'name': 'host1'}, '2': {'name': 'host2'} } })
    templar = Templar(loader=None, variables=data)
    j2vars = AnsibleJ2Vars(templar, dict({}))
    assert len(j2vars) == len(data)

# Generated at 2022-06-21 07:53:33.249678
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    vars = VariableManager()
    templar = Templar(vars, loader=None)
    globals = dict()
    locals = dict()
    locals['test'] = 'test'
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert isinstance(ansible_j2_vars, Mapping)

# Generated at 2022-06-21 07:53:40.857589
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # print "test_AnsibleJ2Vars() start"
    templar = None
    globals = {'g_ansible_verbosity': 4, 'g_ansible_no_log': True}
    locals = {'l_ansible_verbosity': 5, 'l_ansible_no_log': False}
    ansible_j2_vars_obj = AnsibleJ2Vars(templar, globals, locals)
    # print "test_AnsibleJ2Vars() end"
    pass

# Generated at 2022-06-21 07:53:53.092328
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.unsafe_variable import UnsafeVariable
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    load = DataLoader()

    inv = InventoryManager(loader=load, sources='localhost,')
    v = VariableManager(loader=load, inventory=inv)

    j2vars = AnsibleJ2Vars(Templar(loader=load, variables=v), v._get_globals())

# Generated at 2022-06-21 07:54:03.393260
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    templar = Templar(loader=None, variables=VariableManager())
    locals = dict(v1=1, v2=2, v3=3, v4=4, v5=5, v6=6, v7=7, v8=8, v9=9, v10=10,
               l1=1, l2=2, l3=3, l4=4, l5=5, l6=6, l7=7, l8=8, l9=9, l10=10)
    locals_copy = dict(locals)

# Generated at 2022-06-21 07:54:13.469695
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    loader = DataLoader()
    vault_pass = loader.load_from_file('tests/test_vault.yml')
    passwords = {'vault_password_file': 'tests/test_vault.yml'}
    vault = VaultLib(passwords)

    inv

# Generated at 2022-06-21 07:54:15.023047
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    Unit test for constructor of class AnsibleJ2Vars
    '''

    # TODO
    pass

# Generated at 2022-06-21 07:54:22.066784
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    `AnsibleJ2Vars.__len__` is not a method.  It is
    a method descriptor.  That means it cannot be called
    directly.
    '''
    proxy = AnsibleJ2Vars(None,None)
    try:
        proxy.__len__()
    except TypeError as e:
        assert str(e).startswith('descriptor')
        assert str(e).endswith('not callable')
    except:
        msg = 'type(proxy.__len__) must be TypeError but not'
        raise AssertionError(msg)

# Generated at 2022-06-21 07:54:31.771901
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    Tests __iter__ method
    '''
    from ansible.templating.template import Templar

    j2vars = AnsibleJ2Vars(Templar(), dict())
    # check that iterating over AnsibleJ2Vars is not raising excepions
    assert set(j2vars) == set()
    assert isinstance(iter(j2vars), type(iter([])))

    # check that we can retrieve items
    j2vars = AnsibleJ2Vars(Templar(), dict())
    j2vars.add_locals(dict(foo={'name': 'value'}))

    assert 'foo' in j2vars
    assert j2vars['foo'] == {'name': 'value'}

# Generated at 2022-06-21 07:54:36.215325
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, {'a': 1, 'b': 2}, locals={'c': 3, 'd': 4})

    assert sorted(j2vars) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-21 07:54:43.345443
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    templar = Templar(loader=None, variables=dict(a='foo', b='bar'), shared_loader_obj=None)
    ansible_j2vars = AnsibleJ2Vars(templar, dict(c='baz'), locals=dict(x='y'))

    assert 'a' in ansible_j2vars
    assert 'b' in ansible_j2vars
    assert 'x' in ansible_j2vars
    assert 'y' not in ansible_j2vars
    assert 'c' not in ansible_j2vars


# Generated at 2022-06-21 07:54:54.570769
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    templar = None
    globals = {"gvar1":"gval1", "gvar2":"gval2"}
    locals = {"lvar1":"lval1", "lvar2":"lval2"}

    avj2v = AnsibleJ2Vars(templar, globals, locals)
    assert avj2v.__contains__("gvar1") == True
    assert avj2v.__contains__("gvar2") == True
    assert avj2v.__contains__("lvar1") == True
    assert avj2v.__contains__("lvar2") == True
    assert avj2v.__contains__("undefined variable") == False


# Generated at 2022-06-21 07:55:05.777413
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import jinja2.environment

    l_testvar1 = 'ok'
    l_testvar2 = 'ok'

    environment = jinja2.environment.Environment()
    templar = Templar(loader=None, variables={}, environment=environment)
    globals = {'g_testvar1': 'ok', 'g_testvar2': 'ok'}
    locals = {'l_testvar1': 'ok', 'l_testvar2': 'ok'}

    test = AnsibleJ2Vars(templar, globals, locals=locals)

    # All keys from locals, globals, variables
    # need to be in this object.
    keys = {k for k in locals}
    keys.update(globals)
    keys.update(templar.available_variables)

# Generated at 2022-06-21 07:55:23.169000
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars

    locals = dict()
    vars = dict()

    hostvars = HostVars()
    hostvars.update(dict(k1='v1', k2='v2'))

    templar = Templar(loader=None)
    templar._available_variables = dict(hv=hostvars)

    globals = dict()
    globals.update(g1='1', g2='2', g3='3')

    v = AnsibleJ2Vars(templar, globals, locals)
    assert v.__len__() == 5
    assert 'hv' in v
    assert 'g1' in v
   

# Generated at 2022-06-21 07:55:35.127387
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    templar = object()
    globals = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    locals = {'x': 10, 'y': 20, 'z': 30, 'w': 40}
    hostvars = HostVars()
    hostvars.add_host('localhost', {'hello':'world'})
    obj = AnsibleJ2Vars(templar, globals, locals)
    obj._templar.available_variables = {'e': 5, 'f': 6, 'g': 7, 'h': 8, 'vars': hostvars}
    keys = set()
    for key in obj:
        keys.add(key)
    assert len(keys) == 12

# Generated at 2022-06-21 07:55:43.062862
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import safe_eval

    templar = safe_eval.create_templar()
    v = AnsibleJ2Vars(templar, globals={})

    local1 = v.add_locals({'var1': 'x'})
    assert local1['var1'] == 'x'
    local2 = local1.add_locals({'var2': 'y'})
    assert local1['var1'] == 'x'
    assert local2['var1'] == 'x'
    assert local2['var2'] == 'y'

# Generated at 2022-06-21 07:55:49.459050
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class TemplarMock:
        def __init__(self, templar_variables):
            self.available_variables = templar_variables

        def template(self, variable):
            return self.available_variables[variable]

    class HostVarsMock(object):
        def get_vars(self, host):
            return host

    class Host(dict):
        def __init__(self, name, **kwargs):
            self.name = name
            self.vars = HostVarsMock()
            super(Host, self).__init__(**kwargs)

    templar_variables = {
        "key1": "value1",
        "key2": "value2"
    }

    templar = TemplarMock(templar_variables)

    globals = {}

# Generated at 2022-06-21 07:56:01.543966
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os
    import sys

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..'))

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host

    host = Host("localhost")
    templar = Templar(loader=None, variables=dict(foo='bar'))
    variables = AnsibleJ2Vars(templar, dict())
    # Test if we get the desired variable
    assert variables['foo'] == 'bar'
    # Test if we get the desired variable
    assert variables['__file__'] == __file__
    # Check that we raise an KeyError exception

# Generated at 2022-06-21 07:56:13.318980
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.template import Templar
    class MyTemplar(Templar):
        def __init__(self, data=None):
            super(Templar,self).__init__()
            self.available_variables = data
        def template(self, data):
            return data

    class MyMutableMapping(MutableMapping):
        def __init__(self, data=None):
            super(MyMutableMapping,self).__init__()
            self._data = data.copy()
        def __getitem__(self, key):
            return self._data[key]
        def __setitem__(self, key, value):
            self._data[key] = value

# Generated at 2022-06-21 07:56:25.095891
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    templar = Templar(loader=None)
    f = open('ansible_j2vars.txt')
    s = f.read()
    f.close()
    # print(s)
    dct = safe_eval(s)
    # print(dct)
    dct_vars = dct['vars']
    dct_globals = dct['globals']
    dct_locals = dct['locals']
    ansible_j2vars = AnsibleJ2Vars(templar, dct_globals, locals=dct_locals)
    for k,v in dct_vars.iteritems():
        ansible_j2vars[k]

# Generated at 2022-06-21 07:56:26.422564
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert False, "unit test not implemented"


# Generated at 2022-06-21 07:56:31.113620
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    assert AnsibleJ2Vars({},{},locals={'a':1,'b':2}).add_locals({'c':3})._locals == {'a':1,'b':2,'c':3}
    assert AnsibleJ2Vars({},{},locals={'a':1,'b':2}).add_locals(None)._locals == {'a':1,'b':2}

# Generated at 2022-06-21 07:56:43.768881
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # https://github.com/ansible/ansible/pull/45984
    #
    # AnsibleJ2Vars() object had an infinite __len__ method.
    #
    # Side effect of this bug is because dict.update is called with it,
    # and dict.update iterates over the elements of the AnsibleJ2Vars()
    # instance it is passed, which means it'll never complete.
    #
    from jinja2.runtime import StrictUndefined
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.hostvars import HostVars
    from ansible.vars import combine_vars
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-21 07:57:10.500541
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    import sys

    # Prepare test variable set
    test_vars = dict(
        a_simple_var='simple',
        a_dict_var=dict(
            a=1,
            b=2
        ),
        a_list_var=[1, 2, 3],
    )

    # Prepare test globals
    test_globals = dict(
        a_global_var='global',
        a_global_function=dict(
            a=1,
            b=2
        ),
    )

    # Init AnsibleJ2Vars class
    aj2vars = AnsibleJ2Vars(Templar(loader=None), test_globals, test_vars)

    # Test dict interface

# Generated at 2022-06-21 07:57:16.972853
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class fake_templar():
        def __init__(self):
            self.available_variables = {"a": "value of a"}
        def template(self, var):
            return var
    class fake_globals():
        def __init__(self):
            self.globals = {"b": "value of b"}

    ansible_vars = AnsibleJ2Vars(fake_templar(), fake_globals())
    assert len(ansible_vars) == 2


# Generated at 2022-06-21 07:57:29.610044
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    templar = Templar(loader = None, variables = dict(a = 1, b = 2, c = dict(d = 3, e = 4)))
    variables = dict(x = 'X', y = 'Y', z = dict(d = 'D', e = 'E'))    
    variables = AnsibleJ2Vars(templar, variables)

    env = jinja2.Environment()
    env.filters['to_yaml'] = lambda v: dict(v)

    jinja2_variables = dict()
    for name,variable in templar.available_variables.items():
        if hasattr(variable, '__UNSAFE__'):
            jinja2_

# Generated at 2022-06-21 07:57:38.357398
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class Templar():
        def __init__(self, available_variables):
            self.available_variables = available_variables
            self.result = None
        def template(self, variable):
            self.result = variable
            return variable

    globals = {"j1": "g1", "j2": "g2", "j3": "g3"}

    # test available_variables
    print("## test 1")
    locals = {"j2": "l2", "j3": "l3"}
    available_variables = {"j2": "a2", "j3": "a3", "j4": "a4"}
    vars = AnsibleJ2Vars(Templar(available_variables), globals, locals)

# Generated at 2022-06-21 07:57:48.825144
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    aj2v = AnsibleJ2Vars(None, None, None)
    aj2v._templar.available_variables = {'1':1,'2':2,'3':3,'4':4}
    aj2v._locals = {'1':1,'2':2,'3':3,'4':4}
    aj2v._globals = {'1':1,'2':2,'3':3,'4':4}
    assert len(aj2v) == len(aj2v._templar.available_variables) + len(aj2v._locals) + len(aj2v._globals)


# Generated at 2022-06-21 07:57:54.272325
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    glob = {'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5'}
    locals = {'f': '6'}
    templar = Templar(loader=None)
    test_obj = AnsibleJ2Vars(templar, glob, locals)
    obj_len = len(test_obj)
    assert(obj_len == 6)



# Generated at 2022-06-21 07:57:59.244478
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    locals = dict()
    templar = Templar(loader=None)
    t = AnsibleJ2Vars(templar, locals)
    print(t._templar)
    print(t._globals)
    print(t._locals)


# Generated at 2022-06-21 07:58:11.436822
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.jinja2 import AnsibleJ2Loader, Templar
    from ansible.template import Jinja2Environment
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    locals = dict()
    locals['l_key'] = 'val'
    globals = dict()
    globals['g_key'] = 'val'
    templar = Templar(loader=AnsibleJ2Loader(jinja2_env=Jinja2Environment(undefined=AnsibleUndefined)))
    vars_obj = AnsibleJ2Vars(templar, globals, locals)


    # test that len(AnsibleJ2Vars) works for a case where the value
    # of a key is a HostVars instance

# Generated at 2022-06-21 07:58:20.738396
# Unit test for method __len__ of class AnsibleJ2Vars

# Generated at 2022-06-21 07:58:31.637127
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars

    # Create the hostvars variable
    hostvars = HostVars(host=Host("example.com"), variables={u'foo': u'bar'})

    # Setup Test
    locals = {'l_name': 'Here is the bar', 'l_foo': 'Testing foo here'}
    globals = {
        'name': 'Here is the bar',
        'foo': 'Testing foo here',
        'ansible_facts': {
            'os_kernel': {
                'name': 'Here is the bar',
                'foo': 'Testing foo here'
            }
        }
    }


# Generated at 2022-06-21 07:59:10.696724
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import pytest
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_globals(dict(a=1, b=2, c=3))
    variable_manager.set_host_variable(host='localhost', varname='a', value=2)
    variable_manager.set_host_variable(host='localhost', varname='b', value=3)
    variable_manager.set_host_variable(host='localhost', varname='c', value=4)

    templar = Templar(loader=None, variable_manager=variable_manager)

# Generated at 2022-06-21 07:59:21.033579
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    loader = DataLoader()

    variables = dict(foobar='banana')
    playbook_variables = dict(ansible_version='2.0',
                              ansible_facts=dict(distribution='ubuntu'),
                              inventory_hostname='localhost',
                              groups=['ungrouped'],
                              group_names=['ungrouped'],
                              play_hosts=[],
                              foo='bar',
                              uptime_seconds=18001,
                              inventory_dir='/etc/ansible/hosts')
    variable_

# Generated at 2022-06-21 07:59:32.209663
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # If I create an AnsibleJ2Vars object with a valid Templar() object and
    # with a dictionary of globals, the newly created AnsibleJ2Vars object
    # should __contain__ the globals' keys.
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    vault_pass = VaultLib(password='dummypass')
    templar = Templar(loader=None, shared_loader_obj=None, vault_secrets=[], vault_password=vault_pass, templatevars=None, disable_lookups=False)
    globals = {'foo': 'bar', 'baz': 'qux'}
    # When
    result = AnsibleJ2Vars(templar, globals)

# Generated at 2022-06-21 07:59:42.604968
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import safe_eval
    from ansible.template.templar import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    templar = Templar(VariableManager())
    globals = {} # empty for testing
    locals = {} # empty for testing
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)
    assert set() == set(ansible_vars)

    locals = {'var1': 'value1', 'var2': 'value2'}
    ansible_vars = ansible_vars.add_locals(locals)
    assert set(['var1', 'var2']) == set(ansible_vars)


# Generated at 2022-06-21 07:59:47.848990
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    import jinja2

    templar = jinja2.Environment(loader=jinja2.FileSystemLoader('/tmp')).from_string('')
    globals = {}
    locals = {}

    AnsibleJ2Vars(templar, globals, locals) # should not throw


test_AnsibleJ2Vars()

# Generated at 2022-06-21 07:59:57.663224
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.match import InventoryMatch
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    loader, variable_manager, inventory = (DataLoader(), VariableManager(), InventoryManager())
    variable_manager.loader = loader
    variable_manager.inventory = inventory
    variable_manager._host_vars_plugins = variable_manager._host_vars_plugins


# Generated at 2022-06-21 08:00:05.326316
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class FakeTemplar():
        available_variables = {'foo': 'bar', 'bar': 'baz'}

    class FakeGlobals():
        pass

    class FakeLocals():
        pass

    j2v = AnsibleJ2Vars(FakeTemplar(), FakeGlobals(), FakeLocals())

    assert 'foo' in j2v
    assert 'bar' in j2v
    assert 'baz' not in j2v


# Generated at 2022-06-21 08:00:13.816868
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    For this unit test you need to launch:
    $ ansible-test sanity --python 2.7 --test module_utils.ansible_jinja2.AnsibleJ2Vars
    '''
    # FIXME: remove this test, it is not supposed to be here
    #        i.e. it is not related to an ansible module and
    #             it is not a unit test
    #        In this pull request:
    #        https://github.com/ansible/ansible/pull/45912
    #        it was used during debuging the following:
    #        I had to edit the file 'module_utils/ansible_jinja2.py' (in the 'ansible' repository)
    #        because the method 'add_locals' was not working properly. The problem was that the
    #        field

# Generated at 2022-06-21 08:00:25.585944
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.template
    j2 = ansible.template.AnsibleJ2()
    locals = {'loc_a': 'a', 'loc_b': 'b'}
    globals = {'glob_a': 'aa', 'glob_b': 'bb'}
    l1 = AnsibleJ2Vars(j2, globals)
    l2 = l1.add_locals(locals)
    c1 = l1.__contains__
    c2 = l2.__contains__
    g1 = l1.__getitem__
    g2 = l2.__getitem__
    assert(not c1('loc_a'))
    assert(not c1('loc_b'))
    assert(not c1('glob_a'))

# Generated at 2022-06-21 08:00:29.028095
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ''' test_AnsibleJ2Vars() '''

    templar = mock_templar()

    vars = AnsibleJ2Vars(templar, dict())

    assert vars['foo'] == 'bar'

