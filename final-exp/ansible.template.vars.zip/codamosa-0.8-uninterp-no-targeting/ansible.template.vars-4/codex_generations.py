

# Generated at 2022-06-21 07:51:02.763979
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
  class Templar():
    def __init__(self):
      self.available_variables = {'foo': 'bar'}

  templar = Templar()

  # Test 'foo' exists in available_variables
  v = AnsibleJ2Vars(templar, {})
  assert 'foo' in v

  # Test that locals override available_variables
  v = AnsibleJ2Vars(templar, {}, {'foo': 'baz'})
  assert 'foo' in v

  # Test that undefined variables returns False
  v = AnsibleJ2Vars(templar, {})
  assert 'undefined' not in v

  # Test that variables from globals returns True
  v = AnsibleJ2Vars(templar, {'foo': 'baz'})

# Generated at 2022-06-21 07:51:14.614026
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar

    templar = Templar(loader=None)

    # Create a dictionary of values to be used in a test
    dict_values = {'xx':1, 'yy':2, 'zz':3}

    # Instantiate an AnsibleJ2Vars object using the templar and dict_values
    proxy = AnsibleJ2Vars(templar, dict_values, locals=dict_values)

    # Verify that the object type is AnsibleJ2Vars
    assert isinstance(proxy, AnsibleJ2Vars), "Object is not of type AnsibleJ2Vars"

    # Verify that the AnsibleJ2Vars object has the expected key-value pairs
    assert proxy['xx'] == 1, "Key xx's corresponding value is incorrect"

# Generated at 2022-06-21 07:51:18.429256
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    t = Templar(None)
    a = AnsibleJ2Vars(t, {'a' : 'A'})
    assert a['a'] == 'A'

# Generated at 2022-06-21 07:51:25.926303
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    def foo():
        if True:
            pass
    if True:
        pass
    if True:
        pass

    class Templar(object):
        def __init__(self):
            self.available_variables = dict()
            self.available_variables['k1'] = 'v1'
            self.available_variables['k2'] = 'v2'

        def template(self, txt):
            if txt == 'v1':
                return 'tt1'
            if txt == 'v2':
                return 'tt2'

    templar = Templar()

    #
    # base case
    #

    vars = AnsibleJ2Vars(templar, dict())
    assert len(vars) == 2

    #
    # with locals
    #

    local = dict()
   

# Generated at 2022-06-21 07:51:38.625182
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Test case: keys/variables have been added to the AnsibleJ2Vars object
    # with the add_local method of Template class.  The methods __len__ and
    # __contains__ should report the correct number and presence of those keys.
    #
    # See the use of AnsibleJ2Vars in the method _load_vars of the Template class.
    # See also test_Template__load_vars method in `test_template.py`.

    from ansible.template import Templar

    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, dict(), locals=dict())

    key = 'key1'
    assert key not in j2vars
    assert len(j2vars) == 0

    j2vars._locals[key] = 1

# Generated at 2022-06-21 07:51:47.015205
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    try:
        import jinja2
    except ImportError:
        print("jinja2 is required for testing the AnsibleJ2Vars add_locals method")
        return

    from ansible.template import Templar

    proxy = AnsibleJ2Vars(Templar(), {"a_global": "foo"})
    assert len(proxy) == 1

    proxy2 = proxy.add_locals({'a_local': 'bar'})
    assert len(proxy2) == 2
    assert len(proxy) == 1

    proxy3 = proxy.add_locals(None)
    assert proxy3 == proxy
    assert len(proxy3) == 1

    proxy4 = proxy2.add_locals(None)
    assert proxy4 == proxy2
    assert len(proxy4) == 2

# Generated at 2022-06-21 07:51:58.381239
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import os
    import jinja2
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible import constants as C

    # Load inventory
    inv = HostVars(
        host_list=C.DEFAULT_HOST_LIST or '/etc/ansible/hosts',
        group_list=C.DEFAULT_GROUP_LIST or '/etc/ansible/group_vars/all'
    )

    # Load templates
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(os.path.join(C.DEFAULT_MODULE_PATH[0], 'template')))

    # Initialize templar
    templar = Templar(loader=env, variables=inv)


    # Initialize globals

# Generated at 2022-06-21 07:52:03.970526
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    t = Templar()
    t._available_variables = {'foo': 'foo is here'}
    v = AnsibleJ2Vars(t, {})
    assert v['foo'] == 'foo is here'
    assert v['bar'] == KeyError

# Generated at 2022-06-21 07:52:15.832979
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # test with all three dicts provided
    globals, locals, variables = {}, {}, {}
    variables['template_host'] = 'localhost'
    test = AnsibleJ2Vars(None, globals, locals)
    assert len(test) == 3

    # test with no globals
    globals = None
    variables['template_host'] = 'localhost'
    test = AnsibleJ2Vars(None, globals, locals)
    assert len(test) == 3

    # test with no locals
    locals = None
    variables['template_host'] = 'localhost'
    test = AnsibleJ2Vars(None, globals, locals)
    assert len(test) == 3

    # test with no variables
    variables = None
    test = AnsibleJ2Vars(None, globals, locals)

# Generated at 2022-06-21 07:52:23.503909
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import json
    import ast
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # set up Templar() object with encryption support
    def get_vault_secrets(filename):
        return [VaultLib(password_file=filename)]
    templar = Templar(vault_secrets=get_vault_secrets('vault_password_file'))

    # set up globals
    with open('globals.txt') as f:
        globals = ast.literal_eval(f.read())

    # set up locals
    with open('locals.txt') as f:
        locals = ast.literal_eval(f.read())
    # create locals from what jinja2 will create

# Generated at 2022-06-21 07:52:36.923267
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import sys
    if sys.version_info[0] >= 3:
        maketrans = str.maketrans
    else:
        from string import maketrans

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.strategy.linear import StrategyModuleStore
    from ansible.template import Templar
    from ansible.template import vault
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    context_obj = PlayContext()
    tqm = None
    variable_manager = VariableManager()
    loader = None
    play_context = PlayContext()
    play = None
    extra_vars = dict()

# Generated at 2022-06-21 07:52:47.864570
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.vars import VariableManager
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    import sys
    import pytest
    sys.path.insert(0, 'lib/ansible/module_utils')
    import ansible.module_utils.facts as facts

    # Valid scenarios
    var_manager = VariableManager()
    templar = Templar(loader=None, variables=var_manager)

# Generated at 2022-06-21 07:52:58.488061
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import compile_replacer
    from ansible.template.templar import Templar

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager._fact_cache = {"ansible_version.full" : "1.1.1"}

    templar = Templar(
        loader=None,
        variables=variable_manager,
        shared_loader_obj=None,
        use_handlers=False,
        fail_on_undefined=False,
        environment=None,
        replace_underscores=False,
        disable_lookups=False,
        replacer=compile_replacer(),
    )


# Generated at 2022-06-21 07:53:04.167478
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar():
        def __init__(self, available_variables):
            self.available_variables = available_variables
        def template(self, variable):
            return variable + "_template"

    vars = AnsibleJ2Vars(Templar({"key1": "value", "key2": "value2"}), {"key3": "value3"}, locals={"local1": "value4"})
    assert vars["key1"] == "value_template"
    assert vars["key2"] == "value2_template"
    assert vars["key3"] == "value3"
    assert vars["local1"] == "value4"
    assert vars["undefined"] == KeyError

# Generated at 2022-06-21 07:53:04.836895
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert __contains__

# Generated at 2022-06-21 07:53:16.862537
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a fake AnsibleVars object for the test
    variables = {}
    variables['var_1'] = "foo1"
    variables['var_2'] = "foo2"
    variables['var_3'] = "foo3"
    variables['var_4'] = "foo4"

    # Initialize the AnsibleJ2Vars object
    test_context = PlayContext()
    j2_templar = Templar(loader=None, variables=variables)
    test_AnsibleJ2Vars = AnsibleJ2Vars(j2_templar, {})
    assert len(test_AnsibleJ2Vars) == 4


# Generated at 2022-06-21 07:53:26.453181
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.module_utils import basic
    import ansible.module_utils.common.template
    from ansible.vars.hostvars import HostVars
    import mock
    import pytest

    host = HostVars(
        mock.Mock(
            get_name=mock.Mock(return_value='test_host')
        ),
        dict()
    )

    # test for undefined variable exception
    with pytest.raises(KeyError) as e_info:
        AnsibleJ2Vars(
            templar=ansible.module_utils.common.template.AnsibleTemplar(
                loader=None
            ),
            globals={},
            locals=dict()
        )['no_such_variable']

    # test for presence of variable
    assert 'vars' in Ansible

# Generated at 2022-06-21 07:53:38.866598
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Empty
    assert len(AnsibleJ2Vars(None, None, None)) == 0
    # One variable
    assert len(AnsibleJ2Vars(None, None, None)) == 0
    # Two variables
    assert len(AnsibleJ2Vars(None, None, None)) == 0
    # One global variable
    assert len(AnsibleJ2Vars(None, None, None)) == 0
    # Two global variables
    assert len(AnsibleJ2Vars(None, None, None)) == 0
    # One local variable
    assert len(AnsibleJ2Vars(None, None, None)) == 0
    # Two local variables
    assert len(AnsibleJ2Vars(None, None, None)) == 0
    # One global and one local variable

# Generated at 2022-06-21 07:53:48.708936
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    class TestTemplar:
        available_variables = {
            'x': 123,
            'y': 789,
        }
        def __init__(self):
            self.template_data = {}
            self.undefined_found = False
        def template(self, v, fail_on_undefined=True, override=None,
                     convert_bare=None, preserve_trailing_newlines=None,
                     escape_backslashes=True, templar=None, **kwargs):
            if v not in self.template_data:
                raise AnsibleUndefinedVariable('template not provided in test')
            return self.template_data[v]

    globals = {
        'z': 456,
    }
    templar = TestTemplar()

# Generated at 2022-06-21 07:53:59.393764
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class TestTemplar:
        def __init__(self):
            self.av = dict()

        def available_variables(self):
            return self.av

        def template(self, varname):
            if varname == "varname1":
                return "templated"
            else:
                return varname

    av = dict()
    av['varname1'] = "variable1"
    av['varname2'] = "variable2"
    templar = TestTemplar()
    templar.av = av

    globals = dict()
    globals['global1'] = "global1"
    globals['global2'] = "global2"

    locals = dict()
    locals['local1'] = "local1"
    locals['local2'] = "local2"

    an

# Generated at 2022-06-21 07:54:13.658858
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import tempfile
    import ansible.constants as C

    templar = ansible.template.Templar(loader=ansible.parsing.dataloader.DataLoader())
    templar.basedir = tempfile.mkdtemp()

# Generated at 2022-06-21 07:54:23.666379
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    j2_globals = { 'foo': 'global_foo', 'bar': 'global_bar' }
    j2_vars = AnsibleJ2Vars(templar, j2_globals)
    assert j2_vars['foo'] == 'global_foo'
    
    j2_locals = { 'foo': 'local_foo', 'baz': 'local_baz' }
    j2_vars = j2_vars.add_locals(j2_locals)
    
    assert j2_vars['foo'] == 'local_foo'


# Generated at 2022-06-21 07:54:34.019797
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert len(AnsibleJ2Vars(None, None, None)) == 0
    assert len(AnsibleJ2Vars(None, {'a': 1, 'b': 2, 'c': 3})) == 3
    assert len(AnsibleJ2Vars(None, {'a': 1, 'b': 2, 'c': 3}, {'a': 1, 'b': 2, 'c': 3})) == 3
    assert len(AnsibleJ2Vars(None, {'a': 1, 'b': 2, 'c': 3}, {'a': 1})) == 4
    assert len(AnsibleJ2Vars(None, {'a': 1, 'b': 2, 'c': 3}, {'d': 4})) == 4

# Generated at 2022-06-21 07:54:42.691669
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Mock Templar class to be able to test AnsibleJ2Vars class
    class Templar:
        def __init__(self):
            self.items = {}
            pass
        def template(self, item):
            return
        def available_variables(self):
            return self.items
        def set_available_variables(self, items):
            # Set the content of items attribute which is the local variable storage in AnsibleJ2Vars class
            # This is to simulate the dict like behavior of template variables
            self.items = items

    # Mock AnsibleModule class to be able to test AnsibleJ2Vars class

# Generated at 2022-06-21 07:54:50.358654
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict

    var_manager = VariableManager()
    var_manager.extra_vars = ImmutableDict({"i": "22"})
    proxy = AnsibleJ2Vars(var_manager, {})

    res = set()
    for x in proxy:
        res.add(x)

    assert res == set(["i"])


# Generated at 2022-06-21 07:54:52.497902
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert(True)

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-21 07:54:59.982497
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from jinja2.utils import missing

    templar = Templar(variables={'one': 1, 'two': 2}, loader=None, shared_loader_obj=None, configuration=None, disable_lookups=False)
    play_context = PlayContext()
    play_context._set_globals(vars(missing))
    tmp = AnsibleJ2Vars(templar, play_context.global_vars)
    assert tmp.__contains__('one')
    assert tmp.__contains__('two')
    assert not tmp.__contains__('three')


# Generated at 2022-06-21 07:55:12.521982
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    from ansible.template.safe_eval import safe_eval

    # ansible_vars from unit test
    ansible_vars = {
        'ansible_all_ipv4_addresses': [
            '10.0.0.1',
            '192.168.0.1',
        ],
        'ansible_all_ipv6_addresses': [
            'fe80::216:3eff:fe8f:31e',
        ]
    }

    # locals from unit test

# Generated at 2022-06-21 07:55:18.281959
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    example = AnsibleJ2Vars(None, {'g_key1': 'g_val1'}, locals={'l_key1': 'l_val1'})
    example._templar = FakeTemplar({'av_key1': 'av_val1'})

    assert set(example) == set(['l_key1', 'av_key1', 'g_key1'])



# Generated at 2022-06-21 07:55:26.428994
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from unittest import TestCase
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.vars import HostVars
    class TestAnsibleJ2Vars(TestCase):
        def test___contains__(self):
            variables = dict(one=1, two=2, three=3)
            vars_manager = VariableManager()
            #self.assertFalse(vars_manager.get_vars(play=play) is None)
            for key, value in iteritems(variables):
                vars_manager._vars_per_host[key] = value
            templar = Templar(vars_manager, loader=None, shared_loader_obj=None)

# Generated at 2022-06-21 07:55:41.579965
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
  from ansible.template import Templar
  import ansible.constants as constants
  import ansible.utils.template as template
  from ansible.vars.hostvars import HostVars
  import ansible.parsing.dataloader as dataloader
  from ansible.inventory.manager import InventoryManager
  from ansible.parsing.vault import VaultLib
  vault_path = template.template('/home/vagrant/.ansible/vault_pass.txt')
  vault_password = VaultLib(password_file=vault_path)

# Generated at 2022-06-21 07:55:51.265635
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    j2vars = AnsibleJ2Vars(Templar(loader=None), dict())
    if len(j2vars) != 0:
        raise AssertionError("AnsibleJ2Vars__len__: Bad initialization, expected 0, got %d" % len(j2vars))

    j2vars = AnsibleJ2Vars(Templar(loader=None), dict(a=1, b=2, c=3))
    # TODO: (temporarily skipped)
    # if len(j2vars) != 3:
    #    raise AssertionError("AnsibleJ2Vars__len__: Expected 3, got %d" % len(j2vars))

# Generated at 2022-06-21 07:56:02.728412
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()
    locals = dict(
        l_a = '1',
        l_b = '2',
        l_c = '3',
        l_d = '4',
        l_e = '5',
    )
    globals = dict(
        g_a = '1',
        g_b = '2',
        g_c = '3',
        g_d = '4',
        g_e = '5',
    )
    available_variables = dict(
        v_a = '1',
        v_b = '2',
        v_c = '3',
        v_d = '4',
        v_e = '5',
    )

# Generated at 2022-06-21 07:56:14.766020
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    j2_vars = AnsibleJ2Vars(Templar().set_available_variables({'foo': 'bar'}), dict(), dict())

    # test with a single key (in this case 'foo')
    result = j2_vars['foo']
    assert result == 'bar'

    # test with a non existing key (in this case 'key1')
    try:
        j2_vars['key1']
        assert False
    except KeyError:
        assert True

    group = Host(name='test')
    group.vars = {'myvar': 'myvalue'}
    group.set_variable('myvar2', 'myvalue2', 0)
   

# Generated at 2022-06-21 07:56:25.662462
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2

    assert len(AnsibleJ2Vars({}, [], locals={})) == 0

    templar = jinja2.Environment(undefined=jinja2.StrictUndefined).from_string('{{ var }}').make_module(dict(var=1))
    assert len(AnsibleJ2Vars(templar, [], locals={})) == 1
    assert len(AnsibleJ2Vars(templar, [], locals=dict(var2=2))) == 2

    templar = jinja2.Environment(undefined=jinja2.StrictUndefined).from_string('{{ var }}').make_module(dict())
    assert len(AnsibleJ2Vars(templar, [], locals=dict(var=1))) == 1

    templar

# Generated at 2022-06-21 07:56:34.085910
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.template
    templar = ansible.template.AnsibleJ2Template("{{ lookup('pipe', 'echo -n foo') }}",
                                                 {'foo': 'bar'}, shared_loader_obj=None,
                                                 variable_manager=None,
                                                 loader=None,
                                                 jinja2_native=False)
    ansible_j2_vars_obj = AnsibleJ2Vars(templar, {}, None)
    # Case1:
    # If varname in self._locals:
    #    return self._locals[varname]
    # Case: varname not in self._templar.available_variables and varname not in self._globals
    assert(ansible_j2_vars_obj['foo'] == 'bar')


# Generated at 2022-06-21 07:56:46.314566
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    from ansible.template import Templar

    t = Templar(loader=None)
    t.set_available_variables(dict(foo='foo is foo', bar='bar is bar'))

    v = AnsibleJ2Vars(t, {})

    if 'foo' not in v:
        assert False, 'foo should be in v'
    if 'bar' not in v:
        assert False, 'bar should be in v'
    if 'baz' in v:
        assert False, 'baz should not be in v'

    if v['foo'] != 'foo is foo':
        assert False, 'v[foo] should be "foo is foo", not "%s"' % v['foo']

    v2 = v.add_locals({'baz':'baz is baz'})


# Generated at 2022-06-21 07:56:55.702866
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    proxy = AnsibleJ2Vars(templar, dict(a=1))
    assert sorted(proxy) == ['a'], '__iter__() should return sorted keys of all scopes of variables'

    templar = Templar(loader=None, available_variables=dict(b=2))
    proxy = AnsibleJ2Vars(templar, dict(a=1))
    assert sorted(proxy) == ['a', 'b'], '__iter__() should return sorted keys of all scopes of variables'

    templar = Templar(loader=None, available_variables=dict(a=2))
    proxy = AnsibleJ2Vars(templar, dict(a=1))

# Generated at 2022-06-21 07:57:08.391137
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import pytest
    from ansible.vars.unsafe_proxy import _UnsafeProxy

    # initiate a class AnsibleJ2Vars
    templar = AnsibleJ2Vars(None, None, None)

    # test __contains__ with dict
    dict_one = dict(host_one=dict(ansible_hostname='host_one'))
    dict_two = dict(host_two=dict(ansible_hostname='host_two'))


# Generated at 2022-06-21 07:57:18.130075
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    try:
        from ansible.errors import AnsibleError
        from ansible.module_utils.six import iteritems
        from ansible.module_utils.six.moves import builtins
        from ansible.template import Templar
    except:
        raise AssertionError("Cannot import ansible modules 'AnsibleError', 'iteritems', 'builtins' and 'Templar'. Module AnsibleJ2Vars cannot be tested")

    # Test whether the method __len__ return the right number of elements when vars is not empty
    template = Templar(loader=None)
    available_variables = {'test_1':1, 'test_2':'test_value_1'}
    template.set_available_variables(available_variables)
    proxy = AnsibleJ2Vars(template, globals={}, locals={})

# Generated at 2022-06-21 07:57:35.678119
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.template import get_available_variables

    varnames = ['hostvars', 'vars', 'inventory_hostname']
    locals = {'l_somevariable': 'somevalue'}
    templar = Templar(get_available_variables(dict(), dict()))
    ansible_j2_vars = AnsibleJ2Vars(templar, dict(), locals=locals)

    for varname in varnames:
        assert varname not in ansible_j2_vars
        try:
            ansible_j2_vars[varname]
            assert False, 'Exception not raised'
        except Exception as e:
            assert isinstance(e, KeyError)

    ansible_j2_vars._templar.available_variables.update

# Generated at 2022-06-21 07:57:48.113954
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """Test method __iter__ of class AnsibleJ2Vars"""
    # Set up parameters
    templar = None
    globals = {'g1': 'a', 'g2': 'b', 'g3': 'c'}
    locals = {'l1': 'd', 'l2': 'e', 'l3': 'f'}
    available_variables = {'v1': 'g', 'v2': 'h', 'v3': 'i'}

    # Set up mocks
    templar_mock = object()
    templar_mock.available_variables = available_variables

    # Call the method
    ansible_j2_vars = AnsibleJ2Vars(templar_mock, globals, locals)

# Generated at 2022-06-21 07:57:48.726635
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert True

# Generated at 2022-06-21 07:57:57.034669
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # test_AnsibleJ2Vars___iter__() must be run in main process
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from jinja2 import Environment, PackageLoader

    env = Environment(loader=PackageLoader('ansible', 'templates'))
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    templar = Templar(loader=None, variables=variable_manager, play_context=play_context)
    variables = AnsibleJ2Vars(templar, env.globals)
    iterator = iter(variables)
    name_list = []

# Generated at 2022-06-21 07:58:08.616349
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.template import Templar

    templar = Templar()
    globals = {}
    locals = {}
    ajvars = AnsibleJ2Vars(templar, globals, locals)

    def test_case(varname_to_test, result_expected):
        result_actual = varname_to_test in ajvars
        if result_actual != result_expected:
            raise AssertionError(
                '''Failed test case: varname_to_test = '%s', result_expected = '%s', result_actual = '%s' ''' %
                (varname_to_test, result_expected, result_actual))

    test_case('foobar', False)
    test_case('nonexsistent', False)
    test_case('vars', False)

# Generated at 2022-06-21 07:58:16.262090
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    class Templar():

        def __init__(self):
            self.available_variables = dict()

    templar = Templar()

    globals = dict()

    locals = dict(l_key1='l_value1', l_key2='l_value2')

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    assert sorted(ansible_j2_vars.__iter__()) == sorted(['l_key1', 'l_key2'])



# Generated at 2022-06-21 07:58:23.646086
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 07:58:35.296809
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from collections import called_module
    from unit.mock.loader import DictDataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({
        "tmpl": "hello {{ from_available }}",
        "tmpl_1": "hello {{ from_available_1 }}",
        "var": "{{ from_available_1 }}",
        "var_1": "{{ from_available_2 }}",
        "var_2": "{{ from_available_3 }}"
    })
    available_variables = {'from_available': 'world', 'from_available_1': 'world_1',
                           'from_available_2': 'world_2', 'from_available_3': 'world_3'}
    variable_manager = VariableManager()


# Generated at 2022-06-21 07:58:45.105762
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # Create needed objects to pass in to AnsibleJ2Vars
    templar = object()
    globals = object()

    # Create the object we wish to test
    ansible_j2_vars = AnsibleJ2Vars(templar, globals)

    # Assert the created object is of the correct type
    assert(isinstance(ansible_j2_vars, AnsibleJ2Vars))

    # Assert the templar passed in is correctly stored in the object
    assert(ansible_j2_vars._templar == templar)

    # Assert the globals passed in is correctly stored in the object
    assert(ansible_j2_vars._globals == globals)

    # Assert the locals stored in the object is of the correct type

# Generated at 2022-06-21 07:58:56.835683
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Test variable
    variable = '{{ variable }}'
    # Test variable name
    variable_name = 'variable'
    # Test variable value
    variable_value = 'value'
    # Test variables which contains variable_name and variable_value
    variables = {variable_name: variable_value}

    # Get a templar with variables
    templar = Templar(loader=None, variables=variables)
    # Get a AnsibleJ2Vars with templar, globals and locals
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    # Test whether the ansible_j2_vars contains variable_name and variable
    assert ansible_j2_vars.__contains__(variable_name)
    assert ansible_j2_vars.__cont

# Generated at 2022-06-21 07:59:16.094763
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_self = AnsibleJ2Vars('Templar Object', globals)
    assert 'foo' in test_self
    assert 'bar' in test_self
    assert 'baz' not in test_self
    # test_self.assertRaises(TypeError, test_self.__contains__, None)
    # test_self.assertRaises(TypeError, test_self.__contains__, 17)


# Generated at 2022-06-21 07:59:27.282943
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.template
    import ansible.module_utils.common.jsonapi
    import ansible.template.safe_eval

    templar = ansible.template.Templar(loader=None, variables={})
    globals = { 'a': 'b' }
    locals_1 = { 'c': 'd' }
    locals_2 = { 'e': 'f' }
    my_vars = AnsibleJ2Vars(templar, globals, locals=locals_1)
    assert my_vars['a'] == 'b'
    assert my_vars['c'] == 'd'
    my_vars = my_vars.add_locals(locals_2)
    assert my_vars['e'] == 'f'

# Generated at 2022-06-21 07:59:33.414720
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    Test __len__ function of AnsibleJ2Vars Class
    """
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = None
    locals = {'one': 'foo', 'two': 'bar', 'three': 'baz'}
    myclass = AnsibleJ2Vars(templar, globals, locals)
    len_value = len(myclass)
    assert len_value == 3


# Generated at 2022-06-21 07:59:44.802911
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    from ansible.vars.hostvars import HostVars

    assert AnsibleJ2Vars.__doc__ is not None
    assert AnsibleJ2Vars.__getitem__.__doc__ is not None

    context = PlayContext()
    templar = Templar(loader=DataLoader())
    aj2vars = AnsibleJ2Vars(templar, None, None)

    class Test:
        pass

    test = Test()

    test.variable1 = "'test1'"
    assert aj2vars[test] == "'test1'"

    test.variable1 = '"test1"'

# Generated at 2022-06-21 07:59:55.647620
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars import HostVars
    from ansible.module_utils.six import PY2

    ########################################################################
    # initial tests to ensure calls to __len__ don't cause issues
    ########################################################################
    # normal host vars
    assert len(AnsibleJ2Vars(None, {}, locals={'foo': 'bar'})) == 1
    assert len(AnsibleJ2Vars(None, {'baz': 'quux'}, locals={'foo': 'bar'})) == 2

    # uncachable host vars
    assert len(AnsibleJ2Vars(None, {}, locals={'foo': wrap_var(['foo'])})) == 1

# Generated at 2022-06-21 08:00:00.250116
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible import context
    aj2v = AnsibleJ2Vars(context.CLIARGS, {})
    assert 'inventory_hostname' in aj2v
    assert 'hostvars' in aj2v
    assert 'vars' in aj2v


# Generated at 2022-06-21 08:00:11.180848
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    fake_host = Host(name='fake_host')
    fake_host.vars = HostVars(
        host=fake_host,
        vault_files=list(),
        task_vars=dict(),
        group_vars=dict()
    )

    fake_group = Group(name='fake_group')
    fake_group.vars = dict()
    fake_group.vars['group_var'] = 'group_var'
    fake_group.hosts[fake_host.name] = fake_host

# Generated at 2022-06-21 08:00:23.706008
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method',
                                     'become_user', 'check', 'diff', 'listhosts', 'syntax'])
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play

# Generated at 2022-06-21 08:00:30.463918
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar()
    hostVar = HostVars()
    hostVar.vars = {'test': 'success'}
    av = {'test': 'success', 'ansible_facts': hostVar}
    # test if templar.available_variables is read by AnsibleJ2Vars.__contains__
    aj2v = AnsibleJ2Vars(templar, {}, {'context': av})
    assert 'test' in aj2v
    # test if templar.available_variables is not read by AnsibleJ2Vars.__contains__
    aj2v = AnsibleJ2

# Generated at 2022-06-21 08:00:41.781388
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Testing data
    existing_vars = {'existing': 1}
    existing_globals = {'globals': 2}
    existing_locals = {'l_locals': 3}
    class Templar(object):
        def __init__(self):
            self.available_variables = existing_vars
    templar = Templar()

    # Initialize an AnsibleJ2Vars object containing the testing data
    ajv = AnsibleJ2Vars(templar, existing_globals, existing_locals)

    # Test __iter__
    assert set(iter(ajv)) == set(existing_vars.keys()) | set(existing_globals.keys()) | set(existing_locals.keys())

