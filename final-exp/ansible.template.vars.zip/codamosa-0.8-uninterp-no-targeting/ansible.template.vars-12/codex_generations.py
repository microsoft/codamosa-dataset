

# Generated at 2022-06-21 07:51:09.393576
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # Create a templar object
    from ansible.template import Templar
    templar = Templar()

    # Create a dict for the jinja2 globals
    globals = dict()

    # Create the object under test
    from ansible.template.vars import AnsibleJ2Vars
    vars = AnsibleJ2Vars(templar, globals)

    assert vars.__contains__("vars") == False
    try:
        assert vars.__getitem__("vars") == False
        assert False
    except KeyError:
        assert True
    # Note: the above tests are expected to fail since this is an empty test case

# Generated at 2022-06-21 07:51:18.303430
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.playbook.play_context as play_context
    import ansible.playbook.block as block
    import ansible.vars.manager as manager
    import ansible.template as template
    import ansible.vars.hostvars as hostvars

    templar = template.AnsibleTemplate(play_context.PlayContext(), block=block.Block().load(dict(hosts=['localhost']), task=dict(vars=dict(foo='foo')), play=None), variable_manager=manager.VariableManager())
    templar._available_variables = dict(foo='foo')
    globals = dict(bar='bar')

    j2vars = AnsibleJ2Vars(templar, globals)
    assert j2vars['foo'] == 'foo'

# Generated at 2022-06-21 07:51:28.140931
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    ansible_J2Vars = AnsibleJ2Vars(templar, {}, {})
    assert('foo' in ansible_J2Vars) is False
    templar.available_variables = {'foo': ['bar',]}
    assert('foo' in ansible_J2Vars) is True
    ansible_J2Vars._locals = {'foo': 'bar'}
    assert('foo' in ansible_J2Vars) is True
    ansible_J2Vars._globals = {'foo': 'bar'}
    assert('foo' in ansible_J2Vars) is True


# Generated at 2022-06-21 07:51:40.285166
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=True)

    vars = AnsibleJ2Vars(templar, None)
    try:
        dummy = vars['var']
    except KeyError:
        pass
    else:
        assert False, "AnsibleJ2Vars for undefined variable got item {}".format(dummy)
    assert 'var' not in vars, "AnsibleJ2Vars for undefined variable got True from __contains__"

# Generated at 2022-06-21 07:51:45.478867
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    globals = { 'g_k1': 'g_v1' }
    locals = { 'l_k1': 'l_v1' }
    templar = {}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'l_k1' in j2vars
    assert 'g_k1' in j2vars
    assert 'bad_key' not in j2vars


# Generated at 2022-06-21 07:51:57.413181
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    test_templar = Templar(loader=Mock())
    test_globals = dict()

    test_j2_vars_instance = AnsibleJ2Vars(test_templar, test_globals)

    # test: variable in self._templar.available_variables
    test_templar.available_variables = {"test_variable": "test_value"}

    assert test_j2_vars_instance["test_variable"] == "test_value"

    # test: variable in self._globals
    test_globals["test_variable"] = "test_value"

    assert test_j2_vars_instance["test_variable"] == "test_value"

    # test: variable in self._locals
    test_locals = dict()

# Generated at 2022-06-21 07:52:10.425095
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = AnsibleJ2Template()
    globals = {}
    locals = {}
    vars = AnsibleJ2Vars(templar, globals, locals)
    
    assert len(vars) == 0
    assert list(vars) == []

    globals['g1'] = 1
    assert len(vars) == 1
    assert list(vars) == ['g1']

    # Ensure that we get the whole vars object
    locals['vars'] = dict(a=1, b=2, c=3)
    assert len(vars) == 4
    assert list(vars) == ['g1', 'vars', 'a', 'b']
    assert len(vars['vars']) == 3

    # Add some other variables
    locals['j1'] = 1

# Generated at 2022-06-21 07:52:20.157914
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.module_utils.six import PY2
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    import os

    # Avoid the possibility of using an existing Vault password file
    AnsibleVaultEncryptedUnicode.vault_password = None

    # Create a vault password file
    vault_pass = VaultLib()
    vault_pass.password = "myvaultpassword"
    vault_pass.write_file(".vault_pass.txt")

    # Prepare a simple template file
    template_file = "template.j2"

# Generated at 2022-06-21 07:52:31.248944
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()

    vars = AnsibleJ2Vars(templar, globals=dict())

    def test_case(name, value, expected_value):
        vars._templar.available_variables[name] = value
        assert vars[name] == expected_value

    # Test case 1: template existing variable from available_variables using custom filter
    test_case("foo_var", "{{ foo_var | to_json }}", '"foo"')

    # Nested variables
    vars._templar.available_variables['hostvars'] = {
        'foo_host': {
            'foo_var': 'foo'
        }
    }

# Generated at 2022-06-21 07:52:39.440521
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    # create variables manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(variable='some-value')
    variables = variable_manager.get_vars(host=None)
    variables['hostvars'] = HostVars(dict())

    # create a new  AnsibleJ2Vars object
    templar = Templar(variables=variables,
                      loader=None,
                      shared_loader_obj=None,
                      vault_secrets=None)


# Generated at 2022-06-21 07:52:55.340338
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import pytest

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    hostvars = get_hostvars()

    manager = VariableManager()
    manager.set_host_variable(host=hostvars.__hostname__, varname='testvar', value='test')
    manager.set_host_variable(host=hostvars.__hostname__, varname='testvar1', value='test1')
    manager.set_host_variable(host=hostvars.__hostname__, varname='testvar2', value='test2')

    manager.add_globals({'test': 'test',
                         'gtest1': 'gtest1',
                         'gtest2': 'gtest2'})

# Generated at 2022-06-21 07:53:01.370279
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    ansible_j2vars = AnsibleJ2Vars(templar=templar, globals=dict())
    ansible_j2vars._templar.available_variables = dict(foo=1, bar=2)
    ansible_j2vars._locals = dict(baz=3, quux=4)
    assert sorted(list(ansible_j2vars)) == sorted(['foo', 'bar', 'baz', 'quux'])

# Generated at 2022-06-21 07:53:07.698349
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars import VariableManager
    from ansible.template import Templar

    v = VariableManager()
    t = Templar(vars=v)
    g = dict()

    test = AnsibleJ2Vars(templar=t, globals=g)
    keys = []
    for key in test:
        keys.append(key)

    assert set(keys) == set(v.available_variables)

# Generated at 2022-06-21 07:53:14.870462
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {'foo' : 'bar', 'baz' : 'qux'}
    vars = AnsibleJ2Vars(templar, globals)
    keys = set()
    for k in vars:
        keys.add(k)
    assert(set(keys) == set(globals))


# Generated at 2022-06-21 07:53:25.451519
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
  from ansible.template import Templar

  jvars = AnsibleJ2Vars(Templar(), {}, locals={})
  assert len(jvars) == 0

  jvars = AnsibleJ2Vars(Templar(), {'a': 1}, locals={})
  assert len(jvars) == 1

  jvars = AnsibleJ2Vars(Templar(), {}, locals={'b': 2})
  assert len(jvars) == 1

  jvars = AnsibleJ2Vars(Templar(), {'a': 1}, locals={'b': 2})
  assert len(jvars) == 2

  jvars = AnsibleJ2Vars(Templar(), {'a': 1, 'c': 3}, locals={'b': 2, 'd': 4})

# Generated at 2022-06-21 07:53:37.230605
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict(
        foo='bar'
    )
    locals = dict(
        baz='qux'
    )
    proxy = AnsibleJ2Vars(templar, globals, locals)

    assert 'foo' == proxy['foo']
    assert 'bar' == proxy['foo']

    assert 'foo' in proxy
    assert 'baz' in proxy
    assert 'qux' in proxy

    assert 'foobar' not in proxy

    assert len(proxy) == 2

    assert 'foo' in list(proxy)
    assert 'baz' in list(proxy)
    assert 'foobar' not in list(proxy)

# Generated at 2022-06-21 07:53:47.321128
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.parsing.yaml.objects import AnsibleUnicode
    locals_value = AnsibleUnicode("new_locals_value")
    locals = dict()
    locals["new_locals_key"] = locals_value
    class MockTemplar():
        def __init__(self, available_variables):
            self.available_variables = available_variables
        def template(self, variable):
            return variable
    dict_var = dict()
    dict_var["new_dict_key"] = locals_value
    available_variables = dict()
    available_variables["new_available_variable_key"] = dict_var

    templar = MockTemplar(available_variables)
    ansible_j

# Generated at 2022-06-21 07:53:47.868422
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    assert True

# Generated at 2022-06-21 07:53:50.621260
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    fail_msg = "AnsibleJ2Vars.__contains__ does not work as expected"
    vars = AnsibleJ2Vars(None, {'var': 'val'})
    assert 'var' in vars, fail_msg
    assert 'var2' not in vars, fail_msg

# Generated at 2022-06-21 07:54:01.321040
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import re
    import random
    import string

    random_string = ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(100))

    # new_templar is invalid.
    new_templar = re.compile(r'\b(a)(?!\1)(b)(?<=\1)(c)(?=\2)\b', re.IGNORECASE)
    # new_globals is valid.
    new_globals = {random_string: random_string}

    new_AnsibleJ2Vars = AnsibleJ2Vars(new_templar, new_globals)

    # random_string is in new_globals.
    assert random_string in new_AnsibleJ2Vars

    # random_

# Generated at 2022-06-21 07:54:07.080450
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    print(AnsibleJ2Vars)


# Generated at 2022-06-21 07:54:14.728620
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    This is a test of AnsibleJ2Vars.add_locals() method
    '''
    from ansible.template import Templar
    templar = Templar()
    ansible_j2_vars = AnsibleJ2Vars(templar, {'foo': 'foo', 'bar': 'bar'}, {'qux': 'qux'})
    locals = {'_bar': '_bar', '_baz': '_baz'}
    ansible_j2_vars.add_locals(locals)
    assert locals == {'_bar': '_bar', '_baz': '_baz'}


# Generated at 2022-06-21 07:54:15.428718
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass

# Generated at 2022-06-21 07:54:25.211096
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    from scripts.module_utils.basic import AnsibleModule

    module_args = dict(test_a=dict(test_b=5,test_c=5),test_d=5)
    module_name = 'test1'
    module = AnsibleModule(argument_spec=module_args)
    basedir = '.'
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(test_a=1, test_b=2, test_c=3, test_d=4)
    play_context = PlayContext()


# Generated at 2022-06-21 07:54:35.195405
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import unittest
    from ansible.template import Templar

    class TestIter(unittest.TestCase):
        """Class to test __iter__ method of class AnsibleJ2Vars """
        def test_iter(self):
            templar = Templar(loader=None, shared_loader_obj=None)
            globals = dict(a=1, b=2)
            locals = dict(c=3, d=4)
            w = AnsibleJ2Vars(templar, globals, locals)
            self.assertTrue("a" in w.__iter__() and "b" in w.__iter__() and "c" in w.__iter__() and "d" in w.__iter__())

    import __main__
    __main__.unittest = unittest
    unittest.main

# Generated at 2022-06-21 07:54:38.686674
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    test_AnsibleJ2Vars = AnsibleJ2Vars(templar, {}, {})
    assert len(test_AnsibleJ2Vars) == 0

# Generated at 2022-06-21 07:54:44.963450
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    var_0 = AnsibleJ2Vars()
    assert len(var_0) == 0, "The length of var_0 is 0 instead of: 0"
    assert len(var_0) == 0, "The length of var_0 is 0 instead of: 0"
    assert len(var_0) == 0, "The length of var_0 is 0 instead of: 0"
    assert len(var_0) == 0, "The length of var_0 is 0 instead of: 0"
    assert len(var_0) == 0, "The length of var_0 is 0 instead of: 0"
    assert len(var_0) == 0, "The length of var_0 is 0 instead of: 0"
    assert len(var_0) == 0, "The length of var_0 is 0 instead of: 0"

# Generated at 2022-06-21 07:54:48.712389
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
   j2vars = AnsibleJ2Vars(None, {'a': 1, 'b': 2})
   assert sorted(list(j2vars)) == ['a', 'b']

# Generated at 2022-06-21 07:54:58.820090
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.template.template import Templar
    templar = Templar(loader=None)
    globals = {}
    locals = None
    ajv = AnsibleJ2Vars(templar, globals, locals)
    ajv._templar.available_variables = {'foo': 'bar'}
    assert 'foo' in ajv
    ajv._locals = {'foo': 'bar'}
    assert 'foo' in ajv
    ajv._templar.available_variables = {'foo': HostVars({'foo': 'bar'})}
    assert 'foo' in ajv
    ajv._globals = {'foo': 'bar'}
    assert 'foo' in aj

# Generated at 2022-06-21 07:55:11.255189
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = Templar(loader=None, variables={'all':'all', 'group_names': 'group_names', 'groups': 'groups'})
    host_vars = HostVars(loader=None, variables={'inventory_hostname': 'inventory_hostname', 'group_names': 'group_names', 'groups': 'groups'})
    j2vars = AnsibleJ2Vars(templar, {'inventory_dir': 'inventory_dir', 'omit': 'omit'}, locals={'hostvars': host_vars, 'hostvars[inventory_hostname]': host_vars})

    assert j2vars['all'] == 'all'
    assert j2vars['group_names'] == 'group_names'
    assert j2vars['groups'] == 'groups'
    assert j2

# Generated at 2022-06-21 07:55:25.076024
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test code for AnsibleJ2Vars.__contains__
    to_test = AnsibleJ2Vars('', {})
    with pytest.raises(AnsibleJ2Vars.__contains__.expected_exceptions):
        to_test.__contains__()


# Generated at 2022-06-21 07:55:33.282172
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
   j2vars = AnsibleJ2Vars(None, None, None)
   assert(j2vars.add_locals({"a": 1})._locals == {"a": 1})
   assert(j2vars.add_locals({"a": 1, "b": 2})._locals == {"a": 1, "b": 2})
   assert(j2vars.add_locals(None)._locals == {})

if __name__ == '__main__':
   test_AnsibleJ2Vars_add_locals()

# Generated at 2022-06-21 07:55:40.889085
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # First, create objects
    templar = None
    globals = {}
    locals = {'l_a': 'a', 'l_b': 'b'}

    # Second, create an object of our class
    ansiblevars = AnsibleJ2Vars(templar, globals, locals=locals)

    # Third, test our function
    ansiblevars_len = ansiblevars.__len__()
    assert ansiblevars_len == 2


# Generated at 2022-06-21 07:55:48.424726
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # should raise error for undefined variable
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(None, None)
    ansible_j2_vars = AnsibleJ2Vars(templar, {})

    try:
        ansible_j2_vars['undefined']
    except KeyError as e:
        assert str(e) == "undefined variable: undefined"

    ansible_j2_vars._templar.available_variables = {'vars': {}}
    ansible_j2_vars._globals = dict()

    assert ansible_j2_vars['vars'] == {}

    ansible_j2_vars

# Generated at 2022-06-21 07:56:00.827955
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import json
    import tempfile, os
    import ansible.galaxy
    import ansible.parsing.dataloader
    import ansible.plugins.loader
    import ansible.template
    import ansible.utils.display
    import ansible.vars
    import ansible.vars.manager
    import ansible.constants

    ansible.galaxy.api.configure()
    templar = ansible.template.Templar(loader=ansible.parsing.dataloader.DataLoader())
    templar.environment.loader.set_basedir(os.getcwd())
    ansible.constants.DEFAULT_HASH_BEHAVIOUR = "replace"

    # Create Inventory for testing

# Generated at 2022-06-21 07:56:03.203953
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
  iter1 = 0
  for iter1 in AnsibleJ2Vars(0,0,0):
    iter1+=1
  return iter1 == 0

# Generated at 2022-06-21 07:56:09.310353
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, dict())
    assert not isinstance(j2vars._locals, dict)
    j2vars.add_locals(dict())
    assert isinstance(j2vars._locals, dict)
    assert j2vars._locals == dict()

# Generated at 2022-06-21 07:56:13.567635
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    proxy = AnsibleJ2Vars(templar=None, globals=None)
    locals = dict(hostvars=None)
    proxy2 = proxy.add_locals(locals)
    assert proxy2._locals == locals

# Generated at 2022-06-21 07:56:24.718005
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

    from ansible.utils.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    templar = Templar(loader=None, variables={'foo': 'bar'})
    context = PlayContext()
    vault_secrets = []

# Generated at 2022-06-21 07:56:33.114684
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """
    Basically, this function implicates that
    when the 'hostvars' is a dictionary, 
    it will work fine.
    """
    ansible_vars = {'hostvars': {'192.168.0.1': {'ansible_ssh_user': 'root', 'ansible_ssh_pass': 'xxxxx'}}}
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader, variables=ansible_vars)
    ajv = AnsibleJ2Vars(templar, None, None)
    assert 'hostvars' in ajv
    assert 'ansible_ssh_user' in ajv
    assert 'ansible_ssh_pass' in aj

# Generated at 2022-06-21 07:56:48.351708
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    # AnsibleJ2Vars need templar object
    def test_constructor_with_templar():
        pc = PlayContext()
        templar = Templar(loader=None, variables=pc.vars_cache, # AnsibleJ2Vars need templar
                          shared_loader_obj=pc.loader, fail_on_undefined=False)
        aj = AnsibleJ2Vars(templar, pc.globals)
        assert(not isinstance(aj, dict))
        assert(aj is not None)

    # 'globals': should be dictionary

# Generated at 2022-06-21 07:56:56.835964
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Test that the locals dictionary is copy
    '''
    from ansible.vars.hostvars import HostVars
    from ansible.template.safe_eval import ansible_safe_eval

    templar = ansible_safe_eval.AnsibleTemplar()
    globals = dict()
    locals_ = dict()
    j2vars = AnsibleJ2Vars(templar, globals, locals=locals_)

    hostvars = HostVars(templar, "127.0.0.1")
    locals_['hostvars'] = hostvars

    j2vars_add_locals = j2vars.add_locals(locals_)

    assert j2vars_add_locals['hostvars'] == hostvars
    assert j2

# Generated at 2022-06-21 07:57:09.487280
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=AnsibleLoader(None))
    available_variables = {'foo': 'bar', 'hostvars': HostVars(host_name='hostname', variables={'baz': 'zab'})}
    globals = {'xyz': 'zyx'}
    locals = {'l_xyz': 'lyzx'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    case1 = {'name': 'foo', 'input': 'foo', 'expected': 'bar'}
    actual = vars[case1['input']]
    assert case1['expected']

# Generated at 2022-06-21 07:57:19.954680
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    """
    verify __init__() works
    """

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    variable_manager.extra_vars = dict(
        foo="bar",
        baz="bak",
        secret="None",
        secret_marked="None",
        secret_not_marked="None"
    )
    templar = Templar(loader=DataLoader(), variables=variable_manager)
    globals = dict()
    locals = dict()
    ansible_J2Vars = AnsibleJ2V

# Generated at 2022-06-21 07:57:26.498001
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(None, None)
    globals = {'answer': 42}
    locals = {'l_answer': 43}
    aj2vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert sorted(globals.keys()) == sorted(aj2vars.__iter__())



# Generated at 2022-06-21 07:57:34.931497
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    import jinja2

    templar = Templar(None, None, None)
    globals_var = {'ansible_version': 1}
    locals_var = {'l_my_local_var': 2}

    proxy_obj = AnsibleJ2Vars(templar, globals_var, locals_var)
    for i, variable in enumerate(proxy_obj):
        if i == 0:
            assert variable == 'ansible_version'
        elif i == 1:
            assert variable == 'my_local_var'
        else:
            assert False

# Generated at 2022-06-21 07:57:46.884117
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class FakeTemplar():
        def __init__(self):
            self.available_variables = {'a': 'variable_value'}
        def template(self, variable):
            return variable

    locals = {'b': 2, 'c': 3}
    globals = {'a': 1}
    obj = AnsibleJ2Vars(FakeTemplar(), globals, locals=locals)

    # Test whether expected and actual variable values match
    def test_variable(varname):
        assert varname in obj # test if variable exists in object
        assert obj[varname] == locals[varname] # test if value of variable in object matches the expected one

    # Test whether expected and actual variable values match

# Generated at 2022-06-21 07:57:49.712997
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ''' test case might be not correct implemented'''
    # jinja2.tests.test_runtime.TestDict
    import jinja2
    test_obj = AnsibleJ2Vars(jinja2.Environment(
        loader=jinja2.DictLoader({'test.tpl': '{{ foo }}'})
        ), {'foo': 42})
    assert len(test_obj) == 1


# Generated at 2022-06-21 07:57:57.690253
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleError

    vault_pass = 'secret'
    vault = VaultLib(vault_pass)

    templar = Templar(loader=None, shared_loader_obj=None, variables={}, vault_secrets=dict(vault_password=vault_pass))
    locals = dict(var1='var1', hostvars=HostVars({"var2": "var2"}), unsafe_text=AnsibleUnsafeText("unsafe_text"))

# Generated at 2022-06-21 07:58:09.744409
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import os
    import sys
    import unittest

    # Add to path the module
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))  # noqa

    # Import the module
    from ansible.vars import AnsibleJ2Vars

    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.cli import CLI

    loader = DataLoader()
    inv_loader = InventoryManager(loader=loader, sources=["tests/test_data/test_vars_template_options/hosts"])
    inv_

# Generated at 2022-06-21 07:58:24.948589
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    globals['g_key1'] = 'g_val1'
    globals['g_key2'] = 'g_val2'
    templar.available_variables = {'av_key1': 'av_val1', 'av_key2': 'av_val2'}
    locals['l1_key1'] = 'l1_val1'
    locals['l1_key2'] = 'l1_val2'
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)


# Generated at 2022-06-21 07:58:36.999177
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar as AnsibleTemplar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    templar = AnsibleTemplar()
    a_dict = dict()
    a_dict['a'] = AnsibleUnicode('b')
    a_dict['b'] = AnsibleUnicode('c')
    ansible_vars = AnsibleJ2Vars(templar, dict(), locals=dict())
    assert 'a' in ansible_vars
    assert 'b' in ansible_vars
    assert 'a' in ansible_vars or 'b' in ansible_vars
    assert 'c' not in ansible_vars
    assert 'a' in ansible_vars and 'c' not in ansible_vars

# Unit

# Generated at 2022-06-21 07:58:44.321940
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vars = AnsibleJ2Vars(templar=None, globals=None)

    vars._templar = object()
    assert len(vars) == 1

    vars._globals = {'a': 1}
    assert len(vars) == 2

    vars._locals = {'b': 2}
    assert len(vars) == 3

    vars._locals = {'a': 2, 'b': 2}
    assert len(vars) == 3


# Generated at 2022-06-21 07:58:45.572733
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert False, "Remove tests for __contains__"


# Generated at 2022-06-21 07:58:51.702686
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar, globals, locals = dict(), dict(), dict()
    aj2vs = AnsibleJ2Vars(templar, globals, locals)
    assert aj2vs.add_locals({'test_local': 'test_local'})
    assert aj2vs.add_locals({'test_local': 'test_local'})._locals['test_local'] == 'test_local'

# Generated at 2022-06-21 07:58:58.155953
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    
    from ansible.parsing.template import Templar

    templar = Templar(loader=None)

    vars = AnsibleJ2Vars(templar, {}, {})

    assert vars.add_locals({ 'foo': 'bar' })._locals == { 'foo': 'bar' }

    assert vars.add_locals({ 'foo': 'baz' })._locals == { 'foo': 'baz' }

# Generated at 2022-06-21 07:59:05.685777
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)

    # Templating a variable
    assert AnsibleJ2Vars(templar, {'foo': 'bar'})['foo'] == 'bar'

    # Validating undefined variable
    try:
        AnsibleJ2Vars(templar, {'foo': 'bar'})['bar']
        # Will fail if previous line did not raise an Exception
        assert False
    except KeyError:
        # That's a success
        pass

# Generated at 2022-06-21 07:59:12.854134
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    j2_vars = AnsibleJ2Vars(Templar(), {})  # empty dict for globals

    j2_vars._templar.available_variables = {'foo': 'bar'}
    assert j2_vars['foo'] == 'bar'
    j2_vars._templar.available_variables = {'foo': 42}
    assert j2_vars['foo'] == 42

    j2_vars._globals = {'foo': 'baz'}
    assert j2_vars['foo'] == 'baz'
    j2_vars._globals = {'foo': 43}
    assert j2_vars['foo'] == 43


# Generated at 2022-06-21 07:59:21.322887
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    DATA = "data"

    # Setup
    templar = Templar()
    templar.available_variables = {}
    var = AnsibleJ2Vars(templar, {})

    # Test 1
    # Test with a variable that is not in available_variables
    try:
        var["var"]
        assert False, "Expected a KeyError exception"
    except KeyError:
        pass

    # Test 2
    # Test with a variable that is in available_variables
    templar.available_variables = { "var": DATA }
    assert var["var"] == DATA

# Generated at 2022-06-21 07:59:28.336050
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    proxy = AnsibleJ2Vars(templar, {})
    assert sorted(list(proxy)) == sorted([
        'inventory_dir',
        'inventory_file',
        'inventory_hostname',
        'inventory_hostname_short',
        'playbook_dir',
        'play_hosts',
        'play_name',
    ])


# Generated at 2022-06-21 07:59:51.775046
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template import Templar
    from ansible.template import to_text

    vars_manager = dict(test_key_1='test_value_1', test_key_2='test_value_2', test_key_3='test_value_3')
    templar = Templar(loader=None, variables=vars_manager)

    globals = dict()
    locals = dict()

    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv.__iter__() == {'test_key_1', 'test_key_2', 'test_key_3'}


# Generated at 2022-06-21 07:59:59.454920
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class Templar:
        def __init__(self, **kwargs):
            self.available_variables = kwargs
        def template(self, value):
            return value


    values = {
        'vars': {
            'ansible_connection': 'local',
            'ansible_host': '127.0.0.1',
            'ansible_port': '2222'
        },
        'hostvars': {
            '127.0.0.1': {
                'ansible_connection': 'local',
                'ansible_host': '127.0.0.1',
                'ansible_port': '2222'
            }
        }
    }

# Generated at 2022-06-21 08:00:03.708367
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Necessary import
    from ansible.template.safe_eval import ansible_safe_eval
    assert AnsibleJ2Vars(ansible_safe_eval, {"foo": "bar"}, {}).__contains__("foo")



# Generated at 2022-06-21 08:00:10.312045
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    globals = {'g': 1}
    locals  = {'l': 2}
    templar = Templar(variables={'v': 3})

    j = AnsibleJ2Vars(templar, globals, locals)

    assert 'g' in j
    assert 'v' in j
    assert 'l' in j
    assert j['g'] == 1
    assert j['l'] == 2
    assert j['v'] == 3



# Generated at 2022-06-21 08:00:20.587326
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template.template import Templar
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    templar = Templar(loader=None, variables=dict(one=1, two=2), shared_loader_obj=None, play_context=play_context)
    context = dict(name="Carol")
    globals = dict(stat="happy")
    j2_vars = AnsibleJ2Vars(templar, globals=globals, locals=context)
    assert len(j2_vars) == 4


# Generated at 2022-06-21 08:00:25.460737
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    t = Templar(None, {})
    v = AnsibleJ2Vars(t, {})
    v2 = v.add_locals({'a': 'A'})
    assert v != v2
    assert v2['a'] == 'A'

# Generated at 2022-06-21 08:00:35.839507
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    t = Templar()
    v = AnsibleJ2Vars(t, {'g': 'global'}, {'local': 'local'})
    print(v['g'])
    print(v['local'])
    vars = HostVars(hostname='hostname')
    vars['hostname'] = 'hostname'
    vars['ip'] = 'x'
    vars['inventory_ip'] = 'y'
    vars['inventory_hostname'] = 'z'
    vars['inventory_hostname_short'] = 'a'
    t.set_available_variables(vars)
    print(v['hostvars'])

# Generated at 2022-06-21 08:00:46.120328
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    This method tests __getitem__ method of AnsibleJ2Vars class.
    It tests for success, exception and error cases for two variable
    names.
    '''

    # Setup for test - created variables accessible to AnsibleJ2Vars
    templar = AnsibleJ2Vars
    globals = {'name1': 'value1', 'name2': 'value2'}
    locals = {'name3': 'value3', 'name4': 'value4'}

    ansible_vars = AnsibleJ2Vars(templar, globals, locals)

    # Success - return value for name1
    assert ansible_vars['name1'] == 'value1'

    # Success - return value for name2
    assert ansible_vars['name2'] == 'value2'

    #

# Generated at 2022-06-21 08:00:52.908604
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar

    templar = Templar(None)

    my_vars = {}
    my_globals = {}

    J2Vars = AnsibleJ2Vars(templar, my_globals, locals=my_vars)

    try:
        J2Vars['my_undefined_var']
    except KeyError:
        pass
