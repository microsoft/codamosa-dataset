

# Generated at 2022-06-23 13:22:59.877927
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    globals = {
        'x': 'y',
        'z': 'zz',
    }

    locals = {
        'a': None,
        'b': 'c',
        'd': 'e',
        'f': 'g'
    }

    templar = None

    a = AnsibleJ2Vars(templar, globals, locals)

    assert len(a) == len(expect_a)


# Generated at 2022-06-23 13:23:03.742867
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    vars = AnsibleJ2Vars().__iter__()
    assert type(vars) == 'set'


# Generated at 2022-06-23 13:23:09.078568
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = None
    globals = {"a": "b"}
    locals = {"c": "d"}

    test_obj = AnsibleJ2Vars(templar, globals, locals)
    ret = test_obj.add_locals({"e": "f"})
    assert ret._locals.get("c") == "d"
    assert ret._locals.get("e") == "f"

# Generated at 2022-06-23 13:23:19.375247
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # pylint: disable=too-few-public-methods
    class Templar():
        available_variables = {'var3':'value of var3'}
    class AnsibleUndefinedVariable(Exception):
        def __init__(self, msg):
            self.message = msg
    # Initialize an AnsibleJ2Vars object with the method under test
    ansible_j2_vars = AnsibleJ2Vars(Templar(), {'var1':'value of var1'})
    # Call the method with an empty locals dictionary
    ansible_j2_vars_empty_locals = ansible_j2_vars.add_locals({})
    # Check that locals are empty and that var1 is defined in globals
    assert not ansible_j2_vars_empty_locals._loc

# Generated at 2022-06-23 13:23:25.713094
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    globals = {}
    locals = {}
    templar = Templar()
    variable_proxy = AnsibleJ2Vars(templar, globals, locals)
    variable_proxy['foo'] = 'bar'
    variable_proxy['bar'] = 'foo'
    variable_proxy['baz'] = 'blah'
    variable_proxy['bark'] = 'meow'
    assert len(variable_proxy) == 4


# Generated at 2022-06-23 13:23:30.893691
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class Templar(object):
        def __init__(self, available_variables):
            self.available_variables = available_variables
        def template(self, variable):
            return self.available_variables[variable]

    templar = Templar({ 'a': 1 })
    assert AnsibleJ2Vars(templar, None, None)['a'] == 1

# Generated at 2022-06-23 13:23:38.482427
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible import constants as C
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    vm = VariableManager()
    vm.extra_vars = dict(test1=dict(a=1, b=2), test2=3, test3=4, test4='value4')
    templar = Templar(loader=None, shared_loader_obj=None, variables=vm)

    # Variable names are not in available_variables
    vars = AnsibleJ2Vars(templar, {})
    assert {} == vars._locals
    assert {} == vars._templar.available_variables
    assert {} == vars._templar._available_variables
    assert {} == vars.templar._available_variables

    # There are no variable names in available

# Generated at 2022-06-23 13:23:42.266205
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(None)
    j2vars = AnsibleJ2Vars(templar, dict(), locals=dict(l_a=1, l_b=2, l_c=3))
    assert dict(j2vars) == dict(a=1, b=2, c=3)
    j2vars_locals = j2vars.add_locals(dict(l_d=4, l_e=5, l_f=6))
    assert dict(j2vars_locals) == dict(a=1, b=2, c=3, d=4, e=5, f=6)

# Generated at 2022-06-23 13:23:49.646538
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.manager import create_variable_manager

    variable_manager = create_variable_manager()
    variable_manager._extra_vars = {}
    variable_manager._options_vars = {}
    variable_manager._host_vars = {}
    variable_manager._group_vars = {}

    templar = Templar(loader=None, variables=variable_manager)

    var = AnsibleJ2Vars(templar, {})

    assert len(var) == 0


# Generated at 2022-06-23 13:23:58.749159
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=None)
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host='localhost', varname='hostvars_test', value=HostVars(hostname='localhost', inventory_hostname='localhost'))
    variable_manager.set_host_variable(host='localhost', varname='vars_test', value={'ansible_ssh_host': '192.168.0.1'})

# Generated at 2022-06-23 13:24:09.686235
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    variables = {
        'hostvars': HostVars(hostname='127.0.0.1', variables={'ansible_connection': 'local'}),
        'vars': {'a': 'A'},
        }
    loader  = DataLoader()
    templar = Templar(loader=loader, variables=variables)

    j2vars = AnsibleJ2Vars(templar, globals=dict(), locals=dict())
    assert j2vars['vars'] == variables['vars']
    assert j2vars['hostvars'] == variables['hostvars']

# Generated at 2022-06-23 13:24:16.544654
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    # Initialize AnsibleJ2Vars class
    #templar = Templar()
    globals = {}
    locals = {}
    ansible_j2vars = AnsibleJ2Vars(None, globals, locals)

    # Get expected value
    expected_value = 0

    # Get actual value
    actual_value = ansible_j2vars.__len__()

    # Check if actual value is equal to expected value
    assert actual_value == expected_value


# Generated at 2022-06-23 13:24:26.964097
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
        AnsibleJ2Vars:__getitem__ - Without exception
            - with hostvars
            - with vars
            - with unsafe
            - with value
            - without value
    '''
    from ansible.vars.hostvars import HostVars

    class MyJinja2Templar(object):
        def __init__(self, my_dict):
            self.my_dict = my_dict

        def template(self, val):
            if val not in self.my_dict:
                raise AnsibleUndefinedVariable("%s is not defined" % val)
            else:
                return self.my_dict[val]

        @property
        def available_variables(self):
            return self.my_dict

    class MyTestClass(object):
        pass


# Generated at 2022-06-23 13:24:33.266845
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    t = Templar(loader=None)
    ajv = AnsibleJ2Vars(templar=t, globals=None, locals=None)

    assert t is ajv._templar
    assert not ajv._locals

    ajv._templar.available_variables = dict(a=1)
    assert 1 == ajv['a']

    ajv._templar.available_variables['vars'] = dict(b=2)
    assert 2 == ajv['b']
    assert dict(b=2) == ajv['vars']

    ajv._locals = dict(c=3)
    assert 3 == ajv['c']

    ajv._globals = dict(d=4)
    assert 4

# Generated at 2022-06-23 13:24:42.185456
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY2
    import jinja2
    import sys

    templar = Templar(loader=None, variables={})

    # jinja2 2.9+
    if sys.version_info[0] >= 3 or (sys.version_info[0] == 2 and sys.version_info[1] >= 9):
        assert not templar.environment

    # jinja2 2.10+
    if sys.version_info[0] >= 3 or (sys.version_info[0] == 2 and sys.version_info[1] >= 10):
        assert not templar.template_class

    # jinja2 2.7+

# Generated at 2022-06-23 13:24:42.894218
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass

# Generated at 2022-06-23 13:24:50.933790
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.templating import Templar
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, templar=templar, inventory=inventory)

    globals = {
        'key1': 'value1',
        'key2': 'value2',
    }


# Generated at 2022-06-23 13:24:55.681676
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2
    import jinja2.runtime

    globals = dict()
    locals = dict()
    locals['jinja2'] = jinja2
    locals['jinja2.runtime'] = jinja2.runtime
    j2vars = AnsibleJ2Vars(templar=None, globals=globals, locals=locals)

    assert len(j2vars) == 2

# Generated at 2022-06-23 13:25:00.445007
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = {
        'test': 'success',
    }
    locals = {
        'test': 'success',
    }
    ajvars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert 'test' in ajvars
    assert 'nonexisting' not in ajvars


# Generated at 2022-06-23 13:25:12.209908
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.hostvars import HostVars
    ansible_vars = {'string': 'string', 'unicode': AnsibleUnicode('unicode'), 'int': 1, 'dict': {'k': 'v'}, 'host_vars': HostVars(host_name='hostvars', variables={'host_vars': {'host': 'host'}}, vault_password=None)}
    ansible_vars_key_only = {'string': 'string', 'unicode': AnsibleUnicode('unicode'), 'int': 1, 'dict': {'k': 'v'}, 'host_vars': None}

# Generated at 2022-06-23 13:25:20.653557
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import safe_eval


# Generated at 2022-06-23 13:25:24.855002
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.template import Templar
    templar = Templar()
    j2_vars = AnsibleJ2Vars(templar, globals={'test': 'working'})
    assert len(j2_vars) == 1

# Generated at 2022-06-23 13:25:35.370285
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class TestTemplar():
        # Test __init__() of AnsibleJ2Vars
        def __init__(self):
            self.available_variables = dict()
            # Test __contains__() of AnsibleJ2Vars
            self.available_variables.update({
                "item1": {"item2": {"item3": "value"}}
            })
            # Test __getitem__() of AnsibleJ2Vars
            self.available_variables.update({
                "item4": ["item5", "item6"]
            })
            # Test __len__() of AnsibleJ2Vars
            self.available_variables.update({
                "item7": "value"
            })
            # Test __iter__() of AnsibleJ2Vars

# Generated at 2022-06-23 13:25:36.563443
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass


# Generated at 2022-06-23 13:25:39.119551
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = None
    globals = {}
    locals = None
    assert AnsibleJ2Vars(templar, globals, locals) != None


# Generated at 2022-06-23 13:25:39.730232
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    pass

# Generated at 2022-06-23 13:25:44.493879
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    t = Templar(loader=None)
    globals = dict(test='test')
    t.set_available_variables(globals)
    locals = dict(test2='test2')
    vars = AnsibleJ2Vars(templar=t, globals=globals, locals=locals)
    assert vars['test'] == 'test'
    assert vars['test2'] == 'test2'

# Generated at 2022-06-23 13:25:45.113144
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass

# Generated at 2022-06-23 13:25:51.561166
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar      = Templar(loader=DataLoader(), variables={}, shared_loader_obj=play_context)

    globals     = {'a': 5, 'b': 12}
    locals      = {'c': 8, 'd': 15}

    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 4 == len(vars)
    assert vars['a'] == 5
    assert vars['b'] == 12
    assert vars['c'] == 8
    assert vars['d'] == 15

    templar.set_available_variables(vars)

    gen

# Generated at 2022-06-23 13:26:01.960158
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Init an object
    templar = None
    globals = None
    locals = None
    myobj = AnsibleJ2Vars(templar, globals, locals)

    # Test with a simple key
    var1 = 'abc'
    result = myobj.__contains__(var1)
    assert result == False

    # Test with an existing key
    # locals = dict()
    # locals['abc'] = 'value of abc'
    # myobj = AnsibleJ2Vars(templar, globals, locals)
    # result = myobj.__contains__(var1)
    # assert result == True


# Generated at 2022-06-23 13:26:09.220367
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from jinja2.runtime import StrictUndefined
    from ansible.templating.jinja2 import Templar

    test_data = {'a': 1, 'b': 2, 'missing_data': StrictUndefined}
    templar = Templar(loader=None, variables=test_data)

    len1 = len(AnsibleJ2Vars(templar=templar, globals={'a': 1}))
    len2 = len(AnsibleJ2Vars(templar=templar, globals={}))
    assert len1 == len2 == 3

# Generated at 2022-06-23 13:26:19.212883
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import accomplish_wrap
    from ansible.template.template import Templar
    from ansible.plugins.filter.core import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    apply_filter = accomplish_wrap(wrap_var)

    template = "{{ansible_managed}}"
    templar = Templar(loader=None, variables={'ansible_managed': apply_filter('__ansible_managed_default__')})

    globals = dict()
    globals['ansible_managed'] = apply_filter('__ansible_managed_default__')

    ajv = AnsibleJ2Vars(templar, globals=globals)
    assert len(ajv) == 3


# Generated at 2022-06-23 13:26:23.585058
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from .templar import Templar

    templar = Templar(loader=None)

    available_variables = dict()

    available_variables.update(dict(_SENTINEL_GLOBALS='Test value'))

    ansible_j2_vars = AnsibleJ2Vars(templar, available_variables, locals=None)

    assert('_SENTINEL_GLOBALS' in ansible_j2_vars)
    assert('_SENTINEL' not in ansible_j2_vars)


# Generated at 2022-06-23 13:26:34.394740
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import pytest
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.yaml.objects import AnsibleUnicode
    ansible_vars = {
        "vars": {
            "A": "a1",
            "B": "b1",
            "C": "c1"
        },
        "omit": {
            "A": "a1",
            "B": "b1",
            "C": "c1"
        },
        "A": "a1",
        "B": "b1",
        "C": "c1"
    }

    templar = Templar(loader=None, variables=ansible_vars)

# Generated at 2022-06-23 13:26:46.694393
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    templar = object()
    globals = {}
    locals = {}

    ansible_vars = AnsibleJ2Vars(templar, globals, locals)

    # Test empty case
    assert len(ansible_vars) == 0

    # Test non-empty case
    ansible_vars._templar.available_variables = {'v1': 'v1', 'v2': 'v2'}
    ansible_vars._locals = {'l1': 'l1', 'l2': 'l2', 'l3': 'l3'}
    ansible_vars._globals = {'g1': 'g1', 'g2': 'g2'}

    assert len(ansible_vars) == 5

# Generated at 2022-06-23 13:26:54.472197
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    jv1 = AnsibleJ2Vars(Templar(loader=None), {})

    # test locals with one element
    locals_1 = {'l_var' : 'l_value'}
    jv2 = jv1.add_locals(locals_1)
    assert jv2['var'] == 'l_value'
    assert jv2['l_var'] == 'l_value'

    # test locals with more than one element
    locals_2 = {'l_var' : 'l_value', 'l_var2' : 'l_value2'}
    jv3 = jv1.add_loc

# Generated at 2022-06-23 13:27:03.597764
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    var_manager = VariableManager()

    # Initialize required objects
    templar = Templar(loader=loader, variables=var_manager)

    variables = dict(a="ansible", b=dict(c="cool"))
    j2vars = AnsibleJ2Vars(templar, variables)

    # Template variable 'a'
    assert (j2vars['a'] == "ansible")

    # Template variable 'b.c'
    assert (j2vars['b.c'] == "cool")

    # Test __contains__()
    assert ('a' in j2vars)

# Generated at 2022-06-23 13:27:14.209683
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.templar import MockTemplar

    from ansible.parsing.vault import VaultLib
    from ansible.vars.manager import VariableManager

    with patch.multiple(VaultLib, is_encrypted_file=DEFAULT, is_encrypted_data=DEFAULT):
        vault_secret = "password"
        vault_password_file = "/dev/null"
        loader = DictDataLoader({})
        vault = VaultLib(vault_secret, vault_password_file, loader=loader)

    var_manager = VariableManager()
    var_manager.extra_vars = {'first_key': 'first_value'}
    var_manager.host_

# Generated at 2022-06-23 13:27:24.278957
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class Templar:
        def __init__(self):
            self.available_variables = dict()
        def template(self,content):
            return content

    mytemplar = Templar()

    myglobals = dict()

    proxy = AnsibleJ2Vars(mytemplar, myglobals)

    class MyDict(dict):
        pass

    value = MyDict()
    value["key"] = "value"
    mytemplar.available_variables["my_dict"] = value
    result = proxy.__getitem__("my_dict")
    assert "key" in result.keys()

    class MyAccessible(object):
        key = "value"
        def __getattribute__(self, name):
            return object.__getattribute__(self,name)

# Generated at 2022-06-23 13:27:30.880293
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    globals = { 'a': 1, 'b': 2, 'c': 3 }
    locals = { 'd': 4, 'e': 5, 'f': 6 }

    templar = AnsibleJ2Vars(None, globals, locals)

    assert len(templar) == 6

    for k in templar:
        assert templar[k] == locals[k]

# Generated at 2022-06-23 13:27:40.009802
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host

    templar = Templar(loader=None, shared_loader_obj=None, variables=VariableManager())
    # test __getitem__(varname) with all kinds of variables
    # build a dict
    one_level_dict = {'a':1, 'b':2, 'c':3}
    # build a list
    one_level_list = [1, 2, 3, 4]
    # build a string
    string = 'a string'
    # build a number
    number = 1
    # build a dict (hostvars) of Host()
    hostvars_dict = dict()

# Generated at 2022-06-23 13:27:41.931393
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass


# Generated at 2022-06-23 13:27:50.859949
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.module_utils.common._collections_compat import Mapping
    def test_sets(templar, globals, locals, expected):
        var_proxy = AnsibleJ2Vars(templar, globals, locals=locals)
        s = set(var_proxy)

        assert len(s) == len(expected)
        for e in expected:
            assert e in s

    test_sets(None, None, None, [])

    templar = {}
    globals = {
        'foo': 'bar',
        'bar': 'foo',
    }
    locals = {
        'baz': 'qux',
    }
    expected = ['baz', 'foo', 'bar']
    test_sets(templar, globals, locals, expected)


# Generated at 2022-06-23 13:28:01.692325
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    hostvars = HostVars(host_name="localhost")
    hostvars.update({'test1': 'test1'})

    globals = {'ansible_facts': hostvars,
               'ansible_test2': 'test2',
               'ansible_test3': AnsibleUnsafeText('test3')}
    templar = {}

    # 1. test that exception raises if key is not found in all dictionaries
    ansible_j2_vars = AnsibleJ2Vars(templar, globals)
    got_exception = False


# Generated at 2022-06-23 13:28:09.596591
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    from ansible.template import Templar
    from ansible.parsing.jparser import JsonParser
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_dict = {'var1': 1, 'var2': 2, 'var3': 3, 'var4': 4}
    yaml = AnsibleLoader(yaml_dict, JsonParser()).get_single_data()

    templar = Templar(None, loader=None, variables=yaml)

    globals = {'var1': 1, 'var2': 2, 'var3': 3, 'var4': 4}
    locals = {'var1': 1, 'var2': 2, 'var3': 3, 'var4': 4}


# Generated at 2022-06-23 13:28:19.477169
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
  # jinja2 is not required for this, so we'll use the fake version
  from ansible.module_utils.six.moves import builtins
  fake_jinja2 = builtins.__import__('fake_jinja2')
  templar = fake_jinja2.Templar(loader=None)
  vars = AnsibleJ2Vars(templar, {'foo': 'bar'}, locals={'baz': 'qux'})

  # Even though locals were added, they do not exist yet
  assert 'baz' not in vars
  assert 'foo' not in vars
  # There are no variables, yet
  assert len(vars) == 0

  # The first time we see variables, we make them available to getitem

# Generated at 2022-06-23 13:28:29.217788
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'a': 1, 'b': 2, 'c': 3})
    vars = AnsibleJ2Vars(templar=templar, globals={'a': 1})
    assert len(vars) == 5

    # The ansible.module_utils.common._collections_compat.Mapping is an abstract
    # class which defines a variable mapping. The python2.6 doesn't support
    # abstract class, so we need to make sure that vars variables is mapping
    assert isinstance(vars, Mapping)



# Generated at 2022-06-23 13:28:37.340204
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    new_locals = dict()
    new_locals['foo'] = 'bar'
    new_locals['baz'] = 'qux'
    new_locals['corge'] = 'grault'

    obj = AnsibleJ2Vars(None, dict(), dict())
    obj2 = obj.add_locals(new_locals)
    assert obj2._locals == new_locals

    obj3 = obj2.add_locals(dict())
    assert obj3._locals == new_locals

# Generated at 2022-06-23 13:28:45.351433
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        import jinja2
        import jinja2.utils
        import jinja2.environment
        import jinja2.runtime
    except Exception as e:
        print("SKIP: could not import jinja2: %s" % e)
        import sys
        sys.exit(0)

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inv = InventoryManager(loader)
    vm = VariableManager()
    vm.set_inventory(inv)
    r_play = Play.load(dict(name="test"), variable_manager=vm, loader=loader)

    # this is needed to get the vars

# Generated at 2022-06-23 13:28:54.311732
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host

    vm = VariableManager()
    h = Host()

    err_msg = 'Variable %s is not available'

    templar = Templar(loader=None, variables=vm, host=h)
    ansible_vars = AnsibleJ2Vars(templar, dict(), dict())

    # Raise error when variable does not exist
    for variable in [u'var_1', u'var_2', u'var_3']:
        try:
            variable in ansible_vars
            assert False, 'variable exists, this should not happen'
        except:
            assert True

# Generated at 2022-06-23 13:29:04.859697
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()
    globals = dict()

    with open('test_AnsibleJ2Vars__getitem__.data', 'r') as f:
        lines = f.readlines()
        for line in lines:
            index = line.find(" ")
            locals = dict(l_a=line[:index], l_b=line[index+1:])
            vars = AnsibleJ2Vars(templar, globals, locals)
            result = vars['a']
            assert result == line[:index]
            result = vars['b']
            assert result == line[index+1:]



# Generated at 2022-06-23 13:29:14.977996
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class FakeTemplar(object):
        def __init__(self, available_variables):
            self.available_variables = available_variables

        def template(self, variable):
            return variable

    class FakeVars(Dict):
        def __contains__(self, k):
            return True

    fake_globals = FakeVars({'b': 2})

    fake_templar = FakeTemplar({'a': 1})

    ansible_j2_vars = AnsibleJ2Vars(fake_templar, fake_globals)

    assert len(ansible_j2_vars) == 3


# Generated at 2022-06-23 13:29:26.102074
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Test AnsibleJ2Vars.add_locals() method.

    :return:
    '''

    from jinja2.utils import missing
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.module_utils.six import PY2
    import jinja2
    import os, tempfile
    from ansible.module_utils._text import to_bytes

    facts = {'os_family': 'RedHat'}

    test_globals = {'foo': 'bar', 'os_family': 'RedHat', 'baz': missing}

    test_template = '''
    {{ foo }}
    {{ os_family }}
    {{ baz }}
    '''

    (fd, test_path) = tempfile.mkstem

# Generated at 2022-06-23 13:29:31.452853
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = Templar()
    j2vars = AnsibleJ2Vars(templar, { "somevar": "somevalue" })
    assert "somevar" in j2vars
    assert "somevalue" in j2vars
    assert "someothervar" not in j2vars


# Generated at 2022-06-23 13:29:42.263151
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class FakeTemplar:
        def __init__(self, available_variables):
            self.available_variables = available_variables
        def template(self, var):
            return var
    assert AnsibleJ2Vars(None, {}, {'var1': 'value1', 'var2': 'value2'}).keys() == ['var1', 'var2']
    assert AnsibleJ2Vars(FakeTemplar({'var3': 'value3', 'var4': 'value4'}), {'var5': 'value5', 'var6': 'value6'}).keys() == ['var3', 'var4', 'var5', 'var6']

# Generated at 2022-06-23 13:29:55.188592
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {}
    locals = None

    # Create an instance of class AnsibleJ2Vars and test the loading of the class attributes
    ansible_j2_vars_instance1 = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars_instance1._templar == templar
    assert ansible_j2_vars_instance1._globals == globals
    assert ansible_j2_vars_instance1._locals == {}

    locals = {'a': 1, 'l_a': 1}
    # Create an instance of class AnsibleJ2Vars and test the loading of the class attributes
    ansible_j2_vars_instance2 = Ans

# Generated at 2022-06-23 13:29:59.400185
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    j = AnsibleJ2Vars(None, dict(), dict())
    j._templar.available_variables = dict(a=10)
    j._locals = dict(a=100)
    assert j['a'] == 100

    j = AnsibleJ2Vars(None, dict(), dict())
    j._templar.available_variables = dict(a='{{c}}', b=dict(c=100))
    assert j['a'] == 100
    try:
        j['c']
        assert False, 'Invalid key "c" should have failed'
    except KeyError:
        pass

# Generated at 2022-06-23 13:30:10.101843
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    j2vars = AnsibleJ2Vars(templar, dict())
    assert len(j2vars) == 0

    templar = Templar(loader=None, variables={'a':'1', 'b':'2'})
    j2vars = AnsibleJ2Vars(templar, dict())
    assert len(j2vars) == 2

    templar = Templar(loader=None, variables={'a':'1', 'b':'2'})
    j2vars = AnsibleJ2Vars(templar, dict())
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'c' not in j2vars
    assert len

# Generated at 2022-06-23 13:30:18.592954
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.template
    #test 1: undefined variable
    name = 'test'
    vars_obj = ansible.template.AnsibleJ2Vars(None, None, None)
    # assert no such variable
    assert 'test' not in vars_obj
    # assert getitem fails as well
    try:
        vars_obj['test']
        # fail the test if getitem does not fail
        assert False
    except KeyError:
        assert True

    # test 2: defined variable
    vars_obj._locals = {'test': {'key': 'value'}}
    assert 'test' in vars_obj
    val = vars_obj['test']
    assert val == {'key': 'value'}

# Generated at 2022-06-23 13:30:24.562799
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Test __contains__ of AnsibleJ2Vars.
    '''

    templar = None
    globals = {'gvar': [1, 2]}
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'gvar' in vars

    assert 'l_var' not in vars

    locals.update({'l_var': 100})
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'l_var' in vars



# Generated at 2022-06-23 13:30:35.052601
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class Templar():
        def __init__(self):
            self.available_variables = dict(
                x = dict(
                    y = dict(
                        z = 42,
                    ),
                ),
            )

    globals = dict(a = 1, b = 2)
    locals = dict(c = 3, d = 4)

    vars = AnsibleJ2Vars(Templar(), globals, locals)

    assert 'a' in vars
    assert 'b' in vars
    assert 'c' in vars
    assert 'd' in vars

    for name in Templar().available_variables:
        assert name in vars

    for name in Templar().available_variables['x']:
        assert name in vars


# Generated at 2022-06-23 13:30:43.152932
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    template_string = "{{ a + b }}"
    t = Templar(loader=None, variables=dict(a=1, b=2))
    v = AnsibleJ2Vars(t, globals=dict(), locals=dict(a=1))
    v = v.add_locals(dict(b=2))
    assert safe_eval(template_string, locals=v) == 3


# -- helper functions used in action plugins --


# Generated at 2022-06-23 13:30:53.334734
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class MockTemplar:
        available_variables = {"var1":"v1", "var2":"v2"}
    globals = {'global':'global_val'}
    locals = {'local':'local_val'}
    proxy = AnsibleJ2Vars(MockTemplar(), globals, locals)
    assert proxy['var1'] == "v1"
    assert proxy['var2'] == "v2"
    assert proxy['global'] == "global_val"
    assert proxy['local'] == "local_val"
    assert len(proxy) == 4
    assert 'var1' in proxy
    assert 'var2' in proxy
    assert 'var3' not in proxy
    assert 'local' in proxy
    assert 'global' in proxy
    assert 'global_local' not in proxy
    assert len

# Generated at 2022-06-23 13:31:01.791605
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    globals = dict(a=1, b=2)
    locals  = dict(c=3, d=4)
    proxy   = AnsibleJ2Vars(Templar(), globals, locals) # not an ideal test
    assert proxy['a'] == 1
    assert proxy['c'] == 3
    assert 'e' not in proxy
    try:
        proxy['e']
    except KeyError:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-23 13:31:09.483552
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # testing with locals only
    templar = None
    locals = {'test': 1}
    globals = None

    test_obj = AnsibleJ2Vars(templar, globals, locals=locals)
    test_add_locals = test_obj.add_locals(locals)
    assert test_add_locals._templar is None
    assert test_add_locals._globals == {}
    assert test_add_locals._locals['test'] == 1

    # testing with both locals and globals
    locals = {'test': 1}
    globals = {'test2': 2}

    test_obj = AnsibleJ2Vars(templar, globals, locals=locals)

# Generated at 2022-06-23 13:31:21.510376
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    varManager = VariableManager()
    templar = Templar(loader=None, variables=varManager)
    locals = {
        'x': '6'
    }
    y = '7'
    varManager.set_variable('y', y)
    varManager.set_variable('z', '8')
    j2_vars = AnsibleJ2Vars(templar, {}, locals)
    try:
        value = j2_vars['x']
        assert value == '6'
    except Exception as e:
        assert False
    try:
        value = j2_vars['y']
        assert value == '7'
    except Exception as e:
        assert False

# Generated at 2022-06-23 13:31:29.536808
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    import os

    assert isinstance(AnsibleJ2Vars.__getitem__, object)

    variable_manager = VariableManager()
    variable_manager.set_inventory(None)

    extra_vars = {'foo_1': 'bar1', 'foo_2': 'bar2'}

    variable_manager.extra_vars = extra_vars
    variable_manager.options_vars = ['etc/ansible/hosts']

    play_context = PlayContext()
    play_context.verbosity = 1

# Generated at 2022-06-23 13:31:37.577047
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    tmplar = Templar()
    vars_proxy = AnsibleJ2Vars(tmplar, globals=dict(), locals=dict(local_uts="answer is 42"))
    assert "local_uts" in vars_proxy
    assert vars_proxy["local_uts"] == "answer is 42"
    vars_proxy_new_locals = vars_proxy.add_locals(dict(local_uts="answer is not 43"))
    assert vars_proxy_new_locals["local_uts"] == "answer is not 43"

# Generated at 2022-06-23 13:31:40.928251
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar()
    # the only requirement to test the constructor is that
    # the input parameter must be an instance of class Templar
    assert isinstance(templar, Templar)

# Generated at 2022-06-23 13:31:48.811555
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = None
    globals = dict(x='x', t='t')
    locals = dict(y='y', t='T')
    proxy = AnsibleJ2Vars(templar, globals, locals)
    assert proxy['x'] == 'x'
    assert proxy['t'] == 'T'
    assert proxy['y'] == 'y'
    new_locals = dict(a='a', y='Y')
    # old locals should be unchanged
    assert proxy['y'] == 'y'
    proxy = proxy.add_locals(new_locals)
    # new locals should have been added
    assert proxy['a'] == 'a'
    # old locals should have been overwritten
    assert proxy['y'] == 'Y'
    # ... but the old locals object should be unchanged

# Generated at 2022-06-23 13:31:59.531244
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    mock_locals = {
        'mock_var': 'mock_value',
        'mock_dict': {
            'mock_dict_key': 'mock_dict_value'
        }
    }



# Generated at 2022-06-23 13:32:10.148920
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
        Unit test for the constructor of class AnsibleJ2Vars.
        Checks that when locals is a dictionary, the dictionary is copied to self._locals.
        If locals is None, nothing is copied.
    '''
    import jinja2.environment
    from ansible.parsing.vault import VaultLib

    templar = Templar(None, vault_password="vault_pass", loader=None)
    # locals is a dictionary
    globals = dict()
    locals = dict()
    jvars = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)
    assert jvars._locals == locals
    locals["test_locals"] = "test"

# Generated at 2022-06-23 13:32:21.247499
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import jinja2
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    available_variables = {"var_dict":{"key1": "value1", "key2": "value2"}, "var": "value"}
    j2_env = jinja2.Environment(undefined=jinja2.StrictUndefined)
    templar = Templar(loader=None, variables=available_variables)
    globals = {"g_key1": "g_value1", "g_key2": "g_value2"}

    ansible_j2vars = AnsibleJ2Vars(templar, globals)
    iterator = ansible_j2vars.__iter__()
    list_iterator = list(iterator)

# Generated at 2022-06-23 13:32:31.700747
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    class Templar(object):
        '''
        A dummy class to simulate Templar() object
        '''
        def __init__(self, data):
            self.available_variables = data

    def test_case(available_variables, locals, globals):
        templar = Templar(available_variables)
        vars_obj = AnsibleJ2Vars(templar, globals, locals)

        assert len(vars_obj) == len(set(available_variables.keys() + locals.keys() + globals.keys()))

    available_variables = {'var1': 1, 'var2': 2, 'var3': 3, 'var4': 4, 'var5': 5, 'var6': 6}

# Generated at 2022-06-23 13:32:35.034983
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ajv = AnsibleJ2Vars(None, dict())
    ret = "foo" in ajv
    assert ret is False

# Generated at 2022-06-23 13:32:42.551519
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    templar = Templar(loader=DataLoader())
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3, 'd': 4}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert all(k in vars for k in ('a', 'b', 'c', 'd'))

    # locals should be preferred over globals
    assert vars['a'] == 3
    assert vars['b'] == 4

# Generated at 2022-06-23 13:32:51.872293
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2

    globals = {'a': 'b'}
    locals1 = {}
    locals2 = {
        'e': 'f',
        'g': 'h',
    }
    templar = jinja2.Environment(loader=jinja2.FileSystemLoader('')).from_string('test_template').make_module({})

    vars1 = AnsibleJ2Vars(templar, globals=locals1)
    vars2 = AnsibleJ2Vars(templar, globals=locals2)

    assert len(vars1) == 1
    assert len(vars2) == 3

# Generated at 2022-06-23 13:33:00.139308
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os
    import unittest

    from ansible.module_utils.six import StringIO
    from ansible.template import Templar, TemplarError
    from ansible.parsing.vault import VaultLib
    from ansible.config.manager import ConfigManager
    from units.mock.loader import DictDataLoader

    class AnsibleJ2VarsTestCase(unittest.TestCase):
        TEST_VARIABLE_NAME = "varname"
        TEST_VARIABLE_VALUE = "varname_value"
        TEST_GLOBAL_NAME = "globalname"
        TEST_GLOBAL_VALUE = "globalname_value"
        TEST_KEY = "key"
        TEST_VALUE = "value"
        TEST_VARS = ["var_a", "var_b", "var_c"]