

# Generated at 2022-06-23 13:22:58.451528
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    templar = Templar(loader=None, variables={}, fail_on_undefined=False)
    globals = {'var': 'value'}
    locals = {'loop_var': 'loop_value'}
    ajv = AnsibleJ2Vars(templar, globals, locals=locals)
    ajv_w_locals = ajv.add_locals({'more_locals': 'more_values'})
    assert ajv_w_locals._locals['loop_var'] == 'loop_value'
    assert ajv_w_locals._locals['more_locals'] == 'more_values'
    assert 'loop_var' not in ajv._loc

# Generated at 2022-06-23 13:23:09.903364
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    import pdb

    base_vars = {'foo': 'bar', 'baz': 'quux'}
    base_locals = {'local_foo': 'local_bar'}
    new_locals = {'new_local_foo': 'new_local_bar'}

    templar = Templar(loader=None)
    templar.available_variables = base_vars
    j2vars = AnsibleJ2Vars(templar, globals={}, locals=base_locals)

    # Test when new locals is None
    assert(j2vars.add_locals(None) == j2vars)

    # Test when new locals is a dict

# Generated at 2022-06-23 13:23:10.794037
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass



# Generated at 2022-06-23 13:23:20.597823
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import safe_eval

    templar = safe_eval.construct_mapping("""
    {
        "_templar": {
            "available_variables": {
                "va": "42"
            }
        },
        "_globals": {
            "gg": "42"
        },
        "_locals": {
            "ll": "42"
        }
    }
    """)

    assert AnsibleJ2Vars(templar._templar, templar._globals, locals=templar._locals)["va"] == "42"
    assert "va" in AnsibleJ2Vars(templar._templar, templar._globals, locals=templar._locals)

# Generated at 2022-06-23 13:23:31.239077
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar(loader=None)
    globals = dict(unsafe_test = UnsafeProxy())

    var_proxy = AnsibleJ2Vars(templar, globals)
    assert 'unsafe_test' in var_proxy

    # if locals passed to constructor is not a dict, then its a no-op
    var_proxy = AnsibleJ2Vars(templar, globals, locals=None)
    assert 'unsafe_test' in var_proxy

    var_proxy = AnsibleJ2Vars(templar, globals, locals=object())
    assert 'unsafe_test' in var_proxy

    # check that locals is copied
    var_proxy = AnsibleJ2Vars

# Generated at 2022-06-23 13:23:35.828341
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class Templar:
        def __init__(self):
            self.available_variables = {'a':1, 'b':2}

    t = Templar()

    a = AnsibleJ2Vars(t, {'c':3})
    assert len(a) == 3
    a = AnsibleJ2Vars(t, {'c':3}, {'d':4})
    assert len(a) == 4


# Generated at 2022-06-23 13:23:41.177994
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    try:
        from ansible.template import Templar
    except:
        raise ImportError()

    templar = Templar(loader=None)

    globals = {
        'test1': 1,
        'test2': 2,
    }

    locals = {
        'test3': 3,
        'test4': 4,
    }

    ansible_vars = {
        'test5': 5,
        'test6': 6,
    }

    aj2v = AnsibleJ2Vars(templar, globals, locals)
    templar._available_variables = ansible_vars

    assert hasattr(aj2v, '__iter__')
    assert callable(getattr(aj2v, '__iter__'))

    iterator = aj2v.__iter__()

   

# Generated at 2022-06-23 13:23:50.524637
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    # The locals provided to AnsibleJ2Vars.add_locals() are the vars of the current template
    # (the "local" vars, as opposed to globals or vars from other templates). The new_locals dict
    # created in AnsibleJ2Vars.add_locals() should contain all the vars in locals as well as
    # any other vars in self._locals.

    from ansible.templating import Templar
    templar = Templar(loader=None, variables=None)

    locals = {'a': 1, 'b': 2, 'c': 3}
    ajv1 = AnsibleJ2Vars(templar, {}, locals=locals)

    locals = {'d': 4, 'e': 5}
    ajv2 = ajv1.add_locals

# Generated at 2022-06-23 13:23:59.302816
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager.set_known_hosts_file("/usr/local/etc/ansible/hosts")
    variable_manager.extra_vars = {'test_var': 'value of test_var'}
    templar = Templar(loader=loader, variables=variable_manager)

    test_vars = AnsibleJ2Vars(templar, {'test_global': 'value of test_global'}, locals={'test_locals': 'value of test_locals'})

    assert len(test_vars) == 3
    assert test_vars['test_var'] == 'value of test_var'

# Generated at 2022-06-23 13:24:10.416668
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class Templar():

        def __init__(self):
            self.available_variables = {
                'var1': 'value1',
                'var2': 'value2',
            }

        def template(self, variable):
            return variable

    globals = {
        'var3': 'value3',
        'var4': 'value4',
    }

    locals = {
        'var5': 'value5',
        'var6': 'value6',
    }

    j2_vars = AnsibleJ2Vars(Templar(), globals, locals=locals)

    # j2_vars contains var1
    assert 'var1' in j2_vars

    # j2_vars should contain 6 keys (var1, var2, var3, var4, var5 and var6)

# Generated at 2022-06-23 13:24:20.074960
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """
    AnsibleJ2Vars override __getitem__() to template variable before jinja2 sees it.
    """
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.hostvars import HostVars

    templar = Templar(None)
    globals = dict()
    locals = {'context': 'test', 'environment': 'test', 'template': 'test'}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # test with dict and HostVars
    dict_test = dict()
    dict_test['test_dict'] = 'test_dict'
    vars['vars'] = dict_test

# Generated at 2022-06-23 13:24:26.162115
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import ansible_safe_eval, ansible_builtin_lookup
    from ansible.template import Templar
    import pytest
    import os

    current_dir = os.path.dirname(os.path.abspath(__file__))
    test_data = os.path.join(current_dir, "test_J2Vars_iter")
    test_data = os.path.join(test_data, "test_data.yml")

    test_data = ansible_safe_eval.load_data(test_data)

    test_vars = test_data['test_data']['test_vars']
    test_globals = test_data['test_data']['test_globals']

    templar = Templar(loader=None)


# Generated at 2022-06-23 13:24:32.038813
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    j2vars = get_AnsibleJ2Vars_obj()
    locals = dict(a=1)

    new_j2vars = j2vars.add_locals(locals)
    assert new_j2vars._locals['a'] == locals['a']
    assert new_j2vars._locals['b'] == j2vars._locals['b']


# Generated at 2022-06-23 13:24:41.245100
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from tempfile import mkdtemp
    import shutil
    import sys
    import os
    sys.path.append(os.path.join(mkdtemp()))
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib'))
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {'foo': 'bar'}
    locals = {'foo': 'baz'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert len(ajv) == 1
    assert next(iter(ajv)) == 'foo'
    shutil.rmtree(sys.path.pop(0))
    sys.path.pop()

# Generated at 2022-06-23 13:24:48.432513
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    tem = Templar(loader=None)
    a = AnsibleJ2Vars(tem, {})

    keys = set()
    for key in a:
        keys.add(key)
    assert len(keys) == 1
    assert 'environment' in keys

    keys = set()
    a = AnsibleJ2Vars(tem, {'foo': 1})
    for key in a:
        keys.add(key)
    assert len(keys) == 2
    assert 'foo' in keys
    assert 'environment' in keys


# Generated at 2022-06-23 13:24:58.775100
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    basedir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with undefined variables
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert "undefined" not in vars
    assert "undefined" not in vars
    assert "undefined" not in vars
    assert "undefined" not in vars
    assert "undefined_var" not in v

# Generated at 2022-06-23 13:25:06.055985
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    globals = {
        'hostvars': HostVars(hostvars={'host1': {'f1': 'abc', 'f2': {'f3': 123}}}),
    }

    j2vars = AnsibleJ2Vars(templar, globals, locals=dict(vars=dict(k1='v1', k2=['vide', 'vide', 'vide'], k3=dict(k4='v4', k5=dict(k6='v6')))))
    assert j2vars['k1'] == 'v1'
    assert j

# Generated at 2022-06-23 13:25:17.001067
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from jinja2.runtime import Undefined

    # Dummy variables for testing
    vars = {'var1': 'foo', 'var2': 'bar'}
    globals = {}
    locals = {'local1': 'var1', 'local2': 'var2'}

    class Templar:
        '''
        Dummy Templar class for testing AnsibleJ2Vars
        '''

        @classmethod
        def template(cls, var):
            '''
            Dummy method for Templating a variable
            '''

            # If the variable is a dict, return it itself
            # Otherwise, return the value of the variable
            if isinstance(var, dict):
                return var
            else:
                return vars[var]

    # Create AnsibleJ2Vars object
    aj2v = AnsibleJ

# Generated at 2022-06-23 13:25:28.124812
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    locals = {'hostvars': HostVars()}
    globals = {}

    var_proxy = AnsibleJ2Vars(templar, globals, locals=locals)

    locals['new_local'] = 'value_of_new_local'
    assert 'new_local' in locals
    assert 'new_local' in var_proxy
    assert locals['new_local'] == var_proxy['new_local']

    globals['new_global'] = 'value_of_new_global'
    assert 'new_global' in var_proxy
    assert globals['new_global'] == var_proxy['new_global']

    templar.available_vari

# Generated at 2022-06-23 13:25:34.705559
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}
    vars = AnsibleJ2Vars(templar, globals, locals={'d': 4, 'e': 5, 'f': 6})
    assert set(vars) == set(['a', 'b', 'c', 'd', 'e', 'f'])



# Generated at 2022-06-23 13:25:43.596914
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class FakeTemplar():
        def __init__(self):
            self.available_variables = {'test': 'variable'}

        def template(self, variable):
            return variable

    # test if variable is in locals
    locls = {'test': 'local'}
    glob = {}
    vars = AnsibleJ2Vars(FakeTemplar(), glob, locls)
    assert vars['test'] == 'local'

    # test if variable is in available_variables
    locls = {}
    glob = {}
    vars = AnsibleJ2Vars(FakeTemplar(), glob, locls)
    assert vars['test'] == 'variable'

    # test if variable is in globals
    locls = {}
    glob = {'test': 'global'}
    vars = Ansible

# Generated at 2022-06-23 13:25:45.545402
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    assert AnsibleJ2Vars(None, None).add_locals(None) is not None


# Generated at 2022-06-23 13:25:51.063303
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Unit test for the constructor

    # We should be able to construct
    templar = 'templar'
    globals = 'globals'
    locals = 'locals'
    instance = AnsibleJ2Vars(templar, globals, locals)

    # We should be able to access the parameters
    assert instance._templar == templar
    assert instance._globals == globals
    assert instance._locals == locals


# Generated at 2022-06-23 13:26:03.139496
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    hostvars = HostVars(
        variable_manager=variable_manager,
        loader=variable_manager._loader,
        hostname='test_host'
    )
    variable_manager._hostvars = {'test_host': hostvars}
    variable_manager._fact_cache = {'test_host': {}}

    inventory = InventoryManager(loader=None, variable_manager=variable_manager, sources=None)

# Generated at 2022-06-23 13:26:11.408640
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import unittest
    import ansible.templating.j2
    templar = ansible.templating.j2.Templar()
    vars = AnsibleJ2Vars(templar, {'test1': 'test1value'}, locals={'test2': 'test2value'})

    class AnsibleJ2VarsContainsTest(unittest.TestCase):
        def test_check_vars_contains__should_pass(self):
            self.assertTrue('test1' in vars)
        def test_check_vars_contains__should_pass(self):
            self.assertTrue('test2' in vars)

# Generated at 2022-06-23 13:26:22.992680
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """
    test ansible j2 vars:

    - __contains__(k)
    """
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    globals = {}

    locals = {"my_key": "my_val"}
    vars = {"my_other_key": "my_other_val"}

    container = AnsibleJ2Vars(loader, globals, locals)

    assert 'my_key' in container
    assert 'my_other_key' in container

    locals = {"my_other_key": "my_other_val"}
    vars = {"my_key": "my_val"}

    container = AnsibleJ2Vars(loader, globals, locals)

    assert 'my_key' in container
    assert 'my_other_key'

# Generated at 2022-06-23 13:26:34.035770
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    locals = {'d': 4, 'b': 'two'}
    globals = {'d': 4, 'b': 'two'}
    ansible_j2_vars = AnsibleJ2Vars('templar', locals)
    # class attributes are initialized and are of the correct type
    assert isinstance(ansible_j2_vars._templar, str)
    assert isinstance(ansible_j2_vars._locals, dict)
    assert isinstance(ansible_j2_vars._globals, dict)
    # attributes are initialized with the correct values
    assert ansible_j2_vars._templar == 'templar'
    assert ansible_j2_vars._locals == locals
    assert ansible_j2_vars._globals == globals

# Generated at 2022-06-23 13:26:39.558263
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    ansible_vars = {}
    ansible_vars['a'] = 'a1'
    ansible_vars['b'] = 'b1'
    ansible_vars['c'] = 'c1'

    ansible_j2vars = AnsibleJ2Vars(templar, ansible_vars)

    # len(ansible_j2vars) should return 3
    assert len(ansible_j2vars) == 3


# Generated at 2022-06-23 13:26:46.157253
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'foo': 'bar'})

    vars = AnsibleJ2Vars(templar=templar, globals={'baz': 'raz'})

    keys = set()
    for key in vars:
        keys.add(key)

    assert keys == set(('foo', 'baz'))



# Generated at 2022-06-23 13:26:50.726222
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # Set up locals
    locals = {}
    locals['inventory_hostname'] = 'hostname'
    locals['inventory_hostname_short'] = 'hostnameshort'
    locals['group_names'] = ['group1', 'group2']

    # Set up globals
    globals = {}
    globals['ansible_play_hosts'] = 'ansiblePlayHosts'

    # Create a template
    from ansible.template import Templar
    templar = Templar(None, locals=locals)

    # Create the AnsibleJ2Vars
    ansiblej2vars = AnsibleJ2Vars(templar, globals=globals)

    # Check the variables
    assert templar.available_variables['hostvars'] == {}
    assert templar.available_variables['groups']

# Generated at 2022-06-23 13:27:01.336691
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.vault import VaultLib

    global_vars = {"a": 1}
    local_vars = {"b": 1}

    obj = AnsibleJ2Vars(None, global_vars, local_vars)

    assert isinstance(obj["a"], int)
    assert isinstance(obj["b"], int)

    assert isinstance(obj["vars"], HostVars) or isinstance(obj["vars"], dict)
    assert isinstance(obj[VaultLib.ENCRYPTED_STR], str)
    assert isinstance(obj[VaultLib.ENCRYPTED_STR], str)

# Generated at 2022-06-23 13:27:12.248043
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Test one
    templar = None
    globals = {
        'g_str1': 'str1',
        'g_str2': 'str2',
        'g_boolean1': False,
        'g_boolean2': False,
        'g_int1': 1,
        'g_int2': 2
    }
    locals = {
        'l_str1': 'l_str1',
        'l_str2': 'l_str2',
        'l_boolean1': True,
        'l_boolean2': False,
        'l_int1': -1,
        'l_int2': 2
    }

    ajv = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-23 13:27:18.617606
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    variables = HostVars()
    templar = Templar(loader=None, variables=variables)

    variables.update({
        'vars': {'a': 1, 'b': 2, 'c': 3},
        'a': 'A',
        'b': 'B',
        'c': 'C',
        'd': 'D',
    })
    proxy = AnsibleJ2Vars(templar, {})
    len_1 = len(proxy)

    variables.update({
        'e': 'E'
    })
    proxy = AnsibleJ2Vars(templar, {})
    len_2 = len(proxy)


# Generated at 2022-06-23 13:27:25.414972
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar_obj = object()
    globals_obj = object()
    locals_obj = object()
    # create instance of class AnsibleJ2Vars
    ansible_j2_vars_obj = AnsibleJ2Vars(templar_obj, globals_obj, locals_obj)
    # get instance of class AnsibleJ2Vars
    ansible_j2_vars_obj_new = ansible_j2_vars_obj.__getitem__('vars')

    # check if objects are equal
    assert ansible_j2_vars_obj == ansible_j2_vars_obj

# Generated at 2022-06-23 13:27:36.049407
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    AnsibleJ2Vars.__len__()
    """
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory=None)

    variable_manager.extra_vars = {'fizz': 'buzz'}
    variable_manager.options_vars = {'foo': 'bar'}

    play_context = PlayContext(variable_manager=variable_manager)

    templar = Templar(loader=None, variable_manager=variable_manager, play_context=play_context)


# Generated at 2022-06-23 13:27:47.147673
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            # Nothing to do
            pass

        def test_add_locals(self):
            # Set-up
            ansible_variables = {
                'test_str': 'value_str',
                'test_int': 15,
                'test_dict': { 'key1': 'val1', 'key2': 'val2' },
                'test_list': [ 'item1', 'item2', 'item3' ],
                'test_tuple': ( 'item1', 'item2', 'item3' ),
                'test_set': set(['item1', 'item2', 'item3']),
                'test_bool': True
            }


# Generated at 2022-06-23 13:27:58.952356
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Initial variables
    var1 = 'var1'
    var2 = 'var2'
    global_var1 = 'global_var1'
    global_var2 = 'global_var2'

    # Data
    templar_data = {var1: 'value %s' % var1, var2: 'value %s' % var2, 'context': 'context', 'environment': 'environment', 'template': 'template'}

    # Get key
    def get_key():
        return 'var1'

    # Templar mock
    class TemplarMock:
        def __init__(self, data):
            self._templar_data = data

        def template(self, *args):
            return self._templar_data[args[0]]


# Generated at 2022-06-23 13:28:07.902514
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    j2_loader = AnsibleLoader(dict(
        a_var='a',
        b_var=AnsibleVaultEncryptedUnicode('b'),
        c_var=AnsibleUnsafeText('c'),
    ), variable_start_string='%', variable_end_string='%')
    templar = Templar(loader=j2_loader)

    globals = {'a_global': 'a', 'b_global': 'b'}

# Generated at 2022-06-23 13:28:14.219263
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    This function will test the constructor of class AnsibleJ2Vars
    '''
    import ansible.template
    templar = ansible.template.AnsibleTemplar(loader=None)
    ansible_j2vars = AnsibleJ2Vars(templar, globals={})
    assert ansible_j2vars is not None

# Generated at 2022-06-23 13:28:21.965457
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    templar = Templar()

    globals = {
        'g_unsafe': AnsibleUnsafeText('global unsafe'),
        'g_safe'  : 'global safe',
    }
    locals = {
        'l_unsafe': AnsibleUnsafeText('local unsafe'),
        'l_safe'  : 'local safe',
    }
    variables = {
        'v_unsafe': AnsibleUnsafeText('var unsafe'),
        'v_safe'  : 'var safe',
    }

    templar.available_variables = variables
    proxy = AnsibleJ2Vars(templar, globals, locals)

    assert len(proxy) == 5
    assert 'g_unsafe'

# Generated at 2022-06-23 13:28:32.004891
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import json
    # Given a set of variables
    expected_result = {
        "group_names": [
            "ungrouped",
        ],
        "groups": {
            "ungrouped": {
                "hosts": [
                    "localhost",
                ],
                "vars": {},
                "children": [],
            },
        },
    }

    json_str = '{"1": 1, "2": 2, "3": {}}'
    groups = json.loads(json_str)

    json_str = '{"playbook_dir": "/ansible", "inventory_hostname": "localhost", "inventory_file": null}'
    templar = json.loads(json_str)

    # And a class AnsibleJ2Vars
    ansible_j2_vars = AnsibleJ2

# Generated at 2022-06-23 13:28:42.841490
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    variable_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-23 13:28:53.547970
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import pytest
    from ansible.templating import Templar

    v = {'a': 'A'}
    t = Templar(v, None)
    g = {'b': 'B'}
    loc = {'c': 'C'}
    ajv = AnsibleJ2Vars(t, g, loc)
    assert ajv['a'] == 'A'
    assert ajv['b'] == 'B'
    assert ajv['c'] == 'C'

    ajv = ajv.add_locals(loc)
    assert ajv['a'] == 'A'
    assert ajv['b'] == 'B'
    assert ajv['c'] == 'C'

    # make sure that locals are added correctly

# Generated at 2022-06-23 13:29:05.562919
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    class TestTemplar:
        def __init__(self):
            self.available_variables = dict()


    test_globals = dict()
    test_globals['g0'] = 'g0_value'
    test_globals['g1'] = 'g1_value'
    test_globals['g2'] = 'g2_value'
    test_globals['g3'] = 'g3_value'

    test_locals = dict()
    test_locals['l0'] = 'l0_value'
    test_locals['l1'] = 'l1_value'

    test_template = dict()
    test_template['t0'] = 't0_value'
    test_template['t1'] = 't1_value'

    test_templ

# Generated at 2022-06-23 13:29:16.498587
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.manager import VariableManager

    class TestTemplate:
        def __init__(self):
            self.vars_mgr = VariableManager()

        def template(self, v):
            return self.vars_mgr.template(v)

        def available_variables(self):
            return self.vars_mgr.get_vars()

    # test mixing unsafe and non-unsafe variables
    test_template = TestTemplate()

    vars_unsafe = dict()
    vars_unsafe['var1'] = 'this is var1'
    vars_unsafe['var2'] = 'this is var2'
    vars_unsafe['var3'] = 'this is var3'
    vars_unsafe['var4'] = 'this is var4'
    vars_uns

# Generated at 2022-06-23 13:29:26.738245
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())
    globals_v  = dict(g_a=1, g_b=2)
    locals_v   = dict(l_a=3, l_b=4)
    available_variables = dict(v_a=5, v_b=6)

    vars = dict(globals=globals_v, locals=locals_v, available_variables=available_variables)
    assert vars['globals'] == globals_v
    assert vars['locals'] == locals_v
    assert vars['available_variables'] == available_variables


# Generated at 2022-06-23 13:29:34.105986
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    # - Arrange
    templar = object()
    globals = dict()
    locals = {'a': 'A', 'b': 'B'}
    proxy = AnsibleJ2Vars(templar, globals)

    # - Act
    result = proxy.add_locals(locals)

    # - Assert
    assert type(result) == AnsibleJ2Vars
    assert result._templar == templar
    assert result._globals == globals
    assert result._locals == locals

# Generated at 2022-06-23 13:29:43.713902
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.hostvars import HostVars
    var_dict = {
        'foo': 1,
        'bar': 'hello',
        'baz': HostVars(dict(a='a')),
    }

    # Test case when all are present in locals, globals and templar
    ajv = AnsibleJ2Vars(templar=None, globals=var_dict, locals=var_dict)
    assert len(ajv) == 3

    # Test case when there are duplicate variables
    ajv = AnsibleJ2Vars(templar=None, globals=var_dict, locals=var_dict)
    ajv._templar.available_variables = var_dict

    assert len(ajv) == 3

    # Test case when one of the variables is missing

# Generated at 2022-06-23 13:29:55.813114
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import template_loader

    # Initialize j2_vars
    j2_vars = AnsibleJ2Vars(
        templar=template_loader.get('jinja2').get('Jinja2'),
        globals=dict(),
        locals=dict()
    )

    # Verify class type
    if type(j2_vars) != AnsibleJ2Vars:
        raise AssertionError("type(j2_vars) is not AnsibleJ2Vars")

    # Some tests

# Generated at 2022-06-23 13:30:08.533514
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class MockTemplar:
        def __init__(self):
            self.available_variables = dict()
        def template(self, value):
            return value
    class MockVariables:
        def __init__(self):
            self.data = dict()
        def __contains__(self, k):
            return k in self.data
        def __getitem__(self, k):
            return self.data[k]

    variables = MockVariables()
    # isinstance(templar, Templar)
    templar = MockTemplar
    globals = dict()
    j2vars = AnsibleJ2Vars(templar, globals)
    assert j2vars.__contains__('varname') is False
    variables.data['varname'] = 'varvalue'
   

# Generated at 2022-06-23 13:30:19.960320
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar()
    globals = dict()
    locals = dict()
    ansible_vars = dict()

    ansible_vars['test_variable_1'] = 'test_variable1_value'
    ansible_vars['test_variable_2'] = 'test_variable2_value'
    ansible_vars['test_variable_3'] = 'test_variable3_value'
    ansible_vars['test_variable_4'] = 'test_variable4_value'

    locals['test_local_1'] = 'test_local1_value'
    locals['test_local_2'] = 'test_local2_value'

# Generated at 2022-06-23 13:30:27.100940
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    # Setup mock objects
    loader = DataLoader()
    jvars = AnsibleJ2Vars(None, {}, locals={})

    # Test all code paths
    test1_vars = dict(one=1, two=2, three=3, four=4, five=5)
    assert len(jvars.add_locals(test1_vars)) == len(test1_vars)

    # TODO: Create a mock for AnsibleVariable to test isinstance(variable, dict) and varname == "vars"
    # TODO: Create a mock for HostVars to test isinstance

# Generated at 2022-06-23 13:30:29.930884
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    hostvars = dict(x="x_value")
    new = AnsibleJ2Vars(None, hostvars)
    assert "x" in new
    assert "x_value" not in new


# Generated at 2022-06-23 13:30:36.751745
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import SafeEval
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.template.vars import AnsibleVars

    vars_mgr = AnsibleVars(loader=None, vault_password=None)
    # create a vault secret
    secret = '$ANSIBLE_VAULT;1.1;AES256\n'
    secret += '66643337376162636264303638316434653435303736376132666535303334666137636166663265\n'
    secret += '34383332363063653036366535313164653833623963376331666562353466653937343663343035\n'

# Generated at 2022-06-23 13:30:46.468148
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Constructor without parameters
    AnsibleJ2VarsTestObj = AnsibleJ2Vars(None, None, None)

    # Test when the variable is in local vars and the variable is string
    AnsibleJ2VarsTestObj._locals = {'test_var': 'test_str'}
    assert AnsibleJ2VarsTestObj['test_var'] == 'test_str'

    # Test when the variable is in local vars and the variable is int
    AnsibleJ2VarsTestObj._locals = {'test_var': 1}
    assert AnsibleJ2VarsTestObj['test_var'] == 1

    # Test when the variable is in available variables and the variable is string
    AnsibleJ2VarsTestObj._templar = Templar(variables={'test_var': 'test_str'})

# Generated at 2022-06-23 13:30:54.538841
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # __contains__ returns true for variable names defined in locals or available variables
    try:
        from ansible.parsing.vault import VaultLib
    except ImportError:
        # vault is not installed, we can't test the vaulted variable content
        pass
    else:
        class MockTemplar():
            def __init__(self):
                self.available_variables = {
                    'vaulted': VaultLib().encrypt('vaulted'),
                    'non_vaulted': 'non_vaulted'
                }

        class MockVars():
            def __init__(self):
                self.templar = MockTemplar()
                self._globals = dict()
                self._locals = dict()

        aj2v = AnsibleJ2Vars(MockTemplar(), dict())

# Generated at 2022-06-23 13:31:05.640986
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar():
        def __init__(self):
            self.available_variables = None
        def template(self, variable):
            return variable

    # Setup template proxy with dummy variables and globals
    templar = Templar()

# Generated at 2022-06-23 13:31:16.365984
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class TestTemplar:
        def template(self, a):
            return a

    templar = TestTemplar()

    vars = AnsibleJ2Vars(templar, {'global1':1}, {'local1':2})

    assert vars['local1'] == 2
    assert vars['global1'] == 1
    assert vars['global2'] == 2

    # locals are not found in the upper class
    try:
        assert vars['local2'] == 3
    except:
        pass

    # locals are not found in the upper class
    try:
        assert vars['local3'] == 4
    except:
        pass

    # vars of upper class are found
    assert vars['local1'] == 2


# Generated at 2022-06-23 13:31:26.907333
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
   from ansible.parsing import vault
   from ansible.template import Templar
   from ansible.vars.hostvars import HostVars
   from ansible.vars import VariableManager

   def get_variable_manager(hostname, loader, vault_password=None):
       variable_manager = VariableManager()
       variable_manager.add_loader(loader)
       variable_manager.set_inventory(inventory)
       variable_manager.extra_vars = {}
       variable_manager.options_vars = {}
       variable_manager.vault_password = vault_password
       return variable_manager

   expected = [
         '_templar',
         '_globals',
         '_locals',
         'vault_password'
   ]

   loader = DictDataLoader({})
   hostvars = Host

# Generated at 2022-06-23 13:31:37.115987
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import os
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    file = __file__
    directory = os.path.dirname(file)
    if directory.strip():
        directory += '/'
    locals = {
        "hostvars": HostVars(dict()),
        "directory": directory,
        "file": file
    }
    data = AnsibleJ2Vars(templar, {}, locals)
    assert sorted(data) == [
        'directory',
        'file',
        'hostvars',
        'template_host'
    ]

# Generated at 2022-06-23 13:31:46.368954
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar

    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    available_vars = {'av1': 'av1', 'av2': 'av2'}

    templar = Templar(loader=None, variables=dict())
    templar._available_variables = available_vars

    proxy = AnsibleJ2Vars(templar, globals, locals)
    assert len(proxy) == 5
    assert proxy['g1'] == 'g1'
    assert proxy['g2'] == 'g2'
    assert proxy['l1'] == 'l1'
    assert proxy['l2'] == 'l2'

# Generated at 2022-06-23 13:31:57.566220
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = magicmock(spec=AnsibleJ2Vars)
    globals = {'key': 'value'}
    locals = {'local': 'value'}

    ajv = AnsibleJ2Vars(templar, globals, locals)
    ajv.add_locals({'new': 'value'})

    # FIXME run this only on jinja2>=2.9?
    # prior to version 2.9, locals contained all of the vars and not just the current
    # local vars so this was not necessary for locals to propagate down to nested includes
    assert ajv._locals == {'local': 'value', 'new': 'value'}



# Generated at 2022-06-23 13:32:01.943158
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = None
    globals = {"type": "test"}
    locals = None

    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert aj2v is not None

# Generated at 2022-06-23 13:32:11.788996
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()

    # unit test 1
    expected_result = 'value'
    available_variables = {'role_name': 'value'}
    j2vars = AnsibleJ2Vars(templar = templar, globals = {}, locals = {})
    templar.available_variables = available_variables
    ans = j2vars['role_name']
    if ans != expected_result:
        raise AssertionError('unit test 1: expected_result "%s", got "%s"' % (expected_result, ans))

    # unit test 2
    expected_result = 'value'
    available_variables = {'role_name': 'value'}
    locals = {'role_name': 'value'}

# Generated at 2022-06-23 13:32:18.492049
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)
    locals = dict()
    globals = dict(a=AnsibleUnsafeText('b'), **dict(c=AnsibleUnsafeText('d')))
    proxy = AnsibleJ2Vars(templar, globals, locals)
    assert set(proxy) == set(('a', 'c'))

# Generated at 2022-06-23 13:32:30.051593
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    templar = Templar(
        loader=None,
        variables=VariableManager(
            loader=None,
            inventory=Inventory(loader=None)
        )
    )

    j2vars = AnsibleJ2Vars(templar, {"g_key": "global value", "g_uniq": 1})
    assert list(iter(j2vars)) == ['g_key', 'g_uniq']

    j2vars = AnsibleJ2Vars(templar, {"g_key": "global value"}, {"l_key": "local value"})
    assert list(iter(j2vars)) == ['l_key', 'g_key']


# Generated at 2022-06-23 13:32:41.530411
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    import re
    from ansible.templating.template import Templar

    t = Templar(loader=None)
    t.available_variables = {
        'a': 'foo',
        'b': 'bar',
        'c': {
            'd': 'baz'
        },
        'vars': {
            'e': 'dont_touch_me'
        },
        'unsafe': 'yes',
        'vars_unsafe': 'yes',
        'hostvars': HostVars()
    }
    v = AnsibleJ2Vars(t, globals={'g': 'global'})

    assert v['a'] == 'foo'
    assert v['b'] == 'bar'

# Generated at 2022-06-23 13:32:53.758124
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager(), shared_loader_obj=None)

    my_var = 'foo'
    local1 = {'k1': 'v1'}
    local2 = {'k2': 'v2'}
    local3 = {'k3': 'v3'}
    local_all = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}

    # Test with None locals
    jv = AnsibleJ2Vars(templar, {}, None)
    assert jv.add_locals(None) is jv

    # Test with empty locals