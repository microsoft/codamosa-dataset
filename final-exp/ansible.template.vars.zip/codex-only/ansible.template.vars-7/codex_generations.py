

# Generated at 2022-06-23 13:22:57.890840
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    templar = Templar(variables=dict(
        dict1=dict(
            key='VALUE',
            list=[1, 4, 7]
        )
    ))

    simple_args = AnsibleJ2Vars(templar, globals=dict(
        unix_socket='/tmp/mysql.sock',
        user_name='shin',
        mysql_binary='/usr/bin/mysql',
        mysqladmin_binary='/usr/bin/mysqladmin',
    ))

    # test whether simple args are handled as expected
    assert simple_args['unix_socket'] == '/tmp/mysql.sock'
    assert simple_args['user_name'] == 'shin'

   

# Generated at 2022-06-23 13:23:09.385486
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        from ansible.template import Templar
    except:
        exit('please run test with ansible development types')

    templar = Templar(loader=None)
    templar.available_variables = {
        'boolean': True,
        'integer': 7,
        'list': [3,4,5],
        'dict': {'a':'b'},
        'float': 3.14,
        'string': 'Hello world'}

    j2vars = AnsibleJ2Vars(templar, {})

    assert j2vars.get('string') == 'Hello world'
    assert j2vars.get('integer') == 7

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-23 13:23:19.546100
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext

    # Create an instance of AnsibleJ2Vars
    templar = object() # just to pass a valid object
    globals = dict()
    locals = dict()
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)

    # Add a variable
    # Check if variable exists
    locals['a'] = 1
    assert ansible_j2vars.__contains__("a")

    # Add another variable
    locals['b'] = 2
    # Check if variable exists
    assert ansible_j2vars.__contains__("b")

    # Add a global variable
    globals['c'] = 3
    # Check if variable exists

# Generated at 2022-06-23 13:23:20.121689
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert True
    return

# Generated at 2022-06-23 13:23:30.406478
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    locals = {'some_local_variable': 'something'}
    globals = {'some_global_variable': 'something'}
    templar = 'something'

    # test that the method calls __contains__ on both self._locals and self._templar.available_variables
    def mock_contains(self, k):
        if k in self._locals:
            return True
        if k in self._templar.available_variables:
            return True
        if k in self._globals:
            return True
        return False

    AnsibleJ2Vars.__contains__ = mock_contains
    proxy = AnsibleJ2Vars(templar, globals, locals=locals)
    assert 'some_local_variable' in proxy

# Generated at 2022-06-23 13:23:36.605723
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    assert AnsibleJ2Vars(None, {}, {'foo': 'bar'}).add_locals(None)._locals == {'foo': 'bar'}
    assert AnsibleJ2Vars(None, {}, {}).add_locals({'foo': 'bar'})._locals == {'foo': 'bar'}
    assert AnsibleJ2Vars(None, {}, {'foo': 'bar', 'baz': 'xyzzy'}).add_locals({'baz': 'glarch'})._locals == {
        'foo': 'bar', 'baz': 'glarch'}

# Generated at 2022-06-23 13:23:48.920253
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    
    # This should pass because _templar is a Templar object and _globals is a dict
    test_a = AnsibleJ2Vars(templar=None, globals={})
    assert test_a

    # This should fail because _templar is not a Templar object
    test_b = AnsibleJ2Vars(templar=None, globals=None)
    assert test_b == False
    
    # This should fail because _globals is not a dict
    test_c = AnsibleJ2Vars(templar=None, globals=None)
    assert test_c == False
    
    # This should fail because both _templar and _globals are not Templar or dict respectively
    test_d = AnsibleJ2Vars(templar=None, globals=None)

# Generated at 2022-06-23 13:23:58.193520
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    assert AnsibleJ2Vars(templar, {}).__getitem__("string") == ''

    t = Templar(loader=None, variables={'string': 'string'})
    assert AnsibleJ2Vars(t, {}).__getitem__("string") == 'string'

    t = Templar(loader=None, variables={'string': '{{missing}}'})
    try:
        AnsibleJ2Vars(t, {}).__getitem__("string")
        assert False
    except AnsibleError as e:
        assert "An unhandled exception occurred while templating '{{missing}}'" in str(e)
       

# Generated at 2022-06-23 13:24:08.800967
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar()

    # handle 'vars'
    vars_vars = {
        'vars': {
            'a': '1',
            'b': '2',
            'c': '3',
        }
    }
    ansible_j2_vars = AnsibleJ2Vars(templar, globals={}, locals={})
    assert ansible_j2_vars['vars'] == vars_vars['vars']

    # handle HostVars
    vars_hostvars = {
        'hostvars': HostVars(vars_vars)
    }
    ansible_

# Generated at 2022-06-23 13:24:13.077682
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar()
    globals = dict()
    locals = dict()

    j2vars = AnsibleJ2Vars(templar, globals, locals)
    # iterate over the iterator
    for _ in j2vars:
        pass

# Generated at 2022-06-23 13:24:22.145070
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Create Templar
    from ansible.template.template import Templar
    templar = Templar(loader=None)

    # Create AnsibleJ2Vars
    globals = dict(load_str='globals')
    locals = dict(load_str='locals')
    aj2v = AnsibleJ2Vars(templar, globals, locals)

    # Lookup
    assert aj2v['load_str'] == locals['load_str']

    # Iteration
    assert not set(aj2v) - set(locals) - set(globals)

    # Length
    assert len(set(aj2v)) == len(set(locals) | set(globals))

    # Add locals
    aj2v = aj2v.add_locals({'x': 1})
   

# Generated at 2022-06-23 13:24:27.214120
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    
    templar = None
    globals = {'g1':1, 'g2':2}
    locals = {'l1':1, 'l2':2}

    j2v = AnsibleJ2Vars(templar, globals, locals)

    assert len(j2v) == 4

# Generated at 2022-06-23 13:24:34.739680
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()

    ansiblej2vars = AnsibleJ2Vars(templar, {}, {})
    with pytest.raises(KeyError):
        ansiblej2vars.__getitem__('undefined')

    ansiblej2vars = AnsibleJ2Vars(templar, {'test_var': 'test_val'}, {})
    with pytest.raises(AnsibleUndefinedVariable):
        ansiblej2vars.__getitem__('test_var')

# Generated at 2022-06-23 13:24:43.754326
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar()

    j2vars = AnsibleJ2Vars(templar, globals={'aaa': 'bbb'}, locals={'ccc': 'ddd'})

    assert ('aaa' in j2vars) == True
    assert ('bbb' in j2vars) == False
    assert ('ccc' in j2vars) == True
    assert ('ddd' in j2vars) == False


# Generated at 2022-06-23 13:24:54.355709
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    import os

    vault_pass = os.path.expanduser('~/.vault_pass')
    vault = VaultLib(vault_pass)
    loader = AnsibleLoader(None, vault)

    inventory_file = os.path.expanduser('~/Documents/GitHub/ansible-inventory-loader/inventory/hosts')
    inventory_data = loader.load_from_file(inventory_file)

    variables = inventory_data.get_host('server.example.com').get_vars()

    templar = Templar(loader=loader, variables=variables)


# Generated at 2022-06-23 13:24:55.260196
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # TODO: add
    raise NotImplementedError

# Generated at 2022-06-23 13:25:03.940350
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    print("%s  test AnsibleJ2Vars.__iter__:" % ("-"*50))
    import jinja2
    from ansible.template.safe_eval import ansible_eval

    # Jinja2 environment setup
    jenv = jinja2.Environment(loader=jinja2.FileSystemLoader('./'), undefined=jinja2.StrictUndefined)
    jenv.filters['to_yaml'] = ansible_eval.to_yaml
    jenv.filters['to_nice_yaml'] = ansible_eval.to_nice_yaml
    jenv.filters['to_json'] = ansible_eval.to_json
    jenv.filters['to_nice_json'] = ansible_eval.to_nice_json
    jenv.filters['to_text']

# Generated at 2022-06-23 13:25:05.632134
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert False, "No implemented test for AnsibleJ2Vars.__contains__"


# Generated at 2022-06-23 13:25:16.760261
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from jinja2.runtime import Undefined
    from ansible.template import Templar
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # create vars
    variable = {'item1':'value1', 'item2': 'value2'}

    templar = Templar(loader={})
    templar.available_variables = variable

    # create globals
    globals = {'g_item1':'g_value1', 'g_item2':'g_value2'}

    # create locals
    locals = {'item1':'changedValue1', 'item2':'changedValue2'}

    # if we don't pass locals to __init__()
    ansibleJ2Vars = AnsibleJ2

# Generated at 2022-06-23 13:25:20.657007
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    import pytest

    j2v = AnsibleJ2Vars(
        Templar(variables={}, loader=None),
        {'a': 'A', 'b': 'B', 'c': 'C'},
        {'b': 'X', 'c': 'Y', 'd': 'Z'}
    )
    assert len(j2v) == 4

# Generated at 2022-06-23 13:25:31.040698
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class TestVars(object):
        def __init__(self, vars):
            self.vars = vars

    globals = {'g1': 'global1', 'g2': 'global2'}
    locals = {'l1': 'local1'}
    vars = {'v1': 'var1', 'v2': 'var2', 'v3': 'var3'}
    templar = TestVars(vars)
    proxy = AnsibleJ2Vars(templar, globals, locals)

    assert set(proxy.keys()) == set(globals.keys() | locals.keys() | vars.keys())
    assert set(proxy.items()) == set((k, proxy[k]) for k in proxy.keys())

# Generated at 2022-06-23 13:25:34.353746
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.vault import VaultLib
    templar = VaultLib()
    aj2v = AnsibleJ2Vars(templar, {'a': 1})
    assert aj2v.add_locals({'b': 1, 'c': 1})



# Generated at 2022-06-23 13:25:43.379397
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.yaml.objects import AnsibleMapping

    locals = {'a': '1', 'b': '2', 'c': '3'}
    templar = AnsibleJ2Vars(templar=None, globals={}, locals=locals)

    assert templar['a'] == locals['a']
    assert templar['b'] == locals['b']
    assert templar['c'] == locals['c']
    try:
        assert templar['d'] == locals['d']
    except KeyError:
        assert True
    else:
        assert False

    globals = {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-23 13:25:52.960066
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = Templar(loader=None, variables={'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'})
    globals = {'a': 'A', 'b': 'B', 'c': 'C', 'd': 'D'}
    locals = {'b': 'b2'}

    # locals is None
    ajv = AnsibleJ2Vars(templar=None, globals=None, locals=None)
    assert ajv == ajv.add_locals(locals)

    # locals is not None
    ajv = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)
    ajv2 = ajv.add_locals(locals)

    assert aj

# Generated at 2022-06-23 13:25:55.051915
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    assert len(AnsibleJ2Vars.__iter__.__doc__) > 0


# Generated at 2022-06-23 13:26:04.263801
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    Test __len__
    '''
    class Templar(object):
        '''
        For test purpose
        '''
        available_variables = {'a': 'a', 'b': 'b'}
    globals={'a': 'a', 'b': 'b'}
    locals = {'l_c': 'c', 'l_d': 'd'}
    obj = AnsibleJ2Vars(Templar(), globals, locals)
    return len(obj) == 4


# Generated at 2022-06-23 13:26:12.977296
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = 1
    globals = {'g1': '1.1', 'g2': '2.2'}
    locals = {'l_l1': '1.1', 'l_l2': '2.2'}
    proxy = AnsibleJ2Vars(templar, globals, locals)
    assert('g1' in proxy)
    assert('g2' in proxy)
    assert('l_l1' in proxy)
    assert('l_l2' in proxy)
    assert(len(proxy) == 4)

    for key in proxy:
        assert(key == 'g1' or key == 'g2' or key == 'l_l1' or key == 'l_l2')



# Generated at 2022-06-23 13:26:17.943547
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    t = Templar(loader=None)
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(['--vault-password-file', '/dev/null'])
    aj2vars = AnsibleJ2Vars(t,
                            {'foo': 'FOO',
                            'bar': 'BAR',
                            'baz': 'BAZ'},
                            t._available_variables)
    assert len(aj2vars) == 3

# Generated at 2022-06-23 13:26:18.512003
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    print("test")

# Generated at 2022-06-23 13:26:30.383150
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.plugins.loader import var_manager
    templar = var_manager.Templar(loader=None)

# Generated at 2022-06-23 13:26:39.204065
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    import jinja2
    env = jinja2.Environment()

    templar = env.from_string("{{ var }}")
    globals_ = {"var": "global"}
    locals_ = {"var": "local"}
    locals_override = {"var": "new_local"}

    vars_ = AnsibleJ2Vars(templar, globals_, locals=locals_)
    assert vars_["var"] == "local"

    # Testing that new_locals is added to the same instance of vars_,
    # and that default behaviour will override locals with globals
    vars_updated = vars_.add_locals(locals_override)
    assert vars_updated["var"] == "new_local"
    assert vars_updated is vars_

    # Testing that new_

# Generated at 2022-06-23 13:26:49.438163
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import sys
    assert sys.version_info[0] >= 3, 'Unittest requires Python3'

    from ansible.template import Templar
    templar = Templar()

    x = AnsibleJ2Vars(templar, {}, locals={'a': 1, 'b': 2})
    y = x.add_locals({'b': 3, 'c': 4})
    assert y['a'] == 1
    assert y['b'] == 3
    assert y['c'] == 4

    x = AnsibleJ2Vars(templar, {}, locals={'a': 1, 'b': 2})
    y = x.add_locals(None)
    assert y is x


# Generated at 2022-06-23 13:27:00.656793
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    class Dummy:
        def __init__(self):
            pass
    dummy = Dummy()
    dummy.template = 'Hello'
    dummy.get_vault_secrets = 'Hello'
    dummy.available_variables = {'var1': 'value1'}
    dummy.vars = {'var1': 'value1'}
    jvars = AnsibleJ2Vars(dummy, {'global': 'global'}, locals={'local': 'local'})
    jvars.add_locals({'local_add': 'local_add'})
    assert(jvars['var1'] == 'value1')
    assert(jvars['local'] == 'local')

# Generated at 2022-06-23 13:27:05.139456
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals_ = {'var': 'var'}
    locals_ = {'l_local': 'local'}
    var_proxy = AnsibleJ2Vars(templar, globals_, locals_)
    assert(var_proxy['l_local'] == 'local')
    assert(var_proxy['var'] == 'var')

# Generated at 2022-06-23 13:27:14.709330
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible import errors as err
    from ansible.template.safe_eval import assert_good_template
    from ansible.template.template import Templar
    from ansible.template.vars import AnsibleJ2Vars

    templar = Templar(None, None)
    my_vars = AnsibleJ2Vars(templar, dict(foo="foo"), locals=dict(bar="bar"))

    try:
        assert_good_template("{{ foo }}", dict(vars=my_vars))
    except Exception:
        assert False

    try:
        assert_good_template("{{ foo }}", dict(vars=my_vars.add_locals(dict(foo="fool"))))
    except Exception:
        assert False


# Generated at 2022-06-23 13:27:24.444547
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.template
    import ansible.vars.hostvars

    templar = ansible.template.AnsibleJ2TemplateVars(None, None, None)
    templar.available_variables = {"vars": {"a": "b"}, "TestMagicVars": ansible.vars.hostvars.HostVars({"a": "b"}, "localhost")}
    vars_ = {"vars": {"a": "c"}, "c": "d"}

    try:
        AnsibleJ2Vars(templar,vars_)["TestMagicVars"]
    except AttributeError:
        assert False

    assert AnsibleJ2Vars(templar,vars_)["vars"] == {"a": "c"}


# Generated at 2022-06-23 13:27:35.589660
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.vars.hostvars
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # We create a Templar instance by calling the private method init_templar() of class PlayContext
    play_context = PlayContext()
    templar = play_context.init_templar(loader=None, variables={'var1': 'value1', 'var2': 'value2'}, shared_loader_obj=None)

    # We create an AnsibleJ2Vars instance for testing AnsibleJ2Vars.__getitem__()
    j2vars = AnsibleJ2Vars(templar, {'var3': 'value3'})


# Generated at 2022-06-23 13:27:46.928902
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_globals = {'g1': 1, 'g2': { 'g21': 21 }}
    test_locals = {'l1': 1, 'l2': { 'l21': 21 }}
    test_variables = {
        'v1':1, 'v2': { 'v21':21 },
        'not_present_in_any_input': 42
    }
    templar = AnsibleJ2Vars(globals=test_globals, locals=test_locals, variables=test_variables)

    assert 'l1' in templar
    assert 'g1' in templar
    assert 'v1' in templar
    assert 'not_present_in_any_input' in templar
    assert 'v2' in templar

# Generated at 2022-06-23 13:27:58.748442
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {
        'a': 1,
        'b': 2,
        'c': [1, 2, 3],
        'd': {'e': 1, 'f': 'foo', 'g': None}
    }
    vars = AnsibleJ2Vars(templar, globals)
    assert set(vars.__iter__()) == set(globals)
    locals = {
        'a': 2,
        'b': 3,
        'c': [2, 3, 4],
        'd': {'e': 2, 'f': 'bar', 'g': False},
        'h': HostVars()
    }
    v

# Generated at 2022-06-23 13:28:07.794139
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    from ansible.template import Templar
    from  ansible.vars.hostvars import HostVars
    import pytest
    j2_env = jinja2.Environment()
    templar = Templar(loader=None, variables={'foo1': 'bar'})
    globals_ = {'foo3': 'bar'}
    locals_ = {'foo2': 'bar'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals_, locals_)
    assert(ansible_j2_vars.__contains__('foo1'))
    assert(ansible_j2_vars.__contains__('foo2'))
    assert(ansible_j2_vars.__contains__('foo3'))
   

# Generated at 2022-06-23 13:28:18.478064
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import pytest
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(None)
    var1 = HostVars(loader=None)
    var2 = dict()
    var3 = dict()
    var3['vars'] = dict()

    vars_obj = AnsibleJ2Vars(templar, globals=var1)
    assert 'vars' in vars_obj

    vars_obj = AnsibleJ2Vars(templar, globals=var2)
    assert 'vars' in vars_obj

    vars_obj = AnsibleJ2Vars(templar, globals=var3)
    assert 'vars' in vars_obj


# Generated at 2022-06-23 13:28:28.884697
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import pytest

    variables = {'my_var': 'test value'}
    locals = {'local_var': 'local value'}
    from ansible.template import Templar
    t = Templar(loader=None, variables=variables)
    vp = AnsibleJ2Vars(templar=t, globals={}, locals=locals)

    # Test with local vars
    assert vp['local_var'] == 'local value'

    # Test with global vars
    assert vp['my_var'] == 'test value'

    # Test with undefined variabel
    with pytest.raises(KeyError):
        vp['undefined_variable']

# Generated at 2022-06-23 13:28:40.514002
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib

    my_locals = dict()
    my_vars = dict()
    my_globals = dict()

    # Create a variable manager and a jinja2 environment
    variable_manager = VariableManager()
    variable_manager.extra_vars = my_vars
    variable_manager.options_vars = my_globals
    variable_manager.set_found_vars_file("./tests/vars")
    variable_manager.set_vault_secrets(VaultLib(["./tests/vault_pass"]))


# Generated at 2022-06-23 13:28:52.304962
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    
    class AnsibleJ2Vars(object):
        def __init__(self, templar, globals, locals=None):
            self._templar = templar
            self._globals = globals
            self._locals = dict()
            if isinstance(locals, dict):
                for key, val in iteritems(locals):
                    if val is not missing:
                        if key[:2] == 'l_':
                            self._locals[key[2:]] = val
                        elif key not in ('context', 'environment', 'template'):
                            self._locals[key] = val
    
        def __contains__(self, k):
            if k in self._locals:
                return True
            if k in self._templar.available_variables:
                return

# Generated at 2022-06-23 13:28:57.265975
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    t = Templar(loader=None)
    globals = {'test1':'test1val'}
    locals = {'test2':'test2val'}
    var = AnsibleJ2Vars(t, globals, locals)
    assert var['test1'] == 'test1val'
    assert var['test2'] == 'test2val'

# Generated at 2022-06-23 13:29:04.614706
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import ansible.template
    templar = ansible.template.Templar(loader=None)
    proxy = AnsibleJ2Vars(templar, dict(), dict(a=1, b=2))
    assert len(proxy) == 2, 'dict length is not 2'
    proxy = AnsibleJ2Vars(templar, dict(a=1), dict(a=1, b=2))
    assert len(proxy) == 2, 'dict length is not 2'


# Generated at 2022-06-23 13:29:16.017949
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    class Templar:
        def __init__(self, available_variables):
            self.available_variables = available_variables

    available_variables = {'a': 1, 'b': 2, 'c': 3}
    globals = {'d': 4, 'e': 5}
    locals = {'f': 6}
    locals.update({'l_' + k: v for k, v in locals.items()})
    templar = Templar(available_variables)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    assert set(ansible_j2_vars) == set(available_variables.keys() + globals.keys() + locals.keys())


# Unit

# Generated at 2022-06-23 13:29:17.100867
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # FIXME
    pass


# Generated at 2022-06-23 13:29:27.064746
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    templar = Templar(loader=None)

    # None locals
    v = AnsibleJ2Vars(templar, dict())
    assert v == AnsibleJ2Vars(templar, dict())

    # empty locals
    v = AnsibleJ2Vars(templar, dict(), locals=dict())
    assert v == AnsibleJ2Vars(templar, dict(), locals=dict())

    # locals dict
    v = AnsibleJ2Vars(templar, dict(), locals=dict(a=1))
    assert v == AnsibleJ2Vars(templar, dict(), locals=dict(a=1))

    # locals dict with HostVars
    v = AnsibleJ2Vars

# Generated at 2022-06-23 13:29:27.671302
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    pass

# Generated at 2022-06-23 13:29:32.784344
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar():
        def __init__(self):
            self.available_variables = dict()

        def template(self, variable):
            return variable

    templar = Templar()
    globals = dict()
    locals = dict()
    v = AnsibleJ2Vars(templar, globals, locals)
    v['varname']

# Generated at 2022-06-23 13:29:36.331293
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    j2vars = AnsibleJ2Vars(Templar(), {}, locals={
        'l_x': 'y'
    })

    assert 'x' in j2vars
    assert j2vars['x'] == 'y'

# Generated at 2022-06-23 13:29:43.217374
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    def return_len(length):
        def len(self):
            return length
        return len

    class MockTemplar():
        def __init__(self):
            self.available_variables = {'k1': 1, 'k2': 2}

        len=return_len(len(self.available_variables))

    class MockGlobals():
        def __init__(self):
            self.globals = {'k3': 3, 'k4': 4}

        len=return_len(len(self.globals))

    class MockLocals():
        def __init__(self):
            self.locals = {'k5': 5, 'k6': 6}

        len=return_len(len(self.locals))


# Generated at 2022-06-23 13:29:51.725257
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # test basic constructs by parsing test_variable.
    # This test asserts that AnsibleJ2Vars object is correctly initialized.

    # test_variable = '42'
    test_variable = {'task_var': '42'}
    templar = Templar(loader=None)
    test_object = AnsibleJ2Vars(templar, {}, test_variable)
    assert isinstance(test_object, dict)
    assert test_variable['task_var'] == test_object['task_var']

# Generated at 2022-06-23 13:29:58.245528
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.vault import VaultLib
    templar = Templar(vault_secrets=VaultLib())
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals=dict(), locals=locals)
    assert len(vars) == 2
    locals['test_var'] = 'test_var'
    vars = AnsibleJ2Vars(templar, globals=dict(), locals=locals)
    assert len(vars) == 3

# Generated at 2022-06-23 13:30:09.549204
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2
    from ansible.template import Templar
    templar = Templar(None, variables={'foo': 'bar'})
    locals = {'a': 1, 'b': 2}
    globals = {'c': 3, 'd': 4}
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)
    assert isinstance(ansible_vars, Mapping)
    assert ansible_vars['foo'] == 'bar'
    assert ansible_vars['c'] == 3
    assert ansible_vars['d'] == 4
    assert ansible_vars['a'] == 1
    assert ansible_vars['b'] == 2
    assert 'foo' in ansible_vars
    assert 'c' in ansible_vars

# Generated at 2022-06-23 13:30:20.854961
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = None
    globals = {'ansible_version': '2.0',
               'ansible_facts': {},
               'ansible_user_id': 'md',
               'ansible_ssh_hosts': {},
               'ansible_ssh_pass': '',
               'module_name': 'service',
               'module_args': {},
               'play_hosts': [],
               'group_names': [],
               'groups': {},
               'inventory_hostname': 'localhost'
    }
    j2vars = AnsibleJ2Vars(templar, globals, locals = {'testlocalvar': 'testlocalvalue'})
    print('testlocalvar:', len(j2vars) == len(globals) + 1)

# Generated at 2022-06-23 13:30:33.491913
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    templar_obj = Templar(loader=None, shared_loader_obj=None, variables=None)
    var_manager_obj = VariableManager()
    play_context_obj = PlayContext()

    ansible_j2_vars_obj = AnsibleJ2Vars(templar_obj, var_manager_obj.get_vars(play=play_context_obj),
                                        locals=var_manager_obj.get_vars(play=play_context_obj, include_hostvars=False))

    assert isinstance(ansible_j2_vars_obj, AnsibleJ2Vars)

# Generated at 2022-06-23 13:30:40.713553
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class Templar():
        def __init__(self):
            pass
        def __contains__(self, varname):
            return True
        def template(self, variable):
            return 100
        available_variables = {'x':1, 'y':2}

    templar = Templar()

    locals = {'a':2, 'b':3}
    globals_ = {'a':4, 'd':5}
    globals_['e'] = 6

    ansible_vars = AnsibleJ2Vars(templar, globals_, locals)
    # Test __contains__
    assert 'x' in ansible_vars
    # Test __len__
    assert len(ansible_vars) == 7
    # Test __getitem__

# Generated at 2022-06-23 13:30:51.829503
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class Templar:
        def __init__(self, available_variables, fail_on_undefined=False):
            self.available_variables = available_variables
            self.fail_on_undefined = fail_on_undefined

        def template(self, variable):
            return variable

    vars_manager = VariableManager()
    vars_manager.set_fact('b', 'b_value')
    vars_manager.set_fact('c', 'c_value')
    vars_manager.set_variable('d', 'd_value')

    # Case 1: available_variables has key "a"

# Generated at 2022-06-23 13:30:55.112216
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ansible_j2vars = AnsibleJ2Vars('','')
    assert ansible_j2vars.__class__.__name__ == 'AnsibleJ2Vars'

# Generated at 2022-06-23 13:31:06.042121
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    class FakeTemplar(Templar):

        def __init__(self):
            self.available_variables = { 'foo': 'bar' }

        def template(self, data, extra_vars=None,
                     convert_bare=False, cache=False, fail_on_undefined=True,
                     override_vars=None,
                     env=None,
                     vars=None,
                     expand_lists=True,
                     j2_native=False,
                     j2_vars=None,
                     encode_errors='strict'):
            return "template"

    class FakeModule(object):
        def get_option(self, x):
            if x == "vars_files":
                return []
            return None

    templar = FakeTemplar()

   

# Generated at 2022-06-23 13:31:16.989260
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        AnsibleJ2Vars(templar=None, globals=None)
        assert False
    except TypeError:
        assert True

    # test init()
    vars = AnsibleJ2Vars(templar='templar', globals='globals')
    assert vars._templar == 'templar'
    assert vars._globals == 'globals'
    assert vars._locals == {}
    assert not vars.get('var_name')

    # test add_locals()
    vars = AnsibleJ2Vars(templar='templar', globals='globals')
    new_locals = {'var_name': 'var_value'}
    vars.add_locals(locals=new_locals)

# Generated at 2022-06-23 13:31:27.274670
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2 as j2
    import yaml
    yaml_loader = j2.FileSystemLoader('./templates')
    j2_env = j2.Environment(loader=yaml_loader)
    j2_env.globals = {'foo': 'bar'}
    j2_env.globals.update({'list': [1, 2, 3]})
    j2_env.globals.update({'dict': {'key1': 'foo', 'key2': 'bar'}})

    # Create fake local variables that should override global variables in the template
    locals = {'foo': 'override_bar', 'list': ['override_foo', 'override_bar']}

# Generated at 2022-06-23 13:31:36.080516
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    ''' Ensures that add_locals of AnsibleJ2Vars class works'''
    locals = {"key1": "value1", "key2": "value2"}
    vars = {'key': 'value'}
    templar = None
    proxy = AnsibleJ2Vars(templar, vars)
    locals_proxy = proxy.add_locals(locals)
    assert len(locals_proxy) == len(locals) + len(vars)
    for key in locals:
        assert key in locals_proxy

# Generated at 2022-06-23 13:31:45.206297
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import sys, os

    import ansible.playbook.play_context as pc
    import ansible.template as template
    import ansible.vars.hostvars as ansible_hh
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # test code here
    # Don't test for host because it's not a builtin variable.
    context = pc.PlayContext()
    host = ansible_hh.HostVars({"inventory_hostname": "hello"})
    # Use a real variable manager for the test
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host, "inventory_hostname", "hello")


# Generated at 2022-06-23 13:31:52.097459
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar()
    globals = {}
    locals = {}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert isinstance(vars, AnsibleJ2Vars)
    print("test_AnsibleJ2Vars successful")

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-23 13:32:01.194544
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    templar = type('Templar', (object,), {'template': lambda self,x:x, 'available_variables':{'a':1, 'b':2}})()
    globals = {'c':3}
    locals  = {'a':4}

    proxy = AnsibleJ2Vars(templar, globals, locals)
    proxy_new = proxy.add_locals(locals={'d':4})

    assert proxy_new is not proxy
    assert proxy_new._templar is proxy._templar
    assert proxy_new._globals is proxy._globals
    assert proxy_new._locals  is not proxy._locals
    assert proxy_new._locals  != proxy._locals

# Generated at 2022-06-23 13:32:07.937061
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.templar import Templar
    from ansible.vars.unsafe_proxy import strip_unsafe_keys
    templar = Templar()
    vars = AnsibleJ2Vars(templar, {'foo': 'baz'})
    vars['bar'] = 'foo'
    vars = strip_unsafe_keys(vars, templar._available_variables)
    assert (len(vars) == 4)


# Generated at 2022-06-23 13:32:16.058160
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'foo': 'bar'}
    locals = {'baz': 'bat'}
    instance = AnsibleJ2Vars(templar, globals, locals=locals)
    assert instance._templar is templar
    assert instance._globals is globals
    assert instance._locals == locals


# Generated at 2022-06-23 13:32:24.127149
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    # input
    templar_mock = "templar"
    globals_mock = { 'item1': 'item1' }
    locals_mock = { 'item2': 'item2' }

    # test
    ansible_j2_vars_proxy = AnsibleJ2Vars(templar_mock, globals_mock)
    ansible_j2_vars_proxy = ansible_j2_vars_proxy.add_locals(locals_mock)

    # asserts
    assert ansible_j2_vars_proxy.__unwrap__()['_templar'] == templar_mock
    assert ansible_j2_vars_proxy.__unwrap__()['_globals'] == globals_mock
    assert ansible_j2

# Generated at 2022-06-23 13:32:28.321949
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar()
    globals = {}
    locals = {}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert(vars is not None)


# Generated at 2022-06-23 13:32:40.700908
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.hostvars import HostVars
    # set up locals to be passed to constructor of AnsibleJ2Vars
    locals = dict()
    locals['foo'] = 'bar'
    locals['a'] = 'b'
    locals['one'] = '1'
    locals['michael'] = 'dehaan'
    locals['hostvars'] = HostVars()
    locals['hostvars']['example.com'] = dict()
    locals['hostvars']['example.com']['ansible_host'] = '127.0.0.1'
    locals['hostvars']['example.com']['ansible_port'] = 22

    # set up globals to be passed to constructor of AnsibleJ2Vars
    globals = dict()
    globals['foo']

# Generated at 2022-06-23 13:32:48.559393
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.errors import AnsibleError
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    temp_dir = os.path.realpath(tempfile.mkdtemp())

    local_temp_dir = os.path.join(temp_dir, 'local_temp_dir')
    loader = DataLoader()
    variable_manager = VariableManager()

    try:
        os.mkdir(local_temp_dir)
    except OSError as e:
        raise AnsibleError("Failed to make local_temp_dir: %s" % e)

    variable_manager.set_vault_secrets

# Generated at 2022-06-23 13:32:58.183112
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template.templar import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # hosts = ['localhost']
    hostname = 'localhost'
    templar = Templar(loader=None, variables={})
    hostvars = HostVars(loader=None, variables={})

    # This is needed to load a variable using ansible_safe_eval
    # In this case we use the variable 'hostvars'