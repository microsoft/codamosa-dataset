

# Generated at 2022-06-23 13:23:05.612750
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    templar = Templar()
    globals = {
        'g_var': 'gvar_val'
    }
    locals = {
        'l_var': 'lvar_val',
        'l_undefined': missing,
    }
    variables = AnsibleJ2Vars(templar, globals, locals)
    assert 'g_var' in variables
    assert 'l_var' in variables
    assert 'l_undefined' not in variables
    assert 'abc' not in variables
    result = set()
    for elem in variables:
        result.add(elem)
    assert 'g_var' in result
    assert 'l_var' in result
    assert 'l_undefined' not in result

# Generated at 2022-06-23 13:23:13.992491
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    def test_func(data):
        return AnsibleUnsafeText(data)

    templar = Templar(loader=None)
    templar.available_variables = dict(a='a', b='b')
    templar.environment.globals['test_func'] = test_func
    vars = AnsibleJ2Vars(templar, templar.environment.globals)
    assert vars['a'] == 'a'
    assert vars['b'] == 'b'
    assert vars['test_func'] == test_func
    assert vars['missing'] == missing


# Generated at 2022-06-23 13:23:20.650729
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible import context
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    context.CLIARGS = {}
    templar = Templar(loader=None)

    host_vars1 = HostVars({"a": 1, "b": 2}, "fake_host")
    host_vars2 = HostVars({"c": 3, "d": 4}, "fake_host")

    test_vars = {
        "vars": {
            "x": "abcd",
            "y": "{{ z }}",
            "z": "xyz"
        }
    }

# Generated at 2022-06-23 13:23:29.975585
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    # Import needed for this unit test
    import jinja2
    from ansible.template import Templar

    # Set-up of test
    templar = Templar(loader=None)
    ansiblej2vars = AnsibleJ2Vars(templar, {}, locals=None)
    locals_test = {'test_key1': 'test_value1', 'test_key2': 'test_value2'}
    # Test the method
    ansiblej2vars_update = ansiblej2vars.add_locals(locals_test)

    # Check the results
    assert(ansiblej2vars_update._templar is templar)
    assert(ansiblej2vars_update._globals is {})

# Generated at 2022-06-23 13:23:36.238487
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Arrange a dummy AnsibleJ2Vars object
    class templar_object(object):
        def __init__(self):
            self.available_variables = dict()
        def template(self, x):
            return x
    templar = templar_object()
    globals = dict(foo='bar', answer=42)
    j2_vars = AnsibleJ2Vars(templar, globals)

    # Act
    result = list(j2_vars.__iter__())

    # Assert
    assert (result == ['foo', 'answer'])


# Generated at 2022-06-23 13:23:45.175767
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar as template
    templar = template()
    vars = AnsibleJ2Vars(templar, globals={}, locals={'x': 42})
    new_vars = vars.add_locals({'y': 10})

    assert 'x' in new_vars._locals
    assert 'y' in new_vars._locals
    assert new_vars._locals['x'] == 42
    assert new_vars._locals['y'] == 10

# Generated at 2022-06-23 13:23:55.397397
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    # Test with a simple setup:
    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()

    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader,
                      play_context=play_context)

    test_vars = AnsibleJ2Vars(templar=templar,
                              globals={},
                              locals={})

    test_vars["var1"] = "Hello"
    test_vars["var2"] = "World"

    assert "var1" in test_v

# Generated at 2022-06-23 13:23:57.851469
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # check if the constructor works correctly
    # args:
    # return:
    # exceptions:
    #     raise AnsibleError("AnsibleJ2Vars constructor is broken")
    return


# Generated at 2022-06-23 13:24:05.449875
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    ji = InventoryManager(loader=loader, sources=['localhost'])
    host = ji.get_host("localhost")
    host.vars = {'foo': 'bar', 'bar': 'baz'}
    variable_manager = VariableManager(loader=loader, inventory=ji)
    variable_manager.set_host_variable(host, 'hostvar', 'hostval')
    variable_manager.set_host_variable(host, 'inventory_hostname', 'localhost')

# Generated at 2022-06-23 13:24:14.883872
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    AJV = AnsibleJ2Vars(None, None, None)

    assert AJV.add_locals(None) is AJV
    assert AJV.add_locals({}) is AJV
    assert AJV.add_locals({'x': 'a'})._locals == {'x': 'a'}

    AJV = AnsibleJ2Vars(None, None, {'x': 'a'})

    assert AJV.add_locals(None)._locals == {'x': 'a'}
    assert AJV.add_locals({})._locals == {'x': 'a'}
    assert AJV.add_locals({'x': 'b'})._locals == {'x': 'b'}

# Generated at 2022-06-23 13:24:26.665077
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar()
    globals = { 'variables': {} }
    locals = { 'l_key_local': 'value_local' }

    j2_vars = AnsibleJ2Vars(templar, globals, locals)

    assert not ('wrong' in j2_vars)

    # key_local is defined in locals
    assert 'key_local' in j2_vars

    # key_local is defined in locals and in available_variables
    globals['variables'].update(available_variables={'key_local': 'value_available'})
    assert 'key_local' in j2_vars

    # key_local is defined in locals, in available_variables and in globals

# Generated at 2022-06-23 13:24:30.330703
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    vars = {'foo': 'foo'}
    test_obj = AnsibleJ2Vars(templar=templar, globals={'bar': 'bar'})
    test_obj.add_locals(vars)
    assert test_obj.__getitem__('foo') == 'foo'
    assert test_obj.__getitem__('bar') == 'bar'

# Generated at 2022-06-23 13:24:40.436295
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # No need to test more than one iteration, as it should be equivalent for all variables
    import jinja2
    from ansible.vars.hostvars import HostVars
    templar  = jinja2.Environment()
    variable = {'key1':'value1', 'key2':'value2'}
    vars     = {'var1':variable, 'var2':'value2', 'var3': HostVars()}
    globals  = {'global1':'globalvalue1'}
    ansiblej2vars = AnsibleJ2Vars(templar, globals, locals=vars)
    for variable in ansiblej2vars:
        return
    assert True == True


# Generated at 2022-06-23 13:24:49.884891
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    def fake_available_variables(self):
        return dict()

    def fake_template(self, variable):
        return variable

    old_available_variables = AnsibleJ2Vars.available_variables
    old_template = AnsibleJ2Vars.template
    AnsibleJ2Vars.available_variables = fake_available_variables
    AnsibleJ2Vars.template = fake_template

    # Test case that 'AnsibleJ2Vars' contains a variable which is in '_locals'
    locals = dict()
    locals['l_key1'] = "value1"
    locals['l_key2'] = "value2"
    vars_dict = AnsibleJ2Vars("templar", "globals", locals)
    assert("key1" in vars_dict)
   

# Generated at 2022-06-23 13:25:00.018582
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.vars import AnsibleVars
    import jinja2
    j2_environment = jinja2.Environment(undefined=jinja2.StrictUndefined)
    ansible_vars = AnsibleVars(j2_environment)
    ansible_vars._var_cache = {
            'ansible_host': '1.1.1.1',
            'ansible_port': 22,
        }
    proxy = AnsibleJ2Vars(ansible_vars, {}, {})
    assert proxy['ansible_host'] == '1.1.1.1'
    assert proxy['ansible_port'] == 22

    proxy = proxy.add_locals({'ansible_port': 2222})

# Generated at 2022-06-23 13:25:05.676752
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """
    Unit test for method __iter__.
    Checks return value of the method and raised exceptions.
    """

    class _MockTemplar:
        available_variables = [1, 2]

    j2vars = AnsibleJ2Vars(_MockTemplar(), {'test': 1})
    assert list(j2vars.__iter__()) == [1, 2, 'test']

# Generated at 2022-06-23 13:25:16.802736
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    templar = Templar(loader=None)
    collection_vars = dict(a=1, b=2)
    injected_vars = dict(c=3, d=4)
    extra_vars = dict(e=5, f=6)
    vars_dict = combine_vars(extra_vars, injected_vars, collection_vars)
    facts_dict = dict(foo=7, bar=8)
    templar._available_variables = vars_dict
    templar.set_available_variables(facts=facts_dict)
    ansible_vars = AnsibleJ2Vars(templar, globals=dict())

# Generated at 2022-06-23 13:25:26.718841
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'k': 'v'})

    j2vars = AnsibleJ2Vars(templar, {'a': 'b'}, locals={'c': 'd'})
    assert(j2vars['k'] == 'v')
    assert(j2vars['a'] == 'b')
    assert(j2vars['c'] == 'd')

    assert len(j2vars.add_locals({'e': 'f'})) == 5
    assert(j2vars.add_locals({'e': 'f'})['e'] == 'f')

# Generated at 2022-06-23 13:25:33.899420
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = None
    globals = dict(k1="v1", k2="v2", k3="v3")
    obj = AnsibleJ2Vars(templar, globals=globals)
    assert len(obj) == 3
    locals = dict(k4="v4", k5="v5", k6="v6")
    obj = AnsibleJ2Vars(templar, globals=globals, locals=locals)
    assert len(obj) == 6


# Generated at 2022-06-23 13:25:39.493118
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.unsafe_proxy import wrap_var

    # for now just try to make sure the constructor works
    templar = wrap_var(dict(a='b'))
    proxy = AnsibleJ2Vars(templar, dict(c='d'))

    assert 'a' in proxy
    assert 'c' in proxy
    assert proxy['a'] == 'b' and proxy['c'] == 'd'

# Generated at 2022-06-23 13:25:46.720850
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """Unit test for method __contains__ of class AnsibleJ2Vars"""
    from ansible.template import Templar
    # Test variables
    templar = Templar(loader=None)
    globals = None
    locals = None
    # Test error handling
    # Test normal behavior
    result = AnsibleJ2Vars(templar, globals, locals)
    assert isinstance(result, AnsibleJ2Vars)
    # Test normal behavior
    result = AnsibleJ2Vars(templar, globals, locals)
    assert isinstance(result, AnsibleJ2Vars)
    # Test normal behavior
    result = AnsibleJ2Vars(templar, globals, locals)
    assert isinstance(result, AnsibleJ2Vars)


# Generated at 2022-06-23 13:25:52.903671
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import fail_eval, bool_or_none, template
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.vars.hostvars import HostVars
    templar = template.Templar(loader=None, variables={'a': 'b', 'c': {'d': 'e'}, 'f': ['x', 'y']}, fail_on_undefined=False)

    globals_dict = {'g': 'h', 'i': {'j': 'k'}, 'l': ['m', 'n']}
    proxy = AnsibleJ2Vars(templar, globals=globals_dict)


# Generated at 2022-06-23 13:25:55.937389
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.templating import Templar
    assert type(AnsibleJ2Vars(Templar(), None, None)) == AnsibleJ2Vars

# Generated at 2022-06-23 13:26:07.498923
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Note: we don't need to test the exception cases because they are
    # tested in test_templar.py

    from ansible.parsing.templating import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars

    # The standard use case
    # 1) Variable from the task_vars
    # 2) Variable from the host_vars
    # 3) Special variable 'vars' (which contains the inventory variables)
    # 4) Special variable 'HostVars' (which contains the special variable 'inventory_hostname')
    var_manager = VariableManager()

# Generated at 2022-06-23 13:26:17.673458
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import unsafe_eval
    templar = unsafe_eval
    globals = {}
    locals = {'a': 'a', 'b': 'b'}
    a = AnsibleJ2Vars(templar, globals, locals)
    new_locals = {'a': 'aa', 'c': 'c'}
    b = AnsibleJ2Vars(templar, globals, locals=new_locals)
    c = a.add_locals(b)
    assert (c['a'] == 'aa')
    assert (c['b'] == 'b')
    assert (c['c'] == 'c')

# Generated at 2022-06-23 13:26:29.505318
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """
    Validate that AnsibleJ2Vars.__iter__() works as expected
    """

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    from ansible.module_utils import basic

    class TestAnsibleJ2Vars(unittest.TestCase):

        def setUp(self):
            self.module = basic.AnsibleModule(
                argument_spec=dict(
                    my_vars=dict(type='dict'),
                ),
            )

            self.module.params = dict(my_vars={'var1': 1, 'var2': 2})
            self.my_vars = self.module.params['my_vars']

        def tearDown(self):
            pass


# Generated at 2022-06-23 13:26:38.554709
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class AnsibleJ2Template(object):
        def __init__ (self, locals):
            self._locals = locals

        def template(self, varname):
            if self._locals is not None and varname in self._locals:
                return self._locals[varname]
            else:
                return (varname, self._locals)

    test_globals = { "g1": "glob1", "g2": "glob2"}
    test_local = { "l1": "loc1", "l2": "loc2"}
    test_templar = AnsibleJ2Template(test_local)
    vars = AnsibleJ2Vars(test_templar, test_globals, locals=test_local)
    assert len(vars) == 4

# Generated at 2022-06-23 13:26:47.253630
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()
    context.vars = dict(a=2)
    templar = Templar(loader=None, variables=context.vars)

    j2var = AnsibleJ2Vars(templar, dict(b=3), locals=dict(c=4))

    new_j2var = j2var.add_locals(dict(d=5))
    assert new_j2var._locals == dict(c=4, d=5)

# Generated at 2022-06-23 13:26:57.873535
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.play_context import PlayContext

    templar = Templar(PlayContext())
    globals = {
        'foo': 'foo_value',
        'bar': 'bar_value',
    }
    locals = {
        'bar': 'bar_value_from_locals',
    }
    variables = AnsibleJ2Vars(templar, globals, locals=locals)
    assert len(variables) == 2

    # If the value of a variable is an instance of class AnsibleUnsafeText,
    # the variable is not added
    globals = {
        'foo': 'foo_value',
        'bar': AnsibleUnsafeText('bar_value'),
    }

# Generated at 2022-06-23 13:27:09.143479
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # create a valid Templar object
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.templating.template
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    templar = ansible.templating.template.Templar(loader=loader, variable_manager=variable_manager)
    # create valid global and local variables
    # this test just calls the constructor
    globals = {'a_global': 'a_global_value'}
    locals = {'a_local': 'an_overridden_global_value'}
    # call constructor
    returned = AnsibleJ2Vars(templar, globals, locals)
    # check that it is

# Generated at 2022-06-23 13:27:18.045752
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    e = AnsibleJ2Vars(None, None, locals={})
    f = e.add_locals({'x': 1})
    assert isinstance(f, AnsibleJ2Vars)
    assert isinstance(f._locals, dict)
    assert f._locals == {'x': 1}
    assert f._globals is None

    g = f.add_locals({'x': 2})
    assert isinstance(g, AnsibleJ2Vars)
    assert g._locals['x'] == 1

    h = g.add_locals({'y': 2})
    assert isinstance(h, AnsibleJ2Vars)
    assert h._locals['y'] == 2
    assert h._locals['x'] == 1
    assert h._globals is None

# Generated at 2022-06-23 13:27:26.238782
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar # use real templar from ansible code
    from ansible.vars.hostvars import HostVars
    templar = Templar()
    ajv = AnsibleJ2Vars(templar, {'global1': 'global1', 'global2': 'global2'})
    assert 'global1' in ajv
    assert 'global2' in ajv
    assert 'local1' not in ajv
    assert 'local2' not in ajv
    new_globals = {'global1': 'overridden 1'}
    new_locals = {'local1': 'local1', 'local2': 'local2'}
    new_hostvars = HostVars(host=None, variables=new_globals)

# Generated at 2022-06-23 13:27:30.874486
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    j2vars = AnsibleJ2Vars("templar", "globals", "locals")
    try:
        j2vars["test"]
        assert False
    except KeyError as e:
        assert e.args[0] == "undefined variable: test"
    assert j2vars["vars"] == "globals"
    assert j2vars["templar"] == "templar"
    assert j2vars["locals"] == "locals"
    assert j2vars["globals"] == "globals"

# Generated at 2022-06-23 13:27:40.008864
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})
    ansible_vars = AnsibleJ2Vars(templar=templar, globals={}, locals={})

# Generated at 2022-06-23 13:27:48.527661
# Unit test for method __len__ of class AnsibleJ2Vars

# Generated at 2022-06-23 13:27:53.344776
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    play_context = PlayContext()
    inventory = loader.load_from_file("tests/inventory")
    templar = Templar(loader=loader, variables=inventory.get_host("foobar").get_vars())
    globals = {"hostvars": HostVars(play_context, {}), "play_hosts": {}}
    play_context.set_task_and_variable_override(inventory.get_host("foobar").get_vars(), templar)

    vars = AnsibleJ2Vars(templar, globals)
    env

# Generated at 2022-06-23 13:28:00.835544
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(dict())
    templar = Templar(loader=None, variables={}, vault_secrets=vault)

    globals = dict(x=1, y=2)
    locals = dict(z=3, t=4)
    obj = AnsibleJ2Vars(templar, globals, locals)

    result = set(obj)
    expected = set()
    expected.update(globals, locals)
    assert result == expected


# Generated at 2022-06-23 13:28:09.077564
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2.runtime
    # __len__ will not call __contains__ if a value is found in the mappings
    #
    # Test 1: only locals
    locals1 = {'a': 1, 'b': 2}
    j2vars = AnsibleJ2Vars(None, None, locals=locals1)
    assert len(j2vars) == 2
    # Test 2: only globals
    globals1 = {'a': 1, 'b': 2}
    j2vars = AnsibleJ2Vars(None, globals1)
    assert len(j2vars) == 2
    # Test 3: both locals and globals
    j2vars = AnsibleJ2Vars(None, globals1, locals=locals1)

# Generated at 2022-06-23 13:28:19.204497
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__(): # pylint: disable=too-many-locals
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import PluginLoader
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    data_loader = DataLoader()
    data_loader.set_basedir('/home/')
    inventory = InventoryManager(loader=data_loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=data_loader, inventory=inventory)

    class Options(object):
        vars = None
        tags = None
        listhosts = None
        subset = None
        extra

# Generated at 2022-06-23 13:28:30.785313
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = {'test_global_1': 'global_1', 'test_global_2': 'global_2'}
    locals  = {'test_local_1': 'local_1', 'test_local_2': 'local_2'}
    available_variables = {'test_available_variable_1': 'avilable_variable_1', 'test_available_variable_2': 'avilable_variable_2'}
    templar._available_variables = available_variables

    print('testing __iter__')
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-23 13:28:42.350343
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """
    Test __contains__ of AnsibleJ2Vars
    """
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    fake_loader = DictDataLoader({
        "templates/facts": TemplateData(u'''
            {% if ansible_system == "Linux" %}
               {% if ansible_distribution == "Ubuntu" %}
                 linux-ubuntu
               {% else %}
                 linux
               {% endif %}
            {% elif ansible_system == "SunOS" %}
               sunos
            {% endif %}
        ''')
    })


# Generated at 2022-06-23 13:28:52.202135
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    print("Running test_AnsibleJ2Vars___len__")
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()

    variable_manager._extra_vars = {
        'foo': 'bar',
        'baz': [1, 2],
        'bar': 'baz',
        'hello': 'goodbye'
    }
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    ansible_j2_vars = AnsibleJ2Vars(templar, {})
    assert len(ansible_j2_vars) == 4


# Generated at 2022-06-23 13:28:59.204957
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    import os
    import sys
    from units.mock.vars import inject_vars
    from units.mock.loader import DictDataLoader

    vars_manager = VariableManager()

# Generated at 2022-06-23 13:29:06.546660
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    a = AnsibleJ2Vars(None, {'a': 1, 'b': 2, 'c': 3}, locals={'b': 4, 'c': 5})
    b = a.add_locals({'a': 6, 'c': 7})
    assert a['b'] == 4
    assert b['b'] == 4
    assert a['a'] == 1
    assert b['a'] == 6
    assert a['c'] == 5
    assert b['c'] == 7

# Generated at 2022-06-23 13:29:12.815828
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    new_templar = Templar(loader=None)
    new_globals = {}
    new_locals = {}
    new_vars = AnsibleJ2Vars(templar = new_templar, globals = new_globals, locals = new_locals)
    print(new_vars)
# test_AnsibleJ2Vars()

# Generated at 2022-06-23 13:29:16.631846
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert AnsibleJ2Vars(None, {}).__len__() == 0
    assert AnsibleJ2Vars(None, {'a': 1}).__len__() == 1
    assert AnsibleJ2Vars(None, {'a': 1, 'b': 2}).__len__() == 2

# Generated at 2022-06-23 13:29:23.948108
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    testObj = AnsibleJ2Vars(Templar(loader=DataLoader()),
                            globals = {'foo': 'bar'},
                            locals = {'foobar': 'foo'})

    assert list(testObj) == ['foo', 'foobar']


# Generated at 2022-06-23 13:29:34.406922
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class AnsibleJ2VarsTest:
        def __init__(self):
            self.available_variables = {
                'test': 'a',
                'test1': 'b'
            }
            self.template = self.available_variables

        def template(self, val):
            return val

        def safe_template(self, val):
            return val

    templar = AnsibleJ2VarsTest()

    globals = {}
    locals = {
        'test': 'c',
        'test2': 'd',
        'context': 'e',
        'environment': 'f',
        'l_test': 'g',
    }

    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert len(j2vars) == len(locals)

# Generated at 2022-06-23 13:29:43.932830
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import os

    # Set up
    vm = VariableManager()
    templar = Templar(loader=None, variables=vm)

    # test __getitem__
    inj = AnsibleJ2Vars(templar, None)
    vm.set_host_variable(Host(name='foo'), 'test_var', 'this is some variable content')
    assert inj['test_var'] == 'this is some variable content'

# Generated at 2022-06-23 13:29:55.944864
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # set up some arbitrary parameters to be passed to AnsibleJ2Vars
    templar = object()
    globals = {'key1': 'value1', 'key2': 'value2'}
    locals = {'key3': 'value3', 'key4': 'value4'}

    # instantiate AnsibleJ2Vars
    vars_obj = AnsibleJ2Vars(templar, globals, locals)
    # test __contains__ for successful match of globals, locals and templar
    assert 'key1' in vars_obj
    assert 'key2' in vars_obj
    assert 'key3' in vars_obj
    assert 'key4' in vars_obj
    # test __contains__ for no match
    assert 'notakey' not in vars_obj

   

# Generated at 2022-06-23 13:30:04.265176
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
  vars = {}
  templar = type('Templar', (object,), {'available_variables': vars, 'template': lambda x: x})()
  ansible_j2_vars = AnsibleJ2Vars(templar, globals={'foo': 'bar'})
  assert len(ansible_j2_vars) == 2
  assert ansible_j2_vars['foo'] == 'bar'

# Generated at 2022-06-23 13:30:10.736684
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    locals = {'a': 1, 'b': 2, 'c': 3}
    globals = {'d': 4, 'e': 5, 'f': 6}
    av = {'av': 1, 1: 2, 2: 3, 'l_i': 4}

    test_templar = Templar([], [], av)

    count = len(AnsibleJ2Vars(test_templar, globals, locals))

    assert(count == 11)



# Generated at 2022-06-23 13:30:19.956100
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import os
    import pytest

    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = action_loader.ActionModuleLoader(None, '', False)

    play_context = PlayContext()
    play_context.hostvars = dict()
    templar = Templar(loader=loader, variables=play_context.hostvars)
    basedir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
    templar._basedir = basedir


# Generated at 2022-06-23 13:30:27.101018
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from jinja2 import DictLoader
    from ansible.inventory.manager import InventoryManager
    fake_loader = DictLoader({'good': '{{goodvar}} works'})
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=fake_loader))
    variable_manager.extra_vars = {'goodvar': 'fake'}
    variable_manager.host_vars = {'127.0.0.1': {'goodvar': 'real'}}
    templar = Templar(loader=fake_loader, variables=variable_manager)
    options = None
    j2vars = AnsibleJ2Vars(templar, dict(), dict())

# Generated at 2022-06-23 13:30:34.858241
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    # Create a Templar instance
    from ansible.template import Templar
    templar = Templar()
    templar._available_variables = {
        'var1': 1,
        'var2': 2,
        'hostvars': HostVars({'var3': 3}),
    }
    # Create a globals dictionary
    globals = {'var4': 4}
    # Create an AnsibleJ2Vars instance
    ansible_j2vars = AnsibleJ2Vars(templar, globals)
    # Check if the variables are present
    assert 'var1' in ansible_j2vars
    assert 'var2' in ansible_j2vars
    assert 'var3' in ansible_j2vars


# Generated at 2022-06-23 13:30:43.614340
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import generate_safe_names_for, assert_safe_names
    from ansible.template import Templar

    variables = dict(a=1, b=2)

    safe_names = generate_safe_names_for(variables, set(), Templar.allowed_include_patterns, 'test_AnsibleJ2Vars___iter__')
    assert_safe_names(safe_names, variables)

    v = AnsibleJ2Vars(Templar(loader=None), variables)
    assert set(v) == set(variables.keys())


# Generated at 2022-06-23 13:30:53.334378
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'test_var_1': 'old_value'})
    test_proxy = AnsibleJ2Vars(templar, {}, locals={})

    # no locals
    test_proxy2 = test_proxy.add_locals(None)
    assert test_proxy2._locals == {}

    # locals added
    test_proxy2 = test_proxy.add_locals({'test_var_2': 'new_value'})
    assert len(test_proxy2._locals) == 2
    assert test_proxy2._locals['test_var_1'] == 'old_value'
    assert test_proxy2._locals['test_var_2'] == 'new_value'

# Generated at 2022-06-23 13:31:00.931710
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    AnsibleJ2Vars.__contains__() Test
    '''
    templar = Templar()
    globals = {'pure_variable': 'v'}
    vars = AnsibleJ2Vars(templar, globals)
    constrained = vars.__contains__("test_AnsibleJ2Vars___contains__")
    assert(constrained == False)


# Generated at 2022-06-23 13:31:10.181398
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    locals = {'b': 'B', 'c': 'C', 'l_a': 'A'}
    globals = {'a': 'a', 'b': 'b', 'c': 'c'}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    result = sorted(list(ansible_j2_vars.__iter__()))
    expected = ['a', 'b', 'c']
    if result != expected:
        raise AssertionError("Failed to assert if AnsibleJ2Vars.__iter__() returned the expected result.\n"
                             "Expected:\n%s\n\nResult:\n%s\n" % (result, expected))

# Generated at 2022-06-23 13:31:22.164446
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    fake_variable_manager = VariableManager()
    fake_loader = None
    fake_templar = Templar(loader=fake_loader, variables=fake_variable_manager)

    fake_lookup_terms = 'lookup_terms'
    fake_terms = listify_lookup_plugin_terms(fake_lookup_terms, templar=fake_templar, loader=fake_loader, fail_on_undefined=False)

    # The value of fake_value is not important here as we will not load it
    # We create a fake AnsibleUnsafeText as we need to test with

# Generated at 2022-06-23 13:31:29.880270
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader

    locals = {
        'l_a': 'va',
        'l_b': 'vb',
        'l_c': '{{ l_a }}',
    }

    data = dict(
        a=1,
        b=dict(
            c='{{ a }}',
            d='{{ b.c }}',
        )
    )

    t = Templar(loader=DictDataLoader(dict()))
    obj = AnsibleBaseYAMLObject.construct_yaml_map(None, data)
    t.set_available_variables(obj)

# Generated at 2022-06-23 13:31:33.056613
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    aj2v = AnsibleJ2Vars(Templar(), {"a": 1})
    assert len(aj2v) == 1


# Generated at 2022-06-23 13:31:43.511342
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    Ensure that we hide the unsafe variables and template others
    '''

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    class mock_unsafe_text(AnsibleUnsafeText):
        def __init__(self, v):
            self.v = v

        def __eq__(self, other):
            return self.v == other.v

        def __str__(self):
            return self.v

        def __unicode__(self):
            return self.v

    class mock_unsafe_proxy(AnsibleUnsafe):
        def __init__(self, v):
            self.v = v

        def __eq__(self, other):
            return self.v == other.v

# Generated at 2022-06-23 13:31:50.136795
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    play_context = PlayContext()
    tqm = None
    playbook = Playbook.load('../../examples/playbook.yml', variable_manager = variable_manager, loader = loader, play_context = play_context, tqm = tqm)
    play = playbook.get_plays()[0]
    variable_manager.set_inventory(play.hosts)
    variable_manager.set_play_context(play_context)
    variable_manager.set_loader(loader)


# Generated at 2022-06-23 13:32:00.186827
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.inventory.host import Host

    templar = Templar(loader=None)

    hostvars = HostVars({"test": "value"})
    templar.set_available_variables(hostvars)
    templar.set_available_variables({"test2": "value2"})

    globals = {}
    locals = {}

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    iterable = ansible_j2_vars.__iter__()
    assert next(iterable) == "test"
    assert next(iterable) == "test2"

    # cleanup
    templar = None
    del tem

# Generated at 2022-06-23 13:32:10.370787
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    Ensure AnsibleJ2Vars.__iter__() returns a generator on __iter__
    '''
    import os
    from ansible.template import Templar

    local_vars = dict(a="hello", b="world", c=1, d=2, e=3)
    global_vars = dict(f="testing", g="testing", h=9)

    templar = Templar(loader=None)
    vars = AnsibleJ2Vars(templar, global_vars, local_vars)

    key_iterator = vars.__iter__()
    assert isinstance(key_iterator, type(iter(list()))), "Returned object is not an iterator"

# Generated at 2022-06-23 13:32:20.166143
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(None)
    globals = {'some_global': 1}
    locals = {'some_local': 2}
    vars_proxy = AnsibleJ2Vars(templar, globals, locals)
    new_locals = {'other_local': 3}
    new_proxy = vars_proxy.add_locals(new_locals)
    assert "some_local" in new_proxy._locals
    assert new_proxy._locals["some_local"] == 2
    assert "other_local" in new_proxy._locals
    assert new_proxy._locals["other_local"] == 3

# Generated at 2022-06-23 13:32:30.503374
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={ u'ansible_foo': u'bar' })
    globals = dict(a=1, b=2)
    locals = dict(c=3, d=4)

    my_vars = AnsibleJ2Vars(templar, globals, locals)

    assert (u'ansible_foo' in my_vars)
    assert (u'a' in my_vars)
    assert (u'c' in my_vars)

    assert (my_vars[u'ansible_foo'] == u'bar')
    assert (my_vars[u'a'] == 1)
    assert (my_vars[u'c'] == 3)

# Generated at 2022-06-23 13:32:35.879301
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    Test method __len__ of class AnsibleJ2Vars
    """
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = {}
    locals = {'a': 1, 'b': 2}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals=locals)

    # Call method __len__
    returned_value = ansible_j2_vars.__len__()

    assert returned_value == 2

# Generated at 2022-06-23 13:32:40.586469
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    # Setup variables
    templar = Templar()
    vars = AnsibleJ2Vars(templar, {'a':1}, {'b':2})
    # Add three elements
    vars['c'] = 3
    vars['d'] = 4
    vars['e'] = 5
    # Test length.
    assert len(vars) == 5

    # Add three elements
    vars['f'] = 6
    vars['g'] = 7
    vars['h'] = 8
    # Test length.
    assert len(vars) == 8

# Generated at 2022-06-23 13:32:45.850850
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert len(AnsibleJ2Vars(None, None)) == 0
    assert len(AnsibleJ2Vars(None, {'global_1': 1})) == 1
    assert len(AnsibleJ2Vars(None, {'global_1': 1}, {'local_1': 1})) == 2
    assert len(AnsibleJ2Vars(None, {'global_1': 1}, {'local_1': 1, 'local_2': 2})) == 3


# Generated at 2022-06-23 13:32:56.637429
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar      = Templar(loader=None, variables={})
    j2_vars      = AnsibleJ2Vars(templar, {}, {})

    # in this case, the variable is in available_variables
    # it will be returned as a templated value
    class A(object):
        def __str__(self):
            return "RESULT"

    templar.available_variables = { "a": A() }
    assert j2_vars["a"] == "RESULT"

    # in this case, the variable is in locals, it will be returned as is
    j2_vars._locals["b"] = "RESULT2"
    assert j