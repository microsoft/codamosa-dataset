

# Generated at 2022-06-23 13:23:05.040715
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Creating object
    templar = Templar(loader=None, variables=None)
    globals = {}
    locals = {}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # Check that __contains__ returns True if given variable is available
    templar.available_variables = {"var1": "value1", "var2": "value2"}
    assert "var1" in j2vars
    assert "var2" in j2vars

    # Check that __contains__ returns True if given variable is not available
    templar.available_variables = {}
    assert "var1" not in j2vars
    assert "var2" not in j2vars

    # Check that __contains__ returns True if given variable is global

# Generated at 2022-06-23 13:23:13.793605
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.utils.vars

    class Templar(object):
        def __init__(self, vars):
            self.available_variables = vars
            self.no_log_values = None
            self.cur_context = None

        def set_available_variables(self, variables):
            self.available_variables = variables

        def get_available_variables(self):
            return self.available_variables

        def set_no_log_values(self, no_log_values):
            self.no_log_values = no_log_values

        def set_templar_context(self, context):
            self.cur_context = context


# Generated at 2022-06-23 13:23:15.799363
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    vault.decrypt('foo')
    result = vault.decrypt('bar')
    assert result == 'bar'

# Generated at 2022-06-23 13:23:19.720409
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
   (templar, globals, locals) = ({}, {}, {})

# Generated at 2022-06-23 13:23:27.016224
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = {'a': 'b'}
    locals = {'a': 'c', 'l_b': 'd'}
    jvars = AnsibleJ2Vars(templar, globals, locals=locals)

    assert 'a' in jvars
    assert 'b' in jvars
    assert 'c' in jvars
    assert 'd' in jvars
    assert 'e' not in jvars


# Generated at 2022-06-23 13:23:35.977563
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar

    templar = Templar(loader=None)

    # construct with nothing
    vars = AnsibleJ2Vars(templar, dict())
    assert vars

    # construct with something in locals
    vars = AnsibleJ2Vars(templar, dict(), locals={'foo': 'bar'})
    assert vars

    # construct with something in globals
    vars = AnsibleJ2Vars(templar, { 'foo': 'bar' })
    assert vars

    # construct with something in locals and globals
    vars = AnsibleJ2Vars(templar, {'bar': 'foo'}, locals={'foo': 'bar'})
    assert vars

    # test that we can access the variables we put in
    assert 'foo' in vars


# Generated at 2022-06-23 13:23:48.793611
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
	print('Tests for AnsibleJ2Vars')
	# Test default constructor
	variables = AnsibleJ2Vars(templar=None, globals=None, locals=None)

	# Test __contains__
	if variables.__contains__('variable'):
		print('variable is present in variables variable')
	else:
		print('variable is not present in variables variable')

	# Test __getitem__
	print('variable present in variables variable is')
	print(variables.__getitem__('variable'))
	print('variable not present in variables variable is')
	try:
		print(variables.__getitem__('variable1'))
	except KeyError:
		print('Key error thrown')
		print('')

	# Test __iter__

# Generated at 2022-06-23 13:23:57.462719
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    AnsibleJ2Vars.__len__ should return the size of the set composed by
    the three collections : _templar.available_variables, self._locals and
    self._globals.
    '''
    templar = lambda : None
    templar.available_variables = {"var1" : 1, "var2" : 2}
    locals = {"var1" : 1, "var3" : 3}
    globals = {"var1" : 1, "var4" : 4}
    my_AnsibleJ2Vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(my_AnsibleJ2Vars) == 4


# Generated at 2022-06-23 13:24:05.979711
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.playbook.play_context
    import ansible.template.templar
    from ansible.template.template import Templar
    from ansible.template.vars import AllVars
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    play_context = ansible.playbook.play_context.PlayContext()
    templar = ansible.template.templar.Templar(loader=None, variables=AllVars(loader=None, play_context=play_context))
    templar._available_variables = {
        'foo': 'bar',
        'baz': 'test',
    }

    globals = {
        'xyz': 'test',
    }


# Generated at 2022-06-23 13:24:15.245416
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import hostvars
    from ansible.template import Templar
    from ansible import constants as C

    ajv = AnsibleJ2Vars(Templar(None, loader=None), None, locals={'context': 'host'})

    # No exceptions should be thrown
    try:
        'context' in ajv
    except Exception:
        assert False, '\'context\' not in ajv'

    try:
        'template' in ajv
    except Exception:
        assert False, '\'template\' not in ajv'

    try:
        'foo' in ajv
    except Exception:
        assert False, '\'foo\' not in ajv'


# Generated at 2022-06-23 13:24:26.376652
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=loader)

    d = AnsibleJ2Vars(templar, {'a': 'g1'})
    d = d.add_locals({'a': 'local1'})
    assert d['a'] == 'local1'
    assert d.add_locals({'b': 'local2'})['a'] == 'local1'
    assert d.add_locals({'b': 'local2'})['b'] == 'local2'

# Generated at 2022-06-23 13:24:28.533972
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = None
    locals = {'foo': 'bar'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in j2vars
    assert 'bar' not in j2vars

# Generated at 2022-06-23 13:24:34.453905
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import mock

    # Test execution in single task
    templar_mock = mock.MagicMock()
    vars_mock = mock.MagicMock()
    j2vars = AnsibleJ2Vars(templar_mock, vars_mock)
    assert j2vars._templar == templar_mock
    assert j2vars._globals == vars_mock
    assert j2vars._locals == {}

    # Test execution in role execution
    locals_mock = {"test": "value"}
    j2vars = AnsibleJ2Vars(templar_mock, vars_mock, locals_mock)
    assert j2vars._locals == locals_mock


# Generated at 2022-06-23 13:24:42.339776
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    d = {'test': 'Test1'}
    globals = {'test': 'Test2'}
    templar = Templar(loader=None)
    vars = AnsibleJ2Vars(templar, globals)
    assert vars['test'] == 'Test2'
    vars = AnsibleJ2Vars(templar, globals, locals=d)
    assert vars['test'] == 'Test1'
    hv = HostVars()
    assert vars['vars'] is hv
    hv['test'] = 'Test3'
    assert vars['test'] == 'Test3'

# Generated at 2022-06-23 13:24:50.750730
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import sys
    import os
    import unittest
    from ansible.template.safe_eval import safe_eval

    curdir = os.path.dirname(os.path.abspath(__file__))
    templardir = os.path.join(curdir, '..', '..', 'template')
    sys.path.insert(0, templardir)

    # import jinja2
    from ansible.template import Templar
    from ansible.template.template import AnsibleTemplate

    class TestAnsibleJ2Vars(unittest.TestCase):
        def setUp(self):
            self.template_class = AnsibleTemplate

        def test_ansiblej2vars_init(self):
            t_obj = Templar(loader=None, variables={})
            t_obj.set

# Generated at 2022-06-23 13:24:59.595674
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2
    import tempfile

    with tempfile.NamedTemporaryFile() as temp:

        test_input = '''{{ (hostvars[host]['ansible_os_family'] | string)[0] }}'''
        test_output = '''{{ (hostvars[host]['ansible_os_family'] | string)[0] }}'''

        temp.write(test_input.encode('utf-8'))
        temp.seek(0)

        with open(temp.name, 'r') as temp_read:
            input_template = temp_read.read()
            template_vars = {
                'hostvars': {
                    'host': {
                        'ansible_os_family': 'RedHat'
                    }
                },
                'host': 'host'
            }



# Generated at 2022-06-23 13:25:06.237573
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = dict()
    locals = dict()

    a_j2v = AnsibleJ2Vars(templar, globals, locals)

    assert locals == a_j2v._locals
    assert templar == a_j2v._templar
    assert globals == a_j2v._globals
    locals = dict(foo=1)
    new_a_j2v = a_j2v.add_locals(locals)
    assert locals == new_a_j2v._locals
    assert templar == new_a_j2v._templar
    assert globals == new_a_j2v._globals

# Generated at 2022-06-23 13:25:07.111847
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert True

# Generated at 2022-06-23 13:25:15.874948
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import Templar

    all_plugin_dirs = []
    add_all_plugin_dirs(all_plugin_dirs)

    vars = {'a': 1, 'b': 2, 'c': 3}
    templar = Templar(all_plugin_dirs=all_plugin_dirs)

    aj2vars = AnsibleJ2Vars(templar, vars, locals=locals())
    assert sorted(list(aj2vars.__iter__())) == ['a', 'b', 'c']


# Generated at 2022-06-23 13:25:22.527809
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    test_vars = {'a':1, 'b':2, 'c':3}
    test_globals = {'d':4, 'e':5, 'f':6}
    test_locals = {'g':7, 'h':8, 'i':9}
    templar = Templar(loader=None)
    test_ansible_j2_vars = AnsibleJ2Vars(templar, globals=test_globals, locals=test_locals)
    test_ansible_j2_vars._templar.available_variables = test_vars
    assert test_ansible_j2_vars.__len__() == 9


# Generated at 2022-06-23 13:25:32.672942
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Test globals and locals are returned as expected
    templar = Templar(loader=None)
    globals = {"var1": "val1", "var2": "val2"}
    locals = {"var3": "val3", "var4": "val4"}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == len(globals) + len(locals)
    assert "var1" in j2vars
    assert "var2" in j2vars
    assert "var3" in j2vars
    assert "var4" in j2vars
    # Test new locals get added correctly
    locals = {"var5": "val5"}

# Generated at 2022-06-23 13:25:41.599275
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar()
    globals = {'foo': 'bar'}
    locals = {'bar': 'foo'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'foo' in vars
    assert 'bar' in vars
    # Tests if checks in AnsibleJ2Vars.__contains__ when traversing the locals dict
    assert 'i_am_safe' not in vars
    vars._locals = {'i_am_safe': AnsibleUnsafeText('I AM SAFE')}
    assert 'i_am_safe' in vars


# Generated at 2022-06-23 13:25:50.795921
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = MockTemplar()
    globals = {'foo': 'bar'}
    locals = {'baz': 'qux'}
    var_proxy = AnsibleJ2Vars(templar, globals, locals=locals)
    assert var_proxy['foo'] == globals['foo']
    assert var_proxy['baz'] == locals['baz']
    locals_new = {'baz': 'qux2'}
    var_proxy2 = var_proxy.add_locals(locals_new)
    assert len(var_proxy2) == len(var_proxy) + 1
    assert var_proxy2['baz'] == locals_new['baz']



# Generated at 2022-06-23 13:26:02.557044
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)
    hosts_vars = HostVars(host_vars={})
    hosts_vars.add_host("test01")
    hosts_vars['test01']['var1'] = 10
    hosts_vars['test01'].add_host("test02")
    hosts_vars['test01']['test02']['var2'] = 20
    vars_loader = {'var1': ['val1', 'val2'], 'test': hosts_vars}
    templar._available_variables = vars_loader
    globals = {"testg" : "gval"}
    locals = {'testl': 'lval'}

    ans

# Generated at 2022-06-23 13:26:06.904816
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    in_vars = {'test_key':'test_value'}
    var_proxy = AnsibleJ2Vars(templar, in_vars)
    var_proxy.__len__()


# Generated at 2022-06-23 13:26:09.371291
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass



# Generated at 2022-06-23 13:26:19.814392
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    my_templar = Templar(loader=None)

    globals = {
        'test1': 'test1',
        'test2': 'test2'
    }    
    locals  = {
        'test3': 'test3',
        'test4': 'test4'
    }    
    my_AnsibleJ2Vars = AnsibleJ2Vars(my_templar, globals, locals)

    # Test if AnsibleJ2Vars.__getitem__() returns the expected values
    assert my_AnsibleJ2Vars['test1'] == 'test1'
    assert my_AnsibleJ2Vars['test2'] == 'test2'
    assert my_AnsibleJ2Vars['test3'] == 'test3'

# Generated at 2022-06-23 13:26:32.058532
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    import yaml
    templar = Templar(loader=None, variables=None)
    vars = {}
    source_content = '''
    a: some_value
    b: some_other_value
    '''
    vars = combine_vars(vars, yaml.load(source_content))
    vars = AnsibleJ2Vars(templar, {}, locals=vars)
    assert vars['a'] == 'some_value'
    assert vars['b'] == 'some_other_value'

    vars = vars.add_locals({'a': 'another_value', 'c': 'yet_another_value'})
    assert vars['a'] == 'another_value'

# Generated at 2022-06-23 13:26:38.940167
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import pytest

    templar = {"foo": "bar"}
    globals = {}
    locals = {"foo": "bar"}

    # test with locals
    vars = AnsibleJ2Vars(templar, globals, locals=locals)
    vars = vars.add_locals({"foo": "bar2"})
    assert vars["foo"] == "bar2"

    # test without locals
    vars = AnsibleJ2Vars(templar, globals)
    vars = vars.add_locals({"foo": "bar3"})
    assert len(vars) == 1
    assert vars["foo"] == "bar3"

# Generated at 2022-06-23 13:26:50.250090
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    locals = dict(
        b='local b',
        c='local c',
        l_a='local l_a',
        l_b='local l_b',
        context=dict(a='context a', b='context b'),
        environment=dict(a='environment a', b='environment b'),
        template=dict(a='template a', b='template b'),
    )

# Generated at 2022-06-23 13:26:58.526178
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = dict(a='b')
    locals = dict(b='c')
    instance = AnsibleJ2Vars(templar, globals, locals)
    wrapped_locals = wrap_var(locals)
    ansible_locals = dict(l_b='c')

    assert dict(instance) == dict(ansible_locals, **globals)

# Generated at 2022-06-23 13:27:06.853124
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars

    class MyTemplar(Templar):
        def __init__(self, variables):
            self.available_variables = variables

    variables = {"vars": {"key1": "value1"}, "key2": "value2"}
    locals = {"l_key3": "value3", "l_key4": {"key5": "value5"}}
    globals = {"g_key6": UnsafeProxy({'key6': {'key7': 'value7'}}), "g_key8": HostVars()}

    aj2v = AnsibleJ2Vars(MyTemplar(variables), globals, locals)

# Generated at 2022-06-23 13:27:10.863369
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = None
    globals = {'a': 1}
    locals = None

    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    assert len(ansible_j2_vars) == 1


# Generated at 2022-06-23 13:27:18.044320
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.unsafe_proxy import generate_unsafe

    templar = generate_unsafe('dict')
    globals = {'g_key':'g_value'}
    locals = {'l_key':'l_value'}
    aj2v = AnsibleJ2Vars(templar, globals, locals)

    for key in aj2v:
        assert key in aj2v

    assert 'g_key' in aj2v
    assert 'l_key' in aj2v

    assert 'no_key' not in aj2v


# Generated at 2022-06-23 13:27:19.086733
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass



# Generated at 2022-06-23 13:27:25.147604
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    Test class AnsibleJ2Vars, method __len__
    '''
    uut = AnsibleJ2Vars(None, {'alpha':1, 'beta':2, 'gamma':3})
    assert len(uut) == 3, 'should have counted 3 items in map'

# Generated at 2022-06-23 13:27:35.923032
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    # 1. testing AnsibleJ2Vars with no variables
    templar = Templar()
    py_vars = AnsibleJ2Vars(templar, globals={})
    assert len(py_vars) == 0

    # 2. testing AnsibleJ2Vars with some variables
    globals = {
        "foo": "bar"
    }
    locals = {
        "foo": "bar",
        "test": True
    }

    templar = Templar()
    py_vars = AnsibleJ2Vars(templar, globals=globals, locals=locals)
    assert len(py_vars) == 2

    # 3. testing AnsibleJ2Vars with a

# Generated at 2022-06-23 13:27:47.070450
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Create two fake dictionary
    dict1 = dict(a=1, b=2, c=3)
    dict2 = dict(d=4, e=5, f=6)

    class fake_templar:
        available_variables = dict1

    # Pretend that fake_templar is a templar object
    templar = fake_templar()
    # Init AnsibleJ2Vars class
    j2v = AnsibleJ2Vars(templar, dict2)

    # Evaluate the len of j2v (with __len__ method)
    len_j2v = len(j2v)
    # Get the size of the union of the two dictionaries
    size_union = len(set.union(set(dict1.keys()),set(dict2.keys())))

    #

# Generated at 2022-06-23 13:27:55.392137
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    is_in = __contains__
    mydict = {'a':1, 'b':2, 'c':3}
    assert(is_in(mydict, 'a') == True)
    assert(is_in(mydict, 'b') == True)
    assert(is_in(mydict, 'c') == True)
    assert(is_in(mydict, 'd') == False)
    print('test_AnsibleJ2Vars___contains__: {}'.format('PASS'))


# Generated at 2022-06-23 13:28:03.853641
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    j2_vars = AnsibleJ2Vars(templar, {'a':1,'b':2})

    assert j2_vars['a'] == 1
    assert j2_vars['b'] == 2

    try:
        j2_vars['c']
        raise AssertioError('j2_vars must raise `KeyError`')
    except KeyError:
        pass

    assert set(j2_vars) == set(['a','b'])
    assert len(j2_vars) == 2

# Generated at 2022-06-23 13:28:16.183213
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    import os
    import sys

    # Monkey patch to avoid loading plugins
    old_get_all = Templar._get_all_plugin_loaders

    def _get_all_plugin_loaders(templar, *args, **kwargs):
        from ansible.errors import AnsibleError
        raise AnsibleError('plugin loading disallowed for this test case')
    Templar._get_all_plugin_loaders = _get_all_plugin_loaders

    add_all_plugin_dirs()

    # Monkey patch to avoid loading filters
    old_filter_loader = Templar._filter_loader


# Generated at 2022-06-23 13:28:22.668639
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from jinja2 import Environment

    templar = Environment()
    j2vars = AnsibleJ2Vars(templar, globals={'var1': 1, 'var2': 2, 'var3': 3})

    assert len(j2vars) == 3

# Generated at 2022-06-23 13:28:32.248048
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class MyTemplar():
        def __init__(self):
            self.available_variables = {
                'hostvars': 'hostvars',
                'var1': 'value1',
                'var2': {
                    'var3': 'value3'
                },
                'var4': [
                    'value4',
                    'value5',
                    {
                        'var6': 'value6'
                    }
                ]
            }
        def template(self, variable):
            return variable

    class MyGlobals():
        def __getitem__(self, varname):
            if varname == 'global_var1':
                return 'global_value1'
            elif varname == 'global_var2':
                return {
                    'global_var3': 'global_value3',
                }


# Generated at 2022-06-23 13:28:43.042587
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar

    # test the constructor
    template_vars = {'foo': 'bar'}
    template_vars['hostvars'] = dict(foo='bar')
    template_vars['ansible_all_ipv4_addresses'] = ['127.0.0.1']
    template_vars['ansible_all_ipv6_addresses'] = ['::1']
    template_vars['ansible_fqdn'] = 'localhost'
    template_vars['ansible_hostname'] = 'localhost'
    template_vars['ansible_default_ipv4'] = dict(address='127.0.0.1', aliases=['localhost'])
    template_vars['ansible_default_ipv6'] = dict(address='::1', aliases=[])
   

# Generated at 2022-06-23 13:28:43.924282
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    assert True

# Generated at 2022-06-23 13:28:54.224901
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    def _mock_template(value):
        if isinstance(value, dict):
            return value
        else:
            return value+'_template'

    class _MockTemplar():
        def __init__(self, available_variables):
            self.available_variables = available_variables

        def template(self,value):
            return _mock_template(value)

    def _mock_getitem_and_contains(value):
        def __getitem__(self, key):
            return value
        def __contains__(self, key):
            return True
        return (__getitem__, __contains__)

    import random

    # test __len__ with 3 empty dict
    templar = _MockTemplar({})
    globals = {}
    locals = {}
   

# Generated at 2022-06-23 13:29:06.494499
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    j2vars = AnsibleJ2Vars(None, None)
    try:
        j2vars['a']
    except KeyError as e:
        assert type(e) == KeyError
        assert str(e) == "undefined variable: a"
    try:
        j2vars['b']
    except KeyError as e:
        assert type(e) == KeyError
        assert str(e) == "undefined variable: b"
    assert 'a' not in j2vars
    assert 'b' not in j2vars

    j2vars._templar.available_variables = {'a': 10}
    assert j2vars['a'] == 10
    assert 'a' in j2vars

    j2vars._globals = {'b': 20}
    assert j

# Generated at 2022-06-23 13:29:16.952752
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar

    h = dict(
        hostvars = dict(a=1, b=2, c=3),
        ansible_vars = dict(a=dict(a=1, b=2, c=3), b = dict(a=2, b=3, c=4)),
    )
    v = dict(
        __unsafe__ = dict(a=1, b=2, c=3),
        hostvars = dict(a=1, b=2, c=3),
    )
    g = dict(
        a=1, b=2, c=3,
    )

    # var name 'hostvars' is skipped because isinstance(h['hostvars'], HostVars) is true

# Generated at 2022-06-23 13:29:27.009543
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    t = Templar(loader=None, variables={'xyz': 'abc'})
    av = AnsibleJ2Vars(t, {'a': 'global_a'}, {'b': 'local_b'})
    assert ('a' in av)
    assert ('b' in av)
    assert ('xyz' in av)
    assert ('not_there' not in av)
    assert (av['a'] == 'global_a')
    assert (av['b'] == 'local_b')
    assert (av['xyz'] == 'abc')
    assert (av.get('xyz') == 'abc')
    assert (av.get('missing') is None)
    assert (av.get('missing', 'x') == 'x')

# Generated at 2022-06-23 13:29:37.330123
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template.safe_eval import safe_eval

    templar = Templar(loader=None)
    templar._available_variables = dict()
    value = dict()
    value['key1'] = AnsibleUnicode('value1')
    value['key2'] = AnsibleUnicode('value2')
    templar._available_variables['vars'] = value
    globals = dict()
    globals['gkey'] = AnsibleUnicode('gvalue')
    locals = dict()
    locals['lkey'] = AnsibleUnicode('lvalue')

    # test case 1: key in available_variables
    # excepted result: True
    ansiblej2

# Generated at 2022-06-23 13:29:46.374030
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    class FakeTemplate():
        def __init__(self, name):
            self.name = name

    class FakeTemplar():
        def __init__(self, available_variables):
            self.available_variables = available_variables

        def available_variables(self):
            return self.available_variables

        def get_initial_variable_scope(self, play=None, host=None, task=None):
            return self.available_variables

        def template(self, template, preserve_trailing_newlines=False, escape_backslashes=True,
                     fail_on_undefined=False, convert_data=True, strip_comments=True):
            if isinstance(template, FakeTemplate):
                return 'templated:%s' % template.name
            else:
                return template


# Generated at 2022-06-23 13:29:57.498139
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar

    templar = Templar(loader=None)
    j2_vars = AnsibleJ2Vars(templar, globals=None)
    assert isinstance(j2_vars, AnsibleJ2Vars)
    assert isinstance(j2_vars, Mapping)
    assert not hasattr(j2_vars, '__getitem__')

    templar.set_available_variables(dict(
        foo='bar',
        baz='quux',
        list=['foo', 'bar', 'baz', 'quux'],
        int=1,
        float=0.001,
        bool=True
    ))

# Generated at 2022-06-23 13:30:04.171172
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class Templar:
        available_variables = {}
        def template(self, variable):
            return variable

    vars = AnsibleJ2Vars(Templar(), dict())
    local_vars = dict()
    local_vars['test'] = 'test'

    assert(vars.add_locals(local_vars)['test'] == 'test')

# Generated at 2022-06-23 13:30:12.497696
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.templating import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager

    vars_dict1 = dict(
        config_vars=dict(
            dns_server='1.2.3.4',
            vault_secret="{{ '1234567890abcdef' | password_hash('sha512', 'salt') }}",
        ),
        vars=dict(
            vault_password_file='/etc/vault_password',
        ),
    )
    vm1 = VariableManager()
    vm1.extra_vars = vars_dict1


# Generated at 2022-06-23 13:30:22.038098
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Simulating the usage of AnsibleJ2Vars.
    '''
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    inventory = Inventory(variable_manager=variable_manager)
    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{foo}}')))
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=None)

    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = None

# Generated at 2022-06-23 13:30:32.068436
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class myTemplate(object):
        def __init__(self, var):
            self.var = var

        def template(self, var):
            return self.var

    class myJ2Vars(AnsibleJ2Vars):
        def __init__(self, var):
            self.var = var

        def __getitem__(self, varname):
            return self.var

    t = myTemplate('hostvars')
    v = myJ2Vars('hostvars')
    assert len(v), 'len of AnsibleJ2Vars returns 0'

# Generated at 2022-06-23 13:30:42.588700
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    variables = VariableManager()
    variables.extra_vars = dict()
    variables.extra_vars['test_variable'] = "test value 2"
    templar = Templar(loader=None, variables=variables)
    newVars = AnsibleJ2Vars(templar, globals=dict(), locals=dict())
    assert ("test_variable" in newVars)
    assert (newVars["test_variable"] == "test value 2")
    newVars = AnsibleJ2Vars(templar, globals=dict(test_variable="test value 3"), locals=dict())
    assert ("test_variable" in newVars)
    assert (newVars["test_variable"] == "test value 3")
    # This

# Generated at 2022-06-23 13:30:52.983265
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleSequence

    templar = Templar()

    avail_vars = {
        'foo': 'bar',
        'bam': 'boo',
        'abc': AnsibleSequence([1, 2, 3], loader=None, vault_password=None),
    }

    test_obj = AnsibleJ2Vars(templar, avail_vars)
    assert(len(test_obj) == 3)
    assert(test_obj.__contains__('foo'))

    test_obj = AnsibleJ2Vars(templar, avail_vars, locals={'bam': 'not_boo'})
    assert(len(test_obj) == 4)

# Generated at 2022-06-23 13:31:04.712687
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # create vars with value HostVars
    hostvars = HostVars()

# Generated at 2022-06-23 13:31:05.692899
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert True

# Generated at 2022-06-23 13:31:15.172968
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    assert len(AnsibleJ2Vars(Templar(PlayContext()), {'a': 1}, {'b': 2})) == 2
    assert len(AnsibleJ2Vars(Templar(PlayContext()), {'a': 1})) == 1
    assert len(AnsibleJ2Vars(Templar(PlayContext()), {'a': 1}, {'b': 2, 'a': 3})) == 2
    assert len(AnsibleJ2Vars(Templar(PlayContext()), {'b': 2, 'a': 3}, {'a': 1})) == 2


# Generated at 2022-06-23 13:31:26.379407
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    templar = Templar(None, loader=None)

    var_proxy = AnsibleJ2Vars(templar, {}, locals={})
    var_proxy = var_proxy.add_locals({'foo': 'bar'})

    assert var_proxy._locals == {'foo': 'bar'}

    # Test that locals do not propagate to child templates, by creating a child template
    # and making sure that it does not have the 'foo' local variable.
    child = var_proxy.add_locals({})
    assert child._locals == {}

    # Test that locals do propagate to child templates, but only if jinja2>=2.9

# Generated at 2022-06-23 13:31:38.104889
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager.set_inventory(inventory)

    play_source =  dict(
            name = "Ansible Play",
            hosts = "localhost",
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='Hello World'))),
            ]
        )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    all_vars = variable

# Generated at 2022-06-23 13:31:46.948983
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    locals = dict()
    locals['l1'] = 'val1'
    locals['l2'] = 'val2'
    variables = dict()
    variables['v1'] = 'val1'
    variables['v2'] = 'val2'
    globals = dict()
    globals['g1'] = 'val1'
    globals['g2'] = 'val2'
    templar = Templar(loader=None)
    templar.available_variables = variables
    j2vars = AnsibleJ2Vars(templar=templar, locals=locals, globals=globals)
    assert 'g1' in j2vars
    assert 'g2' in j2vars
    assert 'l1' in j2vars

# Generated at 2022-06-23 13:31:58.956032
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from jinja2.loaders import DictLoader
    from ansible.template import Templar

    env = jinja2.Environment(loader=DictLoader(
        {'test.j2': '{{ foo }}{{ bar }} {{ dict }}'}))
    globals = dict()
    templar = Templar(loader=env)
    j2vars = AnsibleJ2Vars(templar, globals=globals)

    # first, we test the locals previously in the code block:
    # new_locals = dict((key, val) for key,val in iteritems(locals) if key not in ('context', 'environment', 'template'))
    # if the locals contain 'foo', 'bar' and 'dict', everything is ok!

# Generated at 2022-06-23 13:32:09.802999
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import copy

    templar = None # Not used

    # Test with empty dict
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars.add_locals(dict()) == j2vars
    assert j2vars.add_locals(None) == j2vars

    # Test with a locals that does not modify the j2vars
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    new_locals = dict(a=1, b=2, c=3)
    assert j2vars.add_locals(new_locals) != j2vars
    assert j2vars

# Generated at 2022-06-23 13:32:14.548910
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    templar_instance = Templar(loader=None, variables={})
    ansiblej2vars_instance = AnsibleJ2Vars(templar=templar_instance, globals={'something': 'something'})
    len_results = ansiblej2vars_instance.__len__()
    print("len_results: %s" % len_results)

test_AnsibleJ2Vars___len__()


# Generated at 2022-06-23 13:32:23.298124
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import  SafeEval
    from ansible.template import Templar

    locs = {'l_template': 'foo', 'a': 1, 'b': 2, 'c': 3}
    glob = {'g_template': 'bar', 'd': 1, 'e': 2, 'f': 3}
    vars = {'v_template': 'baz', 'var': 1, 'var_2': 2, 'var_3': 3}

    # initialize string templar
    templar = Templar(loader=None, variables=vars, shared_loader_obj=None)
    # initialize AnsibleJ2Vars object
    aj2vars = AnsibleJ2Vars(templar, globals=glob, locals=locs)


# Generated at 2022-06-23 13:32:32.923389
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()

    locals = {'a': 1, 'b': 2}
    j2vars = AnsibleJ2Vars(templar, globals, locals=locals)
    j2vars_locals = j2vars.add_locals(locals)

    assert j2vars_locals is not j2vars
    assert j2vars_locals._templar is j2vars._templar
    assert j2vars_locals._globals is j2vars._globals
    assert j2vars_locals._locals is not j2vars._locals

# Generated at 2022-06-23 13:32:39.952333
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.utils import template
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.template import TaskVars
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    templar = template.Templar(loader=DataLoader())
    templar._available_variables = {
        'ansible_architecture': 'x86_64',
        'ansible_bios_date': '01/01/2011',
        'ansible_bios_version': 'unknown',
    }
    j2vars = AnsibleJ2Vars(templar, {}, None)
    j2vars._locals = {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-23 13:32:45.320656
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = DummyTemplar()
    globals = DummyDict()
    locals = DummyDict()
    globals.dict.update({'g1':'g1 value', 'g2':'g2 value'})
    locals.dict.update({'l1':'l1 value', 'l2':'l2 value'})
    av = AnsibleJ2Vars(templar, globals, locals)
    assert 3 == len(av)


# Generated at 2022-06-23 13:32:48.967669
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    print("AnsibleJ2Vars")
    from ansible.template import Templar
    templar = Templar(loader=None)
    print("Templar instance : ", templar)
    AnsibleJ2Vars(templar , {}, {})

if __name__ == "__main__":
    test_AnsibleJ2Vars()

# Generated at 2022-06-23 13:32:58.591393
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    defaults = dict(
        templar=None,
        globals=None,
        locals=None,
    )

    def _copydict(src, dst):
        if isinstance(src, dict):
            src = dict(src)
        assert isinstance(src, dict)
        dst.update(src)

    defaults_copy = dict(defaults)
    params = dict(templar='abc')
    _copydict(params, defaults_copy)
    assert defaults_copy == dict(
        templar='abc',
        globals=None,
        locals=None,
    )

    defaults_copy = dict(defaults)
    params = dict(globals='abc')
    _copydict(params, defaults_copy)