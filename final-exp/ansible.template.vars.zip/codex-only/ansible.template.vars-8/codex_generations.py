

# Generated at 2022-06-23 13:23:01.022616
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = object()
    globals = {}
    locals = {}

    obj = AnsibleJ2Vars(templar, globals, locals)
    new_locals = {'foo':'bar'}
    new_obj = obj.add_locals(new_locals)

    assert isinstance(new_obj, AnsibleJ2Vars)
    assert new_obj._templar == templar
    assert new_obj._globals == globals
    assert new_obj._locals == new_locals

# Generated at 2022-06-23 13:23:11.599403
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = None

# Generated at 2022-06-23 13:23:21.447208
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Unit test for method __contains__ of class AnsibleJ2Vars
    '''
    class AnsibleJ2VarsTest(AnsibleJ2Vars):
        '''
        AnsibleJ2Vars subclass created to access the __contains__ method
        '''

        def __contains__(self, k):
            '''
            To access __contains__ method
            '''
            return super(AnsibleJ2VarsTest, self).__contains__(k)

    from ansible.template import Templar
    templar = Templar(loader=None)
    templar._available_variables = {'test_value1': 'test_value1', 'test_value2': 'test_value2', 'test_value3': 'test_value3'}

    obj = AnsibleJ

# Generated at 2022-06-23 13:23:32.051442
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=DataLoader(), sources=['tests/units/vars/ansibleJ2Vars_test'])
    inventory.set_playbook_basedir('tests/units/vars')
    hosts = inventory.get_hosts()
    groups = inventory.get_groups()
    groups = [Group(name=g.name, hosts=[hosts[0]], vars=g.vars) for g in groups]


# Generated at 2022-06-23 13:23:42.557020
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    print ("===> test_AnsibleJ2Vars___len__()")
    import os
    import ansible.template
    import ansible.vars
    import jinja2

    class FakeVars:
        def __getitem__(self, k):
            return "abc"

    fake_vars = FakeVars()
    fake_vars_loader = ansible.vars.VarsModule()
    fake_vars_loader.get_vars(play=None, task=None, host=None, include_hostvars=False)


# Generated at 2022-06-23 13:23:54.293581
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    templar = Templar(loader=None)
    globals = {'a': 'A'}
    locals = {'a': UnsafeProxy('aa'), 'b': 'B', 'c': UnsafeProxy('cc')}
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)

    my_locals = {'b': UnsafeProxy('bb'), 'd': 'D'}
    my_ansible_vars = ansible_vars.add_locals(my_locals)

    # check that original ansible_vars not changed
    assert(my_ansible_vars is not ansible_vars)

# Generated at 2022-06-23 13:23:54.959122
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass


# Generated at 2022-06-23 13:24:03.610901
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    locals = {'test1': 'value1', 'test2': 'value2'}
    globals = {'test3': 'value3', 'test4': 'value4'}

    templar = Templar(loader=None)
    templar._available_variables = {'test5': 'value5', 'test6': 'value6'}
    templar._vars_cache = {}

    test_obj = AnsibleJ2Vars(templar, globals, locals)

    assert sorted(list(test_obj)) == ['test1', 'test2', 'test3', 'test4', 'test5', 'test6']


# Generated at 2022-06-23 13:24:13.474420
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.module_utils.common.collections
    from ansible.template import Templar

    test_obj = AnsibleJ2Vars(
        templar=Templar(
            loader=None,
            variables={
                'foo': 'bar'
            }
        ),
        globals={
            'baz': 'qux'
        },
        locals={
            'l_blah': 'blah'
        }
    )

    assert 'foo' in test_obj
    assert 'bar' not in test_obj
    assert 'baz' in test_obj
    assert 'qux' not in test_obj
    assert 'blah' in test_obj
    assert 'l_blah' not in test_obj



# Generated at 2022-06-23 13:24:26.543399
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import ansible.template
    from ansible.module_utils._text import to_text

    templar = ansible.template.AnsibleTemplar()

    m = AnsibleJ2Vars(templar, { 'item' : 'global' }, { 'l_item' : 'local' })

    assert m['item'] == 'global'
    assert m['l_item'] == 'local'

    try:
        m['not_found']
        assert False
    except KeyError as e:
        assert to_text(e) == 'undefined variable: not_found'

    assert len(m) == 2
    assert set(iter(m)) == set(['item', 'l_item'])
    assert set(m.keys()) == set(['item', 'l_item'])

# Generated at 2022-06-23 13:24:36.925846
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # 1.
    #   - correct var_name
    #   - var_name in _templar.available_variables
    #   - var is not a dict
    #   - variable is not a list
    #   - variable is not a string
    #   - variable is not an AnsibleUnsafeText
    #   - variable is not an AnsibleUnsafeText
    #   - variable is not an AnsibleUnsafeText
    #   - variable is not an AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    class Templar():
        def __init__(self, available_variables, template):
            self.available_variables = available_variables
            self.template = template
    class AnsibleUnsafeText():
        def __init__(self):
            pass

# Generated at 2022-06-23 13:24:44.714647
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    def run_test(locals, expected):
        templar = object()
        globals = {}
        j2vars = AnsibleJ2Vars(templar, globals, locals=locals)
        j2vars2 = j2vars.add_locals(j2vars)
        assert j2vars2 != j2vars
        assert len(j2vars2._locals) == len(expected)
        for k, v in iteritems(expected):
            assert j2vars2._locals[k] == v
    run_test(locals={}, expected={})
    run_test(locals={'a' : 1}, expected={'a' : 1})

# Generated at 2022-06-23 13:24:55.303069
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    vars_manager = VariableManager()

    templar = Templar(loader=None, variables=vars_manager)

    test_vars = {'var1': 'value1', 'var2': 'value2'}

    ansible_vars_with_locals = AnsibleJ2Vars(templar, test_vars, locals=test_vars)

    assert ansible_vars_with_locals['var1'] == 'value1'

    locals_with_new_var = {'var3': 'value3'}

    ansible_vars_with_new_locals = ansible_vars_with_locals.add_locals(locals_with_new_var)

    assert ansible_

# Generated at 2022-06-23 13:25:03.973429
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class fake_templar(object):
        def __init__(self):
            self.available_variables = {
                'k1': 'v1',
                'k2': 'v2',
            }

        def template(self, v):
            return v

    globals = {
        'k1': 'g1',
        'k2': 'g2',
        'k3': 'g3',
    }

    locals = {
        'k1': 'l1',
        'k2': 'l2',
    }

    ajv = AnsibleJ2Vars(fake_templar(), globals, locals=locals)

    if 'k1' not in ajv:
        raise AssertionError('Failed to check if key exists in AnsibleJ2Vars')

# Generated at 2022-06-23 13:25:15.094117
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.hostvars import HostVars
    from jinja2.utils import missing

    host_vars = HostVars()

    templar = object()
    globals = {'test_global' : object()}
    locals = {'test_local' : object()}
    ansible_var = {'test_ansible' : object()}
    host_vars.add_host('test_host')
    host_vars.set('test_host', 'test_host_var', object())

    assert AnsibleJ2Vars(templar, globals, locals).__len__() == 3
    assert AnsibleJ2Vars(templar, globals, locals=None).__len__() == 1

# Generated at 2022-06-23 13:25:22.154697
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.vars.hostvars
    import ansible.template.safe_eval
    import ansible.template.templar
    hostvars = ansible.vars.hostvars.HostVars()
    safe_eval = ansible.template.safe_eval.SafeEval(vars={})
    templar = ansible.template.templar.Templar(loader=None, variables={}, shared_loader_obj=None, 
                                               searchpath=[], basedir=None, vault_password=None)
    templar._available_variables = {'vars': hostvars, 'inventory_hostname': 'ny-web-01', 'foo': 'bar'}
    templar._safe_eval = safe_eval
    templar._fail_on_undefined = False
   

# Generated at 2022-06-23 13:25:26.939941
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    locals_ = dict(a=1)
    t = Templar(loader=None, variables=dict(a=1))
    v = AnsibleJ2Vars(templar=t, globals=dict(a=1), locals=locals_)
    assert len(v) == 3

# Generated at 2022-06-23 13:25:30.943077
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    locals = {'foo':'bar'}
    proxy = AnsibleJ2Vars(None, None)
    new_proxy = proxy.add_locals(locals)
    assert new_proxy._locals['foo'] == 'bar'

# Generated at 2022-06-23 13:25:37.336948
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.unicode import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    hosts = [Host(), Host()]
    groups = [Group('all')]
    groups[0].add_host(hosts[0])
    groups[0].add_host(hosts[1])
    variables = {
        'string': 'foo',
        'dict': { 'a': 1, 'b': 2 },
    }
    variables1 = {
        'new_var': 'bar',
    }
    variables

# Generated at 2022-06-23 13:25:45.448914
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.play_context import PlayContext
    class Templar:
        def __init__(self):
            self.available_variables = {}
    play_context = PlayContext()
    play_context.variable_manager.extra_vars = dict(a='test', b='test1')
    play_context.variable_manager.hostvars = dict(a='test2', c='test3')
    j2vars = AnsibleJ2Vars(Templar(), dict(d='test4')).add_locals(dict(e='test5'))
    assert j2vars['a'] == 'test'
    assert j2vars['b'] == 'test1'
    assert j2vars['c'] == 'test3'
    assert j2vars['d'] == 'test4'


# Generated at 2022-06-23 13:25:53.942854
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class TestAnsibleJ2Vars__contains__:
        def __init__(self):
            self.available_variables = {'a': 1, 'd': 4}
    templar = TestAnsibleJ2Vars__contains__()
    globals = {'b': 2, 'e': 5}
    locals = {'c': 3, 'f': 6}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'b' in vars
    assert 'e' in vars
    assert 'c' in vars
    assert 'f' in vars
    assert 'a' in vars
    assert 'd' in vars
    assert 'g' not in vars


# Generated at 2022-06-23 13:25:56.042286
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass


# Generated at 2022-06-23 13:26:07.574087
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    t = Templar(None)
    aj2v = AnsibleJ2Vars(t, {"foo": "bar", "baz": "boo"})
    assert aj2v["foo"] == "bar"
    assert aj2v["baz"] == "boo"

    tv = True
    assert aj2v.add_locals({"l_tv": tv})["tv"] == True

    hv = HostVars({"foo": "bar"})
    assert aj2v.add_locals({"l_hv": hv})["hv"] == hv

# Generated at 2022-06-23 13:26:19.212870
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.manager import VariableManager
    from ansible.template.safe_eval import safe_eval
    import jinja2
    import mock
    import pytest

    # FIXME: the UnsafeProxy class has no __contains__ method.
    #        patch it with a dummy version
    UnsafeProxy.__contains__ = lambda *_, **__: None
    UnsafeProxy.__iter__ = lambda *_, **__: None
    UnsafeProxy.__len__ = lambda *_, **__: None


# Generated at 2022-06-23 13:26:24.848248
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.templating import Templar
    templar = Templar(loader=None, variables={'foo': 'bar'}, shared_loader_obj=None)
    assert len(AnsibleJ2Vars(templar, {})) == 1
    assert len(AnsibleJ2Vars(templar, {'bar': 'baz'})) == 2
    assert len(AnsibleJ2Vars(templar, {'foo': 'bar'})) == 1
    assert len(AnsibleJ2Vars(templar, {'foo': 'baz'})) == 1
    assert len(AnsibleJ2Vars(templar, {}, {'foo': 'baz'})) == 2


# Generated at 2022-06-23 13:26:32.039076
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar

    a = AnsibleJ2Vars(Templar({}), {'a': 'b'})
    assert a['a'] == 'b'

    # Check that we are delegating the name resolution to
    # the Templar class (i.e. `available_variables`).
    # We setup a Templar that returns a value when
    # looking up 'c' as a variable.
    b = AnsibleJ2Vars(Templar({'c': 'b'}), {})
    assert b['c'] == 'b'

    # If we don't return a value for 'c', we should
    # get a KeyError
    c = AnsibleJ2Vars(Templar({}), {})

# Generated at 2022-06-23 13:26:39.840984
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    templar = Templar(loader=None)
    a = AnsibleJ2Vars(templar, {}, {})

    a["123"] = AnsibleUnicode("123")
    a["234"] = 234
    a["345"] = AnsibleUnicode("345")

    a = AnsibleJ2Vars(templar, {"456": 456})

    assert sorted(list(a)) == ["123", "234", "345", "456"]

    b = AnsibleJ2Vars(templar, {"456": 456}, {"234": 234})

    assert sorted(list(b)) == ["123", "234", "345", "456"]



# Generated at 2022-06-23 13:26:50.978082
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    # Test: get variable from available_variables
    templar = Templar(loader=None)
    templar._available_variables = {'a':'A'}
    var_proxy = AnsibleJ2Vars(templar, {}, {})
    assert var_proxy['a'] == 'A'
    # Test: get variable from globals
    var_proxy = AnsibleJ2Vars(templar, {'b':'B'}, {})
    assert var_proxy['b'] == 'B'
    # Test: get variable from locals
    var_proxy = AnsibleJ2Vars(templar, {}, {'c':'C'})

# Generated at 2022-06-23 13:27:02.647578
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # noinspection PyUnusedLocal,PyPep8
    class Templar():
        def __init__(self, *args, **kwargs):
            self.available_variables = dict()

        def template(self, *args, **kwargs):
            raise Exception("should not be called")

    # The empty dict is the locals here
    vars = AnsibleJ2Vars(Templar(), {}, {})
    assert len(vars) == 0

    # The dict is the locals here
    vars = AnsibleJ2Vars(Templar(), {}, dict(a=1, b=2))
    assert len(vars) == 2
    assert vars['a'] == 1
    assert vars['b'] == 2
    assert 'c' not in vars

    # The dict is the locals here
    v

# Generated at 2022-06-23 13:27:13.471100
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    test with locals None
    '''
    class MyAnsibleJ2Vars(AnsibleJ2Vars):
        def __init__(self):
            super(MyAnsibleJ2Vars, self).__init__(self, self, self)
    instance = MyAnsibleJ2Vars()
    new_locals = {'a':'b'}
    instance_new = instance.add_locals(new_locals)

# Generated at 2022-06-23 13:27:23.678134
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Create 2 AnsibleVars objects
    import jinja2
    # jinja2.environment.Environment object
    j2_env = jinja2.SandboxedEnvironment()
    # ansible.template.AnsibleEnvironment object
    a_env = j2_env
    # ansible.template.Template object
    t_template = j2_env.from_string('{{foo}} is {{bar}}')
    # ansible.template.AnsibleTemplate object
    a_template = t_template
    # ansible.vars.manager.VariableManager object
    v_mgr = ansible.vars.manager.VariableManager()
    # templar.Templar object

# Generated at 2022-06-23 13:27:30.284262
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 13:27:37.812465
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import safe_eval

    templar = safe_eval.construct_python_object("Template")
    vars = AnsibleJ2Vars(templar, {}, locals={'key1': 'val1', 'key2': 'val2'})
    new_vars = vars.add_locals({'key2': 'val2_2', 'key3': 'val3'})
    assert new_vars['key1'] == 'val1'
    assert new_vars['key2'] == 'val2_2'
    assert new_vars['key3'] == 'val3'

# Generated at 2022-06-23 13:27:47.611701
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from jinja2.environment import Environment
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    inject = dict(my_host=dict(k1='v1'))
    j2_env = Environment()
    templar = Templar(loader=None, variables=combine_vars(loader=None, inject=inject))
    ansible_j2vars = AnsibleJ2Vars(templar, {}, {})

    assert "my_host" in ansible_j2vars
    assert "k1" in ansible_j2vars

    # __contains__ will return False for variables,
    #  but will raise an exception if you try to get them as items (__getitem__)

# Generated at 2022-06-23 13:27:52.639772
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import ansible.vars.hostvars as hostvars
    var_hostvars = hostvars.HostVars(dict(foo=1), 'foo_host')
    test_vars = dict(foo='a', bar='b', l_baz='c', hosted=var_hostvars)

    class test_templar():
        def __init__(self, vars):
            self.available_variables = vars

        def template(self, varname):
            return self.available_variables[varname]

    # Mock up jinja2 globals
    test_globals = dict(jinja2_globals=1)
    
    # Mock up jinja2 locals
    test_locals = dict(jinja2_locals=2)

    # Construct AnsibleJ2

# Generated at 2022-06-23 13:27:57.670142
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Make dummy Templar()
    class Templar(object):
        available_variables = {
            # Dummy variables for this test
            'foo': 1,
            'bar': 2,
            'baz': 3,
            'qux': 4
        }

        def __init__(self):
            return

        def template(self, src):
            return src

    # Make dummy locals()
    locals = {
        # Dummy variables for this test
        'three': 3,
        'four': 4,
    }

    # Make dummy globals()
    globals = {
        # Dummy variables for this test
        'five': 5,
        'six': 6,
    }

    # Make dummy AnsibleJ2Vars()

# Generated at 2022-06-23 13:28:07.716836
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.unsafe_proxy import UnsafeProxy

    env = []
    locals = []
    g = dict()
    g['test_global_var'] = 'test_global_var_value'

    t = AnsibleJ2Vars(env, g, locals)
    res_1 = 'test_global_var_value'
    res_2 = t['test_global_var']
    assert res_1 == res_2

    locals = {'test_local_var': 'test_local_var_value'}

    t = AnsibleJ2Vars(env, g, locals)
    res_1 = 'test_local_var_value'
    res_2 = t['test_local_var']
    assert res_1 == res_2

    # test if var value is UnsafeProxy
   

# Generated at 2022-06-23 13:28:14.813820
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict(a=1, b=2, c=3)
    locals = dict(d=4, e=5, f=6, l_g=6, l_h=8)
    vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert len(vars) == 8

# Generated at 2022-06-23 13:28:28.250528
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('tests/unit/inventory_for_varname_testing'))
    variable_manager._extra_vars = {'foo': 'bar'}

    templar = Templar(loader=loader, variable_manager=variable_manager)

    mytest = AnsibleJ2Vars(templar=templar, globals=None, locals=None)
    assert 'hostvars' in mytest
    assert 'inventory_hostname' in mytest
    assert 'foo' in mytest
    assert 'json_query' in mytest

# Generated at 2022-06-23 13:28:39.737903
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Test the method of __contains__ in AnsibleJ2Vars.
    
    :return:
    '''
    from ansible.template import Templar
    
    templar = Templar(loader=None)
    ansible_vars = AnsibleJ2Vars(templar, {})
    
    templar.set_available_variables({"varname" : "data"})
    assert ansible_vars.__contains__("varname") == True
    
    templar.set_available_variables({"varname1" : "data1"})
    assert ansible_vars.__contains__("varname") == True
    assert ansible_vars.__contains__("varname1") == True
    
    assert ansible_vars

# Generated at 2022-06-23 13:28:41.873659
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    aj2v = AnsibleJ2Vars()
    assert aj2v.__contains__('anykey') == False


# Generated at 2022-06-23 13:28:53.375376
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Create a set of variables, two of them refer to a class object and
    # a dictionary. These two variables use the non-default values for the
    # last two constructor arguments.
    templar = None
    globals_vars = {'foo': 1, 'bar': [1, 2], 'baz': {'a': 'b'}}
    locals_vars = {'foo': 3, 'bar': [1, 2], 'baz': {'a': 'b'}}

    # Create the variable class and get the local variables 'foo' and 'bar'.
    av = AnsibleJ2Vars(templar, globals_vars, locals_vars)
    foo = av.get('foo')
    bar = av.get('bar')
    baz = av.get('baz')
    xxx = av

# Generated at 2022-06-23 13:29:05.017874
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Required for AnsibleContext class
    from ansible.inventory.manager import InventoryManager

    t = Templar(VariableManager(), loader=None)

    globals_ = {}
    locals_ = {}

    ajv = AnsibleJ2Vars(t, globals_, locals_)

    globals_.update({'test_var': 1})
    locals_.update({'test_var_2': 2})
    t.set_available_variables(t.template('test_var'))

    assert list(ajv) == ['test_var', 'test_var_2']

    # Should also work if __contains__ returns True
    assert list(ajv) == ['test_var', 'test_var_2']

    # Try an

# Generated at 2022-06-23 13:29:09.989100
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict(a=1)
    locals = dict(b=2)
    mapping = AnsibleJ2Vars(templar, globals, locals)
    assert mapping['a'] == 1 and mapping['b'] == 2

# Generated at 2022-06-23 13:29:16.821228
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # FIXME: add test code

    # current configuration: TODO: change for your environment
    templar = None
    globals = None

    # construction of object
    obj = AnsibleJ2Vars(templar, globals)

    # TODO: check correct construction

    # end
    print('Info: test_AnsibleJ2Vars(): succeed')

# Run unit test
if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-23 13:29:26.921166
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ansible_vars = {'a': 'b', 'x': 'y'}
    j2_vars = AnsibleJ2Vars(None, ansible_vars)
    # test __contains__
    assert 'a' in j2_vars
    assert 'x' in j2_vars
    # test __getitem__
    assert j2_vars['a'] == 'b'
    assert j2_vars['x'] == 'y'
    # test __iter__
    for var in iter(j2_vars):
        assert var in ['a', 'x'], 'unexpected var in iter(j2_vars): %s' % var
    # test __len__
    assert len(j2_vars) == 2, 'unexpected len(j2_vars)'

# Generated at 2022-06-23 13:29:37.248436
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    j2vars = AnsibleJ2Vars([], {}, {'l_A': 'B', 'A': 'x'})
    # l_A should return B because it is a local var
    assert j2vars['l_A'] == 'B'
    # A should not exist in globals and should not be a local var
    assert j2vars['A'] == 'x'
    # B should not exist in globals and should not be a local var
    with pytest.raises(KeyError):
        j2vars['B']
    # C should not exist in globals and should not be a local var
    with pytest.raises(KeyError):
        j2v

# Generated at 2022-06-23 13:29:45.315247
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None, variables={})
    ajv = AnsibleJ2Vars(templar, globals={'foo': 'bar'}, locals={'leo': 42})
    variables = {'golf': 'echo', 'hotel': 'delta'}
    variables.update(ajv)
    assert variables['foo'] == 'bar'
    assert variables['leo'] == 42
    assert variables['golf'] == 'echo'
    assert variables['hotel'] == 'delta'

# Generated at 2022-06-23 13:29:56.975698
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # mock objects
    templar = MockTemplar()
    globals = {}
    locals = {}

    # start test
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2vars._locals == {}
    locals_to_add = {'a': 'b'}
    ansible_j2vars2 = ansible_j2vars.add_locals(locals_to_add)
    assert ansible_j2vars2._locals == locals_to_add
    locals_to_add = {'c': 'd'}
    ansible_j2vars3 = ansible_j2vars2.add_locals(locals_to_add)

# Generated at 2022-06-23 13:30:07.344792
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    print("in test_AnsibleJ2Vars___iter__ ...")
    # Set the AnsibleJ2Vars class' tracer
    set_trace()
    # Get the AnsibleJ2Vars' class
    AnsibleJ2Vars_cls = AnsibleJ2Vars
    # Create a new object from the AnsibleJ2Vars class
    AnsibleJ2Vars_obj = AnsibleJ2Vars_cls(None, None, None)
    # Iterate the AnsibleJ2Vars object
    for i in AnsibleJ2Vars_obj:
        print(i)
    

# Generated at 2022-06-23 13:30:16.206517
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    t = Templar(loader=None)
    ajv = AnsibleJ2Vars(t, {'bogus_global' : 'should not see this'}, locals={'locals_var' : 'locals_value'})
    ajv2 = ajv.add_locals({'second_locals_var' : 'second_locals_val'})
    assert 'locals_var' in ajv2
    assert 'second_locals_var' in ajv2


# Generated at 2022-06-23 13:30:24.293366
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Create mock object
    class MockTemplar():
        __slots__ = ()
        def __init__(self, *args, **kwargs):
            pass
    mock_templar = MockTemplar()

    # Set global variables
    mock_globals = dict()
    mock_globals['test_globals'] = 'test_globals'

    # Create object
    ansible_j2vars = AnsibleJ2Vars(templar=mock_templar, globals=mock_globals)

    # Check getter method
    assert 'test_globals' in ansible_j2vars

# Generated at 2022-06-23 13:30:34.941857
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Dummy class to make the test work without Templar object
    class DummyTemplar():
        pass

    # Test values to the variables
    dummy_templar_object = DummyTemplar()
    globals_input = {}
    locals_input = {'test_key1': 'test value 1', 'test_key2': 'test value 2'}

    # Construct the AnsibleJ2Vars object
    ansible_j2_vars = AnsibleJ2Vars(dummy_templar_object, globals_input)

    # Call the method to be tested
    new_ansible_j2_vars = ansible_j2_vars.add_locals(locals_input)

    # Check the results

# Generated at 2022-06-23 13:30:45.513837
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = VariableManager()
    hostvars = HostVars(loader=loader, inventory=inventory)

    templar = Templar(loader=loader, variables=inventory.get_vars(host=None))


# Generated at 2022-06-23 13:30:49.550501
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'a': 1}
    v = AnsibleJ2Vars(templar, globals, locals={})
    assert len(v) == 1



# Generated at 2022-06-23 13:31:00.099181
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    Tests the initialization of AnsibleJ2Vars class.
    '''

    # check for valid templar value
    t = AnsibleJ2Vars(templar=None, globals={})
    assert t is not None
    assert t._templar is None

    # check for valid globals value
    t = AnsibleJ2Vars(None, globals=None)
    assert t is not None
    assert t._globals is None

    # check for valid locals value
    t = AnsibleJ2Vars(None, None, locals=None)
    assert t is not None
    assert t._locals is None

# Generated at 2022-06-23 13:31:09.957427
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    var_manager = VariableManager()
    var_manager.extra_vars = dict(e='E')

    t = Templar(loader=loader, variables=var_manager)
    av = t.available_variables
    g = dict(g='G')
    vars = AnsibleJ2Vars(t, g)

    assert 'e' in vars
    assert 'g' in vars

    assert 'l_e' not in vars
    assert 'l_g' not in vars

    play_context = PlayContext()

# Generated at 2022-06-23 13:31:18.444734
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    try:
        from jinja2 import Environment, StrictUndefined
    except ImportError:
        return
    a = AnsibleJ2Vars(Environment(undefined=StrictUndefined), globals={'VARIABLE': 'variable'}, locals={'LOCAL': 'local', 'l_NESTED': {'a': '1', 'b': '2'}})
    b = set(['VARIABLE', 'LOCAL', 'NESTED'])
    assert set(iter(a)) == b, '__iter__() should return all keys of the ansible variables'

# Generated at 2022-06-23 13:31:23.127284
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.vars import Templar
    locals = dict(a='A', b='B')
    global_vars = dict(c='C')
    var_proxy = AnsibleJ2Vars(Templar(), global_vars, locals=locals)
    new_locals = dict(z='Z')
    new_var_proxy = var_proxy.add_locals(new_locals)

    assert isinstance(new_var_proxy, AnsibleJ2Vars)
    assert isinstance(new_var_proxy._globals, dict)
    assert isinstance(new_var_proxy._locals, dict)
    assert new_var_proxy._globals == var_proxy._globals

# Generated at 2022-06-23 13:31:30.266100
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class VariableManager:
        def __init__(self, variables=None):
            self.available_variables = variables or dict()

    class PlayContext:
        def __init__(self, variables=None):
            self.vars = variables

    class Host:
        def __init__(self, variables=None):
            self.vars = variables

    class Bunch:
        def __init__(self, adict):
            self.__dict__.update(adict)

    host0 = Host({'a': 1})
    host1 = Host({'a': 2})
    play_context = PlayContext({'b': 1})
    inventory = Bunch({'get_hosts': lambda pattern: [host0, host1]})
    variable_manager = VariableManager({'foo': 'bar', 'c': 3})
   

# Generated at 2022-06-23 13:31:40.695143
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import AnsibleVars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    vault_lib = VaultLib([])
    templar = vault_lib

    ans_vars = AnsibleVars(templar, vault_lib, [])
    templar.set_available_variables(ans_vars)

    ans_j2_vars = AnsibleJ2Vars(templar, {}, locals={})
    assert(len(ans_j2_vars) == 0)
    assert(not ans_j2_vars.__contains__('This_var_does_not_exist'))

# Generated at 2022-06-23 13:31:48.703975
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template.safe_eval import ansible_safe_eval

    # Extract variables for test case
    fake_template_name = 'fake_template_name'

    # Prepare test case data and mock
    var_value_eval = ansible_safe_eval('{\'key1\': 1, \'key2\': [\'a\', \'b\']}')
    var_vars = {'key1': 'val1', 'key2': AnsibleVaultEncryptedUnicode('val2'), 'key3': 3, 'key4': 4}
    var_globals = {}
    var_locals = {}

    # Execute test case
    test_obj = AnsibleJ2V

# Generated at 2022-06-23 13:31:59.467433
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template.test.test_vars import MockTemplar
    from ansible.template.test.test_vars import MockVars
    templar = MockTemplar(vars=MockVars())

# Generated at 2022-06-23 13:32:03.728299
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'foo': 'bar'})

    x = AnsibleJ2Vars(templar, {}, {})

    assert(len(x)) == 1



# Generated at 2022-06-23 13:32:10.188241
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.compat.tests import unittest

    from ansible.template import Templar

    class TestAnsibleJ2Vars(unittest.TestCase):

        def setUp(self):
            self.templar = Templar(loader=None, variables={'var1': 'foo', 'var2': 'bar'})
            self.globals = {'global1': 'foo', 'global2': 'bar'}
            self.locals = {'local1': 'foo', 'local2': 'bar'}

        def test_AnsibleJ2Vars___len__(self):
            vars = AnsibleJ2Vars(self.templar, self.globals, locals=self.locals)


# Generated at 2022-06-23 13:32:21.282932
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    # Create Templar object with fake modules
    templar = Templar(loader=None, variables={})

    # Create AnsibleJ2Vars object
    ansible_vars = AnsibleJ2Vars(templar, None, None)

    # Test method __len__(), where variables are empty
    assert len(ansible_vars.__len__()) == 0

    # Test method __len__(), where variables include single entry
    templar = Templar(loader=None, variables={"var1": "var1"})
    ansible_vars = AnsibleJ2Vars(templar, None, None)
    assert len(ansible_vars.__len__()) == 1

    # Test method __len__(), where variables include multiple entries

# Generated at 2022-06-23 13:32:31.736466
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class Templar:
        '''
        A mock class to replace the real Templar class of Ansible
        '''
        def __init__(self, available_variables):
            self.available_variables = available_variables

        def template(self, template):
            return template

    class HostVars(dict):
        '''
        A mock class to replace the real HostVars class of Ansible
        '''
        def __init__(self, **kwargs):
            super(HostVars, self).__init__(**kwargs)

    vars_dict_1 = HostVars(foo=1, bar=2)
    vars_dict_2 = HostVars(foo=2, bar=3)
    locals = dict(l_baz=3)

    # There are two dicts l_ and vars_

# Generated at 2022-06-23 13:32:42.740400
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = None
    locals = {'l_x': 3, 'l_y': 4}
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert 'x' not in ansible_j2vars
    assert 'l_x' not in ansible_j2vars
    assert 'y' not in ansible_j2vars
    assert 'l_y' not in ansible_j2vars
    locals['x'] = 3
    locals['y'] = 4
    ansible_j2vars = ansible_j2v

# Generated at 2022-06-23 13:32:50.091546
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class Templar(object):

        def __init__(self, templar):
            self._templar = templar

        def template(self, data):
            return self._templar.template(data)

        @property
        def available_variables(self):
            return {'vars': 1}

    class Jinja2Module(object):

        def __init__(self, text):
            self.text = text

        def template(self, value):
            assert type(value) is str
            assert value == "vars"
            return self.text

    templar = Templar(Jinja2Module(2))
    ansible_j2vars = AnsibleJ2Vars(templar, {}, {})

    assert ansible_j2vars['vars'] == 2

# Generated at 2022-06-23 13:32:55.471393
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    j2_vars = AnsibleJ2Vars(None, {'key1': 'val1', 'key2': 'val2'}, locals={'key3': 'val3'})
    assert set(['key1', 'key2', 'key3']) == set(j2_vars.__iter__())
