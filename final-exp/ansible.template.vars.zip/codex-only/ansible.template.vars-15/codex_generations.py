

# Generated at 2022-06-23 13:22:58.609907
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader, variables={'test_AnsibleJ2Vars___iter__': 42})
    play_context = PlayContext()

    proxy = AnsibleJ2Vars(templar, {})

    assert iter(proxy)

    found = False
    for var in proxy:
        if var == 'test_AnsibleJ2Vars___iter__':
            found = True

    assert found == True


# Generated at 2022-06-23 13:23:01.073996
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
  a = AnsibleJ2Vars();


if __name__ == '__main__':
  test_AnsibleJ2Vars()

# Generated at 2022-06-23 13:23:11.631756
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    # test_templar1
    test_vars = {'a':'foo', 'b': 'bar', 'c':'koo'}
    test_globals = {'baz':'zab'}
    test_templar1 = jinja2.Environment().from_string('var={{a}}').template
    test_templar1.vars = test_vars
    test_templar1.available_variables = test_vars

    # test_templar2
    test_locals = {'baz':'bam'}
    test_templar2 = jinja2.Environment().from_string('var={{baz}}').template
    test_templar2.vars = test_locals
    test_templar

# Generated at 2022-06-23 13:23:21.492382
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    t = Templar()

    # test that we can also instantiate AnsibleJ2Vars without globals or locals
    v = AnsibleJ2Vars(t, globals=None, locals=None)

    # test that we can instantiate AnsibleJ2Vars with globals
    g = {"k1": "g1"}
    v = AnsibleJ2Vars(t, globals=g, locals=None)
    assert "k1" in v
    assert v["k1"] == "g1"

    # test that we can instantiate AnsibleJ2Vars with locals
    l = {"k1": "l1"}

# Generated at 2022-06-23 13:23:32.090854
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    class Templar(object):
        def __init__(self, vars):
            self.available_variables = vars

    templar = Templar(vars= {'a': 1, 'b': 2})

    globals = {'a': 11, 'b':12}

    class A(object):
        def __UNSAFE__(self):
            return True

    locals = {'a': 21, 'b':22, 'context': 23, 'environment': 24, 'template': 25, 'vars': A()}

    # test case 1
    locals_new = {'a': 31, 'b': 32, 'c': 33, 'd': 34}

    a = AnsibleJ2Vars(templar, globals, locals)

    # test

# Generated at 2022-06-23 13:23:42.611305
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    import os

    # setup
    class Templar():
        def __init__(self, available_variables):
            self._available_variables = available_variables

        @property
        def available_variables(self):
            return self._available_variables

        def template(self, variable):
            return variable

    templar = Templar(dict(AVAILABLE_VARIABLES='foo'))
    locals = dict(LOCAL_VARIABLE='bar')
    globals = dict(GLOBAL_VARIABLE='baz')

    # test
    j2_vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)

    # assertion
    assert 'AVAILABLE_VARIABLES' in j2_vars


# Generated at 2022-06-23 13:23:54.293611
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.hostvars import HostVars

    j2vars = AnsibleJ2Vars('templar', {'my_global': 'my_global_val'}, {'l_my_local': 'my_local_val'})
    assert(j2vars['my_global'] == 'my_global_val')
    assert(j2vars['l_my_local'] == 'my_local_val')

    # Test that locals with locals
    j2vars2 = j2vars.add_locals({'l_my_local': 'local_val_in_locals'})
    assert (j2vars2['my_global'] == 'my_global_val')

# Generated at 2022-06-23 13:24:01.407336
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost', 'notlocalhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = {}
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    tqm = None
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play))

# Generated at 2022-06-23 13:24:12.110418
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import sys
    import unittest

    class AnsibleJ2VarsTests(unittest.TestCase):
        """unit tests for AnsibleJ2Vars"""
        templar = None
        globals = None
        locals = None
        obj = None

        def setUp(self):
            from ansible.template import Templar
            from ansible.vars import VariableManager
            from ansible.inventory import Inventory

            variable_manager = VariableManager()
            inventory = Inventory(variable_manager)
            variable_manager.set_inventory(inventory)

            self.templar = Templar(None, variable_manager)
            self.globals = dict()
            self.locals = None
            self.obj = AnsibleJ2Vars(self.templar, self.globals, locals=self.locals)



# Generated at 2022-06-23 13:24:18.407438
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    vm = VariableManager()
    vm.set_globals({'global_var': 0})
    vm.set_host_variable('localhost', 'host_var', 0)
    vm.set_variable('local_var', 0)

    templar = Templar(loader=None, variables=vm)

    v = AnsibleJ2Vars(templar, dict())
    assert len(v) == 3

    v = AnsibleJ2Vars(templar, {'global_var': 0})
    assert len(v) == 4

    v = AnsibleJ2Vars(templar, {'global_var': 0}, locals={'local_var': 0})
    assert len(v) == 5



# Generated at 2022-06-23 13:24:20.915574
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    a = AnsibleJ2Vars(None, {'a': 'blah'}, {'b': 'blah'})
    assert len(a) == 2


# Generated at 2022-06-23 13:24:23.397775
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    An unit test cannot be done.
    In order to run it for an AnsibleJ2Vars object, that must be initialized.
    But that's not possible, as AnsibleJ2Vars is an abstract class,
    and cannot be instantiated.
    '''
    assert True

# Generated at 2022-06-23 13:24:31.039995
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader

    def _validate_one_item(item, key_set):
        assert item in key_set

    loader = DataLoader()
    templar = Templar(loader=loader, variables={'foo': 'bar'}, fail_on_undefined=False)

    ajv = AnsibleJ2Vars(templar, dict())

    # get all available keys
    key_set = set()
    for key in ajv:
        key_set.add(key)
    # test if all available keys are in the key set
    for item in templar.available_variables:
        _validate_one_item(item, key_set)

# Generated at 2022-06-23 13:24:40.425296
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.unsafe_proxy import create_unsafe_proxy
    from ansible import constants as C
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 13:24:49.885194
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # Mock templar class for testing
    class Templar:
        def __init__(self, variable_dict, available_variables):
            self.available_variables = available_variables
            self.variable_dict = variable_dict

        def template(self, variable):
            return self.variable_dict[variable]

    # Create test variables
    globals = {'gvar1': 'gval1'}
    locals = {'lvar1': 'lval1'}
    available_variables = {'avar1': 'aval1'}
    variable_dict = {v: k for k, v in available_variables.items()}
    templar = Templar(variable_dict, available_variables)

    # Test the proxy variables

# Generated at 2022-06-23 13:25:00.018225
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)

# Generated at 2022-06-23 13:25:10.284969
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    #mock Templar() class
    class Templar():
        def __init__(self):
            self.available_variables = {'var_1':'var_1'}
    templar = Templar()
    #mock globals
    globals = {'global_1':'global_1'}
    #mock locals
    locals = {'local_1':'local_1'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert sorted(list(j2vars.__iter__())) == sorted(['var_1', 'local_1', 'global_1'])


# Generated at 2022-06-23 13:25:19.745846
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    import ansible.utils.unsafe_proxy as unsafe_proxy
    from ansible.vars.hostvars import HostVars

    j2_vars = AnsibleJ2Vars(templar=None, globals={}, locals={})

    # test 1: varname not in j2_vars
    try:
        j2_vars.__getitem__('varname_not_in_j2_vars')
        assert False, 'should have raised KeyError'
    except KeyError:
        assert True

    # test 2: var_type = str
    varname = 'VARNAME'
    var_value = 'value'


# Generated at 2022-06-23 13:25:24.699354
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = {}
    globals = {}
    locals = {}
    var = AnsibleJ2Vars(templar, globals, locals)
    assert var._templar == templar
    assert var._globals == globals
    assert var._locals == locals


# Generated at 2022-06-23 13:25:35.289272
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    vars = {'foo': {'bar': "42"}}

    local_var_proxy = AnsibleJ2Vars(Templar(loader=DataLoader()), {}, locals=vars).add_locals({})
    assert local_var_proxy['foo']['bar'] == "42"

    play_context = PlayContext()
    local_var_proxy = AnsibleJ2Vars(Templar(loader=DataLoader(), variables=vars, shared_loader_obj=play_context), {}, locals=vars).add_locals({})
    assert local_var_proxy['foo']['bar'] == "42"

# Generated at 2022-06-23 13:25:45.108307
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    # display.debug("Test method __iter__ in class AnsibleJ2Vars")

    from ansible.parsing.vault import VaultLib
    vault_secret = "test_password"
    vault = VaultLib([(vault_secret,)])
    vault_decrypted_file = vault.decrypt("./test_files/vault_vars.yml")

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import get_all_plugin_loaders

    inventory = InventoryManager(loader=get_all_plugin_loaders(), sources=["localhost,"])

# Generated at 2022-06-23 13:25:54.032592
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # create a templar with some variable v2
    from ansible.template import Templar
    templar = Templar(loader=None)
    variable_data = {'v2': 'data v2'}
    templar.set_available_variables(variable_data)

    # create an instance of AnsibleJ2Vars and check that __getitem__
    # works as expected

    # varname not in templar.available_variables
    globals = {'g1': 'g1'}
    locals = {'l1': 'l1'}
    varname = 'v1'
    ajv = AnsibleJ2Vars(templar, globals, locals=locals)
    with pytest.raises(KeyError) as err:
        data = ajv[varname]


# Generated at 2022-06-23 13:26:06.860108
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    # test data
    tmplr = Templar(None)
    j2vars = AnsibleJ2Vars(tmplr, {}, {})

    # test
    with pytest.raises(KeyError) as e_info:
        j2vars['fake']
    assert "undefined variable: fake" in str(e_info)

    j2vars._locals['fake'] = 'fake_str'
    assert j2vars['fake'] == 'fake_str'

    j2vars._glob

# Generated at 2022-06-23 13:26:18.681408
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from jinja2 import StrictUndefined
    import ansible.vars.hostvars
    class ansible_vars_hostvars_HostVars(ansible.vars.hostvars.HostVars):
        pass
    class ansible_vars_hostvars_HostVarsVars(ansible.vars.hostvars.HostVarsVars):
        pass
    class ansible_playbook_play_Play(object):
        pass
    class ansible_inventory_host_Host(object):
        pass

    vars = {'a': 1, 'b': 2}
    locals = {'d': 4, 'e': 5}
    globals = {'f': 6, 'g': 7}
    hostvars = {'h': 8, 'i': 9}
    vars_

# Generated at 2022-06-23 13:26:20.644493
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Can only be tested via integration.
    '''
    pass


# Generated at 2022-06-23 13:26:31.679453
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    ''' Unit test for method __iter__ of class AnsibleJ2Vars '''

    from ansible.template import Templar

    templar = Templar(loader=None, variables={})

    # Create a test class instance
    ansible_vars = AnsibleJ2Vars(templar,
        globals={'a': 'A', 'b': 'B', 'd': 'D'},
        locals={'c': 'C', 'd': 'D', 'l_e': 'E'})

    # Test __iter__ of class AnsibleJ2Vars
    assert set(ansible_vars) == set(['a', 'b', 'c', 'd', 'e'])


# Generated at 2022-06-23 13:26:35.365543
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(None, loader=None, variables={'test_var': 'foo'})
    ansible_j2_vars = AnsibleJ2Vars(templar, {})
    assert ansible_j2_vars['test_var'] == 'foo'

# Generated at 2022-06-23 13:26:41.623992
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 0

    templar.available_variables = dict(k1=1, k2=2)
    assert len(vars) == 2

    globals = dict(k3=3, k4=4)
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 4

    locals = dict(k5=5, k6=6)
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 6



# Generated at 2022-06-23 13:26:51.763592
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class T(object):
        pass
    t = T()
    t.available_variables = 'test_available_variables'
    t.template = lambda x: x
    l = AnsibleJ2Vars(t, 'test_globals', {'x' : 'x'})
    # Empty locals (no change)
    nl = l.add_locals({})
    assert nl._locals == {'x': 'x'}
    assert nl._templar == 'test_available_variables'
    assert nl._globals == 'test_globals'
    # Not empty locals (additional)
    nl = l.add_locals({'y': 'y'})
    assert nl._locals == {'x': 'x', 'y': 'y'}
   

# Generated at 2022-06-23 13:27:03.461629
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import pytest
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible_collections.ansible.community.plugins.loader import vault_manager

    templar = Templar(vault_secrets=[VaultLib()], vault_password_files=[], vault_ids=[], \
                      show_content=False, vault_manager=vault_manager, loader=None)

    globals = {'id': 'test_jar1', 'test1': 'test_test1', 'test2': 'test_test2'}
    locals = {'id': 'test_jar1', 'test3': 'test_test3', 'test4': 'test_test4'}
    var_proxy = AnsibleJ2Vars(templar, globals, locals)

    # test

# Generated at 2022-06-23 13:27:10.006941
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    from ansible.template import Templar

    templar = Templar(loader=None)
    j2_vars = AnsibleJ2Vars(templar, {}, {'l_a':1, 'l_b':2})

    assert j2_vars['a'] == 1
    assert j2_vars['b'] == 2
    assert j2_vars['c'] == 3



# Generated at 2022-06-23 13:27:13.554691
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os
    fixtures_path = os.path.join(os.path.dirname(__file__), 'unit/templating/jinja2/fixtures')
    variables = VariableManager()
    loader = DataLoader()

    templar = Templar(loader=loader, variables=variables)
    fh = open(os.path.join(fixtures_path, 'testvars.yml'), 'rb')
    vars = yaml.load(fh)
    fh.close()
    vp = AnsibleJ2Vars(templar, vars)
    assert len(vp) == 16

# Generated at 2022-06-23 13:27:22.767429
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None, variables={'foo': 'bar'})

    j2_vars = AnsibleJ2Vars(templar, globals={}, locals={'l_whatever': 'whatever'})
    assert 'whatever' in j2_vars
    assert 'l_whatever' not in j2_vars
    assert 'foo' in j2_vars
    assert 'l_foo' not in j2_vars
    assert 'bar' not in j2_vars
    assert 'l_bar' not in j2_vars


# Generated at 2022-06-23 13:27:35.115132
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import re
    from . import jinja2_vars
    from . import jinja2_vars
    from . import jinja2_vars
    from . import jinja2_vars
    from . import jinja2_vars
    from . import jinja2_vars
    from . import jinja2_vars
    from . import jinja2_vars
    from . import jinja2_vars
    from . import jinja2_vars
    from . import jinja2_vars
    from . import jinja2_vars
    from . import jinja2_vars

    j2_vars = jinja2_vars.AnsibleJ2Vars()

# Generated at 2022-06-23 13:27:40.221456
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'apple': 5, 'banana': 3, 'carrot': 12}
    locals = {'apple': 5, 'banana': 3, 'carrot': 12}
    templar.available_variables = {'apple': 5, 'banana': 3, 'carrot': 12}
    ansible_j2_vars_object = AnsibleJ2Vars(templar, globals, locals)
    assert 'apple' in ansible_j2_vars_object
    assert 'banana' in ansible_j2_vars_object
    assert 'carrot' in ansible_j2_vars_object

# Generated at 2022-06-23 13:27:48.713071
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    from ansible.template import Templar
    from ansible.vars import VariableManager

    var_manager = VariableManager()
    var_manager.extra_vars = {'foo': 'bar', 'one': 1, 'answer': 42, 'omg': True}
    var_manager.options_vars = {'baz': 'qux'}

    template_ds = '{{ foo }} {{ baz }}'
    templar = Templar(loader=None, variables=var_manager)

    ajv = AnsibleJ2Vars(templar, dict(), dict())
    templar.set_available_variables(ajv)

# Generated at 2022-06-23 13:27:56.094371
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import assert_expr
    templar = build_templar_mock()
    globals = {
        'value': 80,
        'variable': 'global'
    }
    locals = {
        'variable': 'local'
    }
    # We check that after the call to add_locals, the variable proxy contains the
    # value of 'variable' in locals and that this is equal to 'local',
    # and contains the value of 'value' in globals and that this is equal to 80.
    proxy = AnsibleJ2Vars(templar, globals, locals)
    new_locals = {
        'variable': 'new_local'
    }
    proxy = proxy.add_locals(new_locals)

# Generated at 2022-06-23 13:28:02.657846
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict(globals_var = 'globals',)
    locals = dict(a = 'a')

    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2vars[globals.keys()[0]] == globals.values()[0]
    assert j2vars[locals.keys()[0]] == locals.values()[0]

# Generated at 2022-06-23 13:28:15.420397
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import string_types

    class TestVarsModule(object):
        def get_vars(self, loader, path, entities, cache=True):
            return dict()

    class TestLoader(object):
        def __init__(self):
            self.vars_plugins = {'test': TestVarsModule()}

    def test_data_generator(data_type, data):
        if data_type == 'string':
            yield data
        elif data_type == 'unsafe':
            yield AnsibleUnsafeText(data)
       

# Generated at 2022-06-23 13:28:28.885290
# Unit test for constructor of class AnsibleJ2Vars

# Generated at 2022-06-23 13:28:35.416563
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar()
    test_obj = AnsibleJ2Vars(templar, globals={'a':1,'b':1}, locals={'a':2,'b':2,'c':2})
    expected = 3
    result = len(test_obj)
    assert (result == expected), 'Result: %s, Expected: %s' % (result, expected)

# Generated at 2022-06-23 13:28:44.486048
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ####
    # TODO: still need to add tests for __contains__(self, k) and __iter__(self) methods
    ####
    from ansible.template import Templar
    import ansible.vars.hostvars
    templar = Templar()

    # should create an empty object
    j2_obj = AnsibleJ2Vars(templar, {})
    # __len__
    assert 0 == len(j2_obj)

    # should return the expected object
    j2_obj = AnsibleJ2Vars(templar, {}, {'test':'testtest'})
    # __len__
    assert 1 == len(j2_obj)
    # __getitem__
    test_object = j2_obj['test']
    assert 'testtest' == test_object

   

# Generated at 2022-06-23 13:28:50.672109
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    __len__ should return the number of unique keys from the 3 sources
    """
    templar = object()
    globals = {'global_var': 'value'}
    locals = {'local_var': 'value'}
    vars_ = {'var': 'value'}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    ajv._templar.available_variables = vars_
    assert len(ajv) == 3


# Generated at 2022-06-23 13:28:59.415573
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.templar import Templar

    J2Var = AnsibleJ2Vars(
        Templar(
            loader=None,
            variables={
                'var2': ['a','b','c']
            },
            shared_loader_obj=None,
            finalize=None,
        ),
        globals={
            'test_func': lambda x: x * 2,
            'test_vars': {
                'var3': 'f'
            }
        },
        locals={
            'var1': 'a',
            'l_var1': 'd'
        },
    )
    assert J2Var['var1'] == 'a'
    assert J2Var['var2'] == ['a','b','c']
    assert J2Var['var3'] == 'f'
    assert J

# Generated at 2022-06-23 13:29:11.868633
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    class MockTemplar(Templar):
        '''
        A mock Templar that only implements the required methods
        '''

        def __init__(self):
            pass


# Generated at 2022-06-23 13:29:19.601667
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template.template import Templar

    templar = Templar(loader=None, variables={})
    globals = dict()
    vars = AnsibleJ2Vars(templar, globals)

    assert vars["undefined"] == AnsibleUndefinedVariable
    assert "undefined" in vars

    assert vars["vars"] == dict()
    assert vars["vars"] is not AnsibleUndefinedVariable
    assert "vars" in vars

    vars_dict = {'foo': 'bar'}
    vars = AnsibleJ2Vars(templar, globals, locals=vars_dict)
    assert vars["vars"] == vars_dict
    assert vars["vars"] is not AnsibleUndefined

# Generated at 2022-06-23 13:29:27.875769
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.utils.color import stringc
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import sys
    import random

    # create a dummy templar to pass to the AnsibleJ2Vars object
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=['dummy'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 13:29:29.565735
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass
    # TODO: Implement test


# Generated at 2022-06-23 13:29:38.606612
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2

    # A simple templar object
    templar = jinja2.Template("my {{ var }}")

    # Globals
    globals = {"global": "global"}

    # Locals
    locals = {"local": "local"}

    # Instance
    vars_obj = AnsibleJ2Vars(templar, globals, locals)

    assert isinstance(vars_obj, AnsibleJ2Vars)
    assert isinstance(vars_obj, Mapping)
    assert vars_obj._globals == globals
    assert vars_obj._locals == locals
    assert vars_obj._templar == templar

# Test method __contains__()

# Generated at 2022-06-23 13:29:45.825085
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)
    vars_obj = AnsibleJ2Vars(templar, {})
    keys = set()
    for k in vars_obj:
        keys.add(k)

    assert varname in keys
    assert varname in vars_obj
    assert varname in templar.available_variables

# Generated at 2022-06-23 13:29:57.240281
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(None, None)
    globals = {'g1': 'g1', 'g2': 'g2'}
    locals = {'l1': 'l1', 'l2': 'l2'}
    var_proxy = AnsibleJ2Vars(templar, globals, locals=locals)
    assert var_proxy.__contains__('g1') == True
    assert var_proxy.__contains__('g2') == True
    assert var_proxy.__contains__('g3') == False
    assert var_proxy.__contains__('l1') == True
    assert var_proxy.__contains__('l2') == True
    assert var_proxy.__contains__('l3') == False


# Generated at 2022-06-23 13:30:09.446124
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    import jinja2
    class Temple(object):
        def __init__(self, loader, variable_manager, **kwargs):
            self.available_variables = variable_manager.get_vars()
            self.loader = loader
            self.environment = jinja2.Environment(loader=self.loader)

        def template(self, variable):
            t = self.environment.from_string(variable)
            return t.render(self.available_variables)

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 13:30:20.780242
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    def test_variables(varname, message):
        try:
            AnsibleJ2Vars(templar, globals)
        except Exception as e:
            assert message == e.message
            raise

    templar = Templar({'vars': {}}, None, None)
    globals = {'vars': {}}
    test_variables('unknown', 'undefined variable: unknown')

    templar = Templar({'vars': {}}, None, None)
    globals = {'vars': {}}
    test_variables('vars', 'undefined variable: {{vars}}')

    templar = Templar({'vars': {}}, None, None)
    globals = {'vars': {}}
    test_variables('some_var', 'undefined variable: {{some_var}}')

# Generated at 2022-06-23 13:30:33.417141
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from jinja2 import StrictUndefined
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval

    context = {"v1": "value1", "v2": "value2"}

    t1 = Templar(variables=context, undefined_errors=False, loader=None)

    globals = {"g1": "global1", "g2": "global2"}
    locals = {"l1": "local1", "l2": "local2"}

    aj2v = AnsibleJ2Vars(t1, globals, locals)
    aj2vnew = aj2v.add_locals(locals)

    assert aj2vnew["v1"] == "value1"
    assert aj2vnew["v2"] == "value2"
    assert a

# Generated at 2022-06-23 13:30:41.803156
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    from ansible.template import Templar
    from ansible.module_utils.six.moves import builtins

    globals = {}
    for i in dir(builtins):
        globals[i] = getattr(builtins, i)

    templar = Templar(loader=None)
    vars_proxy = AnsibleJ2Vars(templar, globals)

    assert '__builtin__' in vars_proxy._globals
    assert '__file__' not in vars_proxy._locals
    assert 'vars' not in vars_proxy._locals

# Generated at 2022-06-23 13:30:49.013176
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    j2vars = AnsibleJ2Vars(templar=None, globals={'name': 'dongjoon'}, locals={'age': 30})
    assert 'name' in j2vars
    assert 'age' in j2vars
    assert 'age' not in j2vars._templar.available_variables

if __name__ == '__main__':
    test_AnsibleJ2Vars()

# Generated at 2022-06-23 13:31:01.331049
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.playbook.play import Play
    from ansible.template import Templar

    from ansible.template import inclusive_variable_lookup

    templar = Templar(loader=None, variables={})

    variable_manager = None

    variable_manager = inclusive_variable_lookup(variable_manager)

    play_context = Play()
    play_context._variable_manager = variable_manager

    local_vars = {
        'var1': 'var1',
        'var2': 'var2'
    }

    j2vars = AnsibleJ2Vars(templar, play_context.globals, locals=local_vars)

    # local variables are added to the object
    assert('var1' in j2vars)
    assert('var2' in j2vars)

    # more local

# Generated at 2022-06-23 13:31:09.281216
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import pytest
    from collections import Mapping
    from ansible.vars.hostvars import HostVars

    templar = Templar()
    vars = AnsibleJ2Vars(templar, {}, {})
    with pytest.raises(KeyError):
        vars['foo']
    vars._templar.available_variables = {'foo': 'bar'}
    assert vars['foo'] == 'bar'
    vars._templar.available_variables['foo'] = '{{ baz }}'
    assert vars['foo'] == '{{ baz }}'
    vars._templar.available_variables['baz'] = 'foobar'
    assert vars

# Generated at 2022-06-23 13:31:16.733899
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    tmplar = Templar(None)
    a = AnsibleJ2Vars(tmplar, None, None)
    res = len(a)
    assert(res == 0)

    tmplar.available_variables = {'a':1, 'b':2}
    a._locals = {'a':3, 'c':4}
    a._globals = {'b':5}
    res = len(a)
    assert(res == 5)

# Generated at 2022-06-23 13:31:25.939508
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.templar import Templar

    # This is an instance of class AnsibleJ2Vars
    j2_proxy = AnsibleJ2Vars(Templar(), globals={'foo': 123})

    # When looking for 'foo', return it as-is, without templating.
    # So no need to test
    assert j2_proxy['foo'] == 123

    # The key 'bar' is not found in both _locals and available_variables
    # Then it will raise an error
    try:
        j2_proxy['bar']
    except KeyError as e:
        assert e.args == ("undefined variable: bar",)

# Generated at 2022-06-23 13:31:32.822924
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'foo': 'foo'})

    j2_vars = AnsibleJ2Vars(templar, {}, locals={'bar': 'bar'})
    assert 'foo' in j2_vars
    assert 'bar' in j2_vars
    assert 'baz' not in j2_vars

# Generated at 2022-06-23 13:31:43.293422
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    # Empty vars
    templar = Templar(loader=None)
    ajvars = AnsibleJ2Vars(templar, globals={})

    assert 'foo' not in ajvars

    # Only in globals
    templar = Templar(loader=None)
    ajvars = AnsibleJ2Vars(templar, globals={'foo': 'bar'})

    assert 'foo' in ajvars

    # Only in locals
    templar = Templar(loader=None)
    ajvars = AnsibleJ2Vars(templar, globals={}, locals={'foo': 'bar'})

    assert 'foo' in ajvars

    # Only in available
    templar = Templar(loader=None)
    a

# Generated at 2022-06-23 13:31:49.931054
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    AnsibleJ2Vars unit test
    '''
    from ansible.template import Templar

    templar = Templar(variables=dict())
    # ansible_hostname and ansible_host must be a valid variable in scope,
    # or AnsibleJ2Vars won't initialize
    templar._available_variables = {"ansible_hostname": "127.0.0.1"}
    templar._host_vars = {"127.0.0.1": {"ansible_host": "127.0.0.1"}}

    j2vars = AnsibleJ2Vars(templar, {})

    # A j2vars object with no locals() should return ansible_hostname
    # and ansible_host when queried
    assert 'ansible_hostname' in j

# Generated at 2022-06-23 13:31:54.885495
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)

    j2vars = AnsibleJ2Vars(templar, {'a': 0})
    j2vars.add_locals({'b': 0})

    assert len(j2vars) == 2

# Generated at 2022-06-23 13:32:02.437396
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import os
    import ansible.vars.hostvars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inv)

    local_vars = dict(
        foo = 42,
        bar = dict(
            baz = 2,
        ),
    )
    globals_vars = dict(
        foo = "bar",
    )
    # '__iter__' from class 'AnsibleJ2Vars' does not work with dict, dict => dict should be tested
    # '

# Generated at 2022-06-23 13:32:12.079078
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.templating import Templar

    vars_manager = VariableManager()
    loader = DataLoader()

    hostvars = dict(
        a='a',
        b='b',
    )
    vars_manager.add_host_vars('somehost', hostvars)
    available_vars = dict(
        hostvars=hostvars,
        group_names=['all'],
    )

    templar = Templar(loader=loader, variables=vars_manager)
    globals = {}
    locals = None
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert j2vars['hostvars'] == hostv

# Generated at 2022-06-23 13:32:19.543611
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from unittest.mock import Mock
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    templar = Templar(variables={'foo': {'bar': 'baz'}}, loader=Mock())
    proxy = AnsibleJ2Vars(templar, globals={'x': 'y'})

    assert proxy['foo'] == {'bar': 'baz'}
    assert proxy['x'] == 'y'


# Generated at 2022-06-23 13:32:30.463561
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import pytest
    from ansiblemodule_utils.compat import _module_kwargs, PY2
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from copy import deepcopy
    from ansible.config.manager import ConfigManager
    from jinja2 import Template
    import os
    import sys
    import ansible
    from collections import MutableMapping
    from jinja2 import meta
    import logging
    import yaml
    loader = DataLoader()
    #initialize config
    configManager = ConfigManager()
    configManager.load_configuration_file(os.path.join(ansible.__path__[0],
                                                       'config/ansible.cfg'))

# Generated at 2022-06-23 13:32:41.788458
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    ansible_vars = {}
    ansible_vars['a'] = 1
    ansible_vars['b_int'] = 2
    ansible_vars['b'] = 2
    ansible_vars['c'] = 3
    ansible_vars['d'] = 4
    ansible_vars['e'] = 5
    ansible_vars['f'] = 6
    ansible_vars['g_int'] = 7
    ansible_vars['g'] = 7

    vars_obj = AnsibleJ2Vars(ansible_vars, {}, None)

    ansible_vars_key_list = []
    for key in vars_obj:
        ansible_vars_key_list.append(key)


# Generated at 2022-06-23 13:32:54.335895
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import wrap_var

    global_dict = dict(a='a', b='b', c='c')
    local_dict = dict(b='B', d='D')
    templar = Templar(loader=None)
    templar.available_variables = dict(c='C')

    vars_new = AnsibleJ2Vars(templar, global_dict, local_dict)
    assert len(vars_new) == 4

    templar.available_variables = dict(c=wrap_var(dict(value=[1, 2, 3])))
    vars_new = AnsibleJ2Vars(templar, global_dict, local_dict)
    assert len(vars_new) == 4


# Unit