

# Generated at 2022-06-23 13:22:59.160533
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(None, loader=None)
    data = AnsibleJ2Vars(templar, {}, {})
    data2 = AnsibleJ2Vars(templar, {'foo':'bar'}, {})
    data3 = AnsibleJ2Vars(templar, {'foo':'bar'}, {'foo':'baz'})

    assert not 'foo' in data
    assert 'foo' in data2
    assert 'foo' in data3
    assert data2['foo'] == 'bar'
    assert data3['foo'] == 'baz'

# Generated at 2022-06-23 13:23:10.507889
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from units.mock import patch
    from ansible.playbook.play_context import PlayContext

    templar_mock = create_autospec(Templar)
    templar_mock.available_variables = {"a": 1}

    globals = {}
    locals = None

    with patch.object(AnsibleJ2Vars, '__contains__', return_value=True):
        aj2v = AnsibleJ2Vars(templar_mock, globals)

    # test if method __contains__ of class AnsibleJ2Vars
    # can return True when the key is in templar.available_variables dict
    assert aj2v.__contains__("a")
    globals["a"] = 1
    # test if method __contains__ of class Ansible

# Generated at 2022-06-23 13:23:17.001044
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class TestTemplar(object):
        def __init__(self):
            self.available_variables = {}
        def template(self, variable):
            return None
    t = TestTemplar()
    aj2v = AnsibleJ2Vars( t, {})
    # Test that getitem fails on unset
    try:
        aj2v['foo']
    except KeyError as ke:
        ke_str = str(ke)
        assert ke_str == "'foo'"

# Generated at 2022-06-23 13:23:18.049354
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass



# Generated at 2022-06-23 13:23:28.616652
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableSet
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    templar = Templar(variable_manager=VariableManager(host_list=[Host(name="dummy")]),
                      loader=None, shared_loader_obj=None)
    jvars = AnsibleJ2Vars(templar, dict())
    templar.set_available_variables(hostvars=dict())
    jvars_new = jvars.add_locals(locals=dict(a=1, b=2))
    assert jvars_new['a'] == 1
    assert jvars_new['b'] == 2

    templar.available_variables

# Generated at 2022-06-23 13:23:36.937377
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    # We have to use a real templar and varMgr to test this, because
    # jinja2 actually checks the type of the object in _data, and
    # will raise an exception if it is not a dict (which is what this
    # class is supposed to make it look like).

    class FakeJ2Vars(AnsibleJ2Vars):
        def __init__(self, templar, globals, locals=None):
            super(FakeJ2Vars, self).__init__(templar, globals, locals)


# Generated at 2022-06-23 13:23:44.550369
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import safe_eval

    init_dict_modules = {'_templar': safe_eval(), '_globals': {'var': 'value'}, '_locals': {'var1': 'value1'}}
    result = AnsibleJ2Vars(**init_dict_modules).__len__()
    expected_result = 3
    assert result == expected_result


# Generated at 2022-06-23 13:23:54.787005
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.templating import Templar
    from ansible.template import Templar as Template

    def _test_contains_and_get(obj, var, result):
        if result:
            assert(var in obj)
            obj[var]
        else:
            assert(var not in obj)
            try:
                obj[var]
            except:
                pass
            else:
                raise RuntimeError("AnsibleJ2Vars unexpectedly contains '%s' but should not" % var)

    # Test 1 from the inside out.
    # Test 2 from the outside in.

    # Test 1
    # Test the variables passed to the jinja2 templar
    templar = Templar(None, variables={'a':'b', 'b':'c', 'c':'d'})
    # locals should not be used

# Generated at 2022-06-23 13:24:01.691228
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.templating.jinja2.environment import Environment

    path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/playbook/play_context.py')
    variables = VariableManager(loader=DataLoader())
    variables.set_inventory(os.path.join(os.path.dirname(__file__), '../../lib/ansible/inventory'))
    variables.extra_vars = {'hostvars': {'a': '1', 'b': '2'}}

# Generated at 2022-06-23 13:24:10.217870
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars import hostvars
    from ansible.vars import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager.set_host_variable(hostvars.HostVars('testhost'), "test", "value")
    templar = Templar(loader=None, variables=variable_manager)
    myVars = AnsibleJ2Vars(templar, globals=dict(), locals=dict())

    assert myVars['test'] == 'value'
    assert "test" in myVars

# Generated at 2022-06-23 13:24:20.000122
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    globals = dict(hostvars=HostVars(dict()))
    templar = Templar(loader=None, variables=globals, shared_loader_obj=None)
    temp = AnsibleJ2Vars(templar, globals)

    assert len(temp) == 2
    temp._locals['l_fake_local'] = 'fake_local_value'
    assert len(temp) == 3
    temp._templar.available_variables['fake_var'] = 'fake_var_value'
    assert len(temp) == 4
    temp._globals['fake_global'] = 'fake_global_value'

# Generated at 2022-06-23 13:24:24.813991
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = object()
    globals = { 'g1': 'y' }
    proxy = AnsibleJ2Vars(templar, globals)
    assert proxy == { 'g1': 'y' }

    locals = { 'l1': 'value1', 'l2': 'value2' }
    new_proxy = proxy.add_locals(locals)
    assert new_proxy == { 'g1': 'y', 'l1': 'value1', 'l2': 'value2' }

    # assert proxy is unchanged
    assert proxy == { 'g1': 'y' }



# Generated at 2022-06-23 13:24:36.232731
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        "foo": "value of foo",
    }
    variable_manager.host_vars['host'] = {
        "bar": "value of bar",
    }

    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    variables = AnsibleJ2Vars(templar, variable_manager.get_globals(), locals=templar.get_available_variables(only_templates=True))

    locals = {
        "baz": "value of baz",
    }
    variables_with_locals = variables.add_locals(locals)


# Generated at 2022-06-23 13:24:47.555441
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Construct a default AnsibleJ2Vars object
    templar = object()
    globals = {}
    aj2v = AnsibleJ2Vars(templar, globals)

    # We should not get any locals from default object
    assert type(aj2v._locals) == dict
    assert not aj2v._locals

    # Get a copy of AnsibleJ2Vars with some local variables
    locals = {'a': 1, 'b': 2}
    aj2v = aj2v.add_locals(locals)

    # We should get local variables from copy of AnsibleJ2Vars
    assert type(aj2v._locals) == dict
    assert len(aj2v._locals) == 2

    # We should not change the original AnsibleJ2Vars object
   

# Generated at 2022-06-23 13:24:58.183943
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    templar = Templar(loader=None, variables={})
    value = None
    # 1. test if locals = None, return self
    a = AnsibleJ2Vars(templar, {}, None)
    assert a == a.add_locals(None)
    # 2. test if locals is not empty, create a copy of self
    locals = {}
    locals[42] = 'foo'

# Generated at 2022-06-23 13:25:05.674736
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar()
    globals = dict(g_var="g_value")
    locals = dict(l_var="l_value")
    vars_proxy = AnsibleJ2Vars(templar, globals, locals)
    assert vars_proxy['g_var'] == u"g_value"
    assert vars_proxy['l_var'] == u"l_value"

    # Test wrong type
    # locals = 123
    # vars_proxy = AnsibleJ2Vars(templar, globals, locals)
    # assert vars_proxy['g_var'] == u"g_value"
    # assert vars_proxy['l_var'] == u"l_value"

# Generated at 2022-06-23 13:25:16.803629
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    templar = Templar(loader=None)

    locals = {'array': ['a', 'b', 'c'],
              'user': 'ansible',
              'dict': {'key1': 'value1', 'key2': 'value2'},
              'nested_dict': {'key1': {'key2': 'value1'},
                              'key3': {'key4': 'value2'}},
              'var': 'var',
              'var_array': ['v1', 'v2', 'v3']}
    globals_ = {'gbool': True,
                'gint': 0,
                'gnone': None,
                'gstring': 'string'}

# Generated at 2022-06-23 13:25:28.352304
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader, inventory=inventory))
    vars_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager = vars_manager
    variable_manager._fact_cache = dict(foo=wrap_var(dict(bar='baz')))
    variable_manager._host_vars = dict(localhost=wrap_var(dict(ansible_connection='local')))

# Generated at 2022-06-23 13:25:33.016331
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
  # TODO check templar
  templar = None
  # TODO check globals
  globals = None
  # TODO check locals
  locals = None
  proxy = AnsibleJ2Vars(templar, globals, locals)
  proxy.__contains__('foo')


# Generated at 2022-06-23 13:25:42.195391
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import wrap_var

    # Testing parameters
    j2_var_name = "vars"
    j2_var_name_2 = "vars_2"
    j2_var_value = "vars_value"
    j2_var_value_2 = "vars_value_2"

    # Setting up the test environment
    templar = Templar(loader=None, variables=None)
    templar.available_variables = dict()
    templar.available_variables[j2_var_name] = wrap_var(j2_var_value)
    templar.available_variables[j2_var_name_2] = wrap_var(j2_var_value_2)

    # Testing the

# Generated at 2022-06-23 13:25:48.756205
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.template import Templar
    import collections

    templar = Templar(loader=None)
    globals_dict = {}
    locals_dict = {}

    ansible_vars = AnsibleJ2Vars(templar, globals_dict, locals_dict)

    assert isinstance(ansible_vars.__iter__(), collections.Iterator)
    assert isinstance(set(ansible_vars), collections.Set)

# Generated at 2022-06-23 13:26:00.701578
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template import Templar

    # using a dummy vars_to_template value
    vars_to_template = {
        'a': '{{b}}',
        'b': '{{c}}',
        'c': '{{d}}',
        'd': '{{e}}',
        'e': '{{f}}',
        'f': '{{g}}',
        'g': '{{h}}',
        'h': 'this is h',
    }

    variable_manager = VariableManager()
    variable_manager.set_fact_cache({})
    variable_manager.extra_vars = {}
    variable_manager.host_vars = {}
    variable_manager.group_

# Generated at 2022-06-23 13:26:10.372626
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from six import string_types

    # create a mock HostVars which is used to ensure that this is returned raw by AnsibleJ2Vars
    class MockHostVars(HostVars):
        def __getitem__(self, key):
            return key

    # create a mock templar which is used by AnsibleJ2Vars to access variables
    class MockTemplar(Templar):
        def __init__(self, template_vars, hostvars):
            self.available_variables = template_vars
            self.hostvars = hostvars

            # set available_variables to another variable for testing purposes,

# Generated at 2022-06-23 13:26:20.965294
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Test if constructed with a valid Templar() object, as well as several
    # dictionaries of variables representing different scopes (jinja2 terminology).

    vars = dict(
        a=1,
        b=2,
        c=dict(
            d=3,
            e=4
        )
    )

    templar = Templar(loader=None, variables=vars)
    globals = dict()
    locals = dict()
    ansible_vars_proxy = AnsibleJ2Vars(templar, globals, locals)

    assert isinstance(ansible_vars_proxy._templar, Templar), '_templar is type Templar, expected AnsibleTemplate'

# Generated at 2022-06-23 13:26:33.399131
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    ##################################################################
    # This is a test for method __contains__ of class AnsibleJ2Vars
    ##################################################################

    if not __name__ == "__main__":
        return False

    import ansible.module_utils.common.AnsibleJ2Vars
    import ansible.module_utils.common.AnsibleJ2Template
    import sys

    global_var = "global_var"
    val_global_var = "val_global_var"
    local_var = "local_var"
    val_local_var = "val_local_var"
    templar = ansible.module_utils.common.AnsibleJ2Template.AnsibleJ2Template()
    globals = {global_var : val_global_var}

# Generated at 2022-06-23 13:26:40.576112
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.playbook
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from collections import OrderedDict
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from contextlib import contextmanager

    # yaml.safe_load(s) returns None, if s is empty.
    @contextmanager
    def _yaml_safe_load(s):
        if bool(s):
            yield yaml.safe_load(s)
        else:
            yield None

    class FakeVariableManager(object):
        def __init__(self):
            self.vars_cache = {}


# Generated at 2022-06-23 13:26:51.131520
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    import ansible.playbook.play

    class AnsibleJ2VarsMockTemplar:
        def __init__(self):
            available_variables = {
                'test': 'success',
            }
            self.available_variables = available_variables

    class AnsibleJ2VarsMockHost:
        def __init__(self):
            self.name = 'dummy'
            self.vars = {'test1': 'success'}

    class AnsibleJ2VarsMockPlay:
        def __init__(self):
            self.get_vars = {'test2': 'success'}

    #
    # executes AnsibleJ2Vars() with arguments

# Generated at 2022-06-23 13:27:02.298057
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.plugins.loader import add_vars_plugin, add_filter_plugin
    mapper = Templar(loader=None)
    add_vars_plugin(mapper._available_variables)
    add_filter_plugin(mapper._available_filters)
    ajv_obj = AnsibleJ2Vars(mapper, globals={})
    ajv_obj.__contains__() == False
    assert isinstance(ajv_obj._templar, Templar)
    assert isinstance(ajv_obj, AnsibleJ2Vars)
    assert isinstance(ajv_obj.__getitem__('hostvars'), HostVars)

# Generated at 2022-06-23 13:27:07.342635
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Returns the number of valid items in the instance
    #
    templar = None
    globals = dict()
    locals = dict()
    ansibleJ2Vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansibleJ2Vars) == 0



# Generated at 2022-06-23 13:27:15.492205
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    import os
    import sys

    def null_data():
        return None

    templar = Templar(loader=null_data)
    vars = AnsibleJ2Vars(templar, globals())
    print("test_AnsibleJ2Vars___getitem__: type(vars[sys]) -> " + str(type(vars[sys])))
    print("test_AnsibleJ2Vars___getitem__: type(vars[os]) -> " + str(type(vars[os])))
    print("test_AnsibleJ2Vars___getitem__: type(vars[AnsibleJ2Vars]) -> " + str(type(vars[AnsibleJ2Vars])))

# Generated at 2022-06-23 13:27:23.238967
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    class Templar:
        def template(self, variable):
            return "AAAABBBBAAAA"

    proxy = AnsibleJ2Vars(Templar(), {'foo': 'bar'}, {'mik': 'bou', 'mik2': 'bou2'})

    assert(proxy['foo'] == 'bar')    # VAR exists in globals
    assert(proxy['mik'] == 'bou')    # VAR exists in locals
    assert(proxy['mik2'] == 'AAAABBBBAAAA')

    try:
        proxy['mik3']
        assert(False)
    except KeyError:
        assert(True)

# Generated at 2022-06-23 13:27:34.865476
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    collection = AnsibleJ2Vars(Templar(), dict())
    assert not ('blah' in collection), "blah is not in empty dict"

    # Create a test variable for the VariableManager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'blah': 'foo'}

    collection = AnsibleJ2Vars(Templar(variable_manager=variable_manager), dict())
    assert ('blah' in collection), "blah is in variable_manager"

    collection = AnsibleJ2Vars(Templar(variable_manager=variable_manager), dict(blah='foo'))
    assert ('blah' in collection), "blah is in dict"

# Generated at 2022-06-23 13:27:38.396228
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    a = AnsibleJ2Vars()
    assert sorted(list(iter(a))) == sorted([u'inventory_dir', u'inventory_file', u'omit', u'playbook_dir', u'role_names', u'roles_path'])

    a = AnsibleJ2Vars()
    assert sorted(list(iter(a))) == sorted([u'inventory_dir', u'inventory_file', u'omit', u'playbook_dir', u'role_names', u'roles_path'])

# Generated at 2022-06-23 13:27:40.126743
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass

# Generated at 2022-06-23 13:27:48.600943
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()


# Generated at 2022-06-23 13:27:56.024552
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2

    templar = jinja2.Environment(undefined=jinja2.StrictUndefined).from_string('a{{b}}').environment.variable_start_string
    globals = {}
    locals = {'a' : 1, 'b' : 2, 'c' : 3}
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)

    assert ansible_vars['a'] == 1
    assert ansible_vars['b'] == 2
    assert ansible_vars['c'] == 3
    assert 'd' not in ansible_vars

    new_locals = {'c' : 4, 'd' : 5}
    new_ansible_vars = ansible_vars.add_locals(new_locals)



# Generated at 2022-06-23 13:27:57.061290
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert True



# Generated at 2022-06-23 13:28:04.398397
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.templating import Templar
    templar = Templar()
    jinja_vars = AnsibleJ2Vars(templar, {}, {'c': 'd'})
    jinja_vars1 = jinja_vars.add_locals({'e': 'f'})
    assert jinja_vars1['c'] == 'd'
    assert jinja_vars1['e'] == 'f'

# Generated at 2022-06-23 13:28:09.394858
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables=dict(a=dict(b=2)))
    vars = AnsibleJ2Vars(templar, dict(c=3))
    assert len(vars) == 2



# Generated at 2022-06-23 13:28:19.393229
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.vault import VaultSecret

    templar = Templar(None, loader=None, variables={}, vault_secrets={})
    vars = AnsibleJ2Vars(templar, globals={'v': 1}, locals={'x': 2, 'l_z': 3})

    itr = iter(vars)

    assert len(list(itr)) == 3
    assert 'x' in vars
    assert 'v' in vars
    assert 'z' in vars
    assert vars['x'] == 2
    assert vars['v'] == 1
    assert vars['z'] == 3
    assert vars['z'] is not missing

    vars = AnsibleJ2

# Generated at 2022-06-23 13:28:24.477519
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    templar = Templar()
    j2_vars = AnsibleJ2Vars(templar, {}, locals={"testing": "test"})
    assert sorted(j2_vars.__iter__()) == ["testing"]


# Generated at 2022-06-23 13:28:33.157636
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = mock.MagicMock()
    globals = {}
    env = AnsibleJ2Vars(templar, globals)

    templar.available_variables = {'aaa': 'bbb', 'ccc': 'ddd'}

    assert len(env) == 2

    templar.available_variables = {'aaa': 'bbb'}
    globals = {'ddd': 'eee'}
    env = AnsibleJ2Vars(templar, globals)

    assert len(env) == 2

    templar.available_variables = {'aaa': 'bbb'}
    globals = {'aaa': 'bbb'}
    env = AnsibleJ2Vars(templar, globals)

    assert len(env) == 1


# Generated at 2022-06-23 13:28:37.923517
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    aj2v = AnsibleJ2Vars(Templar(loader=None, variables={'foo': 1}), {}, Play().vars)
    assert len(aj2v) == 1


# Generated at 2022-06-23 13:28:40.661578
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    var = {'a': {'aa': 'val'}, 'b': 'val', 'c': {'cc': 'val'}}
    proxy = AnsibleJ2Vars('templar', var)
    assert len(proxy) == 3

# Generated at 2022-06-23 13:28:45.807765
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    vars = AnsibleJ2Vars(Templar(), {'a': 1}, locals={'b': 2})
    assert 'a' in vars
    assert 'b' in vars
    assert 'c' not in vars


# Generated at 2022-06-23 13:28:55.809145
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class Templar:
        def __init__(self, av, gv, lv):
            self.available_variables = av
            self.globals_variables = gv
            self.locals_variables = lv

    av = {
        'a': 1,
        'b': 2
    }

    gv = {
        'foo': 'bar',
        'baz': 'buz'
    }

    lv = {
        'c': 3
    }

    templar = Templar(av, gv, lv)

    avars = AnsibleJ2Vars(templar, gv, lv)

    keys = set()
    keys.update(['a', 'b', 'foo', 'baz', 'c'])


# Generated at 2022-06-23 13:29:08.367117
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible import context
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars

    templar = context.CLIARGS['module_vars'].copy()
    templar['ANSIBLE_VAULT'] = VaultLib()
    templar['ANSIBLE_VAULT_PASSWORD_FILE'] = './vault_pass.txt'

    global_vars = combine_vars(context.CLIARGS['module_vars'], context.CLIARGS['extra_vars'])

    locals = {'name': 'test', 'age': 20}
    global_vars['a'] = '1'
    global_vars['b'] = '2'


# Generated at 2022-06-23 13:29:15.121467
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = AnsibleJ2Vars(None, {}, None)
    locals = {
        'test_variable': AnsibleUnsafeText('test_value')
    }
    new_locals = templar.add_locals(locals)

    assert new_locals['test_variable'] == 'test_value', "add_locals() should add a local variable to templar"

# Generated at 2022-06-23 13:29:26.171568
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = Templar(loader=None, variables={'varname': AnsibleUnsafeText('value')})

    # Test with locals (dict)
    locals = {}
    locals['l_localhost'] = 12345
    j2v = AnsibleJ2Vars(templar, {'g_group': 'group'}, locals)

    # Test __contains__
    assert 'localhost' in j2v
    assert 'g_group' in j2v
    assert 'varname' in j2v
    assert 'varname2' not in j2v

    # Test with locals (dict with missing key)
    locals = {}
    locals['l_localhost'] = missing
    j2v = Ans

# Generated at 2022-06-23 13:29:37.033960
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import ansible_safe_eval
    class _Templar:
        def __init__(self):
            self.available_variables=dict()
            self.available_variables['a']="a"
        def template(self,a):
            return ansible_safe_eval(a)
    class _Globals:
        def __init__(self):
            self.b='b'
    templar=_Templar()
    globals=_Globals()
    aj2vars=AnsibleJ2Vars(templar,globals)
    assert "b" in aj2vars
    assert "a" in aj2vars
    assert "c" not in aj2vars


# Generated at 2022-06-23 13:29:45.112602
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    t = Templar(loader=None, variables={'a': 1})
    v = AnsibleJ2Vars(templar=t, globals={'b': 2}, locals={'c': 3})

    # Check that the variables are accessible
    assert v['a'] == 1
    assert v['b'] == 2
    assert v['c'] == 3

    # Check that add_locals(d) creates a new AnsibleJ2Vars which contains the new variable
    v_new = v.add_locals({'d': 4})
    assert v_new['d'] == 4

    # Check that self is not modified
    assert v['d'] == missing

# Generated at 2022-06-23 13:29:56.723661
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    This unit test checks that the method __iter__ of the class AnsibleJ2Vars
    works correctly.
    '''

    # create the variables we will use
    templar = object()
    globals = {'a': 2, 'b': 4}
    locals = {'c': 6, 'd': 8}

    # create the AnsibleJ2Vars object we will test
    vars = AnsibleJ2Vars(templar, globals, locals)

    # check that the keys are correct
    keys = list(vars.__iter__())
    assert len(keys) == len(globals) + len(locals)
    for key in keys:
        assert key in globals or key in locals

    # check that the keys are correct
    keys = list(vars)
    assert len

# Generated at 2022-06-23 13:30:09.145404
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    templar = Templar(loader=DataLoader(), variables=VariableManager(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader())))
    globals = unsafe_eval("""
{% set test_var = { 'a': '1', 'b': '2', 'c': '3' } -%}
{% for key, val in test_var.items() %}
{% do globals()[key] = val -%}
{% endfor %}
{{ globals() }}
""")

# Generated at 2022-06-23 13:30:20.591072
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    def get_variable_manager(loader, context):
        return VariableManager(loader=loader, inventory=None, version_info=context.CLIARGS['version_info'])

    class AnsibleJ2VarsMock(AnsibleJ2Vars):
        def __init__(self, templar, globals, locals=None):
            self._templar = templar
            self._globals = globals
            self._locals = locals

    templar = None
    globals = {'test': 1}
    locals = {'test1': 2}

    a = AnsibleJ2VarsMock(templar, globals, locals)

   

# Generated at 2022-06-23 13:30:33.417298
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class TemplarMock(object):
        def __init__(self):
            self._available_variables = {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}

        def template(self, variable):
            return variable

        @property
        def available_variables(self):
            return self._available_variables

    def test_to_dict(obj):
        return {key: obj[key] for key in dir(obj) if not key.startswith('__')}

    templar_mock = TemplarMock()
    ajv = AnsibleJ2Vars(templar_mock, {'test4': 'test4', 'test5': 'test5'})
    ajv_dict = test_to_dict(ajv)

    assert a

# Generated at 2022-06-23 13:30:36.227256
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars(dict())
    templar = AnsibleJ2Vars(hostvars, dict())
    # we have 3 dictionaries
    assert len(templar) == 3

# Generated at 2022-06-23 13:30:39.276166
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    t = Templar(loader=None, variables={'var1': 'var1'})
    a = AnsibleJ2Vars(templar=t, globals={'globvar': 'globvar'})
    assert(len(a) == 3)

# Generated at 2022-06-23 13:30:47.526473
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import os
    import jinja2
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    variable_manager = jinja2.Environment(loader=loader, undefined=jinja2.StrictUndefined)
    templar = Templar(loader=loader, variables=variable_manager)
    host = type('host', (object,), {})()
    host.name = "localhost"
    _vars = dict(a=1, b=2, c=3, d=4)
    context = PlayContext()
    context._vars = _vars

# Generated at 2022-06-23 13:30:49.939905
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = Templar()
    globals = {}
    locals = {}
    AnsibleJ2Vars(templar, globals, locals)


# Generated at 2022-06-23 13:31:02.017176
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Test case 1: set is empty
    globals = {'g1': 1}
    templar = {}
    vars = AnsibleJ2Vars(templar, globals)
    assert list(vars) == []

    # Test case 2: set of dicts are empty
    globals = {'g1': 1}
    templar = {'t1': 2}
    vars = AnsibleJ2Vars(templar, globals)
    assert list(vars) == ['t1']

    # Test case 3: set of dicts are not empty
    globals = {'g1': 1, 'g2': 2}
    templar = {'t1': 2, 't2': 2, 't3': 3}

# Generated at 2022-06-23 13:31:08.198154
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var
    templar = Templar(loader=None, variables={
        'vars': wrap_var(HostVars(dict(a=1, b=2))),
        'c': 3,
    })
    j2vars = AnsibleJ2Vars(templar, {})
    assert hasattr(j2vars, '__iter__')
    assert set(j2vars) == set(['vars', 'c'])

# Generated at 2022-06-23 13:31:19.680825
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar()
    vault_secrets_loader = VaultLib('password', None, None)
    templar._vars_plugins.update([vault_secrets_loader])

    # Test 1
    ansible_j2_vars = AnsibleJ2Vars(templar, {})
    assert iter(ansible_j2_vars) is None

    # Test 2
    ansible_j2_vars = AnsibleJ2Vars(templar, dict())
    assert iter(ansible_j2_vars) is None

    # Test 3

# Generated at 2022-06-23 13:31:28.823472
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = None
    globals = None
    locals = None
    new_locals = None

    # Case: locals == None
    v1 = AnsibleJ2Vars(templar, globals, locals)
    v2 = v1.add_locals(new_locals)
    assert id(v1) == id(v2)

    # Case: locals != None
    locals = { 'a' : 1, 'b' : 2 }
    v1 = AnsibleJ2Vars(templar, globals, locals)
    v2 = v1.add_locals(new_locals)
    assert id(v1) != id(v2)
    assert v1._locals == v2._locals

    new_locals = { 'a' : 3, 'c' : 4 }


# Generated at 2022-06-23 13:31:35.825083
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    t = Templar(loader=None)      # Dummy loader, not used
    j2v = AnsibleJ2Vars(t, {}, {}) # empty locals
    j2v_locals = j2v.add_locals({'foo': 'bar'})
    assert j2v_locals is not j2v
    assert j2v_locals['foo'] == 'bar'

# Generated at 2022-06-23 13:31:45.026416
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Let's start with a dictionnary containing locals
    locals = dict(
        dict_toto=dict(
            dict_tata=dict(
                dict_coucou="hello"
            )
        )
    )

    # Create an AnsibleJ2Vars instance
    j2v = AnsibleJ2Vars(None, None, locals)

    # Create a copy of j2v with updated locals
    new_locals = dict(
        dict_toto=dict(
            dict_tata=dict(
                dict_coucou="hello",
                dict_tutu="world"
            )
        )
    )
    j2v_copy = j2v.add_locals(new_locals)

    # Check that the number of locals has increased in j2v_copy

# Generated at 2022-06-23 13:31:56.800790
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    Test to ensure that given the values passed,
    AnsibleJ2Vars.__contains__ returns True
    '''

    template_data = dict(
        dict(
            templar=None,
            globals=dict(
                answer=42
            ),
            locals=None,
            result=True
        )
    )
    results = []
    msg = 'AnsibleJ2Vars.__contains__ did not return expected result'

    for item in template_data:
        j2v = AnsibleJ2Vars(
            templar=item.get('templar'),
            globals=item.get('globals'),
            locals=item.get('locals')
        )

# Generated at 2022-06-23 13:32:03.303408
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from . import Templar
    t = Templar("/path/to/root/playbook")
    t.set_available_variables(dict(TEST="value"))

    v = AnsibleJ2Vars(t, dict(TEST2="value2"))
    assert "TEST" in v
    assert "TEST2" in v
    assert "UNDEFINED" not in v


# Generated at 2022-06-23 13:32:09.651541
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar
    from ansible.vars.hostvars import HostVars

    pc = PlayContext()
    templar = Templar(pc)
    ajv = AnsibleJ2Vars(templar, None)

    # exception 'AnsibleUndefinedVariable' should be raised
    varname = 'VARNAME'
    try:
        variable = ajv[varname]
    except AnsibleUndefinedVariable as e:
        assert varname in str(e)
    else:
        raise AssertionError(
            "AnsibleUndefinedVariable exception should be raised when variable '%s' is not defined" % varname
        )

    # variable = HostVars(), return should be the same
    variable = Host

# Generated at 2022-06-23 13:32:20.948601
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # tests for empty variable proxy
    vp = AnsibleJ2Vars(templar=None, globals={}, locals={})
    try:
        assert len(vp) == 0
    except AssertionError:
        raise AssertionError(
            "len(AnsibleJ2Vars(templar=None, globals={}, locals={})) should be 0")
    # tests for variable proxy containing data in locals and _templar.available_variables
    vp = AnsibleJ2Vars(
        templar=None, globals={}, locals={"var1": "var"})

# Generated at 2022-06-23 13:32:24.840287
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class DummyJ2Vars(AnsibleJ2Vars):
        def __init__(self):
            super(DummyJ2Vars, self).__init__({}, {})

    assert DummyJ2Vars()

# Generated at 2022-06-23 13:32:29.138903
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    j2vars = AnsibleJ2Vars(templar=None, globals={'test':'test'}, locals={'test':'test'})
    if j2vars['test'] != 'test':
        raise AssertionError('Jinja2 variable proxy not initialized properly.')

# Generated at 2022-06-23 13:32:41.307857
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    Test AnsibleJ2Vars.__iter__ method
    '''
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    from ansible.template import Templar

    class TestAnsibleJ2Vars(unittest.TestCase):

        def test__iter__(self):
            templar = Templar(loader=None)
            j2vars = AnsibleJ2Vars(
                templar=templar,
                globals={'test_global1': 'test_global_val1',
                         'test_global2': 'test_global_val2'})
            self.assertEqual(len(j2vars), 2)
            self.assertTrue(isinstance(j2vars, Mapping))


# Generated at 2022-06-23 13:32:53.449905
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """