

# Generated at 2022-06-23 13:22:55.210583
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    empty_dict = {}

    assert isinstance(AnsibleJ2Vars(templar, globals=empty_dict), Mapping)
    assert isinstance(AnsibleJ2Vars(templar, globals=empty_dict, locals=empty_dict), Mapping)

# Generated at 2022-06-23 13:22:59.549609
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = {}
    locals = {'a': 'a', 'b': 'b'}

    result = AnsibleJ2Vars(templar, globals, locals=locals)
    assert result.__iter__() == locals.__iter__()



# Generated at 2022-06-23 13:23:06.097263
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    j2_val = {'foo': 'bar'}
    j2_vars = AnsibleJ2Vars(Templar(), {})
    new_vars = j2_vars.add_locals(j2_val)
    assert new_vars._locals['foo'] == 'bar'

# Generated at 2022-06-23 13:23:07.137292
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass # TODO


# Generated at 2022-06-23 13:23:14.883445
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 13:23:24.947150
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.template.template import AnsibleJinja2TemplateEnvironment
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    templar = Templar(loader=None, variables={})
    globals = AnsibleJinja2TemplateEnvironment()
    vars = VariableManager()
    vars.setup_cache()
    vars.update_cache([({'test': '1', 'test1': 'test1'}, 'host_hostname')])
    vars.add_host_vars('host_hostname', {'test': '1', 'test1': 'test1'})
    vars.update_cache([({'test2': '1', 'test3': 'test3'}, 'host_hostname')])
   

# Generated at 2022-06-23 13:23:34.612705
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.parsing import DataLoader

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.vars import VariableManager

    from ansible.module_utils.six import BytesIO

    from ansible.template.vars import AnsibleJ2Vars

    text_obj1 = AnsibleUnsafeText(u'text1')
    text_obj2 = AnsibleUnsafeText(u'text2')
    unsafe_obj = AnsibleUnsafeText(u'unsafe')
    d = {
        'text1': text_obj1,
        'text2': text_obj2,
        'unsafe': unsafe_obj,
    }

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_v

# Generated at 2022-06-23 13:23:40.810216
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook.includer import IncludeLoader

    class MyTemplar(Templar):
        def __init__(self):
            pass

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(foo="1", bar="2")
    variable_manager.host_vars = dict(localhost=dict(baz="3"))
    variable_manager.group_vars = dict(group1=dict(hoge="4"))

    templar = MyTemplar()
    templar._available_variables = variable_manager.get_vars

# Generated at 2022-06-23 13:23:50.306221
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.module_utils.jinja2.templar import Templar
    from ansible.template import Templar as TemplarTemplate 

    templar = Templar(None, loader=None)
    #check construct from TemplarTemplate
    template = TemplarTemplate(loader=None, shared_loader_obj=None)
    hostvars = dict()
    hostvar = dict()
    hostvar['name'] = 'host1'
    hostvar['ip'] = '10.0.0.1'
    hostvar['cpu'] = 1
    hostvar['memory'] = '1024'
    hostvar['services'] = ['ssh', 'http', 'smtp']
    hostvars['host1'] = hostvar
    hostvar = dict()
    hostvar['name'] = 'host2'

# Generated at 2022-06-23 13:23:58.302573
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    env = {}
    templar = Templar(loader=None, variables=env)
    locals = {}
    ansible_j2_vars = AnsibleJ2Vars(templar, {}, locals)
    assert ansible_j2_vars._templar == templar
    assert ansible_j2_vars._locals == locals

    locals = {'foo' : 'bar'}
    ansible_j2_vars = AnsibleJ2Vars(templar, {}, locals)
    assert ansible_j2_vars._templar == templar
    assert ansible_j2_vars._locals == locals


# Generated at 2022-06-23 13:24:06.783174
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.templar import Templar
    t = Templar(loader=None, variables={})
    aj2v = AnsibleJ2Vars(templar=t, globals={'foo':1, 'bar':2})
    assert 'foo' in aj2v
    assert 'bar' in aj2v
    assert 'baz' not in aj2v
    assert aj2v['foo'] == 1
    assert aj2v['bar'] == 2
    try:
        aj2v['baz']
        assert False, "Did not get KeyError on accessing aj2v['baz']"
    except KeyError:
        pass


# Generated at 2022-06-23 13:24:15.705733
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar()

    # Testing empty locals
    vars = AnsibleJ2Vars(templar, dict())
    assert vars is vars.add_locals(None)

    # Testing locals containing a single key "foo"
    vars = AnsibleJ2Vars(templar, dict())
    newvars = vars.add_locals(dict(foo="bar"))
    # The locals of the new object should be a copy of the locals of the original object
    assert newvars._locals.items() == vars._locals.items()
    # And the new object should include the locals of the original object
    assert newvars._locals.get("foo") == "bar"

    # Testing locals containing two keys "foo" and "x"
    vars

# Generated at 2022-06-23 13:24:24.737993
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar
    from ansible.template.vars import AnsibleJ2Vars

    templar = Templar(loader=None, variables={})
    ansible_vars = AnsibleJ2Vars(templar, PlayContext())
    assert hasattr(ansible_vars, '__iter__')
    assert hasattr(iter(ansible_vars), '__next__')
    # Iterator works only in Python 3
    # next(iter(ansible_vars))


# Generated at 2022-06-23 13:24:26.933145
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    assert True == False

# Generated at 2022-06-23 13:24:33.281695
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    import jinja2
    from ansible.template import Templar

    templar = Templar(None, None)
    globals = {'data': {'key1': 'value1', 'key2': 'value2'}}
    locals = {'data': {'key3': 'value3', 'key4': 'value4'}}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert len(vars) == 4
    assert 'key1' in vars
    assert 'key2' in vars
    assert 'key3' in vars
    assert 'key4' in vars
    assert 'key5' not in vars
    assert 'key6' not in vars


# Generated at 2022-06-23 13:24:42.215143
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault = VaultLib(None)
    vault_secret = VaultSecret('$ANSIBLE_VAULT;1.1;AES256\n61383133616532633162383063333638653933323935333564303539346466333163323138\n356261373131383664663536316466653864356265310a3933643162653965316335623563\n633538343862366339643161336132303035326161653533383732396233393239393037\n373564653136623732656639\n', 'vaultpassword')

# Generated at 2022-06-23 13:24:52.621899
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.template import Templar
    from ansible import constants as C

    templar = Templar(loader=None, variables={}, shared_loader_obj=None, searchpath=C.DEFAULT_TEMPLATE_PATH)
    globals = dict()

    if C.DEFAULT_JINJA2_NATIVE:
        # Force to use JSON encoder in tests, to avoid different behavior of global_vars in json and native mode
        templar.available_variables = dict()
        templar.json_env = AnsibleJSONEncoder()

    j2vars = AnsibleJ2Vars(templar, globals, locals=None)

    # if there are no locals, but the var is found in jinja2 available_variables

# Generated at 2022-06-23 13:25:00.551593
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """
    Unit test for method __contains__ of class AnsibleJ2Vars
    """


# Generated at 2022-06-23 13:25:03.784222
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    t = AnsibleJ2Vars(None, None)
    t.add_locals({'foo': 2})
    assert t._locals['foo'] == 2


# Generated at 2022-06-23 13:25:12.935170
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    class Dummy(object):
        pass
    dummy = Dummy()
    dummy.vars = {'a': 'a'}
    dummy.play_context = PlayContext(play=dummy)
    templar = Templar(loader=None, variables=dummy.vars, fail_on_undefined=False)
    proxy = AnsibleJ2Vars(templar, {'a': 'a'})
    proxy.add_locals({'b': 'b'})
    assert proxy['b'] == 'b'

# Generated at 2022-06-23 13:25:15.136475
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # raise NotImplementedError('No unit test written for method __contains__ of class AnsibleJ2Vars')
    pass


# Generated at 2022-06-23 13:25:15.707265
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    assert True == True

# Generated at 2022-06-23 13:25:16.333311
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    assert True

# Generated at 2022-06-23 13:25:22.759244
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from jinja2 import Undefined, StrictUndefined
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from units.mock.loader import DictDataLoader
    from ansible.vars.hostvars import HostVars

    MOCK_LOADER = DictDataLoader({
        'hostvars': {
            'local': {
                'key1': 'val1',
                'key2': 'val2',
            }
        }
    })


# Generated at 2022-06-23 13:25:31.656344
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    templar = Templar(loader=loader, variables={})

    test_obj = AnsibleJ2Vars(templar, globals={})
    for _ in test_obj:
        assert False

    test_obj = AnsibleJ2Vars(templar, globals={}, locals={})
    for _ in test_obj:
        assert False

    test_obj = AnsibleJ2Vars(templar, globals={}, locals={'a': 1, 'b': 2})
    assert len(set(test_obj)) == 2



# Generated at 2022-06-23 13:25:40.757130
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.playbook
    from ansible.template import Templar

    templar = Templar(loader=None)
    my_data = AnsibleJ2Vars(templar, {'aaa': 'AAA'}, {'bbb': 'BBB', 'l_ccc': 'CCC'})

    # test if key is defined in self._locals
    # key is defined
    if 'bbb' in my_data:
        assert my_data['bbb'] == 'BBB'
        assert my_data['l_ccc'] == 'CCC'
    else:
        assert False

    # test if key is defined in self._templar.available_variables
    # key is defined
    if 'aaa' in my_data:
        assert my_data['aaa'] == 'AAA'
    else:
        assert False

# Generated at 2022-06-23 13:25:43.697676
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    obj = AnsibleJ2Vars(A(), {}, None)
    obj.__len__()
    obj.__len__()



# Generated at 2022-06-23 13:25:53.178245
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # test_AnsibleJ2Vars___contains__(AnsibleJ2Vars)
    # This test should pass in Python 2
    #
    # DO NOT REMOVE:
    # Python 2 dicts have no __contains__ method, so this code must be here
    # to prevent a TypeError when running the test_AnsibleJ2Vars___getitem__ test
    # in Python 2.
    # BEGIN PYTHON2:
    class DictSimul:
        def __init__(self, *args):
            pass
    # END PYTHON2

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

# Generated at 2022-06-23 13:26:05.935635
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    given_template_dict = {
        'lookup_options': {
            'redis': {
                'host': '127.0.0.1',
                'port': 6379,
                'db_index': 0,
                'key_prefix': 'base64:'
            }
        }
    }

    given_locals = {'key': 'lookup_options.redis'}
    given_globals = {'foo': 'bar'}

    # template_dict normally contains the results of the included file from Jinja2.Template
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    templar = Templar(loader=None, variables=given_template_dict)

# Generated at 2022-06-23 13:26:17.848697
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import sys
    if sys.version_info[0] < 3:
        import __builtin__
    else:
        import builtins as __builtin__
    import mock
    import __main__
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def _create_unsafe_proxy_mock(text):
        unsafe_proxy_mock = mock.MagicMock()
        unsafe_proxy_mock.__str__.side_effect = lambda self: text
        unsafe_proxy_mock.__repr__.side_effect = lambda self: text
        unsafe_proxy_mock.__add__.side_effect = lambda lhs, rhs: _create_unsafe_proxy_mock("" if rhs is None else rhs)
        return unsafe_proxy_mock

    templar

# Generated at 2022-06-23 13:26:29.686817
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()

    globals = {}
    locals = {"var1": "bar1", "var2": "bar2"}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # Test case: existing global variable
    globals['yaml_tag'] = 'tag:yaml.org,2002:str'
    assert vars['yaml_tag'] == 'tag:yaml.org,2002:str'

    # Test case: existing local variable
    assert vars['var1'] == 'bar1'

    # Test case: existing variable in vars
    templar.available_variables['var3'] = 'bar3'
    assert vars['var3'] == 'bar3'

    # Test case: undefined variable

# Generated at 2022-06-23 13:26:38.696659
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Example (non exhaustive) test case.
    # To run the tests: $ python -m test.test_ansible_j2vars
    try:
        from ansible.template.safe_eval import ansible_safe_eval
        from ansible.template import Templar
        from ansible.playbook.play_context import PlayContext
    except ImportError:
        print('\n\nUNIT TEST ERROR: ansible needs to be installed to run the ansible j2vars unit tests')
        sys.exit(1)

    # basic test of the constructor
    def test_case0():
        variables = dict(key1='value1', key2='{{value2}}')
        context = PlayContext()
        templar = Templar(loader=None, variables=variables,
            shared_loader_obj=None, context=context)


# Generated at 2022-06-23 13:26:50.073900
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from collections import OrderedDict
    from jinja2 import DictLoader
    from jinja2._compat import string_types
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    class Play(object):
        def __init__(self):
            self._play_context = PlayContext()

        @property
        def _loader(self):
            return DictLoader({})

        @property
        def vars(self):
            return dict(aaa=dict(bbb="123"))

    play = Play()

    def _combine_vars(var1, var2):
        combined = combine_vars(var1, var2)

# Generated at 2022-06-23 13:26:57.923917
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    # Create a dict instance
    dict_instance = dict(a=1, b=2, c=3)

    # Create a Templar instance
    templar = Templar()

    # Create an AnsibleJ2Vars instance
    aj2v = AnsibleJ2Vars(templar, dict_instance)

    # Verify the AnsibleJ2Vars instance has attributes that match the keys of dict_instance
    for key in dict_instance:
        assert hasattr(aj2v, key)


# Generated at 2022-06-23 13:27:09.192278
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.template.safe_eval import safe_eval

    var_manager = VariableManager()
    var_manager.set_globals({'global_var': 'global_value'})
    vault_secret = VaultSecret('vault_secret')
    vault = VaultLib([vault_secret])
    var_manager.set_vault_secrets([vault_secret])
    templar = Templar(var_manager, vault_secrets=[vault_secret], fail_on_undefined=True)

# Generated at 2022-06-23 13:27:12.751235
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import ansible.template
    j2vars = AnsibleJ2Vars(templar=ansible.template.Templar(), globals={'a': 1, 'b': 3})
    expected = {'a', 'b'}
    assert set(j2vars) == expected

# Generated at 2022-06-23 13:27:20.231417
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # initialize
    class _Templar(object):
        def __init__(self):
            self.available_variables = {'x': 1, 'y': 2}
        def template(self, variable):
            return variable

    globals = {'a': 3, 'b': 4}
    locals = None

    # test
    j2_vars = AnsibleJ2Vars(_Templar(), globals, locals)
    assert sorted(list(j2_vars)) == ['a', 'b', 'x', 'y']

# Generated at 2022-06-23 13:27:33.076070
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import jinja2

    class MockHost(object):
        def __init__(self, name):
            self.name = name

    host_obj = MockHost('localhost')

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    playbook_context = PlayContext()
    inventory = [host_obj]

    # Create variables

# Generated at 2022-06-23 13:27:37.269192
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''Test case for class AnsibleJ2Vars'''
    testobj = AnsibleJ2Vars(None, None)
    print('test __len__')
    assert len(testobj) == 0



# Generated at 2022-06-23 13:27:43.730458
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    vars_mock = dict()
    vars_mock["k"] = "v"
    vars_mock["k2"] = "v2"

    templar_mock = object()
    globals_mock = object()

    obj = AnsibleJ2Vars(templar_mock, globals_mock, locals=vars_mock)

    assert len(obj) == len(vars_mock)


# Generated at 2022-06-23 13:27:52.606903
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.module_utils.six import StringIO

    from ansible.parsing.jinja2.filters import AnsibleJinja2Filters
    from ansible.template import Templar

    from ansible.module_utils._text import to_text

    globals = {}
    locals = {}
    filters = AnsibleJinja2Filters(Templar(loader=None))
    templar = Templar(loader=None, variables={'one': 1, 'two': 2, 'three': 3}, filters=filters)

    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 3

    v

# Generated at 2022-06-23 13:28:02.965379
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template.templar import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    class VarMgr(object):
        def __init__(self, extra_vars):
            self.extra_vars = extra_vars

        def get_vars(self, loader, play=None, host=None, task=None, include_hostvars=True):
            return self.extra_vars

    loader = DataLoader()
    play = PlayContext()
    templar = Templar(loader=loader, variables=VariableManager(loader, play))

    extra_vars = dict()
    extra_v

# Generated at 2022-06-23 13:28:15.597313
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible import errors
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, wrap_var

    templar = Templar(loader=None)

    # Test when the variable is given in available_variables but not in locals and globals
    templar.available_variables = {'k': 'v'}
    vars = AnsibleJ2Vars(templar, globals={})

    assert(vars['k'] == 'v')

    # Test when the variable is given in locals and not in globals
    templar.available_variables = {}
    vars = AnsibleJ2Vars(templar, globals={}, locals={'k': 'v'})

    assert(vars['k'] == 'v')

    # Test when the variable

# Generated at 2022-06-23 13:28:27.821575
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # create a template context
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict(var1='hello')
    locals = dict(var1='world')
    vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)

    assert vars['var1'] == 'world'

    # locals of lower priority
    locals['var1'] = 'not world'
    assert vars['var1'] == 'world'

    # local value of 'var1' must be str, not int to pass assert
    locals['var1'] = 0
    assert vars['var1'] == 'world'

# Generated at 2022-06-23 13:28:29.644135
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # FIXME: add test here for AnsibleJ2Vars.__init__()
    # Need to mock Templar() object
    pass



# Generated at 2022-06-23 13:28:41.367031
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar()

    globals = {'test': {'hello': 'world'},
               'a': {'b': {'e': 'j'}},
               'z': {'b': {'e': 'j'}},
               'one': 1,
               'two': 2,
               'three': {'a': {'a': 1, 'b': 2, 'c': 3}},
               'four': HostVars(),
               'var': {'a': 'var a', 'b': 'var b', 'c': 'var c'}
               }


# Generated at 2022-06-23 13:28:53.237535
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar

    c = PlayContext()
    t = Templar(loader=None, variables=dict(v1="v1val", v2="v2val", v3="v3val"))
    v = AnsibleJ2Vars(templar=t, globals=dict(g1="g1val", g2="g2val", g3="g3val"))

    # Simple case
    assert v["v1"] == "v1val"
    assert v["g1"] == "g1val"

    # Container item
    assert v["v2"] == ["v2val"]
    assert v["g2"] == ["g2val"]

    # Unsafe
    assert v["v3"] == "v3val"
    assert v

# Generated at 2022-06-23 13:29:04.753698
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Class used for test
    class TemplarTest:
        available_variables = {'foo': 'bar'}
        def __init__(self):
            self.result = None
        def template(self, value):
            self.result = value
            return value
    locals_test = {'l_foo': 'bar'}
    globals_test = {'g_foo': 'bar'}
    # Test 
    templar = TemplarTest()
    test = AnsibleJ2Vars(templar, globals_test, locals=locals_test)
    # Test 1
    assert test.__contains__('foo') == True
    # Test 2
    assert test.__contains__('l_foo') == True
    # Test 3
    assert test.__contains__('g_foo') == True


# Generated at 2022-06-23 13:29:16.083203
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import add_directory
    from ansible.galaxy.api import GalaxyAPI
    from mock import Mock

    galaxy_api = GalaxyAPI(Mock(), Mock())
    templar = Templar(loader=None, variables=VariableManager(), shared_loader_obj=galaxy_api, fail_on_undefined=True)


# Generated at 2022-06-23 13:29:26.503741
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    try:
        from ansible.plugins.loader import vars_loader
        assert vars_loader != None
    except ImportError:
        from ansible.plugins import vars_loader
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    variable_manager = vars_loader.VarsModule()
    variable_manager.add_directory("./lib/ansible/plugins/vars")
    variable_manager.add_directory("./lib/ansible/plugins/filter")
    variable_manager.add_directory("./lib/ansible/plugins/lookup")
    variable_manager.add_directory("./lib/ansible/plugins/tests")
    variable_manager.all = {}
    variable_manager

# Generated at 2022-06-23 13:29:37.119169
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    Test function to confirm the constructor of AnsibleJ2Vars class and
    test the overridden methods __contains__ and __getitem__ and the methods
    add_locals and __iter__.
    '''
    templar = None
    globals = dict(var1 = 'value1', var2 = 'value2', var3 = 'value3')
    locals  = dict(var4 = 'value4', var5 = 'value5', var6 = 'value6')
    test_vars = AnsibleJ2Vars(templar, globals, locals)

    # test __contains__
    for k,v in iteritems(globals):
        assert k in test_vars
    for k,v in iteritems(locals):
        assert k in test_vars

# Generated at 2022-06-23 13:29:39.633458
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert len(AnsibleJ2Vars(None, None)) == 0

# Generated at 2022-06-23 13:29:44.251150
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    dict1 = dict(key1="value1")
    dict2 = dict(key2="value2")
    dict3 = dict(key3="value3")

    vars = AnsibleJ2Vars(None, dict1, dict2)
    vars.update(dict3)

    assert set(vars) == set(dict1.keys()) | set(dict2.keys()) | set(dict3.keys())


# Generated at 2022-06-23 13:29:49.177060
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible import templar
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    AnsibleJ2Vars(Templar(VariableManager()), {})

# Generated at 2022-06-23 13:29:58.798679
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    import unittest

    class Test_AnsibleJ2Vars(unittest.TestCase):

        def setUp(self):
            # Setup test environment
            class TestTemplar:
                available_variables = dict()

            self.test_templar = TestTemplar()
            self.test_globals = dict()
            self.test_locals = dict()

            self.test_ansible_j2vars = AnsibleJ2Vars(self.test_templar, self.test_globals, locals=self.test_locals)
            self.test_locals['local_var_1'] = 'local_value_1'


        def test_add_locals(self):
            # Test simple values
            new_ansible_j2vars = self.test_ans

# Generated at 2022-06-23 13:30:04.045358
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.template import Templar

    j2vars = AnsibleJ2Vars(Templar(), globals={}, locals={})

    new_locals = {'k1': 'v1', 'k2': 'v2'}
    new_j2vars = j2vars.add_locals(new_locals)

    assert new_j2vars._locals == new_locals
    assert new_j2vars._templar is j2vars._templar

    new_j2vars = j2vars.add_locals(None)
    assert new_j2vars._locals is j2vars._locals

    # j2vars should not be modified by add_locals call

# Generated at 2022-06-23 13:30:12.424787
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''The constructor for AnsibleJ2Vars is tested here.'''

    from ansible.template import Templar

    templar = Templar(loader=None)

    expected_locals = {'key1': 'value1', 'key2': 'value2'}
    expected_globals = {'key3': 'value3', 'key4': 'value4'}

    ajv = AnsibleJ2Vars(templar, expected_globals, locals=expected_locals)

    assert(len(ajv) == 4)
    assert(ajv.__contains__('key1'))
    assert(ajv.__contains__('key2'))
    assert(ajv.__contains__('key3'))
    assert(ajv.__contains__('key4'))


# Generated at 2022-06-23 13:30:22.110550
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    host_vars = HostVars(host_name="localhost")
    host_vars["key0"] = 0
    host_vars["key1"] = 1
    host_vars["key2"] = 2
    templar.available_variables = host_vars
    globals = {"key3": 3}
    locals = {"key4": 4}
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals=locals)
    len_ansible_j2_vars = len(ansible_j2_vars)
    assert len_ansible_j2_vars == 5

# Unit test

# Generated at 2022-06-23 13:30:34.206812
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    Test whether class AnsibleJ2Vars initializes properly.
    '''

    try:
        import ansible.module_utils.common.collections
        HAS_COLLECTIONS_COMPAT = True
    except ImportError:
        HAS_COLLECTIONS_COMPAT = False

    # Mocking up the template
    templar = None
    globals = {"g_var": 42}
    locals = {"l_var": 99}

    # Initialize a AnsibleJ2Vars object class
    ansibleJ2Vars = AnsibleJ2Vars(templar, globals, locals)

    # Testing whether the AnsibleJ2Vars object class initializes properly
    if not HAS_COLLECTIONS_COMPAT:
        assert ansibleJ2Vars._templar == templar
       

# Generated at 2022-06-23 13:30:41.229719
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import vars_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import BaseInventory
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    loader = DataLoader()
    inventory = BaseInventory(loader=loader)
    templar = Templar(loader=loader, variables=inventory.get_vars(host=None))

    inventory.add_group(Group('webservers'))
    inventory.add_group(Group('database'))
    inventory.add_

# Generated at 2022-06-23 13:30:52.052633
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Create object without locals
    templar = AnsibleJ2Vars(None, dict(), dict())
    templar_with_locals = templar.add_locals(dict())
    assert isinstance(templar_with_locals, AnsibleJ2Vars)
    assert templar_with_locals._locals == dict()
    # Pass locals parameter to AnsibleJ2Vars.add_locals()
    templar_with_locals = templar.add_locals({"local_variable": "local_value"})
    assert isinstance(templar_with_locals, AnsibleJ2Vars)
    assert templar_with_locals._locals == {"local_variable": "local_value"}

# Generated at 2022-06-23 13:31:03.770285
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template.vars import AnsibleJ2Vars
    import ansible.parsing.vault as vault
    from ansible.utils.vars import combine_vars

    av = {'item': "test"}
    tv = vault.VaultAES256(b=['vault_test'])
    vtp = AnsibleJ2Vars(tv, {}, locals={'item': "test"})

    # Item is in locals
    assert (vtp.__contains__(key='item')) is True

    # Item is in vars
    assert (vtp.__contains__(key='vars')) is True

    # Item is in available_variables

# Generated at 2022-06-23 13:31:10.408203
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from random import randint
    from copy import deepcopy

    def randValue(min_, max_):
        r = randint(min_, max_)
        return r

    def getRandArray(min_, max_, len_):
        arr = []
        for i in range(0, len_):
            arr.append(randValue(min_, max_))
        return arr

    class TestClass:
        def __init__(self, count):
            self.count = count

        def __len__(self):
            return self.count


# Generated at 2022-06-23 13:31:16.677691
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, dict(), dict(a="c"))
    assert dict(a="c") == j2vars.add_locals(dict(b="d"))
    assert dict(a="c", b="d") == j2vars.add_locals(dict(b="d"))

# Generated at 2022-06-23 13:31:27.129429
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import os

    # Setup ansible.cfg to pick up the ansible loaders plugin path
    os.environ['ANSIBLE_CONFIG'] = os.path.join(os.path.dirname(os.path.dirname(__file__)), "ansible.cfg")

    # Get loader object
    loader = DataLoader()

    # Setup variable manager object
    variable_manager = VariableManager()

    # Setup templar object
    templar = Templar(loader=loader, variable_manager=variable_manager)

    # First, call the constructor
    vars_proxy = AnsibleJ2Vars(templar, None)

# Generated at 2022-06-23 13:31:38.598399
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar, Dictable
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Test template
    # Note:  The HostVars instance is an example of an unsafe class
    test_dict = dict(
        local_var = 'local val',
        key = 'val',
        my_hostvar = HostVars(),
        vars = dict(
            var = 'varval',
            my_hostvar = HostVars(),
        ),
    )

    test_templar = Templar(loader=None)

    # List of returned values to be tested

# Generated at 2022-06-23 13:31:47.337370
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.template
    templar = ansible.template.Templar()
    locals = {"values": ["v1", "v2", "v3"]}

    j2vars = AnsibleJ2Vars(templar, None, locals)
    assert "values" in j2vars

    j2vars = AnsibleJ2Vars(templar, {"value": "v4"}, locals)
    assert "value" in j2vars

    templar.available_variables = {"value": "v5"}
    j2vars = AnsibleJ2Vars(templar, None, locals)
    assert "value" in j2vars

    j2vars = AnsibleJ2Vars(templar, None, None)
    assert "value" in j2vars


#

# Generated at 2022-06-23 13:31:58.993511
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar

    # Case 1: Invalid variable
    templar = Templar(loader=None)
    globals = {}
    locals = {}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    try:
        ajv.__getitem__("invalid_variable")
        assert(False)
    except Exception as e:
        assert(type(e) == KeyError and e.args[0] == "invalid_variable")

    # Case 2: Valid variable
    templar = Templar(loader=None)
    globals = {}
    locals = {}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    ret = ajv.__getitem__("ansible_verbosity")
    assert(ret == 0)

# Generated at 2022-06-23 13:32:04.803319
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = None
    globals = {}
    locals = None

    ansible_j2vars_object = AnsibleJ2Vars(templar, globals, locals)
    len_result = len(ansible_j2vars_object)
    print(len(ansible_j2vars_object))
    print(len_result)


# Generated at 2022-06-23 13:32:13.583406
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.compat.tests import unittest
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import unsafe_proxy_wrap

    class TestCase(unittest.TestCase):

        def test_getitem_with_dict(self):
            self.assertEquals(vars_proxy['vars'], VARS)
            self.assertEquals(vars_proxy['vars']['x'], 10)

        def test_getitem_with_HostVars(self):
            self.assertEquals(vars_proxy['HostVars'], HostVars())


# Generated at 2022-06-23 13:32:22.918350
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    test_list = ['test_1', 'test_2']
    test_dict = {'test_1':'a', 'test_2':'b'}
    test_globals = {'test_0':'c', 'test_1':'d'}
    test_locals = {'test_2':'e', 'test_3':'f'}
    test_AnsibleJ2Vars = AnsibleJ2Vars(test_list, test_globals, test_locals)
    assert(test_AnsibleJ2Vars.__contains__('test_2'))
    assert(test_AnsibleJ2Vars.__contains__('test_3'))
    assert(test_AnsibleJ2Vars.__contains__('test_2') != False)


# Generated at 2022-06-23 13:32:32.740455
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template.template import Templar, AnsibleEnvironment
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    env_args = {
        'variable_start_string': '${',
        'variable_end_string': '}',
        'block_start_string': '${{',
        'block_end_string': '}}',
    }

    templetor = Templar(loader=None, variables={}, env=AnsibleEnvironment(**env_args))

    globals = {'test_globals': 1}
    locals = {'test_locals': 2}
    ansible_j2_vars = AnsibleJ2Vars(templetor, globals, locals)

    # AnsibleUnsafeText is not an

# Generated at 2022-06-23 13:32:39.771026
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar, get_j2_environment

    variable_manager = VariableManager()
    loader = DataLoader()

    environment = get_j2_environment()
    environment.filters.update(loader.template_filters)
    templar = Templar(loader=loader, variables=variable_manager, environment=environment)

    # Test __init__
    vars = AnsibleJ2Vars(templar, globals=dict())
    assert vars._templar == templar
    assert vars._globals == dict()
    assert vars._locals == dict()

    # Test __contains__
    assert not ('foo' in vars)

# Generated at 2022-06-23 13:32:44.571166
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class test_templar(object):
        def __init__(self):
            self.available_variables = dict()
            self.available_variables['v1'] = 'test'
            self.available_variables['v3'] = 'test'

    class test_var(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value
        def __str__(self):
            return self.name

    v1 = test_var('v1', 'test1')
    v2 = test_var('v2', 'test2')
    v3 = test_var('v3', 'test3')

    dglobals = dict()
    dglobals['g1'] = v1
    dglobals['g2'] = v2

    d

# Generated at 2022-06-23 13:32:51.281494
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    class AnsibleJ2VarsTest(AnsibleJ2Vars):
        def __init__(self, templar, globals, locals):
            self._templar = templar
            self._globals = globals
            self._locals = locals

    # Test 1
    vars_mgr = VariableManager()
    loader = DataLoader()
    play_context = PlayContext()
    play_context.network_