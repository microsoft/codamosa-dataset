

# Generated at 2022-06-23 13:22:51.043727
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    pass

# Generated at 2022-06-23 13:23:02.664395
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    j2v1 = AnsibleJ2Vars(Templar(), {'product': 'Ansible'})
    j2v1.add_locals({'version': 2.0})
    assert j2v1['product'] == 'Ansible'
    assert j2v1['version'] == 2.0
    j2v2 = j2v1.add_locals({'branch': 'devel'})
    assert j2v1['product'] == 'Ansible'
    assert j2v1['version'] == 2.0
    assert 'branch' not in j2v1
    assert j2v2['product'] == 'Ansible'
    assert j2v2['version'] == 2.0

# Generated at 2022-06-23 13:23:11.035165
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar(loader=None)

    av = dict(a=1, b=2)
    lv = dict(l_c=3)
    gv = dict(g_d=4)

    test_obj = AnsibleJ2Vars(templar, gv, lv)

    assert 'a' in test_obj
    assert 'b' in test_obj
    assert 'l_c' in test_obj
    assert 'c' not in test_obj
    assert 'g_d' not in test_obj
    assert 'd' not in test_obj
    assert 'not_exist' not in test_obj



# Generated at 2022-06-23 13:23:19.111048
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    templar = Templar(loader=None, variables=None)
    t1 = { 'a': 1 }
    t2 = { 'b': 2 }
    t3 = { 'c': 3 }
    t4 = { 'd': 4 }
    variables = combine_vars(t1,t2)
    variables = combine_vars(variables, t3)
    variables = combine_vars(variables, t4)

    assert AnsibleJ2Vars(templar,variables).get('a') == 1

# Generated at 2022-06-23 13:23:29.737542
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    templar      = Templar(loader=None, variables=play_context)

    # Successful runs
    proxy = AnsibleJ2Vars(templar, {}, {'l_foo':'bar'})
    assert proxy['foo'] == 'bar'

    # Unsuccessful runs
    try:
        proxy['undefined']
    except KeyError as e:
        assert str(e) == "undefined variable: undefined"
    except Exception:
        assert False

    # Expected error message when the variable is undefined
    # context is the same as var_name because the variable name is not available.
    # This happens when the variable is referenced in a string which is passed
    # to a function like "{{ myfunc(var_name) }}

# Generated at 2022-06-23 13:23:37.731501
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'foo': 'bar'})
    play_context = PlayContext()
    play_context._set_task_and_variable_override({'foo': 'bar'})
    ajvars = AnsibleJ2Vars(templar, {'foo': 'bar'}, locals=play_context)
    assert iter(ajvars) is not None
    ajvars = AnsibleJ2Vars(templar, {}, locals=play_context)
    assert iter(ajvars) is not None
    play_context._set_task_and_variable_override({})

# Generated at 2022-06-23 13:23:42.725383
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    import json

    # create Templar and AnsibleJ2Vars objects
    tmplr = Templar(loader=None)
    globals = { "g_global1": "global_value1_from_dict" }
    # Check it for empty locals
    vars = AnsibleJ2Vars(tmplr, globals, locals=None)
    assert len(vars) == 1
    assert "g_global1" in vars
    assert vars["g_global1"] == "global_value1_from_dict"
    # Check it for existing locals
    locals = { "l_local1": "local_value1_from_dict" }
    vars = AnsibleJ2Vars(tmplr, globals, locals=locals)

# Generated at 2022-06-23 13:23:54.332746
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    an_dict = {"a": 1, "b": 2, "c": 3}
    an_dict2 = {"b": 2, "c": 3}
    templar = Templar(loader=None, shared_loader_obj=None)
    an_obj = AnsibleJ2Vars(templar, an_dict)
    print("len(AnsibleJ2Vars(templar, an_dict)) = %s" % len(an_obj))
    an_obj = AnsibleJ2Vars(templar, an_dict2, locals=an_dict2)

# Generated at 2022-06-23 13:24:03.675380
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    def get_loader(base_dir):
        loader = DataLoader()
        inventory_manager = InventoryManager(loader=loader, sources='localhost,')
        variable_manager = VariableManager(loader=loader, inventory=inventory_manager)


# Generated at 2022-06-23 13:24:13.814374
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import jinja2

    loader = DataLoader()
    jenv = jinja2.Environment(loader=loader, undefined=jinja2.StrictUndefined)
    my_loader = jenv.get_template("hello.j2").module.ansible_loader
    templar = Templar(loader=my_loader, shared_loader_obj=loader, variables={})
    aj2v = AnsibleJ2Vars(templar, safe_eval)
    # The constructor has successfully created an AnsibleJ2Vars object.  Now test that it works.
    assert("ansible_hostname" in aj2v)

# Generated at 2022-06-23 13:24:14.817246
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert False, "Test not implemented"


# Generated at 2022-06-23 13:24:20.361023
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = object()
    globals = { 'c_foo':'foo', 'c_bar':'bar' }
    locals = { 'l_foo':'foo', 'l_bar':'bar' }

    a = AnsibleJ2Vars(templar, globals, locals)
    assert len(a) == 4     # len of {'c_foo', 'c_bar', 'l_foo', 'l_bar'}



# Generated at 2022-06-23 13:24:21.763311
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    Test function __len__ of class AnsibleJ2Vars
    '''
    # TODO write unit test
    pass


# Generated at 2022-06-23 13:24:29.217587
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    Ensure that AnsibleJ2Vars.__iter__ returns a correct list
    '''
    templar = None
    globals = {'one': 1, 'two': 2, 'three': 3}
    locals = {'four': 4, 'five': 5}
    vars = AnsibleJ2Vars(templar, globals, locals)

    assert sorted(list(vars)) == ['five', 'four', 'one', 'three', 'two']


# Generated at 2022-06-23 13:24:38.973531
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-23 13:24:39.881362
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    pass



# Generated at 2022-06-23 13:24:49.484795
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, globals=dict())

    # empty dict
    dict_keys = dict(j2vars).keys()
    if dict_keys:
        raise AssertionError("expected empty dict, but got '%s'" % dict_keys)

    # populated dict
    j2vars._locals = dict(foo='bar')
    dict_keys = dict(j2vars).keys()
    if 'foo' not in dict_keys:
        raise AssertionError("expected 'foo' in dict, but got '%s'" % dict_keys)

    # check unsafe proxy
    j2vars._

# Generated at 2022-06-23 13:24:53.751658
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    """
    AnsibleJ2Vars.__len__
    """
    # ansible.utils.unsafe_proxy.AnsibleUnsafeText object
    # ansible.utils.unsafe_proxy.AnsibleUnsafeText('foo')
    assert len(AnsibleJ2Vars()) == 2

# Generated at 2022-06-23 13:25:02.821721
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    # Variable "local" is being defined in the line below
    assert_equals("local", AnsibleJ2Vars(Templar(), {}, {}).add_locals({"local": 1})['local'])
    # Variable "foo" is defined in the line below
    foo = {"foo": "foo", "bar": "bar"}
    # Variable "local" is not being defined in the line below
    assert_equals("foo", AnsibleJ2Vars(Templar(), {}, {}).add_locals({"local": 1, "foo": foo})['foo']['foo'])

if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule, missing
    from ansible.template import Templar

# Generated at 2022-06-23 13:25:14.361754
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.templating.jinja2.environment import Environment
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    vars_manager = VariableManager()
    env = Environment(loader=loader, variable_manager=vars_manager, undefined=None)
    templar = env.get_template("").module

    # Fake AnsibleModule instance
    class FakeAnsibleModule():
        def __init__(self):
            self._name = "template"
            self._ansible_version = "fake version"
            self.params = {}
            self.args = {}
            self.fail_json = False

    fake_ansible_module = FakeAnsibleModule()

# Generated at 2022-06-23 13:25:21.789349
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template import Templar

    vars_dict = dict(
        k1="v1",
        k2=["v2","v3"],
        k3=dict(k4="v4")
    )
    j2vars = AnsibleJ2Vars(Templar(loader=None), unsafe_eval(str(vars_dict)))
    res_list = [
        ("k1", True),
        ("k2", True),
        ("k3", True),
        ("k4", True),
        ("k5", False)
    ]


# Generated at 2022-06-23 13:25:32.053126
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    templar = Templar(loader=None)
    template_uid = 12345
    template_vars = dict(foo=1, bar='2', baz=AnsibleUnicode('3'))

    ans = AnsibleJ2Vars(templar, globals=dict(), locals=dict(l_foo=1, l_bar='2', l_baz=AnsibleUnicode('3')))
    assert (ans[u'foo'] == template_vars[u'foo'])
    assert (ans[u'bar'] == template_vars[u'bar'])
    assert (ans[u'baz'] == template_vars[u'baz'])

# Generated at 2022-06-23 13:25:37.758726
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import sys
    import os
    import os.path
    import pytest
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'mazer'))
    from units.mock.loader import DictDataLoader

    # define test variables
    variable = 42
    variables = dict(foo = variable)
    globals = dict(bar = variable)

    # define mocks
    class mock_templar():
        class j2_env():
            class globals():
                pass
        def __init__(self):
            self.templar = None
            self.loader = None
            self.j2_env = None
            self.available_variables = dict()
        def template(self, arg):
            return arg

# Generated at 2022-06-23 13:25:43.811997
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {
        'a': 1,
    }
    locals = {
        'c': 3,
        'l_d': 4,
    }
    jvars = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in jvars
    assert 'c' in jvars
    assert 'd' in jvars
    assert 'e' not in jvars
    assert not 'e' in jvars


# Generated at 2022-06-23 13:25:53.282759
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader, module_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost')
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='Hello Ansible Module World')))
            ]
        )

# Generated at 2022-06-23 13:26:04.903780
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)

    globals = dict()
    locals = dict()
    aj2vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'foo' not in aj2vars
    aj2vars._locals['foo'] = 'bar'
    assert 'foo' in aj2vars
    aj2vars._templar.available_variables['foo'] = 'baz'
    assert 'foo' in aj2vars
    aj2vars._globals['foo'] = 'buzz'
    assert 'foo' in aj2vars


# Generated at 2022-06-23 13:26:12.596378
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence

    templar = Templar()
    j2Vars = AnsibleJ2Vars(templar, {})
    assert j2Vars["foo"] == None
    assert j2Vars["foo"]["bar"] == None

    templar.available_variables = { "foo" : "bar" }
    assert j2Vars["foo"] == "bar"
    assert j2Vars["foo"]["bar"] == None

    templar.available_variables = { "foo" : AnsibleVaultEncryptedUnicode('foo') }
    assert j2Vars["foo"] == 'foo'

# Generated at 2022-06-23 13:26:24.211483
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import unittest2 as unittest
    from ansible.template import Templar

    templar = Templar(None)
    globals = dict()
    locals = dict()
    aj2v = AnsibleJ2Vars(templar, globals, locals)

    class AnsibleJ2VarsTestCase(unittest.TestCase):
        '''
        ansible.template.vars.AnsibleJ2Vars: method __iter__ testing case
        '''

        def test__AnsibleJ2Vars___iter__(self):
            '''
            ansible.template.vars.AnsibleJ2Vars: method __iter__
            '''
            iter_obj = iter(aj2v)
            self.assertIsInstance(iter_obj, object)

# Generated at 2022-06-23 13:26:34.923324
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    t = Templar()
    t.vars = dict(one=1, two=2, three=3)
    t.set_available_variables(dict(one='1', two='2', three='3'))
    t.set_available_variables(dict(four=4, five=5, six=6))
    t.set_available_variables(dict(seven=7, eight=8, nine=9))
    vars = AnsibleJ2Vars(t, dict(ten=10, eleven=11, twelve=12))
    assert len(vars) == 12, 'AnsibleJ2Vars instance __len__ should return 12'

# Generated at 2022-06-23 13:26:47.786412
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = {'global1': 'global1', 'global2': 'global2'}
    locals = {'local1': 'local1', 'local2': 'local2'}
    ansible_vars = {'a': 'a', 'b': 'b'}

    av_proxy = dict()
    class Templar(object):
        available_variables = ansible_vars

        def template(self, value):
            if value in av_proxy:
                return av_proxy[value]
            else:
                return value

    templar = Templar()
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 6

    expected_keys = set()
    expected_keys.update(vars._locals)
    expected

# Generated at 2022-06-23 13:26:58.274583
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template.templar import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(name="debug", debug="var=hostvars"),
        ]
    )

    inventory = InventoryManager(loader=None,  sources=['127.0.0.1'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

# Generated at 2022-06-23 13:26:59.412882
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    pass


# Generated at 2022-06-23 13:27:07.132382
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    import pickle

    # use pickle to deserialize the values generated by ansible itself
    # https://docs.python.org/3/library/pickle.html#data-stream-format
    stream = b'\x80\x03csansible.parsing.vaultU\x80\x02\x88.'
    stream += b'\x80\x03\x86\x19\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00.'

# Generated at 2022-06-23 13:27:12.501942
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    A = AnsibleJ2Vars(None, globals=dict(), locals=dict())
    B = A.add_locals(dict(var1='val1'))
    assert B._locals == dict(var1='val1')
    C = B.add_locals(dict(var2='val2'))
    assert C._locals == dict(var1='val1', var2='val2')

# Generated at 2022-06-23 13:27:18.410763
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    data = [('a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5)]
    templar = Templar(loader=None, variables=dict())
    a = AnsibleJ2Vars(templar, dict(data))
    assert sorted(a) == sorted(x[0] for x in data)



# Generated at 2022-06-23 13:27:23.599283
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    vars = {'a': 1, 'b': 2, 'c': 3}
    globals = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    len_vars = len(AnsibleJ2Vars(None, vars))
    len_globals = len(AnsibleJ2Vars(None, globals))
    assert len_vars == len_globals

# Generated at 2022-06-23 13:27:35.434870
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from jinja2.utils import missing
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Setup AnsibleJ2Vars object, with dummy data
    variables = dict(
        one=1, two=2,
        three="{{four}}",
        four=4,
        l_bla="bla"
    )
    templar = Templar(DataLoader(), variables=variables)
    vars_obj = AnsibleJ2Vars(templar, dict(), locals=dict())

    # Assert that "one" is contained in the object
    assert 'one' in vars_obj

    # Assert that "l_bla" is contained in the object
    assert 'l_bla' in vars

# Generated at 2022-06-23 13:27:43.888112
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # ansible_foo={'bar':'baz'} should be in _templar.available_variables
    templar = Templar(loader=None, variables={'ansible_foo':{'bar':'baz'}})
    proxy = AnsibleJ2Vars(templar, {'ansible_foo':{'bar':'baz'}})
    assert 'ansible_foo' in proxy
    # ansible_foo={'bar':'baz'} should be accessible via proxy
    assert proxy['ansible_foo'] == {'bar':'baz'}
    # locals={'ansible_foo':'not a dict'} should be in _locals, not _templar.available_variables

# Generated at 2022-06-23 13:27:48.780337
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar  = None
    globals  = { 'g1':'g1_value'}
    locals   = { 'l1':'l1_value'}
    var_name = 'g1'

    ansible_vars = AnsibleJ2Vars(templar, globals, locals=locals)

    assert var_name in ansible_vars

    var_name = 'l1'
    assert var_name in ansible_vars

# Generated at 2022-06-23 13:27:59.692794
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(None, loader=DataLoader())
    locals = {}
    globals = {}

    vars = AnsibleJ2Vars(templar, globals, locals=locals)

    locals['l_key1'] = 'l_value1'
    locals['l_key2'] = 'l_value2'
    locals['context'] = 'context'
    locals['environment'] = 'environment'
    locals['template'] = 'template'

    keys = set()
    for key in vars:
        keys.add(key)

    assert set(['l_key1', 'l_key2']) == keys



# Generated at 2022-06-23 13:28:08.430620
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    v = {"v1":"v1_value","v2":"v2_value"}
    g = {'g1': 'g1_value', 'g2': 'g2_value'}
    l = {'l1': 'l1_value', 'l2': 'l2_value'}

    av = AnsibleJ2Vars(None, g, l)
    assert 'v1' in av, "v1 should not be in av"
    assert 'g1' in av, "g1 should not be in av"
    assert 'l1' in av, "l1 should not be in av"
    assert 'v2' not in av, "v2 should not be in av"
    assert 'g2' not in av, "g2 should not be in av"

# Generated at 2022-06-23 13:28:13.531988
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    Test AnsibleJ2Vars.__init__
    '''
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    variables = AnsibleJ2Vars(templar, globals={})
    assert isinstance(variables, Mapping)

# Generated at 2022-06-23 13:28:21.572287
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils import plugin_docs

    try:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    except ImportError:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def test_AnsibleJ2Vars___len__():

        variable_manager = VariableManager()
        variable_manager.extra_vars = variable_manager.load_extra_vars(loader=None, variables=None)
        variable_manager.options_vars = variable_manager.load_options_vars(variable_manager.extra_vars)

# Generated at 2022-06-23 13:28:31.752802
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    ''' Test for AnsibleJ2Vars().__iter__ '''

    class DummyTemplar():
        def __init__(self):
            self.available_variables = {}
        def template(self, jinja_object):
            return jinva_object

    from collections import OrderedDict
    vars_proxy = AnsibleJ2Vars(DummyTemplar(), globals={}, locals={})


# Generated at 2022-06-23 13:28:38.882286
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible import templar

    globals = { 'g': 1 }
    locals = { 'l': 2 }
    vars = { 'v': 3 }
    templar.set_available_variables(vars)

    v = AnsibleJ2Vars(templar, globals, locals)

    assert len(v) == len(set(vars.keys()).union(set(locals.keys())).union(set(globals.keys())))

# Generated at 2022-06-23 13:28:47.125340
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    inventory = [{"hostname":"hostname1","vars": HostVars({"hostvars1":"var1","hostvars2":"var2"})},
                 {"hostname":"hostname2","vars": HostVars({"hostvars3":"var3","hostvars4":"var4"})}]
    templar = Templar(loader=None, variables=inventory)
    globals_vars = dict(globals1="var1",globals2="var2")
    locals_vars = dict(locals1="var1",locals2="var2")

    j2vars = AnsibleJ2Vars(templar, globals_vars, locals_vars)
    vars_keys

# Generated at 2022-06-23 13:28:55.060539
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy

    loader = DataLoader()
    templar = Templar(loader=loader, variables={})
    host = Host(name='example')
    variable_manager = VariableManager(loader=loader, inventory=InventoryManager(loader=loader, sources=[]))
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=[]))
    variable_manager.add_host_variable(host, 'var1', 'value1')
   

# Generated at 2022-06-23 13:29:02.770633
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.inventory.host import Host

    host = Host(name="foo")
    templar = Templar(loader=None, variables=dict(foo='bar'), host=host)
    v = AnsibleJ2Vars(templar, globals=dict(baz="qux"))

    assert 'baz' in v
    assert v['baz'] == "qux"
    assert 'foo' in v
    assert v['foo'] == "bar"

# Generated at 2022-06-23 13:29:14.834470
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=None)
    vm = VariableManager()
    vm.set_fact = lambda x: x
    vm.set_host_variable = lambda x, y: x
    vm.set_task_and_generator_vars = lambda x, y, z: x
    vm.set_nonpersistent_facts = lambda x: x
    templar.set_available_variables(vm.get_vars(loader=None, play=None))

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test1': 'test1', 'test2': 'test2'}

# Generated at 2022-06-23 13:29:23.404374
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    mock_templar = Templar(None, None)
    varname = "ab"
    locals = {'ab': 1}
    globals = {'bc': 2, 'cd': 3}
    mock_ansible_j2_vars = AnsibleJ2Vars(mock_templar, globals, locals)
    mock_ansible_j2_vars.__contains__(varname)
    assert varname in mock_ansible_j2_vars

# Generated at 2022-06-23 13:29:27.295506
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'test': 'test'}
    vars_ = AnsibleJ2Vars(templar, globals=globals)
    assert "test" in vars_
    assert not "made_up_key" in vars_



# Generated at 2022-06-23 13:29:35.665026
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """
    Test the __iter__ method of the AnsibleJ2Vars class
    """
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_mgr = VariableManager()

    j2_vars = AnsibleJ2Vars(Templar(loader=loader, variables=variable_mgr), {}, {})
    for key, item in j2_vars.items():
        assert False, "There is unexpected item (key %s) in AnsibleJ2Vars" % str(key)

# Generated at 2022-06-23 13:29:36.718210
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass


# Generated at 2022-06-23 13:29:43.380990
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    avail_vars = {'a': 1, 'b': 2, 'c': 3}
    globals = {'d': 4, 'e': 5, 'f': 6}
    locals = {'g': 7, 'h': 8, 'i': 9}
    proxy = AnsibleJ2Vars(Templar(variables=avail_vars), globals, locals)
    if not ('a' in proxy):
        assert False, "__contains__ did not find key 'a' in proxy"
    if not ('b' in proxy):
        assert False, "__contains__ did not find key 'b' in proxy"
    if not ('c' in proxy):
        assert False, "__contains__ did not find key 'c' in proxy"

# Generated at 2022-06-23 13:29:44.219496
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert()

# Generated at 2022-06-23 13:29:56.119272
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.host import Host

    templar = Templar(loader=DataLoader())
    host = Host(name='localhost')

# Generated at 2022-06-23 13:30:05.522227
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    obj = AnsibleJ2Vars(Templar(VariableManager()), locals={}, globals={})
    obj.add_locals({'l_test': {'test1': 1, 'test2': 2, 'test3': 3}})
    assert len(obj) == 3
    obj.add_locals({'l_test': 3})
    assert len(obj) == 4

# Generated at 2022-06-23 13:30:13.127411
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template.templar import Templar
    from ansible.template import Jinja2Environment

    t = Templar(loader=None, variables={'foo': 'bar', 'baz': 'baz'})
    j2e = Jinja2Environment()
    j2e.globals['range'] = range
    # getattr(UnsafeProxy, '__UNSAFE__') fails in Python 3.5 (we are using Python 3.5 in the CI)
    # the following workaround is found in https://github.com/ansible/ansible/pull/20187/
    unsafe = UnsafeProxy('somestring')
    unsafe.__UNSAFE__ = True
    # end of

# Generated at 2022-06-23 13:30:20.998443
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    errmsg = '__contains__ of class AnsibleJ2Vars should be working properly'

    d = dict()
    d['a'] = 1
    d['b'] = 2
    d['c'] = 3

    j2v = AnsibleJ2Vars(None, d)

    if 'a' not in j2v:
        raise AssertionError(errmsg)

    if 'b' not in j2v:
        raise AssertionError(errmsg)

    if 'c' not in j2v:
        raise AssertionError(errmsg)


# Generated at 2022-06-23 13:30:21.668885
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    assert True # FIXME

# Generated at 2022-06-23 13:30:33.139890
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(None, loader=None)
    import collections
    globals = collections.defaultdict(dict)
    tests = [
        {'locals': {'a': 1}, 'expected': 1},
        {'locals': {'a': 1, 'b': 2}, 'expected': 2},
        {'locals': {'b': 2}, 'expected': 1},
        {'locals': {'b': 2, 'z': 26}, 'expected': 2},
    ]
    for test in tests:
        assert len(AnsibleJ2Vars(templar, globals, locals=test['locals'])) == test['expected']


# Generated at 2022-06-23 13:30:43.614517
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from unit.mock.templar import Templar
    from unit.mock.loader import DictDataLoader

    loader = DictDataLoader({
        "test.j2": "{% if test %}foo{% endif %}",
        "other.j2": "{% include 'test.j2' %}",
        "fail.j2": "{{ test }}",
    })
    templar = Templar(loader=loader)

    variables = {
        "test": "my_value",
    }

    # test the templated version
    proxy = AnsibleJ2Vars(templar, variables)
    assert proxy["test"] == "my_value"
    assert proxy["fail"] == "{{ test }}" # we don't template expressions that don't include a template

    # test the templated version

# Generated at 2022-06-23 13:30:53.599957
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)

    options = dict(
        hostfile='',
        listhosts='',
        subset='',
        syntax='',
        connection='',
        module_path='',
        forks='',
        remote_user='',
        private_key_file='',
        ssh_common_args='',
        sftp_extra_args='',
        scp_extra_args='',
        ssh_extra_args='',
        verbosity='',
        check='',
        diff='',
    )
    templar.set_available_variables(C.config.get_config_value('DEFAULT_HOST_LIST', variables=options))

    # create a demo ajs

# Generated at 2022-06-23 13:31:05.088315
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    print("Constructor AnsibleJ2Vars")
    import ansible.playbook.play
    import ansible.template.template
    import ansible.parsing.yaml.objects
    import ansible.vars.unsafe_proxy
    my_play = ansible.playbook.play.Play()
    my_play.__setattr__('_variable_manager', ansible.vars.manager.VariableManager())
    templar = ansible.template.template.Templar(loader=None, variables=AnsibleJ2Vars(my_play._variable_manager.get_vars(
    ), {}, {'test_var': 'test_val'}))
    templar.set_available_variables(my_play._variable_manager.get_vars())

# Generated at 2022-06-23 13:31:07.473897
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # Execute code
    ansible_j2_vars = AnsibleJ2Vars('templar','globals','locals')
    # check if the instance is created properly
    assert ansible_j2_vars != None

# Generated at 2022-06-23 13:31:14.671575
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'var1': '1', 'var2': '2'})
    globals = {'gvar1': '3', 'gvar2': '4'}
    locals = {'lvar1': '5', 'lvar2': '6'}
    j2v = AnsibleJ2Vars(templar, globals, locals)
    assert 'var1' in j2v
    assert 'lvar2' in j2v
    assert 'gvar1' in j2v
    assert 'gvar2' in j2v
    assert 'wrong' not in j2v
    assert 'wrong' not in locals
    assert 'wrong' not in globals
    assert 'wrong' not in templar.available_variables
#

# Generated at 2022-06-23 13:31:17.984851
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    obj = AnsibleJ2Vars(1, 2, 3)
    assert obj._templar == 1
    assert obj._globals == 2
    assert obj._locals == 3

# Generated at 2022-06-23 13:31:19.043487
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # TODO
    pass


# Generated at 2022-06-23 13:31:28.532298
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.template
    t = ansible.template.AnsibleJ2TemplateModule(None, None, None, None, None)

    globals = { 'a': 1, 'b': 2 }
    locals = { 'c': 3, 'd': 4, 'l_e': 5, 'l_f': 6, 'l': 7, 'context': 8, 'environment': 9, 'template': 10 }
    orig_vars = { 'a': 1, 'b': 2, 'c': 3, 'd': 4, 'l_e': 5, 'l_f': 6, 'l': 7, 'context': 8, 'environment': 9, 'template': 10 }

# Generated at 2022-06-23 13:31:39.649318
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_text
    assert AnsibleJ2Vars(Templar, {}).__len__() == 0
    v = AnsibleJ2Vars(Templar, {'a': 'b'})
    assert v.__len__() == 1
    v.available_variables = {'a': 'b'}
    assert v.__len__() == 1
    v.available_variables = {'c': 'd'}
    assert v.__len__() == 2
    original_contents = {'c': 'd'}

# Generated at 2022-06-23 13:31:47.532122
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.template.safe_eval
    from ansible.plugins.loader import get_all_plugin_loaders

    # Create a Templar object
    templar = ansible.template.safe_eval.Templar(loader=None, shared_loader_obj=None, variables=None)

    # Create a dictionary like object containing all the global variables
    globals = {}
    for plugin_loader in get_all_plugin_loaders():
        globals[plugin_loader.name] = plugin_loader.get_all_j2_filters()

    # Create a AnsibleJ2Vars object
    j2vars = AnsibleJ2Vars(templar, globals)

    # Test contains method
    assert 'to_json' in j2vars
    assert 'a_global_var' not in j2vars

# Generated at 2022-06-23 13:31:58.993807
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible
    module_utils_path = ansible.utils.module_finder.get_module_path('ansible.module_utils.basic')
    module_utils_path = module_utils_path[:module_utils_path.index('module_utils')]
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    play_context = PlayContext()
    templar = ansible.template.Templar(loader=loader, variables=dict(foo='world', bar='world', fooz='world'))
    vars = AnsibleJ2Vars(templar=templar, globals=dict())

    # Test template variable

# Generated at 2022-06-23 13:32:09.843333
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = None
    locals = {'a': 1, 'b': 2, 'c': 3}

    aj2v = AnsibleJ2Vars(templar, globals, locals)

    keys = set(['a', 'b', 'c'])
    assert(set(aj2v.__iter__()) == keys)

    keys.update(['d', 'e'])
    aj2v._templar.available_variables = {'d': 4, 'e': 5}
    assert(set(aj2v.__iter__()) == keys)

    keys.update(['f', 'g'])
    aj2v._globals = {'f': 6, 'g': 7}
    assert(set(aj2v.__iter__()) == keys)




# Generated at 2022-06-23 13:32:16.633371
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    templar = Templar(loader=None, variables={'a':1, 'b':2})

    globals = {
        'a': 'global_a',
        'b': 'global_b',
        'c': 'global_c',
    }

    locals = {
        'a': 'local_a',
        'b': 'local_b',
        'd': 'local_d',
    }

    var_mgr = AnsibleJ2Vars(templar, globals, locals=locals)

    assert len(var_mgr) == len(globals) + len(locals) + len(templar.available_variables) == 5
    assert 'a' in var_mgr


# Generated at 2022-06-23 13:32:27.968134
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Arrange
    globals = { 'a': 'apple', 'b': 'banana', 'c': 'cherry' }
    locals = { 'a': 'ant', 'b': 'bat', 'c': 'cat' }
    templar = 'templar'
    ansibleJ2Vars = AnsibleJ2Vars(templar, globals=globals, locals=locals)

    # Act
    len_result = ansibleJ2Vars.__len__()

    # Assert
    assert len_result == 6
    # TODO: also do a len_result == len(ansibleJ2Vars) assert
    # TODO: also do a ansibleJ2Vars.__contains__('a') assert

# Generated at 2022-06-23 13:32:35.553180
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = dict()
    globals = dict()
    locals = dict()

    testobj = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' not in testobj

    locals['a'] = '1'
    testobj = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in testobj

    globals['a'] = '1'
    testobj = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in testobj

    templar['a'] = '1'
    testobj = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in testobj

# vim: set et:

# Generated at 2022-06-23 13:32:39.771225
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    locals = {"key1": "value1"}
    templar = {"key2": "value2"}
    globals = {"key3": "value3"}
    aj2v = AnsibleJ2Vars(templar, globals, locals)
    assert("key1" in aj2v)
    assert("key2" in aj2v)
    assert("key3" in aj2v)
    assert("key4" not in aj2v)


# Generated at 2022-06-23 13:32:46.995393
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    class FakeTemplar:
        available_variables = {'v1': 'vars', 'v2': 'vars', 'v3': 'vars', 'v4': 'vars'}

    vars = AnsibleJ2Vars(FakeTemplar(), globals={'g1': 'globals', 'g2': 'globals'}, locals={'l1': 'locals', 'l2': 'locals'})

    assert 'v1' in vars
    assert 'g1' in vars
    assert 'l1' in vars

    assert 'v5' not in vars
    assert 'g5' not in vars
    assert 'l5' not in vars


# Generated at 2022-06-23 13:32:57.167223
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Tests method add_locals of class AnsibleJ2Vars with various cases and
    expected values according to test data.
    '''

    from ansible.templating import Templar
    from ansible.plugins.loader import vars_loader

    templar = Templar(loader=vars_loader, shared_loader_obj=vars_loader, variables={'test_var': 'ok'})

    # Data