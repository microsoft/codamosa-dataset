

# Generated at 2022-06-23 13:23:00.557046
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    test_vars = {
        'test_variable_01': 'test_value_01',
        'test_variable_02': AnsibleUnsafeText('test_value_02'),
    }
    result = AnsibleJ2Vars(None, None, test_vars).__iter__()
    assert result != None
    result = list(result)
    assert len(result) == 2
    assert 'test_variable_01' in result
    assert 'test_variable_02' in result


# Generated at 2022-06-23 13:23:05.145495
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2

    v = AnsibleJ2Vars(jinja2.Environment(), {})
    v["var"] = 42
    assert v["var"] == 42


# Generated at 2022-06-23 13:23:13.648692
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar

    yaml_data = """
    ---
    a:
      - '1'
      - '2'
      - '3'
    b:
      - '4'
      - '5'
      - '6'
    c:
      - '7'
      - '8'
      - '9'
    """
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()

    # import the yaml data into templar
    # so the available variables are known
    templar.set_available_variables(yaml.safe_load(yaml_data))

    # create a new AnsibleJ2Vars instance
    j2vars = AnsibleJ2Vars(templar,globals)

    # verify that

# Generated at 2022-06-23 13:23:23.787714
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.template.safe_eval import unsafe_eval

    # load test locals
    fname = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'vars.yml')
    test_locals = yaml.safe_load(open(fname))

    # load test globals
    fname = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'globals.yml')
    test_globals = yaml.safe_load(open(fname))

    # test that the locals are returned as they are
    templar = Templar(loader=None, variables=None)

# Generated at 2022-06-23 13:23:26.368382
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    ansible_vars = AnsibleJ2Vars(templar, globals={}, locals={})
    assert len(ansible_vars) == 0

# Generated at 2022-06-23 13:23:35.487368
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.manager import VariableManager
    var_manager = VariableManager()
    var_manager.set_inventory(None)
    var_manager.extra_vars = {
        'hoge': 'Hoge',
        'fuga': {
            'piyo': 'Piyo',
        }
    }

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    templar = Templar(loader=None, variables=var_manager)
    play_context = PlayContext()
    play_context.vars = var_manager.get_vars()

    proxy = AnsibleJ2Vars(templar, play_context.get_globals(templar), play_context.vars)

    # test for undefined variable

# Generated at 2022-06-23 13:23:36.093813
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass


# Generated at 2022-06-23 13:23:48.835202
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Arrays
    # Local vars
    local_vars = {}
    local_vars['l_test_var_1'] = 1
    local_vars['l_test_var_2'] = 2
    # templates
    local_templates = {}
    local_templates['test_var_1'] = "{{ test_var_1 }}"
    local_templates['test_var_2'] = "{{ test_var_2 }}"

    # Expected results
    expected_result_no_templates = {}
    expected_result_no_templates['test_var_1'] = False
    expected_result_no_templates['test_var_2'] = False
    expected_result_no_templates['l_test_var_1'] = True

# Generated at 2022-06-23 13:23:54.868530
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2
    globals = dict()
    templar = jinja2.Environment()
    locals = dict()
    aj2vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert(isinstance(aj2vars, AnsibleJ2Vars))
    assert(isinstance(aj2vars, Mapping))
    assert(len(aj2vars) == 0)


# Generated at 2022-06-23 13:24:01.736978
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class Templar(object):
        def __init__(self, available_variables):
            self.available_variables = available_variables
    locals=dict()
    globals=dict()
    templar = Templar({"k1":"v1", "k2":"v2"})
    locals["v3"]="v3"
    locals["v4"]="v4"
    globals["v5"]="v5"
    globals["v6"]="v6"
    ansibleJ2Vars = AnsibleJ2Vars(templar, globals, locals)
    keys = set()
    for key in ansibleJ2Vars:
        keys.add(key)
    assert "v3" in keys
    assert "v4" in keys
    assert "k1" in keys

# Generated at 2022-06-23 13:24:12.361178
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping

    # Create mocked Templar
    fake_templar = type('Templar', (object,), {})()
    fake_templar.available_variables = {}
    fake_templar.template = lambda x: x

    # Create mocked VariableManager
    fake_vars_mgr = type('VariableManager', (object,), {})()
    fake_vars_mgr.extra_vars = {}
    fake_vars_mgr.get_vars = lambda: {'a': 1, 'b': 2}
    fake_vars_mgr.get_host_vars = lambda x: HostVars

# Generated at 2022-06-23 13:24:21.667438
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar(object):
        def __init__(self, available_variables):
            self.available_variables = available_variables
        def template(self, variable):
            return variable

    globals = {
        'g_g0': 'g0',
        'g_g1': 'g1',
        'g_g2': 'g2',
    }
    locals = {
        'l_l0': 'l0',
        'l_l1': 'l1',
        'l_l2': 'l2',
        'context': 'context',
        'environment': 'environment',
        'template': 'template',
    }

# Generated at 2022-06-23 13:24:25.901863
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()
    vars = dict()
    j2_vars = AnsibleJ2Vars(templar, vars)
    try:
        _ = j2_vars['test']
        raise
    except KeyError:
        pass
    # SyntaxError: invalid syntax
    # vars['test']
    j2_vars._templar.available_variables['test'] = 'test'
    _ = j2_vars['test']



# Generated at 2022-06-23 13:24:36.794971
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import pytest
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    locals = dict()
    locals['name'] = 'I am not a proxy'
    locals['nested_var'] = {'key': 'value'}
    locals['nested_unsafe_var'] = AnsibleUnsafeText('value')
    locals['nested_unsafe_var2'] = '$ANSIBLE_VAULT;something'

    templar = Templar(loader=None)
    vars = AnsibleJ2Vars(templar, globals=dict(), locals=locals)

    assert len(locals) == 3
    assert len(vars) == 4



# Generated at 2022-06-23 13:24:43.916361
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Mapping
    if PY3:
        long = int

    vars = dict(a=dict(b=dict(c=dict(d=dict(e="ponies are fun")))))
    t = Templar(loader=None)
    t.set_available_variables(vars)
    vp = AnsibleJ2Vars(t, {})
    assert(isinstance(vp, Mapping))
    assert(isinstance(vp['a'], dict))
    assert(isinstance(vp['a']['b'], dict))

# Generated at 2022-06-23 13:24:54.355685
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = None
    globals = {'a': 1}
    locals = {'b': 2}
    vars_without_locals = AnsibleJ2Vars(templar, globals)
    vars_with_locals = AnsibleJ2Vars(templar, globals, locals)
    vars_with_new_locals = vars_without_locals.add_locals(locals)
    assert vars_with_locals is not vars_without_locals
    assert vars_with_new_locals is not vars_without_locals
    assert vars_with_new_locals is not vars_with_locals
    assert vars_with_locals._locals == vars_with_new_locals._locals

# Generated at 2022-06-23 13:25:03.333076
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    test_cases = [
        ('vars', True, None),
        ('template', True, None),
        ('environment', True, None),
        ('context', True, None),
        ('foo', False, 'undefined variable: foo'),
    ]

    for (name, should_succeed, expected_error_message) in test_cases:
        templar = Templar(loader=None, variables={name: 'bar'})
        vars = AnsibleJ2Vars(templar, dict())
        if should_succeed:
            result = vars[name]
            assert result == 'bar'

# Generated at 2022-06-23 13:25:09.124674
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText as unsafe
    import ansible.constants as C
    import ansible.vars.hostvars as HV
    import ansible.vars.unsafe_proxy as UP

    templar = J2Template({}, C.DEFAULT_HASH_BEHAVIOUR)


# Generated at 2022-06-23 13:25:19.114358
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager

    templar = Templar(loader=None, variables=VariableManager())
    variable = HostVars()
    variable.add_host("host1")
    variable.add_host("host2")
    variable.set_host_variable("host2", "var1", "val1")
    variable.set_host_variable("host2", "var2", "val2")
    var_dict = dict()
    var_dict["vars"] = variable
    ajv = AnsibleJ2Vars(templar, globals=None, locals=var_dict)

    assert(ajv["vars"]["host2"]["var1"] == "val1")

# Generated at 2022-06-23 13:25:29.296455
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars

    vars = AnsibleJ2Vars(templar=None, globals={}, locals={})
    try:
        vars["foo"]
        assert False # should not be reached
    except KeyError as err:
        assert str(err) == "undefined variable: foo"

    vars = AnsibleJ2Vars(templar=None, globals={"foo": 123}, locals={})
    assert vars["foo"] == 123

    vars = AnsibleJ2Vars(templar=None, globals={}, locals={"foo": 123})
    assert vars["foo"] == 123

    # FIXME what is the correct behavior?

# Generated at 2022-06-23 13:25:35.608535
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    templar = Templar(loader=None, variables=None)

    globals = {'bla': 'a', 'blo': 'b'}
    locals = {'bli': 'c'}

    ajv = AnsibleJ2Vars(templar, globals, locals)

    assert 'bla' in ajv
    assert 'blo' in ajv
    assert 'bli' in ajv
    assert 'blub' not in ajv

# Generated at 2022-06-23 13:25:45.108836
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import collections
    import sys
    import types
    import unittest

    # Necessary to support calling AnsibleJ2Vars inside a "with" statement
    class templar(object):
        class Templar(object):
            def __init__(self):
                self._available_variables = {'a': None}
            def template(self, var):
                if isinstance(var, collections.Mapping):
                    return var
                return 'template({})'.format(var)
        __enter__ = lambda s: s.Templar()
        __exit__ = lambda s, t, v, b: None

    locals = {'l_a': 'l_a', 'l_b': 'l_b'}

# Generated at 2022-06-23 13:25:54.032784
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Example data
    templar = None
    globals = {'g': 'globals'}
    locals1 = {'l1': 'l1'}
    locals2 = {'l2': 'l2'}
    locals3 = {'l3': 'l3'}

    # Test empty locals
    j2vars = AnsibleJ2Vars(templar, globals)
    j2vars2 = j2vars.add_locals(None)
    assert id(j2vars) == id(j2vars2)

    # Test locals not None
    j2vars2 = j2vars.add_locals(locals1)
    assert id(j2vars) != id(j2vars2)

# Generated at 2022-06-23 13:26:04.616126
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    def TestTemplate():
        pass
    TestTemplate.template = lambda x: x
    globals = {
        'foo': 'bar',
        'baz': {'qux': 'quux'}
    }
    locals = {
        'test': 'test'
    }
    var = AnsibleJ2Vars(TestTemplate(), globals, locals)
    assert var['foo'] == 'bar'
    assert var['baz'] == {'qux': 'quux'}
    assert var['test'] == 'test'
    assert var['missing'] == AnsibleUndefinedVariable()


# Generated at 2022-06-23 13:26:12.395935
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import os
    import sys
    import ansible.utils
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.template.vars import Templar
    from ansible.template.template import Templar as AnsibleJ2Templar
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.template.vars import AnsibleJ2Vars

# Generated at 2022-06-23 13:26:24.028673
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.module_utils.six import iteritems
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # first test AnsibleUndefinedVariable
    vm1 = VariableManager()
    vm1.set_globals(gv='global var')
    vm1.set_host_variable('hv', 'host var')
    vm1.set_fact_cache(fc='fact cache')
    vm1.set_variable('v', 'var')
    templar1 = Templar(loader=None, variables=vm1)

    ajv1 = AnsibleJ2Vars(templar1, {}, {})
    for ajv in [ajv1]:
        with pytest.raises(KeyError) as excinfo:
            x = ajv['undefined var']
       

# Generated at 2022-06-23 13:26:34.766709
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2

    def jinja2_env(vars):
        ''' Create a jinja2 environment with the given vars added. '''
        env = jinja2.Environment()
        env.globals.update(vars)
        return env

    # Test case: when locals is None, return self.
    def test_none(var_proxy, vars):
        result = var_proxy.add_locals(None)
        if result != var_proxy:
            raise Exception('expected result to equal self for test case with locals: %s' % None)

    # Test case: when locals are not None, create a new AnsibleJ2Vars with the locals added.

# Generated at 2022-06-23 13:26:47.634852
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.module_utils.common._collections_compat import Mapping
    assert issubclass(AnsibleJ2Vars, Mapping)

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.ajson import AnsibleJSONEncoder
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    # Simple data structure to put in a fake inventory
    inventory_host_vars = {'host_01': {'k1': 'v1'}}

    #

# Generated at 2022-06-23 13:26:50.082551
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Create the object to test
    var_obj = AnsibleJ2Vars(None, None)

    # Test
    result = var_obj.add_locals(None)

    # Check the result
    assert result == var_obj

# Generated at 2022-06-23 13:27:01.728862
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    # set up templar with a dummy variable
    templar = Templar(loader=None, variables={'x': 'hello world'})
    # set up a dummy globals variable
    globals = {'a': 'b'}
    # set up a dummy local variable
    locals = {'l_y': 'ahoy'}
    # create object to test
    j2_vars = AnsibleJ2Vars(templar, globals, locals)
    # test is successful if iter() contains all of our dummy variables

# Generated at 2022-06-23 13:27:12.628185
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var

    templar = Templar()
    available_variables = dict(a_dict = dict(a_key = 'a_string'),
                               a_list = ['a_string', 'another_string'],
                               an_int = 123,
                               a_float = 123.456,
                               a_bool = True,
                               a_string = 'a_string',
                               a_var = 'a_var',
                               undefined = None)
    globals = dict(ansible_version = dict(full = '2.5.0', major = 2, minor = 5, revision = 0, string = '2.5.0'))


# Generated at 2022-06-23 13:27:22.897199
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import os
    import sys
    import unittest
    from abc import ABCMeta, abstractmethod

    import ansible.module_utils.jinja2_native as j2n

    class MockLoader(object):
        @abstractmethod
        def get_source(self, environment, template):
            return "test"

    class MockEnvironment(object):
        def __init__(self, **kwargs):
            self._jinja2_native = j2n
            self.loader = MockLoader()
            if 'options' in kwargs:
                self.options = kwargs['options']
            else:
                self.options = j2n.Undefined

    class MockTemplar(object):
        def __init__(self, **kwargs):
            self.environment = MockEnvironment(**kwargs)


# Generated at 2022-06-23 13:27:35.115688
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars import combine_vars
    from ansible.errors import AnsibleError
    from ansible.utils.vars import combine_vars as combine_vars_util
    import copy

    vault_pass = '$ANSIBLE_VAULT;1.1;AES256'

    def _get_var(name):
        return {'foo': {'bar': name}}



# Generated at 2022-06-23 13:27:40.245071
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2Vars(Templar(loader=DataLoader()), globals, locals)
    assert list(iter(j2vars)) == []

    globals = dict()
    locals = dict(var='value')
    j2vars = AnsibleJ2Vars(Templar(loader=DataLoader()), globals, locals)
    assert list(iter(j2vars)) == ['var']

    globals = dict()
    locals = dict()

# Generated at 2022-06-23 13:27:48.711571
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    # initializing VaultLib
    vault_secrets_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'module_utils', 'vault_module_secrets.yml')
    vault_lib = VaultLib(vault_secrets_path, 1)

    # initializing Templar
    templar = Templar(loader=None, variables={}, vault_secrets=vault_lib)

    # initializing AnsibleJ2Vars
    j2vars = AnsibleJ2Vars(templar, { '_': lambda x: x })

    # check, if AnsibleJ2Vars is a class Mapping

# Generated at 2022-06-23 13:27:56.094603
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar=Templar(loader=None)
    v1={'a':1, 'b':2}
    v2={'c':3, 'd':4}
    a=AnsibleJ2Vars(templar, v1, v2)

    # test case for method __getitem__
    assert a['a']==1
    assert a['b']==2
    assert a['c']==3
    assert a['d']==4

    # test case for method __contains__
    assert 'a' in a
    assert 'b' in a
    assert 'c' in a
    assert 'd' in a
    assert 'e' not in a

    # test case for method __iter__

# Generated at 2022-06-23 13:28:03.383394
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = Templar()
    globals = {'foo': 'bar'}
    locals = {'l_spam': 'eggs'}
    # test with locals
    ansiblej2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(ansiblej2vars) == 2
    # test without locals
    ansiblej2vars = AnsibleJ2Vars(templar, globals)
    assert len(ansiblej2vars) == 1

# unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-23 13:28:15.808137
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Create a AnsibleJ2Vars object with empty parameters
    ansible_j2vars = AnsibleJ2Vars(None, {}, {})

    # Test if length of variable in AnsibleJ2Vars object is 0
    assert(len(ansible_j2vars) == 0)

    # Create a AnsibleJ2Vars object with defined parmeters
    ansible_j2vars2 = AnsibleJ2Vars(None, {'a': 'b'}, {})

    # Test if length of variable in AnsibleJ2Vars object is 1
    assert(len(ansible_j2vars2) == 1)

    # Create a AnsibleJ2Vars object with defined parmeters

# Generated at 2022-06-23 13:28:29.172455
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    a = AnsibleJ2Vars(templar, dict())

    new_dict = dict()
    new_dict["a"] = "foo"
    new_dict["b"] = "bar"
    new_dict["c"] = "foobar"

    a1 = a.add_locals(new_dict)

    new_dict2 = dict()
    new_dict2["d"] = "eggs"
    new_dict2["e"] = "ham"

    a2 = a1.add_locals(new_dict2)

    assert a2["a"] == "foo"
    assert a2["b"] == "bar"
    assert a2["c"] == "foobar"

# Generated at 2022-06-23 13:28:33.665347
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert len(AnsibleJ2Vars(None,dict(a=1,b=2,c=3))) == 3
    assert len(AnsibleJ2Vars(None,dict(a=1))) == 1



# Generated at 2022-06-23 13:28:39.880102
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = {'x':'gx', 'y':'gy'}
    locals = {'x':'lx', 'y':'ly'}

    obj = AnsibleJ2Vars(templar, globals, locals)
    sorted_iteritems = sorted(iteritems(obj))
    expected_result = [('x','lx'), ('y','ly')]
    assert sorted_iteritems == expected_result

# Generated at 2022-06-23 13:28:47.799602
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    templar = Templar(loader=loader)
    inventory = Inventory(loader=loader, variable_manager=VariableManager())
    play_context = Play.load(_play_context, variable_manager=VariableManager(), loader=DataLoader())
    vars_obj = AnsibleJ2Vars(templar, play_context, locals=play_context.vars)

    assert len(vars_obj) == len(play_context.vars)

# Generated at 2022-06-23 13:28:57.420032
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock, call

    class TestAnsibleJ2Vars(unittest.TestCase):

        def setUp(self):
            self.mock_templar = MagicMock(name='Templar')
            self.mock_templar._available_variables = MagicMock(name='_available_variables')
            self.mock_templar._available_variables.keys.return_value = ['a']
            self.mock_globals = MagicMock(name='globals')
            self.mock_globals.keys.return_value = ['b']
            self.mock_locals = MagicMock(name='locals')

# Generated at 2022-06-23 13:29:08.502001
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import safe_eval
    # TODO: We need to fix this test
    #
    # The test is currently failing because it is iterating over the
    # internal variables of the Templar which is changing over time
    # due to the jinja2 changes.
    #
    # The test should create the variables from the dictionary below
    # and pass the them to the __contains___ method to test it
    # correctly.

    vars = {
        'my_var': 'my_var'
    }

    templar = safe_eval.AnsibleTemplar()

    ajv = AnsibleJ2Vars(templar, vars)

    assert 'my_var' in ajv

# Generated at 2022-06-23 13:29:18.003226
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Use cases:
    # - If varname is in locals, return it.
    # - If varname is in template, template it and return the result.
    # - If varname is in globals, return it.
    # - If varname is not in locals, template and return the result.
    # - If template fails, raise an error.

    from ansible.template.safe_eval import unsafe_eval
    from ansible.template import Templar

    variables = {
        "foo": "bar",
        "baz": "qux",
    }
    templar = Templar(loader=None, variables=variables)

    globals = {
        "wib": "wob",
        "zoz": "pip",
    }
    j2vars = AnsibleJ2Vars(templar, globals)

# Generated at 2022-06-23 13:29:23.803549
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    assert len(AnsibleJ2Vars(Templar(), {})) == 0
    hash_test = {"a": "b"}
    assert len(AnsibleJ2Vars(Templar(), hash_test)) == len(hash_test)
    assert len(AnsibleJ2Vars(Templar(), {"a": "b", "b": "c"})) == 2

# Generated at 2022-06-23 13:29:28.760846
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import ansible.vars.hostvars
    templar = ansible.vars.hostvars.HostVars()
    an = AnsibleJ2Vars(templar, templar, locals=templar)
    assert isinstance(an, dict)
    assert isinstance(an, AnsibleJ2Vars)

# Generated at 2022-06-23 13:29:38.519023
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    ''' test_AnsibleJ2Vars()

    Tests the correct initialization of the AnsibleJ2Vars class
    '''

    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Initialize the class
    j2vars = AnsibleJ2Vars(Templar(), {}, locals={
        'private_var': AnsibleVaultEncryptedUnicode(u'Hello World!'),
    })

    # Check if private_var is returned
    assert j2vars['private_var'] == u'Hello World!'

    # Check if private_var is not stored in the dictionary
    assert 'private_var' not in j2vars

    # Check if __contains__() method works
    assert 'private_var' in j2

# Generated at 2022-06-23 13:29:42.067964
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    templar = None
    globals = {'vars': {'ansible_version': '2.4'}}
    vars = AnsibleJ2Vars(templar, globals)

    assert vars['ansible_version'] == '2.4'

# Generated at 2022-06-23 13:29:55.189742
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    dl = DataLoader()
    vm = VariableManager(loader=dl)
    vm.set_globals({"foo_global": "bar_global"})
    vm.extra_vars = {"foo_extra": "bar_extra"}
    vm.set_host_variable("test_host", "foo_host_var", "bar_host_var")
    vm.set_host_variable("test_host", "foo_host_var2", "bar_host_var2")

# Generated at 2022-06-23 13:30:01.683960
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    vars = {'var1': 'value1'}
    templar = Templar(loader=None, variables=vars)
    ajv = AnsibleJ2Vars(templar, {}, {})
    assert len(ajv) == len(vars)

    # testing for global variable
    vars = {'var2': 'value2'}
    templar = Templar(loader=None, variables=vars)
    ajv = AnsibleJ2Vars(templar, vars, {})
    assert len(ajv) == len(vars)

    # testing for vault variables
    vault_password_file='test/ansible_vault.txt'

# Generated at 2022-06-23 13:30:11.543164
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from unittest import TestCase, mock
    from ansible.template import Templar

    # mock a template class object
    templar = mock.Mock(spec=Templar)
    templar.available_variables = {'a': 'aa', 'b': 'bb'}

    vars = {'a': 'AAA', 'b': 'BBB', 'c': 'CCC'}

    # test case 1: all variables are present
    case = AnsibleJ2Vars(templar, vars)
    expected = set(('a', 'b', 'c'))
    iter_keys = set()
    for k in case:
        iter_keys.add(k)
    assert(case._locals == {})
    assert(iter_keys == expected)

    # test case 2: locals are present
    case

# Generated at 2022-06-23 13:30:21.954876
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.templating import Templar
    from ansible.vars import VariableManager

    vars_manager = VariableManager()
    vars_manager.host_vars = dict()
    vars_manager.host_vars['host1'] = dict()
    vars_manager.host_vars['host2'] = dict()
    vars_manager.host_vars['host1'] = {'a': '1', 'b': '2'}
    vars_manager.host_vars['host2'] = {'a': '3', 'b': '4'}
    vars_manager.extra_vars = dict()
    vars_manager.extra_vars = {'c': '5', 'd': '6'}

# Generated at 2022-06-23 13:30:32.033655
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = None
    globals = None
    j2vars = AnsibleJ2Vars(templar, globals)
    j2vars_locals = j2vars.add_locals(locals={'foo':'bar'})
    assert j2vars['foo'] == 'bar'
    assert j2vars_locals == j2vars
    j2vars_locals_none = j2vars.add_locals(locals=None)
    assert j2vars_locals_none == j2vars

# Generated at 2022-06-23 13:30:38.401961
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2.environment
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2_vars_obj = AnsibleJ2Vars(templar, globals, locals)

    assert not (ansible_j2_vars_obj.__contains__('teststr'))



# Generated at 2022-06-23 13:30:47.221182
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    hostvars = HostVars(dict(var2='value2'))
    globals = dict(var1='value1')
    locals = dict(var3='value3')
    templar = Templar(loader=None)
    templar.set_available_variables(hostvars)
    templar.set_available_variables(dict(var4='value4'))
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert ansible_j2_vars['var1'] == 'value1'
    assert ansible_j2_vars['var2'] == 'value2'

# Generated at 2022-06-23 13:30:54.772031
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    init_locals = {'name': 'init_locals'}
    j2vars = AnsibleJ2Vars(templar, {'name': 'globals'}, locals=init_locals)
    assert j2vars['name'] == 'init_locals'
    new_locals = {'name': 'new_locals'}
    j2vars_new = j2vars.add_locals(new_locals)
    assert j2vars_new['name'] == 'new_locals'

    init_locals = {'name': 'init_locals'}

# Generated at 2022-06-23 13:31:05.826053
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Test cases for valid input

# Generated at 2022-06-23 13:31:16.625715
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    templar = object()

    globals = {'task_vars': {'test': 'global'}, 'include_vars': {'test': 'global'}}

    locals = {'task_vars': {'test': 'local'}, 'include_vars': {'test': 'local'}}

    unsafe_text = AnsibleUnsafeText('unsafe')

    j2vars = AnsibleJ2Vars(templar, globals, locals)

    # test if "test" is correctly replaced
    assert j2vars.__contains__('test') == True

    # test if "missing" is correctly replaced
    assert j2vars.__contains__('missing') == False

    # test if "task_vars" is

# Generated at 2022-06-23 13:31:24.534754
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Make sure that the method add_locals correctly adds locals.
    # The first step is to create a proxy and add a locals to it.
    import jinja2
    j2_env = jinja2.Environment()

    proxy = AnsibleJ2Vars(templar=j2_env.undefined, globals={}, locals={})

    proxy_with_locals = proxy.add_locals(locals={'foo': 'bar'})
    assert proxy_with_locals._locals.get('foo') == 'bar'

# Generated at 2022-06-23 13:31:37.158443
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import jinja2
    from ansible.template import Templar
    from ansible.inventory import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    hostvars = {'example_host': {}}
    variable_manager = VariableManager()
    variable_manager.set_host_variable(Host('example_host'), hostvars['example_host'])
    variable_manager.set_inventory(loader.load_from_file('tests/ansible_j2vars.py'))
    variable_manager.set_inventory_sources('tests/ansible_j2vars.py')
    variable_manager.extra_vars = {'example_var': 'example_value'}

# Generated at 2022-06-23 13:31:46.368781
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    import sys
    import unittest

    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.template import Templar
    from ansible.template import AnsibleJ2Vars

    class FakeModule(object):
        def __init__(self, inject):
            self.params = inject

    class AnsibleJ2VarsTest(unittest.TestCase):

        def test_AnsibleJ2Vars___iter__(self):

            templar = Templar(loader=None, variables={})
            j2vars = AnsibleJ2Vars(templar, {}, locals={'foo': 'bar', 'bam': 'baz'})

            self.assertTrue(isinstance(j2vars, Mapping))

# Generated at 2022-06-23 13:31:51.892282
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(None)
    a = AnsibleJ2Vars(templar, {}, {})
    assert len(a) == 0

## Unit test for method __getitem__ of class AnsibleJ2Vars

# Generated at 2022-06-23 13:31:57.074695
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    templar = Templar(loader=None, variables={'test_variable': 1234})
    j2vars = AnsibleJ2Vars(templar, {'test_global': 1234}, locals={'test_local': 1234})
    assert len(j2vars) == 3

# Generated at 2022-06-23 13:32:08.620496
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import sys
    if (sys.version_info < (2, 7)):
        import unittest2 as unittest
    else:
        import unittest

    import ansible.module_utils.common.collections
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    ansible.module_utils.common.collections.__imported_to_avoid_2to3_warnings__ = True

    class TestAnsibleJ2Vars(unittest.TestCase):
        def setUp(self):
            self.templar = Templar(loader=None)
            self.globals = {}
            self.locals = {}

# Generated at 2022-06-23 13:32:19.061871
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = AnsibleJ2Vars(None, {'foo': 'bar'})
    if templar.__getitem__('foo') != 'bar':
        raise AssertionError("AnsibleJ2Vars: returned unexpected 'foo' value.")

    templar = AnsibleJ2Vars(None, {'foo': AnsibleUnsafeText('bar')})
    if templar.__getitem__('foo') != 'bar':
        raise AssertionError("AnsibleJ2Vars: returned unexpected 'foo' value.")


# Generated at 2022-06-23 13:32:21.091784
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    #TODO: implement this
    pass


# Generated at 2022-06-23 13:32:31.591504
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
  from ansible.vars.hostvars import HostVars
  from ansible.parsing.yaml.loader import AnsibleLoader
  from ansible.parsing.dataloader import DataLoader
  from ansible.template import Templar
  dl = DataLoader()
  t = Templar(dl)
  av = AnsibleLoader(dl).load_from_file("/tmp/t")
  g = [1, 2, 3, 4]
  l = {"x": "y"}
  v = AnsibleJ2Vars(t, g, l)

  assert '__ansible_facts__' in v
  assert '__ansible_ssh_host' in v
  assert 1 in v
  assert 2 in v
  assert 3 in v
  assert 4 in v
  assert 'x' in v


# Generated at 2022-06-23 13:32:42.630824
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    class DummyVars(dict):
        pass
    templar = Templar({}, None, None, DummyVars)

    ajv = AnsibleJ2Vars(templar, dict())

    assert 'test' in ajv
    assert 'test' in templar.available_variables
    templar.available_variables['test'] = 123
    assert 'test' in ajv
    assert ajv['test'] == 123

    templar.available_variables['test'] = '{{ test2 }}'
    templar.available_variables['test2'] = '123'
    assert 'test' in ajv
    assert 'test2' in ajv
    assert ajv['test'] == '123'


# Generated at 2022-06-23 13:32:50.036529
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    Test expects object of AnsibleJ2Vars
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    variable_manager = inventory.get_variable_manager()
    mytask = Task()
    play_context = PlayContext()
    mytask.vars = dict(a='a', b='b')

# Generated at 2022-06-23 13:32:59.326854
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import unittest
    import ansible.template.safe_eval
    class AnsibleJ2Vars_t(unittest.TestCase):
        def setUp(self):
            self.templar = ansible.template.safe_eval.construct_safe_environment()
            self.globals = dict()
        def test_add_locals_no_locals(self):
            self.locals = None
            self.vars = AnsibleJ2Vars(self.templar, self.globals, locals=self.locals)
            self.vars.add_locals(dict(a=1, b=2))
            self.assertEqual(len(self.vars), 2)
            self.assertTrue('a' in self.vars)