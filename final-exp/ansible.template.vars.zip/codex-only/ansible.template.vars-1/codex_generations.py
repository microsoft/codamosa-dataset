

# Generated at 2022-06-23 13:23:05.514179
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # initialize needed objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])

    # initialize needed objects
    variable_manager.set_inventory(inventory)

    globals = {}
    locals = {}
    templar = variable_manager.get_vars(play=PlayContext(), target_host="localhost")
    # create AnsibleJ2Vars object
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    # tests which work only if you

# Generated at 2022-06-23 13:23:13.941122
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar

    templar = Templar(basedir='/tmp/')

    # test vars in _locals
    aj2v = AnsibleJ2Vars(templar, {})
    aj2v._locals['foo'] = 'bar'
    assert 'foo' in aj2v

    # test vars in _templar.available_variables
    aj2v = AnsibleJ2Vars(templar, {})
    templar.available_variables['foo'] = 'bar'
    assert 'foo' in aj2v

    # test vars in _globals
    aj2v = AnsibleJ2Vars(templar, {'foo': 'bar'})
    assert 'foo' in aj2v

    # test vars is

# Generated at 2022-06-23 13:23:19.336596
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import finalize
    from ansible.template.templar import Templar

    templar = Templar(loader=None, variables={})
    globals = {'bar': 'baz', 'foo': 'foo', 'boo': 'boo'}
    locals = {'foo': 'foofoo'}
    test_obj = AnsibleJ2Vars(templar, globals, locals)
    result = []
    for var in test_obj:
        result.append(var)

    assert result == ['bar', 'foo', 'boo']


# Generated at 2022-06-23 13:23:26.073814
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    # Setup test objects
    class Templar():
        def __getitem__(self, key):
            return "test_value"

    class VarsProxy(AnsibleJ2Vars):
        def __contains__(self, key):
            return True

    class AnsibleUndefinedVariable():
        pass

    # Setup test object and run test
    templar = Templar()
    vars_proxy = VarsProxy(templar, {})
    assert vars_proxy["test"] == "test_value"

# Generated at 2022-06-23 13:23:35.337389
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class DummyTemplar():
        def __init__(self):
            self.available_variables = {'a': 'aa', 'b': 'bb'}

    vars_obj = AnsibleJ2Vars(DummyTemplar(),
                             {'a': 'global_a', 'c': 'global_c'},
                             {'l_a': 'local_a', 'l_c': 'local_c',
                              'context': 'context', 'environment': 'env', 'template': 'template'})

    # given
    assert vars_obj._globals == {'a': 'global_a', 'c': 'global_c'}
    assert vars_obj._locals == {'a': 'local_a', 'c': 'local_c'}
    assert vars_obj._tem

# Generated at 2022-06-23 13:23:41.254534
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars import VariableManager

    mock_original = dict(a_var='{{ a_var | upper }}',
                         b_var='{{ b_var | upper }}',
                         secret='secret',
                         safe_secret=wrap_var('secret'),
                         unsafe_secret='{{ secret }}')
    mock_locals = dict(a_var='a local var',
                       b_var='{{ a_var }}')

    variable_manager = VariableManager()
    variable_manager.extra_vars = mock_original

    play_context = PlayContext()
    templar = Templar

# Generated at 2022-06-23 13:23:50.555017
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None)
    globals = dict(server='www.example.com')
    locals = dict(client='myclient', server='my.server')
    j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert j2_vars['client'] == 'myclient'
    assert j2_vars['server'] == 'my.server'
    assert j2_vars.add_locals(None) is j2_vars
    new_locals = dict(client='yourclient', server='yourserver')
    new_j2_vars = j2_vars.add_locals(new_locals)

# Generated at 2022-06-23 13:23:54.375089
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    assert isinstance(AnsibleJ2Vars(Templar(), {}), AnsibleJ2Vars)
    assert isinstance(AnsibleJ2Vars(Templar(), {}, {}), AnsibleJ2Vars)

# Generated at 2022-06-23 13:24:00.395349
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Setup variables
    templar = 'G'
    locals = {'name1': 'val1', 'name2': 'val2'}
    globals = {'name3': 'val3', 'name4': 'val4'}
    j2vars = AnsibleJ2Vars(templar, globals=globals, locals=locals)
    assert j2vars['name1'] == 'val1'
    assert j2vars['name2'] == 'val2'
    assert j2vars['name3'] == 'val3'
    assert j2vars['name4'] == 'val4'
    return True

# Generated at 2022-06-23 13:24:03.978743
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    templar = dict()
    globals = dict()
    locals = dict()
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert len(ajv) == 0


# Generated at 2022-06-23 13:24:12.396884
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    # Tests if __len__ returns an integer in the case
    # when the locals dict has items.

    # Arrange
    # test_templar = Templar()
    test_templar = None
    test_globals = dict()
    test_locals = dict()
    test_locals['test_key'] = 'test_value'

    test_obj = None

    # Act
    test_obj = AnsibleJ2Vars(test_templar, test_globals, test_locals)

    # Assert
    assert isinstance(test_obj.__len__(), int)


# Generated at 2022-06-23 13:24:18.502970
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from collections import UserDict
    from jinja2 import Environment, Feature, StrictUndefined

    from ansible.errors import AnsibleError
    from ansible.module_utils.six import iteritems
    from ansible.template import Templar

    # 1. empty vars
    t = Templar(loader=None, variables={})
    t.environment = Environment(loader=None, undefined=StrictUndefined)

    av = AnsibleJ2Vars(t, dict())
    assert 'fake' not in av

    # 2. with all kinds of vars, no undefined
    t = Templar(loader=None, variables={'a': '1', 'b': {'c': '2'}, 'd': [{'e': '3'}], 'f': ['4']})

# Generated at 2022-06-23 13:24:28.367494
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars

    templar = Templar()
    globals = {'true': True, 'false': False}
    j2vars = AnsibleJ2Vars(templar, globals)

    class MyDict(Mapping):
        def __getitem__(self, key):
            if key == 'a':
                return AnsibleUnsafeText('unsafe')
            elif key == 'b':
                return HostVars(dict())
            elif key == 'c':
                return 'safe'
            else:
                raise KeyError('no such key: %s' % key)

        def __contains__(self, key):
            return key

# Generated at 2022-06-23 13:24:37.107358
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    locals = {'var': 'value'}
    j2vars = AnsibleJ2Vars(templar, {}, locals)
    assert locals == j2vars.add_locals(None)._locals

    j2vars = AnsibleJ2Vars(templar, {}, locals)
    new_locals = {'var2': 'value2'}
    expected_locals = {'var': 'value', 'var2': 'value2'}
    assert expected_locals == j2vars.add_locals(new_locals)._locals

# Generated at 2022-06-23 13:24:47.640975
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    templar = Templar(VariableManager())
    host = Host('hostname')
    group = Group('groupname')
    hostvars = HostVars(host=host, variables={'test': 'someothervalue'})
    hostvars2 = HostVars(host=host, variables={'test': 'value'})
    group_vars = {'test': 'someothervalue'}

    globals = {'test': 'value'}
    locals = {'test': 'globalvalue'}


# Generated at 2022-06-23 13:24:48.346887
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass

# Generated at 2022-06-23 13:24:50.669767
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
# get len of each variable using __len__
    assert(len(AnsibleJ2Vars) == 7)

# Generated at 2022-06-23 13:25:00.484992
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar

    templar = Templar(loader=None)
    vars = {'a': 'a', 'b': 'b'}

    from ansible.vars.hostvars import HostVars
    hostvars = HostVars(vars, templar)

    from ansible.vars.unsafe_proxy import UnsafeProxy
    unsafe_proxy = UnsafeProxy()

    proxy = AnsibleJ2Vars(templar, {}, {'c': 'c'})

    assert proxy.add_locals({'d': 'd'}) == {'a': 'a', 'b': 'b', 'd': 'd'}

# Generated at 2022-06-23 13:25:12.258276
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = None
    proxy = AnsibleJ2Vars(templar, {}, locals={'foo': 'bar'})
    assert proxy is not None
    proxy2 = proxy.add_locals({'bar': 'baz'})
    assert proxy2 is not None
    assert proxy2._locals == dict(bar='baz', foo='bar')
    assert proxy._locals == dict(foo='bar')

    proxy3 = proxy.add_locals()
    assert proxy3 is not None
    assert proxy3._locals == dict(foo='bar')

if __name__ == "__main__":
    # Run a bunch of tests of the templating system
    import doctest
    doctest.testmod()
    # Run some specific tests of class AnsibleJ2Vars
    test_AnsibleJ2

# Generated at 2022-06-23 13:25:20.683486
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'a': 1, 'b': {'c': 2}})
    j2vars = AnsibleJ2Vars(templar, {'d': 3, 'e': 5})
    j2vars2 = AnsibleJ2Vars(templar, {'d': 3, 'e': 5}, locals=None)

    # locals are not provided, should return a copy of self
    assert j2vars2 is j2vars
    # locals are provided, should return a new object
    locals = {'x': 10, 'y': 20}
    j2vars3 = j2vars.add_locals(locals)
    assert j2vars3

# Generated at 2022-06-23 13:25:29.148009
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    j2_vars = AnsibleJ2Vars(Templar(), globals=dict(foo='gbar'))
    j2_vars_new = j2_vars.add_locals(dict(bar='bfoo'))

    assert 'gbar' == j2_vars_new['foo']
    assert 'bfoo' == j2_vars_new['bar']
    assert 'gbar' == j2_vars['foo']
    assert 'gbar' != j2_vars['bar']
    assert 'bfoo' != j2_vars['bar']

# Generated at 2022-06-23 13:25:33.141664
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # single argument AnsibleJ2Vars.__init__
    ansible_j2_vars = AnsibleJ2Vars(templar=None, globals=None)
    assert iter(ansible_j2_vars) != None


# Generated at 2022-06-23 13:25:39.374950
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # AnsibleJ2Vars object 
    j2vars = AnsibleJ2Vars(None, None, None)

    try:
        # get length of object
        len(j2vars)
    except Exception as e:
        # print the error message
        print(e, "in method __len__ of class AnsibleJ2Vars")
        raise(e)


# Generated at 2022-06-23 13:25:46.876065
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible import constants as C
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    vars_manager = VariableManager()
    vault_secrets = VaultLib(C.DEFAULT_VAULT_PASSWORD_FILE)
    from ansible.template.vars import Templar
    templar = Templar(vars_manager, vault_secrets=vault_secrets)

    vars = dict(foo='bar', baz='quux')
    globals = dict(zip=zip)
    proxy = AnsibleJ2Vars(templar, globals, locals=vars)

    expected = len(vars)+len(globals)+len(templar.available_variables)
    actual = len(proxy)
    assert expected == actual
   

# Generated at 2022-06-23 13:25:53.054146
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class MockTemplar(object):
        def __init__(self, available_variables):
            self.available_variables = available_variables

        def template(self, variable):
            return variable

    templar = MockTemplar({'a': 1, 'b': 2, 'c': 3})
    globals_dict = {'x': 1, 'y': 2, 'z': 3}
    locals_dict = {'u': 1, 'v': 2, 'w': 3}
    instance = AnsibleJ2Vars(templar, globals_dict, locals_dict)
    expected = ['a', 'b', 'c', 'u', 'v', 'w', 'x', 'y', 'z']
    actual = list(instance)
    assert all(x in actual for x in expected)

#

# Generated at 2022-06-23 13:25:56.142955
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = {}
    globals = {}
    locals = {}
    AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-23 13:26:07.658993
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Scenario:
    # 1. Given a varname, we try to retrieve the corresponding value using self._locals,
    #    self._templar or self._globals.
    # 2. In case of success, the value is returned.
    # 3. In case of failure, a KeyError exception is raised.

    from ansible.template.safe_eval import Safevars
    from ansible.template.template import Templar
    from ansible.vars.hostvars import HostVars

    # Case: Var exists in self._locals.
    templar_1 = Templar(loader=None, variables=DummyVarsModule())
    globals_1 = dict()
    locals_1 = dict()
    locals_1['foo'] = 'bar'

# Generated at 2022-06-23 13:26:19.212836
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.errors
    import ansible.module_utils.common._collections_compat as collections
    import ansible.module_utils.six as six
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    # Test that the first argument of __init__ becomes self._templar
    templar = collections.Mock()
    proxy = AnsibleJ2Vars(templar, {})
    assert proxy._templar == templar

    # Test that the second argument of __init__ becomes self._globals
    globals = {}
    proxy = AnsibleJ2Vars(templar, globals)
    assert proxy._globals == globals

    # Test that the third argument of __init__ becomes self._locals
    locals = {}
    proxy

# Generated at 2022-06-23 13:26:31.541359
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class mydict(Mapping):
        def __init__(self):
            self._dict = { 'test' : 0 }

        def __getitem__(self, key):
            return self._dict[key]

        def __iter__(self):
            return iter(self._dict)

        def __len__(self):
            return len(self._dict)

    class mydict(object):
        def __init__(self):
            self._dict = {'test': 0}

        def __getitem__(self, key):
            return self._dict[key]

        def __iter__(self):
            return iter(self._dict)

        def __len__(self):
            return len(self._dict)


# Generated at 2022-06-23 13:26:39.583726
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    templar = Templar(loader=None, variables={})
    globals = {"test1": 1, "test2": 2, "test3": 3}
    locals = {"test4": 4, "test5": 5}
    vars = AnsibleJ2Vars(templar, globals=globals, locals=locals)
    assert len(vars) == 5
    locals["vars"] = HostVars()
    vars = AnsibleJ2Vars(templar, globals=globals, locals=locals)
    assert len(vars) == 6
    globals["vars"] = HostVars()

# Generated at 2022-06-23 13:26:50.781550
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    ''' AnsibleJ2Vars.__len__() '''
    import sys
    if sys.version_info[:2] == (2, 6):
        from jinja2 import Environment
        from jinja2.runtime import Undefined
    else:
        from jinja2 import Environment, Undefined
    from ansible.template import Templar
    from ansible.vars import VariableManager

    host_vars = dict(foo='foo',
                     bar='bar',
                     baz='baz',
                     bof='bof',
                     baf='baf',
                     borf='borf',
                     borfle='borfle',
                     borfle_kaw='borfle_kaw',
                     borfle_kaw_skal='borfle_kaw_skal',
                     )
    group_v

# Generated at 2022-06-23 13:27:02.467820
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    locals = {
        'l_k1': 'v1',
        'l_k2': 'v2',
        'k3': 'v3',
        'k4': 'v4',
        'k5': 'v5',
        'k6': 'v6',
    }
    globals = {
        'k1': 'v1',
        'k2': 'v2',
    }
    ajv = AnsibleJ2Vars('templar', globals, locals=locals)

    # test if ajv contains key which is in locals and not in globals
    assert 'k3' in ajv
    # test if ajv contains key which is in globals and not in locals
    assert 'k1' in ajv
    # test if ajv contains key which is not in

# Generated at 2022-06-23 13:27:13.337817
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    test_variable_manager = VariableManager()
    test_inventory = InventoryManager(loader=None, sources=[])

    test_host = test_inventory.add_host("testhost")
    test_host.set_variable("testvar1", "testval1")
    test_host.set_variable("testvar2", "testval2")

    test_group = test_inventory.add_group("testgroup")
    test_group.add_host(test_host)

    test_variable_manager.set_inventory(test_inventory)
    test_variable_manager.extra_vars = dict(testvar3="testval3")

    test_J2Vars = AnsibleJ2V

# Generated at 2022-06-23 13:27:23.560339
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_globals(dict(foo='foo'))
    variable_manager.set_host_variable(host='localhost', varname='bar', value='bar')
    variable_manager.set_host_variable(host='localhost', varname='baz', value='baz')
    variable_manager.set_host_variable(host='localhost', varname='hostvars', value=HostVars(dict(qux='qux')))

    templar = variable_manager.get_interface('template')

    locals = None
    vars = AnsibleJ2Vars(templar, templar._get_globals(), locals)
    keys = set()

# Generated at 2022-06-23 13:27:33.765887
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    import time
    templar = Templar()
    a = AnsibleJ2Vars(templar, {"time": time})
    variables = {
        "test_var_one": "this is a test variable"
    }
    templar._available_variables = variables
    templar.set_available_variables(HostVars(vars=variables))
    length = len(a)
    assert len(a) == len(variables) + len(a._globals) + len(a._locals)

# Generated at 2022-06-23 13:27:43.138858
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import json
    import yaml
    j2_vars=AnsibleJ2Vars(None, None)
    try:
        j2_vars['test']
        assert False
    except KeyError:
        pass
    assert len(j2_vars) == 0
    assert "test" not in j2_vars
    j2_vars=AnsibleJ2Vars(None, {"test": "ok"})
    assert j2_vars['test'] == "ok"
    assert len(j2_vars) == 1
    assert "test" in j2_vars
    j2_vars=AnsibleJ2Vars(None, {"test": json.loads(json.dumps({"test": "ok"}))})
    assert j2_vars['test']['test']

# Generated at 2022-06-23 13:27:51.917241
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    v1 = dict(key = "value")
    v2 = dict(key = "michael")
    v3 = dict(key = "michael")
    v4 = dict(key = "michael")
    v5 = dict(key = "michael")
    v6 = dict(key = "michael")
    data = dict(v1=v1, v2=v2, v3=v3, v4=v4, v5=v5, v6=v6)
    loader = DataLoader()
    vars_manager = VariableManager(loader=loader)
    templar

# Generated at 2022-06-23 13:28:02.625000
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    try:
        from ansible.template import Templar
    except:
        print("SKIP: missing ansible.template")
        raise

    try:
        from ansible.template import Templar
    except:
        raise Exception("SKIP: missing ansible.template")

    try:
        from ansible.inventory.host import Host
    except:
        raise Exception("SKIP: missing ansible.inventory")

    try:
        from jinja2 import Environment, DictLoader

        env = Environment(loader=DictLoader(dict()))
    except:
        raise Exception("SKIP: missing jinja2")

    # create the templar object
    templar = Templar(env)
    templar._available_variables = dict(v1='one')

    # create the AnsibleJ2Vars object
    aj

# Generated at 2022-06-23 13:28:15.418084
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    # Add a new attribute to class AnsibleJ2Vars
    AnsibleJ2Vars.attr = None

    # Test using a copy of AnsibleJ2Vars
    def test_copy(self):
        assert self.attr is None, "Class variable attr of AnsibleJ2Vars is not None"
        self.attr = 'something'
        copy = AnsibleJ2Vars(self._templar, self._globals, locals=self._locals)
        assert copy.attr is None, "Class variable attr of AnsibleJ2Vars is not None"
        assert self.attr == 'something', "Class variable attr of AnsibleJ2Vars is not 'something'"
        self.attr = None
        del copy

    # Test without using a copy of AnsibleJ2Vars

# Generated at 2022-06-23 13:28:28.884558
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    pass
    # Raise error if class is not callable
    # if not callable(AnsibleJ2Vars):
    #     raise AssertionError("AnsibleJ2Vars is not callable")

    # Call AnsibleJ2Vars and check if the object is created with proper data
    # ansible_j2_vars_obj = AnsibleJ2Vars()

    # Check if the return value of the function __iter__ is Iterator
    # assert isinstance(ansible_j2_vars_obj.__iter__(), Iterator), "ansible_j2_vars_obj.__iter__() does not return Iterator object"
    # assert isinstance(ansible_j2_vars_obj.__iter__(), object), "ansible_j2_vars_obj.__iter__() does not

# Generated at 2022-06-23 13:28:40.513375
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-23 13:28:52.306049
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.template import Templar

    templar = Templar(loader=None)
    proxy = AnsibleJ2Vars(templar, dict(foo='bar'))
    assert proxy['foo'] == 'bar'

    proxy = AnsibleJ2Vars(templar, globals={'foo': 'bar'}, locals={'l_foo': 'asd'})
    assert proxy['l_foo'] == 'asd'
    assert proxy['foo'] == 'bar'

    unsafe_proxy = wrap_var('bar')
    proxy = AnsibleJ2Vars(templar, globals={'foo': unsafe_proxy}, locals={'l_foo': 'asd'})
    assert proxy['l_foo'] == 'asd'

# Generated at 2022-06-23 13:28:53.275376
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert AnsibleJ2Vars is not None
    assert AnsibleJ2Vars is not 0

# Generated at 2022-06-23 13:28:58.067393
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {'foo': 'bar'}
    locals = {'l_foo': 'bar1'}
    test = AnsibleJ2Vars(templar, globals, locals)
    assert test._globals == globals
    assert test._locals == locals
    assert test._templar == templar

# Generated at 2022-06-23 13:29:09.893741
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)

    # all keys are defined in both globals and locals
    locals_1 = {"aaa": "aaa", "bbb": "bbb", "ccc": "ccc"}
    globals_1 = {"aaa": "aaa", "bbb": "bbb", "ccc": "ccc"}
    ansible_jinja_vars_1 = AnsibleJ2Vars(templar, globals=globals_1, locals=locals_1)
    for k in locals_1:
        assert k in ansible_jinja_vars_1

    # all keys are defined in globals only
   

# Generated at 2022-06-23 13:29:19.281477
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    play_context = PlayContext()
    vars = AnsibleJ2Vars(templar, {}, locals=play_context.get_variables(only_vars=True))
    assert vars['inventory_hostname'] == 'localhost'
    try:
        vars['undefined_vars']
        raise AssertionError("Should raise KeyError")
    except KeyError:
        pass
test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-23 13:29:23.819018
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.template
    templar = ansible.template.Templar(loader=None)

    # initializing J2Vars   
    j2vars = AnsibleJ2Vars(templar, globals=None, locals=None)

    locals = dict()
    locals['my_first_var'] = 10
    j2vars = j2vars.add_locals(locals)
    assert j2vars.__contains__('my_first_var')

    locals['my_second_var'] = 'some text'
    j2vars = j2vars.add_locals(locals)
    assert j2vars.__contains__('my_second_var')
   

if __name__ == '__main__':
    test_AnsibleJ2Vars_

# Generated at 2022-06-23 13:29:34.363347
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
   from ansible.vars.unsafe_proxy import wrap_var

   # Create an AnsibleJ2Vars object
   var1 = 1
   hostsvars = wrap_var({'key1': 'value'})
   templar = Templar({'var1': var1, 'hostsvars': hostsvars}, None, None)
   globals = {'globalvar': 2}
   locals = {'localvar': 3}

   ansible_j2vars_obj = AnsibleJ2Vars(templar, globals, locals)

   # Test the iterator
   keys = []
   for key in iter(ansible_j2vars_obj):
       keys.append(key)

   assert len(keys) == 4
   assert 'var1' in keys
   assert 'key1' in keys

# Generated at 2022-06-23 13:29:34.953511
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass

# Generated at 2022-06-23 13:29:42.388323
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import sys
    import os
    import json

    # Ansible modules path
    sys.path.append(
        os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            '../..',
            'lib/ansible/modules/'
            )
        )

    from ansible.template import Templar
    from ansible.module_utils.parsing.convert_bool import boolean

    data = json.load(open('sample_json_data.json'))
    temp = Templar(loader=None, variables=data)
    jvars = AnsibleJ2Vars(temp, dict())

    # check that __getitem__ returns the 'right' value
    assert jvars['key1'] == 'value1'
    assert jvars['key2'] == 2


# Generated at 2022-06-23 13:29:44.214909
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    #TODO
    pass


# Generated at 2022-06-23 13:29:56.121031
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar

    empty_dict = dict()
    t = Templar(**empty_dict)
    ansible_j2vars = AnsibleJ2Vars(t, empty_dict, locals=empty_dict)

    assert '@' not in ansible_j2vars

    ansible_j2vars._templar.available_variables = {
        '@': {'value1'}
    }

    assert '@' in ansible_j2vars

    ansible_j2vars._locals = {
        '@': {'local'}
    }

    assert '@' in ansible_j2vars

    ansible_j2vars._globals = {
        '@': {'global'}
    }

    assert '@' in ansible_j

# Generated at 2022-06-23 13:30:08.797323
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    test_template = Templar(None, None)

    test_globals = {
        'x': "global_x",
        'y': "global_y",
    }

    test_locals = {
        'x': "local_x",
        'y': "local_y",
        'z': "local_z",
    }

    test_vars = {
        'foo': 'FOO',
        'x': "vars_x",
        'y': "vars_y",
    }

    test_obj = AnsibleJ2Vars(test_template, test_globals, test_locals)
    test_template.set_available_variables(test_vars)

    expected_len = 6
    assert len(test_obj) == expected

# Generated at 2022-06-23 13:30:12.593282
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # __init__ requires a valid Templar() object. Unfortunately there
    # is no way to create one, so we we'll use a mock.
    templar = None
    globals = {}
    locals = { "foo": "bar" }
    aj2v = AnsibleJ2Vars(templar, globals, locals=locals)
    assert len(aj2v) == 1
    assert "foo" in aj2v

# Generated at 2022-06-23 13:30:21.258750
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    locals = dict()
    locals["l_1"] = 1
    locals["l_2"] = 1
    locals["context"] = None
    locals["environment"] = None
    locals["template"] = None
    locals["vars"] = dict()
    locals["vars"]["v_1"] = 1
    locals["vars"]["v_2"] = 2
    globals = dict()
    globals["g_1"] = 1
    globals["g_2"] = 2
    j2vars = AnsibleJ2Vars(None, globals, locals=locals)
    num_vars = len(j2vars)
    assert(8 == num_vars)


# Generated at 2022-06-23 13:30:31.102714
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # create mocks
    mock_templar = MagicMock()
    mock_templar.available_variables = {'a':'avalue'}
    mock_globals = {'b':'bvalue'}
    mock_locals = {'c':'cvalue'}
    # run test
    test_obj=AnsibleJ2Vars(mock_templar, mock_globals, mock_locals)
    # ensure __in__ was called correctly
    test_obj.__iter__()

# Generated at 2022-06-23 13:30:38.454061
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class DummyTemplar(object):

        def __init__(self, available_variables=()):
            self.available_variables = available_variables

        def template(self, data):
            return self.available_variables[data]

    templar = DummyTemplar(available_variables={'a': 1, 'b': 2, 'c': 3})
    local_vars = dict(a=5, b=5, c=5, d=5, e=5)

    variables = AnsibleJ2Vars(templar, local_vars)

    assert variables.add_locals(dict(x=10, y=20)) == AnsibleJ2Vars(templar, local_vars, locals=dict(x=10, y=20))
    assert variables.add_locals

# Generated at 2022-06-23 13:30:49.773294
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from jinja2 import Environment
    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    env = Environment()
    templar = Templar(env)
    # create a dict whose items will be looked up
    j2_vars_dict = {'a': AnsibleUnsafeText("original_a")}
    # create an AnsibleJ2Vars object, which will have add_locals method tested
    j2_vars = AnsibleJ2Vars(templar, globals=None, locals=j2_vars_dict)
    # create a new dict of locals
    new_locals = {'a': AnsibleUnsafeText("new_a")}
    j2_v

# Generated at 2022-06-23 13:30:58.482059
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = AnsibleJ2Vars(None, None)
    assert [x for x in templar] == []
    globals = {"global_var": 1, }
    templar = AnsibleJ2Vars(None, globals, locals=None)
    assert [x for x in templar] == ["global_var"]
    locals = {"local_var": 2, }
    templar = AnsibleJ2Vars(None, globals, locals=locals)
    assert [x for x in templar] == ["global_var", "local_var"]


# Generated at 2022-06-23 13:31:09.423400
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import new_vars_loader

    # prepare environment
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager._extra_vars = dict()
    variable_manager._options_vars = dict()
    variable_manager.set_globals(HostVars())
    templar = Templar(loader, variable_manager)
    vars = AnsibleJ2Vars(templar, dict())

    # test an existing key
    assert 'a' in vars

    # test a non existing key

# Generated at 2022-06-23 13:31:21.412168
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import unittest
    class AnsibleJ2VarsTest(unittest.TestCase):
        def test_AnsibleJ2Vars___getitem__(self):
            import ansible.parsing.yaml.objects
            t = ansible.parsing.dataloader.DataLoader()
            t = ansible.parsing.yaml.objects.AnsibleVaultYAMLObject(t)
            t = ansible.parsing.yaml.objects.AnsibleMapping.constructor(t)
            t = ansible.parsing.vault.VaultLib(t)
            t = ansible.vars.unsafe_proxy.AnsibleUnsafeText(t)
            t = ansible.template.templar.Templar(t)
            g = dict()

# Generated at 2022-06-23 13:31:29.517842
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["", "/dev/null"])

    vars_manager = VariableManager(loader=loader, inventory=inventory, version_info=dict(significant_change=False))

    vars_manager.set_inventory(inventory)
    vars_manager.add_group_vars_file("../tests/ansible/inventory/test_vars", target_no_exists="all")

# Generated at 2022-06-23 13:31:33.855080
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class MockTemplar(object):
        available_variables = {'v': 'value'}
        def template(self, v):
            return v

    j2vars = AnsibleJ2Vars(MockTemplar(), {}, locals=None)
    assert j2vars['v'] == 'value'

# Generated at 2022-06-23 13:31:42.224590
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'asdf': 'asdf', 'qwer': 'qwer'}
    j2vars = AnsibleJ2Vars(templar, globals)
    locals = {'test': 'test'}
    j2vars_copy = j2vars.add_locals(locals)
    assert len(j2vars_copy._locals.keys()) == 1
    assert len(j2vars_copy._globals.keys()) == 2
    assert j2vars_copy._locals['test'] == 'test'

# Generated at 2022-06-23 13:31:48.065148
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    templar = DummyTemplar()

    pytest_j2_vars = AnsibleJ2Vars(templar, globals={'g1': 1, 'g2': 2})

    pytest_j2_vars_1 = pytest_j2_vars.add_locals({'l1': 1, 'l2': 2})

    assert pytest_j2_vars_1._locals == {'l1': 1, 'l2': 2}
    assert pytest_j2_vars_1._templar == templar
    assert pytest_j2_vars_1._globals == {'g1': 1, 'g2': 2}



# Generated at 2022-06-23 13:31:59.213214
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    ###################################################################
    # Case 1
    ###################################################################
    # self._templar.available_variables is empty dictionary
    # __getitem__(varname) throw KeyError(undefined variable)
    data = DataLoader()
    templar = Templar(loader=data)
    globals_ = {}
    locals_ = {}
    j2vars = AnsibleJ2Vars(templar, globals_, locals_)

    try:
        j2vars['varname']
    except KeyError:
        pass
    else:
        assert False

    ###################################################################
    # Case 2
    ###################################################################
   

# Generated at 2022-06-23 13:32:06.188076
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {}
    locals = {}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert vars._templar._available_variables["omit_variable_values"] == "omit"
    assert vars._globals == {}
    assert vars._locals == {}


# vim: set expandtab shiftwidth=4:

# Generated at 2022-06-23 13:32:14.230477
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)

    inventory.set_variable('foo', 'bar')
    j2vars = AnsibleJ2Vars(Templar(), {})
    assert 'foo' in j2vars
    assert j2vars['foo'] == 'bar'

    inventory.set_variable('a', 'b')
    j2vars_new = j2vars.add_locals({'c': 'd'})

# Generated at 2022-06-23 13:32:21.325036
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Setup
    templar = 'templar'
    globals = {}
    locals = {'foo_name': 'foo_value'}
    instance_AnsibleJ2Vars = AnsibleJ2Vars(templar, globals, locals)

    # Test contains key from locals
    assert ('foo_name' in instance_AnsibleJ2Vars) == True

    # Test contains non existing key
    assert ('non_existing_key' in instance_AnsibleJ2Vars) == False



# Generated at 2022-06-23 13:32:26.936092
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = object()
    globals = {'a': 1, 'b': 1, 'c': 1}
    locals = {'c': 2, 'd': 2}
    av = AnsibleJ2Vars(templar, globals, locals=locals)
    for key in av:
        assert key in av
    assert 'f' not in av


# Generated at 2022-06-23 13:32:35.370240
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import sys
    if sys.version_info[0] < 3:
        from __builtin__ import dict
    else:
        from builtins import dict

    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None, variable_manager=None))
    globals = dict(foo='bar')
    locals = dict(foo='baz')
    proxy = AnsibleJ2Vars(templar, globals, locals=locals)

    # Test if a key is present in both locals and globals
    assert 'foo' in proxy

    # Test if a key is not present in locals but is present in globals
    assert 'bar' not in proxy

    # Test that a key is present in locals and not in globals


# Generated at 2022-06-23 13:32:44.635497
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    print('TEST: test_AnsibleJ2Vars___contains__')
    import types
    import unittest
    from ansible.module_utils.six import PY2
    import ansible.module_utils.jinja2_native.templar as templar

    class MockTemplar(templar.Templar):
        def __init__(self, vars):
            templar.Templar.__init__(self)
            self.available_variables = vars
        def template(self, x): return x

    vars = {'a': 1, 'b': 2}
    t = MockTemplar(vars)
    v = AnsibleJ2Vars(t, vars)
    for k in vars:
        assert k in v


# Generated at 2022-06-23 13:32:51.124870
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar()
    vars_obj = AnsibleJ2Vars(templar, {})
    vars_obj.add_locals(None)
    assert not hasattr(vars_obj, '_locals')

    vars_obj = AnsibleJ2Vars(templar, {})
    vars_obj.add_locals({})
    assert not hasattr(vars_obj, '_locals')

    vars_obj = AnsibleJ2Vars(templar, {})
    vars_obj.add_locals({ 'foo': 'bar' })
    assert hasattr(vars_obj, '_locals')
    assert vars_obj._locals['foo'] == 'bar'

# Generated at 2022-06-23 13:32:57.447007
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None, variables={'foo': AnsibleUnsafeText('bar')})

    # Test with existing key
    vars = AnsibleJ2Vars(templar, {'foo':'bar'})
    assert 'foo' in vars

    # Test with non existing key
    assert 'foo' not in vars
