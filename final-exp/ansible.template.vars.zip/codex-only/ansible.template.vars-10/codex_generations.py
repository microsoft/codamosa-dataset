

# Generated at 2022-06-23 13:23:03.216019
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    templar = Templar(loader=None, variables={})
    test_var = AnsibleJ2Vars(
        templar=templar,
        globals={}
    )
    # test that the variable defined in vars dict is available
    set_var = dict(test_var1=1)
    test_var._templar.set_available_variables(set_var)
    assert('test_var1' in test_var)
    # test that the variable defined in vars dict is available
    assert('test_var1' in test_var)
    # test that the variable defined in kwargs is available
    assert('test_var2' in test_var)
    # test that the variable defined in

# Generated at 2022-06-23 13:23:12.247894
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # pylint: disable=unnecessary-lambda,unused-argument
    def get_templar():
        return 'TESTTEMPLAR'

    globals_ = {'g1': 'g_val1', 'g2': 'g_val2'}
    locals_ = {'l1': 'l_val1', 'l2': 'l_val2'}

    ansible_var = AnsibleJ2Vars(get_templar(), globals_, locals_)
    assert ansible_var._templar == 'TESTTEMPLAR'
    assert ansible_var._globals == {'g1': 'g_val1', 'g2': 'g_val2'}

# Generated at 2022-06-23 13:23:19.986853
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'g1': 'g1'}
    locals = {'l1': 'l1'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    local_vars = {'l1': 'local_l1'}
    j2vars = j2vars.add_locals(local_vars)
    # local vars of j2vars should have been updated
    assert(j2vars._locals['l1'] == 'local_l1')

# Generated at 2022-06-23 13:23:27.898783
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import jinja2

    templar = jinja2.Environment()()

    vars = AnsibleJ2Vars(templar, dict())
    assert list(vars.__iter__()) == []

    vars = AnsibleJ2Vars(templar, dict(a=1))
    assert list(vars.__iter__()) == ['a']

    vars = AnsibleJ2Vars(templar, dict(a=1, b=2))
    assert list(vars.__iter__()) == ['a', 'b']


# Generated at 2022-06-23 13:23:33.131924
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    templar = Templar(loader=None, shared_loader_object=None, variables={'foo': 'bar'})
    globals = {}
    locals = {}
    play_context = PlayContext()
    obj = AnsibleJ2Vars(templar, globals, locals)
    assert obj._templar == templar
    assert obj._globals == globals
    assert obj._locals == locals
    assert len(obj) == 2

# Generated at 2022-06-23 13:23:38.878951
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    '''
    test_AnsibleJ2Vars___len__ function
    '''
    obj = AnsibleJ2Vars(None, None)
    assert len(obj) == 0
    obj._locals = {'a': 1}
    assert len(obj) == 1
    obj._templar.available_variables = {'b': 2}
    assert len(obj) == 2
    obj._globals = {'c': 3}
    assert len(obj) == 3
    obj._templar.available_variables = {'a': 1}
    assert len(obj) == 3


# Generated at 2022-06-23 13:23:49.222275
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    j2vars = AnsibleJ2Vars(Templar(), {'global_a': 'global_a'}, locals={'local_a': 'local_a'})
    assert isinstance(j2vars['global_a'], AnsibleUnsafeText)
    assert isinstance(j2vars['local_a'], AnsibleUnsafeText)
    assert sorted(list(j2vars)) == ['global_a', 'local_a']

    j2vars = AnsibleJ2Vars(Templar(), {'global_a': 'global_a'}, locals={'local_a': 'local_a'})

# Generated at 2022-06-23 13:23:58.408889
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from jinja2._compat import PY3
    from ansible.template import Templar
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    from_yaml = '''
    huey:
        dewey:
            louie:
                - 1
                - 2
                - 3
            goofy:
                - 3
                - 2
                - 1
        mickey:
            minnie:
                - 1
                - 2
                - 3
    '''
    templar = Templar(loader=None)
    templar.set_available_variables(templar.load_vars(from_yaml, StringIO()))
    test = AnsibleJ2Vars(templar, {})

    # Test without locals

# Generated at 2022-06-23 13:24:09.129390
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import copy

    from ansible.template import Templar

    # Initialize local variables to a known value
    locals = { 'a': 1, 'b': 2 }

    # Create a proxy to the local variables
    class ProxyClass:
        def __init__(self, locals):
            self.locals = locals
        def get_all_vars(self):
            return {'l_a': self.locals['a'],
                    'l_b': self.locals['b'],
                    }
    proxy = ProxyClass(locals)

    # Initialize the dict containing the available variables
    available_variables = { 'c': 1, 'd': 2 }

    # Initialize the Templar object
    templar = Templar(loader=None, variables=available_variables, shared_loader_obj=None)

    # Initialize

# Generated at 2022-06-23 13:24:19.179959
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    templar = Templar(loader=None)
    globals = {
        'gvar1': 1,
        'gvar2': 2,
    }
    vars = AnsibleJ2Vars(templar, globals)

    # Test dict iteration on vars
    assert set(vars) == set(['gvar1', 'gvar2'])

    # Test dict iteration on vars
    assert set(vars) == set(['gvar1', 'gvar2'])
    locals = {
        'gvar1': 3,
        'lvar3': 3,
    }

# Generated at 2022-06-23 13:24:28.883490
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    """Check that AnsibleJ2Vars returns the expected value when given the expected arguments"""
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    vm = VariableManager()
    dict1 = dict(k1='v1', k2='v2', k3='v3')
    dict2 = dict(k4='v4', k5='v5', k6='v6')
    dict3 = dict(k7='v7', k8='v8', k9='v9')
    vm.set_globals(dict1)
    vm.set_vars(dict2)
    vm.set_fact_cache(dict3)
    var

# Generated at 2022-06-23 13:24:31.118589
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    '''
    This is a test function of AnsibleJ2Vars class.
    '''
    # Write your own test
    pass


# Generated at 2022-06-23 13:24:40.503769
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar

    locals = dict(a=1)
    globals = dict(c=3)
    templar = Templar()

    # test with locals=None
    vars = AnsibleJ2Vars(templar, globals)
    assert vars.add_locals(None) == vars

    # test with locals=locals
    new_vars = vars.add_locals(locals)
    assert hasattr(new_vars, '_locals')
    assert new_vars._locals == locals

    # test that vars and new_vars are different objects
    new_vars._locals = dict(a=10)
    assert locals != new_vars._locals

    # test with locals with the same keys as *vars
    #
    # NOTE

# Generated at 2022-06-23 13:24:43.705822
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    test_class = AnsibleJ2Vars
    object = test_class()
    object.test = 1
    object.test1 = 2

    assert len(object) == 2


# Generated at 2022-06-23 13:24:54.356105
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    template_data = dict(
        foo=AnsibleUnsafeText("{{bar}}"),
    )

    t = Templar(loader=None, variables=template_data)
    vars = AnsibleJ2Vars(templar=t, locals=dict(bar=AnsibleUnsafeText("baz")), globals=dict())
    vars = vars.add_locals(dict(bar="baz2"))

    # locals are defined in vars (locals

# Generated at 2022-06-23 13:25:03.332302
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = Templar()
    globals = {'g': 'global'}
    vars0 = AnsibleJ2Vars(templar, globals)
    vars1 = vars0.add_locals({'l1': 'local1'})
    # vars1 should be a copy of vars0 updated with locals
    assert isinstance(vars1, AnsibleJ2Vars)
    assert vars1 != vars0
    assert vars1._locals == {'l1': 'local1'}
    # locals should not be added to existing locals
    vars2 = vars1.add_locals({'l2': 'local2'})
    assert vars2._locals == {'l1': 'local1', 'l2': 'local2'}
    # previous locals should not be

# Generated at 2022-06-23 13:25:14.543165
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import os
    import sys
    import json
    import unittest
    import tempfile

    test_ansible_home = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
    if test_ansible_home not in sys.path:
        sys.path.append(test_ansible_home)

    from ansible.templating import Templar
    from ansible.module_utils.six import PY3

    class TestAnsibleJ2Vars(unittest.TestCase):
        def setUp(self):
            self.templar = Templar(loader=None)
            self.env_dict = dict()
            self.env_dict.update(os.environ)

# Generated at 2022-06-23 13:25:17.545772
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.templating import Templar
    from ansible.vars.manager import VariableManager

    single_vm = VariableManager()
    single_vm.extra_vars = {'hostvars': {}}
    single_templar = Templar(loader=None, variables=single_vm)
    single_scope = AnsibleJ2Vars(single_templar, {})
    assert "hostvars" in single_scope

# Generated at 2022-06-23 13:25:28.768689
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    the_templar = Templar(loader=None)
    the_play = Play.load(dict(
        name='test',
        hosts='all',
        gather_facts='no',
        tasks=[],
    ), variable_manager=VariableManager(loader=None, inventory=Inventory(host_list=[])))
    the_play._variable_manager = VariableManager(loader=None, inventory=Inventory(host_list=[]))
    the_play._variable_manager._fact_cache = dict(foo='bar')
    the_play_context = PlayContext()

# Generated at 2022-06-23 13:25:36.355019
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class MockVarsModule:
        def __init__(self, available_variables):
            self.available_variables = available_variables

    globals = {'a': 'b'}
    locals = {'c': 'd'}

    var = {'e': 'f'}
    templar = MockVarsModule(var)

    var_proxy = AnsibleJ2Vars(templar, globals, locals)

    assert len(var_proxy) == 3
    assert len(var_proxy) == len(globals) + len(locals) + len(var)


# Generated at 2022-06-23 13:25:44.845907
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    var_mgr = VariableManager()
    source_obj = dict(
        a=1,
        b=2,
        c=dict(
            c1=1,
            c2=2,
        ),
    )
    template_obj = dict(
        d=1,
        e=2,
        f=dict(
            f1=1,
            f2=2,
        ),
    )
    dest_obj = dict(
        g=1,
        h=2,
        i=dict(
            i1=1,
            i2=2,
        ),
    )

    # Add a multi

# Generated at 2022-06-23 13:25:53.178164
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from collections import Counter
    from ansible.template import Templar

    templar = Templar(None, loader=None, variables={})
    vars = AnsibleJ2Vars(templar, globals={}, locals={'l_localvar': 'localvar'})
    vars_copy = vars.add_locals({'localvar': 'localvar'})
    vars_count = Counter(vars.keys())
    vars_copy_count = Counter(vars_copy.keys())

    assert vars_count == vars_copy_count
    assert vars_copy['localvar'] == 'localvar'
    assert vars_copy['l_localvar'] == 'localvar'

# Generated at 2022-06-23 13:26:05.933924
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
	from units.mock.loader import DictDataLoader
	from units.compat import unittest


# Generated at 2022-06-23 13:26:16.352973
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    inputs = {
        'foo': 'bar',
        'blue': 'red',
        'name': 'kyle',
    }

    def mock_available_variables(self):
        return inputs

    templar = Templar()
    templar.available_variables = mock_available_variables.__get__(templar, Templar)

    vars = AnsibleJ2Vars(templar, {})
    try:
        assert len(vars) == 3
        assert vars['name'] == 'kyle'
        assert vars['foo'] == 'bar'
        assert vars['blue'] == 'red'
    except:
        raise


# Generated at 2022-06-23 13:26:28.569971
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    a = AnsibleJ2Vars(Templar(), locals={})
    assert len(a) == 0

    b = AnsibleJ2Vars(Templar({}), locals={})
    assert len(b) == 0

    c = AnsibleJ2Vars(Templar({}), locals={'d':'c'})
    assert len(c) == 1
    c['e'] = 'e'
    assert len(c) == 2
    del c['e']
    assert len(c) == 1


# Generated at 2022-06-23 13:26:33.398958
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
  globals = {'a': 1, 'b': 2}
  locals = {'c': 3, 'd': 4}
  templar = object
  ansiblej2vars = AnsibleJ2Vars(templar, globals, locals)
  assert(len(ansiblej2vars) == 3)

# Generated at 2022-06-23 13:26:45.633866
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    import jinja2

    my_locals = { 'foo': 'bar' }
    templar = Templar()
    # Initialize with the local variables
    ansible_j2_vars = AnsibleJ2Vars(templar, globals={}, locals=my_locals)
    # Initialize with the local variables
    ansible_j2_vars = AnsibleJ2Vars(templar, globals={}, locals=my_locals)

    # Push the vars with locals
    ansible_j2_vars = ansible_j2_vars.add_locals(my_locals)


# Generated at 2022-06-23 13:26:52.863785
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(None, None, None, loader=None)
    dict_one = dict(list_one=list(range(10)))
    dict_two = dict(list_two=list(range(20)))
    dict_three = dict(list_three=list(range(30)))
    obj = AnsibleJ2Vars(templar, dict_one, dict_two)
    obj.update(dict_three)
    assert len(obj) == 3
    assert len(obj) == 6
    assert len(obj) == 9
    assert len(obj) == 12


# Generated at 2022-06-23 13:27:04.127274
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.template

    templar = ansible.template.AnsibleJ2Template("templar", "dict_loader")

    variables = dict(
        foo='FOO',
        bar='BAR',
        baz='BAZ',
    )

    # False case: key not in the dict
    aj2v = AnsibleJ2Vars(templar, dict(), dict(foo=variables['foo']))
    assert('baz' not in aj2v)

    # True case: key in the dict
    assert('foo' in aj2v)

    # True case: key in the templates
    aj2v._templar.available_variables = dict(bar=variables['bar'])
    assert('bar' in aj2v)

    # True case: key in the glob

# Generated at 2022-06-23 13:27:14.351731
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import copy
    import json
    import pytest
    from ansible.errors import AnsibleError

    from ansible.module_utils import basic
    from ansible.vars import VariableManager

    def get_ansible_module(argv, **kw):
        global_args = pytest.global_args(**kw)
        mod = basic._AnsibleModule(
            argument_spec=dict(
                json_data=dict(default=None),
            ),
        )
        mod.params['json_data'] = json.dumps(argv)
        mod.exit_json = exit_json
        variable_manager = VariableManager()
        variable_manager.extra_vars = global_args
        variable_manager.options_vars = {'output_file': '/dev/null'}
        variable_manager.run_once

# Generated at 2022-06-23 13:27:24.349848
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Method add_locals is tested for different types of locals
    '''
    from ansible.template import Templar
    from collections import Mapping

    templar = Templar()
    templar.set_available_variables({'name': 'ABC'})

    ansible_j2vars = AnsibleJ2Vars(templar, {})
    assert(ansible_j2vars['name'] == 'ABC')

    locals = {'name': 'XYZ', 'test': 'PQR'}
    ansible_j2vars_with_locals = ansible_j2vars.add_locals(locals)
    assert(ansible_j2vars_with_locals['name'] == 'XYZ')

# Generated at 2022-06-23 13:27:30.756258
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    # setup
    templar = Templar()
    globals = dict()
    locals = dict()
    ansible_var = dict()
    ansible_var['a'] = 'aa'
    ansible_unsafe_var = AnsibleUnsafeText('aa')
    ansible_unsafe_var.__UNSAFE__ = True
    ansible_host_var = HostVars()
    ansible_host_var['a'] = 'aa'
    locals['a'] = 'aa'
    locals['b'] = 'bb'
    locals['c'] = 'cc'
    ansible_var['c'] = 'cc'
    vars_proxy_obj = AnsibleJ

# Generated at 2022-06-23 13:27:40.009123
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = "templar"
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2Vars(templar, locals, globals)

    # test when variable is not in dict
    dict1 = dict()
    dict2 = {"var" : "var"}
    dict3 = dict()
    dict4 = {"var" : "var"}
    templar.available_variables = dict2
    globals.update(dict1)
    locals.update(dict3)
    assert "var" not in j2vars
    del dict1
    del dict2
    del dict3
    del dict4

    # test when variable is in 'templar.available_variables'
    dict1 = dict()
    dict2 = {"var" : "var"}
    dict3

# Generated at 2022-06-23 13:27:44.414090
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class AnsibleUndefinedVariable:

        def message(self):
            return "undefined"

    class AnsibleError:

        def __init__(self, msg):
            self.message = msg

    # Set-up mocks and test object
    templar1 = Templar(loader=None, variables=VariableManager())
    templar1.available_variables = dict()

    templar2 = Templar(loader=None, variables=VariableManager())
    templar2.available_variables = dict()
    templar2.available_variables["A"] = dict()
    templar2.available_variables["B"] = dict()
    templar2.available_vari

# Generated at 2022-06-23 13:27:53.056183
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Tests that add_locals on a AnsibleJ2Vars instance adds new locals without
    destroying original locals

    :return: None
    '''
    # create AnsibleJ2Vars instance
    templar = None
    globals = {}
    locals = {'foo': 'bar'}

    vars = AnsibleJ2Vars(templar, globals, locals=locals)

    assert len(vars._locals) == 1, 'len(vars._locals) is %s instead of 1' % len(vars._locals)

    # testing vars after adding locals
    new_locals = {'baz': 'qux'}

    vars = vars.add_locals(new_locals)


# Generated at 2022-06-23 13:28:03.005142
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.vault import VaultLib
    from ansible.templating import Templar
    class FakeVaultSecret:
        def __init__(self):
            self.vault_id = ''
    class FakeSecret:
        def __init__(self):
            self.vault = FakeVaultSecret()

    templar = Templar(vault_secrets=[FakeSecret()],
                      vault_password='',
                      loader=None)
    globals = {}
    locals = {}
    vars = AnsibleJ2Vars(templar, globals, locals)

    # argument not found
    assert 'variable' not in vars

    # argument found
    globals['variable'] = 1
    assert 'variable' in vars
    del(globals['variable'])

    # argument found
   

# Generated at 2022-06-23 13:28:11.659718
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.playbook.templar import Templar

    templar = Templar(loader=None)
    ansible_j2vars = AnsibleJ2Vars(templar, None)

    varname = 'varrrr'
    try:
        ansible_j2vars[varname]
        assert False
    except KeyError as e:
        assert e.args[0] == "undefined variable: %s" % varname
    except Exception as e:
        assert False

# Generated at 2022-06-23 13:28:20.258040
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2

    def check(vars_dict, varnames, expected):
        assert set(varnames) == expected, 'expected %r but got %r' % (expected, set(varnames))

    # Setup
    templar = jinja2.Environment()

    # Test
    vars1 = AnsibleJ2Vars(templar={'available_variables': {'a': 'b'}}, globals={'c': 'd'})
    check(vars1, vars1.keys(), {'a', 'c'})
    check(vars1, vars1.keys(), {'a', 'c'})


# Generated at 2022-06-23 13:28:31.388965
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.constants import DEFAULT_JINJA2_NATIVE_STR
    from ansible.plugins.loader import jinja2_loader

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(a='moo'))
    variable_manager.set_host_variable('localhost', 'b', 'cow')
    variable_manager.set_host_variable('localhost', 'c', 'moocow')

    mgr = Templar(loader=jinja2_loader, variables=variable_manager, shared_loader_obj=None, fail_on_undefined=False, **DEFAULT_JINJA2_NATIVE_STR)


# Generated at 2022-06-23 13:28:38.323981
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    aj2vars = AnsibleJ2Vars(templar, {}, {})
    # Warning: Please keep the dict keys sorted
    aj2vars._templar.available_variables = { 'k1': 'v1', 'k2': 'v2' }

    assert 'k2' in aj2vars


# Generated at 2022-06-23 13:28:45.860571
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.templating import Templar

# Generated at 2022-06-23 13:28:55.891003
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native, to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.safe_eval import unsafe_eval

    def _templar(src, fail_on_undefined=False, preserve_trailing_newlines=False,
                 convert_bare=False, convert_data=False, static_vars=None,
                 templar=None, disable_lookups=False, loader=None,
                 fail_on_lookup_errors=True, **kwargs):
        if not isinstance(src, str):
            raise AnsibleError("error templating term: %s" % to_text(src))
        else:
            import jinja2.environment

# Generated at 2022-06-23 13:29:08.458162
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    a = AnsibleJ2Vars(Templar(None, loader=None, shared_loader_obj=None, variables={'hostvars': {'host': {'x': '42'}}}), {})

    assert 'hostvars' in a
    assert 'hostvars.host.x' in a
    assert 'hostvars.host.y' not in a
    assert 'missing.stuff' not in a
    assert 'missing' not in a
    assert 'foo' not in a  # must not exist

    a = AnsibleJ2Vars(Templar(None, loader=None, shared_loader_obj=None, variables={}), {'foo': 42})

    assert 'foo' in a

# Unit test

# Generated at 2022-06-23 13:29:16.892042
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars import VariableManager # to get a Templar
    from ansible.playbook.play_context import PlayContext
    import jinja2
    play_context = PlayContext()
    variable_manager = VariableManager(loader=None, variables=dict(a=1, b=2, c=3))
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=variable_manager, play_context=play_context)
    vars = AnsibleJ2Vars(templar, globals=None)
    ret = set(['a', 'b', 'c'])
    assert set(vars) == ret


# Generated at 2022-06-23 13:29:23.795497
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2

    templar = jinja2.Environment().from_string("{{ x.vars.size() }}").render(
        x={'vars': AnsibleJ2Vars(templar=None, globals={}, locals={'size': lambda: 42})})

    assert templar == "42"

if __name__ == '__main__':
    __import__('pytest').main([__file__])

# Generated at 2022-06-23 13:29:30.238744
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Instantiate the class
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.vars.templar import Templar
    from ansible.playbook.vars.manager import VariableManager
    from ansible.playbook.inventory.host import Host
    from ansible.playbook.inventory.group import Group
    from ansible.playbook.play_context import PlayContext
    from ansible.template import AnsibleTemplar
    from ansible.vars.hostvars import HostVars
    from ansible.utils.unsafe_proxy import wrap_var

    templar = Templar(loader=None, variables={})
    globals = {'empty': 'global'}
    locals = {'empty': 'local'}

# Generated at 2022-06-23 13:29:35.774747
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2

    templar = jinja2.Environment().from_string('{{a}}').globals
    globals = {'a': 1}
    locals = {}

    ansible_vars = AnsibleJ2Vars(templar, globals, locals)

    assert len(ansible_vars) == 1, 'len failed'


# Generated at 2022-06-23 13:29:36.808195
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # TODO create a test here
    return

# Generated at 2022-06-23 13:29:43.431453
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    vars_ = {}


# Generated at 2022-06-23 13:29:55.665500
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    const_templar_obj = 'hello'
    const_globals_obj = 'world'
    const_locals_obj = {'item': 'value'}

    expected_locals = const_locals_obj.copy()

    proxy = AnsibleJ2Vars(const_templar_obj, const_globals_obj)
    new_proxy = proxy.add_locals(const_locals_obj)

    assert new_proxy != proxy
    assert new_proxy._templar == proxy._templar
    assert new_proxy._globals == proxy._globals
    assert new_proxy._locals == expected_locals

    new_proxy = proxy.add_locals(None)

    assert new_proxy == proxy
    assert new_proxy._templar == proxy._templar


# Generated at 2022-06-23 13:30:01.062349
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class TemplarMock(object):
        def __init__(self, **kwargs):
            self.available_variables = kwargs
            self.variables = AnsibleJ2Vars(self, globals={}, locals=None)

        def template(self, *args, **kwargs):
            return None

    templar = TemplarMock(hostvars=dict(), general=dict(), l_general=dict())
    locals = dict(general=dict(foo='bar'))
    vars = templar.variables.add_locals(locals)
    assert vars['general']['foo'] == 'bar'

# Generated at 2022-06-23 13:30:11.284388
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.play_context import PlayContext

    templar = Templar(PlayContext())
    templar.template = lambda x: x
    templar.available_variables = dict(existing='existing')

    aj2vars1 = AnsibleJ2Vars(templar, dict(existing='existing'))
    aj2vars2 = AnsibleJ2Vars(templar, dict(existing='existing'), dict(a=1, b=2))
    aj2vars3 = AnsibleJ2Vars(templar, dict(existing='existing', a=3, b=4))


# Generated at 2022-06-23 13:30:21.871752
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import jinja2
    from ansible.parsing.vault import VaultLib
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    vault_pass = 'secret'
    vault = VaultLib([])
    vault.read_password_file()
    vault.secrets = vault.decrypt(vault_pass)

    templar = Templar(loader=None, variables={}, shared_loader_obj=jinja2.FileSystemLoader('/foo/bar'))
    templar._environment = jinja2.Environment()
    templar._templates = {}
    templar._vault = vault

# Generated at 2022-06-23 13:30:34.114980
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template.templar import Templar

    # Setup the dataloader
    loader = DataLoader()

    # Setup the variable manager
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)

    # Setup the templar
    templar = Templar(loader=loader, variables=variable_manager)

    # Setup the AnsibleJ2Vars object:
    # We give a template and retrieve it as 'vars'
    data = {"foo": "bar"}
    vars_proxy = AnsibleJ2Vars(templar, {"vars": data}, locals={"foo": "baz"})

    # AnsibleJ2Vars is a read-only dict

# Generated at 2022-06-23 13:30:41.184952
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    templar = "A Templar object"
    globals = "Global vars"
    locals = "Local vars"
    foo = "Foo"
    ansible_vars = [ "bar", "baz" ]

    proxy = AnsibleJ2Vars( templar, globals, locals )

    assert proxy.add_locals({foo: "foo"})._locals == {foo: "foo", "bar": ansible_vars[0], "baz": ansible_vars[1]}

    assert proxy.add_locals(None)._locals == {"bar": ansible_vars[0], "baz": ansible_vars[1]}

# Generated at 2022-06-23 13:30:46.198246
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    t = Templar(loader=None, variables={'foo' : 'bar'})
    v = AnsibleJ2Vars(t, {})
    assert v['foo'] == 'bar'


# Generated at 2022-06-23 13:30:54.456486
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    globals = dict(g1=1,g2=2,g3=3)
    locals = dict(l1=11,l2=22,l3=33)
    available_variables = dict(a1=111,a2=222,a3=333)

    class Templar:
        def __init__(self):
            pass
        def template(self,variable):
            return variable
        @property
        def available_variables(self):
            return available_variables

    templar = Templar()

    my_vars = AnsibleJ2Vars(templar,globals,locals)

    # test __contains__()
    assert len(my_vars) == 9
    assert "g1" in my

# Generated at 2022-06-23 13:31:05.564900
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved

    var_templar = Reserved(None, None)
    var_globals = dict(ansible_version={"first": 123})
    var_locals = dict(ansible_version={"second": 456})
    var_locals_invalid = dict()

    ansible_vars = AnsibleJ2Vars(var_templar, var_globals, locals=var_locals)

    key = "ansible_version"
    value = ansible_vars[key]
    assert isinstance(value, HostVars)
    assert value == {"first": 123, "second": 456}

    key = "invalid"


# Generated at 2022-06-23 13:31:15.414803
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager)

    # test if an init works
    vars = AnsibleJ2Vars(templar=templar, globals=None)
    assert isinstance(vars, AnsibleJ2Vars)

    # test if available_variables are results of __contains__
    variable_manager.set_variable('foo', 'bar')
    assert 'foo' in variable_manager.get_vars()
    assert 'foo' in vars

    # test if __getitem__ returns value of variable_manager
    assert vars['foo'] == variable_manager.get_vars()['foo']

# Generated at 2022-06-23 13:31:17.823705
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # TODO: modify this unit test when we support python 3
    assert AnsibleJ2Vars is not None

# Generated at 2022-06-23 13:31:27.784319
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Test: Test len() for an empty AnsibleJ2Vars object
    var_manager = VariableManager()
    templar = Templar(var_manager, loader=None)
    aj2v = AnsibleJ2Vars(templar, globals={})
    assert len(aj2v) == 0

    # Test: Test len() for an AnsibleJ2Vars object
    var_manager = VariableManager()
    var_manager.set_variable('a', 1)
    templar = Templar(var_manager, loader=None)
    aj2v = AnsibleJ2Vars(templar, globals={})
    assert len(aj2v) == 1

    # Test: Test len() with locals
    var_manager

# Generated at 2022-06-23 13:31:39.265602
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    from ansible.template import Templar
    templar = Templar(loader=None)

    # Test with None as locals parameter
    vars = AnsibleJ2Vars(templar, {}, None)
    assert vars == {}
    assert vars.add_locals(None) == {}

    vars = AnsibleJ2Vars(templar, {}, dict())
    assert vars == {}
    assert vars.add_locals(None) == {}

    # Test with empty dictionary as locals paramer
    vars = AnsibleJ2Vars(templar, {}, dict())
    assert vars == {}
    assert vars.add_locals(dict()) == {}

    vars = AnsibleJ2Vars(templar, {}, {"key1": 1})
   

# Generated at 2022-06-23 13:31:40.604310
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # How to test large dictionaries for equivalence?
    assert 2==2



# Generated at 2022-06-23 13:31:48.646033
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    import unittest

    templar = Templar(loader=None)
    globals = {'gvar': 'global'}
    vars = AnsibleJ2Vars(templar, globals)

    test_cases = list()

    test_cases.append(
        {
            'name': 'no locals',
            'in_locals': None,
            'want_locals': {},
        }
    )

    test_cases.append(
        {
            'name': 'simple locals',
            'in_locals': {'lvar': 'local'},
            'want_locals': {'lvar': 'local'},
        }
    )


# Generated at 2022-06-23 13:31:59.432997
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import types
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    ansible_vars = {"ansible_architecture": "x86_64"}
    inventory_hostname = "test"
    inventory_variables = {"test": "test_variable"}
    play_hosts = ["test", "test2"]

    test_vars = AnsibleJ2Vars(Templar(vault_secrets=[VaultLib(password_file=None)]),
        inventory_hostname, ansible_vars, inventory_variables,
        play_hosts)

    assert test_vars._globals["inventory_hostname"] == inventory_hostname

    # AnsibleJ2Vars should be a mapping

# Generated at 2022-06-23 13:32:10.064720
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import jinja2
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars_precedence
    from ansible.vars import VariableManager

    templar = jinja2.Environment(loader=jinja2.FileSystemLoader('')).get_template('').environment.from_string
    vars_manager = VariableManager()
    loader = jinja2.DictLoader({})
    vault = VaultLib(None)
    templar.set_available_variables(combine_vars(loader=loader, vault_password=vault.password, all_vars=vars_manager.get_vars(play=None)), vault.password)

    aj2v = Ansible

# Generated at 2022-06-23 13:32:17.392373
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as f:
        j2_vars = AnsibleJ2Vars(Templar(VariableManager()), {})
        j2_vars['something'] = f.name

        assert j2_vars['something']
        assert j2_vars['something'] == f.name

# Generated at 2022-06-23 13:32:27.118333
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    t = Templar()
    v = AnsibleJ2Vars(t, {}, {'local1': 1})
    v2 = v.add_locals({'local2': 2})
    assert v2['local1'] == 1
    assert v2['local2'] == 2

    v3 = v.add_locals(None)
    assert v3['local1'] == 1
    try:
        v3['local2']
        assert False, "AnsibleJ2Vars.__getitem__ should raise KeyError and not return None"
    except KeyError:
        pass

# Generated at 2022-06-23 13:32:37.882000
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.vault import VaultLib
    templar = VaultLib()
    globals = {}
    locals = {}
    vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert vars.__iter__() == []
    vars._templar.available_variables = {'key1':'value1', 'key2':'value2'}
    vars._locals = {'key3':'value3', 'key4':'value4'}
    vars._globals = {'key5':'value5', 'key6':'value6'}
    assert set(vars.__iter__()) == set(['key1', 'key2', 'key3', 'key4', 'key5', 'key6'])

# Unit

# Generated at 2022-06-23 13:32:46.450903
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible import templar as templar_m
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib

    templar_m.set_available_variables(dict(a=1, b=2, c=3))

    j2vars = AnsibleJ2Vars(templar_m, dict(d=4, e=5, f=6))
    assert 'a' in j2vars
    assert 'b' in j2vars
    assert 'c' in j2vars
    assert 'd' in j2vars
    assert 'e' in j2vars
    assert 'f' in j2vars
    assert 'x' not in j2vars

    templar_m.available_variables = None
   

# Generated at 2022-06-23 13:32:49.975344
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    templar = None
    globals = None
    locals = None
    Aj2V = AnsibleJ2Vars(templar, globals, locals)
    assert Aj2V.__contains__('foo') is False


# Generated at 2022-06-23 13:32:56.248504
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar

    ajv = AnsibleJ2Vars(templar=Templar(loader=None, variables={}),
                        globals={},
                        locals={"var0": safe_eval("var0"),
                                "var2": 2})
    # len should return 3
    assert len(ajv) == 3

