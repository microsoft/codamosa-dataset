

# Generated at 2022-06-23 13:23:05.612314
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    templar = Templar(loader=None)
    globals = dict(hostvars=HostVars())
    locals = dict(ansible_facts={}, l_group_names="group1,group2,group3")
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)

    assert 'ansible_facts' in ansible_j2_vars
    assert isinstance(ansible_j2_vars['ansible_facts'], Mapping)

    assert 'group_names' in ansible_j2_vars

# Generated at 2022-06-23 13:23:09.745289
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    globals = {'a': 'a'}
    locals = {'b': 'b'}
    templar = {'c': 'c'}

    obj = AnsibleJ2Vars(templar, globals, locals)
    assert {'a', 'b', 'c'} == set(obj)


# Generated at 2022-06-23 13:23:17.480261
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, {}, {})
    l_test_var = 'test_var'
    j2vars._locals[l_test_var] = l_test_var

    j2vars.__contains__ = lambda self, k: True

    for k in j2vars:
        if k == l_test_var:
            break
    else:
        raise Exception("Error in test_AnsibleJ2Vars___iter__")


# Generated at 2022-06-23 13:23:27.898479
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars

    # Two-level nested variable
    variable = UnsafeProxy(
        {"var1": "{{ var2 }}", "var2": "{{ var3 }}", "var3": "{{ var4 }}", "var4": "{{ var5 }}",
         "var5": "{{ var6 }}", "var6": "{{ var7 }}", "var7": "value"})

    # Length of variables
    assert len(variable) == 7

    # Test AnsibleJ2Vars.__len__ with UnsafeProxy variable case
    assert len(AnsibleJ2Vars(Templar(), dict(), dict(ansible_unsafe=variable))) == 7

    # Test

# Generated at 2022-06-23 13:23:33.911755
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.playbook.play_context import PlayContext
    from ansible.templar import Templar

    vars = {'var': 'var_value'}
    globals = {'global': 'global_value'}
    play_context = PlayContext()
    templar = Templar(loader=None, variables=vars, play_context=play_context)

    j2_vars = AnsibleJ2Vars(templar, globals)

    assert 'var' in j2_vars
    assert 'global' in j2_vars
    assert 'var_1' not in j2_vars


# Generated at 2022-06-23 13:23:39.241830
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {}
    j2vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=None)
    assert len(j2vars) == 0


# Generated at 2022-06-23 13:23:49.471619
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import jinja2
    from ansible.plugins.loader import fragment_loader
    from ansible.template import Templar


# Generated at 2022-06-23 13:23:55.819507
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Creating a template using python jinja2 module
    import jinja2
    j2_template = jinja2.Template('{{ foo }}')

    # Executing the template and waiting for the result
    from ansible.template import Templar
    templar = Templar(loader=None)
    templar._available_variables = {'foo': 'bar'}
    var_proxy = AnsibleJ2Vars(templar, globals=dict())

    assert len(var_proxy) == 1

# Generated at 2022-06-23 13:24:02.202199
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar(object):
        '''
        Class for unit testing of AnsibleJ2Vars
        '''
        available_variables = {
            'var_1': 'TEST_1',
            'var_2': 'TEST_2',
            'var_3': 'TEST_3',
            }

        def __init__(self):
            pass

        def template(self, data):
            return data

    class Locals(Mapping):
        '''
        Class for unit testing of AnsibleJ2Vars
        '''
        def __init__(self, locals):
            self._locals = locals

        def __contains__(self, k):
            if k in self._locals:
                return True
            return False


# Generated at 2022-06-23 13:24:12.994537
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template.safe_eval import undefs
    from ansible.template.templar import Templar
    from ansible.template import Templar
    from ansible.template.template import AnsibleJ2Template

    templar = Templar(loader=None, variables={'my_var': 'my_value'})
    globals_ = dict()
    locals_ = dict()
    jvars = AnsibleJ2Vars(templar, globals_, locals=locals_)

    # Check "in" operator
    assert 'my_var' in jvars
    assert 'missing_var' not in jvars

    # Check "dict in dict" operator
   

# Generated at 2022-06-23 13:24:22.073697
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types

    # Create a mock jinja2.Environment()
    from jinja2 import Environment, Template
    j2_en = Environment()

    # Create a mock AnsibleJ2Template
    from ansible.parsing.ajs2 import AnsibleJ2Template
    aj2t = AnsibleJ2Template(j2_en.from_string("my_var: {{ my_var }}"))

    # Create a mock AnsibleJ2Vars
    from ansible.parsing.ajs2 import AnsibleJ2Vars
    aj2v1 = AnsibleJ2Vars("no templar", "no globals")

    # Create a mock AnsibleTemplar()


# Generated at 2022-06-23 13:24:30.103838
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    This method tests the __getitem__ method of class AnsibleJ2Vars
    '''

    import ansible.template
    import ansible.vars.hostvars
    import ansible.utils.unsafe_proxy

    # Create the templar object needed by the AnsibleJ2Vars object to be tested.
    templar = ansible.template.Templar(loader=None)

    # Create the objects needed to create the AnsibleJ2Vars object to be tested.
    #
    # The templar.available_variables dictionary.

# Generated at 2022-06-23 13:24:35.822828
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    a_dict = dict()
    a_dict['name'] = 'Joe'
    a_dict['age'] = '12'

    b_dict = dict()
    b_dict['name'] = 'Sarah'
    b_dict['age'] = '21'
    b_dict['test_key'] = 'test_value'

    # Initialize an object of class AnsibleJ2Vars
    # __init__(self, templar, globals, locals=None):
    # templar.available_variables = a_dict and b_dict
    # globals = None
    # locals =

# Generated at 2022-06-23 13:24:47.209755
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    templar = Templar(loader=None)
    j2vars = AnsibleJ2Vars(templar, globals=dict())
    assert len(j2vars) == 0
    assert isinstance(j2vars, Mapping)
    templar.available_variables = dict()
    assert len(j2vars) == 0

    templar.available_variables = dict(dict(a=None))
    assert len(j2vars) == 1

    templar.available_variables = dict(a=None, b=None)

# Generated at 2022-06-23 13:24:57.888056
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals=locals)
    # case where the variable does not exist in the templar, globals or locals
    # test: missing_variable raises a KeyError
    varname = 'missing_variable'
    try:
        ansible_j2vars.__getitem__(varname)
        assert False
    except KeyError:
        assert True
    # case where the variable exists in the templar
    # test: variable_value equals the expected value of variable with name variable_name
    variable_name = 'variable_name'
    variable_value = 'variable_value'
    templ

# Generated at 2022-06-23 13:25:05.471123
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import collections
    from ansible.module_utils.six import iteritems
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # initialize AnsibleJ2Vars
    templar = Templar(loader=DataLoader())
    my_globals = dict()
    my_globals['a'] = 1
    my_globals['b'] = 2
    my_locals = dict()
    my_locals['l_c'] = 3
    my_locals['l_c'] = 4
    my_vars = AnsibleJ2Vars(templar, globals=my_globals, locals=my_locals)

    # test __iter__

# Generated at 2022-06-23 13:25:16.590732
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class TestTemplar():
        def __init__(self):
            self.available_variables = {'var1': 'value1', 'var2': 'value2'}

        def template(self, variable):
            return variable

    # Test with empty globals and locals
    vars = AnsibleJ2Vars(TestTemplar(), {}, {})
    assert list(iter(vars)) == ['var2', 'var1']

    # Test with empty globals
    vars = AnsibleJ2Vars(TestTemplar(), {}, {'local1': 'value1', 'local2': 'value2'})
    assert list(iter(vars)) == ['local2', 'local1', 'var2', 'var1']

    # Test with empty locals

# Generated at 2022-06-23 13:25:21.520258
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})

    # When an available variable is requested
    # Then Expected result is the value of that variable in the templar
    ansible_j2_vars = AnsibleJ2Vars(templar, dict())
    templar.set_available_variables({'a_var': 'a_value'})
    assert ansible_j2_vars['a_var'] == 'a_value'

    # When a local variable is requested
    # Then Expected result is the value of that local variable in the templar
    ansible_j2_vars = AnsibleJ2Vars(templar, dict(), {'a_local_var': 'a_local_value'})
    assert ansible_j2_vars

# Generated at 2022-06-23 13:25:31.615930
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import to_safe_object
    templar = Templar(loader=None)
    globals = dict()
    locals = dict()
    j2vars = AnsibleJ2Vars(templar, globals, locals)
    locals['l_var1'] = 'local'
    j2vars = j2vars.add_locals(locals)
    assert j2vars['var1'] == 'local'
    assert j2vars['l_var1'] == 'local'
    assert j2vars['l_var2'] == 'local'
    assert j2vars

# Generated at 2022-06-23 13:25:34.944490
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import ansible.template.template as ansible_template

    globals = {}
    locals = {}
    templar = ansible_template.Templar(loader=None)
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert list(vars.keys()) == ['environment', 'template']

# Generated at 2022-06-23 13:25:38.648635
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    vars_dict = dict( foo='bar' )
    vars_obj = AnsibleJ2Vars(None, vars_dict)
    assert 'foo' in vars_obj
    assert vars_obj.__contains__('foo')


# Generated at 2022-06-23 13:25:48.968618
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    import ansible.module_utils.common.collections as collections
    import ansible.template as template
    import ansible.vars.unsafe_proxy as unsafe_proxy

    def test_fn(self, varname):
        return 1

    # testing a KeyError with a KeyError
    unsafe_proxy.UNSAFE_ERROR_MSG = test_fn
    # with a KeyError
    templar = template.AnsibleTemplar()
    globals = {'foo': 'bar'}
    locals = {'bar': 'foo'}
    j = AnsibleJ2Vars(templar, globals, locals)
    with pytest.raises(KeyError) as exc:
        j.__getitem__('babar')

# Generated at 2022-06-23 13:26:00.949430
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader())
    l = {
        'a': 'b',
        'c': HostVars(),
        'd': dict()
    }

    v = AnsibleJ2Vars(templar, {}, locals=l)
    v1 = v.add_locals({'d': 'e', 'f': 'g'})
    assert v1['a'] == 'b'
    assert v1['c'] == HostVars()
    assert v1['d'] == 'e'
    assert v1['f'] == 'g'

    v2 = v.add_locals(None)
    assert v

# Generated at 2022-06-23 13:26:10.538640
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    class TestDict(dict):
        def __init__(self, **kwargs):
            self.dict = kwargs

        def update(self, **kwargs):
            for key, val in iteritems(kwargs):
                self.dict[key] = val

    class TestJinja2Template(object):
        def __init__(self, **kwargs):
            self.available_variables = TestDict(**kwargs)

        def template(self, variable):
            return variable


    vars_dict = { 'key1': 'val1', 'key2': 'val2' }

    test_j2vars = AnsibleJ2Vars(TestJinja2Template(**vars_dict), {})

    assert test_j2vars.__len__() == 2
    assert test_j2

# Generated at 2022-06-23 13:26:21.167300
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    templar = Templar(loader=DataLoader(), variables={})
    group = InventoryManager(loader=DataLoader(), sources=['myhost']).groups['all']
    proxy = AnsibleJ2Vars(templar, group.vars)
    assert len(proxy) > 0
    assert proxy['inventory_file'] == 'myhost'
    assert 'groups' in proxy
    assert 'inventory_dir' in proxy
    assert 'inventory_file' in proxy

    proxy = AnsibleJ2Vars(templar, globals={})
    assert len(proxy) == 0
    assert 'groups' not in proxy
    assert 'inventory_dir' not in proxy

# Generated at 2022-06-23 13:26:33.255549
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.vault import VaultLib
    import json
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    vault_pass = 'secret'
    # Convert vault_pass from str to bytes for py3, otherwise
    #   the call to update_vault() will raise a TypeError
    if not isinstance(vault_pass, bytes):
        vault_pass = vault_pass.encode('utf8')
    loader, inventory, variable_manager = CLIENT_COMPAT_CONFIG()
    variable_manager.extra_vars = {'secret': 'password123'}
    variable_manager.update_vault(vault_pass)
    play_context = PlayContext()

# Generated at 2022-06-23 13:26:45.436565
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():

    # Test with empty input parameters
    ansible_vars = AnsibleJ2Vars([], [])
    assert ansible_vars is not None, 'AnsibleJ2Vars is None'
    assert len(ansible_vars) == 0, 'AnsibleJ2Vars is not empty'

    # Test with empty locals
    ansible_vars = AnsibleJ2Vars([], [], dict())
    assert ansible_vars is not None, 'AnsibleJ2Vars is None'
    assert len(ansible_vars) == 0, 'AnsibleJ2Vars is not empty'

    # Test with locals with a valid key
    ansible_vars = AnsibleJ2Vars([], [], {'key1': 'hello'})

# Generated at 2022-06-23 13:26:50.018773
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible
    import ansible.module_utils.common.collections
    import ansible.template.template
    import ansible.template._variables
    import ansible.utils.unsafe_proxy

    # Create an AnsibleJ2Vars instance
    globals = dict()
    locals = dict()
    templar = ansible.template.template.Templar(loader=None)

    ansible_j2_vars = ansible.template._variables.AnsibleJ2Vars(templar, globals, locals)

    # Verify method add_locals
    locals = dict()
    ansible_j2_vars.add_locals(locals)
    assert type(ansible_j2_vars) == ansible.template._variables.AnsibleJ2Vars


# Generated at 2022-06-23 13:27:01.640963
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    print ("Starting test_AnsibleJ2Vars___iter__")
    import os
    import sys
    import json
    import unittest

    TEST_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    FILTERS_DIR = os.path.join(TEST_DIR, 'filter_plugins')

    sys.path.append(FILTERS_DIR)

    from ansible import constants as C
    from ansible.template import Templar
    from jinja2.environment import Environment
    from jinja2.loaders import DictLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-23 13:27:10.770937
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    l_one = "one"
    l_two = "two"
    p_one = "one"
    p_two = "two"
    t_one = "one"
    t_two = "two"
    templar = None
    locals = {"one": l_one, "two": l_two}
    globals = {"one": p_one, "two": p_two}
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)
    keys = set(ansible_vars)
    expected_keys = set(['one', 'two'])
    assert keys == expected_keys

# Generated at 2022-06-23 13:27:20.231212
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # AnsibleJ2Vars class needs Templar class to work properly.
    # However, since Templar class is not available here in module_utils, we
    # have to create it ourselves.
    # Note that this class is very dummy and is not a valid Templar class.
    # We just need to ensure that it has expected attributes and methods to
    # pass the assertion test below.
    class Templar:
        def __init__(self):
            self.available_variables = {'a':1, 'b':2, 'c':3, 'd':4}
        def template(self, variable):
            return self.available_variables[variable]

    # Create dummy AnsibleJ2Vars object with dummy 'Templar' object.
    templar = Templar()
    globals = {'a':1, 'b':2}
    locals

# Generated at 2022-06-23 13:27:23.237063
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    j2vars = AnsibleJ2Vars(None, None)
    assert(len([*j2vars]) == 0)
#


# Generated at 2022-06-23 13:27:25.147950
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass # no tests at the moment

# Generated at 2022-06-23 13:27:31.038564
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.j2 import AnsibleJ2Vars
    assert 'changeme' in AnsibleJ2Vars(None, {'changeme': 'foo'})
    assert 'changeme' in AnsibleJ2Vars(None, {'changeme': 'bar'})


# Generated at 2022-06-23 13:27:40.011387
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.vars.hostvars
    assert hasattr(ansible.vars.hostvars, 'HostVars')

    class TestTemplar(object):
        def __init__(self, available_variables):
            self._available_variables = available_variables

        @property
        def available_variables(self):
            return self._available_variables

        def template(self, variable):
            return variable

    class HostVars(dict):
        def __getitem__(self, key):
            return self.get(key, None)

    templar = TestTemplar(available_variables={
        'name': 'peter',
        'surname': 'parker'
    })

# Generated at 2022-06-23 13:27:43.096487
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    """
    Method __contains__ of class AnsibleJ2Vars is not implemented
    :return: None
    """
    raise NotImplementedError("Method __contains__ of class AnsibleJ2Vars is not implemented")

# Generated at 2022-06-23 13:27:51.890616
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class MockTemplar:
        def __init__(self, available_variables):
            self.available_variables = available_variables

    globals = {'global_key': 'global_value'}
    locals = {'local_key': 'local_value'}
    templar = MockTemplar({'vars_key': 'vars_value'})

    # Check with None locals
    a_j2_vars = AnsibleJ2Vars(templar, globals, locals=locals)
    a_j2_vars_with_locals = a_j2_vars.add_locals(None)
    assert locals == a_j2_vars_with_locals._locals

    # Check with locals
    a_j2_vars = AnsibleJ2Vars

# Generated at 2022-06-23 13:28:02.589161
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import unittest
    import tempfile
    try:
        from ansible.inventory.manager import InventoryManager
        from ansible.parsing.dataloader import DataLoader
        from ansible.playbook.play_context import PlayContext
        from ansible.template import Templar
    except ImportError:
        raise unittest.SkipTest("Failed to import ansible modules")

    class TestAnsibleJ2Vars(unittest.TestCase):

        def setUp(self):
            # we need a temporary file to construct the inventory
            self.test_host_ini = tempfile.NamedTemporaryFile(mode='w', prefix='ansible_test_host_ini_')
            self.test_host_ini.write("[test_host]\n")

# Generated at 2022-06-23 13:28:10.032106
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.vars import hostvars, VariableManager
    var_manager = VariableManager()
    j2vars = AnsibleJ2Vars(var_manager.template, var_manager.extra_vars)
    hostvars_value = 'hostvars'
    var_manager.set_host_variable('hostvars', hostvars_value)
    assert j2vars.__len__() == 3



# Generated at 2022-06-23 13:28:18.442857
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    class Templar:
        def __init__(self, vars):
            self.available_variables = vars
    var1 = 'value1'
    var2 = 'value2'
    locals = {'varlocal': var1}
    vars = {'vartemplar': var2}
    templar = Templar(vars)
    vars_obj = AnsibleJ2Vars(templar, globals={}, locals=locals)

    assert 'varlocal' in vars_obj
    assert 'vartemplar' in vars_obj
    assert 'nosuch' not in vars_obj


# Generated at 2022-06-23 13:28:25.016601
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # mock some objects
    templar = Mock()
    globals = {'a': 'b'}
    locals = {'c': 'd'}

    # test __contains__
    a = AnsibleJ2Vars(templar, globals, locals)
    assert 'a' in a
    assert 'b' not in a



# Generated at 2022-06-23 13:28:29.850723
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class FakeTemplar:
        def __init__(self):
            self.available_variables = {
                'a': 'b',
                'c': 'd',
                'e': 'f',
            }

    assert AnsibleJ2Vars(FakeTemplar(), {'g': 'h', 'i': 'j'})

# Generated at 2022-06-23 13:28:38.831697
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # DO NOT REMOVE THIS
    # THIS UNIT TEST IS DISABLED FOR NOW PENDING PROPER RUNTIME
    # SUPPORT FOR UNIT TESTING IN THE MAIN PROJECT
    '''
    templar = Templar(loader=None, variables={'a': 'n1'})
    jvars = AnsibleJ2Vars(templar, {'b': 'n2'}, {'a': 'l1'})
    assert set(jvars) == set('a', 'l_a', 'b')
    '''
    pass


# Generated at 2022-06-23 13:28:47.059553
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)
    globals = {'a': 1, 'b': 2, 'c': 3}

    # method __len__ called before adding any locals
    ansible = AnsibleJ2Vars(templar, globals)
    assert len(ansible) == 3

    locals = {'d': 4, 'e': 5, 'f': 6}
    # method __len__ called after adding locals
    ansible = AnsibleJ2Vars(templar, globals, locals=locals)
    assert len(ansible) == 6

    # method __len__ called when there is one local
    locals = {'d': 4}

# Generated at 2022-06-23 13:28:56.835448
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    test_env = {
        'test_var': 'test_value',
        'test_dict': {'test_key': 'test_value'},
        'test_hostvars': UnsafeProxy({'test_key': 'test_value'}),
    }

    test_globals = {
        'globals_var': 'globals_value',
        'globals_dict': {'globals_key': 'globals_value'},
        'globals_hostvars': UnsafeProxy({'globals_key': 'globals_value'}),
    }


# Generated at 2022-06-23 13:29:08.925370
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import sys
    sys.path.append("..")
    # memodict.py is imported by ansible.template.templar
    import memodict
    import jinja2
    # Some tests of AnsibleJ2Vars.__len__() need to test additional code
    # inside tested method.
    # Included locals: only one env key
    locals = {'env_path': '.'}
    # Globals are not required
    globals = {}
    # Templar() needs a loader
    # Loader() is not required
    loader = jinja2.DictLoader({})
    # MemoDict() is required for Templar()
    memoDict = memodict.MemoDict()
    # Test of method __len__() will be performed for new ansible.template.templar.Templar

# Generated at 2022-06-23 13:29:21.747324
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template.safe_eval import safe_eval

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)
    globals = dict(test_globals=dict(a=1, b=2, c=3))

    locals = dict(
        test_locals=dict(d=4, e=5),
        l_F=HostVars(dict(g=7, h=8)),
        a=100,
    )

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert len(vars) == 10


# Generated at 2022-06-23 13:29:25.778844
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = None
    globals = None
    locals = dict(a=1, b=2)
    var_obj = AnsibleJ2Vars(templar,globals,locals)
    assert var_obj.__contains__('a')


# Generated at 2022-06-23 13:29:36.540646
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
  from ansible.vars.hostvars import HostVars
  from ansible.vars.hostvars import Variable
  from ansible.vars.unsafe_proxy import AnsibleUnsafeText
  from ansible.parsing.yaml.objects import AnsibleUnicode
  from ansible.template import Templar
  from ansible.vars.manager import VariableManager
  from ansible.executor.task_result import TaskResult
  from ansible.playbook.task_include import TaskInclude

  import os
  import sys
  import time

  print(sys.path)

  # create a mock task result

# Generated at 2022-06-23 13:29:40.504339
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    AJV = AnsibleJ2Vars(templar={}, globals={'abc': 123}, locals={'def': 456})

    iterator = AJV.__iter__()
    assert next(iterator) == 'abc'
    assert next(iterator) == 'def'
    try:
        next(iterator)
        assert False
    except StopIteration:
        assert True


# Generated at 2022-06-23 13:29:47.279900
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
   from . import templar
   from .templar import Templar
   from . import constants
   from .vars.hostvars import HostVars
   
   templar_object = Templar(loader=None, variables={})
   constants_object = constants.AnsibleModule(argument_spec={}, supports_check_mode=True)
   host_vars_object = HostVars()
   ansible_j2_vars_object = AnsibleJ2Vars(templar=templar_object, globals=constants_object, locals=host_vars_object)

   assert ansible_j2_vars_object.__contains__("test_globals") is True
   assert ansible_j2_vars_object.__contains__("test_templar") is True
   assert ans

# Generated at 2022-06-23 13:29:52.315128
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    vars_ = {'foo': 'bar'}
    templar = Templar(loader=DictDataLoader({}))
    proxy = AnsibleJ2Vars(templar, vars_)
    assert len(proxy) == 1
    assert proxy.__len__() == 1


# Generated at 2022-06-23 13:30:00.437348
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.template
    import ansible.template.template
    import ansible.vars.hostvars
    import ansible.utils.vars
    from fractions import Fraction

    # Initialize objects with dummy values
    templar = ansible.template.template.Templar(loader=ansible.template.j2_loader, variables=ansible.utils.vars.AnsibleVars())
    play = ansible.playbook.play.Play.load(dict(name = 'test play', gather_facts = 'no'), None, loader=ansible.template.j2_loader)
    block = ansible.playbook.block.Block(play=play)

# Generated at 2022-06-23 13:30:05.807767
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    vars = AnsibleJ2Vars(Templar(), {'a': 'b'})
    l = len(vars)
    assert 1 == l
    vars._templar.available_variables = {'foo': 'bar'}
    assert 2 == len(vars)



# Generated at 2022-06-23 13:30:13.251075
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    # temporarily add to sys.modules - needed for AnsibleUndefinedVariable
    from ansible.module_utils import six
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    if six.PY3:
        import builtins
    else:
        import __builtin__ as builtins
    builtins.__dict__['to_native'] = to_bytes
    builtins.__dict__['boolean'] = boolean

    # main test
    templar = Templar(loader=None)
    my_globals = {'test_global_var': 'global_var'}
    my_locals = {'test_local_var': 'local_var'}

    my_obj = AnsibleJ

# Generated at 2022-06-23 13:30:22.419583
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar()

    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager

    t_vars = dict( a1=1, a2=2 )
    global_vars = dict( a3=3, a4=4 )
    host_vars = dict( a5=5, a6=6 )
    j2_vars = AnsibleJ2Vars(templar, global_vars, locals=t_vars)

    host_vars = HostVars(host_vars)
    vm = VariableManager()
    vm.set_host_variable('127.0.0.1', host_vars)


# Generated at 2022-06-23 13:30:33.737672
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    # main parameters
    templar = Templar({})
    globals = {}
    # test case 1
    locals = None
    answer = {'vars': {'a': 'Hello'}}
    test_object = AnsibleJ2Vars(templar, globals, locals)
    test_value = 'vars' in test_object
    assert test_value == True
    # test case 2
    locals = None
    answer = {'vars': {'a': 'Hello'}}
    test_object = AnsibleJ2Vars(templar, globals, locals)
    test_value = 'vars' in test_object
    assert test_value == True


# Generated at 2022-06-23 13:30:40.905766
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Create a mock Templar class
    class Templar(object):
        def __init__(self, template=None, err_notif=None, error_on_undefined=None,
                     vars=None, env=None,
                     disable_lookups=None, context=None, no_type_regex=None,
                     tempdir=None,
                     avail_vars=None):
            self.template = template
            self.err_notif = err_notif
            self.vars = vars
            self.env = env
            self.context = context
            self.tempdir = tempdir
            self.no_type_regex = no_type_regex
            self.disable_lookups = disable_lookups
            self.error_on_undefined = error_on_undefined
            self.available_variables

# Generated at 2022-06-23 13:30:43.149101
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    return_value = AnsibleJ2Vars(None, None)
    assert return_value is not None

# Generated at 2022-06-23 13:30:43.870741
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass

# Generated at 2022-06-23 13:30:53.751728
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    #'''
    #Check that AnsibleJ2Vars.__contains__ returns True when the given variable
    #is present in the dictionary, and False otherwise.
    #'''
    from jinja2 import Environment, DictLoader
    from j2vars.templar import UnicodeMixin, Templar

    class FakeDisplay(UnicodeMixin):
        def vvv(self, msg, host=None):
            print(msg)

        def vv(self, msg, host=None):
            print(msg)

        def verbose(self, msg, host=None):
            print(msg)

    my_env = Environment(loader=DictLoader({'test.j2': '''{{ hostvars['localhost']['test_var'] }}'''}))
    my_display = FakeDisplay()
    my_

# Generated at 2022-06-23 13:31:05.170139
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    # Create a Templar object using a DummyLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    loader = DataLoader()
    templar = Templar(loader=loader)
    templar._available_variables = dict.fromkeys(('foo', 'bar', 'baz'))

    # Test contains method with existing key, should return True
    aj2v = AnsibleJ2Vars(templar, dict(), dict(baz='qux'))
    assert 'baz' in aj2v
    assert 'foo' in aj2v
    assert 'qux' not in aj2v

    # Test contains method on existing key
    aj2v = AnsibleJ2Vars(templar, dict(foo='baz'), dict())


# Generated at 2022-06-23 13:31:14.871186
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # some fake vars
    vars={"somevar": "somevalue",
          "secret": "you can't see me",}
    templar = None
    globals = {"globalvar": "globalvalue",
               "secret": "you can't see me either"}
    locals = {"localvar": "localvalue",
              "secret": "so you think you're safe? nope, me too"}

    aj2v = AnsibleJ2Vars(templar, globals, locals=locals)
    assert aj2v.locals == locals
    assert aj2v.globals == globals
    assert aj2v.templar == templar
    assert aj2v.available_variables == {'somevar': 'somevalue'}

# Generated at 2022-06-23 13:31:20.341437
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    jv = AnsibleJ2Vars(Templar(None), {}, {'a': '1', 'b': '2'})
    assert 'a' in jv
    assert 'b' in jv
    assert 'x' not in jv



# Generated at 2022-06-23 13:31:27.949560
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    vars = AnsibleJ2Vars(templar, dict(), dict())
    vars['foo'] = dict(a = dict(b = dict(c = dict(d = 1))))
    print(vars['foo'])
    print(vars['foo']['a'])
    print(vars['foo']['a']['b'])
    print(vars['foo']['a']['b']['c'])
    print(vars['foo']['a']['b']['c']['d'])


# Generated at 2022-06-23 13:31:39.431727
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.plugins.loader import vars_loader
    from ansible.template import Templar
    env_cache = {}
    templar = Templar(loader=None, variables={}, env_cache=env_cache)
    vars_proxy = AnsibleJ2Vars(templar, {})
    templar.set_available_variables(vars_loader.get_vars(load_list=['all']))
    assert vars_proxy['vault_password'] == 'Vault password'
    assert vars_proxy['inventory_hostname'] == 'localhost'
    assert vars_proxy['inventory_hostname_short'] == 'localhost'
    assert vars_proxy['group_names'] == ['ungrouped']

# Generated at 2022-06-23 13:31:42.887135
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template.safe_eval import safe_eval
    from ansible.template.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var
    import json

# Generated at 2022-06-23 13:31:49.487550
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'x': 2, 'y': 3}
    locals = {'l_x': 4, 'l_y': 5}
    x = AnsibleJ2Vars(templar, globals, locals=locals)

    # test __contains__
    assert "l_x" in x
    assert "l_y" in x
    assert "x" in x
    assert "y" not in x
    assert "z" not in x

    # test if local variables are accessible;
    # we need to test the case where a variable is defined both globally and locally
    var1 = x['l_x']
    assert var1 == 4

    var2 = x['l_y']
    assert var2 == 5

    #

# Generated at 2022-06-23 13:31:52.882401
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # TODO: Create a mock for Templar, populate the object with some
    #       variables, and verify that add_locals merges locals dict into
    #       self._locals.
    assert False

# Generated at 2022-06-23 13:32:00.387722
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    from ansible.template import Templar

    assert 'var' in AnsibleJ2Vars(Templar(), {}, {'l_var': 'var'})
    assert 'var' in AnsibleJ2Vars(Templar(), {}, {'var': 'var'})
    assert 'var' in AnsibleJ2Vars(Templar(), {'var': 'not_var'})

    assert 'var' not in AnsibleJ2Vars(Templar(), {}, {'var_not': 'var_not'})
    assert 'var' not in AnsibleJ2Vars(Templar(), {})


# Generated at 2022-06-23 13:32:04.888172
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.template.templar
    templar = ansible.template.templar.Templar()
    ansible_j2_vars = AnsibleJ2Vars(templar, {}, {})
    assert 'a' in ansible_j2_vars


# Generated at 2022-06-23 13:32:13.641865
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class MockAnsibleJ2Vars(AnsibleJ2Vars):
        pass

    ajv = MockAnsibleJ2Vars(None, {})
    expected = set()

    # test 1
    # will raise an exception if __iter__ is not implemented
    try:
        iter(ajv)
        assert True
    except TypeError:
        # this will fail if __iter__ is not implemented
        if PY3:
            raise AssertionError('__iter__ method is not implemented')

    # test 2
    # will raise an exception if __iter__ is

# Generated at 2022-06-23 13:32:21.991604
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.injector import get_defaults
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariablesManager

    loader = DataLoader()
    variable_manager = VariablesManager(loader=loader)
    variable_manager._extra_vars = dict(a=1, b=2)
    j2_var_len = AnsibleJ2Vars(Templar(loader=loader, variables=variable_manager), dict(), locals=get_defaults())
    assert len(j2_var_len) == 2

# Generated at 2022-06-23 13:32:32.200387
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """
    Test the __iter__ method.
    Return True when all the test cases pass, False otherwise.
    """
    from ansible.vars.manager import VariableManager
    from ansible.template.safe_eval import unsafe_eval
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    hostvars = {'inventory_hostname': 'foo'}
    task_vars = dict(hostvars=hostvars, play_hosts=hostvars)
    variable_manager = VariableManager()
    variable_manager.set_host_variable(hostvars['inventory_hostname'], hostvars)
    variable_manager.extra_vars = {'magic': 'abc'}
    play_context = PlayContext()

# Generated at 2022-06-23 13:32:35.593410
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    vars = AnsibleJ2Vars(Templar(), {'foo': 'bar'})

test_AnsibleJ2Vars()

# Generated at 2022-06-23 13:32:40.637959
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import tempfile
    import os
    import shutil
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Create a temp directory for the inventory
    temp_dir = tempfile.mkdtemp()

    group_name = 'test_group'
    group_vars_name = 'test_group_vars'
    vars_file_name = 'vars'
    vars_file = os.path.join(temp_dir, vars_file_name)
    os.makedirs(vars_file)

# Generated at 2022-06-23 13:32:48.487082
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    templar = Templar()

    globals = { "foo": "bar" }
    locals1 = { "baz": "qux" }
    locals2 = { "bar": "foo" }

    avars = AnsibleJ2Vars(templar, globals, locals=locals1)
    new_avars = avars.add_locals(locals2)

    assert new_avars._templar is templar
    assert new_avars._globals is globals
    assert new_avars._locals == { "baz": "qux", "bar": "foo" }

    locals3 = { "baz": "hop" }
    new_avars = avars.add_locals(locals3)
    assert new_avars._loc

# Generated at 2022-06-23 13:32:55.850181
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import copy

    data = {
        'a': 1,
        'b': 2,
        'c': {1: 2},
        'd': [1, 2, 3]
    }

    var_a = AnsibleJ2Vars('templar', {}, {'a': 2})
    var_b = copy.deepcopy(var_a)
    var_a.add_locals({'a': 3})

    assert var_a['a'] == 3
    assert var_b['a'] == 2