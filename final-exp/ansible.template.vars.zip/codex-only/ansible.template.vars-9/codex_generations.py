

# Generated at 2022-06-23 13:22:56.823463
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    vault_password = 'asdf'
    vault = VaultLib(vault_password)
    templar = Templar(loader=None, variables={})

    # varname existing in available_variables
    av1 = {}
    av1['foo'] = '1'
    av2 = {}
    av2['bar'] = '2'
    templar.available_variables = av1.copy()
    templar.available_variables.update(av2)

    # varname existing in _globals
    globals = {}
    globals['baz'] = '3'

    # varname existing in _locals
    locals = {}
    locals['foobar'] = '4'

    # varname existing in

# Generated at 2022-06-23 13:23:06.992145
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    locals = {
        'var1': 'value1',
        'var2': 'value2',
    }

    vm = VariableManager()
    templar = Templar(loader=None, variables=vm)

    vars = AnsibleJ2Vars(templar, globals=None, locals=locals)
    vars_locals = vars.add_locals(locals)

    assert vars_locals['var1'] == locals['var1']
    assert vars_locals['var2'] == locals['var2']

# Generated at 2022-06-23 13:23:10.502742
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    t = 'templar'
    g = 'globals'
    l = 'locals'
    v = AnsibleJ2Vars(t, g, l)
    assert v._templar == t
    assert v._globals == g
    assert v._locals == l

# Generated at 2022-06-23 13:23:20.291116
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Test description:
    - test method add_locals of class AnsibleJ2Vars (call it with local variable in dict)

    Expected result:
    - check add_locals of class AnsibleJ2Vars create a new object that contains old local variables and new local variables
    '''

    from ansible.template import Templar
    templar = Templar(loader=None, variables=None)

    test_dict = dict()
    test_dict['a'] = 1
    test_dict['b'] = 2

    test_obj = AnsibleJ2Vars(templar, test_dict)
    result = test_obj.add_locals({'c':3})

    assert result._locals['a'] == 1
    assert result._locals['b'] == 2
    assert result._locals['c']

# Generated at 2022-06-23 13:23:30.937332
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    templar = None
    globals = { 'default_foo': 'default_foo', 'default_bar': 'default_bar' }
    locals = { 'local_baz': 'local_baz' }
    extra_locals = { 'extra_foo': 'extra_foo', 'extra_bar': 'extra_bar' }
    variables = AnsibleJ2Vars(templar, globals, locals)
    # new object should contain
    assert set(['default_foo', 'default_bar', 'local_baz']) == set(variables.keys())
    # adding locals should add locals but not override existing locals
    variables = variables.add_locals(extra_locals)

# Generated at 2022-06-23 13:23:38.921041
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    # AnsibleJ2Vars provided empty locals
    result = AnsibleJ2Vars(templar=None, globals={'my_global_var':'hello'}, locals={})\
        .__len__()
    assert(result == 1)

    # AnsibleJ2Vars provided empty locals
    result = AnsibleJ2Vars(templar=None, globals={'my_global_var':'hello'}, locals={})\
        .add_locals({'my_local_var':'world'})\
        .__len__()
    assert(result == 2)

# Generated at 2022-06-23 13:23:47.370852
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():

    # Test 1
    t1 = AnsibleJ2Vars(
        templar=AnsibleJ2Vars(
            available_variables={'a': 'b'},
        ),
        globals={'c': 'd'},
        locals={'e': 'f'},
    )

    assert 'a' in t1
    assert 'b' not in t1

    assert 'c' in t1
    assert 'd' not in t1

    assert 'e' in t1
    assert 'f' not in t1

    assert 'x' not in t1
    assert 'y' not in t1
    assert 'z' not in t1



# Generated at 2022-06-23 13:23:56.916995
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    locals_ = {"a": "a", "b": "b", "c": "c"}
    globals_ = {"d": "d", "e": "e", "f": "f"}
    # Set _templar.available_variables to None since the value is not used
    templar = Templar()
    templar.available_variables = None
    ansible_j2_vars = AnsibleJ2Vars(templar, globals_, locals_)

    # testing
    tested_result = len(ansible_j2_vars)
    expected_result = len(locals_) + len(globals_)
    assert tested_result == expected_result, "actual:%s, expected:%s" % (tested_result, expected_result)


# Generated at 2022-06-23 13:24:05.408005
# Unit test for method __contains__ of class AnsibleJ2Vars

# Generated at 2022-06-23 13:24:12.661372
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar(loader=None, variables={'foo': 'bar'})
    globals_ = {'baz': 'qux'}
    locals_ = {'l_abc': 'def'}
    var_proxy = AnsibleJ2Vars(templar, globals_, locals_)
    assert sorted(iter(var_proxy)) == ['baz', 'foo', 'l_abc']


# Generated at 2022-06-23 13:24:20.222627
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    from ansible.template import Templar
    templar = Templar(loader=jinja2.DictLoader({}))
    # Check __contains__
    assert "test_varname" not in templar.environment.globals

    # Dummy variable to use
    class Dummy_Variable(object):
        __UNSAFE__ = True
    variable = Dummy_Variable()

    # Add variable
    templar.available_variables["test_varname"] = variable

    # Check __contains__
    assert "test_varname" in templar.environment.globals


# Generated at 2022-06-23 13:24:26.306014
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Example values to test with
    templar_obj = {'a': 1, 'b': 2, 'c': 3}
    globals_obj = {'x': 1, 'y': 2, 'z': 3}
    locals_obj = {'a': 100, 'x': 1000}

    vars_obj = AnsibleJ2Vars(templar_obj, globals_obj, locals=locals_obj)
    
    vars_obj_copy = vars_obj.add_locals(locals_obj)
    assert(vars_obj_copy['a'] == 100)
    assert(vars_obj_copy['x'] == 1000)
    assert(vars_obj_copy['b'] == 2)
    assert(vars_obj_copy['y'] == 2)

# Generated at 2022-06-23 13:24:36.881583
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    globals = {'plugin_vars': "plugin_vars"}
    locals = {'l_vars': "l_vars"}
    templar = Templar(loader=None, variables=locals)
    templar.set_available_variables(available_variables=globals)
    ansible_j2_vars = AnsibleJ2Vars(templar, globals, locals)
    assert globals['plugin_vars'] in ansible_j2_vars
    assert locals['l_vars'] in ansible_j2_vars
    assert 'plugin' in ansible_j2_vars
    assert 'l_vars' not in ansible_j2_vars
    assert 'not_exists' not in ansible_j2_

# Generated at 2022-06-23 13:24:43.962595
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template.templar import Templar

    x = ansible_safe_eval('1', locals = {}, include_exceptions=True)
    assert isinstance(x, int)

    # test initializer (for coverage)
    templar = Templar(loader=None)
    x = AnsibleJ2Vars(templar, globals={})
    x = AnsibleJ2Vars(templar, globals={}, locals={})
    x = AnsibleJ2Vars(templar, globals={}, locals=None)
    assert len(x) == 0

    # test initializer with locals provided
    templar = Templar(loader=None)

# Generated at 2022-06-23 13:24:54.399431
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    templar = Templar(loader=None, variables={'foo': 1}, shared_loader_obj=None)
    dict_of_vars = AnsibleJ2Vars(templar,
                                 globals={'g_foo': 2},
                                 locals={'l_foo': 3})
    assert 'foo' in dict_of_vars

    dict_of_vars = AnsibleJ2Vars(templar,
                                 globals={},
                                 locals={'l_foo': 3})
    assert 'foo' not in dict_of_vars
    assert 'l_foo' in dict_of_vars


# Generated at 2022-06-23 13:25:03.239279
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Creates an AnsibleJ2Vars object to test the method
    AnsibleJ2Vars.add_locals()

    Returns:
        (bool) True if the test passed and False if it failed
    '''

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    templar = Templar()

    a1 = AnsibleJ2Vars(templar, {'a': 1})
    a2 = a1.add_locals({'b': 2, 'c': 3})
    a3 = a2.add_locals({'c': 4, 'd': 5})

    if (a1['a'] != 1) or (a1['b'] is not None) or (a1['c'] is not None):
        return False


# Generated at 2022-06-23 13:25:14.543122
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # ansible.module_utils.common._collections_compat.Mapping is not a builtin
    # so we need to fake it
    class Mapping(object):
        pass

    # ansible.module_utils.common._collections_compat is not imported
    # so we need to fake it too
    class _collections_compat(object):
        Mapping = Mapping
    sys.modules['ansible.module_utils.common._collections_compat'] = _collections_compat

    # ansible.module_utils.common.dict is not imported
    # so we need to fake it too
    class dict(object):
        def __init__(self, *args, **kwargs):
            pass

        def __contains__(self, *args, **kwargs):
            return False

# Generated at 2022-06-23 13:25:21.859667
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # Injections are a bit tricky to test. If they are not defined, they are
    # in a dictionary called inject. Injections can be defined as injection
    # or l_injection. The AnsibleJ2Vars class should return the injected
    # variables from the following sequence:
    # - locals.injection
    # - locals.j_injection
    # - available_variables
    # - globals.j_injection
    #
    # This was an issue that broke the handling of a batch of tasks as a
    # single item, when in fact a batch of tasks should be handled as a
    # batch. See issue #19093

    # Prepare the input data: Templar object and data sets
    templar_obj = mock.Mock()

# Generated at 2022-06-23 13:25:30.954833
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    g = { 'xyz': [1, 2, 3], 'abc': { 'a': 1, 'b': 2 } }
    l = { 'xyz': [4, 5, 6], 'abc': { 'b': 3, 'c': 4 } }
    v = AnsibleJ2Vars(None, g, l)

    keys = set()
    keys.update(v.keys())
    assert keys == { 'xyz', 'abc' }

    assert 'xyz' in v
    assert 'def' not in v

    assert v['xyz'] == [4, 5, 6]
    assert v['abc'] == { 'b': 3, 'c': 4, 'a': 1, 'b': 2 }

# Generated at 2022-06-23 13:25:36.013697
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    from ansible.template.jinja2 import AnsibleJ2TemplateEnvironment

    templar = Templar(AnsibleJ2TemplateEnvironment())
    globals = {'g1': 'g_val1', 'g2': 'g_val2'}
    locals = {'l1': 'l_val1', 'l2': 'l_val2'}

    j2vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(j2vars) == 4


# Generated at 2022-06-23 13:25:40.532428
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # No arguments
    with pytest.raises(TypeError):
        AnsibleJ2Vars()
    # Argument types
    with pytest.raises(AssertionError):
        AnsibleJ2Vars('templar', 'globals', 'locals')
    # Multiple arguments
    with pytest.raises(AssertionError):
        AnsibleJ2Vars('templar', 'globals', 'locals', 'extra')

# Generated at 2022-06-23 13:25:46.204421
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class Templar:
        available_variables = {'a': 1, 'b': 2, 'c': 3}

    globals = {'a': 100}
    locals = {'a': 200}

    vars = AnsibleJ2Vars(Templar(), globals, locals)
    assert len(vars) == 3



# Generated at 2022-06-23 13:25:54.267382
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from collections import OrderedDict
    templar = Templar(loader=None)
    globals_ = OrderedDict(var1='this is var1')
    locals_ = OrderedDict(var2='this is var2')
    vars = AnsibleJ2Vars(templar, globals=globals_, locals=locals_)
    assert 'var1' in vars
    assert 'var2' in vars
    assert 'varX' not in vars
    # Check the value returned by AnsibleJ2Vars.__getitem__ is correct
    assert vars['var1'] == 'this is var1'
    assert vars['var2'] == 'this is var2'


# Generated at 2022-06-23 13:26:06.994975
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.template import Templar
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader

    t = Templar(loader=DataLoader())
    v = VariableManager()
    i = PlayContext()
    i.load_from_file = boolean(42)
    o = AnsibleJ2Vars(t, v, i)


# Generated at 2022-06-23 13:26:16.528510
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    dictionary = {}
    dictionary['a'] = 'hello'
    dictionary['b'] = 'world'
    j2vars = AnsibleJ2Vars(None, dictionary)
    msg = "Test __getitem__ method of class AnsibleJ2Vars: FAILED"
    assert j2vars['a'] == 'hello',msg
    assert j2vars['b'] == 'world',msg
    msg = "Test __getitem__ method of class AnsibleJ2Vars: SUCCESS"
    print(msg)

if __name__ == '__main__':
    test_AnsibleJ2Vars___getitem__()

# Generated at 2022-06-23 13:26:23.189292
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    my_templar = Templar(loader=loader, variables=variable_manager)

    # case1: KeyError raised with undefined variable
    my_dict = AnsibleJ2Vars(my_templar, dict(), dict())
    try:
        my_dict['var1']
    except KeyError as e:
        assert e.args[0] == "undefined variable: var1"
    else:
        assert False, "Should have raised KeyError"
    # case2: KeyError is not raised, dict is returned
    my

# Generated at 2022-06-23 13:26:34.144839
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.inventory.host import Host

    templar = Templar(loader=None, variables={'foo': "bar"})
    my_var = AnsibleJ2Vars(templar, globals({}))

    # check case when we have a variable in the var_cache
    assert my_var['foo'] == "bar"

    # check case when we have a variable in the globals
    assert my_var['inventory_hostname'] == "test_host"
    assert my_var['inventory_hostname_short'] == "test_host"

    # check case when we have a variable in the locals
    vars = {'foo': "bar", 'inventory_hostname': 'test_host', 'inventory_hostname_short': 'test_host'}
    my_var = Ans

# Generated at 2022-06-23 13:26:46.797374
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    globals = dict()
    locals = dict()
    vars = dict()
    vars['vars'] = vars
    templar = Templar(loader=None, variables=vars)
    proxy = AnsibleJ2Vars(templar, globals, locals)

    # dict.__getitem__
    vars['test1'] = dict()
    assert(isinstance(proxy['test1'], dict))
    # HostVars is special, return it as-is
    vars['test2'] = HostVars(loader=None, variable_manager=None)
    assert(isinstance(proxy['test2'], HostVars))

    # variable is not defined

# Generated at 2022-06-23 13:26:54.161522
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import pytest

    # We create a mock AnsibleJ2Vars object to test the __len__ method
    class MockAnsibleJ2Vars:
        def __init__(self, templar, globals, locals):
            pass

        def __iter__(self):
            return iter([])

        def __contains__(self, varname):
            return True

        def __getitem__(self, varname):
            return ""

    globals = {
        "global1": "global1",
    }

    locals = {
        "local1": "local1",
    }

    templar = MockAnsibleJ2Vars(globals, locals)

    assert(len(templar) == 0)

# Generated at 2022-06-23 13:26:58.611803
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    locals = dict()
    locals['l_test_1'] = "l_test_value"

    globals = dict()
    globals['g_test_1'] = "g_test_value"

    templar = Templar(loader=None)
    templar.available_variables = dict()
    templar.available_variables['av_test_1'] = "av_test_value"
    templar.available_variables['av_test_2'] = AnsibleUnicode("av_test_value")

    test_obj = AnsibleJ2Vars(templar, globals, locals=locals)

    assert 'test_1' in test_obj

# Generated at 2022-06-23 13:27:06.950871
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    '''
    Testing the initialization part of the class.
    '''
    # testing if initilization fails because of wrong type for tempalar
    res = False
    try:
        a = AnsibleJ2Vars(None, None)
    except:
        res = True
    assert res

    # testing if initilization fails because of wrong type for globals
    res = False
    try:
        a = AnsibleJ2Vars("test", None)
    except:
        res = True
    assert res

    # testing if initilization fails because of wrong type for locals
    res = False
    try:
        a = AnsibleJ2Vars("test", "test", None)
    except:
        res = True
    assert res

    # testing if initialization fails because locals is not a dict
    res = False
   

# Generated at 2022-06-23 13:27:14.636865
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar({}, {}, None)
    j2vars = AnsibleJ2Vars(templar, globals={}, locals={})

    # Test for local variable
    assert 'a' in j2vars

    # Test for available variable
    templar.available_variables = {'b': 'b'}
    assert 'b' in j2vars

    # Test for global variable
    assert 'c' in j2vars

    # Test for undefined variable
    assert 'd' not in j2vars



# Generated at 2022-06-23 13:27:21.123610
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    templar = None
    globals = { "g1": "g1", "g2": "g2" }
    locals = { "l1": "l1", "l2": "l2" }
    jv = AnsibleJ2Vars(templar, globals, locals)
    it = iter(jv)
    l = list(it)
    l.sort()
    assert l == ['g1', 'g2', 'l1', 'l2']

# Generated at 2022-06-23 13:27:21.689514
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    pass

# Generated at 2022-06-23 13:27:28.552402
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.templating import Templar
    from ansible import constants as C
    from ansible.vars.hostvars import HostVars
    _available_variables = None
    _template = 'my template'
    _vars = {'variable': 'my value'}
    _templar = Templar(loader=None, variables=_vars)
    _globals = {'hostvars': {'host': HostVars({'variable': 'my value'})}}
    _locals = None

    _c = AnsibleJ2Vars(_templar, _globals, locals=_locals)
    assert _c.__getitem__('variable') == 'my value'
    assert _c.__getitem__('hostvars')['host']['variable'] == 'my value'

# Generated at 2022-06-23 13:27:37.625170
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None)

    vars = AnsibleJ2Vars(templar, {'test_var': 'test_value'})
    assert 'test_var' in vars

    # __getitem__() with undefined variable
    try:
        vars['undefined_var']
    except KeyError as e:
        assert e.args[0] == "undefined variable: undefined_var"

    # __getitem__() with an existing variable
    # __contains__() should be always True for this variable
    assert vars['test_var'] == 'test_value'
    assert 'test_var' in vars

    # __getitem__() with a falsy value
    # __contains__() should be always False for this variable

# Generated at 2022-06-23 13:27:47.614008
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    Unit test for method add_locals of class AnsibleJ2Vars
    '''
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.template.safe_eval import unsafe_eval

    templar = unsafe_eval.__self__._templar
    execution_vars = {}
    templar._available_variables = execution_vars

    play_context = PlayContext()
    globals = {}
    locals = {'bar' : 'baz'}

    proxy = AnsibleJ2Vars(templar, globals, locals)
    proxy_locals = proxy.add_locals({'bar' : 'foo'})

    assert proxy_locals['bar'] == 'foo'

# Generated at 2022-06-23 13:27:59.051098
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():

    from ansible.template import Templar
    from ansible.vars import VariableManager

    varman = VariableManager()
    varman.extra_vars={'haz':'cheez'}
    varman.extra_vars['mylist']=range(10)

    templar = Templar(varman)

    new_vars = AnsibleJ2Vars(templar, {}, {'foo':'bar'})

    assert 'haz' in new_vars
    assert new_vars['haz'] == 'cheez'

    assert 'foo' in new_vars
    assert new_vars['foo'] == 'bar'

    assert 'mylist' in new_vars
    assert new_vars['mylist'] == range(10)

# Generated at 2022-06-23 13:28:07.971298
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-23 13:28:18.581040
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import os
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.template import Templar

    with patch.dict(os.environ, {'ANSIBLE_TEMPLATE_INHERITANCE_CACHE_ENABLED': 'false'}):
        t = Templar(None)
        try:
            # check that t.available_variables is not a dict
            getattr(t.available_variables, 'keys')()
        except AttributeError:
            # the available_variables is not a dict, so AnsibleJ2Vars.__getitem__
            # must return a dict-like object instead of the Templar itself
            assert set(AnsibleJ2Vars(t, {}, {})) == set()

# Generated at 2022-06-23 13:28:30.305947
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():

    from ansible.vars.manager import VariableManager
    from ansible.template.safe_eval import safe_eval
    from ansible.template import Templar

    # Create mocks
    templar = Templar(loader=None, variables={})

    variables = VariableManager()
    variables.extra_vars = dict()
    variables.extra_vars['x'] = 'foo'
    variables.extra_vars['y'] = 'bar'
    variables.extra_vars['z'] = 'baz'

    variables.host_vars = dict()
    variables.host_vars['host1'] = dict()
    variables.host_vars['host1']['x'] = 'zoo'
    variables.host_vars['host1']['y'] = 'far'

# Generated at 2022-06-23 13:28:42.044216
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    # Test __init__() and __contains__()
    globals = {'var_1': 'a', 'var_2': 'b'}
    vars = AnsibleJ2Vars(templar, globals=globals, locals={'var_1': 'A', 'var_2': 'B', 'var_3': 'C'})
    assert 'var_1' in vars
    assert 'var_2' in vars
    assert 'var_3' in vars
    assert 'var_4' not in vars
    # Test __len__()
    assert len(vars) == 3
    # Test __iter__()
    # FIXME: additional condition is needed, see temp_vars.py
    #

# Generated at 2022-06-23 13:28:50.084469
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.vars import TemplateVars
    from ansible.template import Templar

    # Prepare fixture for test
    data = dict(
        a=dict(
            b=dict(
                c=dict(d='d', e='e'),
            ),
        ),
    )
    template_vars = TemplateVars(data)
    templar = Templar(loader=None, variables=template_vars)
    to_test = AnsibleJ2Vars(templar, {})

    assert 'e' in to_test
    assert 'z' not in to_test

# Generated at 2022-06-23 13:28:59.172539
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    class A:     # pylint: disable=too-few-public-methods
        pass

    class B:     # pylint: disable=too-few-public-methods
        def __iter__(self):
            yield 1
            yield 2

    class C:     # pylint: disable=too-few-public-methods
        def __getitem__(self, i):
            return i

    class D:     # pylint: disable=too-few-public-methods
        pass

    class E:     # pylint: disable=too-few-public-methods
        def __getitem__(self, i):
            return i

        def __iter__(self):
            yield 1

    assert(list(AnsibleJ2Vars(A(), A(), locals=A())) == [])


# Generated at 2022-06-23 13:29:10.590370
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)
    test_templar = Templar(loader=loader)
    globals = {"foo": "bar"}
    locals = {"baz": "boo"}
    test_vars = AnsibleJ2Vars(templar, globals, locals)
    result = test_vars.__contains__(globals.keys()[0])
    assert result == True
    result = test_vars.__contains__(locals.keys()[0])
    assert result == True
    result = test_vars.__contains__("fizz")
    assert result == False


# Generated at 2022-06-23 13:29:22.557071
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class Templar:
        def __init__(self, variables):
            self.available_variables = variables
        
        def template(self, x):
            return x
    
    vars = AnsibleJ2Vars(Templar({'a': 1, 'b': 2, 'c': 3}), {'c': 30, 'd': 40})
    # vars = a: 1, b: 2, c: 3
    # globals = c: 30, d: 40
    assert vars['a'] == 1
    assert vars['b'] == 2
    assert vars['c'] == 3
    assert vars['d'] == 40
    # locals = e: 4, f: 5
    vars = vars.add_locals({'e': 4, 'f': 5})

# Generated at 2022-06-23 13:29:27.202717
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    testing method AnsibleJ2Vars.add_locals
    '''

    test_locals = {'my_name': 'John Doe'}
    jvars = AnsibleJ2Vars(None, None, test_locals)

    added_jvars = jvars.add_locals({'my_age': 42})

    assert added_jvars._locals == {'my_name': 'John Doe', 'my_age': 42}

# Generated at 2022-06-23 13:29:31.649482
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    assert len(AnsibleJ2Vars(1, 2, 3)) == 0
    assert len(AnsibleJ2Vars(1, 2, 3)) == 0
    assert len(AnsibleJ2Vars(1, 2, 3)) == 0


# Generated at 2022-06-23 13:29:42.415608
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    class MockTemplar(object):
        def __init__(self, d):
            self.data = d

        def available_variables(self):
            return self.data
    v = {
        'a': 1,
        'b': 2
    }
    t = MockTemplar(v)
    c = {
        'a': 5
    }
    p = AnsibleJ2Vars(t, c)
    assert v['a'] == p['a']
    assert v['b'] == p['b']
    assert c['a'] == p['a']

    t.data['a'] = 10
    assert v['a'] != p['a']
    assert v['a'] == 10
    assert c['a'] != p['a']
    assert c['a'] == 5
    assert p['a']

# Generated at 2022-06-23 13:29:55.317919
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VarsModule
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    from ansible.module_utils._text import to_text

    class DummyVarsModule(VarsModule):
        pass

    obj = DummyVarsModule()
    templar = Templar(loader=None, variables=obj, shared_loader_obj=None)
    globals = {'a': 1, 'b': 2}
    locals = {'c': 3}
    v = AnsibleJ2Vars(templar, globals, locals=locals)
    # test all duplicates
    keys = set(globals)
    keys.update(locals)

# Generated at 2022-06-23 13:30:01.741554
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from jinja2.runtime import Undefined

    class Templar(object):
        available_variables = {
            'all': 'all',
            'vars': {'foo': 'foo', 'bar': {'baz': 'baz'}},
            'hostvars': {'a_host': {'foo': 'foo', 'bar': {'baz': 'baz'}}},
            'group_names': ['a_group'],
            'groups': {'a_group': {'children': [], 'hosts': []}},
            'inventory_hostname': 'a_host'
        }

    def globals_func(var):
        return var


# Generated at 2022-06-23 13:30:11.545178
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.parsing.dataloader import DataLoader
    from ansible.templating.jinja2.environment import Environment

    loader = DataLoader()
    env = Environment(loader=loader, keep_trailing_newline=True, lstrip_blocks=True, trim_blocks=True)

    j2vars = AnsibleJ2Vars(env.get_template("{{ myvar }}").module_vars, globals())

    j2vars_with_locals = j2vars.add_locals({"myvar": "myval"})

    new_myvar = j2vars_with_locals["myvar"]
    assert new_myvar == "myval"

    j2vars_without_locals = j2vars.add_locals({})

    new_myvar_

# Generated at 2022-06-23 13:30:21.483241
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    # Test with the right inputs
    templar = object()
    globals = {"a": "1", "b": "2", "c": "3"}
    locals = {"d": "4", "e": "5", "f": "6"}
    jvars = AnsibleJ2Vars(templar, globals, locals)
    assert len(jvars) == 6

    # Test with the wrong inputs
    templar = object()
    globals = "abcd"
    locals = "efgh"
    jvars = AnsibleJ2Vars(templar, globals, locals)
    try:
        len(jvars)
        assert False
    except:
        assert True


# Generated at 2022-06-23 13:30:32.025217
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from units.mock.loader import DictDataLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import jinja2

    # Checks the number of items in variable proxy
    jinja_env = jinja2.Environment(loader=DictDataLoader({}))
    variable_manager = AnsibleJ2Vars(Templar(loader=DataLoader()), jinja_env.globals, locals=dict(a=1, b=2, c=3))
    assert len(variable_manager) == 3



# Generated at 2022-06-23 13:30:38.528033
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    import jinja2
    json = '{"key1":"value1","key2":"value2","key3":"{{key4}}"}'
    expected_json_output = '{"key1":"value1","key2":"value2","key3":"value4"}'
    template = jinja2.Template(json)
    templar = Templar(loader=None)
    globals = {"key4": "value4"}
    expected_key = "key3"
    expected_value = "value4"
    v = AnsibleJ2Vars(templar, globals)
    actual_json_output = template.render(v)
    assert actual_json_output == expected_json_output
    assert v[expected_key] == expected_value

# Generated at 2022-06-23 13:30:44.477653
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={})
    globals = {"foo": "bar"}
    locals = {"baz": "qux"}
    ajv = AnsibleJ2Vars(templar, globals, locals)
    assert ajv._templar == templar
    assert ajv._globals == globals
    assert ajv._locals == locals

# Generated at 2022-06-23 13:30:53.661456
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    t = type('TemplarDummy', (), {'template': lambda context: context})()
    v = AnsibleJ2Vars(t, {'a' : 1, 'b' : 2}, {'c' : 3})

    assert 'a' in v
    assert 'c' in v
    assert 'd' not in v
    assert v['a'] == 1
    assert v['c'] == 3

    v2 = v.add_locals({'a' : 7, 'd' : 8})
    assert 'a' in v2
    assert 'c' in v2
    assert 'd' in v2
    assert v2['a'] == 7
    assert v2['c'] == 3
    assert v2['d'] == 8

# Generated at 2022-06-23 13:31:00.027483
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    class Templar(object):
        def __init__(self):
            self.available_variables = dict()
        def template(self, variable):
            return variable

    data = AnsibleJ2Vars(Templar(), dict(), dict(a='b'))
    expected_result = 1
    result = len(data)
    assert(expected_result == result)


# Generated at 2022-06-23 13:31:08.963358
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vm = VariableManager()
    templar = Templar(loader=None, variables=vm)
    j2_vars = AnsibleJ2Vars(templar, vm.get_vars(), None)
    j2_vars.add_locals({'locals': 1})
    assert j2_vars['locals'] == 1
    j2_vars.add_locals({'locals': 2})
    assert j2_vars['locals'] == 2
    j2_vars.add_locals({'locals1': 3})
    assert j2_vars['locals1'] == 3

# Generated at 2022-06-23 13:31:18.646967
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    j2vars_obj = AnsibleJ2Vars(
        Templar(
            loader=DataLoader(),
            variables=VariableManager(),
            shared_loader_obj=None,
            inventory=None,
            all_vars=dict(),
            options={},
            context=PlayContext(),
        ),
        globals={},
        locals={},
    )
    assert isinstance(j2vars_obj.__iter__(), iterator)


# Generated at 2022-06-23 13:31:23.662948
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    globals = {'host_name': 'localhost'}
    templar = None
    vars = AnsibleJ2Vars(templar, globals)
    assert len(vars) == 1, 'AnsibleJ2Vars.__len__ is broken'


# Generated at 2022-06-23 13:31:26.034750
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    """
    Unit test for method __iter__ of class AnsibleJ2Vars
    """
    pass


# Generated at 2022-06-23 13:31:38.028015
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # class AnsibleJ2Vars(Mapping) that really is identical to the built-in dict type
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar

    play_context = PlayContext()

    # create ansible jinja templating object
    loader = DataLoader()
    variable_manager = VariableManager()

    # initialize a jinja templating object with the ansible jinja templating object
    # which takes the ansible globals and vars objects

# Generated at 2022-06-23 13:31:46.891080
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():

    from ansible.template import Templar

    t = Templar('/home/user/ansible/some_dir', {})

    av = {
        'a' : 123,
        'b' : 'abc',
        'c' : [ 1, 2, 3 ],
        'd' : { 'a': 1, 'b': 2, 'c': 3 },
        'e' : None,
        'f' : [ 1, 'x', 3 ]
    }

    gp = {
        'a' : 321,
        'b' : 'cba',
        'c' : [ 1, 2, 3 ],
        'd' : { 'a': 3, 'b': 2, 'c': 1 },
    }

    aj2v = AnsibleJ2Vars(t, gp, locals=av)

# Generated at 2022-06-23 13:31:58.957190
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import copy
    import types
    from ansible.template import Templar

    my_templar = Templar(None, loader=None)
    my_templar._available_variables = {"test0":0, "test1":1, "test2":2, "test3":3, "test4":4}
    my_dict1 = {"test0":0, "test1":1, "test3":3, "test4":4}
    my_dict2 = {"test2":2, "test5":5, "test6":6, "test7":7, "test8":8}

    my_var_proxy = AnsibleJ2Vars(my_templar, my_dict1)

    # Test case: locals is not provided

# Generated at 2022-06-23 13:32:04.732228
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import get_all_plugin_loaders

    for plugin_loader in get_all_plugin_loaders():
        plugin_loader.add_directory('./lib/ansible/plugins/action')
        plugin_loader.add_directory('./lib/ansible/plugins/cache')
        plugin_loader.add_directory('./lib/ansible/plugins/callback')
        plugin_loader.add_directory('./lib/ansible/plugins/connection')
        plugin_loader.add_directory('./lib/ansible/plugins/filter')

# Generated at 2022-06-23 13:32:07.562167
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    j2vars = AnsibleJ2Vars(None, {'a': 'b'})
    assert 'a' in j2vars
    assert 'c' not in j2vars

# Generated at 2022-06-23 13:32:20.126295
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template.safe_eval import safe_eval
    from ansible.template.templar import Templar
    from ansible.template.vars import AnsibleVars
    import jinja2

    t = Templar(
        loader=jinja2.DictLoader({'some_template': '{{ a }}'}),
        variables=AnsibleVars().vars()
    )
    result = t.template('{{ a }}', dict(a=1), convert_bare=True)
    assert result == 1

    t = Templar(
        loader=jinja2.DictLoader({'some_template': '{{ a }}'}),
        variables=AnsibleVars().vars()
    )
    locals = dict(a=2)

# Generated at 2022-06-23 13:32:29.406539
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class DummyTemplar():
        def __init__(self):
            self.available_variables = {'x': 'foo'}
            self.template = lambda x: x

    templar = DummyTemplar()
    globals = {'y': 'bar'}
    locals = {'z': 'baz'}

    class DummyJinjaObj():
        def __init__(self, locals):
            self.locals = locals
    jinjaobj = DummyJinjaObj(locals)

    o = AnsibleJ2Vars(templar, globals)
    assert o.add_locals(jinjaobj) is o

# Generated at 2022-06-23 13:32:37.609665
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {'var1': 'x', 'var2': 'y', 'var3': 'z'}
    locals = {'var4': 'a', 'var5': 'b'}
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert len(vars) == 5
# test_AnsibleJ2Vars___len__()

# Generated at 2022-06-23 13:32:46.229201
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    import ansible.constants as C

    templar = Templar(variables=dict(password='verybadpassword'))
    templar.set_available_variables(dict(password='verybadpassword'))


# Generated at 2022-06-23 13:32:55.043463
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    assert hasattr(templar, 'available_variables')
    globals = dict()
    locals = dict()
    vars = AnsibleJ2Vars(templar, globals, locals)
    assert not vars
    globals['g'] = 1
    assert len(vars) == 1
    locals['l'] = 2
    assert len(vars) == 2
    vars._templar.available_variables['a'] = 1
    assert len(vars) == 3
