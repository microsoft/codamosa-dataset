

# Generated at 2022-06-23 13:22:56.509968
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    init_dict = {'a': 1, 'b': 2, 'c': 3}
    ansible_j2_vars = AnsibleJ2Vars('templar', init_dict, init_dict)
    assert ansible_j2_vars['a'] == 1
    assert ansible_j2_vars['b'] == 2
    assert ansible_j2_vars['c'] == 3

# Generated at 2022-06-23 13:23:08.488460
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    hostvars = HostVars({"a":1})
    templar = Templar(loader=None, variables={"x":{"y":"z"}})
    globals = {"zoo":"boo"}
    locals = {"loo":"moo"}
    aj2v = AnsibleJ2Vars(templar, globals, locals)

    assert(list(aj2v.__iter__()) == ["loo", "x", "zoo"])

    templar = Templar(loader=None, variables={"x":{"y":"z"}, "aa":{"bb":"cc"}})
    aj2v = AnsibleJ2Vars(templar, globals, locals)

# Generated at 2022-06-23 13:23:18.725935
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    '''
    This is a unit test for method __getitem__ of class AnsibleJ2Vars

    :return:
    '''

# Generated at 2022-06-23 13:23:25.778441
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars
    v = VariableManager()
    var = v.get_vars(loader=None, play=None, host=None)
    templar = Templar(loader=None, variables=var)
    j2vars = AnsibleJ2Vars(templar, var)
    # test __init__ function
    assert len(j2vars) == len(var)


# Generated at 2022-06-23 13:23:28.245156
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    templar = Templar(None, loader=None, variables={})

    # Empty test
    AnsibleJ2Vars(templar, dict())


# Generated at 2022-06-23 13:23:36.643041
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template.safe_eval import safe_eval
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.hostvars import HostVars
    vault = VaultLib(["foo"], "bar")
    templar = Templar(vault, convert_bare=True)
    Glob = {"foo":"bar", "globals":globals, "to_text":AnsibleUnicode, "from_yaml":safe_eval}
    ansible_j2vars = AnsibleJ2Vars(templar, Glob)
    assert ansible_j2vars["foo"] == "bar"
    assert "foo" in ansible_j2vars
    assert ansible_j2vars

# Generated at 2022-06-23 13:23:48.918809
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    global_vars = {'gvar1': 'gvalue1', 'gvar2': 'gvalue2', 'gvar3': 'gvalue3'}
    local_vars = {'lvar1': 'lvalue1', 'lvar2': 'lvalue2', 'lvar3': 'lvalue3'}
    ansible_vars = {'avar1': 'avalue1', 'avar2': 'avalue2', 'avar3': 'avalue3'}
    all_vars = {}
    all_vars.update(local_vars)
    all_vars.update(global_vars)
    all_vars.update(ansible_vars)

    from ansible.template import Templar
    templar = Templar(loader=None)
    templar._available_variables

# Generated at 2022-06-23 13:23:54.333860
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    import ansible.constants as constants
    templar = Templar(loader=None, variables={})
    globals = {}
    locals = {}
    a = AnsibleJ2Vars(templar, globals, locals)
    if 'ansible_version' in a:
        assert True
    if 'a' in a:
        assert True


# Generated at 2022-06-23 13:24:00.808373
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    Unit test for method __iter__ of class AnsibleJ2Vars
    '''

    from ansible.template import Templar
    templar = Templar(loader=None, variables={'abc': 123})

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    globals = {'xyz': 'hello', 'abc': AnsibleUnsafeText('hi'), 'def': 123}

    locals = {'l_ghi': 'ignored'}

    vars = AnsibleJ2Vars(templar, globals, locals)

    assert sorted(list(iter(vars))) == sorted(['abc', 'def', 'xyz'])


# Generated at 2022-06-23 13:24:11.662800
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    def fail(test_name, reason=None):
        print("FAILED: %s" % (test_name))
        if reason:
            print("\tREASON: %s" % (reason))

    def ok(test_name):
        print("OK     : %s" % (test_name))

    # Create instance of class AnsibleJ2Vars
    class MyTemplar(object):
        def __init__(self):
            self.available_variables = {'foo':'bar'}
        def template(self, v):
            return v + " templated"

    t = MyTemplar()
    aj2v = AnsibleJ2Vars(t, globals={'baz':'qux'})

    # Test that the instance has a _templar property

# Generated at 2022-06-23 13:24:21.001780
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    # Load the templar module
    from ansible.template import Templar
    templar = Templar(loader=None)

    # Dictionary of variables representing jinja2 globals
    globals = {}

    # Create a new instance of AnsibleJ2Vars
    j2vars = AnsibleJ2Vars(templar, globals)

    # Modify the locals dictionary that will be added to the j2vars
    locals = {'var1': 'value1', 'var2': 'value2'}

    # Create a copy of j2vars containing the new locals
    new_j2vars = j2vars.add_locals(locals)

    # Test the content of j2vars.locals
    assert(new_j2vars._locals == locals)

# Generated at 2022-06-23 13:24:26.946259
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from units.mock.loader import DictDataLoader
    from jinja2 import Environment
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    env = Environment(loader=DictDataLoader({'test.j2': '{{a}}'}))
    templar = Templar(loader=loader, variables={'a': 'v1'}, environment=env)
    vars = AnsibleJ2Vars(templar=templar, globals=None, locals=None)
    assert 'a' in vars
    assert vars['a'] == 'v1'
    vars = AnsibleJ2Vars(templar=templar, globals=None, locals={'a': 'v2'})
    assert vars['a'] == 'v2'
   

# Generated at 2022-06-23 13:24:37.148257
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar

    dict_globals = {}
    dict_locals = {}
    templar = Templar(loader=None, variables={})

    ansible_jinja2_vars = AnsibleJ2Vars(templar, dict_globals, dict_locals)
    assert len(ansible_jinja2_vars) == 0

    dict_locals = {'a': 1, 'b': 2, 'c': 3}
    dict_globals = dict_locals
    ansible_jinja2_vars = AnsibleJ2Vars(templar, dict_globals, dict_locals)
    assert len(ansible_jinja2_vars) == 3

    dict_locals = {}

# Generated at 2022-06-23 13:24:45.025877
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from jinja2.runtime import StrictUndefined
    from jinja2.environment import Environment
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager, HostVars

    assert hasattr(AnsibleJ2Vars, '__iter__')
    assert callable(AnsibleJ2Vars.__iter__)

    hostvars = HostVars(variable_manager=VariableManager(loader=DataLoader()), hostname='localhost')
    hostvars.data = {'ansible_local': {'test1': 'test1_val'}, 'test2': 'test2_val'}
    templar = Templar(loader=DataLoader(), variables=hostvars, fail_on_undefined=True)

    env

# Generated at 2022-06-23 13:24:51.977226
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    
    assert AnsibleJ2Vars(jinja2.Environment(), locals={}, globals={}).__contains__("_templar") == False
    assert AnsibleJ2Vars(jinja2.Environment(), locals={}, globals={}).__contains__("_globals") == False
    assert AnsibleJ2Vars(jinja2.Environment(), locals={}, globals={}).__contains__("_locals") == False

# Generated at 2022-06-23 13:25:01.409248
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar()
    hostvars = HostVars(host=Host(name='testhost', port=22), variables=dict(foo='bar'))
    hostvars.vars = hostvars.variables
    variables = AnsibleJ2Vars(templar, dict(hv=hostvars), locals=dict(l_foo='bar'))
    for case in dict(foo=AnsibleUnicode('bar'),
                     l_foo=AnsibleUnicode('bar'),
                     hv=hostvars):
        assert variables[case] == variables.__get

# Generated at 2022-06-23 13:25:13.494276
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.template import Templar

    vars = AnsibleJ2Vars(Templar(), {}, {})

    templar = Templar(loader=None, variables=vars, shared_loader_obj=None)

    password = VaultPassword("password")
    secret = VaultSecret("password", password)

    vault = VaultLib(secret)

    vault_text = vault.encrypt("hello")

    # NOTE(retr0h): This represents what would get pulled from a task

# Generated at 2022-06-23 13:25:17.883555
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template import Templar

    vars = dict(a=42, b=[1,2,3])
    templar = Templar(loader=None, variables=vars)
    vars_obj = AnsibleJ2Vars(templar, dict())

    result = sorted(list(vars_obj))

    assert result == ['a', 'b']


# Generated at 2022-06-23 13:25:28.846113
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    #from ansible.vars.hostvars import HostVars
    #from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    data_loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=data_loader, variables=variable_manager, va_only=True)

    globals = {"testcase1": "value1", "testcase2": "value2"}
    locals = {"testlocals2": "value2"}

# Generated at 2022-06-23 13:25:34.916328
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = mock.MagicMock()
    globals = dict()
    locals = dict()
    AnsiJ2Vars = AnsibleJ2Vars(templar, globals, locals)
    assert AnsiJ2Vars._templar == templar
    assert AnsiJ2Vars._globals == globals
    assert AnsiJ2Vars._locals == {}
    assert AnsiJ2Vars.is_safe == True


# Generated at 2022-06-23 13:25:43.901743
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    '''
    ensures that add_locals correctly handles a None locals
    '''
    from ansible.template.safe_eval import assert_unsafe_passes
    from ansible.template import Templar
    # Don't need a valid play for this test
    templar = Templar()

    vars = {'value': 'value'}
    globals = {}

    j2vars = AnsibleJ2Vars(templar, globals, locals=vars)
    added_j2vars = j2vars.add_locals(locals=None)

    assert_unsafe_passes('"{{ value }}" == "value"', added_j2vars)


# Generated at 2022-06-23 13:25:53.348177
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import unittest.mock as mock

    def run_test(mock_template, mock_available_variables, locals, expected):
        mock_templar = mock.MagicMock()
        mock_templar.template.side_effect = mock_template
        mock_templar.available_variables = mock_available_variables

        result = AnsibleJ2Vars(templar=mock_templar, globals=dict(), locals=locals)

        # run the method to test
        try:
            result = result['abc']
        except Exception as e:
            result = e

        # make sure that the test succeed
        assert result == expected

    # Test 1: with a normal variable
    mock_template = lambda x: x
    mock_available_variables = {'abc': 'ABC'}

# Generated at 2022-06-23 13:26:06.121648
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar

    # Create a template and the variables to be used

    template_path = "template_path"
    templar = Templar(loader=None, variables={}, shared_loader_obj=None)
    templar._available_variables = {
        'foo': 'bar',
    }

    # Create an AnsibleJ2Vars object

    globals = {
        'bar': 'foo',
    }

    local_vars = {
        'foo': 'foobar',
    }

    j2_vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=local_vars)

    # Test if the method returns the variables

    # Test local
    assert j2_vars['foo'] == 'foobar'

    # Test glob

# Generated at 2022-06-23 13:26:15.117264
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.template import Templar
    templar = Templar(loader=None)
    globals = {}
    globals['a'] = 'a'
    globals['b'] = 'b'
    globals['c'] = 'c'
    locals = {}
    locals['b'] = 'b'
    locals['d'] = 'd'
    locals['e'] = 'e'
    j2_vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert len(j2_vars) == 5


# Generated at 2022-06-23 13:26:27.143557
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    class AnsibleJ2Template(jinja2.Template):
        def __init__(self, templar, globals, locals=None):
            pass

    from ansible.template.safe_eval import safe_eval
    from jinja2.environment import Environment as AnsibleJ2Environment

    ansible_hostvars = {'hostvars': {'host1': '1.1.1.1'}}
    ansible_all_hosts = ['host1']


# Generated at 2022-06-23 13:26:36.807906
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Prepare data
    templar = {'a1': 'A1', 'a2': 'A2'}
    globals = {'g1': 'G1', 'g2': 'G2'}
    locals = {'l1': 'L1', 'l2': 'L2'}

    # Call method to be tested
    ansible_vars = AnsibleJ2Vars(templar, globals, locals)
    keys = [k for k in ansible_vars]

    # Check result
    assert isinstance(keys, list)
    assert len(keys) == 6
    assert 'g1' in keys
    assert 'g2' in keys
    assert 'a1' in keys
    assert 'a2' in keys
    assert 'l1' in keys
    assert 'l2' in keys


# Generated at 2022-06-23 13:26:45.380988
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import jinja2
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import AnsibleVars

    templar = jinja2.Environment()
    globals = AnsibleVars()
    locals = AnsibleBaseYAMLObject()

    ans = AnsibleJ2Vars(templar, globals, locals)
    assert ans.__contains__('x') == False
    locals.x = 1
    assert ans.__contains__('x') == True


# Generated at 2022-06-23 13:26:53.909909
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    class Templar:
        def template(self, item):
            # Ensure that item is actually a string
            if not isinstance(item, str):
                raise TypeError('item should be a string')

            return item.upper()

    templar = Templar()
    globals = {'a': 1, 'b': 2, 'c': 3}
    locals = {'a': 11, 'b': 22}

    # Test that __getitem__ fails if item is not in globals, locals or templar
    vars = AnsibleJ2Vars(templar, globals, locals=locals)
    assert vars['some_key'] == 'SOME_KEY'

    # Test that __getitem__ returns globals item if exists
    assert vars['a'] == 1
    assert vars['b'] == 2

# Generated at 2022-06-23 13:26:55.018226
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    # TODO - test it
    pass

# Generated at 2022-06-23 13:27:06.196061
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.template.template import AnsibleJ2Template
    from ansible.vars import VariableManager

    templar = Templar(loader=None, variables=VariableManager(), shared_loader_obj=None)
    globals = dict()
    locals = dict()

    ansiblej2vars = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)

    # test case 1: test KeyError if jinja2 is looking for a variable
    #              that is undefined in ansible
    try:
        ansiblej2vars["undefined_var"]
    except KeyError as e:
        assert(str(e) == "undefined variable: undefined_var")
    else:
        assert(False)



# Generated at 2022-06-23 13:27:14.850968
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    t = AnsibleJ2Vars({'a':1}, {'b':2})
    assert sorted(list(t)) == ['a', 'b']

    t = AnsibleJ2Vars({'b':2}, {'a':1})
    assert sorted(list(t)) == ['a', 'b']

    t = AnsibleJ2Vars({'b':2}, {'a':1, 'c':3, 'd':4})
    assert sorted(list(t)) == ['a', 'b', 'c', 'd']

    t = AnsibleJ2Vars({'b':2}, {'a':1, 'c':3, 'd':4})
    assert sorted(list(t)) == ['a', 'b', 'c', 'd']


# Generated at 2022-06-23 13:27:20.619356
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    # TODO: This is a non-functional stub for test_AnsibleJ2Vars___getitem__.
    #       Update or remove this stub once this module is updated to use Ansible 2.3.
    #
    #       See https://github.com/ansible/ansible/issues/20103
    #       See https://github.com/ansible/ansible/issues/19026
    pass

# Generated at 2022-06-23 13:27:26.704295
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.template import Templar
    assert AnsibleJ2Vars(Templar(), {}).__contains__('foo') is False
    assert AnsibleJ2Vars(Templar(), {'foo': 'bar'}).__contains__('foo') is True
    assert AnsibleJ2Vars(Templar(), {'foo': 'bar'}, {'baz': 'qux'}).__contains__('baz') is True
    assert AnsibleJ2Vars(Templar(), {'foo': 'bar'}, {'baz': 'qux'}).__contains__('foo') is True


# Generated at 2022-06-23 13:27:36.693790
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from jinja2.exceptions import UndefinedError
    from ansible.template import Templar
    import ansible.playbook.play_context
    context = ansible.playbook.play_context.PlayContext()
    templar = Templar(loader=None, variables={}, shared_loader_obj=None, context=context)
    locals = {'top':'local'}
    globals = {'top':'global'}
    local_top_level = AnsibleJ2Vars(templar, globals, locals=locals)
    # first check that local variables are present
    assert 'top' in local_top_level
    assert local_top_level['top'] == locals['top']
    # then check that local variables take precedence
    locals['top'] = 'new_local'

# Generated at 2022-06-23 13:27:46.866891
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    templar = None  # FIXME
    globals_ = {"foo": 1, "bar": 2}
    locals_ = {"baz": 3}
    vars = AnsibleJ2Vars(templar, globals_, locals=locals_)
    assert vars["foo"] == 1
    assert vars["bar"] == 2
    assert vars["baz"] == 3
    assert len(vars) == 3
    assert set(vars.keys()) == set(globals_.keys()) | set(locals_.keys())
    assert set(vars.values()) == set(globals_.values()) | set(locals_.values())
# End unit test for AnsibleJ2Vars.__init__


# Generated at 2022-06-23 13:27:56.702243
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.templating import Templar
    templar = Templar(loader=None)
    globals = dict(glob_foo="glob_foo", glob_bar=[dict(glob_foo="glob_foo")])
    locals = dict(loc_foo="loc_foo", loc_bar=[dict(loc_foo="loc_foo")])
    av = dict(var_foo="var_foo", var_bar=[dict(var_foo="var_foo")])
    templar.set_available_variables(av)
    res = len(AnsibleJ2Vars(templar, globals, locals))
    assert res == 6

# Generated at 2022-06-23 13:28:02.552222
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    import ansible.template
    templar = ansible.template.Templar(loader=None, variables={'foo': 'bar'})
    vars = AnsibleJ2Vars(templar, globals={'baz': 'quux'}, locals={'foobar': 'spam'})
    assert 'foo' in vars
    assert 'baz' in vars
    assert 'foobar' in vars
    assert 'beef' not in vars


# Generated at 2022-06-23 13:28:15.367142
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import ansible.playbook.play

    mock_play = ansible.playbook.play.Play()
    mock_play._variable_manager = "The variable manager"

    templar = ansible.playbook.play.PlayBook.make_templar(mock_play, "variable manager")

    globals = {}
    subject = AnsibleJ2Vars(templar, globals)

    subject._locals = {"var_in_locals": "var_in_locals_value"}
    subject._templar.available_variables = {"var_in_available_variables": "var_in_available_variables_value"}
    subject._globals = {"var_in_globals": "var_in_globals_value"}


# Generated at 2022-06-23 13:28:18.760432
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    jv = AnsibleJ2Vars()
    #assert isinstance(jv, AnsibleJ2Vars)

# Generated at 2022-06-23 13:28:29.076472
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    my_locals = dict()
    my_locals['test_variable'] = 1
    my_globals = dict()
    my_globals['test_global'] = 1
    my_vars = dict()
    my_vars['test_var'] = 1
    j2v = AnsibleJ2Vars(None, my_globals, my_locals)

    assert my_locals.keys() == my_globals.keys() == my_vars.keys()
    assert sorted(my_locals.keys()) == sorted(j2v.keys())
    assert sorted(my_locals.keys()) == sorted(j2v.__iter__())

# Generated at 2022-06-23 13:28:40.758095
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    globals = {'abc': 'def'}
    locals = {'ghi': 'jkl'}
    j2vars = AnsibleJ2Vars(templar, globals, locals)

    assert j2vars['ghi'] == 'jkl'
    assert j2vars['abc'] == 'def'

    # case where locals contains added vars
    locals2 = {'klm': 'nop'}
    j2vars2 = j2vars.add_locals(locals2)

    assert j2vars2['ghi'] == 'jkl'


# Generated at 2022-06-23 13:28:52.304395
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    # Create a fake play with a fake playcontext
    play = Play()
    playcontext = PlayContext()
    play._inject_facts_as_vars = False
    playcontext._inject_facts_as_vars = False
    vartree = play.get_variable_manager().get_vars(play=play, play_context=playcontext)

    templar = Templar(loader=None, variables=vartree)

    # Create a test case with three local variables
    test_case = AnsibleJ2Vars(templar, {}, {"l_var1": 1, "l_var2": 2, "l_var3": 3})

# Generated at 2022-06-23 13:28:59.326344
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    locals = {'k1': 'v1', 'k2': 'v2'}
    vars = AnsibleJ2Vars(None, None, locals=locals)

    # test with an empty local dict: nothing should have changed
    assert locals == vars.add_locals({})._locals

    # test with a non-empty local dict
    new_locals = {'k3': 'v3', 'k4': 'v4'}
    assert locals.update(new_locals) == vars.add_locals(new_locals)._locals

# Generated at 2022-06-23 13:29:11.335564
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    try:
        import jinja2.environment
        import jinja2.loaders
        import ansible.template.template
        import ansible.vars.hostvars
        import ansible.vars.manager
    except ImportError as e:
        print("failed=True msg=%s" % e)
        return

    class AnsibleJ2Vars_Mock(AnsibleJ2Vars):
        def __init__(self):
            self.available_variables = {
                'varname_01': 'value_01',
            }
            self.template = ansible.template.template.Templar()

    vars = AnsibleJ2Vars_Mock()
    assert vars['varname_01'] == 'value_01'

# Generated at 2022-06-23 13:29:16.826910
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    # Initialize the AnsibleJ2Vars object
    globals_ = {'g1':1, 'g2':2}
    locals_ = {'g1':3, 'l1':4}
    templar = Templar()
    obj = AnsibleJ2Vars(templar, globals_, locals_)
    # Test iterator
    assert sorted(list(obj)) == ['g1', 'g2', 'l1']


# Generated at 2022-06-23 13:29:19.651488
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    assert (AnsibleJ2Vars(None, None, locals=None))


# Generated at 2022-06-23 13:29:25.406766
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    j2vars = AnsibleJ2Vars(templar, globals)
    assert j2vars['item'] == 'item1'
    assert j2vars['item1'] == 'item1'

# Some variables to use in the unit tests
templar = {
    'available_variables': {
        'item': 'item1',
        'item1': 'item1',
    }
}

globals = {
    'range': range
}

# Generated at 2022-06-23 13:29:31.371999
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    templar = Templar(loader=None)
    defaults = dict(a=1, b=2, c=3)
    jvars = AnsibleJ2Vars(templar, defaults)

    assert sorted(list(jvars)) == ['a', 'b', 'c']

    variables = { 'a': 2, 'b': 3, 'c': 4, 'd': 4 }

    templar.set_available_variables(combine_vars(defaults, variables))

    # should contain only the vars available defined in templar
    assert sorted(list(jvars)) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-23 13:29:42.224107
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    templar = Templar(loader=None)
    locals = {'a': 'b'}
    ansible_vars = {'b' : 'c'}
    globals = {'c': 'd'}
    ansible_j2vars = AnsibleJ2Vars(templar, globals, locals)
    ansible_j2vars._templar.available_variables = ansible_vars
    ############### test the value in locals
    assert ansible_j2vars['a'] == 'b'
    ############### test the value in available_variables
    assert ansible_j2vars['b'] == 'c'
    ############### test the

# Generated at 2022-06-23 13:29:55.189494
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    class TestJinja2Templar:
        def __init__(self, vv):
            self.available_variables = vv
        def template(self, var):
            return self.available_variables[var]

    v1 = {'one': 'two'}
    v2 = {'three': 'four'}
    v3 = {'five': 'six'}

    tv1 = AnsibleJ2Vars(TestJinja2Templar(v1), {})
    assert not 'three' in tv1

    tv2 = tv1.add_locals({'three': 'test'})
    assert 'three' in tv2
    assert tv2['three'] == 'test'

    tv3 = tv2.add_locals(v2)
    assert 'three' in tv3

# Generated at 2022-06-23 13:30:00.321349
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    from ansible.utils import context_objects as co
    from ansible.template import Templar

    templar = Templar(co.GlobalCLIArgs())
    vars1 = AnsibleJ2Vars(templar, {'a': 1, 'b': 2}, locals={'a': 3})
    vars2 = vars1.add_locals({'b': 4})
    assert vars1['a'] == 3
    assert vars1['b'] == 2
    assert vars2['a'] == 3
    assert vars2['b'] == 4

# Generated at 2022-06-23 13:30:10.808202
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    try:
        from units.mock.loader import DictDataLoader
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager
        from ansible.template import Templar
        from ansible.inventory.manager import InventoryManager
        from ansible.inventory.host import Host
    except ImportError:
        raise AssertionError("unable to import from units.mock.loader")

    def get_hosts(pattern):
        if 'all' in pattern:
            return {'name': 'all', 'groups': []}
        if 'group' in pattern:
            return [{'name': 'group', 'groups': ['group']}]
        return []

    inventory = InventoryManager(loader=DataLoader())
    inventory.add_group('group')
    inventory.add_

# Generated at 2022-06-23 13:30:19.956501
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    import sys
    try:
        from unittest import mock
    except ImportError:
        import mock # For Python v2.6

    # Setup class instance
    templar = mock.Mock()
    globals = {'g1': 1, 'g2': 2}
    locals = {'l1': 1, 'l2': 2}
    with mock.patch('ansible.template.AnsibleVars.__getitem__') as __getitem__:
        with mock.patch('ansible.template.AnsibleVars.__setitem__') as __setitem__:
            instance = AnsibleJ2Vars(templar, globals, locals)

    # Setup return values
    # Note: __getitem__ will not be called.

# Generated at 2022-06-23 13:30:27.100728
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    dataloader = DataLoader()
    variable_manager = VariableManager()

    vars1 = {'key1': 'val1',
             'key2': 'val2',
             'key3': 'val3'}
    variable_manager.extra_vars = vars1
    variable_manager.set_available_variables(loader=dataloader)

    vars2 = {'key4': 'val4',
             'key5': 'val5',
             'key6': 'val6'}
    variable_manager.extra_vars = vars2
    variable_manager.set_available_variables(loader=dataloader)

# Generated at 2022-06-23 13:30:30.303142
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    '''
    AnsibleJ2Vars.__iter__()
    '''
    templar = AnsibleJ2Vars(None, None, None)
    assert sorted(list(templar)) == sorted(["template", "context", "environment"])

# Generated at 2022-06-23 13:30:38.066879
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    from ansible.template.safe_eval import ansible_safe_eval
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    templar = Templar(loader=None)
    j2_env = AnsibleJ2Vars(templar, dict())

    test_dict = dict(key1='val1', key2='val2')
    test_dict1 = dict(key3='{{ansible_play_hosts}}')
    test_dict2 = UnsafeProxy(test_dict1)

    test_eval_dict = dict(key5='key6')
    test_eval_dict1 = ansible_safe_eval('dict(key5="key6")')

    j2_env._locals.update(test_dict)
    j2_env._locals

# Generated at 2022-06-23 13:30:45.238805
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    # get a dummy Templar object to pass to constructor
    templar = Templar(loader=None, variables={})
    # create an empty globals dict
    globals = {}
    # instantiate the test class
    ans_vars = AnsibleJ2Vars(templar, globals)
    # when constructed as above, should not be able to get anything from it
    assert len(ans_vars) == 0
    assert "foo" not in ans_vars
    import pytest
    with pytest.raises(KeyError):
        ans_vars["foo"]

# Generated at 2022-06-23 13:30:54.176299
# Unit test for method add_locals of class AnsibleJ2Vars
def test_AnsibleJ2Vars_add_locals():
    import unittest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from jinja2.runtime import Undefined
    class TestTemplar(Templar):
        def __init__(self, loader=None, variables=None, fail_on_undefined=False):
            self._loader = loader
            self.available_variables = {'inventory_hostname': 'hostname'}
            self.fail_on_undefined = fail_on_undefined

        def template(self, variable, convert_bare=True, preserve_trailing_newlines=False, escape_backslashes=True, fail_on_undefined=False, convert_data=True, templatevars=None):
            return variable


# Generated at 2022-06-23 13:31:05.330957
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    x = AnsibleJ2Vars()
    hv = {}
    hv['a'] = 'a'
    hv['b'] = 'b'
    x._globals = hv
    x._templar.available_variables = {'c': 'c'}
    x._templar.template = lambda s: s
    assert x['a'] == 'a'
    assert x['b'] == 'b'
    assert x['c'] == 'c'
    assert x['d'] == None
    assert x['a'] == 'a'
    assert x['b'] == 'b'
    assert x['c'] == 'c'

# Generated at 2022-06-23 13:31:10.899367
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    import jinja2
    from ansible.parsing.template import Templar
    from ansible.template.safe_eval import safe_eval
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None)

    def safe_eval_func1(statement, locals=None, include_exceptions=False):
        return safe_eval(statement, locals=locals, include_exceptions=include_exceptions)

    templar._lookup_loader = safe_eval_func1

    test_globals = dict()

    test_globals['one'] = 1
    test_globals['two'] = 2
    test_globals['three'] = 3

    test_locals = dict()

    test_locals['two'] = "Two"
    test_loc

# Generated at 2022-06-23 13:31:11.925246
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    pass


# Generated at 2022-06-23 13:31:17.077004
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    my_globals = { "some_global": "foo" }
    my_locals = { "some_local": "bar" }
    available_variables = { "some_variable": "bam" }

    templar = Templar(loader=loader, variables=available_variables)

    a = AnsibleJ2Vars(templar, my_globals, my_locals)

    expected = "foo"
    actual = a['some_global']
    assert expected == actual

    expected = "bar"
    actual = a['some_local']
    assert expected == actual

    expected = "bam"
    actual = a['some_variable']

# Generated at 2022-06-23 13:31:27.311164
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.module_utils.common._collections_compat import OrderedDict

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    j2_vars = None


# Generated at 2022-06-23 13:31:38.708402
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
   from ansible.callbacks import vvv
   from ansible.template import Templar
   from ansible.vars.hostvars import HostVars
   from ansible.vars.manager import VariableManager
   from ansible.playbook.play_context import PlayContext

   host_vars = HostVars(vvv, {})
   context = PlayContext()
   context.become = False

   if hasattr(AnsibleJ2Vars, '__iter__'):
      test_var_manager = VariableManager(loader=None, host_vars=host_vars,
            variable_manager=None, mod_def_vars=None)
      test_templar = Templar(loader=None, variables=test_var_manager)


# Generated at 2022-06-23 13:31:47.337867
# Unit test for method __iter__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___iter__():
    log_msg("Test: '__iter__' method of class 'AnsibleJ2Vars'")

    #preparation
    if ansible_module is None:
        ansible_module = AnsibleModule(
            argument_spec = dict(),
            supports_check_mode = True
        )
    templar = Templar(loader=CachingLoader(), variables={'var1': 1, 'var2': 2})
    globals = {'glob1': 1, 'glob2': 2}
    ajv = AnsibleJ2Vars(templar, globals)

    #test
    #make sure that {'var1', 'var2', 'glob1', 'glob2'} are in the AnsibleJ2Vars object

# Generated at 2022-06-23 13:31:58.993216
# Unit test for method __getitem__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___getitem__():
    template = """{{ var }}"""
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    from ansible.vars.hostvars import HostVars
    loader = DataLoader()

    templar = Templar(loader=loader)

    vars = AnsibleJ2Vars(templar, {"var": "original"}, {"var": "local"})
    assert vars["var"] == "local"

    # make sure we use the HostVars class
    hostvars = HostVars({"var": "hostvars"})
    vars = AnsibleJ2Vars(templar, {"var": hostvars})
    assert vars["var"] == hostvars

    # make sure we use the vars class

# Generated at 2022-06-23 13:32:09.843423
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader

    templar = Templar(loader=DataLoader(), variables=dict(a=1, b=dict(c=2)))
    globals = dict(d=1, e=dict(f=2))
    locals = ImmutableDict(g=1, h=dict(i=2))
    variable_proxy = AnsibleJ2Vars(templar=templar, globals=globals, locals=locals)
    assert len(variable_proxy) == 8

    templar = Templar(loader=DataLoader(), variables=dict(a=1, b=dict(c=2)))
    globals = dict(d=1, e=dict(f=2))
    variable

# Generated at 2022-06-23 13:32:16.586563
# Unit test for constructor of class AnsibleJ2Vars
def test_AnsibleJ2Vars():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template.vars import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    globals = {
        'abc': 'abc',
        'def': 'def',
    }
    locals = {
        '-l_abc': AnsibleUnsafeText(u'abc', unsafe=True),
        'context': None,
        'environment': None,
        'template': None,
        'xyz': 'xyz',
    }
    variables = {
        '-abc': AnsibleUnicode(u'abc'),
        '-def': AnsibleUnicode(u'def'),
        '-xyz': AnsibleUnicode(u'xyz'),
    }

    templar

# Generated at 2022-06-23 13:32:28.725134
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    import os
    import ansible.constants as C
    import ansible.plugins.loader as plugins
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from collections import MutableMapping

    current_directory = os.getcwd()
    vars_manager = plugins.VarsModule()

    templar = Templar(loader=None, variables=dict())
    templar.available_variables = dict()
    templar.set_available_variables(templar.template("{{ hostvars }}", fail_on_undefined=True))

    # Test case which checks if the variable is present in the locals.
    print("Starting Test 1")

# Generated at 2022-06-23 13:32:41.078475
# Unit test for method __len__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___len__():
    import pytest
    from ansible.template import Templar

    class ansible_vars_class(object):
        def __init__(self):
            self.keys = ['ansible_test_key_1', 'ansible_test_key_2', 'ansible_test_key_3']

    ansible_vars_obj = ansible_vars_class()

    class dict_class(object):
        def __init__(self):
            self.keys = ['dict_test_key_1', 'dict_test_key_2', 'dict_test_key_3']

    dict_obj = dict_class()

    test_object = AnsibleJ2Vars(
        templar = Templar(),
        globals = dict_obj,
        locals = ansible_vars_obj,
        )


# Generated at 2022-06-23 13:32:51.819729
# Unit test for method __contains__ of class AnsibleJ2Vars
def test_AnsibleJ2Vars___contains__():
    #test AnsibleJ2Vars.__contains__, the method
    #test getitem
    from ansible.template import Templar

    templar = Templar(loader=None)
    ansible_j2_globals = {}
    ansible_j2_vars = AnsibleJ2Vars(templar, ansible_j2_globals)
    assert "abc" not in ansible_j2_vars

    templar.available_variables = { "abc": "abc_value" }
    assert "abc" in ansible_j2_vars

    ansible_j2_globals = { "abc": "abc_value" }
    assert "abc" in ansible_j2_vars