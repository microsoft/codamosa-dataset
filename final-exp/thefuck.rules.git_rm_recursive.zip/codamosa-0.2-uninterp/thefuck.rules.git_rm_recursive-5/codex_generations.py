

# Generated at 2022-06-18 08:12:08.974136
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf *', 'fatal: not removing \'*\' recursively without -r'))
    assert not match(Command('git rm -rf *', 'fatal: not removing \'*\' recursively without -r', '', 1))
    assert not match(Command('git rm -rf *', 'fatal: not removing \'*\' recursively without -r', '', 0))
    assert not match(Command('git rm -rf *', 'fatal: not removing \'*\' recursively without -r', '', 2))
    assert not match(Command('git rm -rf *', 'fatal: not removing \'*\' recursively without -r', '', 3))
    assert not match(Command('git rm -rf *', 'fatal: not removing \'*\' recursively without -r', '', 4))

# Generated at 2022-06-18 08:12:11.778657
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r folder', 'fatal: not removing \'folder\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r folder'

# Generated at 2022-06-18 08:12:14.539414
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm')) == 'git rm -r'

# Generated at 2022-06-18 08:12:16.115090
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r')
    assert get_new_command(command) == 'git rm -r -r'

# Generated at 2022-06-18 08:12:21.447483
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 0))


# Generated at 2022-06-18 08:12:30.770551
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))

# Generated at 2022-06-18 08:12:40.955495
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r\n'))

# Generated at 2022-06-18 08:12:50.797853
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r -r'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r -r -r'))

# Generated at 2022-06-18 08:12:55.056853
# Unit test for function match
def test_match():
    assert match(Command('git rm -r',
                         'fatal: not removing \'src/test/resources/file\' recursively without -r\n'))
    assert not match(Command('git rm -r',
                             'fatal: not removing \'src/test/resources/file\' recursively without -r\n'))


# Generated at 2022-06-18 08:12:59.624315
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))


# Generated at 2022-06-18 08:13:05.177420
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))

# Generated at 2022-06-18 08:13:09.674603
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm -rf', ''))


# Generated at 2022-06-18 08:13:14.225655
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r file')) == 'git rm -r -r file'
    assert get_new_command(Command('git rm -r file1 file2')) == 'git rm -r -r file1 file2'

# Generated at 2022-06-18 08:13:17.850703
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:13:20.299507
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r -r file'

# Generated at 2022-06-18 08:13:22.593910
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r -r test'

# Generated at 2022-06-18 08:13:31.229165
# Unit test for function match
def test_match():
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', '', '', '', 1))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', '', '', '', 0))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', '', '', '', None))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', '', '', '', ''))

# Generated at 2022-06-18 08:13:33.858928
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file.txt', 'fatal: not removing \'file.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file.txt'

# Generated at 2022-06-18 08:13:36.243998
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r test'

# Generated at 2022-06-18 08:13:42.669514
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', '', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', '', 'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm -r file', '', 'fatal: not removing \'file\' recursively without -r\n'))


# Generated at 2022-06-18 08:13:48.940348
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r test'

# Generated at 2022-06-18 08:13:51.375997
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r a', 'fatal: not removing \'a\' recursively without -r')) == 'git rm -r -r a'

# Generated at 2022-06-18 08:13:54.620707
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', ''))
    assert not match(Command('git rm file', ''))


# Generated at 2022-06-18 08:13:57.562084
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r test'

# Generated at 2022-06-18 08:14:04.423125
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r', '', '', '', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', '', '', ''))


# Generated at 2022-06-18 08:14:11.820133
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', '', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', '', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', '', ''))


# Generated at 2022-06-18 08:14:14.676969
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r .', 'fatal: not removing \'.\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r .'

# Generated at 2022-06-18 08:14:21.886570
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:14:24.679702
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r test'

# Generated at 2022-06-18 08:14:29.472862
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:14:43.992063
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r',
                         ''))
    assert not match(Command('git rm file', '', ''))
    assert not match(Command('git rm -r file', '', ''))
    assert not match(Command('git rm -r file',
                             'fatal: not removing \'file\' recursively without -r',
                             ''))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r',
                             ''))


# Generated at 2022-06-18 08:14:46.947998
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -rf -r file'

# Generated at 2022-06-18 08:14:56.548899
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 0))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 123))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', -1))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', None))

# Generated at 2022-06-18 08:15:00.552790
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n'))


# Generated at 2022-06-18 08:15:02.412178
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:15:06.847126
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r file')) == 'git rm -r -r file'
    assert get_new_command(Command('git rm -r file1 file2')) == 'git rm -r -r file1 file2'

# Generated at 2022-06-18 08:15:14.674585
# Unit test for function match
def test_match():
    assert match(Command('git rm -r',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r', ''))
    assert not match(Command('git rm', ''))
    assert not match(Command('git rm',
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm',
                             'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:15:19.386282
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm', ''))
    assert not match(Command('git', ''))
    assert not match(Command('', ''))


# Generated at 2022-06-18 08:15:27.373653
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file',
                             'fatal: not removing \'file\' recursively without -r\n'
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively'))


# Generated at 2022-06-18 08:15:34.082081
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:15:51.985768
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 3))


# Generated at 2022-06-18 08:15:57.697396
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:16:02.273524
# Unit test for function match
def test_match():
    assert match(Command('git rm -r',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r', ''))
    assert not match(Command('git rm', ''))
    assert not match(Command('git rm -r', 'fatal: not removing \'file\''))


# Generated at 2022-06-18 08:16:11.577669
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r -f')) == 'git rm -r -f -r'
    assert get_new_command(Command('git rm -r -f -v')) == 'git rm -r -f -v -r'
    assert get_new_command(Command('git rm -r -f -v -n')) == 'git rm -r -f -v -n -r'
    assert get_new_command(Command('git rm -r -f -v -n -q')) == 'git rm -r -f -v -n -q -r'

# Generated at 2022-06-18 08:16:13.081561
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:16:22.878900
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r --cached')) == 'git rm -r --cached -r'
    assert get_new_command(Command('git rm -r --cached --ignore-unmatch')) == 'git rm -r --cached --ignore-unmatch -r'
    assert get_new_command(Command('git rm -r --cached --ignore-unmatch --quiet')) == 'git rm -r --cached --ignore-unmatch --quiet -r'
    assert get_new_command(Command('git rm -r --cached --ignore-unmatch --quiet --dry-run')) == 'git rm -r --cached --ignore-unmatch --quiet --dry-run -r'

# Generated at 2022-06-18 08:16:25.226639
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-18 08:16:29.856722
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r test')) == 'git rm -r -r test'
    assert get_new_command(Command('git rm -r test/')) == 'git rm -r -r test/'

# Generated at 2022-06-18 08:16:32.675333
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r -f')) == 'git rm -r -f -r'

# Generated at 2022-06-18 08:16:34.419824
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:17:05.699516
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-18 08:17:08.103912
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file'

# Generated at 2022-06-18 08:17:15.019056
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r\n',
                         '', 1))
    assert not match(Command('git rm file', '', '', 1))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n', '', 1))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n', '', 1))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n', '', 1))


# Generated at 2022-06-18 08:17:17.186792
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r -r file'

# Generated at 2022-06-18 08:17:19.140029
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-18 08:17:20.829109
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', 'fatal: not removing ')) == 'git rm -r -r'

# Generated at 2022-06-18 08:17:24.102922
# Unit test for function match
def test_match():
    assert match(Command('git rm -r',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r',
                             'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:17:26.311009
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r -r file'

# Generated at 2022-06-18 08:17:28.795680
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r a', 'fatal: not removing \'a\' recursively without -r')) == 'git rm -r -r a'

# Generated at 2022-06-18 08:17:30.365242
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:18:32.451183
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:18:39.079944
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r -f', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r -f -r'
    assert get_new_command(Command('git rm -f', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -f -r'
    assert get_new_command(Command('git rm', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r'

# Generated at 2022-06-18 08:18:43.308517
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r -f')) == 'git rm -r -f -r'
    assert get_new_command(Command('git rm -r -f -n')) == 'git rm -r -f -n -r'

# Generated at 2022-06-18 08:18:51.825837
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 0))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 123))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', -1))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', None))
    assert not match

# Generated at 2022-06-18 08:18:59.974875
# Unit test for function match
def test_match():
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', '', '', '', ''))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', '', '', '', '', '', ''))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', '', '', '', '', '', '', ''))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', '', '', '', '', '', '', '', ''))

# Generated at 2022-06-18 08:19:05.096054
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:19:11.681015
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:19:15.202136
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 3))


# Generated at 2022-06-18 08:19:17.597851
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file'

# Generated at 2022-06-18 08:19:19.010255
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r -r test'

# Generated at 2022-06-18 08:21:25.205153
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r\n'))


# Generated at 2022-06-18 08:21:29.464334
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt', ''))
    assert not match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:21:36.124503
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r -f')) == 'git rm -r -f -r'
    assert get_new_command(Command('git rm -f -r')) == 'git rm -f -r -r'
    assert get_new_command(Command('git rm -f')) == 'git rm -f -r'
    assert get_new_command(Command('git rm')) == 'git rm -r'
    assert get_new_command(Command('git rm -r -f -r')) == 'git rm -r -f -r -r'
    assert get_new_command(Command('git rm -r -r')) == 'git rm -r -r -r'
   

# Generated at 2022-06-18 08:21:39.291133
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file'

# Generated at 2022-06-18 08:21:42.080672
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r test'

# Generated at 2022-06-18 08:21:44.139064
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm -r', 'fatal: not removing')) == 'git rm -r -r'

# Generated at 2022-06-18 08:21:46.558657
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-18 08:21:48.492682
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1 file2', 'fatal: not removing \'file1\' recursively without -r')) == 'git rm -r file1 file2'

# Generated at 2022-06-18 08:21:54.025537
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:22:00.643841
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))
