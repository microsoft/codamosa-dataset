

# Generated at 2022-06-18 08:12:09.062516
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:12:16.480119
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:12:20.788391
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))


# Generated at 2022-06-18 08:12:22.429844
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:12:26.150466
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 0))


# Generated at 2022-06-18 08:12:28.515294
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', 'fatal: not removing '
                                   '\'file\' recursively without -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:12:38.874719
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r -f')) == 'git rm -r -f -r'
    assert get_new_command(Command('git rm -r -f -v')) == 'git rm -r -f -v -r'
    assert get_new_command(Command('git rm -r -f -v -n')) == 'git rm -r -f -v -n -r'
    assert get_new_command(Command('git rm -r -f -v -n --cached')) == 'git rm -r -f -v -n --cached -r'

# Generated at 2022-06-18 08:12:47.523638
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:12:49.133445
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:12:52.100194
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file'

# Generated at 2022-06-18 08:12:56.080360
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:13:01.195983
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm -r file', ''))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\''))


# Generated at 2022-06-18 08:13:04.247258
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm -rf file.txt', ''))


# Generated at 2022-06-18 08:13:05.738485
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:13:15.336088
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r -r')) == 'git rm -r -r -r'
    assert get_new_command(Command('git rm -r -r -r')) == 'git rm -r -r -r -r'
    assert get_new_command(Command('git rm -r -r -r -r')) == 'git rm -r -r -r -r -r'
    assert get_new_command(Command('git rm -r -r -r -r -r')) == 'git rm -r -r -r -r -r -r'

# Generated at 2022-06-18 08:13:17.887909
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file'

# Generated at 2022-06-18 08:13:26.657891
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r\n',
                             stderr='fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n',
                             stderr='fatal: not removing \'file\' recursively without -r\n'))


# Generated at 2022-06-18 08:13:33.499622
# Unit test for function match
def test_match():
    assert match(Command('git rm -r',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r', ''))
    assert not match(Command('git rm', ''))
    assert not match(Command('git rm',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r',
                         'fatal: not removing \'file\' recursively without -r',
                         'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:13:37.912315
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -rf file', ''))
    assert not match(Command('git rm -rf file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:13:46.550919
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 0))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 0))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 0))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 0))

# Generated at 2022-06-18 08:13:56.946907
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r', '', 0))


# Generated at 2022-06-18 08:14:06.889152
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file',
                             'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', ''))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:14:16.793275
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 0))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 123))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', -1))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', None))

# Generated at 2022-06-18 08:14:19.377511
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-18 08:14:25.693484
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r\n',
                         '', 1))
    assert not match(Command('git rm file', '', '', 1))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n', '', 1))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n', '', 1))


# Generated at 2022-06-18 08:14:34.339777
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:14:40.866599
# Unit test for function match
def test_match():
    assert match(Command('git rm -r', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r', 'fatal: not removing \'file\' recursively without -r', '', 0))


# Generated at 2022-06-18 08:14:48.101880
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file',
                             'fatal: not removing \'file\' recursively without -r\n'
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', ''))


# Generated at 2022-06-18 08:14:55.499576
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:15:00.327341
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r foo')) == 'git rm -r -r foo'
    assert get_new_command(Command('git rm -r foo bar')) == 'git rm -r -r foo bar'


# Generated at 2022-06-18 08:15:10.448888
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:15:17.904552
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -rf file', ''))
    assert not match(Command('git rm -rf file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm -rf file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -rf file', 'fatal: not removing \'file\' recursively without -r', '', 3))


# Generated at 2022-06-18 08:15:20.889059
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))


# Generated at 2022-06-18 08:15:26.688048
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:15:30.459840
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 3))


# Generated at 2022-06-18 08:15:32.639309
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r -r file'

# Generated at 2022-06-18 08:15:37.237208
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', ''))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:15:40.689125
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r -r')) == 'git rm -r -r -r'

# Generated at 2022-06-18 08:15:44.436546
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r -r file'

# Generated at 2022-06-18 08:15:48.127070
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:16:07.500831
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r test'

# Generated at 2022-06-18 08:16:09.275380
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:16:15.833346
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', '', '')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r -f', '', '')) == 'git rm -r -f -r'
    assert get_new_command(Command('git rm -r -f -r', '', '')) == 'git rm -r -f -r -r'
    assert get_new_command(Command('git rm -r -f -r -r', '', '')) == 'git rm -r -f -r -r -r'

# Generated at 2022-06-18 08:16:23.566904
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:16:26.552276
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r a', 'fatal: not removing \'a\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r a'

# Generated at 2022-06-18 08:16:34.059006
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:16:41.229537
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:16:43.290857
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r -r test'

# Generated at 2022-06-18 08:16:44.690543
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:16:45.838486
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file'

# Generated at 2022-06-18 08:17:21.930054
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r -r test'

# Generated at 2022-06-18 08:17:23.944552
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf dir', 'fatal: not removing \'dir\' recursively without -r')) == 'git rm -rf -r dir'

# Generated at 2022-06-18 08:17:27.459093
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))


# Generated at 2022-06-18 08:17:31.239733
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:17:35.152028
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))


# Generated at 2022-06-18 08:17:37.313618
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r -r test'

# Generated at 2022-06-18 08:17:42.955238
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:17:45.733317
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r -f --cached file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -f --cached -r file'

# Generated at 2022-06-18 08:17:48.011168
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file'

# Generated at 2022-06-18 08:17:50.197305
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file'

# Generated at 2022-06-18 08:19:00.400710
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:19:04.143397
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', ''))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:19:05.746898
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:19:08.354102
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file'

# Generated at 2022-06-18 08:19:11.078241
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r test'

# Generated at 2022-06-18 08:19:12.526424
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-18 08:19:20.524497
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 3))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 1))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', 0))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', -1))
    assert not match(Command('git rm -rf', 'fatal: not removing \'file\' recursively without -r', '', -3))

# Generated at 2022-06-18 08:19:24.778099
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1))


# Generated at 2022-06-18 08:19:31.771735
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r',
                             'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-18 08:19:40.318198
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file',
                             'fatal: not removing \'file\' recursively without -r\n'
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file',
                             'fatal: not removing \'file\' recursively without -r\n'
                             'fatal: not removing \'file\' recursively without -r\n'
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match