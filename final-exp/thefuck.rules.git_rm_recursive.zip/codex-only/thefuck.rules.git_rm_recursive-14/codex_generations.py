

# Generated at 2022-06-24 06:46:15.964330
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm file', '', '')) == 'git rm -r file'
    assert get_new_command(Command('git rm file', '', '')) == 'git rm -r file'
    assert get_new_command(Command('git rrm file', '', '')) == 'git rrm -r file'
    assert get_new_command(Command('git rm -rf file', '', '')) == 'git rm -r -rf file'

# Generated at 2022-06-24 06:46:19.585655
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    first_command = Command('git rm -f', '')
    assert ('git rm -f -r', None) == (
        get_new_command(first_command))

    second_command = Command('git rm -f -r', '')
    assert ('git rm -f -r', None) == (
        get_new_command(second_command))

# Generated at 2022-06-24 06:46:22.619594
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command(script='git rm a b c',
                                          output='fatal: not removing \'b\' recursively without -r'))
    assert u'git rm -r a b c' == new_command

# Generated at 2022-06-24 06:46:27.906909
# Unit test for function match
def test_match():
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('', '', ''))
    assert not match(Command('git rm file', '', 'fatal: unmerged files'))

# Unit tests for function get_new_command

# Generated at 2022-06-24 06:46:31.986758
# Unit test for function match
def test_match():
    """
    Test function match
    """
    assert match(Command('git rm hello', 'fatal: not removing \'hello\' recursively without -r'))
    assert match(Command('git rm hello', '')) == False

# Generated at 2022-06-24 06:46:34.857040
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'
    assert get_new_command(Command('git rm -qr file')) == 'git rm -qr -r file'

# Generated at 2022-06-24 06:46:37.022247
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command("git rm -r  -rf .")) == "git rm -rf ."

# Generated at 2022-06-24 06:46:39.504163
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r /")
    expected = "git rm -r -r /"
    assert get_new_command(command).script == expected



# Generated at 2022-06-24 06:46:43.744214
# Unit test for function match
def test_match():
    command1 = Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r')

    assert match(command1)

    command2 = Command('git rm --cached -r dir', '', 'fatal: not removing \'dir\' recursively without -r')

    assert not match(command2)



# Generated at 2022-06-24 06:46:47.070620
# Unit test for function match
def test_match():
    assert match(Command(script="git status",
                         output="fatal: not removing 'xx' recursively without -r"))
    assert not match(Command(script="git status",
                             output="fatal: not removing recursively without -r"))



# Generated at 2022-06-24 06:46:51.993834
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f folder', 'fatal: not removing \'folder\' recursively without -r')) == 'git rm -r -f folder'
    assert get_new_command(Command('git rm -f folder', 'fatal: not removing \'folder/filename.txt\' recursively without -r')) == 'git rm -r -f folder'

# Generated at 2022-06-24 06:46:55.903471
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git rm a', '')) == 'git rm -r a'
	assert get_new_command(Command('git rm a b', '')) == 'git rm -r a b'
	assert get_new_command(Command('git rm a b c', '')) == 'git rm -r a b c'

# Generated at 2022-06-24 06:46:59.403854
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm README.md', output='fatal: not removing \'README.md\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r README.md'

# Generated at 2022-06-24 06:47:00.834580
# Unit test for function get_new_command
def test_get_new_command():
  assert (get_new_command("git rm test") == "git rm -r test")

# Generated at 2022-06-24 06:47:04.392807
# Unit test for function get_new_command
def test_get_new_command():
    # Testing command without rm -r flag
    command = Command('rm -rf', '', 'fatal: not removing \'dir\' recursively without -r')
    assert get_new_command(command) == 'rm -rf -r'

# Generated at 2022-06-24 06:47:07.015796
# Unit test for function match
def test_match():
	output = 'fatal: not removing \'setup.py\' recursively without -r\n'
	command = Command('git rm setup.py', output)
	assert match(command)


# Generated at 2022-06-24 06:47:09.767387
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git rm -r a/b', 'fatal: not removing \'/a/b\' recursively without -r')) == 'git rm -r -r a/b'

# Generated at 2022-06-24 06:47:11.527778
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'

# Generated at 2022-06-24 06:47:14.692864
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = 'git rm file1.txt', output = 'fatal: not removing \'file1.txt\' recursively without -r\n')
    assert get_new_command(command) == command.script.replace('rm ', 'rm -r ')

# Generated at 2022-06-24 06:47:17.489944
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test', 'output')
    assert u'git rm -r test' == get_new_command(command)

# Generated at 2022-06-24 06:47:21.016602
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm -rf file")) == "git rm -rf -r file"
    assert get_new_command(Command("git rm --recursive --cached -f file")) == "git rm --recursive --cached -f -r file"


# Generated at 2022-06-24 06:47:25.768448
# Unit test for function match
def test_match():
    assert not match(Command('put rm file1 file2', '', '', None, None))
    assert not match(Command('put rm', '', '', None, None))
    assert match(Command('put rm file1 file2', 'fatal: not removing \'file1\' recursively without -r', '', None, None))
    assert not match(Command('put rm file1 file2', '', '', None, None))
    assert not match(Command('put r', '', '', None, None))


# Generated at 2022-06-24 06:47:28.013771
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command.from_string('git rm hello.txt')) == 'git rm -r hello.txt'

# Generated at 2022-06-24 06:47:31.979308
# Unit test for function match
def test_match():
    assert match(Command(script ='git rm hello.py', output = 'fatal: not removing \'hello.py\' recursively without -r'))
    assert not match(Command(script ='git rm hello.py', output = 'fatal: not removing \'hello.py\' '))


# Generated at 2022-06-24 06:47:34.649757
# Unit test for function get_new_command
def test_get_new_command():
    """Check function get_new_command of command 'git rm'"""
    command = Command('git rm test')
    assert get_new_command(command) == 'git rm -r test'

# Generated at 2022-06-24 06:47:36.475605
# Unit test for function match
def test_match():
    assert match(Command('git rm -r'))
    assert not match(Command('git rm'))


# Generated at 2022-06-24 06:47:40.937432
# Unit test for function match
def test_match():
    assert git_support
    assert match(Command('git rm file', ''))
    assert match(Command('git rm -rf file', ''))
    assert not match(Command('git rm', ''))
    assert not match(Command('git rm -r', ''))
    assert not match(Command('git add', ''))


# Generated at 2022-06-24 06:47:47.298853
# Unit test for function match

# Generated at 2022-06-24 06:47:52.927683
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command
    command = Command('cd ~/; git rm dir; git status',
                      'fatal: not removing \'dir\' recursively without -r\n')
    assert get_new_command(command) == 'cd ~/; git rm -r dir; git status'

# Generated at 2022-06-24 06:47:56.639106
# Unit test for function match
def test_match():
    assert match(Command(' rm '))
    assert not match(Command('git rm '))
    assert match(Command('git rm --cached'))
    assert match(Command('git rm -f --cached "path to file"'))
    assert not match(Command('git rm -r '))
    assert not match(Command('git rm'))



# Generated at 2022-06-24 06:48:00.943688
# Unit test for function match
def test_match():
    assert match(Command('git rm file name', 'fatal: not removing \'file name\' recursively without -r')) is True
    assert match(Command('rm file name', 'fatal: not removing \'file name\' recursively without -r')) is False



# Generated at 2022-06-24 06:48:03.667786
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm dir").script == "git rm -r dir"
    assert get_new_command("git-rm dir").script == "git-rm -r dir"


# Generated at 2022-06-24 06:48:06.816303
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f',
                                   'fatal: not removing '
                                   '\'a/b/c\' recursively without -r')) \
           == 'git rm -f -r'

# Generated at 2022-06-24 06:48:09.687836
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r q')
    assert get_new_command(command) == 'git rm -r -r q'

# Generated at 2022-06-24 06:48:12.724951
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r abc', 'fatal: not removing \'abc\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r abc'

# Generated at 2022-06-24 06:48:16.451979
# Unit test for function match
def test_match():
    # Test a command that matches
    assert match(Command('git rm file', '\nfatal: not removing \'file\' recursively without -r\n', '')) == True

    # Test a command that does not match
    assert match(Command('git rm file', 'No such file or directory\n', '')) == False



# Generated at 2022-06-24 06:48:18.111965
# Unit test for function match
def test_match():
    assert(match('git rm test.txt') == True)
    assert(match('git rm -r test.txt') == False)
    assert(match('git clone test.txt') == False)


# Generated at 2022-06-24 06:48:22.171276
# Unit test for function match
def test_match():
    assert match(Command('rm /path/to/working-tree.lock',
                         "fatal: not removing '"
                         "/path/to/working-tree.lock' recursively without -r"))
    assert not match(Command('git rm --cached -r .', ''))

# Generated at 2022-06-24 06:48:25.417706
# Unit test for function get_new_command
def test_get_new_command():
	cmd = Command("git rm xxx")
	new_cmd = get_new_command(cmd)
	assert new_cmd == "git rm -r xxx"

# Generated at 2022-06-24 06:48:27.623165
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test -r', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r test -r'

# Generated at 2022-06-24 06:48:30.880581
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file1 file2', '''
        error: invalid path 'file1'
        fatal: not removing 'file2' recursively without -r
        ''', None) == 'git rm -r file1 file2'

# Generated at 2022-06-24 06:48:32.707723
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm -r")) == "git rm -r -r"

# Generated at 2022-06-24 06:48:37.846336
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm file', '')) ==
           "git rm -r file")
    assert(get_new_command(Command('git rm file1 file2', '')) ==
           "git rm -r file1 file2")
    assert(get_new_command(Command('git rm .', '')) ==
           "git rm -r .")
    assert(get_new_command(Command('git rm -a', '')) ==
           "git rm -r -a")


# Generated at 2022-06-24 06:48:41.751664
# Unit test for function match
def test_match():
    assert match(Command('rm -r test.txt', ''))
    assert not match(Command('rm test.txt', ''))
    assert not match(Command('rm -r test.txt', '', ''))


# Generated at 2022-06-24 06:48:47.588028
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r', ''))

    assert get_new_command(Command('git rm file',
                                   'fatal: not removing \'file\' recursively without -r', '')) == 'git rm -r file'

    assert get_new_command(Command('git rm -x file',
                                   'fatal: not removing \'file\' recursively without -r', '')) == 'git rm -x -r file'

# Generated at 2022-06-24 06:48:50.318558
# Unit test for function match
def test_match():
    assert match(Command('git rm foo/bar',
                         'fatal: not removing \'foo/bar\' recursively without -r\n', 1))



# Generated at 2022-06-24 06:48:54.952459
# Unit test for function match
def test_match():
    script1 = 'git rm -r'
    script2 = 'git rm '

    output1 = 'fatal: not removing \'salam\' recursively without -r'
    output2 = 'fatal: not removing \'salam\' recursively without -f'

    command1 = Command(script1, output1)
    assert match(command1)

    command2 = Command(script2, output1)
    assert match(command2)

    command3 = Command(script1, output2)
    assert not match(command3)

    command4 = Command(script2, output2)
    asse

# Generated at 2022-06-24 06:48:56.563704
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf folder',
                         'fatal: not removing \'folder\' recursively without -r'))
    assert not match(Command('git rm -rf folder', ''))


# Generated at 2022-06-24 06:48:59.522843
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm hello.py", "fatal: not removing 'hello.py' recursively without -r")
    assert get_new_command(command) == "git rm -r hello.py"

# Generated at 2022-06-24 06:49:02.957391
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="git rm -r  file_name",
                      output="fatal: not removing 'file_name' recursively without -r")
    assert get_new_command(command) == u'git rm -r -r file_name'

# Generated at 2022-06-24 06:49:07.473629
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                        'fatal: not removing \'file\' recursively without -r'))
    assert match(Command('git rm -r file', '')) == False
    assert match(Command('git rm file',
                        'fatal: not removing \'file\' recursively without -r')) == False


# Generated at 2022-06-24 06:49:10.812064
# Unit test for function match
def test_match():
    assert match(Command('rm foo -rf',
                         'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo -rf',
                             'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git foo', ''))


# Generated at 2022-06-24 06:49:17.630610
# Unit test for function match
def test_match():
    assert match(Command(script='git rm -r new_dir',
                         stderr='fatal: not removing \'new_dir/\' recursively without -r'))
    assert not match(Command(script='git rm -r new_dir',
                             stderr='fatal: not removing \'new_dir /\' recursively without -r'))
    assert not match(Command(script='git rm new_dir',
                             stderr='fatal: not removing \'new_dir\' recursively without -r'))
    assert not match(Command(script='git rm new_dir',
                             stderr='fatal: not removing \'new_dir\' recursively without -r'))


# Generated at 2022-06-24 06:49:22.347106
# Unit test for function match
def test_match():

    from thefuck.types import Command
    assert not match(Command('git commit'))
    assert match(Command('git rm file-not-exist'))
    assert not match(Command('git rm -r folder'))
    assert match(Command('git rm -r file-not-exist'))
    assert match(Command('rm -r file-not-exist'))
    assert match(Command('rm file-not-exist'))



# Generated at 2022-06-24 06:49:24.820238
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm folder/',
                                   'fatal: not removing \'folder/\' recursively without -r',
                                   '',
                                   1)) == u'git rm -r folder/'

# Generated at 2022-06-24 06:49:25.710767
# Unit test for function match

# Generated at 2022-06-24 06:49:33.329784
# Unit test for function get_new_command
def test_get_new_command():
    assert "git rm -r" == get_new_command("git rm")
    assert "git rm -r" == get_new_command("git rm ")
    assert "git rm -r -r" == get_new_command("git rm -r")
    assert "git rm -r -r" == get_new_command("git rm -r ")
    assert "git file rm -r" == get_new_command("git file rm")
    assert "git file rm -r" == get_new_command("git file rm ")
    assert "git file rm -r -r" == get_new_command("git file rm -r")
    assert "git file rm -r -r" == get_new_command("git file rm -r ")

# Generated at 2022-06-24 06:49:36.757629
# Unit test for function match
def test_match():
    assert(match(Command('git rm -r abc')))
    assert(not match(Command('git rm abc')))
    assert(not match(Command('git rm abc', '')))
    assert(not match(Command('git rm abc', '', '')))


# Generated at 2022-06-24 06:49:46.691121
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test',
               output='fatal: not removing \'test\' recursively without -r'))
    assert match(Command('git rm test',
               output='fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm', output=''))
    assert not match(Command('git rm test', output=''))
    assert not match(Command('git rm -r', output=''))
    assert not match(Command('git rm',
                output='fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm -r',
                output='fatal: not removing \'test\' recursively without -r'))


# Generated at 2022-06-24 06:49:56.370570
# Unit test for function match
def test_match():
    """Test case match"""
    assert not match(Command('git rm "*.pyc"', ""))
    assert not match(Command('git rm README.md', ""))

    assert match(Command('git rm -r "*.pyc"', ""))
    assert match(Command('git rm -r README.md', ""))
    assert match(Command('git rm --cached "*.pyc"', ""))
    assert match(Command('git rm --cached README.md', ""))

    assert match(Command('git rm "*.pyc"', "fatal: not removing 'foo' recursively without -r\n"))
    assert match(Command('git rm README.md', "fatal: not removing 'foo' recursively without -r\n"))


# Generated at 2022-06-24 06:49:59.681480
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r folder',
                                   'fatal: not removing '
                                   '\'folder\' recursively without -r')) == 'git rm -r -r folder'

# Generated at 2022-06-24 06:50:03.984710
# Unit test for function match
def test_match():
    assert match(Command('git rm some/folder', stderr='fatal: not removing \'some/folder\' recursively without -r'))
    assert not match(Command('git rm some/folder', stderr='fatal: not removing \'some/folder\''))
    assert not match(Command('git branch', stderr='fatal: not removing \'some/folder\''))



# Generated at 2022-06-24 06:50:05.877684
# Unit test for function match
def test_match():
    command = Command(script='git rm file.txt',
                      output="fatal: not removing 'file.txt' recursively without -r")
    assert match(command)



# Generated at 2022-06-24 06:50:09.836474
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing '
                         "'folder/file' recursively without -r\n"))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: '
                                         "pathspec 'file' did not match any "
                                         'files'))


# Generated at 2022-06-24 06:50:13.101878
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git rm nadeesh/ tests/', 'fatal: not removing \'nadeesh/\' recursively without -r')) == 'git rm -r nadeesh/ tests/'

# Generated at 2022-06-24 06:50:18.468373
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = 'git rm -f .',
                                   output = 'fatal: not removing '.concat('\''.concat('\' recursively without -r')),
                                   stderr = 'fatal: not removing '.concat('\''.concat('\' recursively without -r')))) == 'git rm -f -r .'

# Generated at 2022-06-24 06:50:22.698860
# Unit test for function match
def test_match():
    assert match(Command('git rm -r dir', 'fatal: not removing \'dir\' recursively without -r'))  # noqa
    assert not match(Command('git rm dir', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))  # noqa


# Generated at 2022-06-24 06:50:31.159875
# Unit test for function match
def test_match():
    def assert_match(script, output, expected_status):
        assert match(Command(script, output)) == expected_status

    assert_match('git rm "some_file/some_dir"',
                 'fatal: not removing '
                 '\'some_file/some_dir\' recursively '
                 'without -r', True)

    assert_match('git rm "some_file/some_dir"',
                 'fatal: not removing '
                 '\'some_file/some_dir\' '
                 'without -r', False)

    assert_match('git rm "some_file/some_dir"',
                 'fatal: not removing '
                 '\'some_file/some_dir\' recursively', False)


# Generated at 2022-06-24 06:50:35.307430
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    script = 'rm f'
    output = ("fatal: not removing 'f' recursively without -r\n"
              "Did you mean 'rm -r f'?")
    assert get_new_command(Command(script=script, output=output)) == 'rm -r f'

# Generated at 2022-06-24 06:50:37.795555
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command('git rm file.txt') == 'git rm -r file.txt'


# Generated at 2022-06-24 06:50:40.580538
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert ('git rm -r file'
            == get_new_command(Command('git rm file',
                                       'fatal: not removing file recursively without -r')))

# Generated at 2022-06-24 06:50:45.649218
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf',
                         'fatal: not removing \'non-existent-file\' recursively without -r'))
    assert match(Command('git rm',
                         'fatal: not removing \'non-existent-file\' recursively without -r'))
    assert not match(Command('git rm -r', 'Not removing'))


# Generated at 2022-06-24 06:50:50.786613
# Unit test for function match
def test_match():
    assert match(Command(script='git rm a',
                         stderr="fatal: not removing 'a' recursively without -r"))
    assert match(Command(script='rm a',
                         stderr="fatal: not removing 'a' recursively without -r"))
    assert not match(Command(script='git rm a',
                             stderr="fatal: not removing 'b' recursively without -r"))
    assert not match(Command(script='git rm a',
                             stderr="fatal: not removing 'a' recursively without -r\nNot fatal"))



# Generated at 2022-06-24 06:51:00.177533
# Unit test for function match
def test_match():
    assert(match(Command('git status', 'fatal: not removing \'.gitignore\' recursively without -r\n')))
    assert(match(Command('git status', 'fatal: not removing \'.gitignore\', \'file.txt\' recursively without -r\n')))
    assert(match(Command('git status', 'fatal: not removing \'file.txt\', \'.gitignore\' recursively without -r\n')))
    assert(match(Command('git status', 'fatal: not removing \'file.txt\', \'.gitignore\' recursively without -r\n')))
    assert(not match(Command('git status', 'fatal: not removing \'..gitignore\' recursively without -r')))

# Generated at 2022-06-24 06:51:01.937721
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == u'git rm -r file'

# Generated at 2022-06-24 06:51:03.246629
# Unit test for function match
def test_match():
    assert match(Command('git rm test', ''))
    assert not match(Command('rm test', ''))

#Unit test for function get_new_command

# Generated at 2022-06-24 06:51:06.579709
# Unit test for function match
def test_match():
    str = "fatal: not removing 'FILE.txt' recursively without -r"
    assert match(Command('git rm FILE.txt', str))
    assert match(Command('git rm -f FILE.txt', str))
    assert match(Command('git rm FILE.txt -f', str))


# Generated at 2022-06-24 06:51:09.706732
# Unit test for function get_new_command
def test_get_new_command():
    """ get_new_command should return a command with a -r flag """
    command = Command('rm test')
    assert get_new_command(command) == "git rm -r test"

# Generated at 2022-06-24 06:51:13.104338
# Unit test for function get_new_command
def test_get_new_command():
    output = 'fatal: not removing \'dir\' recursively without -r\n'
    command = 'git rm dir'
    assert(get_new_command(command, output) == 'git rm -r dir')

enabled_by_default = True

# Generated at 2022-06-24 06:51:16.696727
# Unit test for function match
def test_match():
    assert match(Command('git rm myfile',
                         'fatal: not removing "myfile" recursively without -r'))
    assert not match(Command('git rm myfile',
                             'error: pathspec "myfile" did not match any files'))

# Generated at 2022-06-24 06:51:18.711937
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command('git rm file.txt')) == 'git rm -r file.txt'

# Generated at 2022-06-24 06:51:20.895767
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 
        "fatal: not removing 'foo' recursively without -r"))
    assert not match(Command('git rm foo', ''))


# Generated at 2022-06-24 06:51:25.147753
# Unit test for function get_new_command
def test_get_new_command():
    # mock of command.
    command = Mock(script='git rm foo/bar.txt', output='fatal: not removing \'foo/\' recursively without -r')
    output = get_new_command(command)
    assert output == 'git rm -r foo/bar.txt'


# Generated at 2022-06-24 06:51:30.234061
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf text', '', 'fatal: not removing \'text/text2\' recursively without -r'))
    assert not match(Command('git rm', '', 'fatal: not removing \'text/text2\' recursively without -r'))
    assert not match(Command('git', '', ''))


# Generated at 2022-06-24 06:51:32.278639
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf dir', output='error: '))



# Generated at 2022-06-24 06:51:33.329805
# Unit test for function match

# Generated at 2022-06-24 06:51:35.943329
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r folder')
    assert get_new_command(command) == 'git rm -r -r folder'

# Generated at 2022-06-24 06:51:37.349421
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm hello.txt', '')) == 'git rm -r hello.txt'

# Generated at 2022-06-24 06:51:41.368517
# Unit test for function match
def test_match():
    '''
    Test to determine if the git rm command will match.
    '''

    # Call function match
    test_match = git.match(git.match(command))

    # Verify the result
    assert test_match == None


# Generated at 2022-06-24 06:51:49.884444
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(
        Command('rm test.txt', 'fatal: not removing \'test.txt\' recursively \
without -r')) == 'git rm -r test.txt')
    assert(get_new_command(
        Command('rm .git/test.txt', 'fatal: not removing \'.git/test.txt\' \
recursively without -r')) == 'git rm -r .git/test.txt')
    assert(get_new_command(
        Command('rm src', 'fatal: not removing \'src\' recursively without -r'))
        == 'git rm -r src')

# Generated at 2022-06-24 06:51:53.384604
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
        'fatal:  not removing \'foo\' recursively without -r', ''))
    assert not match(Command('git rm foo', '', ''))
    assert not match(Command('git pull', '', ''))


# Generated at 2022-06-24 06:51:56.643949
# Unit test for function match
def test_match():
    test_string = "git rm: refusing to remove \'.gitignore\' recursively without -r"
    assert match(Command("git rm .gitignore", test_string))
    assert not match(Command("git rm .gitignore", ''))


# Generated at 2022-06-24 06:51:59.034946
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git rm -r') == 'git rm -r -r'

# Generated at 2022-06-24 06:52:03.058484
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck import shells
    from thefuck.specific.git import git_support

    assert git_support
    assert get_new_command(shells.and_('git rm foo', 'fatal: not removing '
                                       'foo recursively without -r')) == 'git rm -r foo'

# Generated at 2022-06-24 06:52:11.516045
# Unit test for function match
def test_match():
    assert match(Command(script='git rm $a',
                         output='fatal: not removing ' +
                         "'some/file' recursively without -r"))
    assert match(Command(script='git rm',
                         output='fatal: not removing ' +
                         "'some/file' recursively without -r"))
    assert not match(Command(script='git rm',
                             output='fatal: not removing recursively ' +
                             "without -r"))
    assert not match(Command(script='git rm',
                             output='fatal: not removing ' +
                             "'some/file' recursively without -r",
                             stderr='fatal: not removing ' +
                             "'some/file' recursively without -r"))



# Generated at 2022-06-24 06:52:13.499002
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm file.txt")== "git rm -r file.txt"

# Generated at 2022-06-24 06:52:16.459129
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm README.md') == 'git rm -r README.md'
    assert get_new_command('git rm -f README.md') == 'git rm -f -r README.md'
    assert not git_support('git rm')
    assert not git_support('git ')
    assert not git_support('ls')

# Generated at 2022-06-24 06:52:19.739084
# Unit test for function match
def test_match():
    assert(match(Command("git rm <file>", "fatal: not removing '<file>' recursively without -r\n"))!=False)
    assert(match(Command("git rm -r <file>", "fatal: not removing '<file>' recursively without -r\n"))==False)
    assert(match(Command("git rm <file>", "fatal: not removing '<file>' recursively\n"))==False)
    assert(match(Command("git rm <file>", "<file> not found\n"))==False)
    

# Generated at 2022-06-24 06:52:24.837513
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_not_removing_recursively import get_new_command
    assert get_new_command(Command('git rm -f')) == 'git rm -f -r'
    assert get_new_command(Command('git rm -f -n')) == 'git rm -f -n -r'

# Generated at 2022-06-24 06:52:27.549035
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' '
                      'recursively without -r')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-24 06:52:31.342668
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursive import get_new_command
    from thefuck.shells import shell
    assert get_new_command(shell.and_('git rm Makefile',
                                      "fatal: not removing 'Makefile' recursively without -r")) ==\
           'git rm -r Makefile'

# Generated at 2022-06-24 06:52:41.672108
# Unit test for function match
def test_match():
    global match
    match_script_1 = Command('git rm -rf')
    match_script_1.results = "fatal: not removing 'file.h' recursively without -r"
    assert match(match_script_1)

    match_script_2 = Command('git rm')
    match_script_2.results = "fatal: not removing 'file.h' recursively without -r"
    assert match(match_script_2)

    unmatch_script_3 = Command('git rm')
    unmatch_script_3.results = "error: your local changes to the following files would be overwritten by merge:"
    assert not match(unmatch_script_3)

    unmatch_script_4 = Command('git rm -rf')

# Generated at 2022-06-24 06:52:46.646864
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r',
                         None))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively',
                             None))
    assert not match(Command('git rm file', '', None))


# Generated at 2022-06-24 06:52:54.944444
# Unit test for function match
def test_match():
    # Return true when the correct error appears on screen
    command = Command('git rm test -r', 'fatal: not removing \'test\' recursively without -r')
    assert match(command)
    # Return false when the error is not there
    command = Command('git rm test -r', 'fatal: not removing \'test\' recursively with -r')
    assert not match(command)
    # Return false when the error is there but not in the correct place
    command = Command('git rm test', 'fatal: not removing \'test\' recursively without -r')
    assert not match(command)
    # Return false when git support is not enabled
    command = Command('rm test -r', 'fatal: not removing \'test\' recursively without -r')
    assert not match(command)


# Generated at 2022-06-24 06:52:59.197589
# Unit test for function match
def test_match():
    assert match(Command('rm file.txt',
                         'fatal: not removing \'file.txt\' recursively'
                         ' without -r'))
    assert not match(Command('rm file.txt', ''))
    assert not match(Command('cp file.txt newfile.txt', ''))
    assert not match(Command('', ''))


# Generated at 2022-06-24 06:53:02.722299
# Unit test for function get_new_command
def test_get_new_command():
    unit_test_command = Command('git rm folder/subfolder', 'fatal: not removing \'folder/subfolder\' recursively without -r\n')
    assert u'git rm -r folder/subfolder' == get_new_command(unit_test_command)

# Generated at 2022-06-24 06:53:04.838707
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-24 06:53:11.033460
# Unit test for function match
def test_match():
    output =  "fatal: not removing 'API/app/Http/Controllers/TestController.php' recursively without -r"
    assert match(Command(" git stash ", output)) is True
    assert match(Command(" git rm ", output)) is True
    assert match(Command(" git rm -f ", output)) is True
    assert match(Command(" git rm -rf ", output)) is False
    assert match(Command(" git stash ", output)) is True
    assert match(Command(" git stash drop ", output)) is False


# Generated at 2022-06-24 06:53:13.789859
# Unit test for function get_new_command
def test_get_new_command():
    output = 'fatal: not removing \'testing_dir\' recursively without -r'
    command = Command('git rm testing_dir', output)

    assert get_new_command(command) == u'git rm -r testing_dir'

# Generated at 2022-06-24 06:53:16.924462
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm test', output="fatal: not removing 'test' recursively without -r")) == "git rm -r test"
    assert get_new_command(Command(script='git rm test', output="fatal: not removing 'test/' recursively without -r")) == "git rm -r test/"

# Generated at 2022-06-24 06:53:24.529913
# Unit test for function get_new_command
def test_get_new_command():
    # no quotes in rm command
    command = Command(script='git add "arg"', output='')
    assert get_new_command(command) == u'git add -r "arg"'
    assert 'rm' not in get_new_command(command)

    # quotes in rm command
    command = Command(script='git add "arg"', output='')
    assert get_new_command(command) == u'git add -r "arg"'
    assert 'rm' not in get_new_command(command)


# Unit tests for function match

# Generated at 2022-06-24 06:53:33.080095
# Unit test for function match
def test_match():
    from thefuck.main import Command

    # When git command output contains all necessary information
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n')
    assert match(command)

    # When git command output is missing part of necessary information
    command = Command('git rm file', 'fatal: not removing \'file\' recursively\n')
    assert not match(command)

    # When git command output is missing all necessary information
    command = Command('git rm file', 'fatal: removing \'file\' recursively\n')
    assert not match(command)


# Generated at 2022-06-24 06:53:41.034933
# Unit test for function match
def test_match():
    assert match(Command('git rm hello-world', '', 'fatal: not removing \'hello-world\' recursively without -r\n'))
    assert match(Command('rm hello-world', '', 'fatal: not removing \'hello-world\' recursively without -r\n'))
    assert match(Command('git rm hello-world bimbo', '', 'fatal: not removing \'hello-world\' recursively without -r\n'))
    assert match(Command('rm hello-world bimbo', '', 'fatal: not removing \'hello-world\' recursively without -r\n'))
    assert not match(Command('git rm hello-world', '', ''))

# Generated at 2022-06-24 06:53:47.968442
# Unit test for function match
def test_match():
    assert match(Command('git rm src/file', 'fatal: not removing \'src/file\' recursively without -r'))
    assert not match(Command('git rm src/file', 'fatal: not removing anything'))
    assert not match(Command('git rm src/file', 'fatal: not removing "file.txt" recursively without -r'))
    assert not match(Command('git rm src/file', 'fatal: not removing "file.txt" recursively without'))


# Generated at 2022-06-24 06:53:50.896076
# Unit test for function match
def test_match():
    assert match(Command('git rm dir', "fatal: not removing 'dir' recursively without -r")) is True
    assert match(Command('git rm dir', "")) is False


# Generated at 2022-06-24 06:53:51.833314
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_co

# Generated at 2022-06-24 06:53:55.171754
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1 file2 file3', 'fatal: not removing \'file1\' recursively without -r')) == u'git rm -r file1 file2 file3'



# Generated at 2022-06-24 06:53:57.334049
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git rm file',
                output="fatal: not removing 'file' recursively without -r")) == 'git rm -r file'

# Generated at 2022-06-24 06:53:59.334074
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command
    assert get_new_command(command) == "git rm -r README.md"

# Generated at 2022-06-24 06:54:03.159206
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')
    command.script_parts = ['git', 'rm', 'foo']
    assert get_new_command(command) == 'git rm -r foo'

# Generated at 2022-06-24 06:54:09.249431
# Unit test for function match
def test_match():
    assert match(Command("git rm 'config-file.yaml'", "'config-file.yaml' recursively without -r", ""))
    assert not match(Command("git rm 'config-file.yaml'", "", ""))
    assert not match(Command("git rmi 'config-file.yaml'", "'config-file.yaml' recursively without -r", ""))


# Generated at 2022-06-24 06:54:14.382336
# Unit test for function match
def test_match():
    assert match(Command('git rm file/path', u'fatal: not removing \'directory/\' recursively without -r'))
    assert not match(Command('git rr file/path', u'fatal: not removing \'directory/\' recursively without -r'))
    assert not match(Command('git rm file/path', u'fatal: not removing \'directory/\' recursively'))


# Generated at 2022-06-24 06:54:16.356000
# Unit test for function match
def test_match():
    assert match(Command('git rm foo.txt', ''))
    assert not match(Command('git rm -r foo.txt', ''))

# Generated at 2022-06-24 06:54:25.494344
# Unit test for function match
def test_match():
    assert match(Command('git checkout master',
                         "fatal: not removing 'node_modules/' recursively without -r",
                         ''))
    assert match(Command('git rm non_existing_file.txt',
                         'fatal: not removing \'non_existing_file.txt\' recursively without -r',
                         '')) is False
    assert match(Command('git rm -r some/path',
                         'fatal: not removing \'some/path\' recursively without -r',
                         '')) is False
    assert match(Command('git rm -rf some/path',
                         'fatal: not removing \'some/path\' recursively without -r',
                         '')) is False

# Generated at 2022-06-24 06:54:32.743151
# Unit test for function match
def test_match():
    assert match(Command('git rm *.py',
                         'fatal: not removing \'com.py\' recursively without -r\n'))
    assert not match(Command('git rm *.py', 'fatal: not removing'))
    assert not match(Command('git rm *.py', 'fatal: not removing \'recursively without -r\''))
    assert not match(Command('git rm *.py', 'fatal: not removing \'com.py\' recursively without -r'))


# Generated at 2022-06-24 06:54:35.451954
# Unit test for function match
def test_match():
    command = Command(script='git status --porcelain',
        output="fatal: not removing 'src/global_variables.py' recursively without -r")
    assert match(command)


# Generated at 2022-06-24 06:54:43.161736
# Unit test for function match
def test_match():
    command = Command('git rm b', 'fatal: not removing \'b\' recursively without -r\n', '')
    assert match(command) == True
    command = Command('git rm a', 'fatal: not removing \'a\' recursively without -r\n', '')
    assert match(command) == True
    command = Command('git rm c', 'fatal: not removing \'c\' recursively without -r\n', '')
    assert match(command) == True
    command = Command('git rm d', 'fatal: not removing \'d\' recursively without -r\n', '')
    assert match(command) == True


# Generated at 2022-06-24 06:54:49.015138
# Unit test for function match

# Generated at 2022-06-24 06:54:56.354826
# Unit test for function match
def test_match():
    assert match(Command('rm file', 'fatal: not removing \'file\' recursively without -r\n', ''))
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n', ''))
    assert not match(Command('rm -r file', 'fatal: not removing \'file\' recursively without -r\n', ''))
    assert not match(Command('rm file', 'fatal: foobar\n', ''))


# Generated at 2022-06-24 06:54:58.604274
# Unit test for function match
def test_match():
    assert match(Command('git rm test.txt',
                         'fatal: not removing \'test.txt\' recursively without -r'))


# Generated at 2022-06-24 06:55:01.143597
# Unit test for function match
def test_match():
    assert match(Command('git rm xyz.c',
                         'fatal: not removing \'xyz.c\' recursively without -r'))

# Generated at 2022-06-24 06:55:05.707433
# Unit test for function match
def test_match():
    assert match(Command('rm foo',
                         '')) is None
    assert match(Command('git rm foo',
                         'fatal: not removing \'bar\' recursively without -r\n'))
    assert not match(Command('git rm foo',
                         'fatal: not removing \'bar\' recursively without -r\n'))


# Generated at 2022-06-24 06:55:10.234847
# Unit test for function match

# Generated at 2022-06-24 06:55:13.354481
# Unit test for function match
def test_match():
    assert match(Command(' git rm -r fileA'))
    assert match(Command(' git rm -r fileA fileB'))
    assert not match(Command(' git rm fileA'))
    assert not match(Command(' rm fileA'))


# Generated at 2022-06-24 06:55:15.030239
# Unit test for function match
def test_match():
	# Unit test when match
	assert match('git rm xxxxxx')
	# Unit test when not match
	assert match('git rm') == False

# Generated at 2022-06-24 06:55:17.749083
# Unit test for function match
def test_match():
    assert match(Command(' git rm -r name ', '', '', 0, '/'))
    assert not match(Command(' git rm name ', '', '', 0, '/'))
    assert not match(Command(' ls', '', '', 0, '/'))


# Generated at 2022-06-24 06:55:21.686519
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_recursive_rm import get_new_command
    assert get_new_command(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'


# Generated at 2022-06-24 06:55:25.753037
# Unit test for function match
def test_match():
    command = Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r\n')
    assert match(command)
    command = Command('git rm file.txt', '')
    assert not match(command)


# Generated at 2022-06-24 06:55:36.328014
# Unit test for function match
def test_match():
    # if git_support == true
    assert match(Command('git rm file/other_file.py', '')) == True
    assert match(Command('git rm file/other_file.py', 'fatal: not removing     ''file/other_file.py'' recursively without -r\n')) == True
    assert match(Command('git rm file/other_file.py', 'fatal: not removing     ''file/other_file.py'' recursively without -r')) == True
    assert match(Command('git rm file/other_file.py', 'fatal: not removing     ''file/other_file.py'' recursively without -r\n',
    'fatal: not removing     ''file/other_file.py'' recursively without -r')) == True

# Generated at 2022-06-24 06:55:39.709508
# Unit test for function get_new_command
def test_get_new_command():
    output = 'fatal: not removing \'thing/\' recursively without -r'
    command = Command('git rm thing/', output)
    expected_command = 'git rm -r thing/'
    assert get_new_command(command) != expected_command

# Generated at 2022-06-24 06:55:47.189012
# Unit test for function match
def test_match():
    assert (match(Command(script='git rm test.txt',
                          output="fatal: not removing 'test.txt' recursively without -r"))
            == True)
    assert (match(Command(script='git rm test.txt',
                          output='test.txt: No such file or directory'))
            == False)
    assert (match(Command(script='ls test.txt',
                          output='test.txt: No such file or directory'))
            == False)


# Generated at 2022-06-24 06:55:56.448631
# Unit test for function match
def test_match():
    assert match(Command('git rm -r a.txt', 'fatal: not removing \'a.txt\' recursively without -r'))
    assert match(Command('git branch rm -r a.txt', 'fatal: not removing \'a.txt\' recursively without -r'))
    assert not match(Command('git rm -r a.txt', 'fatal: not removing \'a.txt\' recursively unless -r'))
    assert not match(Command('git branch rm -r a.txt', 'fatal: not removing \'a.txt\' recursively unless -r'))
    assert not match(Command('rm -r a.txt', 'fatal: not removing \'a.txt\' recursively without -r'))

# Generated at 2022-06-24 06:55:57.619727
# Unit test for function match
def test_match():
    assert match(Command('git rm -r'))
    assert not match(Command('rm -r'))

# Generated at 2022-06-24 06:56:00.607446
# Unit test for function get_new_command
def test_get_new_command():
    script = "git rm file.txt"
    output = "fatal: not removing 'file.txt' recursively without -r"
    command = Command(script, output)
    assert get_new_command(command) == "git rm -r file.txt"

# Generated at 2022-06-24 06:56:06.589892
# Unit test for function match
def test_match():
    class TestCmd(object):
        def __init__(self, script, output):
            self.script = script
            self.output = output
    assert match(TestCmd('git rm', "fatal: not removing 'dir' recursively without -r\n"))
    assert match(TestCmd('git rm tmp/test', "fatal: not removing 'dir' recursively without -r\n"))
    assert not match(TestCmd('git rm -r', "fatal: not removing 'dir' recursively without -r\n"))
    assert match(TestCmd('git rm', "fatal: not removing 'file' recursively without -r\n"))
    assert match(TestCmd('git rm tmp/file', "fatal: not removing 'file' recursively without -r\n"))


# Generated at 2022-06-24 06:56:16.476026
# Unit test for function match
def test_match():
    output_without_recursive_error = '''
error: The following untracked working tree files would be removed by checkout:
	file1
	file2
Please move or remove them before you switch branches.
Aborting
'''
    output_with_recursive_error = '''
error: The following untracked working tree files would be removed by checkout:
	file1
	file2
	file3
Please move or remove them before you switch branches.
Aborting
'''

    # Test for match
    assert match(Command('git rm file1 file2 file3', output_with_recursive_error))
    assert match(Command('git rm file1 file2', output_with_recursive_error))
    assert match(Command('git rm file1 file2 file3', output_without_recursive_error)) is False