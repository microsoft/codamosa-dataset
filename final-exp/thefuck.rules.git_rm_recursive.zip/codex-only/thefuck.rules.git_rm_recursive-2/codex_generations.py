

# Generated at 2022-06-24 06:46:13.544925
# Unit test for function match
def test_match():
    assert match({'script': "git rm file",
                  'output': 'fatal: not removing \'file\' recursively without -r'})

    assert match({'script': "some command",
                  'output': 'fatal: not removing \'file\' recursively without -r'}) is False


# Generated at 2022-06-24 06:46:15.342367
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf this_folder'))
    assert not match(Command('cd /'))


# Generated at 2022-06-24 06:46:18.397844
# Unit test for function get_new_command
def test_get_new_command():
    # Simple case
    assert get_new_command('git rm -f file1.txt') == 'git rm -r -f file1.txt'
    # Advanced case
    assert get_new_command('git rm -r -f file1.txt dir1') == 'git rm -r -r -f file1.txt dir1'

# Generated at 2022-06-24 06:46:21.990944
# Unit test for function match

# Generated at 2022-06-24 06:46:24.299526
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm CNAME', 'fatal: not removing \'CNAME\' recursively without -r')) == 'git rm -r CNAME'



# Generated at 2022-06-24 06:46:32.430854
# Unit test for function match
def test_match():
    assert match(Command('rm -r RM', "", "fatal: not removing 'RM' recursively without -r"))
    assert match(Command('git rm RM', "", "fatal: not removing 'RM' recursively without -r"))
    assert match(Command('rm -r RM', "", "fatal: rm -r RM: No such file or directory"))
    assert not match(Command('rm -r RM', "", "Error: rm -r RM: No such file or directory"))
    assert not match(Command('git rm RM', "", "fatal: rm -r RM: No such file or directory"))


# Generated at 2022-06-24 06:46:34.892957
# Unit test for function match
def test_match():
    command = Command(' git rm -r test')
    assert match(command)
    assert not match(Command(''))
    assert not match(Command(' git rm test'))


# Generated at 2022-06-24 06:46:38.189831
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command(script='git rm tests',
                           stdout='''fatal: not removing 'tests' recursively without -r''')
    assert get_new_command(test_command) == 'git rm -r tests'

# Generated at 2022-06-24 06:46:43.922748
# Unit test for function match
def test_match():
    assert match(Command('git rm x', "fatal: not removing 'x' recursively without -r"))
    assert not match(Command('git rm -r x', "fatal: not removing 'x' recursively without -r"))
    assert not match(Command('git rm x', "fatal: not removing 'x' recursively without -R"))
    assert not match(Command('rm x', "fatal: not removing 'x' recursively without -r"))


# Generated at 2022-06-24 06:46:46.683777
# Unit test for function get_new_command
def test_get_new_command():
   command = Command('git rm -rf folder/')
   command.stderr = "fatal: not removing 'folder/' recursively without -r"
   assert get_new_command(command) == 'git rm -rf -r folder/'

# Generated at 2022-06-24 06:46:53.289804
# Unit test for function get_new_command
def test_get_new_command():
    # Testing handling of filenames with spaces
    command = Command("git rm 'filename with spaces'",
                      'fatal: not removing \'filename with spaces\' recursively without -r')
    assert get_new_command(command) == "git rm -r 'filename with spaces'"
    # Testing handling of filenames without spaces
    command = Command("git rm filename",
                      'fatal: not removing \'filename\' recursively without -r')
    assert get_new_command(command) == "git rm -r filename"

# Generated at 2022-06-24 06:46:55.420352
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm abc')) == 'git rm -r abc'

# Generated at 2022-06-24 06:47:00.563231
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm rmscript.sh')
    output = u"""
    fatal: not removing 'rmscript.sh' recursively without -r
    """
    command.output = output
    assert(get_new_command(command) == "git rm -r rmscript.sh")

# Generated at 2022-06-24 06:47:04.141437
# Unit test for function match
def test_match():
    # Check that match function works correctly
    assert match('git rm file')
    assert not match('git rm -r file')
    assert match('git rm file')
    assert not match('git')
    assert not match('something rm file')


# Generated at 2022-06-24 06:47:12.307068
# Unit test for function match
def test_match():
    assert match(Command('git commit',
                output="fatal: not removing 'file' recursively without -r"))
    assert not match(Command('git commit',
                output="fatal: not removing 'file' recursively wit -r"))
    assert not match(Command('git commit',
                output="fatal: not removing 'file' recursively with -r"))
    assert not match(Command('git checkout -b master',
                output="fatal: not removing 'file' recursively with -r"))
    assert not match(Command('git commit',
                output="fatal: not removing 'file' recursively without -w"))
    assert not match(Command('git commit -m "fail"',
                output="fatal: not removing 'file' recursively without -r"))
    assert not match(Command('git rm'))


# Generated at 2022-06-24 06:47:14.337045
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f test_path', 'fatal: not removing \'test_path\' recursively without -r')
    assert get_new_command(command) == 'git rm -f -r test_path'

# Generated at 2022-06-24 06:47:17.491737
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -r") == "git rm -r -r"
    assert get_new_command("git rm") == "git rm -r"

# Generated at 2022-06-24 06:47:21.745041
# Unit test for function match
def test_match():
    assert match(Command(script="git remote rm origin",
                         output="error: not removing 'origin' recursively without -r"))
    assert not match(Command(script="git remote rm origin",
                         output="error: not removing 'origin' recursively without -r",
                         stderr="fatal: not removing 'origin' recursively without -r"))

# Generated at 2022-06-24 06:47:23.491610
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo')) == 'git rm -r foo'

# Generated at 2022-06-24 06:47:29.041968
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.main import Command

    command = Command('git branch -d ab', 'error: branch \'ab\' not found.', '')
    assert 'git branch -D ab' == get_new_command(command)

    command = Command('git rm a', 'fatal: not removing \'a\' recursively without -r', '')
    assert 'git rm -r a' == get_new_command(command)

# Generated at 2022-06-24 06:47:32.444500
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm xxx.txt', 'fatal: not removing \'xxx.txt\' recursively without -r')
    output = get_new_command(command)
    assert output == 'git rm -r xxx.txt'

# Generated at 2022-06-24 06:47:37.470458
# Unit test for function match
def test_match():
    assert match(Command(script = 'git rm ', output = 'fatal: not removing \'file or directory\' recursively without -r'))
    assert not match(Command(script = 'git rm -r', output = 'fatal: not removing \'file or directory\' recursively without -r'))
    assert not match(Command(script = 'ls', output = 'fatal: not removing \'file or directory\' recursively without -r'))


# Generated at 2022-06-24 06:47:40.364805
# Unit test for function get_new_command
def test_get_new_command():
    output = 'fatal: not removing \'path/subpath/subsubpath\' recursively without -r'

# Generated at 2022-06-24 06:47:43.160754
# Unit test for function get_new_command
def test_get_new_command():
    command = "git rm file.txt"
    assert(get_new_command(Command(command, "fatal: not removing '" + command + "' recursively without -r")) ==
    "git rm -r file.txt")


# Generated at 2022-06-24 06:47:49.430263
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('rm file.txt') == 'rm -r file.txt'
    assert get_new_command('rm /tmp/file.txt') == 'rm -r /tmp/file.txt'
    assert get_new_command('rm -f file.txt') == 'rm -f -r file.txt'
    assert get_new_command('git rm file.txt') == 'git rm -r file.txt'

# Generated at 2022-06-24 06:47:56.361579
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('', 'error: The following untracked working tree files would be overwritten by merge:\n    autotune.sh\nPlease move or remove them before you can merge.')
    assert get_new_command(command) == 'git stash -u'
    
    command = Command('git stash show error: Your local changes to the following files would be overwritten by merge:\n    autotune.sh\nPlease, commit your changes or stash them before you can merge.')
    assert get_new_command(command) == 'git stash'
    
    command = Command('git rm ffff','fatal: not removing \'ffff\' recursively without -r')
    assert get_new_command(command) == 'git rm -r ffff'

# Generated at 2022-06-24 06:48:01.329742
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf foo',
                         'fatal: not removing \'foo/bar\' recursively without -r\n',
                         None))
    assert not match(Command('git rm -rf',
                             'fatal: not removing \'foo/bar\' recursively without -r\n',
                             None))


# Generated at 2022-06-24 06:48:04.487282
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git branch foo', 'fatal: not removing \'foo\' recursively without -r'))



# Generated at 2022-06-24 06:48:06.433896
# Unit test for function match
def test_match():
    assert match(make_command('git rm bad-file'))
    assert not match(make_command('git commit'))


# Generated at 2022-06-24 06:48:08.275435
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r .')) == 'git rm .'

# Generated at 2022-06-24 06:48:12.103343
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r *', '', 'fatal: not removing \'.gitignore\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r -r *'

# Generated at 2022-06-24 06:48:15.009625
# Unit test for function match
def test_match():
	output = "fatal: not removing 'prog/main.tex' recursively without -r\n"
	assert match(Command(script='git rm prog/main.tex',
						 output=output))



# Generated at 2022-06-24 06:48:19.609163
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('rm -rf .') == 'rm -rf -r .'
    assert get_new_command('rm -rf test_repo') == 'rm -rf -r test_repo'
    assert get_new_command('rm -rf test_repo/') == 'rm -rf -r test_repo/'
    assert get_new_command('rm -rf test_repo/test.py') == 'rm -rf -r test_repo/test.py'

# Generated at 2022-06-24 06:48:22.609160
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm hello.txt',
                                   'fatal: not removing \'hello.txt\' recursively without -r\n')) == u'git rm -r hello.txt'

# Generated at 2022-06-24 06:48:24.938718
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm HoLy')
    assert get_new_command(command) == 'git rm -r HoLy'

# Generated at 2022-06-24 06:48:26.569626
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foopackage')) == 'git rm -r foopackage'

# Generated at 2022-06-24 06:48:31.836512
# Unit test for function match
def test_match():
    assert match(Command('git rm foo bar', '', '', 1, 2))
    assert match(Command('git rm my_file.txt', '', '', 1, 2))
    assert not match(Command('git stash', '', '', 1, 2))
    assert not match(Command('git commit', '', '', 1, 2))
    assert not match(Command('git something else', '', '', 1, 2))


# Generated at 2022-06-24 06:48:34.921534
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', '', '', 2))
    assert match(Command('git rm -r', '', '', 2)) is False
    assert match(Command('git rm -r', '', '', 2)) is False

# Generated at 2022-06-24 06:48:37.972615
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_recursive import get_new_command
    assert get_new_command(Command('rm test-file', 'fatal: not removing \'src/test-file\', recursively without -r')) == u'git rm -r test-file'


# Generated at 2022-06-24 06:48:40.976784
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test')
    assert 'git rm -r test' == get_new_command(command)



# Generated at 2022-06-24 06:48:46.357018
# Unit test for function match
def test_match():
    assert match(Command('git rm *.pyc', 'fatal: not removing \'myfile.pyc\''
                         ' recursively without -r', '', 1, ''))
    assert match(Command('git rm *.*', 'fatal: not removing \'myfile.pyc\''
                         ' recursively without -r', '', 1, ''))
    assert not match(Command('git rm *.pyc', '', '', 1, ''))



# Generated at 2022-06-24 06:48:47.473346
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm .') == 'git rm -r .'

# Generated at 2022-06-24 06:48:51.748199
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf something',
                          output='fatal: not removing \'something\' recursively without -r'))
    assert not match(Command('git rm something',
                             output='fatal: not removing \'something\' recursively without -r'))


# Generated at 2022-06-24 06:48:55.975201
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt', ' file.txt -r'))
    assert not match(Command('git rm file.txt', ''))


# Generated at 2022-06-24 06:48:58.155816
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test')
    new_command = get_new_command(command)
    assert(new_command == 'git rm -r test')

# Generated at 2022-06-24 06:48:59.157204
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file.txt')
    assert get_new_command(command) == 'git rm file.txt'

# Generated at 2022-06-24 06:49:02.601419
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(u'rm file', u'fatal: not removing \'file\': You need to resolve your current index first\n')
    assert get_new_command(command) == u'git rm -r file'


enabled_by_default = True

# Generated at 2022-06-24 06:49:06.774450
# Unit test for function get_new_command
def test_get_new_command():
    """Test case for function get_new_command"""
    command = Command("git rm -r test_data", "fatal: not removing 'test_data' recursively without -r")

    assert(get_new_command(command) == 'git rm -r -r test_data')

# Generated at 2022-06-24 06:49:12.361692
# Unit test for function match
def test_match():
    assert match(Command(' rm test/fake_file', '', '', '', ''))
    assert match(Command(' rm test/fake_file ', '', '', '', ''))
    assert match(Command(' git rm test/fake_file', '', '', '', ''))
    assert match(Command(' git rm test/fake_file ', '', '', '', ''))
    assert not match(Command('rm test/fake_file', '', '', '', ''))
    assert not match(Command(' rm test/fake_file', '', '', '', ''))
    assert not match(Command('', '', '', '', ''))


# Generated at 2022-06-24 06:49:16.543573
# Unit test for function match
def test_match():
    command = Command('git rm foo')
    assert match(command)
    command = Command('git rm -f foo')
    assert match(command)
    command = Command('rm foo')
    assert not match(command)
    command = Command('git foo')
    assert not match(command)
    command = Command('git rm -r foo')
    assert not match(command)


# Generated at 2022-06-24 06:49:20.167479
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git rm -rf a')) == 'git rm -r -rf a'
    assert get_new_command(Command('git rm -f a')) == 'git rm -r -f a'


# Generated at 2022-06-24 06:49:23.147599
# Unit test for function match
def test_match():
    assert match(Command(script='git branch -D foo',
            output="fatal: not removing 'foo' recursively without -r"))
    assert not match(Command(script='git branch -D foo',
            output="fatal: not removing 'foo' recursively"))


# Generated at 2022-06-24 06:49:25.774238
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo',
                                   'fatal: not removing \'foo\' recursively without -r')) == 'git rm -r foo'

# Generated at 2022-06-24 06:49:28.328373
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r A' == Command('git rm A', '').script
    assert 'git rm -r A B' == Command('git rm A B', '').script
    assert 'git rm -r A' == Command('git rm A', '').script

# Generated at 2022-06-24 06:49:32.037868
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file1', 
        'fatal: not removing \'file1\' recursively without -r\n'))
    assert not match(Command('git rm file1',
        'fatal: not removing \'file1\' recursively without -r\n'))


# Generated at 2022-06-24 06:49:41.901761
# Unit test for function match
def test_match():
    assert match(Command('git branch branch1 branch2 branch3 branch4 branch5', ''))
    # pylint: disable=line-too-long
    assert not match(Command('git branch branch1 branch2 branch3 branch4 branch5', 'error: branch \'branch1 branch2 branch3 branch4 branch5\' does not exist'))
    assert match(Command('git rm f1 f2 f3 f4 f5', 'error: pathspec \'f1 f2 f3 f4 f5\' did not match any file(s) known to git.'))
    assert not match(Command('git rm f1 f2 f3 f4 f5', ''))
    assert match(Command('git rm -r f1 f2 f3 f4 f5', 'fatal: not removing \'f1 f2 f3 f4 f5\' recursively without -r'))

# Generated at 2022-06-24 06:49:42.796659
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git rm -r dir'
    result = get_new_command(Command(command, ''))
    assert result == 'git rm -r -r dir'

# Generated at 2022-06-24 06:49:45.428879
# Unit test for function match
def test_match():
    assert(match(Command(script='git rm -r --cached lala', output='fatal: not removing \'lala\' recursively without -r')) == True)
    assert(match(Command(script='git rm -r --cached', output='fatal: not removing ')) == False)    
    

# Generated at 2022-06-24 06:49:50.853513
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2', stderr="fatal: not removing 'file2' recursively without -r"))
    assert not match(Command('git rm file1 file2', stderr="fatal: not removing 'file2' recursively without -r",
                     stdout="Deleted file2"))
    assert not match(Command('git rm file1 file2'))


# Generated at 2022-06-24 06:49:54.746665
# Unit test for function get_new_command
def test_get_new_command():
	command = Command("git rm -r --cached some/dir")
	expected_output = "git rm -r -r --cached some/dir"
	assert get_new_command(command) == expected_output

# Generated at 2022-06-24 06:49:56.213491
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -r test") == "git rm -r -r test"

# Generated at 2022-06-24 06:49:58.516073
# Unit test for function get_new_command
def test_get_new_command():
    # Unit test for command_parts
    assert get_new_command(Command('rm file1 file2', '')) == 'git rm -r file1 file2'

# Generated at 2022-06-24 06:50:03.841516
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script=u'git rm dsdsd -f',
                                   output=u"fatal: not removing 'dsdsd' recursively without -r")) == u'git rm -r dsdsd -f'
    assert get_new_command(Command(script=u'git rm dsdsd',
                                   output=u"fatal: not removing 'dsdsd' recursively without -r")) == u'git rm -r dsdsd'

# Generated at 2022-06-24 06:50:07.440751
# Unit test for function match
def test_match():
    assert match(Command('git branch master', 'error: pathspec', ''))
    assert match(Command('git branch master', 'error: pathspec', ''))
    assert match(Command('git branch master', 'error:branch', ''))
    assert not match(Command('git branch master', 'error: pathspec', '', '', '', ''))


# Generated at 2022-06-24 06:50:12.974204
# Unit test for function match
def test_match():
    assert match(Command('git rm test',
                         'fatal: not removing "test" recursively without -r',
                         '/usr/bin/git rm test'))

    assert not match(Command('git rm test',
                             'fatal: not removing "test" recursively without -r',
                             '/usr/bin/git rmdir test'))


# Generated at 2022-06-24 06:50:15.954502
# Unit test for function match
def test_match():
    assert match(Command('git rm ', 'fatal: not removing \'test-repository/test_bash.sh\' recursively without -r'))


# Generated at 2022-06-24 06:50:18.517953
# Unit test for function match
def test_match():
    command = Command(script='git rm -rf')
    assert match(command)
    assert not match(Command(script='not git rm -rf'))



# Generated at 2022-06-24 06:50:21.946271
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm directory', '')) == u'git rm -r directory'
    assert get_new_command(Command('git rm -rf directory', '')) == u'git rm -rf -r directory'

# Generated at 2022-06-24 06:50:25.523093
# Unit test for function match
def test_match():
    assert match(Command('git rm test', 
                         "fatal: not removing 'test' recursively without -r",
                         ''))
    assert not match(Command('git rm test', ''))

# Generated at 2022-06-24 06:50:27.636765
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r aFile.txt')
    assert get_new_command(command) == 'git rm -r -r aFile.txt'

# Generated at 2022-06-24 06:50:30.152828
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         'fatal: not removing \'foo\' recursively without -r\n', '', 0, None))



# Generated at 2022-06-24 06:50:33.074265
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf /some/folder','')) == 'git rm -rf -r /some/folder'

# Generated at 2022-06-24 06:50:35.591208
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command(command.Command("git rm -rf /tmp/folder", "/tmp/folder/: not removing 'folder' recursively without -r", None)))

# Generated at 2022-06-24 06:50:44.550426
# Unit test for function match
def test_match():
    assert match(Command(script='git rm test.txt', output='fatal: not removing \'test.txt\' recursively without -r')), 'Should return true'
    assert not match(Command(script='git rm -r test.txt', output='fatal: not removing \'test.txt\' recursively without -r')), 'Should return false'
    assert match(Command(script='git rm test.txt', output='fatal: not removing \'test.txt\' recursively without -r\nfatal: not removing \'test.txt\' recursively without -r')), 'Should return true'
    assert not match(Command(script='echo "test"', output='fatal: not removing \'test.txt\' recursively without -r')), 'Should return false'



# Generated at 2022-06-24 06:50:46.447627
# Unit test for function get_new_command
def test_get_new_command():
    assert('git rm -r *' == get_new_command('git rm *'))
    assert('rm -r *' == get_new_command('rm *'))

# Generated at 2022-06-24 06:50:47.427930
# Unit test for function match
def test_match():
    assert match(Command('rm -rf'))


# Generated at 2022-06-24 06:50:48.700547
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm file1 file2") == "git rm -r file1 file2"

# Generated at 2022-06-24 06:50:52.263373
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'git -r status'
    assert get_new_command('git rm') == 'git -r rm'
    assert get_new_command('git rm file') == 'git -r rm file'
    assert get_new_command('git rm file folder') == 'git -r rm file folder'
    assert get_new_command('git rm file folder -n') == 'git -r rm file folder -n'

# Generated at 2022-06-24 06:50:54.464853
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm -f *', '', '')) == 'git rm -rf *'

# Generated at 2022-06-24 06:50:57.865396
# Unit test for function match
def test_match():
    assert match(Command('rm f.txt', "fatal: not removing 'f.txt' recursively without -r"))
    assert not match(Command('rm f.txt', "fatal: not removing 'f.txt'"))


# Generated at 2022-06-24 06:50:59.299960
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm yodogg') == 'git rm -r yodogg'

# Generated at 2022-06-24 06:51:02.512241
# Unit test for function get_new_command
def test_get_new_command():
    cmd = 'git rm hello.txt'
    out = 'fatal: not removing \'hello.txt\' recursively without -r'
    assert 'rm -r hello.txt' in get_new_command(Command(cmd, out))

# Generated at 2022-06-24 06:51:03.700850
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf bla',
                         "fatal: not removing 'bla' recursively without -r"))


# Generated at 2022-06-24 06:51:07.482977
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.txt',
               'fatal: not removing \'hello.txt\' recursively without -r'
               ))
    assert match(Command('git rm -r hello.txt',
               'fatal: not removing \'hello.txt\' recursively without -r'
               )) is False


# Generated at 2022-06-24 06:51:11.261516
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm x',
                      'fatal: not removing \'x\' recursively without -r\n',
                      '')
    assert get_new_command(command) == 'git rm -r x'

# Generated at 2022-06-24 06:51:13.833934
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('''git rm file
fatal: not removing 'file' recursively without -r
''') == 'git rm -r file'


# Generated at 2022-06-24 06:51:17.502906
# Unit test for function match
def test_match():
    assert match(u"git rm dirname")
    assert match(u"git rm dirname/")
    assert not match(u"git rm --cached file")
    assert not match(u"git rm dirname/")


# Generated at 2022-06-24 06:51:20.579810
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', 'rm', '-r', 'foo', 'bar', 'baz']
    command.script_parts = ['git', 'rm', 'foo', 'bar', 'baz']
    assert get_new_command(command) == u' '.join(command_parts)

# Generated at 2022-06-24 06:51:25.893123
# Unit test for function match
def test_match():
    assert match(Command('git rm',
                         'fatal: not removing \'test/test_git.py\' recursively without -r'))

    assert not match(Command('git rm test/test_git.py',
                             'fatal: not removing \'test/test_git.py\' recursively without -r'))

    assert not match(Command('git rm', ''))



# Generated at 2022-06-24 06:51:31.976670
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file_path', '', 'fatal: not removing', ''))
    assert match(Command('git rm -r file_path', '', 'fatal: not removing', ''))
    assert not match(Command('git rm -r file_path', '', '', ''))
    assert not match(Command('git rm -r file_path', '', '', ''))



# Generated at 2022-06-24 06:51:37.031594
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm *.txt', 'fatal: not removing "*.txt" recursively without -r', '', '', '')) == 'git rm -r *.txt'
    assert get_new_command(Command('git rm *.txt', 'fatal: not removing "*.txt" recursively without -r', '', '', '')) == 'git rm -r *.txt'

# Generated at 2022-06-24 06:51:40.196802
# Unit test for function match
def test_match():
    assert match(Command("git rm lala",output=''))
    assert not match(Command("git rm -r lala",output=''))


# Generated at 2022-06-24 06:51:48.805637
# Unit test for function match
def test_match():
    assert(match(Command(script='git rm foo',
                         output='fatal: not removing \'foo\' recursively without -r')) == True)
    assert(match(Command(script='git rm foo',
                         output='fatal: not removing \'foo\' recursively without -r\n')) == True)
    assert(match(Command(script='git rm foo',
                         output='fatal: not removing \'foo\' recursively without -r\nfoo bar')) == True)
    assert(match(Command(script='git rm foo',
                         output='fatal: not removing \'foo\' recursively without -r\nfatal: not removing \'foo\' recursively without -r\n')) == True)


# Generated at 2022-06-24 06:51:51.852604
# Unit test for function match
def test_match():
    assert match(Command('git rm folder/file.txt',
                         'fatal: not removing \'folder/file.txt\' recursively without -r'))



# Generated at 2022-06-24 06:51:55.323064
# Unit test for function get_new_command
def test_get_new_command():
    output = u'''
fatal: not removing 'sites/default/files/js/autocomplete.js' recursively without -r
'''
    command = Command(
        'rm sites/default/files/js/autocomplete.js',
        output)

# Generated at 2022-06-24 06:52:01.801707
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm svn/trunk')) == 'git rm -r svn/trunk'
    assert get_new_command(Command('git status', 'fatal: not removing \'svn/trunk\' recursively without -r\n')) == 'git status'
    assert get_new_command(Command('git rm svn/trunk', 'fatal: not removing \'svn/trunk\' recursively without -r\n')) == 'git rm -r svn/trunk'

# Generated at 2022-06-24 06:52:04.481609
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_recursive_rm import get_new_command
    assert get_new_command('git rm test') == 'git rm -r test'


enabled_by_default = True

# Generated at 2022-06-24 06:52:08.069726
# Unit test for function match
def test_match():
    assert match(Command('git rm -r .idea',
                         'fatal: not removing '
                         '\'.idea\' recursively without -r', '', 1, ''))
    assert not match(Command('git rm', '', '', 1, ''))


# Generated at 2022-06-24 06:52:11.223154
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo.py')
    expected = 'git rm -r foo.py'
    assert get_new_command(command) == expected

# Generated at 2022-06-24 06:52:17.513437
# Unit test for function match
def test_match():
    assert match(Command('git rm file1', '', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git rm file1', '', ''))
    assert not match(Command('git commit', '', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('rm file1', '', 'fatal: not removing \'file1\' recursively without -r'))


# Generated at 2022-06-24 06:52:18.989915
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file')
    assert u'git rm -r file' == get_new_command(command)

# Generated at 2022-06-24 06:52:22.890295
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm test',
                                   output="fatal: not removing 'test.zip' recursively without -r")) == u'git rm -r test'

# Generated at 2022-06-24 06:52:26.148290
# Unit test for function get_new_command
def test_get_new_command():
    default_kwargs = { 'terminal_size': (80, 24), 'env': {}, 'is_a_tty': True }

# Generated at 2022-06-24 06:52:29.159826
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm hello', output='fatal: not removing \'<filename>\' recursively without -r')
    new_command = get_new_command(command)
    assert u'git rm -r hello' == new_command

# Generated at 2022-06-24 06:52:30.892714
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo')) == 'git rm -r foo'

# Generated at 2022-06-24 06:52:34.815184
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = u"git rm file1 file2",
                      output = u"fatal: not removing 'file2' recursively without -r")
    assert get_new_command(command) == u"git rm -r file1 file2"


# Generated at 2022-06-24 06:52:39.170431
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         stderr='fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file',
                         stderr='fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-24 06:52:44.948120
# Unit test for function get_new_command
def test_get_new_command():
    script = Command("git rm -rf file/path/", """fatal: not removing 'file/path/' recursively without -r
    """)
    assert get_new_command(script) == 'git rm -r -rf file/path/'
    script = Command("git rm file/path", """fatal: not removing 'file/path' recursively without -r
    """)
    assert get_new_command(script) == 'git rm -r file/path'

# Generated at 2022-06-24 06:52:46.607133
# Unit test for function match
def test_match():
    assert match(Command('git rm a'))
    assert not match(Command('git config --global user.name'))

# Generated at 2022-06-24 06:52:50.863408
# Unit test for function get_new_command
def test_get_new_command():
    command = Mock(script='git rm file.txt',
                   script_parts=['git', 'rm', 'file.txt'],
                   output='fatal: not removing \'file.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file.txt'

# Generated at 2022-06-24 06:52:53.752712
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r test_file' == get_new_command('git rm test_file')

# Generated at 2022-06-24 06:52:56.594140
# Unit test for function match
def test_match():
    command = Command('git remote rm test1', 'fatal: not removing \'test1\' recursively without -r')
    assert match(command)

# Generated at 2022-06-24 06:52:58.633002
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f main.js', 'fatal: not removing ')) == 'git -r rm -f main.js'

# Generated at 2022-06-24 06:53:01.627703
# Unit test for function get_new_command
def test_get_new_command():
    c = Command(script='git rm asd/asd', output='fatal: not removing \'asd/asd\' recursively without -r')
    assert get_new_command(c) == 'git rm -r asd/asd'

# Generated at 2022-06-24 06:53:04.608529
# Unit test for function match
def test_match():
    assert match(Command('git rm filename',
                         'fatal: not removing \'filename\' recursively without -r\n'))
    assert not match(Command('git status', ''))
    assert not match(Command('git commit', ''))


# Generated at 2022-06-24 06:53:09.691485
# Unit test for function match
def test_match():
    command = Command(script='git rm file.txt',
                      stderr='''fatal: not removing 'file.txt' recursively without -r
''')
    assert match(command)
    command = Command(script='git rm file.txt',
                      stderr='''fatal: not removing 'file.txt' recursively without -r
''')
    assert not match(command)

# Generated at 2022-06-24 06:53:13.485427
# Unit test for function match
def test_match():
    assert(match(Command(script='git rm file_1.txt',
                        output="fatal: not removing 'file_1.txt' recursively without -r"))
           == True)


# Generated at 2022-06-24 06:53:16.212211
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm file',
                                   'fatal: not removing "file" recursively without -r'
                                   '\n',
                                   path = '/home/user/project')) \
            == 'git rm -r file'

# Generated at 2022-06-24 06:53:18.454359
# Unit test for function match
def test_match():
  assert match(Command(script="git rm -r /*", output="fatal: not removing '/*' recursively without -r"))


# Generated at 2022-06-24 06:53:23.577146
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm dir1/dir2/dir3",
                      "fatal: not removing 'dir1/dir2/dir3' recursively without -r\nerror: 'dir1/dir2/dir3' did not match any files")
    assert get_new_command(command) == "git rm -r dir1/dir2/dir3"

# Generated at 2022-06-24 06:53:27.274101
# Unit test for function match
def test_match():
    assert match(Command('git rm -r .', 'fatal: not removing \'.\' recursively without -r'))
    assert match(Command('git rm .', 'fatal: not removing \'.\' recursively without -r'))
    assert not match(Command('git rm', 'fatal: not removing \'.\' recursively without -r'))


# Generated at 2022-06-24 06:53:33.038546
# Unit test for function match
def test_match():
    assert match(Command('rm /home/vhoang/test',
        'fatal: not removing \'/home/vhoang/test\' recursively without -r')) == True
    assert match(Command('rm -r /home/vhoang/test',
        'fatal: not removing \'/home/vhoang/test\' recursively without -r')) == False


# Generated at 2022-06-24 06:53:36.961294
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'
    assert get_new_command('git rm -f file') == 'git rm -f -r file'
    assert get_new_command('git rm -f file1 file2') == 'git rm -f -r file1 file2'

# Generated at 2022-06-24 06:53:47.928944
# Unit test for function get_new_command
def test_get_new_command():

    # test 1
    input_script = u'git rm .idea/workspace.xml'

# Generated at 2022-06-24 06:53:55.445558
# Unit test for function match
def test_match():
    assert match(Command(' git rm -rf .', stderr='fatal: not removing '
                         '. recursively without -r'))
    assert not match(Command(' git rm -rf .', stderr='fatal: not removing '
                             '. recursively without -r',))
    assert not match(Command(' git rm -rf .', stderr='fatal: not removing '
                             '. recursively without -r',))
    assert not match(Command(' git rm -rf .', stderr='fatal: not removing '
                             '. recursively without -r',))


# Generated at 2022-06-24 06:53:59.413507
# Unit test for function get_new_command
def test_get_new_command():
    check_match = "fatal: not removing '\x1b[31;1mconfig/application.yml\x1b[0m' recursively without -r"
    assert get_new_command(Command('rm config/application.yml', check_match)) == 'git rm -r config/application.yml'



# Generated at 2022-06-24 06:54:03.745024
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(
        Command('rm -f file.txt file2.txt',
                'fatal: not removing \'file.txt\' recursively without -r\n',
                '')) == 'git rm -f -r file.txt file2.txt'


# Generated at 2022-06-24 06:54:08.211530
# Unit test for function match
def test_match():
    assert match(
        Command('rm README.md', 'fatal: not removing \'README.md\' recursively without -r\n')
    )
    assert not match(
        Command('rm foo', '')
    )
    assert match(
        Command('git rm README.md', 'fatal: not removing \'README.md\' recursively without -r\n')
    )
    assert not match(
        Command('git rm foo', '')
    )


# Generated at 2022-06-24 06:54:12.805386
# Unit test for function get_new_command
def test_get_new_command():
    # Ensure that this rule can handle spaces inside the path as well
    command = Command("git rm -f '/some folder with spaces/file'")
    assert get_new_command(command) == "git rm -rf '/some folder with spaces/file'"

    # Ensure that this rule can handle spaces inside escaped paths as well
    command = Command("git rm -f '/some\\ folder\\ with\\ spaces/file'")
    assert get_new_command(command) == "git rm -rf '/some\\ folder\\ with\\ spaces/file'"

# Generated at 2022-06-24 06:54:22.807209
# Unit test for function match

# Generated at 2022-06-24 06:54:27.131960
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', 'add', '-A', 'git', 'commit', '-m', 'test', 'git', 'push']
    index = command_parts.index('commit') + 1
    assert(get_new_command(Command('git commit', command_parts)) == 'git add -A git commit -m "test" git push')

# Generated at 2022-06-24 06:54:30.610455
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git rm dir'
    output = 'fatal: not removing \'dir\' recursively without -r'
    assert get_new_command(script, output) == script + ' -r'

# Generated at 2022-06-24 06:54:33.481627
# Unit test for function get_new_command
def test_get_new_command():
    command = type('command', (object,), {'script_parts': ['git', 'rm', 'file'], 'output': 'fatal: not removing \'file\' recursively without -r'})
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-24 06:54:36.258996
# Unit test for function match
def test_match():
	command = type('obj', (object,), {'script': 'git rm file.txt', 'output': "fatal: not removing 'file.txt' recursively without -r"})
	assert match(command)


# Generated at 2022-06-24 06:54:43.438843
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm unknown.txt',
                      '')
    new_command = get_new_command(command)
    assert u'git rm -r unknown.txt' == new_command
    command = Command('git rm -f unknown.txt',
                      '')
    new_command = get_new_command(command)
    assert u'git rm -rf unknown.txt' == new_command
    command = Command('git -f rm unknown.txt',
                      '')
    new_command = get_new_command(command)
    assert u'git -f rm -r unknown.txt' == new_command

# Generated at 2022-06-24 06:54:48.540364
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_not_removing_recursively import get_new_command
    command = "git rm -fq test/file"
    new_command = get_new_command(command, None)
    assert new_command == "git rm -fq -r test/file"

# Generated at 2022-06-24 06:54:51.212216
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm test/')) == 'git rm -r test/'


# Generated at 2022-06-24 06:54:55.032625
# Unit test for function match
def test_match():
    command_1 = Command('rm -r yy',
                        'fatal: not removing \'yy\' recursively without -r\n')
    command_2 = Command('ls',
                        'fatal: not removing \'yy\' recursively without -r\n')
    command_3 = Command('git rm -r yy',
                        'fatal: not removing \'yy\' recursively without -r\n')

    assert not match(command_1)
    assert not match(command_2)
    assert match(command_3)



# Generated at 2022-06-24 06:54:58.268795
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm foo.txt',
        output="fatal: not removing 'foo.txt' recursively without -r")) == 'git rm -r foo.txt'

# Generated at 2022-06-24 06:55:04.439571
# Unit test for function match
def test_match():
    # Test with command that contains rm and has errors
    command = Command('git rm -r test',
        "fatal: not removing 'test/file2' recursively without -r\n", '')
    assert match(command)

    # Test with rm command that has no errors
    command = Command('git rm test', '', '')
    assert not match(command)

    # Test with a non-git command
    command = Command('rm test', '', '')
    assert not match(command)



# Generated at 2022-06-24 06:55:06.164278
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r a_directory', '', '', '', '')) == 'git rm -r -r a_directory'

# Generated at 2022-06-24 06:55:07.841192
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm . -d')
    assert get_new_command(command) == 'git rm -r . -d'

# Generated at 2022-06-24 06:55:12.471306
# Unit test for function match
def test_match():
    assert match(Command('git rm foo'))
    assert match(Command('git rm -rf foo'))
    assert match(Command('git rm -r foo'))
    assert not match(Command('git rm --force foo'))
    assert not match(Command('git rm foo', stderr='bar'))
    assert not match(Command('git rm bar', stderr='fatal: not removing'))


# Generated at 2022-06-24 06:55:15.903206
# Unit test for function match
def test_match():
	# Test if match gives correct output
	assert git_support(match)(Command('git rm -r'))
	# Test if the function doesn't match in wrong cases
	assert not git_support(match)(Command('git check'))

# Test function get_new_command

# Generated at 2022-06-24 06:55:20.085852
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r file' == get_new_command(u'git rm file')
    assert u'git rm -r path/to/file' == get_new_command(u'git rm path/to/file')

# Generated at 2022-06-24 06:55:27.980212
# Unit test for function match
def test_match():
    assert match(Command(' git rm src', '', ''))
    assert not match(Command('git rm src', '', ''))
    assert match(Command(' git rm -r src', '', ''))
    assert not match(Command('git rm -r src', '', ''))
    assert not match(Command(' git rm src', '', 'fatal: not removing '))
    assert not match(Command(' git rm src', '', ' recursively without -r'))
    assert not match(Command(' git rm src', '', 'fatal: not removing '
                             'recursively without -r'))


# Generated at 2022-06-24 06:55:32.791351
# Unit test for function match
def test_match():
    command_output = '''fatal: not removing 'test-repository/.git/refs/remotes/origin/master' recursively without -r
'''
    assert match(Command('rm -rf test-repository', '', command_output))
    assert not match(Command('rm -rf test-repository', '', ''))
    assert not match(Command('git commit', '', command_output))



# Generated at 2022-06-24 06:55:38.311937
# Unit test for function match
def test_match():
    assert match(Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r'))
    assert match(Command('git rm test.txt', '')) is False
    assert match(Command('git rm -r test.txt', 'fatal: not removing \'test.txt\' recursively without -r')) is False


# Generated at 2022-06-24 06:55:41.794887
# Unit test for function get_new_command
def test_get_new_command():
    command = "git rm --cached -r -f /path/to/file"
    new_command = "git rm -r --cached -f /path/to/file"
    assert (get_new_command(Command(command, "", "")) == new_command)

# Generated at 2022-06-24 06:55:44.173270
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r file' == get_new_command(Command(script=u'git rm file', output=u"fatal: not removing 'file' recursively without -r\nDid you mean 'rm'?"))

# Generated at 2022-06-24 06:55:46.317987
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm foo bar')) == 'git rm -r foo bar')

# Generated at 2022-06-24 06:55:54.871242
# Unit test for function match
def test_match():
    assert match(Command(script='git rm file1 file2', output='git: \'rm\' is not a git command. See \'git --help\'.'))
    assert match(Command(script='git rm file1 file2', output="fatal: not removing 'file1' recursively without -r"))
    assert match(Command(script='git rm  file1 file2', output="fatal: not removing 'file1' recursively without -r"))
    assert not match(Command(script='git rm  file1 file2', output="fatal: not removing 'file1' recursively without -r",
                             stderr='fatal: not removing \'file1\' recursively without -r'))



# Generated at 2022-06-24 06:56:00.204378
# Unit test for function match
def test_match():
    assert match(Command('git status', '', 'fatal: not removing \'.gitignore\' recursively without -r'))
    assert not match(Command('git status', '', 'fatal: not removing \'.gitignore\' recursively without -r', ''))
    assert not match(Command('ls status', '', 'fatal: not removing \'.gitignore\' recursively without -r'))
    assert not match(Command('git status', '', 'fatal: not removing \'.gitignore\''))


# Generated at 2022-06-24 06:56:05.982824
# Unit test for function match
def test_match():
    assert match(Command(script="git rm test.txt",
                         output="fatal: not removing 'test.txt' recursively without -r"))
    assert not match(Command(script="git rm -r test.txt",
                         output="fatal: not removing 'test.txt' recursively without -r"))
    assert not match(Command(script="git rm test.txt",
                         output="test: command not found"))
    assert not match(Command(script="git test.txt",
                         output="fatal: not removing 'test.txt' recursively without -r"))


# Generated at 2022-06-24 06:56:09.997685
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf *'))
    assert match(Command('git rm *'))
    assert not match(Command('git config --global user.name'))
    assert not match(Command('rm -rf *'))
