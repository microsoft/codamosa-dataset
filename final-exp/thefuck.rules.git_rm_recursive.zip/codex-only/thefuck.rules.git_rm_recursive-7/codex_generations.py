

# Generated at 2022-06-24 06:46:15.688871
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command(script = "git rm 'test'",
                           stdout =
        """
fatal: not removing 'test' recursively without -r
""")
    assert git_rm_r.get_new_command(test_command) == u'git rm -r \'test\''

# Generated at 2022-06-24 06:46:18.344964
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == u'git rm -r file'
    assert get_new_command('git rm file1 file2 file3') == u'git rm -r file1 file2 file3'


# Generated at 2022-06-24 06:46:21.517921
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(
        Command(script='git rm file', output='fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'
    assert get_new_command(
        Command(script='git rm -rf from to', output='fatal: not removing \'from\' recursively without -r')) == 'git rm -rf from to'

# Generated at 2022-06-24 06:46:24.755674
# Unit test for function match
def test_match():
    assert match(Command('test', 'fatal: not removing \'src/package.json\' recursively without -r'))
    assert not match(Command('test', ''))
    assert not match(Command('test', 'fatal: not removing \'src/package.json\' recursively with -r'))


# Generated at 2022-06-24 06:46:30.703887
# Unit test for function match
def test_match():
    assert match(Command('git rm ', 'fatal: not removing \'README.md\' recursively without -r'))
    assert not match(Command('sudo git rm ', 'fatal: not removing \'README.md\' recursively without -r'))
    assert not match(Command('git rm', 'fatal: not removing \'README.md\' recursively without -r'))


# Generated at 2022-06-24 06:46:34.275223
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r a/b/c.txt', '', '', '')) == 'git rm -r a/b/c.txt'
    assert get_new_command(Command('rm -r', '', '', '')) == 'rm -r'

# Generated at 2022-06-24 06:46:36.782763
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -rf /root', '')
    fixed = get_new_command(command)
    assert fixed == "git rm -rf -r /root"

# Generated at 2022-06-24 06:46:39.271914
# Unit test for function get_new_command
def test_get_new_command():
    """
    Test if the correct command is returned for git rm

    """
    command = Command('git rm')
    assert get_new_command(command) == 'git rm -r'

# Generated at 2022-06-24 06:46:43.879990
# Unit test for function match
def test_match():
    command = Command(' rm test.txt', 'RM test.txt', 'fatal: not removing \'test.txt\' recursively without -r')
    assert match(command)

    command = Command(' rm test.txt', 'RM test.txt', 'fatal: not removing \'test.txt\' recursively with -r')
    assert not match(command)


# Generated at 2022-06-24 06:46:45.615716
# Unit test for function match
def test_match():
    assert (match(Command(' rm file',
                         'fatal: not removing \'file\' recursively without -r',
                         '')))

# Generated at 2022-06-24 06:46:47.022575
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm directory")) == "git rm -r directory"

# Generated at 2022-06-24 06:46:49.392076
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command(script = "git rm files", output = "fatal: not removing 'files' recursively without -r")) == "git rm -r files"

# Generated at 2022-06-24 06:46:53.637224
# Unit test for function match
def test_match():
    assert match(Command('git rm -f file',
                         stderr='error: not removing \'file\' recursively without -r',
                         ))
    assert not match(Command('git rm -f',
                         stderr='error: not removing \'file\' recursively without -r',
                         ))


# Generated at 2022-06-24 06:46:59.490138
# Unit test for function get_new_command
def test_get_new_command():
   # run command in test directory
   command_test=Command("git rm -r dir1/dir2", "fatal: not removing 'dir1/dir2' recursively without -r\nDid you mean this?\n  rm 'dir1/dir2'")
   # check if command has been corrected
   assert "git rm -r dir1/dir2" == get_new_command(command_test)

# Generated at 2022-06-24 06:47:01.292454
# Unit test for function match
def test_match():
    assert match(Command('git rm file'))
    assert match(Command('git rm -rf file'))


# Generated at 2022-06-24 06:47:08.310046
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test', 'fatal: not removing \'test\' recursively without -r'))== 'git rm -r test'
    assert get_new_command(Command('git rm -r test1 test2', 'fatal: not removing \'test\' recursively without -r'))== 'git rm -r -r test1 test2'
    assert get_new_command(Command('git rm -f test1', 'fatal: not removing \'test\' recursively without -r'))== 'git rm -f -r test1'

# Generated at 2022-06-24 06:47:09.581790
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm a',
                                   output="fatal: not removing 'a' recursively without -r")) == "git rm -r a"

# Generated at 2022-06-24 06:47:12.884443
# Unit test for function match
def test_match():
    assert not match(Command('git foo',
                             stderr='usage: git rm [options]'))

    assert match(Command('git rm foo',
                         stderr='fatal: not removing \'foo\' recursively without -r'))

# Generated at 2022-06-24 06:47:14.223252
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r dir', '', '')) == 'git rm dir -r'

# Generated at 2022-06-24 06:47:18.771979
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf test'))
    assert match(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm -rf test', 'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm -rf test', 'fatal: not removing \'test\' recursively without -r', stderr='something'))
    assert not match(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r', stderr='fatal: not removing \'test\' recursively without -r'))

# Generated at 2022-06-24 06:47:22.244398
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('./my_script.sh', 'rm -v /foo')
    command.output = "fatal: not removing 'foo' recursively without -r"
    assert get_new_command(command) == './my_script.sh rm -v -r /foo'

# Generated at 2022-06-24 06:47:26.095355
# Unit test for function match
def test_match():
    assert not match(Command('git sth'))
    assert not match(Command('git rm f'))
    assert match(Command('git rm f', output=u'fatal: not removing \'"f"\' recursively without -r\n'))


# Generated at 2022-06-24 06:47:28.700017
# Unit test for function match
def test_match():
    assert match(Command('git st', '')) == False
    assert match(Command('git rm test', "fatal: not removing 'test' recursively without -r")) == True

# Generated at 2022-06-24 06:47:36.176061
# Unit test for function match
def test_match():
    # Testing for invalid command with "fatal: not removing '" and "' recursively without -r" in the output
    assert match(Command('git rm $file',
                         'fatal: not removing ' + "'" + '$file' + "'" + ' recursively without -r',
                         '', 1))
    # Testing for invalid command with "fatal: not removing '" in the output but "' recursively without -r" in the output
    assert not match(Command('git rm $file',
                         'fatal: not removing ' + "'" + '$file' + "'",
                         '', 1))



# Generated at 2022-06-24 06:47:44.652544
# Unit test for function match
def test_match():
    assert match(Command('git branch -h', 'err'))
    assert match(Command('git branch -h', 'err: fatal: not removing '))
    assert match(Command('git branch -h', 'err: fatal: not removing \'master\''))
    assert match(Command('git branch -h', 'err: fatal: not removing \'master\' recursively without -r'))
    assert not match(Command('git branch -h', 'err: fatal: not removing \'master\' without -r'))
    assert not match(Command('git branch -h', 'err: not removing \'master\' recursively without -r'))


# Generated at 2022-06-24 06:47:47.509457
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f a')
    assert get_new_command(command) == 'git rm -f -r a'

    command = Command('git rm -f a b')
    assert get_new_command(command) == 'git rm -f -r a b'

# Generated at 2022-06-24 06:47:52.418859
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo',
                      'fatal: not removing \'foo\' recursively without -r\n',
                      '')
    assert_equals(get_new_command(command), 'git rm -r foo')

# Generated at 2022-06-24 06:47:54.072898
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm a')) == u'git rm -r a'

# Generated at 2022-06-24 06:47:56.974872
# Unit test for function get_new_command
def test_get_new_command():
    test_value = "git rm myfile"
    assert get_new_command(Command(test_value, "fatal: not removing 'myfile' recursively without -r")) == "git rm -r myfile"


# Generated at 2022-06-24 06:47:58.917644
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm dir', '/bin/rm: cannot remove \'dir\': Is a directory', '')) == 'git rm -r dir'


# Generated at 2022-06-24 06:48:03.022918
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert (get_new_command(Command('rm file', '', 'fatal: not removing \'file\' recursively without -r')) ==
            "git rm -r file")

# Generated at 2022-06-24 06:48:07.868875
# Unit test for function match
def test_match():
    assert match(Command('git rm a',
                         'fatal: not removing \'a\' recursively without -r'))
    assert not match(Command('git rm -r a', ''))
    assert not match(Command('git rm a', ''))
    assert not match(Command('git rm a',
                             'fatal: not removing \'a\' recursively without -r'))



# Generated at 2022-06-24 06:48:12.725196
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f /tmp/file1 /tmp/file2', 
                                'fatal: not removing \'/tmp/file1\' recursively without -r')) \
                               == 'git rm -r -f /tmp/file2'

# Generated at 2022-06-24 06:48:14.506675
# Unit test for function match
def test_match():
    assert match(Command('git rm', 'fatal: not removing \'some.file\' recursively without -r'))
    assert not match(Command('git rm', 'No error'))


# Generated at 2022-06-24 06:48:16.303965
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm new_folder', 'git rm new_folder', 0)) == u'git rm -r new_folder'

# Generated at 2022-06-24 06:48:20.969649
# Unit test for function get_new_command
def test_get_new_command():
    test_commands = ["git rm -rf src/test/resources",
                     "git rm src/test/resources",
                     "git rm -rf src/test/resources/",
                     "git rm src/test/resources/"]

    for test_command in test_commands:
        command = Command(script=test_command,
                          stderr="fatal: not removing 'src/test/resources' recursively without -r",
                          stdout="",
                          env={})
        assert get_new_command(command) == "git rm -r src/test/resources"

# Generated at 2022-06-24 06:48:25.417435
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf foo bar', 'fatal: not removing \'foo\' recursively without -r\nfatal: not removing \'bar\' recursively without -r\n')) == 'git rm -rf -r foo bar'

# Generated at 2022-06-24 06:48:28.221803
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file.txt',
                      'fatal: not removing \'file.txt\' recursively without -r')
    new_command = get_new_command(command)
    assert new_command == 'git rm -r file.txt'

# Generated at 2022-06-24 06:48:31.343766
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f file',
                      'fatal: not removing \'file\' recursively without -r\n',
                      '')
    assert get_new_command(command) == 'git rm -f -r file'

# Generated at 2022-06-24 06:48:37.018415
# Unit test for function match
def test_match():
    assert match(Command('git pull',
                         'fatal: not removing \'.gitignore\' recursively without -r',
                         '', 123))
    assert match(Command('git rm filea.txt fileb.txt',
                         'fatal: not removing \'.gitignore\' recursively without -r',
                         '', 123))
    assert not match(Command('ls',
                             'fatal: not removing \'.gitignore\' recursively without -r',
                             '', 123))


# Generated at 2022-06-24 06:48:40.212213
# Unit test for function match
def test_match():
    assert match(Command('git rm hello world', "fatal: not removing 'hello' recursively without -r"))


# Generated at 2022-06-24 06:48:43.362483
# Unit test for function get_new_command
def test_get_new_command():
    command = Script('git rm folder', 'not removing \'folder\' recursively without -r. Use -f if you really want to remove it')
    assert get_new_command(command) == 'git rm -r folder'



# Generated at 2022-06-24 06:48:46.962302
# Unit test for function match
def test_match():
    command = Command('app/views/index.js: No such file or directory', output='fatal: not removing \'app/views/index.js\' recursively without -r')
    assert match(command)
    assert not match(Command('rm -r app/views/index.js', output='fatal: not removing \'app/views/index.js\' recursively without -r'))
    assert not match(Command('rm app/views/index.js'))


# Generated at 2022-06-24 06:48:48.483741
# Unit test for function match
def test_match():
    command = Command(script='git branch -D --no-merged')
    assert (match(command)
            is True)


# Generated at 2022-06-24 06:48:53.165158
# Unit test for function match
def test_match():
    # Check that command is detected as a match to the rule
    assert match(Command('git rm -r folder', 'fatal: not removing \'folder/\''))
    # Check that command is detected as a match to the rule
    assert match(Command('git rm folder', 'fatal: not removing \'folder/\''))


# Generated at 2022-06-24 06:48:54.376836
# Unit test for function match
def test_match():
    assert match(Command('git rm', '', 'fatal: not removing \'static\' \
recursively without -r'))

# Generated at 2022-06-24 06:49:00.963334
# Unit test for function match
def test_match():
    command = Command('git rm file/to/remove')
    command.output = 'fatal: not removing \'file/to/remove\' recursively without -r'
    assert match(command)
    command.script = 'git rm file/to/remove'
    assert not match(command)
    command.script = 'rm file/to/remove'
    assert not match(command)
    command.script = 'dir rm file/to/remove'
    assert not match(command)
    command.script = 'git rm file/to/remove'
    assert match(command)
    command.script = 'git rm file/to/remove'
    command.output = 'fatal: not removing \'file/to/remove\' recursively without -r'
    assert match(command)
    command.script = 'git rm file/to/remove'

# Generated at 2022-06-24 06:49:08.275543
# Unit test for function get_new_command

# Generated at 2022-06-24 06:49:14.260973
# Unit test for function match
def test_match():
    """
    test the match function in git.py
    """
    assert match(Command('git rm -r -f --cached test',
                         'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm test', 'fatal: not removing \'test\''))
    assert not match(Command('git rm -r', 'fatal: not removing \'test\''))
    assert not match(Command('git rm -r test', 'fatal: not removing \'test\''))
    assert not match(Command('git rm -r test', 'fatal: not removing \'test\''))
    assert not match(Command('git rm -r test', 'fatal: not removing \'test\' without -r'))

# Generated at 2022-06-24 06:49:17.180301
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r')
    assert('rm -r file.txt' == get_new_command(command))

# Generated at 2022-06-24 06:49:21.555632
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', 'fatal: not removing \'foo/bar\' recursively without -r'))
    assert not match(Command('git commit', '', 'fatal: not removing \'foo/bar\''))
    assert not match(Command('git commit', '', 'fatal: not removing without -r'))



# Generated at 2022-06-24 06:49:24.021691
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo',
                                   'fatal: not removing \'foo\' recursively without -r',
                                   '')) == 'git rm -r foo'

# Generated at 2022-06-24 06:49:27.001563
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f --cached *', 'fatal: not removing \'src/test.c\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -f -r --cached *'

# Generated at 2022-06-24 06:49:31.271214
# Unit test for function match
def test_match():
    command = Command('git rm file1', '', '', stderr='fatal: not removing \'file1\' recursively without -r')
    assert match(command)
    command = Command('git rm file1', '', '')
    assert not match(command)


# Generated at 2022-06-24 06:49:35.516251
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test', '', 'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('', '', ''))

# Generated at 2022-06-24 06:49:38.696535
# Unit test for function match
def test_match():
    assert match(
        Command('git rm -rf _build',
                'fatal: not removing \'_build\' recursively without -r\n',
                '', 0))
    assert not match(Command('git rm _build', '', '', 0))


# Generated at 2022-06-24 06:49:41.847089
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm file')) == 'rm -r file'
    assert get_new_command(Command('rm -f file')) == 'rm -f -r file'


# Generated at 2022-06-24 06:49:44.280327
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f dir/file.txt', 'fatal: not removing \'dir/file.txt\' recursively without -r\n')) == 'git rm -r -f dir/file.txt'

# Generated at 2022-06-24 06:49:49.362039
# Unit test for function match
def test_match():
        assert match(Command('rm -rf .',output="fatal: not removing '.' recursively without -r"))
        assert not match(Command('git rm -rf .',output="fatal: not removing '.' recursively without -r"))
        assert not match(Command('git rm -rf .',output="fatal: not removing '.' recursively with -r"))


# Generated at 2022-06-24 06:49:55.622579
# Unit test for function match
def test_match():
    """
    Testing the match function in git_rm_recursively
    """
    assert match(Command('git rm -r',
                         'fatal: not removing \'x\' recursively without -r\n'))
    assert not match(Command('git rm',
                             'fatal: not removing \'x\' recursively without -r\n'))
    assert not match(Command('git rm',
                             'fatal: not removing \'x\' recursively woth -r\n'))



# Generated at 2022-06-24 06:49:59.844556
# Unit test for function match
def test_match():
    assert match(Command('git rm file_not_exist', ''))
    assert not match(Command('git rm file_not_exist', '', stderr=
    """
    fatal: not removing 'file_not_exist' recursively without -r
    """))

# Generated at 2022-06-24 06:50:03.070729
# Unit test for function match
def test_match():
    assert match(Command("git rm hello", "fatal: not removing 'hello' recursively without -r"))
    assert not match(Command("git rm hello", "fatal: not removing 'hello' without -r"))

# Generated at 2022-06-24 06:50:10.573781
# Unit test for function match
def test_match():
    assert match(Command('git rm filename',
                         'fatal: not removing \'filename\''
                         ' recursively without -r', ''))
    assert not match(Command('git rm filename',
                             'fatal: not removing \'filename\''
                             ' recursively without -r', '',
                             'git rm filename'))
    assert not match(Command('git rm filename',
                             'fatal: not removing \'filename\''
                             ' recursively without -r', '',
                             'git rm -r filename'))
    assert not match(Command('git rm filename',
                             'fatal: not removing \'filename\'', ''))
    assert not match(Command('', '', ''))


# Generated at 2022-06-24 06:50:13.064779
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r *')
    assert get_new_command(command) == 'git rm -r -r *'

# Generated at 2022-06-24 06:50:17.289832
# Unit test for function match
def test_match():
    res = match(Command('git rm -r dir'))
    assert res
    res = match(Command('git rm -r dir file'))
    assert res
    res = match(Command('git rm -r dir file', 'error: pathspec'))
    assert not res


# Generated at 2022-06-24 06:50:20.641754
# Unit test for function match
def test_match():
    assert match(Command('git rm file1',
        "fatal: not removing 'file1' recursively without -r\n"))
    assert not match(Command('git rm file1', ''))

# Generated at 2022-06-24 06:50:25.171712
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r myfile', 'fatal: not removing \'myfile\''
                      ' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r myfile'

# Generated at 2022-06-24 06:50:29.919975
# Unit test for function get_new_command
def test_get_new_command():
	command = type('obj', (object,), {
		'script': 'git rm README',
		'output': "fatal: not removing 'README' recursively without -r",
		'script_parts': ['git', 'rm', 'README', ]
	})
	new_command = get_new_command(command)
	assert new_command == 'git rm -r README'

# Generated at 2022-06-24 06:50:35.404170
# Unit test for function get_new_command
def test_get_new_command():
    command_ = u"git rm -r folder/file"
    new_command = u"git rm -r -r folder/file"
    correct_command = u"git rm -r folder/file"

    assert git_r.get_new_command(command.Command(command_, "",
                                                correct_command)) == new_command

# Generated at 2022-06-24 06:50:40.217246
# Unit test for function match
def test_match():
    assert match(Command('rm a',
                         'fatal: not removing \'a\' recursively without -r',
                         ''))
    assert not match(Command('rm a', '', ''))
    assert not match(Command('rm a',
                             'fatal: unknown command \'rm a\'',
                             ''))


# Generated at 2022-06-24 06:50:44.710506
# Unit test for function match
def test_match():
    assert match(Command("git rm -r src/main.c", "fatal: not removing 'src/main.c' recursively without -r"))
    assert not match(Command('git rm src/main.c', 'fatal: not removing \'src/main.c\' recursively without -r'))


# Generated at 2022-06-24 06:50:52.140226
# Unit test for function match
def test_match():
    output = "fatal: not removing 'build/CMakeFiles/CMakeError.log' recursively without -r"
    assert match(Command("git rm -f build/CMakeFiles/CMakeError.log", output))
    assert match(Command("git rm build/CMakeFiles/CMakeError.log", output))
    assert match(Command("git rm 'build/CMakeFiles/CMakeError.log'", output))
    assert not match(Command("git rm build/CMakeFiles/CMakeError.log", ""))
    assert not match(Command("git -f rm build/CMakeFiles/CMakeError.log", output))
    assert not match(Command("git -rf build/CMakeFiles/CMakeError.log", output))


# Generated at 2022-06-24 06:50:54.962006
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test',
                         'fatal: not removing \'test\' recursively without -r'))

# Unit tests for function get_new_command

# Generated at 2022-06-24 06:50:57.903749
# Unit test for function match
def test_match():
    assert match(Command('git remote rm origin',
        "fatal: not removing 'origin' recursively without -r", ''))
    assert not match(Command('git remote rm origin', '', ''))

# Generated at 2022-06-24 06:51:00.393470
# Unit test for function match
def test_match():
    assert match(Command('git rm test.txt',
                         'fatal: not removing \'test.txt\' recursively without -r'))
    assert not match(Command('git rm test.txt', ''))

# Generated at 2022-06-24 06:51:05.145658
# Unit test for function match
def test_match():
    # Test that it matches the expected command, with output
    command_output = """
fatal: not removing 'file_name.txt' recursively without -r
"""
    assert match(Command('git rm file_name.txt', command_output))

    # Test that it doesn't match an unrelated command
    assert not match(Command('git status', ''))


# Generated at 2022-06-24 06:51:10.296076
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test.txt', '', 'fatal: not removing \'test.txt\' recursively without -r', 1)) == 'git rm -r test.txt'
    assert get_new_command(Command('git rm -r test.txt', '', 'fatal: not removing \'test.txt\' recursively without -r', 1)) == 'git rm -r test.txt'

# Generated at 2022-06-24 06:51:14.122262
# Unit test for function match
def test_match():
    """
    Test match function
    """
    from thefuck.specific.git import match
    output = 'fatal: not removing \'toto/\' recursively without -r'
    command = Command('git rm toto/', output)
    assert(match(command))



# Generated at 2022-06-24 06:51:15.891019
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf foo', ''))
    assert not match(Command('git add file', ''))


# Generated at 2022-06-24 06:51:18.493525
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo', '', 'fatal: not removing \'foo\' recursively without -r', '', '')) == 'git rm -r foo'


# Generated at 2022-06-24 06:51:22.932430
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm file', '')) == 'git rm -r file')
    assert(get_new_command(Command('git branch -D branch', '')) == 'git branch -D -r branch')

# Generated at 2022-06-24 06:51:27.406193
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="git rm --cached foo", output="fatal: not removing 'foo' recursively without -r")
    assert get_new_command(command) == "git rm -r --cached foo"


# Generated at 2022-06-24 06:51:34.821848
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git rm -r test_file_1'
            == get_new_command('git rm test_file_1', 'git'))
    assert ('git rm -r test_file_1'
            == get_new_command('git rm test_file_1 test_file_2 ', 'git'))
    assert ('git rm -r test_file_1'
            == get_new_command('git rm test_file_1 test_file_2', 'git'))

# Generated at 2022-06-24 06:51:37.008562
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm dir1',
                      'fatal: not removing \'dir1\' recursively without -r\n',
                      'dir1')
    assert get_new_command(command) == 'git rm -r dir1'

# Generated at 2022-06-24 06:51:40.973938
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' \
recursively without -r\n'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm', 'foo'))

# Generated at 2022-06-24 06:51:45.043307
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm help.md',
                                   output="fatal: not removing 'help.md' recursively without -r")) \
        == "git rm -r help.md"


# Generated at 2022-06-24 06:51:46.411065
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'

# Generated at 2022-06-24 06:51:48.150280
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         "fatal: not removing 'file' recursively without -r"))

# Generated at 2022-06-24 06:51:51.167177
# Unit test for function match
def test_match():
    assert match(Command('git rm ', 'fatal: not removing \'f.py\' recursively without -r'))


# Generated at 2022-06-24 06:51:53.885895
# Unit test for function match
def test_match():
    assert match(Command('git rm',
         "fatal: not removing 'file' recursively without -r"))
    assert not match(Command('git rm', "nothing happens"))


# Generated at 2022-06-24 06:51:56.785650
# Unit test for function match
def test_match():
    assert match(Command('rm a', 'fatal: not removing \'a\' recursively without -r')) is True
    assert match(Command('rm a -r', 'fatal: not removing \'a\' recursively without -r')) is False
    assert match(Command('rm a -r', 'fatal: not removing \'a\' recursively without')) is False


# Generated at 2022-06-24 06:52:01.325326
# Unit test for function match
def test_match():
    assert match(Command('git branch -d bugfix',
                         'error: not removing \'branch\' recursively without -r',
                         '', 3))
    assert not match(Command('git branch -d bugfix', '', '', 3))



# Generated at 2022-06-24 06:52:04.863058
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm foo/bar", "fatal: not removing 'foo/bar' recursively without -r")
    assert get_new_command(command) == "git rm -r foo/bar"

# Generated at 2022-06-24 06:52:08.652545
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = 'git rm -a --cached hello',)) == 'git rm -a -r --cached hello'
    assert get_new_command(Command(script = 'git rm -a --cached hello',)) != 'git rm -a --cached hello'

# Generated at 2022-06-24 06:52:14.441055
# Unit test for function match
def test_match():
    assert git.match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert git.match(Command('git rm file', 'fatal: not removing \'files\' recursively without -r'))
    assert not git.match(Command('git rm file', ''))


# Generated at 2022-06-24 06:52:16.212087
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm filename", "")
    assert get_new_command(command) == "git rm -r filename"

# Generated at 2022-06-24 06:52:19.115141
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "msg" test.txt', '',
                         'fatal: not removing \'test.txt\' recursively without -r\n'
                         'Did you mean this?\n'
                         '\trm \'test.txt\'\n'))
    assert not match(Command('git commit -m "msg"', '', 'fatal: not removing \'test.txt\' recursively without -r'))


# Generated at 2022-06-24 06:52:24.215898
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ["git", "rm", "test"]
    command = type('Command', (), {"script_parts": command_parts, "output": ''})
    new_command = get_new_command(command)
    cmp_command = u'git rm -r test'
    assert cmp_command == new_command

# Generated at 2022-06-24 06:52:27.372097
# Unit test for function match
def test_match():
    command = Command("git rm random_directory/random_folder",
                      ("fatal: not removing 'random_directory/random_folder' "
                       "recursively without -r"))
    assert match(command)


# Generated at 2022-06-24 06:52:29.333232
# Unit test for function match
def test_match():
    assert (match("git rm file") == True)
    assert (match("git rm -r file") == False)


# Generated at 2022-06-24 06:52:33.544053
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo')) == 'git rm -r foo'
    assert get_new_command(Command('git rm foo bar')) == 'git rm -r foo bar'
    assert get_new_command(Command('rm foo')) == 'rm -r foo'

# Generated at 2022-06-24 06:52:37.152602
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r file1 file2',
        'fatal: not removing '
        "'path/to/file1' recursively without -r\n"
        "fatal: not removing 'file2' recursively without -r")) == \
        "git rm -r -r file1 file2"

# Generated at 2022-06-24 06:52:39.388500
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r')
    assert git_rm_to_rm.get_new_command(command) == 'git rm -r test.txt'

# Generated at 2022-06-24 06:52:43.964511
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    correct_command = git_rm_can_not_remove_directory_recursively('git rm tests')
    assert get_new_command(Command('git rm tests',
                                   'fatal: not removing \'tests\' recursively without -r\n',
                                   '', 0, '', '')) == correct_command

# Generated at 2022-06-24 06:52:49.923401
# Unit test for function match
def test_match():
    assert match(Command('git rm -r directory',
                         stderr='fatal: not removing \'directory\' recursively without -r',
                         script='git rm -r directory',
                         stdout=None,
                         args=('-r', 'directory')))
    assert not match(Command(script='git rm -r directory',
                             stdout=None,
                             args=('-r', 'directory')))


# Generated at 2022-06-24 06:52:54.686325
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='rm a/b/c',
                      stdout=r"""
error: The following untracked working tree files would be removed by checkout:
    README.md
    test/test.py
Please move or remove them before you can switch branches.
Aborting
fatal: not removing 'a/b/c' recursively without -r
"""
                      )
    new_command = get_new_command(command)
    assert new_command == "git rm -r a/b/c"

# Generated at 2022-06-24 06:52:57.164451
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test', 'fatal: not removing \'test\' recursively without -r', '')) == 'git rm -r test'



# Generated at 2022-06-24 06:52:59.947879
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git rm -r foo.h'
    assert get_new_command(command) == "git rm -r foo.h"

# Generated at 2022-06-24 06:53:06.418272
# Unit test for function match
def test_match():
    assert match(Command(' git rm a/b/c'))
    assert not match(Command(' git rm a/b/c', 'fatal: not removing \''))
    assert not match(Command(' git rm a/b/c', 'fatal: not removing \'', 'recursively without -r'))
    assert not match(Command(' git rm a/b/c', 'fatal: not removing \'', 'recursively without -r', 'wrong'))

# Generated at 2022-06-24 06:53:09.164429
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    result = get_new_command(Command('git rm file.txt'))
    assert result == "git rm -r file.txt"

# Generated at 2022-06-24 06:53:11.486416
# Unit test for function match
def test_match():
    command = Command("git rm --cached my_file",
                      "fatal: not removing 'my_file' recursively without -r")
    assert match(command)



# Generated at 2022-06-24 06:53:14.497601
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='rm -rf test.txt',
                      stderr='fatal: not removing \'/home/dir/test.txt\' recursively without -r\n')
    assert get_new_command(command) == 'rm -rf -r test.txt'

# Generated at 2022-06-24 06:53:16.057410
# Unit test for function match
def test_match():
    assert match(Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r', '', 1, 1))

# Generated at 2022-06-24 06:53:20.694542
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm folder') == 'git rm -r folder'
    assert get_new_command('git rm -f folder') == 'git rm -r -f folder'
    assert get_new_command('git rm -f --cached folder') == 'git rm -r -f --cached folder'

# Generated at 2022-06-24 06:53:25.057600
# Unit test for function match
def test_match():
    assert match(Command('git rm foo.txt',
                      'fatal: not removing \'foo.txt\' recursively without -r'))
    assert not match(Command('git rm foo.txt', ''))
    assert not match(Command('', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-24 06:53:32.566977
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'
    if py3:
        assert get_new_command(Command('git rm file', 'fatal: not removing \'file\': Is a directory')) == 'git rm -r file'
    else:
        assert get_new_command(Command('git rm file', 'fatal: not removing \'file\': Is a directory')) == 'git rm -r file'
    assert get_new_command(Command('git rm file', '')) == 'git rm file'

# Generated at 2022-06-24 06:53:40.688339
# Unit test for function match
def test_match():
    assert match(Command('git rm | grep', ''))
    assert match(Command('git rm | grep', 'fatal: not removing'))
    assert match(Command('git rm | grep', 'fatal: not removing \'\' recursively without -r'))
    assert not match(Command('git rm | grep', 'fatal: not removing \'\' recursively with -r'))
    assert not match(Command('git rm', 'fatal: not removing \'\' recursively without -r'))
    assert match(Command('git rm', ''))
    assert match(Command('git rm', 'fatal: not removing'))
    assert match(Command('git rm', 'fatal: not removing \'\' recursively without -r'))

# Generated at 2022-06-24 06:53:47.057883
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git branch -d branch-name")
    assert get_new_command(command) == "git branch -d -r branch-name"

    command = Command("git rm -rf branch-name")
    assert get_new_command(command) == "git rm -rf -r branch-name"

    command = Command("git rm branch-name")
    assert get_new_command(command) == "git rm -r branch-name"


# Generated at 2022-06-24 06:53:51.457230
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm readme.txt') == 'git rm -r readme.txt'
    assert get_new_command('git rm readme.txt testing') == 'git rm -r readme.txt testing'
    assert get_new_command('git rm read') == 'git rm -r read'


# Generated at 2022-06-24 06:53:56.196463
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo',
                'fatal: not removing \'foo\' recursively without -r\n'))
    assert not match(Command('ls .', ''))
    assert not match(Command('git rm foo', ''))


# Generated at 2022-06-24 06:54:00.370896
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert git_rm_recursive('git rm a').get_new_command() == u'git rm -r a'
    assert git_rm_recursive(Command('git rm -n a', 'fatal: not removing "a" recursively without -r')).get_new_command() == u'git rm -n -r a'

# Generated at 2022-06-24 06:54:02.577991
# Unit test for function match
def test_match():
    assert match(Command("git rm test", "fatal: not removing 'test' recursively without -r"))


# Generated at 2022-06-24 06:54:12.216861
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3',
                         'fatal: not removing \'file1\' recursively without -r\n',
                         'error'))
    assert match(Command('git rm file1 file2 file3',
                         'fatal: not removing \'file2\' recursively without -r\n',
                         'error'))
    assert match(Command('git rm file1 file2 file3',
                         'fatal: not removing \'file3\' recursively without -r\n',
                         'error'))
    assert not match(Command('git rm file1 file2 file3',
                             'fatal: not removing \'file2\' recursively without -r\n'
                             'fatal: not removing \'file1\' recursively without -r\n',
                             'error'))

# Generated at 2022-06-24 06:54:20.597986
# Unit test for function match
def test_match():
    # Test for string that matches
    assert match(Command('rm -rf *'))
    # Test for string that matches but is wrong flag
    assert not match(Command('rm -r *'))
    # Test that a single character doesn't break the command
    assert match(Command('rm -rf a'))
    # Test that a single character doesn't break the command
    assert match(Command('rm -rf a'))
    # Test git command
    assert match(Command('git rm -rf a'))
    # Test no filename
    assert match(Command('rm -rf'))
    # Test no flag
    assert match(Command('rm *'))



# Generated at 2022-06-24 06:54:25.955760
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm file', '', '')) == 'git rm -r file'
    assert get_new_command(Command('git rm file', '', '')) == 'git rm -r file'
    assert get_new_command(Command('git rm -r file', '', '')) == 'git rm -r -r file'
    assert get_new_command(Command('git rm -r -r file', '', '')) == 'git rm -r -r -r file'
    assert get_new_command(Command('git rm file -r', '', '')) == 'git rm file -r -r'

# Generated at 2022-06-24 06:54:33.307431
# Unit test for function get_new_command
def test_get_new_command():
    git_command_output = '''fatal: not removing 'src/main/java/com/example/auth/authentication/provider/ClientCredentialAuthenticationProvider.java' recursively without -r
'''
    command = Command('git rm src/main/java/com/example/auth/authentication/provider/ClientCredentialAuthenticationProvider.java', git_command_output)
    assert (get_new_command(command) == 'git rm -r src/main/java/com/example/auth/authentication/provider/ClientCredentialAuthenticationProvider.java')

# Generated at 2022-06-24 06:54:37.047454
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.md', output='fatal: not removing \'hello.md\' recursively without -r'))
    assert not match(Command('pwd', output='/home/michael/scripts'))
    assert not match(Command('ls', output='abc.py\nabc.pyc\nabc.txt'))


# Generated at 2022-06-24 06:54:42.480293
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('something','fuck')
    command.script = "git rm testfile/or/dir"
    command.output = "fatal: not removing 'testfile/or/dir' recursively without -r"
    command.script_parts = ["git", "rm", "testfile/or/dir"]
    new_command = get_new_command(command)
    assert new_command == "git rm -r testfile/or/dir"

# Generated at 2022-06-24 06:54:45.305281
# Unit test for function get_new_command
def test_get_new_command():
    test_command = 'git rm foo.bar'
    command = Command(test_command, u'fatal: not removing \'foo.bar\' recursively without -r')
    assert get_new_command(command) == 'git rm -r foo.bar'

# Generated at 2022-06-24 06:54:47.210576
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("rm ~/.vimrc") == "rm -r ~/.vimrc"

# Generated at 2022-06-24 06:54:52.833062
# Unit test for function match
def test_match():
    # for out in [
        # 'fatal: not removing \'submodule/submodule/.git\' recursively without -r',
        # 'fatal: not removing \'/submodule/submodule/.git\' recursively without -r',
        # 'fatal: not removing \'submodule/submodule\.git\' recursively without -r'
    # ]:
    assert match(Command('git rm submodule/submodule/.git',
        'fatal: not removing \'submodule/submodule/.git\' recursively without -r'))
    assert not match(Command('git rm submodule/submodule/.git', ''))


# Generated at 2022-06-24 06:54:56.816395
# Unit test for function match
def test_match():
    command = Command('git rm -r ./test.txt')
    assert match(command)
    command = Command('git rm ./test.txt -r')
    assert not match(command)


# Generated at 2022-06-24 06:54:58.942257
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test -r')
    assert get_new_command(command) == 'git rm -r test -r'

# Generated at 2022-06-24 06:55:00.693222
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r test.txt' == get_new_command('git rm test.txt')

# Generated at 2022-06-24 06:55:03.341648
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='rm file',
                                   output="fatal: not removing 'file' recursively without -r")) == 'git rm -r file'

# Generated at 2022-06-24 06:55:09.864331
# Unit test for function match
def test_match():
    assert match(Command('git rm test.bank',
                         'fatal: not removing \'test.bank\' recursively without -r\n'))
    assert match(Command('git rm test.bank2',
                         'fatal: not removing \'test.bank2\' recursively without -r\n'))
    assert not match(Command('git rm',
                             'fatal: not removing \'test.bank\' recursively without -r\n'))
    assert not match(Command('git rm --cached test.bank',
                             'fatal: not removing \'test.bank\' recursively without -r\n'))


# Generated at 2022-06-24 06:55:11.378251
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm foo" ) == "git rm -r foo"
    assert get_new_command("git rm -f foo" ) == "git rm -f -r foo"
    assert get_new_command("git rm --cached foo" ) == "git rm -r --cached foo"

# Generated at 2022-06-24 06:55:13.442902
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Context(script='git rm folder')) == 'git rm -r folder'



# Generated at 2022-06-24 06:55:14.988045
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r file')) == 'git rm -r -r file'

# Generated at 2022-06-24 06:55:17.254259
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf test', "fatal: not removing 'test' recursively without -r"))
    assert not match(Command('git rm -rf test', ''))


# Generated at 2022-06-24 06:55:20.132540
# Unit test for function match
def test_match():
    assert match(Command('git rm folder/test.py', 'fatal: not removing \'folder/test.py\' recursively without -r'))


# Generated at 2022-06-24 06:55:25.539820
# Unit test for function match
def test_match():
    assert match(Command('git rm -f *.pyc',
                         "fatal: not removing '" +
                         "XXX' recursively without -r"))
    assert not match(Command('git rm -f *.pyc',
                             'fatal: not removing ' +
                             'XXX recursively without r'))
    assert not match(Command('git rm -f *.pyc', ''))


# Generated at 2022-06-24 06:55:27.346251
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo')) == 'git rm -r foo'



# Generated at 2022-06-24 06:55:29.163706
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r')
    assert get_new_command(command) == 'git rm -r -r'

# Generated at 2022-06-24 06:55:37.049938
# Unit test for function match
def test_match():
    # Test with a wrong output
    assert match("git rm -rn foo") is None

    # Test with a wrong output (without "output")
    assert match("git rm -rn foo", "") is None

    # Test with a good output (with error)
    output = "fatal: not removing 'bar' recursively without -r"
    assert match("git rm -rn foo", output)

    # Test with a good output (without error)
    output = "fatal: not removing 'bar' recursively without -r\n"
    assert match("git rm -rn foo", output) is None

# Generated at 2022-06-24 06:55:42.437786
# Unit test for function match
def test_match():
    git_output_1 = '''fatal: not removing 'foo/bar.txt' recursively without -r'''
    git_output_2 = '''fatal: entry 'foo/bar.txt' not uptodate. Cannot merge.'''

    assert match(Command(script = 'git rm foo/bar.txt', output = git_output_1))
    assert not match(Command(script = 'git rm foo/bar.txt', output = git_output_2))


# Generated at 2022-06-24 06:55:44.439862
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm *') == 'git rm -r *'
    assert get_new_command('git rm path') == 'git rm -r path'

# Generated at 2022-06-24 06:55:48.754177
# Unit test for function match
def test_match():
    command1 = Command('git rm -rf file', 'fatal: not removing \'file\' recursively without -r')
    command2 = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert match(command1)
    assert match(command2)


# Generated at 2022-06-24 06:55:52.819047
# Unit test for function get_new_command
def test_get_new_command():
    command = type("Command", (object,),
                   {"script": "git rm somefile",
                    "script_parts": ["git", "rm", "somefile"]})
    new_command = get_new_command(command)
    assert new_command == "git rm -r somefile"

# Generated at 2022-06-24 06:55:55.326106
# Unit test for function match
def test_match():
    assert match(Command('git cmd --flag1', '', 'fatal: not removing \'/path/file\' recursively without -r'))
    assert not match(Command('git cmd', '', 'fatal: not removing \'dir\' recursively without -r'))

# Generated at 2022-06-24 06:55:57.487528
# Unit test for function match
def test_match():
    command = "\nfatal: not removing 'mybranch' recursively without -r\n"
    assert match(Command('git rm mybranch', command))



# Generated at 2022-06-24 06:56:01.151809
# Unit test for function match
def test_match():
    assert match(Command('git rm some_file', 'fatal: not removing \'some_file\' recursively without -r\n'))
    assert not match(Command('git rm', 'fatal: not removing \'some_file\' recursively without -r\n'))
    assert not match(Command('git rm', 'fatal: not removing \'some_file\' recursively without -r\n'))
    assert not matc

# Generated at 2022-06-24 06:56:02.053415
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-24 06:56:04.987019
# Unit test for function match
def test_match():
    match_output = MagicMock(spec=sh.ErrorReturnCode)
    match_output.output = "fatal: not removing 'dir' recursively without -r"
    assert match(MagicMock(script='git rm dir', output=match_output))
    assert not match(MagicMock(script='git mv dir', output=match_output))



# Generated at 2022-06-24 06:56:08.683202
# Unit test for function match
def test_match():
    assert match(Command('git branch -d branch',
            output="error: branch 'branch' not found."))
    assert not match(Command('git branch -d branch',
            output="Deleted branch branch (was ff419d7)."))


# Generated at 2022-06-24 06:56:11.976406
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f some_directory')
    new_command = get_new_command(command)
    assert new_command == 'git rm -f -r some_directory'

# Generated at 2022-06-24 06:56:16.698382
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt', ''))
    assert not match(Command('git rm file.txt', 'fatal: not removing \'file.txt\''))
    assert not match(Command("git status", "fatal: not removing 'file.txt' recursively without -r"))
