

# Generated at 2022-06-24 06:46:14.874107
# Unit test for function get_new_command
def test_get_new_command():
    # git rm -r
    command = Command('git rm test', '', '')
    assert get_new_command(command) == u'git rm -r test'
    # git rm -rf
    command = Command('git rm -rf test', '', '')
    assert get_new_command(command) == u'git rm -rf test'
    # git rm
    command = Command('git rm', '', '')
    assert get_new_command(command) == u'git rm -r'

# Generated at 2022-06-24 06:46:20.249522
# Unit test for function match
def test_match():
    assert match(Command('git rm -r hello.txt',
                         'fatal: not removing \'hello.txt\' recursively without -r\n'))
    assert not match(Command('git rm hello.txt',
                         'fatal: not removing \'hello.txt\' recursively without -r\n'))
    assert not match(Command('git rm -r hello.txt',
                         'fatal: not removing \'hello.txt\' recursively without -r\n'))
    assert not match(Command('git rm -r hello.txt',
                         'fatal: not removing \'hello.txt\' recursively without -r'))


# Generated at 2022-06-24 06:46:21.558481
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r foo' == get_new_command('git rm foo')

# Generated at 2022-06-24 06:46:26.399185
# Unit test for function get_new_command
def test_get_new_command():
    print("Check get_new_command...")
    output = "fatal: not removing 'my_file.txt' recursively without -r"
    command = Command('git rm my_file.txt', output=output)
    new_command = get_new_command(command)
    expected_command = "git rm -r my_file.txt"
    if new_command == expected_command:
        print("OK")
    else:
        print("KO")
        print("Returned command: {}".format(new_command))
        print("Expected command: {}".format(expected_command))



# Generated at 2022-06-24 06:46:34.625989
# Unit test for function match
def test_match():
    assert match(Command(' git rm -r new_folder ', 'fatal: not removing \'new_folder\' recursively without -r'))
    assert match(Command(' git rm new_folder ', 'fatal: not removing \'new_folder\' recursively without -r'))
    assert not match(Command(' git rm -rf new_folder ', 'fatal: not removing \'new_folder\' recursively without -r'))
    assert not match(Command(' git rm new_folder ', 'fatal: not removing \'new_folder\''))
    assert not match(Command(' rm new_folder ', 'fatal: not removing \'new_folder\' recursively without -r'))


# Generated at 2022-06-24 06:46:38.332469
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursive_without_r import get_new_command
    assert get_new_command(Command(script="git rm foo", output="fatal: not removing 'foo' recursively without -r")) == "git rm -r foo"

# Generated at 2022-06-24 06:46:41.409007
# Unit test for function match
def test_match():
    assert match(Command('git rm -r new_branch',
                'fatal: not removing \'new_branch\' recursively without -r',
                'git rm -r new_branch'))
    assert not match(Command('git rm new_file',
                             "fatal: pathspec 'new_file' did not match any files",
                             'git rm new_file'))



# Generated at 2022-06-24 06:46:44.157029
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r folder1', '', 'fatal: not removing \'folder1\' recursively without -r')) == 'git rm -r -r folder1'

# Generated at 2022-06-24 06:46:52.658895
# Unit test for function match
def test_match():
    # A match for the following error messege:
    # 'error: the following file has local modifications:'
    # '<repository_file_name>'
    assert match(Command('git rm file',
                        'fatal: not removing \'file\' recursively without -r')) is True
    assert match(Command('git rm',
                        'fatal: not removing \'file\' recursively without -r')) is False
    assert match(Command('git rm file',
                        'fatal: not removing \'file\' recursively')) is False
    assert match(Command('rm file',
                        'fatal: not removing \'file\' recursively without -r')) is False


# Generated at 2022-06-24 06:46:56.356804
# Unit test for function get_new_command
def test_get_new_command():
    """Tests that the get_new_command function returns recursively (-r)
        to the rm command in #match function
    """
    command = Command('git rm x')
    assert get_new_command(command) == 'git rm -r x'

# Generated at 2022-06-24 06:47:01.433071
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git rm path-to-file1.py path-to-file2.py',
                                'fatal: not removing \'path-to-file1.py\' recursively without -r\n')) == 'git rm -r path-to-file1.py path-to-file2.py'

# Generated at 2022-06-24 06:47:05.416569
# Unit test for function get_new_command
def test_get_new_command():
    """Unit test for function get_new_command"""
    assert_equals(get_new_command(Command('git rm -r dir', 'fatal: not removing \'dir\' recursively without -r\n')),
                  "git rm -r -r dir")

# Generated at 2022-06-24 06:47:09.577672
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file1 file2',
                         'fatal: not removing \'file1\' and \'file2\' recursively without -r'))
    assert not match(Command('git rm file', ''))



# Generated at 2022-06-24 06:47:13.466692
# Unit test for function match
def test_match():

    # Test function match() when command matches
    command = Command(script = 'git rm -rho abc.txt')
    assert match(command) == True

    # Test function match() when command does not match
    command = Command(script = 'git -rho abc.txt')
    assert match(command) == False

# Generated at 2022-06-24 06:47:16.470630
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f file',
                      'fatal: not removing \'file\' recursively without -r')
    assert_equals(get_new_command(command), 'git rm -rf file')

# Generated at 2022-06-24 06:47:19.463690
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm directory', 'fatal: not removing \'directory\' recursively without -r', '')
    assert 'rm -r directory' == get_new_command(command)



# Generated at 2022-06-24 06:47:22.504785
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm non existent file',
                      'fatal: not removing \'non\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r non'


enabled_by_default = True

# Generated at 2022-06-24 06:47:25.991411
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm README.md') == 'git rm -r README.md'
    assert get_new_command('cd src && git rm README.md') == 'cd src && git rm -r README.md'

# Generated at 2022-06-24 06:47:28.991724
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r test/test_helper.pyc")
    assert get_new_command(command) == "git rm -r -r test/test_helper.pyc"

# Generated at 2022-06-24 06:47:30.687090
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm test.py') == 'git rm -r test.py'

# Generated at 2022-06-24 06:47:33.366435
# Unit test for function match
def test_match():
    command = Command('git rm awesome.txt', 'fatal: not removing \'awesome.txt\' recursively without -r\n')
    assert match(command)


# Generated at 2022-06-24 06:47:38.944936
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', 'rm', 'config.ini']

# Generated at 2022-06-24 06:47:41.573227
# Unit test for function match
def test_match():
    script = "git rm foo"
    output = "fatal: not removing 'foo' recursively without -r"
    command = Command(script, output)
    assert match(command)


# Generated at 2022-06-24 06:47:45.913629
# Unit test for function match
def test_match():
	assert match(Command('git rm file1 file2 file3 file4', \
			'''fatal: not removing 'file1' recursively without -r
fatal: not removing 'file2' recursively without -r
fatal: not removing 'file3' recursively without -r
fatal: not removing 'file4' recursively without -r
'''))


# Generated at 2022-06-24 06:47:51.071019
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm .;')) == 'git rm -r .;'
    assert get_new_command(Command('git rm .')) == 'git rm -r .'
    assert get_new_command(Command('git commit -a')) == 'git commit -a'

# Generated at 2022-06-24 06:47:52.683013
# Unit test for function match
def test_match():
    # Returns True when git rm is used with wrong arguments and raises an error
    command = Command('git rm -r *')
    assert match(command)


# Generated at 2022-06-24 06:47:57.424710
# Unit test for function get_new_command

# Generated at 2022-06-24 06:48:05.795879
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'
    assert get_new_command('git rm -r foo') == 'git rm -r foo'
    assert get_new_command('git rm -b foo') == 'git rm -b -r foo'
    assert get_new_command('git rm -f foo') == 'git rm -f -r foo'
    assert get_new_command('git rm --cached foo') == 'git rm --cached -r foo'
    assert get_new_command('git rm -f --cached foo') == 'git rm -f --cached -r foo'

# Generated at 2022-06-24 06:48:09.551491
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git rm file',
                                    'fatal: not removing \'file\' recursively without -r\n',
                                    None))
            == 'git rm -r file')

# Generated at 2022-06-24 06:48:13.292433
# Unit test for function match
def test_match():
    #print git_support(get_new_command)
    command = Command('git rm -f *.png', 'fatal: not removing \'.gitignore\' recursively without -r\n')
    #print match(command)
    assert match(command)



# Generated at 2022-06-24 06:48:16.603285
# Unit test for function match
def test_match():
    assert match(Command('git branch test', '', '', 0, 'fatal: not removing "test" recursively without -r', '')) == True
    assert match(Command('git branch test', '', '', 0, 'fatal: not removing "test" recursively with -r', '')) == False

# Generated at 2022-06-24 06:48:19.202341
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command(Command('git rm -r dir', output='fatal: not removing \'dir\' recursively without -r\n', script='git rm -r dir'))
    assert new_cmd == 'git rm -r -r dir'

# Generated at 2022-06-24 06:48:21.714304
# Unit test for function match
def test_match():
    assert match('git status')
    assert match('git rm')
    assert match('git rm -r')
    assert match('git rm -f')


# Generated at 2022-06-24 06:48:25.178914
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm foo bar", "fatal: not removing 'foo' recursively without -r")) == "git rm -r foo bar"

# Generated at 2022-06-24 06:48:26.762333
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git rm test')) == 'git rm -r test'

# Generated at 2022-06-24 06:48:34.610151
# Unit test for function match
def test_match():
    # run a command that doesn't match
    output = r'''error: unknown switch `s'
usage: git rm [options] [--] <file>...

'''
    command_ = Command(script='git rm -s', output=output)
    assert not match(command_)

    # run a command that matches
    output = r'''fatal: not removing 'numpy/core/multiarray/tests/test_multiarray.pyc' recursively without -r
'''
    command_ = Command(script='git rm numpy/core/multiarray/tests/test_multiarray.pyc', output=output)
    assert match(command_)

# Generated at 2022-06-24 06:48:40.785019
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'
    assert get_new_command(Command('git rm -f file')) == 'git rm -f -r file'
    assert get_new_command(Command('git rm | rm -f file')) == 'git rm -r | rm -f file'


# Generated at 2022-06-24 06:48:45.552021
# Unit test for function match
def test_match():
    assert_equals(match(Command('foo', '', '')), False)
    assert_equals(match(Command('rm bar', '',
                             'fatal: not removing \'bar\' recursively without -r')), True)
    assert_equals(match(Command('git rm bar', '',
                             'fatal: not removing \'bar\' recursively without -r')), True)



# Generated at 2022-06-24 06:48:48.511813
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = 'git branch -d branchname',
                      output = 'fatal: not removing \'branchname\' recursively without -r')
    assert get_new_command(command) == 'git branch -d -r branchname'

# Generated at 2022-06-24 06:48:53.998469
# Unit test for function match
def test_match():
    command = Command("git rm -r")
    assert not match(command)
    command = Command("git rm -r --cached file")
    assert not match(command)
    command = Command("git rm ")
    assert match(command)
    command = Command("git rm -r")
    assert match(command)
    command = Command("git rm -rf")
    assert match(command)


# Generated at 2022-06-24 06:48:58.653697
# Unit test for function match
def test_match():
    assert (match(Command('git rm -r bower_components/ angular.min.js',
                         'fatal: not removing \'bower_components/\' recursively without -r\n'
                         'Use --cached to keep the file, or make sure it is in your working directory to remove it.\n'))
            is True)



# Generated at 2022-06-24 06:49:01.958014
# Unit test for function get_new_command
def test_get_new_command():
    # Setup string
    command_str = 'git rm foo'
    # Setup Command class object
    command_obj = Command(command_str, 'fatal: not removing \'foo\' recursively without -r')

    # Check if get_new_command returns the correct command
    assert get_new_command(command_obj) == 'git rm -r foo'

# Generated at 2022-06-24 06:49:06.565432
# Unit test for function match
def test_match():
    assert match(Command('rm -rf ~/temp', 'fatal: not removing \'~/temp\' recursively without -r'))
    assert match(Command('git rm -rf ~/temp', 'fatal: not removing \'~/temp\' recursively without -r'))
    assert not match(Command('rm -rf ~', 'fatal: rm not found'))

# Generated at 2022-06-24 06:49:12.752613
# Unit test for function get_new_command
def test_get_new_command():
    git_command = 'rm command.py'
    output = "fatal: not removing 'command.py' recursively without -r"
    from thefuck.types import Command
    command = Command(git_command, output)
    assert u'git rm -r command.py' == get_new_command(command)
    git_command = 'rm command.py tests.py'
    output = "fatal: not removing 'tests.py' recursively without -r"
    command = Command(git_command, output)
    assert u'git rm -r command.py tests.py' == get_new_command(command)

# Generated at 2022-06-24 06:49:14.986295
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2', 'fatal: not removing \'file1\' recursively without -r'))

# Generated at 2022-06-24 06:49:19.463910
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3', 'fatal: not removing \'file2\' recursively without -r')) == True
    assert match(Command('git rm file1 file2 file3', 'fatal: not removing \'file2\'')) == False
    assert match(Command('git rm file1 file2 file3', 'fatal: not removing \'file2\' recursively without')) == False


# Generated at 2022-06-24 06:49:23.605623
# Unit test for function match
def test_match():
    assert match(Command('', ''))
    assert not match(Command('', 'fatal: not removing'))
    assert not match(Command('', 'fatal: not removing recursively without -r'))
    assert not match(Command('rm', 'fatal: not removing'))
    assert not match(Command('rm', 'fatal: not removing recursively without -r'))


# Generated at 2022-06-24 06:49:25.477714
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm -rf .", "fatal: not removing '.' recursively without -r")) == "git rm -rf -r ."

# Generated at 2022-06-24 06:49:28.296309
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="git rm foo/bar/test.txt",
                      output="fatal: not removing 'foo/bar/test.txt' recursively without -r\n")
    assert get_new_command(command) == "git rm -r foo/bar/test.txt"

# Generated at 2022-06-24 06:49:31.063041
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="git rm -r folder/",
                      stdout=u"fatal: not removing 'folder' recursively without -r")

# Generated at 2022-06-24 06:49:35.651281
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -r /tmp/file',
                      output="fatal: not removing 'file' recursively without -r")
    assert get_new_command(command) == 'git rm -r -r /tmp/file'

# Generated at 2022-06-24 06:49:44.988897
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    command = Command('git rm -r file', '', '', '')
    assert get_new_command(command) == 'git rm -r file'
    command = Command('git rm -r file something', '', '', '')
    assert get_new_command(command) == 'git rm -r file something'
    command = Command('git rm -r file something', '', '', '', 'something')
    assert get_new_command(command) == 'git rm -r file something'
    command = Command('git rm -r file something', '', '', '', 'file')
    assert get_new_command(command) == 'git rm -r file something'

# Generated at 2022-06-24 06:49:53.910381
# Unit test for function match
def test_match():
    assert(match(Command("git rm --cached file1 file2 file3 file4",
                "fatal: not removing 'file2' recursively without -r\n")))
    assert(match(Command("git rm file1 file2 file3 file4",
                "fatal: not removing 'file2' recursively without -r\n")))
    assert(not match(Command("git rm file1 file2 file3 file4",
                "fatal: not removing 'foo' recursively without -r\n")))
    assert(not match(Command("git rm file1 file2 file3 file4",
                "fatal: not removing 'file2' recursively without -r foo")))



# Generated at 2022-06-24 06:50:00.866327
# Unit test for function match
def test_match():
    command = Command('git rm dir1', 'fatal: not removing \'dir1\' recursively without -r')
    assert match(command)
    command = Command('git rm dir1', 'fatal: not removing \'README\' recursively without -r')
    assert not match(command)
    command = Command('git rm -r dir1', 'fatal: not removing \'README\' recursively without -r')
    assert not match(command)
    command = Command('', 'fatal: not removing \'README\' recursively without -r')
    assert not match(command)


# Generated at 2022-06-24 06:50:03.670193
# Unit test for function get_new_command
def test_get_new_command():
        command = Command(script='git rm -r --cached cache')
        assert get_new_command(command) == "git rm -r -r --cached cache"

# Generated at 2022-06-24 06:50:06.680965
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
        'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))


# Generated at 2022-06-24 06:50:09.229903
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r\n', '')
    assert get_new_command(command) == 'git rm -r dir'

# Generated at 2022-06-24 06:50:12.359574
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git rm foo/',
                                    'fatal: not removing \'foo/\' recursively without -r\n')) ==
            'git rm -r foo/')

# Generated at 2022-06-24 06:50:14.098053
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command(script='git rm file.txt',
                                   stdout="fatal: not removing 'file.txt' recursively without -r")) == "git rm -r file.txt")

# Generated at 2022-06-24 06:50:20.903178
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm stats.py") == "git rm -r stats.py"
    assert get_new_command("git rm -rf stats.py") == "git rm -rf stats.py"
    assert get_new_command("git rm stats.py/") == "git rm -r stats.py/"
    assert get_new_command("git rm stats.py; rm stats.py") == "git rm -r stats.py; rm stats.py"

# Generated at 2022-06-24 06:50:23.524816
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r tmp')) == 'git rm -r -r tmp'

# Generated at 2022-06-24 06:50:27.573931
# Unit test for function match
def test_match():
    assert match(Command("git rm asdf", "fatal: not removing 'asdf' recursively without -r\n"))
    assert not match(Command("git rm -r asdf", "fatal: not removing 'asdf' recursively without -r\n"))


# Generated at 2022-06-24 06:50:29.528959
# Unit test for function match
def test_match():
    from thefuck.specific.git import match
    assert match('git rm file') == True


# Generated at 2022-06-24 06:50:35.835450
# Unit test for function match
def test_match():
    """ test match """
    assert match(Command('git rm app/models/robot.rb',
                         'fatal: not removing \'app/models/robot.rb\' recursively without -r'))
    assert not match(Command('git rm -r app/models/robot.rb',
                             'fatal: not removing \'robot.rb\' recursively without -r'))



# Generated at 2022-06-24 06:50:37.393574
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'

# Generated at 2022-06-24 06:50:43.629619
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f .travis.yml',
                                   '.travis.yml: is a directory\n'))\
            == 'git rm -f -r .travis.yml'
    assert get_new_command(Command('git rm -r one two',
                                   'fatal: not removing \'two\' '
                                   'recursively without -r\n'))\
            == 'git rm -r -r one two'

# Generated at 2022-06-24 06:50:45.404067
# Unit test for function get_new_command
def test_get_new_command():
    cmd = "git rm file"
    assert get_new_command(cmd) == "git rm -r file"

# Generated at 2022-06-24 06:50:48.190851
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r filename' == get_new_command('git rm filename')
    assert 'git rm -r -f filename' == get_new_command('git rm -f filename')
    assert 'git rm "filename with spaces" -r' == get_new_command('git rm "filename with spaces"')

# Generated at 2022-06-24 06:50:58.840773
# Unit test for function match
def test_match():
    command1 = u'git rm dir1/file1 dir2/file2'
    command2 = u'git rm -rf dir1/file1 dir2/file2'
    command3 = u'git rm file1 file2'
    output1 = u"""
fatal: not removing 'dir1/file1' recursively without -r
fatal: not removing 'dir2/file2' recursively without -r
"""
    output2 = u"""
fatal: not removing 'file1' recursively without -r
fatal: not removing 'file2' recursively without -r
"""
    command = type("Command", (object,), {})
    command.script = command1
    command.output = output1
    command.script_parts = command1.split()
    assert match(command)
    command.script_

# Generated at 2022-06-24 06:51:02.658868
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r', '', 1))
    assert not match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r', '', 0))
    assert not match(Command(''))


# Generated at 2022-06-24 06:51:04.344449
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test')) == u'git rm -r test'

# Generated at 2022-06-24 06:51:06.643609
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('rm hello.txt', '', 'hello.txt')) == 'git rm -r hello.txt'

# Generated at 2022-06-24 06:51:10.901950
# Unit test for function match
def test_match():
    command = Command(' git rm this')
    assert match(command)
    command = Command(' git rm -r')
    assert not match(command)
    assert git_support(Command('git rm this'))
    assert not git_support(Command('rm this'))


# Generated at 2022-06-24 06:51:17.947932
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', '', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert match(Command('git rm -r file.txt', '', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm r file.txt', 'Some error message', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert match(Command('git rm file.txt', '', 'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-24 06:51:21.987483
# Unit test for function match
def test_match():
    """
    test for the function match()
    """
    assert match(Command('git rm toto', 'fatal: not removing \'toto\' recursively without -r\n'))
    assert not match(Command('git rm toto', 'fatal: not removing \'toto\' recursively without -rf\n'))
    assert not match(Command('', ''))
    assert not match(Command('git status', ''))


# Generated at 2022-06-24 06:51:27.755216
# Unit test for function match
def test_match():
    assert git_support(match)(Command('git rm -r .'))
    assert git_support(match)(Command('git rm -rf .'))
    assert not git_support(match)(Command('git add .'))
    assert not git_support(match)(Command('git rm .'))
    assert not git_support(match)(Command('git rmdir .'))


# Generated at 2022-06-24 06:51:34.985044
# Unit test for function match
def test_match():
    assert match(Command('git rm file1.txt',
                         'fatal: not removing \'file1.txt\' recursively without -r',
                         ''))
    assert match(Command('git rm file2.txt',
                         'fatal: not removing \'file2.txt\' recursively without -r',
                         ''))
    assert not match(Command('git rm file1.txt file2.txt',
                             'fatal: not removing \'file2.txt\' recursively without -r',
                             ''))
    assert not match(Command('git rm',
                             'fatal: not removing \'file1.txt\' recursively without -r',
                             ''))
    assert not match(Command('git rm file1.txt', '', ''))



# Generated at 2022-06-24 06:51:37.714881
# Unit test for function match
def test_match():
    assert match(Command('git log', '', '/Users/me/git'))
    assert not match(Command('git log', '', '/Users/me/git',sudo=True))
    assert not match(Command('git log', '', ''))

# Generated at 2022-06-24 06:51:41.612240
# Unit test for function match
def test_match():
    assert not match(Command('git bear', stderr='fatal: not removing \'C\' recursively without -r\n'))
    assert match(Command('git rm foo', stderr='fatal: not removing \'C\' recursively without -r\n'))
    assert not match(Command('git rm foo', stderr='An error has occured'))
    assert not match(Command('git foo rm', stderr='fatal: not removing \'C\' recursively without -r\n'))


# Generated at 2022-06-24 06:51:44.503734
# Unit test for function match
def test_match():
    command = Command("git rm new.txt", "fatal: not removing 'new.txt' recursively without -r\n")
    assert match(command)



# Generated at 2022-06-24 06:51:46.598994
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm noexistfile')
    assert get_new_command(command) == 'git rm -r noexistfile'

# Generated at 2022-06-24 06:51:50.210747
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script=u'git rm -r -r -r -r folder', output=u'fatal: not removing \'folder\' recursively without -r\n')
    assert get_new_command(command) == u'git rm -r -r -r -r -r folder'

# Generated at 2022-06-24 06:51:51.894604
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm data') == 'git rm -r data'



# Generated at 2022-06-24 06:51:55.748866
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm <file>', 'fatal: not removing \
\'<file>\' recursively without -r\nDid you mean \'rm -r\'?')
    assert get_new_command(command).script == 'git rm -r <file>'


enabled_by_default = True

# Generated at 2022-06-24 06:52:03.293347
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command("rm abc") == 'rm -r abc'
	assert get_new_command("git rm abc") == 'git rm -r abc'
	assert get_new_command("git rm --force abc") == 'git rm --force -r abc'
	assert get_new_command("git rm -f abc") == 'git rm -f -r abc'
	assert get_new_command("git rm -fr abc") == 'git rm -fr -r abc'
	assert get_new_command("git rm -rf abc") == 'git rm -rf -r abc'

# Generated at 2022-06-24 06:52:05.671349
# Unit test for function get_new_command
def test_get_new_command():
    assert "git rm -r file" == get_new_command(Command("git rm file", "/file"))

# Generated at 2022-06-24 06:52:07.978972
# Unit test for function match
def test_match():
    assert match(u'git rm tests.py')
    assert not match(u'git rm -r tests/')
    assert not match(u'git rb tests.py')


# Generated at 2022-06-24 06:52:14.834066
# Unit test for function match
def test_match():
    assert match(Command(' rm foo.txt', '', 'fatal: not removing \'foo.txt\' recursively without -r'))
    assert match(Command('git rm foo.txt', '', 'fatal: not removing \'foo.txt\' recursively without -r'))
    assert not match(Command('git rm foo.txt', '', 'fatal: not removing \'foo.txt\' recursively '))


# Generated at 2022-06-24 06:52:18.099583
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo', ''))
    assert not match(Command('ls', ''))

# Generated at 2022-06-24 06:52:22.366401
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file.txt', 'fatal: not removing \' file.txt \' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r file.txt'


# Generated at 2022-06-24 06:52:25.297555
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r filename' == str(get_new_command(Command('git rm filename',
                                                                'fatal: not removing \'filename\' recursively without -r')))


# Generated at 2022-06-24 06:52:32.078740
# Unit test for function match
def test_match():
    print('Unit test for function match')
    assert match(Command(script='git rm -b test',
                         output='fatal: not removing \'test\' recursively without -r'))

    # False cases
    assert not match(Command(script='git rm',
                             output='fatal: pathspec \'\' did not match any files'))
    assert not match(Command(script='git rm -f',
                             output='fatal: pathspec \'\' did not match any files'))
    assert not match(Command(script='git rm -r',
                             output='fatal: pathspec \'\' did not match any files'))



# Generated at 2022-06-24 06:52:35.060647
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r test',
        u'fatal: not removing \'test\' recursively without -r\n')) == 'git rm -r -r test'

# Generated at 2022-06-24 06:52:40.180241
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -r dir', 'fatal: not removing \'dir\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r dir'

    command = Command('rm .*', 'fatal: not removing \'dir\' recursively without -r')
    assert get_new_command(command) == 'rm -r .*'

# Generated at 2022-06-24 06:52:46.350278
# Unit test for function match
def test_match():
    assert match(Command(script='git rm -f',
                         stderr=open(os.devnull, 'w'),
                         output="fatal: not removing 'rm' recursively without -r"))
    assert not match(Command(script='git rm -f',
                             stderr=open(os.devnull, 'w'),
                             output="fatal: not removing 'rm recursively without -r"))


# Generated at 2022-06-24 06:52:52.769523
# Unit test for function match
def test_match():
    assert match(Command('rm test.txt', 'fatal: not removing \'ly.txt\' recursively without -r'))
    assert match(Command('git rm test2.txt', 'fatal: not removing \'ly.txt\' recursively without -r'))
    assert match(Command('git rm test/test.txt', 'fatal: not removing \'test/test.txt\' recursively without -r'))
    assert not match(Command('rm t', ''))
    assert not match(Command('git rm t', ''))


# Generated at 2022-06-24 06:53:01.041866
# Unit test for function match
def test_match():
    # Tests positive case
    command = Command('git rm path/to/file', 'fatal: not removing '
                      '\'path/to/file\' recursively without -r')
    assert match(command)

    # Tests absence of 'rm' in command
    command = Command('git mv path/to/file', 'fatal: not removing '
                      '\'path/to/file\' recursively without -r')
    assert not match(command)

    # Tests output without the given string
    command = Command('git rm path/to/file', 'error: too many arguments')
    assert not match(command)



# Generated at 2022-06-24 06:53:07.095182
# Unit test for function match
def test_match():
    def test_output(input, output):
        assert match(Command(script=input, output=output))

    test_output('git rm -r myfile.txt',
                "fatal: not removing 'myfile.txt' recursively without -r")
    test_output('git rm -r myfile.txt',
                "fatal: not removing 'myfile.txt' recursively without -r\n")
    test_output('git rm -r myfile.txt',
                "fatal: not removing 'test.txt' recursively without -r\n")



# Generated at 2022-06-24 06:53:09.981164
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r test', '', 'fatal: not removing \'test\' recursively without -r')) ==\
        u'git rm -r -r test'

# Generated at 2022-06-24 06:53:11.570221
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm something', '1')) == 'rm -r something'

# Generated at 2022-06-24 06:53:15.439093
# Unit test for function match
def test_match():
    command = '''git rm foo/bar/baz.txt
fatal: not removing 'foo/bar' recursively without -r
'''
    assert(match(Command(script=command)) != None)


# Generated at 2022-06-24 06:53:20.006818
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursively import get_new_command
    assert get_new_command(Command('git rm -f README', 'fatal: not removing \'README\' recursively without -r', '', 1)) == u'git rm -f -r README'

# Generated at 2022-06-24 06:53:23.277166
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r foo bar') == 'git rm -r -r foo bar'
    assert get_new_command('git rm foo bar') == 'git rm -r foo bar'

# Generated at 2022-06-24 06:53:26.518793
# Unit test for function match
def test_match():
	test= ["git rm folder_name"]
	response=["fatal: not removing 'folder_name' recursively without -r"]
	command=Command(test,response)
	assert match(command)


# Generated at 2022-06-24 06:53:30.433459
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm foo',
                      stdout=("fatal: not removing 'foo' recursively "
                              "without -r\n"))
    assert get_new_command(command) == "git rm -r foo"

# Generated at 2022-06-24 06:53:32.194640
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r file' == get_new_command(u'git rm file')

# Generated at 2022-06-24 06:53:35.402846
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = u'git rm -h',
                      output = u"fatal: not removing '-h' recursively without -r\n")
    assert u'git rm -r -h' == get_new_command(command)

# Generated at 2022-06-24 06:53:36.754175
# Unit test for function match
def test_match():
    assert match(Command('rm example.txt', '', '<some error about recursively without -r'))


# Generated at 2022-06-24 06:53:41.314495
# Unit test for function match
def test_match():
    assert match(Command('git rm -a', '', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm -a', '', 'fatal: not removing \'file.txt\''))


# Generated at 2022-06-24 06:53:43.946949
# Unit test for function match
def test_match():
    assert_true(match(Command('git rm foo',
    """fatal: not removing 'foo' recursively without -r
    """)))


# Generated at 2022-06-24 06:53:47.389321
# Unit test for function match
def test_match():
    assert match(Command(script='git rm -rf', output="fatal: not removing 'A' recursively without -r"))
    assert not match(Command(script='git rm -rf', output="usage: git rm [options] <file>..."))

# Generated at 2022-06-24 06:53:54.699372
# Unit test for function match
def test_match():
    assert match(Command('rm -r test', 'fatal: not removing \'test\' recursively without -r'))
    assert match(Command('rm -rf test', 'fatal: not removing \'test\' recursively without -r'))
    assert match(Command('rm test', 'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('rm test', 'fatal: not removing \'test\' recursively without -r', '', 1))
    assert not match(Command('rm test', 'something else with rm'))


# Generated at 2022-06-24 06:53:57.170098
# Unit test for function match
def test_match():
    test_command = "git rm test.txt"
    output = "fatal: not removing 'test.txt' recursively without -r\r\n"
    assert match(Command(test_command, output))

# Generated at 2022-06-24 06:54:00.371242
# Unit test for function match
def test_match():
    command_check = Command('git rm -r @ --cached',
                            'Username for \'https://github.com\': \nfatal: not removing \'@\' recursively without -r\n')
    assert match(command_check)


# Generated at 2022-06-24 06:54:02.899862
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm nohup.out')
    new_command = get_new_command(command)
    assert 'git rm -r' in new_command

# Generated at 2022-06-24 06:54:07.164435
# Unit test for function match
def test_match():
    assert match(Command('rm README.md', '', 'fatal: not removing \'README.md\' recursively without -r\n',''))
    assert not match(Command('git checkout master', '', '', ''))


# Generated at 2022-06-24 06:54:10.301694
# Unit test for function match
def test_match():
    assert match(Command('git rm README.md', ''))
    assert not match(Command('git rm README.md', '', error=127))
    assert not match(Command('rm file.txt', ''))


# Generated at 2022-06-24 06:54:12.109290
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm --cached file') == 'git rm -r --cached file'
    assert get_new_command('git rm lib') == 'git rm -r lib'

# Generated at 2022-06-24 06:54:14.907404
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf folder/file.txt', 'fatal: not removing \'folder/file.txt\' recursively without -r',
                        ''))


# Generated at 2022-06-24 06:54:17.990138
# Unit test for function match
def test_match():
    assert match('git rm file0 file1 file2 file3 file4 file5 file6')
    assert not match('git rm file0 file1 file2 file3 file4 file5')


# Generated at 2022-06-24 06:54:20.319248
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -r', stdout='fatal: not removing ' +
                      "'path/to/a_folder' recursively without -r")
    assert get_new_command(command) == 'git rm -r -r'

# Generated at 2022-06-24 06:54:25.784103
# Unit test for function get_new_command
def test_get_new_command():
    script = u"cd path/to/directory/ && git rm -r repo/dir/dir_2"
    output = u"fatal: not removing 'repo/dir/dir_2' recursively without -r"
    new_command = get_new_command(FakeCommand(script, output))
    assert new_command == script[:script.find('rm') + len('rm')] + ' -r' + script[script.find('rm') + len('rm'):]

# Generated at 2022-06-24 06:54:30.344684
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f a b', 'fatal: not removing \'a\' recursively without -r\nfatal: not removing \'b\' recursively without -r')
    assert get_new_command(command) == 'git rm -f -r a b'

# Generated at 2022-06-24 06:54:32.384319
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm wtf')
    assert get_new_command(command) == 'git rm -r wtf'



# Generated at 2022-06-24 06:54:35.631566
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file_name', 'fatal: not removing '\
                                   '\'file_name\' recursively without -r'))\
                                   == 'git -r rm file_name'

# Generated at 2022-06-24 06:54:38.400177
# Unit test for function match
def test_match():
    assert match(Command('rm  -f README.md'))
    assert not match(Command('Rm  -f README.md'))
    assert not match(Command('rm --recursive -f README.md'))



# Generated at 2022-06-24 06:54:44.576680
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git branch -avvv -a aaa bbb',
                       'fatal: not removing \'a\' recursively without -r')
    command2 = Command('git rm -r aaa bbb',
                       'fatal: not removing \'a\' recursively without -r')
    assert get_new_command(command1) == 'git branch -avvv -a -r aaa bbb'
    assert get_new_command(command2) == 'git rm -r aaa bbb'



# Generated at 2022-06-24 06:54:47.215690
# Unit test for function get_new_command
def test_get_new_command():
	command = Command('git rm -rf')
	assert 'git rm -rf -r' == get_new_command(command)

# Generated at 2022-06-24 06:54:52.388428
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git rm --cached foo', 'fatal: not removing \'foo\' recursively without -r')) == 'git rm -r --cached foo'
    assert get_new_command(
        Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')) == 'git rm -r foo'
    assert get_new_command(
        Command('git rm foo/bar', 'fatal: not removing \'foo/bar\' recursively without -r')) == 'git rm -r foo/bar'

# Generated at 2022-06-24 06:54:56.198719
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1, None)) == 'git rm -r file'

# Generated at 2022-06-24 06:54:59.181889
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', 'fatal: not removing \'dir/\''
        ' recursively without -r use \'--cached\' instead')) == 'git rm -r -r'

# Generated at 2022-06-24 06:55:02.595702
# Unit test for function get_new_command
def test_get_new_command():
    old_command="git rm 'file.txt'"
    new_command=get_new_command(Command(script=old_command, output="fatal: not removing 'file.txt' recursively without -r"))
    asse

# Generated at 2022-06-24 06:55:11.616136
# Unit test for function get_new_command
def test_get_new_command():
    '''Test if get_new_command does the right thing'''
    command = Command('rm doc/howto/quickstart.rst', 'fatal: not removing \'doc/howto/quickstart.rst\' recursively without -r')
    assert get_new_command(command) == 'git rm -r doc/howto/quickstart.rst'
    command = Command('rm -df doc/howto/quickstart.rst', 'fatal: not removing \'doc/howto/quickstart.rst\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -df doc/howto/quickstart.rst'

# Generated at 2022-06-24 06:55:14.370436
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test', 'fatal: not removing \'test\' recursively without -r', '')
    assert get_new_command(command) == 'git rm -r test'

# Generated at 2022-06-24 06:55:17.030188
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f file.txt', 'fatal: not removing \'file.txt\' recursively without -r')
    assert get_new_command(command) == command.script + ' -r'
    

# Generated at 2022-06-24 06:55:22.299941
# Unit test for function match
def test_match():
    command = 'git rm a b c'
    assert match(command)
    command = 'git rm a'
    assert match(command)
    command = 'git rm -r a'
    assert not match(command)
    command = 'git rm'
    assert not match(command)
    command = 'git remove'
    assert not match(command)


# Generated at 2022-06-24 06:55:31.462807
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'
    assert get_new_command('git rm file1 file2 file3') == 'git rm -r file1 file2 file3'
    assert get_new_command('git rm file1 file2 file3') == 'git rm -r file1 file2 file3'
    assert get_new_command('git rm file1 file2 file3 ') == 'git rm -r file1 file2 file3 '
    assert get_new_command('git rm file1 file2 file3 ') == 'git rm -r file1 file2 file3 '
    assert get_new_command('git rm -f file') == 'git rm -f -r file'

# Generated at 2022-06-24 06:55:33.340240
# Unit test for function match
def test_match():
    assert match(Command('git rm a b', 'fatal: not removing \'a\' recursively without -r\n'))



# Generated at 2022-06-24 06:55:36.327957
# Unit test for function match
def test_match():
    assert match(Command('rm file1 file2 file3', '', '')) is True
    assert match(Command('rm', '', '')) is False


# Generated at 2022-06-24 06:55:41.794911
# Unit test for function match
def test_match():
    # Case 1: rm argument raises error
    assert (match(Command('rm -r a/b/c', "fatal: not removing 'a/b/c' recursively without -r")) != None)

    # Case 2: rm argument does not raise error
    assert match(Command('rm -r a/b/c', '')) == None

    # Case 3: rm missing argument
    assert match(Command('rm', '')) == None

# Generated at 2022-06-24 06:55:42.868044
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('rm -rf src/AppBundle') == 'rm -rf -r src/AppBundle'

# Generated at 2022-06-24 06:55:47.552969
# Unit test for function match
def test_match():
    lst = [ "git rm -r --cached a ,,, b",
            "git rm -r --cached a"
            ]
    outcomes = [ False, True ]
    for idx, val in enumerate(lst):
        assert (match(val) == outcomes[idx])


# Generated at 2022-06-24 06:55:50.936559
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf new_file', 'fatal: not removing \'new_file\' recursively without -r')

    assert get_new_command(command) == 'git rm -rf -r new_file'

# Generated at 2022-06-24 06:55:55.377872
# Unit test for function match
def test_match():
    assert match(command.Command('git rm file.txt',
                                 'fatal: not removing \'file.txt\' recursively without -r\n'))
    assert not match(command.Command('git rm -r file.txt',
                                     'fatal: not removing \'file.txt\' recursively without -r\n'))


# Generated at 2022-06-24 06:55:58.497787
# Unit test for function match
def test_match():
    assert match(Command(script='git rm file',
                         output="fatal: not removing './file' recursively without -r"))
    assert not match(Command(script='git rm foo',
                             output="fatal: pathspec 'foo' did not match any files"))


# Generated at 2022-06-24 06:55:59.926895
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-24 06:56:04.010768
# Unit test for function match
def test_match():
    # Test the case when the error message shows up
    assert(match(Command('git rm -d "a/b/"',
                         'fatal: not removing \'a/b/c/\' recursively without -r\n',
                         '', 1)) == True)

    # Test the case when the error message doesn't show up
    assert(match(Command('git rm -d "a/b/"',
                         '', '', 1)) == False)

# Generated at 2022-06-24 06:56:09.040047
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -rf abc.txt', stderr='fatal: not removing \'abc.txt/def.txt\' recursively without -r',)
    assert get_new_command(command) == 'git rm -rf -r abc.txt'



# Generated at 2022-06-24 06:56:12.879761
# Unit test for function match
def test_match():
    assert match(Command('git rm test', '',
        r"fatal: not removing 'test/test.txt' recursively without -r"))
    assert not match(Command('git rm test', '', r''))
