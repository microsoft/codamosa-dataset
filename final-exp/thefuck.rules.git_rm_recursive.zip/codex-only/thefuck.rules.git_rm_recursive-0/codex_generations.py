

# Generated at 2022-06-24 06:46:12.897264
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -f test.txt', 'fatal: not removing \'test.txt\' recursively without -r')
    assert get_new_command(command) == 'rm -r -f test.txt'

# Generated at 2022-06-24 06:46:14.223239
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm file") == "git rm -r file"

# Generated at 2022-06-24 06:46:16.709345
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm', output="fatal: not removing 'file.py' recursively without -r")) == 'git rm -r'

# Generated at 2022-06-24 06:46:18.630263
# Unit test for function match
def test_match():
    assert match(Command('git rm second.py',
                         'fatal: not removing ''second.py'' recursively without -r')
                 )


# Generated at 2022-06-24 06:46:23.898765
# Unit test for function match
def test_match():
    """ Unit test for function match
    """
    assert match(Command('git rm README.rst', 'fatal: not removing \
            \'README.rst\' recursively without -r'))
    assert not match(Command('git rm README.rst', ''))
    assert not match(Command('git remote', 'fatal: not removing \
            \'README.rst\' recursively without -r'))


# Generated at 2022-06-24 06:46:28.277456
# Unit test for function get_new_command
def test_get_new_command():
    command_string = "git rm file"
    command = Command(command_string, "fatal: not removing 'file' recursively without -r")
    expected = "git rm -r file"
    actual = get_new_command(command)
    assert_equals(expected, actual)

# Generated at 2022-06-24 06:46:31.251296
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git rm file'
    command = Command(script, 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == "git rm -r file"

# Generated at 2022-06-24 06:46:40.207969
# Unit test for function match
def test_match():
    assert match(Command('', 'error: pathspec \'file.txt\' did not match any file(s) known to git.\n'
                         'error: pathspec \'file.txt\' did not match any file(s) known to git.\n'
                         'fatal: not removing \'file.txt\' recursively without -r\n'))
    assert not match(Command('', 'error: pathspec \'file.txt\' did not match any file(s) known to git.\n'
                             'error: pathspec \'file.txt\' did not match any file(s) known to git.\n'))
    assert not match(Command('', 'fatal: not removing \'file.txt\' recursively without -r\n'))



# Generated at 2022-06-24 06:46:44.393997
# Unit test for function match
def test_match():
    assert match(Command('git rm -r', "fatal: not removing 'path' recursively without -r"))
    assert not match(Command('git rm ', "fatal: not removing 'path' recursively without -r"))
    assert not match(Command('git rms ', "fatal: not removing 'path' recursively without -r"))

# Generated at 2022-06-24 06:46:48.054750
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(' git rm -r "file 1.txt" "file 2.txt"', 'fatal: not removing \'file 1.txt\' recursively without -r')
    assert(get_new_command(command) == ' git rm -r "file 1.txt" "file 2.txt"')

# Generated at 2022-06-24 06:46:50.754169
# Unit test for function match
def test_match():
    command = Command('git rm src/test.py', 'fatal: not removing \'src/test.py\' recursively without -r')
    assert match(command)


# Generated at 2022-06-24 06:46:53.008311
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -df *')
    assert get_new_command(command) == "git rm -df -r *"

# Generated at 2022-06-24 06:46:56.356988
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    from thefuck.specific.git import match
    command = Command('git rm -rf')
    assert match(command)
    assert "rm -rf" in get_new_command(command)

# Generated at 2022-06-24 06:46:58.702157
# Unit test for function match
def test_match():
    command = Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r')
    assert match(command)



# Generated at 2022-06-24 06:47:00.519008
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm', '', 'error: not removing ...')) == 'git rm -r'

# Generated at 2022-06-24 06:47:03.160063
# Unit test for function match
def test_match():
    assert match(Command('git rm -r asdf/asdf', '', None))
    assert not match(Command('brew rm -r asdf', '', None))



# Generated at 2022-06-24 06:47:07.514774
# Unit test for function get_new_command
def test_get_new_command():
    command_script = ' git rm -f new_file'
    command_output = 'fatal: not removing \'new_file\' recursively without -r'
    command = Command(script=command_script, output=command_output)
    assert get_new_command(command) == 'git rm -r -f new_file'


# Generated at 2022-06-24 06:47:12.671711
# Unit test for function match
def test_match():
    assert match(Command('rm foo',
                         'fatal: not removing \'foo\' recursively without -r\n',
                         ''))
    assert not match(Command('rm foo', '', ''))
    assert not match(Command('rm foo',
                             'fatal: not removing \'foo\' recursively without\
-r\n',
                             ''))
    assert not match(Command('rm foo',
                             '',
                             'fatal: not removing \'foo\' recursively without\
-r\n'))


# Generated at 2022-06-24 06:47:14.507073
# Unit test for function get_new_command
def test_get_new_command():
    f = get_new_command
    assert f(Command('git rm file/ sub/ -r', '')) == 'git rm -r file/ sub/'
    assert f(Command('git rm file/ sub/ file2/ -r', '')) == 'git rm -r file/ sub/ file2/'

# Generated at 2022-06-24 06:47:17.298948
# Unit test for function get_new_command
def test_get_new_command():
    assert ('rm -r file1 file2 file3'
            == get_new_command('rm file1 file2 file3'))

# Generated at 2022-06-24 06:47:20.059771
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'got: fatal: not removing \'file\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-24 06:47:22.687703
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r test.txt'

# Generated at 2022-06-24 06:47:25.386553
# Unit test for function match
def test_match():
    command = Command('git rm test', '', 'fatal: not removing \'test\' recursively without -r')
    assert match(command)


# Generated at 2022-06-24 06:47:29.953796
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='rm file',
                                   stderr='error: pathspec \'file\' did not match any file(s) known to git.\n'
                                          "fatal: not removing '"
                                          'file'
                                          "' recursively without -r")) == 'git rm -r file'

# Generated at 2022-06-24 06:47:33.039776
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm "filename"', "fatal: not removing 'filename' recursively without -r")
    assert get_new_command(command) == 'git rm -r "filename"'

# Generated at 2022-06-24 06:47:34.629302
# Unit test for function get_new_command
def test_get_new_command():
    # Correct new command
    command = Command('git rm -r test')
    asser

# Generated at 2022-06-24 06:47:43.433474
# Unit test for function match
def test_match():
    """
    test if match() recognizes a git error message and
    returns true if it is
    """
    output = ''' jesse@ThinkPad-T520  ~/projects/git-repos/git-repos.git   master ●  git rm github.com/heroku/heroku-buildpack-ruby.git

fatal: not removing 'github.com/heroku/heroku-buildpack-ruby.git' recursively without -r

'''
    assert(match(Command('fatal: not removing', output, '', prefix=u'jesse@ThinkPad-T520  ~/projects/git-repos/git-repos.git   master ●  ')) == True)


# Generated at 2022-06-24 06:47:46.059613
# Unit test for function get_new_command
def test_get_new_command():

    command = Command('git rm -r folder', '')
    assert(match(command))

    new_command = get_new_command(command)
    assert(new_command == u'git rm -r -r folder')

# Generated at 2022-06-24 06:47:47.920804
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf filename.txt',
                         'fatal: not removing \'filename.txt\' recursively without -r'))
                       

# Generated at 2022-06-24 06:47:49.593460
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', 'rm', 'my_file']
    assert get_new_command(command_parts) == 'git rm -r my_file'

# Generated at 2022-06-24 06:47:52.954642
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm test') == 'git rm -r test'
    assert get_new_command('git rm test1 test2') == 'git rm -r test1 test2'
    assert get_new_command('git rm test1 test2 -f') == 'git rm -f -r test1 test2'
    assert get_new_command('git rm -f test') == 'git rm -r -f test'


# Generated at 2022-06-24 06:47:59.262111
# Unit test for function match
def test_match():
    assert match(
        Command('git rm -r somefile',
                'fatal: not removing \'somefile/sub-file\' recursively without -r',
                ''))
    assert not match(
        Command('git rm -r somefile',
                'fatal: not removing \'somefile\' recursively without -r',
                ''))
    assert not match(
        Command('git rm -r somefile',
                'fatal: not removing \'somefile\' recursively without -r',
                ''))
    assert not match(
        Command('git rm -r somefile',
                'fatal: not removing \'somefile/sub-file\' recursively without -r',
                ''))


# Generated at 2022-06-24 06:48:08.883435
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file')
    assert get_new_command(command) in ['git rm -r file']
    command = Command('git rm three files')
    assert get_new_command(command) in ['git rm -r three files']
    command = Command('git rm -f file')
    assert get_new_command(command) in ['git rm -rf file']
    command = Command('git rm -f three files')
    assert get_new_command(command) in ['git rm -rf three files']
    command = Command('git rm -f')
    assert get_new_command(command) in ['git rm -rf']
    command = Command('git rm three -f files')
    assert get_new_command(command) in ['git rm three -rf files']

# Generated at 2022-06-24 06:48:17.976235
# Unit test for function match
def test_match():
    assert match(Command('git branch --set-upstream-to=origin/master master',
                         'error: pathspec \'master\' did not match any file(s) known to git.\n'))
    assert match(Command('git branch --set-upstream-to=origin/master master',
                         'fatal: Not a valid object name master.\n'))

    assert not match(Command('git branch --set-upstream-to=origin/master master',
                             'fatal: Not a valid object name master.'))
    assert not match(Command('git branch --set-upstream-to=origin/master master',
                             'master.\n'))

# Generated at 2022-06-24 06:48:22.536961
# Unit test for function match
def test_match():
    print(get_new_command(Command('git rm test_match.txt', '', 'fatal: not removing \'test_match.txt\' recursively without -r')))
    assert match(Command('git rm test_match.txt', '', 'fatal: not removing \'test_match.txt\' recursively without -r'))
    assert not match(Command('git rm test_match.txt', '', 'git: \'rm\' is not a git command. See \'git --help\''))
    assert not match(Command('rm test_match.txt', '', 'fatal: not removing \'test_match.txt\' recursively without -r'))


# Generated at 2022-06-24 06:48:26.648201
# Unit test for function match
def test_match():
    assert match(Command('git rm -r', 'fatal: not removing \'a/b/c\' recursively without -r'))
    assert not match(Command('git rm', 'fatal: not removing \'a/b/c\' recursively without -r'))



# Generated at 2022-06-24 06:48:30.162894
# Unit test for function match
def test_match():
    assert match(Command('git branch abc',
             output="fatal: not removing 'abc' recursively without -r"))
    assert not match(Command('git branch',
                 output="fatal: not removing 'abc' recursively without -r"))


# Generated at 2022-06-24 06:48:34.461367
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(' rm myfile', 'fatal: not removing \'myfile\' recursively without -r')
    assert(get_new_command(command) == 'rm -r myfile')
    command = Command(' git rm myfile', 'fatal: not removing \'myfile\' recursively without -r')
    assert(get_new_command(command) == 'git rm -r myfile')

# Generated at 2022-06-24 06:48:38.412794
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {
        'script_parts': ['git', 'rm', 'wrong_file']
    })()
    assert (get_new_command(command)
            == 'git -r rm wrong_file')

# Generated at 2022-06-24 06:48:43.230387
# Unit test for function match
def test_match():
	# Display messages if error occurs while testing match function
	# In order to check whether match function works properly,
	# give a command with error message which is caused by 'rm' command
	# and then check the result
	result = match(Command('rm test.txt'));
	assert (result == False)


# Generated at 2022-06-24 06:48:46.440230
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm new') == 'git rm -r new'
    assert get_new_command('git rm -f new') == 'git rm -f -r new'
    assert get_new_command('git rm -rf new') == 'git rm -rf -r new'

# Generated at 2022-06-24 06:48:49.505226
# Unit test for function match
def test_match():
    assert match(Command("git rm file", stderr="""fatal: not removing 'file' recursively without -r\n""", script="git rm file", stdout="""fatal: not removing 'file' recursively without -r\n"""))
    assert not match(Command("git add .", script="git add ."))


# Generated at 2022-06-24 06:48:51.748070
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r')
    new_command = get_new_command(command)
    assert new_command == 'git rm -fr'

# Generated at 2022-06-24 06:49:01.944421
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('vim -r')
    new_command = get_new_command(command)
    assert new_command == 'vim -r'
    
    command = Command('git rm -r')
    new_command = get_new_command(command)
    assert new_command == 'git rm -r -r'
    
    command = Command('vim foo bar')
    new_command = get_new_command(command)
    assert new_command is None
    
    command = Command('git rm foo bar')
    new_command = get_new_command(command)
    assert new_command is None
    
    command = Command('git rm foo bar', 'fatal: not removing \'foo\' recursively without -r')
    new_command = get_new_command(command)

# Generated at 2022-06-24 06:49:04.927898
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r file' == get_new_command("git rm file")
    assert u'git rm -r --cached stuff' == get_new_command("git rm --cached stuff")


# Generated at 2022-06-24 06:49:07.560185
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r a',
                      u"fatal: not removing 'a' recursively without -r")
    assert get_new_command(command) == u'git rm -r a'

# Generated at 2022-06-24 06:49:13.880763
# Unit test for function match
def test_match():

    # Should match
    assert match(Command("git rm .", "fatal: not removing '.' recursively without -r -f")) == True
    assert match(Command("git rm -n .", "fatal: not removing '.' recursively without -r -f")) == True
    assert match(Command("git rm .", "fatal: not removing '.' recursively without -r")) == True

    # Should not match
    assert match(Command("git foo .", "fatal: not removing '.' recursively without -r")) == False
    assert match(Command("git rm .", "fatal: not removing '.' recursively without -r", "ERROR")) == False
    assert match(Command("git rm .", "fatal: not removing '.' recursively without -r -f -f")) == False



# Generated at 2022-06-24 06:49:19.293728
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_fix_recursive_removal import get_new_command
    command = "git rm -rf badDir"
    output = "fatal: not removing 'badDir' recursively without -r"
    new_command = "git rm -rf -r badDir"
    assert get_new_command(Mock(script = command, output = output)) == new_command

# Generated at 2022-06-24 06:49:22.020689
# Unit test for function match
def test_match():
    assert match(command=Command('git rm foo'))
    assert not match(command=Command('git commit -m "Fixes #123'))
    assert not match(command=Command('git remote -v'))


# Generated at 2022-06-24 06:49:25.815798
# Unit test for function match
def test_match():
    assert match(Command('git rm foo/bar.py', 'fatal: not removing \'foo/bar.py\' recursively without -r'))
    assert match(Command('git rm bar.py', 'fatal: not removing \'bar.py\' recursively without -r'))
    assert not match(Command('git rm bar.py', ''))
    assert not match(Command('git foobar', ''))


# Generated at 2022-06-24 06:49:28.096903
# Unit test for function match
def test_match():
    assert match('git rm fox')
    assert match('git rm fox bar')
    assert match('git rm -r fox bar') is False
    assert match('git rm -a') is False



# Generated at 2022-06-24 06:49:30.991499
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm test_file',
                                   stdout=u'fatal: not removing \'test_file\' recursively without -r')) == 'git rm -r test_file'

# Generated at 2022-06-24 06:49:33.676445
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', '')) == 'git rm -r -r'

# Generated at 2022-06-24 06:49:39.907565
# Unit test for function match
def test_match():
    assert match(Command('git rm -f file_a.txt',
                         'fatal: not removing \'./file_a.txt\' recursively without -r', True))
    assert not match(Command('git rm -f file_a.txt',
                         'fatal: not removing \'./file_a.txt\' recursively without -r', False))
    assert not match(Command('git rm -f file_a.txt', '', True))

# Generated at 2022-06-24 06:49:49.829065
# Unit test for function match
def test_match():
    script1 = 'git add -A'
    script2 = 'git rm -rf dirname'
    script3 = 'git rm -r dirname'
    script4 = 'git rm dirname'
    script5 = 'git rm dirname'
    script6 = 'git rm -rf dirname'

    output1 = '''fatal: not removing '''
    output2 = '''fatal: not removing '''
    output3 = '''fatal: not removing '''
    output4 = '''error: the following file has staged content differing from both the file and the HEAD:
	dirname
(use -f to force removal)'''
    output5 = '''fatal: not removing '''
    output6 = '''fatal: not removing '''

    command1 = Command(script1, output1)
    command2 = Command

# Generated at 2022-06-24 06:49:52.888495
# Unit test for function match
def test_match():
	output = "fatal: not removing 'submodule/subsubmodule' recursively without -r"
	command = Command('git rm', output)
	assert match(command)


# Generated at 2022-06-24 06:49:55.822697
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git rm filename')
    assert 'git rm -r' in get_new_command(command1)
    command2 = Command('git rm -r filename')
    assert 'git rm' in get_new_command(command2)

# Generated at 2022-06-24 06:50:03.564735
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_file import get_new_command
    command = type('Cmd', (object,), {
        'script_parts': ['git', 'rm', 'chrome/common/importer/ProfileWriter.h'],
        'output': "fatal: not removing 'chrome/common/importer/ProfileWriter.h' recursively without -r",
        'script': "git rm chrome/common/importer/ProfileWriter.h\nfatal: not removing 'chrome/common/importer/ProfileWriter.h' recursively without -r"
        })
    assert get_new_command(command) == 'git rm -r chrome/common/importer/ProfileWriter.h'

# Generated at 2022-06-24 06:50:05.743427
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git svn rm -r')) == 'git svn rm -r -r'

# Generated at 2022-06-24 06:50:07.185500
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')) == 'git rm -r foo'

# Generated at 2022-06-24 06:50:09.710793
# Unit test for function match
def test_match():
    assert match(Command('git rm fuck', '', '', 1, None))
    assert not match(Command('git rm', '', '', 1, None))
    assert match(Command('ls', '', '', 1, None))


# Generated at 2022-06-24 06:50:19.656131
# Unit test for function match
def test_match():
    # Check if git rm and fatal error
    assert match(Command('git rm -r abc', 'fatal: not removing \'abc\' recursively without -r'))
    assert match(Command('git rm -r abc def', 'fatal: not removing \'abc\' recursively without -r'))
    assert match(Command('git rm -r /abc', 'fatal: not removing \'/abc\' recursively without -r'))
    assert match(Command('git rm -r \\abc', 'fatal: not removing \'\\abc\' recursively without -r'))
    assert not match(Command('git rm -r abc', 'fatal: not removing \'abc\' recursively without -r'))



# Generated at 2022-06-24 06:50:27.798556
# Unit test for function match
def test_match():
    assert match(Command(script='git rm dir', output='fatal: not removing '
              + "'dir' recursively without -r"))
    assert not match(Command(script='git branch -r', output='origin/fatal: '
               + 'not removing \'dir\' recursively without -r'))
    assert not match(Command(script='git status', output='fatal: not removing '
               + '\'dir\' recursively without -r'))



# Generated at 2022-06-24 06:50:34.218042
# Unit test for function match
def test_match():
    assert match(Command('git rm',
                         "fatal: not removing 'foo/' recursively without -r",
                         ''))
    assert not match(Command('git rm',
                             "fatal: not removing 'foo/' recursively without -r",
                             '',
                             '',
                             '/bin/git'))
    assert not match(Command('git rm',
                             '',
                             ''))
    assert not match(Command('rm',
                             "fatal: not removing 'foo/' recursively without -r",
                             ''))
    assert not match(Command('git rm',
                             'fatal: not removing "" recursively without -r',
                             ''))

# Generated at 2022-06-24 06:50:37.649881
# Unit test for function match
def test_match():
    assert match(Command('git rm *.txt', 'fatal: not removing \'/home/me/*.txt\' recursively without -r'))


# Generated at 2022-06-24 06:50:41.104396
# Unit test for function get_new_command
def test_get_new_command():
    command_output = u"""
fatal: not removing 'index.html' recursively without -r
"""
    command = Command('git rm index.html', command_output)
    assert get_new_command(command) == 'git rm -r index.html'

# Generated at 2022-06-24 06:50:44.979329
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm a_directory_without_untracking",
                      "fatal: not removing 'a_directory_without_untracking' recursively without -r")
    assert get_new_command(command) == "git rm -r a_directory_without_untracking"

# Generated at 2022-06-24 06:50:47.217462
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm iamdir --cached",
                      "fatal: not removing 'iamdir' recursively without -r")
    assert get_new_command(command) == "git rm -r iamdir --cached"

# Generated at 2022-06-24 06:50:49.587239
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git rm -r dir'
    command = Command(script, "fatal: not removing 'dir' recursively without -r", '')
    assert match(command)
    assert get_new_command(command) == script

# Generated at 2022-06-24 06:50:55.521097
# Unit test for function match
def test_match():
    # Test command.script = git rm file.txt
    # return False
    command = Command('git rm file.txt', 'error: ')
    assert not match(command)

    # Test command.script = git rm file.txt
    # return True
    command = Command('git rm file.txt', 'fatal: not removing "file.txt" recursively without -r')
    assert match(command)


# Generated at 2022-06-24 06:51:02.738444
# Unit test for function match
def test_match():
    assert match(Command('foo rm . -rf', "fatal: not removing '.' recursively without -r"))
    assert match(Command('foo rm . -rf', "fatal: not removing '../' recursively without -r"))
    assert match(Command('foo rm . -rf', "fatal: not removing '..' recursively without -r"))
    assert not match(Command('foo rm -rf .', "fatal: not removing '.' recursively without -r"))
    assert not match(Command('foo rm -rf a', "fatal: not removing 'a' recursively without -r"))
    assert not match(Command('foo rm -rf a', "fatal: not removing 'aa' recursively without -r"))


# Generated at 2022-06-24 06:51:10.384828
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursive import get_new_command
    command = Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')
    assert get_new_command(command) == 'git rm -r foo'
    assert get_new_command(Command('git rm foo.txt', 'fatal: not removing \'foo.txt\' recursively without -r')) == 'git rm -r foo.txt'
    assert get_new_command(Command('git rm foo bar', 'fatal: not removing \'bar\' recursively without -r')) == 'git rm -r foo bar'
    assert get_new_command(Command('git rm -f foo', 'fatal: not removing \'foo\' recursively without -r')) == 'git rm -f -r foo'

#

# Generated at 2022-06-24 06:51:10.987791
# Unit test for function match
def test_match():
    assert match(command)

# Generated at 2022-06-24 06:51:13.980095
# Unit test for function match
def test_match():
    assert match(Command('git rm dir1/dir2/file'))
    assert not match(Command('git status'))
    assert not match(Command('rm dir1/dir2/file'))


# Generated at 2022-06-24 06:51:16.787280
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(' git rm directory', u'''
        fatal: not removing 'directory' recursively without -r''')
    assert get_new_command(command) == u'git rm -r directory'

# Generated at 2022-06-24 06:51:19.486126
# Unit test for function match
def test_match():
    cmds = ("git stash save -p",)
    for cmd in cmds:
        assert match(Command(cmd, "fatal: not removing 'zzz' recursively without -r", ""))

# Generated at 2022-06-24 06:51:23.496908
# Unit test for function match
def test_match():
    assert match(Command('git rm -r /home/usr/file.py', '', 'fatal: not removing \'/home/usr/file.py\' recursively without -r'))
    assert not match(Command('rm -r /home/usr/file.py', '', 'fatal: not removing \'/home/usr/file.py\' recursively without -r'))


# Generated at 2022-06-24 06:51:25.965672
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.py', ''))
    assert not match(Command('git', ''))

# Generated at 2022-06-24 06:51:29.136917
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test', 'fatal: not removing \'test\' recursively without -r')
    new_command = get_new_command(command)
    assert u'git rm -r test' == new_command

# Generated at 2022-06-24 06:51:35.550607
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', ''))
    assert not match(Command('git rm foo', ''))
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r'))
    assert match(Command('git rm -h', ''))
    assert not match(Command('git rm -h', 'fatal: not removing \'foo\' recursively without -r'))

# Generated at 2022-06-24 06:51:37.007155
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r first')
    assert(get_new_command(command) == "git rm -r -r first")

# Generated at 2022-06-24 06:51:41.328079
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f test.txt',
                      'fatal: not removing \'test.txt\' recursively without -r\n', '', 1)
    assert_equals(get_new_command(command), 'git rm -r -f test.txt')

# Generated at 2022-06-24 06:51:44.541270
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm A')) == 'git rm -r A'
    assert get_new_command(Command('git rm -r A')) == 'git rm -r -r A'

# Generated at 2022-06-24 06:51:51.211717
# Unit test for function match
def test_match():
    # Test function match
    # Check when file doesn't exist
    result_1 = {'script': "git rm test.txt", 'output': "fatal: not removing 'test.txt' recursively without -r"}
    assert match(result_1) == True
    # Check when file exists
    result_2 = {'script': "git rm src/test.txt", 'output': "fatal: not removing 'src/test.txt' recursively without -r"}
    assert match(result_2) == True


# Generated at 2022-06-24 06:51:56.979875
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r test'
    assert get_new_command(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r test'
    assert get_new_command(Command('git rm -rf test', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -rf test'

# Generated at 2022-06-24 06:52:00.441816
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-24 06:52:08.205930
# Unit test for function match
def test_match():
    match_tests = [
        "git rm file.py",
        "git rm -rf file.py",
        "rm -rf file.py  \n file.py "
    ]

    for test in match_tests:
        assert match(Command(script=test, output='fatal: not removing \'file.py\' recursively without -r'))

    no_match_tests = [
        "git remote -v",
        "git rm -rf file.py",
        "rm -rf file.py"
    ]

    for test in no_match_tests:
        assert not match(Command(script=test, output='fatal: not removing \'file.py\' recursively without -r'))

test_match()

# Generated at 2022-06-24 06:52:11.424767
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('rm dir/')) == 'git rm -r dir/'


# Generated at 2022-06-24 06:52:16.552637
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm filename', 'error: not removing recursively without -r', 'git')) == u'git rm -r filename'
    assert get_new_command(Command('git rm \'filename\'', 'error: not removing recursively without -r', 'git')) == u'git rm -r \'filename\''


# Generated at 2022-06-24 06:52:18.647481
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = 'git rm -rf --cached docs'.split()
    index = command_parts.index('rm') + 1
    command_parts.insert(index, '-r')
    assert ' '.join(command_parts) == u'git rm -rf -r --cached docs'

# Generated at 2022-06-24 06:52:21.830896
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command(Command('git rm -f files', '')), 'git rm -f -r files')

# Generated at 2022-06-24 06:52:23.754563
# Unit test for function match
def test_match():
    assert match(Command('git rm -f test'))
    assert not match(Command('cd my_repo'))



# Generated at 2022-06-24 06:52:25.616631
# Unit test for function match
def test_match():
    assert match(Command('git rm'))


# Generated at 2022-06-24 06:52:28.483098
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git rm -r path', '', 'fatal: not removing \'path\' recursively without -r')) \
        == 'git rm -r -r path'

# Generated at 2022-06-24 06:52:33.940851
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm milestone', 'fatal: not removing \'milestone\' recursively without -r\n')) == 'git rm -r milestone'
    assert get_new_command(Command('git rm -r milestone', 'fatal: not removing \'milestone\' recursively without -r\n')) == 'git rm -r milestone'


# Generated at 2022-06-24 06:52:36.287850
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf .git')
    assert get_new_command(command) == 'git rm -rf -r .git'

# Generated at 2022-06-24 06:52:39.653806
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r\n')
    out = get_new_command(command)
    assert out == 'git rm -r file.txt'

# Generated at 2022-06-24 06:52:40.791269
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf name')) == 'git rm -rf -r name'

# Generated at 2022-06-24 06:52:50.601940
# Unit test for function match
def test_match():
    # Test match with a basic command that has no rm -r
    command = Command(script = u'git rm file')
    assert match(command)
    # Test match with a basic command that has rm -r
    command = Command(script = u'git rm -r file')
    assert not match(command)
    # Test match with a basic command that has rm -r in its output
    command = Command(script = u'git rm file', output = u'fatal: not removing \'')
    assert not match(command)
    # Test match with a basic command that has rm -r in its output and is fatal
    command = Command(script = u'git rm file', output = u'fatal: not removing \'')
    assert match(command)


# Generated at 2022-06-24 06:52:55.507251
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: not removing \'a/b/c\' recursively without -r'))
    assert not match(Command('git status', "fatal: not removing 'recursively'"))


# Generated at 2022-06-24 06:53:00.035159
# Unit test for function get_new_command
def test_get_new_command():
    output_error_line = "fatal: not removing './test/test_git.py' recursively without -r"
    command = Command(script='git rm test/test_git.py', output=output_error_line)
    new_command = get_new_command(command)
    assert new_command == u"git rm -r test/test_git.py"

# Generated at 2022-06-24 06:53:01.589758
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file1 file2 file3') == 'git rm -r file1 file2 file3'

# Generated at 2022-06-24 06:53:06.535100
# Unit test for function match
def test_match():
    assert match(Command('git rm /shahryar/some/dir', '', 'fatal: not removing \'/shahryar/some/dir\' recursively without -r'))
    assert not match(Command('git rm a/b/c', '', 'fatal: not removing \'a/b/c\' recursively without -r'))
    assert not match(Command('git gl', '', ''))


# Generated at 2022-06-24 06:53:10.658844
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'
    assert get_new_command('git rm -v foo') == 'git rm -v -r foo'
    assert get_new_command('git rm --cached -r foo') == 'git rm -r --cached -r foo'

# Generated at 2022-06-24 06:53:14.685626
# Unit test for function match
def test_match():
    command = Command('git rm dir toto', "fatal: not removing 'dir' recursively without -r\nDid you mean this?\n\trm 'dir'")
    assert match(command)
    
# Unit tes

# Generated at 2022-06-24 06:53:15.877686
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'

# Generated at 2022-06-24 06:53:17.331205
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -f') == 'git rm -f -r'

# Generated at 2022-06-24 06:53:22.065731
# Unit test for function match
def test_match():
    assert not match(Command(script='cd test', output='test'))
    assert match(Command(script='git rm test',
                         output="fatal: not removing 'test' recursively without -r"))
    assert not match(Command(script='git rm test',
                            output='test'))

# Generated at 2022-06-24 06:53:24.721593
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f *.pyc')
    assert get_new_command(command) in ["git rm -rf *.pyc", "git -rf rm *.pyc"]

# Generated at 2022-06-24 06:53:28.905604
# Unit test for function match
def test_match():
	command = Command("git rm  a")
	assert match(command) == False
	command = Command("git rm a")
	command.output = "fatal: not removing 'a' recursively without -r"
	assert match(command)


# Generated at 2022-06-24 06:53:31.013804
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file/path', '')
    assert get_new_command(command) == u'git rm -r file/path'

# Generated at 2022-06-24 06:53:33.876159
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm cli_tests',
                                   'fatal: not removing \'cli_tests\' recursively without -r\n')) == 'git rm -r cli_tests'

# Generated at 2022-06-24 06:53:38.826559
# Unit test for function match
def test_match():
    from tests.utils import Command

    assert match(Command('rm -r dir', stderr='fatal: not removing '
                         '\'dir/file\' recursively without -r'))
    assert not match(Command('rm file', stderr='fatal: not removing '
                         '\'file\' recursively without -r'))
    assert not match(Command('rm -r file'))
    assert not match(Command('git rm file'))
    assert not match(Command('git rm -r file'))

# Generated at 2022-06-24 06:53:43.590561
# Unit test for function match
def test_match():
    assert match(Command('git rm foo bar',
                         'fatal: not removing \'foo\' recursively without -r',
                         '', 1))
    assert not match(Command('git rm foo',
                             '', '', 1))
    assert not match(Command('', '', '', 1))


# Generated at 2022-06-24 06:53:47.078799
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3',
                         'fatal: not removing \'file1\' recursively without -r',
                         '/git/path'))


# Generated at 2022-06-24 06:53:53.523336
# Unit test for function match
def test_match():
    assert not match(Command('rm --cached'))
    assert not match(Command('git rm'))
    assert not match(Command('git add foobar'))
    assert match(Command('git rm foobar'))
    assert match(Command('git rm -r foobar'))
    assert match(Command('git rm -rf foobar'))
    assert match(Command('git rm foobar foobar2'))
    assert match(Command('git rm -r foobar foobar2'))

# Generated at 2022-06-24 06:53:56.476533
# Unit test for function get_new_command
def test_get_new_command():
    command_output = u"fatal: not removing 'docs' recursively without -r"
    command = Command('rm docs', command_output)
    assert get_new_command(command) == u'git -r rm docs'

# Generated at 2022-06-24 06:53:59.756818
# Unit test for function match
def test_match():
    assert match(Command('git rm deploy',
            output="fatal: not removing 'deploy' recursively without -r"))
    assert not match(Command('git rm deploy',
            output="fatal: 'deploy' not removing recursively without -r"))



# Generated at 2022-06-24 06:54:02.254023
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r test_directory' == get_new_command(Command(script=u'git rm test_directory'))

# Generated at 2022-06-24 06:54:05.582940
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         "fatal: not removing 'file' recursively without -r"))



# Generated at 2022-06-24 06:54:10.049448
# Unit test for function match
def test_match():
    assert match(Command('git rm -f file1', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git rm -f file1', 'nothing'))
    assert not match(Command('git branch branch1', 'fatal: not removing \'file1\' recursively without -r'))


# Generated at 2022-06-24 06:54:12.905165
# Unit test for function match
def test_match():
    assert(match(Command('git rm file1 file2 file3',
                         'fatal: not removing \'file1\' recursively without -r\n',
                         '')))
    assert(not match(Command('git rm file1 file2 file3',
                             'fatal: not removing \'file1\' recursively without -r\n',
                             '')))


# Generated at 2022-06-24 06:54:16.423326
# Unit test for function match
def test_match():
    assert match(Command('rm test.txt',
                         'fatal: not removing \'test.txt\' recursively without -r\n',
                         ''))


# Generated at 2022-06-24 06:54:20.956544
# Unit test for function match
def test_match():
    assert match(Command('git rm text.txt',
                         'fatal: not removing \'text.txt\' recursively without -r'))
    assert not match(Command('git rm text.txt', 'text.txt'))
    assert not match(Command('rm text.txt', 'fatal: not removing \'text.txt\' recursively without -r'))


# Generated at 2022-06-24 06:54:25.979964
# Unit test for function get_new_command
def test_get_new_command():
    command_test_rm = Command(script='git rm file.txt',
                              stdout='fatal: not removing \'file.txt\' recursively without -r\n')
    command_test_rmdir = Command(script='git rm -d directory/',
                                 stdout='fatal: not removing \'directory/\' recursively without -r\n')
    assert get_new_command(command_test_rm) == 'git rm -r file.txt'
    assert get_new_command(command_test_rmdir) == 'git rm -d -r directory/'

# Generated at 2022-06-24 06:54:29.036745
# Unit test for function get_new_command
def test_get_new_command():
	cmd = Command('git rm file.txt')
	assert get_new_command(cmd) == 'git rm -r file.txt'

# Generated at 2022-06-24 06:54:33.090199
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm folder',
                      'fatal: not removing \'folder\' recursively without -r\n')

# Generated at 2022-06-24 06:54:35.122666
# Unit test for function match
def test_match():
    assert(match(Command('git rm file1')))
    assert(match(Command('rm file2')))


# Generated at 2022-06-24 06:54:37.853004
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file.txt', u"""
        fatal: not removing 'file.txt' recursively without -r
        """, u'git rm file.txt')) == u'git rm -rfile.txt'

# Generated at 2022-06-24 06:54:46.053975
# Unit test for function match
def test_match():
    assert(match(Command('git rm file1 file2 file3')) == False)
    assert(match(Command('git rm file1 file2 file3', 'fatal: not removing \'file1\' recursively without -r\nfatal: not removing \'file2\' recursively without -r\nfatal: not removing \'file3\' recursively without -r\n', '', 1)) == True)
    assert(match(Command('git status', '# On branch master\n#\n# Initial commit\n#\n# Untracked files:\n#   (use "git add <file>..." to include in what will be committed)\n#\n#       file1\n#       file2\n#', '', 0)) == False)


# Generated at 2022-06-24 06:54:51.430742
# Unit test for function get_new_command
def test_get_new_command():
    command_test_case = ("git rm -r file",
                         "fatal: not removing 'file' recursively without -r\n")
    command_test = Command(command_test_case[0], command_test_case[1])
    assert get_new_command(command_test) == "git rm -r -r file"

# Generated at 2022-06-24 06:54:55.055356
# Unit test for function match
def test_match():
    assert match(
        Command(script="git rm foo", output="fatal: not removing 'foo' recursively without -r")) is not None


# Generated at 2022-06-24 06:54:58.653643
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm folder/', 
        'fatal: not removing \'folder/\' recursively without -r')) in ['git -r rm folder/', 'git rm -r folder/']


# Generated at 2022-06-24 06:55:02.033183
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command("git rm nosuchdir",
                                   "fatal: not removing 'nosuchdir' recursively without -r"))
           == "git rm -r nosuchdir")


# Generated at 2022-06-24 06:55:10.758877
# Unit test for function match
def test_match():
    command = Command('git rm -r --cached blah', 'fatal: not removing \'blah\' recursively without -r\n')
    assert match(command) is True
    command = Command('git rm --cached blah', 'fatal: not removing \'blah\' recursively without -r\n')
    assert match(command) is False
    command = Command('git rm -r --cached blah', 'fatal: not removing \'blah\' recursively without -r\n')
    assert match(command) is True
    command = Command('git rm -r --cached blah', 'fatal: not removing \'blah\' recursively without -r\n')
    assert match(command) is True

# Generated at 2022-06-24 06:55:15.438666
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f misstyped_path',None,None)) == 'git rm -rf misstyped_path'
    assert get_new_command(Command('git rm -f misstyped_path/',None,None)) == 'git rm -rf misstyped_path/'



# Generated at 2022-06-24 06:55:16.828355
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm app.py") == 'git rm -r app.py'

# Generated at 2022-06-24 06:55:20.095342
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         "fatal: not removing 'file' recursively without -r"))
    assert not match(Command('git rm file', ''))

# Generated at 2022-06-24 06:55:29.769970
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf tests', '', '')) == u'git rm -rf -r tests'
    assert get_new_command(Command('git rm -f tests', '', '')) == u'git rm -f -r tests'
    assert get_new_command(Command('git rm -rf --cached tests', '', '')) == u'git rm -rf -r --cached tests'
    assert get_new_command(Command('git rm tests', '', '')) == u'git rm -r tests'
    assert get_new_command(Command('git rm --cached tests', '', '')) == u'git rm -r --cached tests'
    assert get_new_command(Command('git rm -rf tests/', '', '')) == u'git rm -rf -r tests/'
   

# Generated at 2022-06-24 06:55:32.781692
# Unit test for function match
def test_match():
    assert match(Command('$ git rm -r', 'fatal: not removing '
                                 "'<path>' recursively without -r\n"))
    assert not match(Command('$ git rm -r'))

# Generated at 2022-06-24 06:55:39.426831
# Unit test for function match
def test_match():
    assert match(Command('git rm -r testfile', 'fatal: not removing \'testfile\' recursively without -r\n', '/tmp'))
    assert match(Command('git rm testfile', 'fatal: not removing \'testfile\' recursively without -r\n', '/tmp'))
    assert not match(Command('git rm -r testfile', 'fatal: not removing \'testfile\' recursively without -r\n', '/tmp'))

# Generated at 2022-06-24 06:55:50.342799
# Unit test for function match
def test_match():
    assert match(Command('rm -f /etc',
                         "fatal: not removing '/etc' recursively without -r",
                         ''))
    assert not match(Command('rm', '', ''))
    assert not match(Command('rm /etc', '', ''))
    assert not match(Command('rm -f /etc', '', ''))
    assert not match(Command('rm -f', '', ''))

    assert match(Command('git rm -f /etc',
                        "fatal: not removing '/etc' recursively without -r",
                        ''))
    assert not match(Command('git rm', '', ''))
    assert not match(Command('git rm /etc', '', ''))
    assert not match(Command('git rm -f /etc', '', ''))

# Generated at 2022-06-24 06:55:52.434158
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', '')) == 'git rm -r file'

# Generated at 2022-06-24 06:55:58.888574
# Unit test for function match
def test_match():
    cmd1 = Command('git rm test.txt', 'fatal: not removing \''
                   'test.txt\' recursively without -r')
    assert match(cmd1)
    cmd2 = Command('git rm', 'fatal: not removing '
                   '\'test.txt\' recursively without -r')
    assert not match(cmd2)
    cmd3 = Command('git rm -r test.txt', 'fatal: not removing '
                    '\'test.txt\' recursively without -r')
    assert not match(cmd3)
    assert not match(Command('git rm test.txt'))


# Generated at 2022-06-24 06:56:01.734582
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f test-repo/test_file', 'fatal: not removing \'test-repo/test_file\' recursively without -r')
    assert get_new_command(command) == u'git rm -f -r test-repo/test_file'

# Generated at 2022-06-24 06:56:04.598540
# Unit test for function match
def test_match():
    assert (match(Command('git rm --cached hello.py',
                          'fatal: not removing \'hello.py\' recursively without -r',
                          '')))
    assert not (match(Command('git rm hello.py',
                          'fatal: not removing \'hello.py\' recursively without -r',
                          '')))

# Generated at 2022-06-24 06:56:07.337050
# Unit test for function match
def test_match():
    example = types.Command("git rm -rf src", "", "fatal: not removing 'src' recursively without -r")
    assert match(example)

# Generated at 2022-06-24 06:56:10.250082
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing '
                                       "'foo' recursively without -r\n"))
