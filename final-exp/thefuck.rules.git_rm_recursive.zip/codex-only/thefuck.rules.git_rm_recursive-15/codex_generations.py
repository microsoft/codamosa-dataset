

# Generated at 2022-06-24 06:46:12.095636
# Unit test for function match
def test_match():
    assert match(Command('git rm -r "test"',
            'fatal: not removing \'test\' recursively without -r\n',
            '/bin/bash'))


# Generated at 2022-06-24 06:46:15.963827
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file'
    command = Command('git clone badurl', 'fatal: repository \'badurl\' does not exist')
    assert get_new_command(command) != 'git clone -r badurl'

# Generated at 2022-06-24 06:46:17.978292
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm a', 'fatal: not removing \'a\' recursively without -r', '', 0, None)
    assert get_new_command(command) == 'git rm -r a'

# Generated at 2022-06-24 06:46:19.804331
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm dir", "fatal: not removing 'dir' recursively without -r")
    assert get_new_command(command) == "git rm -r dir"

# Generated at 2022-06-24 06:46:22.721097
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file.py',
                      """fatal: not removing 'file.py' recursively 
                      without -r""")
    assert(get_new_command(command) == 'git rm -r file.py')


# Generated at 2022-06-24 06:46:25.444753
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command('git rm -f app/foo', 'fatal'))
    assert result == 'git rm -f -r app/foo'


# Generated at 2022-06-24 06:46:29.378798
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm file1',
                                   'fatal: not removing '
                                   "'/Users/file1/' recursively "
                                   "without -r\n", '')) == 'git rm -r file1'

# Generated at 2022-06-24 06:46:32.171598
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf path')
    new_command = get_new_command(command)
    assert new_command == 'git rm -rf -r path'

# Generated at 2022-06-24 06:46:34.607323
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm dir') == 'git rm -r dir'
    assert get_new_command('git rm -r dir') == 'git rm -r dir'

# Generated at 2022-06-24 06:46:38.665533
# Unit test for function get_new_command
def test_get_new_command():
    script = u'git rm folder/file'
    command = Command(script, 'fatal: not removing \'/home/user/folder/file\' recursively without -r\n')
    new_command = get_new_command(command)
    assert new_command == u'git rm -r folder/file'

# Generated at 2022-06-24 06:46:42.932087
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("abc rm test1 test2", "abc: test1: Is a directory", None)) == "abc rm -r test1 test2"
    assert get_new_command(Command("git rm test1 test2", "git: test1: Is a directory", None)) == "git rm -r test1 test2"

# Generated at 2022-06-24 06:46:51.270901
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm test', 'fatal: not removing test recursively without -r', '', 42)) == 'git rm -r test'
    assert get_new_command(Command('rm test1 test2', 'fatal: not removing test1 recursively without -r', '', 42)) == 'git rm -r test1 test2'
    assert get_new_command(Command('rm test1 test2', 'fatal: not removing test1 recursively without -r', '', 42)) == 'git rm -r test1 test2'
    assert get_new_command(Command('rm test1 test2', 'fatal: not removing test1 recursively without -r', '', 42)) == 'git rm -r test1 test2'

# Generated at 2022-06-24 06:46:54.047163
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
     Command('git rm file',
      'fatal: not removing \'file\' recursively without -r\n')) == 'git rm -r file'

# Generated at 2022-06-24 06:46:56.981372
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm image.png',
            'fatal: not removing \'image.png\' recursively without -r')
    new_command = get_new_command(command)
    assert new_command == 'git rm -r image.png'

# Generated at 2022-06-24 06:46:59.012160
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -r") == "git rm -r -r"


# Generated at 2022-06-24 06:47:04.543422
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git status', 'fatal: not removing \'.git/hooks\' recursively without -r')) ==u'git status -r'
    assert get_new_command(Command('git status', 'fatal: not removing \'.git/hooks/pre-push\'')) ==u'git status -r'

# Generated at 2022-06-24 06:47:05.591373
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf foo')) == 'git rm -r -rf foo'

# Generated at 2022-06-24 06:47:10.496402
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert (get_new_command(Command('', '', 'fatal: not removing ''abc'' recursively without -r', '')) == 'git rm -r abc')
    assert (get_new_command(Command('', '', 'fatal: not removing ''abc'' recursively without -r', '')) == 'git rm -r abc')
    assert (get_new_command(Command('', '', 'fatal: not removing ''abc'' recursively without -r', '')) == 'git rm -r abc')
    assert (get_new_command(Command('', '', 'fatal: not removing ''abc'' recursively without -r', '')) == 'git rm -r abc')

# Generated at 2022-06-24 06:47:11.526172
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm test") == "git rm -r test"

# Generated at 2022-06-24 06:47:15.731737
# Unit test for function match
def test_match():
    assert (match(
        Command(script='git rm',
                output="fatal: not removing '.' recursively without -r"))
            == True)
    assert (match(
        Command(script='git rm',
                output='fatal: not removing '
                       '\'dfdaf\' recursively without -r'))
            == True)
    assert match(Command(script='git add',
                         output="fatal: not removing "
                                "'.' recursively without -r")) == False



# Generated at 2022-06-24 06:47:21.334172
# Unit test for function match
def test_match():
    assert(match(Command('git rm', 'fatal: not removing \'src/foo\' recursively without -r', None)))
    assert(not match(Command('git rm', 'fatal: not removing \'src/foo\' recursively with -r', None)))
    assert(not match(Command('git rm', 'fatal: not removing \'src/foo\' recursively', None)))


# Generated at 2022-06-24 06:47:24.316018
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                         "fatal: not removing 'file.txt' recursively without -r\n"))
    assert not match(Command('git rm -r file.txt',
                             "fatal: not removing 'file.txt' recursively without -r\n"))


# Generated at 2022-06-24 06:47:26.924249
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert_equal(get_new_command(Command('git rm -r folder', 'error')), 'git rm -r -r folder')

# Generated at 2022-06-24 06:47:28.149521
# Unit test for function match
def test_match():
	match("test")


# Generated at 2022-06-24 06:47:31.008137
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r test' == get_new_command(Command('git rm test'))
    assert u'rm -rf test' == get_new_command(Command('rm test'))

# Generated at 2022-06-24 06:47:32.969542
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', '', "fatal: not removing 'foo'"
                         " recursively without -r"))

# Generated at 2022-06-24 06:47:35.008795
# Unit test for function match
def test_match():
	output = "fatal: not removing 'xxx' recursively without -r"
	assert match(Command('rm xxx',output))



# Generated at 2022-06-24 06:47:37.363217
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test_dir')
    assert get_new_command(command) == "git rm -r -r test_dir"



# Generated at 2022-06-24 06:47:45.457142
# Unit test for function match
def test_match():
    assert match(Command(script='git rm -rf x',
                         commands_history=[],
                         env={},
                         output='fatal: not removing \'x\' recursively without -r'))
    assert not match(Command(script='git rm -rf x',
                             commands_history=[],
                             env={},
                             output='fatal: not removing \'x\' recursively without -r'))
    assert not match(Command(script='',
                             commands_history=[],
                             env={},
                             output='fatal: not removing \'x\' recursively without -r'))
    assert not match(Command(script='git rm -rf x',
                             commands_history=[],
                             env={},
                             output='fatal: not removing \'x\''))


# Generated at 2022-06-24 06:47:56.373956
# Unit test for function get_new_command
def test_get_new_command():
    # Test running "git rm foo" and getting error "foo: needs to be removed recursively"
    initial_command = "git rm foo"
    expected_command = "git rm -r foo"
    command_output = """rm 'foo': needs to be removed recursively
Use '--ignore-unmatch' to skip this path""".split('\n')[0]
    command = Command(initial_command, command_output)
    assert get_new_command(command) == expected_command

    # Test running "git rm -r foo" and getting error "foo: needs to be removed recursively"
    initial_command = "git rm -r foo"
    expected_command = "git rm -r -r foo"

# Generated at 2022-06-24 06:48:00.470834
# Unit test for function match
def test_match():
    assert match(Command('git rm file_name', 'fatal: not removing \'file_name\' recursively without -r'))
    assert not match(Command('git rm file_name', 'fatal: not removing \'file_name\''))


# Generated at 2022-06-24 06:48:04.122832
# Unit test for function match
def test_match():
	test_test = "asdfasdf rm asdfasdf fatal: not removing 'asdfasdf' recursively without -r"
	test_command = Command(script = "rm", output = test_test)
	assert match(test_command) == True


# Generated at 2022-06-24 06:48:08.465281
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    test_command = 'git rm -f myfile'
    output = ("fatal: not removing 'myfile' recursively without -r\n"
              "Did you mean 'rm -f'?")
    assert get_new_command(Command(script=test_command, output=output)) == 'git rm -rf myfile'

# Generated at 2022-06-24 06:48:17.941735
# Unit test for function match
def test_match():
    # Tests match() with "fatal: not removing '" in command.output
    # and "' recursively without -r" in command.output
    assert match(Command('rm file', 'fatal: not removing \'file\' recursively without -r', ''))
    # Tests match() with "fatal: not removing '" in command.output
    # and "' recursively without -rf" in command.output
    assert not match(Command('rm file', 'fatal: not removing \'file\' recursively without -rf', ''))
    # Tests match() with "fatal: not removing '" in command.output
    # and "' recursively without -r" not in command.output
    assert not match(Command('rm file', 'fatal: not removing \'file\' recursively without', ''))
    # Tests match() with "fatal

# Generated at 2022-06-24 06:48:20.545973
# Unit test for function match
def test_match():
    assert match(Command(script='git rm file.txt',
                         output='fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command(script='git rm file.txt',
                         output='fatal: pathspec \'file.txt\' did not match any files'))
 

# Generated at 2022-06-24 06:48:27.350139
# Unit test for function match
def test_match():
    command1 = Command('rm .gitignore', 'fatal: not removing \'.gitignore\' recursively without -r')
    command2 = Command('rm -r .gitignore', 'fatal: not removing \'.gitignore\' recursively without -r')
    command3 = Command('git rm .gitignore', 'fatal: not removing \'.gitignore\' recursively without -r')
    assert not match(command1)
    assert match(command2)
    assert match(command3)


# Generated at 2022-06-24 06:48:28.932116
# Unit test for function get_new_command
def test_get_new_command():
    script = u'git rm folder/'
    command = Command(script, 'fatal: not removing \'folder/\' recursively without -r\n')
    assert(get_new_command(command) == 'git rm -r folder/')

# Generated at 2022-06-24 06:48:35.029741
# Unit test for function match
def test_match():
    assert match(Command('git rm file', "fatal: not removing 'file' recursively without -r", False))
    assert match(Command('git rm directory', "fatal: not removing 'directory' recursively without -r", False))
    # not a git command
    assert not match(Command('rm file', "fatal: not removing 'file' recursively without -r", False))
    assert not match(Command('rm -r file', "", False))
    assert not match(Command('rm file', "", False))



# Generated at 2022-06-24 06:48:39.785177
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         'fatal: not removing \'foo\' recursively without -r\n'))
    assert not match(Command('git rm foo', ''))
    assert not match(
        Command('ls', 'fatal: not removing \'foo\' recursively without -r\n'))

# Generated at 2022-06-24 06:48:42.160308
# Unit test for function match
def test_match():
    assert match(Command('git rm -r', stderr='fatal: not removing \'folder\' recursively without -r'))


# Generated at 2022-06-24 06:48:48.806411
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git rm dir/',
                                   'fatal: not removing \'dir/\' recursively without -r')) == 'git rm -r dir/'
    assert get_new_command(Command('git rm -d dir/',
                                   'fatal: not removing \'dir/\' recursively without -r')) == 'git rm -d -r dir/'
    assert get_new_command(Command('git rm file.txt',
                                   'fatal: not removing \'file.txt\' recursively without -r')) == 'git rm -r file.txt'

# Generated at 2022-06-24 06:48:52.289693
# Unit test for function match
def test_match():
	cmd_inp = [u'git rm -r one',u'fatal: not removing \'one/two/three\' recursively without -r',u"Did you mean this?"]
	assert match(cmd_inp)


# Generated at 2022-06-24 06:48:55.204731
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f README', 'fatal: not removing \'README\' recursively without -r')) == \
        u'git rm -rf README'

# Generated at 2022-06-24 06:48:59.088860
# Unit test for function get_new_command
def test_get_new_command():
	script = "git rm -f somedir"
	output = "fatal: not removing 'somedir' recursively without -r\n"
	assert get_new_command(Command(script, output)) == "git rm -r -f somedir"

# Generated at 2022-06-24 06:49:02.958118
# Unit test for function match
def test_match():
    new_script = 'git rm a.txt'
    output =("fatal: not removing 'a.txt' recursively without -r"
             "Did you mean 'rm'?")
    assert match(Command(script=new_script, output=output))


# Generated at 2022-06-24 06:49:08.452349
# Unit test for function match
def test_match():
    assert not match(Command('git foo', '', str(1)))
    assert not match(Command('git rm 1', '', str(1)))
    assert not match(Command('git rm 1', '', str(1)))
    assert match(Command('git rm 1',
                         "fatal: not removing '1' recursively without -r",
                         str(1)))

# Unit tests for function get_new_command

# Generated at 2022-06-24 06:49:13.300704
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {})
    command.script = "git rm file"
    command.output = "fatal: not removing 'file' recursively without -r"
    command.script_parts = ['git', 'rm', 'file']
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-24 06:49:15.018989
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r mytest','')) == 'git rm -r mytest'

# Generated at 2022-06-24 06:49:16.101619
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'


# Generated at 2022-06-24 06:49:18.567700
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -f foo', 'fatal: not removing \'foo\'')) in ('rm -f -r foo', 'rm -r -f foo')

# Generated at 2022-06-24 06:49:20.350756
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command("git rm a b")) == u"git rm -r a b")

# Generated at 2022-06-24 06:49:22.493772
# Unit test for function get_new_command
def test_get_new_command():

    command = Command('git rm -rf path/to/directory')
    assert get_new_command(command) == "git rm -rf -r path/to/directory"


# Generated at 2022-06-24 06:49:28.987963
# Unit test for function match
def test_match():
    # Test for git command
    assert match(Command('git rm -r test', 'fatal: not removing \'/Users/user/git/test\' recursively without -r')).should == True
    assert match(Command('git rm -d test', 'fatal: not removing \'/Users/user/git/test\' recursively without -r')).should == False
    assert match(Command('git rm test', 'fatal: not removing \'/Users/user/git/test\' recursively without -r')).should == True
    assert match(Command('git rm -r file test', 'fatal: not removing \'/Users/user/git/test\' recursively without -r')).should == False

    # Test for different command

# Generated at 2022-06-24 06:49:37.953800
# Unit test for function get_new_command
def test_get_new_command():
    # Test one
    command = Command(
        'git rm test.txt',
        'fatal: not removing \'.../test.txt\' recursively without -r\n',
        '',
        stderr='fatal: not removing \'.../test.txt\' recursively without -r',
        script='git rm test.txt',
        stderr_lines=['fatal: not removing \'.../test.txt\' recursively without -r'],
        stdout_lines=[],
        output='fatal: not removing \'.../test.txt\' recursively without -r\n')

    new_command = get_new_command(command)

    assert new_command == 'git rm -r test.txt'
    # End test one

    # Test two

# Generated at 2022-06-24 06:49:40.526445
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm directory', '', '')) == 'git rm -r directory'

# Generated at 2022-06-24 06:49:44.812292
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output = '''
fatal: not removing 'tests/test_document.txt' recursively without -r
'''.strip()
    assert get_new_command(Command('git rm tests/test_document.txt',
                                   output)) == 'git rm -r tests/test_document.txt'

# Generated at 2022-06-24 06:49:47.908546
# Unit test for function get_new_command
def test_get_new_command():
    command_script_parts = ['git', 'rm', '-f', '-r']
    assert get_new_command(Command(' '.join(command_script_parts), '')) == 'git rm -f -r'

# Generated at 2022-06-24 06:49:50.541620
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git rm .',
		'fatal: not removing \'.gitignore\' recursively without -r')) == 'git rm -r .'

# Generated at 2022-06-24 06:49:56.513357
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command("git rm a", "")) == "git rm -r a"
    assert get_new_command(Command("git rm -f a", "")) == "git rm -f -r a"
    assert get_new_command(Command("git rm -f a b", "")) == "git rm -f -r a b"

# Generated at 2022-06-24 06:50:00.721502
# Unit test for function match
def test_match():
    assert match(Command('git rm'))
    assert match(Command('git rm non_empty_folder'))
    assert not match(Command('git rm -rf .'))
    assert not match(Command('git mv f1 f2'))


# Generated at 2022-06-24 06:50:03.949636
# Unit test for function match
def test_match():
    assert match(Command(script='git rm -r a',
                         output="fatal: not removing 'a' recursively without -r"))
    assert not match(Command(script='git rm a',
                         output="fatal: not removing 'a' recursively without -r"))
    assert not match(Command('ls', ''))

# Generated at 2022-06-24 06:50:06.403890
# Unit test for function get_new_command
def test_get_new_command():
    """Test if the match function works correctly and return
    the correct output.
    """
    assert get_new_command(Command('git rm hello.py'
                                   'fatal: not removing hello.py recursively without -r', ''))

# Generated at 2022-06-24 06:50:09.395905
# Unit test for function get_new_command
def test_get_new_command():
    from tests.shells import Mock
    from tests.utils import Command
    assert get_new_command(Command('git rm not-empty-dir/')) == 'git rm -r not-empty-dir/'
    assert get_new_command(Command('git rm not-empty-dir')) == 'git rm -r not-empty-dir'

# Generated at 2022-06-24 06:50:12.163330
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm -rf files", "fatal: not removing 'files' recursively without -r")) == u"git rm -rf -r files"

# Generated at 2022-06-24 06:50:13.771534
# Unit test for function match
def test_match():
    assert match(Command(' rm -rf \'a\' ',
                         output='fatal: not removing \'a\' recursively without -r'))



# Generated at 2022-06-24 06:50:19.701045
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf a b c', "fatal: not removing 'a' recursively without -r"))
    assert not match(Command('rm -rf a b c', "fatal: not removing 'a' recursively without -r"))
    assert not match(Command('git rm -rf a b c', "fatal: not removing 'a' without -r"))


# Generated at 2022-06-24 06:50:24.070591
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', 'fatal: not removing '' recursively without -r')) == 'git rm -r -r'

# Generated at 2022-06-24 06:50:27.635333
# Unit test for function match
def test_match():
    assert match(
        Command('git rm folder_name', 'fatal: not removing \'folder_name\' recursively without -r'))
    assert not match(Command('not a git rm command', 'some message'))


# Generated at 2022-06-24 06:50:30.153246
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file',
                            'fatal: not removing \'file\' recursively without -r\n')) == 'git rm -r file'

# Generated at 2022-06-24 06:50:38.463727
# Unit test for function match
def test_match():
  assert match(Command(" git rm file_name ", " fatal: not removing 'file_name' recursively without -r"))
  assert match(Command(" git rm folder_name ", " fatal: not removing 'folder_name' recursively without -r"))
  assert match(Command(" git rm file_name ", "")) == False
  assert match(Command(" git rm -r folder_name ", " fatal: not removing 'folder_name' recursively without -r")) == False
  assert match(Command(" rm file_name ", " fatal: not removing 'file_name' recursively without -r")) == False


# Generated at 2022-06-24 06:50:43.582685
# Unit test for function match
def test_match():
    assert match(Command('git rm abc', 'fatal: not removing ')) == False
    assert match(Command('git rm -r', 'fatal: not removing ')) == False
    assert match(Command('git rm abc', 'fatal: not removing \'abc\' recursively without -r')) == True

# Unit test function get_new_command

# Generated at 2022-06-24 06:50:49.036718
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                         stderr='fatal: not removing \'file.txt\' recursively without -r\n'))
    assert not match(Command('git rm file.txt',
                             stderr='fatal: not removing \'file.txt\' recursively with -r\n'))
    assert not match(Command('git rm file.txt',
                             stderr='fatal: not removing \'file.txt\' recursively without\n'))
    assert not match(Command('git rm file.txt'))


# Generated at 2022-06-24 06:50:58.326315
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'.gitignore\' recursively without -r'))
    assert match(Command('git rm -r file', 'fatal: not removing \'.gitignore\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'.gitignore\' recursively with -r'))
    assert not match(Command('git rma file', 'fatal: not removing \'.gitignore\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'.gitignore\' recursively without -r'))


# Generated at 2022-06-24 06:51:01.309720
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r --cached readme.md', 'git rm: readme.md: is a directory (not removed)')[0]) == 'git rm -r -r --cached readme.md'

# Generated at 2022-06-24 06:51:03.409442
# Unit test for function match
def test_match():
    assert match(Command('command', 'git rm -r'))
    assert not match(Command('git rm -r', 'git rm -r'))

# Generated at 2022-06-24 06:51:08.202510
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = 'rm a/b/c', output = u"fatal: not removing 'a/b/c' recursively without -r")
    assert get_new_command(command) == u'git rm -r a/b/c'
    assert get_new_command(command = Command(script = 'git push orgin master', output = u"fatal: not removing 'a/b/c' recursively without -r")) == 'git push orgin master'

# Generated at 2022-06-24 06:51:11.602984
# Unit test for function match
def test_match():
    assert match('git rm file.txt')
    assert match('git rm -r file.txt')
    assert not match('git add file.txt')
    assert not match('git add -r file.txt')


# Generated at 2022-06-24 06:51:13.785100
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -rf' == get_new_command(Command('git rm -rf', '', '', 1, None))


# Generated at 2022-06-24 06:51:18.310110
# Unit test for function get_new_command
def test_get_new_command():
    trans_command = "git rm -rf test"
    trans_command_parts = trans_command.split(' ')
    com = Command(trans_command_parts, "fatal: not removing 'test/' recursively without -r", "")
    assert u' '.join(get_new_command(com).split(' ')) == "git rm -r -rf test"

# Generated at 2022-06-24 06:51:23.945738
# Unit test for function match
def test_match():
    assert match(Command('git rm -r src'))
    assert match(Command(u'git rm src', 'fatal: not removing \'./src/assets/img/logo.svg\' recursively without -r\nUse \'git rm --cached src\' to unstage\n'))
    assert not match(Command(u'git rm src'))

# Generated at 2022-06-24 06:51:27.754323
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test', '/tmp/fake-dir', 'git rm test\nfatal: not removing '
        '\'test\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r test'

# Generated at 2022-06-24 06:51:33.646826
# Unit test for function match
def test_match():
    assert match(Command('git rm README.md', 
                         'fatal: not removing \'README.md\' recursively without -r'))
    assert match(Command('git rm -r test',
                         'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm -r \'test\'',
                             'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git add README.md', 
                             'fatal: not removing \'README.md\' recursively without -r'))


# Generated at 2022-06-24 06:51:35.686044
# Unit test for function match
def test_match():
    """Test for match function"""
    match_test = match(Command('git rm folder', '', 'fatal: not removing \'folder\' recursively without -r', '', '', ''))
    assert(match_test)

# Generated at 2022-06-24 06:51:37.893902
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm test.py') == 'git rm -r test.py'
    assert get_new_command('git rm test.py test.php') == 'git rm -r test.py test.php'

# Generated at 2022-06-24 06:51:39.460274
# Unit test for function match
def test_match():
    assert match(Command(script = 'git rm asdf',
            output = 'fatal: not removing \'asdf\' recursively without -r'))



# Generated at 2022-06-24 06:51:48.774617
# Unit test for function match
def test_match():
    # Test function returns True when command contains ' rm '
    assert match(Command(script=' rm bad_file.txt',
                         output='error: pathspec \'bad_file.txt\' did not match\
                          any file(s) known to git.'))

    # Test function returns False when command does not contain ' rm '
    assert match(Command(script=' rmdir bad_directory',
                         output='error: pathspec \'bad_directory\' did not match\
                          any file(s) known to git.')) is False

    # Test function returns False when command does not have the correct error
    assert match(Command(script=' rm bad_file.txt',
                         output='error: pathspec \'bad_file.txt\' did not match\
                          any file(s) known to git.')) is False


# Generated at 2022-06-24 06:51:52.215550
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file_name', 'fatal: not removing \'file_name\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file_name'

# Generated at 2022-06-24 06:51:59.726574
# Unit test for function get_new_command
def test_get_new_command():
    # Case 1 - Check if function returns the correct command with
    # rm command with a single argument
    assert (get_new_command(Command(script="git rm test",
                               output="fatal: not removing 'test' "
                               "recursively without -r")) ==
            "git rm -r test")
    # Case 2 - Check if function returns the correct command with
    # rm command with a multiple arguments
    assert (get_new_command(Command(script="git rm test test2",
                               output="fatal: not removing 'test' "
                               "recursively without -r")) ==
            "git rm -r test test2")

# Generated at 2022-06-24 06:52:02.891192
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm dir5/dir6/dir7', 'fatal: not removing \'dir5/dir6/dir7\' recursively without -r')) == 'git rm -r dir5/dir6/dir7'

# Generated at 2022-06-24 06:52:06.390546
# Unit test for function match
def test_match():
    assert match(Command('rm -d foo', "", "fatal: not removing 'foo/' recursively without -r"))
    assert not match(Command('rm -d foo', "", ""))
    assert not match(Command('rm -d foo', "", "error: unknown switch `d'"))


# Generated at 2022-06-24 06:52:09.066468
# Unit test for function match
def test_match():
    assert match(Command('git rm a', "fatal: not removing 'a' recursively without -r"))
    assert not match(Command('git rm a', ''))
    assert not match(Command('foo rm a', ''))


# Generated at 2022-06-24 06:52:15.377588
# Unit test for function match
def test_match():
    assert match(Command('rm -r dir',
            output='fatal: not removing \'dir/\' recursively without -r'))
    assert match(Command('rm -r dir',
            output='fatal: not removing \'dir/subdir\' recursively without -r'))
    assert match(Command('git rm -r dir',
            output='fatal: not removing \'dir/subdir\' recursively without -r'))
    assert not match(Command('rm -r dir',
            output='fatal: not removing \'subdir\' recursively without -r'))
    assert not match(Command('rm -r dir',
            output='fatal: not removing \'subdir\' recursively without -r'))

# Generated at 2022-06-24 06:52:17.135131
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f abc', '', '')) == 'git rm -rf abc'

# Generated at 2022-06-24 06:52:22.610221
# Unit test for function get_new_command
def test_get_new_command():
    command_script = "git rm <filename>"
    command_output = """fatal: not removing '<filename>' recursively without -r
Use 'git rm --cached <filename>' to unstage"""


    command = Command(command_script, command_output)    
    assert_equals(get_new_command(command), """git rm -r <filename>""")

# Generated at 2022-06-24 06:52:25.160459
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo', 'fatal: not removing ''foo'' recursively without -r')) == 'git rm -r foo'

# Generated at 2022-06-24 06:52:31.453049
# Unit test for function match
def test_match():
    # only testing to see if the command matches,
    # since the output is git-specific, it should be
    # tested in the git.py unit tests
    #
    # should match
    command1 = type("CommandObject", (object,), {"output":"",
                                                 "script":"cd ..; git rm -r pwd"})
    assert match(command1)
    # shouldn't match
    command2 = type("CommandObject", (object,), {"output":"",
                                                 "script":"cd ..; git rm pwd"})
    assert not match(command2)


# Generated at 2022-06-24 06:52:35.041227
# Unit test for function match
def test_match():
    command = Command('git rm -r ./', 'fatal: not removing \'./\' recursively without -r')
    assert match(command)
    command2 = Command('git rm ./', 'fatal: not removing \'./\' recursively without -r')
    assert not match(command2)



# Generated at 2022-06-24 06:52:39.026852
# Unit test for function match
def test_match():
    assert match(Command('git rm -r foo.txt',
        """fatal: not removing 'foo.txt' recursively without -r
        """,
        ""))
    assert not match(Command('git rm foo.txt',
        '', ''))


# Generated at 2022-06-24 06:52:44.066437
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm toto titi tata', 'fatal: not removing \'toto\''
                      ' recursively without -r\nfatal: not removing \'titi\''
                      ' recursively without -r\nfatal: not removing \'tata\''
                      ' recursively without -r')
    assert get_new_command(command) == ('git rm -r toto titi tata')

# Generated at 2022-06-24 06:52:47.092612
# Unit test for function get_new_command
def test_get_new_command():
    output = 'fatal: not removing \'.gitignore\' recursively without -r'
    rule = get_new_command(Command('git rm .gitignore', output))
    assert rule == 'git rm -r .gitignore'

# Generated at 2022-06-24 06:52:50.236669
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         'fatal: not removing \'foo\' recursively without -r',
                         ''))
    assert not match(Command('git rm foo', '', ''))

# Generated at 2022-06-24 06:52:52.355735
# Unit test for function match
def test_match():
    assert match(Command(script='git rm '))
    assert not match(Command(script='git rm',
                             output="fatal: not removing '"
                             ))


# Generated at 2022-06-24 06:52:55.460567
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r --cached src/')) == "git rm -r -r --cached src/"

# Generated at 2022-06-24 06:52:58.299638
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -fr new_file', 'fatal: not removing \'new_file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -fr new_file'

# Generated at 2022-06-24 06:53:00.328538
# Unit test for function get_new_command
def test_get_new_command():
    command_ = Command('git rm filename', '')
    assert get_new_command(command_) == 'git rm -r filename'

# Generated at 2022-06-24 06:53:02.727058
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git rm lol'
    new_command = get_new_command(Command(command))
    assert(new_command == 'git rm -r lol')

# Generated at 2022-06-24 06:53:05.283943
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r "file"', "fatal: pathspec 'file' did not match any files")
    assert get_new_command(command) == "git rm -r -r 'file'"

# Generated at 2022-06-24 06:53:09.365300
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf /var/tmp/toto', '/var/tmp/toto', 'fatal: not removing \'/var/tmp/toto\' recursively without -r')
    assert get_new_command(command) == 'git rm -rf -r /var/tmp/toto'

# Generated at 2022-06-24 06:53:14.855604
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm file',
                      stdout='fatal: not removing "file" recursively without -r')
    assert get_new_command(command) == 'git rm -r file'
    command = Command(script='git rm -f dir/',
                      stdout='fatal: not removing "dir/" recursively without -r')
    assert get_new_command(command) == 'git rm -r -f dir/'
    command = Command(script='git rm file1 file2',
                      stdout='fatal: not removing "file1" recursively without -r')
    assert get_new_command(command) == 'git rm -r file1 file2'

# Generated at 2022-06-24 06:53:19.208316
# Unit test for function match
def test_match():
    assert match(Command('git rm', 'fatal: not removing \'A/path\' recursively without -r\n'))
    assert not match(Command('git rm', 'fatal: not removing \'A/path\' recursively\n'))



# Generated at 2022-06-24 06:53:21.251935
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command("git rm foo") == "git rm -r foo")

# Generated at 2022-06-24 06:53:25.994390
# Unit test for function match
def test_match():
    assert match(Command(script='git status', output='fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command(script='git status', output='fatal: not removing \'file.txt\' recursively without -r', stderr='fatal: not removing \'file.txt\' recursively without -r'))
	


# Generated at 2022-06-24 06:53:29.572933
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command('rm file', 'fatal: not removing \'file\' recursively without -r')) == u'git rm -r file'

# Generated at 2022-06-24 06:53:34.358795
# Unit test for function match
def test_match():
	assert match(Command('git rm file'))
	assert match(Command('git rm -r file')) == False
	assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
	assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')) == False


# Generated at 2022-06-24 06:53:41.784455
# Unit test for function match
def test_match():
	from thefuck.types import Command
	from thefuck.shells import Bash
	from thefuck import shells

	shell = Bash()
	shell.environ = {'GIT_TRACE': '1'}
	shell.which = lambda x: '/usr/bin/'+x

	# Normal use case
	assert match(Command('git rm -r folder', 'fatal: not removing \'folder\' recursively without -r\n',
			shell))

	# Error use case
	assert not match(Command('git rm -r folder', 'fatal: ...\n',
			shell))
	assert not match(Command('git rm -r folder', 'fatal: not removing \'folder\' ...\n',
			shell))

# Generated at 2022-06-24 06:53:45.736781
# Unit test for function match
def test_match():
    assert match(
        Command('git rm -rf target', '', 'fatal: not removing \'target\' recursively without -r'))
    assert not match(
        Command('git rm -rf target', '', ''))
    asser

# Generated at 2022-06-24 06:53:48.664267
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf what',
                         'fatal: not removing \'what\' recursively without -r'))
    assert not match(Command('git rm -rf what', ''))

# Generated at 2022-06-24 06:53:55.405887
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm blah.txt', 'fatal: not removing \'blah.txt\' recursively without -r')) == \
        'git rm -r blah.txt'
    assert get_new_command(Command('git something rm blah.txt', 'fatal: not removing \'blah.txt\' recursively without -r')) == \
        'git something rm -r blah.txt'
    assert get_new_command(Command('git rm blah.txt', '')) == \
        'git rm -r blah.txt'

# Generated at 2022-06-24 06:53:59.681479
# Unit test for function match
def test_match():
    # No output
    assert not match(Command('rm document.txt', ''))
    # Not correct output
    assert not match(Command('rm document.txt', 'fatal: not removing some'))
    # All right
    assert match(Command('rm document.txt', 'fatal: not removing some'
                ' recursively without -r'))



# Generated at 2022-06-24 06:54:02.894727
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ["git", "rm", "-r", "This is a test"]
    assert get_new_command(command_parts) == u"git rm -r -r This is a test"

# Generated at 2022-06-24 06:54:05.950298
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command("git rm /tmp/foo/bar.txt") == "git rm -r /tmp/foo/bar.txt")

# Generated at 2022-06-24 06:54:10.050164
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git rm untracked.txt',
                                          'fatal: not removing \'untracked.txt\' recursively without -r\n',
                                          0))
    assert u'git rm -r untracked.txt' == new_command

# Generated at 2022-06-24 06:54:13.638575
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')
    assert get_new_command(command) == 'git rm -r foo'

if __name__ == '__main__':
    print(get_new_command.__name__)
    print(get_new_command(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')))
    # Unit tests above
    print(test_get_new_command())

# Generated at 2022-06-24 06:54:21.933457
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2'))
    assert match(Command('git rm file1 file2', 'fatal: not removing \'file2\' recursively without -r\n'))
    assert not match(Command('git rm file1 file2', 'fatal: not removing \'file2\' recursively with -r\n'))
    assert not match(Command('git rm file1 file2', 'fatal: not removing \'file2\' recursively without -r'))
    assert not match(Command('git rm file1 file2', 'fatal: not removing \'file2\' recursively without -r\n'))


# Generated at 2022-06-24 06:54:27.171456
# Unit test for function get_new_command
def test_get_new_command():
    command_output = u"""git rm: 'asdasd/': 没有那个文件或目录
fatal: 不能递归删除目录 'asdasd/'"""
    from thefuck.types import Command
    assert get_new_command(Command('git rm asdasd', command_output)) == 'git rm -r asdasd'

# Generated at 2022-06-24 06:54:31.465066
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf', 'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm -rf', ''))
    assert not match(Command('git rm -rf', 'fatal: not removing \'test\''))


# Generated at 2022-06-24 06:54:35.772030
# Unit test for function match
def test_match():
	# Test 1
	assert match(Command("git rm src/git.py"))

	# Test 2
	assert not match(Command("git commit -m 'It's a commit.'"))

	# Test 3
	assert not match(Command("git"))

	# Test 4
	assert not match(Command("git -h"))


# Generated at 2022-06-24 06:54:40.618892
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo',
                'fatal: removing \'foo\' recursively without -r'))
    assert not match(Command('git remove foo',
                'fatal: not removing \'foo\' recursively without -r'))


# Generated at 2022-06-24 06:54:46.116371
# Unit test for function match
def test_match():
    assert match(Command(script = 'git rm non-existing-file', output = 'fatal: not removing \'non-existing-file\''))
    assert match(Command(script = 'git rm README.md', output = 'fatal: not removing \'README.md\' recursively without -r'))
    assert not match(Command(script = 'git rm -r README.md', output = 'fatal: not removing \'README.md\' recursively without -r'))



# Generated at 2022-06-24 06:54:49.846666
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r', output_format='lower'))
    assert not match(Command('git rm -r foo', '', output_format='lower'))



# Generated at 2022-06-24 06:54:54.601654
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', 'rm', '-rf', 'directory/']
    command = Command(' '.join(command_parts), 'error')
    assert_equals(get_new_command(command), command_parts[0] + ' ' + command_parts[1] + ' ' + command_parts[3])

# Generated at 2022-06-24 06:55:04.547876
# Unit test for function match
def test_match():
    # Testing function match with argument command whose script contains rm and whose output contains
    # "fatal: not removing '" and "' recursively without -r"
    assert match(Command('git rm mohit.c',
                         'fatal: not removing \'mohit.c\' recursively without -r'))
    # Testing function match with argument command whose script contains rm and whose output contains
    # "fatal: not removing '" and "' recursively without -r"
    assert match(Command('git rm folder',
                         'fatal: not removing \'folder\' recursively without -r'))
    # Testing function match with argument command whose script contains rm and whose output doesn't
    # contain "fatal: not removing '" and "' recursively without -r"

# Generated at 2022-06-24 06:55:13.557569
# Unit test for function match
def test_match():
    """ Unit test for function match
    """
    commands = ['git rm -rv test-repo/test-submodule', 'git rm test-repo/test-submodule']
    cmd_outputs = ['fatal: not removing \'test-repo/test-submodule\' recursively without -r']
    status = [True, True]
    for cmd, cmd_output, sta in zip(commands, cmd_outputs, status):
        my_command = create_command(cmd, stderr=cmd_output)
        assert match(my_command) == sta


# Generated at 2022-06-24 06:55:18.486967
# Unit test for function match
def test_match():
	assert match(Command('git rm non-empty-dir', 
		'fatal: not removing \'non-empty-dir\' recursively without -r\n'))
	assert match(Command('git rm non-empty-dir', 
		'fatal: not removing \'non-empty-dir\' recursively without -r\n'))
	assert match(Command('git rm non-empty-dir', 
		'fatal: not removing \'non-empty-dir\' recursively without -r\n'))


# Generated at 2022-06-24 06:55:21.319719
# Unit test for function match
def test_match():
    assert(match(Command("git rm src/file.py",
                         "fatal: not removing 'src/file.py' recursively without -r")))



# Generated at 2022-06-24 06:55:24.796590
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm -r', '', 'fatal: not removing \'outer\' recursively without -r')) == 'git rm -r -r'

# Generated at 2022-06-24 06:55:28.422378
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm test") == "git rm -r test"
    assert get_new_command("git rm -r test") == "git rm -r test"
    assert get_new_command("git rm -rf test") == "git rm -rf test"

# Generated at 2022-06-24 06:55:31.026738
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm stuff") == "git rm -r stuff"
    assert get_new_command("git rm -r stuff") == "git rm -r stuff"

# Generated at 2022-06-24 06:55:36.075165
# Unit test for function get_new_command
def test_get_new_command():
    output = u"fatal: not removing 'Test/app/app.iml' recursively without -r"
    command = Command(u"git rm Test/app/app.iml", output)
    assert (u"git rm -r Test/app/app.iml" ==
            get_new_command(command))



# Generated at 2022-06-24 06:55:37.904476
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'


# Generated at 2022-06-24 06:55:40.416190
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', '',
                                   "fatal: not removing 'file' recursively without -r")) == 'git rm -r file'

# Generated at 2022-06-24 06:55:45.587744
# Unit test for function match
def test_match():
    assert(match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')))
    assert(not match(Command('git rm file', '')))
    assert(not match(Command('git commit file', 'fatal: not removing \'file\' recursively without -r')))


# Generated at 2022-06-24 06:55:49.922915
# Unit test for function match
def test_match():
    assert match(Command('git rm fileName', 'fatal: not removing \'fileName\' recursively without -r\n'))
    assert match(Command('git rm fileName', 'fatal: not removing \'fileName\' recursively without -r\n')) == False


# Generated at 2022-06-24 06:55:55.791353
# Unit test for function match
def test_match():
    assert match(Command('git rm -r foo',
               'fatal: not removing \'foo\' recursively without -r',
               ''))
    assert match(Command('git rm foo',
               'fatal: not removing \'foo\' recursively without -r',
               ''))

    assert not match(Command('git foo', 'fatal: not removing \'foo\' recursively without -r', ''))
    assert not match(Command('git foo', '', ''))


# Generated at 2022-06-24 06:55:58.577461
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test', 'fatal: not removing \'test\' recursively without -r')
    output = get_new_command(command)
    assert u'git rm -r test' == output


# Generated at 2022-06-24 06:56:00.915567
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -C repo file',
                      'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -C repo file'


# Generated at 2022-06-24 06:56:04.102771
# Unit test for function match
def test_match():
    assert match(Command('rm -rf',
                         'fatal: not removing \'.gitignore\' recursively without -r'))
    assert not match(Command('rm -rf', ''))
    assert not match(Command('git rm',
                             'fatal: not removing \'.gitignore\' recursively without -r'))


# Generated at 2022-06-24 06:56:07.056985
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1', '', '/tmp')) == 'git rm -r file1'


# Generated at 2022-06-24 06:56:08.992188
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm x', '')) == \
           'git rm -r x'

# Generated at 2022-06-24 06:56:18.217204
# Unit test for function match
def test_match():
    test_match = [
        "git status",
        "git rm -f path/to/b",
        "git rm -rf path/to/b",
        "git add path/to/b",
        "git add -f path/to/b",
        "git rm path/to/b",
        "git rm -f path/to/b",
        "git rm -rf path/to/b",
        "git status",
        "git rm path/to/b/c",
        "git rm -f path/to/b/c",
        "git rm -rf path/to/b/c",
        "git status"]

    result = [match(Command(_, None)) for _ in test_match]