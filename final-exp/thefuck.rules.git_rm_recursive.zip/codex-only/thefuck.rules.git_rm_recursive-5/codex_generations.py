

# Generated at 2022-06-24 06:46:16.315264
# Unit test for function match
def test_match():
    assert match(Command('git log', '', ''))
    assert match(Command('git log -n', '', ''))
    assert not match(Command('git logg', '', ''))
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r'))



# Generated at 2022-06-24 06:46:19.618197
# Unit test for function match
def test_match():
    assert match(Command('git branch branch_name',
                         'fatal: not removing \'branch_name\' recursively without -r\n'))
    assert match(Command('git branch branch_name',
                         'error: pathspec \'branch_name\' did not match any file(s) known to git\n'))


# Generated at 2022-06-24 06:46:22.331243
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' \
recursively without -r')
    
    assert(get_new_command(command) == 'git rm -r file')

# Generated at 2022-06-24 06:46:24.245694
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test/','fatal: not removing \'./test/funcs.py\' recursively without -r'))


# Generated at 2022-06-24 06:46:29.431820
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                   {'script': 'git rm foo',
                    'output': "fatal: not removing 'foo' recursively without -r",
                    'script_parts': ['git', 'rm', 'foo']})()
    assert get_new_command(command) == 'git rm -r foo'

# Generated at 2022-06-24 06:46:37.609162
# Unit test for function match
def test_match():
    assert match(Command('git rm', 'git: \'rm\' is not a git command. See \'git --help\'.\n\nDid you mean this?\n\trm\n'))
    assert match(Command('git rm', 'fatal: not removing \'Makefile\' recursively without -r\n'))
    assert not match(Command('git rm', 'fatal: not removing \'Makefile\' without -r\n'))
    assert not match(Command('git rm', 'fatal: Pathspec \'Makefile\' did not match any files\n'))
    assert not match(Command('git rm', 'Everything up-to-date\n'))

# Generated at 2022-06-24 06:46:39.020865
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git remote rm test')
    assert get_new_command(command) == 'git remote rm -r test'

# Generated at 2022-06-24 06:46:44.153992
# Unit test for function match
def test_match():

    command1 = Command("git rm -r subdir/foo", "fatal: not removing 'subdir/foo' recursively without -r")
    command2 = Command("git rm -r", "fatal: not removing 'subdir/foo' recursively without -r")
    command3 = Command("git rm -r foo", "fatal: not removing 'subdir/foo' recursively")

    # testing match
    assert (match(command1))
    assert (match(command2))
    assert (not match(command3))



# Generated at 2022-06-24 06:46:48.440033
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    git_command = 'git rm -f a/b/c'
    output = 'fatal: not removing \'a/b/c\' recursively without -r'

    new_command = get_new_command(Command(git_command, output))

    assert new_command == 'git rm -r -f a/b/c'

# Generated at 2022-06-24 06:46:50.809155
# Unit test for function match
def test_match():
  assert match(Command('git rm btest.rb', 'fatal: not removing \'btest.rb\' recursively without -r'))


# Generated at 2022-06-24 06:46:57.016271
# Unit test for function get_new_command
def test_get_new_command():
    script = 'rm test.txt'
    new_script = get_new_command(Command(script, ''))
    assert new_script == 'rm -r test.txt'
    script = 'git rm test.txt'
    new_script = get_new_command(Command(script, ''))
    assert new_script == 'git rm -r test.txt'
    script = 'other_command rm test.txt'
    new_script = get_new_command(Command(script, ''))
    assert new_script == 'other_command rm test.txt'

# Generated at 2022-06-24 06:47:04.393211
# Unit test for function match
def test_match():
    def _createcommand(command, output):
        return command, Command(script='', stdout=output)
    functions = [_createcommand(
        'git rm file',
        "fatal: not removing 'file' recursively without -r")]
    assert any(match(*func) for func in functions)

    functions = [_createcommand(
        'git rm -r file',
        "fatal: not removing 'file' recursively without -r")]
    assert not any(match(*func) for func in functions)


# Generated at 2022-06-24 06:47:06.694866
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm a', 'fatal: not removing ''a'' recursively without -r')
    assert get_new_command(command) == 'git rm -r a'

# Generated at 2022-06-24 06:47:08.575888
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file/', '')
    assert 'git rm -r file/' == get_new_command(command)

# Generated at 2022-06-24 06:47:10.872179
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.py',
                         'fatal: not removing \'hello.py\' recursively without -r'))
    assert not match(Command('git rm hello.py', ''))


# Generated at 2022-06-24 06:47:12.960500
# Unit test for function get_new_command
def test_get_new_command():
    command, new_command = GitRmNeedsR("git rm error", "error")
    assert new_command == "git rm -r error"

# Generated at 2022-06-24 06:47:22.579863
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r file.txt' == get_new_command(Command('git rm file.txt',
                                                            u"fatal: not removing 'file.txt' recursively without -r"))
    assert u'git rm -r file.txt' == get_new_command(Command('git rm file.txt',
                                                            u"error: not removing 'file.txt' recursively without -r"))
    assert u'git rm -r file.txt' == get_new_command(Command('git rm file.txt',
                                                            u"fatal: not removing 'file.txt' recursively without -r\n"
                                                            u"warning: not removing 'file2.txt' recursively without -r"))
    assert u'git rm -r file.txt' != get_new_command

# Generated at 2022-06-24 06:47:29.668939
# Unit test for function get_new_command
def test_get_new_command():
    # Example of error for when a directory is too big and needs -r
    command = Command('git rm -rf to_delete', 'Not removing to_delete recursively without -r')
    assert get_new_command(command) == "git rm -rf -r to_delete"

    # Example for when the option is already the first one
    command = Command('git rm -rf -f to_delete', 'Not removing to_delete recursively without -r')
    assert get_new_command(command) == "git rm -rf -rf to_delete"

# Generated at 2022-06-24 06:47:33.584459
# Unit test for function match
def test_match():
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r')) is True
    assert match(Command('git add file', '', 'fatal: not removing \'file\' recursively without -r')) is False


# Generated at 2022-06-24 06:47:34.740750
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'

# Generated at 2022-06-24 06:47:38.889721
# Unit test for function match
def test_match():
    """
    Test for match function
    """
    match_command = """git rm  "help.txt"
fatal: not removing 'help.txt' recursively without -r
"""
    command = Command(script="git rm  'help.txt'", output=match_command)
    assert match(command)



# Generated at 2022-06-24 06:47:41.855530
# Unit test for function match
def test_match():
    assert match(Command(script='git rm foo',
                         output='fatal: not removing ''foo'' recursively without -r'))
    assert not match(Command('git rm foo', 'fatal: foo'))


# Generated at 2022-06-24 06:47:45.494178
# Unit test for function match
def test_match():
    command = Command('git rm -r /tmp/pwd/somefile', output = "fatal: not removing '/tmp/pwd/somefile' recursively without -r\n")
    assert match(command)


# Generated at 2022-06-24 06:47:49.435951
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf *', 'fatal: not removing \'README.md\' recursively without -r')
    assert(get_new_command(command) == 'git rm -rf -r *')

# Generated at 2022-06-24 06:47:54.507123
# Unit test for function match
def test_match():
    assert match(Command(' rm file',
               'fatal: not removing \'file\' recursively without -r', ''))
    assert match(Command(' rm file/',
               'fatal: not removing \'file/\' recursively without -r', ''))
    assert not match(Command(' rm file', '', ''))

# Generated at 2022-06-24 06:47:57.471279
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm file.md',
                                   'fatal: not removing \'file.md\' recursively without -r\n')) \
        == u'git rm -r file.md'

# Generated at 2022-06-24 06:48:02.820286
# Unit test for function match
def test_match():
    assert match(Command('git rm dirname', 'fatal: not removing \'dirname\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 0))

# Generated at 2022-06-24 06:48:04.229228
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'git status'
    assert get_new_command('git rm *') == 'git rm -r *'


# Generated at 2022-06-24 06:48:10.539626
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf dir/', 'fatal: not removing \'dir/\' recursively without -r'))
    assert not match(Command('rm -rf dir/', 'fatal: not removing \'dir/\' recursively without -r'))
    assert not match(Command('git rm -rf dir/', 'fatal: not removing \'dir/\' recursively'))


# Generated at 2022-06-24 06:48:15.202022
# Unit test for function match

# Generated at 2022-06-24 06:48:17.479828
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = "git rm -rf files", output = "fatal: not removing 'files' recursively without -r")) == "git rm -rf -r files"

# Generated at 2022-06-24 06:48:19.893574
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm -f test1.py',
                                   output='fatal: not removing \'test2.py\' '
                                          'recursively without -r\n')) == \
           'git rm -r -f test1.py'

# Generated at 2022-06-24 06:48:21.349792
# Unit test for function match
def test_match():
    assert match(Command('git rm foo'))
    assert not match(Command('git show foo'))


# Generated at 2022-06-24 06:48:26.247708
# Unit test for function match
def test_match():
    assert match(Command('git rm file1', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git rm file1', 'deleted file1'))
    assert not match(Command('git rm file1', 'fatal: not removing \'file1\''))
    ass

# Generated at 2022-06-24 06:48:28.037404
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
            'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-24 06:48:30.875164
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm file/', 'fatal: not removing \'file/\' recursively without -r\n')) == 'git rm -r file/')


enabled_by_default = True

# Generated at 2022-06-24 06:48:33.082668
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r data")
    assert get_new_command(command) == "git rm -r -r data"

# Generated at 2022-06-24 06:48:36.803418
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r') == 'git rm -r -r'
    assert get_new_command('git rm -r foo.txt') == 'git rm -r -r foo.txt'
    assert get_new_command('git rm foo.txt bar.txt') == 'git rm -r foo.txt bar.txt'

# Generated at 2022-06-24 06:48:41.073183
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm folder', '')) == 'git rm -r folder'
    assert get_new_command(Command('git rm -f folder', '')) == 'git rm -f -r folder'


# Generated at 2022-06-24 06:48:43.784849
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r')) == 'git rm -r test.txt'


enabled_by_default = True

# Generated at 2022-06-24 06:48:45.347756
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm this_directory')) == \
        'git rm -r this_directory'

# Generated at 2022-06-24 06:48:46.765295
# Unit test for function match
def test_match():
    assert match(Command("git rm --cached file2.txt", "fatal: not removing 'file2.txt' recursively without -r"))

# Generated at 2022-06-24 06:48:48.353737
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r test')) == 'git rm -r -r test'


# Generated at 2022-06-24 06:48:49.813121
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm la")) == "git rm -r la"

# Generated at 2022-06-24 06:48:52.096707
# Unit test for function match
def test_match():
    assert match(Command("git rm folder",
                  "fatal: not removing 'folder/' recursively without -r"))


# Generated at 2022-06-24 06:49:02.304444
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm dir','''error: pathspec 'dir' did not match any file(s) known to git.
    error: pathspec 'dir' did not match any file(s) known to git.
    fatal: not removing 'dir' recursively without -r''')) == 'git rm -r dir'
    assert get_new_command(Command('git rm -r dir','''error: pathspec 'dir' did not match any file(s) known to git.
    error: pathspec 'dir' did not match any file(s) known to git.
    fatal: not removing 'dir' recursively without -r''')) == 'git rm -r dir'

# Generated at 2022-06-24 06:49:04.122332
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm test') == 'git rm -r test'

# Generated at 2022-06-24 06:49:12.012439
# Unit test for function match
def test_match():
    assert(match(Command('git rm f.txt', 'fatal: not removing \'f.txt\' recursively without -r')))
    assert(not match(Command('git rm f.txt', 'fatal: not removing \'f.txt\'')))
    assert(not match(Command('git rm f.txt', 'fatal: not removing \'f.txt\' without -r')))
    assert(not match(Command('git rm -r f.txt', 'fatal: not removing \'f.txt\' recursively without -r')))
    assert(not match(Command('git rm -r f.txt', 'fatal: not removing \'f.txt\'')))
    assert(not match(Command('git rm -r f.txt', 'fatal: not removing \'f.txt\' without -r')))


# Generated at 2022-06-24 06:49:15.703360
# Unit test for function get_new_command
def test_get_new_command():
    command = "git rm file.txt"
    command_with_error = "git rm file.txt\nfatal: not removing 'file.txt' recursively without -r"
    assert get_new_command(Command(command, command_with_error)) == "git rm -r file.txt"

# Generated at 2022-06-24 06:49:18.389208
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf --cached .idea', '', 1, '')
    assert get_new_command(command) == 'git rm -rf -r --cached .idea'

# Generated at 2022-06-24 06:49:22.022742
# Unit test for function get_new_command
def test_get_new_command():
	command.script = u"git rm -v test_dir"
	command.script_parts = command.script.split()
	command.output = "fatal: not removing 'test_dir' recursively without -r"

	target = u"git rm -r -v test_dir"
	assert get_new_command(command) == target

# Generated at 2022-06-24 06:49:27.268700
# Unit test for function match
def test_match():
    assert not match(Command('git rm brand new file', "fatal: not removing 'brand' recursively without -r", ''))
    assert match(Command('git rm brand new file', "fatal: not removing 'brand' recursively without -r\n", ''))
    assert match(Command('git rm -f brand new file', "fatal: not removing 'brand' recursively without -r\n", ''))
    assert match(Command('cd awesome-project\ngit rm brand new file', "fatal: not removing 'brand' recursively without -r\n", ''))


# Generated at 2022-06-24 06:49:32.120335
# Unit test for function match
def test_match():
    assert match(Command(script='git stash rm -r stash@{0}',
        output='fatal: not removing \'stash@{0}\' recursively without -r'))
    assert not match(Command(script='git stash rm -r stash@{0}',
        output='fatal: Not a git repository: \'.git\''))

# Generated at 2022-06-24 06:49:36.275434
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r\n')) == 'git rm -r foo'

# Generated at 2022-06-24 06:49:40.015956
# Unit test for function match

# Generated at 2022-06-24 06:49:49.986138
# Unit test for function get_new_command
def test_get_new_command():
    """
    Function get_new_command should insert -r after rm
    """
    command = Command(script = ' rm --cached file1 file2',
                      output = "error: This operation must be run in a work tree\nfatal: not removing 'file1' recursively without -r\nfatal: not removing 'file2' recursively without -r")
    assert (get_new_command(command) == "rm -r --cached file1 file2")

    command = Command(script = 'git rm --cached file1 file2',
                      output = "error: This operation must be run in a work tree\nfatal: not removing 'file1' recursively without -r\nfatal: not removing 'file2' recursively without -r")

# Generated at 2022-06-24 06:49:53.033411
# Unit test for function get_new_command
def test_get_new_command():
    check_output = u'fatal: not removing \'test\' recursively without -r'
    assert get_new_command(Command('git rm test', check_output)) == 'git rm -r test'

# Generated at 2022-06-24 06:50:01.987439
# Unit test for function match
def test_match():
    assert match(Command('git rm', 'fatal: not removing "file" recursively without -r', '', 0, None))
    assert match(Command('git rm', 'fatal: not removing "file" recursively without -r', '', 0, None))
    assert match(Command('git rm', 'fatal: not removing "file" recursively without -r', '', 0, None))
    assert match(Command('git rm', 'fatal: not removing "file" recursively without -r', '', 0, None))
    assert not match(Command('', '', '', 0, None))
    assert not match(Command('', '', '', 0, None))
    assert not match(Command('', '', '', 0, None))
    assert not match(Command('', '', '', 0, None))

# Generated at 2022-06-24 06:50:03.685793
# Unit test for function get_new_command
def test_get_new_command():
    command.script_parts = ['git', 'rm', 'file']
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-24 06:50:06.727558
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r foo', 'fatal: not removing \'foo\' recursively without -r')
    assert get_new_command(command) == u'git rm -r -r foo'

# Generated at 2022-06-24 06:50:09.456796
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command(script='git rm -f .',
                                   output='fatal: not removing \'.\' recursively without -r')) == 'git rm -rf .'

# Generated at 2022-06-24 06:50:10.925923
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm test') == 'git rm -r test'

# Generated at 2022-06-24 06:50:16.948858
# Unit test for function match
def test_match():
    assert (match(Command('git rm -r house.txt',
                          'fatal: not removing \'house.txt\' recursively without -r'))
            is True)
    assert match(Command('git rm -r house.txt', None)) is False
    assert match(Command('git', 'fatal: not removing \'house.txt\' recursively without -r')) is False



# Generated at 2022-06-24 06:50:21.582046
# Unit test for function match
def test_match():
	assert match(Command('git rm -r --cached .', 'fatal: not removing \'../.DS_Store\' recursively without -r')) == True
	assert match(Command('git rm -r --cached .', 'fatal: not removing \'../.git\' recursively without -r')) == True



# Generated at 2022-06-24 06:50:26.143627
# Unit test for function match
def test_match():
    assert match(Command(script='git rm filename',
                         output="fatal: not removing 'filename' recursively without -r"))
    assert match(Command(script='git rm filename',
                         output="fatal: not removing 'filename' recursively without -r")) == False


# Generated at 2022-06-24 06:50:29.586109
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', stderr='fatal: not removing  foo recursively without -r'))
    assert not match(Command('git rm foo', stderr='fatal: not removing  foo recursively without -r',
                             stdout='foo'))


# Generated at 2022-06-24 06:50:33.173219
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo', 
                                   'fatal: not removing \'foo\' recursively without -r')) == 'git rm -r foo'

# Generated at 2022-06-24 06:50:36.861712
# Unit test for function match
def test_match():
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', ''))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', ''))


# Generated at 2022-06-24 06:50:38.956542
# Unit test for function match
def test_match():
    assert match(Command(script='git rm file',
                         output="fatal: not removing 'file' recursively without -r"))


# Generated at 2022-06-24 06:50:39.525637
# Unit test for function match
def test_match():
    assert gi

# Generated at 2022-06-24 06:50:43.966866
# Unit test for function match
def test_match():
    assert match(Command('git rm -r secret_file',
                         'fatal: not removing \'secret_file\' recursively without -r'))
    assert not match(Command('git rm -r secret_file', ''))
    assert not match(Command('git rm -r secret_file'))



# Generated at 2022-06-24 06:50:46.324067
# Unit test for function match
def test_match():
    script = "git rm bar"
    output = "fatal: not removing 'bar' recursively without -r"
    assert match(Command(script, output))


# Generated at 2022-06-24 06:50:48.779800
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm file") == "git rm -r file"
    assert get_new_command("git rm directory") == "git rm -r directory"
    assert get_new_command("git rm file directory") == "git rm -r file directory"


# Generated at 2022-06-24 06:50:53.759889
# Unit test for function match
def test_match():
    assert match(Command(script='git rm test.py',
                         output="fatal: not removing 'test.py' recursively without -r\n"))
    assert not match(Command(script='git rm test.py',
                             output="fatal: not removing test.py without -r\n"))

# Generated at 2022-06-24 06:50:56.717178
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r dir/file')
    new_command = get_new_command(command)
    assert 'git rm -r -r dir/file' == new_command

# Generated at 2022-06-24 06:51:01.067773
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf file1', '', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git rm file1', '', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git rm', '', ''))
    assert not match(Command('git -rf', '', ''))


# Generated at 2022-06-24 06:51:02.797540
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command(Command("git rm test", output="fatal: not removing 'test' recursively without -r"))

# Generated at 2022-06-24 06:51:04.867126
# Unit test for function match
def test_match():
    assert match(Command('git rm file1', 'fatal: not removing \'file2\' recursively without -r'))


# Generated at 2022-06-24 06:51:11.880293
# Unit test for function get_new_command
def test_get_new_command():
    assert ("git rm -r file" == get_new_command(Command("git rm file", "")))
    assert ("git rm -rf file" == get_new_command(Command("git rm -f file", "")))
    assert ("git rm -rf file" == get_new_command(Command("git rm -rf file", "")))
    assert ("git rm -r test.py" == get_new_command(Command("git rm test.py", "")))
    assert ("rm -rf file" == get_new_command(Command("rm file", "")))
    assert ("rm -rf file" == get_new_command(Command("rm -f file", "")))
    assert ("rm -rf file" == get_new_command(Command("rm -rf file", "")))

# Generated at 2022-06-24 06:51:15.976054
# Unit test for function match
def test_match():
    assert match(Command('git rm file', output=
                         '''fatal: not removing 'file' recursively without -r'''))
    assert not match(Command('git rm -r file', output=
                             '''fatal: not removing 'file' recursively without -r'''))


# Generated at 2022-06-24 06:51:20.207761
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', output='fatal: not removing \'foo\' recursively without -r\n'))
    assert not match(Command('git branch', output='fatal: not removing \'foo\' recursively without -r\n'))



# Generated at 2022-06-24 06:51:23.188852
# Unit test for function get_new_command
def test_get_new_command():
    """
    This test make sure the get_new_command function returns correct values
    """
    assert get_new_command("git rm test") == "git rm -r test"

# Generated at 2022-06-24 06:51:25.910764
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -r dir1', '', '')) == 'rm -r -r dir1'

# Generated at 2022-06-24 06:51:36.880101
# Unit test for function match
def test_match():
    # Test with one command
    # Success
    command = Command('git rm -r install', "fatal: not removing 'install' recursively without -r")
    assert match(command)
    # Failure - No command
    command = Command('', "fatal: not removing 'install' recursively without -r")
    assert not match(command)
    # Failure - Multiple commands
    command = Command('git add install; git rm install', "fatal: not removing 'install' recursively without -r")
    assert not match(command)
    # Failure - No error
    command = Command('git rm -r install', "Success")
    assert not match(command)
    # Failure - No error in command
    command = Command('git rm -r install', "Success")
    assert not match(command)


# Generated at 2022-06-24 06:51:39.305863
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm .idea')) == 'git rm -r .idea'

# Generated at 2022-06-24 06:51:43.316508
# Unit test for function match
def test_match():
    assert match(Command('git rm myfile',
                         'fatal: not removing \'myfile\' recursively without -r'))
    assert not match(Command('git rm myfile', ''))
    assert not match(Command('rm myfile', ''))


# Generated at 2022-06-24 06:51:47.155018
# Unit test for function match
def test_match():
	# Arrange
	from thefuck.types import Command
	command = Command("git rm dir", "fatal: not removing 'dir' recursively without -r", "")
	
	# Act
	result = match(command)
	
	# Assert
	assert(result)


# Generated at 2022-06-24 06:51:50.030810
# Unit test for function match
def test_match():
    assert match(Command('git rm test',
                         'fatal: not removing \'test\' recursively without -r'))
    assert match(Command('git rm test', '')) is False

# Generated at 2022-06-24 06:51:51.764720
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm foo")
    assert get_new_command(command) == "git rm -r foo"

# Generated at 2022-06-24 06:52:01.176081
# Unit test for function match
def test_match():
    assert not match(Command('git lol', 'lol', 'git'))
    assert match(Command('git rm lala', '', 'fatal: not removing \'lala\' ' +
                         'recursively without -r\nDid you mean \'rm -r\'?'))
    assert match(Command('git rm -rf lala', '', 'fatal: not removing \'lala\' ' +
                         'recursively without -r\nDid you mean \'rm -r\'?'))
    assert match(Command('git rm -r lala', '', 'fatal: not removing \'lala\' ' +
                         'recursively without -r\nDid you mean \'rm -r\'?'))

# Generated at 2022-06-24 06:52:07.128072
# Unit test for function get_new_command
def test_get_new_command():
    command = u'git rm -f file1.txt;git rm file2.txt'
    commands_to_test = {
        command: u'git rm -f -r file1.txt;git rm -r file2.txt'
    }
    for command, new_command in commands_to_test.iteritems():
        assert get_new_command(Command(command, '', '')) == new_command

# Generated at 2022-06-24 06:52:10.368317
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm app/Folder')) == u'git rm -r app/Folder'
    assert get_new_command(Command('rm app/File')) == u'git rm app/File'

# Generated at 2022-06-24 06:52:14.390081
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm lala', '')) == 'git rm -r lala'
    assert get_new_command(Command('git rm lala.txt lala2.txt', '')) == 'git rm -r lala.txt lala2.txt'

# Generated at 2022-06-24 06:52:18.422057
# Unit test for function match
def test_match():
    # Test that the expected command is matched
    assert(match(Command('git rm file',
                         'fatal: not removing \'file\' recursively '
                         'without -r')))
    # Test that the un-expected command is not matched
    assert(not match(Command('echo hello', '')))



# Generated at 2022-06-24 06:52:26.178001
# Unit test for function get_new_command
def test_get_new_command():
    # Test if a git rm command with a directory is modified correctly
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r file'
    # Test if a git rm command with a file is modified correctly
    command = Command('git rm test/file', 'fatal: not removing \'test/file\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r test/file'


# Generated at 2022-06-24 06:52:32.585892
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursive import get_new_command
    command = type('Command', (object,),
                   {'script': 'git rm thefuck/rules/git_rm_recursive.py',
                    'output': 'fatal: not removing \'thefuck/rules/git_rm_recursive.py\' recursively without -r\n',
                    'script_parts': ['git', 'rm', 'thefuck/rules/git_rm_recursive.py']})
    assert get_new_command(command) == 'git rm -r thefuck/rules/git_rm_recursive.py'

# Generated at 2022-06-24 06:52:34.765888
# Unit test for function match
def test_match():
    assert git.match('git rm file1 file2') != None
    assert git.match('git add file1') == None


# Generated at 2022-06-24 06:52:38.736421
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r .idea", ".idea is a directory (not removed)\nfatal: not removing 'notes.txt' recursively without -r", "", 0, "")
    assert get_new_command(command) == "git rm -r -r .idea"

# Generated at 2022-06-24 06:52:44.579890
# Unit test for function match
def test_match():
	# one space
	assert match(Command(script='git rm -r dir', output="fatal: not removing 'dir' recursively without -r"))
	# two spaces
	assert match(Command(script='git  rm -r dir', output="fatal: not removing 'dir' recursively without -r"))
	# three spaces
	assert match(Command(script='git   rm -r dir', output="fatal: not removing 'dir' recursively without -r"))
	

# Generated at 2022-06-24 06:52:49.529423
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git branch | grep master | xargs git rm',
                      "fatal: not removing 'master' recursively without -r\n")
    assert get_new_command(command) == \
        "git branch | grep master | xargs git rm -r"


enabled_by_default = True if git_support() else False

# Generated at 2022-06-24 06:52:54.890434
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', "fatal: not removing 'file.txt' recursively without -r"))
    assert not match(Command('git rm -r file.txt', "fatal: not removing 'file.txt' recursively without -r"))
    assert not match(Command('git rm folder', "fatal: not removing 'folder' recursively without -r"))
    assert not match(Command('rm folder', "fatal: not removing 'folder' recursively without -r"))
    assert not match(Command('git rm file.txt', ''))


# Generated at 2022-06-24 06:52:58.119164
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git branch -D ivan',
            stdout="fatal: not removing 'ivan' recursively without -r")
    assert get_new_command(command) == 'git branch -D -r ivan'

# Generated at 2022-06-24 06:53:07.314859
# Unit test for function match
def test_match():
    # Test single file
    command = Command('git rm src/app.js', 'fatal: not removing \'src/app.js\' recursively without -r\n')
    assert match(command)
    command = Command('git rm src/app.js', 'fatal: not removing \'src/app.js\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r src/app.js'

    # Test multiple files
    command = Command('git rm src/app.js src/routes/index.js', 'fatal: not removing \'src/app.js\' recursively without -r\nfatal: not removing \'src/routes/index.js\' recursively without -r\n')
    assert match(command)

# Generated at 2022-06-24 06:53:11.571250
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm -rf src/")) == "git rm -rf -r src/"
    assert get_new_command(Command("git rm -r src/")) == "git rm -r -r src/"
    assert get_new_command(Command("git rm -r src/folder")) == "git rm -r -r src/folder"

# Generated at 2022-06-24 06:53:14.271081
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm test.txt', output="fatal: not removing 'test.txt' recursively without -r")
    assert(get_new_command(command) == 'git rm -r test.txt')


# Generated at 2022-06-24 06:53:21.621098
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
            '/home/user/project/file\nfatal: not removing \'file\' recursively without -r\n',
            '/home/user/project/file'))
    assert not match(Command('git rm file',
            '/home/user/project/file\nfatal: not removing \'file\' recursively without -r\n',
            '/home/user/project/file',
            style_error=True))
    assert not match(Command('git rm file',
            '/home/user/project/file\nfatal: not removing \'file\' recursively without -r\n',
            '/home/user/project/file',
            stderr='Something else'))

# Generated at 2022-06-24 06:53:29.029763
# Unit test for function match
def test_match():
    # Test if it matches
    assert match(Command('git rm',
                         "fatal: not removing 'folder/ab' recursively without -r"))
    # It should not match if it is not a git command
    assert not match(Command('rm',
                             "fatal: not removing 'folder/ab' recursively without -r"))
    # It should not match if it is an git rm command with no message
    assert not match(Command('git rm', ''))
    # It should not match if it is not a git rm command
    assert not match(Command('git add',
                             "fatal: not removing 'folder/ab' recursively without -r"))
    # It should not match if the error message is not raised
    assert not match(Command('git rm', "could not remove 'folder/ab'"))


# Generated at 2022-06-24 06:53:36.034605
# Unit test for function match
def test_match():
    assert git_support
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r\n'
                         ))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r\n',
                             error=True))
    assert not match(Command('git commit file',
                             'fatal: not removing \'file\' recursively without -r\n',
                             error=True))


# Generated at 2022-06-24 06:53:38.735016
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git rm test', 'fatal: not removing test recursively without -r', None)) ==
            'git rm -r test')

# Generated at 2022-06-24 06:53:48.186690
# Unit test for function match
def test_match():
    # Unit test for function match, with git
    command = Command('rm -rf .* && git commit -m "remove files"', '')
    assert match(command) is True

    # with git, but the wrong output
    command = Command('rm -rf .*', 'fatal: pathspec \'*\' did not match any files')
    assert match(command) is False

    # with git, but the wrong output
    command = Command('rm -rf .*', 'fatal: not removing \'*\' recursively without -r')
    assert match(command) is True

    # without git, so we don't match
    command = Command('rm -rf .*', '')
    assert match(command) is False

# Generated at 2022-06-24 06:53:51.358729
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'
    assert get_new_command('git rm file1 file2') == 'git rm -r file1 file2'

# Generated at 2022-06-24 06:53:54.072342
# Unit test for function match
def test_match():
    assert match(Command('rm -rf dir',
                         'fatal: not removing \'dir/subdir\' recursively without -r'))
    assert not match(Command('git status', 'nothing to commit'))

# Generated at 2022-06-24 06:54:00.826317
# Unit test for function match
def test_match():
    assert match(Command('rm fun',
                         stderr='''fatal: not removing 'fun' recursively without -r
'''))
    assert not match(Command('git rm fun',
                             stderr='''fatal: not removing 'fun' recursively without -r
'''))
    assert not match(Command('rm fun',
                             stderr='''e: not removing 'fun' recursively without -r
'''))
    assert not match(Command('rm fun',
                             stderr='''fatal: not removing 'fun' recursively without'''))



# Generated at 2022-06-24 06:54:05.029949
# Unit test for function match
def test_match():
    assert match(Command(' rm file1',
                   '/tmp/repo master\nfatal: not removing \'file1\' recursively without -r\n',
                   '', 0))
    assert not match(Command(' rm file1',
                   '/tmp/repo master\nfatal: not removing \'file1\' recursively without -r\n',
                   '', 0))

# Generated at 2022-06-24 06:54:07.975606
# Unit test for function match
def test_match():
    # Test positive match
    assert match(Command('git rm foldername',
                'fatal: not removing \'foldername\' recursively without -r\n',
                '', 1))

    # Test negative match
    assert not match(Command('git rm foldername',
                             '',
                             '', 1))



# Generated at 2022-06-24 06:54:12.709045
# Unit test for function match
def test_match():
    assert match(Command(' rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))    
    assert not match(Command(' rm file.txt', 'fatal: not removing recursively without -r'))
    assert not match(Command('git rm file.txt', 'fatal: not removing recursively without -r'))


# Generated at 2022-06-24 06:54:16.172335
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm --cached filename.py')
    assert get_new_command(command) == 'git rm -r --cached filename.py'

# Generated at 2022-06-24 06:54:17.794766
# Unit test for function match
def test_match():
    assert match(u'git rm -rf a \'b\'')
    assert not match(u'git rm -rf a')

# Generated at 2022-06-24 06:54:19.704452
# Unit test for function match
def test_match():
    assert match(Command('git rm test'))
    assert not match(Command('git add test.txt'))
    assert not match(Command('git remote add test'))

# Generated at 2022-06-24 06:54:22.055354
# Unit test for function match
def test_match():
    assert match(Command('git rm --force a.txt',
        'fatal: not removing \'a.txt\' recursively without -r'))



# Generated at 2022-06-24 06:54:31.693600
# Unit test for function match
def test_match():
    assert(match(
        Command('git rm iwanttodelete')) == False)
    assert(match(Command(
        'git rm ',
        'fatal: not removing \'iwanttodelete/\' recursively without -r')) == True)
    assert(match(
        Command('gitt rm iwanttodelete'),
        'fatal: not removing \'iwanttodelete/\' recursively without -r') == False)
    assert(match(
        Command('git rm iwanttodelete', 'fatal: not removing \'iwanttodelete/\' recursively without -r')) == True)

# Generated at 2022-06-24 06:54:34.424354
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm myfolder', 'fatal: not removing \'myfolder\' recursively without -r\n')) == 'git rm -r myfolder'

# Generated at 2022-06-24 06:54:37.593580
# Unit test for function match
def test_match():
    assert match(Command('git rm file', output="fatal: not removing 'file' recursively without -r"))
    assert not match(Command('git rm file', output="fatal: not removing 'file' without -r"))
    assert not match(Command('git rm file', output="fatal: not removing '[file]' recursively without -r"))


# Generated at 2022-06-24 06:54:40.084715
# Unit test for function match
def test_match():
    assert match(Command('git rm test.txt', '', '', '', 1))
    assert not match(Command('ls', '', '', '', ''))


# Generated at 2022-06-24 06:54:44.910608
# Unit test for function get_new_command
def test_get_new_command():
    example_original_command = 'git rm -r File'
    example_modified_command = 'git rm -r -r File'
    command = Command(example_original_command, example_original_command, example_modified_command, 'fatal: not removing \'File\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r File'

# Generated at 2022-06-24 06:54:51.159949
# Unit test for function match
def test_match():
    assert match(Command('git rm *', 'fatal: not removing \'src/ \' recursively without -r\n'))
    assert not match(Command('git rm src/', 'fatal: not removing \'src/ \' recursively without -r\n'))
    assert not match(Command('git rm *', 'fatal: "src" is outside repository\n'))


# Generated at 2022-06-24 06:54:54.308316
# Unit test for function get_new_command
def test_get_new_command():
	assert u'git rm -r --cached file' == get_new_command(make_command('git rm --cached file', u'fatal: not removing \'file\' recursively without -r'))

# Generated at 2022-06-24 06:54:57.981613
# Unit test for function match
def test_match():
    command = Command("git rm -r dir/", "fatal: not removing 'dir/' recursively without -r")
    assert match(command)
    assert not match(Command("git rm dir", ""))


# Generated at 2022-06-24 06:55:08.831346
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(
        script='git rm -r',
        output="fatal: not removing 'build/bdist.macosx-10.6-intel/egg' recursively without -r\n",
        stderr="")) == 'git rm -r -r'
    assert get_new_command(Command(
        script='git rm',
        output="fatal: not removing 'build/bdist.macosx-10.6-intel/egg' recursively without -r\n",
        stderr="")) == 'git rm -r'

# Generated at 2022-06-24 06:55:11.115005
# Unit test for function match
def test_match():
    assert match(Command('git rm -r', 'fatal: not removing \'.gitignore\' recursively without -r'))
    assert not match(Command('ls'))


# Generated at 2022-06-24 06:55:13.244118
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command.Command('git rm txt', 'fatal: not removing \'txt\' recursively without -r')) == 'git rm -r txt'

# Generated at 2022-06-24 06:55:16.372670
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', '', 'fatal: not removing \
\'file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt', '', ''))
    assert not match(Command('git commit file.txt', '', ''))


# Generated at 2022-06-24 06:55:20.180504
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file'


# Generated at 2022-06-24 06:55:24.968974
# Unit test for function match
def test_match():
    assert match(Command('git rm d.txt', 'fatal: not removing \'d.txt\' recursively without -r'))
    assert not match(Command('git rm d.txt', ''))
    assert not match(Command('rm d.txt', 'fatal: not removing \'d.txt\' recursively without -r'))


# Generated at 2022-06-24 06:55:30.802056
# Unit test for function match
def test_match():
	# Unit test to check the function match of git.py under specific folder
	# When the input is rm
	assert match(Command('git rm', 'fatal: not removing \'filename\' recursively without -r'))
	# When the input is rmdir
	assert match(Command('git rmdir', 'fatal: not removing \'filename\' recursively without -r'))
	# When the input is mv
	assert not match(Command('git mv', 'fatal: not removing \'filename\' recursively without -r'))


# Generated at 2022-06-24 06:55:33.482659
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r test' == get_new_command(
        Command(u'git rm test', 'fatal: not removing \'test\' recursively without -r'))

# Generated at 2022-06-24 06:55:38.792947
# Unit test for function match
def test_match():
    assert not match(Command('git rm a'))
    assert not match(Command('git rm -r a'))
    assert match(Command('git rm a',
                         'fatal: not removing \'a\' recursively without -r'))
    assert match(Command('git rm a',
                         'error: unable to unlink old \'a\' (Permission denied)'))


# Generated at 2022-06-24 06:55:42.245061
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm file_name',
                                   output='fatal: not removing \'file_name\' recursively without -r')) == 'git rm -r file_name'

# Generated at 2022-06-24 06:55:44.543856
# Unit test for function get_new_command
def test_get_new_command():
    from mock import Mock
    assert get_new_command(Mock(script='git rm test', output='error output')) == 'git rm -r test'

# Generated at 2022-06-24 06:55:54.811339
# Unit test for function match
def test_match():
    output = "fatal: not removing 'file.txt' recursively without -r"
    assert match(Command("git rm file.txt", output))
    assert match(Command("git rm file.txt", "foo: not removing 'file.txt' recursively without -r"))
    assert not match(Command("git rm file.txt", "foo: not removing 'file.txt' recursively without"))
    assert not match(Command("git rm file.txt", "foo: not removing 'file.txt' recursively without -r", ""))
    assert not match(Command("git rm file.txt", "foo: not removing 'file.txt' recursively"))
    assert not match(Command("git rm file.txt", "file.txt: No such file or directory"))
    assert not match(Command("git rm file.txt", ""))



# Generated at 2022-06-24 06:55:56.962459
# Unit test for function match
def test_match():
    assert match(command("git push"))
    assert match(command("git rm abc"))
    assert not match(command("git rm"))
    assert not match(command(""))


# Generated at 2022-06-24 06:56:01.178822
# Unit test for function match
def test_match():
    command = Command('git rm -rf dir/', 'fatal: not removing \'dir/\' recursively without -r')
    match_result = match(command)
    assert match_result

    command = Command('git rm -f dir/', 'fatal: not removing \'dir/\' recursively without -r')
    match_result = match(command)
    assert match_result


# Generated at 2022-06-24 06:56:03.123694
# Unit test for function match
def test_match():
    assert (match(Command(' rm -rf foobar',
                         'fatal: not removing '
                         '\'.gitignore\' recursively without -r'))
            == True)



# Generated at 2022-06-24 06:56:08.829462
# Unit test for function match
def test_match():
    assert match(Command('git rm filename',
        'fatal: not removing \'filename\' recursively without -r \n',
        '', 1))
    assert not match(Command('git rm -r filename',
        'fatal: not removing \'filename\' recursively without -r \n',
        '', 1))
    assert not match(Command('git rm filename', '', '', 1))


# Generated at 2022-06-24 06:56:12.733423
# Unit test for function match
def test_match():
    assert(match(Command('git rm -rf script.sh',
        'fatal: not removing \'script.sh\' recursively without -r')))
    assert(not match(Command('git rm -rf script.sh', '')))

