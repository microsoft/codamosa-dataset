

# Generated at 2022-06-24 06:46:16.203097
# Unit test for function match
def test_match():
    assert match(Command('git rm file_name.txt', '', '', 0, None))
    assert match(Command('git rm --force -r file_name.txt', '', '', 0, None))
    assert not match(Command('git rm --cached file_name.txt', '', '', 0, None))


# Generated at 2022-06-24 06:46:22.186053
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command(script='git rm file')
    command1.output = 'fatal: not removing \'file\' recursively without -r'
    command2 = Command(script='git rm -r file')
    command2.output = 'fatal: not removing \'file\' recursively without -r'
    assert(get_new_command(command1) == 'git rm -r file')
    assert(get_new_command(command2) == 'git rm -r -r file')
    # this should not match
    command3 = Command(script='git rm file')
    command3.output = 'fatal: not removing \'file\''
    assert(match(command3) == False)
    assert(get_new_command(command3) == 'git rm file')


# Generated at 2022-06-24 06:46:24.580679
# Unit test for function match
def test_match():
    assert match('git rm file.txt')
    assert match('git rm bin')
    assert not match('git rm file.txt -rf')
    assert not match('git rm')
    assert not match('rm file.txt')


# Generated at 2022-06-24 06:46:34.602591
# Unit test for function get_new_command
def test_get_new_command():
    # Test 1
    command1 = Command(script='git rm -rf',
                       stderr="fatal: not removing 'a' recursively without -r")
    assert get_new_command(command1) == 'git rm -rf -r'

    # Test 2
    command2 = Command(script='git rm  a',
                       stderr="fatal: not removing 'a' recursively without -r")
    assert get_new_command(command2) == 'git rm -r a'

    # Test 3
    command3 = Command(script='git rm a b c',
                       stderr="fatal: not removing 'a' recursively without -r")
    assert get_new_command(command3) == 'git rm -r a b c'

    # Test 4

# Generated at 2022-06-24 06:46:38.285348
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='rm -f file.txt',
                      stdout="fatal: not removing 'file.txt' recursively without -r",
                      stderr='')
    assert get_new_command(command) == 'rm -r -f file.txt'

# Generated at 2022-06-24 06:46:44.009603
# Unit test for function match
def test_match():
    assert match(Command('rm filename', 'fatal: not removing '
        'filename recursively without -r'))
    assert not match(Command('git rm filename', 'fatal: not removing '
        'filename recursively without -r'))
    assert not match(Command('rm filename', 'fatal: not removing '
        'filename recursively without -r\n'))
    assert not match(Command('git rm filename', 'fatal: not removing'))



# Generated at 2022-06-24 06:46:46.127283
# Unit test for function match
def test_match():
    assert match(Command(
        script='git rm -r dir/',
        output='fatal: not removing \'dir/\' recursively without -r\n'))



# Generated at 2022-06-24 06:46:52.338640
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git pull'
    new_command = get_new_command(command)
    assert u'git pull' == new_command
    command = 'git rm file'
    new_command = get_new_command(command)
    assert u'git rm -r file' == new_command
    command = 'git rm -r file'
    new_command = get_new_command(command)
    assert u'git rm -r -r file' == new_command

# Generated at 2022-06-24 06:46:56.170114
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git rm -rf foo bar',
                            stderr='fatal: not removing \'foo\' recursively without -r')) == 'git rm -rf -r foo bar'

# Generated at 2022-06-24 06:46:59.257554
# Unit test for function get_new_command
def test_get_new_command():
    # Test correct implementation
    assert get_new_command('git rm file') == "git rm -r file"
    # Test incorrect implementation
    assert get_new_command('git mv file') == "git mv file"

# Generated at 2022-06-24 06:47:02.317677
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r test/' in get_new_command(Command(script='git rm test/', output='fatal: not removing \'test\' recursively without -r'))

# Generated at 2022-06-24 06:47:04.585764
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file.txt', '', '')) == u'git rm -r file.txt'


# Generated at 2022-06-24 06:47:08.482926
# Unit test for function match
def test_match():
    command = Command('rm -r a/b/c',
                      "fatal: not removing 'a/b/c' recursively without -r\n")
    assert match(command)
    command = Command('rm  a/b/c',
                      "fatal: not removing 'a/b/c' recursively without -r\n")
    assert match(command)
    command = Command('rm -rf a/b/c')
    assert not match(command)
    command = Command('rm a/b/c')
    assert not match(command)


# Generated at 2022-06-24 06:47:11.088421
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f myfile',
                      """fatal: not removing 'myfile' recursively without -r\n""")
    assert get_new_command(command) == "git rm -f -r myfile"

# Generated at 2022-06-24 06:47:13.143338
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo', '', '', '', '', '')) == 'git rm -r foo'

# Generated at 2022-06-24 06:47:17.803427
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt', ''))
    assert not match(Command('ls file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-24 06:47:24.922619
# Unit test for function match
def test_match():
    assert(match(Command(' git rm foo',
                         'fatal: not removing \'foo\' recursively without -r\n')))
    assert(match(Command(' git rm foo/bar',
                         'fatal: not removing \'foo/bar\' recursively without -r\n')))
    assert(not match(Command(' git rm foo', '')))
    assert(not match(Command(' rm foo',
                              'fatal: not removing \'foo\' recursively without -r\n')))
    assert(not match(Command(' git mv foo',
                              'fatal: not removing \'foo\' recursively without -r\n')))


# Generated at 2022-06-24 06:47:28.747569
# Unit test for function get_new_command
def test_get_new_command():
    script = "git rm file.txt"
    output = "fatal: not removing 'file.txt' recursively without -r"
    command = Command(script, None, output)
    assert get_new_command(command) == "git rm -r file.txt"

# Generated at 2022-06-24 06:47:33.090174
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {
        'script_parts': ['git', 'rm', '--cached'],
        'output': "fatal: not removing 'SETUP.md' recursively without -r"})
    output1 = 'git rm -r --cached'
    assert get_new_command(command) == output1

# Generated at 2022-06-24 06:47:35.886256
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm pwd', 'fatal: not removing \'pwd\' recursively without -r')
    assert get_new_command(command) == 'git rm -r pwd'

# Generated at 2022-06-24 06:47:41.348711
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git rm -r file1.txt',
                'fatal: not removing \'file1.txt\' recursively without -r\n')) == 'git rm -r -r file1.txt'

    assert get_new_command(
        Command('rm file1.txt',
                'fatal: not removing \'file1.txt\' recursively without -r')) != 'rm -r -r file2.txt'


# Generated at 2022-06-24 06:47:48.980654
# Unit test for function match
def test_match():
    assert match(Command('rm filename', '', 'fatal: not removing \'filename\' recursively without -r'))
    assert not match(Command('git rm filename', '', 'fatal: not removing \'filename\' recursively without -r'))
    assert not match(Command('rm filename', '', 'fatal: not removing \'filename\' recursively without -r', '', '', ''))
    assert not match(Command('rm filename', '', 'fatal: not removing \'filename\' recursively without -r', '', None, None))
    assert not match(Command('rm filename', '', 'fatal: not removing \'filename\' recursively without -r', '', 1, None))
    assert not match(Command('rm filename', '', 'fatal: not removing \'filename\' recursively without -r', '', None, 0))

# Generated at 2022-06-24 06:47:53.918555
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -Rf --cached a/file.js',
                      'fatal: not removing \'a/file.js\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r -Rf --cached a/file.js'

# Generated at 2022-06-24 06:47:57.341260
# Unit test for function match
def test_match():
    from thefuck.rules.git_rm import match
    assert match(Command('git rm -v-r --cached', 'fatal: not removing \'file/\' recursively without -r'))
    assert match(Command('git rm -v -r --cached', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-24 06:47:59.765252
# Unit test for function get_new_command
def test_get_new_command():
    assert_equal(get_new_command(Command('git rm my_dir', '')),
                 'git rm -r my_dir')

# Generated at 2022-06-24 06:48:02.820559
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')) == 'git rm -r foo'

# Generated at 2022-06-24 06:48:10.708563
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command(script="git rm -r ui/views/",
                       stderr="fatal: not removing 'ui/views/' recursively without -r")
    command2 = Command(script="git rm ui/views/",
                       stderr="fatal: not removing 'ui/views/' recursively without -r")
    command3 = Command(script="git rm ui/views/", output="fatal: not removing 'ui/views/' recursively without -r")

    assert get_new_command(command1) == "git rm -r ui/views/"
    assert get_new_command(command2) == "git rm -r ui/views/"
    assert get_new_command(command3) == "git rm -r ui/views/"

# Generated at 2022-06-24 06:48:14.727627
# Unit test for function match
def test_match():
    assert match(Command(script='git rm -rf',
                         output="fatal: not removing 'template/somedir' recursively without -r"))
    assert not match(Command(script='git rm -- -rf',
                             output="fatal: not removing 'template/somedir' recursively without -r"))


# Generated at 2022-06-24 06:48:17.206994
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('', ''))
    assert not match(Command('git status', ''))


# Generated at 2022-06-24 06:48:20.903173
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r folder', '', 'fatal: not removing \'folder\' recursively without -r')) == 'git rm -r folder'
    assert get_new_command(Command('git rm folder', '', 'fatal: not removing \'folder\' recursively without -r')) == 'git rm -r folder'
    assert get_new_command(Command('git rm folder/file', '', 'fatal: not removing \'folder/file\' recursively without -r')) == 'git rm -r folder/file'

# Generated at 2022-06-24 06:48:23.592916
# Unit test for function match
def test_match():
    command = Command(' git reset nh', '', 'fatal: not removing \'nh\' recursively without -r')
    assert match(command)



# Generated at 2022-06-24 06:48:26.567450
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3', '', 'fatal: not removing \'file1\' recursively without -r'))


# Generated at 2022-06-24 06:48:29.423572
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test/foo', u"fatal: not removing 'test/foo' recursively without -r")
    assert get_new_command(command) == 'git rm -r -r test/foo'

# Generated at 2022-06-24 06:48:34.288797
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    script = Command('git rm')
    output = '''fatal: not removing 'test/test_helper.rb' recursively without -r
'
Test5
'''
    new_command = get_new_command(Command(script=script, output=output))
    assert new_command == 'git rm -r'


# Generated at 2022-06-24 06:48:36.624591
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursively import get_new_command
    command = 'git rm test'
    assert get_new_command(command) == 'git rm -r test'


# Generated at 2022-06-24 06:48:41.701459
# Unit test for function get_new_command
def test_get_new_command():
    """Test to get new command"""
    from thefuck.rules.git_rm import get_new_command
    assert get_new_command(Command('git rm -rf directory', 'fatal: not removing \'directory\' recursively without -r\n')) == u'git rm -r -rf directory'

# Generated at 2022-06-24 06:48:42.618560
# Unit test for function match

# Generated at 2022-06-24 06:48:45.228176
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -rf')) == 'git rm -rf'

# Generated at 2022-06-24 06:48:52.363278
# Unit test for function match
def test_match():
    # Test if match is true when command is 'git rm'
    command = Command(script='git rm', output='fatal: not removing \'dir\' recursively without -r')
    assert match(command) == True
    # Test if match is false when command is 'rm'
    command = Command(script='rm', output='fatal: not removing \'dir\' recursively without -r')
    assert match(command) == False
    # Test if match is false when command is 'git rm' with no output
    command = Command(script='git rm', output='')
    assert match(command) == False
    # Test if match is false when command is 'git rm' with altered output
    command = Command(script='git rm', output='fatal: not removing \'dir\' recursively without -a')
    assert match(command) == False


# Generated at 2022-06-24 06:48:54.005601
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r file_name', 'fatal: not removing \'file_name\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file_name'

# Generated at 2022-06-24 06:48:55.274147
# Unit test for function get_new_command
def test_get_new_command():
    assert('git rm -r test' == get_new_command('git rm test'))

# Generated at 2022-06-24 06:49:00.730050
# Unit test for function match
def test_match():
    assert match(Command('git branch -r test', 'fatal: not removing \'test\' recursively without -r\n'))
    assert not match(Command('git branch -r', 'fatal: not removing \'\' recursively without -r\n'))
    assert not match(Command('echo test', 'fatal: not removing \'\' recursively without -r\n'))


# Generated at 2022-06-24 06:49:04.537045
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf test', 'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm -rf test', 'error: not removing \'test\' recursively without -r'))


# Generated at 2022-06-24 06:49:07.087421
# Unit test for function match
def test_match():
    command = Command(script='git rm foo',
                      stderr='fatal: not removing \'foo\' recursively without -r')
    assert match(command)


# Generated at 2022-06-24 06:49:09.749987
# Unit test for function match
def test_match():
    assert match(Command('git rm -r ',
        'fatal: not removing \'.gitignore\' recursively without -r\n',
        ''))
    assert not match(Command('git rm',
        '',
        ''))


# Generated at 2022-06-24 06:49:11.556375
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r'))


# Generated at 2022-06-24 06:49:15.767658
# Unit test for function match
def test_match():
    assert match(Command('git rm foo/bar', ''))
    assert match(Command('git rm foo/bar bar/foo', ''))
    assert match(Command('git rm -r foo/bar', '')) is False
    assert match(Command('git foo', '')) is False
    assert match(Command('rm foo/bar', '')) is False



# Generated at 2022-06-24 06:49:23.891988
# Unit test for function match
def test_match():
    assert match(Command('git branch -D branch_name',
                         'error: branch \'branch_name\' not found.', ''))
    assert not match(Command('git branch -D branch_name',
                             '', ''))
    assert match(Command(' git branch -D branch_name',
                         'error: branch \'branch_name\' not found.', ''))
    assert not match(Command(' git branch -D branch_name',
                             'error: branch \'branch_name\' not found.'))
    assert match(Command('git branch -D branch_name',
                         'error: branch \'branch_name\' not found.\n', ''))
    assert not match(Command(' git branch -D branch_name',
                             '', ''))

# Generated at 2022-06-24 06:49:29.980881
# Unit test for function get_new_command
def test_get_new_command():
    repo_path = 'sample_repo'
    cur_dir = os.getcwd()
    os.chdir('tests/'+repo_path)

    # Create dir and a dummy file to delete
    temp_dir = tempfile.mkdtemp()
    subprocess.call(['git', 'checkout', 'master'])
    subprocess.call(['touch', temp_dir])

    # Create a dummy command and command.output
    command = Command('git rm ' + temp_dir, repo_path)
    command.output = 'fatal: not removing \'' + temp_dir + '\' recursively without -r'

    new_command = u'git rm -r ' + temp_dir
    assert get_new_command(command) == new_command
    os.chdir(cur_dir)

# Generated at 2022-06-24 06:49:35.515978
# Unit test for function match
def test_match():
    assert match(Command('rm file', '', 'fatal: not removing \'file\' recursively without -r'))
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('rm -r file', '', ''))


# Generated at 2022-06-24 06:49:40.693620
# Unit test for function match
def test_match():
    str_cmd_not_match = 'git status'
    str_cmd_match = 'git rm ./testfile'
    
    cmd_not_match = Command(str_cmd_not_match,
                            '',
                            '')
    assert not match(cmd_not_match)
    
    cmd_match = Command(str_cmd_match,
                        '',
                        'fatal: not removing \'./testfile\' recursively without -r')
    assert match(cmd_match)
    

# Generated at 2022-06-24 06:49:45.930290
# Unit test for function get_new_command
def test_get_new_command():
    command = type(
        'Command',
        (object,),
        {
            'script': 'git rm fileName',
            'script_parts': ['git', 'rm', 'fileName'],
            'output': "fatal: not removing 'fileName' recursively without -r"
        }
    )

    assert get_new_command(command) == 'git rm -r fileName'

# Generated at 2022-06-24 06:49:55.745131
# Unit test for function get_new_command
def test_get_new_command():
    # Test case #1: rm a.txt
    # Script parts: ['git', 'rm', 'a.txt']
    # Command parts: ['git', 'rm', '-r', 'a.txt']
    assert get_new_command(type('obj', (object,), {'script_parts': ['git', 'rm', 'a.txt']})) == 'git rm -r a.txt'

    # Test case #2: git rm a.txt b.txt
    # Script parts: ['git', 'rm', 'a.txt', 'b.txt']
    # Command parts: ['git', 'rm', '-r', 'a.txt', 'b.txt']

# Generated at 2022-06-24 06:50:04.379113
# Unit test for function match
def test_match():
    assert git_support(match)(Command("git rm file.txt", "fatal: not removing 'file.txt' recursively without -r"))
    assert git_support(match)(Command("git rm file.txt", "fatal: not removing 'file.txt' recursively without -r", "error"))
    assert git_support(match)(Command("git rm file.txt", "fatal: not removing 'file.txt' recursively without -r", "error", "error"))
    assert git_support(match)(Command("git rm file.txt", "fatal: not removing 'file.txt' recursively without -r", "error", "error", "error"))

# Generated at 2022-06-24 06:50:06.945124
# Unit test for function match
def test_match():
    assert_true(match(Command(script='git rm -r a b c',
                              output='fatal: not removing \'a\' recursively without -r')))
    assert_false(match(Command(script='git rm a b c',
                               output='fatal: not removing \'a\' recursively without -r')))
    assert_false(match(Command(script='git rm -r a b c',
                               output='fatal: not removing \'a\' without -r')))

# Generated at 2022-06-24 06:50:09.982024
# Unit test for function get_new_command
def test_get_new_command():
	from thefuck.rules.git_rm_recursive import get_new_command
	expected = u'git rm -r random_project'
	assert get_new_command(Mock(script=u'git rm random_project', output=u"fatal: not removing 'random_project' recursively without -r")) == expected

# Generated at 2022-06-24 06:50:15.428298
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test',
                                   'fatal: not removing \'test\' recursively without -r')) == 'git rm -r test'
    assert get_new_command(Command('git rm test/',
                                   'fatal: not removing \'test/\' recursively without -r')) == 'git rm -r test/'

# Generated at 2022-06-24 06:50:18.560842
# Unit test for function match
def test_match():
    assert match(Command('git rm *',
    'fatal: not removing \'README.md\' recursively without -r'))
    assert not match(Command('git rm *', ''))


# Generated at 2022-06-24 06:50:25.379727
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file1 file2 file3',
                         'fatal: not removing \'file2\' recursively without -r'))
    assert match(Command('git rm file1',
                         'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git rm file1', ''))
    assert not match(Command('git rm file1', 'fatal: not removing \'file1\' recursively without it'))
    assert not match(Command('git rm file1', 'fatal: not removing \'file1\' recursively without -r\n'
                                             'fatal: not removing \'file1\' recursively without -r'))
    
    

# Generated at 2022-06-24 06:50:32.613030
# Unit test for function match
def test_match():
    def _match(cmd, err):
        com = Command(cmd, err)
        assert match(com)
    _match('git branch branch_with_spaces',
            "fatal: not removing 'branch_with_spaces' recursively without -r")
    _match('git rm file',
            "fatal: not removing 'file' recursively without -r")
    _match('git branch branch_with_spaces',
            "fatal: not removing 'branch_with_spaces' recursively without -r")
    _match('git rm file',
            "fatal: not removing 'file' recursively without -r")
    assert not match(Command('git rm -r',
                             "fatal: not removing 'file' recursively without -r"))

# Generated at 2022-06-24 06:50:35.162891
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm file', output='fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-24 06:50:40.401209
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_force_rm_dir import get_new_command
    assert get_new_command('git rm dir') == 'git rm -r dir'
    assert get_new_command('git rm -r dir') == 'git rm -r dir'
    assert get_new_command('git rm -rf dir') == 'git rm -rf -r dir'

# Generated at 2022-06-24 06:50:46.681576
# Unit test for function get_new_command
def test_get_new_command():
    from test_utils import assert_equals
    assert_equals(get_new_command('git rm file-name', [], ''), 'git rm -r file-name')
    assert_equals(get_new_command('git rm -r file-name', [], ''), 'git rm -r file-name')
    assert_equals(get_new_command('git rm --cached file-name', [], ''), 'git rm -r --cached file-name')

# Generated at 2022-06-24 06:50:53.085990
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm bla/bla',
                      'fatal: not removing \'bla/bla\' recursively without -r\n')
    assert get_new_command(command) == "git rm -r bla/bla"
    command = Command('git rm -qf bla/bla',
                      'fatal: not removing \'bla/bla\' recursively without -r\n')
    assert get_new_command(command) == "git rm -qf -r bla/bla"
    command = Command('git rm -fr bla/bla',
                      'fatal: not removing \'bla/bla\' recursively without -r\n')
    assert get_new_command(command) == "git rm -fr -r bla/bla"


# Generated at 2022-06-24 06:50:59.775836
# Unit test for function match
def test_match():
    command = Command('git rm -r my_folder')
    assert not match(command)
    assert git_support(command)
    out = ("fatal: not removing 'my_folder' recursively without -r\n"
           "Did you mean 'rm -r'?")
    command = Command('git rm -r my_folder', out)
    assert match(command)
    assert git_support(command)
    command = Command('git rm -rf my_folder', out)
    assert not match(command)
    assert git_support(command)


# Generated at 2022-06-24 06:51:03.546260
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('rm file',
                             'fatal: not removing \'file\' recursively without -r\n'))

# Generated at 2022-06-24 06:51:05.680404
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1 file2', '/bin')) == 'git rm -r file1 file2'

# Generated at 2022-06-24 06:51:15.796251
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command("git rm a\\\ndsf") == "git -r rm a\\\ndsf")
    assert(get_new_command("git rm asdff") == "git -r rm asdff")
    assert(get_new_command("git rm --cached asdff") == "git rm -r --cached asdff")
    assert(get_new_command("git rm -r --cached asdff") == "git rm -r --cached asdff")
    assert(get_new_command("git rm --cached -r asdff") == "git rm -r --cached -r asdff")

# Generated at 2022-06-24 06:51:17.795245
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git fsd rm me -f') == 'git fsd rm -r me -f'



# Generated at 2022-06-24 06:51:20.771973
# Unit test for function match
def test_match():
    assert match(Command('git status',
                'fatal: not removing \'<file>\' recursively without -r\n'))
    assert not match(Command('git status',''))
    assert not match(Command('git rm test.txt',''))


# Generated at 2022-06-24 06:51:23.624764
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r')) == 'git rm -r dir'

# Generated at 2022-06-24 06:51:28.483664
# Unit test for function match
def test_match():
    assert match(Command('git branch -d blah/blahblah',
                         'error: branch \'blah/blahblah\' not found.'))
    assert not match(Command('git branch -d blah',
                             'error: branch \'blah/blahblah\' not found.'))


# Generated at 2022-06-24 06:51:33.374078
# Unit test for function get_new_command
def test_get_new_command():
    command = type("Command", (object,), {"script" : "git rm file", "script_parts" : ["git", "rm", "file"], "output" : "fatal: not removing 'file' recursively without -r"})
    assert get_new_command(command) == "git rm -r file"

# Generated at 2022-06-24 06:51:35.980015
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -rf folder', '', '')
    assert get_new_command(command) == 'git rm -r -rf folder'

# Generated at 2022-06-24 06:51:40.024115
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command
    result = get_new_command(
        Command('rm -r foo', "fatal: not removing 'foo' recursively without -r"))
    assert result == 'git rm -r foo'

# Generated at 2022-06-24 06:51:41.735603
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r path')) == 'git rm -r -r path'

# Generated at 2022-06-24 06:51:43.611026
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm file")=="git rm -r file"

# Generated at 2022-06-24 06:51:47.274605
# Unit test for function get_new_command
def test_get_new_command():
    fixed_command = get_new_command(Command('git rm -r test',
                                            'fatal: not removing \'test\' recursively without -r'))
    assert fixed_command == "git rm -r test"

# Generated at 2022-06-24 06:51:50.163989
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('rm test',
    'fatal: not removing \'test\' recursively without -r\n')) == 'git rm -r test')


# Generated at 2022-06-24 06:51:52.216234
# Unit test for function get_new_command
def test_get_new_command():
    from test_fixtures import GitCommand
    assert get_new_command(GitCommand(script="git rm directory")) == 'git rm -r directory'

# Generated at 2022-06-24 06:51:55.324111
# Unit test for function match
def test_match():
    assert match(Command(' git rm myfile.txt',
    'fatal: not removing \'myfile.txt\' recursively without -r'))
    assert not match(Command('git rm myfile.txt', 'something'))


# Generated at 2022-06-24 06:51:57.485608
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test')
    assert get_new_command(command) == 'git rm -r test'


# Generated at 2022-06-24 06:52:00.485766
# Unit test for function match
def test_match():
    command = Command('rm dir', 'fatal: not removing \'dir\' recursively without -r')
    assert match(command)


# Generated at 2022-06-24 06:52:08.808690
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = u'git rm -r foo',
    				  stderr=u"fatal: not removing 'foo' recursively without -r\n")
    assert (get_new_command(command) ==
            u'git rm -r -r foo')

    command = Command(script = u'git rm foo',
    				  stderr=u"fatal: not removing 'foo' recursively without -r\n")
    assert (get_new_command(command) ==
            u'git rm -r foo')

    command = Command(script = u'git rm foo bar',
    				  stderr=u"fatal: not removing 'bar' recursively without -r\n")

# Generated at 2022-06-24 06:52:13.116637
# Unit test for function match
def test_match():
    assert match(Command("git rm directory/file", "fatal: not removing 'directory/file' recursively without -r"))
    assert not match(Command("git rm file", "fatal: not removing 'directory/file' recursively without -r"))

# Generated at 2022-06-24 06:52:20.570095
# Unit test for function match
def test_match():
    assert match(Command('rm file', '', 'fatal: not removing \'file\' recursively without -r')) == True
    assert match(Command('', '', 'fatal: not removing \'file\' recursively without -r')) == False
    assert match(Command('rm file', '', 'fatal: not removing \'file\'')) == False
    assert match(Command('', '', 'fatal: not removing \'file\' recursively without -r')) == False
    assert match(Command('rm file', '', 'fatal: removing \'file\' recursively without -r')) == False


# Generated at 2022-06-24 06:52:22.075515
# Unit test for function match

# Generated at 2022-06-24 06:52:25.391727
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                    'fatal: not removing \'bar/foo\' recursively without -r'))
    assert not match(Command('git rm foo',
                    'fatal: not removing \'bar'))

# Generated at 2022-06-24 06:52:28.473801
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f', '')) == 'git rm -f -r'
    assert get_new_command(Command('git rm -f my_folder/', '')) == 'git rm -f -r my_folder/'

# Generated at 2022-06-24 06:52:29.549504
# Unit test for function match

# Generated at 2022-06-24 06:52:39.895908
# Unit test for function match
def test_match():
    # True case
    assert match(
        Command('git rm ../Test_Repo/test/test_match.py',
                'fatal: not removing \'../Test_Repo/test/test_match.py\' \
recrusively without -r'))
    # False case
    assert not match(
        Command('git rm ../Test_Repo',
                ''))
    assert not match(
        Command('git rm ../Test_Repo/test/test_match.py',
                ''))
    assert not match(
        Command('git rm ../Test_Repo/test/test_match.py',
                'fatal: not removing \'../Test_Repo/test/test_match.py\' \
recrusively without -r', 'Not a git command'))


# Generated at 2022-06-24 06:52:43.965696
# Unit test for function match
def test_match():
    assert match(Command('git br', output='fatal: not removing \'<target>\' recursively without -r'))
    assert match(Command('git rm README', output='fatal: not removing \'<target>\' recursively without -r'))



# Generated at 2022-06-24 06:52:47.347498
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command("git rm -rf dir") == u'git rm -r -rf dir')
    assert(get_new_command("git rm -rf dir/") == u'git rm -r -rf dir/')

# Generated at 2022-06-24 06:52:50.821441
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command

    assert get_new_command(Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r', '', 0, '')) == "git rm -r dir"

# Generated at 2022-06-24 06:52:55.141432
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -rf a', 'fatal: not removing '
        'a\' recursively without -r\n')) == 'git rm -rf -r a'

# Generated at 2022-06-24 06:53:03.543464
# Unit test for function match
def test_match():
    # Test for Git
    assert match(Command('git rm file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r',
                         '', 3))
    assert not match(Command('git rm -r file.txt',
                             'fatal: not removing \'file.txt\' recursively without -r',
                             '', 3))
    # Test for Github
    assert match(Command('github rm file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r',
                         '', 3))
    assert not match(Command('github rm -r file.txt',
                             'fatal: not removing \'file.txt\' recursively without -r',
                             '', 3))


# Generated at 2022-06-24 06:53:06.298564
# Unit test for function match
def test_match():
    assert match(Command('git rm *.pyc',
                         'fatal: not removing \'foo.pyc\' recursively without -r\n',
                         '/home/jakeday/git-repos/python-leap/'))


# Generated at 2022-06-24 06:53:09.458876
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file.txt'

# Generated at 2022-06-24 06:53:12.058962
# Unit test for function match
def test_match():
    command = Command('git rm -r filename', 'fatal: not removing \'filename\' recursively without -r\nfatal: pathspec \'filename\' did not match any files')
    assert match(command)


# Generated at 2022-06-24 06:53:13.824226
# Unit test for function match
def test_match():
    assert match(Command('git rm', '', 'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-24 06:53:19.057904
# Unit test for function match
def test_match():
    assert match(Command('git rm file1', 'fatal: not removing \'file1\' recursively without -r\n'))
    assert not match(Command('git rm file1', ''))
    assert not match(Command('rm file1', ''))
    assert not match(Command('git rm file1', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git rm file1', 'fatal: not removing \'file1\' recursively without -r\n', 'other'))


# Generated at 2022-06-24 06:53:22.972811
# Unit test for function match
def test_match():
    assert match(Command('git branch -d master', '', 'error: cannot delete branch \'master\' checked out at \'/Users/dang/Git/pwclient\'\n', 0))
    assert match(Command(u'git rm a', '', u"fatal: not removing 'a' recursively without -r", 0))
    assert not match(Command('git rm a', '', '', 0))
    assert not match(Command(u'git rm -r a', '', '', 0))
    assert not match(Command('', '', '', 0))


# Generated at 2022-06-24 06:53:25.734862
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r "test"', "fatal: not removing 'test' recursively without -r")
    assert get_new_command(command) == 'git rm -r "test"'

# Generated at 2022-06-24 06:53:33.083808
# Unit test for function get_new_command
def test_get_new_command():
    #Test case 1: expected output is same as example
    command = Command(script='git rm file',
            stderr="fatal: not removing 'file' recursively without -r")
    assert(get_new_command(command) == 'git rm -r file')

    #Test case 2: Command does not contain 'rm'
    command = Command(script='git add file',
            stderr="fatal: not adding 'file' recursively without -a")
    assert(get_new_command(command) == 'git add file')

# Generated at 2022-06-24 06:53:34.853572
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm index.htm', '', '')
    globals()['get_new_command'](command)

# Generated at 2022-06-24 06:53:38.031509
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm file/") == "git rm -r file/"
    assert get_new_command("git rm file/ ") == "git rm -r file/ "
    assert get_new_command("git rm file/asd") == "git rm -r file/asd"


# Generated at 2022-06-24 06:53:44.136777
# Unit test for function match
def test_match():
    assert match(Command('git rm -r alice',
                         'fatal: not removing \'alice\' recursively without -r\n',
                         ''))
    
assert get_new_command(Command('git rm -r alice',
                                'fatal: not removing \'alice\' recursively without -r\n',
                                '')) == 'git rm -r -r alice'

# Generated at 2022-06-24 06:53:48.340049
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: not removing \'dir/\' recursively without -r',
                         'git rm dir/'))
    assert not match(Command('git status',
                             'fatal: not removing \'dir/\' with -r',
                             'git rm dir/'))

# Generated at 2022-06-24 06:53:52.539815
# Unit test for function match
def test_match():
    assert match("git rm 'file.txt'")
    assert match("git rm -r 'folder'")
    assert match("git rm folder/")
    assert not match("git rm")
    assert match("git rm -f 'file.txt'")
    assert match("git rm file.txt")


# Generated at 2022-06-24 06:53:57.375757
# Unit test for function get_new_command
def test_get_new_command():
    from types import ModuleType
    from mock import Mock

    mock_command = type('obj', (object,), {
        'script': 'git rm file',
        'script_parts': ['git', 'rm', 'file'],
        'output': ("fatal: not removing 'file' recursively without -r")})
    assert get_new_command(mock_command) == "git rm -r file"

# Generated at 2022-06-24 06:53:59.374176
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test/test'))
    assert match(Command('git rm -f test/test'))


# Generated at 2022-06-24 06:54:04.744824
# Unit test for function match
def test_match():
    assert match(Command('git rm src/com/test.java',
        'fatal: not removing \'src/com/test.java\' recursively without -r\n',
    ))
    assert not match(Command('rm src/com/test.java',
        'fatal: not removing \'src/com/test.java\' recursively without -r\n',
    ))


# Generated at 2022-06-24 06:54:08.300957
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf foo', '\nfatal: not removing \'foo\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -rf -r foo'


# Generated at 2022-06-24 06:54:11.882899
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -r -f')) == 'git rm -r -r -f'


# Generated at 2022-06-24 06:54:16.835478
# Unit test for function get_new_command
def test_get_new_command():
    output = u"""fatal: not removing 'C:/Users/loic/Desktop/untitled folder/git_hub/arbin/tests/system/tmp/git-repo/long_file_name.css' recursively without -r
"""
    command = Command('git rm long_file_name.css', output)
    assert(get_new_command(command) == "git rm -r long_file_name.css")

# Generated at 2022-06-24 06:54:20.005926
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {
        'script': 'git rm -rf .idea/',
        'output': 'fatal: not removing \'.idea/\' recursively without -r'})
    assert get_new_command(command) == 'git rm -r -rf .idea/'

# Generated at 2022-06-24 06:54:22.990251
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm -r directory', 'fatal: not removing \'directory\' recursively without -r'))



# Generated at 2022-06-24 06:54:24.456978
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm dir/', 'error: no...')
    assert get_new_command(command) == 'git rm -r dir/'

# Generated at 2022-06-24 06:54:28.115386
# Unit test for function match
def test_match():
    assert match(Command('git rm -r dir', 'fatal: not removing \'dir\' recursively without -r'))
    assert not match(Command('git rm', 'fatal: not removing \'dir\' recursively without -r'))
    assert not match(Command('git rm -r dir', ''))


# Generated at 2022-06-24 06:54:31.307759
# Unit test for function match
def test_match():
    assert match(Command("git rm folder", "fatal: not removing 'folder' recursively without -r", None))
    assert match(Command("git rm -r folder", "fatal: not removing 'folder' recursively without -r", None))

# Generated at 2022-06-24 06:54:34.040073
# Unit test for function match
def test_match():
    command = Command('git rm test', 'fatal: not removing \'test\' recursively without -r')

    assert(match(command) is True)


# Generated at 2022-06-24 06:54:36.366858
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r dir', '')) == 'git rm dir'
    assert get_new_command(Command('git rm dir', '')) == 'git rm -r dir'

# Generated at 2022-06-24 06:54:41.742282
# Unit test for function match

# Generated at 2022-06-24 06:54:45.022576
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo', '''fatal: not removing 'foo' recursively without -r
Use --cached to keep the file, or make a new commit to, and then delete the file.
''', None)) == u'git rm -r foo'

# Generated at 2022-06-24 06:54:47.416294
# Unit test for function match

# Generated at 2022-06-24 06:54:50.937579
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r'
    assert get_new_command(Command('git rm')) == 'git rm'


# Generated at 2022-06-24 06:54:56.260498
# Unit test for function get_new_command
def test_get_new_command():
    command = u'rm -f .DS_Store'
    output = u'fatal: not removing \'.DS_Store\' recursively without -r'
    new_command = get_new_command(Command(script = command,
                                          output = output,
                                          env = os.environ))
    assert new_command == u'rm -f -r .DS_Store'

# Generated at 2022-06-24 06:54:59.661629
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -d file/to/delete', '', 'fatal: not removing \'file/to/delete\' recursively without -r')
    assert get_new_command(command) == 'git rm -d -r file/to/delete'

# Generated at 2022-06-24 06:55:01.877990
# Unit test for function match
def test_match():
    assert match(Command("git rm -r folder", "fatal: not removing 'folder' recursively without -r"))


# Generated at 2022-06-24 06:55:04.760694
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm resources',
                      'fatal: not removing \'resources\' recursively without -r\n',
                      '', 1)
    assert_equals(get_new_command(command), 'git rm -r resources')

# Generated at 2022-06-24 06:55:07.956933
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm a b c')) == 'git rm -r a b c'

# Generated at 2022-06-24 06:55:12.269043
# Unit test for function match
def test_match():
    assert match(Command('git rm foo'))
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r\n'))
    assert not match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r\n', 'bar'))
    assert not match(Command('git add foo'))


# Generated at 2022-06-24 06:55:16.792862
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm src', 'fatal: not removing \'src\' recursively without -r')) == u'git rm -r src'
    assert get_new_command(Command('git rm -a src', 'fatal: not removing \'src\' recursively without -r')) == u'git rm -r -a src'


# Generated at 2022-06-24 06:55:23.557651
# Unit test for function match
def test_match():
    assert match(Command('git rm testtest', 'fatal: not removing \'tests/test_something.py\' recursively without -r'))
    assert not match(Command('git add something', ''))
    assert not match(Command('git rm testtest', 
                             'fatal: not removing \'tests/test_something.py\' recursively without -r',
                             'fatal: not removing \'tests/test_something.py\' recursively without -r'))


# Generated at 2022-06-24 06:55:29.211939
# Unit test for function match
def test_match():
    assert match(Command('git rm w'))
    assert match(Command('git rm w', output='fatal: not removing ''w'' recursively without -r'))
    assert not match(Command('git rm w', output='fatal: not removing ''''w'' recursively without -r'))
    assert not match(Command('git rm w', output='fatal: not removing ''''w'''))


# Generated at 2022-06-24 06:55:39.850315
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))
    assert match(Command('git rm -r --cached file', 'fatal: not removing \'file\' recursively without -r'))
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert match(Command('git rm  .', 'fatal: not removing \'.\' recursively without -r'))
    assert not match(Command('git rm -r file', 'fatal: \'file\' is not a commit and a branch \'f\' cannot be created from it'))
    assert not match(Command('git rm -r file', 'fatal: not removing'))

# Generated at 2022-06-24 06:55:42.766698
# Unit test for function match
def test_match():
    assert match(Command('git rm -r names',
                         'fatal: not removing \'names\' recursively without -r'))


# Generated at 2022-06-24 06:55:46.023730
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('rm .git', '', 'fatal: not removing \'.git\' recursively without -r')) == 'git rm -r .git')

# Generated at 2022-06-24 06:55:50.063996
# Unit test for function get_new_command
def test_get_new_command():
    script = ['git', 'rm', 'foo']
    output = "fatal: not removing 'foo' recursively without -r\n" \
             "Did you mean 'rm -r'?"
    assert(get_new_command(Command(script, output)) ==
           'git rm -r foo')


# Generated at 2022-06-24 06:55:53.337734
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'
    assert get_new_command('git rm file1 file2') == 'git rm -r file1 file2'

# Generated at 2022-06-24 06:55:55.832000
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(u'git rm submodule', u"fatal: not removing 'submodule' recursively without -r")
    assert get_new_command(command) == u'git rm -r submodule'

# Generated at 2022-06-24 06:56:00.165911
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test', 'fatal: not removing \'test\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r test'
    command = Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r -r test'

# Generated at 2022-06-24 06:56:01.413148
# Unit test for function match
def test_match():
    assert match(Command('git commit'))
    assert not match(Command('echo Hello World!'))


# Generated at 2022-06-24 06:56:04.088488
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                stderr="fatal: not removing 'file' recursively without -r\n"))
    assert not match(Command('git rm -r file',
                stderr="fatal: not removing 'file' recursively without -r\n"))


# Generated at 2022-06-24 06:56:15.241933
# Unit test for function match
def test_match():
    from thefuck.rules.git_error_not_removing_recursively import match
    from tests.utils import Command

    assert match(Command('git rm file1 file2 file3'))
    assert match(Command('git rm file1 file2 file3',
         output='fatal: not removing \'file1\' recursively without -r\r\n'))
    assert match(Command('git rm file1 file2 file3',
         output='fatal: not removing \'file2\' recursively without -r\r\n'))

    assert not match(Command('git rm file1 file2 file3',
    output='fatal: not removing \'file1\' recursively without -r\r\n'))