

# Generated at 2022-06-24 06:46:15.133114
# Unit test for function get_new_command
def test_get_new_command():
    check_output = '''fatal: not removing 'moose/test.txt' recursively without -r
'''
    command = Command('git rm moose/test.txt', check_output)
    new_command = get_new_command(command)
    assert new_command == 'git rm -r moose/test.txt'

# Generated at 2022-06-24 06:46:17.145439
# Unit test for function match
def test_match():
    assert match(Command('git rm some_file',
                         'fatal: not removing \'some_file\' recursively without -r'))


# Generated at 2022-06-24 06:46:20.110566
# Unit test for function match
def test_match():
    # Test git rm file
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert match(command)
    assert get_new_command(command) == 'git rm -r file'

    assert not match(Command('git rm file'))

# Generated at 2022-06-24 06:46:24.342495
# Unit test for function match
def test_match():
    assert match(Command('git branch foo',
                         'fatal: not removing \'foo\' recursively without -r\n'))
    assert not match(Command('git branch foo',
                             'fatal: not removing \'foo\' recursively without -r\n',
                             'some error'))
    assert not match(Command('rm foo', 'not removing \'foo\' recursively without -r\n'))


# Generated at 2022-06-24 06:46:28.697597
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git rm NonExistentFolder/', '', 'fatal: not removing \'NonExistentFolder/\' recursively without -r')) == \
           'git rm -r NonExistentFolder/'



# Generated at 2022-06-24 06:46:30.887417
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm -r subdirectory', '')) == u'git rm -r -r subdirectory')

# Generated at 2022-06-24 06:46:34.847363
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursively import get_new_command
    assert get_new_command(
        Command('git rm .gitignore', 'fatal: not removing '
                '.gitignore recursively without -r\ndone', '')) == \
        'git rm -r .gitignore'

# Generated at 2022-06-24 06:46:40.777491
# Unit test for function match
def test_match():
	# git rm file name
	assert match("git rm file_name") 
	# rm file name
	assert not match("rm file_name")
	# git rm -r file_name
	assert not match("git rm -r file_name")
	# git rm -rf file_name
	assert not match("git rm -rf file_name")
	# git rm -f file_name
	assert not match("git rm -f file_name")


# Generated at 2022-06-24 06:46:44.067560
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt',
                             'fatal: not removing'))
    

# Generated at 2022-06-24 06:46:48.022010
# Unit test for function get_new_command
def test_get_new_command():
    command = Rule(match, get_new_command)
    script = u"git rm file_name"
    out = u"fatal: not removing 'file_name' recursively without -r\n "
    new_command = get_new_command(Command(script, out))
    assert new_command == script + ' -r'

# Generated at 2022-06-24 06:46:57.341340
# Unit test for function match
def test_match():
    # Test for the case when the error message is generated from 
    # git rm command and the message is due to the fact that
    # the user is trying to delete a non-empty directory
    # without using "-r" option.
    command = Command('git rm somedir/', u'', u'fatal: not removing \'somedir/\' recursively without -r')
    assert match(command)
    # Test for the case when the error message is generated from 
    # git rm command, and the message is due to any other 
    # reason other than trying to delete a non-empty directory
    # without using "-r" option.
    command = Command('git rm somedir/', u'', u'fatal: not removing \'somedir/\'')
    assert not match(command)
    # Test for the case when the error

# Generated at 2022-06-24 06:47:00.515967
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command.Command('git rm test', 'git rm test\nfatal: not removing \'test\' recursively without -r\n')) == 'git rm -r test'

# Generated at 2022-06-24 06:47:04.447750
# Unit test for function match
def test_match():
    match_stderr = '''\
 fatal: not removing 'test_directory/test.txt' recursively without -r
'''
    assert match(Command('rm test_directory/test.txt', stderr=match_stderr))


# Generated at 2022-06-24 06:47:06.450657
# Unit test for function match
def test_match():
    assert match(Command('git rm -r folder', '', ''))
    assert not match(Command('git rm folder', '', ''))

# Generated at 2022-06-24 06:47:08.658462
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm dir1 dir2', 'fatal: not removing \'dir1\' recursively without -r')) == 'git rm -r dir1 dir2'

# Generated at 2022-06-24 06:47:11.809475
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively with -r'))


# Generated at 2022-06-24 06:47:14.366172
# Unit test for function match
def test_match():
    assert match(Command('git rm 2'))
    assert match(Command('git rm 2', 'fatal: not removing \'2\' recursively without -r'))
    assert not match(Command('git rm 2', 'fatal: not removing \'2\' recursively without -r, 5'))

# Generated at 2022-06-24 06:47:18.634422
# Unit test for function match
def test_match():
	assert match(Command("git rm -r a", "fatal: not removing 'a' recursively without -r")) == True
	assert match(Command("git rm --cached a", "fatal: not removing 'a' recursively without -r")) == False


# Generated at 2022-06-24 06:47:22.129933
# Unit test for function match
def test_match():
    assert match(Command('git commit file', 'fatal: not removing \'file\' recursively without -r', ''))
    assert not match(Command('git commit file', '', ''))
    assert not match(Command('git commit file', '', ''))


# Generated at 2022-06-24 06:47:24.041369
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test')
    assert(get_new_command(command) == 'git rm -r test')

# Generated at 2022-06-24 06:47:28.210254
# Unit test for function get_new_command
def test_get_new_command():
    # git rm -rf "README.md"
    command = Command('git rm -f "README.md"',
                      'fatal: not removing \'README.md\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -rf "README.md"'

# Generated at 2022-06-24 06:47:35.365435
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2', 'fatal: not removing \'file1\' recursively without -r\n'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('rm file', 'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git lg', ''))


# Generated at 2022-06-24 06:47:37.505844
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-24 06:47:40.905864
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'
    assert get_new_command('git rm --cached foo') == 'git rm -r --cached foo'
    assert get_new_command('git rm -n foo') == 'git rm -r -n foo'

# Generated at 2022-06-24 06:47:45.234720
# Unit test for function get_new_command
def test_get_new_command():
    #Unit test for function get_new_command
    command = Command(script = 'git rm -f README.md', 
            stderr = 'fatal: not removing \'README.md\' recursively without -r\n',
            output = '', 
            env={})
    assert get_new_command(command) == 'git rm -f -r README.md'

# Generated at 2022-06-24 06:47:49.709366
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf ssh/jumphosts',
                         output="fatal: not removing 'ssh/jumphosts' recursively without -r"))
    assert not match(Command('git rm -rf ssh/jumphosts',
                             output="fatal: not removing 'ssh/jumphosts' recursively without -r\nblabla"))
    assert not match(Command('git rm -rf ssh/jumphosts',
                             output="blabla"))



# Generated at 2022-06-24 06:47:54.141095
# Unit test for function match
def test_match():
    command1 = Command('git rm test', "fatal: not removing 'test' recursively without -r")
    command2 = Command('git rm test2', "")
    command3 = Command('git rm test3', "fatal: not removing 'test' recursively without -r")

    assert match(command1)
    assert not match(command2)
    assert not match(command3)



# Generated at 2022-06-24 06:47:58.432389
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursive import get_new_command

    assert get_new_command(Command(script='git rm')) == 'git rm -r'
    assert get_new_command(Command(script='git rm -v')) == 'git rm -rv'
    assert get_new_command(Command(script="git rm -rf")) == "git rm -r -rf"

# Generated at 2022-06-24 06:48:03.543552
# Unit test for function match
def test_match():
    command = Command('git rm file', 'fatal: not removing \'dir\' recursively without -r')
    assert match(command)
    command = Command('git rm file', 'fatal: not removing \'dir\' recursively without -r', 'c')
    assert match(command)


# Generated at 2022-06-24 06:48:05.161558
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -r \'dst\'") == "git rm -r \'dst\' -r"

# Generated at 2022-06-24 06:48:07.944813
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git rm foo/', u"fatal: not removing 'foo/' recursively without -r")).script ==
            'git rm -r foo/')

# Generated at 2022-06-24 06:48:10.636828
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', None))
    assert not match(Command('git pull', None))

# Generated at 2022-06-24 06:48:12.635593
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git rm dir')) == 'git rm -r dir'

# Generated at 2022-06-24 06:48:14.849687
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm --cached -r dir/')
    assert get_new_command(command) == 'git rm -r --cached -r dir/'

# Generated at 2022-06-24 06:48:17.160583
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r src",
                      "fatal: not removing 'src' recursively without -r")
    assert get_new_command(command) == "git rm -r -r src"

# Generated at 2022-06-24 06:48:18.913621
# Unit test for function match
def test_match():
    assert match(Command(script='git rm foo/bar.txt',
                         output='fatal: not removing foo/bar.txt recursively without -r'))
    assert not match(Command())


# Generated at 2022-06-24 06:48:29.385884
# Unit test for function match
def test_match():
    assert not match(Command('git', output=''))
    assert not match(Command('git rm', output=''))
    assert not match(Command('git rm foo', output='fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo', output='fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm -r foo', output=''))

    assert match(Command('git rm foo', output='fatal: not removing \'foo\' recursively without -r'))
    assert match(Command('git rm -rf foo', output='fatal: not removing \'foo\' recursively without -r'))

    assert not match(Command('git rm --cached foo', output='fatal: not removing \'foo\' recursively without -r'))

# Generated at 2022-06-24 06:48:36.696888
# Unit test for function match
def test_match():
    assert match(Command('rm README.md',
                         'fatal: not removing \'README.md\''
                         ' recursively without -r'))
    assert not match(Command('rm README.md',
                         'fatal: not removing \'README.md\''
                         ' recursively without -r',
                         '/bin'))
    assert not match(Command('rm README.md',
                         'fatal: not removing \'README.md\'',
                         '/bin'))
    assert not match(Command('rm README.md',
                         'fatal: not removing \'README.md\'',
                         '/bin'))


# Generated at 2022-06-24 06:48:46.826033
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm -rf a b c',
                                   output='foo', stderr='fatal: not removing \'a\' recursively without -r')) == 'git rm -rf -r a b c'
    assert get_new_command(Command(script='git rm -rf a b c',
                                   output='foo', stderr='fatal: not removing \'a\' recursively without -r')) == 'git rm -rf -r a b c'
    assert get_new_command(Command(script='git rm -rf a b c',
                                   output='foo', stderr='fatal: not removing \'a\' recursively without -r')) == 'git rm -rf -r a b c'

# Generated at 2022-06-24 06:48:48.908684
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert (get_new_command(Command('git rm path/to/dir', '', '', ''))
            == 'git rm -r path/to/dir')



# Generated at 2022-06-24 06:48:51.597957
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r\n'))


# Generated at 2022-06-24 06:48:56.609298
# Unit test for function match
def test_match():
    assert git_support(match)(Command('whatis'))
    assert not git_support(match)(Command('git branch'))
    assert git_support(match)(Command(' git rm '))
    assert not git_support(match)(Command('for i in *.py; do rm -rf `basename $i .py`; done'))

# Unit tests for function get_new_command

# Generated at 2022-06-24 06:48:59.652986
# Unit test for function match
def test_match():
    assert match(Command(script='git rm foo/bar/baz',
        output='fatal: not removing \'foo/bar/baz\' recursively without -r'))
    assert match(Command(script='git rm foo/bar/baz',
        output='fatal: not removing \'foo/foo/bar/baz\' recursively without -r'))
    assert match(Command(script='git rm foo/bar/baz',
        output='fatal: not removing \'foo/foo/foo/bar/baz\' recursively without -r'))


# Generated at 2022-06-24 06:49:03.512086
# Unit test for function match
def test_match():
    # Match test
    assert match(Command('git rm foo.txt', 'fatal: not removing \'foo.txt\' recursively without -r', '', '', True))
    # No match test
    assert not match(Command('git rm foo.txt', '', '', '', False))

# Generated at 2022-06-24 06:49:07.234825
# Unit test for function get_new_command
def test_get_new_command():
    command_test = Command('git rm -r')
    command_test.script_parts = ['git', 'rm', '-r']
    command_test.output = "fatal: not removing '"
    assert get_new_command(command_test) == 'git rm -r -r'

# Generated at 2022-06-24 06:49:13.275150
# Unit test for function match
def test_match():
    assert match(Command('git rm -r directory/', '', 'fatal: not removing \'directory/\' recursively without -r', 1))
    assert not match(Command('git rm -Recursively directory/', '', 'fatal: not removing \'directory/\' recursively without -r', 1))
    assert not match(Command('git rm directory/', '', 'fatal: not removing \'directory/\' recursively without -r', 1))
    assert not match(Command('git -r rm directory/', '', 'fatal: not removing \'directory/\' recursively without -r', 1))
    assert not match(Command('rm directory/', '', 'fatal: not removing \'directory/\' recursively without -r', 1))



# Generated at 2022-06-24 06:49:17.929557
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r --cached dir/').script == 'git rm -r -r --cached dir/'
    assert get_new_command('git rm --cached -r dir/').script == 'git rm -r --cached -r dir/'
    assert get_new_command('git rm --cached dir/').script == 'git rm --cached -r dir/'
    assert get_new_command('git rm -r --cached dir/file').script == 'git rm -r -r --cached dir/file'

# Generated at 2022-06-24 06:49:20.832232
# Unit test for function get_new_command
def test_get_new_command():
    command = 'rm file.txt'
    new_command = 'rm -r file.txt'
    assert get_new_command(Command(command, '', 'fatal: not removing')) == new_command

# Generated at 2022-06-24 06:49:24.065554
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1', 'fatal: not removing '
                                                  "'file1' recursively"
                                                  ' without -r')) == 'git rm -r file1'
# vim:set ai et sts=4 sw=4 tw=80:

# Generated at 2022-06-24 06:49:29.924410
# Unit test for function match
def test_match():
    # Not a git command
    assert match(Command('git branch -av', "git branch -av")) == False
    
    # Not a 'rm' command
    assert match(Command('git add -p', "git add -p")) == False
    
    # Not an error message
    assert match(Command('git rm newfile.txt', "git rm newfile.txt")) == False
    
    # A 'rm' command with error
    assert match(Command('git rm file.txt', "fatal: not removing 'file.txt' recursively without -r")) == True
    

# Generated at 2022-06-24 06:49:34.926912
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', script='git rm foo', stderr='fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo', script='git rm foo', stderr='fatal: not removing \'foo\''))


# Generated at 2022-06-24 06:49:37.608522
# Unit test for function match
def test_match():
    assert match(Command('git config test',
                         'fatal: not removing \'./test\' recursively without -r'))
    assert not match(Command('git config test'))


# Generated at 2022-06-24 06:49:42.027942
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('rm old/new',
                            script='rm old/new',
                            stderr='fatal: not removing old/new recursively without -r',
                            )) == "git rm -r old/new"

# Generated at 2022-06-24 06:49:46.250786
# Unit test for function match
def test_match():
    rm = Command('git rm file1 file2', '', 'fatal: not removing \'file1\' recursively without -r\n')
    assert match(rm)
    rm2 = Command('git rm file1 file2', '', '\n')
    assert not match(rm2)


# Generated at 2022-06-24 06:49:52.888802
# Unit test for function match
def test_match():
    assert match(Command('rm abc', "fatal: not removing 'abc' recursively without -r"))
    assert match(Command('git rm abc', "fatal: not removing 'abc' recursively without -r"))
    assert not match(Command('rm abc', "fatal: not removing 'abc' recursively without -r", "Warning"))
    assert not match(Command('rm abc', "fatal: not removing 'abc' recursively without -r\n"))


# Generated at 2022-06-24 06:49:58.885031
# Unit test for function match
def test_match():
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', ''))
    assert match(Command('git rm folder', '', 'fatal: not removing \'folder\' recursively without -r', ''))
    assert match(Command('git rm folder file', '', 'fatal: not removing \'folder\' recursively without -r', ''))
    assert not match(Command('git rm not_existing_folder', '', '', ''))


# Generated at 2022-06-24 06:50:03.877919
# Unit test for function match
def test_match():
    assert match(Command('git rm .idea',
                         'fatal: not removing \'.idea\' recursively without -r',
                         ))
    assert not match(Command('git rm .idea',
                         'fatal: not removing \'.idea\' recursively with -r',
                         ))
    assert not match(Command('git rm',
                         'fatal: not removing \'.idea\' recursively without -r',
                         ))


# Generated at 2022-06-24 06:50:10.028240
# Unit test for function get_new_command
def test_get_new_command():
    # I created a shell script called test.sh with content
    # "git rm -r test"
    from thefuck.rules.git_rm_fatal import get_new_command
    test_command = "test.sh"
    assert get_new_command(Command(test_command, "fatal: not removing 'test' recursively without -r")) == "git rm -r test"
    assert get_new_command(Command(test_command, "fatal: not removing 'another_test' recursively without -r")) == "git rm -r another_test"

# Generated at 2022-06-24 06:50:12.580541
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf some_file')
    assert get_new_command(command) == 'git rm -r -f some_file'

# Generated at 2022-06-24 06:50:17.868042
# Unit test for function match
def test_match():
    command = Command('git rm src/tests/test.py', 'fatal: not removing \'src/tests/test.py\' recursively without -r\n')
    assert match(command)

    command = Command('git help', 'fatal: not removing \'src/tests/test.py\' recursively without -r\n')
    assert not match(command)



# Generated at 2022-06-24 06:50:23.973796
# Unit test for function match
def test_match():
    """
    This function is responsible for testing the match function in the file
    git_recursive.py
    
    Use git status output as input test data.
    """
    observed1 = Command("git status", "\n"
                                      "fatal: not removing 'git_recursive.py' recursively without -r\n")
    assert(match(observed1))
    
    observed2 = Command("git status", "fatal: not removing 'git_recursive.py' recursively without -r\n")
    assert(not match(observed2))


# Generated at 2022-06-24 06:50:27.213539
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo/bar',
                      'fatal: not removing \'foo/bar\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r foo/bar'

# Generated at 2022-06-24 06:50:33.978709
# Unit test for function match
def test_match():
    assert match(Command(script="git branch -a", output=''' error: pathspec '-a' did not match any file(s) known to git. '''))
    assert not match(Command(script="git branch -a", output=''' fatal: not removing 'file' recursively without -r '''))
    assert not match(Command(script="git rm -a", output=''' error: pathspec '-a' did not match any file(s) known to git. '''))
    assert match(Command(script="git rm -a", output=''' fatal: not removing 'file' recursively without -r '''))
    assert not match(Command(script="git rm -r file", output=''' fatal: not removing 'file' recursively without -r '''))



# Generated at 2022-06-24 06:50:36.650533
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm myfolder')
    assert get_new_command(command) == 'git rm -r myfolder'

# Generated at 2022-06-24 06:50:44.378343
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf app/assets/javascripts/bla',
                         stderr='fatal: not removing \'app/assets/javascripts/bla\' recursively without -r'))
    assert not match(Command('git rm -rf app/assets/javascripts/bla',
                             stderr='fatal: not removing \'app/assets/javascripts/bla\' recursively without -r'))
    assert not match(Command('git rm -rf app/assets/javascripts/bla', stderr=''))
    assert not match(Command('git rm -rf app/assets/javascripts/bla'))


# Generated at 2022-06-24 06:50:48.894053
# Unit test for function match
def test_match():
    assert match(Command('foo rm foo/bar', ''))
    assert match(Command('foo rm foo/bar', 'fatal: not removing \'foo/bar\' recursively without -r'))
    assert not match(Command('foo rm foo/bar', 'fatal: not removing \'foo/bar\' recursively without -r',
                             'other output'))
    assert not match(Command('foo rm -r foo/bar', 'fatal: not removing \'foo/bar\' recursively without -r'))

# Generated at 2022-06-24 06:50:54.826603
# Unit test for function match
def test_match():
    script = "git rm -r ./scripts/tools/git.sh"
    output = """error: the following file has local modifications:
	scripts/tools/git.sh
fatal: not removing 'scripts/tools/git.sh' recursively without -r
ERROR: Job failed: exit code 1"""
    assert match(Command(script, output, ''))


# Generated at 2022-06-24 06:50:56.813455
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm file")) == 'git rm -r file'



# Generated at 2022-06-24 06:50:59.348036
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ["git", "rm", "file"]
    script = u' '.join(command_parts[:])
    command = Command(script, '')
    assert get_new_command(command) == \
        u'git rm -r file'

# Generated at 2022-06-24 06:51:05.241970
# Unit test for function match
def test_match():
    assert match(Command('git status', '', '',
        'fatal: not removing \'file\' recursively without -r', 0))
    assert not match(Command('git status', ''))
    assert not match(Command('git status', '', '',
        'fatal: not removing \'file\' recursively', 0))
    assert not match(Command('git status', '', '',
        'fatal: not removing \'file\' recursively', 0))


# Generated at 2022-06-24 06:51:08.839096
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r'))

# Generated at 2022-06-24 06:51:10.992941
# Unit test for function match
def test_match():
    assert match(Command('git status',
                         'fatal: not removing \'.git\' recursively without -r'))
    assert not match(Command('git status', 'fatal: not removing something'))


# Generated at 2022-06-24 06:51:12.799965
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm *')) == 'git rm -r *'



# Generated at 2022-06-24 06:51:16.631167
# Unit test for function get_new_command

# Generated at 2022-06-24 06:51:19.584299
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git branch -d foo/bar")
    index = command.script_parts.index('rm') + 1
    assert get_new_command(command) == "git rm -r foo/bar"


# Generated at 2022-06-24 06:51:23.085885
# Unit test for function match
def test_match():
    assert match("git rm a/b")
    assert match("git rm foo")
    assert not match("git rm -r a/b")
    assert not match("git rm -r foo")


# Generated at 2022-06-24 06:51:27.559850
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_add_recursive import get_new_command

    assert get_new_command('git rm -q your/file.py') == u'git rm -q -r your/file.py'


# Generated at 2022-06-24 06:51:30.929849
# Unit test for function match
def test_match():
    assert match(Command(script='git rm foo',
                         stderr='fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command())


# Generated at 2022-06-24 06:51:35.943747
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', 'rm', '-rf', 'dir']
    command = Command(script=' '.join(command_parts),
                      output="fatal: not removing 'dir' recursively without -r")
    assert get_new_command(command) == 'git rm -r -rf dir'

# Generated at 2022-06-24 06:51:39.980732
# Unit test for function get_new_command
def test_get_new_command():
    test_match = 'git rm someFile'
    test_output = "fatal: not removing 'someFile' recursively without -r"
    assert(get_new_command(Command(test_match, test_output)) == 'git rm -r someFile')

# Generated at 2022-06-24 06:51:43.254215
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command('git rm blabla', 'fatal: not removing \'blabla\' recursively without -r'))
    assert result == 'git rm -r blabla'

# Generated at 2022-06-24 06:51:47.421748
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm test',
         stdout= \
         'fatal: not removing \'test\' recursively without -r\n',
         stderr='',
         script_parts=['git', 'rm', 'test'])
    assert(get_new_command(command) == 'git rm -r test')

# Generated at 2022-06-24 06:51:49.896186
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("rm -f src/test/test.c")) == "rm -rf src/test/test.c"


# Generated at 2022-06-24 06:51:53.747803
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf one',
                         'fatal: not removing \'one\' recursively without -r', ''))
    assert not match(Command('git rm one', '', ''))
    assert not match(Command('git rm -r one', '', ''))



# Generated at 2022-06-24 06:51:56.644407
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git rm -r file_name' == get_new_command(Command('git rm file_name', '', 'fatal: not removing \'file_name\' recursively without -r')))


# Generated at 2022-06-24 06:51:59.766915
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r',
                         '', 1))



# Generated at 2022-06-24 06:52:03.292891
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf folder', '', '')) == 'git rm -rf -r folder'
    assert get_new_command(Command('git rm -f submodule/folder', '', '')) == 'git rm -f -r submodule/folder'

# Generated at 2022-06-24 06:52:09.329021
# Unit test for function match
def test_match():
    # Test for match
    # Test for non-match
    assert match(Command("git rm pom.xml",
        output="fatal: not removing 'pom.xml' recursively without -r")) is True
    assert match(Command("git rm pom.xml",
        output="fatal: not removing 'pom.xml' recursively without -r"
               "Bye. POM")) is False
    # Test non-git command
    assert match(Command("rm pom.xml",
        output="fatal: not removing 'pom.xml' recursively without -r")) is False


# Generated at 2022-06-24 06:52:19.876954
# Unit test for function get_new_command
def test_get_new_command():
    # command: 'git rm <file>'
    command = Command('git rm file.txt',
                      'fatal: not removing \'file.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file.txt'

    # command: 'git rm <file> <file>'
    command = Command('git rm file1.txt file2.txt',
                      'fatal: not removing \'file1.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file1.txt file2.txt'

    # command: 'git rm <file> -- <file>'
    command = Command('git rm file1.txt -- file2.txt',
                      'fatal: not removing \'file1.txt\' recursively without -r')


# Generated at 2022-06-24 06:52:24.076893
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf dir',
                         'fatal: not removing \'dir\' recursively without -r'))
    assert not match(Command('git rm dir',
                             'fatal: not removing \'dir\' recursively without -r'))

# Generated at 2022-06-24 06:52:26.545190
# Unit test for function match
def test_match():
    command = Command('git rm foo')
    assert match(command)
    command = Command('git rm foo bar')
    assert match(command) is False



# Generated at 2022-06-24 06:52:29.876554
# Unit test for function get_new_command
def test_get_new_command():
    script = "git rm -rf ."
    output = "fatal: not removing '.' recursively without -r\n"
    command = Command(script=script, output=output)
    assert get_new_command(command) == "git rm -r -rf ."

# Generated at 2022-06-24 06:52:32.149497
# Unit test for function match
def test_match():
    output = 'Error message.'
    # match test
    assert match(Command('git rm folder_name', output))


# Generated at 2022-06-24 06:52:34.812674
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', '', output='fatal: not removing \'file-to-delete\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file-to-delete'

# Generated at 2022-06-24 06:52:37.591054
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='rm -rf file.txt', stdout='')
    assert get_new_command(command) == 'git rm -r -rf file.txt'

# Generated at 2022-06-24 06:52:43.467968
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf /some/error/file/here'))
    assert not match(Command('git rm -rf /some/error/file/here', 'fatal: not removing ''/some/error/file/here'' recursively without -r'))
    assert not match(Command('git rm -rf /some/error/file/here', 'fatal: not removing ''/some/error/file/here'' recursively without -r', error=True))


# Generated at 2022-06-24 06:52:46.761578
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command(script='git rm -r subdirectory',
                           output='fatal: not removing \'subdirectory\' recursively without -r'))
           == 'git rm -r -r subdirectory')

# Generated at 2022-06-24 06:52:49.929266
# Unit test for function match
def test_match():
    assert match(Command('git rm testing/modules/fixers.py', ''))
    assert match(Command('git rm -r testing/modules/fixers.py', '')) is False


# Generated at 2022-06-24 06:52:54.448241
# Unit test for function get_new_command
def test_get_new_command():
    match = MagicMock(return_value=True)
    get_new_command = MagicMock(side_effect=git_remove.get_new_command)
    with patch('thefuck.rules.git_remove.match', match), \
         patch('thefuck.rules.git_remove.get_new_command', get_new_command):
        result = git_remove.get_new_command(MagicMock())
        assert result == 'git rm -r file'

# Generated at 2022-06-24 06:52:57.307514
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf test',
                         'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm -rf test', ''))



# Generated at 2022-06-24 06:53:03.669695
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         stderr=(
                            "fatal: not removing 'file' recursively without -r"
                        )))
    assert not match(Command('git add file',
                             stderr=(
                                "fatal: not removing 'file' recursively without -r"
                            )))
    assert match(Command('git rm file',
                         stderr=(
                            "fatal: not removing 'file' \
                             recursively without -r"
                        )))


# Generated at 2022-06-24 06:53:07.793944
# Unit test for function get_new_command
def test_get_new_command():
    output = 'fatal: not removing \'dir/file\' recursively without -r\n'
    command = Command(script='git  rm dir/file',
                      output=output,
                      stderr=output)
    assert get_new_command(command) == 'git  rm -r dir/file'


# Generated at 2022-06-24 06:53:15.082463
# Unit test for function get_new_command
def test_get_new_command():
    command_output = u'fatal: not removing ' \
                     '\'/Users/sbommireddy/Desktop/GitHub/botbuilder-python/tests/test_injector.py\'' \
                    ' recursively without -r'
    command_script = u'git rm /Users/sbommireddy/Desktop/GitHub/botbuilder-python/tests/test_injector.py'
    command = Command(script=command_script, output=command_output)
    assert get_new_command(command) == u'git rm -r /Users/sbommireddy/Desktop/GitHub/botbuilder-python/tests/test_injector.py'

# Generated at 2022-06-24 06:53:17.533444
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf dir',
                         'fatal: not removing \'dir\' recursively without -r'))


# Generated at 2022-06-24 06:53:19.618985
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm folder')) == 'git rm -r folder'

# Generated at 2022-06-24 06:53:23.725894
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'
    assert get_new_command('git rm -f foo') == 'git rm -rf foo'
    assert get_new_command('git rm -f -r foo') == 'git rm -rf -r foo'

# Generated at 2022-06-24 06:53:26.652680
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(script="git rm -f test",
        output="fatal: not removing 'test/t.txt' recursively without -r"))
        == "git rm -f -r test")

# Generated at 2022-06-24 06:53:29.086245
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm a b')
    assert get_new_command(command) == 'git rm -r a b'

# Generated at 2022-06-24 06:53:31.754987
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -n test") == "git rm -rf -n test"
    assert get_new_command("git rm -r test") == "git rm -r test"

# Generated at 2022-06-24 06:53:40.101283
# Unit test for function match
def test_match():

        # case 01 : script contains ' rm ' and output contains 'fatal: not removing '" ...
        # the resulting new command is the original with '-r ' added
        script = "rm -f /tmp/foo/bar/file"
        output = "'/tmp/foo/bar/file' not removed.\nfatal: not removing 'file' recursively without -r"
        command = Command(script, output)
        assert match(command) is not None
        new_command = get_new_command(command)

        assert new_command == "git rm -r -f /tmp/foo/bar/file"
        
        # case 02 : script contains ' rm ' but output is NOT 'fatal: not removing '" ...
        # the resulting new command is the original
        script = "rm -f /tmp/foo/bar/file"

# Generated at 2022-06-24 06:53:50.586179
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f src/script.py', '')) == 'git rm -rf src/script.py'
    assert get_new_command(Command('git rm -f src/script.py', 'fatal: not removing \'src/script.py\' recursively without -r')) == 'git rm -rf src/script.py'
    assert get_new_command(Command('git rm -f src/script.py', 'fatal: not removing \'src/script.py\' recursively without -r\n')) == 'git rm -rf src/script.py'

# Generated at 2022-06-24 06:53:52.735999
# Unit test for function match
def test_match():
    assert match(Command('git rm folder', 'fatal: not removing \'folder\' recursively without -r'))


# Generated at 2022-06-24 06:53:59.335262
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r *', error='''fatal: not removing 'build' recursively without -r
Did you mean this?
	git rm --cached build''')
    assert get_new_command(command) == u'git rm -r -r *'
    command = Command('git rm -rf *', error='''fatal: not removing 'build' recursively without -r
Did you mean this?
	git rm --cached build''')
    assert get_new_command(command) == u'git rm -r -rf *'

# Generated at 2022-06-24 06:54:02.536525
# Unit test for function get_new_command
def test_get_new_command():
    command_output = Command('git rm -r file', '', '')
    assert get_new_command(command_output).script == u'git rm -r -r file'

# Generated at 2022-06-24 06:54:06.872690
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file'))

# Generated at 2022-06-24 06:54:09.342623
# Unit test for function match
def test_match():
    assert match(Command('git rm -r local',
                         'fatal: not removing \'local/\' recursively without -r',
                         '', 1))



# Generated at 2022-06-24 06:54:15.076784
# Unit test for function match
def test_match():
    assert match(Command("git rm -f file_not_exist.txt", "fatal: not removing 'file_not_exist.txt' recursively without -r"))
    assert not match(Command("git rm file_not_exist.txt", "fatal: not removing 'file_not_exist.txt' recursively without -r"))
    assert not match(Command("git rm", "fatal: not removing 'file_not_exist.txt' recursively without -r"))


# Generated at 2022-06-24 06:54:17.464519
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('rm test.txt', '')) == 'git rm -r test.txt'

# Generated at 2022-06-24 06:54:20.398755
# Unit test for function match
def test_match():
    # test match. return True if the command match with this rule
    assert match(Command('git rm -r', 'fatal: not removing \'3\' recursively without -r'))
    assert not match(Command('git rm 3', 'fatal: not removing \'3\' recursively without -r'))


# Generated at 2022-06-24 06:54:26.964143
# Unit test for function match
def test_match():
    assert match(Command('git commit file1 file2 file3',
        output="fatal: not removing 'file1' recursively without -r")) is True
    assert match(Command('git commit file1 file2 file3',
        output="fatal: not removing 'file2' recursively without -r")) is True
    assert match(Command('git commit file1 file2 file3',
        output="fatal: not removing 'file3' recursively without -r")) is True
    assert match(Command('git commit file1 file2 file3',
        output="fatal: not removing 'file4' recursively without -r")) is False

# Generated at 2022-06-24 06:54:33.084946
# Unit test for function match
def test_match():
    assert not match(Command('git rm file', '', 'fatal: not removing ''file'' recursively without -r', ''))
    assert match(Command('git rm file', '', 'fatal: not removing ''file'' recursively without -r', '', 'git'))
    assert not match(Command('git add file', '', '', '', 'git'))
    assert not match(Command('rm file', '', '', '', 'git'))


# Generated at 2022-06-24 06:54:35.975624
# Unit test for function match
def test_match():
    assert not match(Command('ls', ''))
    assert not match(Command('rm test.txt', ''))
    assert match(Command('rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r'))



# Generated at 2022-06-24 06:54:37.766566
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm test/test.txt') == 'git rm -r test/test.txt'



# Generated at 2022-06-24 06:54:39.502780
# Unit test for function match

# Generated at 2022-06-24 06:54:42.086288
# Unit test for function match
def test_match():
    command = Command(script='git rm -rf',
            output="fatal: not removing 'dd' recursively without -r")
    assert match(command)


# Generated at 2022-06-24 06:54:44.425314
# Unit test for function match
def test_match():
    assert match(Command('git rm test_file',
    """fatal: not removing 'test_file' recursively without -r
""", ''))


# Generated at 2022-06-24 06:54:48.799832
# Unit test for function match
def test_match():
    assert match(Command('git rm dir'))
    assert match(Command('git rm file'))
    assert not match(Command('git rm'))
    assert not match(Command('git config --global color.ui true'))


# Generated at 2022-06-24 06:54:55.784527
# Unit test for function match
def test_match():
    assert match(Command('git rm extra.txt', 'fatal: not removing \'extra.txt\' recursively without -r\n'))
    assert not match(Command('git rm extra.txt', ''))
    assert not match(Command('git commit', 'fatal: not removing \'extra.txt\' recursively without -r\n'))
    assert not match(Command('rm extra.txt', 'fatal: not removing \'extra.txt\' recursively without -r\n'))


# Generated at 2022-06-24 06:55:06.022414
# Unit test for function match
def test_match():
    assert match(Command(script='git rm file.txt',
                         stderr="fatal: not removing 'file.txt' recursively without -r"))
    assert match(Command(script='git rm *.txt',
                         stderr="fatal: not removing '*.txt' recursively without -r"))
    assert match(Command(script='git rm .',
                         stderr="fatal: not removing 'dummyDir' recursively without -r"))
    assert not match(Command(script='git rm file.txt',
                             stderr="fatal: not removing 'file.txt' recursively without the -r"))
    assert not match(Command(script='git rm file.txt',
                             stderr="fatal: not removing 'file.txt' recursively without -m"))


# Generated at 2022-06-24 06:55:10.665354
# Unit test for function match
def test_match():
    assert match(Command('git rm /home/user/test.txt',
                         'fatal: not removing \'/home/user/test.txt\' recursively without -r\n'))
    assert not match(Command('git rm /home/user/test.txt', 'something'))


# Generated at 2022-06-24 06:55:14.659934
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', '', '')) == u'git rm -r file'
    assert get_new_command(Command('git rm file1 file2', '', '')) == u'git rm -r file1 file2'
    assert get_new_command(Command('git rm -f file', '', '')) == u'git rm -f -r file'

# Generated at 2022-06-24 06:55:16.136263
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm testdir') == 'git rm -r testdir', 'To get new command'

# Generated at 2022-06-24 06:55:20.998495
# Unit test for function get_new_command
def test_get_new_command():
    inp = 'git rm -r folder/'
    inp_output = "fatal: not removing 'folder/' recursively without -r"
    command = Command(script=inp, output=inp_output)
    assert get_new_command(command) == 'git rm -r -r folder/'

# Generated at 2022-06-24 06:55:25.958905
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git -r rm file',
                             'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\''))

# Generated at 2022-06-24 06:55:36.535190
# Unit test for function match
def test_match():

    # match with git rm single file
    output = "fatal: not removing 'myfile' recursively without -r"
    script = "git rm myfile"
    mock_command = Mock(script=script, output=output)
    assert match(mock_command)

    # match with git rm multiple files
    output = "fatal: not removing 'myfile1' recursively without -r"
    script = "git rm myfile1 myfile2"
    mock_command = Mock(script=script, output=output)
    assert match(mock_command)

    # match with git rm directory
    output = "fatal: not removing 'mydir' recursively without -r"
    script = "git rm mydir"
    mock_command = Mock(script=script, output=output)

# Generated at 2022-06-24 06:55:44.004499
# Unit test for function match
def test_match():
    assert match(Command('git rm "some file"',
                         'fatal: not removing \'some file\' recursively without -r'))
    assert match(Command('git rm \'some file\'',
                         'fatal: not removing \'some file\' recursively without -r'))
    assert not match(Command('cd "some file"',
                             'fatal: not removing \'some file\' recursively without -r'))
    assert not match(Command('git rm', 'fatal: not removing \'some file\' recursively without -r'))


# Generated at 2022-06-24 06:55:49.965682
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('rm file') == 'rm -r file'
    assert get_new_command('rm -r file') == 'rm -r file'
    assert get_new_command('rm -f file') == 'rm -rf file'
    assert get_new_command('rm file -f') == 'rm -r file -f'
    assert get_new_command('rm -f -v file') == 'rm -rf -v file'

# Generated at 2022-06-24 06:55:56.860486
# Unit test for function match
def test_match():
    # Test for match function, output from command: git rm abc.txt
    command = Command(script='git rm abc.txt',
                      output="""fatal: not removing 'abc.txt' recursively without -r""",
                      stderr='',)
    assert match(command)

    # Test for match function, output from command: git rm abc.txt
    command = Command(script='git rm abc.txt',
                      output="""fatal: not removing 'abc.txt' recursively without -r""",
                      stderr='',)
    assert match(command)


# Generated at 2022-06-24 06:55:59.896022
# Unit test for function get_new_command
def test_get_new_command():
    command_line = u"git rm --cached docs/src/doc.tex"
    new_command = u"git rm --cached -r docs/src/doc.tex"
    assert(get_new_command(Command(command_line)) == new_command)


# Generated at 2022-06-24 06:56:01.701717
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo', stderr='fatal: not removing \'foo\' recursively without -r')) == 'git rm -r foo'

# Generated at 2022-06-24 06:56:04.358768
# Unit test for function match
def test_match():
    assert match(Command('rm foo'))
    assert not match(Command('git rm foo', 'fatal: not removing "foo" recursively without -r'))
    assert not match(Command('git rm foo', 'error: unknown switch `r\''))
    assert not match(Command('rm foo'))



# Generated at 2022-06-24 06:56:11.017138
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm .gitignore')) == 'git rm -r .gitignore'
    assert get_new_command(Command('git push origin master')) == 'git push origin master'
    assert get_new_command(Command('git rm README.rst')) == 'git rm -r README.rst'


# Generated at 2022-06-24 06:56:14.392816
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = [u'git', u'rm', u'--force', u'./build/*']
    assert get_new_command(get_command(compile(command_parts, u'', 'exec'))) == u'git rm -r --force ./build/*'