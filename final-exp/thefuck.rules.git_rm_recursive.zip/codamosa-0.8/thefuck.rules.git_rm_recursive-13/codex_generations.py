

# Generated at 2022-06-12 11:39:44.907998
# Unit test for function match
def test_match():
    assert match(Command('git rm -r dir', 'fatal: not removing \'dir\' recursively without -r\nUse \'git rm -r --cached dir\' to unstage contents\n'))


# Generated at 2022-06-12 11:39:47.874657
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf repo', 'fatal: not removing \'repo\' recursively without -r')
    assert get_new_command(command) == 'git rm -rf -r repo'

# Generated at 2022-06-12 11:39:52.139822
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_forceremove import get_new_command
    assert get_new_command(Command('git rm file',
    '''fatal: not removing 'file' recursively without -r''', '')) == 'git rm -r file'

#Unit test for function match

# Generated at 2022-06-12 11:39:54.553840
# Unit test for function match
def test_match():
    # Initialize command object
    command = Command('git rm foo', "fatal: not removing 'foo' recursively without -r\n")
    assert(match(command))

# Generated at 2022-06-12 11:39:56.029056
# Unit test for function match

# Generated at 2022-06-12 11:39:59.218813
# Unit test for function match
def test_match():
    assert match(Command('git rm non-existent-file',
                         "fatal: not removing 'non-existent-file' recursively without -r\n",
                         ''))


# Generated at 2022-06-12 11:40:01.960021
# Unit test for function get_new_command
def test_get_new_command():
    command_rm = Command("rm test", "", "")
    command_rm_r = Command("rm -r test", "", "")
    assert get_new_command(command_rm) == command_rm_r.script

# Generated at 2022-06-12 11:40:05.668110
# Unit test for function get_new_command
def test_get_new_command():
    script = "git rm"
    script_parts = script.split()
    output = "fatal: not removing 'foo' recursively without -r"
    command = Command(script, script_parts, output, "")
    new_command = get_new_command(command)
    assert new_command == "git rm -r"

# Generated at 2022-06-12 11:40:09.231318
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm -f -r')) == 'git rm -f -r -r'
    assert not get_new_command(Command(script='git rm -f'))


# Generated at 2022-06-12 11:40:14.420030
# Unit test for function match
def test_match():
    from thefuck.types import Command
    script1 = "git rm -f a"
    script2 = "git rm a"

    # No match case
    assert match(Command(script1, "fatal: not removing 'a'")) == False
    assert match(Command(script2, "fatal: not removing 'a'")) == False

    # Expected match case
    assert match(Command(script2, "fatal: not removing 'a' recursively without -r")) == True

# Generated at 2022-06-12 11:40:20.124816
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'git rm file\n'
                         'fatal: not removing \'file\' recursively without -r',
                         None))
    assert not match(Command('git rm file', '', None))


# Generated at 2022-06-12 11:40:22.634665
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r README', 'fatal: not removing \'README\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r README'

# Generated at 2022-06-12 11:40:26.192384
# Unit test for function get_new_command
def test_get_new_command():
	command = Command(script='git rm file1 file2', output='fatal: not removing \'file1\' recursively without -r')
	assert get_new_command(command) == 'git rm -r file1 file2'


# Generated at 2022-06-12 11:40:32.466548
# Unit test for function match
def test_match():
    script = "git rm -v foo"
    output = "fatal: not removing 'foo/bar' recursively without -r"

    command = Command(script, output)

    assert match(command)

    script = "git rm -v foo/bar"
    output = "fatal: not removing 'foo' recursively without -r"

    command = Command(script, output)

    assert match(command)


# Generated at 2022-06-12 11:40:39.317984
# Unit test for function match
def test_match():
    # True
    assert match(Command(script='git rm hello.txt',
                         stderr='fatal: not removing \'hello.txt\' recursively without -r'))

    # False
    assert not match(Command(script='git rm',
                             stderr='fatal: not removing \'hello.txt\' recursively without -r'))
    assert not match(Command(script='git add hello.txt',
                             stderr='fatal: not removing \'hello.txt\' recursively without -r'))



# Generated at 2022-06-12 11:40:42.294969
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git rm tmp/test.xml'
    output = "fatal: not removing 'tmp/test.xml' recursively without -r"
    command = Command(script, output, '', 0)
    assert get_new_command(command) == 'git rm -r tmp/test.xml'

# Generated at 2022-06-12 11:40:48.857517
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test -r', 'fatal: not removing \'test\' recursively without -r\n',
                      alias=Alias(name='git', command='git'))
    fuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu

# Generated at 2022-06-12 11:40:54.321002
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf README.md',
                         'fatal: not removing \'README.md\' recursively without -r'))
    assert not match(Command('git rm -rf README.md', ''))
    assert not match(Command('rm -rf README.md',
                        'fatal: not removing \'README.md\' recursively without -r'))


# Generated at 2022-06-12 11:40:55.169465
# Unit test for function match
def test_match():
    command = Command('git rm -r .')
    assert (match(command) == True)


# Generated at 2022-06-12 11:40:56.979491
# Unit test for function match
def test_match():
    assert match(Command("git rm --cached file",
                         "fatal: not removing 'file' recursively without -r"))
    assert not match(Command("git rm --cached file",  "file successfully removed"))



# Generated at 2022-06-12 11:41:01.565155
# Unit test for function match
def test_match():
    assert match(Command('git push origin master',
                         'fatal: not removing \'src/foo\' recursively without -r\n'))


# Generated at 2022-06-12 11:41:05.296386
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm pattern',
                      output="fatal: not removing 'pattern' recursively without -r\n")
    new_command = get_new_command(command)
    assert new_command == "git rm -r pattern"

# Generated at 2022-06-12 11:41:10.315116
# Unit test for function match
def test_match():
	assert match(Command('rm -rf /'))
	assert not match(Command('rm -rf /', 'fatal: not removing \'\'/recursively without -r'))
	assert not match(Command('git rm '))
	assert not match(Command('git rm -r'))


# Generated at 2022-06-12 11:41:14.568172
# Unit test for function match
def test_match():
    command = Command(script='git rm README.md',
                      output='fatal: not removing \'README.md\' recursively without -r')
    assert not match(command)

    command = Command(script='git rm README.md',
                      output='fatal: not removing \'README.md\' recursively without -r')
    assert match(command)


# Generated at 2022-06-12 11:41:19.371793
# Unit test for function get_new_command
def test_get_new_command():
    output_text = "fatal: not removing 'dir1/dir2/file' recursively without -r"
    command = Command('git rm dir1/dir2/file', output_text)
    assert 'git rm -r dir1/dir2/file' in get_new_command(command)

# Generated at 2022-06-12 11:41:21.768449
# Unit test for function match
def test_match():
    assert match(Command('git rm -f f', '', 'fatal: not removing \'f\' recursively without -r'))


# Generated at 2022-06-12 11:41:26.457087
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf /tmp/test'))
    assert match(Command('git rm -rf /tmp/test', 'error: '
                         "fatal: not removing '/tmp/test' recursively "
                         'without -r'))
    assert not match(Command('git rm -rf /tmp/test', 'fatal: not removed'))



# Generated at 2022-06-12 11:41:29.365985
# Unit test for function match
def test_match():
    assert match(Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r'))
    assert not match(Command('git commit', 'On branch master\nnothing to commit, working directory clean'))


# Generated at 2022-06-12 11:41:31.671066
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -rf test")
    assert get_new_command(command) == "git rm -rf -r test"

# Generated at 2022-06-12 11:41:36.241009
# Unit test for function get_new_command
def test_get_new_command():
   new_command = get_new_command(
       Command('rm /mocked/path' , "fatal: not removing 'mocked_path/' recursively without -r"))
   assert new_command == 'git rm -r /mocked/path'

# Generated at 2022-06-12 11:41:42.922410
# Unit test for function match
def test_match():
    """
    Checks if the match function is working properly.
    """
    assert match(u"git: 'rm' is not a git command. See 'git --help'.")
    assert not match(u"git status")
    assert not match(u"git rm")


# Generated at 2022-06-12 11:41:46.781971
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='rm -f some_file',
        output="fatal: not removing 'some_file' recursively without -r")
    assert('git rm -f -r some_file'==get_new_command(command))

# Generated at 2022-06-12 11:41:50.686482
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test')) == 'git rm -r test'
    assert get_new_command(Command('git rm test', 'fatal: not removing \'test\' recursively without -r\n')) == 'git rm -r test'

# Generated at 2022-06-12 11:41:52.750996
# Unit test for function get_new_command
def test_get_new_command():
	assert(get_new_command(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r -r test')

# Generated at 2022-06-12 11:41:56.120569
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         stderr='fatal: not removing "file" recursively without -r'))
    assert not match(Command('git rm file',
                             stderr='fatal: not removing "file"'))

# Generated at 2022-06-12 11:41:58.467761
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git rm foo',
                                    'fatal: not removing \'foo\' recursively without -r\n')) == 'git rm -r foo')

# Generated at 2022-06-12 11:42:01.507502
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm \"some dir\"", "fatal: not removing 'some dir' recursively without -r")
    assert get_new_command(command) == "git rm -r \"some dir\""

# Generated at 2022-06-12 11:42:12.078729
# Unit test for function match
def test_match():
    assert match(
        Command('git add myfile.txt',
                '')) is False

    assert match(
        Command('git add myfile.txt',
                'fatal: not removing \'myfile.txt\' recursively without -r\n')) is True

    assert match(
        Command('git add myfile.txt',
                'fatal: not removing \'../myfile.txt\' recursively without -r\n')) is True

    assert match(
        Command('git add 1 2 3 4 5 6 7 8 9 10',
                'fatal: not removing \'1\' recursively without -r\n')) is True

    assert match(
        Command('git add -r',
                'fatal: not removing \'1\' recursively without -r\n')) is False


# Generated at 2022-06-12 11:42:16.873863
# Unit test for function match
def test_match():
    assert_true(match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')))
    assert_false(match(Command('git rm foo', 'fatal: not removing \'foo\'')))
    assert_false(match(Command('rmgit foo', '')))


# Generated at 2022-06-12 11:42:22.396129
# Unit test for function match
def test_match():
	assert match(Command('git rm hmm',
						'fatal: not removing \'hmm\' recursively without -r',
						'', 1))
	assert not match(Command('git rm hmm',
						'',
						'', 1))
	assert not match(Command('git rm hmm',
						'fatal: rm hmm',
						'', 1))



# Generated at 2022-06-12 11:42:28.670660
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f .')
    assert get_new_command(command) == "git rm -r -f ."

# Generated at 2022-06-12 11:42:32.484943
# Unit test for function match
def test_match():
    assert match(Command(script='git rm test', output='fatal: not removing \'test\' recursively without -r'))
    assert match(Command(script='git rm test', output='fatal: not removing \'test.tmp\' recursively without -r'))
    

# Generated at 2022-06-12 11:42:37.212029
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r'))
    assert match(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r\n'))
    assert not match(Command('git rm test', 'fatal: pathspec \'test\' did not match any files'))

# Generated at 2022-06-12 11:42:43.857904
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3',
                         'fatal: not removing \'file1\' recursively without -r'))
    assert match(Command('git rm file1',
                         'fatal: not removing \'file1\' recursively without -r'))
    assert match(Command('git rm file1',
                         'fatal: not removing \'file1 file2 file3\' recursively without -r'))


# Generated at 2022-06-12 11:42:52.818206
# Unit test for function match
def test_match():
	assert match(Command('rm folder', 'fatal: not removing \'folder\' recursively without -r')) == True
	assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) == True
	assert match(Command('rm file', 'fatal: not removing \'file\' recursively without -r')) == True
	assert match(Command('git rm folder', 'fatal: not removing \'folder\' recursively without -r')) == True
	assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) == True
	assert match(Command('rm folder', 'fatal: not removing \'folder\' recursively without -r')) == True

# Generated at 2022-06-12 11:42:55.090590
# Unit test for function match
def test_match():
    assert match(Command('git rm name', 'fatal: not removing \'name\' recursively without -r\n'))


# Generated at 2022-06-12 11:43:01.844930
# Unit test for function get_new_command
def test_get_new_command():
    if os.name == "nt":
        command = Command('rm not_existing_file',
                          'fatal: not removing \'not_existing_file\'' +
                          ' recursively without -r\n', '')
    else:
        command = Command('rm not_existing_file', 'fatal: not removing' +
                          ' \'not_existing_file\' recursively without -r\n', '')
    assert get_new_command(command) == u'git rm -r not_existing_file'

# Generated at 2022-06-12 11:43:11.941889
# Unit test for function get_new_command

# Generated at 2022-06-12 11:43:13.924541
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm folder')
    assert get_new_command(command) == 'git rm -r folder'


# Generated at 2022-06-12 11:43:17.148919
# Unit test for function get_new_command
def test_get_new_command():
    command = Script('git rm foo', 'fatal: not removing "foo" recursively without -r')
    assert get_new_command(command) == u'git rm -r foo'

# Unit tests for functions match and get_new_command

# Generated at 2022-06-12 11:43:24.040020
# Unit test for function match
def test_match():
    assert match(Command('git rm README.md',
        'fatal: not removing \'README.md\' recursively without -r'))


# Generated at 2022-06-12 11:43:26.741264
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm test', output='fatal: not removing \'test\': it is not a working tree')) == 'git rm -r test'


# Generated at 2022-06-12 11:43:33.112811
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('') == u"git rm -r  ")
    assert(get_new_command('gitt rm ') == u"git rm -r ")
    assert(get_new_command('git rm') == u"git rm -r")
    assert(get_new_command('git rm stuff') == u"git rm -r stuff")
    assert(get_new_command('git rm stuff stuff') == u"git rm -r stuff stuff")


# Generated at 2022-06-12 11:43:43.427294
# Unit test for function match
def test_match():
    assert(match(Command('rm file', '', 'fatal: not removing \'file\' recursively without -r', '')) == True)
    assert(match(Command('rm', '', 'fatal: not removing \'\' recursively without -r', '')) == True)
    assert(match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', '')) == True)
    assert(match(Command('rm file', '', 'fatal: not removing \'file\' recursively without -r', '')) == True)
    assert(match(Command('rm file', '', 'fatal:', '')) == False)
    assert(match(Command('rm', '', 'fatal:', '')) == False)

# Generated at 2022-06-12 11:43:45.816529
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo', '', '')
    assert get_new_command(command) == "git rm -r foo"

# Generated at 2022-06-12 11:43:48.577155
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm README',
                      output="fatal: not removing 'README' recursively without -r")
    assert get_new_command(command) == 'git rm -r README'

# Generated at 2022-06-12 11:43:55.469304
# Unit test for function get_new_command
def test_get_new_command():
    # Case 1
    input_command = "git rm -r --cached dev.js"
    output_command = "git rm -r dev.js"
    new_command = get_new_command(Command(input_command, '', '', '', ''))
    assert new_command == output_command

    # Case 2
    input_command = "git rm 'dev.js'"
    output_command = "git rm -r 'dev.js'"
    new_command = get_new_command(Command(input_command, '', '', '', ''))
    assert new_command == output_command

# Generated at 2022-06-12 11:43:58.034498
# Unit test for function match
def test_match():
    assert match(Command('git rm a',
                         "fatal: not removing 'a' recursively without -r"))

# # Unit test for function get_new_command

# Generated at 2022-06-12 11:44:01.719967
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', '-r', 'rm', '-r', 'test.txt']
    command = Command(command_parts, u'error')

    assert get_new_command(command) == u'git -r rm -r -r test.txt'

# Generated at 2022-06-12 11:44:06.329091
# Unit test for function get_new_command
def test_get_new_command():
    command = Script('git rm -rf branch_to_delete', 'fatal: not removing '
                                                    '\'branch_to_delete\' '
                                                    'recursively without -r')
    assert git_rm_r.get_new_command(command) == 'git rm -r -rf branch_to_delete'

# Generated at 2022-06-12 11:44:18.935146
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert (get_new_command(Command(script='git rm abc',
                                    stderr='fatal: not removing \'abc\' recursively without -r'))
            == u'git rm -r abc')

# Generated at 2022-06-12 11:44:20.788339
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo bar', '')) == u'git rm -r foo bar'

# Generated at 2022-06-12 11:44:23.475968
# Unit test for function match
def test_match():
    command = Command('git rm -r foo/', 'fatal: not removing \'foo/\' recursively without -r')
    assert match(command)



# Generated at 2022-06-12 11:44:25.680742
# Unit test for function get_new_command
def test_get_new_command():
    from tests.modules.specific.git import CommandStub
    command = CommandStub('git rm -f test', 'fatal: not removing \'test\''
                                            ' recursively without -r',
                          '')
    assert get_new_command(command) == 'git rm -r -f test'

# Generated at 2022-06-12 11:44:33.901647
# Unit test for function match
def test_match():
    # The match function must return True if the given command contains 'rm'
    # in its script_parts and command.output contains a message saying
    # that 'rm' is not recursive without the -r option and False otherwise.
    assert match(Command('rm README', script='git rm README',
                         output="fatal: not removing 'README' recursively without -r"))
    assert not match(Command('rm README', script='git rm README',
                             output="fatal: not removing 'README'"))
    assert not match(Command('rm README', script='git rm README',
                             output="fatal: not removing 'README' recursively"))



# Generated at 2022-06-12 11:44:37.991794
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -rf')) == 'git rm -rf -r'
    assert get_new_command(Command('git rm --cached -r')) == 'git rm --cached -r -r'
    assert get_new_command(Command('git rm --cached -rf')) == 'git rm --cached -rf -r'

# Generated at 2022-06-12 11:44:39.633456
# Unit test for function match
def test_match():
    assert match(Command('rm -r test'))


# Generated at 2022-06-12 11:44:43.452390
# Unit test for function get_new_command
def test_get_new_command():
    old_command = u"git remote rm origin"
    new_command = u"git remote rm -r origin"
    assert get_new_command(Command(script=old_command)) == new_command

# Generated at 2022-06-12 11:44:45.320669
# Unit test for function match
def test_match():
    assert match(Command("git rm -rf myfile", "fatal: not removing 'myfile' recursively without -r\n",))


# Generated at 2022-06-12 11:44:48.277967
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm')) == 'git rm -r'

# Generated at 2022-06-12 11:45:01.585974
# Unit test for function get_new_command
def test_get_new_command():
    import pytest
    from thefuck.types import Command
    command_parts = ['git', 'rm', 'Myfile']
    command = Command(script=' '.join(command_parts),
            stdout='fatal: not removing \'Myfile\' recursively without -r',
            stderr='')

    assert get_new_command(command) == 'git rm -r Myfile'

# Generated at 2022-06-12 11:45:07.082034
# Unit test for function match
def test_match():
    assert match(Command('git rm ', 'fatal: not removing \'.gitignore\' recursively without -r'))
    assert not match(Command('git rm ', 'fatal: not removing \'non_recursive_file.txt\' recursively without -r'))
    assert not match(Command('git rm non_recursive_file.txt', ''))


# Generated at 2022-06-12 11:45:10.561783
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm src/test1/test2/test.txt', 'fatal: not removing \'src/test1/test2/test.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r src/test1/test2/test.txt'

# Generated at 2022-06-12 11:45:14.467825
# Unit test for function get_new_command
def test_get_new_command():
    def _assert(script, expected):
        assert get_new_command(script) == expected

    _assert("git rm hh", "git rm -r hh")
    _assert("git rm hh --cached", "git rm -r hh --cached")

# Generated at 2022-06-12 11:45:16.124726
# Unit test for function match
def test_match():
    assertmatch(match, COMMAND1)
    assertnotmatch(match, COMMAND2)


# Generated at 2022-06-12 11:45:23.490612
# Unit test for function get_new_command
def test_get_new_command():
    # Then
    assert get_new_command(Command('echo test', '', '', 0)) == 'echo test'
    assert get_new_command(Command('git rm test', '', '', 0)) == 'git rm test'
    assert get_new_command(Command('git rm test', '', "fatal: not removing 'directory' recursively without -r", 0)) == 'git rm -r test'
    assert get_new_command(Command('git rm test directory', '', "fatal: not removing 'directory' recursively without -r", 0)) == 'git rm -r test directory'

# Generated at 2022-06-12 11:45:26.289082
# Unit test for function match
def test_match():
    from tests.utils import Command

    assert match(Command('git remote rm origin',
                         'fatal: not removing \'origin\' recursively without -r'))



# Generated at 2022-06-12 11:45:27.207416
# Unit test for function match
def test_match():
    assert match(Command('git rm file'))
    assert match(Command('git rm -f'))
    assert not match(Command('git rm -rf'))


# Generated at 2022-06-12 11:45:28.936545
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm TODO') == 'git rm -r TODO'
    assert get_new_command('git rm -r TODO') == 'git rm -r -r TODO'
    assert get_new_command('git pull origin master') == 'git pull origin master'

# Generated at 2022-06-12 11:45:30.460573
# Unit test for function match
def test_match():
    assert match(Command('git rm dir'))
    assert match(Command('git rm -r dir'))


# Generated at 2022-06-12 11:45:51.360615
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert u'git rm -r foo' == get_new_command(Command('git rm foo'))

# Generated at 2022-06-12 11:45:53.144063
# Unit test for function match
def test_match():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert(match(command))


# Generated at 2022-06-12 11:45:56.961265
# Unit test for function get_new_command
def test_get_new_command():
    command = u'git rm file-name'
    new_command = get_new_command(Command(command))
    assert new_command == u'git rm -r file-name'

    command_not_matched = u'rm file-name'
    new_command = get_new_command(Command(command_not_matched))
    assert not new_command



# Generated at 2022-06-12 11:46:03.920632
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
             "fatal: not removing 'file' recursively without -r"))
    assert match(Command('git rm dir/',
             "fatal: not removing 'dir/' recursively without -r"))
    assert match(Command('git rm dir/file',
             "fatal: not removing 'dir/file' recursively without -r"))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'not found'))


# Generated at 2022-06-12 11:46:08.022845
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'remove foo'))
    assert match(Command('git rm foo', 'fatal: not removing \'bar\' recursively without -r'))
    assert not match(Command('rm foo', 'remove foo'))
    assert not match(Command('git rm foo', 'remove foo'))


# Generated at 2022-06-12 11:46:17.738610
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert (get_new_command(Command('git rm README',
                                    'fatal: not removing '
                                   '"README" recursively without -r'))
                           == 'git rm -r README')
    assert (get_new_command(Command('git rm README.txt',
                                    'fatal: not removing '
                                    '"README.txt" recursively without -r'))
            == 'git rm -r README.txt')
    assert (get_new_command(Command('git rm README.txt README',
                                    'fatal: not removing '
                                    '"README.txt" recursively without -r'))
            == 'git rm -r README.txt README')

# Generated at 2022-06-12 11:46:21.933583
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test/test_helper.rb', 'fatal: not removing \\"test/test_helper.rb\\"'
            ' recursively without -r\n', '', 0, '', '')
    assert get_new_command(command) == 'git rm -r -r test/test_helper.rb'

# Generated at 2022-06-12 11:46:26.182207
# Unit test for function get_new_command
def test_get_new_command():
    from tests.test_utils import Command

    old_command = Command('git rm -r -f')
    new_command = get_new_command(old_command)

    assert new_command == "git rm -f -r"

# Generated at 2022-06-12 11:46:28.450310
# Unit test for function match
def test_match():
    assert match(Command('rm -rf a', output='fatal: not removing \'a\' recursively without -r'))


# Generated at 2022-06-12 11:46:30.596915
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test', 'fatal: not removing \'test\' recursively without -r', '', 125)) == 'git rm -r test'

# Generated at 2022-06-12 11:46:53.666612
# Unit test for function get_new_command
def test_get_new_command():
    commands = ['git rm somefile.txt',
                'git rm -r somefile.txt']
    for command in commands:
        assert(get_new_command(Command(command, "fatal: not removing 'somefile.txt' recursively without -r")) == 'git rm -r somefile.txt')


# Generated at 2022-06-12 11:46:55.002304
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file_name') == 'git rm -r file_name'

# Generated at 2022-06-12 11:46:59.492632
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm folder',
                                   output="fatal: not removing 'folder' recursively without -r")) == 'git rm -r folder'
    assert get_new_command(Command(script='git rm -rf .',
                                   output="fatal: not removing '.' recursively without -r")) == 'git rm -rf -r .'

# Generated at 2022-06-12 11:47:07.628768
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2',
                         'fatal: not removing \'dummy\' recursively without -r'))
    assert match(Command('git rm dummy',
                         'fatal: not removing \'dummy\' recursively without -r'))
    assert match(Command('git rm src/dummy',
                         'fatal: not removing \'dummy\' recursively without -r'))
    assert match(Command('git rm dummy/',
                         'fatal: not removing \'dummy/\' recursively without -r'))
    assert not match(Command('git rm dummy file1 file2',
                         'fatal: not removing \'dummy\' recursively without -r'))
    assert not match(Command('git rm dummy',
                         'fatal: not removing \'dummy\' recursively with -r'))

# Generated at 2022-06-12 11:47:10.848789
# Unit test for function match
def test_match():
    assert match(Command('git rm -f aaa', None))
    assert not match(Command('git rm -rf aaa', None))
    assert not match(Command('git rm -r aaa', None))
    assert not match(Command('git rm aaa', None))


# Generated at 2022-06-12 11:47:12.659591
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         'fatal: not removing \'foo\' recursively without -r'))



# Generated at 2022-06-12 11:47:15.625008
# Unit test for function match
def test_match():
    assert not match(Command('git rm', 'fatal: not removing \'foo\' recursively without -r', 'git rm foo'))
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r', 'git rm foo'))


# Generated at 2022-06-12 11:47:18.498405
# Unit test for function match
def test_match():
    match('git rm core')
    assert match(Command('git rm core',
         "fatal: not removing 'core' recursively without -r\n",
         ''))
    assert_not_exists('git rm core')


# Generated at 2022-06-12 11:47:21.604825
# Unit test for function match
def test_match():
    assert match(Command('rm test', 'fatal: not removing \'test\' recursively without -r\n',
                         ''))

    assert not match(Command('rm test', 'fatal: not removing \'test\' recursively without -r\n',
                             ''))



# Generated at 2022-06-12 11:47:27.100050
# Unit test for function match
def test_match():
    ret = match(Command(script='git push -u origin master',
                        stdout='',
                        stderr='fatal: not removing \'tests/test_shell.py\' recursively without -r\n'))
    assert ret == True
    assert isinstance(get_new_command(Command(script='git push -u origin master',
                        stdout='',
                        stderr='fatal: not removing \'tests/test_shell.py\' recursively without -r\n')),
                        str)

# Generated at 2022-06-12 11:48:12.233260
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = "git branch -d branch1",
                                   output = "fatal: not removing 'branch1' recursively without -r")) == "git branch -d -r branch1"

# Generated at 2022-06-12 11:48:13.941969
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(" git rm -r test ")
    assert get_new_command(command) == u"git rm test -r"

# Generated at 2022-06-12 11:48:18.821459
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('git rm ~/Projects/test/test_file.py',
             'fatal: not removing \'~/Projects/test/test_file.py\' recursively without -r\nDid you mean \'rm -r ~/Projects/test/test_file.py\'?')
    assert get_new_command(cmd) == 'git rm -r ~/Projects/test/test_file.py'

# Generated at 2022-06-12 11:48:24.381497
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command('git rm folder',
                                   output="fatal: not removing 'folder' \
recursively without -r")) == 'git rm -r folder'
    assert get_new_command(Command('git rm -r folder/',
                                   output="fatal: not removing 'folder/' \
recursively without -r")) == 'git rm -r -r folder/'

# Generated at 2022-06-12 11:48:26.919964
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm dir/',
                      "fatal: not removing 'dir/' recursively wthout -r")
    assert get_new_command(command) == u'git rm -r dir/'

# Generated at 2022-06-12 11:48:31.181204
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    rm_command = ('git rm -r --cached /home/user/.bash_profile', '', '')
    decorated_git = Command(rm_command, 'git')
    assert get_new_command(decorated_git) == 'git rm -r --cached -r /home/user/.bash_profile'

# Generated at 2022-06-12 11:48:33.295181
# Unit test for function match
def test_match():
    assert match(Command('git rm test.txt', '', 'fatal: not removing \'test.txt\' recursively without -r'))


# Generated at 2022-06-12 11:48:40.314011
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1 file2', '', '')) == 'git rm -r file1 file2'
    assert get_new_command(Command('git rm dir1', '', '')) == 'git rm -r dir1'
    assert get_new_command(Command('git rm /dir1', '', '')) == 'git rm -r /dir1'
    assert get_new_command(Command('git rm -f /dir1', '', '')) == 'git rm -rf /dir1'
    assert get_new_command(Command('git rm --cached file1', '', '')) == 'git rm --cached -r file1'

# Generated at 2022-06-12 11:48:42.626272
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('\\rm file', 'fatal: not removing \'file\' recursively without -r', '')
    assert get_new_command(command) == '\\rm -r file'

# Generated at 2022-06-12 11:48:49.288864
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(
                script=u'git rm --cached some/directory',
                output=u"""error: pathspec 'some/directory' did not match any file(s) known to git.
fatal: not removing 'some/directory' recursively without -r""",
                stderr=u"""error: pathspec 'some/directory' did not match any file(s) known to git.
""",
                stdout=u"""fatal: not removing 'some/directory' recursively without -r
""",
                )) == u"""git rm -r --cached some/directory""")