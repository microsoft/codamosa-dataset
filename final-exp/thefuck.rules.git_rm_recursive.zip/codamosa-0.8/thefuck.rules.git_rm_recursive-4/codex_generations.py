

# Generated at 2022-06-12 11:39:47.350001
# Unit test for function match
def test_match():
    # Check if function match returns when it should
    assert match(Command('git rm nonexistantFile', 'fatal: not removing \'nonexistantFile\' recursively without -r'))



# Generated at 2022-06-12 11:39:50.208913
# Unit test for function match
def test_match():
    assert match(Command('git rm dir/file', 'fatal: not removing '
    '\'.gitignore\' recursively without -r\n', None))



# Generated at 2022-06-12 11:39:52.519253
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf dir')) == ' '.join(['git', '-r', 'rm', '-rf', 'dir'])

# Generated at 2022-06-12 11:39:54.807802
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))

# Generated at 2022-06-12 11:39:58.879666
# Unit test for function match
def test_match():
    assert match(Command('git rm non_empty_folder/', 'fatal: not removing \'non_empty_folder/\' recursively without -r', ''))
    assert match(Command('git rm -r non_empty_folder/', 'fatal: not removing \'non_empty_folder/\' recursively without -r', '')) is False
    assert match(Command('git rm non_empty_folder/', '', '')) is False
    assert match(Command('git', '', '')) is False


# Generated at 2022-06-12 11:40:01.297151
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r doc', '', '')
    new_command = get_new_command(command)
    assert new_command == command.script

# Generated at 2022-06-12 11:40:06.243982
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('rm file') == 'rm -r file'
    assert get_new_command('rm file1 file2') == 'rm -r file1 file2'
    assert get_new_command('rm -f file') == 'rm -f -r file'
    assert get_new_command('rm -f file1 file2') == 'rm -f -r file1 file2'

# Generated at 2022-06-12 11:40:12.120548
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r a', '')
    assert get_new_command(command) == 'git rm -r -r a'
    command = Command('git rm -rf a', '')
    assert get_new_command(command) == 'git rm -rf a'
    command = Command('git rm -rnf a', '')
    assert get_new_command(command) == 'git rm -rnf a'

# Generated at 2022-06-12 11:40:20.994932
# Unit test for function match
def test_match():
    assert match(Command('git rm -f README.md',
                         'fatal: not removing \'README.md\' recursively without -r'))
    assert match(Command('git rm -f README.md', 'fatal: not removing \'README.md\' recursively'))
    assert not match(Command('git rm -r README.md', 'fatal: not removing \'README.md\' recursively'))
    assert not match(Command('git rm -f README', 'fatal: not removing \'README.md\' recursively'))
    assert not match(Command('git rm README', 'fatal: not removing \'README.md\' recursively'))


# Generated at 2022-06-12 11:40:24.691344
# Unit test for function match
def test_match():
    assert match(Command(script='git rm', stderr=fake_git_rm))
    assert not match(Command(script='git rm', stderr=fake_git_rm_error_message))
    assert not match(Command(script='ls', stderr=fake_git_rm))


# Generated at 2022-06-12 11:40:37.423126
# Unit test for function match
def test_match():
    assert (match(Command('rm foo.bar', '')) == False)
    assert (match(Command('rm ', '')) == False)
    assert (match(Command('rm', '')) == False)
    assert (match(Command('git rm ', '')) == False)
    assert (match(Command('git rm foo', '')) == False)
    assert (match(Command('git rm', '')) == False)
    assert (match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')) == True)
    assert (match(Command('git rm', 'fatal: not removing \'foo\' recursively without -r')) == False)
    assert (match(Command('git rm', 'fatal: not removing \'foo\' recursively without -r', '')) == False)

# Generated at 2022-06-12 11:40:44.052376
# Unit test for function match
def test_match():
    # If match is not None, then it should be true for 'git rm dir'
    assert match(Command('git rm dir', '', 'fatal: not removing \'dir\' recursively without -r'))
    # but should not match other commands
    assert not match(Command('git rm dir', '', 1))
    assert not match(Command('git rm file', '', 1))
    assert not match(Command('git rm -r dir', '', 1))
    assert not match(Command('ls dir', '', 1))


# Generated at 2022-06-12 11:40:46.138039
# Unit test for function match
def test_match():
    assert match(Command('git rm foo.bar', 'fatal: not removing \'foo.bar\' recursively without -r'))
    assert not match(Command('git rm foo.bar'))

# Generated at 2022-06-12 11:40:47.896270
# Unit test for function match
def test_match():
    assert match('git rm dir/filename')


# Generated at 2022-06-12 11:40:51.549895
# Unit test for function match
def test_match():
    assert match(Command('git rm index.html', '')) == False
    assert match(Command('git rm index.html', 'fatal: not removing \'index.html\' recursively without -r')) == True


# Generated at 2022-06-12 11:40:56.131507
# Unit test for function match
def test_match():
    assert match(Command('git remote rm zoidberg',
                         "fatal: not removing 'zoidberg' recursively without -r"))
    assert not match(Command('rm -rf'))
    assert not match(Command('git remote rm'))
    assert not match(Command('git remote rm zoidberg'))


# Generated at 2022-06-12 11:40:57.475800
# Unit test for function match
def test_match():
    assert match(Command('git rm foo'))
    assert not match(Command('rm foo', output='fatal: foo directory'))

# Generated at 2022-06-12 11:41:01.668361
# Unit test for function match
def test_match():
    assert match(Command('git rm -r /bin/*',
                         'fatal: not removing \'/bin/vim\' recursively without -r'))
    assert not match(Command('git rm -r /bin/*',
                             'rm: cannot remove \'Dummy\' : No such file or directory'))
    assert not match(Command('ls', ''))


# Generated at 2022-06-12 11:41:04.737171
# Unit test for function match
def test_match():
    assert(match(Command('git rm file.txt',
        'fatal: not removing \'file.txt\' recursively without -r')))



# Generated at 2022-06-12 11:41:06.297976
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r '

# Generated at 2022-06-12 11:41:16.470078
# Unit test for function match
def test_match():
    assert match(Command("rm file1 file2 file3", "fatal: not removing 'file1' recursively without -r",
                        "git rm file1 file2 file3"))
    assert match(Command("rm file1 file2 file3", "fatal: not removing 'file1' (or 'file1') recursively without -r",
                        "git rm file1 file2 file3"))
    assert not match(
        Command("rm file1 file2 file3", "fatal: fasdfdasfdsa", "git rm file1 file2 file3"))
    assert not match(
        Command("rm file1 file2 file3", "fatal: not removing 'file1' recursively with -r", "git rm file1 file2 file3"))


# Generated at 2022-06-12 11:41:19.371894
# Unit test for function match
def test_match():
    assert match(Command('git rm /srv/www/example.com'))
    assert not match(Command('git pull'))

# Generated at 2022-06-12 11:41:24.799580
# Unit test for function match
def test_match():
    # Not a git command
    assert not match(Command('ls', ''))
    # Not an error message
    assert not match(Command('git remote add origin https://github.com/nvbn/test', ''))
    # Nomrmal error message
    assert match(Command('git rm --cached asdf', 'fatal: not removing \'asdf\' recursively without -r\n'))



# Generated at 2022-06-12 11:41:27.542548
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'
    assert get_new_command(Command('git rm -f file')) == 'git rm -f -r file'

# Generated at 2022-06-12 11:41:29.934945
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm file1 file2 file3", "fatal: not removing 'file1' recursively without -r")) == "git rm -r file1 file2 file3"

# Generated at 2022-06-12 11:41:32.130951
# Unit test for function match
def test_match():
    command = Command('git rm -rf src', 'fatal: not removing \'src\' recursively without -r')
    assert match(command)

# Generated at 2022-06-12 11:41:40.517177
# Unit test for function get_new_command
def test_get_new_command():
    command = '[master 7b1b62f] Add README.md\n' + \
              ' 1 file changed, 40 insertions(+)\n' + \
              " create mode 100644 README.md\n" + \
              "error: pathspec '*' did not match any file(s) known to git.\n" + \
              "fatal: not removing '/home/peter/Downloads/vim-7.4.tar.bz2' recursively without -r\n"
    assert get_new_command(Command(command, '')) == "git rm -r *"

# Generated at 2022-06-12 11:41:51.401740
# Unit test for function match
def test_match():
    command_1="git rm file"
    command_2="git rm --cached file"
    command_3="git rm file -r"
    command_4="git rm file 1 2 3"
    command_5="git rm file 1 2 3 -r"
    command_6="git rm file -r 1 2 3"
    command_7="bla bla bla"
    output_1="fatal: not removing 'file' recursively without -r"
    output_2="bla bla bla"
    command_class_1=Command(command_1, "", output_1)
    command_class_2=Command(command_2, "", output_1)
    command_class_3=Command(command_3, "", output_1)

# Generated at 2022-06-12 11:41:55.309479
# Unit test for function match
def test_match():
    # Test for matching stderr
    assert match(Command("git rm 'test'", "fatal: not removing 'test/' recursively without -r"))

    # Test for not matching stderr
    assert not match(Command("git rm -r 'test'", "fatal: not removing 'test/' recursively without -r"))


# Generated at 2022-06-12 11:41:58.145070
# Unit test for function get_new_command
def test_get_new_command():
    command = ("git rm --cached a b", "fatal: not removing 'a' recursively without -r\n")
    assert get_new_command(Command(command, None)) == "git rm -r --cached a b"

# Generated at 2022-06-12 11:42:04.165695
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', 'fatal: not removing file recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-12 11:42:12.929160
# Unit test for function match
def test_match():
	assert match(Command('git rm ali'))
	assert match(Command('git rm -n ali'))
	assert match(Command('git rm -r ali'))
	assert not match(Command('git rm ali', ''))
	assert not match(Command('git add ali'))
	assert not match(Command('git add ali', ''))
	assert not match(Command('git rm'))
	assert not match(Command('git rm -r'))
	assert not match(Command('git rm -n'))
	assert not match(Command('git rm', ''))
	assert not match(Command('git rm -n', ''))
	assert not match(Command('git rm -r', ''))


# Generated at 2022-06-12 11:42:15.112958
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file1 file2 file3',
            'fatal: not removing \'file1\' recursively without -r\n' +
            'fatal: not removing \'file2\' recursively without -r\n' +
            'fatal: not removing \'file3\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file1 file2 file3'

# Generated at 2022-06-12 11:42:17.665164
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r', '')
    assert get_new_command(command) == 'git rm -r foo'

# Generated at 2022-06-12 11:42:23.360221
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm folder', 'fatal: not removing \'folder\' recursively without -r')
    assert get_new_command(command) == u'git rm -r folder'
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == u'git rm -r file'
    command = Command('git rm -f file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == u'git rm -f -r file'

# Generated at 2022-06-12 11:42:32.620017
# Unit test for function match
def test_match():
    assert match(Command('rm file',
                         'fatal: not removing \'file\' recursively without -r',
                         ''))
    assert not match(Command('', '', ''))
    assert not match(Command('',
                             'fatal: not removing \'file\' recursively without -r',
                             ''))
    assert not match(Command('',
                             'fatal: not removing \'file\' recursively without -r',
                             ''))
    assert not match(Command('rm',
                             'D file',
                             ''))
    assert not match(Command('rm -r',
                             'fatal: not removing \'file\' recursively without -r',
                             ''))



# Generated at 2022-06-12 11:42:37.326515
# Unit test for function match
def test_match():
    assert match(Command('git rm -r --cached test/foo',
                         'fatal: not removing \'test/foo\' recursively without -r\n'
                         'Did you mean this?\n  rm \'test/foo\'', ''))
    assert not match(Command('git rm -r --cached test/foo', '', ''))


# Generated at 2022-06-12 11:42:43.502211
# Unit test for function match
def test_match():
    assert_true(match(Command('git rm b', 'fatal: not removing \'b\' recursively without -r')))
    assert_false(match(Command('git rm a', 'fatal: not removing \'b\' recursively without -r')))
    assert_false(match(Command('git rm b -r', 'fatal: not removing \'b\' recursively without -r')))


# Generated at 2022-06-12 11:42:46.407509
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm file'))



# Generated at 2022-06-12 11:42:49.900070
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -r file.txt',
        output="fatal: not removing 'file.txt' recursively without -r")
    assert get_new_command(command) == 'git rm -r -r file.txt'

# Generated at 2022-06-12 11:43:05.650414
# Unit test for function match
def test_match():
    assert match(Command('git rm -v lxdfile.py', 'fatal: not removing \'lxdfile.py\' recursively without -r'))
    assert not match(Command('git rm -v lxdfile.py', 'fatal: not removing \'lxdfile.py\' recursively without -r', 'fatal: not removing \'lxdfile.py\' recursively without -r'))
    assert not match(Command('some_command -v lxdfile.py', 'fatal: not removing \'lxdfile.py\' recursively without -r'))

# Generated at 2022-06-12 11:43:07.790897
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r .' == get_new_command(Command('git rm .', 'fatal: not removing \'somefile\' recursively without -r'))

# Generated at 2022-06-12 11:43:10.695293
# Unit test for function match
def test_match():
    assert match(Command(script='git rm newFile.txt',
                         output="fatal: not removing 'newFile.txt' recursively without -r"))



# Generated at 2022-06-12 11:43:14.697957
# Unit test for function match
def test_match():
    assert match(Command('some command', 'some output', 'some script'))
    assert match(Command('some command', 'some output', 'git rm somefile'))
    assert match(Command('some command', 'some output', 'git rm -r somefolder'))
    assert not match(Command('some command', 'some output'))


# Generated at 2022-06-12 11:43:17.371076
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf foo/',
                                   'fatal: not removing \'foo/\' recursively without -r\n')) == 'git rm -r -rf foo/'

# Generated at 2022-06-12 11:43:19.882551
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf folder/'
                         'fatal: not removing '
                         'folder/ submodule recursively without -r', ''))


# Generated at 2022-06-12 11:43:26.950449
# Unit test for function match
def test_match():
    assert (match(Command('git rm -r',
                 'fatal: not removing \'build\' recursively without -r')))
    assert (not match(Command('git rm',
                 'fatal: not removing \'build\' recursively without -r')))
    assert (not match(Command('rm some files',
                 'fatal: not removing \'build\' recursively without -r')))
    assert (not match(Command('git rm -r',
                 'fatal: not removing \'build\' recursively without -r')).output)
    assert (not match(command))


# Generated at 2022-06-12 11:43:30.554746
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -f *.py") == "git rm -rf -f *.py"
    assert get_new_command("git rm -f *.py *.txt") == "git rm -rf -f *.py *.txt"

# Generated at 2022-06-12 11:43:34.212678
# Unit test for function match
def test_match():
    assert match(Command('rm ^', '', 'fatal: not removing \'^\' recursively without -r'))
    assert not match(Command('rm ^', '', ''))
    assert not match(Command('rm ^', '', 'fatal: not removing \'^\' recursively without -r', '', ''))



# Generated at 2022-06-12 11:43:38.155887
# Unit test for function get_new_command
def test_get_new_command():
    command = 'rm folder'
    output = "fatal: not removing 'folder/file.txt' recursively without -r"
    assert get_new_command(Command(command, output)) == 'git rm -r folder'

# Generated at 2022-06-12 11:44:00.367859
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test', 'fatal: not removing \'test\' recursively without -r', 'git rm test')

    assert u'git rm -r test' == get_new_command(command)

# Generated at 2022-06-12 11:44:05.280150
# Unit test for function match
def test_match():
    assert match(Command('git rm -r myfile',
                    'fatal: not removing \'myfile\' recursively without -r'))
    assert not match(Command('git rm -r myfile', ''))
    assert not match(Command('git rm myfile', ''))


# Generated at 2022-06-12 11:44:10.870311
# Unit test for function match
def test_match():
    result_command_one = Command("git rm file.txt", "fatal: not removing 'file.txt' recursively without -r")
    result_command_two = Command("git rm -r dir", "")
    result_command_three = Command("git rm -r dir")

    assert match(result_command_one)
    assert not match(result_command_two)
    assert not match(result_command_three)


# Generated at 2022-06-12 11:44:14.745561
# Unit test for function get_new_command
def test_get_new_command():
    """
    git rm: error: The following untracked working tree files would be overwritten by merge:
    git rm: fatal: not removing 'file.txt' recursively without -r
    """
    assert get_new_command(Command('git rm file.txt', '', '', '')) == 'git rm -r file.txt'

# Generated at 2022-06-12 11:44:17.485730
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file/with/subdir/') == 'git rm -r file/with/subdir/'

# Generated at 2022-06-12 11:44:20.278723
# Unit test for function get_new_command
def test_get_new_command():
    args = git.Arguments("git rm -r", "fatal: not removing 'filename' recursively without -r")
    assert(get_new_command(command=args)=="git rm -r -r")

# Generated at 2022-06-12 11:44:30.314326
# Unit test for function match
def test_match():
    command = Command('git rm file.txt')

    assert match(command)
    assert get_new_command(command) == 'git rm -r file.txt'

    command = Command('git rm file.txt',
                      'fatal: not removing \'file.txt\' recursively without \
                      -r')

    assert match(command)
    assert get_new_command(command) == 'git rm -r file.txt'

    command = Command('git rm file.txt',
                      'fatal: not removing \'file.txt\' recursively without \
                      -r\ngit rm file.txt')

    assert match(command)
    assert get_new_command(command) == 'git rm -r file.txt'


# Generated at 2022-06-12 11:44:32.724309
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3', '', 'fatal: not removing \'file1\' recursively without -r'))


# Generated at 2022-06-12 11:44:43.104388
# Unit test for function match
def test_match():
    # Valid test
    assert match(Command('git rm foo.txt', 
        'fatal: not removing \'foo.txt\' recursively without -r'))
    assert match(Command('git rm -m foo.txt', 
        'fatal: not removing \'foo.txt\' recursively without -r'))
    assert match(Command('git rm --cached foo.txt', 
        'fatal: not removing \'foo.txt\' recursively without -r'))
    assert match(Command('git rm -f foo.txt', 
        'fatal: not removing \'foo.txt\' recursively without -r'))

    # Invalid test    
    assert not match(Command('ls foo.txt', 
        'ls: cannot access foo.txt: No such file or directory'))

# Generated at 2022-06-12 11:44:47.933925
# Unit test for function get_new_command
def test_get_new_command():
    with patch('thefuck.rules.git_rmdir_not_empty.git_support',
               return_value=True):
        assert_equal(
            get_new_command(Mock(script='rm test',
                                 output="error: directory 'test' not empty",
                                 script_parts=['rm', 'test']
                                 )),
            'rm -r test'
        )

# Generated at 2022-06-12 11:45:33.091410
# Unit test for function match
def test_match():
    assert match(Command(script='git rm file', output='fatal: not removing file recursively without -r'))
    assert not match(Command(script='git rm file', output='fatal: not removing file recursively '))
    assert not match(Command(script='git rm', output='fatal: not removing file recursively without -r'))
    assert not match(Command(script='git rm file', output='fatal: not removing file recursively without -r'))


# Generated at 2022-06-12 11:45:36.585699
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command(script='git rm foo', output='fatal: not removing \'foo\' recursively without -r\n')
    assert get_new_command(test_command) == 'git rm -r foo'

# Generated at 2022-06-12 11:45:41.264405
# Unit test for function get_new_command
def test_get_new_command():
    command_parts =['git', 'rm', '-r', 'file1', 'file2', 'file3']
    command = Command(command_parts, '', '')
    # An invalid script will not be matched
    command.script = 'rm -r file1 file2 file3'
    assert not match(command)
    # A valid script will be matched
    command.script = 'git rm file1 file2 file3'
    assert get_new_command(command) == 'git rm -r file1 file2 file3'

# Generated at 2022-06-12 11:45:44.697519
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1 file2',
                                   'fatal: not removing \'file2\' recursively without -r')) == 'git rm -r file1 file2'

# Generated at 2022-06-12 11:45:47.732207
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rebase -i HEAD^^^") == "git rebase --continue"
    assert get_new_command("git rebase -i HEAD^^^") == "git rebase --abort"

# Generated at 2022-06-12 11:45:55.096642
# Unit test for function match
def test_match():
    command='git rm /some/file'
    assert match(Command(command, "fatal: not removing '/some/file' recursively without -r\n")) == True
    assert match(Command(command, "fatal: not removing '/some/file' recursively without -r")) == True
    assert match(Command(command, "fatal: not removing '/some/file' recursively without -r\n\n")) == True
    assert match(Command(command, "fatal: not removing '/some/file' recursively without -r\n\n\n")) == True
    assert match(Command(command, "fatal: not removing '/some/file' recursively without -r\n\n\n\n")) == True

# Generated at 2022-06-12 11:45:56.798974
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test', '')
    assert get_new_command(command) == 'git rm -r -r test'

# Generated at 2022-06-12 11:46:00.152215
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file -f', '')) == 'git rm -r file -f'
    assert get_new_command(Command('git rm -f file', '')) == 'git rm -f -r file'

# Generated at 2022-06-12 11:46:08.189425
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git rm file.py') == 'git rm -r file.py')
    assert(get_new_command('git rm file.py file2.py') == 'git rm -r file.py file2.py')
    assert(get_new_command('git rm -rv file.py') == 'git rm -r -rv file.py')
    assert(get_new_command('git rm -rf file.py') == 'git rm -r -rf file.py')
    assert(get_new_command('git rm -rf file.py file2.py') ==
           'git rm -r -rf file.py file2.py')

# Generated at 2022-06-12 11:46:15.141723
# Unit test for function match
def test_match():
    assert match(Command(script = 'rm file.txt',
                         stderr = 'fatal: not removing \'file.txt\' recursively without -r'))
    assert match(Command(script = 'git rm -rf file.txt',
                         stderr = 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command(script = 'rm file.txt',
                             stderr = 'error: not removing \'file.txt\''))



# Generated at 2022-06-12 11:47:49.434533
# Unit test for function match
def test_match():
    assert match(Command('git rm a b',
                    'fatal: not removing a\' recursively without -r\n',
                    None))
    assert not match(Command('git rm a',
                'fatal: not removing a\' recursively without -r\n',
                None))
    assert not match(Command('git rm a b'))
    assert not match(Command('git rm',
                'fatal: not removing a\' recursively without -r\n',
                None))


# Generated at 2022-06-12 11:47:51.688633
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test.py', 'fatal: not removing \'test.py\' recursively without -r')) == 'git rm -r test.py'

# Generated at 2022-06-12 11:47:53.992575
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
        'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt', ''))


# Generated at 2022-06-12 11:47:58.040430
# Unit test for function get_new_command
def test_get_new_command():
    """ Assert that the command rm -r is prepended when appropriate"""
    assert get_new_command(Command('git rm file/not/found', '', 'fatal: not removing \'file/not/found\' recursively without -r')) == 'git rm -r file/not/found'

# Generated at 2022-06-12 11:48:02.412873
# Unit test for function get_new_command
def test_get_new_command():
    from tests.mocks import Mock
    assert get_new_command(Mock(script='git rm a',
                                output='fatal: not removing \'a\'\n'
                                       'recursively without -r')) == 'git rm -r a'

# Generated at 2022-06-12 11:48:08.461577
# Unit test for function match
def test_match():
    # a positive case
    assert match(Command(script='git rm -r test',
                         output="fatal: not removing 'test' recursively without -r"))
    # a negative case
    assert not match(Command(script='git rm -r test',
                             output='fatal: not removing test recursively without -r'))
    # another negative case
    assert not match(Command(script='git rm -r test',
                             output='error: not removing recursively without -r'))


# Generated at 2022-06-12 11:48:13.612329
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm and/or/here/are/some/more/directories/') == 'git rm -r and/or/here/are/some/more/directories/'
    assert get_new_command('git rm -r and/or/here/are/some/more/directories/') == 'git rm -r and/or/here/are/some/more/directories/'
    assert get_new_command('git rm .') == 'git rm -r .'

# Generated at 2022-06-12 11:48:15.572196
# Unit test for function get_new_command
def test_get_new_command():
    command = "rm TESTFILE"
    assert get_new_command(command) == "rm -r TESTFILE"

# Generated at 2022-06-12 11:48:18.707796
# Unit test for function get_new_command
def test_get_new_command():
    script = "git rm file1 file2 file3"
    output = "fatal: not removing 'file1' recursively without -r"
    command = Command(script, output)
    assert get_new_command(command) == "git rm -r file1 file2 file3"

# Generated at 2022-06-12 11:48:28.071591
# Unit test for function match
def test_match():
    command1 = Command("git rm -rf src", "fatal: not removing 'src' recursively without -r")
    assert match(command1)
    command2 = Command("git rm -rf src",
                       "fatal: not removing 'src' recursively without -r\n"
                       "Did you mean 'rm -rf'?")
    assert match(command2)
    command3 = Command("git rm -rf src/",
                       "fatal: not removing 'src/' recursively without -r\n"
                       "Did you mean 'rm -rf'?")
    assert match(command3)
    command4 = Command("git rm -rf src", "fatal: not removing 'src' recursively without -r")
    assert match(command4)