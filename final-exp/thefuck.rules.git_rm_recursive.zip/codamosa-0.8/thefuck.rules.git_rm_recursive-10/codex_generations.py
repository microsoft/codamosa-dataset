

# Generated at 2022-06-12 11:39:50.543690
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.specific.git import git_support
    from thefuck.types import Command
    command = Command('git rm -r clang', '', 'fatal: not removing \'clang\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r clang'
    # test not match situation
    command_no_match = Command('git rm clang', '', 'fatal: not removing \'clang\' recursively without -r')
    assert git_support(get_new_command)(command_no_match) == None

# Generated at 2022-06-12 11:39:54.387900
# Unit test for function get_new_command
def test_get_new_command():
    old_command = 'git rm foo'
    new_command = 'git rm -r foo'
    output = "fatal: not removing 'foo' recursively without -r"
    command = Command(old_command, output)
    assert get_new_command(command) == new_command
    assert not match(command)

# Generated at 2022-06-12 11:39:57.603403
# Unit test for function match
def test_match():
    command = Command('git rm -r lib/cool.txt', 'fatal: not removing \'lib/cool.txt\' recursively without -r')
    import sys
    assert match(command)


# Generated at 2022-06-12 11:40:00.918540
# Unit test for function match
def test_match():
    # input command
    command = Command("git rm file")
    # output from command execution
    command.output = "fatal: not removing 'file' recursively without -r"
    # test output
    assert match(command)



# Generated at 2022-06-12 11:40:03.024155
# Unit test for function match
def test_match():
    assert match(Command('git rm -f README.md', 'fatal: not removing \'README.md\' recursively without -r\n'))
    assert not match(Command('git rm -f README.md', ''))
    assert not match(Command('wc -c README.md', ''))

# Generated at 2022-06-12 11:40:06.057965
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -rf ./this_dir")
    assert get_new_command(command) == "git rm -rf -r ./this_dir"
    command = Command("git rm -rf this_file")
    assert get_new_command(command) == "git rm -rf -r this_file"

# Generated at 2022-06-12 11:40:11.929142
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r dir1")
    assert get_new_command(command) == "git rm -r -r dir1"
    command = Command("git rm dir1")
    assert get_new_command(command) == "git rm -r dir1"
    command = Command("git rm  dir1")
    assert get_new_command(command) == "git rm -r dir1"

# Generated at 2022-06-12 11:40:15.770108
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf blah', 'fatal: not removing \'blah\' recursively without -r'))
    assert not match(Command('git rm -rf blah', 'Removed blah'))
    assert not match(Command('git rm -rf blah'))


# Generated at 2022-06-12 11:40:20.582625
# Unit test for function get_new_command
def test_get_new_command():
    assert ''.join(['git rm -r ', ' hello']) == get_new_command(
        Command(''.join(['git rm ', ' hello']), ''))
    assert ''.join(['git config --global color.status auto ', ' hello']) == get_new_command(
        Command(''.join(['git config --global color.status auto ', ' hello']), ''))

# Generated at 2022-06-12 11:40:22.491564
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git rm foo bar'
    assert get_new_command(Command(command, '', '')) == 'git rm -r foo bar'

# Generated at 2022-06-12 11:40:32.706560
# Unit test for function get_new_command
def test_get_new_command():
    # test for arguments not containing 'rm'
    command = Command("", "", "")
    assert_equal(get_new_command(command), command.script)
    # test for command output not containing the required error message
    command = Command("git rm", "", "")
    assert_equal(get_new_command(command), command.script)
    # test for correct arguments
    command = Command("git rm", "", "fatal: not removing 'com/test/test_file' recursively without -r")
    assert_equal(get_new_command(command), "git rm -r")

# Generated at 2022-06-12 11:40:37.188713
# Unit test for function match
def test_match():
    assert match(Script(script=u'git rm file.txt'))
    assert match(Script(script=u'git rm -f file.txt'))
    assert not match(Script(script=u'git rm -f file.txt',
        output=u"fatal: not removing 'file.txt' recursively without -r"))

# Generated at 2022-06-12 11:40:40.217522
# Unit test for function match
def test_match():
    assert match(Command('git rm common.py', 'fatal: not removing \'common.py\' recursively without -r'))
    assert not match(Command('git rm common.py', ''))
    assert not match(Command('rm common.py', 'fatal: not removing \'common.py\' recursively without -r'))


# Generated at 2022-06-12 11:40:41.845798
# Unit test for function match
def test_match():
    assert match(Command('git rm file', '', 'fatal: not removing \
\'file\' recursively without -r'))


# Generated at 2022-06-12 11:40:43.473699
# Unit test for function match
def test_match():
    assert match(Command('git rm -r'))
    assert not match(Command('rm'))


# Generated at 2022-06-12 11:40:45.113250
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm develop', '', '')) == 'git rm -r develop'


# Generated at 2022-06-12 11:40:50.476137
# Unit test for function match
def test_match():
    assert match(Command("git rm -f dir/file", "fatal: not removing 'dir/file' recursively without -r"))
    assert not match(Command("git rm -f dir/file", "fatal: not removing 'dir/file'"))
    assert not match(Command("git rm -r dir/file", "fatal: not removing 'dir/file' recursively without -r"))

# Generated at 2022-06-12 11:40:52.997410
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git rm file', 'fatal: not removing')) == 'git rm -r file'

# Generated at 2022-06-12 11:41:01.967259
# Unit test for function match
def test_match():
    assert match(Command('git rm -r *', 'fatal: not removing \'*\' recursively without -r'))
    assert match(Command('git rm -r *', 'fatal: not removing \'*.py\' recursively without -r'))
    assert not match(Command('git rm *', 'fatal: not removing \'*\' recursively without -r'))
    assert not match(Command('git rm -r -f *', 'fatal: not removing \'*\' recursively without -r'))
    assert not match(Command('git rm -r * --cached', 'fatal: not removing \'*\' recursively without -r'))
    assert not match(Command('git rm -r -f &*', 'fatal: not removing \'*\' recursively without -r'))


# Generated at 2022-06-12 11:41:05.336117
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm myFile', "fatal: not removing 'myFile' recursively without -r" , '')
    assert get_new_command(command) == u'git rm -r myFile'

# Generated at 2022-06-12 11:41:10.789954
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test1.py', 'fatal: not removing \'test1.py\' recursively without -r'))
    assert not match(Command('git rm -r test1.py'))
    assert not match(Command('git remote -v', 'fatal: not removing \'test1.py\' recursively without -r'))


# Generated at 2022-06-12 11:41:11.350583
# Unit test for function match

# Generated at 2022-06-12 11:41:13.016927
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command("git rm file.txt") == "git rm -r file.txt")


# Generated at 2022-06-12 11:41:15.023377
# Unit test for function match
def test_match():
    assert match(Command('git rm file/path',
        'fatal: not removing \'path\' recursively without -r\n'))


# Generated at 2022-06-12 11:41:22.097434
# Unit test for function get_new_command
def test_get_new_command():
    git_rm_recursively_fails_regex = (
        "^.*fatal: not removing '.*' recursively without -r$"
    )
    assert match(Command('git rm -r foo', git_rm_recursively_fails_regex))
    assert get_new_command(Command('git rm -r foo', git_rm_recursively_fails_regex)) \
        == 'git rm -r -r foo'

# Generated at 2022-06-12 11:41:26.775238
# Unit test for function match
def test_match():
    assert (match(Command('git rm submodule',
                          stderr='fatal: not removing \'submodule\' recursively without -r')))
    assert (not match(Command('git rm submodule',
                              stderr='fatal: not removing \'submodule\' recursively --r')))
    assert (not match(Command('git rm submodule')))



# Generated at 2022-06-12 11:41:29.588749
# Unit test for function get_new_command
def test_get_new_command():
	assert "git rm -r testABC" == get_new_command(Command('git rm testABC',
															 'fatal: not removing \'testABC\' recursively without -r'))

# Generated at 2022-06-12 11:41:31.582156
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /home/scott/web'))



# Generated at 2022-06-12 11:41:34.494569
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo', 'fatal: not removing "foo" recursively without -r')
    assert get_new_command(command) == u'git rm -r foo'

# Generated at 2022-06-12 11:41:37.594558
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    command = Command('rm -r')
    assert get_new_command(command) == 'rm -r'

# Generated at 2022-06-12 11:41:50.598086
# Unit test for function match
def test_match():
    assert match(Command('git rm'))
    assert match(Command('git rm xyz'))
    assert match(Command('git rm -f'))
    assert match(Command('git rm -f xyz'))
    assert match(Command('git rm -rf'))
    assert match(Command('git rm -rf xyz'))
    assert match(Command('git rm -v'))
    assert match(Command('git rm -v xyz'))
    assert match(Command('git rm -rfv'))
    assert match(Command('git rm -rfv xyz'))

    assert not match(Command('git rmerror'))
    assert not match(Command('git rm xyz abc'))



# Generated at 2022-06-12 11:41:53.514943
# Unit test for function match
def test_match():
    assert match(Command(script='git rm ',
                         output='fatal: not removing "test" recursively without -r'))
    assert not match(Command(script='git status', output=''))
    assert not match(Command(script='git log', output=''))


# Generated at 2022-06-12 11:41:57.386690
# Unit test for function match
def test_match():
    a = Command(script = 'git rm -r file.txt')
    match(a)
    a = Command(script = 'git rm -r file.txt')
    match(a)
    a = Command(script = 'git rm -r file.txt')
    match(a)


# Generated at 2022-06-12 11:42:01.137615
# Unit test for function match
def test_match():
    command1 = Command("git rm *", "fatal: not removing '*' recursively without -r")
    command2 = Command("git rm", "fatal: not removing '*' recursively without -r")
    assert match(command1)
    assert not match(command2)

# Generated at 2022-06-12 11:42:05.681187
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = "git rm -f a/b",
                      stderr = "fatal: not removing 'a/b' recursively without -r")
    assert get_new_command(command) == 'git rm -f -r a/b'

# Generated at 2022-06-12 11:42:07.870838
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test')) == 'git rm -r test'


# Generated at 2022-06-12 11:42:10.051326
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm a', 'fatal: not removing \'a\' recursively without -r')) == 'git rm -r a'

# Generated at 2022-06-12 11:42:12.689718
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command1 = Command('git rm test')
    command2 = Command('git rm -r test1')

    new_cmd = get_new_command(command1)
    assert new_cmd == 'git rm -r test'

# Generated at 2022-06-12 11:42:17.869429
# Unit test for function get_new_command
def test_get_new_command():
    output = u"""fatal: not removing 'db/migrate/20150708041053_add_avatar_column_to_user.rb' recursively without -r
Did you mean this?
	git rm --cached db/migrate/20150708041053_add_avatar_column_to_user.rb"""
    command = Command('git rm db/migrate/20150708041053_add_avatar_column_to_user.rb', output)
    assert (get_new_command(command) == u'git rm -r db/migrate/20150708041053_add_avatar_column_to_user.rb')

# Generated at 2022-06-12 11:42:20.748699
# Unit test for function match
def test_match():
    mock_command = p.MockCommand(script=u'git rm foo/bar', output="fatal: not removing 'foo/bar' recursively without -r")
    assert match(mock_command)


# Generated at 2022-06-12 11:42:28.134950
# Unit test for function get_new_command
def test_get_new_command():
    command = "git rm -r -f --cached dir/file"
    assert get_new_command(Command(command, "fatal: not removing 'dir/file' recursively without -r")) == "git rm -r -f -r --cached dir/file"

# Generated at 2022-06-12 11:42:33.974627
# Unit test for function match
def test_match():
    assert match(Command(script = 'git rm foo'))
    assert match(Command(script = 'git rm -r foo'))
    assert not match(Command(script = 'git rm'))
    assert not match(Command(script = 'git rm -f foo'))
    assert not match(Command(script = 'rm foo'))
    assert not match(Command(script = 'rm -r foo'))


# Generated at 2022-06-12 11:42:36.892772
# Unit test for function match
def test_match():
    assert match(Command(' git rm .',
                         'fatal: not removing \'.\' recursively without -r'))
    assert not match(Command(
        ' git rm .', 'fatal: not removing \'..\' recursively without -r'))

# Generated at 2022-06-12 11:42:38.879919
# Unit test for function match
def test_match():
    assert match(Command('git rm test.txt', '', '', '', '', ''))
    assert not match(Command('git status', '', '', '', '', ''))

# Generated at 2022-06-12 11:42:44.325560
# Unit test for function get_new_command

# Generated at 2022-06-12 11:42:48.587171
# Unit test for function match
def test_match():
    assert match(Command('git stash rm stash@{1}',
        u"fatal: not removing 'stash@{1}' recursively without -r", ''))
    assert not match(Command('git stash', '', ''))
    assert not match(Command('git rm -r', '', ''))


# Generated at 2022-06-12 11:42:51.670114
# Unit test for function match
def test_match():
    # Test match function
    assert match(Command(script='git rm -rf .'))
    assert match(Command(script='git rm -rf .',
                         output='fatal: not removing '
                                "'./README.md' recursively without -r"))


# Generated at 2022-06-12 11:42:54.802514
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt', ''))


# Generated at 2022-06-12 11:42:56.713663
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test.py', '')) == 'git rm -r test.py'

# Generated at 2022-06-12 11:43:00.699938
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -f README.rg', 'fatal: not removing \'README.rg\' recursively without -r')
    new_command = get_new_command(command)
    assert new_command == 'git rm -r -f README.rg'

# Generated at 2022-06-12 11:43:10.831228
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r test.txt'

# Generated at 2022-06-12 11:43:13.381062
# Unit test for function match
def test_match():
    assert match(Command('git rm', "fatal: not removing 'foo' recursively without -r"))
    assert not match(Command('git rm -r', "fatal: not removing 'foo' recursively without -r"))



# Generated at 2022-06-12 11:43:17.546416
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("rm -rf scripts/", "fatal: not removing 'scripts/' recursively without -r")
    new_command = get_new_command(command)

    # Verify rm -rf scripts/ becomes rm -r scripts/
    assert(new_command == "rm -r -rf scripts/")

# Generated at 2022-06-12 11:43:22.544597
# Unit test for function match
def test_match():
	command1=Command(script='git rm file_to_remove',output="fatal: not removing 'file_to_remove' recursively without -r")
	command2=Command(script='git rm -r file_to_remove',output="fatal: not removing 'file_to_remove' recursively without -r")
	
	assert match(command1)
	assert not match(command2)


# Generated at 2022-06-12 11:43:25.343142
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test',
                      'fatal: not removing \'test\' recursively without -r')
    assert get_new_command(command) == 'git rm -r test'

# Generated at 2022-06-12 11:43:28.548382
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf qwe', 
        'fatal: not removing \'qwe\' recursively without -r'))
    assert not match(Command('git rm -rf qwe', ''))


# Generated at 2022-06-12 11:43:34.335987
# Unit test for function match
def test_match():
    git_support() # This function is required to create global variables
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 1, ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively', '', 1, ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\'', '', 1, ''))

#Unit test for function get_new_command

# Generated at 2022-06-12 11:43:36.694620
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r test').script == 'git rm -r -r test'


# Generated at 2022-06-12 11:43:41.550413
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', '', '', ''))
    assert not match(Command('git rm file', '', ''))
    

# Generated at 2022-06-12 11:43:48.364763
# Unit test for function match
def test_match():
    result = match(Command('git rm ', 'fatal: not removing \'blah.py\' recursively without -r'))
    assert result
    assert not match(Command('git rm -r', 'fatal: not removing \'blah.py\' recursively without -r'))
    assert not match(Command('git something', 'fatal: not removing \'blah.py\' recursively without -r'))
    assert not match(Command('git rm', ''))

# Generated at 2022-06-12 11:44:05.464532
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command
    assert u'git rm -r file.py' == get_new_command(Script(u'git rm file.py'))


# Generated at 2022-06-12 11:44:07.247059
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-12 11:44:12.113826
# Unit test for function match
def test_match():
    assert match(Command('git rm hello',
               'fatal: not removing \'hello\' recursively without -r\n'))
    assert not match(Command('git rm hello', ''))
    assert not match(Command('git rsm hello', ''))
    assert not match(Command('git rm -r hello', ''))


# Generated at 2022-06-12 11:44:17.862198
# Unit test for function match
def test_match():
    assert git.match(Command("git rm vishal",
                            "fatal: not removing 'vishal' recursively without -r\n"))
    assert git.match(Command("git rm -n vishal.txt",
                            "fatal: not removing 'vishal.txt' recursively without -r\n"))
    assert git.match(Command("git rm vishal.txt",
                            "fatal: not removing 'vishal.txt' recursively without -r\n"))
    assert git.match(Command("git rm -r vishal.txt",
                            "fatal: not removing 'vishal.txt' recursively without -r\n"))
    assert not git.match(Command("git rm vishal", ""))


# Generated at 2022-06-12 11:44:26.499452
# Unit test for function match
def test_match():
    command_str = "git rm file1 file2 file3"
    command_str_2 = "git rm -r file1 file2 file3"
    command_str_3 = "git rm -r file1 file2 file3"
    command_obj = Command(command_str, "fatal: not removing 'file1' recursively without -r")
    command_obj_2 = Command(command_str_2, "fatal: not removing 'file1' recursively without -r")
    command_obj_3 = Command(command_str_3, "")
    assert not match(command_obj)
    assert not match(command_obj_2)
    assert not match(command_obj_3)


# Generated at 2022-06-12 11:44:29.946570
# Unit test for function match
def test_match():
    assert match(Command('git rm', 'fatal: not removing \'b\' recursively without -r'))
    assert not match(Command('git rm', 'fatal: not removing \'\' recursively without -r'))



# Generated at 2022-06-12 11:44:32.669478
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git rm folder',
            'fatal: not removing \'folder\' recursively without -r',
            '', 123)) == "git rm -r folder")

# Generated at 2022-06-12 11:44:35.330401
# Unit test for function match
def test_match():
    assert match(Command('git rm -f a',
                         'fatal: not removing \'-f\' recursively without -r'))
    assert not match(Command("git branch -d mybranch", ""))


# Generated at 2022-06-12 11:44:38.240731
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git status && git add -r file_1' == get_new_command(
        Command('git status && git rm file_1',
            u"fatal: not removing 'file_1' recursively without -r\n"
            u"Did you mean 'rm' ?",
            u'git status && git rm file_1'))

# Generated at 2022-06-12 11:44:40.858941
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm test_file') == 'git rm -r test_file'

# Generated at 2022-06-12 11:44:59.060505
# Unit test for function match
def test_match():
    assert match(Command('rm -rf a b'))
    assert match(Command('git rm -rf a b'))
    assert match(Command('git rm a b'))
    assert not match(Command('rm a b'))
    assert not match(Command('git commit'))


# Generated at 2022-06-12 11:45:02.579784
# Unit test for function get_new_command
def test_get_new_command():
	test_command = Command('test')
	test_command.script = "git rm file"
	test_command.output = "fatal: not removing 'file' recursively without -r"
	assert get_new_command(test_command) == "git rm -r file"

# Generated at 2022-06-12 11:45:08.710131
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git rm asd',
                                   'fatal: not removing \'asd\' recursively without -r')) == 'git rm -r asd'
    assert get_new_command(Command('git rm -f asd',
                                   'fatal: not removing \'asd\' recursively without -r')) == 'git rm -f -r asd'

# Generated at 2022-06-12 11:45:11.314840
# Unit test for function get_new_command
def test_get_new_command():
	command = Command("git rm -r -f README.md", "fatal: not removing 'README.md' recursively without -r")
	assert(get_new_command(command) == "git rm -rf -r README.md")

# Generated at 2022-06-12 11:45:16.322453
# Unit test for function get_new_command
def test_get_new_command():
    command_test = type('test', (object,),
                        {'script': 'git rm testfile', 'script_parts': ['git', 'rm', 'testfile'], 'output': "fatal: not removing 'testfile' recursively without -r\n"})
    assert get_new_command(command_test) == "git rm -r testfile"


# Generated at 2022-06-12 11:45:20.117424
# Unit test for function match
def test_match():
    out = "fatal: not removing 'third_dir/sub_dir/sub_sub_dir' recursively without -r"
    cmd = Command(' git rm third_dir ', out)
    assert match(cmd)
    assert not match(Command(' git rm -r third_dir', out))


# Generated at 2022-06-12 11:45:24.968414
# Unit test for function match
def test_match():
    assert match(Command('git rm a b',
                         'fatal: not removing \'a\' recursively without -r', ''))
    assert not match(Command('git rm a b',
                             'fatal: not removing \'b\' recursively without -r\n'
                             'Did you mean this?\n  rm', ''))

# Generated at 2022-06-12 11:45:29.346266
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script=u'git rm file.txt',
                      results=[u'',
                               u'fatal: not removing \'file.txt\' recursively without -r'])
    new_command = get_new_command(command)
    assert new_command == u'git rm -r file.txt'

# Generated at 2022-06-12 11:45:33.484412
# Unit test for function match
def test_match():
    RESULTS = ['git rm -f --cached target',
               'git rm -f --cached target # comment',
               'git rm -r target/dir']

    for result in RESULTS:
        assert match(Command(result,
                             "fatal: not removing 'target' recursively without -r\n"))

    else:
        assert not match(Command('git rm target', ''))


# Generated at 2022-06-12 11:45:36.260094
# Unit test for function get_new_command
def test_get_new_command():
    """Test for function get_new_command"""
    # Unit test for get_new_command doesn't make sense, because the
    # modification is purely static.

# Generated at 2022-06-12 11:45:55.208913
# Unit test for function match
def test_match():
    output = textwrap.dedent("""
    error: the following file has staged content different from both the file and the HEAD:
        README.md
    fatal: not removing 'README.md' recursively without -r""")

    assert match(Command("git rm README.md", output)) is True
    assert match(Command("git rm README.md", "")) is False



# Generated at 2022-06-12 11:45:58.937801
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r folder/subfolder',
                      '/home/arthur/file.py',
                      'fatal: not removing \'folder/subfolder\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r -r folder/subfolder'

# Generated at 2022-06-12 11:46:02.332859
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    command = Command('git rm dir', 'fatal: not removing '\
                                    'recursively without -r')
    assert get_new_command(command) == 'git -r rm dir'

# Generated at 2022-06-12 11:46:10.727830
# Unit test for function match
def test_match():
    # Match function should return true if the output contains the following
    assert match(Command('git rm test.txt',
                         'fatal: not removing \'test.txt\' recursively \
                         without -r',
                         0, None))

    # Match function should return false if the output doesnt contain the
    # word 'fatal'
    assert not match(Command('git rm test.txt',
                             'Not removing files without -r option',
                             0, None))

    # Match function should return false if the command does not contain
    # 'git rm'.
    assert not match(Command('git rm',
                             'Not removing files without -r option',
                             0, None))


# Generated at 2022-06-12 11:46:13.847497
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm file',
                           stderr='fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-12 11:46:15.230588
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm folder') == 'git rm -r folder'

# Generated at 2022-06-12 11:46:17.260772
# Unit test for function get_new_command
def test_get_new_command():
    command = CommandMock('git rm  -r --cached test')
    assert get_new_command(command) == 'git rm -r  -r --cached test'

# Generated at 2022-06-12 11:46:19.370883
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm',
                                   'fatal: not removing \'file\' recursively without -r',
                                   '')) == 'git rm -r file'

# Generated at 2022-06-12 11:46:29.932047
# Unit test for function match
def test_match():
    match_output = Command('git rm -r test_dir', stderr='fatal: not removing '
                           '\'test_dir\' recursively without -r')
    assert match(match_output)

    match_output = Command('git rm test_file', stderr='fatal: not removing '
                           '\'test_file\' recursively without -r')
    assert match(match_output)

    no_match_output = Command('git rm test_dir', stderr='fatal: not removing '
                              '\'test_dir\' recursively without -r')
    assert not match(no_match_output)

    no_match_output = Command('git', stderr='fatal: not removing '
                              '\'test_dir\' recursively without -r')

# Generated at 2022-06-12 11:46:31.931480
# Unit test for function match
def test_match():
    assert match(Command("git rm foo", "fatal: not removing 'foo' recursively without -r"))
    assert not match(Command("git rm foo", ""))

# Generated at 2022-06-12 11:46:50.511207
# Unit test for function get_new_command
def test_get_new_command():
    git_rm_command = "git rm superfile.txt"
    git_rm_new_command = "git rm -r superfile.txt"
    assert_equals(get_new_command(Command(git_rm_command, "", "")), git_rm_new_command)

# Generated at 2022-06-12 11:46:52.807039
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r',
                         '/usr/local/bin/git'))


# Generated at 2022-06-12 11:46:55.157035
# Unit test for function match
def test_match():
    assert match(Command('git rm usecase.sh', "fatal: not removing 'usecase.sh' recursively without -r"))
    assert not match(Command('git branch', ''))

# Generated at 2022-06-12 11:46:59.246159
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file1 file2') == 'git rm -r file1 file2'
    assert get_new_command('git rm -r file1 file2') == 'git rm -r file1 file2'
    assert get_new_command('git rm -r file1') == 'git rm -r file1'

# Generated at 2022-06-12 11:47:01.438018
# Unit test for function match
def test_match():
    assert (match(Command('git rm -rf file', "fatal: not removing 'file' recursively without -r", '')))


# Generated at 2022-06-12 11:47:03.307198
# Unit test for function match
def test_match():
    assert match(Command(' rm ', 'fatal: not removing \'README.md\' recursively without -r'))


# Generated at 2022-06-12 11:47:06.053535
# Unit test for function match
def test_match():
    assert match(Command('rm a', stderr='fatal: not removing \'a\' recursively without -r'))
    assert not match(Command('rm a', stderr='fatal: not removing \'a\''))



# Generated at 2022-06-12 11:47:10.419421
# Unit test for function get_new_command
def test_get_new_command():
    res = get_new_command(Script("git rm -f", "fatal: not removing 'xxx' recursively without -r"))
    assert res == 'git rm -f -r'
    res = get_new_command(Script("git rm -f xxx", "fatal: not removing 'xxx' recursively without -r"))

# Generated at 2022-06-12 11:47:16.416791
# Unit test for function match
def test_match():
   assert match(Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r\n')) == True
   assert match(Command('git rm test.txt', 'not removing \'test.txt\' recursively without -r\n')) == False
   assert match(Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r\n')) == True
   assert match(Command('git', 'fatal: not removing \'test.txt\' recursively without -r\n')) == False


# Generated at 2022-06-12 11:47:19.533255
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    command1 = Command('git rm file')
    assert get_new_command(command1) == 'git rm -r file'
    command2 = Command('git rm -r file')
    assert get_new_command(command2) is None

# Generated at 2022-06-12 11:48:02.928599
# Unit test for function match
def test_match():
    assert(match(Command('git rm foo/path', 'fatal: not removing \'foo/path\' recursively without -r')))
    assert(not match(Command('git rm foo/path', 'fatal: not removing \'foo/path\' recursively without')))
    assert(not match(Command('git rm foo/path', 'fatal: not removing \'foo/path\' recursively')))
    assert(not match(Command('git rm foo/path')))


# Generated at 2022-06-12 11:48:04.518542
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm file', 'fatal: recursively without -r\n'))
    assert not match(Command('git rm file', 'fatal: not removing \n'))

# Generated at 2022-06-12 11:48:07.962746
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))

# Generated at 2022-06-12 11:48:10.831854
# Unit test for function match
def test_match():
    assert match(Command('git rm -f src/test.py')) is False
    assert match(Command('git rm src/test.py',
                         "fatal: not removing 'src/test.py' recursively"
                         " without -r\n")) is True


# Generated at 2022-06-12 11:48:15.491346
# Unit test for function match
def test_match():
    # False if rm not in command
    assert not match(Command('git status', '', ''))
    # False if script not in command
    assert not match(Command('git rm', '', ''))
    # False if rm not in output
    assert not match(Command('git rm', '', ''))
    # False if "fatal: not removing '" not in output
    assert not match(Command('git rm', '', 'fatal: not removing'))
    # True if rm and script and output in command
    assert match(Command('git rm', '', "fatal: not removing 'foo' recursively without -r"))



# Generated at 2022-06-12 11:48:24.776336
# Unit test for function match
def test_match():
    # command line should contain 'rm'
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    # command line should contain ' rm ' even if there are other 'rm' in the command
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))
    # command line should contain '-r'
    assert not match(Command('git rm file', ''))
    # command line should not contain ' rm '
    assert not match(Command('git foobar',
        'fatal: not removing \'file\' recursively without -r'))
    # command line should not contain '-r'
    assert not match(Command('git rm file',
        'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-12 11:48:28.403789
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command("git rm 'something'")) == "git rm -r 'something'")
    assert(get_new_command(Command("git rm something")) == "git rm -r something")
    assert(get_new_command(Command("git rm something -r")) == "git rm -r something -r")
    assert(get_new_command(Command("git rm 'something' -r")) == "git rm -r 'something' -r")

# Generated at 2022-06-12 11:48:33.836424
# Unit test for function match
def test_match():
    assert match(Command('git rm filename', '', 'fatal: not removing \'filename\' recursively without -r'))
    assert not match(Command('git rm filename', '', ''))
    assert not match(Command('git rmdir foldername', '', ''))
    assert not match(Command('git rm -r foldername', '', 'fatal: not removing \'filename\' recursively without -r'))



# Generated at 2022-06-12 11:48:37.312796
# Unit test for function match
def test_match():
    assert match(command=Command(' git rm -rf README.md ', 'fatal: not removing \'README.md\' recursively without -r')) == True
    assert match(command=Command(' git rm -rf README.md ', 'error: not removing \'README.md\' recursively without -r')) == False


# Generated at 2022-06-12 11:48:39.369106
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm -r --cached dist")) == u'git rm -r -r --cached dist'

# Generated at 2022-06-12 11:49:20.752303
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git remote rm test') == 'git remote -r rm test'

# Generated at 2022-06-12 11:49:23.575071
# Unit test for function get_new_command
def test_get_new_command():
    from mock import Mock
    command = Mock(script='git rm -f testFile', output="fatal: not removing 'testFile' recursively without -r")
    assert get_new_command(command) == "git rm -r -f testFile"

# Generated at 2022-06-12 11:49:27.441559
# Unit test for function match
def test_match():
    assert match(Command('git rm f', 'fatal: not removing \'f\' recursively without -r', ''))
    assert not match(Command('git rm -r f', '', ''))
    assert not match(Command('git diff', '', ''))



# Generated at 2022-06-12 11:49:29.523524
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git status") == "git status"
    assert get_new_command("git rm -r file2.txt") == "git rm -r -r file2.txt"

# Generated at 2022-06-12 11:49:33.218522
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r lorem', '', 'fatal: not removing \'lorem\'')) == 'git rm -r lorem'
    assert get_new_command(Command('git rm lorem', '', 'fatal: not removing \'lorem\' recursively without -r')) == 'git rm -r lorem'

# Generated at 2022-06-12 11:49:36.382598
# Unit test for function match
def test_match():
    with Command(script='git rm blah blah blah') as command:
        assert match(command)
    with Command(script='git rm blah blah blah', output='fatal: not removing blah blah without -r') as command:
        assert match(command) is False


# Generated at 2022-06-12 11:49:40.129769
# Unit test for function match
def test_match():
    assert match(Command('git rm lib/ansible/modules/core/cloud/amazon/ec2_vol_info.py',
                         'fatal: not removing \'lib/ansible/modules/core/cloud/amazon/ec2_vol_info.py\' recursively without -r'))

# Unit tests for function get_new_command

# Generated at 2022-06-12 11:49:43.026427
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('rm file', '', '')) == \
        'git rm -r file'
    assert get_new_command(Command('git rm file', '', '')) == \
        'git rm -r file'