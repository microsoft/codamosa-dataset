

# Generated at 2022-06-12 11:39:45.959145
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = 'git rm abc.txt',
                      output = 'fatal: not removing \'abc.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r abc.txt'

# Generated at 2022-06-12 11:39:50.901990
# Unit test for function match
def test_match():
    assert match(Command('git rm non-existent-file',
        'fatal: not removing \'non-existent-file\' recursively without -r\n',
        ''))
    assert not match(Command('git rm non-existent-file', '', ''))
    assert not match(Command('ls non-existent-file', '', ''))
    asser

# Generated at 2022-06-12 11:39:54.695775
# Unit test for function match
def test_match():
	output = 'fatal: not removing \'README.md\' recursively without -r'
	command = 'git rm README.md'
	assert match(Command(command, output))
	command = 'git test README.md'
	assert not match(Command(command, output))


# Generated at 2022-06-12 11:39:57.641790
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.txt',
                         'fatal: not removing \'hello.txt\' recursively without -r'))
    assert not match(Command('git rm hello.txt', ''))


# Generated at 2022-06-12 11:39:59.429168
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command("git rm f -r") == "git rm -r f -r"

# Generated at 2022-06-12 11:40:02.130911
# Unit test for function match
def test_match():
    assert match(Command('rm "file"', 'fatal: not removing \'file\' recursively without -r', None))
    assert not match(Command('', '', None))


# Generated at 2022-06-12 11:40:03.944228
# Unit test for function match
def test_match():
    assert match(Command('git rm one_file',
                         'fatal: not removing \'one_file\' recursively without -r\n'))


# Generated at 2022-06-12 11:40:08.091180
# Unit test for function match
def test_match():
    assert match(Command('git rm file1',
                         'fatal: not removing \'file1\' recursively without -r\n'))
    assert not match(Command('git rm', ''))
    assert not match(Command(
        'git rm file1',
        'fatal: not removing \'file1\' recursively without -r\n'))


# Generated at 2022-06-12 11:40:12.308573
# Unit test for function match
def test_match():
    output = ("fatal: not removing 'tests/unit/exceptions.py' recursively "
              "without -r"
    )
    command = Command('git rm tests/unit/exceptions.py', output)
    assert match(command)



# Generated at 2022-06-12 11:40:20.540724
# Unit test for function match
def test_match():
    assert not match(Command("git commit -m 'fix'"))
    assert not match(Command("git rm -f --cached file1 file2", "fatal: not removing 'file1' recursively without -r\nDid you mean 'rm --cached'?"))
    assert match(Command("git rm -f --cached file1 file2", "fatal: not removing 'file1' recursively without -r\n2 files removed"))
    assert match(Command("git rm -f --cached file1 file2", "fatal: not removing 'file1' recursively without -r\n3 files removed"))


# Generated at 2022-06-12 11:40:31.114102
# Unit test for function match
def test_match():
    assert match(Command('git rm a/b/c', '', 'fatal: not removing \'/a/b/c\' recursively without -r'))
    assert not match(Command('git rm a/b/c', '', 'fatal: not removing \'/a/b/c\''))
    assert not match(Command('git rm a/b/c', '', 'fatal: not removing \'a/b/c\' recursively without -r'))
    assert not match(Command('rm a/b/c', '', 'fatal: not removing \'/a/b/c\' recursively without -r'))


# Generated at 2022-06-12 11:40:33.274635
# Unit test for function match
def test_match():
    assert match(Command('git rm x',
                'fatal: not removing \'x/x\' recursively without -r'))


# Generated at 2022-06-12 11:40:37.345750
# Unit test for function match
def test_match():
    # Matching case
    command = Command('git rm dir1',
                      'fatal: not removing \'dir1\' recursively without -r')
    assert match(command)
    # Non-matching case
    command = Command('git rm dir1', 'fatal: not removing something')
    assert not match(command)

# Generated at 2022-06-12 11:40:40.111116
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r'
                         ))
    assert not match(Command('git rm file.txt', ''))
    assert not match(Command('git rm -r folder', ''))



# Generated at 2022-06-12 11:40:42.264890
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'
    assert get_new_command('git rm -r file') == 'git rm -r file'


enabled_by_default = True

# Generated at 2022-06-12 11:40:45.222589
# Unit test for function match
def test_match():
    assert match(Command('git commit',
                         output='fatal: not removing \'docs/\' recursively without -r\n'))
    assert not match(Command('git commit',
                             output='fatal: not removing \'file\' recursively without -r\n'))

# Generated at 2022-06-12 11:40:50.237240
# Unit test for function match
def test_match():
    # Typical case
    assert match(Command('git rm file',
            "fatal: not removing 'file' recursively without -r"))
    # Not a 'git rm' command
    assert not match(Command('rm file',
                         "fatal: not removing 'file' recursively without -r"))
    
            

# Generated at 2022-06-12 11:40:51.593843
# Unit test for function match
def test_match():
    assert not match(Command('echo test', ''))


# Generated at 2022-06-12 11:40:59.024302
# Unit test for function match
def test_match():
    assert match(Command('git rm foo.txt', "")) is True
    assert match(Command('git rm -r foo.txt', "")) is False
    assert match(Command('git rm foo.txt', 'fatal: not removing \'bar\' recursively without -r')) is True
    assert match(Command('git rm foo.txt', 'fatal: not removing \'bar\' recursively without -r blabla')) is False
    assert match(Command('git rm foo.txt', 'fatal: not removing \'bar\' without -r')) is False


# Generated at 2022-06-12 11:41:02.876153
# Unit test for function match
def test_match():
    command = Command(' git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r')
    assert match(command) is True

    command = Command(' git rm file', 'fatal: not removing \'file.txt\' recursively without -r')
    assert match(command) is False

    command = Command(' git rm file.txt', '')
    assert match(command) is False



# Generated at 2022-06-12 11:41:09.296311
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f file.txt',
                      'fatal: not removing "file.txt" recursively without -r')
    assert get_new_command(command) == command.script + ' -r'

# Generated at 2022-06-12 11:41:12.164860
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command("git rm dir", "fatal: not removing 'dir' recursively without -r")
    assert (get_new_command(test_command) == "git rm -r dir")

# Generated at 2022-06-12 11:41:14.830967
# Unit test for function match
def test_match():
    assert match(Command('rm -rf docs/build', '', 'fatal: not removing \'docs/build\' recursively without -r'))
    assert not match(Command('rm -rf docs/build', '', 'help you'))


# Generated at 2022-06-12 11:41:19.325745
# Unit test for function match
def test_match():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert match(command)
    command = Command('something', 'fatal: not removing \'file\' recursively without -r')
    assert not match(command)


# Generated at 2022-06-12 11:41:23.633988
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf ./resources',
                         'fatal: not removing \'./resources\' recursively without -r'))
    assert not match(Command('git rm -rf ./resources',
                             'Deleted branch master (was c3d3e7f).'))


# Generated at 2022-06-12 11:41:26.409999
# Unit test for function match
def test_match():
    assert match(Command('git rm blah blah blah', 'fatal: not removing blah blah blah recursively without -r'))
    assert not match(Command('git rm blah blah blah', 'fatal:'))

# Generated at 2022-06-12 11:41:30.929261
# Unit test for function match
def test_match():
    assert match(Command('git rm test.txt', '', 'fatal: not removing \'test.txt\' recursively without -r'))
    assert not match(Command('git rm test.txt', '', 'fatal: not removing \'test.txt\' recursively'))
    assert not match(Command('git rm -r test.txt', '', 'fatal: not removing \'test.txt\' recursively without -r'))


# Generated at 2022-06-12 11:41:41.305153
# Unit test for function match
def test_match():
    assert match(Command("git rm 'recursive_deleted_file/file.c'", "fatal: not removing 'recursive_deleted_file/file.c' recursively without -r\n"))
    assert not match(Command("git rm 'recursive_deleted_file/file.c'", "fatal: not removing 'recursive_deleted_file/file.c' recursively without -r"))
    assert not match(Command("git rm -r 'recursive_deleted_file/file.c'", "fatal: not removing 'recursive_deleted_file/file.c' recursively without -r\n"))

# Generated at 2022-06-12 11:41:43.971718
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git remote rm origin', 'fatal: not removing \'.\' recursively without -r')) == 'git remote rm -r origin'

# Generated at 2022-06-12 11:41:52.752400
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_error_rm_failed_unsupported_case import get_new_command
    output_1 = u'fatal: not removing \'examples/one.pdf\' recursively without -r\nDid you mean \'rm -r\'?\n'
    output_2 = u'fatal: not removing \'examples/one.pdf\' recursively without -r\n'
    command_1 = 'git rm examples/one.pdf'
    command_2 = 'git rm -r examples/one.pdf'
    assert get_new_command(command_1,output_1) == command_2
    assert get_new_command(command_1,output_2) == command_1

# Generated at 2022-06-12 11:41:57.313299
# Unit test for function match
def test_match():
    assert match(Command('git rm -r *'))
    assert not match(Command('git rm -r file'))


# Generated at 2022-06-12 11:41:59.135351
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -r css/") == u"git rm -r -r css/"

# Generated at 2022-06-12 11:42:02.080748
# Unit test for function match
def test_match():
    assert match(Command('git rm not_a_dir'))
    assert not match(Command('git rm -r dir'))
    assert not match(Command('git mv file'))


# Generated at 2022-06-12 11:42:05.561075
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
        'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm file', ''))

# Generated at 2022-06-12 11:42:09.462840
# Unit test for function match
def test_match():
    assert match(Command('git rm ttt',
                         'fatal: not removing \'ttt\' recursively without -r'))
    assert not match(Command('git rm ttt',
                             'fatal: not removing \'ttt\''))


# Generated at 2022-06-12 11:42:12.099055
# Unit test for function match
def test_match():
    command = Command("git rm LICENSE", "fatal: not removing 'LICENSE' recursively without -r\n")
    assert match(command)

    command = Command("git rm LICENSE", "Nothing goes here\n")
    assert not match(command)



# Generated at 2022-06-12 11:42:15.122564
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command("git rm -f .DS_Store") == "git rm -f -r .DS_Store"
 


# Generated at 2022-06-12 11:42:19.074096
# Unit test for function match
def test_match():
    assert match(Command("git rm foo", "", "/"))
    assert not match(Command("git rm foo", "", ""))
    assert not match(Command("git foo rm bar", "", ""))
    assert not match(Command("foo rm bar", "", ""))
    
    

# Generated at 2022-06-12 11:42:23.130894
# Unit test for function match
def test_match():
    assert match(Script('git rm folder', 'fatal: not removing '
        "'folder' recursively without -r")) == True
    assert match(Script('git rm file', 'fatal: not removing '
        "'file' recursively without -r")) == True
    assert match(Script('rm file', 'fatal: not removing '
        "'file' recursively without -r")) == False



# Generated at 2022-06-12 11:42:28.824365
# Unit test for function get_new_command
def test_get_new_command():
    script_parts = ['git', 'rm', '-r', './data/view']
    output_parts = "fatal: not removing './data/view' recursively without -r"
    command = Command(script_parts, output_parts)
    new_command = get_new_command(command)
    assert new_command == 'git rm -r -r ./data/view'

# Generated at 2022-06-12 11:42:34.848353
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -f ./test') == 'git rm -f -r ./test'
    assert get_new_command('git rm test/test.txt') == 'git rm -r test/test.txt'

# Generated at 2022-06-12 11:42:36.603857
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm test',
                      stdout=u"fatal: not removing 'test' recursively without -r")
    new_command = get_new_command(command)
    assert new_command == u'git rm -r test'

# Generated at 2022-06-12 11:42:39.744494
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.fix_git_rm import get_new_command
    assert get_new_command('git rm -rf') == 'git rm -r -rf'
    assert get_new_command('git rm -r -rf') == 'git rm -r -r -rf'


# Generated at 2022-06-12 11:42:45.665482
# Unit test for function match
def test_match():
    assert match(Command(script=' rm -rf folder', output="fatal: not removing 'folder' recursively without -r"))
    assert match(Command(script=' rm -rf folder', output="fatal: not removing 'folder/' recursively without -r"))
    assert match(Command(script=' rm -rf folder', output="fatal: not removing 'folder/file1' recursively without -r"))


# Generated at 2022-06-12 11:42:52.762699
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf /tmp/1',
                         'fatal: not removing \'/tmp/1\' recursively ' +
                         'without -r\n'))
    assert not match(Command('ls', ''))
    assert not match(Command('git rm /tmp/1',
                             'fatal: not removing \'/tmp/1\' recursively ' +
                             'without -r\n'))
    assert not match(Command('git rm -rf /tmp/1',
                         'fatal: not removing \'/tmp/1\' recursively ' +
                         'without -r\n\n'))


# Generated at 2022-06-12 11:42:54.196212
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2', ''))



# Generated at 2022-06-12 11:43:01.068382
# Unit test for function match
def test_match():
    assert match(Command('git rm -r folder_with_untracked_files', '',
                         'fatal: not removing \'folder_with_untracked_files\' recursively without -r'))
    assert not match(Command('git status', '', ''))
    assert not match(Command("rm -r folder_with_untracked_files", '',
                         'fatal: not removing \'folder_with_untracked_files\' recursively without -r'))


# Generated at 2022-06-12 11:43:06.460773
# Unit test for function match
def test_match():
    test_examples = [
        # A typical match
        '''$ git rm -rf public
        fatal: not removing 'public' recursively without -r
        $ ''',
        # Another typical match
        '''$ git rm -rf public
        fatal: not removing 'public' recursively without -r
        $ '''
    ]

    for example in test_examples:
        assert match(Command(script=example))



# Generated at 2022-06-12 11:43:09.778153
# Unit test for function match
def test_match():
    assert match(Command.from_string(' git rm folder/'))
    assert match(Command.from_string(' gi rm folder/'))
    assert not match(Command.from_string('git rm'))



# Generated at 2022-06-12 11:43:14.208889
# Unit test for function match
def test_match():
    assert match(Command('git rm ', 'fatal: not removing '))
    assert match(Command('git rm ', "fatal: not removing '"))
    assert match(Command('git rm ', "' recursively without -r"))
    
    assert not match(Command('git rm ', 'fatal: not removing :'))
    assert not match(Command('git rm ', "fatal: not removing ' "))
    assert not match(Command('git rm ', "' recursively without -r "))


# Generated at 2022-06-12 11:43:19.612834
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', '/tmp/mess/mess$ ')
    new_command = get_new_command(command)
    assert new_command == u'git rm -r file'

# Generated at 2022-06-12 11:43:21.945216
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm rm.txt")
    new_command = get_new_command(command)
    assert new_command == "git rm -r rm.txt"

# Generated at 2022-06-12 11:43:31.786517
# Unit test for function match
def test_match():
	match_one = match(Command('rm file.txt', '', 'fatal: not removing \'file.txt\' recursively without -r'))
	assert match_one == True
	match_two = match(Command('git rm file.txt', '', 'fatal: not removing \'file.txt\' recursively without -r'))
	assert match_two == True
	match_three = match(Command('rm folder/', '', 'fatal: not removing \'folder/\' recursively without -r'))
	assert match_three == True
	match_four = match(Command('git rm folder/', '', 'fatal: not removing \'folder/\' recursively without -r'))
	assert match_four == True

# Generated at 2022-06-12 11:43:37.854641
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.py', "error: unable to unlink old 'hello.py'\nfatal: not removing 'hello.py' recursively without -r"))
    assert not match(Command('git rm hello.py', "error: unable to unlink old 'hello.py'\nerror: unable to unlink old 'hello.py'"))


# Generated at 2022-06-12 11:43:40.722974
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git rm dir_name'
    new_command = 'git rm -r dir_name'
    assert get_new_command({'script': script}) == new_command

# Generated at 2022-06-12 11:43:45.404252
# Unit test for function get_new_command
def test_get_new_command():
    command_test = 'git rm -r --cached app.py'
    command = Command(command_test, 'fatal: not removing \'app.py\' recursively without -r')
    assert get_new_command(command) == 'git rm -r --cached -r app.py'

# Generated at 2022-06-12 11:43:48.529031
# Unit test for function match
def test_match():
    assert match(Command('git rm',
                         'fatal: not removing \'src/\': '
                         'Directory not empty\n'
                         'fatal: not removing \'doc/\': '
                         'Directory not empty\n', 0))


# Generated at 2022-06-12 11:43:55.672655
# Unit test for function match
def test_match():
    assert match(Command('git rm file/name.txt',
                         output="fatal: not removing 'file/name.txt' recursively without -r")) == True
    assert match(Command('git rm file/name.txt',
                         output="fatal: not removing 'file/name.txt' recursively without -r")) == True
    assert match(Command('git rm file/name.txt',
                         output="fatal: not removing 'file/name.txt' without -r")) == False
    assert match(Command('ls',
                         output="fatal: not removing 'file/name.txt' recursively without -r")) == False


# Generated at 2022-06-12 11:43:59.083568
# Unit test for function get_new_command
def test_get_new_command():
    output = 'fatal: not removing \'somedir\' recursively without -r'
    command = Command('git rm somedir', output)
    assert get_new_command(command) == 'git rm -r somedir'

# Generated at 2022-06-12 11:44:04.895154
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r a b')) == 'git rm -r a b'
    assert get_new_command(Command('git rm a b')) == 'git rm -r a b'
    assert get_new_command(Command('git rm a \\\' b')) == "git rm -r a ' b"


# Generated at 2022-06-12 11:44:12.747214
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', '', 'fatal: not removing \'config\' recursively without -r')) == 'git rm -r -r'
    assert get_new_command(Command('git add testfile', '', 'fatal: not removing \'testfile\' recursively without -r')) == 'git add -r testfile'


# Generated at 2022-06-12 11:44:17.395252
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command

    assert get_new_command(Command(script='git rm -r file')) == 'git rm -r -r file'
    assert get_new_command(Command(script='git rm file')) == 'git rm -r file'



# Generated at 2022-06-12 11:44:19.312077
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test', '')
    assert 'git rm -r -r test' == get_new_command(command)

# Generated at 2022-06-12 11:44:22.886474
# Unit test for function match
def test_match():
    """
    Unit test for function match.
    """
    from thefuck.types import Command

    assert match(Command('git rm file', '')) is True
    assert match(Command('git add file', '')) is False



# Generated at 2022-06-12 11:44:25.629282
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3 file4', '',
                         'fatal: not removing \'file1\' recursively\
                         without -r\n'))
    
    

# Generated at 2022-06-12 11:44:27.624545
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r file')) == 'git rm -r file'

# Generated at 2022-06-12 11:44:29.766220
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -r test')
    assert get_new_command(command) == 'git rm -r -r test'

# Generated at 2022-06-12 11:44:33.626215
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r 'a b'",
                      "git: fatal: not removing 'a b' recursively without -r")
    assert match(command)
    new_command = get_new_command(command)
    assert 'git rm -r -r \'a b\'' == new_command

# Generated at 2022-06-12 11:44:35.656746
# Unit test for function match
def test_match():
    assert match(Command('git rm -r dir1',
                         'fatal: not removing \'dir1\' recursively without -r'))



# Generated at 2022-06-12 11:44:45.467418
# Unit test for function get_new_command
def test_get_new_command():
	import os
	from thefuck.rules.git import get_new_command
	from thefuck.types import Command

	script = u"git rm file"
	new_script = get_new_command(Command(script=script, 
											stderr=os.linesep.join(["fatal: not removing 'file' recursively without -r",
																	"Use 'git rm --cached file...' to unstage templates."]),
											script_parts=[u"git", u"rm", u"file"],
											stdout=''))

	assert new_script == "git rm -r file"

# Generated at 2022-06-12 11:44:54.129054
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2', u'fatal: not removing \'file1\' recursively without -r'))
    assert match(Command('git rm folder1', u'fatal: not removing \'folder1\' recursively without -r'))
    assert not match(Command('git rm file1 file2', u'fatal: not removing \'file1\' with -r'))
    assert not match(Command('git rm file1 file2', u'fatal: not removing \'file1\' recursively without -r file2'))
    

# Generated at 2022-06-12 11:44:58.929865
# Unit test for function get_new_command
def test_get_new_command():
    my_command = Command(u'git rm -r new/dir/1', None)
    assert get_new_command(my_command) == u'git rm -r -r new/dir/1'
    my_command = Command(u'git rm -rf new/dir/1', None)
    assert get_new_command(my_command) == u'git rm -rf new/dir/1'

# Generated at 2022-06-12 11:45:02.046694
# Unit test for function get_new_command
def test_get_new_command():
    """
    Test get_new_command for substituted git rm command 
    """
    
    command = Command('git rm folder', '')
    new_command = get_new_command(command)
    assert new_command == 'git rm -r folder'

# Generated at 2022-06-12 11:45:03.713742
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm folder')) == 'git rm -r folder'

# Generated at 2022-06-12 11:45:04.817217
# Unit test for function match

# Generated at 2022-06-12 11:45:07.845678
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-12 11:45:09.691996
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -f app.component.ts') == 'git rm -f -r app.component.ts'


# Generated at 2022-06-12 11:45:13.303524
# Unit test for function get_new_command
def test_get_new_command():
    commands = [Command('git remote rm origin'), Command('git rm -rf')]
    for command in commands:
        test_result_command = get_new_command(command)
        assert test_result_command == u'{} -r'.format(command.script)

# Generated at 2022-06-12 11:45:16.321882
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo bar') == 'git rm -r foo bar'
    assert get_new_command('git rm foo/bar') == 'git rm -r foo/bar'

# Generated at 2022-06-12 11:45:25.134066
# Unit test for function match
def test_match():
    assert match(Command(script='git status',
                 output="""
On branch master
Your branch is up-to-date with 'origin/master'.
Changes not staged for commit:
  (use "git add/rm <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

        modified:   scripts/func.sh

Untracked files:
  (use "git add <file>..." to include in what will be committed)

        fedora-18-x86_64-install-virtual-box-guest-additions/

no changes added to commit (use "git add" and/or "git commit -a")
"""))

# Generated at 2022-06-12 11:45:31.878638
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf path/to/file/', '/usr/bin/git rm -rf path/to/file/\nfatal: not removing \'path/to/file/\' recursively without -r\n')
    assert(get_new_command(command) == 'git rm -rf -r path/to/file/')


enabled_by_default = True

# Generated at 2022-06-12 11:45:33.805254
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git rm file', '')) == 'git rm -r file'


# Generated at 2022-06-12 11:45:37.688625
# Unit test for function get_new_command
def test_get_new_command():
    output = "fatal: not removing 'README.md' recursively without -r"
    command = Command('git rm README.md', output)
    assert get_new_command(command) == 'git rm -r README.md'

# Generated at 2022-06-12 11:45:39.383904
# Unit test for function match
def test_match():
    assert match(Command('git rm -f file', '', 'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-12 11:45:43.444967
# Unit test for function match
def test_match():
    assert git_support
    assert match(Command(script='git rm foo',
                         output='fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command(script='git foo', output=''))

# Generated at 2022-06-12 11:45:47.916747
# Unit test for function match
def test_match():
    assert(match(Command('git rm x')))
    assert(match(Command('git rm -rf x')))
    assert(match(Command('git rm --cached x')))
    assert(not match(Command('rm x')))
    assert(not match(Command('git add x')))


# Generated at 2022-06-12 11:45:50.239249
# Unit test for function match
def test_match():
    assert match(Command('rm -rf package', 'fatal: not removing \'package\' recursively without -r', None))


# Generated at 2022-06-12 11:45:53.754409
# Unit test for function match
def test_match():
    assert match(Command("git status", "fatal: not removing 'branches/foo' recursively without -r"))
    assert not match(Command("git status", "fatal: not removing 'branches/foo'"))
    assert not match(Command("git status", "removing 'branches/foo'"))

# Generated at 2022-06-12 11:45:56.046395
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt', ''))



# Generated at 2022-06-12 11:45:57.700287
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command("git rm hello.txt"))
# output: git rm -r hello.txt

# Generated at 2022-06-12 11:46:05.779105
# Unit test for function match
def test_match():
    assert match("git rm file1 file2 file3")
    assert not match("git status")
    assert not match("git commit")
    assert not match("git push")
    assert not match("rm file1 file2")


# Generated at 2022-06-12 11:46:08.108716
# Unit test for function match
def test_match():
    assert match(Command('git rm README.md',
			 'fatal: not removing \'README.md\' recursively without -r\n',
			 ''))

# Generated at 2022-06-12 11:46:10.997026
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm file.txt', 'fatal: not removing')) == 'git rm -r file.txt'

# Generated at 2022-06-12 11:46:15.588731
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r file.txt')) == u'git rm -r -r file.txt'
    assert get_new_command(Command('git rm -r file1.txt file2.txt')) == u'git rm -r -r file1.txt file2.txt'
    

# Generated at 2022-06-12 11:46:18.164261
# Unit test for function get_new_command
def test_get_new_command():
    command_test = Command(script='git rm dir',
                           output="fatal: not removing 'dir' recursively without -r\n")
    assert get_new_command(command_test) == 'git rm -r dir'

# Generated at 2022-06-12 11:46:20.674384
# Unit test for function get_new_command
def test_get_new_command():
    res = get_new_command( Command( script='git rm test',
                           stderr='fatal: not removing "test" recursively without -r' ))
    assert res == 'git rm -r test'

# Generated at 2022-06-12 11:46:24.411080
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm bla', 'fatal: not removing \'bla\' recursively without -r')
    assert get_new_command(command) == 'git rm -r bla'

# Generated at 2022-06-12 11:46:25.265326
# Unit test for function match
def test_match():
    assert match(Command(script='git rm -rf /tmp/test', output='fatal: not removing \'/tmp/test\' recursively without -r'))

# Generated at 2022-06-12 11:46:29.445297
# Unit test for function match
def test_match():
    assert match(Command(script=' git rm -r aaa ',
                         stderr="fatal: not removing 'aaa' recursively without -r"))
    assert not match(Command(script=' git add aaa ',
                             stderr="fatal: not removing 'aaa' recursively without -r"))


# Generated at 2022-06-12 11:46:33.909972
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'
    assert get_new_command(Command('git rm file1 file2 file3')) == 'git rm -r file1 file2 file3'
    assert get_new_command(Command('git rm file1 file2 file3', 'fatal: not removing \'file2\' recursively without -r\n', '')) == 'git rm -r file1 file2 file3'

# Generated at 2022-06-12 11:46:45.892592
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -r fred', 'fatal: not removing  recursively without -r')) == ' rm  -r fred'

# Generated at 2022-06-12 11:46:49.156883
# Unit test for function match
def test_match():
    assert_match(match, '/home/mkyong/dir1 $ git rm -r dir2')
    assert_match(match, '/home/mkyong/dir1 $ git rm -r dir2')
    assert_not_match(match, 'rm recursively without -r')


# Generated at 2022-06-12 11:46:51.416030
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))


# Generated at 2022-06-12 11:46:54.501371
# Unit test for function match
def test_match():
    assert match(Command(script='git rm pippo', output='fatal: not removing \'pippo\' recursively without -r'))
    assert not match(Command('rm', output='rm: missing file operand\nTry \'rm --help\' for more information.'))

# Generated at 2022-06-12 11:46:57.327268
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('rm untracked.txt') == 'rm -r untracked.txt'
    assert get_new_command('git rm untracked.txt') == 'git rm -r untracked.txt'

# Generated at 2022-06-12 11:47:01.784090
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing \'bar\' recursively without -r'))
    assert not match(Command('git rm foo', 'fatal: not removing \'bar\''))
    assert not match(Command('git rmdir foo', 'fatal: not removing \'bar\' recursively without -r'))

# Generated at 2022-06-12 11:47:04.398230
# Unit test for function match
def test_match():
    assert match(Command('git rm tmp',
        "fatal: not removing 'tmp' recursively without -r\n"))
    assert not match(Command('git rm tmp', ''))


# Generated at 2022-06-12 11:47:06.809610
# Unit test for function match
def test_match():
    assert match(Script('git rm stuff', '', 'fatal: not removing \'stuff\' recursively without -r', 0))


# Generated at 2022-06-12 11:47:08.458124
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('rm file')) == 'git rm -r file')


# Generated at 2022-06-12 11:47:11.238264
# Unit test for function match
def test_match():
    assert match(Command(script = 'iekdfj', 
    			output='fatal: not removing \'test/test.txt\' recursively without -r\n'))
    assert not match(Command('git status'))



# Generated at 2022-06-12 11:47:25.004640
# Unit test for function match
def test_match():
    output = 'fatal: not removing \'src/foo.py\' recursively without -r\n'
    assert match(Command('rm src/foo.py', output))


# Generated at 2022-06-12 11:47:25.990231
# Unit test for function match
def test_match():
    # How to test this?
    assert False


# Generated at 2022-06-12 11:47:29.721072
# Unit test for function match
def test_match():
    output = 'fatal: not removing \'<file>\' recursively without -r'
    assert match(Command('git rm <file>', output))
    assert not match(Command('git rm -r <file>', output))
    assert not match(Command('git help', output))

# Generated at 2022-06-12 11:47:34.637167
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) is True
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')) is False
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) is True


# Generated at 2022-06-12 11:47:42.216717
# Unit test for function match
def test_match():
    """
    Checks if the match function returns the correct boolean value
    :return:
    """
    # Test 1: simple case of rm with -r flag
    command = Command('rm -r folder1', 'fatal: not removing \'folder1\' recursively without -r')
    assert match(command)

    # Test 2: simple case of rm witout -r flag
    command = Command('rm folder1', 'fatal: not removing \'folder1\' recursively without -r')
    assert not match(command)

    # Test 3: simple case of rm with -r flag but different output
    command = Command('rm -r folder1', 'fatal: not removing \'folder1\' recursively with -r')
    assert not match(command)

    # Test 4: simple case of rm witout -r flag and different output
    command = Command

# Generated at 2022-06-12 11:47:45.086970
# Unit test for function match
def test_match():
    assert match(Command("git rm -r '\*.yml'",
    "fatal: not removing '\*.yml' recursively without -r\n", 0)) is True


# Generated at 2022-06-12 11:47:46.467504
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git rm dir1') == 'git rm -r dir1')

# Generated at 2022-06-12 11:47:47.704325
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r') == r'git rm -r'

# Generated at 2022-06-12 11:47:50.024383
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r folder', None)) == 'git rm -r -r folder'

# Generated at 2022-06-12 11:47:52.406188
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -f file",
                      "fatal: not removing 'file' recursively without -r",
                      "")
    assert get_new_command(command) == "git rm -f -r file"

# Generated at 2022-06-12 11:48:06.254275
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r',
                         ''))
    assert not match(Command('git rm',
                             'fatal: not removing \'file\' recursively without -r',
                             ''))

# Generated at 2022-06-12 11:48:11.541769
# Unit test for function match
def test_match():
    assert match(Command('git rm -f README.md', 'fatal: not removing \'README.md\' recursively without -r'))
    assert not match(Command('git rm -f README.md', ''))
    assert not match(Command('git rm -rf README.md', 'fatal: not removing \'README.md\' recursively without -r'))
    assert not match(Command('rm -rf README.md', 'fatal: not removing \'README.md\' recursively without -r'))


# Generated at 2022-06-12 11:48:13.831427
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm example",
                      "fatal: not removing 'example' recursively without -r")
    assert get_new_command(command) == "git rm -r example"

# Generated at 2022-06-12 11:48:20.508093
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('git rm -rf file',
                         stderr='fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm -f file',
                         stderr='fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm -rf file',
                         stderr='fatal: not removing \'file\' recursively with -r\n'))


# Generated at 2022-06-12 11:48:23.767261
# Unit test for function match
def test_match():
    assert match(Command(script='git rm foo',
                         output="fatal: not removing 'foo' recursively without -r"))
    assert not match(Command(script='git rm foo',
                             output="fatal: No such file or directory"))


# Generated at 2022-06-12 11:48:27.531367
# Unit test for function match
def test_match():
    # Unit test for function git_support
    assert git_support()
    assert match(Command('git add test.txt', '', '/path')) == True
    assert match(Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r', '/path')) == True


# Generated at 2022-06-12 11:48:31.150167
# Unit test for function get_new_command
def test_get_new_command():
    '''
    Test case for get_new_command function
    '''
    assert(get_new_command(Command('git rm -rf test', '', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -rf -r test')

# Generated at 2022-06-12 11:48:34.454306
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.py', '', 'fatal: not removing \'hello.py\' recursively without -r'))
    assert match(Command('git branch -d hello', '', 'error: The branch \'hello\' is not fully merged.')) is False


# Generated at 2022-06-12 11:48:36.052671
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -rf directory') == 'git rm -rf -r directory'

# Generated at 2022-06-12 11:48:39.000457
# Unit test for function match
def test_match():
    assert(match(Command(script='git remote add origin git@github.com:nviennot/toto.git',
                        output='fatal: not removing \'toto/\' recursively without -r')))



# Generated at 2022-06-12 11:49:06.103151
# Unit test for function match
def test_match():
    assert match(Command('git rm unstage.txt', 'fatal: not removing \'unstage.txt\' recursively without -r'))
    assert not match(Command('git status', ''))


# Generated at 2022-06-12 11:49:08.662486
# Unit test for function get_new_command
def test_get_new_command():
    """Test for get_new_command fun
    """
    assert get_new_command(Command('rm test.py',
                                   'fatal: not removing "test.py" recursively without -r')) == 'git rm -r test.py'

# Generated at 2022-06-12 11:49:11.045289
# Unit test for function match
def test_match():
    command = Command(script='git rm file.txt',
                      output="fatal: not removing 'file.txt' recursively without -r")
    assert match(command)



# Generated at 2022-06-12 11:49:12.426208
# Unit test for function get_new_command
def test_get_new_command():
    assert "git rm -r File.txt" == get_new_command("git rm File.txt")

# Generated at 2022-06-12 11:49:16.086419
# Unit test for function match
def test_match():
    fun = Command('git rm test_step3.txt')
    assert match(fun)
    fun = Command('git rm test_step3.txt/')
    assert not match(fun)
    fun = Command('git rm test_step3.txt/')
    assert not match(fun)


# Generated at 2022-06-12 11:49:19.048849
# Unit test for function get_new_command
def test_get_new_command():
    assert_equal(get_new_command(Command(script='git rm foobar',
                                         stderr='fatal: not removing \'foobar\' recursively without -r')),
                 'git rm -r foobar')

# Generated at 2022-06-12 11:49:24.004722
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm directory', '')) == 'git rm -r directory'
    assert get_new_command(Command('git rm file', '')) == 'git rm file'
    assert get_new_command(Command('git rm -rf directory', '')) == 'git rm -rf directory'
    assert get_new_command(Command('git rm -rf file', '')) == 'git rm -rf file'


# Generated at 2022-06-12 11:49:28.731144
# Unit test for function match
def test_match():
    # Test with rm properly implemented
    command1 = 'git rm -rf folder'
    assert match(Command(command1, '', '')) == False

    # Test with rm not correctly implemented
    command2 = "git rm -rf folder\nfatal: not removing 'folder' recursively without -r"
    assert match(Command(command2, command2, '')) == True


# Generated at 2022-06-12 11:49:31.582396
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git rm -r foo/hello.cpp'
            == get_new_command(
                Command('git rm foo/hello.cpp',
                        'fatal: not removing \'foo/hello.cpp\' recursively without -r')).script)

# Generated at 2022-06-12 11:49:33.409067
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command(Command(script='git rm f', output="fatal: not removing 'f' recursively without -r")), u'git rm -r f')