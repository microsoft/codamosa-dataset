

# Generated at 2022-06-12 11:39:45.095029
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-12 11:39:54.387935
# Unit test for function match
def test_match():
    assert match(Command('rm -rf ./*', 'fatal: not removing \'./test\' recursively without -r'))
    assert not match(Command('rm -rf ./*', 'fatal: not removing \'./test\' recursively without -r', stderr=None))
    assert not match(Command('rm -rf ./*', 'fatal: not removing \'./test\' recursively without -r', stdout=None))
    assert not match(Command('rm -rf ./*', 'fatal: removing \'./test\' recursively without -r'))
    assert not match(Command('git rm -rf ./*', 'fatal: not removing \'./test\' recursively without -r'))

# Generated at 2022-06-12 11:39:58.742502
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f test_file', '')
    assert get_new_command(command) == 'git rm -rf -f test_file'

    command = Command('git rm test_file', '')
    assert get_new_command(command) == 'git rm -r test_file'

# Generated at 2022-06-12 11:40:01.591069
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -rf foo', output='fatal: not removing \'foo\' recursively without -r')
    assert(get_new_command(command) == "git rm -rf -r foo")

# Generated at 2022-06-12 11:40:05.093863
# Unit test for function get_new_command
def test_get_new_command():
    command_test = Command('git commit -m "message"', 'fatal: not removing \'path_file\'/filename recursively without -r\n')
    assert get_new_command(command_test) == 'git commit -m "message" && git rm -r path_file/filename'

# Generated at 2022-06-12 11:40:06.780312
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git', 'git rm -r -f path')
    assert '(git)' in get_new_command(command)

# Generated at 2022-06-12 11:40:10.824176
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm .', 'fatal: not removing \'./binary_Search.py\' '
                                  'recursively without -r')
    assert get_new_command(command) == 'git rm -r ./binary_Search.py'

# Generated at 2022-06-12 11:40:13.237003
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm directory/file.txt', 'fatal: not removing \'directory/file.txt\' recursively without -r')) == 'git rm -r directory/file.txt'

# Generated at 2022-06-12 11:40:17.461422
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert (get_new_command(Command('git rm f'))
            == 'git rm -r f')
    assert (get_new_command(Command('git rm f/'))
            == 'git rm -r f/')

# Generated at 2022-06-12 11:40:21.397198
# Unit test for function get_new_command
def test_get_new_command():
    command_str = 'git rm -r file.txt'
    assert 'git rm -r -r file.txt' == (
        git.rm.get_new_command(types.Command('git rm file.txt', command_str, u'fatal: not removing \'file.txt\' recursively without -r\n')))

# Generated at 2022-06-12 11:40:25.455498
# Unit test for function get_new_command
def test_get_new_command():
    assert "git rm -r -f" == get_new_command("git rm -f")

# Generated at 2022-06-12 11:40:27.659511
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm src/resources', '')) == 'git rm -r src/resources'

# Generated at 2022-06-12 11:40:32.704666
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         stderr='fatal: not removing \'some/path/file\' recursively without -r',
            ))
    assert not match(Command('git rm file',
                             stderr='fatal: not removing \'some/path/file\' recursively without r',
                             ))

# Generated at 2022-06-12 11:40:35.000153
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command(Command('git rm something')),
                  'git rm -r something')


# Generated at 2022-06-12 11:40:36.704672
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-12 11:40:38.705118
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test.txt',
                                   'fatal: not removing \'test.txt\' recursively without -r\n')) == 'git rm -r test.txt'

# Generated at 2022-06-12 11:40:41.570691
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm yolo', 'fatal: not removing \'yolo\' recursively without -r')
    assert get_new_command(command) == 'git rm -r yolo'


# Generated at 2022-06-12 11:40:45.783862
# Unit test for function match
def test_match():
    assert match(Command('git rm file', stderr='fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', stderr='fatal: not removing \'file\''))
    assert not match(Command('git rm file', stderr='fatal: not removing \'file\' recursively without -r',
                             script='git commit'))


# Generated at 2022-06-12 11:40:54.002669
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert(get_new_command(Command('git rm -r dir')) == u'git rm dir -r')
    assert(get_new_command(Command('git rm -r dir1 dir2')) == u'git rm dir1 -r dir2 -r')
    assert(get_new_command(Command('git rm dir1 dir2')) == u'git rm dir1 dir2 -r')
    assert(get_new_command(Command('git rm -r dir1 dir2')) == u'git rm dir1 -r dir2 -r')
# End of unit test

# Generated at 2022-06-12 11:40:56.527454
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
            'fatal: not removing \'file.txt\' recursively without -r')) == True


# Generated at 2022-06-12 11:41:04.119163
# Unit test for function match
def test_match():
    # General case
    assert match(Command('git rm -r file.txt',
        'fatal: not removing \'file.txt\' recursively without -r'
        ))

    # Not a git command nor git output
    assert not match(Command('rm file.txt', 'fatal: not removing...'))

    # Not a 'rm' command
    assert not match(Command('git rm file.txt', 'fatal: not removing...'))

    # No 'recursively without -r' in output
    assert not match(Command('git rm file.txt',
                             'fatal: not removing \'file.txt\''))


# Generated at 2022-06-12 11:41:07.295048
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('''
    git rm path/to/file

fatal: not removing 'path/to/file' recursively without -r
    ''') == 'git rm -r path/to/file'

# Generated at 2022-06-12 11:41:13.352076
# Unit test for function match
def test_match():
    assert match(Command('git rm 1', '', 'fatal: not removing \'1\' recursively without -r', 1))
    assert not match(Command('git rm -r 1', '', 'fatal: not removing \'1\' recursively without -r', 1))
    assert not match(Command('ls 1', '', 'fatal: not removing \'1\' recursively without -r', 1))


# Generated at 2022-06-12 11:41:15.806740
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('ls', ''))


# Generated at 2022-06-12 11:41:20.789144
# Unit test for function match
def test_match():
    assert match(Command('rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r\n', ''))
    assert match(Command('rm -r file.txt', 'fatal: not removing \'file.txt\' recursively without -r\n', '')) is False

# Generated at 2022-06-12 11:41:30.104294
# Unit test for function get_new_command
def test_get_new_command():
    match_command = Command('git rm -r --cached pre-commit',
            r'fatal: not removing \'pre-commit\' recursively without -r\n')
    assert get_new_command(match_command) == 'git rm -r -r --cached pre-commit'

    no_match_command = Command('git rm pre-commit',
            r'fatal: not removing \'pre-commit\' recursively without -r\n')
    assert get_new_command(no_match_command) == 'git rm pre-commit'

    no_match_output = Command('git rm pre-commit',
            r'fatal: not removing \'pre-commit\' recursively without -r')
    assert get_new_command(no_match_output) == 'git rm pre-commit'


# Generated at 2022-06-12 11:41:36.333604
# Unit test for function match
def test_match():
    assert match(
        Command('git rm README.md', 'fatal: not removing \'README.md\' recursively without -r'))
    assert not match(Command('git rm README.md', ''))
    assert not match(Command('git rm -r README.md', 'fatal: not removing \'README.md\' recursively without -r'))


# Generated at 2022-06-12 11:41:38.132489
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', '', '')) == 'git rm -r -r'

# Generated at 2022-06-12 11:41:47.763185
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = u'git rm file',
                                   output = u"fatal: not removing 'file' recursively without -r")) == \
                                   u'git rm -r file'
    assert get_new_command(Command(script = u'git rm -f file',
                                   output = u"fatal: not removing 'file' recursively without -r")) == \
                                   u'git rm -f -r file'
    assert get_new_command(Command(script = u'git -f rm file',
                                   output = u"fatal: not removing 'file' recursively without -r")) == \
                                   u'git -f rm -r file'

# Generated at 2022-06-12 11:41:51.832911
# Unit test for function get_new_command
def test_get_new_command():
    # GIVEN
    command = Command('git rm -r a', 'fatal: not removing \'a\' recursively without -r')

    # WHEN
    new_command = get_new_command(command)

    # THEN
    assert(new_command == 'git rm -r -r a')

# Generated at 2022-06-12 11:42:00.136780
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git rm -f target_file'
    new_command = 'git rm -r -f target_file'
    assert get_new_command(Command(command, '')) == new_command

# Generated at 2022-06-12 11:42:06.342823
# Unit test for function match
def test_match():
    error_msg = "error: 'lemur' is not a valid \
                 revision or object name"
    assert match(Command('git rm lemur', error_msg))

    error_msg = "fatal: pathspec 'lemur/' did not match any files"
    assert not match(Command('git rm lemur/', error_msg))

    assert not match(Command('git lemur', ''))

# Generated at 2022-06-12 11:42:10.670808
# Unit test for function get_new_command
def test_get_new_command():
    output = (u'fatal: not removing \'README.md\' recursively without -r\n'
              u'Did you mean \'rm -- README.md\'?\n')
    command = Command(u'git rm README.md', output)
    assert get_new_command(command) == u'git rm -r README.md'

# Generated at 2022-06-12 11:42:13.773657
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm dir/', '', '/')
    assert get_new_command(command) == 'git rm -r dir/'
    command = Command('git rm dir', '', '/')
    assert get_new_command(command) == 'git rm -r dir'

# Generated at 2022-06-12 11:42:14.795304
# Unit test for function match
def test_match():
    command = Command('git rm file.txt')
    assert(match(command))

# Generated at 2022-06-12 11:42:16.449731
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'

# Generated at 2022-06-12 11:42:23.635031
# Unit test for function match
def test_match():
    
    # test for match
    command1 = Command('git branch -D branch1 branch2', 'fatal: not removing \'branch2\': It is not an empty branch.\n', '', 0)
    assert match(command1)

    # test for no match
    command2 = Command('git branch -D branch1 branch2', 'fatal: not removing \'branch2\': It is not an empty branch.', '', 0)
    assert not match(command2)

    # test for match
    command3 = Command('git branch -D branch1 branch2', 'fatal: not removing \'branch2\': It is not an empty branch.', '', 0)
    assert not match(command3)


# Generated at 2022-06-12 11:42:34.298015
# Unit test for function match
def test_match():
    match_no_arg= 'git rm'
    match_one_arg_file= 'git rm fileA.txt'
    match_one_arg_directory= 'git rm directory/'
    match_more_args_file= 'git rm fileA.txt fileB.txt'
    match_more_args_directory= 'git rm directory/ directory2/'

    assert not match(Command(script=match_no_arg, output=''))
    assert match(Command(script=match_one_arg_file,
                         output='fatal: not removing \'fileA.txt\' recursively without -r\n'))
    assert match(Command(script=match_one_arg_directory,
                         output='fatal: not removing \'directory/\' recursively without -r\n'))

# Generated at 2022-06-12 11:42:36.568444
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -f .git/objects/31')) == 'git rm -f -r .git/objects/31'

enabled_by_default = True

# Generated at 2022-06-12 11:42:39.708840
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -r dir', 'rm: cannot remove ‘dir’: Is a directory\n'
                                   'fatal: not removing \'isdir/\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r -r dir'

# Generated at 2022-06-12 11:42:47.462256
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-12 11:42:53.336564
# Unit test for function match
def test_match():
    assert match(Command('git rm no_path', 'fatal: not removing \'no_path\' recursively without -r'))
    assert match(Command('git rm path/to/file.txt', 'fatal: not removing \'path/to/file.txt\' recursively without -r'))
    assert not match(Command('git rm path/to/file.txt', 'fatal: not removing \'path/to/file.txt\''))
    assert not match(Command('git rm', 'fatal: not removing \'path/to/file.txt\' recursively without -r'))


# Generated at 2022-06-12 11:42:58.684401
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test/', 'fatal: not removing '
                         '\'.tox/py27\' recursively without -r'))
    assert not match(Command('git ap', 'fatal: not removing '
                             '\'.tox/py27\' recursively without -r'))
    assert not match(Command('git rm -r test/', ''))


# Generated at 2022-06-12 11:43:04.061008
# Unit test for function match
def test_match():
    assert match(Command('git rm test.py', 'fatal: not removing \'test.py\' recursively without -r'))
    assert not match(Command('git rm test.py', ''))
    assert not match(Command('git rm test.py -f', 'fatal: not removing \'test.py\' recursively without -r'))
    assert not match(Command('git rm test.py -f', ''))


# Generated at 2022-06-12 11:43:11.832596
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -r foo") == "git rm -r -r foo"
    assert get_new_command("git rm foo") == "git rm -r foo"
    assert get_new_command("git rm -r foo bar") == "git rm -r -r foo bar"
    assert get_new_command("git rm foo bar") == "git rm -r foo bar"
    assert get_new_command("git rm -r foo bar baz") == "git rm -r -r foo bar baz"
    assert get_new_command("git rm foo bar baz") == "git rm -r foo bar baz"


# Generated at 2022-06-12 11:43:13.645527
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r a/b/c', '')) == 'git rm -r a/b/c'

# Generated at 2022-06-12 11:43:23.290050
# Unit test for function match
def test_match():
    assert match(Command('git rm -f *.txt', 'fatal: not removing \'a.txt\' recursively without -r'))
    assert match(Command(' git rm -f *.txt', 'fatal: not removing \'a.txt\' recursively without -r'))
    assert match(Command('git rm -f *.txt', 'fatal: not removing \'a.txt\' recursively without -r'))
    assert match(Command('git rm -f *.txt', 'fatal: not removing \'a.txt\' recursively without -r', 'git rm -f *.txt'))
    assert not match(Command('git rm -f *.txt', 'fatal: not removing \'a.txt\' recursively without -r\nblah blah blah'))

# Generated at 2022-06-12 11:43:30.857046
# Unit test for function match
def test_match():
    assert match(Command('hg rm test', '', '', 0, None))
    assert match(Command('git rm test', '', '', 0, None))
    assert not match(Command('hg rm -r test', '', (1, '', ''), 0, None))
    assert not match(Command('git rm -r test', '', (1, '', ''), 0, None))
    assert not match(Command('git rm -rf test', '', '', 0, None))
    assert not match(Command('hg rm -rf test', '', '', 0, None))


# Generated at 2022-06-12 11:43:33.112847
# Unit test for function match
def test_match():
    assert match(Command(script = 'git rm file1.py',
                         output = "fatal: not removing 'file1.py' recursively without -r"))


# Generated at 2022-06-12 11:43:36.694040
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='rm -f $file_name')) == 'rm -rf $file_name'


enabled_by_default = True

# Generated at 2022-06-12 11:43:48.109779
# Unit test for function match
def test_match():
    assert match(Command('ls', ''))==False
    assert match(Command('git rm', ''))==False
    assert match(Command('git rm a', 'fatal: not removing \'a\''))==False
    assert match(Command('git rm a', 'fatal: not removing \'a\''))==False
    assert match(Command('git rm a', 'fatal: not removing \'a\' recursively without -r'))==True


# Generated at 2022-06-12 11:43:53.281916
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm')) == 'git -r rm'
    assert get_new_command(Command('git rm -f')) == 'git -f -r rm'
    assert get_new_command(Command('git rm -f -n')) == 'git -f -n -r rm'
    assert get_new_command(Command('git rm -n')) == 'git -n -r rm'

# Generated at 2022-06-12 11:43:57.522427
# Unit test for function get_new_command
def test_get_new_command():
    # The below command gives the output
    # "fatal: not removing 'source/' recursively without -r"
    # when trying to delete a folder named source
    command = u'git rm source/'
    output = u"fatal: not removing 'source/' recursively without -r"
    mock_command = Mock(script=command, output=output)
    assert get_new_command(mock_command) == u'git rm -r source/'


# Generated at 2022-06-12 11:43:59.495195
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r *')
    assert get_new_command(command) == 'git rm -r -r *'

# Generated at 2022-06-12 11:44:01.622034
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test')) == 'git rm -r test'



# Generated at 2022-06-12 11:44:05.128826
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git rm foo') == 'git rm -r foo')
    assert(get_new_command('git rm foo/bar') == 'git rm -r foo/bar')


# Generated at 2022-06-12 11:44:11.280765
# Unit test for function get_new_command
def test_get_new_command():
    assert match(Command('git rm -f file1 file2', u'fatal: not removing \u2018file1\u2019 recursively without -r'))
    assert not match(Command('git rm -f file1 file2', u'my error message'))
    assert get_new_command(Command('git rm -f file1 file2', u'fatal: not removing \u2018file1\u2019 recursively without -r')) == 'git rm -f -r file1 file2'

# Generated at 2022-06-12 11:44:14.204465
# Unit test for function match
def test_match():
    assert match(Command('git rm fred',
                         'fatal: not removing \'fred\' recursively without -r'))
    assert not match(Command('git rm fred',
                             'fatal: not removing \'fred\''))


# Generated at 2022-06-12 11:44:20.240736
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf', output='fatal: not removing \'.\' recursively without -r'))
    assert match(Command('git rm -r', output='fatal: not removing \'.\' recursively without -r'))
    assert not match(Command('git rm -rf', error='fatal: not removing \'.\' recursively without -r'))



# Generated at 2022-06-12 11:44:28.017515
# Unit test for function get_new_command
def test_get_new_command():
    # Matchin condition
    assert match(Command('git rm folder',
                         'fatal: not removing \'folder\' recursively without -r'))
    # Not matching
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r'))

    # Get the new command
    new_command = get_new_command(Command('git rm -f folder',
                                          'fatal: not removing \'folder\' recursively without -r'))
    assert u'git rm -f -r folder' == new_command


# vim: set expandtab:

# Generated at 2022-06-12 11:44:35.177430
# Unit test for function match
def test_match():
	command = Command(' git rm path/to/directory', ("fatal: not removing 'path/to/directory' recursively without -r\n", "", 0))
	assert match(command) == True



# Generated at 2022-06-12 11:44:38.119054
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm -r test/testfile.txt', '', '', '')) ==
           'git rm -r -r test/testfile.txt')


# Generated at 2022-06-12 11:44:41.823625
# Unit test for function match
def test_match():
    assert match(Command(' rm file',
    	"fatal: not removing 'file' recursively without -r"))
    assert not match(Command(' rm file',''))


# Generated at 2022-06-12 11:44:43.534380
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git rm file.txt') == 'git rm -r file.txt')

# Generated at 2022-06-12 11:44:46.791501
# Unit test for function match
def test_match():
    assert match(Command('git rm a',
                        stderr='fatal: not removing "a" recursively without -r'))
    assert not match(Command('git rm a',
                             stderr='fatal: not removing "b" recursively without -c'))

# Generated at 2022-06-12 11:44:51.203824
# Unit test for function get_new_command
def test_get_new_command():
    cmd_gitrm_not_recursive = 'git rm not-recursive'

    assert(get_new_command(Command(cmd_gitrm_not_recursive,
        'fatal: not removing \'not-recursive\' recursively without -r\n',
        '', 1)) == 'git rm -r not-recursive')

# Generated at 2022-06-12 11:45:00.200829
# Unit test for function match
def test_match():
    assert match(Command('git rm non_empty_dir',
        'fatal: not removing \'non_empty_dir\' recursively without -r\n',
        '', 1))
    assert not match(Command('git rm non_empty_dir',
        'note: the following paths are ignored by one of your .gitignore files:\n'
        'fatal: not removing \'non_empty_dir\' recursively without -r\n',
        '', 1))
    assert not match(Command('git rm non_empty_dir',
        'fatal: not removing \'non_empty_dir\' recursively without -r\n',
        '', 2))

# Generated at 2022-06-12 11:45:03.258051
# Unit test for function match
def test_match():
    # Test for match function
    assert match(Command('rm -rf base')) == False
    assert match(Command(u'git rm main.cpp'))
    assert match(Command('git rm -rf main.cpp')) == False


# Generated at 2022-06-12 11:45:09.577517
# Unit test for function match
def test_match():
    assert match(Command('git commit', stderr='error: unknown switch `e')) is None
    assert match(Command('git commit', stderr='usage: git commit [<options>] [--] <pathspec>...')) is None
    assert match(Command('git commit foo', stderr='error: unknown switch `e')) is None

    assert match(Command('git rm foo', stderr="fatal: not removing 'foo/bar' recursively without -r"))

# Generated at 2022-06-12 11:45:15.198965
# Unit test for function match
def test_match():
    command1 = Command("git rm README.md",
                       "fatal: not removing 'README.md' recursively"
                       " without -r\n",
                       "")
    command2 = Command("git rm README.md",
                       "fatal: not removing 'README.md' recursively without -r\n",
                       "")

    assert match(command1) is True
    assert match(command2) is False


# Generated at 2022-06-12 11:45:27.855573
# Unit test for function match
def test_match():
    command = Command('git rm -r my_folder', 'fatal: not removing \'folder\' recursively without -r')
    assert match(command)


# Generated at 2022-06-12 11:45:30.417237
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git commit' == get_new_command(Command(
        script = u'git rm somefile',
        output = u'fatal: not removing \'somefile\' recursively without -r'
        ))

# Generated at 2022-06-12 11:45:33.383284
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-12 11:45:36.538226
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm test') == 'git rm -r test'
    assert get_new_command('git rm -f test') == 'git rm -rf test'

# Generated at 2022-06-12 11:45:39.277906
# Unit test for function match
def test_match():
    assert (match(Script('git rm -r file', '', ''))
            is not None)
    assert (match(Script('git rm file', '', 'fatal: not removing'))
            is None)



# Generated at 2022-06-12 11:45:45.555851
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf file1 file2 file3',
                      'fatal: not removing \'file1\' recursively without -r\nfatal: not removing \'file2\' recursively without -r\nfatal: not removing \'file3\' recursively without -r')
    assert get_new_command(command) == 'git rm -rf -r file1 file2 file3'

# Generated at 2022-06-12 11:45:48.961094
# Unit test for function match
def test_match():
    assert match(Command('git rm *', 'fatal: not removing \'venv\' recursively without -r'))
    assert not match(Command('ls', 'fatal: not removing \'venv\' recursively without -r'))
    

# Generated at 2022-06-12 11:45:51.396701
# Unit test for function match
def test_match():
    assert match(Command(script='git rm *.pdf',
        stderr='fatal: not removing \'*.pdf\' recursively without -r\n',
        stdout=''))

# Generated at 2022-06-12 11:45:52.905977
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm not_a_directory") == "git rm -r not_a_directory"

# Generated at 2022-06-12 11:45:55.703749
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git rm src/tests/fixtures/test.txt', 'fatal: not removing \'src/tests/fixtures/test.txt\' recursively without -r\n')) == 'git rm -r src/tests/fixtures/test.txt'

# Generated at 2022-06-12 11:46:17.333412
# Unit test for function match
def test_match():
    assert match(Command('git rm blahblah', 'fatal: not removing \'blahblah\' recursively without -r'))
    assert not match(Command('git rm blahblah', ''))

# Generated at 2022-06-12 11:46:20.789045
# Unit test for function match
def test_match():
    assert match(Command('git rm test',
                         'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm test', '\''))
    assert not match(Command('git rm test', 'not removing \'test\''))
    assert not match(Command('git rm test', 'fatal: not removing \'test\' recursively without -r'))


# Generated at 2022-06-12 11:46:31.162105
# Unit test for function match
def test_match():
    output_1 = "fatal: not removing 'test/test_rules/test_match.py' recursively without -r"
    command_1 = Command("git rm test/test_rules/test_match.py", output_1)
    output_2 = "fatal: not removing 'test/test_rules/test_match.py' recursively without -r"
    command_2 = Command("rm test/test_rules/test_match.py", output_2)
    output_3 = "rm: cannot remove 'test/test_rules/test_match.py': No such file or directory"
    command_3 = Command("rm test/test_rules/test_match.py", output_3)

    assert match(command_1)
    assert not match(command_2)
    assert not match(command_3)



# Generated at 2022-06-12 11:46:33.287127
# Unit test for function get_new_command

# Generated at 2022-06-12 11:46:36.840305
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(script='git rm file',
                                    output='fatal: not removing \'file\' recursively without -r')) ==
            'git rm -r file')

# Generated at 2022-06-12 11:46:40.637664
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3', u"fatal: not removing 'file1' recursively without -r"))
    assert not match(Command('git rm file1 file2 file3', u"not removing 'file1' recursively without -r"))
    assert not match(Command('git rm file1 file2 file3', u"fatal: not removing 'file1' recursively"))


# Generated at 2022-06-12 11:46:44.952534
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command(script='git rm -rf',
                                     output='fatal: not removing '
                                     '\'non_existent_file.txt\' recursively '
                                     'without -r'))
    assert result == 'git rm -rf -r'

# Generated at 2022-06-12 11:46:48.977685
# Unit test for function match
def test_match():
    assert not match(Command(script='foobar',
                             stderr='fatal: not removing directory \'bar\' recursively without -r',
                             env={},
                             ))
    assert match(Command(script='git rm bar',
                         stderr='fatal: not removing directory \'bar\' recursively without -r',
                         env={},
                         ))

# Generated at 2022-06-12 11:46:52.609067
# Unit test for function match
def test_match():
    test1 = Command('git rm -r some_directory', 'fatal: not removing \'some_directory\' recursively without -r\n', '')
    test2 = Command('git rm some_file', '', '')
    assert match(test1)
    assert not match(test2)


# Generated at 2022-06-12 11:46:55.969629
# Unit test for function match
def test_match():
    assert match(Command('git rm -r .', 'fatal: not removing \'.\' recursively without -r'))
    assert not match(Command('git rm -r .', 'fatal: not removing \'.\' recursively without -r'))


# Generated at 2022-06-12 11:47:45.858744
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_expect_recursive import get_new_command
    command = Command('git rm README.md', 'fatal: not removing \'README.md\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r README.md'


# Generated at 2022-06-12 11:47:50.617530
# Unit test for function match
def test_match():
    assert (match(Command('git rm file',
                          stderr='fatal: not removing \'file\' recursively without -r'))
            is True)
    assert (match(Command('git rm -r dir',
                          stderr='fatal: not removing \'dir\' recursively without -r'))
            is False)


# Generated at 2022-06-12 11:47:51.957510
# Unit test for function get_new_command

# Generated at 2022-06-12 11:47:59.262818
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf *', 'fatal: not removing \'*\' recursively without -r'))
    assert match(Command('git rm path/to/file', 'fatal: not removing \'path/to/file\' recursively without -r'))
    assert not match(Command('git rm -r path/to/file', 'fatal: not removing \'path/to/file\' recursively without -r'))
    assert not match(Command('git add path/to/file', 'fatal: not removing \'path/to/file\' recursively without -r'))


# Generated at 2022-06-12 11:48:04.146760
# Unit test for function match
def test_match():
    assert(match(Command('git rm file1',
                         'fatal: not removing \'file1\' recursively without -r')))
    assert(not match(Command('git rm file2', '')))
    assert(not match(Command('ls file', '')))


# Generated at 2022-06-12 11:48:08.271044
# Unit test for function match
def test_match():
    check_match(match, "git rm -r myDir")
    check_match(match, "git rm myDir")
    check_no_match(match, "hello grep -r myDir")
    check_no_match(match, "git lol")
    check_no_match(match, "rm -r myDir")


# Generated at 2022-06-12 11:48:13.633397
# Unit test for function get_new_command
def test_get_new_command():
    #First command includes an rm command
    command = types.Command("git rm -r --cached 'escape_char_test'",
                            "fatal: not removing 'escape_char_test' recursively without -r")
    assert get_new_command(command) == "git rm -r -r --cached 'escape_char_test'"
    #Second command does not include an rm command and should return the original command
    command = types.Command("ls -l",
                            "fatal: not removing 'escape_char_test' recursively without -r")
    assert get_new_command(command) == command.script

# Generated at 2022-06-12 11:48:16.579455
# Unit test for function match
def test_match():
    assert match("git rm -r a/b/c")
    assert match("git rm -r a/b/c/")
    assert not match("git rm a/b/c")


# Generated at 2022-06-12 11:48:19.866346
# Unit test for function match
def test_match():
    assert match(Command('git rm file_name', 'fatal: not removing \'file_name\' recursively without -r'))
    assert not match(Command('git rm --cached file_name', ''))


# Generated at 2022-06-12 11:48:23.068104
# Unit test for function match
def test_match():
    """
    Unit test for function match
    """
    command = Command(script = 'git rm -f *.py', output = "fatal: not removing 'foo.py' recursively without -r")
    assert match(command)
