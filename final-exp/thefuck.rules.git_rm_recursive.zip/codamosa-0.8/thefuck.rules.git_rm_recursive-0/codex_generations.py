

# Generated at 2022-06-12 11:39:44.453673
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r file.txt' == get_new_command(Command(script = u'git rm file.txt',
                                                      stdout = u'fatal: not removing \'file.txt\' recursively without -r\n',
                                                    stderr = u''))

# Generated at 2022-06-12 11:39:46.529237
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         'fatal: not removing \'foo\' recursively without -r'))



# Generated at 2022-06-12 11:39:48.890676
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r fake') == 'git rm -r -r fake'

# Generated at 2022-06-12 11:39:52.308061
# Unit test for function match
def test_match():
    assert(match(Command('git branch branch_name', '', 'git branch branch_name\n* branch_name')))
    assert(not match(Command('git branch branch_name', '', 'git branch branch_name\n* master')))


# Generated at 2022-06-12 11:39:54.991620
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm /path/to/dir', 'fatal: not removing \'/path/to/dir\' recursively without -r')) == 'git rm -r /path/to/dir'

# Generated at 2022-06-12 11:39:56.829823
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test', '2')) == 'git rm -r test'

# Generated at 2022-06-12 11:40:02.739619
# Unit test for function match
def test_match():

    assert(match(Command(script='git status', output='fatal: not removing \'{}\' recursively without -r'.format(random.choice(['file1.txt','file2.txt','file3.txt'])))))
    assert(not match(Command(script='git status', output='fatal: not removing \'file1.txt\' recursively without -r')))
    assert(not match(Command(script='git status', output='fatal: not removing anything recursively without -r')))


# Generated at 2022-06-12 11:40:05.165393
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -r blah blah',
                      stdout="fatal: not removing 'file.txt' recursively without -r")
    output = get_new_command(command)
    assert "git rm -r -r" in output

# Generated at 2022-06-12 11:40:11.570086
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert (get_new_command(Command('git rm foo')) == 'git rm -r foo')
    assert (get_new_command(Command('git rm foo bar')) == 'git rm -r foo bar')
    assert (get_new_command(Command('git add foo')) == 'git add foo')
    assert (get_new_command(Command('git add foo bar')) == 'git add foo bar')



# Generated at 2022-06-12 11:40:19.897592
# Unit test for function match
def test_match():
    command_output = u' fatal: not removing \'../f/z/b/c/d/e/f/t\' recursively without -r\n'
    command = Command('git rm -f ../f/z/b/c/d/e/f/t', command_output)
    assert(match(command) != None)

    command_output = u'target \'../f/z/b/c/d/e/f/t\' is not a directory.\n'
    command = Command('git rm -f ../f/z/b/c/d/e/f/t', command_output)
    assert(match(command) == None)


# Generated at 2022-06-12 11:40:32.950525
# Unit test for function match
def test_match():
    assert match(Command('git rm file_name', '', 'fatal: not removing \'file_name\' recursively without -r') )

# Generated at 2022-06-12 11:40:35.226618
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-12 11:40:37.495929
# Unit test for function match
def test_match():
    command = Command('git rm -r test',
                      'fatal: not removing \'test\' recursively without -r\n')
    assert match(command)


# Generated at 2022-06-12 11:40:42.098688
# Unit test for function match
def test_match():
	assert (match(Command("git rm foo","fatal: not removing 'foo/bar' recursively without -r",None,None)))
	assert (not match(Command("git rm foo","rm: cannot remove '/Users/Jackie/Desktop/workshop-02/foo/bar': No such file or directory",None,None)))


# Generated at 2022-06-12 11:40:48.772362
# Unit test for function match
def test_match():
    example_output = """fatal: not removing '{0}' recursively without -r

Did you mean '{0}'?
Yes, delete this
No, do not delete this
"""

    # Test rm command
    cmd = Command("git rm '{0}'", example_output.format('dir'))
    assert match(cmd)

    cmd = Command("git rm '{0}'", example_output.format('file'))
    assert match(cmd)

    # Test rm --cached command
    cmd = Command("git rm --cached '{0}'", example_output.format('dir'))
    assert match(cmd)

    cmd = Command("git rm --cached '{0}'", example_output.format('file'))
    assert match(cmd)

    # Test rm --force command

# Generated at 2022-06-12 11:40:52.778939
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm -rf src/')) == 'git rm -r -rf src/'
    assert get_new_command(Command('git rm src/')) == 'git rm -r src/'


# Generated at 2022-06-12 11:40:57.123613
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', '', '')) == 'git rm -r file'
    assert get_new_command(Command('git rm fr file', '', '')) == 'git rm -r fr file'
    assert get_new_command(Command('git rm -f file', '', '')) == 'git rm -f -r file'

# Generated at 2022-06-12 11:41:00.944004
# Unit test for function match
def test_match():
    assert match(Command(script='$ git rm test.cpp',
                         output='fatal: not removing \'test.cpp\''
                                ' recursively without -r'))
    assert not match(Command(script='$ git rm test.cpp',
                             output='fatal: not removing'))



# Generated at 2022-06-12 11:41:03.465902
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(
           Command('git rm test.txt', '')) ==
           'git rm -r test.txt')

# Generated at 2022-06-12 11:41:05.164244
# Unit test for function get_new_command

# Generated at 2022-06-12 11:41:11.715404
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm myfile', 'fatal: not removing \'myfile\' recursively without -r', '/home')
    assert get_new_command(command) == 'git rm -r myfile'

# Generated at 2022-06-12 11:41:13.393237
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -f a b') == 'git rm -f -r a b'

# Generated at 2022-06-12 11:41:18.989748
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                         'fatal: not removing \'./file.txt\' recursively without -r'
                         ))
    # Doesn't match if there aren't quotes in the error message
    assert not match(Command('git rm file.txt',
                             'fatal: not removing \'./file.txt\' recursively without -r'
                             ))



# Generated at 2022-06-12 11:41:22.606397
# Unit test for function match
def test_match():
    assert match(Command('git rm path1 path2',
             'fatal: not removing \'path1\' recursively without \'-r\'', ''))
    assert not match(Command('ls', '', ''))


# Generated at 2022-06-12 11:41:25.075627
# Unit test for function match
def test_match():
    assert match(Command(script='git rm file',
                         output="error: 'file' is a directory (not removed)\nerror: failed to remove 'file'"))
    assert not match(Command())

# Generated at 2022-06-12 11:41:27.494425
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm test', output="fatal: not removing 'blah' recursively without -r")) == "git rm -r test"

# Generated at 2022-06-12 11:41:32.370589
# Unit test for function get_new_command

# Generated at 2022-06-12 11:41:36.192935
# Unit test for function match
def test_match():
    assert match(Command('git rm aaa',
                         'fatal: not removing "aaa" recursively without -r\n',
                         '/home/Alex/'))


# Generated at 2022-06-12 11:41:41.101575
# Unit test for function match
def test_match():
    command_output = '''
    fatal: not removing 'test/.git/objects/pack/tmp_pack_2GqjKD' recursively without -r
    '''
    assert match(Command('git rm test/.git/objects/pack', command_output))
    assert not match(Command('git rm test', ''))
    assert not match(Command('git rm test/.git/objects/pack', ''))


# Generated at 2022-06-12 11:41:44.718128
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r folder/file',
                      """fatal: not removing 'folder/file' recursively without -r""")

    assert get_new_command(command) == command.script.replace(' ', '  ')



# Generated at 2022-06-12 11:41:50.038979
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-12 11:41:53.607000
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r',
                         '', 1))
    assert not match(Command('git rm -r file',
                             '', '', 1))
    assert not match(Command('ls file',
                             '', '', 1))


# Generated at 2022-06-12 11:41:56.478649
# Unit test for function match
def test_match():
    assert match(Command('git add foo.txt', '', '/home/fake_user'))
    assert not match(Command('git commit -a', '', '/home/fake_user'))


# Generated at 2022-06-12 11:41:59.825399
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r test',
                                   'fatal: not removing '
                                   "'test' recursively "
                                   'without -r')) == 'git rm -r -r test'

# Generated at 2022-06-12 11:42:04.266570
# Unit test for function match
def test_match():
    assert match(Command('git rm [file]', 'fatal: not removing \'[file]\' recursively without -r'))
    assert not match(Command('git rm -r [file]', ''))
    assert not match(Command('git rm  [file]', ''))


# Generated at 2022-06-12 11:42:08.730190
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command()
    cmd.script = "git rm -f FOLDER"
    cmd.output = "fatal: not removing 'FOLDER' recursively without -r"
    assert get_new_command(cmd) == "git rm -r -f FOLDER"

# Generated at 2022-06-12 11:42:14.023852
# Unit test for function match
def test_match():
    assert match(Command('git rm 1',
        'fatal: not removing \'1\' recursively without -r',
        'git rm 1\n'))
    assert not match(Command('git rm 1',
        'fatal: not removing \'1\' recursively with -r',
        'git rm 1\n'))
    assert not match(Command('ls',
        'fatal: not removing \'1\' recursively with -r',
        'git rm 1\n'))


# Generated at 2022-06-12 11:42:21.809086
# Unit test for function match
def test_match():
    test_calls = [
        Command('git rm -r dir1', 'fatal: not removing \'dir1/dir2\' recursively without -r'),
        Command('git rm -r dir1', 'fatal: not removing \'dir1/dir2/dir3\' recursively without -r', None),
        Command('git rm -r dir1', 'fatal: not removing \'dir1/dir2/dir3/file\' recursively without -r', None),
        Command('git rm -r dir1', 'fatal: not removing \'file1\' recursively without -r')]
    for test_call in test_calls:
        assert match(test_call)



# Generated at 2022-06-12 11:42:23.919120
# Unit test for function match
def test_match():
    assert match(Command('git rm test',
                         'fatal: not removing \'test\' recursively without -r',
                         None))

# Generated at 2022-06-12 11:42:29.082980
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck import types
    check_get_new_command = get_new_command(types.Command('git rm .',
                                                          'fatal: not removing \'.\' recursively without -r\n',
                                                          None, None,
                                                          'git rm .'))
    assert check_get_new_command == 'git rm -r .'

# Generated at 2022-06-12 11:42:35.438214
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm --other-flags', '', '')) == 'git rm -r --other-flags'
    assert get_new_command(Command('git rm --other-flags', '', '')) != 'git rm --other-flags'

# Generated at 2022-06-12 11:42:37.599829
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm myfile", "fatal: not removing 'myfile' recursively without -r")) == "git rm -r myfile"


# Generated at 2022-06-12 11:42:43.728652
# Unit test for function match
def test_match():
    match1 = "git rm test.txt"
    match2 = "git rm -r test"
    match3 = "git rm -r test.txt"
    match4 = "git rm test"
    match5 = "git rm -r test/"
    match6 = "git rm -rf anothertest.txt"

    assert match(Command(script = match1, output = "fatal: not removing 'test.txt' recursively without -r"))
    assert not match(Command(script = match2, output = "fatal: not removing 'test' recursively without -r"))
    assert match(Command(script = match3, output = "fatal: not removing 'test.txt' recursively without -r"))
    assert match(Command(script = match4, output = "fatal: not removing 'test' recursively without -r"))

# Generated at 2022-06-12 11:42:48.408755
# Unit test for function get_new_command
def test_get_new_command():
    script = "git rm /path/to/file"
    output = "fatal: not removing '/path/to/file' recursively without -r"
    command = Command(script, output)
    new_command = get_new_command(command)
    assert new_command == u'git rm -r /path/to/file'

# Generated at 2022-06-12 11:42:51.271803
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test.txt', 'fatal: not removing \'test/test.txt\' recursively without -r')
    new_command = get_new_command(command)
    assert new_command == u'git rm -r test.txt'

# Generated at 2022-06-12 11:42:53.472249
# Unit test for function match
def test_match():
    command = Command('git rm -r new_dir')
    assert(match(command))


# Generated at 2022-06-12 11:42:57.674698
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')
    command2 = Command('git rm foo', '')
    assert get_new_command(command1) == 'git rm -r foo'
    assert get_new_command(command2) == 'git rm foo'

# Generated at 2022-06-12 11:43:00.559522
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('rm foo', 'fatal: not removing \'foo\''
                                   ' recursively without -r')) == 'git rm -r foo')

# Generated at 2022-06-12 11:43:03.166545
# Unit test for function match
def test_match():
    assert match(Command(' rm filename', '', 'fatal: not removing '))
    assert match(Command(' rm filename', '', 'fatal: not removing '' recursively without -r'))


# Generated at 2022-06-12 11:43:06.194872
# Unit test for function get_new_command
def test_get_new_command():
    command = Command.from_string('git rm test')
    assert get_new_command(command) == u'git rm -r test'

# Generated at 2022-06-12 11:43:12.084812
# Unit test for function match
def test_match():
    assert git_rm.match(Command('git rm filename', output='fatal: not removing \'filename\' recursively without -r\n'))
    assert not git_rm.match(Command('git rm filename', output='filename\' recursively without -r\n'))


# Generated at 2022-06-12 11:43:15.704718
# Unit test for function match
def test_match():
    assert match(Command('git branch|grep foo', stderr="fatal: not removing '.' recursively without -r"))
    assert not match(Command('git branch', stderr="fatal: not removing '.' recursively without -r"))


# Generated at 2022-06-12 11:43:19.329081
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf foo',
                         'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo',
                             'fatal: not removing \'foo\' recursively without -r'))

# Generated at 2022-06-12 11:43:20.960944
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm whatever.py')) == 'git rm -r whatever.py'

# Generated at 2022-06-12 11:43:23.290542
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm -r', "fatal: not removing 'abc' recursively without -r"))
        == "git rm -r -r 'abc'")

# Generated at 2022-06-12 11:43:29.237631
# Unit test for function match
def test_match():
    assert match(Command('git rm file', stderr='fatal: not removing '
    'fiel recursively without -r\n'))
    assert match(Command('git rm file', stderr='fatal: not removing '
    'fiel recursively without -r'))
    assert not match(Command('git rm file', stderr='fatal: not remo'))
    assert not match(Command('git rm file', stderr='foobar'))


# Generated at 2022-06-12 11:43:33.365042
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'
    assert get_new_command(Command('git rm -v -f')) == 'git rm -v -f -r'
    assert get_new_command(Command('git rm --cached')) == 'git rm --cached -r'

# Generated at 2022-06-12 11:43:41.227906
# Unit test for function get_new_command
def test_get_new_command():
    import sys
    from thefuck.types import Command

    script_parts = ['git', 'rm', 'file_name.txt']

    command = Command(script=' '.join(script_parts),
                      stdout=u'fatal: not removing \'file_name.txt\' recursively without -r',
                      stderr=None,
                      script_parts=script_parts,
                      _arguments=[])

    assert get_new_command(command) == 'git rm -r file_name.txt'

# Generated at 2022-06-12 11:43:44.291484
# Unit test for function match
def test_match():
    command = Command(script='git rm file.txt', output='fatal: not removing \'file.txt\' recursively without -r\n')
    assert match(command)



# Generated at 2022-06-12 11:43:47.396417
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
        'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo'))



# Generated at 2022-06-12 11:43:52.551795
# Unit test for function match
def test_match():
    match('git rm -f file')
    assert match('git rm file')
    assert match('git rm file1 file2 file3')
    assert not match('git rm')

# Generated at 2022-06-12 11:43:55.398724
# Unit test for function match
def test_match():
    assert match(Command(' git status',
                            "fatal: not removing 'lib' recursively without -r\n"))
    assert not match(Command(' git status',
                            'fatal: repository not found\n'))

# Generated at 2022-06-12 11:43:59.421520
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
         '/tmp/git-repo$ git rm foo\nfatal: not removing '
         '\'foo\' recursively without -r\n', 1))
    assert not match(Command('git rm bar',
         '', 1))


# Generated at 2022-06-12 11:44:03.240172
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm abc/def', 'fatal: not removing \'abc/def\' recursively without -r')) == 'git rm -r abc/def'

# Generated at 2022-06-12 11:44:06.807774
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command_test = get_new_command(Command(script='git rm -rf .git && git status',
                                                   output='fatal: not removing \'.git\' recursively without -r'))
    assert get_new_command_test == 'git rm -rf -r .git && git status'

# Generated at 2022-06-12 11:44:09.404547
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'
    assert get_new_command('git rm directory') == 'git rm -r directory'

# Generated at 2022-06-12 11:44:15.861611
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git -r rm README.md' == get_new_command(Command(script=u'git rm README.md',
                                                               stderr=u"fatal: not removing 'README.md' recursively without -r\n",
                                                               env={}))
    assert u'git rm -r README.md' == get_new_command(Command(script=u'git rm README.md',
                                                               stderr=u"fatal: not removing 'README.md' recursively without -r\n",
                                                               env={}))

# Generated at 2022-06-12 11:44:18.257172
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm a', 'fatal: not removing \'a\' recursively without -r', '')) == 'git rm -r a'

# Generated at 2022-06-12 11:44:20.790042
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git rm test', output='error: not removing test'))
    assert new_command == 'git rm -r test'

# Generated at 2022-06-12 11:44:23.516415
# Unit test for function match
def test_match():
    assert (match(Command(script='git rm file.txt',
                          output='fatal: not removing \'file.txt\' recursively without -r')) != None)



# Generated at 2022-06-12 11:44:33.672677
# Unit test for function match
def test_match():
    assert match(Command('git rm test.txt', '', '', 1, None))
    assert match(Command('git rm test.py', '', '', 1, None))
    assert match(Command('git rm test.js', '', '', 1, None))
    assert match(Command('git rm test.css', '', '', 1, None))
    assert match(Command('git rm test.html', '', '', 1, None))


# Generated at 2022-06-12 11:44:34.080300
# Unit test for function match

# Generated at 2022-06-12 11:44:40.973329
# Unit test for function match
def test_match():
    output = 'fatal: not removing \'foo/bar\' recursively without -r'
    assert match(Command('git rm foo/bar', output))
    assert match(Command('git rm foo/bar -f', output))
    assert match(Command('git rm -f foo/bar', output))
    assert not match(Command('git rm foo/bar', ''))
    assert not match(Command('git rm -f foo/bar', ''))


# Generated at 2022-06-12 11:44:43.239754
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm dir')
    assert get_new_command(command) == 'git rm -r dir'

# Generated at 2022-06-12 11:44:46.745223
# Unit test for function match
def test_match():
    assert( match( Command( script = u'git rm autobuild/libsoccer.a',
                            output = u'''fatal: not removing 'autobuild/libsoccer.a' recursively without -r

'''
                          )
                 )
          == True
        )

# Generated at 2022-06-12 11:44:55.105558
# Unit test for function match
def test_match():
    """
    This function is a string match function, so the only real test is to test
    all the possible use cases of the function, which are the following:

    1. "git rm <something>" not in command.script
    2. "git rm <something>" in command.script and no error message
    3. "git rm <something>" in command.script, error message about removing recursively and the file is a directory
    4. "git rm <something>" in command.script, error message about removing recursively and the file is a symbolic link
    """

    # Case 1
    command = Command('ls')
    assert(match(command) == None)

    # Case 2
    command = Command('git rm <something>')
    assert(match(command) == None)

    # Case 3
    command = Command('git rm <something>')


# Generated at 2022-06-12 11:44:57.942915
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command(script='git rm -rf', output="fatal: not removing 'haha' recursively without -r indicates something strange")) == 'git rm -rf -r'

# Generated at 2022-06-12 11:45:00.614547
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r', 'fatal: not removing \'/home/nishantjain\.nishantjain\' recursively without -r')
    assert get_new_command(command) == 'git rm -r'

# Generated at 2022-06-12 11:45:08.622422
# Unit test for function match
def test_match():
    assert_true(match(Command('git rm -rf foo', 'fatal: not removing \'foo\' recursively without -r\n')))
    assert_false(match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r\n')))
    assert_false(match(Command('git blah blah blah', 'fatal: not removing \'foo\' recursively without -r\n')))
    assert_false(match(Command('git rm foo; git rm bar', 'fatal: not removing \'foo\' recursively without -r\n')))


# Generated at 2022-06-12 11:45:10.565334
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm directory', '', 'fatal: not removing \'directory\' recursively without -r')) == u'git rm -r directory'

# Generated at 2022-06-12 11:45:18.167753
# Unit test for function match
def test_match():
    assert match(command=Command('git rm file'))
    assert match(command=Command('git rm -f ./tmp/file'))
    assert not match(command=Command('git commit file'))



# Generated at 2022-06-12 11:45:22.501669
# Unit test for function get_new_command
def test_get_new_command(): 
    assert get_new_command('git rm -r') == 'git rm -r -r'
    assert get_new_command('git rm -r -r') == 'git rm -r -r -r'
    assert get_new_command('git rm -r -r -r') == 'git rm -r -r -r -r'

# Generated at 2022-06-12 11:45:26.043516
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', '')) == \
        False
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r')) == \
        True


# Generated at 2022-06-12 11:45:30.255135
# Unit test for function get_new_command
def test_get_new_command():
    output = 'fatal: not removing '
    new_command = str(get_new_command(Command('rm a b', output)))
    assert('rm -r' in new_command)
    assert('a' in new_command)
    assert('b' in new_command)


# Generated at 2022-06-12 11:45:32.890578
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively with -r'))


# Generated at 2022-06-12 11:45:36.349822
# Unit test for function get_new_command
def test_get_new_command():
    command = make_command('git rm file1 file2')
    new_command = get_new_command(command)
    assert 'file1 file2' in new_command
    assert 'git rm -r' in new_command

# Generated at 2022-06-12 11:45:38.526740
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm file") == "git rm -r file"
    assert get_new_command("git rm -rf file") == "git rm -rf file"

# Generated at 2022-06-12 11:45:44.698064
# Unit test for function match
def test_match():
    err_output = ("fatal: not removing 'test/test_fucking_shell.py' recursively without -r\n")
    assert match(Command('git rm test/test_fucking_shell.py', err_output))
    assert not match(Command('git rm test/test_fucking_shell.py sup', err_output))
    assert not match(Command('git status', err_output))



# Generated at 2022-06-12 11:45:48.097570
# Unit test for function match
def test_match():
    assert match(Command('git rm test', "fatal: not removing 'test' recursively without -r"))
    assert not match(Command('git rm test', ''))
    assert not match(Command('echo test', ''))


# Generated at 2022-06-12 11:45:50.989571
# Unit test for function match
def test_match():
    assert match(Command('git rm',
                         stderr='fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git status'))


# Generated at 2022-06-12 11:45:58.495992
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    test_command = 'git rm jon'
    command = Command(test_command)
    assert get_new_command(command) == 'git rm -r jon'

# Generated at 2022-06-12 11:46:00.631709
# Unit test for function match
def test_match():
    assert match(Command('rm -r', 'fatal: not removing \'xyz\' recursively without -r'))


# Generated at 2022-06-12 11:46:10.675947
# Unit test for function match
def test_match():
    assert (match(Command('git rm method/that/works',
                          'fatal: not removing \'method/that/works\' recursively without -r'))
            is True)
    assert (match(Command('git rm ',
                          'fatal: not removing \'\' recursively without -r'))
            is True)
    assert (match(Command('git rm ',
                          'fatal: not removing recursively without -r'))
            is False)
    assert (match(Command('git rm method/that/works',
                          'fatal: not removing \'method/that/works\' recursively without -r'))
            is True)

# Generated at 2022-06-12 11:46:14.581378
# Unit test for function match
def test_match():
    assert match(Command('git rm -r aaa', 'fatal: not removing \'aaa\' recursively without -r'))
    assert not match(Command('git rm -r aaa', 'fatal: not removing \'aaa\' recursively without -r ss'))


# Generated at 2022-06-12 11:46:16.406801
# Unit test for function match
def test_match():
    assert match(Command('git rm foo'))
    assert not match(Command('git rm foo -r'))


# Generated at 2022-06-12 11:46:19.404759
# Unit test for function match
def test_match():
    assert match(Command('git rm -r random',
                         'fatal: not removing \'random\' recursively without -r',
                         '', 5))
    assert not match(Command('git rm random', '', '', 5))
    assert not match(Command('ls random', '', '', 5))


# Generated at 2022-06-12 11:46:25.724944
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command("git rm file"), "git rm -r file")
    assert_equals(get_new_command("git rm -f file"), "git rm -f -r file")
    assert_equals(get_new_command("git rm -f"), "git rm -f -r")
    assert_equals(get_new_command("git rm -rf file"), "git rm -rf file")

# Generated at 2022-06-12 11:46:30.442068
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm a b/c',output="fatal: not removing 'a' recursively without -r")) == 'git rm -r a b'
    assert get_new_command(Command(script='git rm a b', output="fatal: not removing 'a' recursively without -r")) == 'git rm -r a b'

# Generated at 2022-06-12 11:46:34.112266
# Unit test for function match
def test_match():
    assert match(Command(script='git rm App.js',
                         output="fatal: not removing 'App.js' recursively without -r"))
    assert not match(Command(script='git add App.js',
                             output="fatal: not removing 'App.js' recursively without -r"))


# Generated at 2022-06-12 11:46:38.485373
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    command_execute = Command('git rm folderfolderfolder',
                                'fatal: not removing \'folderfolderfolder\' recursively without -r\n',
                                2,
                                None)
    assert get_new_command(command_execute) == 'git rm -r folderfolderfolder'

# Generated at 2022-06-12 11:46:46.847509
# Unit test for function match
def test_match():
    assert match(Command('git rm foo/bar', "fatal: not removing 'foo/bar' recursively without -r"))
    assert not match(Command('git rm -r foo/bar', "fatal: not removing 'foo/bar' recursively without -r"))
    assert not match(Command('git rm foo/bar', ""))

# Generated at 2022-06-12 11:46:50.943807
# Unit test for function match
def test_match():
    assert match(Command('git rm -f README.md', "fatal: not removing 'README.md' recursively without -r"))
    assert not match(Command('git rm -f README.md', 'README.md'))
    assert not match(Command('git remote add origin git@github.com:nvbn/thefuck.git', 'error'))


# Generated at 2022-06-12 11:46:54.434677
# Unit test for function match
def test_match():
    assert git_support()
    assert match(command=Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r\n'))
    assert not match(command=Command('git test', ''))
    assert not match(command=Command('git rm test', ''))


# Generated at 2022-06-12 11:47:03.476472
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3',
                         'fatal: not removing \'file1\' recursively without -r',
                         '', 1))
    assert not match(Command('git rm file1 file2 file3',
                             'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git rm file1 file2 file3',
                             'fatal: not removing \'file1\' recursively without -r',
                             '', 2))
    assert not match(Command('git rm file1 file2 file3',
                             'fatal: not removing \'file1\' recursively without -r',
                             '', 1, '/some/path'))

# Generated at 2022-06-12 11:47:08.066299
# Unit test for function match
def test_match():
    f_command = Command('git rm file1.txt', 'fatal: not removing \'file1.txt\' recursively without -r')
    assert match(f_command)
    t_command = Command('git rm -r file1.txt', '')
    assert not match(t_command)
    t_command = Command('rm file1.txt', 'fatal: not removing \'file1.txt\' recursively without -r')
    assert not match(t_command)


# Generated at 2022-06-12 11:47:10.778722
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git rm -rf foo --cached') == 'git rm -rf -r foo --cached')
    assert(get_new_command('git rm [ -abc ]') == 'git rm [ -abc ]')

# Generated at 2022-06-12 11:47:14.530619
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(type('Obj', (object, ), {
        u'script': u'git rm hello',
        u'output': u"fatal: not removing 'hello' recursively without -r",
        u'script_parts': [u'git', u'rm', u'hello']
    })) == u'git rm -r hello'

# Generated at 2022-06-12 11:47:15.506372
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo', 'git rm foo')) == 'git rm -r foo'

# Generated at 2022-06-12 11:47:16.726869
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf test.txt',
        "fatal: not removing 'test.txt' recursively without -r"))



# Generated at 2022-06-12 11:47:22.411086
# Unit test for function match
def test_match():
    assert match(Command('git rm -r "directory/"', "fatal: not removing 'directory/' recursively without -r"))
    assert not match(Command('git rm "directory/"', "fatal: not removing 'directory/' recursively without -r"))
    assert not match(Command('git rm "directory/"', "fatal: not removing 'filename' recursively without -r"))
    assert not match(Command('git rm -r "filename"', "fatal: not removing 'filename' recursively without -r"))


# Generated at 2022-06-12 11:47:31.847603
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -rf dir/foo/bar.txt",
    "fatal: not removing 'dir/foo/bar.txt' recursively without -r")
    assert get_new_command(command) == "git rm -rf -r dir/foo/bar.txt"

# Generated at 2022-06-12 11:47:34.992346
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command.from_string('git rm foo')) == 'git rm -r foo'
    assert get_new_command(Command.from_string('git rm foo bar')) == 'git rm -r foo bar'

# Generated at 2022-06-12 11:47:36.429182
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r foo' in get_new_command("git rm foo")

# Generated at 2022-06-12 11:47:38.690492
# Unit test for function match
def test_match():
    assert match(Command('rm foo', ' fatal: not removing \'foo\' recursively without -r'))

# Unit test function get_new_command

# Generated at 2022-06-12 11:47:41.458573
# Unit test for function match
def test_match():
    command = Command('git rm -rf --cached a.pyc', 'fatal: not removing...', '')
    assert match(command)
    assert not match(Command('git rm -rf --cached a.pyc', '', ''))


# Generated at 2022-06-12 11:47:42.241135
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command('git rm -r *')

# Generated at 2022-06-12 11:47:44.779800
# Unit test for function match
def test_match():
    command = Command('rm Toto')
    command.output = "fatal: not removing 'Toto' recursively without -r"
    assert match(command)



# Generated at 2022-06-12 11:47:48.929847
# Unit test for function match
def test_match():
    assert match(Command(' git rm -r test' ,'fatal: not removing \'test/a.txt\' recursively without -r'))
    assert not match(Command(' git rm -r test' ,'fatal: not removing \'test/a.txt\' recursively without -r'))


# Generated at 2022-06-12 11:47:50.616954
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm folder').script == 'git rm -r folder'

# Generated at 2022-06-12 11:47:51.515510
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'

# Generated at 2022-06-12 11:47:59.348092
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file.txt','/tmp',0,'fatal: not removing \'file.txt\' recursively without -r')) == 'git rm -r file.txt'

# Generated at 2022-06-12 11:48:04.593744
# Unit test for function match
def test_match():
    assert not match(Command('git status'))
    assert not match(Command('git rm'))
    assert not match(Command('git rm foo'))
    assert match(Command('git rm foo',
                         'fatal: not removing \'foo\' recursively '
                         'without -r\n'))

# Generated at 2022-06-12 11:48:07.421867
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('to_be_removed rm -f')) == 'to_be_removed rm -f -r'
    
    

# Generated at 2022-06-12 11:48:09.756078
# Unit test for function match
def test_match():
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r',
                         '', 1))
    assert not match(Command('rm file', '', '', '', 1))

# Generated at 2022-06-12 11:48:18.027966
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\nrm: cannot remove \'file\': Is a directory'))
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\nrm: cannot remove \'file\': Is a directory\nfatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'rm: cannot remove \'file\': Is a directory'))
    assert not match(Command('git rm file', 'git rm: file: No such file or directory'))


# Generated at 2022-06-12 11:48:24.081096
# Unit test for function match
def test_match():
    assert match(Command("git rm -rf folder1/folder2", "fatal: not removing 'folder1/folder2' recursively without -r"))
    assert not match(Command("git rm -rf folder1/folder2", ""))
    assert not match(Command("git rm folder1/folder2", "fatal: not removing 'folder1/folder2' recursively without -r"))
    assert not match(Command("git rm folder1/folder2", ""))


# Generated at 2022-06-12 11:48:26.294938
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm ') == 'git rm -r '
    assert get_new_command('git rm file') == 'git rm -r file'

# Generated at 2022-06-12 11:48:32.008791
# Unit test for function match
def test_match():
    command1 = Command('git rm a', stderr="fatal: not removing 'a' recursively without -r\n")
    command2 = Command('git rm a')
    command3 = Command('git remove a', stderr="fatal: not removing 'a' recursively without -r\n")

    assert (match(command1) == True)
    assert (match(command2) == False)
    assert (match(command3) == False)


# Generated at 2022-06-12 11:48:34.517261
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = "git branch --merged | grep -v '^\\*'")
    assert get_new_command(command) == "git branch --merged | grep -rv '^\\*'"

# Generated at 2022-06-12 11:48:39.456144
# Unit test for function match
def test_match():
    assert git_support(match)(Command('git rm -rf', '', 'fatal: not removing \'-rf\' recursively without -r'))
    assert not git_support(match)(Command('git rm', '', 'fatal: not removing \'\' recursively without -r'))
    assert not git_support(match)(Command('git rm', '', 'fatal: not removing \'rm\' recursively without -r'))


# Generated at 2022-06-12 11:48:47.943566
# Unit test for function get_new_command
def test_get_new_command():
    # GIVEN
    from tests.utils import Command

    command = Command('git rm -r my/dir')

    # WHEN
    new_command = get_new_command(command)

    # THEN
    assert new_command == 'git rm -r my/dir'

# Generated at 2022-06-12 11:48:57.241418
# Unit test for function match
def test_match():
    assert match(Command('git rm something',
                         stderr='fatal: not removing \'something\' recursively without -r\n'))
    assert not match(Command(''))
    assert not match(Command('git rm',
                         stderr='fatal: not removing \'something\' recursively without -r\n'))
    assert not match(Command('git rm something',
                         stderr='fatal: not removing \'something\' recursively without -r'))
    assert not match(Command('git rm -r something',
                         stderr='fatal: not removing \'something\' recursively without -r\n'))
    assert not match(Command('git rm something',
                         stderr='fatal: not removing \'something\' recursively without -r\n',
                         output='Successfully removed'))


# Unit

# Generated at 2022-06-12 11:49:02.903322
# Unit test for function match
def test_match():
    assert match(Command('git rm foo/bar', 'fatal: not removing \'foo/bar\' recursively without -r'))
    assert match(Command('git rm -f foo/bar', 'fatal: not removing \'foo/bar\' recursively without -r'))
    assert not match(Command('git rm foo/bar', ''))
    assert not match(Command('git rm foo/bar', 'fatal: not removing \'bar\' recursively without -r'))
    

# Generated at 2022-06-12 11:49:05.961415
# Unit test for function match
def test_match():
    test_command = Command('git rm -rf *')
    test_command.output = "fatal: not removing 'file.txt' recursively without -r"
    assert match(test_command) == True


# Generated at 2022-06-12 11:49:09.337014
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r file' == get_new_command(Command('git rm -r file', '', ''))
    assert u'git status' == get_new_command(Command('git status', '', ''))
    assert u'git rm file' == get_new_command(Command('git rm file', '', ''))



# Generated at 2022-06-12 11:49:12.360408
# Unit test for function match
def test_match():
    assert match(Command('git rm file/name.txt', 'fatal: not removing \'file/name.txt\' recursively without -r'))
    assert not match(Command('git rm -r file/name.txt', ''))
    assert not match(Command('ls file/name.txt', ''))


# Generated at 2022-06-12 11:49:16.577411
# Unit test for function match
def test_match():
    command='git rm newfile.txt'
    expected=False
    assert match(create_mock_command(command, '')) == expected
    
    command='git rm newfile.txt'
    expected=True
    assert match(create_mock_command(command, 'fatal: not removing \'newfile.txt\' recursively without -r')) == expected


# Generated at 2022-06-12 11:49:22.561320
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf filename',
                         'fatal: not removing \'filename\' recursively without -r'))
    assert match(Command('git rm filename',
                         'fatal: not removing \'filename\' recursively without -r'))
    assert not match(Command('git rm -rf filename', 'fatal: not removing'))
    assert not match(Command('git rm filename', 'fatal: not removing'))



# Generated at 2022-06-12 11:49:24.363188
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', '')
    assert get_new_command(command) == u'git rm -r file'


# Generated at 2022-06-12 11:49:28.793801
# Unit test for function match
def test_match():
    print(match(Command('git rm Makefile', 'fatal: not removing \'Makefile\' recursively without -r\n')))
    assert match(Command('git rm Makefile', 'fatal: not removing \'Makefile\' recursively without -r\n'))
    assert not match(Command('git rm Makefile', ''))


# Generated at 2022-06-12 11:49:37.500690
# Unit test for function match
def test_match():
    assert match(Command('git rm', 'fatal: not removing \'jojo\': '))



# Generated at 2022-06-12 11:49:41.284795
# Unit test for function get_new_command
def test_get_new_command():
    command = u'git rm src/__init__'
    output = u"fatal: not removing 'src/__init__' recursively without -r"
    assert (git_recursive_rm.get_new_command(Command(command, output))
            == u'git rm -r src/__init__')
