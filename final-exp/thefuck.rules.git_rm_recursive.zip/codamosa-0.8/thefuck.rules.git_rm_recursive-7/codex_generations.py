

# Generated at 2022-06-12 11:39:47.875822
# Unit test for function match
def test_match():
    assert match(Command('git rm l'))
    assert not match(Command('ls'))
    assert not match(Command('git rm -r l'))
    assert not match(Command('git rm l; rm l'))


# Generated at 2022-06-12 11:39:50.348812
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r dir', '')
    assert get_new_command(command) == u'git rm -r -r dir'

# Generated at 2022-06-12 11:39:53.114928
# Unit test for function get_new_command
def test_get_new_command():
    output = "fatal: not removing 'subdir' recursively without -r"
    command = Command('git rm subdir', output)
    assert get_new_command(command) == 'git rm -r subdir'

# Generated at 2022-06-12 11:39:57.087921
# Unit test for function match
def test_match():
    assert match(Command(script='git rm foo',
                         output='fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command(script='git rm foo',
                             output='fatal: not removing \'foo\''))
    assert not match(Command(script='git clone',
                             output='fatal: not removing \'foo\' recursively without -r'))


# Generated at 2022-06-12 11:40:01.124333
# Unit test for function match
def test_match():
    assert match(Command('git rm -f', 'fatal: not removing \'k8s.io\' recursively without -r'))
    assert not match(Command('git rm -f', 'fatal: not removing \'k8s.io\' recursively with -r'))


# Generated at 2022-06-12 11:40:04.095721
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file.txt', 'fatal: not removing ' \
        '\'file.txt\' recursively without -r') == 'git rm -r file.txt'
    assert get_new_command('git rm -r file.txt', 'fatal: not removing ' \
        '\'file.txt\' recursively without -r') == 'git rm -r file.txt'

# Generated at 2022-06-12 11:40:05.409593
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('git rm rf') == 'git rm -r rf'


# Generated at 2022-06-12 11:40:07.787120
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', "fatal: not removing 'foo' recursively without -r", None))
    assert not match(Command('git rm foo', "foo", None))

# Generated at 2022-06-12 11:40:14.222998
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm file1 file2',
                                   output="fatal: not removing 'file1' recursively without -r",
                                   stderr='error')) == u'git rm -r file1 file2'
    assert get_new_command(Command(script='git rm -r file1 file2',
                                   output="fatal: not removing 'file1' recursively without -r",
                                   stderr='error')) != u'git rm -r file1 file2'

# Generated at 2022-06-12 11:40:19.028112
# Unit test for function get_new_command
def test_get_new_command():
    a = type('obj', (object,), {
        'script': 'git rm -r test.txt',
        'script_parts': ['git', 'rm', '-r', 'test.txt']
    })()
    assert get_new_command(a) == 'git rm -r -r test.txt'



# Generated at 2022-06-12 11:40:25.862619
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(script='git rm impossible', output='fatal: not removing \'impossible\' recursively without -r') ==
           'git -r rm impossible')
    assert(get_new_command(script='git add impossible', output='fatal: not removing \'impossible\' recursively without -r') ==
           'git add impossible')

# Generated at 2022-06-12 11:40:27.701809
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file.txt') == 'git rm -r file.txt'

# Generated at 2022-06-12 11:40:31.533401
# Unit test for function get_new_command
def test_get_new_command():
    command = Command()
    command.script = u"git rm foo"
    command.output = u"fatal: not removing 'foo' recursively without -r"
    assert "git rm -r foo" == get_new_command(command)

# Generated at 2022-06-12 11:40:33.960353
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm letter', "fatal: not removing 'letter' recursively without -r")) == "git rm -r letter"

# Generated at 2022-06-12 11:40:37.978367
# Unit test for function match
def test_match():
    assert(match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')))
    assert(not match(Command('git rm file', 'test test')))
    assert(not match(Command(' rm file', 'fatal: not removing \'file\' recursively without -r')))


# Generated at 2022-06-12 11:40:46.658230
# Unit test for function match
def test_match():
    # Correct function match
    command = Command(' git status', '','')
    assert match(command) is None
    command = Command('git rm -r ', '', '')
    assert match(command) is None
    command = Command('git rm -r  test', '', '')
    assert match(command) is None
    command_output = "fatal: not removing 'test' recursively without -r\n"
    command = Command('git rm -r  test', '', command_output)
    assert match(command) is True
    command_output += 'git rm: use \'git rm --cached <file>\' to unstage\n'
    command = Command('git rm -r  test', '', command_output)
    assert match(command) is True

# Generated at 2022-06-12 11:40:55.942291
# Unit test for function match
def test_match():
    # Test 1: rm with -r
    command = Command('git rm -r file.py', '', None)
    assert(match(command) == False)
    # Test 2: Test non-recursive rm
    command = Command('git rm file.py',
                      "fatal: not removing 'file.py' recursively "
                      "without -r",
                      None)
    assert(match(command))
    # Test 3: Test non-recursive rm with -d
    command = Command('git rm -d file.py',
                      "fatal: not removing 'file.py' recursively "
                      "without -r",
                      None)
    assert(match(command) == False)


# Generated at 2022-06-12 11:41:01.823030
# Unit test for function match
def test_match():
    command = Command('git rm test/test_file.txt', 'error: pathspec \'test/test_file.txt\' did not match any file(s) known to git.\nfatal: not removing \'test/test_file.txt\' recursively without -r')
    assert(match(command) == True)

    command = Command('git rm test/', 'error: pathspec \'test/\' did not match any file(s) known to git.\nfatal: not removing \'test/\' recursively without -r')
    assert(match(command) == True)

    command = Command('git rm test/test_file.txt', 'fatal: not removing \'test/\' recursively without -r')
    assert(match(command) == False)


# Generated at 2022-06-12 11:41:11.851422
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm filename", "fatal: not removing 'filename' recursively without -r")) == "git rm -r filename"
    assert get_new_command(Command("git rm -r filename", "fatal: not removing 'filename' recursively without -r")) == "git rm -r -r filename"
    assert get_new_command(Command("git rm -rf filename", "fatal: not removing 'filename' recursively without -r")) == "git rm -r -rf filename"
    assert get_new_command(Command("git rm --cached filename", "fatal: not removing 'filename' recursively without -r")) == "git rm -r --cached filename"


# Generated at 2022-06-12 11:41:14.059005
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt'))
    assert not match(Command('cd .git'))
    assert not match(Command('git add file.txt'))


# Generated at 2022-06-12 11:41:20.848948
# Unit test for function match
def test_match():
    assert_true(match(Command("git rm test", "fatal: not removing 'test' recursively without -r", "path"))
                and match(Command("git rm -r test", "fatal: not removing 'test' recursively without -r", "path")))



# Generated at 2022-06-12 11:41:25.074274
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git pull', ''))
    assert match(Command('git rm -n foo', "fatal: not removing 'foo' recursively without -r"))



# Generated at 2022-06-12 11:41:28.152409
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm file',
                      stderr='fatal: not removing \'file\' recursively without -r',
                      env={})
    get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-12 11:41:30.169478
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm FILE', 'fatal: not removing \'File\' recursively without -r')
    assert(get_new_command(command) == 'git rm -r FILE')

# Generated at 2022-06-12 11:41:33.234984
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git rm abc',
                                    'fatal: not removing \'abc\' recursively without -r'))
            == 'git rm -r abc')

# Generated at 2022-06-12 11:41:42.747725
# Unit test for function match
def test_match():
    assert match(Command('rm -r', 'fatal: not removing \'file\' recursively without -r', ''))
    assert match(Command('git rm ', 'fatal: not removing \'file\' recursively without -r', ''))
    assert match(Command('rm ', 'fatal: not removing \'file\' recursively without -r', ''))
    assert not match(Command('rm -r', 'fatal: not removing \'file\' recursively without -rf', ''))
    assert not match(Command('rm -rf', 'fatal: not removing \'file\' recursively without -r', ''))
    assert not match(Command('rm', 'fatal: not removing \'file\' recursively without -r', ''))

# Generated at 2022-06-12 11:41:48.548487
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('rm file', 'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-12 11:41:51.562259
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm /tmp/',
                                   'fatal: not removing \'/tmp/\' recursively without -r'))
           == "git rm -r /tmp/")

# Generated at 2022-06-12 11:41:58.100947
# Unit test for function match
def test_match():
    test_commands = [
            u"git rm -r --cached directory",
            u"git rm   file.txt",
            u"git rm   --cached file.txt",
            u"git rm   --cached file.txt -r ",
            u"git rm   -r file.txt -r ",
            u"git rm   -r file.txt "]
    index = 0
    while index < len(test_commands):
        assert match(Command(script=test_commands[index],
                output='fatal: not removing')
            ) == True
        index = index + 1


# Generated at 2022-06-12 11:42:01.460554
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = "git rm -r *",
                      output = "fatal: not removing 'A/B/C' recursively without -r")
    assert get_new_command(command) == "git rm -r -r *"

# Generated at 2022-06-12 11:42:07.955578
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r a', 'fatal: not removing \'a\' recursively without -r')
    assert get_new_command(command) == u'git rm -r a'

# Generated at 2022-06-12 11:42:09.463903
# Unit test for function match
def test_match():
    command = Command(script='git rm bitbucket.py')
    assert match(command)


# Generated at 2022-06-12 11:42:14.564501
# Unit test for function match
def test_match():
    assert match(Command('git rm test',
                         'fatal: not removing \'test\' recursively without -r'))
    assert match(Command('git rm test', 'fatal: not removing \'test\' recursively without -r', '', 0))
    assert not match(Command('git rm test', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-12 11:42:18.809053
# Unit test for function get_new_command
def test_get_new_command():
    cmd1 = 'git rm fix/my-file'
    cmd2 = 'git rm -r fix/my-file'

    command = Command(cmd1, "fatal: not removing 'fix/my-file' recursively without -r")
    new_command = get_new_command(command)
    assert new_command == cmd2

# Generated at 2022-06-12 11:42:22.668013
# Unit test for function match
def test_match():
    #  with open('test/test_rm.txt') as f:
    #      output = f.read()
    output = """
Agreeing to the Xcode/iOS license requires admin privileges, please run “sudo xcodebuild -license” and then retry this command.
"""
    command = Command('git rm test', output)
    assert match(command)



# Generated at 2022-06-12 11:42:24.399535
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f README', '')) == 'git rm -f -r README'

# Generated at 2022-06-12 11:42:26.219955
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('rm -rf something') == 'rm -rf -r something'

# Generated at 2022-06-12 11:42:29.830413
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git rm -r file1 file2 file3'
    newCommand = 'git rm -r file1 file2 file3'
    assert(get_new_command(Command(command)) == newCommand)



# Generated at 2022-06-12 11:42:31.747463
# Unit test for function match
def test_match():
    assert match(Command('git stash',
                         'fatal: not removing \'file1\' recursively without -r',
                         ''))



# Generated at 2022-06-12 11:42:36.854260
# Unit test for function match
def test_match():
    assert match(Command('git rm foo/bar'))
    assert match(Command('git rm foo/bar', 'fatal: not removing \'foo/bar\' recursively without -r'))
    assert not match(Command('git rm foo/bar', 'fatal: not removing \'foo/bar\' recursively without -r', False))
    assert not match(Command('git rm foo/bar'))


# Generated at 2022-06-12 11:42:46.854196
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm a b')) == 'git rm -r a b'
    assert get_new_command(Command('git remote rm a')) == 'git remote rm  a'
    assert get_new_command(Command('git branch -d a b')) == 'git branch -d a b'
    assert get_new_command(Command('git branch -D a b')) == 'git branch -D a b'
    assert get_new_command(Command('git branch --delete a b')) == 'git branch --delete a b'

# Generated at 2022-06-12 11:42:50.290789
# Unit test for function match
def test_match():
    assert match(Command('git add foo bar baz',
                         'fatal: not removing \'foo\' recursively without -r',
                         '', 1))
    assert not match(Command('git rm foo', '', '', 1))

# Generated at 2022-06-12 11:42:55.410631
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -f src/tests.py",
                      "fatal: not removing 'src/tests.py' recursively without -r")
    new_command = get_new_command(command)
    assert new_command == "git rm -f -r src/tests.py"

# Generated at 2022-06-12 11:43:00.698968
# Unit test for function match
def test_match():
    assert(match(Command(script='git rm -f',
        output='fatal: not removing \'<file>\' recursively without -r'))
        == True)
    assert(match(Command(script='git rm -f <file>',
        output='fatal: not removing \'<file>\' recursively without -r'))
        == False)
    

# Generated at 2022-06-12 11:43:04.653777
# Unit test for function match
def test_match():
    # test the match function
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\''))
    assert not match(Command('ls file', 'fatal: not removing \'file\' recursively without -r'))



# Generated at 2022-06-12 11:43:06.582720
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm dirname', 'fatal: not removing '), None, None) == 'git rm -r dirname'

# Generated at 2022-06-12 11:43:09.907949
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert (get_new_command(Command('git rm -rf test',
                                    "fatal: not removing 'test' recursively without -r",
                                    u'')) == 'git rm -rf -r test')

# Generated at 2022-06-12 11:43:12.467143
# Unit test for function match
def test_match():
    new_script = "git rm -rf test"
    output = 'fatal: not removing \'test\' recursively without -r'
    assert match(Command(new_script, output))


# Generated at 2022-06-12 11:43:15.826437
# Unit test for function match
def test_match():
    assert match(Command('git rm a/b/c', ''))
    assert not match(Command('git rm -r a/b/c', ''))
    assert not match(Command('rm a/b/c', ''))


# Generated at 2022-06-12 11:43:21.621512
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert match(Command('git rm file', 'fatal: not removing \'../file\' recursively without -r'))
    assert match(Command('git rm file', "fatal: not removing 'file' recursively without -r"))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))

# Generated at 2022-06-12 11:43:29.853903
# Unit test for function match
def test_match():
    assert not match(Command('pwd', ''))
    assert match(Command('git rm foo', stderr='fatal: not removing \'foo\' recursively without -r'))


# Generated at 2022-06-12 11:43:32.349659
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm a b', 'fatal: not removing \'a\' recursively without -r')) == 'git rm -r a b'

# Generated at 2022-06-12 11:43:35.402462
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm text')) == 'git rm -r text'


# Generated at 2022-06-12 11:43:42.300447
# Unit test for function match
def test_match():
    assert match(Command('git status', '', '', '')) is None
    assert match(Command('git add', '', '', '')) is None
    assert match(Command('git rm', '', '', '')) is None
    assert match(Command('git rm file', '', '', '')) is None
    assert match(Command('git rm \'test\'', '', '', '')) is None
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r\n', ''))


# Generated at 2022-06-12 11:43:46.661231
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo bar', 'fatal: not removing \'foo bar\' recursively without -r'))


# Generated at 2022-06-12 11:43:50.326722
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo', 'fatal: not removing '
                                   "'foo' recursively without -r",
                                   '', 1, False)) == 'git rm -r foo'



# Generated at 2022-06-12 11:43:52.552659
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm a/b', 'fatal: not removing ')) == u'git rm -r a/b')

# Generated at 2022-06-12 11:43:54.550653
# Unit test for function match
def test_match():
    assert match(Command('$ git rm -r dir', 'fatal: not removing \'dir\' recursively without -r\n'))


# Generated at 2022-06-12 11:43:57.664148
# Unit test for function get_new_command
def test_get_new_command():
    assert git.get_new_command(Command('rm test.txt',
        'fatal: not removing \'test.txt\' recursively without -r\n')) == 'git rm -r test.txt'


# Generated at 2022-06-12 11:44:00.731305
# Unit test for function match
def test_match():
    assert match(Command('git rm toto', 'fatal: not removing \'toto\' recursively without -r'))
    assert not match(Command('git rm toto', ''))
    assert not match(Command('ls -l', ''))


# Generated at 2022-06-12 11:44:14.998632
# Unit test for function match
def test_match():
    F = True
    T = True
    assert F == match(
        Command(script='rm README.md',
                stderr="fatal: not removing 'README.md' recursively without -r",
                output=''))
    assert T == match(
        Command(script='git rm README.md',
                stderr="fatal: not removing 'README.md' recursively without -r",
                output=''))
    assert F == match(
        Command(script='git rm README.md',
                stderr="fatal: not removing 'README.md' recursively without -r",
                output=''))

# Generated at 2022-06-12 11:44:20.397304
# Unit test for function match
def test_match():
    assert match(Command('git rm file', u"fatal: not removing 'file' recursively without -r", ''))
    assert not match(Command('git rm file', u"fatal: not removing 'file' recursively with -r", ''))
    assert not match(Command('git rm file', u"fatal: not removing 'recursively without -r'", ''))


# Generated at 2022-06-12 11:44:23.967548
# Unit test for function match
def test_match():
    # failing test
    assert not match(Command('git rm dir'))

    # passing test
    assert match(Command('git rm dir',
                         'fatal: not removing \'dir\' recursively without -r\n',
                         1))

# Generated at 2022-06-12 11:44:26.678080
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm file',
                                   'fatal: not removing \'file\' recursively '
                                   'without -r\n')) == 'git rm -r file')

# Generated at 2022-06-12 11:44:29.723021
# Unit test for function get_new_command
def test_get_new_command():
	assert git_rm_recursive.get_new_command(Command('git rm -r', '', 'fatal: not removing \'build/\': Directory not empty', '', '')) == 'git rm -r -r'

# Generated at 2022-06-12 11:44:31.452747
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git rm myfolder/') == 'git rm -r myfolder/')

# Generated at 2022-06-12 11:44:33.375566
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', 'fatal: not removing ...')) == 'git rm -r file'

# Generated at 2022-06-12 11:44:35.570818
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script_parts': ['git', 'rm', 'folder_name'], 'output': "fatal: not removing 'folder_name' recursively without -r"})
    assert get_new_command(command)=='git rm -r folder_name'

# Generated at 2022-06-12 11:44:39.888817
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         output="fatal: not removing 'file' recursively without -r"))
    assert not match(Command('git rm -r file',
                             output="fatal: not removing 'file' recursively without -r"))
    assert not match(Command('ls'))

# Generated at 2022-06-12 11:44:43.613245
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(' rm a ', '', '', 'fatal: not removing \'a\' recursively without -r')
    assert get_new_command(command) == 'git rm -r a'

# Generated at 2022-06-12 11:44:56.472218
# Unit test for function match
def test_match():
    assert match(Command('git rm a b c',
                         'fatal: not removing \'a\' recursively without -r'))
    assert not match(Command('git rm a b c', ''))


# Generated at 2022-06-12 11:45:01.146374
# Unit test for function match
def test_match():
    assert match(Command('git rmdir file'))
    assert match(Command('git rmdir file.txt'))
    assert match(Command('git rmdir .'))
    assert not match(Command('git rm -r file'))
    assert not match(Command('git rm file'))
    assert match(Command('git rm file', '\nfatal: not removing \'file\' recursively without -r\n'))


# Generated at 2022-06-12 11:45:04.769840
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf blah blah', 'error')) == 'git rm -r -rf blah blah'
    assert get_new_command(Command('git rm -f blah blah', 'error')) == 'git rm -r -f blah blah'

# Generated at 2022-06-12 11:45:12.095699
# Unit test for function match
def test_match():
    assert match(Command('git rm --cached some_file.py',
                         'fatal: not removing \'some_file.py\' recursively without -r\n'))
    assert not match(Command('git rm some_file.py',
                             'fatal: not removing \'some_file.py\' recursively without -r\n'))
    assert not match(Command('git rm some_file.py',
                             'fatal: not removing \'some_file.py\' recursively without -r\n\n'
                             'If you want to remove this project, '
                             'please run \'npm uninstall <project name>\' manually.\n'))



# Generated at 2022-06-12 11:45:17.665507
# Unit test for function match
def test_match():
    assert match(Command('rm -rf file1 file2',
                         'fatal: not removing \'file1\' recursively without -r'))
    assert match(Command('rm -rf file1',
                         'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('rm -rf file1 file2',
                         'fatal: not removing \'file1\' recursively with -r'))


# Generated at 2022-06-12 11:45:23.534095
# Unit test for function match
def test_match():
    assert match(Command('git rm a/b/c', output='fatal: not removing \'a/b/c\' recursively without -r'))
    assert not match(Command('git rm a/b/c', output='fatal: not removing \'a/b/c\' recursively without -r'))
    assert not match(Command('git rm a/b/c', output='Error: not removing \'a/b/c\' recursively without -r'))


# Generated at 2022-06-12 11:45:25.521749
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-12 11:45:29.806978
# Unit test for function match
def test_match():
    assert match(create_command('rm -rf TODO.old',
        'fatal: not removing \'TODO.old\' recursively without -r'))
    assert not match(create_command('rm -rf TODO.old',
        'fatal: not removing TODO.old'))


# Generated at 2022-06-12 11:45:31.658454
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git branch | xclip -selection clipboard')) == 'git branch -r | xclip -selection clipboard'

# Generated at 2022-06-12 11:45:33.964363
# Unit test for function match
def test_match():
    command = Command('git rm unicorns', 'fatal: not removing \'unicorns\' recursively without -r')
    assert match(command)


# Generated at 2022-06-12 11:45:45.873989
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'


# Generated at 2022-06-12 11:45:48.280478
# Unit test for function match
def test_match():
	command = 'git rm -f foo'
	assert match(command)
	command = 'git rm -f bar'
	assert not match(command)


# Generated at 2022-06-12 11:45:50.564307
# Unit test for function match
def test_match():
    assert(match(Command('git rm -rf abc', '/home/user/PROJECT', '', '')) == \
           True)


# Generated at 2022-06-12 11:45:58.887871
# Unit test for function match
def test_match():
    assert(match('git push') is False)
    assert(match('git rm adslfkj') is False)
    assert(match('git rm adslfkj sadf') is False)
    assert(match('git rm adslfkj adflfkjasdfljdasf')
            and "fatal: not removing 'adslfkj'" in "fatal: not removing 'adslfkj' recursively without -r")
    assert(match('git rm adslfkj adflfkjasdfljdasf')
            and "fatal: not removing 'adflfkjasdfljdasf'" in "fatal: not removing 'adslfkj' recursively without -r")

# Generated at 2022-06-12 11:46:02.600285
# Unit test for function match
def test_match():
    assert match(Command('git rm -f file1 file2',
                         'fatal: not removing \'file1\' recursively without -r\n'))
    assert not match(Command('git rm -f file1 file2', 'file1: No such file or directory'))


# Generated at 2022-06-12 11:46:04.334639
# Unit test for function match
def test_match():
    assert match(u'git rm foo')
    assert match(u'git rm bar')


# Generated at 2022-06-12 11:46:05.646601
# Unit test for function match
def test_match():
    assert match(Command('git rm file'))


# Generated at 2022-06-12 11:46:09.539934
# Unit test for function match
def test_match():
    assert match(Command('git rm hello', '', output='fatal: not removing hello recursively without -r\n'))
    assert not match(Command('git rm hello', '', output=''))
    assert not match(Command('git rm hello', '', output='hello world\n'))


# Generated at 2022-06-12 11:46:12.897191
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r foo', 'fatal: not removing \'foo\' recursively without -r')
    assert get_new_command(command) == u'git rm -r -r foo'

# Generated at 2022-06-12 11:46:15.352022
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-12 11:46:37.485195
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r aa', 'fatal: not removing ')) == 'git rm -r -r aa'

# Generated at 2022-06-12 11:46:38.980855
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r test/file', '')) == 'git rm -r -r test/file'

# Generated at 2022-06-12 11:46:43.076039
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', 'rm', '-r', 'test_dir']
    command.script_parts = command_parts
    command.script = ' '.join(command_parts)
    assert 'git rm -r -r test_dir' == get_new_command(command)

# Generated at 2022-06-12 11:46:49.760573
# Unit test for function get_new_command
def test_get_new_command():
    # Testing for typo in command
    assert 'git push origin master' == get_new_command('git porush origin master')
    assert 'git push origin master' == get_new_command('git porsh origin master')
    assert 'git push origin master' == get_new_command('git posh origin master')
    assert 'git push origin master' == get_new_command('git pus origin master')
    assert 'git push origin master' == get_new_command('git puh origin master')
    assert 'git push origin master' == get_new_command('git psh origin master')
    assert 'git rm -rf' == get_new_command('git rm -rf')
    assert 'git rm' == get_new_command('git rm')
    assert 'git rm -r' == get_new_command('git rm')

# Generated at 2022-06-12 11:46:53.292754
# Unit test for function match
def test_match():
    assert match(Command('git rm directory',
                         stderr='fatal: not removing \'directory\' recursively without -r\n'))
    assert not match(Command('git rm directory/',
                         stderr='fatal: not removing \'directory/\' recursively without -r\n'))


# Generated at 2022-06-12 11:46:55.414790
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command.from_string('git rm file1 file2 file3 file4')) == 'git rm -r file1 file2 file3 file4'

# Generated at 2022-06-12 11:47:02.559093
# Unit test for function match
def test_match():
    assert match(Command('git bad command'))
    assert match(Command('git rm bad command'))
    assert match(Command('git rm file',
                         "fatal: not removing 'file' recursively without -r"))
    assert not match(Command('git rm bad command', "command not found"))
    assert not match(Command('git rm bad command', "fatal: bad command"))
    assert not match(Command('git rm bad command', "fatal: not bad command"))
    assert not match(Command('git rm bad command',
                             "fatal: not removing bad command without -r"))


# Generated at 2022-06-12 11:47:09.311461
# Unit test for function match
def test_match():
    assert match(Command( script='git rm' ))
    assert match(Command( script='git rm -f' ))
    assert match(Command( script='git rm -r' ))
    assert match(Command( script='git rm -rf' ))
    assert match(Command( script='git rm -r foo' ))
    assert match(Command( script='git rm -rf foo' ))
    assert match(Command( script='git rm -r foo bar' ))
    assert match(Command( script='git rm -rf foo bar' ))
    assert not match(Command( script='git rm -r foo bar',
                               output="fatal: not removing 'foo' recursively without -r"))
    assert not match(Command( script='not a git rm command' ))

# Generated at 2022-06-12 11:47:10.534458
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm abc') == 'git rm -r abc'

# Generated at 2022-06-12 11:47:18.833329
# Unit test for function match
def test_match():
    assert match(Command('git rm foo/bar/foobar',
                          "fatal: not removing 'foo/bar/foobar' recursively without -r"))
    assert not match(Command('git rm foo/bar/foobar', ''))
    assert not match(Command('git x foo/bar/foobar',
                               "fatal: not removing 'foo/bar/foobar' recursively without -r"))
    assert not match(Command('git rm foo/bar/foobar',
                               "fatal: not killing 'foo/bar/foobar' recursively without -r"))
    assert not match(Command('git rm foo/bar/foobar',
                               "fatal: not removing 'foo/bar/foobar' recursively without -r"))

# Generated at 2022-06-12 11:47:45.997354
# Unit test for function match
def test_match():
    assert match(Command('git rm trashdir',
                         r"fatal: not removing 'trashdir' recursively without -r"))
    assert not match(Command('git branch -r', ''))


# Generated at 2022-06-12 11:47:49.294867
# Unit test for function match
def test_match():
    # tests for function match
    assert match(Command('git rm -r'))
    assert match(Command('git rm -a'))
    assert match(Command('git rm .'))


# Generated at 2022-06-12 11:47:52.143057
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm config/admin.conf', "/home/benoit",
                                   "fatal: not removing 'config/admin.conf' recursively without -r\n")) == u'git rm config/admin.conf'

# Generated at 2022-06-12 11:47:57.755617
# Unit test for function match
def test_match():
    assert match(Command('git qwe rm rwe', '', 'fatal: not removing \'rwe\' recursively without -r\nDid you mean this?\n\trm -r rwe\n'))
    assert match(Command('git qwe rm rwe', '', 'fatal: not removing \'rwe\' recursively without -r\n'))
    assert not match(Command('git rm rwe', '', ''))


# Generated at 2022-06-12 11:48:03.272224
# Unit test for function match
def test_match():
    # Match
    assert match(Command('git rm -f foo/', stderr='fatal: not removing \'foo/\' recursively without -r'))
    # No match
    assert not match(Command('git rm -f foo/', stderr='fatal: not removing \'foo/\' recursively'))


# Generated at 2022-06-12 11:48:08.460921
# Unit test for function match

# Generated at 2022-06-12 11:48:13.314483
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r\n',
                         ''))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r\n',
                             '', stderr=subprocess.STDOUT))
    assert not match(Command('ls file',
                             'fatal: not removing \'file\' recursively without -r\n',
                             '', stderr=subprocess.STDOUT))

# Generated at 2022-06-12 11:48:14.826449
# Unit test for function match
def test_match():
    assert match(Command('git rm -f a_file'))
    assert not match(Command('git rm a_file'))

# Generated at 2022-06-12 11:48:20.100735
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf static'))
    assert match(Command('git rm static'))
    assert not match(Command('git rm -f static'))
    assert not match(Command('git rm -r static'))
    assert not match(Command('git rmf static'))
    assert not match(Command('git rf static'))
    assert not match(Command('git rm --static'))


# Generated at 2022-06-12 11:48:24.914669
# Unit test for function match
def test_match():
    assert match(Command(' git rm .DS_Store', 'fatal: not removing \'build/.DS_Store\' recursively without -r'))
    assert not match(Command(' git rm .DS_Store', 'On branch master\nnothing to commit, working tree clean'))
    assert not match(Command(' git rm .DS_Store', 'fatal: not removing \'build/.DS_Store\''))


# Generated at 2022-06-12 11:49:14.685857
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test.py', "fatal: not removing 'test.py' recursively without -r"))
    assert not match(Command('git rm test.py', "fatal: not removing 'test.py' recursively without -r"))
    assert not match(Command('git rm test.py', "fatal: not removing test.py recursively without -r"))


# Generated at 2022-06-12 11:49:18.308369
# Unit test for function match
def test_match():
    assert match(Command('git rm test'))
    assert not match(Command('git  rm test'))
    assert not match(Command('rm test', stderr='fatal: not removing '' recursively without -r'))


# Generated at 2022-06-12 11:49:22.051807
# Unit test for function match
def test_match():
    assert match(Command(script='git rm foo', output='not removing'))
    assert not match(Command(script='git rm', output='fatal: not removing'))
    assert not match(Command(script='git rm foo', output='fatal: not removing'))



# Generated at 2022-06-12 11:49:23.779223
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r exampledir')
    assert get_new_command(command) == 'git rm -r -r exampledir'

# Generated at 2022-06-12 11:49:28.537658
# Unit test for function match
def test_match():
    out = '''
fatal: not removing 'live-stable/live/debian-live-7.5.0-amd64-cinnamon-desktop.iso' recursively without -r
'''
    assert match(Command('rm live-stable/live/debian-live-7.5.0-amd64-cinnamon-desktop.iso', out))


# Generated at 2022-06-12 11:49:32.241765
# Unit test for function match
def test_match():
    assert git_rm.match(Command('git rm -r f',
                                stderr='fatal: not removing \'f\' recursively without -r\n'))
    assert not git_rm.match(Command('git rm f',
                                     stderr='fatal: pathspec \'e\' did not match any files\n'))


# Generated at 2022-06-12 11:49:34.078028
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -rf test") == "git rm -rf test"
    assert get_new_command("git rm test") == "git rm -r test"

# Generated at 2022-06-12 11:49:39.937572
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf deps/packages/foo',
            'fatal: not removing \'deps/packages/foo\' recursively without -r'))
    assert not match(Command('git rm -rf deps/packages/foo',
            'fatal: not removing \'deps/packages/foo\' recursively with -r'))
    assert not match(Command('git rm -rf deps/packages/foo',
            'fatal: not removing \'deps/packages/foo\' recursively without -r'))



# Generated at 2022-06-12 11:49:41.753812
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm myfolder', '', '', '')) == 'git rm -r myfolder'


# Generated at 2022-06-12 11:49:44.965103
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_repo_rm import get_new_command
    command = 'git rm test.txt'
    correct_command = 'git rm -r test.txt'
    assert get_new_command(command) == correct_command