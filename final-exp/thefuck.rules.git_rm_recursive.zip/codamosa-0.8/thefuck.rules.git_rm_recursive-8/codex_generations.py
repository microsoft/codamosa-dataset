

# Generated at 2022-06-12 11:39:44.728560
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf folder')
    new_command = get_new_command(command)
    assert new_command == 'git rm -r -rf folder'

# Generated at 2022-06-12 11:39:54.696464
# Unit test for function match
def test_match():
    command = Command('rm file1', 'fatal: not removing \'file1\' recursively without -r\n')
    assert match(command) is True
    command = Command('rm file1 file2', 'fatal: not removing \'file1\' recursively without -r\n')
    assert match(command) is True
    command = Command('git rm file1', 'fatal: not removing \'file1\' recursively without -r\n')
    assert match(command) is True
    command = Command('rm folder1', 'fatal: not removing \'folder1\' recursively without -r\n', '', '')
    assert match(command) is True
    command = Command('rm file1', 'fatal: not removing \'file1\' recursively without -r\n')
    assert match(command) is True
    command

# Generated at 2022-06-12 11:39:57.345219
# Unit test for function match
def test_match():
    assert match(Command('git rm', 'fatal: not removing \'filename\' recursively without -r'))
    assert not match(Command('git branch', ''))

# Generated at 2022-06-12 11:40:02.037769
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf src')) == 'git rm -rf -r src'
    assert get_new_command(Command('git rm -rf src/')) == 'git rm -rf -r src/'
    assert get_new_command(Command('git rm -rf src/*')) == 'git rm -rf -r src/*'

# Generated at 2022-06-12 11:40:03.640340
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -rf dir') == 'git rm -r -rf dir'

# Generated at 2022-06-12 11:40:10.699964
# Unit test for function match
def test_match():
	match_output = '''
fatal: not removing 'A/b' recursively without -r
'''
	not_match_output = '''
fatal: not removing 'A/b' recursively without -r
fatal: not removing 'A/b' recursively without -r
'''

	command = Command('git rm A/b', match_output)
	assert(match(command) == True)

	command = Command('git rm A/b', not_match_output)
	assert(match(command) == False)


# Generated at 2022-06-12 11:40:13.742350
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
            stderr='fatal: not removing \'foo\' recursively without -r\n'))
    assert not match(Command('ls'))
    assert not match(Command('git rm -r foo'))


# Generated at 2022-06-12 11:40:16.440077
# Unit test for function match
def test_match():
    assert(match(Command('git rm abc', 'fatal: not removing \'abc\' recursively without -r', '...')))


# Generated at 2022-06-12 11:40:19.396663
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -r a')
    assert command.script == 'git rm -r a' and command.output == ''
    assert get_new_command(command) == 'git rm -r -r a'

# Generated at 2022-06-12 11:40:23.152614
# Unit test for function match
def test_match():
    assert match(Command('git rm -r', 'fatal: not removing \'git rm\' recursively without -r'))
    assert cmd == 'git rm -r'
    assert not match(Command('rm -rf *', ''))
    assert not match(Command('git rm', ''))
    assert not match(Command('git rm stuff', ''))

# Generated at 2022-06-12 11:40:28.180251
# Unit test for function match
def test_match():
    command = Command("git rm -r fix/some-problem", "fatal: not removing 'fix/some-problem' recursively without -r", "", 0)
    assert match(command)


# Generated at 2022-06-12 11:40:30.320320
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm ./.gitconfig', '', '')
    assert get_new_command(command) == 'git rm -r ./.gitconfig'

# Generated at 2022-06-12 11:40:36.616402
# Unit test for function match
def test_match():
    assert(match(Command('git rm file')) == False)
    assert(match(Command('git rm -r file')) == False)
    assert(match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n')) == True)
    #assert(match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n')) == False)


# Generated at 2022-06-12 11:40:39.093362
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r non-existing-directory',
                      'fatal: not removing \'non-existing-directory\' recursively without -r')
    assert get_new_command(command).script == 'git rm -r -r non-existing-directory'

# Generated at 2022-06-12 11:40:40.386122
# Unit test for function match
def test_match():
    assert match('git rm first.c second.c')
    assert not match('git rm first.c')



# Generated at 2022-06-12 11:40:43.786950
# Unit test for function match
def test_match():
    assert match(Command('git rm -rv file.py', '', '', 1, None))
    assert match(Command('git rm -rf dir', '', '', 1, None))
    assert not match(Command('git status', '', '', 1, None))
    assert not match(Command(' rm -rf dir/file.py', '', '', 1, None))


# Generated at 2022-06-12 11:40:45.814905
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file'))



# Generated at 2022-06-12 11:40:56.398809
# Unit test for function match
def test_match():
	assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r'))
	assert not match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r', 'Error'))
	assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r', 'fatal: You are not currently on a branch.'))
	assert not match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r', 'fatal: You are not currently on a branch.', 'Error'))
	assert not match(Command('ls', 'fatal: not removing \'foo\' recursively without -r'))

if __name__ == "__main__":
    test_match()

# Generated at 2022-06-12 11:41:00.807079
# Unit test for function match
def test_match():
    from thefuck.types import Command
    correct_commands = [
        'git rm foo',
        'git rm -r foo'
    ]
    wrong_commands = [
        'git backup foo',
        'ls foo',
        'git rm -f foo'
    ]
    for command in correct_commands:
        assert match(Command(command, 'fatal: not removing \'foo\' recursively without -r'))
    for command in wrong_commands:
        assert not match(Command(command, 'fatal: not removing \'foo\' recursively without -r'))


# Generated at 2022-06-12 11:41:03.742837
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
        'fatal: not removing \'file\' recursively without -r\n',
         ''))



# Generated at 2022-06-12 11:41:13.737740
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file.py', 'fatal: not removing \'file.py\''
                         ' recursively without -r'))
    assert not match(Command('git rm file.py', 'fatal: not removing \'file.py\''
                         ' recursively without -r'))
    assert not match(Command('ls', 'fatal: not removing \'file.py\''
                         ' recursively without -r'))


# Generated at 2022-06-12 11:41:18.184986
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    script = u'git rm .gitignore'
    output = 'fatal: not removing \'.gitignore\' recursively without -r'
    command = Command(script = script, output = output)
    assert get_new_command(command) == u'git rm -r .gitignore'

# Generated at 2022-06-12 11:41:20.418940
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command(Command("git branch -d branch"))
    assert(new_cmd == "git branch -d -r branch")

# Generated at 2022-06-12 11:41:24.406440
# Unit test for function get_new_command
def test_get_new_command():
    command_name = 'git rm dir'
    output = "fatal: not removing 'dir' recursively without -r"

    command = Command(command_name, output)

    assert get_new_command(command) == 'git rm -r dir'

# Generated at 2022-06-12 11:41:30.037928
# Unit test for function match
def test_match():
    assert match(Command(script=u'git rm file'
                         , output=u"fatal: not removing 'file' recursively without -r"))
    assert match(Command(script=u'git branch -d branch'
                         , output=u"fatal: not removing 'branch' recursively without -r"))
    assert not match(Command(script=u'git rm file', output=u''))
    assert not match(Command(script=u'rm file', output=u''))


# Generated at 2022-06-12 11:41:33.507085
# Unit test for function get_new_command
def test_get_new_command():
    C = Command('git rm *.txt', 'fatal: not removing \'test.txt\' recursively without -r\n')
    assert get_new_command(C) == 'git rm -r *.txt'



# Generated at 2022-06-12 11:41:39.128416
# Unit test for function match
def test_match():
	assert match(Command('git rm -r foo',
						 'fatal: not removing \'foo\' recursively without -r\n'))
	assert not match(Command('git rm foo',
							 'fatal: not removing \'foo\' recursively without -r\n'))



# Generated at 2022-06-12 11:41:41.267824
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r folder') == 'git rm -r -r folder'

# Generated at 2022-06-12 11:41:47.006101
# Unit test for function match
def test_match():
    assert not match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert match(Command('git rm -r dir', 'fatal: not removing \'dir\' recursively without -r'))
    assert match(Command('git rm -r dir file.txt', 'fatal: not removing \'dir\' recursively without -r'))



# Generated at 2022-06-12 11:41:50.918494
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf directory')) == 'git rm -r -rf directory'
    assert get_new_command(Command('git rm -rf directory/subdirectory')) == 'git rm -r -rf directory/subdirectory'

# Generated at 2022-06-12 11:41:59.089345
# Unit test for function match
def test_match():
    fail_output = u'fatal: not removing \'path/to/file\' recursively without -r'
    fail_command = u'git rm path/to/file'
    assert match(Command(fail_command, fail_output))

    success_command = u'git rm -r path/to/file'
    assert not match(Command(success_command, fail_output))

    assert not match(Command(success_command))



# Generated at 2022-06-12 11:42:01.320403
# Unit test for function match
def test_match():
    assert match(Command('git rm myfolder', ''))
    assert not match(Command('git commit', ''))


# Generated at 2022-06-12 11:42:07.301790
# Unit test for function match
def test_match():
    assert match(Command('git rm -t jbuger.txt',
                         'fatal: not removing '
                         '\'some/path/jbuger.txt\' '
                         'recursively without -r\n'
                         'Did you mean this?\n'
                         '\tgit status -t jbuger.txt',
                         ''))



# Generated at 2022-06-12 11:42:15.517272
# Unit test for function match
def test_match():
    # Positive tests
    assert match(Command('git rm -r file', '', 'fatal: not removing \'file\' recursively without -r')) == True

    # Negative tests
    assert match(Command('git commit file', '', 'fatal: not removing \'file\' recursively without -r')) == False
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r')) == False
    assert match(Command('git rm -r file', '', 'fatal: removing \'file\' recursively with -r')) == False
    assert match(Command('git rm -r file', '', 'fatal: removing \'file\'')) == False

# Generated at 2022-06-12 11:42:18.467147
# Unit test for function get_new_command
def test_get_new_command():
  assert(get_new_command(Command(script="git rm myfile",
    output="fatal: not removing 'myfile' recursively without -r")) == "git rm -r myfile")

# Generated at 2022-06-12 11:42:21.272728
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', ''))
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '')) is False

# Generated at 2022-06-12 11:42:30.461615
# Unit test for function match
def test_match():
    command_output = "fatal: not removing 'my_git_directory/n' recursively without -r"
    command_output_without_error_message = "fatal: not removing 'my_git_directory/n' recursively"
    command = Command('git rm my_git_directory/n', command_output)

    assert(match(command))
    assert(not match(Command('git rm my_git_directory/n')))
    assert(not match(Command('git rm my_git_directory/n', command_output_without_error_message)))
    assert(not match(Command('ls my_git_directory/n', command_output)))



# Generated at 2022-06-12 11:42:33.555869
# Unit test for function match
def test_match():
    assert match(Command("git rm -rf *",
                         "fatal: not removing 'test' recursively without -r"))
    assert not match(Command("git rm -rf *", "test"))


# Generated at 2022-06-12 11:42:35.559736
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm x')
    assert (get_new_command(command) == 'git rm -r x')

# Generated at 2022-06-12 11:42:36.099907
# Unit test for function match
def test_match():
    assert False

# Generated at 2022-06-12 11:42:45.319519
# Unit test for function match
def test_match():
    # Match example output for the command "git rm -r *"
    assert(match(Command('git rm -r *', 'fatal: not removing \'example.cpp\' recursively without -r\n')))
    assert(not match(Command('git rm -r *', 'fatal: not removing \'example.cpp\' recursively without -r')))


# Generated at 2022-06-12 11:42:48.866814
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r my_directory', 
            'fatal: not removing \'my_directory\' recursively without -r')
    assert get_new_command(command) == 'git rm -r my_directory'

# Generated at 2022-06-12 11:42:53.312564
# Unit test for function get_new_command
def test_get_new_command():
	command = Command('git rm -f *.txt', 'fatal: not removing \'*.txt\' recursively without -r')
	# When get_new_command is called, it will be verified if match function has matched
	# match function returns false, we must force it to return true
	command.does_match = lambda: True

	# Get new command
	new_command = get_new_command(command)
	assert new_command == 'git rm -f -r *.txt'

# Generated at 2022-06-12 11:42:56.843857
# Unit test for function get_new_command
def test_get_new_command():
    command = types.Command(script = 'git rm file',
            output = 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file'


# Generated at 2022-06-12 11:42:59.361630
# Unit test for function get_new_command
def test_get_new_command():
    Command = namedtuple('Command', ('script'))
    command = Command('git rm file')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-12 11:43:04.433044
# Unit test for function match
def test_match():
    assert(match(Command('rm foo'))== False)
    assert(match(Command('rm -r foo'))== False)
    assert(match(Command('rm foo bar')) == False)
    assert(match(Command('git rm foo')) == False)
    output = '''fatal: not removing 'foo' recursively without -r
'''
    assert(match(Command('git rm foo', output)) == True)

# Generated at 2022-06-12 11:43:08.561305
# Unit test for function match
def test_match():
    assert match(Command('rm -r --cached test.txt',
                         'fatal: not removing \'-r\' recursively without -r'))
    assert not match(Command('rm test.txt', ''))
    assert not match(Command('rm test.txt', 'fatal: not removing \'foo\''))


# Generated at 2022-06-12 11:43:11.759901
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = u'git rm file.txt', output = u"fatal: not removing 'file.txt' recursively without -r")
    assert u'git rm -r file.txt' == get_new_command(command)

# Generated at 2022-06-12 11:43:21.188232
# Unit test for function match
def test_match():
    assert(match(Command('rm testing', 'fatal: not removing \'testing\' recursively without -r', None)) == True)
    assert(match(Command('rm testing', 'fatal: not removing \'testing\' recursively without -r', None)) == True)
    assert(match(Command('rm test', 'fatal: not removing \'test\' recursively without -r', None)) == True)
    assert(match(Command('rm testing', 'fatal: not removing \'testing\' recursively without -r', None)) == True)
    assert(match(Command('rm test', 'fatal: not removing \'test\' recursively without -r', None)) == True)
    assert(match(Command('rm testing', 'fatal: not removing \'testing\' recursively without -r', None)) == True)

# Generated at 2022-06-12 11:43:24.322146
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         'fatal: not removing "foo" recursively without -r'))
    assert not match(Command('git rm foo', 'fatal: not removing "foo"'))


# Generated at 2022-06-12 11:43:36.819107
# Unit test for function match
def test_match():
    assert match(Command('git rm file', stderr="fatal: not removing 'file' recursively without -r"))
    assert match(Command('git rm file', stderr="fatal: not removing 'files' recursively without -r"))
    assert match(Command('git rm -f file', stderr="fatal: not removing 'files' recursively without -r"))
    assert match(Command('git rm --force file', stderr="fatal: not removing 'files' recursively without -r"))
    assert not match(Command('git rm -r file', stderr="fatal: not removing 'files' recursively without -r"))
    assert not match(Command('git rm --recursive file', stderr="fatal: not removing 'files' recursively without -r"))

# Generated at 2022-06-12 11:43:41.079217
# Unit test for function match
def test_match():
    assert match(Command('git rm -r folder/',
                         'fatal: not removing \'folder/\' recursively without -r'))
    assert not match(Command('git rm -r folder/', ''))
    assert not match(Command('rm -r folder/', ''))


# Generated at 2022-06-12 11:43:45.199492
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git rm file.txt'
    command = Command(script, script, 'fatal: not removing \'file.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file.txt'

# Generated at 2022-06-12 11:43:49.687619
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2',
                         'fatal: not removing \'file1\' recursively without -r',
                         ''))
    assert not match(Command('git rm file', '', ''))
    assert not match(Command('rm file', '', ''))



# Generated at 2022-06-12 11:43:52.761162
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r a', 'fatal: not removing \'a\' recursively without -r\n')
    assert get_new_command(command) == "git rm -r -r a"

# Generated at 2022-06-12 11:43:55.574093
# Unit test for function match
def test_match():
    assert match(Command('git branch', 'fatal: not removing \'a.c\' recursively without -r'))
    assert not match(Command('git branch', 'fatal: not removing \'a.c\' recursively'))
    assert not m

# Generated at 2022-06-12 11:44:00.699589
# Unit test for function match
def test_match():
    assert match(Command('git rm text.txt', '', '', '', 1))
    assert not match(Command('git', '', '', '', 1))
    assert not match(Command('git add text.txt', '', '', '', 1))
    assert not match(Command('git rm text.txt', '', '', '', 1))
    assert not match(Command('git rm', '', '', '', 1))


# Generated at 2022-06-12 11:44:09.378023
# Unit test for function match
def test_match():
    print (('Unit test for function match'))
    # Not rm command
    command = Script('ls -la')
    assert (match(command) == False)
    # Git command, but no rm in command.script
    command = Script('git add .')
    assert (match(command) == False)
    # Git rm, but no 'fatal: not removing '
    # in command.output
    command = Script('git rm .')
    command.output = 'fatal: pathspec \' . \' did not match any files'
    assert (match(command) == False)
    # Git rm, but no 'recursively without -r'
    # in command.output
    command = Script('git rm .')
    command.output = ('fatal: not removing \'.\' recursively \n'
                      'without -r')
   

# Generated at 2022-06-12 11:44:15.409298
# Unit test for function match
def test_match():
    assert match(Command('git rm', output='fatal: not removing "." recursively without -r', stderr=True))
    assert match(Command('git rm', output='fatal: not removing ".." recursively without -r', stderr=True))
    assert not match(Command('git rm', output='fatal: not removing ".." recursively without -r', stderr=False))
    assert not match(Command('git rm', output='fatal: not removing without -r', stderr=True))


# Generated at 2022-06-12 11:44:18.643259
# Unit test for function match
def test_match():
    assert_true(match(Command('git add foo', '')))
    assert_false(match(Command('git add foo', 'No error')))
    assert_false(match(Command('git rm foo', '')))


# Generated at 2022-06-12 11:44:35.579804
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm awesome_folder')) == 'git rm -r awesome_folder'
    assert get_new_command(Command('git rm -f awesome_folder')) == 'git rm -f -r awesome_folder'



# Generated at 2022-06-12 11:44:45.641702
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f test_file', 'fatal: not removing \'test_file\' recursively without -r')
    assert get_new_command(command) == 'git rm -rf test_file'
    command = Command('git rm test_file', 'fatal: not removing \'test_file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r test_file'
    command = Command('git rm test_file', "fatal: not removing 'test_file' recursively without -r\nfatal: not removing 'test_file' recursively without -r\n")
    assert get_new_command(command) == 'git rm -r test_file'

# Generated at 2022-06-12 11:44:46.994258
# Unit test for function match
def test_match():
    assert match(Command('rm txt/con')) == True


# Generated at 2022-06-12 11:44:49.641673
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r -f file.txt')
    assert get_new_command(command) == 'git rm -r -f -r file.txt'


# Generated at 2022-06-12 11:44:56.055193
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -rf a/b', '', '/tmux', '/tmux')) == 'git rm -r a/b'
    assert get_new_command(Command('git rm -rf a/b', '', '/tmux', '/tmux')) == 'git rm -r a/b'
    assert get_new_command(Command('g rm -rf a/b', '', '/tmux', '/tmux')) == 'g rm -r a/b'
    assert get_new_command(Command('rm -rf --cached a/b', '', '/tmux', '/tmux')) == 'git rm -r --cached a/b'
    assert get_new_command(Command('rm -rf', '', '/tmux', '/tmux')) == 'git rm -r'

# Generated at 2022-06-12 11:44:59.129743
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_error_add_recursive import get_new_command
    assert get_new_command(Command('git rm -f _build/html')) == 'git rm -r -f _build/html'

# Generated at 2022-06-12 11:45:03.030043
# Unit test for function match
def test_match():
	assert match(Command('git rm non_existent_file', 'fatal: not removing \'non_existent_file\' recursively without -r'))
	assert not match(Command('git add non_existent_file', 'fatal: not removing \'non_existent_file\' recursively without -r'))


# Generated at 2022-06-12 11:45:07.661342
# Unit test for function match
def test_match():
    assert match(Command('git rm test', 'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm test', ''))
    assert not match(Command('git add test', 'fatal: not removing \'test\' recursively without -r'))


# Generated at 2022-06-12 11:45:08.910219
# Unit test for function match
def test_match():
    assert match(Command('git rm -r -r --cached'))


# Generated at 2022-06-12 11:45:12.214107
# Unit test for function match
def test_match():
    script = ' git add _pre-commit && git rm -r --cached tests/fixtures'
    output = "fatal: not removing 'tests/fixtures/666' recursively without -r"
    assert(match(Command(script, output)) == True)

# Generated at 2022-06-12 11:45:51.325019
# Unit test for function match
def test_match():
    assert match(Command('git rm -f foo'))
    assert match(Command('git rm -f foo bar'))
    assert match(Command('git rm -f foo bar/baz'))

# Generated at 2022-06-12 11:45:53.652325
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r',
                         ''))
    assert not match(Command('pip install', "", ""))

# Generated at 2022-06-12 11:45:55.022327
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -f directory_name') == 'git rm -rf directory_name'

# Generated at 2022-06-12 11:45:58.312859
# Unit test for function match
def test_match():
    command = Command("git rm file.py")
    assert match(command)
    command = Command("git rm -r file.py")
    assert not match(command)
    command = Command("grep rm file.py")
    assert not match(command)


# Generated at 2022-06-12 11:46:01.734204
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command
    assert get_new_command(Command('git rm test.txt', 'fatal: not removing \'Test.txt\' recursively without -r')) == 'git rm -r test.txt'

# Generated at 2022-06-12 11:46:11.758885
# Unit test for function match
def test_match():
	# True case 1
	assert match(Command('git rm -f static/js/app/app.js',
							'''fatal: not removing 'static/js/app/app.js' recursively without -r''')) == True
	# True case 2
	assert match(Command('git rm -f static/js/app/app.js',
							'''
							fatal: not removing 'static/js/app/app.js' recursively without -r
							''')) == True
	# False case 1

# Generated at 2022-06-12 11:46:14.757527
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -r hello', '', 'fatal: not removing \'hello\' recursively without -r', '', '', '')
    assert('rm -r -r hello' in get_new_command(command))

# Generated at 2022-06-12 11:46:17.186720
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file.txt', '', 'fatal: not removing \'file.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file.txt'

# Generated at 2022-06-12 11:46:21.768475
# Unit test for function get_new_command
def test_get_new_command():
    command_script = u"git rm -r the_name_of_the_file"
    command_output  = u"fatal: not removing 'the_name_of_the_file' recursively without -r"
    command = Command(command_script, command_output)
    assert u"git rm -r -r the_name_of_the_file" == get_new_command(command)

    command_script = u"git rm the_name_of_the_file"
    command_output  = u"fatal: not removing 'the_name_of_the_file' recursively without -r"

# Generated at 2022-06-12 11:46:26.418168
# Unit test for function match
def test_match():
    assert match(Command("git rm test.txt", "fatal: not removing 'test.txt' recursively without -r"))
    assert not match(Command("git rm test.txt", "fatal: not removing 'test2.txt' recursively without -r"))


# Generated at 2022-06-12 11:47:29.601970
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r\n'))



# Generated at 2022-06-12 11:47:32.682592
# Unit test for function match
def test_match():
    assert match(Command('git rm non_empty_dir', 'fatal: not removing non_empty_dir recursively without -r'))
    assert not match(Command('git rm file', ''))


# Generated at 2022-06-12 11:47:38.133609
# Unit test for function match
def test_match():
    assert match(Command('git rm --cached src/git.py', '', 'fatal: not removing \'src/git.py\' recursively without -r'))
    assert not match(Command('git rm --cached src/git.py', '', ''))
    assert not match(Command('ls src/git.py', '', 'fatal: not removing \'src/git.py\' recursively without -r'))


# Generated at 2022-06-12 11:47:40.879226
# Unit test for function match
def test_match():
    assert match(Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r'))
    assert not match(Command('git rm dir', ''))
    assert not match(Command('git pull', 'fatal: not removing \'dir\' recursively without -r'))


# Generated at 2022-06-12 11:47:42.240720
# Unit test for function match
def test_match():
    test_cmd = Command('git rm fc')
    assert match(test_cmd)


# Generated at 2022-06-12 11:47:45.644608
# Unit test for function match
def test_match():
    assert match(Command(script='git rm --force', output='fatal: not removing \'folder\' recursively without -r'))
    assert not match(Command(script='git rm --force', output='not removing \'folder\' recursively without -r'))


# Generated at 2022-06-12 11:47:49.554862
# Unit test for function get_new_command
def test_get_new_command():
    assert "git rm -r file" == get_new_command('git rm file')
    assert "git rm -r file" == get_new_command('git rm file ')
    assert "git pull && echo" == get_new_command('git pull && echo')



# Generated at 2022-06-12 11:47:54.145347
# Unit test for function match
def test_match():
    import os
    from thefuck.types import Command
    from thefuck.rules.git_add_deleted import match
    shell_output = 'fatal: not removing \'file.txt\' recursively without -r\n'
    command_output = Command("git rm file.txt", shell_output)
    
    assert match(command_output)
    assert not match(Command("git rm -r file.txt", ""))
    assert not match(Command("git add file.txt", ""))


# Generated at 2022-06-12 11:47:58.129246
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'
    assert get_new_command('git rm foo bar') == 'git rm -r foo bar'
    assert get_new_command('git remote rm foo') == 'git remote rm foo'

# Generated at 2022-06-12 11:48:05.209591
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm thefile")) == "git rm -r thefile"
    assert get_new_command(Command("git rm -f thefile")) == "git rm -f -r thefile"
    assert get_new_command(Command("git rmdir thefile")) == "git rmdir -r thefile"
    assert get_new_command(Command("git rmdir -f thefile")) == "git rmdir -f -r thefile"