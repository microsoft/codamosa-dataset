

# Generated at 2022-06-26 06:18:06.270223
# Unit test for function get_new_command
def test_get_new_command():
    assert callable(get_new_command)


# Generated at 2022-06-26 06:18:12.737770
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = u'git rm file.txt'
    var_0 = Command(var_0)
    var_0.output = u'fatal: not removing \'file.txt\' recursively without -r\n'
    var_1 = get_new_command(var_0)
    assert var_1 == u'git rm -r file.txt'


# Generated at 2022-06-26 06:18:14.779718
# Unit test for function match
def test_match():
    assert git_support()


# Generated at 2022-06-26 06:18:21.819204
# Unit test for function match
def test_match():
    assert(match(True, "rm -rf ~/.vim/bundle/Vundle.vim"))
    assert(not match(True, "rm ~/.vim/bundle/Vundle.vim"))
    assert(not match(True, "rm ~/.vim/bundle/Vundle.vim"))
    assert(not match(True, "git rm 'Vundle.vim"))
    assert(not match(True, "git rm 'Vundle.vim"))



# Generated at 2022-06-26 06:18:23.960780
# Unit test for function get_new_command
def test_get_new_command():
    assert False
# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-26 06:18:34.816781
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm foo', stderr='fatal: not removing \'foo\' recursively without -r')
    assert (get_new_command(command) == u'git rm -r foo')
    command = Command(script='git rm foo', stderr='fatal: not removing \'foo\' recursively without -r')
    assert (get_new_command(command) == u'git rm -r foo')
    command = Command(script='ls foo', stderr='fatal: not removing \'foo\' recursively without -r')
    assert (get_new_command(command) is None)
    command = Command(script='git rm foo', stderr='fatal: not removing \'foo\' recursively without -r')

# Generated at 2022-06-26 06:18:38.594902
# Unit test for function get_new_command
def test_get_new_command():
    try:
        test_case_0()
    except AssertionError as e:
        print("test_get_new_command throws AssertionError")
        raise e

# Generated at 2022-06-26 06:18:39.939675
# Unit test for function match
def test_match():
    assert True


# Generated at 2022-06-26 06:18:41.627890
# Unit test for function match
def test_match():
    assert match(' rm -f ')
    assert not match('rm -f')

# Generated at 2022-06-26 06:18:49.429139
# Unit test for function match
def test_match():
    # Getting initial values from dict
    command = {}
    command['script'] = 'git rm src/file.py'
    command['output'] = "fatal: not removing 'src/file.py' recursively without -r"
    command['script_parts'] = ['git', 'rm', 'src/file.py']
    match_output = match(command)
    assert (match_output == True)

# Generated at 2022-06-26 06:18:54.003479
# Unit test for function match
def test_match():
    assert match(Command('git rm a b', 'fatal: not removing \'a\' recursively without -r'))
    assert not match(Command('git rm -r a b', 'fatal: not removing \'a\' recursively without -r'))


# Generated at 2022-06-26 06:18:59.685835
# Unit test for function match
def test_match():
	assert match(Command(script="log")) == False
	assert match(Command(script="git rm -r --cached")) == False
	assert match(Command(script="git rm", output="fatal: not removing '...' recursively without -r")) == True



# Generated at 2022-06-26 06:19:02.263724
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm directory', '', 'fatal: not removing \'directory\' recursively without -r \n', None)) == "git rm -r directory")

# Generated at 2022-06-26 06:19:12.291057
# Unit test for function match
def test_match():
    # rm command with subfolders
    command = Command('rm -rf folder/subfolder',
                      'fatal: not removing \'folder/subfolder/\' recursively without -r\n')
    assert match(command) == True
    # rm command with files
    command = Command('rm -rf folder/file',
                      'fatal: not removing \'folder/file/\' recursively without -r\n')
    assert match(command) == True
    # rm command with files and folders
    command = Command('rm -rf folder/subfolder folder/file',
                      'fatal: not removing \'folder/subfolder/\' recursively without -r\n')
    assert match(command) == True



# Generated at 2022-06-26 06:19:17.310942
# Unit test for function get_new_command
def test_get_new_command():
    output = "fatal: not removing 'directory' recursively without -r"
    command = Command("git rm directory", output)
    assert get_new_command(command) == "git rm -r directory"

# Generated at 2022-06-26 06:19:21.444055
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                output="fatal: not removing 'foo' recursively without -r"))
    assert not match(Command('git lg',
                             output="fatal: not removing 'foo' recursively without -r"))



# Generated at 2022-06-26 06:19:31.722554
# Unit test for function match
def test_match():
	command = Command(script=u'git rm -rf')
	assert match(command) == False
	command = Command(script=u'git rm -rf test')
	assert match(command) == False
	command = Command(script=u'git rm -rf test', output=u"fatal: not removing 'test' recursively without -r\n")
	assert match(command) == True
	command = Command(script=u'git rm -rf test', output=u"fatal: not removing 'test' recursively without -r")
	assert match(command) == True


# Generated at 2022-06-26 06:19:34.561963
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm file") == u'git rm -r file'
    assert get_new_command("git rm -f file") == u'git rm -f -r file'
    assert get_new_command("git rm -rf file") == u'git rm -rf file'

# Generated at 2022-06-26 06:19:41.094818
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', stderr='fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo'))
    assert not match(Command('git rm foo', stderr='fatal: not removing \'bar\' recursively without -r'))


# Generated at 2022-06-26 06:19:48.949971
# Unit test for function match
def test_match():
    assert match(Command('git branch branch_name', '', ''))
    assert match(Command('git branch branch_name', 'fatal: not removing \'file\' recursively without -r', 'git branch branch_name'))
    assert not match(Command('git branch branch_name', 'fatal: not removing \'file\' recursively without -r', 'git branch branch_name'))


# Generated at 2022-06-26 06:20:00.225926
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm toto', '',
        'fatal: not removing \'toto\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r toto'

# Generated at 2022-06-26 06:20:03.124382
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f file.txt', 'fatal: not removing \'file.txt\''
                      ' recursively without -r')
    assert get_new_command(command) == 'git rm -f -r file.txt'

# Generated at 2022-06-26 06:20:10.496182
# Unit test for function match
def test_match():
    command = 'git rm -r some_directory'
    assert match(Command(command, 'fatal: not removing \'some_directory\' recursively without -r'))
    command = 'git help'
    assert not match(Command(command, 'fatal: not removing \'some_directory\' recursively without -r'))


# Generated at 2022-06-26 06:20:13.757523
# Unit test for function get_new_command
def test_get_new_command():
    output = filter(None, ["fatal: not removing 'foo.txt' recursively without -r",
    "Did you mean 'rm -r'?"])
    asser

# Generated at 2022-06-26 06:20:16.369398
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test')) == 'git rm -r test'

# Generated at 2022-06-26 06:20:19.382617
# Unit test for function match
def test_match():
	assert(match(Command('git rm f')) != None)
	assert(match(Command('git rm f -r')) == None)
	assert(match(Command('git rmdir f')) == None)


# Generated at 2022-06-26 06:20:22.687824
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', None, 'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-26 06:20:28.981293
# Unit test for function match
def test_match():
    assert match(Command('git rm dir/not_empty_dir/',
        "fatal: not removing 'dir/not_empty_dir/' recursively without -r"))
    assert not match(Command('git rm dir/',
        "fatal: not removing 'dir/' recursively without -r"))


# Generated at 2022-06-26 06:20:38.671026
# Unit test for function match
def test_match():
    assert match(Command(script = 'git rm -f',
                         stderr = "fatal: not removing 'lib/Smarty.class.php' recursively without -r"))
    assert not match(Command(script = 'git rm -f',
                             stderr = 'fatal: not removing ''lib/Smarty.class.php'' recursively without -r'))
    assert not match(Command(script = 'git ls',
                             stderr = 'fatal: not removing \'lib/Smarty.class.php\' recursively without -r'))


# Generated at 2022-06-26 06:20:43.376153
# Unit test for function match
def test_match():
    command = Command('git rm FOLDER', 'fatal: not removing \'FOLDER\' recursively without -r\n')
    assert match(command)
    assert not match(Command('git rm', ''))

# Generated at 2022-06-26 06:20:57.754402
# Unit test for function get_new_command
def test_get_new_command():
    test_input_command = "git rm x y z"
    test_input_command_output = "fatal: not removing 'x' recursively without -r"
    test_command = Command(test_input_command, test_input_command_output)
    assert get_new_command(test_command) == "git rm -r x y z"


# Generated at 2022-06-26 06:20:59.625798
# Unit test for function match
def test_match():
    assert match(Command('rm file.txt', '', ''))
    assert match(Command('git status', '', '')) is None


# Generated at 2022-06-26 06:21:05.670048
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm folder", "fatal: not removing 'folder'"
                 " recursively without -r \n Use 'git rm -r folder' to remove it")
    assert get_new_command(command) == "git rm -r folder"

# Generated at 2022-06-26 06:21:07.131726
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm /some/path')) == 'git rm -r /some/path'

# Generated at 2022-06-26 06:21:09.475893
# Unit test for function match
def test_match():
    assert match(create_command('git rm file'))
    assert match(create_command('git rm -r dir'))
    assert not match(create_command('git rm'))


# Generated at 2022-06-26 06:21:13.005313
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git rm -r test' ==
            get_new_command(Command('git rm test',
                                    'fatal: not removing \'./test\' recursively without -r')))

# Generated at 2022-06-26 06:21:18.346939
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f src/views/user/UserView.java',
                                   'fatal: not removing \'src/views/user/UserView.java\' recursively without -r')) == 'git rm -r -f src/views/user/UserView.java'

# Generated at 2022-06-26 06:21:20.351281
# Unit test for function get_new_command
def test_get_new_command():
        assert get_new_command(' rm file1') == 'rm -r file1'

# Generated at 2022-06-26 06:21:28.146804
# Unit test for function match
def test_match():
    # Test if match is true when the script contains ' rm ' and the output
    # contains "fatal: not removing '" and "' recursively without -r"
    command = Command('git rm test', 'fatal: not removing \'test\' recursively without -r')
    assert(match(command))

    # Test if match is true when the script does not contain ' rm ' and
    # the output does not contain "fatal: not removing '" and "'
    # recursively without -r"
    command = Command('git branch', 'fatal: You are not currently on a branch.')
    assert(not match(command))


# Generated at 2022-06-26 06:21:33.896756
# Unit test for function match
def test_match():
    assert match(Command('git remote add origin git@github.com:nvie/gitflow.git',
                         "fatal: remote origin already exists."))
    assert not match(Command('git rm file.txt', ''))


# Generated at 2022-06-26 06:21:53.326482
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm dir1')
    assert get_new_command(command) == 'git rm -r dir1'

    command = Command('git rm dir1 dir2')
    assert get_new_command(command) == 'git rm -r dir1 dir2'

# Generated at 2022-06-26 06:22:02.240420
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', '')) == 'git rm -r'
    assert get_new_command(Command('git rm', '')) == 'git rm -r'
    assert get_new_command(Command('git rm -rf', '')) == 'git rm -rf'
    assert get_new_command(Command('git rm -f', '')) == 'git rm -f'
    assert get_new_command(Command('git rm -fv', '')) == 'git rm -fv'
    assert get_new_command(Command('git rm -rfv', '')) == 'git rm -rfv'



# Generated at 2022-06-26 06:22:06.398523
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.py', '', ''))
    assert not match(Command('git rm hello.py', 'fatal: pathspec hello.py\
 did not match any files', ''))


# Generated at 2022-06-26 06:22:09.229479
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', '')) == 'git rm -r file'

# Generated at 2022-06-26 06:22:12.532687
# Unit test for function match
def test_match():
    match_result=match(command=Command(script='git rm -r'))
    assert match_result==False



# Generated at 2022-06-26 06:22:17.909286
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf a_directory')
    assert (get_new_command(command)
            == 'git rm -rf -r a_directory')
    command = Command('git rm -rf a_directory/')
    assert (get_new_command(command)
            == 'git rm -rf -r a_directory/')

# Generated at 2022-06-26 06:22:25.374508
# Unit test for function match
def test_match():
    assert match(Command("git rm -f /home/user/Downloads",
            "fatal: not removing '/home/user/Downloads' recursively without -r", ""))


# Generated at 2022-06-26 06:22:27.592272
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f file.txt')
    assert get_new_command(command) == 'git rm -f -r file.txt'

# Generated at 2022-06-26 06:22:31.413019
# Unit test for function match
def test_match():
    get_new_command.commands = ['git rm foo']
    assert(match(get_new_command) != None)


# Generated at 2022-06-26 06:22:37.750168
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_not_removing_recursively import get_new_command
    command = Command('git rm -f log',
                      'fatal: not removing \'log\' recursively without -r\n')
    assert get_new_command(command) == "git rm -f -r log"

# Generated at 2022-06-26 06:23:09.281710
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo', 'fatal: not removing \'bar\' recursively without -r'))
    assert match(Command('git rm foo', 'fatal: not removing \'bar\' recursively without -r'))


# Generated at 2022-06-26 06:23:11.294939
# Unit test for function get_new_command

# Generated at 2022-06-26 06:23:16.113718
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -f foo',
                      stdout="fatal: not removing 'foo/bar' recursively without -r\n")
    assert get_new_command(command) == "git rm -f -r foo"

# Generated at 2022-06-26 06:23:17.998340
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf .')
    assert(get_new_command(command) == 'git rm -rf -r .')

# Generated at 2022-06-26 06:23:25.202893
# Unit test for function get_new_command
def test_get_new_command():
    if __name__ == '__main__':
        from os import system
        system("git init")
        system("echo foo >bar")
        system("git add bar")
        system("git commit -m bar")
        system("git rm bar")
        output = system("git rm bar -r")
        assert output == 0


enabled_by_default = True

# Generated at 2022-06-26 06:23:27.623296
# Unit test for function match
def test_match():
    command = Command(" rm -d src/app -rf lib/; exit")
    assert match(command)



# Generated at 2022-06-26 06:23:29.483780
# Unit test for function match
def test_match():
    command = Command('my git command')
    assert match(command)

# Generated at 2022-06-26 06:23:33.082811
# Unit test for function match
def test_match():
    assert git.match('git rm fse')
    assert not git.match('git rm fs')
    assert not git.match('git rm')


# Generated at 2022-06-26 06:23:36.580771
# Unit test for function match
def test_match():
    assert match(Command('', '', 'fatal: not removing \'file\' recursively without -r', ''))


# Generated at 2022-06-26 06:23:38.964211
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git mv file dir/', 'fatal: not removing \'file\' recursively without -r')) == 'git mv -r file dir/'


# Generated at 2022-06-26 06:24:48.247686
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git rm folder',
        'fatal: not removing \'folder\' recursively without -r', '')) == 'git rm -r folder'
    assert get_new_command(Command('sudo git rm folder',
        'fatal: not removing \'folder\' recursively without -r', '')) == 'sudo git rm -r folder'

# Generated at 2022-06-26 06:24:53.720734
# Unit test for function get_new_command
def test_get_new_command():
    git_rm_recursively_without_r_cmd = Command("git rm ")
    git_rm_recursively_without_r_cmd.script_parts = ['git', 'rm']
    git_rm_recursively_without_r_cmd.output = "... fatal: not removing ...' recursively without -r ..."

    assert get_new_command(git_rm_recursively_without_r_cmd) == "git rm -r"

# Generated at 2022-06-26 06:24:56.476644
# Unit test for function get_new_command
def test_get_new_command():
    output = 'fatal: not removing \'file/\' recursively without -r'
    command = Command("git rm file/", output)
    assert get_new_command(command) == u"git rm -r file/"

# Generated at 2022-06-26 06:25:02.924238
# Unit test for function match
def test_match():
    output = WrongOptions(command='rm --dry-run spam',
                          error='fatal: not removing \'spam\' recursively without -r')

    assert match(output)

    output = WrongOptions(command='git rm --dry-run spam',
                          error='fatal: not removing \'spam\' recursively without -r')

    assert match(output)

    output = WrongOptions(command='rm --dry-run spam',
                          error='fatal: not removing \'spam\'')
    assert not match(output)

    output = WrongOptions(command='git -c color.status=always status',
                          error='fatal: not removing \'spam\'')
    assert not match(output)

# Generated at 2022-06-26 06:25:10.285583
# Unit test for function match
def test_match():
	test_command1=Command('git rm -r test/', 'fatal: not removing \'test/\' recursively without -r\n')
	test_command2=Command('git rm test/', 'fatal: not removing \'test/\' recursively without -r\n')
	test_command3=Command('git rm test/', 'fatal: not removing \'test/\' recursively without -r')
	assert match(test_command1)
	assert match(test_command2)
	assert not match(test_command3)


# Generated at 2022-06-26 06:25:19.554830
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test', 'fatal: not removing test')) == 'git rm -r test'
    assert get_new_command(Command('git rm test/', 'fatal: not removing test/')) == 'git rm -r test/'
    assert get_new_command(Command('git rm -f test', 'fatal: not removing test')) == 'git rm -f -r test'
    assert get_new_command(Command('git rm --cached test', 'fatal: not removing test')) == 'git rm --cached -r test'
    assert get_new_command(Command('rm test', 'fatal: not removing test')) == 'rm -r test'

# Generated at 2022-06-26 06:25:22.530726
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = 'git rm no_such_folder', output = "fatal: not removing 'no_such_folder' recursively without -r")
    assert get_new_command(command) == "git rm -r no_such_folder"

# Generated at 2022-06-26 06:25:25.465357
# Unit test for function match
def test_match():
    assert match(Command('git rm foo'))
    assert not match(Command('rm foo'))
    assert not match(Command('git add foo'))

# Generated at 2022-06-26 06:25:27.997912
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm file.txt',
                                   output='fatal: not removing \'file.txt\' recursively without -r')) == 'git rm -r file.txt'

# Generated at 2022-06-26 06:25:29.310242
# Unit test for function match
def test_match():
    assert match( Command(' git rm -rf .'))

