

# Generated at 2022-06-26 06:18:12.258589
# Unit test for function get_new_command
def test_get_new_command():
    error = "fatal: not removing 'Directory/' recursively without -r"
    command = Command('git rm -rf Directory', error)
    assert get_new_command(command) == 'git rm -rf -r Directory'
    command = Command('git rm -f --cached Directory', error)
    assert get_new_command(command) == 'git rm -f -r --cached Directory'


# Generated at 2022-06-26 06:18:23.936616
# Unit test for function match
def test_match():
    assert match(Command('echo one two', 'error: pathspec \'one\' did not match any file(s) known to git.\n'))
    assert not match(Command('echo one two', 'error: pathspec \'one\' did not match any file(s) known to git.'))
    assert not match(Command('echo one two', 'error:'))
    assert match(Command('git rm -r one', 'fatal: not removing \'one\' recursively without -r\n'))
    assert not match(Command('git rm -r one', 'fatal: not removing \'one\' recursively without -r'))
    assert not match(Command('git rm -r one', 'fatal:'))
    assert match(Command('git rm one', 'fatal: not removing \'one\' recursively without -r\n'))

# Generated at 2022-06-26 06:18:32.771633
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git rm lulz') == u'git rm -r lulz'
    assert get_new_command(u'git rm -rf lulz') == u'git rm -rf -r lulz'
    assert get_new_command(u'git rm -r lulz') == u'git rm -r lulz'
    assert get_new_command(u'git rm -r') == u'git rm -r'
    assert get_new_command(u'git rm') == u'git rm'

# Generated at 2022-06-26 06:18:36.457760
# Unit test for function get_new_command
def test_get_new_command():
    int_0 = -3042
    var_0 = match(int_0)
    if var_0:
        var_1 = get_new_command(int_0)
        return var_1


# Generated at 2022-06-26 06:18:39.970915
# Unit test for function match
def test_match():
    assert match(Command('rm -rf folder', 'fatal: not removing \'folder\' recursively without -r'))
    assert not match(Command('ls -alh', 'fatal: not removing \'folder\' recursively without -r'))



# Generated at 2022-06-26 06:18:42.078758
# Unit test for function match
def test_match():
    assert match(Command(script='git rm b',
                         stderr='fatal: not removing \'b\' recursively without -r\n'))



# Generated at 2022-06-26 06:18:45.556474
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', 'fatal: not removing \'subfolder\' recursively without -r', '', '')) == 'git rm -r -r'

# Generated at 2022-06-26 06:18:48.440506
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'
    asse

# Generated at 2022-06-26 06:18:53.820806
# Unit test for function match
def test_match():
    assert match('rm file')
    assert not match('rm file', 'Not removing')
    assert not match('rm file', 'fatal: not removing without -r')
    assert not match('rm file', 'fatal: not removing recursively without -r')
    assert match('git rm file', 'fatal: not removing recursively without -r')


# Generated at 2022-06-26 06:18:56.186004
# Unit test for function get_new_command

# Generated at 2022-06-26 06:18:59.164949
# Unit test for function match
def test_match():
    assert (match == 'var_0')


# Generated at 2022-06-26 06:19:03.076949
# Unit test for function match
def test_match():
    assert match(Command(script='git clone', output="cloning into ''.."))
    assert match(Command(script='git rm file', output="fatal: not removing 'file' recursively without -r"))
    assert not match(Command(script='git status', output="nothing to commit, working directory clean"))


# Generated at 2022-06-26 06:19:04.686423
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(0) == 1

# Generated at 2022-06-26 06:19:07.124999
# Unit test for function match
def test_match():
    assert match('') == False
    assert match('git rm test.py -r') == True


# Generated at 2022-06-26 06:19:08.129221
# Unit test for function match
def test_match():
    int_0 = -3042
    var_0 = match(int_0)


# Generated at 2022-06-26 06:19:08.915988
# Unit test for function match
def test_match():
    assert match(0)
    assert not match(1)


# Generated at 2022-06-26 06:19:11.785116
# Unit test for function get_new_command
def test_get_new_command():
    int_0 = -3042
    string_var_0 = get_new_command(int_0)
    if string_var_0 is not None:
        assert string_var_0 is not None
    


# Generated at 2022-06-26 06:19:17.382460
# Unit test for function get_new_command
def test_get_new_command():
    int_0 = -6083
    self_0 = GitCommand(script='git rm -qf test/file', output='fatal: not removing \'test/file\'')
    str_0 = get_new_command(self_0)


# Generated at 2022-06-26 06:19:20.354481
# Unit test for function match
def test_match():
    var_0 = match(3057)
    var_1 = match(3058)

    assert var_0 != var_1


# Generated at 2022-06-26 06:19:27.161996
# Unit test for function match
def test_match():
    command = Command('git rm -r ./app/controllers/api/v1/base_controller.rb',
        'fatal: not removing \'./app/controllers/api/v1/base_controller.rb\' recursively without -r')
    assert match(command)


# Generated at 2022-06-26 06:19:32.758922
# Unit test for function match
def test_match():
    assert match(Command('git rm file1.txt file2.txt',
                   'fatal: not removing \'file2.txt\' recursively without -r\n'))
    assert not match(Command('git rm file1.txt file2.txt', 'not a real output'))


# Generated at 2022-06-26 06:19:35.573448
# Unit test for function match
def test_match():
    assert match(Command('git rm non_existent_file',
    'fatal: not removing \'non_existent_file\' recursively without -r\n'))
    assert not match(Command('git rm non_existent_file',
    'fatal: pathspec \'non_existent_file\' did not match any files\n'))


# Generated at 2022-06-26 06:19:41.057945
# Unit test for function match
def test_match():
    assert match(Command('asdf', 'asdf', 'fatal: not removing \'asdf\' recursively without -r'))
    assert not match(Command('asdf', 'asdf', 'fatal: not removing \'asdf\' recursively without -r'))

# Generated at 2022-06-26 06:19:52.124893
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
    'fatal: not removing \'foo\' recursively without -r', ""))
    assert not match(Command('git rm foo', '', ""))
    assert match(Command('git rm -f foo',
    'fatal: not removing \'foo\' recursively without -r', ""))
    assert not match(Command('git rm -f foo/', '', ""))
    assert not match(Command('git rm -f foo/bar/', '', ""))
    assert not match(Command('git rm -rf foo/', '', ""))
    assert not match(Command('git rm -rf foo/bar/', '', ""))


# Generated at 2022-06-26 06:20:01.399285
# Unit test for function match
def test_match():
    # Valid input with matches
    result = match(Command('git rm foo/'))
    assert result
    result = match(Command('git rm -r foo/'))
    assert not result

    # input without matches
    result = match(Command('git rm'))
    assert not result


# Generated at 2022-06-26 06:20:08.562004
# Unit test for function match
def test_match():
    assert match(Command("git rm -r app/views/user/registrations"))
    assert not match(Command("git rm app/views/user/registrations"))
    assert not match(Command("git rm"))
    assert not match(Command("git rm -r"))
    assert not match(Command("rm -r"))


# Generated at 2022-06-26 06:20:12.292659
# Unit test for function match
def test_match():
    assert match(Command('git rm -r *', 'fatal: not removing '
                         '\'*\' recursively without -r'))
    assert not match(Command('git diff', ''))

# Generated at 2022-06-26 06:20:16.073480
# Unit test for function get_new_command
def test_get_new_command():
    command = "git rm -r --cached file/directory"
    new_command = "git rm -r -r --cached file/directory"
    assert get_new_command(Command(command, "")) == new_command

# Generated at 2022-06-26 06:20:19.381279
# Unit test for function match
def test_match():
    assert match(Command('git rm abc', 'fatal: not removing \'abc\' recursively without -r'))
    assert not match(Command('git ls', 'fatal: not removing \'abc\' recursively without -r'))
    assert not match(Command('git rm abc', ''))



# Generated at 2022-06-26 06:20:30.458942
# Unit test for function match
def test_match():
    assert not match(Command('rm file', "Not a git repository"))
    assert not match(Command('rm file', "fatal: not removing 'foo' recursively without -r"))
    assert not match(Command('rm file', "fatal: not removing 'foo' recursively without -r\n"))
    assert not match(Command('git rm file', "fatal: not removing 'foo' recursively without -r"))
    assert match(Command('rm file', "fatal: not removing 'foo' recursively without -r\n"))
    assert match(Command('rm file', "fatal: not removing 'foo' recursively without -r\n",
                          'git rm file', 'r'))



# Generated at 2022-06-26 06:20:41.769284
# Unit test for function match
def test_match():
    assert match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r'))
    assert match(Command('git rm .', '', 'fatal: not removing \'.\' recursively without -r'))
    assert match(Command('git rm -rf .', '', 'fatal: not removing \'file\' recursively without -r'))



# Generated at 2022-06-26 06:20:44.330948
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file.txt') == 'git rm -r file.txt'

# Generated at 2022-06-26 06:20:49.414564
# Unit test for function match
def test_match():
    assert match(Command('git rm test', ''))
    assert not match(Command('git rm test', '', stderr='fatal: not removing '))
    assert not match(Command('git rm test', '', stderr='fatal: not removing recursively'))


# Generated at 2022-06-26 06:20:58.838898
# Unit test for function match
def test_match():
    output = "[master 89a36ca] tag commit\n 1 file changed, 0 insertions(+), 0 deletions(-)\nOn branch master\nnothing to commit, working tree clean\n\n"
    command = Command("git add .; git commit -m tag commit;git rm -rf  bbb",output)
    assert not match(command)
    command = Command("git add .; git commit -m tag commit;git rm -rf  bbb",output+"fatal: not removing 'bbb' recursively without -r\n")
    assert match(command)



# Generated at 2022-06-26 06:21:08.879202
# Unit test for function match
def test_match():
    assert match(Command('git rm -r retry'))
    assert not match(Command('git rm -r retry', 'fatal: not removing'))
    assert not match(Command('git rm -r retry', 'fatal: not removing', '-'))
    assert not match(Command('git rm -r retry', 'fatal: not removing', 'recursively without'))
    assert not match(Command('git rm -r retry', 'fatal: not removing', 'recursively without -r'))


# Generated at 2022-06-26 06:21:20.629234
# Unit test for function match
def test_match():
    assert git_support(Command('git rm file1 file2 file3'
                              , 'fatal: not removing \'file1\' recursively without -r'
                              , ''))
    assert git_support(Command('git rm file1 file2 file3'
                              , 'fatal: not removing \'file2\' recursively without -r'
                              , ''))
    assert git_support(Command('git rm file1 file2 file3'
                              , 'fatal: not removing \'file3\' recursively without -r'
                              , ''))
    assert git_support(Command('git rm file1 file2 file3'
                              , 'fatal: not removing \'file5\' recursively without -r'
                              , ''))

# Generated at 2022-06-26 06:21:22.913086
# Unit test for function match
def test_match():
    for command_script in ['rm index.html',
                           'rm -v index.html',
                           'rm --cached index.html']:
        command = Command(command_script, '')
        assert match(command)



# Generated at 2022-06-26 06:21:27.971628
# Unit test for function match
def test_match():
    assert match(Command('git rm test',
                 'fatal: not removing \'test\' recursively without -r',
                 '', 1))
    assert match(Command('git rm -a test',
                 'fatal: not removing \'test\' recursively without -r',
                 '', 1))
    assert not match(Command('rm test',
                 'fatal: not removing \'test\' recursively without -r',
                 '', 1))


# Generated at 2022-06-26 06:21:40.430709
# Unit test for function get_new_command
def test_get_new_command():
    script_part = u'rm'
    test_1 = u'git rm -r folder'
    test_2 = u'git rm folder'
    test_3 = u'git rm -r -r folder'
    test_4 = u'git rm -r --cached folder'
    test_5 = u'git rm -r -cached folder'
    test_6 = u'git rm -r --recursive folder'
    test_7 = u'git rm -r -recursive folder'
    test_8 = u'git rm -r folder1 -r folder2'
    test_9 = u'git rm folder1 -r folder2'
    test_10 = u'git rm -r folder1 folder2'
    test_11 = u'git rm folder1 folder2'
    

# Generated at 2022-06-26 06:21:47.047484
# Unit test for function get_new_command
def test_get_new_command():
    output = "fatal: not removing 'path/file.txt' recursively without -r"
    script = "git rm path/file.txt"
    command = type('Command', (), {'output': output,
                                   'script': script,
                                   'script_parts': script.split()})

    assert(get_new_command(command) == u"git rm -r path/file.txt")

# Generated at 2022-06-26 06:22:03.977716
# Unit test for function match
def test_match():
	assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
	assert not match(Command('git rm file', 'fatal: not removing \'file\''))
	assert not match(Command('rm file', 'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-26 06:22:07.850681
# Unit test for function match
def test_match():
    assert match(Command(' git rm foo',
                         'fatal: not removing \'foo\' recursively without -r',
                         ''))
    assert not match(Command(' git rm foo',
                         'fatal: not removing \'foo\' recursively without -r',
                         '',
                         None,
                         '/bin/git'))

# Generated at 2022-06-26 06:22:09.520837
# Unit test for function match
def test_match():
	output = 'fatal: not removing \'pyenv.log\' recursively without -r'
	assert match(command('rm pyenv.log', output))


# Generated at 2022-06-26 06:22:14.214762
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm dir1', "fatal: not removing 'dir1' recursively without -r\n")
    assert get_new_command(command) == "git rm -r dir1"

# Generated at 2022-06-26 06:22:20.836378
# Unit test for function match
def test_match():
    command = Command('git rm README.md', 'fatal: not removing \'README.md\' recursively without -r')
    assert match(command)

    command = Command('git rm README.md', 'fatal: not removing \'README.md\' recursively without -r\n')
    assert match(command)

    command = Command('git rm README.md', 'fatal: not removing \'README.md\' recursively without -r')
    assert not match(command)

    command = Command('git remove README.md', 'fatal: not removing \'README.md\' recursively without -r')
    assert not match(command)


# Generated at 2022-06-26 06:22:28.146041
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == u'git rm -r -r'
    assert get_new_command(Command('git rm -r --cached index.html')) == u'git rm -r -r --cached index.html'
    assert get_new_command(Command('git rm -rf --cached index.html')) == u'git rm -r -rf --cached index.html'

# Generated at 2022-06-26 06:22:34.963301
# Unit test for function get_new_command
def test_get_new_command():
    command_test = "git rm file1.txt"
    error_message = "fatal: not removing 'file1.txt' recursively without -r"
    command = Command(command_test, error_message)
    new_command = get_new_command(command)
    assert "git rm -r file1.txt" == new_command

# Generated at 2022-06-26 06:22:38.653521
# Unit test for function match
def test_match():
    assert match(Command('git rm \"*.png\"',
                         output="fatal: not removing '*.png' recursively without -r\n"))
    assert not match(Command('git rm \"*.png\"', output='ok'))
    assert not match(Command('git rm \"*.png\"', output=''))
    

# Generated at 2022-06-26 06:22:43.610497
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r'
    assert get_new_command(Command('git rm file')) == 'git rm -r file'

# Generated at 2022-06-26 06:22:50.429852
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', 'rm', 'test']
    index = command_parts.index('rm') + 1
    command_parts.insert(index, '-r')
    assert get_new_command(command_parts) == 'git rm -r test'

# Generated at 2022-06-26 06:23:16.247833
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-26 06:23:18.563589
# Unit test for function get_new_command
def test_get_new_command():
    # Test get_new_command function
    from thefuck.types import Command

    command = Command('git rm -r')
    assert get_new_command(command) == 'git rm -r -r'

# Generated at 2022-06-26 06:23:24.540298
# Unit test for function match
def test_match():
    assert match(Command('git commit',
        output="fatal: not removing 't/UpdateTest/screenshots/posts/' recursively without -r"))
    assert not match(Command('git commit',
        output='fatal: some kind of failure'))


# Generated at 2022-06-26 06:23:30.638012
# Unit test for function get_new_command
def test_get_new_command():
    context = Context(script='git rm file', output='fatal: not removing "file" recursively without -r', env={})
    result = get_new_command(Command(script='git rm file', env=context.env))
    assert result == 'git rm -r file'

    context = Context(script='', output='fatal: not removing "file" recursively without -r', env={})
    result = get_new_command(Command(script='git rm file', env=context.env))
    assert result == 'git rm -r file'


# Generated at 2022-06-26 06:23:33.258909
# Unit test for function match
def test_match():
    assert match(Command(script='git status', output='fatal: not removing \'bin\' recursively without -r'))
    assert not match(Command(script='git status', output='fatal: not removing \'bin\' recursively with -r'))
    assert not match(Command(script='git status', output='git status'))

# Generated at 2022-06-26 06:23:36.800585
# Unit test for function get_new_command
def test_get_new_command():
	command = Command("git rm werwer", "")

	assert(get_new_command(command) == "git -r rm werwer")

# Generated at 2022-06-26 06:23:41.997158
# Unit test for function match
def test_match():
    command = 'git rm -r c_cs171_3'
    assert match(Command(script=command, output='fatal: not removing \'c_cs171_3/\' recursively without -r'))
    assert not match(Command(script=command, output='fatal: not removing \'c_cs171_3/\' recursively without -r\n'))
    command = 'git rm c_cs171_3'
    assert match(Command(script=command, output='fatal: not removing \'c_cs171_3\' recursively without -r'))


# Generated at 2022-06-26 06:23:47.206589
# Unit test for function get_new_command
def test_get_new_command():
    script = ["git", "rm", "README.txt"]
    output = "fatal: not removing 'README.txt' recursively without -r"
    command = Command(script, output)
    assert get_new_command(command) == "git rm -r README.txt"

# Generated at 2022-06-26 06:23:54.921716
# Unit test for function match
def test_match():
    assert match(Command('git rm .directory'))
    assert not match(Command('git rm .directory',
                             stderr='fatal: pathspec\'.directory\' did not match any files'))
    assert not match(Command('git rm .directory',
                             stderr='fatal: not removing .directory recursively without -r'))



# Generated at 2022-06-26 06:23:57.289022
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r -f ./', '')) == 'git rm -r -f -r ./'

# Generated at 2022-06-26 06:24:52.949578
# Unit test for function match
def test_match():
    assert match(Command('git rm file_name',
                         'fatal: not removing \'file_name\' recursively without -r'))
    assert not match(Command('git rm file_name', 'fatal: not removing \'file_name\''))
    assert not match(Command('git commit', 'fatal: not removing \'file_name\''))



# Generated at 2022-06-26 06:24:56.753154
# Unit test for function match
def test_match():
    assert match(Command(script="git rm f",
    output='fatal: not removing \'f\' recursively without -r'))
    
    assert not match(Command(script="git rm f",
    output='fatal: not removing \'f\' recursively without -r'))


# Generated at 2022-06-26 06:24:59.300924
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r',
                         stderr='fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-26 06:25:07.154170
# Unit test for function match
def test_match():
    # If the word 'rm' is not in the script, then this should return false
    script = 'git push master'
    output = 'fatal: not removing \'file\' recursively without -r\ndo not force push unless you really have to \n\n'
    command = Command(script, output)
    assert not match(command)
    # If the script does not have the word 'rm', then this should return false
    script = 'git push master'
    output = 'fatal: not removing \'file\' recursively without -r\ndo not force push unless you really have to \n\n'
    command = Command(script, output)
    assert not match(command)
    # If the output does not have the string "fatal: not removing", this should return false
    script = 'git rm file'

# Generated at 2022-06-26 06:25:10.193745
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm folder', '', 'fatal: not removing \'folder/\' recursively without -r')) == 'git rm -r folder'

# Generated at 2022-06-26 06:25:12.448852
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test/')) == u'git rm -r test/'


# Generated at 2022-06-26 06:25:14.584547
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf file',
                         'fatal: not removing \'file\' recursively without -r'))

# Generated at 2022-06-26 06:25:18.223541
# Unit test for function match
def test_match():
    assert match(Command('git rm dfs', '', 'fatal: not removing \'dfs\''))
    assert not match(Command('git rm dfs', '', ''))
    assert not match(Command('git rm dfs', '', 'fatal: not removing \'dffs\''))



# Generated at 2022-06-26 06:25:20.144590
# Unit test for function match
def test_match():
    assert match(Command('git rm nathan',
                'fatal: not removing \'nathan\' recursively without -r\n',
                ''))


# Generated at 2022-06-26 06:25:22.326879
# Unit test for function match
def test_match():
    assert match(Command(script=' git rm -rf'))
    assert not match(Command(script=' git rm'))


# Generated at 2022-06-26 06:27:15.440931
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r test' == gget_new_command(Command(script=u'git rm test', output='fatal: not removing \'test\' recursively without -r'))

# Generated at 2022-06-26 06:27:17.274798
# Unit test for function match
def test_match():
    assert match(Command('rm file1.txt', 'fatal: not removing \'file1.txt\' recursively without -r'))
    assert not match(Command("git rm 'file1.txt'", ''))

# Generated at 2022-06-26 06:27:19.349516
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'
    assert get_new_command('git rm -r file') == 'git rm -r file'

# Generated at 2022-06-26 06:27:20.664314
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command("git rm folder/")
    assert "git rm -r folder/" == new_cmd


# Generated at 2022-06-26 06:27:22.495355
# Unit test for function match
def test_match():
    command = Mock(script='git rm folder', output="fatal: not removing 'folder' recursively without -r")
    assert match(command)


# Generated at 2022-06-26 06:27:24.948398
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r ') == 'git rm -r -r'
    assert get_new_command('git rm') == 'git rm -r'

# Generated at 2022-06-26 06:27:28.129201
# Unit test for function match
def test_match():
    assert match(Command(script = 'git rm a.txt', 
                        output = 'fatal: not removing \'a.txt\' recursively without -r')) 
    assert not match(Command(script = 'git rm a.txt', 
                        output = "Couldn't remove 'a.txt'")) 



# Generated at 2022-06-26 06:27:29.677798
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf'))


# Generated at 2022-06-26 06:27:35.039169
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='rm -f test/.git/test',
                      output=u"fatal: not removing 'test/.git/test' recursively without -r\n"
                             u"use '-f' to force")
    assert get_new_command(command) == 'git rm -r -f test/.git/test'

# Generated at 2022-06-26 06:27:42.864135
# Unit test for function get_new_command
def test_get_new_command():
    import os
    os.system("mkdir test")
    os.chdir("test")
    os.system("git init")
    os.system("mkdir dir1")
    os.system("mkdir dir2 dir3 dir4")
    os.system("touch file1 file2 file3 file4")
    os.system("git add file2 file3")
    from thefuck.rules.fuck_git_rm import get_new_command, match
    from thefuck.types import Command
    command1 = Command("git rm file1 file4 dir1 dir4", "fatal: not removing 'file1' recursively without -r", "git rm file1 file4 dir1 dir4")
    assert get_new_command(command1) == "git rm -r file1 file4 dir1 dir4"