

# Generated at 2022-06-26 06:18:13.333117
# Unit test for function match
def test_match():
    true_var_0 = True
    true_var_1 = False
    str_0 = 'git rm --cached README.md'
    str_1 = 'git rm --cached README.md'
    var_0 = 'fatal: not removing \'README.md\' recursively without -r'
    var_1 = 'fatal: not removing \'README.md\' recursively without -r'
    str_2 = 'git rm --cached README.md'
    str_3 = 'git rm --cached README.md'
    var_2 = ''
    var_3 = 'fatal: not removing \'README.md\' recursively without -r'
    str_4 = 'git rm -f README.md'
    str_5 = 'git rm -f README.md'

# Generated at 2022-06-26 06:18:15.970041
# Unit test for function match
def test_match():
    assert match(str_0) == bool_0


# Generated at 2022-06-26 06:18:24.909760
# Unit test for function match
def test_match():
    err = Exception("match(command)")
    assert match(err) == False, "match returned None!"
    assert match("rm: cannot remove 'hbqid': No such file or directory") == False
    assert match("fatal: not removing 'hbqid' recursively without -r") == False
    assert match("git rm 'hbqid': No such file or directory fatal: not removing 'hbqid' recursively without -r") == True


# def test_get_new_command():
#     err = Exception("get_new_command(command)")
#     assert get_new_command(err) == False, "get_new_command returned None!"
#     assert get_new_command("git rm 'hbqid': No such file or directory fatal: not removing 'hbqid' recursively without

# Generated at 2022-06-26 06:18:32.387021
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = Command('git rm abc', 'fatal: not removing \'abc\' recursively without -r\n')
    str_1 = Command('git rm abc', 'fatal: not removing \'abc\' recursively without -r\n')
    assert get_new_command(str_0) == 'git rm -r abc'
    assert get_new_command(str_1) == 'git rm -r abc'

# Generated at 2022-06-26 06:18:35.770778
# Unit test for function match
def test_match():
    str_0 = 'M\thbqid'
    var_0 = match(str_0)

# Generated at 2022-06-26 06:18:37.741386
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command() == 'git rm -r'

# Generated at 2022-06-26 06:18:42.412384
# Unit test for function get_new_command
def test_get_new_command():
    str_1 = "fatal: not removing '"
    var_1 = get_new_command(str_1)
    if var_1 != "fatal: not removing '-r":
        print('FAIL:get_new_command')
    else:
        print('OK:get_new_command')


# Generated at 2022-06-26 06:18:45.908362
# Unit test for function get_new_command
def test_get_new_command():
    assert '-r' in get_new_command('git rm -r c')
    assert '--r' in get_new_command('git rm --r c')



# Generated at 2022-06-26 06:18:54.096805
# Unit test for function match
def test_match():
    assert match('fatal: not removing \'a\' recursively without -r')
    assert match('git rm a')
    assert match('git rm a b')
    assert match('git rm a b c')
    assert not match('rm a b')
    assert match('fatal: not removing \'a/b\' recursively without -r')
    assert match('git rm a/b')
    assert match('git rm a/b c/d')
    assert not match('rm a/b c/d')
    return True



# Generated at 2022-06-26 06:18:58.186444
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'git rm -f'
    var_0 = get_new_command(str_0)
    assert var_0 == 'git rm -rf -f'

# Generated at 2022-06-26 06:19:01.370260
# Unit test for function match
def test_match():
    var_0 = match()


# Generated at 2022-06-26 06:19:06.734108
# Unit test for function match
def test_match():
    import sys, inspect
    var_0 = False
    var_0 = None
    var_0 = False
    var_0 = None
    var_0 = True
    var_0 = None
    var_0 = False
    return var_0


# Generated at 2022-06-26 06:19:09.634812
# Unit test for function match
def test_match():
    var_0 = _git_support()
    var_1 = unittest.mock.MagicMock()


# Generated at 2022-06-26 06:19:14.731544
# Unit test for function match
def test_match():

    # Test 0
    # Provided by 
    var_0 = '''echo "hi"'''

    # Test 1
    # Provided by 
    var_1 = '''pkg_version -v -I'''

    # Test 2
    # Provided by 
    var_2 = '''pkginfo -l SUNWcit'''

    # Test 3
    # Provided by 
    var_3 = '''pkgchk -l -p -d . SUNWwpd'''

    # Test 4
    # Provided by 
    var_4 = '''pkginfo -x SUNWcit'''

    # Test 5
    # Provided by 
    var_5 = '''pkgchk -l -p -d . SUNWi1of'''

    # Test 6
    # Provided by 

# Generated at 2022-06-26 06:19:23.900891
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Script(u'git rm -r dir/', None, Command('git rm -r dir/', '', 'fatal: not removing \'dir/subdir\' recursively without -r\n', [u'git rm -r dir/subdir'], u'', u'', '', '', '', '', '', '', ''))) == u'git rm -r -r dir/'
    assert get_new_command(Script(u'git rm -r dir', None, Command('git rm -r dir', '', 'fatal: not removing \'dir/subdir\' recursively without -r\n', [u'git rm -r dir/subdir'], u'', u'', '', '', '', '', '', '', ''))) == u'git rm -r -r dir'
    assert get_

# Generated at 2022-06-26 06:19:27.888750
# Unit test for function get_new_command
def test_get_new_command():
    # Assume
    command = "git rm"

    # Action
    actual = get_new_command(command)

    # Assert
    assert actual == "git rm -r"

# Generated at 2022-06-26 06:19:35.551048
# Unit test for function match
def test_match():
    pass

# Generated at 2022-06-26 06:19:36.791570
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm python/README.rst |') == 'git rm -r python/README.rst'

# Generated at 2022-06-26 06:19:39.960974
# Unit test for function match
def test_match():
    assert match(create_command()) == None
    assert match(create_command()) == None
    assert match(create_command()) == None


# Generated at 2022-06-26 06:19:44.128301
# Unit test for function match
def test_match():
    command = Command(script="git rm -rf /tmp/blah",
                      output="fatal: not removing '/tmp/blah' recursively without -r\n")
    assert match(command)



# Generated at 2022-06-26 06:19:49.182560
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command
    assert get_new_command('git rm') == 'git rm -r'
    assert get_new_command('git rm file1 file2') == 'git rm -r file1 file2'

# Generated at 2022-06-26 06:19:55.875451
# Unit test for function match
def test_match():
    assert match(Command(script="git branch -r --merged",
                         output="fatal: not removing 'origin/xxx' recursively without -r"))
    assert match(Command(script="git branch -r --merged",
                         output="fatal: not removing 'origin/xxx' and 'origin/aaa' recursively without -r"))
    assert not match(Command(script="git branch -r --merged",
                             output="fatal: not removing 'origin/xxx' recursively without -rr"))
    assert not match(Command(script="git branch -r --merged",
                             output="fatal: not removing 'origin/xxx' recursively without -r"))

# Generated at 2022-06-26 06:19:59.277714
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    new_command = get_new_command(Command('rm -r file',
                                          'fatal: not removing \'file\' recursively without -r\n', ''))
    assert new_command == 'rm -r -r file'

# Generated at 2022-06-26 06:20:03.050486
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test.py', '', 'fatal: not removing \'test.py\' recursively without -r')
    # get_new_command(command) should return git rm -r test.py
    assert get_new_command(command) == 'git rm -r test.py'

# Generated at 2022-06-26 06:20:08.223676
# Unit test for function match
def test_match():
    assert match(Command('git rm a',
                         'fatal: not removing \'a\' recursively without -r\n'))
    assert not match(Command('ls', ''))
#

# Generated at 2022-06-26 06:20:13.230790
# Unit test for function match
def test_match():
    assert match(u'git rm filename')
    assert match(u' git rm filename')
    assert match(u'git rm filename ')
    assert match(u'git rm filename')
    assert not match(u'git add filename')


# Generated at 2022-06-26 06:20:16.369469
# Unit test for function match
def test_match():
	assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r')) == True


# Generated at 2022-06-26 06:20:24.152285
# Unit test for function match
def test_match():
    # Test with a command without git
    assert match(Command('command', '')) == False
    # Test with command with git but not git rm command
    assert match(Command('git command', '')) == False
    # Test with a git rm command with no output
    assert match(Command('git rm file', '')) == False
    # Test with a git rm command with output but no rm error message
    assert match(Command('git rm file', 'error: file not found')) == False
    # Test with a git rm command with output and a rm error message
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n')) == True
    # Test with a git rm command with output and a rm error message but
    # with different spacing

# Generated at 2022-06-26 06:20:26.441866
# Unit test for function match
def test_match():
    assert match(Command('git rm a', '', 'fatal: not removing \'a\' recursively without -r'))
    assert not match(Command('git rm a', '', 'fatal: not removing \'a\' recursively with -r'))

# Generated at 2022-06-26 06:20:30.382383
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git add file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))



# Generated at 2022-06-26 06:20:44.003128
# Unit test for function get_new_command
def test_get_new_command():
    with patch('thefuck.rules.git.which', return_value=True):
        assert get_new_command(Command('git rm folder', '', '')) == 'git rm -r folder'
        assert get_new_command(Command('git rm -r folder', '', '')) == 'git rm -r folder'

# Generated at 2022-06-26 06:20:49.556455
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    script = "git rm dir"
    output = "fatal: not removing 'dir' recursively without -r"
    command = Command(script, output)
    new_command = get_new_command(command)
    assert new_command == "git rm -r dir"

# Generated at 2022-06-26 06:21:00.529416
# Unit test for function get_new_command
def test_get_new_command():
	new_command = get_new_command(Command('git rm -rf foo', 'fatal: not removing \'foo\' recursively without -r'))
	assert new_command == 'git rm -rf -r foo'
	new_command = get_new_command(Command('git rm -rf -- foo', 'fatal: not removing \'foo\' recursively without -r'))
	assert new_command == 'git rm -rf -- -r foo'
	new_command = get_new_command(Command('git rm -rf -- -f foo', 'fatal: not removing \'foo\' recursively without -r'))
	assert new_command == 'git rm -rf -- -f -r foo'

# Generated at 2022-06-26 06:21:05.523248
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm "file"', "fatal: not removing 'file' recursively without -r")) == \
                                                                                                        'git rm -r "file"'

# Generated at 2022-06-26 06:21:11.447086
# Unit test for function match
def test_match():
    assert match(Command('git rm *.pyc', '', '', 0, 'fatal: not removing \'*.pyc\' recursively without -r'))
    assert match(Command('git rm *', '', '', 0, 'fatal: not removing \'*.pyc\' recursively without -r'))
    assert not match(Command('git rm --cached *.pyc', '', '', 0, ''))



# Generated at 2022-06-26 06:21:21.811442
# Unit test for function match
def test_match():
    assert match(Command('git rm -f --ignore-unmatch /path/to/file',
            stderr='fatal: not removing /path/to/file recursively without -r'))
    assert not match(Command('git rm -f --ignore-unmatch /path/to/file',
            stderr='fatal: not removing /path/to/file recursively without -R'))
    assert match(Command('git rm -f --ignore-unmatch /path/to/file',
            stderr='fatal: not removing /path/to/file recursively without -r',
            re_stderr=r'fatal: not removing (.*) recursively without -r'))

# Generated at 2022-06-26 06:21:28.309250
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert (u'git rm -r foo' ==
            get_new_command(Command('git rm foo', '', '')))
    assert (u'git rm -r foo bar' ==
            get_new_command(Command('git rm foo bar', '', '')))
    assert (u'rm -r foo' ==
            get_new_command(Command('rm foo', '', '')))
    assert (u'rm -r foo bar' ==
            get_new_command(Command('rm foo bar', '', '')))
    assert (u'rm -r foo' ==
            get_new_command(Command('echo rm foo', '', '')))

# Generated at 2022-06-26 06:21:32.062146
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command.from_string('git rm foo')) == 'git rm -r foo'


# Generated at 2022-06-26 06:21:34.882260
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', '')) == u'git rm -r file'

# Generated at 2022-06-26 06:21:47.923173
# Unit test for function match
def test_match():
    import os
    import sys
    import tempfile
    from thefuck import shells
    from thefuck.rules.git_rm import match
    from thefuck.rules.git_rm import get_new_command

    fd, repo_path = tempfile.mkstemp()
    os.close(fd)
    git('init', repo_path)
    os.chdir(repo_path)
    touch('file.txt')
    git('add', 'file.txt')
    git('commit', '-m', 'Added file')

    assert match(Command(u'git rm file.txt', u'fatal: not removing \'file.txt\' recursively without -r', repo_path))

# Generated at 2022-06-26 06:21:57.892180
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm a', stderr="fatal: not removing 'a' recursively without -r")
    assert_equal(get_new_command(command), 'git rm -r a')

# Generated at 2022-06-26 06:22:02.305097
# Unit test for function match
def test_match():
    assert match(Command('rm -rf'))
    assert not match(Command('ls'))
    assert not match(Command('git rm'))
    assert not match(Command('ls -l'))


# Generated at 2022-06-26 06:22:08.348033
# Unit test for function match
def test_match():
    assert(match(Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r', '')) == True)
    assert(match(Command('git rm', 'fatal: not removing \'\' recursively without -r', '')) == True)
    assert(match(Command('git add', 'fatal: not removing \'\' recursively without -r', '')) == False)


# Generated at 2022-06-26 06:22:18.223444
# Unit test for function match
def test_match():
    assert match(Command('git rm -r a', 'fatal: not removing \'a\' recursively without -r'))
    assert not match(Command('git rm a', 'fatal: not removing \'a\' recursively without -r'))
    assert not match(Command('git rm -r a', 'not removing \'a\' recursively without -r'))
    assert not match(Command('git rm -r a', 'fatal: \'a\' recursively without -r'))
    assert not match(Command('rm a', 'fatal: not removing \'a\' recursively without -r'))

# Generated at 2022-06-26 06:22:23.559936
# Unit test for function match
def test_match():
    assert match(command=Command('git rm file/path/'))


# Generated at 2022-06-26 06:22:29.306873
# Unit test for function match
def test_match():
    assert match(Command('git rm a',
          output="fatal: not removing 'testfile2' recursively without -r"))
    assert not match(Command('git rm a',
          output="fatal: not removing 'testfile2' recursively without -r\n"))
    assert not match(Command('git rm a',
          output="fatal: not removing 'testfile2' recursively"))
    assert not match(Command('git rm -r a',
               output="fatal: not removing 'testfile2' recursively without -r"))



# Generated at 2022-06-26 06:22:34.199784
# Unit test for function match
def test_match():
    assert match(Command('git rm fuck'))
    assert not match(Command('git rm -r fuck'))
    assert not match(Command('git remote rm fuck'))
    assert not match(Command('git blah blah'))


# Generated at 2022-06-26 06:22:40.397378
# Unit test for function match
def test_match():
    command1 = Command('git rm -r src/tests', '', '/tmp/git')
    command2 = Command('git rm src/tests',
                       "fatal: not removing 'src/tests' recursively without -r",
                       '/tmp/git')
    command3 = Command('git rm --cached src/tests',
                       "fatal: not removing 'src/tests' recursively without -r",
                       '/tmp/git')
    command4 = Command('git rm src/tests',
                       '',
                       '/tmp/git')
    command5 = Command('git rm -rf src/tests',
                       "fatal: not removing 'src/tests' recursively without -r",
                       '/tmp/git')
    assert match(command1)
    assert match(command2)
    assert not match(command3)

# Generated at 2022-06-26 06:22:45.029753
# Unit test for function match
def test_match():
    assert match(Command('rm -rf', stderr="fatal: not removing 'new' recursively without -r"))
    assert not match(Command('rm -rf', stderr='fatal: not removing'))

# Generated at 2022-06-26 06:22:48.912675
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('echo', 'fatal: not removing \'.git\' recursively without -r')
    assert get_new_command(command) == 'rm -r .git'


enable_support = not shutil.which('git') is None

# Generated at 2022-06-26 06:23:10.210676
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2', '', ''))
    assert match(Command('git rm file1 file2', 'fatal: not removing \'file1\' recursively without -r', ''))
    assert not match(Command('git rm file1 file2', '', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git rm file1 file2', 'fatal: not removing \'file1\' recursively without -f', ''))


# Generated at 2022-06-26 06:23:19.142697
# Unit test for function match
def test_match():
    assert match(Command('rm foo', '', ''))
    assert match(Command('git foo', '', ''))
    assert match(Command('git rm foo', '', ''))
    assert match(Command('git rm foo', '', ''))
    assert not match(Command('git rm', '', ''))
    assert not match(Command('rm', '', ''))
    assert not match(Command('git foo',
                             'fatal: not removing \'bar\' recursively without -r', ''))
    assert not match(Command('git foo',
                             'fatal: not removing \'bar\' recursively without -r', ''))


# Generated at 2022-06-26 06:23:30.421874
# Unit test for function match
def test_match():
    # Test that match function works for case of git rm <file_name>
    assert match(Command('git rm hello.txt', 'fatal: not removing \'hello.txt\' recursively without -r'))
    # Test that match function works for case of git rm -f <file_name>
    assert match(Command('git rm -f hello.txt', 'fatal: not removing \'hello.txt\' recursively without -r'))
    # Test that match function works for case of git rm --cached <file_name>
    assert match(Command('git rm --cached hello.txt', 'fatal: not removing \'hello.txt\' recursively without -r'))
    # Test that match function works for case of git rm -rf <dir_name>

# Generated at 2022-06-26 06:23:32.517689
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf foo/bar', 'fatal: not removing \'foo/bar\' recursively without -r')
    assert get_new_command(command) == 'git rm -rf -r foo/bar'

# Generated at 2022-06-26 06:23:35.995184
# Unit test for function match
def test_match():
    assert match(Command('git rm my_file',
                         'fatal: not removing \'my_file\' recursively without -r'))


# Generated at 2022-06-26 06:23:38.443757
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')
    assert get_new_command(command) == 'git rm -r foo'

# Generated at 2022-06-26 06:23:44.651931
# Unit test for function match
def test_match():
    assert match(Command('git add src/',
                         'fatal: pathspec \'src/\' did not match any files')) is None
    assert match(Command('git rm test',
                         'fatal: not removing \'test\' recursively without -r'))
    assert match(Command('git rm test', '')) is None

# Generated at 2022-06-26 06:23:48.153859
# Unit test for function match
def test_match():
    command = Command(script='git rm -rf tmp',
                      stdout="fatal: not removing 'tmp/' recursively without -r",
                      stderr='error message')
    assert match(command)



# Generated at 2022-06-26 06:23:54.854059
# Unit test for function match
def test_match():
    assert match(Command("git rm -rf dir"))
    assert match(Command("git rm -rf dir", "fatal: not removing 'dir' recursively without -r\n", ""))
    assert not match(Command("git rm -rf dir", "fatal: not removing 'dir' recursively\n", ""))


# Generated at 2022-06-26 06:23:58.328998
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_force_remove import get_new_command
    command = "git rm src/logs/"
    new_command = get_new_command(command)
    assert '-r' in new_command

enabled_by_default = True

# Generated at 2022-06-26 06:24:40.625968
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm path/to/file') == 'git rm -r path/to/file'


# Generated at 2022-06-26 06:24:44.589903
# Unit test for function match
def test_match():
    assert match(Command('git remote add origin git@github.com:nvbn/thefuck',
                         'fatal: remote origin already exists.'))
    assert not match(Command('git remote add origin git@github.com:nvbn/thefuck',
                             ''))



# Generated at 2022-06-26 06:24:50.216872
# Unit test for function match
def test_match():
    assert match(Command('git rm --cached refs/remotes/origin/mybranch', '', 'fatal: not removing \'refs/remotes/origin/mybranch\' recursively without -r'))
    assert not match(Command('git rm -r --cached refs/remotes/origin/mybranch', '', ''))


# Generated at 2022-06-26 06:24:52.377161
# Unit test for function match
def test_match():
    assert match(Command('git rm -r files',
                         "fatal: not removing 'files' recursively without -r\n"))


# Generated at 2022-06-26 06:24:55.454291
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf test2', 'fatal: not removing \'test2\' recursively without -r')
    assert get_new_command(command) == 'git rm -rf -r test2'


# Generated at 2022-06-26 06:24:57.594087
# Unit test for function match
def test_match():
	assert match(Command('git rm not_file', u'some error here'))
	assert not match(Command('git rm', u'some error here'))


# Generated at 2022-06-26 06:25:00.087051
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm foo bar", "fatal: not removing 'foo' recursively without -r")
    match('git rm foo bar')
    assert get_new_command(command) == "git rm -r foo bar"

# Generated at 2022-06-26 06:25:04.105570
# Unit test for function get_new_command
def test_get_new_command():

    from thefuck.types import Command
    from tests.utils import CommandStub

    new_command = get_new_command(Command('git rm -r foo/', '', CommandStub('', '')))
    assert u'git rm -r foo/' == new_command

    # Handle trailing spaces
    new_command = get_new_command(Command('git rm -r foo/ ', '', CommandStub('', '')))
    assert u'git rm -r foo/ ' == new_command

# Generated at 2022-06-26 06:25:07.684830
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf')
    command.output = "fatal: not removing 'foo' recursively without -r\n"
    assert get_new_command(command) == 'git rm -rf -r'

# Generated at 2022-06-26 06:25:11.064719
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'
    assert get_new_command(Command('git rm -r dir')) == 'git rm -r -r dir'

# Generated at 2022-06-26 06:26:36.705775
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r test/ -r')) == 'git rm -r test/ -r'


# Generated at 2022-06-26 06:26:43.181031
# Unit test for function match
def test_match():
    assert match(Command('git rm -r dir/',
                         'fatal: not removing \'dir/\' recursively without -r\n',
                         ''))
    assert not match(Command('git rm -r dir/', '', ''))
    assert not match(Command('git rm -r dir/',
                             'fatal: not removing \'dir/\' recursively without -r\n',
                             ''))



# Generated at 2022-06-26 06:26:48.047705
# Unit test for function match
def test_match():
    assert match(Command('git rm blahblah'))
    assert not match(Command('git rm -r blahblah'))
    assert not match(Command('git rm -rf blahblah'))
    assert not match(Command('git rm -rf blahblah -rf'))
    assert not match(Command('rm'))
    assert not match(Command('rm -r'))
    assert not match(Command('rm -rf'))
    assert not match(Command('rm -rf blahblah'))
    assert not match(Command('rm -rf blahblah -rf'))


# Generated at 2022-06-26 06:26:53.134705
# Unit test for function get_new_command
def test_get_new_command():
    c = Command('git rm -r ../../../../../../../../../../../var/log/kern.log',
                "fatal: not removing '../../../../../../../../../../../var/log/kern.log' recursively without -r",
                '', 0)
    assert(get_new_command(c) == 'git rm -r -r ../../../../../../../../../../../var/log/kern.log')

# Generated at 2022-06-26 06:26:57.035567
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('ls', 'fatal: not removing \'file1\' recursively without -r'))
    

# Generated at 2022-06-26 06:26:59.048221
# Unit test for function match
def test_match():
    assert match(Command('git rm -f folder_name/',
        stderr='fatal: not removing \'folder_name/\' recursively without -r'))

    assert not match(Command('ls', stderr='fatal'))

# Generated at 2022-06-26 06:27:01.337951
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-26 06:27:02.659331
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm some_file') == 'git rm -r some_file'

# Generated at 2022-06-26 06:27:05.407560
# Unit test for function match
def test_match():
    assert match(Command('git rm','fatal: not removing \'doc/foo.pdf\' recursively without -r',''))
    assert match(Command('git remote rm foo','fatal: not removing \'doc/foo.pdf\' recursively without -r','')) == False


# Generated at 2022-06-26 06:27:07.661098
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r')  == 'git rm -r -r'
    assert get_new_command('git rm -r a') == 'git rm -r -r a'
    assert get_new_command('git rm a')    == 'git rm -r a'