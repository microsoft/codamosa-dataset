

# Generated at 2022-06-26 06:18:03.878977
# Unit test for function match
def test_match():
    assert(test_case_0() == None)

# Generated at 2022-06-26 06:18:07.571172
# Unit test for function match
def test_match():
    assert True == match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r'))



# Generated at 2022-06-26 06:18:10.640871
# Unit test for function match
def test_match():
    assert match(Command('git rm mydir', ' fatal: not removing \'mydir\' recursively without -r'))


# Generated at 2022-06-26 06:18:13.505678
# Unit test for function match
def test_match():
    '''
    Unit test for function match
    '''
    bool_0 = True
    assert_equals(True, git_support(bool_0))

if __name__ == '__main__':
    test_match()

# Generated at 2022-06-26 06:18:24.257971
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm filefile', 'fatal: not removing \'filefile\' recursively without -r\n')) == 'git rm -r filefile'
    assert get_new_command(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r\n')) == 'git rm -r -r file'
    assert get_new_command(Command('git rm -rf file', 'fatal: not removing \'file\' recursively without -r\n')) == 'git rm -r -rf file'
    assert get_new_command(Command('git rm --cached file', 'fatal: not removing \'file\' recursively without -r\n')) == 'git rm -r --cached file'

# Generated at 2022-06-26 06:18:27.585520
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = u"git rm 'AUTHORS'"

    var_1 = get_new_command(var_0)



# Generated at 2022-06-26 06:18:31.391290
# Unit test for function get_new_command
def test_get_new_command():
    bool_0 = False
    command_0 = Command(bool_0)
    var_0 = get_new_command(command_0)


# Generated at 2022-06-26 06:18:39.397642
# Unit test for function get_new_command
def test_get_new_command():
    match_iter = re.finditer(pattern, string)
    for match in match_iter:
        var_0 = match.group(1)
        var_1 = match.group(2)
        var_0 = get_new_command(var_0, var_1)
        match_iter = re.finditer(pattern, string)
        for match in match_iter:
            var_0 = match.group(1)
            var_1 = match.group(2)
            var_0 = get_new_command(var_0, var_1)

# Generated at 2022-06-26 06:18:42.238109
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git rm -r path/to/folder && git commit -m "Remove folder"'
    assert get_new_command(command) == 'git rm -r -r path/to/folder && git commit -m "Remove folder"'

# Generated at 2022-06-26 06:18:49.571638
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm *.pyc', 'error: pathspec \'*.pyc\' did not match any file(s) known to git.\nfatal: not removing \'./test_case_0.pyc\' recursively without -r\n', '', 0, '')
    assert get_new_command(command) == u'git rm -r *.pyc'

# Generated at 2022-06-26 06:18:53.422615
# Unit test for function match
def test_match():
    # SOURCE LINE 3
    # SOURCE LINE 18
    pass


# Generated at 2022-06-26 06:19:01.335913
# Unit test for function get_new_command
def test_get_new_command():
    # Setup
    command = MagicMock()
    command.script = u' git rm file'
    command.script_parts = ['git','rm','file']
    command.output = u"fatal: not removing 'file' recursively without -r"
    # Invocation
    result = get_new_command(command)
    # Verification
    assert result == (u'git rm -r file')


# Generated at 2022-06-26 06:19:12.530139
# Unit test for function match
def test_match():
    true = '''* master
  master
  stash
  remotes/origin/master
  remotes/origin/stash
  remotes/origin/test:master
  remotes/origin/test:stash
  remotes/origin/test:stash-1
  remotes/origin/test:stash-2
  remotes/origin/test-2:master
  remotes/origin/test-2:stash
  remotes/origin/test-3:master
  remotes/origin/test-3:stash'''
    command = Command('git branch', true)
    command = Command('git rm master', true)
    assert match(command)
    command = Command('git rm master', '')
    assert not match(command)
    command = Command('git branch', true)
    assert not match(command)


# Generated at 2022-06-26 06:19:16.308593
# Unit test for function match
def test_match():
    assert git_support()
    assert match(Command('', stderr='fatal: not removing \'mkae\' recursively without -r'))


# Generated at 2022-06-26 06:19:17.674489
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-26 06:19:19.052741
# Unit test for function get_new_command
def test_get_new_command():
    assert bool_0 == bool()


# Generated at 2022-06-26 06:19:26.017076
# Unit test for function match
def test_match():

    from thefuck.rules.git_fix_rm_not_removing_recursively import match

    command_0 = Command(
        command='git rm -f * .*',
        script='git rm -f * .*',
        stderr='fatal: not removing \'*\' recursively without -r\nfatal: not removing \'.\' recursively without -r'
    )

    assert match(
        command_0
    )

    command_1 = Command(
        command='git rm -f * .*',
        script='git rm -f * .*',
        stderr='fatal: not removing \'.\' recursively without -r\nfatal: not removing \'*\' recursively without -r'
    )

    assert match(
        command_1
    )


# Generated at 2022-06-26 06:19:31.124511
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm a", "fatal: not removing 'a' recursively without -r")
    assert get_new_command(command) == "git rm -r a"
    command = Command("git rm a b -f", "fatal: not removing 'a' recursively without -r")
    assert get_new_command(command) == "git rm -r a b -f"


# Generated at 2022-06-26 06:19:40.600595
# Unit test for function match
def test_match():
    command_0 = Command('git rm -r src/Backend/Controller/User.php', 'fatal: not removing \'src/Backend/Controller/User.php\' recursively without -r\n')

    # Call the function
    new_command = get_new_command(command=command_0)

    # Check the results
    assert(new_command == 'git rm -r -r src/Backend/Controller/User.php')



# Generated at 2022-06-26 06:19:43.853655
# Unit test for function match
def test_match():
    case_0 = True
    # Test with one or more arguments
    assert_equals(case_0, match("git rm file1 file2"))



# Generated at 2022-06-26 06:19:49.517542
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm green')) == 'git rm -r green', 'It should add -r option'
    assert get_new_command(Command('other_git_command rm green')) == 'other_git_command git rm -r green', 'It should add -r option'

# Generated at 2022-06-26 06:19:54.804844
# Unit test for function get_new_command
def test_get_new_command():
    # Tests that the error message is caught, and only the command is modified
    assert get_new_command('git rm a') == 'git rm -r a'
    # Tests that a different error message is not caught
    assert get_new_command('git rm a') != 'git rm a'
    # Tests that the error is caught and the correct index is found
    assert get_new_command('git rm a b') == 'git rm a -r b'
    # Tests that the message is not caught if index does not exist
    assert get_new_command('git rm a b').index('-r') == 2

# Generated at 2022-06-26 06:20:01.086629
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command_parts = [u'git rm', u'foo']
    command = Command(script=u' '.join(command_parts),
                      script_parts=command_parts,
                      output=u'fatal: not removing \'foo\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r foo'

# Generated at 2022-06-26 06:20:13.050422
# Unit test for function match
def test_match():
    assert match(Command('rm xxx/', '', 'fatal: not removing \'xxx/\' recursively without -r'))
    assert match(Command('rm xxx/', '', 'fatal: not removing \'xxx/x\' recursively without -r'))
    assert match(Command('rm xxx/', '', 'fatal: not removing \'xxx/x\' recursively without -r'))
    assert not match(Command('rm xxx/', '', 'fatal: not removing \'xxx/\' recursively without -r'))
    assert not match(Command('rm xxx/xx', '', 'fatal: not removing \'xxx/x\' recursively without -r'))

# Generated at 2022-06-26 06:20:16.887023
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))

# Generated at 2022-06-26 06:20:18.393696
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('git rm -r foo').script == 'git rm -r -r foo')

# Generated at 2022-06-26 06:20:20.416408
# Unit test for function match
def test_match():
    output = u"fatal: not removing 'README.md' recursively without -r"
    command = Command('git rm README.md', output)
    assert match(command) == True

# Generated at 2022-06-26 06:20:30.645260
# Unit test for function match
def test_match():
    assert match(Command('git rm foo/bad_dir',
                         'fatal: not removing \'foo/bad_dir\' recursively without -r',
                         ''))
    assert not match(Command('git', '', ''))
    assert not match(Command('git rm', '', ''))
    assert not match(Command('git rm foo', '', ''))
    assert not match(Command('git rm foo/', '', ''))
    assert not match(Command('git rm foo/bar', '', ''))
    assert not match(Command('echo rm foo/bar',
                         'fatal: not removing \'foo/bad_dir\' recursively without -r',
                         ''))


# Generated at 2022-06-26 06:20:33.573542
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'

# Generated at 2022-06-26 06:20:35.500520
# Unit test for function match
def test_match():
    assert match(Command('git rm -f foo'))


# Generated at 2022-06-26 06:20:43.652079
# Unit test for function match
def test_match():
    assert_true(match(Command(script='git rm hello.txt', output='fatal: not removing \'hello.txt\' recursively without -r')))


    # Unit test for function get_new_command

# Generated at 2022-06-26 06:20:47.336478
# Unit test for function match
def test_match():
    assert match(Command("git rm -r dir", "fatal: not removing 'dir' recursively without -r"))


# Generated at 2022-06-26 06:20:50.303656
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r ./')) == 'git rm -r -r ./'
    assert get_new_command(Command('git rm -r folder')) == 'git rm -r -r folder'

# Generated at 2022-06-26 06:20:56.093331
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', '', "fatal: not removing 'foo' recursively without -r"))
    assert not match(Command('git rm foo', '', "fatal: not removing"))
    assert not match(Command('git rm foo', ''))



# Generated at 2022-06-26 06:20:59.656766
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('git rm test', 'fatal: not removing '
                      '\'test\' recursively without -r')
    assert 'git rm -r test' == get_new_command(command)

# Generated at 2022-06-26 06:21:04.520830
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f File', 'fatal: not removing \'File\' '
                                          'recursively without -r')
    assert 'git rm -f -r File' == get_new_command(command)

# Generated at 2022-06-26 06:21:08.907016
# Unit test for function get_new_command
def test_get_new_command():
    assert 'rm -r foo' == get_new_command(command.Command('git rm foo',
        '/home/user/foo\n'
        'fatal: not removing \'foo\' recursively without -r', ''))


# Generated at 2022-06-26 06:21:11.924996
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm -r file')) == 'git rm -r -r file'



# Generated at 2022-06-26 06:21:16.036717
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git status' == get_new_command(Command.from_string('git status'))
    assert 'git rm -r test' == get_new_command(Command.from_string('git rm test'))

# Generated at 2022-06-26 06:21:20.865944
# Unit test for function match
def test_match():
    wrong_command_1 = "git rm 'file2'"
    wrong_command_2 = "git rm 'file2 file3'"
    wrong_command_3 = "git rm 'file2' file3"
    wrong_command_4 = "git rm 'file2' file3"
    wrong_output_1 = "fatal: not removing 'file2' recursively without -r\n"
    assert not m

# Generated at 2022-06-26 06:21:32.603603
# Unit test for function match
def test_match():
    command = Command('git rm -rf dir/subdir', 'fatal: not removing \'dir/subdir\' recursively without -r')
    assert match(command)



# Generated at 2022-06-26 06:21:37.735145
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = [u'git', u'rm', u'file.txt']
    command = Command(command_parts, 'error:  not removing \'file.txt\', recursively without -r')
    assert(get_new_command(command) == 'git rm -r file.txt')

# Generated at 2022-06-26 06:21:41.406399
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command(' git rm file ')) == 'git rm -r file'

# Generated at 2022-06-26 06:21:46.054845
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.txt',
      output='fatal: not removing \'hello.txt\' recursively without -r\n'))
    assert not match(Command('git rm hello.txt'))


# Generated at 2022-06-26 06:21:47.609788
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm mymodule', '', '/')
    assert get_new_command(command) == 'git rm -r mymodule'

# Generated at 2022-06-26 06:21:51.010034
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm')) == 'git rm  -r'

# Generated at 2022-06-26 06:21:55.227416
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm somedir',
        'fatal: not removing \'somedir\' recursively without -r\n')) == 'git rm -r somedir'

# Generated at 2022-06-26 06:21:57.109420
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script ='git rm file1 file2')) == 'git rm -r file1 file2'

# Generated at 2022-06-26 06:22:07.819040
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf deb.txt', stderr='fatal: not removing \'deb.txt\' recursively without -r\n'))
    assert match(Command('git rm -rf deb.txt', stderr='fatal: not removing \'deb.txt\' recursively without -r\n'))
    assert not match(Command('git rms -rf deb.txt', stderr='fatal: not removing \'deb.txt\' recursively without -r\n'))
    assert not match(Command('git rms -rf deb.txt', stderr='fatal: not removing \'deb.txt\' recursively without -r\n'))


# Generated at 2022-06-26 06:22:14.580323
# Unit test for function match
def test_match():
    assert match(Command('git rm -r .', 'fatal: not removing \'tests/fake_file\' recursively without -r', None))
    assert not match(Command('git pull', 'fatal: not removing \'tests/fake_file\' recursively without -r', None))


# Generated at 2022-06-26 06:22:36.871972
# Unit test for function match
def test_match():
    assert match(Command('git rm my_folder',
                         'fatal: not removing \'my_folder\' recursively without -r\n'))
    assert not match(Command('git rm my_folder',
                             'fatal: not removing \'my_folder\' recursively without -r'))
    assert not match(Command('git rm -r my_folder',
                             'fatal: not removing \'my_folder\' recursively without -r\n'))


# Generated at 2022-06-26 06:22:40.885915
# Unit test for function match
def test_match():
    assert match(Command('git branch dev',
                         'fatal: not removing "." recursively without -r\n',
                         '', 0))


# Generated at 2022-06-26 06:22:46.206396
# Unit test for function match
def test_match():
    # from thefuck.rules.git_remove_recursively import match
    output = '''fatal: not removing 'test/test.txt' recursively without -r'''

    assert match(Command('git rm test/test.txt', output))

# Generated at 2022-06-26 06:22:50.292912
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm 'test'", "fatal: not removing 'test' recursively without -r\n")
    assert (get_new_command(command)) == "git rm -r 'test'"

# Generated at 2022-06-26 06:22:54.694464
# Unit test for function match
def test_match():
    assert(match(Command('git rm -rf a_folder',
        "fatal: not removing 'a_folder' recursively without -r")) is True)


# Generated at 2022-06-26 06:22:59.312815
# Unit test for function match
def test_match():
    match_test_cases = [
        Command('git rm -f .',
                'fatal: not removing \'<file>\' recursively without -r'),
        Command('git rn <file>',
                'fatal: not removing \'<file>\' recursively without -r'),
        Command('git rr <dir>',
                'fatal: not removing \'<dir>\' recursively without -r')]

    for command in match_test_cases:
        assert match(command)



# Generated at 2022-06-26 06:23:03.569307
# Unit test for function get_new_command
def test_get_new_command():
	command = Command('git rm test', 'fatal: not removing \'test\' recursively without -r\n', None)

	assert get_new_command(command) == 'git rm -r test'

# Generated at 2022-06-26 06:23:07.381499
# Unit test for function match
def test_match():
    assert(match(Command('git rm -r *', '')))
    assert(match(Command('git rm *', "fatal: not removing 'file' recursively without -r\n")) is False)


# Generated at 2022-06-26 06:23:11.775482
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) == "git rm -r file"

# Generated at 2022-06-26 06:23:16.648842
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file.txt', 'fatal: not removing \'file.txt\''
                      'recursively without -r', sys.stderr)
    assert get_new_command(command) == 'git rm -r file.txt'

# Generated at 2022-06-26 06:23:49.247604
# Unit test for function match
def test_match():
  # A valid string return true
  assert match(Command('git rm README',
  'fatal: not removing \'README\' recursively without -r\n'))==True
  # A invalid string return false
  assert match(Command('git add README',''))==False
  
  

# Generated at 2022-06-26 06:23:50.523987
# Unit test for function match
def test_match():
    assert match(Command('rm -rf --force', 'fatal: not removing '
                                        + "'.' recursively without -r"))


# Generated at 2022-06-26 06:23:55.853451
# Unit test for function get_new_command
def test_get_new_command():
    command=Command("git rm -f *.pyc")
    command.output="fatal: not removing 'test.pyc' recursively without -r\n"
    match(command)
    assert get_new_command(command)=="git rm -f -r *.pyc"

# Generated at 2022-06-26 06:24:00.594149
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('rm file.txt',
                         'fatal: not removing \'file.txt\' recursively '
                         'without -r\n', ''))
    assert not match(Command('rm -r file.txt',
                             'fatal: not removing \'file.txt\' recursively '
                             'without -r\n', ''))
    assert not match(Command('git rm file.txt',
                             'fatal: not removing \'file.txt\' recursively '
                             'without -r\n', ''))


# Generated at 2022-06-26 06:24:07.454043
# Unit test for function match
def test_match():
    assert match(Command(script='git rm test.txt',
                         output='fatal: not removing \'test.txt\' recursively without -r'))
    assert not match(Command(script='git rm test.txt',
                             output='fatal: not removing \'test.txt\' recursively'))
    assert not match(Command(script='echo test.txt',
                             output='fatal: not removing \'test.txt\' recursively without -r'))


# Generated at 2022-06-26 06:24:10.676231
# Unit test for function match

# Generated at 2022-06-26 06:24:16.230035
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm docs/git-clone.txt', '')) == 'git rm -r docs/git-clone.txt'
    assert get_new_command(Command('git rm docs/git-clone.txt', '')) != 'git rm -f docs/git-clone.txt'

# Generated at 2022-06-26 06:24:19.493866
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo')
    assert get_new_command(command) == 'git rm -r foo'

# Generated at 2022-06-26 06:24:25.284389
# Unit test for function match
def test_match():
    assert match(Command('git rm folder/file.txt',
                         'fatal: not removing \'folder/file.txt\'' +
                         ' recursively without -r\n'))
    assert match(Command('git log blah blah blah', 'blah blah blah')) == False


#Unit test for function get_new_command

# Generated at 2022-06-26 06:24:37.443338
# Unit test for function match
def test_match():
    assert match(Command('git rm -r [filename]',
                         'fatal: not removing \'[filename]\' recursively without -r'))
    assert match(Command('git rm -rf [filename]',
                         'fatal: not removing \'[filename]\' recursively without -r'))
    assert match(Command('git rm [filename]',
                         'fatal: not removing \'[filename]\' recursively without -r'))
    assert match(Command('git rm [filename] --cached',
                         'fatal: not removing \'[filename]\' recursively without -r'))
    assert match(Command('git rm -rf [filename]',
                         'fatal: not removing \'[filename]\' recursively without -r'))

# Generated at 2022-06-26 06:25:47.609380
# Unit test for function match
def test_match():
    tests_dict = {
        'git rm -r foo/': True,
        'git rm foo/': False,
        'rm foo/': False
    }
    for test, value in tests_dict.items():
        assert match(Command(test, '')) == value


# Generated at 2022-06-26 06:25:49.674611
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file.txt') == 'git rm -r file.txt'


enabled_by_default = True


priority = 1000

# Generated at 2022-06-26 06:25:53.145000
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file', '', 'fatal: not removing \'file\' recursively without -r', 7))
    assert not match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r', 7))
    assert not match(Command('git rm -r file', '', 'fatal: not removing \'file\' recursively without', 7))



# Generated at 2022-06-26 06:25:55.652815
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm file.py", "fatal: not removing 'file.py' recursively without -r")
    assert get_new_command(command) == "git rm -r file.py"

# Generated at 2022-06-26 06:26:00.039077
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         "error: fatal: not removing 'file' recursively without -r",
                         ''))
    assert not match(Command('git branch',
                         "error: fatal: not removing 'file' recursively without -r",
                         ''))

# Generated at 2022-06-26 06:26:01.774309
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test/file')
    assert get_new_command(command) == 'git rm -r test/file'

# Generated at 2022-06-26 06:26:05.030763
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script ='git rm -r new-file.txt', output='fatal: not removing \'new-file.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r new-file.txt'

# Generated at 2022-06-26 06:26:12.676940
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file/', 'fatal: not removing \'file/\' recursively without -r')

    assert get_new_command(command) == 'git rm -r file/'

# Generated at 2022-06-26 06:26:20.647018
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -a', '')) == 'git rm -r -a'
    assert get_new_command(Command('git rm -a', '')) == 'git rm -r -a'
    assert get_new_command(Command('svn rm -a', '', None)) == 'svn rm -a'
    assert get_new_command(Command('svn rm -a', '')) == 'svn rm -a'
    assert get_new_command(Command('svn rm -a', '', 1)) == 'svn rm -a'
    assert get_new_command(Command('svn rm -a', '', [])) == 'svn rm -a'

# Generated at 2022-06-26 06:26:24.181428
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -r file',
                                   'fatal: not removing \'file\' recursively without -r',
                                   '', 0)) == 'git rm -r file'
    assert get_new_command(Command('rm file',
                                   '',
                                   '', 0)) == 'git rm file'