

# Generated at 2022-06-26 06:18:14.657740
# Unit test for function match
def test_match():
    str_0 = u'git rm '
    str_1 = u'fatal: not removing \'test2test/test2test\' recursively without -\
r'
    command = Command(str_0, str_1)
    var_0 = match(command)
    assert var_0 == True
    str_0 = u'git rma '
    str_1 = u'fatal: not removing \'test2test/test2test\' recursively without -\
r'
    command = Command(str_0, str_1)
    var_0 = match(command)
    assert var_0 == False

# Unit test function _get_new_command

# Generated at 2022-06-26 06:18:16.041398
# Unit test for function match
def test_match():
    test_case_0()


# Generated at 2022-06-26 06:18:18.939968
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = '2RR,@k4nofk_#/\r>m('
    test_case_0(str_0)

# Generated at 2022-06-26 06:18:23.115244
# Unit test for function match
def test_match():
    str_0 = '2RR,@k4nofk_#/\r>m('
    var_0 = match(str_0)


# Generated at 2022-06-26 06:18:26.936677
# Unit test for function match
def test_match():
    assert match(' git branch -d  abc')
    assert match('git branch -D  abc')
    assert not match('git push abc origin/master:master')



# Generated at 2022-06-26 06:18:35.649251
# Unit test for function match
def test_match():
    assert match(
        'git rm -r --cached target/release/deps/libsyntax-ddcc0ed2d6b95881.rlib') \
        is False
    assert match('git rm -r --cached target/release/deps/libsyntax') is False
    assert match(
        'git rm -r --cached target/release/deps/libsyntax-ddcc0ed2d6b95881.rlib') \
        is False
    assert match(
        'git rm -r --cached target/release/deps/libsyntax-ddcc0ed2d6b95881.rlib') \
        is False

# Generated at 2022-06-26 06:18:40.881530
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = "git rm nope.md"
    str_1 = "fatal: not removing 'nope.md' recursively without -r"
    str_2 = "fatal: not removing 'nope.md' recursively without -r"
    assert (u'git rm -r nope.md' == get_new_command(str_0, str_1, str_2))

# Generated at 2022-06-26 06:18:46.040932
# Unit test for function match
def test_match():
    assert match('2RR,@k4nofk_#/\r>m(') == False
    assert match('git status') == False
    assert match('git rm') == False
    assert match('git rm -r') == False
    assert match('git rm file') == False
    assert match('git rm file dir file2') == False
    assert match("""fatal: not removing 'file' recursively without -r""") == False
    assert match("""fatal: not removing 'file' recursively without -r
git rm file""") == False
    assert match("""fatal: not removing 'file' recursively without -r
git rm dir file2""") == False
    assert match("""fatal: not removing 'file' recursively without -r
git rm file dir file2""") == True

# Unit test

# Generated at 2022-06-26 06:18:46.875207
# Unit test for function get_new_command
def test_get_new_command():
    # Assert failure on line 17, column 12
    assert get_new_command is None


# Generated at 2022-06-26 06:18:55.909009
# Unit test for function match
def test_match():
    assert match(None) is False
    assert match('') is False
    assert match(' ') is False
    assert match('  ') is False
    assert match('   ') is False
    assert match('    ') is False
    assert match('     ') is False
    assert match('      ') is False
    assert match('       ') is False
    assert match('rm ') is False
    assert match(' rm ') is False
    assert match('fatal: not removing ') is False
    assert match(' fatal: not removing ') is False
    assert match(' fatal: not removing ') is False
    assert match('  fatal: not removing ') is False
    assert match('   fatal: not removing ') is False
    assert match('    fatal: not removing ') is False

# Generated at 2022-06-26 06:19:02.720726
# Unit test for function get_new_command
def test_get_new_command():
    ran = 'git rm test'
    out = ("fatal: not removing 'test' recursively without -r\n"
           "Did you mean 'git rm --cached'?")
    command = Command(ran, out)
    actual = get_new_command(command)
    expected = "git -r rm test"
    assert actual == expected

# Generated at 2022-06-26 06:19:10.214345
# Unit test for function match
def test_match():
    assert match(Command(script='git rm file1', output='fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command(script='git rm file1', output=''))
    assert not match(Command(script='git branch', output='* master'))
    assert not match(Command(script='git rm file1', output='rm: cannot remove'))


# Generated at 2022-06-26 06:19:16.227713
# Unit test for function match
def test_match():
    # Test for match
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 0, ''))
    assert match(Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r', '', 0, ''))
    assert match(Command('git rm --cached -r file', 'fatal: not removing \'file\' recursively without -r', '', 0, ''))

    # Test for not match
    assert not match(Command('git rm file', 'error: file is a directory', '', 0, ''))
    assert not match(Command('rm file', 'fatal: not removing \'file\' recursively without -r', '', 0, ''))
    assert not match(Command('git rm file', '', '', 0, ''))



# Generated at 2022-06-26 06:19:19.926589
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm foo', 'fatal: not removing \'foo\' recursively without -r\n')) == 'git rm -r foo'

# Generated at 2022-06-26 06:19:21.308071
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git rm test', '')) == 'git rm -r test'

# Generated at 2022-06-26 06:19:25.347383
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git rm file'
    new_command = get_new_command(command)
    assert new_command == 'git rm -r file'

# Generated at 2022-06-26 06:19:30.676746
# Unit test for function match
def test_match():
    assert match(Command('git rm file1',
                         'fatal: not removing \'file1\' recursively without -r', ''))
    assert not match(Command('git rm file1',
                             'fatal: not removing \'file1\' recursively with -r', ''))


# Generated at 2022-06-26 06:19:36.194091
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm test.txt',
                                   stderr='fatal: not removing \'test.txt\' recursively without -r')) == 'git rm -r test.txt'

# Generated at 2022-06-26 06:19:39.513205
# Unit test for function match
def test_match():
    command = Command('git rm foo.bar', '/tmp', '', '', '')
    assert (match(command))


# Generated at 2022-06-26 06:19:42.248359
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r a', 'fatal: not removing \'a\' recursively without -r')) == 'git rm -r a'
    

# Generated at 2022-06-26 06:19:48.946267
# Unit test for function get_new_command
def test_get_new_command():
    sentence = 'git rm ccc'
    from thefuck.types import Command
    assert get_new_command(Command(sentence, '')) == 'git rm -r ccc'


enabled_by_default = True

# Generated at 2022-06-26 06:19:55.334443
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command(Command('rm f', '')), 'rm -r f')
    assert_equals(get_new_command(Command('rm ./f', '')), 'rm -r ./f')
    assert_equals(get_new_command(Command('rm ./f/git_repo', '')), 'rm -r ./f/git_repo')
    assert_equals(get_new_command(Command('rm ./f/git_repo1', '')), 'rm -r ./f/git_repo1')
    assert_equals(get_new_command(Command('rm -r f/git_repo1', '')), 'rm -r -r f/git_repo1')

# Generated at 2022-06-26 06:20:00.594016
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', '', '')
    assert get_new_command(command) == 'git rm -r status'
    assert get_new_command(Command('git rm a b', '', '')) == 'git rm -r a b'



# Generated at 2022-06-26 06:20:04.826349
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r --cached dir1",
                      "fatal: not removing 'dir1' recursively without -r\n")
    assert get_new_command(command) == "git rm -r -r --cached dir1"
    command = Command("git rm 'dir1", "' recursively without -r\n")
    assert get_new_command(command) == "git rm 'dir1"



# Generated at 2022-06-26 06:20:10.096298
# Unit test for function match
def test_match():
    assert match(Command('git rm test.py',
                         'fatal: not removing \'test.py\' recursively without -r\n'))
    assert not match(Command('git rm test.py', ''))


# Generated at 2022-06-26 06:20:20.416564
# Unit test for function match
def test_match():
    assert(match(Command('git rm file', '/home/user/folder', 'fatal: not removing \'file\' recursively without -r\nDid you mean this?\n\tgit rm --cached file')))
    assert(match(Command('git rm file', '/home/user/folder', 'fatal: not removing \'file\' recursively without -r\nDid you mean this?\n\tgit rm --cached file\n')))
    assert(match(Command('git rm file', '/home/user/folder', 'fatal: not removing \'file\' recursively without -r\n')))

# Generated at 2022-06-26 06:20:31.521424
# Unit test for function match
def test_match():
    assert_true(match('git rm file.txt'))
    assert_true(match('git rm dir/'))
    assert_true(match('git rm -f file.txt'))
    assert_true(match('git rm -f dir/'))
    assert_true(match('git rm -f --cached file.txt'))
    assert_true(match('git rm -f --cached dir/'))
    assert_false(match('git rm file.txt other.txt'))
    assert_false(match('git rm multiple/files/'))
    assert_false(match('git rm -f file.txt other.txt'))
    assert_false(match('git rm -f multiple/files/'))
    assert_false(match('git rm -f --cached file.txt other.txt'))
    assert_

# Generated at 2022-06-26 06:20:36.833566
# Unit test for function get_new_command
def test_get_new_command():
    assert "git rm -r file" == get_new_command('git rm file')
    assert "git rm -r file file" == get_new_command('git rm file file')
    assert "git rm -r file" == get_new_command('f git rm file')

# Generated at 2022-06-26 06:20:39.721835
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.py', 'fatal: not removing \'hello.py\' recursively without -r'))

# Generated at 2022-06-26 06:20:44.128795
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test -r test2')
    assert get_new_command(command) == u'git rm -r test2 -r test2'


enabled_by_default = True

# Generated at 2022-06-26 06:20:58.756274
# Unit test for function match
def test_match():

    #Function match should return True if there is a fatal when you try to remove a directory without -r
    command = Command("git rm /project/tests", "fatal: not removing '/project/tests' recursively without -r")
    assert match(command) is True
    command = Command("git rm /project/tests", "")
    assert match(command) is False


# Generated at 2022-06-26 06:21:05.102134
# Unit test for function match
def test_match():
    assert match(Command('rm one two', 'fatal: not removing \'one\' recursively without -r\n', ''))
    assert not match(Command('rm one two', 'error: one two', ''))
    assert not match(Command('rm one two', '', ''))


# Generated at 2022-06-26 06:21:10.344503
# Unit test for function match
def test_match():
    assert(match(Command('git rm file',
                         'fatal: not removing "file" recursively without -r')))
    assert(not match(Command('git commit -am "message"',
                         'On branch master\n'
                         'Your branch is up-to-date with \'origin/master\'.\n'
                         'nothing to commit, working directory clean')))


# Generated at 2022-06-26 06:21:16.197200
# Unit test for function match
def test_match():
    # Simple error
    example_command = Command(script=u'git rm file',
                              output=u'fatal: not removing \'file\' recursively without -r')
    assert match(example_command)

    # Not recursively
    example_command = Command(script=u'git rm file',
                              output=u'fatal: not removing \'file\' without -r')
    assert not match(example_command)

    # Recursively
    example_command = Command(script=u'git rm -r file',
                              output=u'fatal: not removing \'file\' recursively without -r')
    assert not match(example_command)

    # garbled error
    example_command = Command(script=u'git rm file',
                              output=u'fatal: not removing all')

# Generated at 2022-06-26 06:21:21.230476
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import shell
    from thefuck.types import Command

    assert (get_new_command(
            Command('git rm -r src', '', 'fatal: not removing \'src\''
                    ' recursively without -r', None,
                    shell('git rm -r src', 'fatal: not removing \'src\''
                          ' recursively without -r')))
            == 'git rm -r -r src')

# Generated at 2022-06-26 06:21:25.360098
# Unit test for function match
def test_match():
    # str1
    assert match(Command('git rm a_dir/',
        'fatal: not removing \'a_dir/\' recursively without -r'))
    # str2
    assert match(Command('git rm -r a_dir/',
        'fatal: not removing \'a_dir/\' recursively without -r'))



# Generated at 2022-06-26 06:21:27.245034
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', "fatal: not removing 'file' recursively without -r")
    assert get_new_command(command) == "git rm -r file"

# Generated at 2022-06-26 06:21:30.544976
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git rm', ''))
    assert new_command == "git rm -r"

# Generated at 2022-06-26 06:21:39.208852
# Unit test for function match
def test_match():
    assert match(Command('git rm toto.txt', \
                         "fatal: not removing 'toto.txt' recursively without -r"))
    assert match(Command('git rm toto.txt', \
                         'fatal: not removing "toto.txt" recursively without -r'))
    assert match(Command('git rm -f toto.txt', \
                         'fatal: not removing "toto.txt" recursively without -r'))
    assert not match(Command('git rm toto', \
                             ''))


# Generated at 2022-06-26 06:21:43.614707
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm file',
                                   output="fatal: not removing 'file' recursively without -r")) == 'git rm -r file'


# Generated at 2022-06-26 06:22:01.615055
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r'))


# Generated at 2022-06-26 06:22:06.948352
# Unit test for function match
def test_match():
    assert match(
          Command('git rm file',
                  stderr='fatal: not removing \'file\' recursively without -r'))
    assert not match(
          Command('git rm file',
                  stderr='fatal: not removing \'file\' recursively withou -r'))

# Generated at 2022-06-26 06:22:09.915816
# Unit test for function get_new_command

# Generated at 2022-06-26 06:22:14.505806
# Unit test for function match
def test_match():
    assert match(Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r'))
    assert not match(Command('git rm test.txt', ''))



# Generated at 2022-06-26 06:22:18.224009
# Unit test for function get_new_command
def test_get_new_command():
    a = FuckItRule()
    a.origin_command = "git rm -rf foler"
    a.output = "fatal: not removing 'foler' recursively without -r"

    assert "git rm -rf -r foler" == a.get_new_command()

# Generated at 2022-06-26 06:22:24.805179
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm stuff', '', 'fatal: not removing \'stuff\' recursively without -r')
                         ) == 'git rm -r stuff'

# Generated at 2022-06-26 06:22:28.146448
# Unit test for function match
def test_match():
    assert match(Command('git rm wrong.txt', '', 'fatal: not removing \'wrong.txt\' recursively without -r'))
    assert not match(Command('git rm wrong.txt', '', ''))


# Generated at 2022-06-26 06:22:38.306625
# Unit test for function match
def test_match():
    # output: fatal: not removing 'foo' recursively without -r
    command1 = Command('git rm foo', '', '')
    assert match(command1) == True

    # output: fatal: not removing 'foo/bar.txt' recursively without -r
    command2 = Command('git rm foo/bar.txt', '', '')
    assert match(command2) == True

    # output: fatal: not removing 'foo/bar.txt' recursively without -r
    command3 = Command('git rm foo/bar.txt', '', '')
    assert match(command3) == True

    # output: fatal: not removing 'foo/bar.txt' recursively without -r
    command4 = Command('git rm foo/bar.txt', '', '')
    assert match(command4) == True

    # output

# Generated at 2022-06-26 06:22:48.906826
# Unit test for function match
def test_match():
    assert match(Command('git rm file2 file1', '', 'fatal: not removing \'file1\' recursively without -r'))
    assert match(Command('git rm --cached file2 file3', '', 'fatal: not removing \'file2\' recursively without -r'))
    assert match(Command('git rm -r file2 file1', '', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git add file1', '', 'fatal: cannot stat \'file1\': Permission denied'))
    assert not match(Command('git rm file2 file1', '', 'fatal: not removing \'file3\' recursively without -r'))

# Generated at 2022-06-26 06:22:56.596056
# Unit test for function get_new_command

# Generated at 2022-06-26 06:23:29.273347
# Unit test for function match
def test_match():
    # Check if match correctly detects the error
    command = Command('git rm file/ -rf', error='fatal: not removing "file/" recursively without -r')
    assert match(command)



# Generated at 2022-06-26 06:23:36.653528
# Unit test for function match
def test_match():

    # Test if the script is correct.
    command1 = Command(' git rm test.txt',
                     'fatal: not removing \'test.txt\' recursively without -r')
    assert (match(command1) == True)

    # Test if the script is incorrect.
    command2 = Command(' git rm test.txt')
    assert (match(command2) == False)

# Generated at 2022-06-26 06:23:38.193896
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git rm foldername') == 'git rm -r foldername')

# Generated at 2022-06-26 06:23:40.419767
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r -d')) == 'git rm -d -r'

# Generated at 2022-06-26 06:23:45.243103
# Unit test for function match
def test_match():
    command = Command('rm lib/jasmine/*', "fatal: not removing 'lib/jasmine/jasmine-core' recursively without -r")
    assert match(command)


# Generated at 2022-06-26 06:23:48.120166
# Unit test for function match
def test_match():
    assert match(Command('git rm file'))
    assert match(Command('git rm -r file'))
    assert not match(Command('rm file'))
    assert not match(Command('git log'))



# Generated at 2022-06-26 06:23:49.942730
# Unit test for function match
def test_match():
    assert not match(Command('git branch | grep branch',
                ''))
    assert match(Command('git rm some_directory',
             'fatal: not removing \'some_directory\' recursively without -r'))

# Generated at 2022-06-26 06:23:53.111289
# Unit test for function match
def test_match():
    from thefuck.specific.git import git_support
    command = Command('git rm -f test.rb')
    assert match(command)


# Generated at 2022-06-26 06:23:57.464535
# Unit test for function match
def test_match():
    assert match(Command('git rm', 'fatal: not removing \'file\' recursively without -r',
                         '', 1))
    assert not match(Command('git branch'))
    assert not match(Command('git rm', '', '', 1))



# Generated at 2022-06-26 06:24:01.087549
# Unit test for function match
def test_match():
	assert match(Command("git rm installed-files.txt", "fatal: not removing 'installed-files.txt' recursively without -r"))


# Generated at 2022-06-26 06:25:18.493359
# Unit test for function match
def test_match():
    assert match(Command('rm file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r\n',
                         '/bin/zsh'))

# Generated at 2022-06-26 06:25:20.349673
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing "file" recursively without -r'))



# Generated at 2022-06-26 06:25:22.467132
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf /directory/file')
    assert get_new_command(command) == 'git rm -rf -r /directory/file'

# Generated at 2022-06-26 06:25:31.167386
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git rm filename') == u'git rm -r filename'
    assert get_new_command(u'git rm -r filename') == u'git rm -r filename'
    assert get_new_command(u'git rm -r my/dir1 my/dir2') == u'git rm -r my/dir1 -r my/dir2'
    assert get_new_command(u'git rm -r -N my/dir1 my/dir2') == u'git rm -r -N my/dir1 -r -N my/dir2'
    assert get_new_command(u'git rm -r --cached my/dir1 my/dir2') == u'git rm -r --cached my/dir1 -r --cached my/dir2'

# Generated at 2022-06-26 06:25:33.787897
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm -r foo", "fatal: not removing 'foo' recursively without -r", "")) == "git rm -r -r foo"

# Generated at 2022-06-26 06:25:40.064342
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2',
                         'fatal: not removing \'file2\' recursively without -r'))
    assert not match(Command('git rm file1 file2',
                             'fatal: not removing \'file2\' recursively without '
                             '-r\nfatal: not removing \'file1\' recursively without '
                             '-r'))
    assert not match(Command('git rm file1 file2', 'fatal: not removing '
                         '\'file2\' recursively without -r', None))



# Generated at 2022-06-26 06:25:48.769020
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('git checkout', ''))


# Generated at 2022-06-26 06:25:53.070275
# Unit test for function match
def test_match():
    command1 = Command('git rm -rf . > /dev/null', 'fatal: not removing \'.\' recursively without -r')
    command2 = Command('git rm -rf . > /dev/null', 'fatal: not removing \'.\' recursively')
    command3 = Command('git rm -rf . > /dev/null', 'Not removing \'.\' recursively')

    assert match(command1) is True
    assert match(command2) is False
    assert match(command3) is False


# Generated at 2022-06-26 06:25:57.136239
# Unit test for function match
def test_match():
    assert match(get_command('git rm --cached filename'))
    assert not match(get_command('git status'))


# Generated at 2022-06-26 06:26:00.730916
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == u'git rm -r file'
    assert get_new_command(Command('git rm --cached file')) == u'git rm --cached -r file'