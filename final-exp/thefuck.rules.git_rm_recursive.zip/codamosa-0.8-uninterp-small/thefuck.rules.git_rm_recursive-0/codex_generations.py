

# Generated at 2022-06-26 06:18:10.861178
# Unit test for function match
def test_match():
    # Case 0
    assert match('git rm file') == 'git rm -r file'

    # Case 1
    #assert match('git checkout HEAD~3') == 'git checkout HEAD~2'

    # Case 2
    #assert match('git checkout HEAD~3') == 'git checkout HEAD~2'

    # Case 3
    #assert match('git checkout HEAD~3') == 'git checkout HEAD~2'



# Generated at 2022-06-26 06:18:14.109331
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'LKjRx\x0bY0v\x0cFw\x0c$Ua\x0b$D;\x0bRp\x0cY'
    command_0 = get_new_command(str_0)

# Generated at 2022-06-26 06:18:17.406991
# Unit test for function get_new_command
def test_get_new_command():
    str_2 = 'rm -r\n'
    var_3 = get_new_command(str_2)


# Generated at 2022-06-26 06:18:24.098379
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = 'git rm file.txt'
    var_1 = get_new_command(var_0)
    var_2 = 'git rm -r file.txt'
    var_3 = get_new_command(var_2)

# Unit tests for function test_case_0

# Generated at 2022-06-26 06:18:28.015483
# Unit test for function match
def test_match():
    new_command = get_new_command('git rm file.txt')
    assert 'git rm -r file.txt' == new_command
    assert match('git rm file.txt')

# Generated at 2022-06-26 06:18:31.532012
# Unit test for function match

# Generated at 2022-06-26 06:18:34.012006
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command('rm -r a b c'))

# Generated at 2022-06-26 06:18:37.955991
# Unit test for function get_new_command
def test_get_new_command():
    str_test = "git rm x"
    str_res = get_new_command(Command(str_test, ""))

    assert str_res is not None
    assert "git rm -r x" == str_res  # assertion fails

# Generated at 2022-06-26 06:18:42.025686
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = "git status"
    var_1 = get_new_command(str_0)
    str_2 = "fatal: not removing '.' recursively without -r"
    var_3 = match(str_0 + str_2)

# Generated at 2022-06-26 06:18:46.417898
# Unit test for function match
def test_match():
    str_0 = 'l\nCnM\x0cxdOf7\x0c9KZ:dC\x0b'
    var_0 = match(str_0)


# Generated at 2022-06-26 06:18:52.709920
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'Nd>lQ?\tR\x0c^kW\x00\x0c\x0e'
    var_0 = get_new_command(str_0)


# Generated at 2022-06-26 06:18:57.496826
# Unit test for function get_new_command
def test_get_new_command():
    str_1 = 'l\nCnM\x0cxdOf7\x0c9KZ:dC\x0b'
    var_1 = get_new_command(str_1)

# Generated at 2022-06-26 06:19:03.749277
# Unit test for function get_new_command
def test_get_new_command():
    command = "git rm hello.txt"
    command_output = "fatal: not removing 'hello.txt' recursively without -r"
    assert get_new_command(command, command_output) == "git rm -r hello.txt"

    command = "git rm hello.txt"
    command_output = "fatal: not removing 'hello.txt' recursively without -r"
    assert get_new_command(command, command_output) == "git rm -r hello.txt"

# Generated at 2022-06-26 06:19:11.640744
# Unit test for function match
def test_match():
    u'l\nCnM\x0cxdOf7\x0c9KZ:dC\x0b'
    u'git rm test'
    u''
    u"fatal: not removing 'test' recursively without -r"
    u'git rm -r test'
    u'l\nCnM\x0cxdOf7\x0c9KZ:dC\x0b'
    u'git rm test'
    u''
    u'fatal: pathspec \''
    u'test'
    u"' did not match any files"
    u'git rm test\' did not match any files'
    u'l\nCnM\x0cxdOf7\x0c9KZ:dC\x0b'
    u'git rm test'
   

# Generated at 2022-06-26 06:19:23.134951
# Unit test for function match
def test_match():
    str_0 = 'git rm -f a.txt'
    str_1 = 'fatal: not removing \'a.txt\' recursively without -r\nDid you mean this?\n\ty\n\tn\n'
    str_2 = 'git rm -f a.txt\nfatal: not removing \'a.txt\' recursively without -r\nDid you mean this?\ny\nn'
    str_3 = 'git rm -f a.txt\nfatal: not removing \'a.txt\' recursively without -r\nDid you mean this?\ny\nn\n'
    str_4 = '\n\n\n\nfatal: not removing \'a.txt\' recursively without -r\n'

# Generated at 2022-06-26 06:19:25.703137
# Unit test for function match
def test_match():
    assert match(str_0) == var_0


# Generated at 2022-06-26 06:19:30.605665
# Unit test for function get_new_command
def test_get_new_command():
    def _case_0():
        str_0 = 'git status\ngit rm '
        str_1 = ''
        var_0 = get_new_command(str_0, str_1)
        assert var_0 == 'git rm -r '


# Generated at 2022-06-26 06:19:35.510029
# Unit test for function get_new_command
def test_get_new_command():
    var_1 = 'git rm -r file'
    res_1 = get_new_command(var_1)


test_case_0()


# Generated at 2022-06-26 06:19:38.199181
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'



# Generated at 2022-06-26 06:19:41.894385
# Unit test for function match
def test_match():
    print('Test case 1: empty string')
    var_0 = match('This is a test string')
    assert var_0 == False

    print('Test case 2: empty string')
    var_0 = match('This is a test string')
    assert var_0 == False



# Generated at 2022-06-26 06:19:46.893653
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git rm *'
    assert get_new_command(command) == 'git rm -r *'

# Generated at 2022-06-26 06:19:50.427234
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -d non_existing_dir', ''))
    assert get_new_command(Command('rm non_existing_dir', ''))

# Generated at 2022-06-26 06:19:55.145892
# Unit test for function match
def test_match():
    import pytest
    from thefuck.rules.rm_recursive import match
    from thefuck.rules.git_support import git_support
    from thefuck.types import Command
    
    output = '''fatal: not removing '.' recursively without -r
Did you mean 'git rm --cached .'?'''
    
    supported_command = git_support(Command('rm .', output))
    unsupported_command = Command('rm .', output)
    
    assert match(supported_command)
    assert not match(unsupported_command)
    

# Generated at 2022-06-26 06:19:57.831993
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm fileWithoutExtension')) == 'git rm -r fileWithoutExtension'

# Generated at 2022-06-26 06:20:03.719429
# Unit test for function get_new_command
def test_get_new_command():
    function_name = 'get_new_command'
    # use case #1
    script1 = " git rm 'src/test.txt' "
    output1 = "fatal: not removing 'src/test.txt' recursively without -r"
    command1 = Command(script1, output1)
    actual_new_command1 = get_new_command(command1)
    expected_new_command1 = "git rm -r 'src/test.txt'"
    assert actua

# Generated at 2022-06-26 06:20:10.925162
# Unit test for function match
def test_match():
    assert match(Command('git clone user@12345netflix.com:/home/repo.git',
                         'fatal: not removing \'path/file\' recursively without -r'))
    assert not match(Command('git rm wrong.txt', ''))
    assert not match(Command('git rm path/file', 'fatal: path/file did not match any files'))


# Generated at 2022-06-26 06:20:15.127755
# Unit test for function match
def test_match():
    command = Command(script='git branch -d test rm file1 file2', 
        error=None,
        output="fatal: not removing 'file1' recursively without -r\n")
    assert match(command)


# Generated at 2022-06-26 06:20:19.471987
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r folder/')) == 'git rm -r -r folder/'
    assert get_new_command(Command('git rm folder/')) == 'git rm -r folder/'
    assert get_new_command(Command('git rm folder')) == 'git rm -r folder'

# Generated at 2022-06-26 06:20:30.523442
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing path/to/file recursively without -r')
    assert get_new_command(command) == 'git rm -r file'
    command = Command('git rm -f file', 'fatal: not removing path/to/file recursively without -r')
    assert get_new_command(command) == 'git rm -f -r file'
    command = Command(
        'git -C /path/to/dir rm -f file',
        'fatal: not removing path/to/file recursively without -r')
    assert get_new_command(command) == 'git -C /path/to/dir rm -f -r file'

# Generated at 2022-06-26 06:20:34.625885
# Unit test for function match
def test_match():
    assert match(Command('git rm -r --cached myfolder',
                         'fatal: not removing '
                         '\'myfolder\' recursively without -r'))


# Generated at 2022-06-26 06:20:47.415525
# Unit test for function match
def test_match():
    assert match(Command('git add -A', '', ''))
    assert match(Command('git add .', '', ''))
    assert match(Command('git add .', '', ''))
    assert match(Command('git add .', '', ''))
    assert not match(Command('ls', '', ''))
    assert not match(Command('git add .', '', ''))



# Generated at 2022-06-26 06:20:49.007729
# Unit test for function match
def test_match():
    script = 'git rm test.py'
    output = "fatal: not removing 'test.py' recursively without -r"
    assert match(Command(script, output))


# Generated at 2022-06-26 06:20:56.454987
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("rm test/cass/t") == "git rm -r test/cass/t"
    assert get_new_command("rm -f -- /") == "rm -r -f -- /"
    assert get_new_command("git rm test/cass/t") == "git rm -r test/cass/t"

# Generated at 2022-06-26 06:21:02.924361
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck import shells
    from thefuck.types import Command
    correct_command = 'git rm -r {}'.format(shells.and_('file1', 'file2'))
    assert ('git rm {}'.format(shells.and_('file1', 'file2')),
            'fatal: not removing \'file1\' recursively without -r')\
        == Command('git rm {}'.format(shells.and_('file1', 'file2')),
                   'fatal: not removing \'file1\' recursively without -r\n')



# Generated at 2022-06-26 06:21:07.333267
# Unit test for function match
def test_match():
    assert match("git rm file")
    assert match("git rm -f file")
    assert match("git rm -f file1 file2 file3")
    assert match("git rm -rf file1 file2 file3")

    assert not match("git rm")
    assert not match("git rm -rf")
    assert not match("git rm -f file1 file2 file3 -r --all")
    assert not match("git rm -r file")
    assert not match("git rm file1 file2 file3 -r --all")



# Generated at 2022-06-26 06:21:09.984036
# Unit test for function match
def test_match():
    assert match(Command('git rm a'))    
    assert match(Command('git rm -r a'))    
    assert not match(Command('git rm -r a b'))    



# Generated at 2022-06-26 06:21:12.961891
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file1')
    assert git_rm('', command) == 'git rm -r file1'
    command = Command('git rm file1 file2')
    assert git_rm('', command) == 'git rm -r file1 file2'

# Generated at 2022-06-26 06:21:17.084970
# Unit test for function match
def test_match():
    assert match(Command('git rm main.cpp'))
    assert not match(Command('main.cpp', ''))
    assert not match(Command('rm main.cpp', ''))


# Generated at 2022-06-26 06:21:19.412267
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm src && git rm -r src')
    assert get_new_command(command).script == 'git rm -r src && git rm -r -r src'

# Generated at 2022-06-26 06:21:20.764879
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm script', '', '')) == "git rm -r script"

# Generated at 2022-06-26 06:21:37.181482
# Unit test for function match
def test_match():
    assert match(Command('git rm scripts/test.py', '', '', '', ''))
    assert match(Command('git rm scripts/*.py', "fatal: not removing 'scripts/test.py' recursively without -r", '', '', ''))
    assert not match(Command('git rm scripts/*.py', '', '', '', ''))

# Generated at 2022-06-26 06:21:48.919668
# Unit test for function match
def test_match():
    assert (match(Command(script="git rm -rf \"javadoc/\xC3\xA4\"",
                        output="fatal: not removing 'javadoc/\xC3\xA4' recursively without -r"))
            == True)
    assert (match(Command(script="git rm -rf javadoc/",
                        output="fatal: not removing 'javadoc/' recursively without -r"))
            == True)
    assert (match(Command(script="git rm \"javadoc/\xC3\xA4\"",
                        output="fatal: not removing 'javadoc/\xC3\xA4' recursively without -r"))
            == True)

# Generated at 2022-06-26 06:21:56.903005
# Unit test for function match
def test_match():
    match_tests = [
        [u'git rm some_dir',True],
        [u'git rm some_dir some_other_dir',True],
        [u'git rm index.html',False],
        [u'git add index.html',False],
        [u'ls index.html',False],
    ]
    for test in match_tests:
        assert match(Command(script=test[0],output=''))==test[1]


# Generated at 2022-06-26 06:22:01.284513
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm d e', 'fatal: not removing \'d/e\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r d e'

# Generated at 2022-06-26 06:22:06.765174
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    disabled_rule, _ = get_new_command(Command('rm foo/bar',
        'fatal: not removing \'foo/bar\' recursively without -r\n',
        ''))
    assert disabled_rule == 'git rm -r foo/bar'

# Generated at 2022-06-26 06:22:11.597695
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo/bar', 'fatal: not removing \'foo/bar\' recursively without -r')
    assert u'git rm -r foo/bar' == get_new_command(command)

# Generated at 2022-06-26 06:22:17.472175
# Unit test for function match
def test_match():
  assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
  assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n'))
  assert not match(Command('git rm -r file', 'fatal: not removing \'file\''))

# Generated at 2022-06-26 06:22:27.721945
# Unit test for function match
def test_match():
    output = '''
    fatal: not removing 'app/Plugin/UserControl/controllers/users_controller.php' recursively without -r
    Did you mean this?
		rm -r app/Plugin/UserControl/controllers/users_controller.php
    '''
    command = Command('rm app/Plugin/UserControl/controllers/users_controller.php', output)
    assert match(command) == True


# Generated at 2022-06-26 06:22:34.146597
# Unit test for function match
def test_match():
    command = Command('git rm -r --cached my_file.py')
    assert match(command)
    command = Command('git rm my_file.py')
    assert not match(command)
    assert not match(Command('cd /tmp/'))
    assert not match(Command('git status'))


# Generated at 2022-06-26 06:22:37.240995
# Unit test for function match
def test_match():
    assert(match(Command('git rm file',
             'fatal: not removing \'file\' recursively without -r\n',
             '/home/desktop/project')))


# Generated at 2022-06-26 06:23:02.640723
# Unit test for function match
def test_match():
    assert match(Command('rm test.py',
                         "fatal: not removing 'test.py' recursively without -r"))
    assert not match(Command('rm test.py', "fatal: not removing 'test.py'"))


# Generated at 2022-06-26 06:23:11.739212
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf ./abc/',
                         'fatal: not removing \'./abc/\' recursively without -r'))
    assert match(Command('git rm -rf abc/',
                         'fatal: not removing \'abc/\' recursively without -r'))
    assert match(Command('git rm -rf ./abc/',
                         'fatal: not removing \'./abc/\' recursively without -r',
                         output=''))
    assert match(Command('git rm -rf abc/',
                         'fatal: not removing \'abc/\' recursively without -r',
                         output=''))
    assert not match(Command('git rm -r abc/',
                             'fatal: not removing \'abc/\' recursively without -r'))

# Generated at 2022-06-26 06:23:17.562610
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2','','fatal: not removing \'file1\' recursively without -r\n','',''))
    assert not match(Command('git rm -r file1 file2','','','',''))
    assert not match(Command('git rm file1 file2','','','',''))


# Generated at 2022-06-26 06:23:29.054328
# Unit test for function match

# Generated at 2022-06-26 06:23:33.716450
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r')
    assert('git rm -r test.txt' == get_new_command(command))


# Generated at 2022-06-26 06:23:37.540114
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r super', 'fatal: not removing \'super\' recursively without -r', '', 1)) == 'git rm -r -r super'

# Generated at 2022-06-26 06:23:42.821598
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm filename') == 'git rm -r filename'
    assert get_new_command('git rm -f filename') == 'git rm -r -f filename'
    assert get_new_command('git rm -f') == 'git rm -r -f'

# Generated at 2022-06-26 06:23:47.878817
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm file', 'fatal: not removing "file" recursively without -r')) == 'git rm -r file'
    assert get_new_command(Command('rm file', "fatal: pathspec 'file' did not match any files")) != 'git rm -r file'

# Generated at 2022-06-26 06:23:52.048749
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test',
        u"""fatal: not removing 'test' recursively without -r
        rm 'test'""", 1))



# Generated at 2022-06-26 06:24:00.664064
# Unit test for function get_new_command
def test_get_new_command():
	from thefuck.rules.git_force_rm import get_new_command
	from thefuck.types import Command
	command1 = Command('git rm -r foo',
	'fatal: not removing \'bar\' recursively without -r', '')
	command2 = Command('git rm -f foo',
	'fatal: not removing \'bar\' recursively without -r', '')
	command3 = Command('git rm foo',
	'fatal: not removing \'bar\' recursively without -r', '')
	assert get_new_command(command1) == 'git rm -r -r foo'
	assert get_new_command(command2) == 'git rm -r -f foo'
	assert get_new_command(command3) == 'git rm -r foo'

# Generated at 2022-06-26 06:24:52.759492
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script_parts':['git', 'rm', '.', '|', 'grep', '.']})
    assert get_new_command(command) == u"git rm -r . | grep ."

# Generated at 2022-06-26 06:25:00.937391
# Unit test for function match
def test_match():
    from thefuck.types import Command
    # Check that the error message is matched
    command = Command('git rm f -r', 'fatal: not removing \'f\' recursively without -r\n')
    assert match(command)
    # Check that the match fails if no error message is present
    command2 = Command('git rm f -r', '')
    assert not match(command2)
    # Check that the match fails if the error message is not complete
    command3 = Command('git rm f', 'fatal: not removing \'f\' recursively without -r\n')
    assert not match(command3)
    # Check that the match fails if the error message is incorrect
    command4 = Command('git rm f -r', 'fatal: not removing \'f\' recursively with -r\n')

# Generated at 2022-06-26 06:25:11.239093
# Unit test for function match
def test_match():
    assert match(Command("git rm *", ""))
    assert match(Command("git rm .", ""))
    assert match(Command("git rm hello", ""))
    assert match(Command("git rm 'hello'", ""))
    assert match(Command("git rm 'hello world'", ""))
    assert match(Command("git rm 'hello/world'", ""))
    assert match(Command("git rm 'hello//world'", ""))
    assert match(Command("git rm 'hello/world/toto'", ""))
    assert match(Command("git rm hello world", ""))
    assert match(Command("git rm 'hello world'", ""))

    assert not match(Command("git rm -r *", ""))
    assert not match(Command("git rm -rf *", ""))

# Generated at 2022-06-26 06:25:13.124231
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('haha rm src/')) == 'haha rm -r src/'

# Generated at 2022-06-26 06:25:21.307157
# Unit test for function get_new_command
def test_get_new_command():
	script = u"git rm hello.txt"
	output = "fatal: not removing 'hello.txt' recursively without -r"
	command = Command(script, output)
	assert get_new_command(command) == u"git rm -r hello.txt"

	script = u"git rm -rf hello.txt"
	output = "fatal: not removing 'hello.txt' recursively without -r"
	command = Command(script, output)
	assert get_new_command(command) == u"git rm -r -rf hello.txt"

	script = u"git rm -r hello.txt"
	output = "fatal: not removing 'hello.txt' recursively without -r"
	command = Command(script, output)

# Generated at 2022-06-26 06:25:25.169739
# Unit test for function get_new_command
def test_get_new_command():
    current = Command(u'git rm dir', u'fatal: not removing \'dir\' recursively without -r', '')
    new_command = get_new_command(current)

    assert u"git rm -r dir" == new_command

# Generated at 2022-06-26 06:25:26.415080
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm -d")) == "git rm -d -r"

# Generated at 2022-06-26 06:25:30.338288
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'
    assert get_new_command(Command('git rm -f file')) == 'git rm -f -r file'
    assert get_new_command(Command('git rm file path')) == 'git rm -r file path'


# Generated at 2022-06-26 06:25:35.830051
# Unit test for function match
def test_match():
    assert(match(Command('git rm -r --cached')) == False)
    assert(match(Command('git rm -r --cached',
        "fatal: not removing 'public/assets/manifest*.json' recursively without -r\n")) == True)
    assert(match(Command('git rm -r --cached',
        "fatal: not removing 'public/assets/manifest*.json', has submodule at 'public/assets/manifest*.json'\n")) == False)

# Generated at 2022-06-26 06:25:39.022590
# Unit test for function get_new_command
def test_get_new_command():
    command = type("Command", (), {"script": "git rm random.py", "output": "fatal: not removing 'random.py' recursively without -r"})
    assert get_new_command(command) == "git rm -r random.py"

# Generated at 2022-06-26 06:27:33.865408
# Unit test for function match
def test_match():
    command = Command('git rm file', 'fatal: not removing '\
                                    + "'.gitignore' recursively without -r\n")
    assert match(command)

# Generated at 2022-06-26 06:27:37.626827
# Unit test for function match
def test_match():
    assert match(Command('git rm filename',
                         'fatal: not removing \'filename\' recursively without -r',
                         ''))
    assert not match(Command('git rm filename',
                             'fatal: not removing \'filename\' recursively with or without -r',
                             ''))


# Generated at 2022-06-26 06:27:39.822513
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm ./test/test')) == 'git rm -r ./test/test'

# Generated at 2022-06-26 06:27:41.706473
# Unit test for function match
def test_match():
    assert match(Command('git rm *.py',
        'fatal: not removing \'docs/conf.py\' recursively without -r\n',
        '', 0))

# Generated at 2022-06-26 06:27:43.354560
# Unit test for function match
def test_match():
    assert match(Command('git rev-parse --git-dir', 'fatal: not removing'))
    assert not match(Command('git rm .', ''))
    assert not match(Command('git rev-parse --git-dir', ''))


# Generated at 2022-06-26 06:27:45.531614
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git rm test",
                                   output="fatal: not removing 'test' recursively without -r")) == 'git rm -r test'

# Generated at 2022-06-26 06:27:46.285598
# Unit test for function match
def test_match():
    assert match(command)


# Generated at 2022-06-26 06:27:52.731069
# Unit test for function match
def test_match():
    assert match(Command('rm', script='rm -rf stuff',
                         output='fatal: not removing "otherstuff" recursively without -r'))
    assert not match(Command('rm', script='rm stuff',
                             output='fatal: not removing "otherstuff" recursively without -r'))
    assert not match(Command('rm', script='rm',
                             output='fatal: not removing "otherstuff"  without -r'))


# Generated at 2022-06-26 06:27:59.908270
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r /tmp/srcDIR', 'fatal: not removing \'srcDIR\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r -r /tmp/srcDIR'
    command = Command('git rm -r /tmp/srcDIR /tmp/destDIR', 'fatal: not removing \'srcDIR\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r -r /tmp/srcDIR /tmp/destDIR'

# Generated at 2022-06-26 06:28:01.236457
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'