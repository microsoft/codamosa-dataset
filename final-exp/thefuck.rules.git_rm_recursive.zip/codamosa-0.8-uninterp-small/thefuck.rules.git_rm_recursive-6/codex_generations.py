

# Generated at 2022-06-26 06:18:13.817499
# Unit test for function match
def test_match():
    command = Command(' rm -r --cached tmp.txt', 'fatal: not removing \'tmp.txt\' recursively without -r\n')
    assert match(command)
    command = Command('git status', '# On branch master\n#\n# Initial commit\n#\n# Untracked files:\n#   (use "git add <file>..." to include in what will be committed)\n#\n#\ttmp.txt\nnothing added to commit but untracked files present (use "git add" to track)\n')
    assert not match(command)

# Generated at 2022-06-26 06:18:16.250882
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(function) == ' ')

# Generated at 2022-06-26 06:18:24.983549
# Unit test for function match
def test_match():
    str_0 = 'git commit -m \'Initial commit\''
    var_0 = match(str_0)
    assert not var_0
    str_1 = ''
    var_1 = match(str_1)
    assert not var_1
    str_2 = 'git rm --cached -r'
    var_2 = match(str_2)
    assert not var_2
    str_3 = 'git rm -rf public/uploads'
    var_3 = match(str_3)
    assert not var_3
    str_4 = 'git commit -m \'Update README.md\''
    var_4 = match(str_4)
    assert not var_4
    str_5 = 'git commit -m \'Update Documentation\''
    var_5 = match(str_5)
    assert not var

# Generated at 2022-06-26 06:18:35.161477
# Unit test for function match
def test_match():
    command = Command(script='git rm a_file', output='error: unable to unlink old '
            '\'a_file\': Permission denied\nfatal: not removing '
            '\'.gitignore\' recursively without -r\n')
    assert match(command)
    command = Command(script='git rm -i a_file', output='error: unable to unlink old '
            '\'a_file\': Permission denied\nfatal: not removing '
            '\'.gitignore\' recursively without -r\n')
    assert not match(command)
    command = Command(script='git rm', output='error: unable to unlink old '
            '\'a_file\': Permission denied\nfatal: not removing '
            '\'.gitignore\' recursively without -r\n')

# Generated at 2022-06-26 06:18:40.149471
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'git rm -r readme.txt'
    str_1 = 'fatal: not removing \'readme.txt\' recursively without -r\ngit rm readme.txt'
    var_0 = get_new_command(str_0, str_1)
    assert var_0 == 'git rm -r -r readme.txt'



# Generated at 2022-06-26 06:18:45.773366
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'git rm -r test_0.py'
    str_1 = 'fatal: not removing \'test_0.py\' recursively without -r'
    var_0 = get_new_command(str_0, str_1)

# Generated at 2022-06-26 06:18:53.108619
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'git rm --cached'
    str_1 = 'fatal: not removing \'file.txt\' recursively without -r'
    command = Command(str_0, str_1)
    var_0 = get_new_command(command)
    var_1 = 'git rm -r --cached'
    # Should not raise exception if not implemented
    pass



# Generated at 2022-06-26 06:18:56.722698
# Unit test for function match
def test_match():
    assert match('git rm foo')
    assert match('git rm -r foo')
    assert not match('git foo')


# Generated at 2022-06-26 06:19:01.843017
# Unit test for function get_new_command

# Generated at 2022-06-26 06:19:08.802923
# Unit test for function match
def test_match():
    command = Command('git rm foo.txt', stderr='fatal: not removing \'foo.txt\' recursively without -r')
    assert match(command)
    command = Command('git rm foo.txt', stderr='fatal: not removing \'foo.txt\' recursively without -r\nbar')
    assert not match(command)



# Generated at 2022-06-26 06:19:22.867885
# Unit test for function match
def test_match():
    assert match(' git rm ') is None
    assert match(' git rm -r ') is None
    assert match(' git add a') is None
    assert match(' git rm a') is None
    assert match(' git rm -r a') is None
    assert match(' git rm -r a') is None
    assert match(' git rm a') is None
    assert match(' git rm a') is None
    assert match(' git rm  ') is None
    assert match(' git rm  ') is None
    assert match(' git rm  ') is None
    assert match(' git add  ') is None
    assert match(' git rm  ') is None
    assert match(' git rm  ') is None
    assert match(' git rm  ') is None
    assert match(' git rm  ') is None
    assert match(' git rm  ')

# Generated at 2022-06-26 06:19:30.006505
# Unit test for function match
def test_match():
    str_0 = 'git rm dir\nfatal: not removing "dir" recursively without -r\n'
    var_0 = match(str_0)
    str_1 = 'git rm dir\nfatal: not removing "dir" recursively without -r\n'
    var_1 = match(str_1)


# Generated at 2022-06-26 06:19:33.238221
# Unit test for function match
def test_match():
    assert match('git rm --cached -r dir')
    assert not match('git rm -r dir')
    assert not match('git rm -r dir/')
    assert not match('git rm dir/')
    assert not match('git rm -r dir/')
    assert not match('git rm dir')
    assert not match('git rm')


# Generated at 2022-06-26 06:19:35.320405
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = ''
    var_0 = get_new_command(str_0)
    assert var_0 == ''


if __name__ == '__main__':
    test_case_0()
    test_get_new_command()

# Generated at 2022-06-26 06:19:43.310486
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = ["git", "rm", "fatal:", "not", "removing", "'branch_name'", "recursively", "without", "-r"]
    var_0 = match(git.GitCommand(str_0, "", ""))
    assert var_0 is True
    var_1 = get_new_command(git.GitCommand(str_0, "", ""))
    assert var_1 == u"git rm -r fatal: not removing 'branch_name' recursively without -r"


if __name__ == '__main__':
    test_case_0()
    test_get_new_command()

# Generated at 2022-06-26 06:19:53.480977
# Unit test for function match
def test_match():
    var_0 = 'git rm -r'
    str_0 = Command(var_0)
    var_1 = match(str_0)
    var_2 = 'git rm'
    str_1 = Command(var_2)
    var_3 = match(str_1)
    var_4 = 'git rm abc'
    str_2 = Command(var_4)
    var_5 = match(str_2)
    var_6 = "git rm 'a b c'"
    str_3 = Command(var_6)
    var_7 = match(str_3)
    var_8 = 'git rm -r a'
    str_4 = Command(var_8)
    var_9 = match(str_4)

# Generated at 2022-06-26 06:19:59.443185
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'git rm -r test'
    var_0 = get_new_command(str_0)

# Generated at 2022-06-26 06:20:07.767213
# Unit test for function match
def test_match():
    # Test 1
    str_0 = 'git pull\n' \
                 'error: Your local changes to the following files would be overwritten by merge:\n' \
                 '	README.md\n' \
                 'Please commit your changes or stash them before you merge.\n' \
                 'Aborting\n'

    var_0 = match(str_0)
    assert var_0 == False

    # Test 2
    str_0 = 'git config --global alias.br branch\n' \
                 'error: could not lock config file .git/config: Permission denied\n'

    var_0 = match(str_0)
    assert var_0 == False

    # Test 3

# Generated at 2022-06-26 06:20:15.528176
# Unit test for function match
def test_match():
    str_0 = "error: unable to delete 'grep-2.21/doc/grep.info': Permission denied"
    var_0 = match(str_0)
    assert var_0 == ' rm ' in str_0 and "fatal: not removing '" in str_0 and "' recursively without -r" in str_0


# Generated at 2022-06-26 06:20:17.044876
# Unit test for function get_new_command
def test_get_new_command():
    print('Testing get_new_command')
    assert get_new_command('') == ' '

# Generated at 2022-06-26 06:20:21.795761
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = ''
    var_0 = get_new_command(str_0)

# Generated at 2022-06-26 06:20:31.991019
# Unit test for function match
def test_match():
    str_0 = 'git rm -r test_branch'
    output = 'fatal: not removing \'test_branch\' recursively without -r'
    var_0 = MagicMock(script=str_0, output=output)
    res_0 = match(var_0)
    str_1 = 'git rm -r test_branch'
    output_1 = "fatal: not removing 'test_branch' recursively without -r"
    var_1 = MagicMock(script=str_1, output=output_1)
    res_1 = match(var_1)
    str_2 = 'rm test_branch'
    output_2 = "fatal: not removing 'test_branch' recursively without -r"

# Generated at 2022-06-26 06:20:34.195422
# Unit test for function match
def test_match():
    assert match(u'git rm -r --cached .idea')



# Generated at 2022-06-26 06:20:44.531286
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'git rm foo'
    var_0 = get_new_command(str_0)
    str_1 = 'git rm -r foo'
    var_1 = get_new_command(str_1)

    if var_0 == var_1:
        print('Success')
    else:
        err_msg = 'Failure'
        raise Exception(err_msg)

# Generated at 2022-06-26 06:20:49.833683
# Unit test for function get_new_command
def test_get_new_command():
    def test_get_new_command_0():
        str_0 = 'git rm file.txt'
        var_0 = get_new_command(str_0)

if __name__ == '__main__':
    test_case_0()
    test_get_new_command_0()

# Generated at 2022-06-26 06:21:00.771508
# Unit test for function match
def test_match():
    command = 'git rm /etc/init.d/couchdb'
    output = """fatal: not removing '/etc/init.d/couchdb' recursively without -r"""
    assert match(command, output)

    command = 'git rm /etc/init.d/couchdb'
    output = """fatal: not removing '/etc/init.d/couchdb' recursively without -r
"""
    assert match(command, output)

    command = 'git rm /etc/init.d/couchdb'
    output = """fatal: not removing '/etc/init.d/couchdb' recursively without -r

"""
    assert match(command, output)


# Generated at 2022-06-26 06:21:02.710351
# Unit test for function match
def test_match():
    assert git_support

# Generated at 2022-06-26 06:21:07.661501
# Unit test for function match
def test_match():
    str_0 = ''
    var_0 = match(str_0)
    str_1 = ''
    var_1 = match(str_1)
    str_2 = ''
    var_2 = match(str_2)

# Generated at 2022-06-26 06:21:10.624818
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('git rm foo/') == 'git rm -r foo/')
    assert (get_new_command('git rm foo') == 'git rm -r foo')
    assert (get_new_command('git rm foo/') == 'git rm -r foo/')

# Generated at 2022-06-26 06:21:12.111278
# Unit test for function get_new_command
def test_get_new_command():
  assert get_new_command() == 'git add <file_name>'

# Generated at 2022-06-26 06:21:23.848151
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script = 'git rm -f *', output = "fatal: not removing '.' recursively without -r\nfatal: not removing '..' recursively without -r\nfatal: not removing 'filename' recursively without -r")
    assert type(get_new_command(command)) == str
    assert get_new_command(command) == 'git rm -f -r *'
    command_2 = Command(script = 'git rm -f file1 file2', output = "fatal: not removing '.' recursively without -r\nfatal: not removing '..' recursively without -r\nfatal: not removing ''file1' and ''file2' recursively without -r")
    assert type(get_new_command(command_2)) == str
    assert get_new_command

# Generated at 2022-06-26 06:21:27.911923
# Unit test for function match
def test_match():
    command = Command('git rm foo', '', '', '', '', '')
    assert match(command)

    command = Command('git rm ', '', '', '', '', '')
    assert not match(command)

    command = Command('git rm foo', 'git rm: pathspec \'foo\' did not match any files', '', '', '', '')
    assert not match(command)


# Generated at 2022-06-26 06:21:34.179997
# Unit test for function match
def test_match():
    assert match(Command('git rm test', '', 'error: pathspec \'test\' did not match any file(s) known to git.'))
    assert match(Command('git rm -r', '', 'fatal: not removing \'-r\' recursively without -r'))


# Generated at 2022-06-26 06:21:37.218959
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r test' == get_new_command(
        Command('git rm test', 'fatal: not removing \'test\' recursively without -r',
                ''))

# Generated at 2022-06-26 06:21:45.777874
# Unit test for function match
def test_match():
    assert match(Command('git rm file/',
                stderr='fatal: not removing \'file/\' recursively without -r'))
    assert not match(Command('git rm file',
                stderr='fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file/',
                 stderr='fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-26 06:21:46.996925
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm -f /some/file')) ==  'git rm -rf -f /some/file'

# Generated at 2022-06-26 06:21:50.250026
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(os.system("git rm test.txt")) == "git rm -r test.txt"

# Generated at 2022-06-26 06:21:59.626577
# Unit test for function match
def test_match():
    assert match(Command("git rm img/image_not_found.png", "fatal: not removing 'img/image_not_found.png' recursively without -r"))
    assert not match(Command("git rm img/image_not_found.png", ""))
    assert not match(Command("git rm -r img/image_not_found.png", "fatal: not removing 'img/image_not_found.png' recursively without -r"))
    assert not match(Command("git log img/image_not_found.png", "fatal: not removing 'img/image_not_found.png' recursively without -r"))


# Generated at 2022-06-26 06:22:02.604167
# Unit test for function match
def test_match():
    assert not match(Command('git rm file_name', '', ''))
    assert match(command = Command(script = 'git rm -f file_name', output = 'fatal: not removing \'file_name\' recursively without -r\n', stderr = ''))



# Generated at 2022-06-26 06:22:10.857385
# Unit test for function match
def test_match():

    # function should return False if "git rm" not in script
    script = "git commit -a -m 'no rm in this script'"
    assert(not match(Command(script=script, output="")))

    # function should return False if "rm" in script, but no error message
    script = "git rm 'not an empty output'"
    assert(not match(Command(script=script, output="")))

    # function should return False if "rm" in script, but no error message
    script = "git rm 'not an empty output'"
    assert(not match(Command(script=script, output="")))

    # function should return True if "rm" in script, and error message present
    script = "git rm 'fatal: not removing not-a-folder'"

# Generated at 2022-06-26 06:22:17.764565
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm test/test.pyc", "")) == "git rm -r test/test.pyc"

# Generated at 2022-06-26 06:22:26.998138
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf foobar', 
                         'fatal: not removing \'foobar\' recursively without -r', 
                         '')) is True
    assert match(Command('git add foobar', 
                         'fatal: pathspec \'foobar\' did not match any files', 
                         '')) is False


# Generated at 2022-06-26 06:22:36.731165
# Unit test for function match
def test_match():
    command = Command('git remote rm origin', "fatal: not removing 'origin'"
            " recursively without -r")
    assert match(command)
    command = Command('git remote rm origin', "fatal: not removing 'origin'"
            " recursively")
    assert not match(command)
    command = Command('git remote rm origin', "fatal: not removing 'origin'")
    assert not match(command)
    command = Command('git remote rm origin', "fatal: without -r"
            " recursively")
    assert not match(command)


# Generated at 2022-06-26 06:22:41.290356
# Unit test for function match
def test_match():
    assert match(Command('git status', "fatal: not removing '.' recursively without -r", '', 1))
    assert not match(Command('git status', '', '', 1))


# Generated at 2022-06-26 06:22:45.346752
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm file") == u'git rm -r file'
    assert get_new_command("git add file") == u'git add file'

# Generated at 2022-06-26 06:22:47.476997
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('rm file')) == 'git rm -r file'

# Generated at 2022-06-26 06:22:51.040339
# Unit test for function match
def test_match():
    assert match(Command('git rm src/main.cc',
        "fatal: not removing 'src/main.cc' recursively without -r"))



# Generated at 2022-06-26 06:22:59.131949
# Unit test for function match
def test_match():
    assert match(Command(script='git rm q', output="fatal: not removing 'q' recursively without -r"))
    assert not match(Command(script='git rm q', output='fatal: pathspec \'q\' did not match any files'))
    assert not match(Command(script='git rm q', output='fatal: not removing \'q\' recursively without'))
    assert not match(Command(script='git rm q', output='fatal: not removing \'q\' p'))
    assert not match(Command(script='gitrmq', output='fatal: not removing \'q\' recursively without -r'))


# Generated at 2022-06-26 06:23:06.343098
# Unit test for function match
def test_match():
    command = 'git rm -r folderA'
    assert(match(Command(command, 'fatal: not removing \'folderA\' recursively without -r\n')) == True)
    command = 'git rm folderA'
    assert(match(Command(command, 'fatal: not removing \'folderA\' recursively without -r\n')) == False)
    command = 'rm -r folderA'
    assert(match(Command(command, 'fatal: not removing \'folderA\' recursively without -r\n')) == False)


# Generated at 2022-06-26 06:23:08.157226
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm -R file', '')) == 'git rm -r -R file'

# Generated at 2022-06-26 06:23:23.109000
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm foo", "fatal: not removing 'foo/bar.py' recursively without -r")
    assert("git rm -r foo" == get_new_command(command))

# Generated at 2022-06-26 06:23:26.734829
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm lol", "fatal: not removing 'lol' recursively without -r")
    assert get_new_command(command) == "git rm -r lol"

# Generated at 2022-06-26 06:23:28.924419
# Unit test for function match
def test_match():
    assert match(Command('git rm path/go/', 'fatal: not removing '
                                            'path/go/ recursively without -r'))


# Generated at 2022-06-26 06:23:38.196132
# Unit test for function get_new_command
def test_get_new_command():
    command_test = u'git rm test'
    from thefuck.rules.git_rm import get_new_command
    assert get_new_command(command_test).script == 'git rm -r test'
    command_test = u'git rm -r test'
    assert get_new_command(command_test).script == 'git rm -r -r test'
    command_test = u'git rm test st>'
    assert get_new_command(command_test).script == 'git rm -r test st>'



# Generated at 2022-06-26 06:23:45.537928
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', output="fatal: not removing 'foo' recursively without -r"))
    assert match(Command('git rm foo', output="fatal: not removing 'foo' recursively without -r"))
    assert not match(Command('git rm foo', output="fatal: not removing 'foo' recursively with -r"))


# Generated at 2022-06-26 06:23:51.391011
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test1', 'fatal: not removing \'test1\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r test1'
    command = Command('git rm -rf test1', 'fatal: not removing \'test1\' recursively without -r')
    assert get_new_command(command) == 'git rm -rf -r test1'
    command = Command('git rm --cached test1', 'fatal: not removing \'test1\' recursively without -r')
    assert get_new_command(command) == 'git rm --cached -r test1'


enabled_by_default = True

# Generated at 2022-06-26 06:23:58.809167
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm',
                'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -r',
                            'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
                'fatal: not removing \'file\' recursively with -r'))


# Generated at 2022-06-26 06:24:03.664157
# Unit test for function match
def test_match():
    assert match(Command("git rm \"dir/\"", "fatal: not removing 'dir/' recursively without -r"))
    assert not match(Command("git rm \"file.txt\"", "rm 'file.txt'"));



# Generated at 2022-06-26 06:24:05.522124
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file') == 'git rm -r file'

# Generated at 2022-06-26 06:24:07.170356
# Unit test for function match
def test_match():
    assert match(Command('git rm test', 'fatal: not removing test recursively without -r'))
    assert not match(Command('git commit', ''))

# Generated at 2022-06-26 06:24:39.836253
# Unit test for function match
def test_match():
	assert match(Command('git rm -r -f --cached --ignore-unmatch config/settings/local.py', \
    					'''fatal: not removing 'config/settings/local.py' recursively without -r''', '')) == True
	assert match(Command('git rm -r -f --cached --ignore-unmatch config/settings/local.py', \
    					'''fatal: not removing 'config/settings/local2.py' recursively without -r''', '')) == False
	assert match(Command('git rm -r -f --cached --ignore-unmatch config/settings/local.py', \
    					'''fatal: not removing 'config/settings/local.py' recursively without -r''', '')) == True
	assert match

# Generated at 2022-06-26 06:24:47.221276
# Unit test for function match
def test_match():
    # Test 1: rm does not exist in the command
    assert match(Command('git status', '')) == False

    # Test 2: rm exists in the command, fatal: not removing exists in command, but ' recursively without -r' does not exist in the command
    assert match(Command('git rm apple', 'error: unable to find apple')) == False

    # Test 3: rm exists in the command, ' recursively without -r' exists in the command, but fatal: not removing does not exist in the command
    assert match(Command('git rm apple', 'fatal: apple recursively without -r')) == False

    # Test 4: rm exists in the command, ' recursively without -r' does not exist in the command, but fatal: not removing exists in the command

# Generated at 2022-06-26 06:24:54.551630
# Unit test for function match
def test_match():
    # Error if none of these are in the output of the command
    assert match(Command('rm')) == False
    assert match(Command('git rm')) == False
    assert match(Command('git rm file')) == False
    assert match(Command('git rm / file')) == False
    assert match(Command('git rm / file',
                         'fatal: not removing')) == False
    # Should be true if all conditions are met
    assert match(Command('git rm / file',
                         'fatal: not removing',
                         'recursively')) == True


# Generated at 2022-06-26 06:24:57.447903
# Unit test for function match
def test_match():
    assert match(Command('git rm ab',
                         "fatal: not removing 'ab' recursively without -r"))
    assert not match(Command('rm ab',
                             "fatal: not removing 'ab' recursively without -r"))

# Generated at 2022-06-26 06:24:59.068161
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm notremoving")) == 'git rm -r notremoving'

# Generated at 2022-06-26 06:25:01.886794
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file.txt', '')
    new_command = get_new_command(command)
    assert new_command == 'git rm -r file.txt'
    command = Command('git rm file.txt -f', '')
    new_command = get_new_command(command)
    assert new_command == 'git rm -r -f file.txt'

# Generated at 2022-06-26 06:25:03.625902
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm dir1', 'fatal: not removing \'dir1\' recursively without -r\n')) == u'git rm -r dir1'

# Generated at 2022-06-26 06:25:07.379404
# Unit test for function get_new_command
def test_get_new_command():
    output = "fatal: not removing 'Folder/' recursively without -r"
    command = Command("git rm Folder/", output)

    assert "git rm -r Folder/" == get_new_command(command)



# Generated at 2022-06-26 06:25:11.628842
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -rf a/b/c/d/e',
                                   "fatal: not removing 'a/b/c/d/e' recursively without -r", '')) == "git rm -rf a/b/c/d/e"

# Generated at 2022-06-26 06:25:18.533005
# Unit test for function get_new_command
def test_get_new_command():
    assert match(Command('git rm file1 file2 file3',
                         'fatal: not removing \'file1\' recursively without -r'))
    assert get_new_command(Command('git rm file1 file2 file3',
                                   'fatal: not removing \'file1\' recursively without -r')) == 'git rm -r file1 file2 file3'
    assert not match(Command('git rm file1 file2 file3',
                             'fatal: not removing \'file1\' without -r'))
    assert not match(Command('git rm file1 file2 file3'))

# Generated at 2022-06-26 06:26:15.674075
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r testfolder", "fatal: not removing 'testfolder' recursively without -r")
    actual_command = get_new_command(command)
    expected_command = "git rm -r -r testfolder"
    assert actual_command == expected_command

# Generated at 2022-06-26 06:26:20.398694
# Unit test for function match
def test_match():
    assert match(Command(script="git rm some-file",
                         output="fatal: not removing 'some-file' recursively without -r"))
    assert not match(Command(script="git rm some-file",
                             output="fatal: not removing without -r"))
    assert not match(Command(script="git rm some-file",
                             output="fatal: not removing 'some-file' recursively"))


# Generated at 2022-06-26 06:26:22.502861
# Unit test for function match
def test_match():
    assert match(Command('git rm -r --cached .',
                         'fatal: not removing \'foo/bar\' recursively without -r'))

# Generated at 2022-06-26 06:26:33.917115
# Unit test for function match
def test_match(): 
    assert match(Command(script=' git rm -r test_match', 
        output='fatal: not removing \'test_match\' recursively without -r')
    ) is True
    assert match(Command(script=' git rm test_match', 
        output='fatal: not removing \'test_match\' recursively without -r')
    ) is False
    assert match(Command(script=' git rm', 
        output='fatal: not removing \'test_match\' recursively without -r')
    ) is False
    assert match(Command(script='git rm -r test_match', 
        output='fatal: not removing \'test_match\' recursively without -r')
    ) is False

# Generated at 2022-06-26 06:26:36.279535
# Unit test for function match
def test_match():
    assert match(Command('git rm hello',
                         'fatal: not removing \'sub\' recursively without -r',
                         ''))

    assert match(Command('rm test',
                         "rm: cannot remove `test/sub': Is a directory",
                         '')) is False



# Generated at 2022-06-26 06:26:40.957936
# Unit test for function match
def test_match():
    assert match(Command('git rm folder', 'fatal: not removing \'folder\' recursively without -r'))
    assert not match(Command('git ds folder', 'fatal: not removing \'folder\' recursively without -r'))
    assert not match(Command('git ds folder', 'fatal: not removing \'folder\' recursively with -r'))


# Generated at 2022-06-26 06:26:45.491287
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git rm -f file1 file2')
    assert get_new_command(command1) == 'git rm -r -f file1 file2'
    command2 = Command('git rm -f file1 file2')
    assert get_new_command(command2) == 'git rm -f -r file1 file2'

# Generated at 2022-06-26 06:26:47.131882
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert u'git rm -r file' == get_new_command(command)

# Generated at 2022-06-26 06:26:53.322208
# Unit test for function match
def test_match():
    script = 'git rm file.class'
    output = 'fatal: not removing \'file.class\' recursively without -r'
    command = Command(script, output)
    print('test_match 1')
    assert(match(command) == True)
    script = 'git rm file.class'
    output = 'fatal: not removing \'file.class\' recursively without -r\n'
    command = Command(script, output)
    print('test_match 2')
    assert(match(command) == True)


# Generated at 2022-06-26 06:26:56.702349
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', '', '')
    assert get_new_command(command) == 'git rm -r file'