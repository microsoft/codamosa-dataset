

# Generated at 2022-06-22 01:55:15.183077
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    assert get_new_command(Command('git rm filename')) == 'git rm -r filename'
    assert get_new_command(Command('git rm -rf path/')) == 'git rm -rf -r path/'

# Generated at 2022-06-22 01:55:21.390805
# Unit test for function match
def test_match():
    assert not match(Command(script='ls', output='fatal: not removing'
                    '\'/tmp/foo\' recursively without -r'))
    assert match(Command(script='git rm foo', output='fatal: not removing'
                         '\'/tmp/foo\' recursively without -r'))
    assert match(Command(script='rm foo', output='fatal: not removing'
                         '\'/tmp/foo\' recursively without -r'))


# Generated at 2022-06-22 01:55:22.383909
# Unit test for function match
def test_match():
    assert match(u"git rm '*.xcodeproj'")


# Generated at 2022-06-22 01:55:32.019514
# Unit test for function match
def test_match():
    assert match(Command('rm file/',
                         stderr='fatal: not removing \'file/\' recursively without -r\n'))
    assert not match(Command('rm file',
                         stderr='fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('rm file/',
                         stderr='fatal: not removing \'file/\' recursively without -r'))
    assert not match(Command('rm file/',
                         stderr='fatal: not removing \'file/\' recursively without -r\n',
                         output='error'))
    assert not match(Command('', stderr=None))


# Generated at 2022-06-22 01:55:34.813357
# Unit test for function match
def test_match():
    assert match(Command('rm -f file', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -f file', 'fatal: not removing \'file\' recursively without -r'))


# Generated at 2022-06-22 01:55:38.670972
# Unit test for function get_new_command
def test_get_new_command():
    command = u"rm -rf ./dir.name"
    command_obj = Command(command, "")
    new_command = get_new_command(command_obj)
    expected = u"git rm -r -r -f ./dir.name"
    assert new_command == expected

# Generated at 2022-06-22 01:55:45.356570
# Unit test for function match
def test_match():
    command = Command('rm foo', 'fatal: not removing \'foo\' recursively without -r')
    assert match(command)
    command = Command('rm foo', 'fatal: not removing \'foo\' recursively without -r', 'git')
    assert match(command)
    command = Command('rm foo', 'fatal: not removing \'foo\' recursively without -r', 'git')
    assert match(command)


# Generated at 2022-06-22 01:55:49.957562
# Unit test for function match
def test_match():
    
    # Not applicable
    assert match(Command('git diff', '', '', 'git', '')) == False
    assert match(Command('git pull', '', '', 'git', '')) == False
    assert match(Command('git checkout branch', '', '', 'git', '')) == False

    # Valid
    assert match(Command('git rm test', '', 'fatal: not removing \'test\' recursively without -r\n', 'git', '')) == True
    

# Generated at 2022-06-22 01:55:53.298749
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r hello.txt', 'fatal: not removing \'hello.txt\' recursively without -r')) == 'git rm -r -r hello.txt'

# Generated at 2022-06-22 01:56:04.132724
# Unit test for function match
def test_match():
    command = Command('rm file',
        'fatal: not removing \'file\' recursively without -r\n')
    assert match(command)

    command = Command('rm file',
        'fatal: not removing \'file\' recursively without -r')
    assert match(command)

    command = Command('rm file',
        'fatal: not removing \'file\' recursively without -r\n\
fatal: Unable to create \'.git/index.lock\': File exists.\n\
Another git process seems to be running in this repository, e.g.\n\
an editor opened by \'git commit\'. Please make sure all processes\n\
are terminated then try again. If it still fails, a git process\n\
may have crashed in this repository earlier:')
    assert not match(command)


# Generated at 2022-06-22 01:56:08.194464
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r', 'fatal: not removing \'test\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r'

# Generated at 2022-06-22 01:56:17.354410
# Unit test for function match
def test_match():
    assert match(Command('git rm a', '', 'fatal: not removing \'a\' recursively without -r',
                         '', 0))
    assert match(Command('git rm -r a', '', 'fatal: not removing \'a\' recursively without -r',
                         '', 0))
    assert not match(Command('git rm -r a', '', 'fatal: \'a\' is not a valid path',
                             '', 0))
    assert not match(Command('git rm a', '', 'fatal: \'a\' is not a valid path',
                             '', 0))


# Generated at 2022-06-22 01:56:21.575775
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                      '',
                      'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm',
                         '',
                         'fatal: not removing \'\' recursively without -r'))


# Generated at 2022-06-22 01:56:25.042894
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command(script="git add test",
                                   output="fatal: not removing 'backup/test' recursively without -r")) ==
           "git rm -r test")



# Generated at 2022-06-22 01:56:30.887085
# Unit test for function match
def test_match():
    assert match(Command('git rm a'))
    assert not match(Command('git rm a', 
                             output='fatal: not removing \'a\''))
    assert not match(Command('git rm a',
                             output='fatal: not removing \'a\' recursively'))
    assert not match(Command('git rm a',
                             output='fatal: not removing \'a\' without -r'))


# Generated at 2022-06-22 01:56:31.987474
# Unit test for function match

# Generated at 2022-06-22 01:56:34.140194
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git add -f -r .' == get_new_command('git add -f .')

# Generated at 2022-06-22 01:56:39.345391
# Unit test for function match
def test_match():
    assert match(Command('git rm test.txt',
                         'fatal: not removing \'test.txt\' recursively without -r\n'))
    assert not match(Command('git rm -r test.txt',
                             'fatal: not removing \'test.txt\' recursively without -r\n'))
    assert not match(Command('echo test', ''))



# Generated at 2022-06-22 01:56:42.397471
# Unit test for function match
def test_match():
    assert match(Command('rm foo',
                         'fatal: not removing \'foo\' recursively without -r\n',
                         ''))
    assert not match(Command('rm -r foo', '', ''))

# Generated at 2022-06-22 01:56:44.506971
# Unit test for function match
def test_match():
    assert match(Command('git rm test', 'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm test', 'fatal: not removing \'test\' without -r'))

# Generated at 2022-06-22 01:56:52.489356
# Unit test for function get_new_command
def test_get_new_command():
    output = u'fatal: not removing \'folder/file\' recursively without -r'
    thefuck_alias = 'fuck'
    thefuck_settings = {'exclude_rules': []}
    command = Command('git rm folder/file', output, thefuck_alias,
                      thefuck_settings, None)
    assert get_new_command(command) == 'git rm -r folder/file'

# Generated at 2022-06-22 01:56:59.578836
# Unit test for function match
def test_match():
    result = match('git branch -d branch-name')
    assert result == False
    result = match('git rm branch-name')
    assert result == False
    result = match('git rm -rbranch-name')
    assert result == False
    result = match('git rm branch-name')
    assert result == False
    result = match('git rm branch-name')
    assert result == False    
    result = match('git rm branch-name')
    assert result == False


# Generated at 2022-06-22 01:57:06.190841
# Unit test for function match
def test_match():
    output_test = 'fatal: not removing \'super/cool.MP4\' recursively without -r\n'
    script_test = 'git clean -f -d super/cool.MP4'
    command_test = CreateCommand(script_test, output_test)

    # Testing that the function match is returning True
    assert match(command_test)

    # Testing that the function match is returning False
    assert not match('git clean -f -d super/cool.MP4')


# Generated at 2022-06-22 01:57:06.576967
# Unit test for function get_new_command

# Generated at 2022-06-22 01:57:08.720889
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git rm myfile.txt', '')
    assert u'git rm -r myfile.txt' == get_new_command(command1)


# Generated at 2022-06-22 01:57:14.318760
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git rm -r src/'))
    assert u'git rm -r src/' == new_command
    new_command = get_new_command(Command('git rm src/'))
    assert u'git rm -r src/' == new_command

# Generated at 2022-06-22 01:57:15.552314
# Unit test for function match
def test_match():
	assert match(Command('git rm -f *.txt', ''))


# Generated at 2022-06-22 01:57:19.494347
# Unit test for function match
def test_match():
    assert match(Command('git rm -r folder1',
                         'fatal: not removing \'folder1\' recursively without -r\n'))
    assert not match(Command('git rm folder1',
                             'fatal: not removing \'folder1\' recursively without -r\n'))



# Generated at 2022-06-22 01:57:23.114953
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    from thefuck.rules.git_rm_recursive import get_new_command
    assert get_new_command(Command('git rm folder', '')) == 'git rm -r folder'

# Generated at 2022-06-22 01:57:25.813904
# Unit test for function get_new_command
def test_get_new_command():
    command_1 = Command("git rm -r --cached file.txt")
    assert get_new_command(command_1) == "git rm -r -r --cached file.txt"

# Generated at 2022-06-22 01:57:32.918664
# Unit test for function match
def test_match():
    assert match(Command('git rm file', stderr='fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', stderr=''))
    assert not match(Command('git rm file', stderr='fatal: not removing \'file\' recursively without -r\n'))


# Generated at 2022-06-22 01:57:39.245065
# Unit test for function match
def test_match():
    command_git_rm_file_recursively = Command('git rm test.txt',
                                       'fatal: not removing \'test.txt\' recursively without -r',
                                       '')
    repo_path = '~/project'
    command_git_rm_file_recursively._git_root_dir = repo_path
    assert match(command_git_rm_file_recursively)


# Generated at 2022-06-22 01:57:40.830942
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command
    assert get_new_command(Command('git rm -rf random_file',
        'fatal: not removing \'random_file\' recursively without -r\n',
        '', 1)) == 'git rm -rf -r random_file'

# Generated at 2022-06-22 01:57:42.987485
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm foo bar", "fatal: not removing 'bar' recursively without -r")
    assert("git rm -r foo bar" in get_new_command(command))
    

# Generated at 2022-06-22 01:57:44.458552
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm newfolder')) == 'git rm -r newfolder'


# Generated at 2022-06-22 01:57:52.985011
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', ''))
    assert match(Command('git rm file.txt', 'fatal: not removing '))
    assert match(Command('git rm file.txt', 'fatal: not removing file.txt'))
    assert match(Command('git rm file.txt', 'fatal: not removing file.txt recursively without -r'))
    assert match(Command('git rm -r file.txt', 'fatal: not removing file.txt recursively without -r'))


# Generated at 2022-06-22 01:57:55.815126
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm .', 'git: \'rm\' is not a git command. See \'git --help\'.')
    assert_equal(get_new_command(command), 'git rm -r .')

# Generated at 2022-06-22 01:58:00.686917
# Unit test for function match
def test_match():
    assert match(Command('git status', '', 'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git status', '', ''))
    assert not match(Command('git foo', '', 'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('foo rm foo', '', 'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('foo', '', 'fatal: not removing \'foo\' recursively without -r'))


# Generated at 2022-06-22 01:58:03.878475
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm')) == 'git rm -r'
    assert get_new_command(Command('git rm -f')) == 'git rm -f -r'

# Generated at 2022-06-22 01:58:10.682070
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf dir',
                         'fatal: not removing \'dir\' recursively without -r'))
    assert match(Command('git rm -rf file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm -rf dir', ''))
    assert not match(Command('git rm -rf file', ''))
    assert not match(Command('git rm -rf file', 'Error'))


# Generated at 2022-06-22 01:58:17.219786
# Unit test for function match
def test_match():
    assert match(Command('git rm src/foo/bar.py', 'fatal: not removing src/foo/bar.py recursively without -r'))
    assert not match(Command('git rm src/foo/bar.py', ''))


# Generated at 2022-06-22 01:58:21.386966
# Unit test for function match
def test_match():
    assert match(Command('git status', ''))
    assert not match(Command('ls', ''))
    assert not match(Command('git commit ', 'fatal: not removing \''))


# Generated at 2022-06-22 01:58:24.025841
# Unit test for function match
def test_match():
    assert match(Command('rm foo', 'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('rm foo', ''))


# Generated at 2022-06-22 01:58:26.762930
# Unit test for function match
def test_match():
    assert(match(Command('git rm -f foo.txt',
        "fatal: not removing 'foo.txt' recursively without -r")) == True)


# Generated at 2022-06-22 01:58:34.248547
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git rm test.py', u'fatal: not removing \'foo/bar\' recursively without -r\n', '')
    command2 = Command('git rm -r foo/bar', u'fatal: not removing \'foo/bar\' recursively without -r\n', '')
    assert get_new_command(command1) == 'git rm -r test.py'
    assert get_new_command(command2) == 'git rm -r foo/bar'

# Generated at 2022-06-22 01:58:40.209289
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
            Command('git rm -r -f', '', 'fatal: not removing \'-r\' recursively without -r')) == 'git rm -r -f -r'
    assert get_new_command(
            Command('git rm -r', '', 'fatal: not removing \'-r\' recursively without -r')) == 'git rm -r -r'

# Generated at 2022-06-22 01:58:51.534112
# Unit test for function match
def test_match():
    assert match({'output': 'fatal: not removing \'/src/Fuzzers/afl-fuzz\' recursively without -r', 'script_parts': ['git', 'rm', '-r', '/src/Fuzzers/afl-fuzz'], 'script': 'git rm -r /src/Fuzzers/afl-fuzz', 'stderr': 'fatal: not removing \'/src/Fuzzers/afl-fuzz\' recursively without -r', 'stderr_lines': ['fatal: not removing \'/src/Fuzzers/afl-fuzz\' recursively without -r'], 'stdout': ''})

# Generated at 2022-06-22 01:58:55.501593
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command=Command('git rm -r test', '', '')) == 'git rm -r -r test'
    assert get_new_command(command=Command('git rm test test', '', '')) == 'git rm -r test test'

# Generated at 2022-06-22 01:58:56.900825
# Unit test for function match
def test_match():
    result = match(Command('git rm master'))
    assert result == True


# Generated at 2022-06-22 01:58:58.753137
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r README.md' == get_new_command('git rm README.md')

# Generated at 2022-06-22 01:59:02.333533
# Unit test for function match

# Generated at 2022-06-22 01:59:04.080762
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -r')
    assert get_new_command(command) == 'rm -r -r'

# Generated at 2022-06-22 01:59:06.499428
# Unit test for function match
def test_match():
    assert match(Command('git rm -r filename', 'fatal: not removing \'filename\' recursively without -r'))
    assert not match(Command('git rm filename', 'fatal: not removing \'filename\' recursively without -r'))
    assert not match(Command('git rm filename', 'fatal: \'filename\' recursively without -r'))
    assert not match(Command('git rm filename', 'fatal: not removing recursively without -r'))


# Generated at 2022-06-22 01:59:11.533536
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', 'rm', '-f']
    command = Command('git rm -f', command_parts)
    command_parts = command.script_parts[:]
    index = command_parts.index('rm') + 1
    command_parts.insert(index, '-r')
    assert(get_new_command(command)) == u' '.join(command_parts)

# Generated at 2022-06-22 01:59:17.367700
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\': it is a directory use --cached to unstage instead', ''))
    assert match(Command('git rm file', 'fatal: not removing \'file\': it is a directory use --cached to unstage instead', ''))
    assert not match(Command('git rm', '', ''))


# Generated at 2022-06-22 01:59:19.639723
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-22 01:59:23.676365
# Unit test for function match
def test_match():
    assert match(Script('git rm a b c'))
    assert not match(Script('git rm a b c', 'fatal: not removing '' recursively without -r'))
    assert not match(Script('git rm'))



# Generated at 2022-06-22 01:59:26.695801
# Unit test for function match
def test_match():
    assert_match('git branch -D branch', 'fatal: not removing \'.gitignore\' recursively without -r')



# Generated at 2022-06-22 01:59:31.718644
# Unit test for function match
def test_match():
    assert match(Command('git rm -r hello.txt hi.txt', '', 'fatal: not removing \'hi.txt\' recursively without -r'))
    assert not match(Command('git rm hello.txt hi.txt', '', 'fatal: not removing \'hi.txt\' recursively without -r'))
    assert not match(Command('git rm -r hello.txt hi.txt', '', ''))


# Generated at 2022-06-22 01:59:33.610872
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm a', '')) == 'git rm -r a'

# Generated at 2022-06-22 01:59:39.753741
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm folder')
    assert get_new_command(command) == 'git rm -r folder'


# Generated at 2022-06-22 01:59:43.178646
# Unit test for function get_new_command
def test_get_new_command():
    assert u"git rm -r not_found" == get_new_command(Command('git rm not_found', 'git rm not_found\nfatal: not removing \'not_found\' recursively without -r', '', 0))

# Generated at 2022-06-22 01:59:46.871382
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='rm test_file.md',
                      output='fatal: not removing \'test_file.md\' recursively without -r\n')
    assert get_new_command(command) == u'git rm -r test_file.md'

# Generated at 2022-06-22 01:59:49.263942
# Unit test for function get_new_command
def test_get_new_command():
    command = type('obj', (object,), {'script': 'git rm test', 'output': u'fatal: not removing \'test\' recursively without -r'})
    command.script_parts = command.script.split()
    assert get_new_command(command) == 'git rm -r test'

# Generated at 2022-06-22 01:59:53.390526
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command("git rm -r dir_", "fatal: not removing 'a.txt' recursively without -r")) ==
            u"git rm -r -r dir_")

# Generated at 2022-06-22 02:00:01.967210
# Unit test for function get_new_command
def test_get_new_command():
    output = "error: the following file has local modifications: Documents/workspace/java/fx-rate-analytics/models/src/main/resources/models/model2/model22.jsm"
    output += "\nfatal: not removing 'Documents/workspace/java/fx-rate-analytics/models/src/main/resources/models/model2/model22.jsm' recursively without -r"
    command = Command(script='git rm Documents/workspace/java/fx-rate-analytics/models/src/main/resources/models/model2/model22.jsm',
                      stderr=output)
    assert get_new_command(command).startswith('git rm -r')
    assert 'model22.jsm' in get_new_command(command)

# Generated at 2022-06-22 02:00:06.779962
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursive import get_new_command
    command = Command('git rm -r file1 file2', 'fatal: not removing \'file1\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r file1 file2'

# Generated at 2022-06-22 02:00:11.594895
# Unit test for function match
def test_match():
    command = Command("git rm foo/bar/baz.py")
    assert not match(command)

    command = Command("git rm foo/bar/baz.py",
        output="fatal: not removing 'foo/bar/baz.py' recursively without -r")
    assert match(command)


# Generated at 2022-06-22 02:00:15.451844
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
        'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt', ''))
    assert not match(Command('ls file.txt', ''))



# Generated at 2022-06-22 02:00:19.249077
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm -r -f dir',
        output="fatal: not removing 'dir/a' recursively without -r")) == u'git rm -r -f -r dir'


# Generated at 2022-06-22 02:00:25.048943
# Unit test for function match
def test_match():
    assert match(Command('git rm a/b/c/d',
                         u"fatal: not removing 'a/b/c/d' recursively without -r"))
    assert not match(Command("echo 'test'", 'test'))

# Generated at 2022-06-22 02:00:28.078870
# Unit test for function match
def test_match():
    from tests.utils import Command, mock_environment
    assert match(Command('git rm file',
                         mock_environment(DIRECTORY=''),
                         "fatal: not removing 'file' recursively without -r\n"))

# Generated at 2022-06-22 02:00:29.772756
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test/file', '', '')) == 'git rm -r test/file'

# Generated at 2022-06-22 02:00:37.990957
# Unit test for function match
def test_match():
	out = """fatal: not removing 'sub_folder4' recursively without -r
error: unknown option `d'
usage: git rm [options] [--] <file>..."""
	command = Command(script = "git rm -d sub_folder4", output = out)
	assert match(command) is True
	
	out1 = """fatal: not removing 'sub_folder4' recursively without -r
error: unknown option `d'
usage: git rm [options] [--] <file>..."""
	command1 = Command(script = "git rm C:\\sub_folder4", output = out)
	assert match(command1) is False
	

# Generated at 2022-06-22 02:00:45.472161
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test1/')
    command.script = 'git rm test1/'
    command.output = """fatal: not removing 'test1/' recursively without -r
Did you mean this?
	git rm --cached test1/
"""
    assert get_new_command(command) == 'git rm -r test1/'
    command.script = 'git rm test1/ test2/'
    assert get_new_command(command) == 'git rm -r test1/ test2/'

# Generated at 2022-06-22 02:00:48.997702
# Unit test for function match
def test_match():
	git_cmd = "git rm -rf"
	git_output = "fatal: not removing 'submodule/submodule-1' recursively without -r"
	command = Command(git_cmd, git_output)
	assert match(command)


# Generated at 2022-06-22 02:00:50.653005
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm f')) == 'git -r rm f'

# Generated at 2022-06-22 02:00:52.633504
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git branch -d foo') == 'git branch -d -r foo'

# Generated at 2022-06-22 02:01:02.341004
# Unit test for function match
def test_match():
    assert match(Command('git rm /home/user/test.txt', '', ''))
    assert match(Command('git rm -f /home/user/test.txt', '', ''))
    assert match(Command('git rm --force /home/user/test.txt', '', ''))
    assert match(Command('git rm -r /home/user', '', '')) is False
    assert match(Command('git rmdir /home/user/test.txt', '', '')) is False
    assert match(Command('git rmdir /home/user', '', '')) is False
    assert match(Command('git rm', '', '')) is False
    assert match(Command('rm', '', '')) is False
    assert match(Command('rm -r', '', '')) is False


# Generated at 2022-06-22 02:01:06.678284
# Unit test for function match
def test_match():
    assert git_support()
    assert match(Command('git rm foo',
        "fatal: not removing 'foo' recursively without -r"))
    assert not match(Command('git rm foo', ""))
    assert not match(Command('git rm foo',
        "fatal: not removing recursively without -r"))



# Generated at 2022-06-22 02:01:11.013442
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1.txt test1/file1.txt', "fatal: not removing 'test1/file1.txt' recursively without -r\n", '')) \
           == 'git rm -r file1.txt test1/file1.txt'

# Generated at 2022-06-22 02:01:14.781105
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -r dirname',
                      stderr="fatal: not removing 'dirname' recursively without -r")
    assert get_new_command(command) == 'git rm -r -r dirname'

    command = Command(script='git rm -rf dirname',
                      stderr="fatal: not removing 'dirname' recursively without -r")
    assert get_new_command(command) == 'git rm -rf -r dirname'

# Generated at 2022-06-22 02:01:21.048823
# Unit test for function match
def test_match():
    assert(match(Command("git rm dsa.py", "fatal: not removing 'dsa.py' recursively without -r")) == True)
    assert(match(Command("git rm dsa.py", "fatal: not removing 'dsa.py' without -r")) == False)
    assert(match(Command("git rm dsa.py", "fatal: not removing 'dsa.py' recursively")) == False)


# Generated at 2022-06-22 02:01:25.310971
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Script(script="git rm folder-with-subfolders", output="fatal: not removing 'folder-with-subfolders' recursively without -r"))
    assert 'git rm -r folder-with-subfolders' == new_command

# Generated at 2022-06-22 02:01:29.642626
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r', '')) == u'git rm -r -r'
    assert get_new_command(Command('git remove -r', '')) == u'git remove -r -r'

# Generated at 2022-06-22 02:01:32.133531
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -r src', 'fatal: not removing \
\'src\' recursively without -r', '', '')) == 'git rm -r -r src'

# Generated at 2022-06-22 02:01:35.263037
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf foo',
                         "fatal: not removing 'foo/bar' recursively without -r\n"))


# Generated at 2022-06-22 02:01:37.460849
# Unit test for function get_new_command
def test_get_new_command():
	command = Command("git rm abc/")
	assert get_new_command(command) == "git rm -r abc/"

# Generated at 2022-06-22 02:01:44.500625
# Unit test for function match
def test_match():
    assert match(Command(' git rm test.txt',
                         'fatal: not removing \'test.txt\' recursively without -r'
                         ))
    assert not match(Command(' git rm test.txt', 'Could not find test.txt')) 
    assert not match(Command('git add test.txt',
                             'fatal: not removing \'test.txt\' recursively without -r'
                             ))
    assert not match(Command(' git rm test.txt', ' fatal: not removing'))


# Generated at 2022-06-22 02:01:46.794330
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm README.txt', '', '')) == 'git rm -r README.txt'

# Generated at 2022-06-22 02:01:53.832437
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test',
                         'fatal: not removing \'test\' recursively without -r\n',
                          None, 1))
    assert not match(Command('git rm test',
                             'fatal: not removing \'test\' recursively without -r\n',
                              None, 1))

# Generated at 2022-06-22 02:01:56.424003
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-22 02:01:59.858034
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf *', "fatal: not removing 'src/git.py' recursively without -r"))


# Generated at 2022-06-22 02:02:03.927337
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r NOT_EXIST',
                                   'fatal: not removing \'NOT_EXIST\' recursively without -r')) == 'git rm -r NOT_EXIST -r'

# Generated at 2022-06-22 02:02:08.187905
# Unit test for function match
def test_match():
    assert match(Command('rm old_file', 'fatal: not removing \'old_file\' recursively without -r', ''))
    assert match(Command('git rm -r old_file', '', ''))
    assert not match(Command('rm old_file', '', ''))
    assert not match(Command('git rm old_file', '', ''))



# Generated at 2022-06-22 02:02:11.703244
# Unit test for function get_new_command
def test_get_new_command():
    script = u"git rm test"
    output = u"fatal: not removing 'test' recursively without -r"
    command = Command(script, output)
    assert get_new_command(command) == u"git rm -r test"

# Generated at 2022-06-22 02:02:17.817880
# Unit test for function match
def test_match():
    assert match(Command(' git rm file', '', 'fatal: not removing \'file\' recursively without -r\n',
                         '', '', '', '/tmp'))
    assert match(Command(' git rm file file2', '', 'fatal: not removing \'file\' recursively without -r\n',
                         '', '', '', '/tmp'))
    assert not match(Command(' git rm file', '', '', '', '', '', '/tmp'))


# Generated at 2022-06-22 02:02:22.082074
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r path/directory',
                                   'fatal: not removing \'path/directory\' recursively without -r\n')) == u'git rm -r -r path/directory'


# Generated at 2022-06-22 02:02:26.208166
# Unit test for function get_new_command
def test_get_new_command():
    output = 'fatal: not removing \'a\' recursively without -r'
    script = 'git rm a'
    command = Command(script=script, output=output)
    assert get_new_command(command) == 'git rm -r a'

# Generated at 2022-06-22 02:02:33.763330
# Unit test for function match
def test_match():
    # Resource: https://github.com/nvbn/thefuck/issues/223
    # Assert True
    assert match(Command("git rm -f config/database.yml"))
    assert match(Command("git rm config/database.yml"))
    # Assert False
    assert not match(Command("git rm -f config/database.yml config/application.yml"))
    assert not match(Command("git rm"))
    assert not match(Command("git rm -f"))
    assert not match(Command("git rm -f config/"))
    assert not match(Command("git rm -f config/*"))


# Generated at 2022-06-22 02:02:41.864258
# Unit test for function get_new_command
def test_get_new_command():
    command=Command("git rm foo", u"fatal: not removing 'foo' recursively without -r")
    new_command=get_new_command(command)
    assert "rm -r foo" in new_command

# Generated at 2022-06-22 02:02:45.764901
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         u"fatal: not removing 'foo' recursively without -r\n"))
    assert not match(Command('git rm foo',
                             u"fatal: unknown option 'foo' recursively without -r\n"))


# Generated at 2022-06-22 02:02:48.519040
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r',
                         '', 1))
    assert not match(Command('git rm', '', '', 1))



# Generated at 2022-06-22 02:02:50.006277
# Unit test for function get_new_command
def test_get_new_command():
    command = "git rm file"
    assert get_new_command(command) == "git rm -r file"

# Generated at 2022-06-22 02:02:52.758481
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git rm file",
                                   output="fatal: not removing 'file' recursively without -r")
                      ) == "git rm -r file"

# Generated at 2022-06-22 02:02:56.294340
# Unit test for function match
def test_match():
    command = Command("git rm -r", "fatal: not removing 'public/system' recursively without -r")
    assert match(command)



# Generated at 2022-06-22 02:02:59.679248
# Unit test for function get_new_command
def test_get_new_command():
    """
    Test to check if the command is return as expected
    """
    command = Command("git rm -r folder/file.txt")
    assert(get_new_command(command) == "git rm -r folder/file.txt")

# Generated at 2022-06-22 02:03:01.527575
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf /')
    assert get_new_command(command) == 'git rm -rf -r /'

    command = Command('git rm -rf /')
    command.script_parts.append('-n')
    assert get_new_command(command) == 'git rm -rf -r / -n'


# Generated at 2022-06-22 02:03:09.878088
# Unit test for function get_new_command
def test_get_new_command():
    rule = GitRmRecursiveRule()
    assert rule.get_new_command('git rm -r -f') \
        == 'git rm -r -r -f'
    assert rule.get_new_command('git rm') == 'git rm -r'
    assert rule.get_new_command('git rm -rf') \
        == 'git rm -r -rf'
    assert rule.get_new_command('git rm -r -f') \
        == 'git rm -r -r -f'

# Generated at 2022-06-22 02:03:11.885774
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test.c')
    assert get_new_command(command) == 'git rm -r test.c'


# Generated at 2022-06-22 02:03:21.595217
# Unit test for function match
def test_match():
    script_test = ("git rm test", "fatal: not removing 'test' recursively without -r")
    assert match(Command(script_test[0], script_test[1]))
    script_test = ("git rm", "fatal: not removing 'test' recursively without -r")
    assert not match(Command(script_test[0], script_test[1]))
    script_test = ("git rm test", "fatal: not removing 'test' -r")
    assert not match(Command(script_test[0], script_test[1]))


# Generated at 2022-06-22 02:03:26.787888
# Unit test for function match
def test_match():
    command = Command(' $ git rm -r folder')
    assert match(command)
    command = Command(' $ git rm -r folder', "fatal: not removing 'folder' recursively without -r")
    assert match(command)
    command = Command(' $ git rm -r folder', "fatal: not removing 'folder' recursively without -r", output='')
    assert match(command)


# Generated at 2022-06-22 02:03:28.718372
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm bla') == u'git rm -r bla'


# Generated at 2022-06-22 02:03:32.260999
# Unit test for function match
def test_match():
    # when match doesn't find anything
    assert match(Command('git st')) is None
    # when match finds something
    assert match(Command('git rm -rf x',
                         'fatal: not removing \'x\' recursively without -r'))

# Generated at 2022-06-22 02:03:35.600033
# Unit test for function match
def test_match():
    assert (match(Command('git rm file', '', '')))
    assert (match(Command('rm file', '', '')))
    assert (not match(Command('git rm --cached', '', '')))
    assert (not match(Command('', '', '')))
    

# Generated at 2022-06-22 02:03:42.081757
# Unit test for function match
def test_match():
    assert match(Command('git rm -f foo', '', '', 'git rm foo: '
                                                 'fatal: not removing "foo" '
                                                 'recursively without -r'))
    assert not match(Command('git rm -f foo', '', '', 'git rm foo: '
                                                      'fatal: foo: No '
                                                      'such file or directory'))



# Generated at 2022-06-22 02:03:43.360578
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm a')
    assert get_new_co

# Generated at 2022-06-22 02:03:44.092697
# Unit test for function match
def test_match():
    assert match(Command('git rm -f test'))


# Generated at 2022-06-22 02:03:45.180671
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -b new-branch', 'fatal: not removing \'-b\' recursively without -r')) == "git rm -r -b new-branch"

# Generated at 2022-06-22 02:03:49.317931
# Unit test for function match
def test_match():
    assert (match(Command('git rm -r test.py', 'git rm: use --cached to unstage', '')))
    assert (not match(Command('git rm -r test.py', 'git rm: use --cached to unstage', '')))
    assert (not match(Command('git rm -r test.py', 'git rm: use --cached to unstage', '')))
    assert (not match(Command('git rm -f test.py', 'git rm: use --cached to unstage', '')))


# Generated at 2022-06-22 02:03:59.933096
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '/home/user'))
    assert not match(Command('git rm -r folder', '', '/home/user'))
    assert not match(Command('git commit', '', '/home/user'))
    assert not match(Command('git reset', '', '/home/user'))

# Generated at 2022-06-22 02:04:02.004744
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-22 02:04:04.887158
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm -rf directory",
                                   'fatal: not removing \'directory\' recursively without -r')) == "git rm -rf -r directory"

# Generated at 2022-06-22 02:04:13.551852
# Unit test for function match
def test_match():
    assert not match(Command('git rm'))
    assert not match(Command('git rm -a'))
    assert match(Command('git rm -r --cached file'))
    assert match(Command('git rm -r --cached a/b/file'))
    assert match(Command('git rm -r --cached a/b/file',
                         stderr='fatal: not removing \'a/b/file\' recursively without -r'))
    assert not match(Command('git rm -r --cached a/b/file',
                         stderr='fatal: not removing \'a/b/file\''))




# Generated at 2022-06-22 02:04:16.684605
# Unit test for function match
def test_match():
    assert match(Command('git rm A'))
    assert not match(Command('rm A'))
    assert not match(Command('git rm -r A'))


# Generated at 2022-06-22 02:04:22.342519
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.specific.git import git_support
    assert u' git status' == get_new_command(git_support(Command('git status', '', '')))
    assert u'git status' == get_new_command(git_support(Command('git status', '', '')))
    assert u'git -c status' == get_new_command(git_support(Command('git -c status', '', '')))

# Generated at 2022-06-22 02:04:28.457264
# Unit test for function match
def test_match():
    assert match(Command('rm foo',
                         'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('rm foo', ''))
    assert not match(Command('rm .git',
                             'fatal: not removing \'.git\' recursively without -r'))
    assert not match(Command('rm .*',
                             'fatal: not removing \'.*\' recursively without -r'))


# Generated at 2022-06-22 02:04:32.857272
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    test_input = Command('git rm test.txt', '')
    test_input.script_parts.append('test.txt')
    test_output = u'git rm -r test.txt'
    assert get_new_command(test_input) == test_output

# Generated at 2022-06-22 02:04:42.628331
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
                         'fatal: not removing \'file.txt\' recursively without -r',
                         '', 3))
    assert not match(Command('git status', '', '', 3))
    assert not match(Command('git rm file1.txt file2.txt file3.txt',
                             'fatal: not removing \'file.txt\' recursively without -r',
                             '', 3))
    assert not match(Command('git rm file1.txt file2.txt file3.txt'))
    assert not match(Command('git rm',
                             'fatal: not removing \'file.txt\' recursively without -r',
                             '', 3))



# Generated at 2022-06-22 02:04:47.090423
# Unit test for function match
def test_match():
    assert match(Command('git rm non_existent_file',
                         'fatal: not removing \'non_existent_file\' recursively without -r'))
    assert match(Command('git rm -r non_existent_file',
                         'fatal: not removing \'non_existent_file\' recursively without -r'))



# Generated at 2022-06-22 02:05:01.859267
# Unit test for function match
def test_match():
    command = Command('rm file')
    assert(match(command) == False)

    command = Command('git rm file')
    assert(match(command) == False)

    command = Command('git rm file')
    command.output = "fatal: not removing 'file' recursively without -r"
    assert(match(command) == True)

    command = Command('git rm "more space in file name"')
    command.output = "fatal: not removing 'more space in file name' recursively without -r"
    assert(match(command) == True)

# Generated at 2022-06-22 02:05:05.595519
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm hello')) == 'git rm -r hello'
    assert get_new_command(Command(u'git rm -r hello')) == u'git rm -r hello'



# Generated at 2022-06-22 02:05:08.817126
# Unit test for function match
def test_match():
    assert match(Command(script=u'git status',
                         output=u"fatal: not removing '.' recursively without -r"))



# Generated at 2022-06-22 02:05:11.497867
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n', '')
    assert get_new_command(command) == 'git rm -r file'