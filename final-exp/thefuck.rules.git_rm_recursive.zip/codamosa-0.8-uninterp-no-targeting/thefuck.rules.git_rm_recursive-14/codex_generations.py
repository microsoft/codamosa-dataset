

# Generated at 2022-06-22 01:55:16.014447
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(get_command(u'git rm foo/')) == u'git rm -r foo/'
    assert get_new_command(get_command(u'git rm foo')) == u'git rm -r foo'
    assert get_new_command(get_command(u'git rm -f foo')) == u'git rm -r -f foo'
    assert get_new_command(get_command(u'git rm -f --cached foo')) == u'git rm -r -f --cached foo'
    assert get_new_command(get_command(u'rm --cached foo/')) == u'rm --cached -r foo/'

# Generated at 2022-06-22 01:55:18.971017
# Unit test for function match
def test_match():
    assert match(Command('git branch | grep master', '', '', '', None, None))
    assert not match(Command('git branch | grep master', '', '', '', None, '/tmp'))



# Generated at 2022-06-22 01:55:26.272456
# Unit test for function match
def test_match():

    # Test 1
    # Command with errors.
    command = Command('git rm file.txt')
    command.output = """error: open("file.txt"): Permission denied
fatal: unable to stat 'file.txt': Permission denied
"""
    assert match(command) == True

    # Test 2
    # Command with errors.
    command = Command('git rm file.txt')
    command.output = """fatal: not removing 'file.txt' recursively without -r
"""
    assert match(command) == True

    # Test 3
    # Command without errors.
    command = Command('git rm file.txt')
    command.output = """rm 'file.txt'
"""
    assert match(command) == False


# Generated at 2022-06-22 01:55:30.525783
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f FILE',
                      "fatal: not removing 'FILE' recursively without -r\ndo you really want to continue?")
    assert get_new_command(command) == 'git rm -f -r FILE'

# Generated at 2022-06-22 01:55:33.128274
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3', 'fatal: not removing \'.gitignore\' recursively without -r'))
    assert not match(Command('git rm file1 file2 file3',''))

# Generated at 2022-06-22 01:55:39.093336
# Unit test for function get_new_command
def test_get_new_command():
    result_command = get_new_command(Command('git status', '', '', '', None))
    assert result_command == 'git status'
    result_command = get_new_command(Command('git rm', '', '', '', None))
    assert result_command == 'git rm'
    result_command = get_new_command(Command('git rm foo', '', '', '', None))
    assert result_command == 'git rm -r foo'
    result_command = get_new_command(Command('git rm -r', '', '', '', None))
    assert result_command == 'git rm -r'
    result_command = get_new_command(Command('git rm -r foo', '', '', '', None))
    assert result_command == 'git rm -r foo'

# Generated at 2022-06-22 01:55:45.028800
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git rm file1')) == 'git rm -r file1'
    assert get_new_command(Command('git rm -f file1')) == 'git rm -f -r file1'
    assert get_new_command(Command('git rm file1 file2')) == 'git rm -r file1 file2'



# Generated at 2022-06-22 01:55:49.783237
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf stuff',
        stderr='fatal: not removing \'stuff\' recursively without -r\n'))
    assert not match(Command('git rm stuff',
        stderr='fatal: not removing \'stuff\' recursively without -r\n'))
    assert not match(Command('git rm ',
        stderr='fatal: not removing \'stuff\' recursively without -r\n'))


# Generated at 2022-06-22 01:55:52.439587
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf test', command_runner=None)) == u"git rm -r -f test"

# Generated at 2022-06-22 01:55:56.532221
# Unit test for function match
def test_match():
    assert match(Command(' rm foo', stderr='fatal: not removing '
                         '\'foo\' recursively without -r\n'))
    assert not match(Command(' rm foo'))



# Generated at 2022-06-22 01:56:06.982685
# Unit test for function match
def test_match():
    # Test if commands with "rm " in script, "fatal: not removing '" in output
    # and "' recursively without -r" in output match.
    assert match(Command(script='rm file', output='fatal: not removing file'\
            ' recursively without -r', stderr='Foo was not removed.'))
    assert match(Command(script='rm file', output="fatal: not removing '"\
            "file' recursively without -r", stderr='Foo was not removed.'))
    assert match(Command(script='git rm file', output='fatal: not removing '\
            'file recursively without -r', stderr='Foo was not removed.'))

# Generated at 2022-06-22 01:56:12.710537
# Unit test for function match
def test_match():
    command = Command('git rm -r wudifjw  ',
                      'fatal: not removing \'wudifjw\' recursively without -r')
    assert match(command)

    command = Command('git rm -r wudifjw  ',
                      'fatal: not removing \'wudifjw\' recursively with -r')
    assert not match(command)


# Generated at 2022-06-22 01:56:23.782687
# Unit test for function get_new_command
def test_get_new_command():
    import os
    from thefuck.specific.git import git_support
    from thefuck.rules.git_rm import match, get_new_command

    test_f = open('test_git_rm.txt', 'w')
    test_f.write('hello world\n')
    test_f.flush()

    output = os.system('git init')
    output = os.system('git add test_git_rm.txt')
    output = os.system('git commit -m "test_git_rm.txt"')
    assert match(Command('git rm test_git_rm.txt'))
    new_command = get_new_command(Command('git rm test_git_rm.txt'))
    assert new_command == 'git rm -r test_git_rm.txt'

# Generated at 2022-06-22 01:56:30.844618
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert match(Command('git rm -r file.txt file2.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm -r file.txt', ''))
    assert not match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-22 01:56:35.029983
# Unit test for function match
def test_match():
    assert match(Command('git rm hello/', stderr='fatal: not removing \'hello/\' recursively without -r'))
    assert not match(Command('git rm hello', stderr='fatal: not removing \'hello/\' recursively without -r'))


# Generated at 2022-06-22 01:56:38.564431
# Unit test for function match
def test_match():
    match_output = u'fatal: not removing \'file\' recursively without -r'
    assert match(Command('rm file', match_output))
    assert not match(Command('rm file', 'abc'))



# Generated at 2022-06-22 01:56:41.569550
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r',
                      '/tmp')
    assert get_new_command(command) == 'git rm -r dir'

# Generated at 2022-06-22 01:56:44.872135
# Unit test for function match
def test_match():
    assert match(Command('git rm file.name', 'fatal: not removing \'file.name\' recursively without -r'))
    assert not match(Command('git rm file.name', ''))

# Generated at 2022-06-22 01:56:47.304183
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -rf ./myfile.txt') == 'git rm -rf -r ./myfile.txt'

# Generated at 2022-06-22 01:56:54.657550
# Unit test for function match
def test_match():
    # No match
    assert not match(Command('git rm "file.cpp"',''))
    assert not match(Command('git rm file.cpp',''))
    assert not match(Command('rm file.cpp',''))
    assert not match(Command('git rm "file.cpp"','fatal: not removing \'file.cpp\' recursively without -r'))
    # Match
    assert match(Command('git rm "file.cpp"','fatal: not removing \'file.cpp\' recursively without -r'))


# Generated at 2022-06-22 01:57:00.769411
# Unit test for function match
def test_match():
    command = Command(script = 'git branch -D branch_name', output = "fatal: not removing 'file' recursively without -r")
    assert match(command)


# Generated at 2022-06-22 01:57:04.940913
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -n "docs"',
                      output="fatal: not removing 'docs' recursively without -r",
                      stdout='',
                      stderr='')
    assert get_new_command(command) == 'git rm -r -n "docs"'

# Generated at 2022-06-22 01:57:06.150515
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'

# Generated at 2022-06-22 01:57:10.323930
# Unit test for function match
def test_match():
    stderr_is_notremoving = "fatal: not removing 'mydir' recursively without -r\n"
    assert match(Command('git rm mydir', stderr=stderr_is_notremoving))
    assert not match(Command('git r mydir', stderr=stderr_is_notremoving))
    assert not match(Command('git rm mydir', stderr="fatal: nt removing 'mydir' recursively without -r\n"))


# Generated at 2022-06-22 01:57:12.775813
# Unit test for function get_new_command
def test_get_new_command():
	command = 'git rm -r test.py'
	assert get_new_command(command) == 'git rm test.py -r'

# Generated at 2022-06-22 01:57:14.896413
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("rm foo/bar") == "git rm -r foo/bar"

# Generated at 2022-06-22 01:57:19.494451
# Unit test for function get_new_command
def test_get_new_command():
    def get_new_command_test(script, output, expected_output):
        command = Command(script, output)
        assert get_new_command(command) == expected_output

    get_new_command_test('git rm some_file',
                         'fatal: not removing \'some_file\' recursively without -r',
                         'git rm -r some_file')

# Generated at 2022-06-22 01:57:24.492982
# Unit test for function match
def test_match():  # noqa
    assert (match(Command('git rm -r foo', 'fatal: not removing \'foo\' recursively without -r')))
    assert (not match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')))
    assert (not match(Command('git rm foo', '')))


# Generated at 2022-06-22 01:57:26.195964
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'

# Generated at 2022-06-22 01:57:31.484482
# Unit test for function get_new_command
def test_get_new_command():
    # Fixture for command.script_parts
    command_parts = ['git', 'rm', 'README.md']
    # Test for result when the command is executed for both match and get_new_command
    assert get_new_command(Command(script_parts=command_parts, output="fatal: not removing 'README.md' recursively without -r")) == 'git rm -r README.md'

# Generated at 2022-06-22 01:57:43.620524
# Unit test for function match
def test_match():
    assert match(Command('git rm File1.txt', ''))
    assert match(Command('git rm File3.txt', ''))
    assert not match(Command('git rm File3.txt', 'fatal: not removing File3.txt'))
    assert not match(Command('git rm -r File3.txt', ''))
    assert not match(Command('git rm -rf File3.txt', ''))



# Generated at 2022-06-22 01:57:54.790275
# Unit test for function match

# Generated at 2022-06-22 01:57:57.398951
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm dir/',
                                 'fatal: not removing \'dir/\' recursively without -r')
    assert get_new_command(command) == "git rm -r dir/"

# Generated at 2022-06-22 01:58:01.344629
# Unit test for function get_new_command
def test_get_new_command():
     command = """
     rm -f test.txt
     fatal: not removing 'test.txt' recursively without -r
     """.strip()
     assert get_new_command(Command(command, '')) == """rm -f -r test.txt"""


# Generated at 2022-06-22 01:58:06.905592
# Unit test for function match
def test_match():
    # If match(command) is true
    # then the script provided by the user which tries to remove a directory
    # unrecursively will be sended to function get_new_command
    assert True == match(Command('rm -rf folder', 'fatal: not removing \
\'folder\' recursively without -r', '', 124))


# Generated at 2022-06-22 01:58:11.054178
# Unit test for function get_new_command
def test_get_new_command():
    # Get new command
    script = "git rm README.md"
    output = "fatal: not removing 'README.md' recursively without -r\n"
    command = Command(script,output)
    assert get_new_command(command) == "git rm -r README.md"

# Generated at 2022-06-22 01:58:12.902288
# Unit test for function match
def test_match():
    assert match(Script(script = 'git rm -r'))
    assert not match(Script(script = 'git rm'))


# Generated at 2022-06-22 01:58:17.217100
# Unit test for function match
def test_match():
    git_output = '''
    fatal: not removing 'tests/test_utils.pyc' recursively without -r
    '''
    command = Command('git rm tests/test_utils.pyc', git_output)
    assert match(command)


# Generated at 2022-06-22 01:58:24.388260
# Unit test for function match
def test_match():
    assert match(Command("git rm Makefile", "fatal: not removing 'Makefile' recursively without -r\n")) is True
    assert match(Command("git clone https://github.com/nvbn/thefuck.git", "")) is False
    assert match(Command("git clone https://github.com/nvbn/thefuck.git", "fatal: not removing 'thefuck' recursively without -r\n")) is True


# Generated at 2022-06-22 01:58:27.072797
# Unit test for function match
def test_match():
	test_command = Command("git rm asdf", "fatal: not removing '.' recursively without -r\n")
	assert match(test_command) == True



# Generated at 2022-06-22 01:58:44.807746
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("rm filename", "fatal: not removing 'filename' recursively without -r")
    assert "git rm -r filename" == get_new_command(command)


# Generated at 2022-06-22 01:58:47.551047
# Unit test for function match
def test_match():
    command = Command(script='git rm -r file',
                      output='fatal: not removing \'file\' recursively without -r')
    assert match(command)



# Generated at 2022-06-22 01:58:52.009317
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_recursive_rm import get_new_command
    command = Command('git rm target',
                    'fatal: not removing \'target\' recursively without -r\n',
                    'git rm target')
    assert 'git rm -r target' == get_new_command(command)

# Generated at 2022-06-22 01:58:54.520468
# Unit test for function match
def test_match():
    assert match(Command('rm file',
                         'fatal: not removing \'file\' recursively without -r'))

# Generated at 2022-06-22 01:58:58.299283
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         'fatal: not removing \'foo\' recursively without -r',
                         ''))
    assert not match(Command('git branch foo',
                             'fatal: not removing \'foo\' recursively without -r',
                             ''))

# Generated at 2022-06-22 01:59:01.699215
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm file/', 'fatal: not removing \'file/\' recursively without -r', '', 3)) == u'git rm -r file/'

# Generated at 2022-06-22 01:59:03.748301
# Unit test for function match
def test_match():
    assert match(Command('rm foo'))
    assert not match(Command('rm foo', '', stderr='not removing'))


# Generated at 2022-06-22 01:59:08.436565
# Unit test for function match
def test_match():
    command = Command('git rm -r ./migrations/0001_initial.py:migrations/0001_initial.pyc', 'fatal: not removing \'./migrations/0001_initial.py\' recursively without -r\n')
    assert match(command)


# Generated at 2022-06-22 01:59:13.043678
# Unit test for function get_new_command
def test_get_new_command():
    new_command = u'git rm -r .'
    assert get_new_command(Command(script=u'git rm .')) == new_command
    assert get_new_command(Command(script=u'git rm .',
                                   output=u'fatal: not removing \'.\' recursively without -r',
                                   )) == new_command

# Generated at 2022-06-22 01:59:15.795332
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'

# Generated at 2022-06-22 01:59:31.668468
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm toto") == "git rm -r toto"

# Generated at 2022-06-22 01:59:37.917539
# Unit test for function match
def test_match():
    assert match(Command('git rm test/abc.txt', '', 'fatal: not removing \'test/abc.txt\' recursively without -r', ''))
    assert match(Command('git rm test/abc.txt', 'fatal: not removing \'test/abc.txt\' recursively without test -r', '', ''))    
    assert not match(Command('git rm test/abc.txt', '', '', ''))


# Generated at 2022-06-22 01:59:44.187854
# Unit test for function get_new_command
def test_get_new_command():
    from types import ModuleType
    first_command = ModuleType('first_command')
    first_command.script = 'git rm -r test'
    first_command.script_parts = first_command.script.split()
    first_command.output = 'fatal: not removing '' recursively without -r'

    assert get_new_command(first_command) == 'git rm -r test'

# Generated at 2022-06-22 01:59:46.998487
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('rm directory', 'rm directory'
                                   '\nfatal: not removing \'directory\' recursively without -r'))
            == 'git rm -r directory')

# Generated at 2022-06-22 01:59:54.828877
# Unit test for function match
def test_match():
    assert match(Command('git rm foo.txt', 'fatal: not removing \'foo.txt\' recursively without -r'))
    assert not match(Command('git rm foo.txt', 'fatal: not removing foo.txt recursively without -r'))
    assert not match(Command('git rm -r foo.txt', 'fatal: not removing foo.txt recursively without -r'))
    assert not match(Command('git rm foo.txt', 'fatal: not removing foo.txt recursively without -r', '', 1))


# Generated at 2022-06-22 01:59:57.394192
# Unit test for function get_new_command
def test_get_new_command():
    command = 'rm -rf test.txt'
    new_command = 'rm -r -rf test.txt'

    assert get_new_command(FakeCommand(command)) == new_command

# Generated at 2022-06-22 01:59:58.974450
# Unit test for function match
def test_match():
    command = Command('git rm', 'fatal: not removing ')
    assert match(command)


# Generated at 2022-06-22 02:00:01.278617
# Unit test for function match
def test_match():
    assert match(Command('git rm fileA',
        'fatal: not removing \'fileA\' recursively without -r'))
    assert not match(Command('git rm fileA', ''))


# Generated at 2022-06-22 02:00:03.241526
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file.txt') == 'git rm -r file.txt'

# Generated at 2022-06-22 02:00:07.783022
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file.txt',
            'fatal: not removing \'file.txt\' recursively without -r')) 
    assert match(Command('git rm file.txt',
            'fatal: not removing \'file.txt\' recursively without -r'))

# Generated at 2022-06-22 02:00:24.214327
# Unit test for function match
def test_match():
    assert match(Command('git rm wrongfile',
        output="fatal: not removing 'wrongfile' recursively without -r\n"))


# Generated at 2022-06-22 02:00:26.838333
# Unit test for function match
def test_match():
    command = Command(' git rm *',
                      """
                      fatal: not removing 'README.md' recursively without -r
                      """)
    assert match(command)


# Generated at 2022-06-22 02:00:32.306736
# Unit test for function match
def test_match():
    assert match(Command('git rm -r folder', 'fatal: not removing \'folder\' recursively without -r\nUse -f if you really want to remove it.'))
    assert not match(Command('git rm folder', 'fatal: not removing \'folder\' recursively without -r\nUse -f if you really want to remove it.'))



# Generated at 2022-06-22 02:00:38.681786
# Unit test for function match
def test_match():
    assert match(Command('git rm file', stderr='''fatal: not removing 'file' recursively without -r
'''))
    assert match(Command('git rm file', stderr='''fatal: not removing 'file' recursively without -r
'''))
    assert not match(Command('git rm file', stderr='''fatal: not removing 'file' recursively without -r
'''))
    assert not match(Command('echo command', stderr='''fatal: not removing 'file' recursively without -r
'''))


# Generated at 2022-06-22 02:00:40.225753
# Unit test for function match
def test_match():
    command = Command(script='rm path')
    assert match(command)


# Generated at 2022-06-22 02:00:46.262953
# Unit test for function match
def test_match():
    assert match(Script(script='git commit',
                        stderr=("fatal: not removing 'dir/subdir/subsubdir' recursively without -r\n")))
    assert not match(Script(script='git commit',
                            stderr=("fatal: not removing 'dir/subdir/subsubdir' recursively with -r\n")))


# Generated at 2022-06-22 02:00:48.996621
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git rm file',
                                   'fatal: not removing \'file\' recursively without -r\n')) == 'git rm -r file'

# Generated at 2022-06-22 02:00:51.982054
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursive import get_new_command
    assert get_new_command(["git", "rm", "--help"]) == "git rm -r --help"

# Generated at 2022-06-22 02:01:01.817211
# Unit test for function match
def test_match():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n', '', '', '')
    assert match(command)
    command = Command('git rm folder', 'fatal: not removing \'folder\' recursively without -r\n', '', '', '')
    assert match(command)
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', '', '')
    assert match(command)
    command = Command('git rm folder', 'fatal: not removing \'folder\' recursively without -r', '', '', '')
    assert match(command)
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n', '', '', '')

# Generated at 2022-06-22 02:01:05.828888
# Unit test for function get_new_command
def test_get_new_command():
    assert ("git rm -r /home/user/git/project/file.txt" == get_new_command(Command('git rm /home/user/git/project/file.txt')))
    assert ("git rm -r file.txt" == get_new_command(Command('git rm file.txt')))


# Generated at 2022-06-22 02:01:24.611443
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r file' == get_new_command(Command('git rm file',
        'fatal: not removing \'file\' recursively without -r'))

# Generated at 2022-06-22 02:01:30.434782
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r dir', 'fatal: not removing \
    \'dir\' recursively without -r')) == 'git rm -r -r dir'
    assert get_new_command(Command('git rm dir', 'fatal: not removing \
    \'dir\' recursively without -r')) == 'git rm -r dir'

# Generated at 2022-06-22 02:01:35.124608
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('ls', ''))



# Generated at 2022-06-22 02:01:39.682498
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f test', '')
    assert get_new_command(command) == 'git rm -r -f test'
    command = Command('git rm -f -r test', '')
    assert get_new_command(command) == 'git rm -r -f -r test'


# Generated at 2022-06-22 02:01:45.103484
# Unit test for function match
def test_match():
    assert match(Command(script='git rm foo/bar'))
    assert match(Command(script='git rm foo/bar/',
       output='fatal: not removing \'foo/bar/\' recursively without -r'))
    assert not match(Command(script='git rm foo/bar/',
       output='fatal: not removing \'bar/\' recursively without -r'))


# Generated at 2022-06-22 02:01:47.119706
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.txt',
                         'fatal: not removing \'hello.txt\' recursively without -r'))



# Generated at 2022-06-22 02:01:50.802841
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command
    old_cmd = u'git rm foo bar'
    expected_cmd = u'git rm -r foo bar'
    assert get_new_command(old_cmd) == expected_cmd


# Generated at 2022-06-22 02:01:52.520289
# Unit test for function match
def test_match():
    assert True == match(Command('git rm -r testing/', ''))


# Generated at 2022-06-22 02:01:55.063686
# Unit test for function get_new_command
def test_get_new_command():
    f = FuckItCommand('git rm -r --cached 2>&1')
    assert get_new_command(f) == 'git rm -r -r --cached 2>&1'

# Generated at 2022-06-22 02:02:06.961328
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git rm hello')) == 'git rm -r hello'
    assert get_new_command(Command('git rm hello/')) == 'git rm -r hello/'
    assert get_new_command(Command('git rm hello/world')) == 'git rm -r hello/world'
    assert get_new_command(Command('hello world git rm')) == 'hello world git rm -r'
    assert get_new_command(Command('hello git rm world')) == 'hello git rm -r world'
    assert get_new_command(Command('git rm -r hello world')) == 'git rm -r hello world'
    assert get_new_command(Command('git rm -r hello/ world')) == 'git rm -r hello/ world'
    assert get

# Generated at 2022-06-22 02:02:25.908307
# Unit test for function get_new_command

# Generated at 2022-06-22 02:02:27.384308
# Unit test for function match
def test_match():
    assert match(Command('git rm README', 'fatal: not removing \'README\' recursively without -r'))
    assert not match(Command('git rm README', ''))
    assert not match(Command('git add README', 'fatal: not removing \'README\' recursively without -r'))


# Generated at 2022-06-22 02:02:31.027056
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Mock(script='git rm -r', output="fatal: not removing '" + 
        "' recursively without -r", script_parts=['git', 'rm', '-r'])) == u'git rm -r -r'


enabled_by_default = True

# Generated at 2022-06-22 02:02:35.435903
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
    assert match(Command('git rm', 'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file', ''))


# Generated at 2022-06-22 02:02:36.962932
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm filename')
    assert get_new_command(command) == 'git rm -r filename'

# Generated at 2022-06-22 02:02:39.096505
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf'))
    assert not match(Command('git add .'))

# Generated at 2022-06-22 02:02:42.092565
# Unit test for function match
def test_match():

    # Test for valid inputs
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r', ''))

    # Test for invalid inputs
    assert not match(Command('rm foo', 'Not removing foo recursively without -r', ''))

# Generated at 2022-06-22 02:02:50.373532
# Unit test for function get_new_command
def test_get_new_command():
    compare_vals = [('git rm -r "path/to/file"', 'git rm -r -r "path/to/file"'),
                    ('git rm --cached "path/to/file"', 'git rm -r --cached "path/to/file"'),
                    ('git rm -r "path/to/file"', 'git rm -r -r "path/to/file"'),
                    ('git rm -r --cached "path/to/file"', 'git rm -r -r --cached "path/to/file"')]
    for command, expected_output in compare_vals:
        command_test = Command(command, '', '')
        assert get_new_command(command_test) == expected_output

# Generated at 2022-06-22 02:02:53.491240
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test', '')) == 'git rm -r test'
    assert get_new_command(Command('git rm test/', '')) == 'git rm -r test/'


# Generated at 2022-06-22 02:02:57.474996
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm README\nfatal: not removing \'README\' recursively without -r', '', '')
    assert get_new_command(command) == u'git rm -r README'

# Generated at 2022-06-22 02:03:19.982461
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
    'fatal: not removing \'file.txt\' recursively without -r\n'))
    assert not match(Command('git rm', 'fatal: not removing \'file.txt\' recursively without -r\n'))
    assert not match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-22 02:03:24.488159
# Unit test for function match
def test_match():
    assert match(Command('git rm a',
                         'fatal: not removing \'a\' recursively without -r\n',
                        ))
    assert  not match(Command('git rm -r a',
                              'fatal: not removing \'a\' recursively without -r\n',
                              ))



# Generated at 2022-06-22 02:03:27.985423
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r new_folder", "fatal: not removing 'new_folder' recursively without -r\n")
    new_command = get_new_command(command)
    assert new_command == "git rm -r -r new_folder"


# Generated at 2022-06-22 02:03:30.853875
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm .idea', output="fatal: not removing '.idea' recursively without -r\n")) == 'git rm -r .idea'

# Generated at 2022-06-22 02:03:33.651961
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm dir', stderr='fatal: not removing '
        '\'dir\' recursively without -r\n')) == 'git rm -r dir'

# Generated at 2022-06-22 02:03:37.151404
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursive_fatal import get_new_command
    assert get_new_command(Command(script='git rm file.txt',
                                   output='fatal: not removing \'file.txt\' recursively without -r')) \
        == "git rm -r file.txt"

# Generated at 2022-06-22 02:03:42.364888
# Unit test for function match
def test_match():
    assert match(Command('git st',
                          'fatal: not removing \'app/data/test\' recursively without -r',
                          '', 0))



# Generated at 2022-06-22 02:03:45.320692
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf docs', 'fatal: not removing \'docs\' recursively without -r')) == u'git rm -r -rf docs'

# Generated at 2022-06-22 02:04:00.774247
# Unit test for function match
def test_match():
    # Test match function when "rm" command is present but no "-r"
    command = Command("git rm path/to/directory", "fatal: not removing 'path/to/directory' recursively without -r")
    assert match(command)
    # Test match function when "rm" command is present but no "-r" and no output
    command = Command("git rm path/to/directory", "")
    assert not match(command)
    # Test match function when "rm" command is present but no "-r" and no directory
    command = Command("git rm", "fatal: not removing '.' recursively without -r")
    assert not match(command)
    # Test match function when "rm" is present but with the "-r" option
    command = Command("git rm -r path/to/directory", "")

# Generated at 2022-06-22 02:04:04.691678
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf test', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -rf -r test'

# Generated at 2022-06-22 02:04:42.078107
# Unit test for function get_new_command
def test_get_new_command():
	# Initalize new command
	command = Command()
	
	# Create command to be mocked
	command.script = u"git rm d"
	command.output = "fatal: not removing 'd' recursively without -r"
	
	# Create new command using get_new_command function
	new_command = get_new_command(command)
	assert new_command == u"git rm -r d"

# Generated at 2022-06-22 02:04:46.035442
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r name_of_folder').script == 'git rm -r -r name_of_folder'
    assert get_new_command('git rm name_of_folder').script == 'git rm -r name_of_folder'


# Generated at 2022-06-22 02:04:47.171126
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git rm -r file'

# Generated at 2022-06-22 02:04:49.979414
# Unit test for function match
def test_match():
    assert match(Command('git rm asd', 'fatal: not removing \'asd\''
                                         ' recursively without -r', ''))


# Generated at 2022-06-22 02:04:56.011193
# Unit test for function match
def test_match():
    assert match(
        Command('git rm file',
                'fatal: not removing \'one/two/three/file\' recursively without -r',
                '')) == True

    assert match(Command('git rm -r file',
                         '',
                         '')) == False

    assert match(Command('git add file',
                         'fatal: not removing \'one/two/three/file\' recursively without -r',
                         '')) == False



# Generated at 2022-06-22 02:04:57.761353
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf build',
                stderr='fatal: not removing \'build\' recursively without -r'))



# Generated at 2022-06-22 02:05:03.830563
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf .idea/', 'not removing \'.idea/\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -rf .idea/'

    command = Command('git rm -r -rf .idea/', 'not removing \'.idea/\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -rf .idea/'

# Generated at 2022-06-22 02:05:11.754355
# Unit test for function match
def test_match():
    assert match(Command('git rm -r --cached parse.c',
                         'fatal: not removing \'parse.c\' recursively without -r\n',
                         3))
    assert not match(Command('git rm -r --cached parse.c',
                             'fatal: not removing \'parse.c\' recursively without -r\n',
                             3))
    assert not match(Command('git reeee',
                             'fatal: not removing \'parse.c\' recursively without -r\n',
                             3))
