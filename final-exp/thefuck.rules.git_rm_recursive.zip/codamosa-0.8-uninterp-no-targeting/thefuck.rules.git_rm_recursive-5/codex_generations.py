

# Generated at 2022-06-22 01:55:17.135389
# Unit test for function match
def test_match():
    assert match(Command('git rm file1', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git rm file1', 'fatal: not removing \'file1\' recursively with -r'))
    assert not match(Command('git config --global user.name', 'Error: not removing \'file1\' recursively without -r'))


# Generated at 2022-06-22 01:55:18.970376
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm hello', '')
    assert get_new_command(command) == 'git rm -r hello'

# Generated at 2022-06-22 01:55:25.672835
# Unit test for function match
def test_match():
    assert match(Command(script = 'git rm filename' ,
                         output = 'fatal: not removing \'filename\' recursively without -r'))
    assert not match(Command(script = 'git rmdir foldername' ,
                             output = 'fatal: not removing \'foldername\' recursively without -r'))
    assert not match(Command(script = 'git rm filename' ,
                             output = 'fatal: not removing \'filename\' recursively without -r'))
    assert not match(Command(script = 'git rm filename' ,
                             output = 'fatal: not removing \'filename\' recursively without -r'))


# Generated at 2022-06-22 01:55:32.016718
# Unit test for function match
def test_match():
    assert match(Command('git rm README.md', '', ''))
    assert not match(Command('git status', '', ''))
    assert match(Command('git rm README.md', '', 'fatal: not removing \'README.md\' recursively without -r', ''))
    assert not match(Command('git rm README.md', '', 'fatal: not removing \'README.md\'', ''))


# Generated at 2022-06-22 01:55:33.519101
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm').split() == ['git', 'rm', '-r']

# Generated at 2022-06-22 01:55:35.485949
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm a', 'fatal: not removing \'a\' recursively without -r')
    assert get_new_command(command) == 'git rm -r a'

# Generated at 2022-06-22 01:55:40.267284
# Unit test for function match
def test_match():
    hash_name = '#' * 40
    output = (" fatal: not removing '" + hash_name + "' recursively "
              "without -r")
    command = Command(' rm ' + hash_name, output)
    assert match(command)


# Generated at 2022-06-22 01:55:46.455059
# Unit test for function match
def test_match():
    assert match(Command('git rm /tmp/test',
                '/tmp/test: Not a directory\nfatal: not removing \'/tmp/test\' recursively without -r'))
    assert not match(Command('git rm /tmp/test',
                '/tmp/test: Not a directory\nfatal: not removing \'/tmp/test\' recursively with -r'))
    assert not match(Command('git rm /tmp/test', ''))


# Generated at 2022-06-22 01:55:50.896056
# Unit test for function match
def test_match():
	assert match(Command('git rm -rf a_directory', "fatal: not removing 'a_directory' recursively without -r"))
	assert not match(Command('git rm -rf a_directory', "fatal: not removing 'a_directory' without -r"))
	assert not match(Command('git rm a_file', "fatal: not removing 'a_directory' recursively without -r"))


# Generated at 2022-06-22 01:55:53.967209
# Unit test for function match
def test_match():
    assert (match(Command('git rm -r asd',
                          'fatal: not removing \'asd/\' recursively without -r\n',
                          '', 1)))


# Generated at 2022-06-22 01:55:58.249953
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -rf dir').script == 'git rm -r -rf dir'

# Generated at 2022-06-22 01:56:02.248006
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm - r files',
                                   output='fatal: not removing \'files\' recursively without -r',
                                   stderr='fatal: not removing \'files\' recursively without -r')) == "git rm -r - r files"



# Generated at 2022-06-22 01:56:08.024029
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r folder') == 'git rm -r folder'
    assert get_new_command('git rm -r folder1 folder2') == 'git rm -r folder1 folder2'
    assert get_new_command('git rm -r "folder1 folder2"') == 'git rm -r "folder1 folder2"'
    assert get_new_command('git rm -r "folder1/folder2"') == 'git rm -r "folder1/folder2"'
    assert get_new_command('git rm folder1 folder2') == 'git rm -r folder1 folder2'

# Generated at 2022-06-22 01:56:11.464377
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm hello.py', 'fatal: not removing \'hello.py\' recursively without -r')
    assert(get_new_command(command) == 'git rm -r hello.py')

# Generated at 2022-06-22 01:56:15.217898
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm noSuchFile') == 'git rm -r noSuchFile'
    assert get_new_command('git rm noSuchFile.py') == 'git rm -r noSuchFile.py'

# Generated at 2022-06-22 01:56:18.805518
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm bar', 'fatal: not removing \'bar\' recursively without -r')
    assert get_new_command(command) == 'git rm -r bar'


# Generated at 2022-06-22 01:56:25.478597
# Unit test for function match
def test_match():
    assert match(Command('git rm not-a-dir', '', 'fatal: not removing \'not-a-dir\' recursively without -r', '')) == True
    assert match(Command('git rm not-a-dir', '', 'fatal: not removing \'not-a-dir\' recursively without -r', '')) == True
    assert match(Command('git rm not-a-dir', '', 'fatal: not removing \'not-a-dir\' recursively without -R', '')) == False


# Generated at 2022-06-22 01:56:31.789963
# Unit test for function match
def test_match():
    assert match(command=Command(script='git rm file_name', output="fatal: not removing 'file_name' recursively without -r"))
    assert not match(command=Command(script='git rm file_name', output="fatal:  removing 'file_name' recursively without -r"))
    assert not match(command=Command(script='ls jason', output="fatal: not removing 'jason' recursively without -r"))


# Generated at 2022-06-22 01:56:36.547028
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         'fatal: not removing \'foo\' recursively without -r',
                         None))
    assert not match(Command('git rm foo', '', None))
    assert not match(Command('git foo', 'fatal: not removing \'foo\' recursively without -r', None))


# Generated at 2022-06-22 01:56:38.268501
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm test') == 'git rm -r test'

# Generated at 2022-06-22 01:56:44.188649
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r test') == 'git rm -r -r test'
    assert get_new_command('git rm -rf test') == 'git rm -rf -r test'

# Generated at 2022-06-22 01:56:45.851917
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm DIR')
    assert get_new_command(command) == 'git rm -r DIR'

# Generated at 2022-06-22 01:56:49.589370
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('$ git rm file.txt')) == "git rm -r file.txt"
    assert get_new_command(Command('$ git rm -f file.txt')) == "git rm -f -r file.txt"


# Generated at 2022-06-22 01:56:54.568855
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm folder/folder', '', '')) == 'git rm -r folder/folder'
    assert get_new_command(Command('git rm -r folder/folder', '', '')) == 'git rm -r folder/folder'


# Generated at 2022-06-22 01:57:05.499697
# Unit test for function match
def test_match():
    assert match(Command('rm foo', '', 'fatal: not removing \x1b[31m\x1b[1mfoo\x1b[m\x1b[m recursively without -r', 1))
    assert match(Command('git rm foo', '', 'fatal: not removing \x1b[31m\x1b[1mfoo\x1b[m\x1b[m recursively without -r', 1))
    assert not match(Command('rm foo', '', '', 1))
    assert not match(Command('rm foo', '', 'fatal: not removing \x1b[31m\x1b[1mfoo\x1b[m\x1b[m recursively without -r', 1, force_colors=True))
    # It looks like colorama returns \x1

# Generated at 2022-06-22 01:57:09.802579
# Unit test for function match
def test_match():
    must_match = [u'git rm -r file.txt',
                  u'git rm -r file.txt && git commit -m "remove"']
    must_not_match = [u'git rm file.txt',
                      u'git rm file.txt && git commit -m "remove"']

    for cmd in must_match:
        assert match(Command(cmd))

    for cmd in must_not_match:
        assert not match(Command(cmd))


# Generated at 2022-06-22 01:57:15.983564
# Unit test for function match
def test_match():
    assert not match(Command(script='git rm -rf /tmp/1111', output='/tmp/1111: No such file or directory'))
    assert not match(Command(script='git rm -rf /tmp/1111', output='fatal: not removing \'/tmp/1111\' recursively'))
    assert match(Command(script='git rm -rf /tmp/1111', output='fatal: not removing \'/tmp/1111\' recursively without -r'))

# Generated at 2022-06-22 01:57:19.273954
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r dirA/dirB", "fatal: not removing 'dirA/dirB' recursively without -r")
    assert get_new_command(command) == "git rm -r dirA/dirB"

# Generated at 2022-06-22 01:57:30.004052
# Unit test for function get_new_command
def test_get_new_command():
	from thefuck.rules.git_rm import match, get_new_command
	from thefuck.types import Command

	assert match(Command('git rm -rf dir', 'fatal: not removing \'dir\' recursively without -r', '', [], ''))
	assert get_new_command(Command('git rm -rf dir', 'fatal: not removing \'dir\' recursively without -r', '', [], '')) == 'git rm -rf -r dir'
	assert match(Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r', '', [], ''))
	assert get_new_command(Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r', '', [], '')) == 'git rm -r dir'

# Generated at 2022-06-22 01:57:35.086145
# Unit test for function match
def test_match():
    """
        Test whether function match works correctly.
        This test checks that match only matches the pattern ' rm ' followed by " fatal: not removing '" and "' recursively without -r" in the output.

        :return: True on succes, False on failure.
    """
    assert match(Command('git rm -f folder/subfolder',
            u"fatal: not removing 'folder/subfolder' recursively without -r"))
    assert not match(Command('git rm -f folder/subfolder', ' '))
    assert not match(Command('git rm -f folder/subfolder', 'Wrong output'))

# Generated at 2022-06-22 01:57:39.430442
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm README.md", "")) == "git rm -r README.md"

# Generated at 2022-06-22 01:57:42.628690
# Unit test for function match
def test_match():
    assert match(Command('git rm myfile', 'fatal: not removing \'myfile\' recursively without -r', ''))
    assert not match(Command('git rm myfile', '', ''))
    assert not match(Command('git rm', '', ''))

# Generated at 2022-06-22 01:57:46.002817
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git rm -r jason') == u'git rm -r -r jason'
    assert get_new_command(u'git rm -rf jason') == u'git rm -rf -r jason'
    assert get_new_command(u'git rm -rf jason -r') == u'git rm -rf -r jason -r'

# Generated at 2022-06-22 01:57:51.084716
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing "foo" recursively without -r'))
    assert not match(Command('git rm foo', 'nothing wrong'))
    assert not match(Command('ls foo', 'nothing wrong'))


# Generated at 2022-06-22 01:57:54.492789
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command(script='git rm -f a a/b',
                                   output='fatal: not removing \'a/b\' recursively without -r')) ==
           'git rm -f -r a a/b')

# Generated at 2022-06-22 01:57:58.735033
# Unit test for function match
def test_match():
    assert match(Command('git rm foo bar'
            ,'fatal: not removing \'foo\' recursively without -r')
                 is True)
    assert match(Command('git rm foo bar','')
                 is False)
    assert match(Command('git rm foo bar'
            ,'fatal: not removing \'bar\' recursively without -r')
                 is True)


# Generated at 2022-06-22 01:58:07.509652
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'
    assert get_new_command(Command('git rm -rf file', '', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -rf -r file'
    assert get_new_command(Command('git rm -r file', '', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'


# Generated at 2022-06-22 01:58:10.636121
# Unit test for function match
def test_match():
    result = match(Command(' rm README.md ', 'fatal: not removing '
                           '\'.gitignore\' recursively without -r', ''))
    assert result == True



# Generated at 2022-06-22 01:58:12.501613
# Unit test for function match
def test_match():
    assert match(Command("git rm *", "fatal: not removing 'file.txt' recursively without -r")) is True


# Generated at 2022-06-22 01:58:20.005609
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="git rm myFile",
                      stderr="fatal: not removing 'myFile' recursively without -r")
    assert get_new_command(command) == "git rm -r myFile"
    command = Command(script="git rm -s myFile",
                      stderr="fatal: not removing 'myFile' recursively without -r")
    assert get_new_command(command) == "git rm -s -r myFile"

# Generated at 2022-06-22 01:58:31.786480
# Unit test for function match
def test_match():
    assert match(Command('git rm file', ''))
    assert match(Command('git rm folder', ''))
    assert not match(Command('git rm', ''))
    assert not match(Command('git rm -rf folder', ''))
    assert not match(Command('git rm -f folder', ''))
    assert not match(Command('git add file',  ''))
    assert not match(Command('git add file', ''))


# Generated at 2022-06-22 01:58:34.357575
# Unit test for function match
def test_match():
    assert match(Command(' rm -rf dir', 'fatal: not removing \'dir\' recursively without -r'))
    assert not match(Command(' rm -rf dir', 'fatal: not removing \'dir\''))
    assert not match(Command(' rm -rf dir', ''))


# Generated at 2022-06-22 01:58:37.041609
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git push',
                                   output='fatal: not removing \'dir\' recursively without -r')) == 'git push -r'

# Generated at 2022-06-22 01:58:39.403241
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -f text.txt', '')) == 'rm -f -r text.txt'

# Generated at 2022-06-22 01:58:41.707618
# Unit test for function match
def test_match():
    assert match(Command('gco test',
                         'fatal: not removing "test" '
                         'recursively without -r'))



# Generated at 2022-06-22 01:58:44.946433
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git rm some_folder', '', '')) == 'git rm -r some_folder'



# Generated at 2022-06-22 01:58:51.159849
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2', 'fatal: not removing \'file1\' recursively without -r\n'))
    assert not match(Command('git clone repo', 'fatal: not removing \'file1\' recursively without -r\n'))
    assert not match(Command('git rm file1', 'fatal: not removing \'file1\' recursively without -r\n'))


# Generated at 2022-06-22 01:58:54.068436
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm file.out',
                                   output=r"fatal: not removing 'file.out' recursively without -r")) == 'git rm -r file.out'

# Generated at 2022-06-22 01:58:56.152919
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r")
    assert get_new_command(command) == "git rm -r -r"

# Generated at 2022-06-22 01:59:00.775414
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = 'git rm test'.split()
    index = command_parts.index('rm') + 1
    command_parts.insert(index, '-r')
    assert u' '.join(command_parts) == 'git rm -r test'

# Generated at 2022-06-22 01:59:09.256302
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo')) == 'git rm -r foo'
    assert get_new_command(Command('git rm foo bar')) == 'git rm -r foo bar'

# Generated at 2022-06-22 01:59:13.042362
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    from tests.utils import rule

    assert rule(match, get_new_command)(Command('git rm .',
                                                 'fatal: not removing '
                                                 "'/path/to/file'"
                                                 ' recursively without -r')) == 'git rm -r .'

# Generated at 2022-06-22 01:59:15.796655
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(' git rm -f dir/ ') == u' git rm -rf dir/'

# Generated at 2022-06-22 01:59:18.499395
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git add foo') == 'git add -r foo'
    assert get_new_command('git reset foo bar') == 'git reset -r foo bar'

# Generated at 2022-06-22 01:59:27.593479
# Unit test for function match
def test_match():
	command = Command('git rm src/test.txt', 'fatal: not removing \'src/components/test.txt\' recursively without -r\n')
	assert match(command)

	command = Command('git rm src/test.txt', '')
	assert not match(command)

	command = Command('git rm src/test.txt', 'fatal: not removing \'src/components/test.txt\' recursively without -r\n\nfatal: not removing \'src/components/test.txt\' recursively without -r\n')
	assert not match(command)


# Generated at 2022-06-22 01:59:37.261340
# Unit test for function match
def test_match():
    assert(not match("git stat"))
    assert(not match("git rm"))
    assert(not match("git rm test"))

    assert(match("git rm -r test"))
    assert(match("git rm -r"))
    assert(match("git rm --recursive"))
    assert(match("git rm -r test"))
    assert(match("git rm -r "))
    assert(match("git rm -r test1 test2"))
    assert(match("git rm --recursive test1 test2"))

    assert(match("git rm testaaa/\\''\'bbb\\''\' \"testccc/ddd\""))
    assert(match("git rm testaaa/bbb \"testccc/ddd\""))


# Generated at 2022-06-22 01:59:44.618867
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command('git rm test'), 'git rm -r test')
    assert_equals(get_new_command('git rm test1 test2'), 'git rm -r test1 test2')
    assert_equals(get_new_command('git rm test1 test2 test3'), 'git rm -r test1 test2 test3')
    assert_equals(get_new_command('rm test1 test2 test3'), 'rm -r test1 test2 test3')

# Generated at 2022-06-22 01:59:47.406985
# Unit test for function get_new_command
def test_get_new_command():
    command_output = 'fatal: not removing \'folder\' recursively without -r'

    assert get_new_command(Command('git rm folder', command_output)) == 'git rm -r folder'

# Generated at 2022-06-22 01:59:50.181084
# Unit test for function match
def test_match():
    script = 'git rm Makefile'
    output = 'fatal: not removing \'Makefile\' recursively without -r\n'
    assert match(Command(script, output))


# Generated at 2022-06-22 01:59:55.068156
# Unit test for function match
def test_match():
    assert match(Command("git rm file1", "fatal: Not removing 'file1' recursively without -r"))
    assert not match(Command("git rm file1", "fatal: Not removing 'file1' recursively without -f"))


# Generated at 2022-06-22 02:00:12.907376
# Unit test for function match

# Generated at 2022-06-22 02:00:13.988783
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file.txt'

# Generated at 2022-06-22 02:00:19.824819
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', '', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt', '', 'fatal: not removing \'file.txt\''))
    assert not match(Command('git commit', '', 'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-22 02:00:27.405901
# Unit test for function match
def test_match():
    assert match(Command('git rm a/b/c', '/tmp/git', 'git',
            'fatal: not removing \'a/b/c\' recursively without -r'))
    assert not match(Command('git rm a/b/c', '/tmp/git', 'git',
            'fatal: not removing \'a/b/c\' recursively with -r'))
    assert not match(Command('rm a/b/c', '/tmp/git', 'git', 'fatal: not removing \'a/b/c\''))


# Generated at 2022-06-22 02:00:33.314689
# Unit test for function match
def test_match():
    cmd = 'git rm -rf data'
    assert(match(cmd))

    cmd = 'git rm -rf data/'
    assert(match(cmd))

    cmd = 'git rm data'
    assert(not match(cmd))

    cmd = 'rm data'
    assert(not match(cmd))

    cmd = 'git rm'
    assert(not match(cmd))


# Generated at 2022-06-22 02:00:42.961946
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_with_minus_r import get_new_command
    script1 = "git rm file1 file2"
    script2 = "git rm -f file1"
    script3= "git rm file1/file2"
    output1 = "'' is not a working tree directory."
    output2 = """fatal: not removing 'file2' recursively without -r
'' is not a working tree directory."""
    output3 = "fatal: not removing 'file1/file2' recursively without -r"
    command1 = Command(script1,[output1])
    command2 = Command(script2,[output2])
    command3 = Command(script3,[output3])
    print(get_new_command(command1))
    print(get_new_command(command2))
   

# Generated at 2022-06-22 02:00:47.856016
# Unit test for function get_new_command
def test_get_new_command():
    command = type("Command", (object,), { "script_parts": ["git", "rm", "src/package.json"], "output": "fatal: not removing 'src/package.json' recursively without -r"})
    new_command = get_new_command(command)
    assert new_command == "git rm -r src/package.json"

# Generated at 2022-06-22 02:00:53.247771
# Unit test for function get_new_command
def test_get_new_command():
    output = u"error: unable to unlink old 'file.py': Permission denied\n"

# Generated at 2022-06-22 02:00:58.181894
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test', 'fatal: not removing \'test\' recursively without -r\ngit rm -r [--cached] [-f | -n] [-r] [--ignore-unmatch] [--quiet] [--] <file>...')
    assert get_new_command(command) == 'git rm -r -r test'


# Generated at 2022-06-22 02:01:02.381070
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
        output='fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git rm file',
        output='fatal: not removing \'file\''))
    assert not match(Command('git ls',
        output='fatal: not removing \'file\''))


# Generated at 2022-06-22 02:01:16.067783
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r file' == get_new_command(Command('git rm file', '', '', 0, None))
    assert u'foo rm -r bar' == get_new_command(Command('foo rm bar', '', '', 0, None))

# Generated at 2022-06-22 02:01:20.156586
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm test")
    # When the command's output matches the match(), it should return a command
    # with '-r' inserted in the correct position.
    assert(get_new_command(command) == 'git -r rm test')

# Generated at 2022-06-22 02:01:23.437352
# Unit test for function match
def test_match():
    output = u"fatal: not removing 'training-session/README.md' recursively without -r"
    command = Command("rm training-session", output)
    assert match(command)


# Generated at 2022-06-22 02:01:27.662841
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ["git", "rm", "file.txt"]
    index = command_parts.index('rm') + 1
    assert (index - 1) == command_parts.index('rm')
    command_parts.insert(index, '-r')
    assert "-r" in command_parts

# Generated at 2022-06-22 02:01:36.808503
# Unit test for function match
def test_match():
    assert git_support
    assert match(Command('git rm -rf --cached .DS_Store','''fatal: not removing 'abc/def/.DS_Store' recursively without -r'''))
    assert match(Command('git rm -rf --cached .DS_Store','''fatal: not removing 'abc/def/.DS_Store' recursively without -r
error: '''.strip()))
    assert not match(Command('git rm -rf --cached .DS_Store','''fatal: not removing 'abc/def/.DS_Store' recursively with -r
error: '''))


# Generated at 2022-06-22 02:01:41.768610
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git rm -r /path/to/file',
       '/path/to/dir\ngit rm -r /path/to/file\nfatal: not removing \'/path/to/file\' recursively without -r'))
    assert new_command == 'git rm -r -r /path/to/file'

# Generated at 2022-06-22 02:01:44.798962
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    # Setup
    command = Command("git rm ")
    command.output = ("fatal: not removing '.' recursively without -r\n"
                      "Did you mean 'git rm --ignore-unmatch .'?")

    # Test
    assert_equals("git rm -r", get_new_command(command))

# Generated at 2022-06-22 02:01:50.302171
# Unit test for function get_new_command
def test_get_new_command():
    output = '''fatal: not removing './files/README.md' recursively without -r
    Did you mean 'rm ./files/README.md'?'
    '''
    command = Command('git rm ./files/README.md', output)
    new_command = get_new_command(command)
    assert u'git rm -r ./files/README.md' == new_command



# Generated at 2022-06-22 02:01:53.296511
# Unit test for function get_new_command

# Generated at 2022-06-22 02:02:03.402518
# Unit test for function match

# Generated at 2022-06-22 02:02:15.618771
# Unit test for function match
def test_match():
    assert match(Command('git rm','fatal: not removing \'foo.pb\' recursively without -r',''))


# Generated at 2022-06-22 02:02:27.120692
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git rm test')) ==
            'git rm -r test')
    assert (get_new_command(Command('git rm test test2')) ==
            'git rm -r test test2')
    assert (get_new_command(Command('git rm -f test')) ==
            'git rm -f -r test')
    assert (get_new_command(Command('git rm -f -r test')) ==
            'git rm -f -r test')
    assert (get_new_command(Command('git rm test test2 -f')) ==
            'git rm -r test test2 -f')
    assert (get_new_command(Command('git rm test test2 -f -r')) ==
            'git rm -r test test2 -f -r')


enabled_

# Generated at 2022-06-22 02:02:30.208918
# Unit test for function match
def test_match():
    output = """rm: cannot remove 'myfile': Is a directory
    fatal: not removing 'myfile' recursively without -r"""
    command = Command('git rm myfile', '', output)
    assert match(command) is True


# Generated at 2022-06-22 02:02:34.074834
# Unit test for function get_new_command
def test_get_new_command():
    git_rm_command = Command('git rm -r a', 'fatal: pathspec \'a\' did not match any files')
    assert(get_new_command(git_rm_command) == 'git rm -r -r a')

# Generated at 2022-06-22 02:02:36.534799
# Unit test for function match
def test_match():
    assert match(Command(script='git rm foo', output='fatal: not removing \'foo\' recursively without -r\n'))
    assert not match(Command(script='ls foo', output=''))


# Generated at 2022-06-22 02:02:45.528042
# Unit test for function match
def test_match():
    ''' Unit test for match function '''

    assert match(Command('git rm rm-file',
                         'fatal: not removing \'rm-file\' recursively without -r',
                         '', 2))

    assert not match(Command('git rm rm-file',
                             'fatal: not removing \'rm-file\' recursively without -r',
                             '', 1))

    assert not match(Command('git rm rm-file',
                             'fatal: not removing \'rm-file\' recursively with -r',
                             '', 2))

    assert not match(Command('git rm rm-file',
                             'fatal: not deleting \'rm-file\' recursively without -r',
                             '', 2))


# Generated at 2022-06-22 02:02:49.128652
# Unit test for function match
def test_match():
    assert match(Command('git rm', 'fatal: not removing \'file\' recursively without -r', 'dir'))
    assert not match(Command('git rm', '', 'dir'))
    assert not match(Command('git add', 'fatal: not removing \'file\' recursively without -r', 'dir'))


# Generated at 2022-06-22 02:02:52.511635
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1 file2', '')) == 'git rm -r file1 file2'
    assert get_new_command(Command('git rm -r file1 file2', '')) == 'git rm -r -r file1 file2'

# Generated at 2022-06-22 02:02:56.006664
# Unit test for function match
def test_match():
    assert match(
        Command('git rm -f',
                'fatal: not removing \'file.txt\' recursively without -r\n'))

# Generated at 2022-06-22 02:02:59.005907
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm test/', 'fatal: not removing', ''))(
        'git rm test/'
    ) == 'git rm -r test/'

# Generated at 2022-06-22 02:03:24.543509
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(
        'git rm -r foo/bar',
        'fatal: not removing \'foo/bar\' recursively without -r',
        '', 1)) == 'git rm -r -r foo/bar'

# Generated at 2022-06-22 02:03:33.298824
# Unit test for function match
def test_match():
    ''' Unit test for function match '''
    test_inputs = """
        git rm -rv some/path
        fatal: not removing 'some/path' recursively without -r""".splitlines()

    # function to test
    def func(command):
        return 'git rm -rv some/path\nfatal: not removing ' + \
               "'some/path' recursively without -r"

    # Test results
    test_results = [False, True]

    # Test loop
    for i in range(0, len(test_inputs)):
        # Run test
        assert match(Command(script=test_inputs[i], output=func(test_inputs[i]))) == test_results[i]



# Generated at 2022-06-22 02:03:38.658246
# Unit test for function match
def test_match():
    assert match(Command('rm fileName', '',
                         'fatal: not removing \'fileName\' recursively without -r'))
    assert match(Command('git rm fileName', '',
                         'fatal: not removing \'fileName\' recursively without -r'))
    assert not match(Command('rm fileName', '', 'Some error message'))
    assert not match(Command('git rm fileName', '', 'Some error message'))



# Generated at 2022-06-22 02:03:43.003362
# Unit test for function get_new_command
def test_get_new_command():
	command = Command('function', 'function')
	command.output = "fatal: not removing 'dirname' recursively without -r"
	match(command)
	assert(get_new_command(command) == 'function -r')

# Generated at 2022-06-22 02:03:46.069027
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r file' == get_new_command(Command('git rm file', 'fatal: not removing "file" recursively without -r'))

# Generated at 2022-06-22 02:03:51.726297
# Unit test for function match
def test_match():
    assert match(Command('git rm fileone.txt filetwo.txt',
                         'fatal: not removing '
                         '\'fileone.txt filetwo.txt\' recursively without -r'))
    assert match(Command('git rm fileone.txt filetwo.txt',
                         'fatal: not removing '
                         '\'fileone.txt filetwo.txt\' recursively without -r')) is False


# Generated at 2022-06-22 02:03:56.040993
# Unit test for function match
def test_match():
    mas_command = 'git rm file.txt'
    mas_output = "fatal: not removing 'file.txt' recursively without -r"
    assert match(Command(mas_command, mas_output))


# Generated at 2022-06-22 02:04:00.048296
# Unit test for function match
def test_match():
    assert not match(Command('echo'))
    assert not match(Command('git rm'))
    assert not match(Command('git rm foo'))
    assert match(Command('git rm foo',
                         "fatal: not removing 'tmp/foo' recursively without -r\n"))


# Generated at 2022-06-22 02:04:02.512384
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1.txt',
                                   'fatal: not removing \'file2.txt\' recursively without -r')) == 'git -rf git rm file1.txt'

# Generated at 2022-06-22 02:04:07.122555
# Unit test for function match
def test_match():
    assert match(Command('git branch rm new-branch'))
    assert not match(Command('git branch rm -r new-branch'))
    assert not match(Command('git branch new-branch', 'fatal: not removing \'new-branch\' recursively without -r'))


# Generated at 2022-06-22 02:04:28.609561
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -rf') == 'git rm -rf'

# Generated at 2022-06-22 02:04:33.702392
# Unit test for function match
def test_match():
    assert match(Command('git rm 123', 'fatal: not removing \'123\' recursively without -r'))
    assert not match(Command('git rm 123', 'git: \'rm\' is not a git command. See \'git --help\'.'))
    assert not match(Command('git r 123', 'fatal: not removing \'123\' recursively without -r'))


# Generated at 2022-06-22 02:04:38.460628
# Unit test for function match
def test_match():
    """ Unit test for function match """
    assert_true(match(Command('git rm -r new_folder', 'fatal: not removing \'new_folder\' recursively without -r')))
    assert_false(match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r')))


# Generated at 2022-06-22 02:04:43.000154
# Unit test for function match
def test_match():
    assert(match(Command('git rm -r a.txt',
                         'fatal: not removing \'a.txt\' recursively without -r')) != None)
    assert(match(Command('git rm -r a.txt', '')) == None)



# Generated at 2022-06-22 02:04:46.201029
# Unit test for function get_new_command
def test_get_new_command():
    command = type('command', (), {
        'script_parts': u'git rm -r'.split(),
        'output': ''})
    assert get_new_command(command) == 'git rm -r -r'

# Generated at 2022-06-22 02:04:48.341610
# Unit test for function match
def test_match():
    assert match(Command('git rm asdasd',
                         "fatal: not removing 'asdasd' recursively without -r",
                         ''))


# Generated at 2022-06-22 02:04:58.003160
# Unit test for function match
def test_match():
    # If '-r' is in the command:
    rm_command = Command('git rm -r my_file', '')
    assert not match(rm_command)

    # If 'recursively without -r' is not in the output:
    rm_command = Command('git rm my_file', 'fatal: not removing file recursively')
    assert not match(rm_command)

    # If there is no 'fatal:' in the output:
    rm_command = Command('git rm my_file', 'not removing file recursively')
    assert not match(rm_command)

    # If there is no 'not removing' in the output:
    rm_command = Command('git rm my_file', 'fatal: removing file recursively')
    assert not match(rm_command)

    # If there is no 'recurs

# Generated at 2022-06-22 02:05:00.455120
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file.txt'

# Generated at 2022-06-22 02:05:04.094296
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm toto')) == 'git rm -r toto'
    assert get_new_command(Command('git rm -r toto')) == 'git rm -r -r toto'

# Generated at 2022-06-22 02:05:09.622691
# Unit test for function match
def test_match():
    assert match(Command('git rm test', output="fatal: not removing 'test' recursively without -r"))
    assert not match(Command('git rm test', output='fatal: not removing'))
    assert match(Command('git rm -r test', output="fatal: not removing 'test' recursively without -r"))
