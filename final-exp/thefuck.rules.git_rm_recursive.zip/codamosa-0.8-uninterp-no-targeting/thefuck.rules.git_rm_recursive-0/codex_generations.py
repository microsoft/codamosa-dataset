

# Generated at 2022-06-22 01:55:13.302185
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm test -r')
    assert(get_new_command(command) == 'git rm -r test -r')

# Generated at 2022-06-22 01:55:16.064039
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git add -r foo' == get_new_command(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r'))

# Generated at 2022-06-22 01:55:19.394437
# Unit test for function get_new_command
def test_get_new_command():
    output_error = "fatal: not removing 'test' recursively without -r\n"
    command = Command('git rm -rf test', output_error)
    assert get_new_command(command) == "git rm -rf -r test"

# Generated at 2022-06-22 01:55:22.675686
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command('git rm README.md', '', 'fatal: not removing \'README.md\' recursively without -r'))
    assert result == 'git rm -r README.md'

# Generated at 2022-06-22 01:55:25.876332
# Unit test for function get_new_command
def test_get_new_command():
    """
    Test to match the command and generate a new command
    """
    assert get_new_command(
        Command('git rm some_file', '')) \
        == Command('git rm -r some_file', '')

# Generated at 2022-06-22 01:55:28.899179
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git rm -rf a/b")) == "git rm -rf -r a/b"

# Generated at 2022-06-22 01:55:32.067186
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command('git remote add origin git@github.com:nvbn/thefuck.git'),
                   'git remote add -r origin git@github.com:nvbn/thefuck.git')

# Generated at 2022-06-22 01:55:40.919255
# Unit test for function match
def test_match():
    match_tests = []
    match_tests.append(Command('git rm A B C', '', 'fatal: not removing \'A\' recursively without -r', ''))
    match_tests.append(Command('git rm A', '', 'fatal: not removing \'A\' recursively without -r', ''))
    match_tests.append(Command('git rm', '', 'fatal: not removing \'\' recursively without -r', ''))
    match_tests.append(Command('git rm -r A', '', 'fatal: not removing \'A\' recursively without -r', ''))

    for command in match_tests:
        assert match(command)

# Unit tests for function get_new_command

# Generated at 2022-06-22 01:55:44.459503
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1 file2',
                                   'fatal: not removing \'file1\' recursively without -r',
                                   '', 1)) == 'git rm -r file1 file2'

# Generated at 2022-06-22 01:55:47.105517
# Unit test for function match
def test_match():
    assert match(Command('git rm a b'))
    assert not match(Command('git', 'rm', 'a'))
    assert not match(Command('git', 'rm'))


# Generated at 2022-06-22 01:56:00.863116
# Unit test for function match
def test_match():
    assert match(Command('rm -rf foo/bar/gaga',
                         'fatal: not removing \'foo/bar/gaga\' recursively without -r\n',
			 1))
    assert not match(Command('git lala', '', 0))
    assert not match(Command('rm lala', '', 0))
    assert not match(Command('git rm -rf foo/bar/gaga',
                         'fatal: not removing \'foo/bar/gaga\' recursively without -r\n',
			 1))
    assert not match(Command('rm -rf foo/bar/gaga',
                         'fatal: not removing \'foo/bar/gaga\' recursively without -r\n',
			 0))

# Extra test for function match

# Generated at 2022-06-22 01:56:03.223447
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm a/b/c/d")
    assert get_new_command(command) == "git rm -r a/b/c/d"

# Generated at 2022-06-22 01:56:06.003657
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm file1 file2',
                      stderr='fatal: not removing \'file2\' recursively without -r')
    assert get_new_command(command) == "git rm -r file1 file2"

# Generated at 2022-06-22 01:56:17.213522
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command("git rm test/my-file", "fatal: not removing 'test/my-file' recursively without -r") == "git rm -r test/my-file"
	assert get_new_command("git rm test2/my-file", "fatal: not removing 'test2/my-file' recursively without -r") == "git rm -r test2/my-file"
	assert get_new_command("git rm test3/my-file", "fatal: not removing 'test3/my-file' recursively without -r") == "git rm -r test3/my-file"	

# Generated at 2022-06-22 01:56:20.695900
# Unit test for function match
def test_match():
    assert match("git rm files")
    assert match("git rm -r files")
    assert not match("git rm -r files -f")
    assert not match("git rm -rf files")
    assert not match("rm -rf files")


# Generated at 2022-06-22 01:56:22.637673
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r -f')
    assert get_new_command(command) == 'git rm -f -r'

# Generated at 2022-06-22 01:56:24.256328
# Unit test for function match
def test_match():
    assert match(Command("git rm 'Utils.cs'"))


# Generated at 2022-06-22 01:56:30.886582
# Unit test for function match
def test_match():
    assert match(Command("git rm f -r", "fatal: not removing 'f' recursively without -r"))
    assert not match(Command("git rm f -r", "fatal: not removing 'f' recursively without -r ERROR"))
    assert not match(Command("git rm f -r", "fatal: not removing 'f' recursively without -r ok"))
    assert not match(Command("git rm f", "fatal: not removing 'f' recursively without -r"))
    

# Generated at 2022-06-22 01:56:35.077375
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm images/')
    assert get_new_command(command) == 'git rm -r images/'

    command = Command('git rm -f images/')
    assert get_new_command(command) == 'git rm -rf images/'


# Generated at 2022-06-22 01:56:36.370579
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm mydir') == 'git rm -r mydir'

# Generated at 2022-06-22 01:56:41.569956
# Unit test for function match
def test_match():
    command = Command('git rm -f README.md', 'fatal: not removing \'README.md\' recursively without -r')
    
    assert match(command) == True


# Generated at 2022-06-22 01:56:47.169339
# Unit test for function match
def test_match():
    assert match(Command('git rm fred',
                         'fatal: not removing \'fred\' recursively without -r'))
    assert not match(Command('git rm fred', ''))
    assert not match(Command('git rm fred',
                             'fatal: not removing \'fred\' recursively without -r',
                             stderr='foo'))


# Generated at 2022-06-22 01:56:50.551417
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git rm -rf test',
                                          '', 'fatal: not removing \'.\' recursively without -r'))
    assert new_command == 'git rm -rf -r test'

# Generated at 2022-06-22 01:56:58.448762
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -f file')) == 'git rm -rf file'
    assert get_new_command(Command('git rm -f file1 file2 file3')) == 'git rm -rf file1 file2 file3'
    assert get_new_command(Command('git rm -f file1 file2 file3 file4 file5 file6 file7 file8 file9 file10 file11 file12')) == 'git rm -rf file1 file2 file3 file4 file5 file6 file7 file8 file9 file10 file11 file12'

# Generated at 2022-06-22 01:57:06.858022
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm foo',
                                   output='fatal: not removing "foo" '+
                                          'recursively without -r')) == 'git rm -r foo'
    assert get_new_command(Command(script='git rm foo/bar',
                                   output='fatal: not removing "foo/bar" '+
                                          'recursively without -r')) == 'git rm -r foo/bar'
    assert get_new_command(Command(script='git rm foo bar',
                                   output='fatal: not removing "foo" '+
                                          'recursively without -r')) == 'git rm foo -r bar'

# Generated at 2022-06-22 01:57:11.200429
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git rm -r ~/dummy_directory',
                                          'fatal: not removing \'~/dummy_directory\' recursively without -r'))
    assert new_command == 'git rm -r -r ~/dummy_directory'

# Generated at 2022-06-22 01:57:17.240097
# Unit test for function match
def test_match():
    # Test with a script that matches the match condition for this rule
    command = Command(script='git rm {{file}}',
                      output="fatal: not removing '{{file}}' recursively without -r")
    assert match(command)

    # Test with a script that does not match the match condition for this rule
    command = Command(script='git rm {{file}}')
    assert not match(command)


# Generated at 2022-06-22 01:57:18.786399
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm asd')) == 'git rm -r asd'

# Generated at 2022-06-22 01:57:22.604560
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'
    assert get_new_command(Command('fuck git rm file')) == 'fuck git rm -r file'


# Generated at 2022-06-22 01:57:28.445260
# Unit test for function get_new_command
def test_get_new_command():
    script_parts = ['/usr/bin/git', 'rm', 'target']
    output = "fatal: not removing 'target' recursively without -r"

    command = Command(script=' '.join(script_parts),
                      script_parts=script_parts,
                      output=output,
                      env={},
                      raw_script="git rm target")
    assert get_new_command(command) == "git rm -r target"

# Generated at 2022-06-22 01:57:34.312317
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf rm',
                         'fatal: not removing \'rm\' recursively without -r', stderr=''))
    assert match(Command('git rm -f rm',
                         'fatal: not removing \'rm\' recursively without -r', stderr=''))
    assert not match(Command('git rm -rf rm', '', ''))


# Generated at 2022-06-22 01:57:38.641147
# Unit test for function match
def test_match():
    # git rm <path>
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(Command('git rm file', ''))
    assert not match(Command('some command', ''))


# Generated at 2022-06-22 01:57:42.985684
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm cherry-pick-1&2') == 'git rm -r cherry-pick-1&2'
    assert get_new_command('git rm --cached') == 'git rm -r --cached'
    assert get_new_command('git rm -f') == 'git rm -rf'


# Generated at 2022-06-22 01:57:44.563833
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file1 file2 file3', '')) == 'git rm -r file1 file2 file3'

# Generated at 2022-06-22 01:57:50.655985
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm ',
                                   'fatal: not removing '
                                   "'lib/hello.rb' recursively without -r\n")) \
                                   == "git rm -r 'lib/hello.rb'"

# Generated at 2022-06-22 01:57:52.797383
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -rf .')) == u'rm -rf -r .'


# Generated at 2022-06-22 01:58:00.438297
# Unit test for function get_new_command

# Generated at 2022-06-22 01:58:09.157098
# Unit test for function match
def test_match():
    assert match(Command('git rm test/foo',
                         '',
                         'fatal: not removing \'test/foo\' recursively without -r'))
    assert not match(Command('git rm test/foo',
                             '',
                             ''))
    assert match(Command('git rm test/foo',
                         '',
                         'fatal: not removing \'test/foo\' recursively without -r\n'))
    assert not match(Command('git rm test/foo',
                             '',
                             'fatal: not removing file recursively without -r\n'))


# Generated at 2022-06-22 01:58:20.214061
# Unit test for function match
def test_match():
    mock_command1 = Mock(script="git rm a",
                         output=("fatal: not removing 'a' recursively without -r\n"
                         "Did you mean this?"))
    assert match(mock_command1)
    mock_command2 = Mock(script="git rm a",
                         output=("fatal: not removing 'a' recursively without -r\n"
                         "Did you mean this?\n"))
    assert match(mock_command2)
    mock_command3 = Mock(script="git rm -r a",
                         output=("fatal: not removing 'a' recursively without -r\n"
                         "Did you mean this?\n"))
    assert not match(mock_command3)

# Generated at 2022-06-22 01:58:28.117662
# Unit test for function get_new_command
def test_get_new_command():
    # Setup
    command.script = "git rm -r reasons"
    command.script_parts = ['git', 'rm', '-r', 'reasons']
    command.output = ("fatal: not removing 'reasons' recursively without -r\n"
                      "Did you mean 'rm -r'?")

    # Exercise
    new_command = get_new_command(command)

    # Verify
    expected_new_command = "git rm -r -r reasons"
    assert new_command == expected_new_command

    # Cleanup - none necessary

# Generated at 2022-06-22 01:58:33.638898
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test', '', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r test'


# Generated at 2022-06-22 01:58:37.086487
# Unit test for function match
def test_match():
    assert match(Command('git rm foo/bar.txt',
        'fatal: not removing \'foo/bar.txt\' recursively without -r\n'))
    assert not match(Command('git rm foo/bar.txt'))


# Generated at 2022-06-22 01:58:43.181731
# Unit test for function match
def test_match():
    assert match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '/bin/bash'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '/usr/bin/python'))
    assert not match(Command('git rm file', 'fatal: not removing \'file\'', '/bin/bash'))

# Generated at 2022-06-22 01:58:50.340583
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    old_command = Command('git rm -rf .',
                          'fatal: not removing \'.\' recursively without -r')
    assert get_new_command(old_command) == 'git rm -r -rf .'

    old_command = Command('git rm -r .', 'fatal: not removing \'.\' recursively without -r')
    assert get_new_command(old_command) == 'git rm -r -r .'

# Generated at 2022-06-22 01:58:53.212759
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm some_file', 
                                   'fatal: not removing \'some_file\' recursively without -r')) == u'git rm -r some_file'

# Generated at 2022-06-22 01:59:04.795815
# Unit test for function match
def test_match():
    import os
    os.system("touch testfile")
    from thefuck.utils import wrap_settings
    with wrap_settings(**{'git_support': True}):
        assert match(Command('git rm testfile', 'fatal: not removing testfile recursively without -r'))
    os.system("git init")
    with wrap_settings(**{'git_support': True}):
        assert not match(Command('git rm testfile', 'fatal: not removing testfile recursively without -r'))
    os.system("git add testfile")
    with wrap_settings(**{'git_support': True}):
        assert match(Command('git rm testfile', 'fatal: not removing testfile recursively without -r'))
    os.system("rm testfile")

# Generated at 2022-06-22 01:59:08.111403
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm README.txt',
                      'fatal: not removing \'README.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r README.txt'

# Generated at 2022-06-22 01:59:11.279589
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm a', 'fatal: not removing '
                                   '\'a\' recursively without -r', None,
                                   'git rm a')) == 'git rm -r a'

# Generated at 2022-06-22 01:59:15.423269
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r dir1',
                                   output=u"fatal: not removing 'dir1' "
                                   u"recursively without -r")) == \
        u'git rm -r -r dir1'

# Generated at 2022-06-22 01:59:16.936092
# Unit test for function match
def test_match():
    assert match(Command('git rm test'))


# Generated at 2022-06-22 01:59:21.827771
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git rm test.txt'
    assert get_new_command(Command(command)) == 'git rm -r test.txt'

# Generated at 2022-06-22 01:59:23.426914
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git rm words')== 'git rm -r words')

# Generated at 2022-06-22 01:59:28.345020
# Unit test for function match
def test_match():
    assert match(Command('git rm file/subdir/subsubdir',
                         'fatal: not removing \'file/subdir\' recursively without -r',
                         ''))
    assert not match(Command('git rm dir', '', ''))
    assert not match(Command('rm file', '', ''))
    asser

# Generated at 2022-06-22 01:59:33.142362
# Unit test for function match
def test_match():
        assert match( Command('git rm file.txt', '', 'fatal: not removing "file.txt" recursively without -r') )
        assert match( Command('git rm -r dir', '', 'fatal: not removing "dir/file.txt" recursively without -r') )
        assert not match( Command('git rm -r .', '', '') )


# Generated at 2022-06-22 01:59:34.652449
# Unit test for function get_new_command
def test_get_new_command():
    assert "git rm -r something" == get_new_command("git rm something")

# Generated at 2022-06-22 01:59:39.072820
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm my_file',
                      'fatal: not removing \'my_file\' recursively without -r')
    assert git_recursive_removal.get_new_command(command) == 'git rm -r my_file'

# Generated at 2022-06-22 01:59:45.096145
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf .', '', 'fatal: not removing \'.\' recursively without -r\n'))
    assert not match(Command('git rm -rf', '', 'fatal: not removing \'.\' recursively without -r\n'))
    assert not match(Command('git rm', '', 'fatal: not removing \'.\' recursively without -r\n'))


# Generated at 2022-06-22 01:59:48.816469
# Unit test for function match
def test_match():
    assert match(Command('git rm -r'))
    assert match(Command('git rm -r pom.xml', stderr='fatal: not removing \'pom.xml\' recursively without -r\n'))
    assert not match(Command('git rm -r pom.xml'))


# Generated at 2022-06-22 01:59:59.362939
# Unit test for function match
def test_match():
    assert match(Command('git rm test.log',
                         u"fatal: not removing 'test.log' recursively without -r"))
    assert match(Command('git rm -f test.log',
                         u"fatal: not removing 'test.log' recursively without -r"))
    assert match(Command('git rm test.log test2.log',
                         u"fatal: not removing 'test.log' recursively without -r"))
    assert not match(Command('git rm -r test.log',
                             u"fatal: not removing 'test.log' recursively without -r"))
    assert not match(Command('git add test.log',
                             u"fatal: not removing 'test.log' recursively without -r"))


# Generated at 2022-06-22 02:00:01.791322
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm Doc/more_info.txt', 'fatal: not removing \'Doc/more_info.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r Doc/more_info.txt'

# Generated at 2022-06-22 02:00:07.739072
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2', "fatal: not removing 'file2' recursively without -r"))
    assert not match(Command('ls', ''))


# Generated at 2022-06-22 02:00:12.358116
# Unit test for function match
def test_match():
    assert match(
        Command('git rm data.csv', 'fatal: not removing \'data.csv\' recursively without -r\n'))
    assert not match(
        Command('git rm .', 'fatal: not removing \'data.csv\' recursively without -r\n'))


# Generated at 2022-06-22 02:00:14.004182
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm somefile', 'output')) == 'git rm -r somefile'

# Generated at 2022-06-22 02:00:20.963224
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2',
            'fatal: not removing \'file1\' recursively without -r\n'
            'fatal: not removing \'file2\' recursively without -r'))
    assert not match(Command('git rm file1 file2', ''))
    assert not match(Command('ls file1 file2', ''))
    assert match(Command('git rm file1 file2',
            'fatal: not removing \'file1\' recursively without -r'))


# Generated at 2022-06-22 02:00:31.662158
# Unit test for function match
def test_match():
    # E.g. git rm data
    command = Command('git rm data', 'fatal: not removing \'data\' recursively without -r\n')
    assert match(command)
    # E.g. git rm -r data
    command = Command('git rm -r data', 'fatal: not removing \'data\' recursively without -r\n')
    assert not match(command)
    # E.g. git rm data/
    command = Command('git rm data/', 'fatal: not removing \'data/\' recursively without -r\n')
    assert match(command)
    # E.g. git rm -r data/
    command = Command('git rm -r data/', 'fatal: not removing \'data/\' recursively without -r\n')
    assert not match(command)
    # E

# Generated at 2022-06-22 02:00:35.589468
# Unit test for function match
def test_match():
	example_command = Command(' git rm readme.txt', 'fatal: not removing \'readme.txt\' recursively without -r')
	assert match(example_command) == True
	example_command = Command(' ls readme.txt', '')
	assert match(example_command) == False		


# Generated at 2022-06-22 02:00:39.607625
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('git rm setup.py', 'fatal: not removing \'setup.py\' recursively without -r\n', '')
    assert get_new_command(command) == 'git rm -r setup.py'

# Generated at 2022-06-22 02:00:44.810820
# Unit test for function match
def test_match():
    assert match(Command('rm -vf a',
                    'fatal: not removing \'a\' recursively without -r\n'))
    assert not match(Command('rm -vf a', 'Some error'))
    assert not match(Command('rm -vf a'))



# Generated at 2022-06-22 02:00:51.938190
# Unit test for function match
def test_match():
    script_error = u"fatal: not removing 'tests/fixtures/file_with_bug' recursively without -r\n"
    command_error = Command('rm tests/fixtures/file_with_bug', script_error)
    assert match(command_error)

    script_error = u"fatal: not removing 'tests/fixtures/file_with_bug' recursively without -r"
    command_error = Command('rm tests/fixtures/file_with_bug', script_error)
    assert match(command_error)

    script_error = u"fatal: not removing tests/fixtures/file_with_bug recursively without -r\n"
    command_error = Command('rm tests/fixtures/file_with_bug', script_error)
    assert match(command_error)

    script

# Generated at 2022-06-22 02:01:01.778655
# Unit test for function match
def test_match():
    # Tests match function with the situation not related to git.
    assert_not_equals(match(
        Command(script='foo', output='Command not found: foo')), None)

    # Tests match function with the situation not related to git.
    assert_not_equals(match(
        Command(script='git rm foo', output='fatal: Unable to find foo')), None)

    # Tests match function with the situation not related to git.
    assert_not_equals(match(
        Command(script='git rm -r foo', output='fatal: Unable to find foo')), None)

    # Tests match function with the situation related to git.
    assert_equals(match(
        Command(script='git rm foo', output="fatal: not removing 'foo' recursively without -r")), None)

    # Tests match function

# Generated at 2022-06-22 02:01:09.041317
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test.txt', 'fatal: not removing \'test.txt\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r test.txt'

# Generated at 2022-06-22 02:01:10.404972
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm x', "fatal: not removing 'x' recursively without -r")) == 'git rm -r x'

# Generated at 2022-06-22 02:01:13.284023
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command = rules.get_new_command
    assert get_new_command(Command('rm',
                                   '/tmp/test',
                                   '',
                                   'fatal: not removing'
                                   ' \'/tmp/test\' recursively'
                                   ' without -r')) == 'git rm -r /tmp/test'

# Generated at 2022-06-22 02:01:15.348026
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git rm -r file/'))
    assert new_command == 'git rm -r -r file/'

# Generated at 2022-06-22 02:01:19.358883
# Unit test for function get_new_command

# Generated at 2022-06-22 02:01:21.831982
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm --cached -r dir/")
    assert get_new_command(command) == "git rm --cached -r -r dir/"


# Generated at 2022-06-22 02:01:24.994044
# Unit test for function get_new_command
def test_get_new_command():
	command = 'git rm file/directory'
	assert(get_new_command(Command(command, error_message, None, 1)) == 'git rm -r file/directory')

# Generated at 2022-06-22 02:01:28.583270
# Unit test for function match
def test_match():
    assert match(Command('git rm README.md', 'fatal: not removing \'README.md\' recursively without -r'))
    assert not match(Command('git rm README.md', ''))


# Generated at 2022-06-22 02:01:30.543711
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf "directory"'))


# Generated at 2022-06-22 02:01:35.627031
# Unit test for function match
def test_match():
    assert match(Command("git rm -r test/foo", "fatal: not removing 'test/foo' recursively without -r"))
    assert not match(Command("git rm -r test/foo", ""))
    assert not match(Command("git rm test/foo", "fatal: not removing 'test/foo' recursively without -r"))


# Generated at 2022-06-22 02:01:43.755482
# Unit test for function match
def test_match():
    assert match(Command('git rm folder', 'fatal: not removing \'folder\' recursively without -r', ''))
    assert not match(Command('git rm folder', 'fatal: not deleting \'folder\' without -r', ''))


# Generated at 2022-06-22 02:01:46.888591
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('rm hello.py')) == 'git rm -r hello.py'
    assert get_new_command(Command('rm -r test')) == 'git rm -r -r test'

# Generated at 2022-06-22 02:01:48.747292
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'

# Generated at 2022-06-22 02:01:55.102753
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command([u"git", u"rm", u"r", u"file"]) == u"git rm -r r file"
    assert get_new_command([u"git", u"rm", u"-r", u"r", u"file"]) == u"git rm -r -r r file"
    assert get_new_command([u"git", u"rm", u"-f", u"r", u"file"]) == u"git rm -f -r r file"


# Generated at 2022-06-22 02:02:05.317243
# Unit test for function match
def test_match():
    command_with_rule = Command('git rm -r *', 'fatal: not removing \'filename\' recursively without -r')
    assert match(command_with_rule)
    command_with_rule_and_other_text = Command('git rm -r *', 'fatal: not removing \'filename\' recursively without -r\nla\nla')
    assert match(command_with_rule_and_other_text)
    command_with_no_rule = Command('git rm -r *', 'fatal: not removing \'filename\' recursively with -r')
    assert not match(command_with_no_rule)

# Generated at 2022-06-22 02:02:08.870913
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm hello', stderr="fatal: not removing 'hello' recursively without -r\n")

    assert get_new_command(command) == 'git rm -r hello'

# Generated at 2022-06-22 02:02:10.814804
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm foo')) == 'git rm -r foo'

# Generated at 2022-06-22 02:02:21.061992
# Unit test for function match
def test_match():
    assert match(Command('git rm non_existing_file',
                         '/root/test', 'fatal: not removing \'non_existing_file\' recursively without -r'))
    assert match(Command('git rm ~/some/non_existing_directory',
                         '/root/test', 'fatal: not removing \'~/some/non_existing_directory\' recursively without -r'))
    assert not match(Command('git rm exiting_file',
                             '/root/test', 'fatal: not removing \'non_existing_file\' recursively without -r'))
    assert not match(Command('git rm -r existing_directory',
                             '/root/test', 'fatal: not removing \'~/some/existing_directory\' recursively without -r'))

# Generated at 2022-06-22 02:02:26.649347
# Unit test for function match
def test_match():
    assert match(Command('git stash',
                         "fatal: Pathspec 'stash@{1}' is in submodule 'lib'\n"
                         'fatal: not removing \'stash@{1}\' recursively without -r'))
    assert not match(Command('git stash',
                         "fatal: Pathspec 'stash@{1}' is in submodule 'lib'"))

# Generated at 2022-06-22 02:02:29.667164
# Unit test for function get_new_command
def test_get_new_command():
    assert  git_rm_without_r.get_new_command(
        Command('foo', 'git rm -r foo', 'fatal: not removing foo recursively without -r')) == 'git rm -r -r foo'


# Generated at 2022-06-22 02:02:39.870250
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm test.py') == 'git rm -r test.py'
    assert get_new_command('git rm -rf test.py') == 'git rm -r -rf test.py'
    assert get_new_command('git rm -r -rf test.py') == 'git rm -r -r -rf test.py'

# Generated at 2022-06-22 02:02:42.538700
# Unit test for function match
def test_match():
    assert match(Command('git rm hello.py',
                         'fatal: not removing \'hello.py\' recursively without -r'))
    assert not match(Command('git rm hello.py', 'hello.py'))



# Generated at 2022-06-22 02:02:44.859288
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm test', 'fatal: not removing test')) == 'git rm -r test'

# Generated at 2022-06-22 02:02:48.250101
# Unit test for function match
def test_match():
    command = Command("git rm dir/", "fatal: not removing 'dir/' recursively without -r")
    match(command) == True
    command = Command("git rm dir/", "fatal: not removing 'dir/' recursively without -r")
    match(command) == True



# Generated at 2022-06-22 02:02:51.941897
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file'

    command = Command('git rm -r file', 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) is None

# Generated at 2022-06-22 02:02:57.516596
# Unit test for function match
def test_match():
    assert not match(Command("rm -f test/*.txt"))
    assert match(Command("git rm *.txt", "fatal: not removing '*.txt' recursively without -r"))
    assert not match(Command("git rm -f -r *.txt", "fatal: not removing '*.txt' recursively without -r"))


# Generated at 2022-06-22 02:03:01.184139
# Unit test for function match
def test_match():

    command = Command("git rm foo", "fatal: not removing 'foo' recursively without -r")
    assert match(command)

    command = Command("git rm foo", "fatal: not removing 'foo' recursively without -ro")
    assert not match(command)

# Generated at 2022-06-22 02:03:04.411539
# Unit test for function match
def test_match():
  assert match(Command("git rm foo bar ", "fatal: not removing 'foo' recursively without -r"))
  assert not match(Command("ls", "OK"))

# Generated at 2022-06-22 02:03:05.754189
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm foo") == "git rm -r foo"

# Generated at 2022-06-22 02:03:16.335915
# Unit test for function get_new_command
def test_get_new_command():
    # Fail to recursively add path to git index
    assert(get_new_command(Command('git rm -f dir',
                                   'fatal: not removing ' +
                                   "'dir' recursively without -r\n")) ==
           'git rm -r -f dir')

    # Fail to recursively add path to git index
    assert(get_new_command(Command('git rm -f dir/',
                                   'fatal: not removing ' +
                                   "'dir/' recursively without -r\n")) ==
           'git rm -r -f dir/')
    # No spaces in path

# Generated at 2022-06-22 02:03:28.887044
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file',
                      'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-22 02:03:31.768326
# Unit test for function match
def test_match():
    a = Command('git rm -r dir',\
    "fatal: not removing 'dir' recursively without -r\n",
    None, None, None, None)
    assert(match(a))

# Generated at 2022-06-22 02:03:33.856656
# Unit test for function match
def test_match():
    assert match(Command('git rm script.py', ''))
    assert not match(Command('git add script.py', ''))


# Generated at 2022-06-22 02:03:39.752036
# Unit test for function match
def test_match():
    # Test success criteria
    assert (match(Command(script='git rm newFile.txt',
        output='fatal: not removing \'newFile.txt\' recursively without -r'))
            == True)

    # Test fail criteria
    assert (match(Command(script='git add newFile.txt',
        output='fatal: not removing \'newFile.txt\' recursively without -r'))
            == False)


# Generated at 2022-06-22 02:03:44.921348
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert test_get_new_command() == 'git rm -r a.txt b.txt'
    assert test_get_new_command() == 'git rm -r a.txt'
    assert test_get_new_command() == 'git rm -r a.txt c.txt'

# Generated at 2022-06-22 02:03:49.109639
# Unit test for function match
def test_match():
    # Does match
    assert match(Command('git rm x', '', 'fatal: not removing \'x\' recursively without -r\n'))

    # Does not match
    assert not match(Command('git x', '', 'fatal: not removing \'x\' recursively without -r\n'))

# Generated at 2022-06-22 02:03:53.994823
# Unit test for function match
def test_match():
    assert match(Command('git rm file', '', '', 1))
    assert not match(Command('git rm', '', '', 1))
    assert not match(Command('foo rm', '', '', 1))
    assert not match(Command('foo', '', '', 1))


# Generated at 2022-06-22 02:03:58.898840
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm x', '', '')) == 'git rm -r x'
    assert get_new_command(Command('git rm -r x', '', '')) == 'git rm -r x'
    assert get_new_command(Command('git rm x y', '', '')) == 'git rm x -r y'

# Generated at 2022-06-22 02:04:01.898178
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command(
        script="git rm file/path a/directory",
        output="fatal: not removing 'file/path' recursively without -r"))
        == 'git rm -r file/path a/directory')

# Generated at 2022-06-22 02:04:05.358311
# Unit test for function get_new_command
def test_get_new_command():
    output = u'fatal: not removing \'file\' recursively without -r'

    command = Command('git rm file')
    assert get_new_command(Command(command, output)) == 'git rm -r file'

# Generated at 2022-06-22 02:04:28.294781
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'
    assert get_new_command('git rm --cached foo') == 'git rm -r --cached foo'

# Generated at 2022-06-22 02:04:30.598542
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r', '', 0, ''))

# Generated at 2022-06-22 02:04:36.764937
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r s3')) == 'git rm -r -r s3'
    assert get_new_command(Command('git rm -r s3 s4')) == 'git rm -r -r s3 s4'
    assert get_new_command(Command('git rm -r s3 s4 s5')) == 'git rm -r -r s3 s4 s5'


# Generated at 2022-06-22 02:04:45.057453
# Unit test for function match
def test_match():
    """Unit test for function match"""
    test_assert_equal(False, match(Command('git rm -rf test', '')))
    test_assert_equal(False,
                      match(Command('git rm -rf test', 'fatal: not removing '
                                                      "'test' recursively without -r",
                                    '', 1)))
    test_assert_equal(True,
                      match(Command('git rm -rf test', 'fatal: not removing '
                                                      "'test' recursively without -r",
                                    '', 1)))


# Generated at 2022-06-22 02:04:51.628294
# Unit test for function match
def test_match():
    assert not match(Command('rm file', ''))
    assert match(Command(u'git rm file', u"fatal: not removing 'file' "
                         u"recursively without -r"))
    assert match(
        Command('git rm file', u"fatal: not removing 'file' "
                u"recursively without -r"))
    assert not match(Command('git rm file', ''))
    assert match(Command(u'git rm -r file', u"fatal: not removing 'file' "
                         u"recursively without -r"))


# Generated at 2022-06-22 02:04:58.139465
# Unit test for function match
def test_match():
    assert (match(Command('git rm file', 'fatal: not removing \'file\' recursively without -r'))
            == True)
    assert (match(Command('git rm hello.txt', "fatal: not removing 'hello.txt' recursively without -r"))
            == True)
    assert (match(Command('git rm hello.txt', ''))
            == False)
    assert (match(Command('git rm -r folder', "fatal: not removing 'folder' recursively without -r"))
            == False)


# Generated at 2022-06-22 02:05:01.096629
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3', ''))
    assert not match(Command('git rm file1', ''))
    assert not match(Command('git rm file1 file2', ' GitKeep File'))


# Generated at 2022-06-22 02:05:05.456099
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm')) == 'git rm -r'
    assert get_new_command(Command('git rm -r', '')) == 'git rm -r'
    assert get_new_command(Command('git rm -r')) == 'git rm -r'


# Generated at 2022-06-22 02:05:09.478293
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -r 'public'", "fatal: not removing 'public' recursively without -r\n")
    assert get_new_command(command) == "git rm -r -r 'public'"