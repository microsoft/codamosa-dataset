

# Generated at 2022-06-22 01:55:14.526165
# Unit test for function match
def test_match():
    assert match(Command('git rm file/without/submodules',
                         stderr='fatal: not removing '
                                '\'file/without/submodules\' recursively '
                                'without -r\n'))
    assert not match(Command('ls', ''))
    assert not match(Command('cd directory/', ''))

# Generated at 2022-06-22 01:55:17.581454
# Unit test for function match
def test_match():
    assert match(Command('git rm',
                         'fatal: not removing \'submodule\' recursively without -r'))
    assert not match(Command('git rm', ''))



# Generated at 2022-06-22 01:55:20.021870
# Unit test for function match
def test_match():
    assert match(Command("git rm foo")) == False
    assert match(Command("git rm foo", "fatal: not removing 'foo' recursively without -r")) == True

# Generated at 2022-06-22 01:55:21.953721
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command(Command('git rm file_name', '', '')))


enabled_by_default = True

# Generated at 2022-06-22 01:55:26.914546
# Unit test for function get_new_command
def test_get_new_command():
    from types import SimpleNamespace
    command = SimpleNamespace(script='git rm toto', script_parts=['git', 'rm', 'toto'], output="fatal: not removing 'toto' recursively without -r")
    command2 = SimpleNamespace(script='git rm toto', script_parts=['git', 'rm', 'toto'], output="fatal: not removing 'toto' recursively without -r")
    assert get_new_command(command) == 'git rm -r toto'
    assert get_new_command(command2) == 'git rm -r toto'

# Generated at 2022-06-22 01:55:29.406355
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm test") == "git rm -r test"

# Generated at 2022-06-22 01:55:32.794497
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
        "fatal: not removing 'file' recursively without -r", ''))
    assert not match(Command('git rm',
        "fatal: not removing 'file' recursively without -r", ''))


# Generated at 2022-06-22 01:55:35.681903
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm submodule -rf',
                            '/home/george/test',
                            'fatal: not removing \'submodule\' recursively without -r\n')) \
        == 'git rm -r submodule -rf'

# Generated at 2022-06-22 01:55:40.125047
# Unit test for function match
def test_match():
    assert match(Command("git rm 'file with spaces'", "fatal: not removing 'file with spaces' recursively without -r"))
    assert match(Command("git rm 'file with spaces'", "")) == False


# Generated at 2022-06-22 01:55:44.508596
# Unit test for function match
def test_match():
    assert match(Command('git rm foo/bar.txt',
                         'fatal: not removing \'foo/bar.txt\' recursively without -r\n'))
    assert not match(Command('git rm foo/bar.txt', ''))
    assert not match(Command('git', ''))


# Generated at 2022-06-22 01:55:48.632869
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm loc -rf',
                                   'fatal: not removing \'loc\' recursively without -r')) == 'git rm -r loc -rf'

# Generated at 2022-06-22 01:55:52.801375
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', 'rm', 'single_file']
    assert get_new_command(Command(script=u' '.join(command_parts),
                                   output='fatal: not removing')) == \
                                   u' '.join(command_parts)

# Generated at 2022-06-22 01:55:58.780867
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test/sample.txt', 'fatal: not removing \
\'test/sample.txt\' recursively without -r'))
    assert not match(Command('git rm test/sample.txt', 'fatal: not removing \
\'test/sample.txt\' recursively without -r'))
	

# Generated at 2022-06-22 01:56:02.204561
# Unit test for function match
def test_match():
    assert match(Command('rm file1 file2', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('rm file1 file2', 'rm: cannot remove \'file1\': No such file or directory'))



# Generated at 2022-06-22 01:56:03.165626
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm a', 'not removing a', '')) == 'git -r rm a'

# Generated at 2022-06-22 01:56:05.305111
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r test' == get_new_command(Command('git rm test',
                                                        'fatal: not removing \'test\' recursively without -r'))

# Generated at 2022-06-22 01:56:08.481338
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2', '', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git checkout branch', '', 'fatal: reference is not a tree: branch'))


# Generated at 2022-06-22 01:56:15.879955
# Unit test for function match
def test_match():
    assert match(Command("git rm 'File with spaces in the name.txt'",
                         "fatal: not removing 'File with spaces in the name.txt' recursively without -r"))
    assert not match(Command("git rm 'File with spaces in the name.txt'", ""))
    assert not match(Command("rm 'File with spaces in the name.txt'",
                             "fatal: not removing 'File with spaces in the name.txt' recursively without -r"))


# Generated at 2022-06-22 01:56:20.156198
# Unit test for function get_new_command
def test_get_new_command():
    command = 'rm file1'
    command_parts = command.split()
    index = command_parts.index('rm') + 1
    command_parts.insert(index, '-r')
    assert get_new_command(command) == u' '.join(command_parts)

# Generated at 2022-06-22 01:56:22.095007
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm README.rst', '')) == 'git rm -r README.rst'

# Generated at 2022-06-22 01:56:27.109848
# Unit test for function match
def test_match():
    assert(match(Command(script = "git rm file.txt",
                        output = "fatal: not removing 'file.txt' recursively without -r")) is True)


# Generated at 2022-06-22 01:56:31.938282
# Unit test for function match
def test_match():
	# Test for match function false
    assert not match('git status')
    assert not match('git rm file_name')
    assert not match('git rm -r file_name')
    assert not match('git rm -rf file_name')
	# Test for match function true
    assert match('git rm file_name ')

	

# Generated at 2022-06-22 01:56:35.214952
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm dummyfile', 'fatal: not removing \'dummyfile\' recursively without -r')
    assert str(get_new_command(command)) == 'git rm -r dummyfile'

# Generated at 2022-06-22 01:56:45.853349
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2', 'test_output'))
    assert match(Command('git rm --cached file1 file2', 'test_output'))
    assert match(Command('git rm -f --cached file1 file2', 'test_output'))
    assert match(Command('git rm *', 'test_output'))
    assert not match(Command('git rm file1 file2', 'test_output', 'test_error'))
    assert not match(Command('git rm --cached file1 file2', 'test_output', 'test_error'))
    assert not match(Command('git rm -f --cached file1 file2', 'test_output', 'test_error'))
    assert not match(Command('git rm *', 'test_output', 'test_error'))


# Generated at 2022-06-22 01:56:51.197282
# Unit test for function match
def test_match():
    assert match(Command('git rm -f foobar',
                         'fatal: not removing \'foobar\' recursively without -r'))
    assert not match(Command('git rm foobar',
                             'fatal: not removing \'foobar\' recursively without -r'))
    assert not match(Command('git rm foobar', ''))



# Generated at 2022-06-22 01:56:54.612060
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf')) == 'git rm -rf -r'
    assert get_new_command(Command('git rm -rf dir')) == 'git rm -rf -r dir'

# Generated at 2022-06-22 01:56:56.704461
# Unit test for function match
def test_match():
    assert(match(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r')))
    asse

# Generated at 2022-06-22 01:57:00.324836
# Unit test for function match
def test_match():
    assert match(Command('git rm ui/foo',
                         stderr='fatal: not removing \'ui/foo\' recursively without -r'))
    assert not match(Command('git rm'))


# Generated at 2022-06-22 01:57:03.753610
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -rf src', "fatal: not removing 'src' recursively without -r")
    assert get_new_command(command) == 'git rm -r -rf src'

# Generated at 2022-06-22 01:57:12.954270
# Unit test for function match
def test_match():
    # Test git rm
    assert match(Command('git rm index',
                         'fatal: not removing \'index\' recursively without -r'))
    # Test git rm -r
    assert not match(Command('git rm -r index',
                         'fatal: not removing \'index\' recursively without -r'))
    # Test git rm -r index, Does not break if rm is not in the right place
    assert not match(Command('git rm -r index',
                         'fatal: not removing \'index\' recursively without -r'))
    # Test other command
    assert not match(Command('git add index',
                         'fatal: not removing \'index\' recursively without -r'))
    # Test bad error message

# Generated at 2022-06-22 01:57:18.230432
# Unit test for function match
def test_match():
    command = Command('git rm -r dir', 'fatal: not removing '
                      + "'dir' recursively without -r")
    assert match(command)


# Generated at 2022-06-22 01:57:29.660472
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm 'dir\'",
                      "fatal: not removing 'dir\\' recursively without -r\n")
    command1 = Command("git rm 'dir'",
                       "fatal: not removing 'dir' recursively without -r\n")
    command2 = Command("git rm \\'dir\\'",
                       "fatal: not removing 'dir' recursively without -r\n")
    command3 = Command("git rm \"dir\"",
                       "fatal: not removing 'dir' recursively without -r\n")
    command4 = Command("git rm 'dir with spaces'",
                       "fatal: not removing 'dir with spaces' recursively without -r\n")

# Generated at 2022-06-22 01:57:32.386895
# Unit test for function get_new_command
def test_get_new_command():
    assert u"git rm -r" == get_new_command(ShellCommand(script=u'git rm test',
                                                        output=u"fatal: not removing 'test' recursively without -r"))

# Generated at 2022-06-22 01:57:38.736901
# Unit test for function get_new_command

# Generated at 2022-06-22 01:57:40.370059
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'git -r status'

# Generated at 2022-06-22 01:57:41.983260
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command( Command('git rm -r c') ) == 'git rm -r -r c'

# Generated at 2022-06-22 01:57:45.290262
# Unit test for function match
def test_match():
    assert match(Command('git rm fuck', ''))
    assert not match(Command('git rm fuck', '', stderr='fatal: not removing'))
    assert not match(Command('git rm fuck', '', stderr='fatal: not removing'))
    assert not match(Command('git rm', ''))


# Generated at 2022-06-22 01:57:54.007179
# Unit test for function match
def test_match():
    match_command_output = "fatal: not removing 'brick' recursively without -r"
    not_match_command_output = "fatal: not removing 'brick' recursively without -r"
    command = Command(script='free', output=not_match_command_output)
    assert not match(command)
    command = Command(script='free', output=not_match_command_output)
    assert not match(command)
    command = Command(script='rm brick', output=match_command_output)
    assert match(command)
    

# Generated at 2022-06-22 01:57:57.324310
# Unit test for function get_new_command
def test_get_new_command():
    # create command
    command = Command('git rm -r tmp/',
                      'fatal: not removing \'tmp/\' recursively without -r')
    # return new command
    assert get_new_command(command) == 'git rm -r -r tmp/'

# Generated at 2022-06-22 01:58:02.237619
# Unit test for function match
def test_match():
    git_rm_stderr = ("fatal: not removing 'tests/functional/test_rules/testdata/test_git.py' recursively without -r\n")
    assert match(Command('git rm tests/functional/test_rules/testdata/test_git.py', git_rm_stderr))



# Generated at 2022-06-22 01:58:10.893469
# Unit test for function match
def test_match():
    assert match(Command('git rm -r foo', 
                         "fatal: not removing 'foo' recursively without -r",
                         '', '', '', ''))
    assert match(Command('git rm foo/bar',
                         "fatal: not removing 'foo/bar' recursively without -r",
                         '', '', '', ''))
    assert not match(Command('git rm -r foo', '', '', '', '', ''))


# Generated at 2022-06-22 01:58:16.649623
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf /path/to/dir', u'fatal: not removing \'/path/to/dir\' recursively without -r\n')
    assert get_new_command(command).script == 'git rm -rf -r /path/to/dir'
    assert get_new_command(command).output == u'fatal: not removing \'/path/to/dir\' recursively without -r\n'

# Generated at 2022-06-22 01:58:25.099332
# Unit test for function get_new_command
def test_get_new_command():
    # error message with file and folder
    command = Command("git rm file.txt other_folder", 
                      "fatal: not removing 'other_folder' recursively without -r")
    assert get_new_command(command) == "git rm -r file.txt other_folder"

    # error message with only folder
    command = Command("git rm other_folder", 
                      "fatal: not removing 'other_folder' recursively without -r")
    assert get_new_command(command) == "git rm -r other_folder"

# Generated at 2022-06-22 01:58:27.825631
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r\n', ''))


# Generated at 2022-06-22 01:58:32.346830
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -r my_folder',
                      output='fatal: not removing \'my_folder\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r -r my_folder'

# Generated at 2022-06-22 01:58:40.053232
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command
    assert get_new_command(Command('git rm a', 'fatal: not removing '
        "'a' recursively without -r\nDid you mean 'rm -r'?")) == \
        'git rm -r a'
    assert get_new_command(Command('git rm -r', 'fatal: not removing '
        "'a' recursively without -r\nDid you mean 'rm -r'?")) == \
        'git rm -r -r'

# Generated at 2022-06-22 01:58:42.017211
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm file1 file2 file3') == 'git rm -r file1 file2 file3'

# Generated at 2022-06-22 01:58:46.622064
# Unit test for function match
def test_match():
    assert match(Command('git rm -f *.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm -f *.txt', 'fatal: file.txt does not exist'))



# Generated at 2022-06-22 01:58:50.642153
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r test')
    new_command = get_new_command(command)
    assert new_command == 'git rm -r -r test'
    assert get_new_command(Command('git rm test')) == 'git rm -r test'

# Generated at 2022-06-22 01:58:55.856469
# Unit test for function match
def test_match():
    assert match(Command('git rm file.py', 'fatal: not removing \'file.py\' recursively without -r', ''))
    assert not match(Command('git status', '', ''))
    assert not match(Command('git rm -r file.py', '', ''))
    assert not match(Command('rm file.py', '', ''))


# Generated at 2022-06-22 01:59:05.242914
# Unit test for function match
def test_match():
    assert match(Command(script='git rm some',
                         output='fatal: not removing \'some\' recursively without -r'))
    assert not match(Command(script='git rm some',
                             output='fatal: not removing \'some\''))


# Generated at 2022-06-22 01:59:08.560383
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git rm test/file',
                                   'fatal: not removing \'test/file\' recursively without -r')) == 'git rm -r test/file'

# Generated at 2022-06-22 01:59:12.467254
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = "git rm -r fileneame")) == "git rm -r -r fileneame"
    assert get_new_command(Command(script = "git rm filenmae2")) == "git rm -r filenmae2"

# Generated at 2022-06-22 01:59:17.182091
# Unit test for function get_new_command
def test_get_new_command():
    old_command = Command('git rm xxxx', 'git rm xxxx\nfatal: not removing \'xxxx\' recursively without -r\n')
    new_command = get_new_command(old_command)
    assert new_command == 'git rm -r xxxx'

# Generated at 2022-06-22 01:59:19.858014
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r')).script ==
            'git rm -r file')

# Generated at 2022-06-22 01:59:22.101131
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm file')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-22 01:59:24.492272
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         "fatal: not removing 'file' recursively without -r"))


# Generated at 2022-06-22 01:59:25.731460
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm -fr a_dir', "fatal: not removing 'a_dir' recursively without -r", '')
    assert get_new_command(command) == u'git rm -r -fr a_dir'

# Generated at 2022-06-22 01:59:28.335834
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f a/b')
    assert_equals(get_new_command(command), 'git rm -r -f a/b')

# Generated at 2022-06-22 01:59:29.944651
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'

# Generated at 2022-06-22 01:59:40.526130
# Unit test for function get_new_command
def test_get_new_command():
    command_ = Command('git rm -r test/file/path', 'fatal: not removing \'path\' recursively without -r')
    matching = match(command_)
    assert matching
    changes_ = get_new_command(command_)
    assert 'git rm -r -r test/file/path' == changes_

# Generated at 2022-06-22 01:59:47.541769
# Unit test for function match
def test_match():
    # Test git rm command
    assert match(Command('git rm -r lib',
                         output='fatal: not removing \'lib\' recursively without -r'))
    # Test errors without 'fatal: not removing'
    assert not match(Command('git rm -r lib',
                         output='fatal: not removing \'lib\' recursively'))

    # Test non git command with 'git rm -r'
    assert not match(Command('sudo rm -r lib',
                         output='fatal: not removing \'lib\' recursively without -r'))


# Generated at 2022-06-22 01:59:49.588474
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -a")
    assert(get_new_command(command) == "git rm -r -a")

# Generated at 2022-06-22 01:59:54.080073
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert (u'git rm -r file' ==
            get_new_command(Command('git rm file',
                                    output= ('fatal: not removing '
                                             "'file' recursively without -r"))))

# Generated at 2022-06-22 01:59:56.737409
# Unit test for function get_new_command
def test_get_new_command():
    # Test case 1
    input_command = Command(script='git rm myfile')
    assert_equals(get_new_command(input_command), 'git rm -r myfile')

# Generated at 2022-06-22 01:59:59.014296
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r', ''))
    assert not match(Command('rm bar', '', ''))

# Generated at 2022-06-22 02:00:01.312850
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git rm abc', 'fatal: not removing '
                                    "'abc' recursively without -r"))
            == 'git rm -r abc')

# Generated at 2022-06-22 02:00:04.607522
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git rm test')) == 'git rm -r test'
    assert(get_new_command('git rm test test2')) == 'git rm -r test test2'


# Generated at 2022-06-22 02:00:12.594925
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    command = Command('git rm -rf path/to/dir')
    assert get_new_command(command) == 'git rm -rf -r path/to/dir'
    
    command = Command('git rm -rf  path/to/dir')
    assert get_new_command(command) == 'git rm -rf -r path/to/dir'

    command = Command('git rm -rf   path/to/dir')
    assert get_new_command(command) == 'git rm -rf -r path/to/dir'

# Generated at 2022-06-22 02:00:15.497976
# Unit test for function match
def test_match():
	assert match(Command('git rm -r a/b',
			     'fatal: not removing \'a/b\' recursively without -r\n',
			     '', 1))

# Generated at 2022-06-22 02:00:24.134410
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm foo')
    assert get_new_command(command).script == 'git rm -r foo'
    command = Command('git foo rm bar')
    assert get_new_command(command).script == 'git foo rm -r bar'

# Generated at 2022-06-22 02:00:27.594968
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm -r "file"',
                      stdout='fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r -r "file"'

# Generated at 2022-06-22 02:00:31.920604
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file1',
                         "fatal: not removing 'file1' recursively without -r"))
    assert not match(Command('rm file1',
                             "fatal: not removing 'file1' recursively without -r"))


# Generated at 2022-06-22 02:00:37.676631
# Unit test for function match
def test_match():
    # These functions are used to simulate the behavior of the shell command
    def my_script(command):
        return command.script

# Generated at 2022-06-22 02:00:39.107757
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm') == 'git rm -r'


# Generated at 2022-06-22 02:00:43.091714
# Unit test for function match
def test_match():
    assert match(Command('git rm new_folder', '', 'fatal: not removing \'new_folder\' recursively without -r'))
    assert not match(Command('git stash', '', ''))



# Generated at 2022-06-22 02:00:45.525965
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(' git rm -r --cached somefile') == 'git rm -r -r --cached somefile'

# Generated at 2022-06-22 02:00:47.389931
# Unit test for function match
def test_match():
    assert match(Command('git remote rm origin'))
    assert not match(Command('git remote rm'))


# Generated at 2022-06-22 02:00:48.232975
# Unit test for function match
def test_match():
    assert match(Command('git rm -r folder/subfolder'))


# Generated at 2022-06-22 02:00:55.999435
# Unit test for function match
def test_match():
    assert match(Command('git rm file.name',
                         'error: the following file has local modifications\n'
                         '    file.name\n'
                         'error: git rm --cached file.name\n'))
    assert match(Command('git rm dir.name/file.name',
                         'fatal: not removing \'dir.name/file.name\' recursively without -r'))
    assert not match(Command('git rm dir.name/file.name',
                             'fatal: not removing \'dir.name/file.name\''))
    assert not match(Command('git rm file.name', ''))



# Generated at 2022-06-22 02:01:05.037090
# Unit test for function get_new_command
def test_get_new_command():
    F = Filter(match, get_new_command)
    assert F.get_new_command(Command(script='git rm -f support/test.py',
                                     output="fatal: not removing 'support/test.py' recursively without -r")) == 'git rm -rf support/test.py'

# Generated at 2022-06-22 02:01:07.282468
# Unit test for function match
def test_match():
    assert match(Command('git rm file', "fatal: not removing 'file' recursively without -r"))
    assert not match(Command('git add file', ''))



# Generated at 2022-06-22 02:01:11.837816
# Unit test for function match
def test_match():
    assert match(Script('git rm file.txt', ''))
    assert match(Script('git rm -r file.txt', ''))
    assert match(Script('git rm -r file.txt', ''))
    assert match(Script('git rm -r file.txt', ''))
    assert match(Script('git rm -r file.txt', ''))
    assert not match(Script('git help rm', ''))
    assert not match(Script('git branch', ''))


# Generated at 2022-06-22 02:01:14.444218
# Unit test for function match
def test_match():
    assert match(Command('git rm src/file.txt',
                "fatal: not removing 'src/file.txt' recursively without -r",
                ''))
    assert not match(Command('git rm -r src',
                u'fatal: not removing \'src\' recursively without -r',
                ''))

# Generated at 2022-06-22 02:01:16.441882
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit')) == 'git rm -r commit'
    assert get_new_command(Command('git rm commit')) == 'git rm -r commit'

# Generated at 2022-06-22 02:01:20.596914
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(
        Command('git rm -r folder',
                'fatal: not removing \'folder\' recursively without -r',
                '')) == 'git rm -r -r folder')



# Generated at 2022-06-22 02:01:23.535169
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm foo', 'fatal: not removing \'foo\' recursively without -r', '')) == 'git rm -r foo'

# Generated at 2022-06-22 02:01:26.497993
# Unit test for function match
def test_match():
    script = 'git rm -r file1 file2'
    output = "fatal: not removing 'file1' recursively without -r"
    assert(match(get_command(script, output)))


# Generated at 2022-06-22 02:01:34.635219
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="git rm foo.txt", output="$ git rm foo.txt\nfatal: not removing 'foo.txt' recursively without -r\n", env={})
    assert get_new_command(command) == "git rm -r foo.txt"

    command = Command(script="rm foo.txt", output="$ rm foo.txt\nfatal: not removing 'foo.txt' recursively without -r\n", env={})
    assert get_new_command(command) == "rm -r foo.txt"

# Generated at 2022-06-22 02:01:36.874836
# Unit test for function match
def test_match():
    from thefuck.shells import Shell
    assert match(Shell('git rm foo', 'fatal: not removing \'foo\' recursively without -r'))

# Generated at 2022-06-22 02:01:54.107630
# Unit test for function match
def test_match():
    assert match(Command('git rm dir1/dir2/file.txt', 'fatal: not removing \'dir1/dir2/file.txt\' recursively without -r'))
    assert not match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git commit -m "message"', 'whatever'))
    assert not match(Command('git commit -m "message"', 'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-22 02:01:56.377261
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm test.txt") == "git rm -r test.txt", "failed to insert -r in rm command"

# Generated at 2022-06-22 02:01:59.811778
# Unit test for function get_new_command
def test_get_new_command():
	new_cmd = get_new_command('git rm <file>')
	assert new_cmd == 'git rm -r <file>'

# Generated at 2022-06-22 02:02:02.446429
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', '', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'

# Generated at 2022-06-22 02:02:07.217383
# Unit test for function match
def test_match():
    # Function returns True
    assert match(
        Command(script='git rm foo',
                output='fatal: not removing \'foo\' recursively without -r'))
    # Function returns False
    assert not match(
        Command(script='git rm foo',
                output='fatal: not removing \'foo\' recursively'))



# Generated at 2022-06-22 02:02:14.008825
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', '', ''))
    assert match(Command('git rm file.txt', '', 'fatal: not removing file.txt recursively without -r'))
    assert not match(Command('git rm file.txt', '', 'fatal: not removing file.txt'))
    assert not match(Command('git rm -r file.txt', '', ''))


# Generated at 2022-06-22 02:02:16.952406
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git rm file')) == u'git rm -r file'
    assert get_new_command(Command('git rm dir')) == u'git rm -r dir'


# Generated at 2022-06-22 02:02:20.484810
# Unit test for function get_new_command
def test_get_new_command():
    res = get_new_command(Command(script = 'git rm -r', output='fatal: not removing '' recursively without -r'))
    assert res == 'git rm -r '

# Generated at 2022-06-22 02:02:21.799081
# Unit test for function match
def test_match():
    assert match("git rm *")
    assert not match("git rm")

# Generated at 2022-06-22 02:02:26.028645
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /tmp/foo', '', 'fatal: not removing \'/tmp/foo\' recursively without -r'))
    assert not match(Command('rm -rf /tmp/foo', '', ''))


# Generated at 2022-06-22 02:02:51.708508
# Unit test for function match
def test_match():
    assert match(Command('rm -rf public/assets/*', '', '', '',
                         'fatal: not removing \'public/assets/bootstrap.min.js\' recursively without -r', 1))
    assert not match(Command('git rm file', '', '', '', '', 1))
    assert not match(Command('rm -rf public/assets/*', '', '', '', '', 1))


# Generated at 2022-06-22 02:02:55.688858
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                "fatal: not removing 'foo' recursively without -r"))
    assert match(Command('git rm foo', '')) is None



# Generated at 2022-06-22 02:02:59.102369
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm -r a') == 'git rm -r -r a'
    assert get_new_command('git rm -r a b c') == 'git rm -r -r a  b c'


# Generated at 2022-06-22 02:03:04.067458
# Unit test for function match
def test_match():
    assert (match(Command('rm file1 file2', 'fatal: not removing \'file1\' recursively without -r'
                                       '\n\'file1\' may be a directory, and was not removed')) != None)
    assert match(Command('rm file1 file2', 'Could not remove file1: Permission error')) == None


# Generated at 2022-06-22 02:03:06.078498
# Unit test for function match
def test_match():
   assert match(Command('git rm -r / ',
                        'fatal: not removing \'/\' recursively without -r'))


# Generated at 2022-06-22 02:03:11.384784
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r',
                         ''))
    assert not match(Command('git a',
                             'fatal: not removing \'file\' recursively'
                             ' without -r',
                             ''))

# Generated at 2022-06-22 02:03:16.815273
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm -r')) == u'git rm -r -r'
    assert get_new_command(Command(script='git rm')) == u'git rm -r'
    assert get_new_command(Command(script='git rm -rf')) == u'git rm -rf'
    assert get_new_command(Command(script='git rm -f')) == u'git rm -f -r'



# Generated at 2022-06-22 02:03:19.540414
# Unit test for function match
def test_match():
    assert match(Command('git remote rm origin', "fatal: not removing 'origin' recursively without -r", ''))


# Generated at 2022-06-22 02:03:25.395506
# Unit test for function match
def test_match():
    assert match(Command('git rm file_name',
                     "fatal: not removing 'file_name' recursively without -r"))
    assert not match(Command('git rm file_name',
                     "fatal: not removing 'file_name' recursively with -r"))
    assert not match(Command('ls file_name',
                     "fatal: not removing 'file_name' recursively without -r"))


# Generated at 2022-06-22 02:03:27.761026
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git rm", output="fatal: not removing 'scripts/' recursively without -r")) == "git rm -r"

# Generated at 2022-06-22 02:04:11.592663
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git branch branch_name', 'fatal: not removing \'.gitignore\' recursively without -r')
    assert get_new_command(command) == 'git branch -r branch_name'

# Generated at 2022-06-22 02:04:19.518218
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf path/to/file/name',
                         stderr='fatal: not removing \'path/to/file/name\' recursively without -r\n'))
    assert not match(Command('git rm -rf path/to/file/name',
                         stderr='fatal: not removing \'path/to/file/name\' recursively without -r'))
    assert not match(Command('git branch -rf branch_name branch_name',
                         stderr='error: branch \'branch_name\' not found.\n'));


# Generated at 2022-06-22 02:04:29.968459
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git rm myfile',
        'fatal: not removing \'myfile\' recursively without -r')) ==
        'git rm -r myfile')
    assert (get_new_command(Command('git -C myrepo rm myfile',
        'fatal: not removing \'myfile\' recursively without -r')) ==
        'git -C myrepo rm -r myfile')
    assert (get_new_command(Command('git -C myrepo rm -f myfile',
        'fatal: not removing \'myfile\' recursively without -r')) ==
        'git -C myrepo rm -f -r myfile')

# Generated at 2022-06-22 02:04:32.617739
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -r src')
    new_command = get_new_command(command)
    assert new_command.script == 'git rm -f -r src'

# Generated at 2022-06-22 02:04:41.044035
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    from thefuck.rules.git_remove_recursive import get_new_command
    wrong_command = Command('git rm file', '', '')
    new_command = get_new_command(wrong_command)
    assert(new_command == u'git rm -r file')
    # Check that function do not change command if it is not matched by rule, 
    # but throws an exception
    correct_command = Command('git branch', '', '')
    new_command = get_new_command(correct_command)
    assert(new_command == u'git branch')

# Generated at 2022-06-22 02:04:44.061214
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    new_command = get_new_command(Command(script="git rm -r test/folder"))
    assert new_command == u"git rm -r test/folder"

# Generated at 2022-06-22 02:04:54.578289
# Unit test for function match
def test_match():
   script = "git rm hello.txt"
   output = "fatal: not removing 'hello.txt' recursively without -r\n"
   command = Command(script, output)
   assert match(command)

   script = "git rm -r hello.txt"
   output = "fatal: not removing 'hello.txt' recursively without -r\n"
   command = Command(script, output)
   assert not match(command)

   script = "rm hello.txt"
   output = "fatal: not removing 'hello.txt' recursively without -r\n"
   command = Command(script, output)
   assert not match(command)

   script = "git rm hello.txt"
   output = "fatal: not removing 'hello.txt'\n"
   command = Command(script, output)
  

# Generated at 2022-06-22 02:04:56.889765
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git rm -r ", stderr="fatal: not removing '<directory>' recursively without -r")) == "git rm -r -r "

# Generated at 2022-06-22 02:04:58.527414
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -r path/to/file") == "git rm -r -r path/to/file"


# Generated at 2022-06-22 02:05:01.609430
# Unit test for function match
def test_match():
    assert match(Command('git rm -r test', 'fatal: not removing \'test\' \
recursively without -r'))
    assert not match(Command('git rm -rf test', 'fatal: not removing \'test\' \
recursively without -r'))