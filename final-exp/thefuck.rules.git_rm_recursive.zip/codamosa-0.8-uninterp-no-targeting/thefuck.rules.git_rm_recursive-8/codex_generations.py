

# Generated at 2022-06-22 01:55:09.597393
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm moo', '')) == "git rm -r moo"
    assert get_new_command(Command('git rm -f moo', '')) == "git rm -f -r moo"

# Generated at 2022-06-22 01:55:17.675372
# Unit test for function match
def test_match():
    assert not match(Command("foo", output=" rm "))
    assert not match(Command("foo", output=" rm -rf blah blah"))
    assert not match(Command("foo", output="fatal: not removing x"))
    assert not match(Command("rm", output="fatal: not removing 'x' recursively without -r"))
    assert match(Command(" foo ", output="fatal: not removing 'x' recursively without -r"))
    assert match(Command("git rm x", output="fatal: not removing 'x' recursively without -r"))
    

# Generated at 2022-06-22 01:55:21.432792
# Unit test for function match
def test_match():
    assert match(Command('git rm file',
                         'fatal: not removing \'file\' recursively without -r'))
    assert not match(Command('git branch -D branch',
                             'error: branch \'branch\' not found.'))


# Generated at 2022-06-22 01:55:22.939520
# Unit test for function match
def test_match():
    _, command = get_test_data()
    assert match(command)


# Generated at 2022-06-22 01:55:28.386141
# Unit test for function match
def test_match():
    assert match(Command('git rm filename'))
    assert match(Command('git rm -r folder'))
    assert not match(Command('git mv filename'))
    assert not match(Command('git rm filename', 'fatal: not removing '+
                                                "'filename'"+
                                                ' recursively without -r'))

# Generated at 2022-06-22 01:55:30.199168
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('git rm test')
    assert get_new_command(cmd) == 'git rm -r test'

# Generated at 2022-06-22 01:55:31.760382
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm dir', '', '')) == 'git rm -r dir'

# Generated at 2022-06-22 01:55:33.319368
# Unit test for function match
def test_match():
    assert match(Command('rm a b c', '', '', 1, 2))


# Generated at 2022-06-22 01:55:36.552668
# Unit test for function match
def test_match():
    assert match(Command('git rm bla',
                         'fatal: not removing \'name\' recursively without -r'))
    assert not match(Command('git rm bla', ''))
    assert not match(Command('ls bla',
                             'fatal: not removing \'name\' recursively without -r'))



# Generated at 2022-06-22 01:55:40.120864
# Unit test for function match
def test_match():
    assert match(Command("git rm fileA fileB", "", "fatal: not removing 'fileA' recursively without -r\n"))


# Generated at 2022-06-22 01:55:44.840419
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r test'

# Generated at 2022-06-22 01:55:47.747859
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    result = get_new_command(Command('git rm folder', 'not removing '
                                     'folder recursively', '', ''))
    assert u'git rm -r folder' == result



# Generated at 2022-06-22 01:55:49.578218
# Unit test for function match
def test_match():
    assert match(Command('git rm -r .'))
    assert match(Command('git rm .'))
    assert not match(Command('git rm -r .', ''))


# Generated at 2022-06-22 01:55:58.056543
# Unit test for function match
def test_match():
    assert match(Command('git rm src/file.txt',
                         'fatal: not removing \'src/file.txt\' recursively without -r'))
    assert match(Command('git rm src/file.txt')) is None
    assert match(Command('git rm src/file.txt',
                         'fatal: not removing \'src/file.txt\' recursively without -r',
                         'error: pathspec \'src/file.txt\' did not match any file(s) known to git.')) is None


# Generated at 2022-06-22 01:56:00.945040
# Unit test for function match
def test_match():
    command = Command('git rm temp.txt', 'fatal: not removing \'temp.txt/file.txt\' recursively without -r\n')
    assert match(command) is True


# Generated at 2022-06-22 01:56:03.636708
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 0)
    assert_equal('git rm -r file', get_new_command(command))

# Generated at 2022-06-22 01:56:06.919341
# Unit test for function match
def test_match():
    assert match(get_command(u'git rm img/a.png'))
    assert match(get_command(u'git rm img/b.png'))
    assert not match(get_command(u'git rm'))
    assert not match(get_command(u'git branch'))


# Generated at 2022-06-22 01:56:10.683319
# Unit test for function match
def test_match():
    # Test if the command matches
    assert match(Command('git rm tests', '', 'fatal: not removing \'tests\' recursively without -r', ''))
    assert not match(Command('git rm', '', '', ''))


# Generated at 2022-06-22 01:56:13.365360
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r')), 'git rm -r foo')

# Generated at 2022-06-22 01:56:20.491142
# Unit test for function match
def test_match():
    assert match(Command('git rm stuff', '', 'fatal: not removing \'stuff\' recursively without -r'))
    assert match(Command('git rm stuff', '', 'fatal: not removing \'stuff\' without -r'))
    assert match(Command('git rm stuff', '', 'fatal: not removing \'stuff\' recursively'))
    assert not match(Command('git rm stuff', '', 'fatal: not removing \'stuff\''))


# Generated at 2022-06-22 01:56:35.080049
# Unit test for function match
def test_match():
    assert_equal(match('git rm -r'), False)
    assert_equal(match('git rm -rf'), False)
    assert_equal(match('git rm -r foo'), False)
    assert_equal(match('git rm foo'), False)
    assert_equal(match('git rm --cached foo'), False)
    assert_equal(match('git rm foo bar'), False)

    # Test that a missing -r will be automatically added
    assert_equal(match('git rm foo bar'), False)
    assert_equal(match('git rm file_name'), False)
    assert_equal(match('git rm - -f'), False)
    assert_equal(match('git rm -f -f'), False)
    assert_equal(match('git rm -f file_name'), False)



# Generated at 2022-06-22 01:56:39.217554
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm commands/fukt.py') == 'git rm -r commands/fukt.py'
    assert get_new_command('git rm -r commands/fukt.py') == 'git rm -r commands/fukt.py'

# Generated at 2022-06-22 01:56:42.729368
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm --cached file1 file2', '', 'fatal: not removing \'file1\' recursively without -r\n')) == 'git rm -r --cached file1 file2'

# Generated at 2022-06-22 01:56:45.813567
# Unit test for function match
def test_match():
    assert match(Command('rm -r folder', '', 'fatal: not removing \'folder\' recursively without -r'))
    assert not match(Command('echo foo', '', 'bar'))

# Generated at 2022-06-22 01:56:50.146302
# Unit test for function get_new_command
def test_get_new_command():
	command = GitCommand('rm file', 'Too many files')
	new_command = get_new_command(command)
	assert 'rm -r' in new_command
	command = GitCommand('rm file', 'fatal: you need to resolve your current index first')
	assert new_command == get_new_command(command)

# Generated at 2022-06-22 01:56:54.151787
# Unit test for function match
def test_match():
    assert match(Command('rm foo', 'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('rm -rf foo', 'fatal: not removing \'foo\' recursively without -r'))



# Generated at 2022-06-22 01:56:57.415767
# Unit test for function match
def test_match():
    assert match(Command('git rm test',
                         'fatal: not removing \'test\' recursively without -r',
                         '', 3))
    assert not match(Command('git branch', '', '', 0))


# Generated at 2022-06-22 01:57:07.405756
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script = 'rm x', output = '')) == 'rm -r x'
    assert get_new_command(Command(script = 'rm -rf x', output = '')) == 'rm -rf x'
    assert get_new_command(Command(script = 'rm x y', output = '')) == 'rm -r x y'
    assert get_new_command(Command(script = 'rm x y z', output = '')) == 'rm -r x y z'
    assert get_new_command(Command(script = 'rm 1 2 3', output = '')) == 'rm 1 2 3'
    assert get_new_command(Command(script = 'rm --help x', output = '')) == 'rm --help -r x'


# Generated at 2022-06-22 01:57:17.886799
# Unit test for function match
def test_match():
    assert match(Command('git rm test',
                         output="fatal: not removing 'test' recursively "
                                "without -r"))
    assert not match(Command('git rm --cached -r test',
                             output="fatal: not removing 'test' "
                                    "recursively without -r"))
    assert not match(Command('git rm -r test',
                             output='/bin/rm: cannot remove '
                                    "'test/subdir/file': No such file or "
                                    "directory"))

# Generated at 2022-06-22 01:57:20.994331
# Unit test for function get_new_command
def test_get_new_command():
    with patch('os.getenv', lambda *args: '/gitpath'):
        assert u'git rm -r README' == get_new_command(Command(
            script='git rm README',
            stderr='fatal: not removing \'README\' recursively without -r\n'))

# Generated at 2022-06-22 01:57:33.855475
# Unit test for function match
def test_match():
    assert match(Command('rm a', 'fatal: not removing \'a\' recursively without -r'))
    assert match(Command('git rm a', 'fatal: not removing \'a\' recursively without -r'))
    assert match(Command('git branch -d a', 'fatal: not removing \'a\' recursively without -r'))
    assert not match(Command('rm a', 'rm: cannot remove \'a\': Is a directory'))



# Generated at 2022-06-22 01:57:35.233805
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm test') == 'git rm -r test'

# Generated at 2022-06-22 01:57:42.270990
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm', '', 'fatal: not removing ''filename'' recursively without -r')) == 'git rm -r'
    assert get_new_command(Command('git rm -rf', '', 'fatal: not removing ''filename'' recursively without -r')) == 'git rm -rf'
    assert get_new_command(Command('git rm -r ', '', 'fatal: not removing ''filename'' recursively without -r')) == 'git rm -r '

# Generated at 2022-06-22 01:57:45.751413
# Unit test for function match
def test_match():
    command = script.Command('git rm foo', 'fatal: not removing', True)
    assert match(command)

    command = script.Command('git branch -d foo', 'fatal: not removing', True)
    assert not match(command)

    command = script.Command('git rm foo', 'fatal: not removing', True)
    assert match(command)


# Generated at 2022-06-22 01:57:48.146334
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r dir')) == 'git rm -r -r dir'

# Generated at 2022-06-22 01:57:54.620485
# Unit test for function match
def test_match():
    assert match(Command(script='git rm -r *',
                         output="fatal: not removing '*' recursively without -r"))
    assert not match(Command(script='cd *',
                             output="fatal: not removing '*' recursively without -r"))
    assert not match(Command(script='git rm *',
                             output="fatal: not removing '*' recursively without -r"))



# Generated at 2022-06-22 01:58:00.916483
# Unit test for function match
def test_match():
    from thefuck.types import Command
    assert match(Command('git rm folder',
                         'fatal: not removing \'folder\' recursively without -r',
                         '', 1))

    assert not match(Command('git rm folder', '',
                             'fatal: not removing \'folder\' recursively without -r', 1))

    assert not match(Command('ls folder', '', '', 1))

    assert not match(Command('git add', '', '', 1))


# Generated at 2022-06-22 01:58:02.505907
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r file' == get_new_command('git rm file')

# Generated at 2022-06-22 01:58:06.712140
# Unit test for function match
def test_match():
    assert match(Command('git rm -r f1', 'fatal: not removing \'f1\' recursively without -r'))
    assert match(Command('git rm -r f1', 'fatal: not removing \'f1\' recursively without'))

# Generated at 2022-06-22 01:58:11.845445
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf hello', '', '', \
        'fatal: not removing \'hello\' recursively without -r', 1))
    assert not match(Command('git rm -rf hello', '', '', \
        'fatal: not removing \'hello\' recursively without -r'))
    assert not match(Command('git rm hello', '', '', ''))


# Generated at 2022-06-22 01:58:24.673967
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file')) == 'git rm -r file'
    assert get_new_command(Command('git rm -f file')) == 'git rm -f -r file'
    assert get_new_command(Command('git rm file dir')) == 'git rm -r file dir'


# Generated at 2022-06-22 01:58:28.543116
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command(script='git rm file',
                      stderr='fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command) == 'git rm -r file'


# Generated at 2022-06-22 01:58:34.033821
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3',
                         'fatal: not removing \'file2\' recursively without -r\n',
                         '/usr/bin/git'))

# Generated at 2022-06-22 01:58:40.013480
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf src /*.class', 'fatal: not removing \'src/main.class\' recursively without -r'))
    assert not match(Command('git rm -rf src/*.class', ''))
    assert not match(Command('git rm -rf src/*.class', 'fatal: not removing \'src/main.class\' recursively without -r'))


# Generated at 2022-06-22 01:58:41.965392
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm foo') == 'git rm -r foo'

# Generated at 2022-06-22 01:58:48.994872
# Unit test for function match
def test_match():
    assert match(Command('git rm f1/f2/f3/f4/file1', '', 'fatal: not removing \'f1/f2/f3/f4/file1\' recursively without -r'))
    assert not match(Command('git rm file1', '', 'fatal: not removing \'file1\' recursively without -r'))
    assert not match(Command('git rm file1', '', ''))


# Generated at 2022-06-22 01:58:50.385940
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git status', '', 'fatal: not removing \'foo\' recursively without -r')
    assert 'git rm -r foo' == get_new_command(command)

# Generated at 2022-06-22 01:58:52.485229
# Unit test for function match
def test_match():
    assert match(Command('git rm -r *',
    'fatal: not removing \'name*\' recursively without -r'))


# Generated at 2022-06-22 01:58:56.152107
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm -rf \"some path\"",
                      "fatal: not removing 'some path' recursively without -r")
    assert "git rm -r -rf \"some path\"" == get_new_command(command)

# Generated at 2022-06-22 01:58:58.298972
# Unit test for function match
def test_match():
    command = Command('git rm file', 'fatal: not removing \'file\' recursively without -r')
    assert match(command)



# Generated at 2022-06-22 01:59:26.063560
# Unit test for function match

# Generated at 2022-06-22 01:59:29.214154
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm -r folder/subfolder',
                                   stderr='fatal: not removing \'folder/subfolder\' recursively without -r')) == u'git rm -r -r folder/subfolder'

# Generated at 2022-06-22 01:59:30.249344
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git rm -rf dir/to/remove') == 'git rm -rf -r dir/to/remove')

# Generated at 2022-06-22 01:59:32.094776
# Unit test for function match
def test_match():
    runner = Prefix("git checkout dev")
    assert match(runner)
# test_match


# Generated at 2022-06-22 01:59:43.522616
# Unit test for function match
def test_match():
    assert match(Command('git rm', ''))
    assert match(Command('git rm foo', ''))
    assert match(Command('git rm foo bar', ''))
    assert match(Command('git rm foo bar', 'fatal: not removing \'foo\' recursively without -r'))
    
    assert not match(Command('git rm foo bar', 'fatal: not removing \'dir1\' recursively without -r'))
    assert not match(Command('git rm foo bar', 'fata: not removing \'dir1\' recursively without -r'))
    assert not match(Command('rm -rf .', 'fatal: not removing \'dir1\' recursively without -r'))
    assert not match(Command('ls', 'fatal: not removing \'dir1\' recursively without -r'))

# Generated at 2022-06-22 01:59:47.241768
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('rm test.md')
    command_parts = command.script_parts
    index = command_parts.index('rm') + 1
    command_parts.insert(index, '-r')
    assert get_new_command(command)== u' '.join(command_parts)

# Generated at 2022-06-22 01:59:54.325445
# Unit test for function match
def test_match():
    
    command = Command("./test.sh 'test'", "fatal: not removing 'test' recursively without -r")
    assert match(command) == True

    command = Command("./test.sh 'test'", "fatal: not removing 'test' recursively without -r")
    assert match(command) == True

    command = Command("./test.sh 'test'", "No like")
    assert match(command) == False


# Generated at 2022-06-22 01:59:56.255282
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -r file") == "git rm -r -r file"

# Generated at 2022-06-22 02:00:00.152658
# Unit test for function get_new_command
def test_get_new_command():
    # Initial command
    initial_command = 'git rm fish'
    # Expected result
    expected_result = 'git rm -r fish'
    # The new command
    new_command = get_new_command(initial_command)
    # Assert that the new command is equal to expected result
    assert new_command == expected_result



# Generated at 2022-06-22 02:00:03.879074
# Unit test for function get_new_command
def test_get_new_command():
    assert ('git rm -r', 'git rm -r a')\
        == GitRm('git rm a').get_new_command()
    assert ('git rm -r', 'git rm -r a')\
        == GitRm('git rm a').get_new_command()

# Generated at 2022-06-22 02:00:23.549222
# Unit test for function match
def test_match():
    assert match(Command(script = "git rm foo", output = "fatal: not removing 'foo' recursively without -r"))
    assert not match(Command(script = "git rm foo", output = "fatal: not removing 'foo' recursively without -r"))

# Generated at 2022-06-22 02:00:29.414277
# Unit test for function match
def test_match():
    output = 'fatal: not removing \'folder\' recursively without -r\n'
    match_out = match(command_types.Command(script='git rm folder', output=output))
    assert match_out == True
    match_out = match(command_types.Command(script='git rm', output=output))
    assert match_out == False
    match_out = match(command_types.Command(script='git rm folder', output=''))
    assert match_out == False

# Generated at 2022-06-22 02:00:31.919383
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r')) == 'git rm -r -r'

# Generated at 2022-06-22 02:00:37.036824
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm file', stdout=
        '''fatal: not removing 'file' recursively without -r
        nvert --no-edit --progress origin/master...HEAD
        Auto-merging file
        CONFLICT (modify/delete): file deleted in HEAD and modified in origin/master. Version origin/master of file left in tree.''')
    assert get_new_command(command) == 'git rm -r file'

# Generated at 2022-06-22 02:00:44.382872
# Unit test for function match
def test_match():
    assert match(Command('git rm app/models/user.rb',
                         "fatal: not removing 'app/models/user.rb'"
                         " recursively without -r", True))
    assert match(Command('git rm app/models/user.rb',
                         "fatal: not removing 'app/models/user.rb'"
                         " recursively without -r", True))
    assert not match(Command('git rm app/models/user.rb', '', False))


# Generated at 2022-06-22 02:00:50.755459
# Unit test for function match
def test_match():
	assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
	assert not match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively with -r'))
	assert not match(Command('rm file.txt', 'fatal: not removing \'file.txt\' recursively with -r'))
	assert not match(Command('git add file.txt', 'fatal: not removing \'file.txt\' recursively with -r'))
	assert not match(Command('rm file.txt', ''))


# Generated at 2022-06-22 02:00:55.492436
# Unit test for function get_new_command
def test_get_new_command():
    command_parts = ['git', 'rm', '--cached', '-r', '*', '--', 'tests/*']
    command = Command('git rm --cached -r * -- tests/*', '', command_parts)
    assert(get_new_command(command) == 'git rm --cached -r * -r -- tests/*')

# Generated at 2022-06-22 02:00:59.104449
# Unit test for function match
def test_match():
    assert match(Command('git rm -r file',
             'error: pathspec \'file\' did not match any file(s) known to git\n'
             'fatal: not removing \'file\' recursively without -r\n',
             False))



# Generated at 2022-06-22 02:01:04.742367
# Unit test for function match
def test_match():
    assert match(Command('git rm file1 file2 file3', '', 'fatal: not removing '
                          '"file1" recursively without -r'))
    assert not match(Command('git rm file1 file2 file3'))
    assert not match(Command('ls file1 file2 file3', '', 'fatal: not removing '
                             '"file1" recursively without -r'))


# Generated at 2022-06-22 02:01:06.913559
# Unit test for function match
def test_match():
    assert match(Command('rm foo', 'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('rm foo', ''))


# Generated at 2022-06-22 02:01:30.103812
# Unit test for function get_new_command
def test_get_new_command():
    command_input = Command('git rm -rf .', 'fatal: not removing \'.\' recursively without -r')
    assert get_new_command(command_input) == 'git rm -rf -r .'

    command_input = Command('git rm -rf .*', 'fatal: not removing \'.*\' recursively without -r')
    assert get_new_command(command_input) == 'git rm -rf -r .*'

# Generated at 2022-06-22 02:01:32.248388
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command
    assert get_new_command(Command('git rm file')) == 'git rm -r file'


# Generated at 2022-06-22 02:01:41.730783
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm_recursive_without_r import get_new_command
    assert get_new_command(Command(script='git rm foo',
                                   output='fatal: not removing \'foo\' recursively without -r\n')) == u'git rm -r foo'
    assert get_new_command(Command(script='rm foo',
                                   output='fatal: not removing \'foo\' recursively without -r\n')) == u'rm -r foo'
    assert get_new_command(Command(script='rm -r foo',
                                   output='fatal: not removing \'foo\' recursively without -r\n')) == u'rm -r foo'

# Generated at 2022-06-22 02:01:52.286889
# Unit test for function match
def test_match():
    assert match(Command('grep -r hello',
                         '')) is None
    assert match(Command('git rm fileA fileB fileC',
                         'fatal: not removing \'fileB\' recursively without -r\n'))
    assert match(Command('git rm -r fileA fileB fileC',
                         'fatal: not removing \'fileB\' recursively without -r\n')) is None
    assert match(Command('git rm fileA fileB fileC',
                         'fatal: not removing \'fileB\'\n')) is None
    assert match(Command('git rm fileA fileB fileC',
                         'fatal: not removing \'fileB\' recursively without -r')) is None

# Generated at 2022-06-22 02:01:54.518686
# Unit test for function match
def test_match():
    assert match(Command('git rm .idea', output="fatal: not removing '<path>/.idea' recursively without -r"))

# Generated at 2022-06-22 02:01:59.319894
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git rm -rf abc', '', 'fatal: not removing \'abc\' recursively without -r')) == 'git rm -rf abc'


# Generated at 2022-06-22 02:02:03.353034
# Unit test for function match
def test_match():
    assert match(Command("git branch -D branch1 branch2 branch3 branch4", "error: branch 'branch4' not found."))
    assert not match(Command("git branch -D branch1 branch2 branch3 branch4", ""))

# Generated at 2022-06-22 02:02:06.196804
# Unit test for function match
def test_match():
    assert match(Command('rm -r a',
                         'fatal: not removing \'a\' recursively without -r'))
    assert not match(Command('rm -r a', ''))


# Generated at 2022-06-22 02:02:09.451201
# Unit test for function match
def test_match():
	assert match(Command('git rm dir/subdir/subsubdir1/subsubsubdir',
	     'fatal: not removing \'dir/subdir/subsubdir1/subsubsubdir\' recursively without -r',
	     ''))
	assert not match(Command('git rm dir/subdir/subsubdir1/subsubsubdir', '', ''))


# Generated at 2022-06-22 02:02:14.766855
# Unit test for function match
def test_match():
    assert match(Command('rm -rf remote', 'fatal: not removing \'remote\' recursively without -r'))
    assert not match(Command('', ''))
    assert not match(Command('rm -rf remote', ''))
    assert not match(Command('rm -rf remote', 'fatal: not removing \'remote\' recursively without -rs'))


# Generated at 2022-06-22 02:02:35.797508
# Unit test for function match
def test_match():
    output = "fatal: not removing 'lib/implementation.py' recursively without -r"
    assert match(Command(script='git rm lib/implementation.py', output=output))
    assert not match(Command(script='git rm lib/implementation.py', output='hey'))


# Generated at 2022-06-22 02:02:42.056762
# Unit test for function match
def test_match():
    assert match(Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r'))
    assert match(Command('git rm a b', 'fatal: not removing \'b\' recursively without -r'))
    assert not match(Command('git rm a b', 'fatal: not removing b recursively without -r'))
    assert not match(Command('git rm a b', 'fatal: not removing \'b\' recursively without -r\n'))
    assert not match(Command('git rm a b'))

# Generated at 2022-06-22 02:02:48.471985
# Unit test for function match
def test_match():
    assert match(Command('git rm fdg', 'fatal: not removing \'fdg\' recursively without -r\n'))
    assert not match(Command('git rm fdg', 'fatal: not removing \'fdg\' recursively with -r\n'))
    assert not match(Command('git rm fdg', 'fatal: not removing \'fdg\' recursively\n'))
    assert not match(Command('rm', 'fatal: not removing \'fdg\' recursively without -r\n'))


# Generated at 2022-06-22 02:02:50.118011
# Unit test for function get_new_command
def test_get_new_command():
    assert u'git rm -r test' == get_new_command(
        Command('git rm test', 'fatal: not removing \'test\' recursively without -r'))

# Generated at 2022-06-22 02:02:52.595461
# Unit test for function match
def test_match():
    assert (match(Command('git branch rm -- test', '')) != None)
    assert (match(Command('git rm -- test', '')) == None)


# Generated at 2022-06-22 02:03:04.066589
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import shell
    """
        git rm -r dir
        fatal: not removing 'dir' recursively without -r
    """
    command = shell.and_("git rm -r dir",
    					 "fatal: not removing 'dir' recursively without -r")
    assert get_new_command(command) == 'git rm -r -r dir'

    """
        git rm -r dir1 dir2
        fatal: not removing 'dir1' recursively without -r
    """
    command = shell.and_(
        "git rm -r dir1 dir2",
        "fatal: not removing 'dir1' recursively without -r")
    assert get_new_command(command) == 'git rm -r -r dir1 dir2'

# Generated at 2022-06-22 02:03:05.754412
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm foo/')) == 'git rm -r foo/'


# Generated at 2022-06-22 02:03:14.156707
# Unit test for function match
def test_match():
    assert match(Command('rm -rf git.txt', 
        "fatal: not removing 'git.txt' recursively without -r"))
    assert not match(Command('git rm git.txt', 
        "fatal: not removing 'git.txt' recursively without -r"))
    assert not match(Command('rm /etc/hosts', 'rm: remove regular empty file \'/etc/hosts\'? y'))
    assert not match(Command('rm /etc/hosts', 'rm: cannot remove \'/etc/hosts\': No such file or directory'))

# Generated at 2022-06-22 02:03:16.815738
# Unit test for function match
def test_match():
    assert match(Command('git rm y'))
    assert match(Command('git rm y', 'fatal: not removing \'y\' recursively without -r\n'))
    assert not match(Command('git rm y -r'))


# Generated at 2022-06-22 02:03:19.939738
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r')) == u'git rm -r file.txt'

# Generated at 2022-06-22 02:03:45.465986
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', 'fatal: not removing \'file\' recursively without -r')) == 'git rm -r file'
    assert get_new_command(Command('git rm file1 file2 file3 file4', 'fatal: not removing \'file1\' recursively without -r\nfatal: not removing \'file1\' recursively without -r\nfatal: not removing \'file1\' recursively without -r\nfatal: not removing \'file1\' recursively without -r')) == 'git rm -r file1 file2 file3 file4'


# Generated at 2022-06-22 02:03:55.435288
# Unit test for function match
def test_match():
    print("\nRunning test for function match")

    command = Command("git rm CMakeLists.tx")
    command.output = "fatal: not removing 'CMakeLists.tx' recursively without -r"

    print("Checking match function works correctly")
    assert match(command) is True, "Command is not recognised correctly"

    command = Command("git rm -r CMakeLists.tx")
    command.output = "fatal: not removing 'CMakeLists.tx' recursively without -r"

    print("Checking match function works correctly (rejects when command is already correct)")
    assert match(command) is False, "Command is not recognised correctly"



# Generated at 2022-06-22 02:04:00.331827
# Unit test for function match
def test_match():
    assert match(Command('git rm dir1/dir2/file',
                         'fatal: not removing \'dir1/dir2/file\' recursively without -r\n'))
    assert not match(Command('git rm file',
                             'fatal: not removing \'dir1/dir2/file\' recursively without -r\n'))


# Generated at 2022-06-22 02:04:05.201897
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         'fatal: not removing \'bar\' recursively without -r',
                         '', 1))
    assert not match(Command('git rm foo', '', '', 1))

# Generated at 2022-06-22 02:04:11.428428
# Unit test for function match
def test_match():
    assert match(
       Command('git checkout branch', 'error: pathspec ... did not match any file(s) known to git.\n'))
    assert match(
       Command('git rm file', 'fatal: not removing \'file\' recursively without -r\n'))
    assert not match(
       Command('git checkout branch', 'error: pathspec ... did not match any file(s) known to git.\n'))


# Generated at 2022-06-22 02:04:14.481537
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(script='git rm -rf filename',
                                    output='fatal: not removing \'filename\' recursively without -r'))=='git rm -r -rf filename')

# Generated at 2022-06-22 02:04:16.805077
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r *')) == 'git rm -r -r *'

# Generated at 2022-06-22 02:04:19.097949
# Unit test for function match
def test_match():
	command = Command('git rm -rf --cached --ignore-unmatch package-lock.json')
	print(match(command))

# Generated at 2022-06-22 02:04:27.212459
# Unit test for function match
def test_match():
    test_cases = [
        ('ls', False),
        ('rm foo.txt', False),
        ('git rm folder/filename.txt', False),  # No error
        ('git rm -r folder/filename.txt', False),  # No error
        ('git rm folder/filename.txt', True),
        ('git rm -r folder/filename.txt', False),  # No error
        ('git rm folder/filename.txt', True)
        ]

    results = [match(Command(cmd)) for cmd, _ in test_cases]
    assert results == [x[1] for x in test_cases]


# Generated at 2022-06-22 02:04:32.571178
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
              'fatal: not removing \'foo\' recursively without -r',
              'bar'))
    assert not match(Command('git foo', '', ''))
    assert not match(Command('git rm foo', 'fatal: not removing foo', 'bar'))
    assert not match(Command('git rm foo bar', '', ''))


# Generated at 2022-06-22 02:04:56.379765
# Unit test for function match
def test_match():
    assert(match(Command('git add docs/file.txt')) == False)
    assert(match(Command('git rm lib/file.txt')) == False)
    assert(match(Command('git rm -r lib/file.txt')) == False)
    assert(match(Command('git rm file.txt')) == True)
    assert(match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r\n')) == True)

    

# Generated at 2022-06-22 02:05:02.068806
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_rm import get_new_command
    assert get_new_command(u'git rm -rf ./sample_data/sub-directory/') == u'git rm -rf -r ./sample_data/sub-directory/'
    assert get_new_command(u'git rm -r ./sample_data/sub-directory/') == u'git rm -r -r ./sample_data/sub-directory/'
    assert get_new_command(u'git rm -rf ./sample_data/sub-directory/ -rf ./sample_data/sub-directory-2/') == u'git rm -rf -r ./sample_data/sub-directory/ -rf ./sample_data/sub-directory-2/'

# Generated at 2022-06-22 02:05:10.636107
# Unit test for function match
def test_match():
    command_output_error = '''fatal: not removing 'mydirectory/' recursively without -r
    Did you mean this?
        git rm -r --cached mydirectory
    '''
    assert match(Command('git rm mydirectory', command_output_error, ''))
    assert match(Command('git rm mydirectory', 'fatal: not removing and something else', '')) is False
    assert match(Command('git rm mydirectory', 'fatal: not removing', '')) is False
    assert match(Command('git rm', '', '')) is False
