

# Generated at 2022-06-22 01:55:11.909184
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm folder')
    assert get_new_command(command) == 'git rm -r folder'

# Generated at 2022-06-22 01:55:16.861054
# Unit test for function match
def test_match():
   """
   When command error is "fatal: not removing 'dir/' recursively without -r",
   function match returns True.
   """
   command = Command('git rm dir/',
            """fatal: not removing 'dir/' recursively without -r""")
   assert match(command) == True


# Generated at 2022-06-22 01:55:21.165781
# Unit test for function match
def test_match():
    assert git_support(match)(Command(script='git rm file',
                                      output="fatal: not removing 'file' recursively without -r"))
    assert not git_support(match)(Command(script='git rm -r file',
                                      output="rm file"))

test_match()


# Generated at 2022-06-22 01:55:23.627780
# Unit test for function match
def test_match():
    assert match(Command('rm file',
                         stderr="fatal: not removing 'file' recursively without -r",
                         ))
    assert not match(Command('git checkout master',''))


# Generated at 2022-06-22 01:55:25.740186
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm test', '', 'fatal: not removing \'test\' recursively without -r')) == 'git rm -r test'



# Generated at 2022-06-22 01:55:29.140130
# Unit test for function match
def test_match():
    assert match(Command('rm -rf submodule',
                         'fatal: not removing \'submodule\' recursively without -r\n',
                         None))


# Generated at 2022-06-22 01:55:31.927358
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm {file} 2>&1',
                           'fatal: not removing \'{file}\' recursively without -r') == u'git rm -r {file} 2>&1'

# Generated at 2022-06-22 01:55:34.714005
# Unit test for function match
def test_match():
    assert match(Command(script='git rm',
                         output="fatal: not removing 'file.ext' recursively without -r"))
    assert not match(Command(script='git rm file.ext',
                             output="test test"))


# Generated at 2022-06-22 01:55:37.452882
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command(Command('git rm test.txt', u'fatal: not removing \'test.txt\' recursively without -r\ntest.txt\n', None)))

# Generated at 2022-06-22 01:55:42.862374
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm new/test.txt',
                      stderr="fatal: not removing 'new/test.txt' recursively without -r",
                      env={},
                      stdout=None)
    assert get_new_command(command).script == "git rm -r new/test.txt"

# Generated at 2022-06-22 01:55:47.185758
# Unit test for function match
def test_match():
    assert match(Command("git rm stupid_word",
        "fatal: not removing 'stupid_word' recursively without -r",
        ""))


# Generated at 2022-06-22 01:55:49.147171
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm file/', '')
    new_command = get_new_command(command)
    assert new_command == 'git rm -r file/'

# Generated at 2022-06-22 01:55:53.545848
# Unit test for function match
def test_match():
    assert match(Command("git remote show origin", "fatal: not removing 'test' recursively without -r", ""))
    assert not match(Command("git remote show origin", "fatal: 'new test' is not a valid remote name", ""))


# Generated at 2022-06-22 01:55:58.780879
# Unit test for function match
def test_match():
    assert match(Command(script='git rm git.py',
                         stderr="fatal: not removing 'git.py' recursively without -r"))
    assert not match(Command(script='git rm git.py',
                             stderr='fatal: not removing anything'))

# Generated at 2022-06-22 01:56:07.187759
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf .', '')) == 'git rm -rf -r .'
    assert get_new_command(Command('git rm -rf folder/', '')) == 'git rm -rf -r folder/'
    assert get_new_command(Command('git rm -rf /home/', '')) == 'git rm -rf -r /home/'
    assert get_new_command(Command('git rm -rf "folder with spaces"', '')) == 'git rm -rf -r "folder with spaces"'
    assert get_new_command(Command('git rm -rf folder folder2', '')) == 'git rm -rf -r folder folder2'
    assert get_new_command(Command('git rm -rf file.txt', '')) == 'git rm -rf -r file.txt'
    assert get_

# Generated at 2022-06-22 01:56:10.209527
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm -r', output='fatal: not removing \'my_folder\' recursively without -r')) == 'git rm -r -r'

# Generated at 2022-06-22 01:56:13.101715
# Unit test for function match
def test_match():
	# Test LineCorrector rme w/o '-r'
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\', recursively without -r'))


# Generated at 2022-06-22 01:56:16.287129
# Unit test for function match
def test_match():
    assert (match(Command(script='git rm file', stderr='fatal: not removing \'file\' recursively without -r\n')))


# Generated at 2022-06-22 01:56:22.514735
# Unit test for function match
def test_match():
    assert match(Command('git rm -rfv ./foo/.', 'fatal: not removing \'foo/subdir\''))
    assert match(Command('git rm -rfv ./foo/.', 'fatal: not removing \'subdir\''))
    assert not match(Command('git rm -rfv ./foo/.', 'Already up-to-date.'))
    assert not match(Command('git rm -rfv ./foo/.', ''))


# Generated at 2022-06-22 01:56:25.717131
# Unit test for function match
def test_match():
    assert match(Command('rm a',
                        'fatal: not removing \'a\' recursively without -r\n',
                        ''))

    assert not match(Command('rm a', 'my error', ''))

# Generated at 2022-06-22 01:56:33.325122
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('git rm dir_with_files', "fatal: not removing 'dir_with_files' recursively without -r")) == \
    u'git rm -r dir_with_files')



# Generated at 2022-06-22 01:56:40.666798
# Unit test for function match
def test_match():
    assert match(Command('git rm', '', 'fatal: not removing \'README\' recursively without -r'))
    assert match(Command('git rm -f', '', 'fatal: not removing \'README\' recursively without -r'))
    assert match(Command('git rm README', '', 'fatal: not removing \'README\' recursively without -r'))
    assert not match(Command('git rm', '', ''))
    assert not match(Command('git rm --cached', '', ''))


# Generated at 2022-06-22 01:56:42.963080
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -rf /')
    assert 'git rm -rf -r /' == get_new_command(command)

# Generated at 2022-06-22 01:56:45.375042
# Unit test for function match
def test_match():
    assert match(Command('git rm lol.txt', 'fatal: not removing \'lol.txt\' recursively without -r'))


# Generated at 2022-06-22 01:56:52.290784
# Unit test for function get_new_command
def test_get_new_command():
    matching_command = Command('git rm abc')
    assert get_new_command(matching_command) == 'git rm -r abc'

    non_matching_command = Command('git rm abcdef')
    assert get_new_command(non_matching_command) == 'git rm -r abcdef'

    command = Command('git rm abc', 'fatal: not removing \'abc\' recursively without -r')
    assert get_new_command(command) == 'git rm -r abc'

# Generated at 2022-06-22 01:56:56.704556
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert not match(Command('git rm -rf file.txt', "fatal: pathspec 'file.txt' did not match any files"))



# Generated at 2022-06-22 01:57:07.257994
# Unit test for function match
def test_match():
    assert(match(Command('git rm README.md',
                     'fatal: not removing \'README.md\' recursively without -r'))
           == True)
    assert(match(Command('git rm README.md',
                     'fatal: not removing \'README.md\' recursively without -r',
                     None, '/home/ubuntu/fuckyou', 'git rm README.md'))
           == True)
    assert(match(Command('git rm README.md',
                     'fatal: not removing \'README.md\' recursively without -q',
                     None, '/home/ubuntu/fuckyou', 'git rm README.md'))
           == False)

# Generated at 2022-06-22 01:57:11.584807
# Unit test for function match
def test_match():
    stderr = ("fatal: not removing 'Gemfile.lock' recursively without -r\n",)
    script = ("git rm Gemfile.lock",)
    command = Command(script,stderr)
    assert match(command)


# Generated at 2022-06-22 01:57:16.114618
# Unit test for function get_new_command
def test_get_new_command():
    # this test is for the case where the file we are supposed to remove is a folder
    command = Command("git rm -f somethingsomething", "fatal: not removing 'somethingsomething' recursively without -r")
    assert get_new_command(command) == "git rm -rf somethingsomething"

# Generated at 2022-06-22 01:57:23.339356
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    # git rm -rf
    command = Command('git rm -rf a b c', '')
    assert get_new_command(command) == 'git rm -rf a b c'

    # git rm -rf --cached
    command = Command('git rm -rf --cached a b c', '')
    assert get_new_command(command) == 'git rm -rf -r --cached a b c'

    # Zsh: git rm -rf
    command = Command('git rm -rf a b c', '', 'zsh')
    assert get_new_command(command) == 'git rm -rf a b c'

    # git rm --cached
    command = Command('git rm --cached a b c', '')
    assert not match(command)

    # git rm --cached


# Generated at 2022-06-22 01:57:32.065121
# Unit test for function match
def test_match():
    assert match(Command('git rm test', 'fatal: not removing \'test\' recursively without -r'))
    assert not match(Command('git rm test', 'fatal: not removing \'test\''))
    assert not match(Command('git rm test', 'fatal: not removing \'test\' recursively without -r', '', 3))


# Generated at 2022-06-22 01:57:35.890213
# Unit test for function get_new_command
def test_get_new_command():
    r = get_new_command(Command('rm -rf'))
    assert r == 'git rm -rf'

    r = get_new_command(Command('git rm -rf'))
    assert r == 'git rm -rf'

# Generated at 2022-06-22 01:57:45.071267
# Unit test for function get_new_command
def test_get_new_command():
    command_1 = Command('git rm /tmp/test',
                        'fatal: not removing \'/tmp/test\' recursively without -r', 1)
    command_2 = Command('git rm --cached /tmp/test',
                        'fatal: not removing \'--cached\'/tmp/test\' recursively without -r', 1)
    command_3 = Command('git rm --cached .',
                        'fatal: not removing \'--cached\'/.\' recursively without -r', 1)

    assert get_new_command(command_1) == 'git rm -r /tmp/test'
    assert get_new_command(command_2) == 'git rm -r --cached /tmp/test'
    assert get_new_command(command_3) == 'git rm -r --cached .'

#

# Generated at 2022-06-22 01:57:50.749232
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf *',
                         'fatal: not removing \'.gitignore\' recursively without -r'))
    assert not match(Command('git rm *',
                             'fatal: not removing \'.gitignore\' recursively without -r'))


# Generated at 2022-06-22 01:57:54.184110
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r -f aa', 'fatal: not removing \'aa\' recursively without -r\n')) == u'git rm -r -f -r aa'


# Generated at 2022-06-22 01:57:57.164231
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm some_directory',
                      'fatal: not removing \'some_directory\' recursively without -r')
    assert get_new_command(command) == 'git rm -r some_directory'


# Generated at 2022-06-22 01:57:58.897094
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    assert get_new_command(Command('git rm A/a')) == 'git rm -r A/a'

# Generated at 2022-06-22 01:58:02.936123
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(u'git rm -r test', u"fatal: not removing 'test' recursively without -r")
    new_cmd = get_new_command(command)
    assert u'git rm -r -r test' == new_cmd

# Generated at 2022-06-22 01:58:05.693600
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm some.file') == 'git rm -r some.file'

# Generated at 2022-06-22 01:58:09.035431
# Unit test for function get_new_command
def test_get_new_command():
    assert_equal(get_new_command(
        'git rm file1 file2 file3',
        'fatal: not removing \'file1\' recursively without -r'),
                 'git rm -r file1 file2 file3')

# Generated at 2022-06-22 01:58:16.745289
# Unit test for function match
def test_match():
    assert match(Command('git rm is_number.py', 'fatal: not removing \'is_number.py\' recursively without -r\n'))
    assert not match(Command('git rm -r is_number.py', ''))

# Generated at 2022-06-22 01:58:21.434736
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm **/*.pyc',
                                   'fatal: not removing \'some_path/some_file\' recursively without -r')) \
    == 'git rm -r **/*.pyc'

# Generated at 2022-06-22 01:58:32.264668
# Unit test for function match
def test_match():
	assert match(Command('git rm -rf', 'fatal: not removing \'mybranch\' recursively without -r'))
	assert not match(Command('git rm -rf', 'fatal: not removing \'mybranch\''))
	assert not match(Command('git rm -rf', 'fatal: not removing \'mybranch\' recursively with -r'))
	assert not match(Command('git rm -rf', 'fatal: not removing \'mybranch\' without -r'))
	assert not match(Command('git rm -rf', 'fatal: not removing \'mybranch\''))
	assert not match(Command('ls', 'fatal: not removing \'mybranch\' recursively without -r'))


# Generated at 2022-06-22 01:58:35.743855
# Unit test for function match
def test_match():
    assert match(Command('git rm test/file.py', output=fatal_not_removing)) is True
    assert match(Command('git rm -r test/dir', output=fatal_not_removing)) is False


# Generated at 2022-06-22 01:58:38.412430
# Unit test for function match
def test_match():
    assert match(Command('rm -rf /',
                         'fatal: not removing \'/\''
                         ' recursively without -r'))


# Generated at 2022-06-22 01:58:40.296090
# Unit test for function get_new_command
def test_get_new_command():
    command_output = u'fatal: not removing \'test/test_git.py\' recursively without -r'
    args = Command('rm test/test_git.py', command_output)
    assert get_new_command(args) == 'git rm -r test/test_git.py'

# Generated at 2022-06-22 01:58:44.465234
# Unit test for function match
def test_match():
    assert match(Script(script="rm file", output="fatal: not removing 'file' recursively without -r"))
    assert not match(Script(script="ls", output="fatal: not removing 'file' recursively without -r"))


# Generated at 2022-06-22 01:58:48.859314
# Unit test for function get_new_command
def test_get_new_command():
    command_output = Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r')
    assert get_new_command(command_output) == 'git rm -r test.txt'


enabled_by_default = True

# Generated at 2022-06-22 01:58:51.253026
# Unit test for function match
def test_match():
    assert match(Command('git rm txt',
            output = 'fatal: not removing \'txt\' recursively without -r\n'))
    


# Generated at 2022-06-22 01:58:54.894854
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command(script='git rm foo/bar', output='fatal: not removing \'foo/bar\' recursively without -r'))
    assert u'git rm -r foo/bar' == new_command

# Generated at 2022-06-22 01:59:08.649996
# Unit test for function match
def test_match():
    assert match(Command('git rm -rf tests',
                         'fatal: not removing \'tests\' recursively without -r', ''))
    assert match(Command('git rm -rf tests',
                         'fatal: not removing \'tests\' recursively without -r', '')) is True
    assert match(Command('git rm -rf tests',
                         'error: could not delete \'tests\'', '')) is False


# Generated at 2022-06-22 01:59:11.720388
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    command = Command('$ git rm -rf --cached substack')
    assert get_new_command(command) == 'git rm -r -rf --cached substack'

# Generated at 2022-06-22 01:59:15.072477
# Unit test for function match

# Generated at 2022-06-22 01:59:16.934645
# Unit test for function get_new_command

# Generated at 2022-06-22 01:59:19.141237
# Unit test for function match
def test_match():
    assert match(Command('git rm file',stderr='fatal: not removing \'file\' recursively without -r\n'))


# Generated at 2022-06-22 01:59:22.602798
# Unit test for function match

# Generated at 2022-06-22 01:59:30.506383
# Unit test for function match
def test_match():
    assert match(Command('git rm -r',
                         "fatal: not removing 'a.txt' recursively without -r\n",
                         ''))
    assert not match(Command('git rm -r',
                             'rm \'file.txt\'',
                             ''))
    assert not match(Command('git rm',
                             'rm \'file.txt\'',
                             ''))
    assert not match(Command('git rm',
                             "fatal: not removing 'a.txt' recursively without -r\n",
                             ''))


# Generated at 2022-06-22 01:59:36.198721
# Unit test for function match
def test_match():
    assert match(Command('git rm aaa',
                         'fatal: not removing \'aaa/\' recursively without -r'))
    assert not match(Command('git rm aaa', ''))
    assert not match(Command('git rm aaa', 'fatal: not removing \'aaa/\' recursively without -r',
                             stderr='fatal: not removing \'aaa/\' recursively without -r'))


# Generated at 2022-06-22 01:59:41.628621
# Unit test for function get_new_command
def test_get_new_command():
    cmnd = Command("git rm -rf folder/*")
    assert get_new_command(cmnd) == "git rm -rf -r folder/*"
    cmnd = Command("git rm folder/*")
    assert get_new_command(cmnd) == "git rm -r folder/*"

# Generated at 2022-06-22 01:59:45.237083
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm path/to/file',
                      """\
error: pathspec 'path/to/file' did not match any file(s) known to git.""")
    assert get_new_command(command) == 'git rm -r path/to/file'

# Generated at 2022-06-22 01:59:55.210319
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -rf a/b/c', '', '')) == 'git rm -rf -r a/b/c'

# Generated at 2022-06-22 01:59:58.114776
# Unit test for function match
def test_match():
    # test for true
    assert match(Test(script='git rm -f .DS_Store'))
    # test for false
    assert not match(Test(script='git rm'))



# Generated at 2022-06-22 01:59:59.655486
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('rm foo', 'fatal: not removing \'foo\' recursively without -r')) == 'git rm -r foo')

# Generated at 2022-06-22 02:00:07.118338
# Unit test for function get_new_command
def test_get_new_command():
    git_rm_command1 = Command("git rm -r dir2", "fatal: not removing 'dir2' recursively without -r")
    git_rm_command2 = Command("git rm path/to/dir", "fatal: not removing 'path/to/dir' recursively without -r")
    assert get_new_command(git_rm_command1) == "git rm -r -r dir2"
    assert get_new_command(git_rm_command2) == "git rm -r path/to/dir"

# Generated at 2022-06-22 02:00:17.937847
# Unit test for function match
def test_match():
    command = Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r')
    assert not match(command)

    command = Command('git rm dir', 'fatal: not removing \'dir\' recursively without -r\n', stderr=command.output)
    assert not match(command)

    command = Command('git rm -r dir', 'fatal: not removing \'dir\' recursively without -r')
    assert not match(command)

    command = Command('git rm -r dir', 'fatal: not removing \'dir\' recursively without -r\n', stderr=command.output)
    assert not match(command)

    command = Command('git rm badbranch')
    assert not match(command)


# Generated at 2022-06-22 02:00:22.547189
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm ")) == "git rm -r "
    assert get_new_command(Command("git rm test")) == "git rm -r test"
    assert get_new_command(Command("git rm -r test")) == "git rm -r -r test"

# Generated at 2022-06-22 02:00:27.492477
# Unit test for function match
def test_match():
    assert match(Command('git rm a', output='fatal: not removing \'a\' recursively without -r'))
    assert not match(Command('git rm -r a', output='fatal: not removing \'a\' recursively without -r'))
    assert not match(Command('git status', output='fatal: not removing \'a\' recursively without -r'))

# Generated at 2022-06-22 02:00:37.416161
# Unit test for function match
def test_match():
    assert match(Command('git rm dir',
                         'fatal: not removing \'dir/dir\' recursively without -r\n'))
    assert match(Command('git rm dir/',
                         'fatal: not removing \'dir/dir\' recursively without -r\n'))
    assert match(Command('git rm \'dir/\' ',
                         'fatal: not removing \'dir/dir\' recursively without -r\n'))
    assert match(Command('git rm \'dir/\'',
                         'fatal: not removing \'dir/dir\' recursively without -r\n'))
    assert match(Command('git rm \'dir/\'',
                         'fatal: not removing \'dir/dir\' recursively without -r\n'))

# Generated at 2022-06-22 02:00:41.056153
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm -r file_name.txt', 'git rm -r file_name.txt\nfatal: not removing \'file_name.txt\' recursively without -r\n', None)) == 'git rm -r -r file_name.txt'

# Generated at 2022-06-22 02:00:49.030296
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(_Command(script='git rm -r', output="fatal: not removing 'graphical-interface/' recursively without -r")) == 'git rm -r -r'
    assert get_new_command(_Command(script='git rm', output="fatal: not removing 'graphical-interface/' recursively without -r")) == 'git rm -r'
    assert get_new_command(_Command(script='git add', output="fatal: not removing 'graphical-interface/' recursively without -r")) is None



# Generated at 2022-06-22 02:01:08.108920
# Unit test for function get_new_command
def test_get_new_command():
    command_string = 'git rm file'
    command = Command(command_string, 'fatal: not removing \'file\' recursively without -r')
    assert get_new_command(command).startswith('git rm -r')


# Generated at 2022-06-22 02:01:14.612142
# Unit test for function match
def test_match():
    # git rm -rf * --> git rm -rf *; rm -rf *
    assert match(Command('git rm -rf *', '', 'fatal: not removing '
                                         '\'.gitignore\' recursively without -r\n'))
    # git rm -rf *.txt --> git rm -rf *.txt; rm -rf *.txt
    assert match(Command('git rm -rf *.txt', '', 'fatal: not removing '
                                              '\'.travis.yml\' recursively without -r\n'))
    assert not match(Command('git rm -rf *.txt', '', 'fatal: not removing '
                                              '\'.travis.yml\' recursively without -r\n'))
    assert not match(Command('git rm -rf *', ''))

# Generated at 2022-06-22 02:01:17.594463
# Unit test for function match
def test_match():
    assert match(Command('git rm -r directory',
        stderr='fatal: not removing \'directory\' recursively without -r'))
    assert not match(Command('git rm -r directory',
                         stderr=''))

# Generated at 2022-06-22 02:01:22.465893
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
                         'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('rm foo'))
    assert not match(Command('git rm foo'))
    assert not match(Command('git rm -r foo'))


# Generated at 2022-06-22 02:01:23.352579
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('rm -rf .git')) ==\
    u'git rm -rf .git'

# Generated at 2022-06-22 02:01:26.001418
# Unit test for function match
def test_match():
    assert match(Command('git rm foo', 'fatal: not removing \'foo\' recursively without -r'))
    assert not match(Command('git rm foo', ''))

# Generated at 2022-06-22 02:01:30.354163
# Unit test for function match
def test_match():
    from thefuck.specific.git import rm_error
    command = Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r')
    assert rm_error.match(command)


# Generated at 2022-06-22 02:01:32.132848
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm list.txt") == "git rm -r list.txt"

# Generated at 2022-06-22 02:01:35.628356
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git rm -f file', ["fatal: not removing 'file' recursively without -r",])
    result = get_new_command(command)
    assert result == 'git rm -f -r file'

# Generated at 2022-06-22 02:01:45.014872
# Unit test for function match
def test_match():
    assert match(Command('git rm non_existent_dir '
                         "fatal: not removing 'non_existent_dir/' "
                         "recursively without -r", None))
    assert not match(Command('git rm non_existent_dir/ '
                             "fatal: not removing 'non_existent_dir' "
                             "recursively without -r", None))
    assert not match(Command('git rm -r non_existent_dir/ '
                             "fatal: not removing 'non_existent_dir' "
                             "recursively without -r", None))
    assert not match(Command('rm non_existent_file '
                             'No such file or directory', None))


# Generated at 2022-06-22 02:02:03.782779
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command
    command = Command('git rm README')
    assert get_new_command(command) == 'git rm -r README'

# Generated at 2022-06-22 02:02:06.537290
# Unit test for function match
def test_match():
    assert match(Command(script='git rm file.py',
         stderr=("fatal: not removing 'file.py' recursively without -r\n"),
         ))


# Generated at 2022-06-22 02:02:09.367266
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git rm -r foo' == get_new_command('git rm foo')

# Generated at 2022-06-22 02:02:14.692278
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,),
                  {'script': u'git rm -r --cached filename',
                   'script_parts': [u'git', u'rm', u'-r', u'--cached', u'filename']
                  })
    assert get_new_command(command) == u'git rm -r --cached -r filename'



# Generated at 2022-06-22 02:02:15.178692
# Unit test for function match
def test_match():
    ass

# Generated at 2022-06-22 02:02:20.920044
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git rm -r', output='fatal: not removing \'basename\' recursively without -r')) == 'git rm -r -r'
    assert get_new_command(Command(script='git rm test', output='fatal: not removing \'test\' recursively without -r')) == 'git rm -r test'

# Generated at 2022-06-22 02:02:24.381838
# Unit test for function match
def test_match():
    assert match(Command('git rm include/hedley.h', ''))
    assert not match(Command('git rm videos/*.ogg', ''))


# Generated at 2022-06-22 02:02:26.687767
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git rm my_directory", ("fatal: not removing 'my_directory' recursively without -r", ""))) == "git -r rm my_directory"

# Generated at 2022-06-22 02:02:29.397072
# Unit test for function get_new_command

# Generated at 2022-06-22 02:02:31.313976
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git rm -r test_file')) == 'git rm -r -r test_file'

# Generated at 2022-06-22 02:02:56.103207
# Unit test for function match
def test_match():
    assert match(Command('git remote add origin git@github.com:vladimyr/thefuck.git', 'fatal: not removing \'git@github.com:vladimyr/thefuck.git\' recursively without -r'))
    assert not match(Command('git branch asd', 'fatal: not removing \'asd\' recursively without -r'))
    assert not match(Command('git rm -r', ' fsdg'))
    assert not match(Command('git', ''))


# Generated at 2022-06-22 02:03:06.431771
# Unit test for function match
def test_match():
    assert git_support()
    assert match(command=Command('git rm /SomeDir',
                                 output='fatal: not removing \'/SomeDir\' recursively without -r\n'))
    assert not match(command=Command('git rm SomeDir', output='SomeDir\n'))
    assert not match(command=Command('git rm SomeDir'))
    assert not match(command=Command('git rm /SomeDir', output='Fatal: not removing \'/SomeDir\' recursively without -r\n'))
    assert not match(command=Command('rm /SomeDir',
                                     output='fatal: not removing \'/SomeDir\' recursively without -r\n'))

# Generated at 2022-06-22 02:03:16.945949
# Unit test for function match
def test_match():
    """Function match should return True if command contains ' rm ' and
    'fatal: not removing ' and ' recursively without -r' and False otherwise
    """

    # True
    assert match(Command('git rm file/path/filename'))
    assert match(Command('git rm -rf file/path/filename'))

    # False
    assert not match(Command('git rm -rf file/path/filename',
                             'fatal: not removing file/path/filename'))
    assert not match(Command('git rm -rf file/path/filename',
                             'fatal: not removing file/path/filename'
                             ' recursively without -rf'))

# Generated at 2022-06-22 02:03:19.682491
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt',
            'fatal: not removing \'file.txt\' recursively without -r'))


# Generated at 2022-06-22 02:03:22.613505
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git rm foo", "fatal: not removing 'foo' recursively without -r")
    assert(get_new_command(command)) == "git rm -r foo"

# Generated at 2022-06-22 02:03:24.321278
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm directory/file') == 'git rm -r directory/file'


# Generated at 2022-06-22 02:03:30.268715
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git rm src',
                      output="fatal: not removing 'src' recursively without -r")
    assert get_new_command(command) == 'git rm -r src'

    # Unit test for function get_new_command
    from tests.utils import Command

    command = Command(script='git rm src/',
                      output="fatal: not removing 'src/' recursively without -r")
    assert get_new_command(command) == 'git rm -r src/'

# Generated at 2022-06-22 02:03:33.933887
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm one.txt',
                                   '/home/joe/some_dir\n'
                                   'fatal: not removing \'one.txt\''
                                   ' recursively without -r\n')) == 'git rm -r one.txt'

# Generated at 2022-06-22 02:03:36.785268
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command

    command = Command('git rm test.txt', 'fatal: not removing \'test.txt\' recursively without -r\n')
    assert get_new_command(command) == 'git rm -r test.txt'

# Generated at 2022-06-22 02:03:45.018974
# Unit test for function match
def test_match():
    assert match(Command('git rm file.txt', 'fatal: not removing \'file.txt\' recursively without -r'))
    assert match(Command('git rm test/file.sh', 'fatal: not removing \'test/file.sh\' recursively without -r'))
    assert match(Command('git rm -f test/file.txt', 'fatal: not removing \'test/file.txt\' recursively without -r'))
    assert not match(Command('ls', ''))


# Generated at 2022-06-22 02:04:30.229803
# Unit test for function match
def test_match():
    # Test for user input is rm
    assert(match(Command('rm', '', '', '', '', '', '')) == False)
    # Test for output contains fatal, not removing and without -r
    assert(match(Command('git rm a.md', 'fatal: not removing "a.md" recursively without -r', '', '', '', '', '')) == True)
    # Test for output contains fatal, not removing but without -r
    assert(match(Command('git rm a.md', 'fatal: not removing "a.md" recursively with -r', '', '', '', '', '')) == False)
    # Test for output contains fatal, not removing and -r

# Generated at 2022-06-22 02:04:32.075869
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git rm -f a/b/c") == "git rm -rf a/b/c"

# Generated at 2022-06-22 02:04:33.458966
# Unit test for function match
def test_match():
    assert match(Command('git rm foo',
        ''))


# Generated at 2022-06-22 02:04:35.869728
# Unit test for function match
def test_match():
    assert match(Command('git branch testmaster'))
    assert not match(Command('cd zz'))


# Generated at 2022-06-22 02:04:38.060554
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git rm file', 'fatal: not removing \'file\' recursively without -r', '', 0, '')) == 'git rm -r file'

# Generated at 2022-06-22 02:04:39.368073
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git rm bugs') == 'git rm -r bugs'

# Generated at 2022-06-22 02:04:45.423004
# Unit test for function match
def test_match():
    assert(match(
        Command('rm foo', 'fatal: not removing \'foo\' recursively without -r'))
           is True)
    assert(match(
        Command('rm foo', 'fatal: not removing \'bar\' recursively without -r'))
           is False)
    assert(match(Command('rm foo', 'some error')) is False)


# Generated at 2022-06-22 02:04:55.368574
# Unit test for function get_new_command
def test_get_new_command():
    """ Unit test for function get_new_command """
    # Test for command: git rm <file_name>
    result = get_new_command(Command(script='git rm <file_name>',
                                    output='fatal: not removing '
                                           "'<file_name>'"
                                           ' recursively without -r'))
    assert result == 'git rm -r <file_name>'

    # Test for command: git rm -r <file_name>
    result = get_new_command(Command(script='git rm -r <file_name>',
                                    output='fatal: not removing '
                                           "'<file_name>'"
                                           ' recursively without -r'))
    assert result == 'git rm -r -r <file_name>'

# Generated at 2022-06-22 02:04:56.453082
# Unit test for function match
def test_match():
    assert match(Command('git rm -r'))



# Generated at 2022-06-22 02:05:00.674612
# Unit test for function match
def test_match():
    assert(match(Command(script='git rm', output='fatal: not removing '
                                                 "'.' recursively without -r")) == True)
    assert(match(Command(script='git rm', output='fatal: not removing '
                                                 "'.' recursively without '-r'")) == True)
    assert(match(Command(script='git rm -r', output='fatal: not removing '
                                                 "'.' recursively without -r")) == False)
