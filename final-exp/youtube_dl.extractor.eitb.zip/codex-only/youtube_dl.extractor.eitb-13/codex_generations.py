

# Generated at 2022-06-24 12:16:12.339336
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None).IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:16:15.258775
# Unit test for constructor of class EitbIE
def test_EitbIE():
    the_EitbIE = EitbIE();
    # at the moment no test is possible without creating a valid url.
    # this test is used to avoid 100% coverage failure.
    assert(the_EitbIE is not None)

# Generated at 2022-06-24 12:16:18.063619
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:27.743814
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    assert info_extractor.IE_NAME == "eitb.tv"
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:28.880901
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()
	assert len(eitb._VALID_URL) > 0

# Generated at 2022-06-24 12:16:31.931521
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:34.349033
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:16:37.857054
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert_equal(e.IE_NAME,'eitb.tv')
    assert_equal(e._VALID_URL, 
        r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:16:45.092416
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert EitbIE._TEST['info_dict']['id'] == '4090227752001'
    assert EitbIE._T

# Generated at 2022-06-24 12:16:45.820746
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE().suite()

# Generated at 2022-06-24 12:16:51.716393
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:55.220948
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_object = EitbIE('http://www.eitb.tv/eu/bideoa/')
    print(ie_object.extract('http://www.eitb.tv/eu/bideoa/')[0])

# Generated at 2022-06-24 12:17:03.879752
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple unit test for class EitbIE.
    """
    class_ = EitbIE
    ie = class_(class_._TEST['url'])
    assert ie.url == class_._TEST['url']
    assert ie.md5 == class_._TEST['md5']
    assert ie.info_dict == class_._TEST['info_dict']
    # TODO: add more unit tests
    ie = class_("http://www.eitb.tv/eu/bideoa/gaur-gauera/4105239119001/4105445969001/gaur-egun-349/")

# Generated at 2022-06-24 12:17:06.261292
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test: Test creation of a EitbIE object.
    """
    eitbie = EitbIE()
    assert(eitbie is not None)

# Generated at 2022-06-24 12:17:17.022771
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:17:30.732205
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:32.887704
# Unit test for constructor of class EitbIE
def test_EitbIE():
	u = EitbIE()
	print(u)


# Generated at 2022-06-24 12:17:34.803041
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("unit test for constructor of class EitbIE")

# Generated at 2022-06-24 12:17:43.811379
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.categories == []
    assert ie.ie_key() == 'Eitb'
    assert ie.ie_label() == 'Eitb'
    assert ie.video_id_regex() == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.thumbnail_url_regex() == None
    assert ie.embed

# Generated at 2022-06-24 12:17:53.379736
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitbie.IE_NAME == 'EitbIE'
    assert eitbie.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:17:55.662912
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:57.033335
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-24 12:17:57.942235
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE();

# Generated at 2022-06-24 12:18:12.410045
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video = EitbIE()
    if video.IE_NAME != "eitb.tv":
        return False
    classObj = EitbIE()
    if not classObj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)':
        return False

# Generated at 2022-06-24 12:18:14.424962
# Unit test for constructor of class EitbIE
def test_EitbIE():
    raise NotImplementedError("TODO")

# Generated at 2022-06-24 12:18:17.043345
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test that the constructor throws no exceptions
    EitbIE()

# Generated at 2022-06-24 12:18:18.848950
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:23.550241
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:18:28.207863
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    eitbie.extract()
    return

# Generated at 2022-06-24 12:18:39.742245
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    result = eitb._real_extract(url)
    assert result['id'] == '4090227752001'
    assert result['ext'] == 'mp4'
    assert result['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert result['description'] == 'Programa de reportajes de actualidad.'
    assert result['duration'] == 3996.76
    assert result['timestamp'] == 1381789200
    assert result['upload_date'] == '20131014'

# Generated at 2022-06-24 12:18:40.363852
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:48.167973
# Unit test for constructor of class EitbIE
def test_EitbIE():
	import unittest
	print("Testing constructor of class EitbIE")
	print("URL is http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
	results = {
		'id': '4090227752001',
		'ext': 'mp4',
		'title': '60 minutos (Lasa y Zabala, 30 años)',
		'description': 'Programa de reportajes de actualidad.',
		'duration': 3996.76,
		'timestamp': 1381789200,
		'upload_date': '20131014',
		'tags': list,
	}

# Generated at 2022-06-24 12:18:54.387113
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:18:56.266415
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert isinstance(IE, EitbIE)
    return IE


# Generated at 2022-06-24 12:19:04.771597
# Unit test for constructor of class EitbIE
def test_EitbIE():
    extractor = EitbIE()
    assert extractor.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL.__doc__ == 'http://www.eitb.tv/eu/bideoa/ or http://www.eitb.tv/es/video/'
    assert extractor._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert extractor._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:19:08.445035
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:10.673870
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        pass
    else:
        assert(False)

# Generated at 2022-06-24 12:19:17.418399
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("")
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:19:21.965186
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert a.IE_NAME == "Eitb"

# Generated at 2022-06-24 12:19:22.979793
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie != None

# Generated at 2022-06-24 12:19:31.420505
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(eitb_ie.name == 'eitb.tv');

# Generated at 2022-06-24 12:19:32.803003
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb

# Generated at 2022-06-24 12:19:39.138164
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:42.989665
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Creation of class.
    instance = EitbIE("test_constructor")
    # Assertion that the class has been created.
    assert instance.is_valid()



# Generated at 2022-06-24 12:19:47.169043
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE != None

# Generated at 2022-06-24 12:19:53.476750
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Call constructor of class EitbIE"""
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_NAME in ie.supported_ie
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._VALID_URL in ie.supported_ie
    assert len(ie._TEST) == len(ie.supported_ie)

# Generated at 2022-06-24 12:19:55.363300
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE == InfoExtractor.get_info_extractor('EitbIE')

# Generated at 2022-06-24 12:19:58.405181
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_obj = EitbIE()
    print("Calling constructor of class EitbIE")
    print("EitbIE object created\n")


# Generated at 2022-06-24 12:20:00.463670
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Testing constructor of class EitbIE
    instance = EitbIE()
    assert isinstance(instance, EitbIE)

# Generated at 2022-06-24 12:20:04.644121
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    eitbIE.get_info_from_url('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:20:09.758547
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)(?:/(?:.*?))?'
    assert type(eitb._TEST) == dict
    assert eitb._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:20:12.663271
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:20:13.294969
# Unit test for constructor of class EitbIE
def test_EitbIE():
	pass

# Generated at 2022-06-24 12:20:16.035919
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:21.171239
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"
    assert ie.IE_NAME == "eitb.tv"
    assert ie.__class__.__name__ == "EitbIE"


# Generated at 2022-06-24 12:20:28.230766
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Unitary test to check if class could be constructed
    ie = EitbIE()
    # print "type of ie is : %s" % type(ie)
    # print "dir of ie is : %s" % dir(ie)
    # print "ie is : %s" % ie
    # print "vars of ie is %s" % vars(ie)
    # print "ie.IE_NAME is : %s" % ie.IE_NAME
    # print "ie._VALID_URL is : %s" % ie._VALID_URL
    # print "ie._TEST is : %s" % ie._TEST


# Generated at 2022-06-24 12:20:41.141166
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:20:49.167632
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert ie.IE_NAME == "eitb.tv"

# Generated at 2022-06-24 12:20:52.932597
# Unit test for constructor of class EitbIE
def test_EitbIE():
    testEitbIE = EitbIE()
    assert testEitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:21:02.205138
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    "Unit test for constructor of class EitbIE"
    
    # Create a new instance of EitbIE
    eitb_ie = EitbIE("")
    
    # Check if name of the class is correct
    assert eitb_ie.IE_NAME == "eitb.tv"
    
    # Check if the _VALID_URL is correct
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    

# Generated at 2022-06-24 12:21:08.597243
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:21:10.895250
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:21:16.617658
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for the EitbIE class constructors.

    """
    EitbIE('eitb.tv', 'eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:21:21.713660
# Unit test for constructor of class EitbIE
def test_EitbIE():
    input_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    instance = EitbIE(None);
    match = instance._match_id(input_url)

# Generated at 2022-06-24 12:21:25.230936
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:21:30.338165
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert (EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
	assert (EitbIE().IE_NAME == 'eitb.tv')

# Generated at 2022-06-24 12:21:31.332031
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE()

# Generated at 2022-06-24 12:21:34.982108
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return InfoExtractor.test(EitbIE)

# Generated at 2022-06-24 12:21:43.807880
# Unit test for constructor of class EitbIE
def test_EitbIE():
    request = sanitized_Request('http://mam.eitb.eus/mam/REST/ServiceMultiweb/DomainRestrictedSecurity/TokenAuth/', headers={'Referer': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'})
    eitbIE = EitbIE()
    token_data = eitbIE._download_json(request, '4090227752001', 'Downloading auth token', fatal=False)
    token = token_data.get('token')
    assert token

# Generated at 2022-06-24 12:21:48.685939
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:49.805611
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()

# Generated at 2022-06-24 12:22:00.284950
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:22:04.961123
# Unit test for constructor of class EitbIE
def test_EitbIE():
    with open("eitb_video.json", "r") as read_file:
        json_data = read_file.read()
        #print(json_data)
        obj = EitbIE()

        video = obj._parse_json(json_data, "4090227752001", 'Downloading video JSON')

# Generated at 2022-06-24 12:22:11.314329
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Unit test for Video
    if EitbIE.suitable(''):
        print ('Suitable')
    else:
        print ('Not Suitable')

    # Unit test for get_id
    print ('ID: %s' % EitbIE._match_id(''))

    # Unit test for real_extract
    print ('Real extraction: %s' % EitbIE._real_extract(''))
    pass

# Generated at 2022-06-24 12:22:19.636546
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    RE = r'(?P<id>[\d]+)'
    url_m = re.match(RE, test_url)
    video_id = url_m.group('id')
    test_url_2 = 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % video_id
    response = urllib2.urlopen(test_url_2)
    json_data = json.load(response)

# Generated at 2022-06-24 12:22:23.731247
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-24 12:22:33.872068
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    video_id = '4104995148001'
    eitb_url = 'http://www.eitb.tv/eu/bideoa/zuzenduak/25-urte/60-minutos/espainiako-hiria'
    assert eitb._match_id(eitb_url) == video_id
    assert eitb._match_id('http://www.eitb.tv/eu/bideoa/zuzenduak/25-urte/60-minutos/espainiako-hiria/4104995148001/') == video_id

# Generated at 2022-06-24 12:22:45.598209
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor

    IE_NAME = 'eitb.tv'
    video_id = '4090227752001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_video = InfoExtractor._download_json(
            'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % video_id,
            video_id)
    eitb_IE = EitbIE(None)
    assert eitb_IE.IE_NAME == IE_NAME
    eitb_IE._

# Generated at 2022-06-24 12:22:47.411971
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Simple test to detect if class EitbIE is created"""
    assert EitbIE



# Generated at 2022-06-24 12:22:49.430988
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'
    return True

# Generated at 2022-06-24 12:22:50.985819
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:22:52.694588
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()
	assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:23:01.044535
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from start import start
	from urlparse import urlparse
	video_id = 4104995148001
	url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/' + str(video_id) + '/la-ruta-de-los-sentidos'
	u = urlparse(url)
	ie = EitbIE(u)
	info = ie.extract(u)
	start(info)

# Generated at 2022-06-24 12:23:05.064726
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:23:16.376561
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:17.857816
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie

# Generated at 2022-06-24 12:23:24.413487
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    assert hasattr(class_, 'ie_key')
    assert class_.ie_key() == 'eitb.tv'
    assert hasattr(class_, 'ie_name')
    assert class_.ie_name() == 'eitb.tv'
    assert hasattr(class_, '_VALID_URL')
    assert class_._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert hasattr(class_, '_TEST')

# Generated at 2022-06-24 12:23:30.987777
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:23:39.316617
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4090227752001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/-/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE('eitb.tv', 'EitbIE')
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._match_id(url) == video_id
    # TODO: Add test for _real_extract


# Generated at 2022-06-24 12:23:40.385823
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie != None

# Generated at 2022-06-24 12:23:48.752648
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # URL: http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    instance = EitbIE(url)
    instance.extract()


# Generated at 2022-06-24 12:23:55.540059
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_EITB = EitbIE()
    assert IE_EITB.IE_NAME == 'eitb.tv'
    assert IE_EITB._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:01.850463
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Constructor of class EitbIE"""
    # test with a normal video
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE().suitable(url)
    EitbIE().extract(url)

# Generated at 2022-06-24 12:24:04.252323
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == (r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/'
                             r'[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:24:12.034474
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'


# Generated at 2022-06-24 12:24:24.097012
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:24.697247
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:24:28.709840
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:24:29.583686
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-24 12:24:39.080816
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url_eitb = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_ie = EitbIE(url_eitb, {})
    assert eitb_ie is not None    # assert True
    #assert eitb_ie.url == 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert eitb_ie.type == 'playlist'

# Generated at 2022-06-24 12:24:40.994161
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Unitary constructor test
    eIE = EitbIE(ie=EitbIE())
    assert isinstance(eIE, EitbIE)

# Generated at 2022-06-24 12:24:44.574509
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    print(EitbIE._real_extract(EitbIE(), url))
#test_EitbIE()

# Generated at 2022-06-24 12:24:54.360233
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test with a video of the main page
    main_page_video_url = "http://www.eitb.tv/eu/bideoa/2014/08/12/el-hombre-espanol-es-deportista/4275925/4275815/"
    main_page_video_id = '4275815'
    main_page_video_ext = 'mp4'
    main_page_video_title = 'El hombre español es deportista'
    main_page_video_description = 'El espíritu deportivo de los españoles se refleja en las carreras solidarias que organizan los ayuntamientos y diversas entidades.'
    main_page_video_duration = 307.12
    main_page_video_timestamp = 1407800

# Generated at 2022-06-24 12:25:00.594972
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)
    assert ie.get_id() == '4090227752001'
    assert ie.get_url() == url
    assert ie.get_name() == 'Eitb'
    print(ie.get_available_formats())

# Generated at 2022-06-24 12:25:04.169732
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Creating instance of EitbIE class
    """
    EitbIE().set_params(name='EitbIE', validation_response_codes=None)

# Generated at 2022-06-24 12:25:07.675935
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:15.887087
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:19.155310
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    test_EitbIE.tested = 1


# Generated at 2022-06-24 12:25:20.092708
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-24 12:25:21.322157
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME

# Generated at 2022-06-24 12:25:21.873093
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:31.970148
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE('http://www.eitb.tv/eu/bideoa/zuzendaritza-teknikoan/4104990625001/4101076495001/luistxo-alonso-rivas/')
    assert eitb is not None, 'Constructor should return an object of class EitbIE'
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:25:37.669734
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test_object = EitbIE();
	assert test_object._VALID_URL == "https?://(www.)?eitb.tv/(eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"
	assert test_object.IE_NAME == "eitb.tv"


# Generated at 2022-06-24 12:25:48.550611
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create a new instance of class EitbIE
    ie = EitbIE()

    # Test _VALID_URL
    print("#Test _VALID_URL")
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    match = ie._VALID_URL.match(url)
    assert match

    # Test _real_extract
    print("#Test _real_extract")
    # Download JSON file
    video_id = match.group('id')
    print("#video_id: " + repr(video_id))

# Generated at 2022-06-24 12:25:49.141815
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE()

# Generated at 2022-06-24 12:25:57.372112
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    IE = EitbIE(url)
    assert IE.IE_NAME == 'eitb.tv'
    assert IE.url == url
    assert IE.id == '4090227752001'
    assert IE.title == "60 minutos (Lasa y Zabala, 30 años)"
    assert IE.description == 'Programa de reportajes de actualidad.'
    assert IE.duration == 3996.76
    assert IE.timestamp == 1381789200
    assert IE.upload_date == '20131014'
    assert IE.tags == list

   

# Generated at 2022-06-24 12:25:59.285281
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:26:09.575593
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'
    eitbIE = EitbIE()
    eitbIE._download_json = lambda *args, **kwargs: {'web_media': [{'RENDITIONS': 'something'}]}
    expected_result = {'id': '4090227752001', 'title': None, 'description': None, 'thumbnail': None, 'duration': None, 'timestamp': None, 'tags': None, 'formats': []}
    result = eitbIE._real_extract(url)
    assert expected

# Generated at 2022-06-24 12:26:20.331137
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test for class EitbIE
    """
    ie = EitbIE()

    assert ie.ie_key() == 'eitb'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'