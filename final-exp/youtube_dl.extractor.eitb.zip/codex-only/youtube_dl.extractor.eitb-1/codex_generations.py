

# Generated at 2022-06-24 12:16:16.785040
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test
    """
    from .common import InfoExtractor
    from .EitbIE import EitbIE
    assert(issubclass(EitbIE, InfoExtractor))
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-24 12:16:27.735624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert EitbIE.IE_NAME == e.IE_NAME
    assert e.TEASER_PATTERN == None
    assert EitbIE.TEASER_PATTERN == e.TEASER_PATTERN
    assert e.VALID_URL == 'https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)'
    assert EitbIE.VALID_URL == e.VALID_URL
    assert e.SUCCESS == None
    assert EitbIE.SUCCESS == e.SUCCESS
    assert e.test() == None
    # Testing EitbIE

# Generated at 2022-06-24 12:16:28.166033
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert 1==1

# Generated at 2022-06-24 12:16:34.252603
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:16:38.569496
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:16:41.790113
# Unit test for constructor of class EitbIE
def test_EitbIE(): 
	ie = EitbIE()

	assert ie
	assert ie.IE_NAME == 'eitb.tv'
	assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:45.247618
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test_EitbIE = EitbIE()
	print("\nUnit test for constructor of class EitbIE")
	if isinstance(test_EitbIE, EitbIE):
		print("Pass")
	else:
		print("Fail")


# Generated at 2022-06-24 12:16:45.996875
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(InfoExtractor())

# Generated at 2022-06-24 12:16:47.218011
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie

# Generated at 2022-06-24 12:16:54.932402
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_common import MockIE


# Generated at 2022-06-24 12:16:56.080139
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:17:00.450789
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('https://www.eitb.eus/es/videos/detalle/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:17:10.197753
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test _VALID_URL in constructor of EitbIE
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    # Test _TEST in constructor of EitbIE

# Generated at 2022-06-24 12:17:18.320304
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test 1:
    # To test the constructor of EitbIE following parameters are used:
    # url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE().download('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')



# Generated at 2022-06-24 12:17:21.907856
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:17:25.881494
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
        # If we get here, no exception was thrown
        assert True
    except Exception:
        # If we get here, an exception was thrown
        assert False


# Generated at 2022-06-24 12:17:27.910418
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE(constructor=EitbIE)

# Generated at 2022-06-24 12:17:29.235742
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()
	assert isinstance(ie, EitbIE)

# Generated at 2022-06-24 12:17:30.584294
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()

# Generated at 2022-06-24 12:17:31.366858
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:17:36.492454
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # The constructor for class should be changed.
    # It does not make sense to construct the class this way.
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:17:40.794263
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_name = 'EitbIE'
    class_object = globals()[class_name]
    instance_object = class_object(InfoExtractor())
    assert(instance_object.ie_key() == 'Eitb')
    assert(instance_object.ie_name() == 'Eitb.tv')

# Generated at 2022-06-24 12:17:41.614504
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:47.430699
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



if __name__ == "__main__":
    test_EitbIE()

# Generated at 2022-06-24 12:17:48.048387
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:17:49.641736
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:17:50.861879
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:17:59.431063
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Run in main thread because of PyBox2d
    from .utils import get_testcases
    from . import unescapeHTML

    testcases = get_testcases(
        EitbIE, only_matching=False)

    def test_eitb(url, *args):
        return (EitbIE, url) + args

    for test in testcases:
        url = unescapeHTML(test['url'])
        args = test.get('_args', ('', ''))
        print(test_eitb(url, *args))

# Generated at 2022-06-24 12:18:12.459093
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print ("test_EitbIE")
    #Test that a given video, which is an instance of class EitbIE, is downloaded and has title, description, duration and thumbnail
    title = "Lanexang en Hawai - Capítulo 3 3/4"
    description = "Capítulo 3 de la serie documental que relata la evolución histórica de la prescencia de la cultura de Laos en Hawai."
    duration = 2557.64
    thumbnail = "http://mam.eitb.eus/docroot/MAM/mam/thumbnail/2014/12/22/c2/0x0_3105_8a700d6dde2c0f3e3d5a8f8913a7fe29.jpg"
    video = EitbIE()

# Generated at 2022-06-24 12:18:15.923249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:18:25.384435
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:32.598148
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(test_url)
    assert ie.name == 'EitbIE'
    assert ie.url == test_url
    assert ie.params == {}
    assert ie.headers == {}
    assert ie.INVENTORY_BASE_URL == 'http://inventory.api.eitb.tv'
    assert ie.countries == ['EU', 'ES']
    assert ie.countries_index == {'eu': 0, 'es': 1}
    assert ie.countries_param == 'country'
    assert ie.default_countries == ('EU', 'ES')

# Generated at 2022-06-24 12:18:35.434322
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.ie_key() == 'eitb.tv')
    assert(ie.ie_name() == 'eitb.tv')

# Generated at 2022-06-24 12:18:40.455129
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    ied = EitbIE(url)
    print(ied)
    assert ied.url == url

# Generated at 2022-06-24 12:18:40.850699
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:18:41.412567
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:41.798824
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE

# Generated at 2022-06-24 12:18:45.627016
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:48.755257
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie=EitbIE(None)

    print (ie)
    print(ie._VALID_URL)
    assert ie._VALID_URL==r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:59.798959
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE()
# Testing URL
test_EitbIE_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Testing without download
print("# Testing without download #")
test_EitbIE_without_download = test_EitbIE()
test_EitbIE_without_download.suitable(test_EitbIE_url)
test_EitbIE_without_download.extract(test_EitbIE_url)

# Testing with download
print("# Testing with download #")
test_EitbIE_with_download = test_EitbIE()
test_Eit

# Generated at 2022-06-24 12:19:11.004257
# Unit test for constructor of class EitbIE
def test_EitbIE():
    unit_test = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert unit_test.IE_NAME == 'eitb.tv'
    assert unit_test.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    unit_test._real_initialize()

# Generated at 2022-06-24 12:19:11.673624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()


# Generated at 2022-06-24 12:19:13.756129
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor of class EitbIE should return an instance of EitbIE
    assert isinstance(EitbIE(), EitbIE)

# Generated at 2022-06-24 12:19:24.512402
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test the constructor of class EitbIE
    """
    
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:33.652676
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    ie = EitbIE("EitbIE")
    assert ie.IE_NAME == "EitbIE"
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:43.428188
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = type(EitbIE)
    assert t.__name__ == 'EitbIE'
    assert t.__bases__ == (EitbIE,)
    assert t.__doc__ == 'Eitb.tv content extractor'
    assert t.IE_NAME == 'eitb.tv'
    assert t._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:47.393687
# Unit test for constructor of class EitbIE
def test_EitbIE():
	try:
		EitbIE()
	except Exception as e:
		print("Error: " + str(e))
	else:
		print("Success")
# Unit test
#test_EitbIE()

# Generated at 2022-06-24 12:19:48.699316
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert(EitbIE)

# Generated at 2022-06-24 12:19:55.994958
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # init class
    eitbie = EitbIE()

    # validate url
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitbie.url_result('Ignored', 'Ignored')
    # check _VALID_URL regex
    eitbie.match_id("Ignored")
    # check _TEST dict
    assert(eitbie._TEST)

# Generated at 2022-06-24 12:20:05.016734
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:20:07.496444
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE("www.eitb.tv")
    assert_equal("eitb.tv", eitb.ie_key())
    assert_equal("eitb.tv", eitb.ie_name())


# Generated at 2022-06-24 12:20:11.406080
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/manu-garciaren-bideoak/manu-garcia-jesulinkarekin/')
    if ie.IE_NAME != 'eitb.tv':
        raise Exception('Wrong IE_NAME')
    print('Test passed')


# Generated at 2022-06-24 12:20:12.850821
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:20:22.364720
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
   

# Generated at 2022-06-24 12:20:31.284829
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.IE_NAME == 'eitb.tv')
    assert(EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:20:33.750122
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None).ie_key() == "eitb.tv"


# Generated at 2022-06-24 12:20:36.240219
# Unit test for constructor of class EitbIE
def test_EitbIE():

    assert EitbIE().IE_NAME == 'eitb.tv'



# Generated at 2022-06-24 12:20:44.957597
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('https://yadi.sk/i/X9g8xlZc1vZdH')
    assert ie.get_video_id() == 'X9g8xlZc1vZdH'
    assert ie.get_url() == 'http://www.eitb.tv/eu/bideoa/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/x/23373754'

# Generated at 2022-06-24 12:20:49.698820
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # This is only a test to see if the constructor of class EitbIE works properly
    # and it is not related to a real video
    eite = EitbIE()
    eite._match_id("http://www.eitb.tv/eu/bideoa/tkn/4104995148001/4104995148001")

# Generated at 2022-06-24 12:21:02.445281
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    video_url = 'http://www.eitb.tv/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_id = '4090227752001'
    expected_info_dict = {'id': '4090227752001', 'ext': 'mp4', 'title': '60 minutos (Lasa y Zabala, 30 años)',
                          'description': 'Programa de reportajes de actualidad.', 'duration': 3996.76,
                          'timestamp': 1381789200, 'upload_date': '20131014', 'tags': list}
    ie_info = ie._real_ext

# Generated at 2022-06-24 12:21:05.395094
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .common import InfoExtractor
    from .common import InfoExtractor
    ie = InfoExtractor()
    ie2 = InfoExtractor()
    ie3 = InfoExtractor()


# Generated at 2022-06-24 12:21:08.532854
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227755001/euskadi-zelan-maite-du/')

# Generated at 2022-06-24 12:21:09.512322
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:21:14.819273
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:21:20.257950
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().name == 'EITB'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:21.992759
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(_VALID_URL).IE_NAME == 'eitb.tv'
    return

# Generated at 2022-06-24 12:21:29.606933
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Test with a valid URL.
	eitb = EitbIE()
	# Test with a valid URL.
	eitb = EitbIE()
	eitb.extract(url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
	eitb.extract(url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
	# Test with a non-valid URL

# Generated at 2022-06-24 12:21:40.064183
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)
    video = ie._real_extract(url)
    assert video['id'] == '4090227752001'
    assert video['ext'] == 'mp4'
    assert video['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert video['description'] == 'Programa de reportajes de actualidad.'
    assert video['duration'] == 3996.76
    assert video['timestamp'] == 1381789200
    assert video['upload_date'] == '20131014'
   

# Generated at 2022-06-24 12:21:40.954928
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _ = EitbIE()

# Generated at 2022-06-24 12:21:43.486949
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:21:44.628980
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE


# Generated at 2022-06-24 12:21:49.600172
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == "eitb.tv"
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:57.920940
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test URL
    url = "http://www.eitb.tv/eu/bideoa/zuzendaria/60-minutos/lasa-y-zabala-30-anos/4104995148001/4090227752001/"
    eitb_ie = EitbIE(url)
    
    # Test name
    assert eitb_ie.name == 'eitb.tv'
    # Test URL
    assert eitb_ie.url == url
    # Test ID
    assert eitb_ie.id == '4090227752001'

# Test for constructor of class EitbIE
test_EitbIE()

# Generated at 2022-06-24 12:22:06.843418
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    _ = EitbIE(url);
    assert(_.IE_NAME == 'eitb.tv')
    assert(_.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-24 12:22:08.215070
# Unit test for constructor of class EitbIE
def test_EitbIE():
  eitb_IE = EitbIE()
  assert eitb_IE

# Generated at 2022-06-24 12:22:10.137760
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE is not None

# Generated at 2022-06-24 12:22:12.503911
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('test_EitbIE()')
    eitb_ie = EitbIE()
    print('EitbIE object created')

# Generated at 2022-06-24 12:22:15.281109
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE(None)
    assert eitb is not None

# Generated at 2022-06-24 12:22:19.566653
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    instance = EitbIE('EitbIE', True)
    assert(instance.ie_key() == 'Eitb')
    assert(instance.ie_name() == 'Eitb.tv')

# Generated at 2022-06-24 12:22:23.693392
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE().handleUrl('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-24 12:22:25.331264
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.ie_key() == 'eitb.tv'

# Generated at 2022-06-24 12:22:26.740036
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE();

# Generated at 2022-06-24 12:22:29.563912
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie_test = EitbIE()
    assert eitb_ie_test

# Generated at 2022-06-24 12:22:30.343481
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:22:35.626881
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    

# Unit test when url is valid

# Generated at 2022-06-24 12:22:37.906657
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for constructor of class EitbIE
    """
    C = EitbIE()

# Generated at 2022-06-24 12:22:42.037175
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:50.288235
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == "eitb.tv"
    assert eitb_ie.url_re == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:01.640484
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:02.411766
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None


# Generated at 2022-06-24 12:23:07.002645
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        from . import tests
        return tests.test_extractors(IE_NAME)[0]
    except ImportError as e:
        import sys
        sys.stderr.write('Tests can\'t be run without the unittest module. To fix this error install the unittest module.\n\nError: {}\n'.format(str(e)))
        sys.exit(1)

# Generated at 2022-06-24 12:23:10.144219
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/lagun-artea/12826/12826/')

# Generated at 2022-06-24 12:23:11.345814
# Unit test for constructor of class EitbIE
def test_EitbIE():
    dl = EitbIE()

# Generated at 2022-06-24 12:23:11.972427
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:23:12.940228
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:23:13.562748
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:23:14.731925
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE._TEST

# Generated at 2022-06-24 12:23:15.389355
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE()

# Generated at 2022-06-24 12:23:20.764596
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert IE.IE_NAME == 'eitb.tv'



# Generated at 2022-06-24 12:23:21.892905
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:23:30.403593
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.suitable("http://eitb.tv/eu/bideoa/60-minutos/44444444444444444/44444444444444444/")
    assert EitbIE.suitable("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert not EitbIE.suitable("http://www.eitb.tv/")

# Generated at 2022-06-24 12:23:34.129801
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:41.834614
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('Testing EitbIE')
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert EitbIE._TEST['info_dict']['id'] == '4090227752001'

# Generated at 2022-06-24 12:23:52.697862
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/bizi-bizi/5665655/'
    actual_result = EitbIE._get_id_from_url(url)
    assert actual_result == '5665655'
    # Test that a given URL leads to a video ID
    url = 'http://www.eitb.tv/eu/bideoa/bizi-bizi/5665655/'
    assert EitbIE.suitable(url)
    video = EitbIE._real_extract(EitbIE(), url)
    assert video['id'] == '5664315'
    # Test if it is a video URL

# Generated at 2022-06-24 12:23:54.033414
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert 'eitb' == EitbIE._VALID_URL.split('/')[2]

# Generated at 2022-06-24 12:23:55.401121
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:55.889085
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:24:01.449303
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Given
    test = EitbIE._TEST
    info_extractor = EitbIE()

    # When
    test_url = test['url']
    video_id = info_extractor._match_id(test_url)
    expected_video_id = test['info_dict']['id']
    assert video_id == expected_video_id


# Generated at 2022-06-24 12:24:02.501646
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE.suite()

# Generated at 2022-06-24 12:24:08.931874
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('https://www.eitb.tv/eu/bideoa/mondragon-goiko-kalitateaz/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    ie = EitbIE('https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:24:09.480479
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:24:10.115107
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()



# Generated at 2022-06-24 12:24:10.754242
# Unit test for constructor of class EitbIE
def test_EitbIE():
  c = EitbIE("","")

# Generated at 2022-06-24 12:24:11.319985
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE()

# Generated at 2022-06-24 12:24:15.240212
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:24:18.897757
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:24:24.196221
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/eu/bideoa/deportes-kronika/deporte-x-kronika-kronika/4101563986001/jose-antonio-camacho-errazkin/4101563986001/")

# Generated at 2022-06-24 12:24:25.343917
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE.suite()

# Generated at 2022-06-24 12:24:30.751433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    video_id = '4090227752001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/' + video_id + '/lasa-y-zabala-30-anos/'
    
    eitbIE = EitbIE(None)

    # Test if video info has been correctly extracted

# Generated at 2022-06-24 12:24:33.030499
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:24:38.548152
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/eskubideak-bideoa/2608457952001/2601357858001/', {})
    url = 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/DomainRestrictedSecurity/TokenAuth/'
    assert ie._download_json(url, None, None, None) == None

# Generated at 2022-06-24 12:24:40.625248
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_info_extractor = EitbIE("eitb.tv")
    assert_not_none(eitb_info_extractor)


# Generated at 2022-06-24 12:24:47.530698
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.__name__ == 'eitb.tv'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:53.224495
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:56.407712
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE"""
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:25:04.848592
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4104995148001'
    video_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/'+video_id+'/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._VALID_URL ==  r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:14.844463
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/');
    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:25:18.872286
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    try:
        instance.IE_NAME
        instance.VALID_URL
        instance.TEST
    except AttributeError:
        raise AssertionError('Some attribute is missing in constructor of class {0}'.format(instance.__class__.__name__))


# Generated at 2022-06-24 12:25:22.681442
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/noticia/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    eitbie = EitbIE(url)
    eitbie.extract()

# Generated at 2022-06-24 12:25:33.678825
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:38.304452
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # The constructor of the class won't raise exception when the url is valid
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:25:43.022981
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.__name__ == 'eitb.tv'

# Generated at 2022-06-24 12:25:52.911945
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    yt = EitbIE(url)
    yt.extract(url)
    assert yt.IE_NAME == 'eitb.tv'
    assert yt._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:54.121800
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE().suite()

# Generated at 2022-06-24 12:25:54.971564
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:26:01.172431
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:26:02.163537
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert True

# Generated at 2022-06-24 12:26:05.255017
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test that an instance of the class EitbIE can be constructed
    ie = EitbIE()
    assert ie is not None
    assert isinstance(ie, InfoExtractor);

# Generated at 2022-06-24 12:26:16.977444
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.ie_key() == 'eitb'
    instance = EitbIE()
    assert instance.IE_NAME == 'eitb.tv'
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'