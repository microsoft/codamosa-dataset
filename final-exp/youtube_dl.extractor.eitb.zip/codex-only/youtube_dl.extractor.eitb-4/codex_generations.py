

# Generated at 2022-06-24 12:16:20.559431
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_url = "http://www.eitb.tv/es/video/noticias-de-euskal-herria/2502467231001/eitb-comparte/2492818509001/"
    i = EitbIE(video_url)
    i.video_id
    assert i.video_id == "2492818509001"
    i.video_url
    assert i.video_url == "http://www.eitb.tv/es/video/noticias-de-euskal-herria/2502467231001/eitb-comparte/2492818509001/"
    i.webpage
    assert i.webpage is None
    i.webpage_url
    assert i.webpage_url is None
    i.title

# Generated at 2022-06-24 12:16:24.430511
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        # Call the constructor of class EitbIE
        EitbIE()
    except Exception as ex:
        # Raise an error if an exception is caught
        assert False, 'Unable to call the constructor of class EitbIE'



# Generated at 2022-06-24 12:16:29.395661
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # An EITB URL is constructed using fields: base, channel, program and id.
    # The field channel is ignored by the parser in the EITB extractor
    eitb_url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    eitb_id = "4090227752001"
    eitb_ie = EitbIE(eitb_url)
    eitb_ie_name = eitb_ie._real_extract(eitb_ie._VALID_URL)
    assert eitb_ie_name['id'] == eitb_id

# Generated at 2022-06-24 12:16:36.680807
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test for constructor of class EitbIE"""
    #url = 'http://www.eitb.tv/eu/bideoa/dokumentala/somos-legion/4288023394001/?t=Ongi-etorri%20EiTB%20Multimedia%20APIfen'
    url = 'http://www.eitb.tv/eu/bideoa/60-minututuak/60-minututuak-2014-2015/1139556855001/1139560253001/iraola-ordua-eta-gaztelera/'
    assert EitbIE._VALID_URL in url
    assert EitbIE._TEST['url'] in url



# Generated at 2022-06-24 12:16:40.279595
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:41.947475
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test the constructor of the class
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:16:46.501634
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._downloader is not None
    assert eitb._downloader.params is not None
    assert eitb._downloader.params['outtmpl'] is not None
    assert eitb._downloader.params['noprogress']
    assert eitb._downloader.params['sleep_interval'] is not None
    assert eitb._downloader.params['default_search'] is None

# Generated at 2022-06-24 12:16:50.856483
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb_ie is not None

# Generated at 2022-06-24 12:16:52.517474
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert(i.IE_NAME == 'Eitb')

# Generated at 2022-06-24 12:17:03.481840
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test on http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/
    video_url = ('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013'
                 '-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    test_video = EitbIE()._real_extract(video_url)
    assert test_video['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert test_video['id'] == '4090227752001'
    assert test_

# Generated at 2022-06-24 12:17:05.438432
# Unit test for constructor of class EitbIE
def test_EitbIE():
    c = EitbIE()
    assert isinstance(c,InfoExtractor), "Failed to create an object of class EitbIE"

# Generated at 2022-06-24 12:17:09.079680
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:17:19.031258
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for EitbIE constructor."""
    url = "http://www.eitb.tv/eu/bideoa/programak/hiru-hiru-arrosa/4104995147001/4083190376001/"
    instance = EitbIE(url)

    expected_url = "http://www.eitb.tv/eu/bideoa/programak/hiru-hiru-arrosa/4104995147001/4083190376001/"
    expected_video_id = "4083190376001"
    expected_video_title = "Hiru hiru arrosa"
    expected_video_description = "Programa de cinco días que trata la agenda política de la semana."

    # Check that given url matches the expected

# Generated at 2022-06-24 12:17:26.846601
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:29.923521
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = InfoExtractor()
    eitb_ie = EitbIE()
    assert eitb_ie == info_extractor.IE_NAME_TO_CLASS['eitb.tv']


# Generated at 2022-06-24 12:17:34.488228
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:43.508364
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check if the IE is supported, otherwise return
    ie = EitbIE()
    if not ie.suitable('http://www.eitb.tv/eu/bideoa/60-minutos/30-anos/20131014220113/'):
        return

    # Extract a video
    test = {'url': 'http://www.eitb.tv/eu/bideoa/60-minutos/30-anos/20131014220113/'}
    ie.extract(test['url'])

    # If a video is extracted, check that it has some values
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:55.892918
# Unit test for constructor of class EitbIE
def test_EitbIE():
    expected_name = 'www.eitb.tv'
    expected_url = 'http://www.eitb.eus/television'
    expected_description = 'description'
    expected_thumbnail = 'http://www.eitb.eus/asset/image_full/1131875/2/0/0/0/0/0/0/0'
    expected_upload_date = '20131001'
    expected_title = 'title'
    expected_duration = 1025
    expected_age_limit = 0
    expected_tags = ['tag1', 'tag2']
    expected_categories = ['category1', 'category2']

# Generated at 2022-06-24 12:17:56.994739
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:18:01.530172
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == "eitb.tv"
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:18:04.210308
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from pytube import YouTube
    my_obj = YouTube()
    my_obj.IE_NAME = 'Eitb'
    assert my_obj.IE_NAME == 'Eitb'


# Generated at 2022-06-24 12:18:05.468373
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert not EitbIE()._downloader.params.get('noplaylist')

# Generated at 2022-06-24 12:18:06.422629
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('eitb')

# Generated at 2022-06-24 12:18:08.222982
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of class EitbIE"""
    return EitbIE()


# Generated at 2022-06-24 12:18:17.031807
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a_test_EitbIE = EitbIE()
    assert a_test_EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert a_test_EitbIE.IE_NAME == 'eitb.tv'
    assert a_test_EitbIE.ie_key() == 'EitbTV'

# Generated at 2022-06-24 12:18:25.595666
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info = EitbIE('EitbIE')._real_extract(
        'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert info['id'] == '4090227752001'
    assert info['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert info['description'] == 'Programa de reportajes de actualidad.'
    assert info['duration'] == 3996.76
    assert info['timestamp'] == 1381789200
    assert info['upload_date'] == '20131014'
    assert info['tags'] == []

# Generated at 2022-06-24 12:18:27.979577
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE(None, None)
    except TypeError:
        return True
    raise AssertionError('Failed to test constructor of class EitbIE')



# Generated at 2022-06-24 12:18:31.116168
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'




# Generated at 2022-06-24 12:18:32.440469
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 12:18:36.514795
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:18:38.321326
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()
    assert t.IE_NAME == 'EitbIE'

# Generated at 2022-06-24 12:18:45.626371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """test for EitbIE"""
    my_url = "http://www.eitb.tv/eu/bideoa/bideoak/makala/12098762/parte-hartzeko-1-zatia-euskal-jaungoiko-kolpez-kolpe/601626"
    eitb_ie = EitbIE(my_url)
    assert eitb_ie.IE_NAME == "eitb.tv"
    assert eitb_ie.url == my_url
    assert eitb_ie.ie_key() == "EitbIE"



# Generated at 2022-06-24 12:18:46.309132
# Unit test for constructor of class EitbIE
def test_EitbIE():
    Eitb = EitbIE()

# Generated at 2022-06-24 12:18:47.203745
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    return


# Generated at 2022-06-24 12:18:50.271446
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        assert False, 'Could not initialize class EitbIE'

# Generated at 2022-06-24 12:18:53.465882
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://foo.bar/')
    assert ie
    ie = EitbIE('')
    assert ie

# Generated at 2022-06-24 12:18:57.943944
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
	assert type(eitb) == EitbIE


# Generated at 2022-06-24 12:19:03.305671
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.name == 'eitb.tv'
    assert ie.test()
    assert ie.suitable(ie.test_urls[0])
    assert not ie.suitable('http://www.eitb.tv/eu/partakatu/')
    assert ie.get_urls() == ie.test_urls[0]

# Generated at 2022-06-24 12:19:08.064149
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:19:15.777280
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/", "eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert "http://www.eitb.tv/eu/bideoa/4090227752001/", "eitb.tv/eu/bideoa/4090227752001/"

# Test for extractor of class EitbIE

# Generated at 2022-06-24 12:19:20.105584
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE('https://www.eitb.tv/es/video/deportes/f1-grand-prix-de-japon-2019-directo/5733128998001/5733128584001/')
    except:
        return False
    return True


# Generated at 2022-06-24 12:19:30.118437
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .common import ExtractorError
    from .common import compat_urlparse
    from .common import compat_urllib_parse
    from .common import compat_urllib_request

    import os
    import unittest

    print('Running unit test for constructor of class EitbIE')
    print('Checking if we can import module EitbIE...')

    test_ie = InfoExtractor(None)
    eitb_ie = EitbIE(test_ie._downloader, test_ie._downloader.cache.base_dir, test_ie._downloader.get_username(), test_ie._downloader.get_password())


# Generated at 2022-06-24 12:19:31.926450
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test 
    eitb_ie = EitbIE(downloader=None)
    assert(eitb_ie.IE_NAME == "EitbTV")

# Generated at 2022-06-24 12:19:35.834879
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:19:39.604665
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")


# Generated at 2022-06-24 12:19:43.114824
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL
    assert EitbIE().IE_NAME == EitbIE._IE_NAME

# Generated at 2022-06-24 12:19:48.029470
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-24 12:19:48.809896
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie

# Generated at 2022-06-24 12:19:50.214835
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-24 12:19:56.709496
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Basic test to see if the class is instantiable
    """
    my_EitbIE = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert_true(isinstance(my_EitbIE,EitbIE))

# Unit tests for info extraction

# Generated at 2022-06-24 12:20:00.509323
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info = EitbIE(EitbIE.create_ie('EitbIE'))
    assert info.ie_key() == 'EitbIE'
    assert info.ie_name() == 'eitb.tv'

# Generated at 2022-06-24 12:20:07.964710
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:12.099200
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:13.086583
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test that EitbIE is instanciable
    return EitbIE()

# Generated at 2022-06-24 12:20:22.529980
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert e._TEST.get('url') == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert e._TEST.get('md5') == 'edf4436247185adee3ea18ce64c47998'
    id = e._TEST['info_dict'].get('id')
    assert id == '4090227752001'

# Generated at 2022-06-24 12:20:24.126336
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None


# Generated at 2022-06-24 12:20:31.577677
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:32.249281
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE()

# Generated at 2022-06-24 12:20:34.933423
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:20:44.446158
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:47.133380
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(EitbIE.IE_NAME)

# Generated at 2022-06-24 12:20:48.888366
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except TypeError:
        print('Test for constructor of class EitbIE has failed!')


# Generated at 2022-06-24 12:21:01.772331
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE({})
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:03.135196
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(InfoExtractor)


# Generated at 2022-06-24 12:21:05.012754
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE().loading == False
	assert EitbIE()._VALID_URL is not None
	assert EitbIE()._TEST['url'] is not None

# Generated at 2022-06-24 12:21:06.410757
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:21:18.267948
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiate the class
    eitbIE = EitbIE()
    # Check the URL to extract
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert url == eitbIE._VALID_URL
    # Assert that the video ID is correct
    video_id = eitbIE._match_id(url)
    assert video_id == '4090227752001'
    # Check that the URL to download the information is right

# Generated at 2022-06-24 12:21:24.386804
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE.IE_NAME = 'eitb.tv'
    test_EitbIE.TEST = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test_EitbIE.MD5 = 'edf4436247185adee3ea18ce64c47998'
    test_EitbIE.ID = '4090227752001'
    test_EitbIE.TITLE = '60 minutos (Lasa y Zabala, 30 años)'
    test_EitbIE.DESCRIPTION = 'Programa de reportajes de actualidad.'

# Generated at 2022-06-24 12:21:30.906359
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('EiTB', 'video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb_ie.ie_key() == 'eitb.tv'
    assert eitb_ie.video_id == '4090227752001'

# Generated at 2022-06-24 12:21:38.969705
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:40.954817
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()

# Unit tests for constructor of class EitbIE

# Generated at 2022-06-24 12:21:41.926792
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("test")

# Generated at 2022-06-24 12:21:46.602549
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:21:51.631705
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb=EitbIE()
    assert eitb.IE_NAME == "eitb.tv"
    assert eitb.IE_DESC == "eitb.tv"
    assert eitb.VALID_URL == r"https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"


# Generated at 2022-06-24 12:21:55.552391
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'EitbIE'

# Generated at 2022-06-24 12:22:01.529141
# Unit test for constructor of class EitbIE
def test_EitbIE():  
  url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/' 
  EitbIE()._real_extract(url)


# Generated at 2022-06-24 12:22:04.377709
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test_EitbIE = EitbIE()
	assert test_EitbIE.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:22:13.740926
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # First test is correct: match
    eitb = EitbIE()
    eitb.suitable('HTTP://WWW.eitb.tv/EU/BIDEOA/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    eitb.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:22:14.987329
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(0)

# Generated at 2022-06-24 12:22:25.937733
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Given an URL, tests for:
     * The URL
     * The class
     * The args
     * Prompt the missing class
    """
    import unittest
    from youtube_dl.utils import FakeYDL
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    fydl = FakeYDL()
    fydl.params['force_generic_extractor'] = True
    with unittest.mock.patch('youtube_dl.YoutubeDL.report_warning') as report_warning:
        fydl.extract_info(url, download=False)
        report_warning.assert_called_

# Generated at 2022-06-24 12:22:28.593511
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:22:40.189945
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test values
    url1 = 'http://www.eitb.tv/eu/bideoa/video-60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

    # Test constructor
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_DESC == 'EITB.tv'
    assert ie._TEST

    # Test regexp
    assert ie._match_id(url1)

# Generated at 2022-06-24 12:22:41.484835
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert(EitbIE()!=None)

# Generated at 2022-06-24 12:22:50.542724
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4090227752001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assertEqual(EitbIE._VALID_URL, url)
    eitb = EitbIE(url)
    assertEqual(eitb._match_id(url), video_id)
    eitb.extract()


if __name__ == '__main__':
    # Unit test for constructor of class EitbIE
    test_EitbIE()

# Generated at 2022-06-24 12:23:01.832791
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()
    t._match_id('http://www.eitb.tv/eu/bideoa/elhuyar/46/25303/')
    t._real_extract('https://www.eitb.tv/eu/bideoa/zerbitzuak/42/13023/')
    t._real_extract('https://www.eitb.tv/eu/bideoa/entzun/358/7403/')
    t._real_extract('https://www.eitb.tv/eu/bideoa/bideo-nagusiak/2/392659/')
    t._real_extract('https://www.eitb.tv/eu/bideoa/gaur/5/392932/')

# Generated at 2022-06-24 12:23:02.794637
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE, type)

# Generated at 2022-06-24 12:23:04.128952
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    return ie


# Generated at 2022-06-24 12:23:05.393661
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:11.190255
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:23:12.552188
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()


# Generated at 2022-06-24 12:23:14.440774
# Unit test for constructor of class EitbIE
def test_EitbIE():
	#Check constructor for the class EitbIE
	assert(EitbIE is not None)


# Generated at 2022-06-24 12:23:18.009116
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _EitbIE = EitbIE('EitbIE', '/eitb/eu/bideoa/', 'es')
    assert isinstance(_EitbIE, EitbIE)

# Generated at 2022-06-24 12:23:20.177626
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/", {})

# Generated at 2022-06-24 12:23:21.607330
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()

# Generated at 2022-06-24 12:23:22.246747
# Unit test for constructor of class EitbIE
def test_EitbIE():
  pass

# Generated at 2022-06-24 12:23:27.922392
# Unit test for constructor of class EitbIE
def test_EitbIE():
    fields = ("_VALID_URL", "_TEST")
    ie = EitbIE("EitbIE.test_EitbIE()")
    for field in fields:
        try:
            print(field)
            print(ie.__getattribute__(field))
        except Exception as e:
            print(e)


# Generated at 2022-06-24 12:23:32.051741
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Tests that the class is correctly created"""
    EitbIE('http://Eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:23:39.391412
# Unit test for constructor of class EitbIE
def test_EitbIE():
    yield 'http://www.eitb.tv/eu/bideoa/60-minutos/4127037373001/4127037373002/60-minutos-episodio-65/', 'edf4436247185adee3ea18ce64c47998'
    yield 'http://www.eitb.tv/es/video/60-minutos/4127037373001/4127037373002/60-minutos-episodio-65/', 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:23:50.235354
# Unit test for constructor of class EitbIE
def test_EitbIE():
    globals()['InfoExtractor'] = type(__name__, (InfoExtractor,), {})
    globals()['InfoExtractor'].__module__ = __name__

# Generated at 2022-06-24 12:23:51.661547
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-24 12:23:53.411891
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:23:57.770237
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb_ie = EitbIE()
	assert eitb_ie.IE_NAME == 'eitb.tv'
	assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:24:04.080875
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    expected_md5 = "edf4436247185adee3ea18ce64c47998"
    expected_title = "60 minutos (Lasa y Zabala, 30 años)"
    expected_description = "Programa de reportajes de actualidad."
    expected_duration = 3996.76
    expected_timestamp = 1381789200
    expected_upload_date = "20131014"
    expected_tags = list

# Generated at 2022-06-24 12:24:05.462908
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test the constructor
    # EitbIE.__init__(None)
    pass

# Generated at 2022-06-24 12:24:06.734861
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IEitb = EitbIE()

# Generated at 2022-06-24 12:24:10.005929
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', None)

# Generated at 2022-06-24 12:24:14.099674
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.ie_key() == 'eitb.tv'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.valid_url('http://www.eitb.tv/eu/bideoa/video/detail/4090227752001/', '4090227752001')

# Generated at 2022-06-24 12:24:15.601361
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        raise AssertionError('constructor test failed')

# Generated at 2022-06-24 12:24:18.897157
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:24:19.523335
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-24 12:24:21.337440
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    

# Generated at 2022-06-24 12:24:24.245692
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()

# Generated at 2022-06-24 12:24:31.655735
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Testing EitbIE constructor with url
    eitb=EitbIE([],{})
    eitb._downloader.params=[]
    # Testing EitbIE constructor with url
    eitb=EitbIE([],{})
    eitb.real_extract({'url': "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"})

# Generated at 2022-06-24 12:24:32.249102
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie

# Generated at 2022-06-24 12:24:34.756942
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _ = EitbIE('https://www.eitb.tv/eu/bideoa/urte-berri-zuzen/4718017978001/')

# Generated at 2022-06-24 12:24:41.215059
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.IE_NAME == 'eitb.tv')
    assert(EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert(EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998')

# Generated at 2022-06-24 12:24:45.509223
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create a new instance of class EitbIE
    eitb_ie_instance = EitbIE()
    # Test the constructor
    assert isinstance(eitb_ie_instance, EitbIE)


# Generated at 2022-06-24 12:24:50.439372
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:00.634787
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE.IE_DESC == 'eitb.tv videos'

# Generated at 2022-06-24 12:25:01.261961
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE()

# Generated at 2022-06-24 12:25:02.040854
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:02.960109
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 12:25:08.745616
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Returns a singleton instance of the class that implements the given IE
    ie = YoutubeIE.ie_key()
    # Tests if the instance is able to handle the given URL
    assert ie.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:25:10.079935
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # It should not raise any exception
    EitbIE()

# Generated at 2022-06-24 12:25:17.692133
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/zuzenean/programa-zuzenean/koldo-azkune---elkarrekin-aurkeztu-gaitu-zuri-belarriak-atzerritik/4024442018001/')
    if ie.IE_NAME != 'eitb.tv':
        raise Exception("IE_NAME is not eitb.tv")

    if len(ie._VALID_URL) < 20:
        raise Exception("Invalid length for _VALID_URL")

    if ie._TEST == None:
        raise Exception("Test does not exist")

# Generated at 2022-06-24 12:25:21.748141
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    # Test initialization
    assert class_ != InfoExtractor
    assert class_('EitbIE', True)
    # Test for class type
    class_instance = class_('EitbIE', False)
    assert isinstance(class_instance, InfoExtractor)

# Generated at 2022-06-24 12:25:33.013310
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:38.792921
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_ie = EitbIE()
    eitb_ie.name = "eitb.tv"
    eitb_ie.suitable(url)

# Generated at 2022-06-24 12:25:39.692891
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("EitbIE", "EitbIE", "EitbIE")

# Generated at 2022-06-24 12:25:44.760947
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_class=EitbIE()
    assert test_class._VALID_URL=='https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:25:52.311877
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_html import get_test_html
    test_html = get_test_html('test_eitb.tv', 'eitb.html')
    eitb_ie = EitbIE()
    results = eitb_ie.extract_links(test_html)
    assert len(results) == 1
    result = results[0]
    assert result.url == 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/DomainRestrictedSecurity/TokenAuth/'
    assert result.ie_key == 'Eitb'
    return results

# Generated at 2022-06-24 12:25:54.520193
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.__name__ == 'EitbIE'

# Generated at 2022-06-24 12:26:01.074081
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ test_EitbIE unit test """
    url = 'http://www.eitb.tv/eu/bideoa/altsasuko-kukai-atsegi-nagusia/4106131034001/4099120907001/orokorra/'
    eitbie = EitbIE()
    print(eitbie._real_extract(url))

# Generated at 2022-06-24 12:26:10.820350
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import _TEST_URL
    from .eitb import EitbIE

    url_test = [
        # ['format_id'],
        [
            'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
        ],
    ]
    for [url] in url_test:
        EitbIE._download_webpage(url, test=True)


## Execute the unit tests
if __name__ == "__main__":
    from .common import _TEST_URL
    from .eitb import EitbIE

    # Test for class AudioIE

# Generated at 2022-06-24 12:26:21.580092
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('https://www.eitb.eus/es/video/programa/764/5456264/ultimo-capitulo-el-matador-se-va-de-bilbao/')
    assert eitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitbIE.IE_NAME == 'eitb.tv'