

# Generated at 2022-06-24 12:16:19.803711
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:16:21.404199
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie

# Generated at 2022-06-24 12:16:25.843675
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 'key', 'secret')
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-24 12:16:29.240170
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instance of class EitbIE
    eitb_ie = EitbIE();
    # Check that _VALID_URL is equivalent to EitbIE._VALID_URL
    assert eitb_ie._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-24 12:16:30.264171
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:16:31.564323
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:35.471109
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    instance = e.ie_key()
    assert e.IE_NAME == instance

# Generated at 2022-06-24 12:16:36.300027
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE(None)._real_initialize()

# Generated at 2022-06-24 12:16:36.860520
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("test_EitbIE")

# Generated at 2022-06-24 12:16:38.553599
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:39.439260
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ieTest = EitbIE()
    assert ieTest is not None

# Generated at 2022-06-24 12:16:39.921955
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:43.027339
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:16:44.236918
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-24 12:16:45.021886
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import EitbIE


# Generated at 2022-06-24 12:16:51.218166
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert instance.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:00.148840
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.get_domain() == 'eitb.tv'
    assert e.get_name() == 'eitb.tv'
    assert e.get_supported_domains() == ['eitb.tv']
    assert e.get_supported_protocolls() == ['http', 'https']
    assert e.get_url_regex() == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert e.get_version() == '0.0.1'

# Generated at 2022-06-24 12:17:04.010499
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'EitbIE'

# Generated at 2022-06-24 12:17:04.824259
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:17:08.065055
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:17:09.522100
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()

# Generated at 2022-06-24 12:17:19.310316
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('test EitbIE')
    ie = EitbIE()
    # assert(ie.IE_NAME == 'eitb.tv')
    # assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    # assert(ie._TEST == {'url': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 'md5': 'edf4436247185adee3ea18ce64c47998', 'info_dict': {'id': '40

# Generated at 2022-06-24 12:17:19.939105
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:17:31.757951
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb._TEST.get('url') == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert eitb._TEST.get('md5') == 'edf4436247185adee3ea18ce64c47998'
    assert eitb

# Generated at 2022-06-24 12:17:32.310460
# Unit test for constructor of class EitbIE
def test_EitbIE():
  pass

# Generated at 2022-06-24 12:17:33.901026
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of class EitbIE"""
    assert EitbIE()


# Generated at 2022-06-24 12:17:35.606768
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:44.504786
# Unit test for constructor of class EitbIE
def test_EitbIE():
    valid_urls = ['http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/']
    invalid_urls = ['http://www.eitb.tv/eu/bideoa/euskal-kostaldea-2013/4104995148001/4103498075001/orejitas-con-maria-de-los-angeles/']
    # valid_urls = ['http://www.eitb.tv/eu/bideoa/euskal-kostaldea-2013/4104995148001/4103498075001/orejitas-con-maria-de-los-angeles/']
    # invalid

# Generated at 2022-06-24 12:17:45.365244
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:17:57.287625
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url_video = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE._download_webpage = lambda _,x: "OK"
    EitbIE._download_json = lambda _,x: {'web_media': [{'HLS_SURL': '', 'HDS_SURL': ''}]}
    EitbIE._search_regex = lambda _,x,y,z,q: ''
    EitbIE._extract_m3u8_formats = lambda _,x,y,z,q: ''

# Generated at 2022-06-24 12:18:05.293404
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from EitbIE import EitbIE
    #test 1
    eitb = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/')
    assert(eitb.url=='http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/')
    #test 2
    eitb = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/')
    assert(eitb.ie_key()=='Eitb')


# Generated at 2022-06-24 12:18:14.918891
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_NAME = 'eitb.tv'
    _VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:18:23.849756
# Unit test for constructor of class EitbIE
def test_EitbIE():
    input = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    IE = EitbIE()
    IE.extract(input) 
    assert(IE.video_id == '4090227752001')
    assert(IE.video_title == '60 minutos (Lasa y Zabala, 30 años)')
    assert(IE.video_description == 'Programa de reportajes de actualidad.')

# Generated at 2022-06-24 12:18:36.120763
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import json
    import requests
    # Test a valid url
    testurl = "http://www.eitb.tv/eu/bideoa/teledocumentales/ocio/munduko-azken-bihotza-documental/4090996394001/4090996393001/rapa-nui-la-isla-de-los-gigantes/"

    ie = EitbIE()
    match = ie._VALID_URL.match(testurl)

    video_id = ie._match_id(testurl)
    json = requests.get("http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/" + video_id)

    assert ie.suitable(testurl)

# Generated at 2022-06-24 12:18:45.471379
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test URL
    test_url1 = 'http://www.eitb.tv/eu/bideoa/bideoak/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test_url2 = 'http://www.eitb.tv/es/video/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

    # Test class instantiation
    eitb_test1 = EitbIE(test_url1)
    eitb_test2 = EitbIE(test_url2)
    print('Class EitbIE instantiated')
    return True

# Generated at 2022-06-24 12:18:49.023538
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for constructor of class EitbIE
    """
    eitb = EitbIE()

    # Checks that the EitbIE is for this URL
    assert eitb.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:18:53.795622
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:55.664189
# Unit test for constructor of class EitbIE
def test_EitbIE():
    x = EitbIE()
    assert x.ie_key() == x.name


# Generated at 2022-06-24 12:19:04.424597
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import sys
    import os
    import tempfile
    # Create an instance of EitbIE class.
    IE_EITB = EitbIE()
    # Print to stdout available information regarding this IE.
    print('\nName: ' + IE_EITB.IE_NAME)
    print('Description: ' + IE_EITB.IE_DESC)
    print('URL format: ' + IE_EITB._VALID_URL)
    # If a parameter is missing, returns None.
    print (sys.argv[0])

# Generated at 2022-06-24 12:19:05.982850
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .. import EitbIE
    EitbIE()

# Generated at 2022-06-24 12:19:12.562093
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i.name == 'eitb.tv'
    assert i.IE_NAME == 'eitb.tv'
    assert i._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:13.391378
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('')

# Generated at 2022-06-24 12:19:24.095548
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (EitbIE.__name__ == 'EitbIE')
    assert (EitbIE.IE_NAME == 'eitb.tv')
    assert (EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:19:34.297730
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Without id on url
    assert EitbIE.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/')
    # Without id on url
    assert EitbIE.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/')
    # With id on url
    assert EitbIE.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/')
    # With id on url

# Generated at 2022-06-24 12:19:44.283900
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.ie_key() == 'EitbIE'
    assert ie.frame_size() == (640,360)

# Generated at 2022-06-24 12:19:53.262229
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    expected_key = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    actual_key = ie._VALID_URL
    assert expected_key in actual_key

# Generated at 2022-06-24 12:19:53.910587
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:19:59.073716
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:00.716799
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert hasattr(EitbIE(), "suitable")
    assert hasattr(EitbIE(), "result_type")

# Generated at 2022-06-24 12:20:02.555954
# Unit test for constructor of class EitbIE
def test_EitbIE():

    try:
        EitbIE()
    except Exception as ex:
        assert False, str(ex)

# Generated at 2022-06-24 12:20:03.427463
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie

# Generated at 2022-06-24 12:20:04.340114
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor)

# Generated at 2022-06-24 12:20:13.153448
# Unit test for constructor of class EitbIE
def test_EitbIE():
  test_Eitb = EitbIE()
  assert test_Eitb.IE_NAME == 'eitb.tv'
  assert test_Eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
  assert test_Eitb._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
  assert test_Eitb._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:20:18.568780
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:21.691049
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:20:26.870968
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()
	res = ie.extract("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
	for f in res["formats"]:
		print(f["url"])

test_EitbIE()

# Generated at 2022-06-24 12:20:33.357920
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
                'mp4', 'edf4436247185adee3ea18ce64c47998',
                '60 minutos (Lasa y Zabala, 30 años)', 'Programa de reportajes de actualidad.',
                3996.76, 1381789200, '20131014', list)

    print("eitb.tv: testing constructor of EitbIE\n")

# Generated at 2022-06-24 12:20:43.694609
# Unit test for constructor of class EitbIE
def test_EitbIE():
    field_names = [
        'id',
        'title',
        'description',
        'thumbnail',
        'duration',
        'timestamp',
        'tags',
        'formats',
    ]
    assert(
        all(f in EitbIE._TEST.keys() for f in field_names)
    ), "The keys of EitbIE._TEST do not agree with the expected list."
    for field in field_names:
        if not isinstance(EitbIE._TEST[field], (list, tuple)):
            continue

# Generated at 2022-06-24 12:20:44.329383
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:20:49.434926
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:51.380413
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:20:53.496881
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:21:04.056764
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST["url"] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST["md5"] == 'edf4436247185adee3ea18ce64c47998'


# Generated at 2022-06-24 12:21:13.644223
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert e._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert e._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:21:14.239901
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:21:24.441861
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.get_type() == 'Video'
    assert ie.get_id() == '4090227752001'
    assert ie.get_title() == '60 minutos (Lasa y Zabala, 30 años)'
    assert ie.get_description() == 'Programa de reportajes de actualidad.'
    assert ie.get_duration() == 3996.76
    assert ie.get_timestamp() == 1381789200


# Generated at 2022-06-24 12:21:27.060787
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIEReader = EitbIE()
    assert eitbIEReader is not None

# Generated at 2022-06-24 12:21:36.203447
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:21:40.098321
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    # Test if constant EitbIE.IE_NAME is same as IE_NAME in constructor
    assert ie.IE_NAME == ie.IE_NAME

# Generated at 2022-06-24 12:21:40.665717
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:43.283849
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:45.392582
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie is not None


# Generated at 2022-06-24 12:21:47.310325
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:21:52.941886
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE();
    assert_equals(eitb_ie.IE_NAME, 'eitb.tv')
    assert_equals(eitb_ie._VALID_URL, r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:21:53.813348
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE != None

# Generated at 2022-06-24 12:21:58.111397
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:59.038171
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:22:03.506190
# Unit test for constructor of class EitbIE
def test_EitbIE():
    request = sanitized_Request(
        'http://mam.eitb.eus/mam/REST/ServiceMultiweb/DomainRestrictedSecurity/TokenAuth/',
        headers={'Referer': None})
    assert request.headers['Referer'] is None
    assert request.get_header('Referer') is None

# Generated at 2022-06-24 12:22:04.806748
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:13.055513
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Basic tests for class EitbIE.
    """
    # EitbIE_test is the name of the class to be tested
    EitbIE_test = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    for attr in ('_VALID_URL', 'IE_NAME', '_TEST', '_real_extract'):
        assert hasattr(EitbIE_test, attr)
    return True

# Generated at 2022-06-24 12:22:14.753482
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), InfoExtractor)

# Generated at 2022-06-24 12:22:25.760926
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for page with HLS and HTTP streams
    url1 = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test1 = EitbIE()._real_extract(url1)
    assert test1['id'] == '4090227752001'
    assert test1['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert test1['description'] == 'Programa de reportajes de actualidad.'
    assert test1['timestamp'] == 1381789200.0

# Generated at 2022-06-24 12:22:38.845525
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test an instance of EitbIE
    ie = EitbIE()

    # Use:
    # from youtube_dl.utils import *
    # debug_print(ie.IE_NAME)

    # Test compatibility with YoutubeIE (above prototype)
    assert ie.suitable('mock-url') == False

# Generated at 2022-06-24 12:22:41.092530
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE()
    assert isinstance(test_EitbIE, InfoExtractor)

# Generated at 2022-06-24 12:22:44.368494
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Empty URL
    eitbIE = EitbIE(None)
    assert eitbIE._VALID_URL == EitbIE._VALID_URL
    assert eitbIE._TEST == EitbIE._TEST
    assert eitbIE.IE_NAME == EitbIE.IE_NAME
    assert eitbIE.ie_key() == EitbIE.ie_key()

# Generated at 2022-06-24 12:22:53.695725
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing for EitbIE")
    
    # Test case 1
    print("Starting Test 01")
    Test01 = EitbIE()
    Test01.IE_NAME = 'eitb.tv'
    Test01._VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:55.927868
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()



# Generated at 2022-06-24 12:23:05.757612
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _EITBIE = EitbIE()
    assert _EITBIE.IE_NAME == 'eitb.tv'
    assert _EITBIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert _EITBIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert _EITBIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:23:07.957201
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert IE.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:23:12.259730
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test
    """
    ie = EitbIE()
    ie.download('http://www.eitb.tv/eu/bideoa/60-minutotan/4090227752001/')


# Generated at 2022-06-24 12:23:23.726633
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Tests for the constructor of an instance of EitbIE
    url_Eitb = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    list_url = []
    list_url.append(url_Eitb)
    ie_Eitb = EitbIE()
    assert ie_Eitb.ie_key() == 'Eitb'
    assert ie_Eitb.suitable(list_url)
    assert ie_Eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:24.464557
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:23:33.407160
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:34.574713
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    return 0


# Generated at 2022-06-24 12:23:37.869535
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:44.615161
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Call constructor of class EitbIE
    test_class = EitbIE()
    # This should be string with name of class
    assert test_class.IE_NAME == 'eitb.tv'
    # This should be valid URL to video on eitb.tv
    assert test_class._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:55.177867
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:24:06.006627
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .jp.smilevideo import SmileVideoIE
    from .scribd import ScribdIE
    from .tdslifeway import TDSLifewayIE
    from .tritondigital import TritonDigitalIE
    from .prosiebensat1 import MySpassIE
    from .adn import ADNIE
    from .adobeconnect import AdobeConnectIE
    from .rai import RAIE
    from .rtvnh import RTVNHIE
    from .rtvdrenthe import RTVDrentheIE
    from .rtvutrecht import RTVUtrechtIE
    from .theplatform import ThePlatformIE
    from .brightcove import BrightcoveEdgeGridIE
    from .lifenews import LifeNewsIE
    from .wdr import WDRIE
    from .videopress import Vide

# Generated at 2022-06-24 12:24:14.834528
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    print(obj.IE_NAME)
    # assert that 'EitbIE' is equal to 'EitbIE'
    assert obj.IE_NAME == 'EitbIE'
    # assert that 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/' is a valid URL
    assert obj._VALID_URL == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'


# Generated at 2022-06-24 12:24:20.044735
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Some test url
    url = "http://www.eitb.tv/es/video/gaztetxe/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    # Instance of class EitbIE with the test url
    eitbie = EitbIE(url)
    # Test method real_extract
    eitbie._real_extract(url)

# Generated at 2022-06-24 12:24:21.436409
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()

# Generated at 2022-06-24 12:24:32.700432
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is True
    assert ie.suitable('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is True
    assert ie.suitable('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001') is False

# Generated at 2022-06-24 12:24:33.230938
# Unit test for constructor of class EitbIE
def test_EitbIE():
	pass

# Generated at 2022-06-24 12:24:34.351514
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE({}), InfoExtractor)

# Generated at 2022-06-24 12:24:38.765244
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
   

# Generated at 2022-06-24 12:24:41.950152
# Unit test for constructor of class EitbIE
def test_EitbIE():
    constructor_test(EitbIE, ['http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'])

# Generated at 2022-06-24 12:24:53.271152
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    #mock_urlopen
    mock_urlopen = mock.MagicMock(side_effect=[
        "JSON_DATA_FOR_VIDEO_4090227752001",
        "JSON_DATA_FOR_VIDEO_4090227752001_HDS_URL",
        "JSON_DATA_FOR_VIDEO_4090227752001_HLS_URL",
        "JSON_DATA_FOR_VIDEO_4090227752001_HDS_PLAYLIST",
        "JSON_DATA_FOR_VIDEO_4090227752001_HLS_PLAYLIST",
    ])
    #

# Generated at 2022-06-24 12:24:55.266092
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE({}, {})
    assert isinstance(ie._VALID_URL, str)

# Generated at 2022-06-24 12:25:03.658906
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiate it with a valid url
    eitb = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    # Check that media id is valid
    assert eitb._match_id('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') == '4090227752001'
    # Check that EITB's media id is found in the URL

# Generated at 2022-06-24 12:25:10.487385
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert not hasattr(EitbIE, '_download_webpage_handle')
    assert not hasattr(EitbIE, '_download_xml')
    assert not hasattr(EitbIE, '_download_json')
    assert not hasattr(EitbIE, '_download_webpage')
    assert not hasattr(EitbIE, '_html_search_regex')
    assert not hasattr(EitbIE, '_get_login_info')
    assert not hasattr(EitbIE, '_NETRC_MACHINE')
    assert not hasattr(EitbIE, '_search_regex')
    assert not hasattr(EitbIE, '_VALID_URL')
    assert not hasattr(EitbIE, '_download_webpage_handle')

# Generated at 2022-06-24 12:25:15.151493
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import re
    assert EitbIE._VALID_URL == re.compile(
        r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    )

# Generated at 2022-06-24 12:25:18.518882
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:25.162817
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor of class EitbIE
    ie = EitbIE()

    # Set "EitbIE._VALID_URL"
    ie._VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    # Check "EitbIE._VALID_URL"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:30.817961
# Unit test for constructor of class EitbIE
def test_EitbIE():
    module_name = 'eitb'
    EitbIE_class = globals()[module_name + 'IE']
    assert EitbIE_class.IE_NAME == module_name
    assert EitbIE_class.__name__ == module_name + 'IE'
    assert 'Youtube' in dir(EitbIE_class)

# Generated at 2022-06-24 12:25:38.476778
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    expected_key = '4090227752001'
    expected_title = '60 minutos (Lasa y Zabala, 30 años)'

    eitb_ie = EitbIE()
    video_id = eitb_ie._match_id(url)
    info_dict = eitb_ie._real_extract(url)

    assert video_id == expected_key
    assert info_dict['title'] == expected_title

# Generated at 2022-06-24 12:25:39.760886
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test that the EitbIE constructor works.
    """
    ie = EitbIE("test")

# Generated at 2022-06-24 12:25:40.748080
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-24 12:25:43.839709
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:25:48.781199
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test with the test URL of the class
    _VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    EitbIE()._real_extract(EitbIE._TEST['url']);

# Generated at 2022-06-24 12:25:56.873075
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    video_info = test._real_extract(
        EitbIE._TEST['url']
    )
    assert video_info['id'] == '4090227752001'
    assert video_info['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert video_info['description'] == 'Programa de reportajes de actualidad.'
    assert video_info['duration'] == 3996.76
    assert video_info['timestamp'] == 1381789200
    assert video_info['upload_date'] == '20131014'
    assert video_info['tags'] == ['60 minutos', 'Gaztea', 'Made in Euskadi']
    assert len(video_info['formats']) >= 4

# Generated at 2022-06-24 12:26:02.960660
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    # Bool check
    assert eitb_ie._downloader is None
    assert eitb_ie._working_dir_is_creation_time is True
    # String check
    assert eitb_ie._WORKING_DIR_BASE == 'youtube-dl'
    assert eitb_ie.DEFAULT_OUTTMPL == '%(title)s-%(id)s.%(ext)s'
    assert eitb_ie._TEMP_FILENAME_TEMPLATE == '%(id)s-%(uploader)s-%(title)s.%(ext)s'
    assert eitb_ie._LANG_URL_TEMPLATE == 'http://www.youtube.com/set_flash_lang?ln=%s'

# Generated at 2022-06-24 12:26:13.143542
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Here we will test that class EitbIE is importing
    test = EitbIE('Class test')
    # Here we will test that class EitbIE has 4 attributes
    assert test.IE_NAME == 'eitb.tv'
    assert test._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert len(test._TEST) == 3
    assert test._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert test

# Generated at 2022-06-24 12:26:14.717690
# Unit test for constructor of class EitbIE
def test_EitbIE():
    cls = EitbIE(InfoExtractor())

