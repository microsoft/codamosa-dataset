

# Generated at 2022-06-24 12:16:12.806191
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for constructor of class EitbIE
    ie=EitbIE()
    pass

# Generated at 2022-06-24 12:16:13.662624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE({}) is not None

# Generated at 2022-06-24 12:16:23.721954
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    info = ie.extract(url)
    assert len(info) > 0

# Generated at 2022-06-24 12:16:30.088391
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Input parameters to constructor of class EitbIE
    EitbIE()


# Generated at 2022-06-24 12:16:31.982330
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb



# Generated at 2022-06-24 12:16:38.816816
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.extractor_key == 'EitbTV'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:42.961525
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:16:43.863487
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # instantiate class
    EitbIE()

# Generated at 2022-06-24 12:16:50.416224
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Test EitbIE class constructor
	# The test video is from http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/
	assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
	
	# Test EITB video extracting

# Generated at 2022-06-24 12:16:52.045071
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:16:52.607080
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:57.270218
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE('http://www.eitb.tv/eu/bideoa/zure-aplikazioa-adibide-berri-bati-egin-gaituzu/4104994983001/')
    assert e.name == 'EitbIE'

# Generated at 2022-06-24 12:17:06.674453
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test 1
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    # Test 2
    ie = EitbIE()
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

    # Test 3
    ie = EitbIE()
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Unit

# Generated at 2022-06-24 12:17:13.999999
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.name == 'EitbIE'
    assert eitb.ie_key() == 'Eitb'
    assert eitb.ie_name() == 'Eitb'
    assert eitb.is_suitable('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:17:16.294401
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(
        InfoExtractor())._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:17:17.489397
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:17:19.069601
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert isinstance(eitb, InfoExtractor)

# Generated at 2022-06-24 12:17:29.797844
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_cases = [
        ('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', True),
        ('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos', False),
    ]

    for (url, expected_result) in test_cases:
        if expected_result:
            assert EitbIE._VALID_URL in EitbIE._VALID_URL(url)
        else:
            assert EitbIE._VALID_URL

# Generated at 2022-06-24 12:17:35.958444
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:38.855175
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    

# Generated at 2022-06-24 12:17:42.191508
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/es/video/60-minutos/168817/2013-05-26/'
    eitbie = EitbIE(url)
    eitbie._real_extract(url)

# Generated at 2022-06-24 12:17:45.594102
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == "eitb.tv"
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:56.803180
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for constructor of class EitbIE
    """
    sut = EitbIE()
    expected = {
        'IE_NAME': 'eitb.tv',
        '_VALID_URL': r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'}
    # Check that sut is an instance of EitbIE
    assert isinstance(sut, EitbIE)
    # Check that mut is an instance of InfoExtractor
    assert isinstance(sut, InfoExtractor)
    # Check that sut has the expected parameters
    assert sut.__dict__ == expected

# Generated at 2022-06-24 12:18:05.150635
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:18:05.878467
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE({})

# Generated at 2022-06-24 12:18:15.391491
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from ..utils import (
        float_or_none,
        int_or_none,
        parse_iso8601,
        sanitized_Request,
    )
    from .eitb import EitbIE
    from . import tests
    import unittest

    class TestEitbIE(object):
        def test_eitb(self):
            #assert(False)

            video_id = 4104995148001
            url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
            md5 = 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:18:20.131509
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()
    assert EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-Gaurko-bideoa/3799083143001/4104995025001/dokumentala-nazioarteko-premioa-lortu-du/')

# Generated at 2022-06-24 12:18:22.473409
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:18:24.140594
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:30.943084
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE(InfoExtractor())
    assert eitbie.IE_NAME == 'eitb.tv'
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:18:41.672864
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Run the test with valid url
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    assert ie.IE_NAME == 'EitbTV'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:43.616766
# Unit test for constructor of class EitbIE
def test_EitbIE():
    actual_class = EitbIE
    expected_class = EitbIE
    assert expected_class == actual_class


# Generated at 2022-06-24 12:18:45.430845
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.name == 'eitb.tv'



# Generated at 2022-06-24 12:18:46.215434
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() != None;

# Generated at 2022-06-24 12:18:47.615995
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:55.483098
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC == 'eitb.tv'


# Generated at 2022-06-24 12:19:01.099160
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995142001/4090227752001/lasa-y-zabala-30-anos/')
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:08.964073
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:19:10.809632
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE(None)
    except:
        pass

# Generated at 2022-06-24 12:19:11.235269
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:19:13.114355
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except Exception as e:
        print(e)
        return False
    return True


# Generated at 2022-06-24 12:19:14.994255
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
        assert True
    except:
        assert False

# Test for extracting url from webpage

# Generated at 2022-06-24 12:19:22.042134
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # To get last test: http://www.eitb.tv/eu/bideoa/the-fray/4104994629001/4104994824001/
    url = 'http://www.eitb.tv/eu/bideoa/the-fray/4104994629001/4104994824001/'
    eitbie = EitbIE()
    info_dict = eitbie.extract(url)
    print (info_dict)
    # print (info_dict['formats'])
    # assert(len(info_dict['formats']) > 1)
    # assert('http://mam.eitb.eus/mam/multimedia/akamai/eitb_web/' in repr(info_dict['formats']) )
    
# Test for

# Generated at 2022-06-24 12:19:28.693526
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', '4090227752001')

# Generated at 2022-06-24 12:19:29.588176
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:19:40.077415
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE('http://www.eitb.tv/eu/bideoa/13-11-03/SUDOKUA/4104995148001') != None)
    assert(EitbIE('http://www.eitb.tv/eu/bideoa/13-11-03/SUDOKUA/4104995148001') != None)
    assert(EitbIE('http://www.eitb.tv/eu/bideoa/13-11-03/SUDOKUA/4104995148001') != None)
    assert(EitbIE('http://www.eitb.tv/eu/bideoa/13-11-03/SUDOKUA/4104995148001') != None)

# Generated at 2022-06-24 12:19:41.240536
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:19:43.326304
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()

# Generated at 2022-06-24 12:19:49.747305
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert_equal(ie.IE_NAME, ie.ie_key())
    assert_equal('eitb.tv', ie.ie_key())
    assert_equal(ie.ie_key(), ie.ie_key())
    assert_equal('eitb.tv', ie.ie_key())

# Generated at 2022-06-24 12:19:53.025107
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert EitbIE()._VALID_URL
        assert EitbIE.IE_NAME
        assert EitbIE._TEST
    except AttributeError:
        raise AssertionError("Not all class attributes are set")

# Generated at 2022-06-24 12:19:53.659884
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:20:00.888300
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # A class to test the creation of EitbIE
    class MockEitbIE(EitbIE):
        pass

    mock_eitb_ie = MockEitbIE({})
    mock_eitb_ie.ie_key = 'EitbIE'
    mock_eitb_ie.ie_name = 'EitbIE'
    mock_eitb_ie.ie_version = '0'

    assert mock_eitb_ie.ie_key == 'EitbIE'
    assert mock_eitb_ie.ie_name == 'EitbIE'
    assert mock_eitb_ie.ie_version == '0'

# Generated at 2022-06-24 12:20:02.722690
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:20:06.382639
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:20:12.592531
# Unit test for constructor of class EitbIE
def test_EitbIE():
    request = sanitized_Request(
                                 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/DomainRestrictedSecurity/TokenAuth/',
                                 headers={'Referer': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'})
    token_data = self._download_json(request, '4090227752001', 'Downloading auth token', fatal=False)

# Generated at 2022-06-24 12:20:14.282353
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:15.887319
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-24 12:20:18.746668
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()._real_extract('http://www.eitb.tv/eu/bideoa/garoa/4104995148001/4090289733001/txapeldunak/')

# Generated at 2022-06-24 12:20:22.332983
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()
	assert eitb != None

# Generated at 2022-06-24 12:20:23.216864
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:20:24.222425
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-24 12:20:32.188499
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Check if fields are properly initialized
    assert eitb._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert eitb._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'


# Generated at 2022-06-24 12:20:33.747023
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, None)

# Generated at 2022-06-24 12:20:37.598204
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple test for creation of class EitbIE
    """
    EitbIE(None)


if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:20:43.043364
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(_VALID_URL).ie_key() == 'Eitb'

# Generated at 2022-06-24 12:20:45.487619
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_TEST = InfoExtractor(EitbIE.ie_key())
    assert IE_TEST.IE_NAME == 'eitb.tv'
    assert IE_TEST._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-24 12:20:48.237596
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:49.720513
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:20:51.099469
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:02.995971
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/eu/bideoak/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

    # Test base attributes
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC == 'Videoak | eitb.eus'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    # Test first test case
    test_case = ie._TEST
    url = test_case.get('url')


# Generated at 2022-06-24 12:21:11.246817
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_values = {
        'name': 'EitbIE',
        'ie_key': 'EitbIE',
        'expected_results': [
            {
                'url': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
                'only_matching': True,
            },
            {
                'url': 'http://www.eitb.tv/eu/bideoa/nire-bideoak/4104995148001/2008733760001/txoriaren-hizkuntzakolokia/',
                'only_matching': True,
            },
        ]

    }

# Generated at 2022-06-24 12:21:12.243682
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL

# Generated at 2022-06-24 12:21:14.037892
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_ = EitbIE()
    print(test_._VALID_URL)


# Generated at 2022-06-24 12:21:22.530529
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('EitbIE', 'eitb.tv', 'eitb.tv')
    eitbIE.suitable('http://www.eitb.tv/eu/grid/bideoak/eitb-videoak/1/128/')
    eitbIE._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:21:27.046980
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:21:28.645368
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()


# Generated at 2022-06-24 12:21:39.291779
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.suitable('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert EitbIE.suitable('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:21:40.190413
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:21:41.536227
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    test_IE(ie)

# Generated at 2022-06-24 12:21:44.352476
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    query = ie.ie_key()
    # Test if the name of constructor of class EitbIE is EitbIE
    assert query == 'EitbIE', 'The name of constructor of class EitbIE is EitbIE'

# Generated at 2022-06-24 12:21:52.493159
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import check_invalid_params

# Generated at 2022-06-24 12:21:57.161057
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME ==  'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:03.977924
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test 1: URL with valid video_id
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._match_id(EitbIE._VALID_URL, url) == '4090227752001'



# Generated at 2022-06-24 12:22:08.115285
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:22:16.454583
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE("http://www.eitb.tv/es/video/", "60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert(IE.get_name() == 'EitbIE')
    assert(IE.get_url() == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert(IE.get_id() == "4090227752001")
    assert(IE.get_real_id() == "4090227752001")

# Generated at 2022-06-24 12:22:27.701033
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .data_downloader import DataDownloader
    from .common import InfoExtractor
    from .common import DownloadContext
    from .common import ExtractorError
    from .common import orderedSet
    from .common import FileDownloader
    from .common import _parse_jwp_pl
    from .extractor import get_info_extractor
    from .youtube_dl.utils import DownloadError
    from .youtube_dl.JsInterpreter import JsInterpreter
    from .youtube_dl.jsinterp import PyJsHoistException
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_http_client


# Generated at 2022-06-24 12:22:33.302928
# Unit test for constructor of class EitbIE
def test_EitbIE():
    parser = EitbIE()
    assert parser.IE_NAME == 'eitb.tv'
    assert parser._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:22:43.922921
# Unit test for constructor of class EitbIE
def test_EitbIE():
    testcode = 'test' + 'code'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    downloader = EitbIE()
    with open(downloader.IE_NAME + '.py') as f:
        assert testcode in f.read()
    assert hasattr(downloader, '_download_json')
    assert downloader._match_id(url) == '4090227752001'
    assert hasattr(downloader, '_real_extract')
    assert hasattr(downloader, '_download_webpage')

# Generated at 2022-06-24 12:22:49.439756
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert(ie.ie_key() == 'Eitb')
    assert(ie.ie_name() == 'eitb.tv')

# Generated at 2022-06-24 12:22:55.338770
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:22:59.770983
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import expected, test_constructor
    test_constructor(EitbIE, expected)

# Generated at 2022-06-24 12:23:05.511290
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Test the EitbIE constructor
    info_extractor = EitbIE()

    # Check if the id of the ie is set correctly
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:11.729895
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE(None, None, None)
    IE = EitbIE(None, {'url': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'}, None)

# Generated at 2022-06-24 12:23:17.751003
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:18.341562
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, None)

# Generated at 2022-06-24 12:23:27.084375
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'
    assert eitbie.VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitbie.TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert eitbie.TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:23:36.186629
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:41.883480
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb = EitbIE()
    _, info = eitb._extract_info(url)
    assert 'web_media' in info
    assert 'RENDITIONS' in info['web_media'][0]


# Generated at 2022-06-24 12:23:47.022482
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitbIE._TEST



# Generated at 2022-06-24 12:23:50.973559
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == 'eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:55.303720
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:56.424468
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('anyurl')

# Generated at 2022-06-24 12:24:02.915700
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    print(ie.IE_NAME)
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    print(ie._VALID_URL)


# Generated at 2022-06-24 12:24:11.726674
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_ie_obj = EitbIE()
    assert eitb_ie_obj._VALID_URL == eitb_ie_obj._TEST['url']
    assert eitb_ie_obj.IE_NAME == 'eitb.tv'
    assert eitb_ie_obj._match_id(url) == '4090227752001'
    for regex in ['_VALID_URL', '_TEST']:
        assert regex in EitbIE.__dict__

# Generated at 2022-06-24 12:24:15.872312
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst.ie_key() == "EitbIE"


if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:24:19.614760
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_video = EitbIE("https://www.eitb.tv/eu/bideoa/", "https://www.eitb.tv/eu/bideoa/")
    eitb_video.extract(
    "https://www.eitb.tv/eu/bideoa/")

# Generated at 2022-06-24 12:24:20.639045
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-24 12:24:21.886898
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:24:24.396824
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:24:27.986120
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Testing constructor
    # Note: This class is just a simple derived class containing
    #       an information extractor, so that constructor needs
    #       to inherit from the parent class (InfoExtractor)
    assert issubclass(EitbIE, InfoExtractor)

# Generated at 2022-06-24 12:24:30.513012
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.ie_key() == 'eitb.tv'

# Generated at 2022-06-24 12:24:33.344549
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE([]);

# Generated at 2022-06-24 12:24:38.491297
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    info_dict = ie._real_extract(ie._VALID_URL)
    desc = 'Programa de reportajes de actualidad.'
    assert info_dict['description'] == desc


# Generated at 2022-06-24 12:24:43.903362
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Using example from eitb.tv
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE()._real_extract(url)


# Generated at 2022-06-24 12:24:45.318888
# Unit test for constructor of class EitbIE
def test_EitbIE():
  EitbIE()


# Generated at 2022-06-24 12:24:46.690731
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE == EitbIE()

# Generated at 2022-06-24 12:24:47.813908
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('EitbIE')

# Generated at 2022-06-24 12:24:48.526081
# Unit test for constructor of class EitbIE
def test_EitbIE():
    tester = EitbIE()

# Generated at 2022-06-24 12:24:53.598472
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test 1
    obj1 = EitbIE()
    obj1.ie_key()

    # Test 2
    obj2 = EitbIE(ie=obj1)
    obj2.ie_key()

    return True
# End of test for constructor of class EitbIE



# Generated at 2022-06-24 12:25:02.587822
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = EitbIE()._real_extract(EitbIE._TEST['url'])
    assert url['id'] == EitbIE._TEST['info_dict']['id']
    assert url['title'] == EitbIE._TEST['info_dict']['title']
    assert url['description'] == EitbIE._TEST['info_dict']['description']
    assert url['duration'] == EitbIE._TEST['info_dict']['duration']
    assert url['timestamp'] == EitbIE._TEST['info_dict']['timestamp']
    assert url['upload_date'] == EitbIE._TEST['info_dict']['upload_date']
    assert url['tags'] == EitbIE._TEST['info_dict']['tags']

# Generated at 2022-06-24 12:25:05.213119
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert hasattr(EitbIE(), '_WORKING')
# Check that object still exists

# Generated at 2022-06-24 12:25:15.188699
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert EitbIE._TEST['info_dict']['id'] == '4090227752001'
    assert EitbIE._TEST

# Generated at 2022-06-24 12:25:23.782593
# Unit test for constructor of class EitbIE
def test_EitbIE():
    valid_url = "http://www.eitb.tv/eu/bideoa/txapeldunak/Aitzol-Aspiazu/4099781407001/"
    expected_title = "Aitzol Aspíazu: \"Xabi Alonso no merece ir a la cárcel\""

    eitb_ie = EitbIE(valid_url)
    assert eitb_ie.IE_NAME == "eitb.tv"
    assert eitb_ie.valid_url(valid_url) == True
    assert eitb_ie.extract_video_info(valid_url).title == expected_title
    assert eitb_ie.extract_video_info(valid_url).timestamp == 1434641600

# Generated at 2022-06-24 12:25:34.365273
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Create a instance of EitbIE class
	eitbIE = EitbIE()

	# Test class name
	assert eitbIE.IE_NAME == 'eitb.tv'

	# Test the _VALID_URL
	assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

	# Test the test: 'md5': 'edf4436247185adee3ea18ce64c47998'
	assert eitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

	# Test the test: 'id': '4090227752001'

# Generated at 2022-06-24 12:25:38.213729
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test that the constructor returns an instance of EitbIE
    ie = EitbIE(None)
    assert ie is not None
    if hasattr(ie, '_download_webpage') and ie._download_webpage is not None:
        assert ie._download_webpage is not None

# Generated at 2022-06-24 12:25:39.222313
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print (EitbIE())

# Generated at 2022-06-24 12:25:42.712618
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert EitbIE()
    except:
        assert 0, "Error on attempt to create the object EitbIE"
    assert 1


# Generated at 2022-06-24 12:25:44.906837
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test the constructor of class EitbIE
    assert EitbIE(EitbIE._VALID_URL) is not None

# Generated at 2022-06-24 12:25:47.111263
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.suitable('http://eitb.tv/eu/bideoa/5109182/5109182/')

# Generated at 2022-06-24 12:25:52.631695
# Unit test for constructor of class EitbIE
def test_EitbIE():

    eitb_ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    print("EitbIE: " + str(eitb_ie))

    assert eitb_ie != None


# Generated at 2022-06-24 12:25:53.861387
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Minimum test to instantiate class
    EitbIE()



# Generated at 2022-06-24 12:25:57.815830
# Unit test for constructor of class EitbIE
def test_EitbIE():
  eitb_ie = EitbIE({}, {}, None)
  assert eitb_ie is not None

if __name__ == '__main__':
  test_EitbIE()

# Generated at 2022-06-24 12:25:59.133983
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() is not None


# Generated at 2022-06-24 12:26:09.497319
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert_equal(eitbIE.IE_NAME, 'eitb.tv')
    assert_equal(eitbIE._VALID_URL, r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:26:14.433908
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # The constructor of class InfoExtractor
    ie = InfoExtractor (None)

    # The constructor of class EitbIE
    eitb = EitbIE(ie)

    # Test to see if instance of EitbIE
    assert isinstance(eitb, EitbIE)
