

# Generated at 2022-06-24 12:16:20.547408
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test for the constructor of class EitbIE
    """
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:16:21.220089
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:16:30.496702
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create an instance of EitbIE
    EitbIETest = EitbIE(None)
    assert (EitbIETest.IE_NAME == 'eitb.tv')
    assert (EitbIETest._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert (EitbIETest._TESTS[0]['url'] == 'http://www.eitb.tv/eu/bideoa/media/urtea-atzo-etorri-da/4848019626001/4848019626001/')

# Generated at 2022-06-24 12:16:33.494029
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:16:39.193732
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Tests for http://www.eitb.tv/eu/bideoa/59-minutuak/4110875087001/martxa-bide-bat-zuzenean-behin-etorri-on/
    eitb_ie = EitbIE(EitbIE.IE_NAME, 'http://www.eitb.tv/eu/bideoa/59-minutuak/4110875087001/martxa-bide-bat-zuzenean-behin-etorri-on/')
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_

# Generated at 2022-06-24 12:16:42.010736
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Basic test for constructor of class EitbIE
    # Test a concrete URL
    url = EitbIE(EitbIE._TEST.get('url'))._url
    # Test that constructor returns the same url
    assert url == EitbIE._TEST.get('url')

# Generated at 2022-06-24 12:16:45.473693
# Unit test for constructor of class EitbIE
def test_EitbIE():
    example_url = 'http://www.eitb.tv/eu/bideoa/zuzenean/zuzenean-2014-15/4099794094001/4097690193001/vaya-migajas/'
    ie = EitbIE(example_url)
    assert ie != None

# Generated at 2022-06-24 12:16:49.515279
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:00.302635
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:08.343871
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert_true(eitbie is not None)
    assert_equal(eitbie.ie_key(), 'Eitb')
    assert_equal(eitbie.ie_name(), 'Eitb')
    assert_equal(eitbie._VALID_URL, r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')



# Generated at 2022-06-24 12:17:11.766126
# Unit test for constructor of class EitbIE
def test_EitbIE():
     try:
          assert(EitbIE)
          print("EitbIE test passed!")
     except AssertionError:
          print("EitbIE test failed!")


# Generated at 2022-06-24 12:17:20.710411
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    id = '4090227752001'
    assert '/eu/bideoa/4090227752001/' in ie._real_extract(url='http://www.eitb.tv/eu/bideoa/4090227752001/')['id']
    assert id in ie._real_extract(url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')['id']

# Generated at 2022-06-24 12:17:22.881442
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:17:24.423313
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-24 12:17:27.793115
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of class EitbIE.

    Please note that this test has to be run with some valid data
    """
    EitbIE('test', 'http://eitb.tv')

# Generated at 2022-06-24 12:17:29.512308
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:30.048614
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:17:31.815403
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    

# Generated at 2022-06-24 12:17:36.631509
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Create an instance of EitbIE.
    """
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE()(url)



# Generated at 2022-06-24 12:17:40.233513
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:41.463347
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:44.424898
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL is not None

# Generated at 2022-06-24 12:17:46.967848
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:17:52.448492
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE().to_screen("http://www.eitb.tv/eu/bideoa/deportes/20131026/deportes-gipuzkoa/1202783/zinemaldia-gipuzkoan-sailaren/")

# Generated at 2022-06-24 12:17:53.166977
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE({}), EitbIE)

# Generated at 2022-06-24 12:17:55.367606
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:04.114199
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:04.767988
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:05.521027
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-24 12:18:06.111347
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:18:07.098256
# Unit test for constructor of class EitbIE
def test_EitbIE():
    global ie
    ie = EitbIE()

# Generated at 2022-06-24 12:18:16.265282
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IEInstance = EitbIE()
    IEInstance.ie_key()
    IEInstance.ie_name()
    IEInstance.ie_build()
    assert IEInstance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:19.439271
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-24 12:18:24.490454
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:26.419346
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE('EitbIE'), EitbIE)


# Generated at 2022-06-24 12:18:28.523217
# Unit test for constructor of class EitbIE
def test_EitbIE():
    res = EitbIE()
    assert isinstance(res, EitbIE)

# Generated at 2022-06-24 12:18:36.364624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4090227752001'
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE(test_EitbIE)._test_url(url,video_id)
    #EitbIE()._test_url(url,video_id)

# Generated at 2022-06-24 12:18:43.078755
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/tk/4104990611001/4087802277001/titulares/")
    info = ie.extract("The Title")
    assert info["id"] == "4087802277001"
    assert info["title"] == "The Title"
    assert info["url"] == "http://www.eitb.tv/es/video/tk/4104990611001/4087802277001/titulares/"

# Generated at 2022-06-24 12:18:49.623169
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:52.849729
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        assert False, "EitbIE could not be created."


# Generated at 2022-06-24 12:18:56.641111
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.suitable('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert not EitbIE.suitable('foo-bar')
    assert EitbIE() is not None

# Generated at 2022-06-24 12:18:57.931015
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-24 12:19:03.305648
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb_ie.ie_key() == 'Eitb'

# Generated at 2022-06-24 12:19:04.157177
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL is not None

# Generated at 2022-06-24 12:19:06.804517
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_obj = EitbIE('eitb.tv', {}, {}, False)
    assert(ie_obj.IE_NAME == "eitb.tv")
    assert(ie_obj.ie_key() == "eitb.tv")

# Generated at 2022-06-24 12:19:10.809184
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:17.450363
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .eitb import EitbIE
    from .common import InfoExtractor
    from ..utils import (
        float_or_none,
        int_or_none,
        parse_iso8601,
        sanitized_Request,
    )

    def _real_extract(self, url):
        video_id = self._match_id(url)

        video = self._download_json(
            'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % video_id,
            video_id, 'Downloading video JSON')

        media = video['web_media'][0]

        formats = []
        for rendition in media['RENDITIONS']:
            video_url = rendition.get('PMD_URL')


# Generated at 2022-06-24 12:19:19.103839
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.ie_key() == 'Eitb'

# Generated at 2022-06-24 12:19:21.828428
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL is not None
    assert ie._TEST is not None

# Generated at 2022-06-24 12:19:23.197196
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert isinstance(e, EitbIE)

# Generated at 2022-06-24 12:19:34.067464
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/');
    # Test URL
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Test ID

# Generated at 2022-06-24 12:19:38.608354
# Unit test for constructor of class EitbIE
def test_EitbIE():
    input= 'http://www.eitb.tv/eu/bideoa/programak/erreportajea/bideo-ONLINE/613059/'
    ie= InfoExtractor.IE_NAME_MAP[EitbIE.IE_NAME].constructor(input)
    assert ie.url == input

# Generated at 2022-06-24 12:19:41.546897
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('', {}, False)
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:19:52.346790
# Unit test for constructor of class EitbIE
def test_EitbIE():
  url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
  from youtube_dl.YoutubeDL import YoutubeDL
  from youtube_dl.compat import compat_urllib_request
  with YoutubeDL(url) as ydl:
    # Proxy handling
    proxy_handler = compat_urllib_request.ProxyHandler({'http': '4.4.4.4:80'})
    opener = compat_urllib_request.build_opener(proxy_handler)
    compat_urllib_request.install_opener(opener)
    # Constructor of class InfoExtractor
    ydl.add_info_ext

# Generated at 2022-06-24 12:19:53.712507
# Unit test for constructor of class EitbIE
def test_EitbIE():
	#Testing if the object EitbIE is created
	assert EitbIE

# Generated at 2022-06-24 12:19:55.241238
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE(None)
    assert obj is not None

# Generated at 2022-06-24 12:19:56.040871
# Unit test for constructor of class EitbIE
def test_EitbIE():
    tester = EitbIE()

# Generated at 2022-06-24 12:19:59.124927
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/aurrera-aurrera/4090034226001/')
    assert ie is not None

# Generated at 2022-06-24 12:20:02.891219
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('EitbIE')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:20:06.562660
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:08.245212
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    eitbie = InfoExtractor(EitbIE)
    assert eitbie

# Generated at 2022-06-24 12:20:09.269363
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb is not None

# Generated at 2022-06-24 12:20:16.547221
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_NAME = 'eitb.tv'
    _VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    ie = EitbIE(IE_NAME, _VALID_URL)
    assert ie.ie_key() == IE_NAME
    assert ie._VALID_URL == _VALID_URL
    assert ie.IE_NAME == IE_NAME

# Generated at 2022-06-24 12:20:19.299192
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)
    ie.download()

# test_EitbIE()

# Generated at 2022-06-24 12:20:30.439584
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

    assert(ie.get_IE_NAME() == 'eitb.tv')
    assert(ie.get_VALID_URL() == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:20:33.844848
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('tt13309818', 'iLyROoafY6Xn', 'yt-dl testing video', '43')

# Generated at 2022-06-24 12:20:44.010689
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:47.193111
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert(eitb_ie is not None)

# Generated at 2022-06-24 12:20:53.312252
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos-0/4104995522001/4090227752001/lasa-y-zabala-30-anos/")
    # Test case 1
    assert(ie.IE_NAME == "eitb.tv")
    # Test case 2
    assert(ie._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)")
    # Test case 3

# Generated at 2022-06-24 12:20:55.533961
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    # Create an instance of the class to be tested
    eitb = EitbIE()
    return eitb

# Generated at 2022-06-24 12:21:05.754066
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _eitbIE = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert _eitbIE.IE_NAME == 'eitb.tv'
    assert _eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:06.447917
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# constructor
	test_object = EitbIE()

# Generated at 2022-06-24 12:21:18.316549
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/hong-kong-2013/4104995148001/4089957208001/los-espirituales/"
    eitb_ie = EitbIE()
    extracted = eitb_ie.extract(url)
    # this assert provides a general test for all the class
    assert isinstance(eitb_ie, InfoExtractor)
    # this assert makes sure this test is for this particular class
    assert isinstance(eitb_ie, EitbIE)
    # this assert provides test for the eitb's domain
    assert extracted.get("domain", False) == "www.eitb.tv"
    # this assert provides test for the eitb's id

# Generated at 2022-06-24 12:21:19.432577
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)


# Generated at 2022-06-24 12:21:20.456307
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE("EitbIE")

# Generated at 2022-06-24 12:21:25.089882
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()
	print(ie)

# Generated at 2022-06-24 12:21:26.503133
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE != None


# Generated at 2022-06-24 12:21:27.375356
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:36.136967
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import sys
    import pytest

# Generated at 2022-06-24 12:21:41.076192
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE()._VALID_URL == 'http://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)$')


# Generated at 2022-06-24 12:21:42.502236
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:46.492131
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:53.250382
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test for constructor of class EitbIE
    """
    test_eitb_ie = EitbIE()
    assert test_eitb_ie.IE_NAME == 'eitb.tv'
    assert test_eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:21:54.821570
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(mock.Mock()).extract(mock.Mock())

# Generated at 2022-06-24 12:21:56.235140
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    assert isinstance(info_extractor, EitbIE)

# Generated at 2022-06-24 12:22:01.327778
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert isinstance(
		EitbIE({}),
		EitbIE,
		"Constructor of EitbIE class should return class instance"
	)

# Unit tests for _real_extract method of class EitbIE

# Generated at 2022-06-24 12:22:03.210849
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'



# Generated at 2022-06-24 12:22:05.740865
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test an example URL of EitbIE.
    assert 'This is a Test' in EitbIE._test()['description']

# Generated at 2022-06-24 12:22:07.632357
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)


# Generated at 2022-06-24 12:22:16.199235
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Necesary to test the constructor of EitbIE.
    """
    test_class = EitbIE()
    test_class._downloader = DummyDownloader()
    test_class._downloader.teststreams = [DummyDownloader()]

# Generated at 2022-06-24 12:22:18.360867
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (
        EitbIE()._VALID_URL ==
        EitbIE._VALID_URL)

# Generated at 2022-06-24 12:22:19.525393
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()

# Generated at 2022-06-24 12:22:30.077359
# Unit test for constructor of class EitbIE
def test_EitbIE():
    example_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video = EitbIE()._real_extract(example_url)

    assert video['id'] == '4090227752001'
    assert video['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert video['description'] == 'Programa de reportajes de actualidad.'
    assert video['duration'] == 3996.76
    assert video['timestamp'] == 1381789200
    assert video['upload_date'] == '20131014'
    assert len(video['tags']) == 5

# Generated at 2022-06-24 12:22:35.228895
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('[constructor of class EitbIE]')
    obj = EitbIE()
    print(obj)
    assert obj.IE_NAME == 'eitb.tv'
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    print('\n')


# Generated at 2022-06-24 12:22:36.841983
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    print(eitb_ie)

# Generated at 2022-06-24 12:22:39.033569
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor  = EitbIE()


if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:22:44.598236
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i.IE_NAME == 'eitb.tv'
    assert i._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:51.192283
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert isinstance(eitb_ie, InfoExtractor)
    assert eitb_ie.ie_key() == 'EitbIE'
    assert eitb_ie.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/').get('id') == '4090227752001'

# Generated at 2022-06-24 12:22:52.768938
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()
    EitbIE('test')
    EitbIE(IE_NAME='test')


# Generated at 2022-06-24 12:22:54.901291
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_eitb = EitbIE()

# Generated at 2022-06-24 12:22:59.769915
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    assert info_extractor.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:01.276840
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("None")
    ie = EitbIE("None", "None")

# Generated at 2022-06-24 12:23:02.470888
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-lasak-eta-zabalak-30-urtez/4090227752001/')

# Generated at 2022-06-24 12:23:03.097861
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:23:06.328041
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:23:14.393000
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/news/detail/4444333/')
    expected_url = 'http://www.eitb.tv/eu/bideoa/news/detail/4444333/'
    if ie.url != expected_url: raise Exception('Unexpected URL: %s' % ie.url)
    if ie.video_id != expected_url: raise Exception('Unexpected video id: %s' % ie.video_id)

# ----------------------------------------------------------------------

# Generated at 2022-06-24 12:23:21.332021
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test_check_IE = EitbIE(test_url, False)    
    assert (test_check_IE.IE_NAME == 'eitb.tv')


# Generated at 2022-06-24 12:23:26.074029
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:23:28.926962
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #class EitbIE(InfoExtractor)
    assert EitbIE(None, None).IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:23:30.308700
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == "EitbIE"

# Generated at 2022-06-24 12:23:38.290622
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:23:48.953257
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4090227752001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb._match_id(url) == video_id


# Generated at 2022-06-24 12:23:50.384371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiate EitbIE class
    EitbIE()

# Generated at 2022-06-24 12:23:51.417336
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:23:56.323315
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"
    assert ie.ie_key() == 'Eitb'
    assert ie.ie_name() == 'eitb.tv'


# Generated at 2022-06-24 12:23:57.624474
# Unit test for constructor of class EitbIE
def test_EitbIE():
  EitbIE() == EitbIE

# Generated at 2022-06-24 12:24:03.937695
# Unit test for constructor of class EitbIE
def test_EitbIE():
    res = EitbIE()._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:24:06.578452
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # First, create an instance of class EitbIE.
    EitbIE()._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')



# Generated at 2022-06-24 12:24:09.473430
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie._VALID_URL, str)
    assert ie.IE_DESC == 'eitb.tv'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:11.168640
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:14.793597
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:15.705079
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()

# Generated at 2022-06-24 12:24:19.810655
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:24:25.644358
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:27.763719
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    try:
        from nose.tools import assert_not_equal
        assert_not_equal(eitbIE, None)
    except:
        print('Test for class EitbIE failed!')


# Generated at 2022-06-24 12:24:32.869615
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.ie_key() == 'eitb.tv'
    assert EitbIE.ie_key() in list(InfoExtractor._ies.keys())
    assert EitbIE.ie_key() in list(InfoExtractor.gen_extractors().keys())
    assert EitbIE.ie_key() in dir(InfoExtractor())

# Generated at 2022-06-24 12:24:33.998486
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.__name__ == 'EitbIE'


# Generated at 2022-06-24 12:24:38.009374
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    e.get_info_dict_for_url('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:24:40.994881
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert EitbIE._VALID_URL
    assert ie._VALID_URL
    assert ie._TEST.get('url')
    assert ie.IE_NAME in ie._TEST.get('url')

# Generated at 2022-06-24 12:24:41.677267
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:53.224704
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Url of german page
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"

    # Instance class EitbIE
    eitbie = EitbIE()

    # Call method _real_extract
    result = eitbie._real_extract(url)

    # Create dictionary with results

# Generated at 2022-06-24 12:24:59.252626
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie =  EitbIE(url);
    assert ie.url == url
    assert ie.name == 'eitb.tv'
    assert ie.match_id == '4090227752001'

# Generated at 2022-06-24 12:25:05.258106
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = 'http://www.eitb.tv/eu/bideoa/dok-haina/4104995148001/4015380596001/berezi-berriak/'
	eitbIE = EitbIE()
	assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
	assert eitbIE.IE_NAME == 'eitb.tv'
	assert eitbIE._downloader == None

# Generated at 2022-06-24 12:25:06.716511
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)._VALID_URL == EitbIE._VALID_URL


# Generated at 2022-06-24 12:25:07.876379
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE() # should not fail


# Generated at 2022-06-24 12:25:09.380786
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE('www.eitb.tv', False)

# Generated at 2022-06-24 12:25:09.837232
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:11.257018
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE(None)
    assert isinstance(IE, InfoExtractor)


# Generated at 2022-06-24 12:25:13.631118
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/vitoria-gasteiz-360/4316543963001/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL ==\
        r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:25:16.825558
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiate EitbIE
    print("Instantiating EitbIE object ...")
    eitb_ie = EitbIE()
    print("EitbIE object instantiated") 

test_EitbIE()

# Generated at 2022-06-24 12:25:19.834310
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-24 12:25:23.517409
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:25:24.658864
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_EITB = EitbIE()

# Generated at 2022-06-24 12:25:29.179716
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:25:39.079228
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check for class EitbIE
    eitb = EitbIE('test', 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb.ie_key() == 'Eitb'
    assert eitb.ie_key() == 'Eitb'
    assert eitb.name() == 'eitb.tv'
    assert eitb.name() == 'eitb.tv'

# Generated at 2022-06-24 12:25:40.460446
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()
    assert True


# Generated at 2022-06-24 12:25:42.138997
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    instance = class_(None)
    assert instance is not None

# Generated at 2022-06-24 12:25:43.699289
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)")


# Generated at 2022-06-24 12:25:45.149540
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:25:46.191156
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:25:50.459076
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE();
    assert ie._VALID_URL.find('/eu/bideoa/') != -1, "Expected URL with '/eu/bideoa/' substring"
    assert ie._VALID_URL.find('/es/video/') != -1, "Expected URL with '/es/video/' substring"

# Generated at 2022-06-24 12:25:51.987549
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    print (ie)


# Generated at 2022-06-24 12:25:55.141610
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:25:59.683196
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:26:05.205496
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test instance creation
    instance = EitbIE()
    assert(isinstance(instance, EitbIE))
    # Test it raises exception with a non-valid url
    instance = EitbIE('http://www.eitb.tv/ayuda/noticias/99865/')
    assert(not isinstance(instance, EitbIE))


# Generated at 2022-06-24 12:26:12.926369
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:26:17.664222
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'