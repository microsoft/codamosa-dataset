

# Generated at 2022-06-24 12:16:12.478860
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None


# Generated at 2022-06-24 12:16:12.997476
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:14.031799
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)



# Generated at 2022-06-24 12:16:23.769893
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:16:29.306190
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    return e

# Generated at 2022-06-24 12:16:31.678550
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:16:39.948433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    with open('eitb/tests/resources/test.html','rb') as f:
        page = f.read()
        url = 'http://www.eitb.tv/eu/bideoa/60-minutos-2011-2012/4104995148001/4086499208/60-minutos-addenda-expedientes-tokio/'
        ie = EitbIE()
        ie.extract_info(url,page = page)


# Generated at 2022-06-24 12:16:43.062618
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie._VALID_URL = ''
    ie.IE_NAME = ''
    ie.extract('http://www.eitb.tv/eu/bideoa/multimedia/2018/01/17/bideoa/')

# Generated at 2022-06-24 12:16:46.242346
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Make sure that all the parameters are working as expected
    assert EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:16:49.150102
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert isinstance(EitbIE(), InfoExtractor)
    except AssertionError: raise AssertionError("Invalid instantiation of EitbIE")


# Generated at 2022-06-24 12:17:00.149667
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._VALID_URL == 'https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)'

# Generated at 2022-06-24 12:17:04.012748
# Unit test for constructor of class EitbIE
def test_EitbIE():
        EitbIE("https://www.eitb.tv/es/video/")


# Generated at 2022-06-24 12:17:06.213624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/telebista/txoriak-eta-fakoak-bideoa/483415/')

# Generated at 2022-06-24 12:17:16.975376
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    # Test for dictionary '_TEST' of class EitbIE
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:17:18.590093
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()
    try:  
        media = EitbIE(None)
    except:
        assert 1 == -1
    

# Generated at 2022-06-24 12:17:23.017259
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE({}, {}, {})
    assert isinstance(eitb, InfoExtractor)

# Generated at 2022-06-24 12:17:24.530076
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Not implemented, so returning existing class
	return EitbIE

# Generated at 2022-06-24 12:17:30.530918
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Unit test for constructor of class EitbIE
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:17:32.425220
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor)

# Generated at 2022-06-24 12:17:33.341329
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_IE = EitbIE()

# Generated at 2022-06-24 12:17:34.711159
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import EitbIE
    desc = EitbIE(None)

# Generated at 2022-06-24 12:17:36.283524
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie_object = EitbIE()
    assert eitb_ie_object is not None

# Generated at 2022-06-24 12:17:37.776349
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:40.920658
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:48.124725
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:50.212473
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:17:51.604289
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE({})


# Generated at 2022-06-24 12:17:56.187132
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)


# Generated at 2022-06-24 12:17:57.252915
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)


# Generated at 2022-06-24 12:18:02.421343
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    instance = class_()
    assert (instance.IE_NAME == 'eitb.tv')
    assert (instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# xfail test for "EitbIE._real_extract"

# Generated at 2022-06-24 12:18:04.306233
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance.IE_NAME, 'EitbIE'

# Generated at 2022-06-24 12:18:09.546314
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    ie = EitbIE()
    media = ie._real_extract(url)
    assert media["id"] == "4090227752001"



# Generated at 2022-06-24 12:18:18.875248
# Unit test for constructor of class EitbIE
def test_EitbIE():
	'''
	Returns an instance of class EitbIE
	'''
	url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	e = EitbIE(url)
	assert e.IE_NAME == "eitb.tv"
	assert e._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"

# Generated at 2022-06-24 12:18:25.239048
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.name == 'eitb.tv'
    assert ie.ie_key() == 'eitb.tv'
    assert ie.ie_key() == ie.get_id()
    assert ie.get_id() == 'eitb.tv'
    assert ie.host() == 'www.eitb.tv'
    assert ie.canonical_url == 'http://www.eitb.tv/eu/bideoa/'
    assert ie.get_url_regex() is not None

# Generated at 2022-06-24 12:18:30.692051
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('https://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.name == 'eitb.tv'
    assert ie.ie_key() == 'EitbIE'
    assert ie.info_dict['id'] == '4090227752001'

# Generated at 2022-06-24 12:18:36.009922
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:18:37.020970
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:18:38.479180
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE(None)
    assert class_ is not None


# Generated at 2022-06-24 12:18:47.219066
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import assert_raises_regexp
    from .common import ExtractorError
    from .common import warning

    assert_raises_regexp(ExtractorError, 'This test is outdated and should be fixed \('
                         'probably by an update of the test\).', EitbIE, 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:18:53.998196
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:59.625831
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Check if this class creates an instance
    """
    id_EitbIE = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

    assert isinstance(id_EitbIE, EitbIE)



# Generated at 2022-06-24 12:19:10.810919
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:20.706810
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4090227752001'
    result = EitbIE()._real_extract('http://www.eitb.tv/eu/bideoa/60-minutos-2013-2014/4104995148001/lasa-y-zabala-30-anos/' + video_id)

    assert(result['id'] == video_id)
    assert(result['title'] == '60 minutos (Lasa eta Zabala, 30 urte)')
    assert(result['description'] == 'Ikuspegi aktualitatetik pasatutako batzorde reportajeak.')
    assert(result['duration'] == 3996.76)

# Generated at 2022-06-24 12:19:21.828116
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE();

# Generated at 2022-06-24 12:19:27.839214
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    if IE_NAME in globals()['_TESTS']:
        for key in globals()['_TESTS'][IE_NAME]:
            assert key in ie._TESTS
    else:
        globals()['_TESTS'][IE_NAME] = []
    globals()['_TESTS'][IE_NAME].append(test_EitbIE)



# Generated at 2022-06-24 12:19:29.478760
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:19:32.677431
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert(eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:19:33.582942
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:19:35.639616
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:19:44.975760
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.__name__ == 'EitbIE'
    assert ie.info_type() == 'video'

# Generated at 2022-06-24 12:19:53.950898
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("\n Unit test for class EitbIE")
    # Test: Create EitbIE instance
    eitb = EitbIE()
    print("\n Test: Create EitbIE instance")
    print("\n Test: URL: http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    print("\n Test: media ID: 4090227752001")
    print("\n Test: class instance: " + str(eitb))


# Generated at 2022-06-24 12:19:56.258913
# Unit test for constructor of class EitbIE
def test_EitbIE():
        # Initialization
        extractor = EitbIE()

        # Test
        assert extractor.IE_NAME == 'EitbIE'

# Generated at 2022-06-24 12:20:00.420740
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE(url)

# Generated at 2022-06-24 12:20:01.618049
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == "eitb.tv"

# Generated at 2022-06-24 12:20:07.569526
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('')

    assert ie.IE_NAME is not None
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.VALID_URL is not None
    assert ie.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.TEST

# Generated at 2022-06-24 12:20:08.738588
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:12.698239
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()  # constructor of class EitbIE
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:20:13.989777
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    assert class_ != None

# Generated at 2022-06-24 12:20:18.969805
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # TODO: Add more tests for other attributes
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:21.916639
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.ie_key() == 'Eitb'
    assert ie.test() == False

# Generated at 2022-06-24 12:20:22.870856
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert isinstance(EitbIE, object)


# Generated at 2022-06-24 12:20:24.702050
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return


if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:20:26.923995
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie=EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'



# Generated at 2022-06-24 12:20:29.240502
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE({'extractor': 'eitb.tv'})
    eitb.extractor_key = 'eitb.tv'
    return eitb

# Generated at 2022-06-24 12:20:35.898674
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:20:37.941847
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE('EitbIE')
    assert info_extractor is not None

# Generated at 2022-06-24 12:20:41.390838
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    print(eitb)

# Generated at 2022-06-24 12:20:52.451361
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test a working video
    EitbIE().assert_url_works("http://www.eitb.tv/eu/bideoa/lehiaketak-lehiaketak-2013/4104993823001/3975850940001/lehiaketak-5-kapitulua---errepidean/")

    # Test a video that is not available
    # (Raises a exception because of the message in the webpage:
    # "Barkuak. Bideo honetarako eskubideak ez dira duela gutxikoak.")

# Generated at 2022-06-24 12:21:03.608757
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # URL EITB.TV format
    url = "http://www.eitb.tv/eu/bideoa/berri-bat/4104995142001/4101191154001/hiru-eskaintza-19-12-2017/"

    # Default options
    downloader = InfoExtractor(url)

    # New options
    downloader = InfoExtractor(url, extractor_key='EITB', forced_code='EU')

    # Options EITB.TV
    options = downloader.options

    # Test URL
    url_result = downloader.download_url.tostring()

# Generated at 2022-06-24 12:21:08.150911
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/GALERIA/4104995148001/4104995148001/'
    ie = EitbIE(url)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:21:18.605761
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # This URL will fail due to the lack of mp4format.
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    # This URL will return a video object.
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    instance = EitbIE(url)
    assert isinstance(instance, EitbIE)


# Generated at 2022-06-24 12:21:23.369197
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('www.eitb.tv', None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:25.787893
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:21:26.743420
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:27.727384
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # We must initialize a "self" object before calling the constructor
    self = EitbIE()
    EitbIE(self)



# Generated at 2022-06-24 12:21:29.010029
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == "eitb.tv"

# Generated at 2022-06-24 12:21:33.536372
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:21:38.340831
# Unit test for constructor of class EitbIE
def test_EitbIE():
    sys.path.insert(0, "..")
    from youtube_dl.extractor import gen_extractors
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(EitbIE)
    ydl.prepare_filename(test_EitbIE._TEST)
    ydl.download([test_EitbIE._TEST['url']])

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:21:40.439151
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE()._NAME == 'eitb.tv'
    assert EitbIE()._working == True


# Generated at 2022-06-24 12:21:43.834376
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """This is a unit test for constructor of class EitbIE"""
    _VALID_URL = EitbIE._VALID_URL
    _TEST = EitbIE._TEST
    ie = InfoExtractor(_VALID_URL)
    assert(ie._VALID_URL == _VALID_URL)


# Generated at 2022-06-24 12:21:51.545766
# Unit test for constructor of class EitbIE
def test_EitbIE():
    I = EitbIE()
    print(I)
    assert(I.IE_NAME == 'eitb.tv')
    assert(I._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert(I._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(I._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998')

# Generated at 2022-06-24 12:21:53.133144
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-24 12:22:04.661804
# Unit test for constructor of class EitbIE
def test_EitbIE():
    args = ['id', 'ext', 'title', 'description', 'duration', 'timestamp', 'upload_date', 'tags']
    assert hasattr(EitbIE, '_TEST')
    assert isinstance(EitbIE._TEST, dict)
    assert 'url' in EitbIE._TEST
    assert 'md5' in EitbIE._TEST
    assert 'info_dict' in EitbIE._TEST
    assert isinstance(EitbIE._TEST['info_dict'], dict)
    for key in args:
        assert key in EitbIE._TEST['info_dict']
    assert 'url' in EitbIE._TEST['info_dict']
    assert 'md5' in EitbIE._TEST['info_dict']

# Generated at 2022-06-24 12:22:05.857324
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE.IE_NAME == 'eitb.tv'



# Generated at 2022-06-24 12:22:15.078714
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:20.964508
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of class EitbIE."""
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE(url, {'username': '', 'password': ''})

# Generated at 2022-06-24 12:22:21.924164
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE()

# Generated at 2022-06-24 12:22:23.554547
# Unit test for constructor of class EitbIE
def test_EitbIE():
	testcase = EitbIE()
	assert testcase


# Generated at 2022-06-24 12:22:33.210700
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(True) # initialize EitbIE instance
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:37.419326
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:43.600602
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(test_url)
    assert ie.name == 'eitb.tv'
    assert ie.url == test_url

# Generated at 2022-06-24 12:22:53.308865
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE_instance = EitbIE()
    assert EitbIE_instance.IE_NAME == 'eitb.tv'
    assert EitbIE_instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:56.627139
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE = class_to_test(EitbIE, 'EitbIE', episode_title_re=r' \([^)]+\)')

# Generated at 2022-06-24 12:22:59.861637
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Unit test for constructor of class EitbIE
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:09.350425
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE(None).IE_NAME == 'eitb.tv'
    assert EitbIE(None)._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE(None)._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert Eitb

# Generated at 2022-06-24 12:23:13.950999
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.__class__.__name__ == EitbIE.__class__.__name__
    assert ie.IE_NAME == EitbIE.IE_NAME
    assert ie.IE_DESC == EitbIE.IE_DESC
    assert ie._VALID_URL == EitbIE._VALID_URL
    assert ie._TEST == EitbIE._TEST


# Generated at 2022-06-24 12:23:14.534792
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:23:15.981523
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test if EitbIE constructor throws no exception
    assert EitbIE

# Generated at 2022-06-24 12:23:17.495406
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert hasattr(EitbIE, 'constructor')

# Generated at 2022-06-24 12:23:18.535305
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:23:23.725454
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:32.838968
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Create object of class EitbIE
    eitbie = EitbIE()
    eitbie.initialize()

    # Get expected results
    expected_ie_name = 'eitb.tv'
    expected_valid_url = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    # Check attributes
    assert eitbie.IE_NAME == expected_ie_name
    assert eitbie._VALID_URL == expected_valid_url

    return
 

# Generated at 2022-06-24 12:23:37.245559
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    id = ie._match_id(test_url)
    EitbIE._real_extract(ie, test_url)

# Generated at 2022-06-24 12:23:41.518931
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert(obj.IE_NAME == 'eitb.tv')
    assert(obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:23:52.503405
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None, {}, None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:59.469335
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test url: http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/
    video_id = '4090227752001'
    # test with standard output
    assert(video_id == EitbIE._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')['id'])
    # test with custom output
    assert(video_id == EitbIE.IE_NAME)
    # test with assert

# Generated at 2022-06-24 12:24:09.089798
# Unit test for constructor of class EitbIE
def test_EitbIE():

    import unittest
    import sys
    sys.path.append('../utils')
    import url_validator

    class TestEitbIE(unittest.TestCase):
        def test_case_1(self):
            url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
            result = url_validator.validate(url, EitbIE)

# Generated at 2022-06-24 12:24:17.475769
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:24:21.534539
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:24:32.746117
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:24:35.162383
# Unit test for constructor of class EitbIE
def test_EitbIE():
    constructor = EitbIE.__init__
    # If any of the next validations fail, the constructor fails
    # as well
    assert constructor is not None
    assert callable(constructor)

# Generated at 2022-06-24 12:24:37.134110
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test the constructor of the class
    """
    assert EitbIE('www.eitb.tv') is not None

# Generated at 2022-06-24 12:24:45.512089
# Unit test for constructor of class EitbIE
def test_EitbIE():
	
	# Test valid URL
	Eitb = EitbIE(url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
	assert Eitb.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', "URL facebook doesn't match expected value"
	assert Eitb.name == 'eitb.tv', "Name of class YoutubeIE doesn't match expected value"

	# Test invalid URL

# Generated at 2022-06-24 12:24:48.243784
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # ie = EitbIE()
    eitb_test = EitbIE()._TEST
    print(eitb_test)

test_EitbIE()

# Generated at 2022-06-24 12:24:52.618810
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:24:59.699595
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:00.239210
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:10.793240
# Unit test for constructor of class EitbIE
def test_EitbIE():
    cls = 'EitbIE'
    instance = locals()[cls]()
    assert(instance.IE_NAME == 'eitb.tv')
    assert(instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert(instance._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(instance._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998')

# Generated at 2022-06-24 12:25:11.342373
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:20.871693
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:24.264239
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst.IE_NAME == 'eitb.tv'
    assert inst._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:29.639497
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:25:33.914332
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:25:44.907105
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:25:45.539137
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:25:47.745751
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE"""
    ie = EitbIE()
    assert ie.IE_NAME == 'Eitb.tv'

# Generated at 2022-06-24 12:25:56.421573
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        if not SITE_INFO['eitb.tv']['unit_test']:
            return
    except KeyError:
        return
    print("\nTesting class EitbIE...")
    eitb = EitbIE()
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video = eitb.extract(url)
    print("\nTesting title...")
    assert video['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    print("\nTesting duration...")
    assert video['duration'] == 3996.76

# Generated at 2022-06-24 12:25:57.769651
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:26:01.423582
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL.search('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/').group('id') == '4090227752001'
test_EitbIE.func_code = EitbIE._VALID_URL.func_code

# Generated at 2022-06-24 12:26:04.931710
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:26:05.925760
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print(EitbIE())


# Generated at 2022-06-24 12:26:12.125708
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
                 'test_EitbIE')
    assert instance.IE_NAME == 'eitb.tv'
    assert instance._VALID_URL == 'http://www.eitb.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
