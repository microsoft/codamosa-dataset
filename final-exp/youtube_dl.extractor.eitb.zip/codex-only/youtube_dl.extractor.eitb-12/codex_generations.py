

# Generated at 2022-06-24 12:16:15.298516
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.ie_key() == 'Eitb'
    assert e.ie_name() == 'Eitb'

# Generated at 2022-06-24 12:16:16.745470
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# EitbIE(info_extractors=None, downloader=None)
	assert True


# Generated at 2022-06-24 12:16:21.214737
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Basic test to show constructor.
    """
    EitbIE()

# Generated at 2022-06-24 12:16:25.663184
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert obj.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:16:30.895456
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("Eitb.tv")

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:16:33.147884
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_CLASS = EitbIE
    invalid_url_error = 'url'
    ie = IE_CLASS()
    ie.initialize()
    ie.extract(invalid_url_error)
    return ie

# Generated at 2022-06-24 12:16:35.714992
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:16:37.359290
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    It's just a declaration, as this test is handled by other test
    """
    assert EitbIE

# Generated at 2022-06-24 12:16:46.789224
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    eitbIE = EitbIE()
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._real_extract(url)['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert eitbIE._real_

# Generated at 2022-06-24 12:16:51.942686
# Unit test for constructor of class EitbIE
def test_EitbIE():
	#Test with the constructor of class EitbIE and with a valid string
    EitbIE("http://www.eitb.tv/eu/bideoa/adurrak/3323520993001/")
    #Test with the constructor of class EitbIE and with a string invalid
    EitbIE("http://www.eitb.tv/eu/bideoa/adurrak/33235209")


# Generated at 2022-06-24 12:16:53.170059
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie)



# Generated at 2022-06-24 12:16:55.319075
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:17:00.985399
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Initialize unit test
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    return ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:05.170346
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'eitb.tv'
    assert len(ie._VALID_URL)


# Generated at 2022-06-24 12:17:15.901270
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == \
        r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:17.078470
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:18.040739
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE, InfoExtractor)

# Generated at 2022-06-24 12:17:24.955227
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Constructor
	eitb = EitbIE()

	# Check if it's the proper class
	assert eitb.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:17:29.799425
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_TEST = EitbIE()
    assert IE_TEST.IE_NAME == 'eitb.tv'
    assert IE_TEST._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:17:39.540464
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Construct instance of EitbIE class,
    # and then test all fields of object
    instance_of_eitbie = EitbIE()
    # Check value of IE_NAME variable.
    assert instance_of_eitbie.IE_NAME == 'eitb.tv', \
        'eitbie object should have correct value of IE_NAME variable.'
    # Check value of _VALID_URL variable.
    assert instance_of_eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)', \
        'eitbie object should have correct value of _VALID_URL variable.'
    # Call _real_initialize() method of instance of Eitb

# Generated at 2022-06-24 12:17:41.832700
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE

if __name__ == '__main__':
    # Unit test for constructor of class EitbIE
    test_EitbIE()

# Generated at 2022-06-24 12:17:43.928727
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Arrange and Act
	ie = EitbIE(InfoExtractor)

	# Assert
	assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:49.748250
# Unit test for constructor of class EitbIE
def test_EitbIE():
    creator = EitbIE()
    creator.IE_NAME
    creator.IE_DESC
    creator._VALID_URL
    creator._TESTS
    creator._TEST
    creator.IE_NAME.lower() in getattr(creator, "ie_key").lower()
    creator.IE_DESC.lower() in getattr(creator, "ie_desc").lower()

# Generated at 2022-06-24 12:17:52.545620
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    ied = ie._real_extract(url)
    assert ied is not None


# Generated at 2022-06-24 12:18:02.919386
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.test()['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie.test()['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:18:03.445515
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:10.415509
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE('http://www.eitb.tv/eu/bideoa/informazioa/zuzendaritza/2014/05/13/jose-mª-goenaga-direktor-epaitegia/')
    assert eitb.ie_key() == 'Eitb'
    assert eitb.ie_name() == 'eitb.tv'

# Unit tests for EitbIE.extract()

# Generated at 2022-06-24 12:18:13.892872
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:18:19.721646
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test if the url is valid
    url = "http://www.eitb.tv/eu/bideoa/futbol/laliga/getafe-vs-granada/4084107354001/"
    assert EitbIE._VALID_URL == re.match(EitbIE._VALID_URL, url).re.pattern


# Generated at 2022-06-24 12:18:21.118317
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test: Class EitbIE should be initialized
    assert EitbIE is not None

# Generated at 2022-06-24 12:18:27.571638
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	video_id = '4090227752001'

# Generated at 2022-06-24 12:18:39.689673
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Creation of a EitbIE instance
    eitbIE = EitbIE()
    # Test of url property
    url = eitbIE.url
    assert url == "https://www.eitb.tv/"
    # Test of IE_NAME property
    ie_name = eitbIE.ie_name
    assert ie_name == "EitbIE"
    # Test of _VALID_URL property
    _valid_url = eitbIE._valid_url
    assert _valid_url == "https://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/[0-9]+/([0-9]+)"
    # Test of _TEST property
    _test = eitbIE._test

# Generated at 2022-06-24 12:18:44.789440
# Unit test for constructor of class EitbIE
def test_EitbIE():

    obj = EitbIE()

    expected = "EitbIE"
    actual = obj.IE_NAME
    assert expected == actual

    expected = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    actual = obj._VALID_URL
    assert expected == actual

# Generated at 2022-06-24 12:18:45.445749
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:18:48.217215
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Initialize an instance
    cli = EitbIE()
    # Check whether the object is initialized, or not
    if cli is None:
        raise AssertionError('It should not be None')
    print('get_info_extractor: {}\n'.format(cli.get_info_extractor()))

# Generated at 2022-06-24 12:18:59.757558
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    if obj.IE_NAME != 'eitb.tv':
        raise Exception('Invalid IE name')
    if obj.IE_SHORT_NAME != 'eitb':
        raise Exception('Invalid IE short name')
    if obj._VALID_URL != 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)':
        raise Exception('Invalid URL regex')

# Generated at 2022-06-24 12:19:02.875473
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitbIE = EitbIE()
	eitbIE.IE_NAME = 'eitb.tv'
	assert eitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:19:07.476272
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:19:16.107153
# Unit test for constructor of class EitbIE
def test_EitbIE():
    module = "EitbIE"
    constructor = "EitbIE"

    # Instantiate the EitbIE class
    instance = globals()[module](constructor)

    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert instance._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert instance._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'


# Generated at 2022-06-24 12:19:16.624838
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:19:17.084309
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-24 12:19:18.012214
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-24 12:19:18.705888
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:19:19.637962
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-24 12:19:22.010837
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test for constructor of class EitbIE"""
    eitbie = EitbIE()
    assert eitbie is not None

# Generated at 2022-06-24 12:19:26.183461
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor

    # Test for the constructor
    EitbIE_test = EitbIE()

    # Check that it is an instance of InfoExtractor
    assert isinstance(EitbIE_test, InfoExtractor)


# Generated at 2022-06-24 12:19:34.236627
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url_test1 = 'http://www.eitb.tv/eu/bideoa/iti-anima/iti-anima-1998/4104995206001/4090227895001/hiru-napar-ira-urrun/'
    url_test2 = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    name_list = ['eitb.tv']
    ie_test = EitbIE()
    # Test for first url
    for name in name_list:
        if ie_test.suitable(url_test1):
            assert ie_test.IE_NAME == name
            assert ie_

# Generated at 2022-06-24 12:19:40.638023
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("---> test_EitbIE()")

    ie = EitbIE()
    print("OK")


# Generated at 2022-06-24 12:19:51.532584
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert EitbIE._TEST['info_dict']['id'] == '4090227752001'
    assert EitbIE._TEST['info_dict']['ext'] == 'mp4'
    assert EitbIE._TEST['info_dict']['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert Eitb

# Generated at 2022-06-24 12:20:00.027926
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert e.IE_NAME == 'eitb.tv'
    assert 'title' in e._TEST['info_dict']

# Generated at 2022-06-24 12:20:07.641874
# Unit test for constructor of class EitbIE
def test_EitbIE():
	def test_EitbIE2():
		assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
		assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
		assert EitbIE._TEST['info_dict']['id'] == '4090227752001'
		assert EitbIE._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:20:08.578214
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Constructor unit testing """
    info_extractor = EitbIE()

# Generated at 2022-06-24 12:20:10.932995
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video = EitbIE()
    info = video.extract("test_url")
    assert type(info) == dict
    assert info["id"] == "test_id"

# Generated at 2022-06-24 12:20:13.024998
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('')
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-24 12:20:19.822744
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    video_id = "4090227752001"
    assert ie._match_id(url) == video_id
    #assert ie._real_extract(url)['id'] == '4090227752001'

# Generated at 2022-06-24 12:20:30.441200
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # eitb uses one '@' before the parameters
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/[^/]+/[^/]+/\d+/(?P<id>\d+)'
    # regex uses 'eitb' instead of 'eitb\.tv'
    assert 'http://www.eitb.tv/eu/bideoa/todo-sobre-la-final-de-la-copa-del-rey-entre-bilbao-y-barca/4098686077001/4098686077001/' in EitbIE._VALID_URL
    # regex uses 'eitb/eu' instead of 'eitb.tv/eu'

# Generated at 2022-06-24 12:20:32.091429
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()

# Generated at 2022-06-24 12:20:37.344324
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE({}, None)._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:20:42.998359
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        IE = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
        return True
    except:
        return False



# Generated at 2022-06-24 12:20:46.047897
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4090227752001/"
    test_info = EitbIE()._parse_json(url, '4090227752001')
    print(test_info)

test_EitbIE()

# Generated at 2022-06-24 12:20:47.363327
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:20:48.786061
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:51.488816
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('www.youtube.com', {})
    assert ie.IE_NAME == 'Eitb'

# Generated at 2022-06-24 12:21:03.228603
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Test for constructor of class EitbIE"""
    Eitb = EitbIE()
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    expected_id = "4090227752001"
    json_url = "http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/" + expected_id + "/"
    expected_title = "60 minutos (Lasa y Zabala, 30 años)"
    expected_description = "Programa de reportajes de actualidad."

# Generated at 2022-06-24 12:21:11.150481
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # Check whether the class EitbIE has been initialized successfully
    assert ie.ie_key() == 'Eitb'
    # Check whether the class EitbIE has the property _VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Check whether the class EitbIE has the method _real_extract
    assert hasattr(ie, '_real_extract') == True
    # Check whether the class EitbIE has the method _match_id
    assert hasattr(ie, '_match_id') == True

# Generated at 2022-06-24 12:21:12.144470
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test = EitbIE()
	return test

# Generated at 2022-06-24 12:21:18.798184
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple unit test for EitbIE
    """
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:26.273095
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Test if it can download the video

# Generated at 2022-06-24 12:21:37.352310
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_obj = EitbIE()
    assert(test_obj.IE_NAME == 'eitb.tv')
    assert(test_obj._VALID_URL ==
           r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:21:41.441182
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('EitbIE')

# Generated at 2022-06-24 12:21:48.595482
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE().ie_key())
    assert(EitbIE().suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'))
    assert(not EitbIE().suitable('http://www.eitb.tv/es/cultura/musica/'))

# Generated at 2022-06-24 12:21:49.084152
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:59.180188
# Unit test for constructor of class EitbIE
def test_EitbIE():
    parser = EitbIE()
    assert parser.IE_NAME == 'eitb.tv'
    assert parser._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:07.452008
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Test function with missing parameters (url, ie_key)
	instance = EitbIE()
	assert(instance!=None)
	# Test function with missing parameters (ie_key)
	#instance = EitbIE('http://www.eitb.tv/eu/bideoa/gaur/765623/')
	#assert(instance!=None)
	# Test function with all parameters
	instance = EitbIE('http://www.eitb.tv/eu/bideoa/gaur/765623/','eitb')
	assert(instance!=None)

# Generated at 2022-06-24 12:22:08.851017
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE().ie_key() == 'eitb.tv'

# Generated at 2022-06-24 12:22:14.196644
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for constructor of class EitbIE
    testIE = EitbIE(None);
    assert testIE is not None, 'Test for constructor of class EitbIE failed!'

test = test_EitbIE();

if __name__ == '__main__':
    print('Executing unit tests for class EitbIE')
    test_EitbIE();
    print('Completed unit tests for class EitbIE')

# Generated at 2022-06-24 12:22:25.419858
# Unit test for constructor of class EitbIE
def test_EitbIE():

    instance = EitbIE()

    assert instance.IE_NAME == 'eitb.tv'
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:34.325691
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test EitbIE constructor.
    """
    valid_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test_EitbIE = EitbIE()
    regex = test_EitbIE._VALID_URL
    m = re.match(regex, valid_url)
    res = test_EitbIE._real_extract(valid_url)
    print('*' * 80)
    print('title: ', res['title'])
    print('*' * 80)

# Generated at 2022-06-24 12:22:46.134933
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test constructor of class EitbIE
    request = sanitized_Request('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', headers={'Referer': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 'X-Forwarded-For': '172.17.0.1'})

# Generated at 2022-06-24 12:22:51.676600
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE([], {}, {})
    assert eitbIE.IE_NAME == EitbIE.IE_NAME

# Generated at 2022-06-24 12:22:55.580635
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    class_.IE_NAME = 'EITB'
    class_.IE_DESC = 'EITB.tv: Auditorio de Bilbao'

# Generated at 2022-06-24 12:23:02.412348
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert obj._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:23:03.368246
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE)

# Generated at 2022-06-24 12:23:15.121475
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE.VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:16.130431
# Unit test for constructor of class EitbIE
def test_EitbIE():
     Test = EitbIE()

# Generated at 2022-06-24 12:23:18.921313
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for constructor of class EitbIE
    assert EitbIE().IE_NAME == 'eitb.tv'



# Generated at 2022-06-24 12:23:22.953500
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple unit test for EitbIE
    """
    ie = EitbIE()
    assert ie.ie_key() == 'Eitb'
    assert ie.ie_codec() == 'Eitb'

# Generated at 2022-06-24 12:23:25.353770
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE({}).IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:31.185773
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/5291133/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:34.650201
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'^https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)(?:$|[?#])'



# Generated at 2022-06-24 12:23:35.534366
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE({})

# Generated at 2022-06-24 12:23:36.757291
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-24 12:23:40.814244
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:41.391106
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:23:42.088767
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-24 12:23:43.988336
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    print(ie)
    
test_EitbIE()

# Generated at 2022-06-24 12:23:46.259110
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Create instance of class EitbIE
    """
    EitbIEInstance = EitbIE()

# Generated at 2022-06-24 12:23:56.400015
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    This test check if class EitbIE is created correctly.
    """
    assert EitbIE.IE_NAME == "eitb.tv"
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:24:05.557672
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitbie.IE_NAME == 'eitb.tv'
    assert eitbie._VALID_URL == 'http://www\.eitb\.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'


# Generated at 2022-06-24 12:24:06.473557
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Object creation
	EitbIE()

# Generated at 2022-06-24 12:24:08.911710
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiation
    EitbIE(
        EitbIE.ie_key(),
        EitbIE._VALID_URL
    )

# Generated at 2022-06-24 12:24:17.344317
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:24:18.667856
# Unit test for constructor of class EitbIE
def test_EitbIE():
	new_EitbIE = EitbIE()
	

# Generated at 2022-06-24 12:24:26.091593
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert instance.suitable(test_url), "URL is not suitable for extracting with EitbIE"
    assert instance.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:30.611235
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple test to see if constructor of class EitbIE works.
    It should return a EitbIE object.
    """
    from .common import InfoExtractor
    from .eitb import EitbIE
    assert isinstance(EitbIE(InfoExtractor()), EitbIE)

# Generated at 2022-06-24 12:24:33.651471
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-24 12:24:40.747440
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:46.222168
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    https://github.com/rg3/youtube-dl/issues/8776
    """
    e = EitbIE('http://www.eitb.tv/eu/bideoa/')
    ie = e.ie_key()
    assert e == globals()[ie + 'IE']

# Generated at 2022-06-24 12:24:48.971453
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == 'http://www.eitb.tv/eu/bideoa/(?P<id>[^/]+)/'

# Generated at 2022-06-24 12:24:49.610273
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert True

# Generated at 2022-06-24 12:24:52.065753
# Unit test for constructor of class EitbIE
def test_EitbIE():
        try:
            EitbIE()
            return True
        except:
            return False

# Generated at 2022-06-24 12:24:53.883861
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        assert False, "Unit test for class EitbIE failed"


# Generated at 2022-06-24 12:24:58.227971
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for constructor of class EitbIE
    """
    # EitbIE.__init__(self)
    # assert eitb_ie != None
    assert True # TODO: implement your test here


# Generated at 2022-06-24 12:25:00.555949
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
        assert True
    except:
        assert False

# Generated at 2022-06-24 12:25:07.114113
# Unit test for constructor of class EitbIE
def test_EitbIE():
    with open('youtube_dl/test/test_data/eitb.tv_url.txt', 'r') as f:
        url = f.read().strip()
    info_dict = EitbIE()._real_extract(url)
    assert info_dict['id'] == '4285811648019'
    assert info_dict['title'] == 'Gran Reserva (A la carta)'
    assert len(info_dict['formats']) == 6

# Generated at 2022-06-24 12:25:11.033007
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        # Call constructor of class EitbIE
        from .common import InfoExtractor
        ie = InfoExtractor()
    except:
        # Raise exception if constructor of class EitbIE can't be called
        raise AssertionError('Can\'t call constructor of class EitbIE')


# Generated at 2022-06-24 12:25:15.886884
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE(None)
    assert obj.IE_NAME == 'eitb.tv'
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Unit tests for download_url of class EitbIE

# Generated at 2022-06-24 12:25:17.744355
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb is not None


# Generated at 2022-06-24 12:25:23.009624
# Unit test for constructor of class EitbIE
def test_EitbIE():
  """
  This is a test for the constructor of the class EitbIE.
  """
  ie = EitbIE()
  assert ie.IE_NAME == 'eitb.tv'
  assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:25:23.710238
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:27.306133
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    if ie is not None:
        print("Unit test for EitbIE class passed!")
    else:
        print("Unit test for EitbIE class failed!")

# Generated at 2022-06-24 12:25:30.210894
# Unit test for constructor of class EitbIE
def test_EitbIE():
    constructorTest(
        'EitbIE',
        {
            'url': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 
            'only_matching': True,
        }
    )


# Generated at 2022-06-24 12:25:40.892454
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for EitbIE class constructor. 
    """
    ie = EitbIE(None)
    test = EitbIE._TEST
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert test['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:25:42.430082
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:49.239286
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for constructor of class test_EitbIE
    eitb_ie = EitbIE('http://www.eitb.tv/eu/bideoa/erakustaldia-zuzenean/4104995148001/4108024886001/', {})
    assert eitb_ie.url == 'http://www.eitb.tv/eu/bideoa/erakustaldia-zuzenean/4104995148001/4108024886001/'

# Generated at 2022-06-24 12:25:50.144800
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #Tests object construction
    EitbIE()

# Generated at 2022-06-24 12:25:54.712814
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('https://www.eitb.tv/es/video/documentales-documentales-2015/5346421780001/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:26:06.071194
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for a video with a closed caption stream
    video = EitbIE()._real_extract("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert len(video['formats']) == 3

    # Test for a video with no closed caption stream
    video = EitbIE()._real_extract("http://www.eitb.tv/eu/bideoa/10-minutos-10-minutos/20131018/vor-viendo-tiempo-aspe-fuerteventura/")
    assert len(video['formats']) == 2

# Generated at 2022-06-24 12:26:08.528522
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except Exception as e:
        raise Exception("Unit test for constructor of class EitbIE failed: " + str(e))


# Generated at 2022-06-24 12:26:13.858511
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(0)
    assert ie.name == 'eitb.tv'
    assert ie.url_re == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
