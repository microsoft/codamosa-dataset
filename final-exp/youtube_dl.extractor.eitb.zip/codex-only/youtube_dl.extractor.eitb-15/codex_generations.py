

# Generated at 2022-06-24 12:16:12.903560
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:16:20.366143
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_instance = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert (eitb_instance.IE_NAME == 'eitb.tv')
    assert (eitb_instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:16:21.017414
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:22.126970
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:16:28.339344
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb = EitbIE()
    assert 'EitbIE object' == eitb.__repr__()
    eitb._real_extract(eitb_url)
    print ("Eitb unit test OK")

# Generated at 2022-06-24 12:16:29.520185
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), EitbIE)

# Generated at 2022-06-24 12:16:32.578536
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE.VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:16:43.268645
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test for EitbIE constructor"""
    ie = EitbIE()

    assert ie.IE_NAME == 'eitb.tv'
    assert ie.VALID_URL.__name__ == '_VALID_URL'
    assert ie._TEST.__name__ == '_TEST'
    assert ie._TEST.get('url') == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST.get('md5') == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:16:47.656486
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiate the class
    a = EitbIE("www.eitb.tv/eu/bideoa/lasa-zabala/4104995148001/4104997828001/")
    # Call method
    a._real_extract("www.eitb.tv/eu/bideoa/lasa-zabala/4104995148001/4104997828001/")
    # Print results
    print(a.formats)

# Generated at 2022-06-24 12:16:49.245399
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    _ = obj.IE_NAME

# Generated at 2022-06-24 12:16:50.058046
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:53.390783
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16')
    print("Constructor of class EitbIE has been tested. It is correct!")

# Generated at 2022-06-24 12:17:04.467228
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    Unit test for the constructor of class EitbIE:
        def __init__(self, *args, **kwargs):
            InfoExtractor.__init__(self, *args, **kwargs)
    '''


# Generated at 2022-06-24 12:17:11.852832
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(EitbIE.ie_key())
    # Test tools import
    from ..tools import assert_equal
    # Test
    # Test info extraction of valid url
    info = ie.extract("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert_equal(info['id'], '4090227752001')
    assert_equal(info['title'], '60 minutos (Lasa y Zabala, 30 años)')
    assert_equal(info['description'], 'Programa de reportajes de actualidad.')
    assert_equal(info['duration'], 3997)

# Generated at 2022-06-24 12:17:14.710460
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Get an instance of YoutubeIE passing a URL
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    # Show information about the URL

# Generated at 2022-06-24 12:17:17.292195
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutotan/4104995148001/4090227752001/lasa-y-zabala-30-urte/')
    assert eitbIE is not None

# Generated at 2022-06-24 12:17:17.702906
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:17:19.911448
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")


# Generated at 2022-06-24 12:17:23.117275
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == EitbIE._VALID_URL

# Generated at 2022-06-24 12:17:24.215365
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:17:27.957616
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        global eitb_test
        eitb_test = EitbIE(None)
    except ValueError as e:
        assert eitb_test != None, 'AssertionError'



# Generated at 2022-06-24 12:17:30.636031
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('EitbIE', 'www.eitb.tv')
    return True

# Unit test to extract videos from www.eitb.tv

# Generated at 2022-06-24 12:17:36.369492
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.IE_NAME == "Eitb")
    assert(ie.IE_DESC == "EITB")
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:17:39.717929
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = 'http://www.eitb.tv/eu/bideoa/sabino-ordoki/4099607352001/denboraldia-bideoa/'
    EitbIE(test_url)

# Generated at 2022-06-24 12:17:42.318101
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    >>> from . import test
    >>> test.IEQuerier(EitbIE).run()
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 12:17:45.854285
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb = EitbIE(EitbIE.ie_key(), url)
    assert isinstance(eitb, EitbIE)

# Generated at 2022-06-24 12:17:52.010247
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:56.896896
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:17:59.984835
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .common import ExtractorError
    from .common import ExtractorError
    try:
        eitbIE = EitbIE()
        assert 1 == 1
    except:
        assert 0 == 1

# Generated at 2022-06-24 12:18:04.393901
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE"""
    return assertTrue(EitbIE() is not None)

# Generated at 2022-06-24 12:18:04.934872
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:09.828380
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(EitbIE.IE_NAME)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:10.638231
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE



# Generated at 2022-06-24 12:18:11.237317
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:17.751810
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for the EitbIE class constructor.

    Args:
        None.

    Returns:
        None.
    """
    # Test the EitbIE class constructor.
    # Initialize the EitbIE class instance.
    eitb_ie_object = EitbIE()
    # Execute the _extract_feed_info method.
    eitb_ie_object._extract_feed_info()

# Generated at 2022-06-24 12:18:21.983826
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test EitbIE class constructor
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE(url=url)

# Generated at 2022-06-24 12:18:23.277184
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:18:26.738077
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .tests.test_media_robot_suite import TestMediaIconsRobot

    url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    t = TestMediaIconsRobot(EitbIE, url)

    t.test(0)

# Generated at 2022-06-24 12:18:32.497754
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    for url in ['http://www.eitb.tv/eu/bideoa/zuzenean/20160523/20160523-argentina-kolungak-hilo-garatu-nahi-du/']:
        eitb.download(url)

# Generated at 2022-06-24 12:18:34.894083
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()

if __name__ == "__main__":
    test_EitbIE()

# Generated at 2022-06-24 12:18:41.492448
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import expected_warnings

    # TODO: This test is broken, needs to be fixed
    """
    e = EitbIE()
    result = e.getEitbIE()
    assert isinstance(result, (InfoExtractor, type(None)))
    """
    with expected_warnings(['ERROR: Unable to download ']):
        e = EitbIE()
        result = e.getEitbIE()
    assert isinstance(result, (InfoExtractor, type(None)))

# Generated at 2022-06-24 12:18:41.880877
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:44.959907
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Create object
    infoExtractor = EitbIE()

    # Function protected
    assert not hasattr(infoExtractor, '_real_extract')

# Generated at 2022-06-24 12:18:48.006325
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_instance = EitbIE()
    assert (eitb_instance._VALID_URL == 
            'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-24 12:18:59.715110
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    obj = EitbIE()
    obj.IE_NAME = "EitbIE"
    obj.IE_DESC = "Eitb.tv"
    obj.VALID_URL = "^https?://[^/]+/video/.*/\d+/\d+/"
    assert(obj.IE_NAME == "EitbIE")
    assert(obj.IE_DESC == "Eitb.tv")
    assert(obj.VALID_URL == "^https?://[^/]+/video/.*/\d+/\d+/")

# Generated at 2022-06-24 12:19:05.105893
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:19:06.209407
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie != None

# Generated at 2022-06-24 12:19:07.466847
# Unit test for constructor of class EitbIE
def test_EitbIE():
    global eitb
    eitb = EitbIE()



# Generated at 2022-06-24 12:19:12.495038
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4090227752001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._match_id(url) == video_id

# Generated at 2022-06-24 12:19:22.763705
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor of EitbIE class
    obj1 = EitbIE()
    assert obj1.IE_NAME == 'eitb.tv'
    assert obj1._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:32.206284
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	eitb = EitbIE()
	result_eitb = eitb.extract(url)
	assert result_eitb['id'] == '4090227752001'
	assert result_eitb['ext'] == 'mp4'
	assert result_eitb['title'] == '60 minutos (Lasa y Zabala, 30 años)'
	assert result_eitb['description'] == 'Programa de reportajes de actualidad.'
	assert result_eitb['duration'] == 3996.76
	assert result_e

# Generated at 2022-06-24 12:19:32.583967
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:19:33.495899
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Errorless running of EitbIE
	pass

# Generated at 2022-06-24 12:19:34.103200
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE

# Generated at 2022-06-24 12:19:42.292983
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie._match_id('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    ie._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:19:49.360386
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:19:51.142150
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')


# Generated at 2022-06-24 12:19:52.100325
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print(EitbIE())


# Generated at 2022-06-24 12:19:55.522719
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE != None, "Failed to initialize class EitbIE"


# Generated at 2022-06-24 12:20:04.906094
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Test for API key
	if not API_KEY:
		print('API Key not set!')
		sys.exit(1)

	# Get API URL	
	api_url = 'http://api.eitb.tv/videos?publication_date=%s&format=json&key=%s' % (PUBLICATION_DATE, API_KEY)

	# Download JSON
	json_data = download_json(URL, scrap_id)
	# Get data
	videos = json_data['videos']

	# Get video IDs
	video_ids = get_video_ids(json_data)
	# Get video urls
	video_urls = get_video_urls(video_ids)
	# Download videos
	videos = download_videos(video_urls, video_ids)
	# Return

# Generated at 2022-06-24 12:20:11.387877
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test_url_constructor
    url = r'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'
    eitb_ie = EitbIE(url)
    eitb_ie.video_id = video_id
    assert eitb_ie.video_id == video_id

# Generated at 2022-06-24 12:20:13.205354
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:22.627291
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'EitbIE'
    assert ie.IE_DESC == 'Eitb'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:26.060679
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:20:32.866492
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:20:36.239471
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL
    assert EitbIE().IE_NAME == EitbIE.IE_NAME

# Generated at 2022-06-24 12:20:41.141709
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_object = EitbIE()
    assert test_object.IE_NAME == 'eitb.tv'
    assert test_object._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:52.426039
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie_instance = EitbIE()
    assert eitb_ie_instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:02.918748
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor: EitbIE(name, ie, fs)
    ie = EitbIE('Eitb.tv', 'eitb.tv', 'eitb.tv')
    # unit test for method EitbIE._real_extract(url)
    info_dict = ie._real_extract("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert info_dict['id'] == '4090227752001'
    print("Test assert for method _real_extract of class EitbIE")


# Generated at 2022-06-24 12:21:06.094894
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:21:10.176955
# Unit test for constructor of class EitbIE
def test_EitbIE():
    w = EitbIE()
    assert w.IE_NAME == 'eitb.tv'
    assert w._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:21:10.602287
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:15.978274
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Unit Test for class EitbIE")
    print("--------------------------------------")
    i = EitbIE()
    print("URL: " + i._VALID_URL)
    print("IE_NAME is: " + i.IE_NAME)
    print("--------------------------------------")


# Generated at 2022-06-24 12:21:25.876366
# Unit test for constructor of class EitbIE
def test_EitbIE():

    test_url = 'http://www.eitb.tv/es/video/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test_video_id = '4090227752001'

    class test_EitbIE(EitbIE):
        def _real_extract(self, url):

            self.assertEqual(url, test_url)

            class test_video:
                pass

            test_video.web_media = [{'RENDITIONS': [{'PMD_URL': 'http://test.pmd'}]}]
            test_video.web_media[0]['HDS_SURL'] = 'http://test.f4m'

# Generated at 2022-06-24 12:21:28.725876
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert ie.name == 'EitbIE'

# Generated at 2022-06-24 12:21:29.299860
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:33.441370
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/eitb-karrika/4104995148001/4090227052001/'
    item = EitbIE(None, url)
    assert item.get_id() == '4090227052001'

# Generated at 2022-06-24 12:21:37.790489
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:21:50.988495
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ei = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ei.IE_NAME == 'eitb.tv'
    assert ei._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:53.289013
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert not EitbIE(None).suitable(None)

# Generated at 2022-06-24 12:21:54.088363
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE();
    

# Generated at 2022-06-24 12:22:00.938912
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/telebista/zuzendaritzak/60-minutos/60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    id = '4090227752001'
    title = '60 minutos (Lasa y Zabala, 30 años)'
    description = 'Programa de reportajes de actualidad.'
    duration = 3996.76
    timestamp = 1381789200977
    upload_date = '20131014'
    tags = ['actualidad', 'cultura', 'politica', 'reportajes', 'vascos']

# Generated at 2022-06-24 12:22:01.974023
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _test_class_constructor('EitbIE')

# Generated at 2022-06-24 12:22:06.350271
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-24 12:22:07.451960
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:22:16.081638
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    deo_eitb = EitbIE(test_url)
    assert deo_eitb.url == test_url
    assert deo_eitb.id == '4090227752001'
    test_url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert deo_eitb.url == test_url

# Generated at 2022-06-24 12:22:26.739736
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:22:29.565320
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e_i_e = EitbIE()
    assert isinstance(e_i_e, EitbIE)

# Generated at 2022-06-24 12:22:32.808466
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_obj = EitbIE()
    assert ie_obj.IE_NAME == 'eitb.tv'
    assert ie_obj.ie_key() == 'Eitb'

# Generated at 2022-06-24 12:22:42.037172
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = 4104995148001
    eitb_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eie = EitbIE()
    eie.url = eitb_url
    info = eie.extract(eitb_url)
    assert info['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert info['id'] == '4090227752001'

# Generated at 2022-06-24 12:22:52.312510
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('blah', 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.name == 'eitb.tv'
    assert ie.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:22:53.203168
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-24 12:23:03.815923
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:23:07.389043
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for EitbIE using the test video
    """
    EitbIE()._real_initialize()
    EitbIE()._real_extract(EitbIE()._TEST)

# Generated at 2022-06-24 12:23:09.801279
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:21.637385
# Unit test for constructor of class EitbIE
def test_EitbIE():
    results = EitbIE()._real_extract(EitbIE._TEST['url'])

    assert results['id'] == EitbIE._TEST['info_dict']['id']
    assert results['ext'] == EitbIE._TEST['info_dict']['ext']
    assert results['title'] == EitbIE._TEST['info_dict']['title']
    assert results['description'] == EitbIE._TEST['info_dict']['description']
    assert results['duration'] == EitbIE._TEST['info_dict']['duration']
    assert results['timestamp'] == EitbIE._TEST['info_dict']['timestamp']
    assert results['upload_date'] == EitbIE._TEST['info_dict']['upload_date']

# Generated at 2022-06-24 12:23:25.982667
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from __main__ import EitbIE
    # if is not a EitbIE instance,
    # then retrieved info will be invalid
    assert isinstance(EitbIE, type(EitbIE()))


# Generated at 2022-06-24 12:23:27.097312
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('4')

# Generated at 2022-06-24 12:23:28.097494
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:23:36.803769
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(object())
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:41.861099
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    url_test = url
    url_test_expected = url
    url_test_result = EitbIE._VALID_URL
    assert EitbIE._VALID_URL == url_test_result
    assert url_test_expected == url_test_result


# Generated at 2022-06-24 12:23:45.810435
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:48.498534
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_c = EitbIE()
    assert eitb_c.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:53.882114
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("test_EitbIE")

    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE()._real_extract(url)

test_EitbIE()

# Generated at 2022-06-24 12:24:00.576941
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    ie._real_extract(url)
    #assert ie._match_id(url) == '4090227752001'
    #assert ie._download_json(url) == '4090227752001'
    #assert ie.IE_NAME == 'eitb.tv'
    #assert ie._real_extract(url) == '4090227752001'
    #assert ie._download_json(url) == '4090227752001'

# Generated at 2022-06-24 12:24:04.814253
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:24:05.787074
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-24 12:24:07.041780
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:08.598986
# Unit test for constructor of class EitbIE
def test_EitbIE():
	"""
	Unit test for the EitbIE class.
	"""
	EitbIE()

# Generated at 2022-06-24 12:24:10.190604
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('EitbIE', {}, 'Eitb')
    assert instance

# Generated at 2022-06-24 12:24:16.433214
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Initialize the class
    ie = EitbIE()
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4129171860001/gazte-komunikabide/'
    # Check the URL, if it's valid return True, otherwise return False
    match = ie._VALID_URL.match(url)
    assert match
    # Obtain the video URL and the video ID
    video_id = match.group('id')

# Main unit test

# Generated at 2022-06-24 12:24:21.434051
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.download("http://www.eitb.tv/eu/bideoa/bizitza-kontuak/25/1/2013/6945/")
    ie.download("http://www.eitb.tv/eu/bideoa/bizitza-kontuak/26/1/2013/6946/")
    ie.download("http://www.eitb.tv/eu/bideoa/bizitza-kontuak/27/1/2013/6947/")
    ie.download("http://www.eitb.tv/eu/bideoa/bizitza-kontuak/28/1/2013/6948/")

# Generated at 2022-06-24 12:24:26.539945
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('wwww.eitb.tv', None)
    assert(ie.IE_NAME == 'EitbIE')
    assert(ie.ie == 'wwww.eitb.tv')
    assert(ie.ie_key == None)
    assert(ie.extractor is None)

# Generated at 2022-06-24 12:24:28.865114
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:24:29.259217
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:24:31.414823
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        eitbIE = EitbIE()
    except: # do nothing since an exception is actually expected
        pass


# Generated at 2022-06-24 12:24:40.762297
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:24:45.017184
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    class_(None)._real_extract('http://www.eitb.tv/eu/bideoa/60-minutos/4090227751001/')

# Generated at 2022-06-24 12:24:56.269971
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Arguemnt 'url' is assigned to the attribute
    assert EitbIE(url="http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/").url == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    # Arguemnt 'url' is assigned to the attribute

# Generated at 2022-06-24 12:25:01.163544
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:25:02.886928
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e is not None

# Generated at 2022-06-24 12:25:04.856175
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e

# Generated at 2022-06-24 12:25:11.249003
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:14.333126
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.name == 'eitb.tv')
    assert(EitbIE.description == 'Eitb.tv videos')
    assert(EitbIE.IE_NAME == 'eitb.tv')


# Generated at 2022-06-24 12:25:18.700311
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:25:25.274750
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Just a unit test for class EitbIE."""
    
    # Unitialize extractor
    EitbIE_obj = None
    
    # Get url
    url = "http://www.eitb.tv/it/video/bideoak/zinemaldia-azken-zinema-eleberriak/5947702050001/5947702050001/"
    
    # Construct EitbIE
    EitbIE_obj = EitbIE(IE_NAME = "EitbIE", url = url)
    
    # Test if EitbIE is correctly loaded
    print(EitbIE_obj != None)

# Generated at 2022-06-24 12:25:29.333388
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:30.860655
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
        print("Object created!")
    except:
        print("Something went wrong!")
# Test execution
test_EitbIE()

# Generated at 2022-06-24 12:25:37.048854
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_i = EitbIE(None)
    print("Testando EITB...")
    print("Expected name: " + "EITB")
    print("Actual name: " + test_i.IE_NAME)
    assert test_i.IE_NAME == test_i._VALID_URL
    assert test_i.IE_NAME == test_i._TEST

# Generated at 2022-06-24 12:25:38.237812
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("")
    assert("EitbIE" in repr(ie))

# Generated at 2022-06-24 12:25:45.249300
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("\nTesting class EitbIE(InfoExtractor)\n")
    print("\n----testing constructor----")
    print("\ntesting EitbIE(InfoExtractor)")
    extractor = EitbIE(InfoExtractor)
    print("Testing extractor.IE_NAME == IE_NAME")
    print(extractor.IE_NAME == EitbIE.IE_NAME)
    print("Testing extractor._VALID_URL == _VALID_URL")
    print(extractor._VALID_URL == EitbIE._VALID_URL)
    print("Testing extractor._TEST == _TEST")
    print(extractor._TEST == EitbIE._TEST)
    print("----testing extract_info----")
    print("\ntesting extract_info()")

# Generated at 2022-06-24 12:25:45.701991
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE

# Generated at 2022-06-24 12:25:48.642537
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = globals()['EitbIE']
    instance = class_()

    assert instance.ie_key() == 'Eitb'
    assert instance.ie_name() == 'Eitb.tv'

# Generated at 2022-06-24 12:25:51.630114
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC == 'EITB'


# Generated at 2022-06-24 12:25:53.299919
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.ie_key() == "EitbIE"

# Generated at 2022-06-24 12:25:55.128794
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)


# Generated at 2022-06-24 12:26:06.860400
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for id=4090227752001
    eitbie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-urte/')
    assert eitbie._match_id('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-urte/') == '4090227752001'
    # Test for id=4124325454001
    eitbie = EitbIE('http://www.eitb.tv/es/video/otros/4124325454001/')
    assert eitbie._match_

# Generated at 2022-06-24 12:26:11.301197
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:26:13.050003
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ test_EitbIE """
    EitbIE()