

# Generated at 2022-06-24 12:16:13.540824
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for EitbIE
    pass # TODO


# Generated at 2022-06-24 12:16:25.979786
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test class constructor
    inst = EitbIE()
    assert inst.IE_NAME == 'eitb.tv'
    assert inst._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:29.360299
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test constructor of class EitbIE.
    """
    # Test normal initialization
    ie = EitbIE()
    assert ie.ie_key() == 'EitbIE'

    # Test initialization with default parameters

# Generated at 2022-06-24 12:16:33.380624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:16:34.996442
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert "EitbIE" in locals()

# Generated at 2022-06-24 12:16:35.884066
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:16:36.643069
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Create instance of class EitbIE and call constructor
    info = EitbIE()

# Generated at 2022-06-24 12:16:40.233407
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:16:41.917032
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.__name__ is 'EitbIE', 'The name of the class EitbIE must be \'EitbIE\''

# Generated at 2022-06-24 12:16:43.229265
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb is not None

# Generated at 2022-06-24 12:16:44.742942
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE(InfoExtractor())
    assert eitb.name == 'eitb.tv'

# Generated at 2022-06-24 12:16:48.749594
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (
        EitbIE.IE_NAME == 'eitb.tv' and
        EitbIE.IE_DESC ==
        'Euskal Irrati Telebista (EITB)' and
        EitbIE._VALID_URL ==
        r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    )

# Generated at 2022-06-24 12:16:50.911683
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    try:
        assert str(ie) == "<EitbIE: info_extractor='eitb.tv'>"
    except AssertionError:
        print("FAILED in testing constructor of class EitbIE")


# Generated at 2022-06-24 12:16:51.920586
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:16:53.562173
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == "eitb.tv"

# Generated at 2022-06-24 12:16:56.187567
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE()
    assert test_EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:01.881415
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:03.182321
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:17:04.125220
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE();

# Generated at 2022-06-24 12:17:04.941032
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:17:06.991394
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_eitb = EitbIE()
    assert IE_eitb.ie_key() == 'Eitb'

# Generated at 2022-06-24 12:17:07.611579
# Unit test for constructor of class EitbIE
def test_EitbIE():
  EitbIE()

# Generated at 2022-06-24 12:17:18.183055
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test URL
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

    # Creating the object
    obj = EitbIE()

    # Check attributes
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert obj.IE_NAME == 'eitb.tv'

    # Check if it can be initialized

# Generated at 2022-06-24 12:17:22.374680
# Unit test for constructor of class EitbIE
def test_EitbIE():

    assert(True)

# Generated at 2022-06-24 12:17:27.709228
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eie = EitbIE()
    assert eie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Test EitbIE._real_extract()

# Generated at 2022-06-24 12:17:28.675088
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert(EitbIE() != None)

# Generated at 2022-06-24 12:17:32.592292
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:17:39.490508
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = 4104995148001
    # Testing regular case
    regular_case = EitbIE()
    json = regular_case._download_json(
        'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % video_id,
        video_id, 'Downloading video JSON')
    # Check that json is correctly extracted
    assert json['web_media'][0]['RENDITIONS'][0]['ENCODING_RATE'] is not None

# Generated at 2022-06-24 12:17:40.105057
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:17:41.480482
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'EitbTV'

# Generated at 2022-06-24 12:17:43.698991
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('ie', 'eitb.tv')
    assert ie.ie_key() == 'eitb.tv'
    assert ie.ie_name() == 'eitb.tv'

# Generated at 2022-06-24 12:17:44.471502
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:17:56.271524
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from .common import InfoExtractor
	from ..utils import (
		float_or_none,
		int_or_none,
		parse_iso8601,
		sanitized_Request,
	)
	import unittest, inspect
	import sys
	import os

	#TODO: Move these tests to a test suite in common or whatever
	def getTestMethod(cls, name="test_EitbIE"):
		for name, method in inspect.getmembers(cls, predicate=inspect.ismethod):
			if name.startswith(name):
				return method
		return None


# Generated at 2022-06-24 12:17:59.381186
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor method can be called without any parameter or parameters
    """
    assert EitbIE()



# Generated at 2022-06-24 12:18:12.409457
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import CommonIE
    from .eitb import EitbIE
    from .common import InfoExtractorError
    from ..utils import (
        compat_str,
        compat_urllib_request,
    )
    from ..compat import (
        compat_urlparse,
    )
    # Call parent class constructor of class EitbIE
    # Parent class: 'InfoExtractor'
    info_extractor_eitb = EitbIE()
    # Call parent class constructor of class CommonIE
    # Parent class: 'InfoExtractor'
    common_ie = CommonIE()
    # Call private method '_download_webpage_handle' of class EitbIE
    # In order to use 'InfoExtractorError' we had to import it first
    # Same for 'compat_urllib_request'

# Generated at 2022-06-24 12:18:15.039005
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('https://www.youtube.com/watch?v=pCezFESATmw');

# Generated at 2022-06-24 12:18:17.653794
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    return eitb

# Generated at 2022-06-24 12:18:24.550812
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case = EitbIE()

# Generated at 2022-06-24 12:18:27.149230
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        from . import EitbIE
    except ImportError:
        assert False, "Could not import EitbIE."
    assert EitbIE

# Generated at 2022-06-24 12:18:39.242799
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE('www.eitb.tv')
    assert eitb._VALID_URL==r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:46.938664
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    url = url.encode('ascii')
    url = url.decode('utf-8')
    e = EitbIE(url)
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:53.980710
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:02.139028
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.type == 'video'
    assert ie.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie.video_id == '4090227752001'

# Generated at 2022-06-24 12:19:03.058535
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video = EitbIE()

# Generated at 2022-06-24 12:19:10.438632
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:19:11.403728
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:19:16.413701
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test constructor
    eitb_ie = EitbIE()
    # test method _real_extract
    eitb_ie._real_extract("")
    # test method _real_extract with right params
    eitb_ie._real_extract("http://www.eitb.tv/eu/bideoa/joxan-goikoetxea-ez-dago-jakintsua-mugimendu-komikian/4104994855001/4090227752001/")

# Generated at 2022-06-24 12:19:18.782905
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # EitbIE constructor
    eitbie = EitbIE()
    # Check using the expected class
    assert eitbie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:19:24.004720
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:34.146944
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    # Test with url of the form: http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/
    video_url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    test_EitbIE = EitbIE()
    test_EitbIE._real_extract(video_url)
    

                
if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:19:38.289029
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:19:41.446243
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_result = True
    try:
        EitbIE()
    except:
        test_result = False
    assert test_result


# Generated at 2022-06-24 12:19:43.854925
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    if eitb is None:
        print ("ERROR: Error creating EitbIE")
        assert False
    return



# Generated at 2022-06-24 12:19:44.856370
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:19:46.820579
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:19:48.274390
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.__name__ == 'EitbIE'

# Generated at 2022-06-24 12:19:49.680901
# Unit test for constructor of class EitbIE
def test_EitbIE():
  ie = EitbIE()
  print(ie)
  assert ie

# Generated at 2022-06-24 12:19:50.266114
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:19:52.053733
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructors normally take the parameters (self, name).
    """
    eitb = EitbIE()

# Generated at 2022-06-24 12:19:55.524086
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('Eitb','eitb.tv','http://www.eitb.tv/eu/bideoa/')

# Generated at 2022-06-24 12:19:56.434054
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(True)

# Generated at 2022-06-24 12:20:03.581021
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Check constructor, loading 13th page of videos from etbSat's channel
    # (http://www.eitb.tv/eu/bideoa/etbsat/)
    etbsat_channel_videos_url = 'http://www.eitb.tv/eu/bideoa/etbsat/?p=12'
    EitbIE(etbsat_channel_videos_url)


#########################################################################
##
## Unit tests for EitbIE
##
#########################################################################

import unittest
from yt_dl.utils import UpdateChecker


# Generated at 2022-06-24 12:20:04.468438
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE != None

# Generated at 2022-06-24 12:20:10.995263
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_ie = EitbIE()
    video = eitb_ie.extract(url)
    assert video['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert video['id'] == '4090227752001'

# Generated at 2022-06-24 12:20:17.188224
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://blabla.com/blabla/http%3A%2F%2Fvid1.beckett.bla.com%2Fbla')
    assert ie._match_id('http://blabla.com/blabla/http%3A%2F%2Fvid1.beckett.bla.com%2Fbla') != None

# Generated at 2022-06-24 12:20:22.230744
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test to ensure the appropriate class constructor is
    instantiated.
    """
    expected_instance = EitbIE()
    assert isinstance(expected_instance, EitbIE)


# Generated at 2022-06-24 12:20:26.528497
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url_test = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE(url_test)

# Generated at 2022-06-24 12:20:27.113548
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE()

# Generated at 2022-06-24 12:20:30.993161
# Unit test for constructor of class EitbIE
def test_EitbIE():
    o = EitbIE()
    # assert attrs are defined. 
    assert o.IE_NAME == 'eitb.tv'
    assert o._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:32.246354
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:20:38.230237
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test case for instance creation of class EitbIE
    _ = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:20:43.581529
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie=EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:49.460249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .EitbIE import EitbIE
    new_class = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    return new_class

# Generated at 2022-06-24 12:21:00.747333
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test_url1 = """http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos/4104994735001/4104994735001/lasa-y-zabala-30-urte/"""
	test_url2 = """http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos/4104994735001/4104994735001/lasa-y-zabala-30-urte/"""

	assert(EitbIE._match_id(test_url1) == EitbIE._match_id(test_url2))

# Generated at 2022-06-24 12:21:02.859743
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(EitbIE._VALID_URL)
    assert ie.ie_key() == EitbIE._VALID_URL

# Generated at 2022-06-24 12:21:03.540405
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() is not None

# Generated at 2022-06-24 12:21:04.606073
# Unit test for constructor of class EitbIE
def test_EitbIE():
    classe = EitbIE
    assert classe is not None

# Generated at 2022-06-24 12:21:13.100338
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    # Download info of url
    info = dict(EitbIE().extract(url))
    assert info['url'] == 'http://eitb-hls.euskaltel.net/hls-live/_definst_/eitb1.stream/playlist.m3u8?hdnts=a5a3aaf4-4d4c-4c0d-8a61-9eeec639a8c6'



# Generated at 2022-06-24 12:21:13.743119
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE();

# Generated at 2022-06-24 12:21:19.581866
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:20.639618
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-24 12:21:21.778907
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # EitbIE's constructor should take one parameter, name.
    assert callable(EitbIE)

# Generated at 2022-06-24 12:21:29.244088
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.IE_NAME == 'eitb.tv')
    assert(EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:21:31.146103
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    assert info_extractor.IE_NAME == "EitbIE"

# Generated at 2022-06-24 12:21:40.098470
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:21:42.866120
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "EitbIE"


# Generated at 2022-06-24 12:21:47.986488
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    instance = EitbIE(url)
    return instance

# Generated at 2022-06-24 12:21:48.600334
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-24 12:21:52.364471
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:57.901590
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url="http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
	eitb_ie = EitbIE()
	#eitb_ie.suitable(url)
	#eitb_ie.get_urls(url)
	eitb_ie.extract(url)


# Generated at 2022-06-24 12:22:09.137634
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Init
    Eitb = EitbIE()

    # Test regex
    valid_url_1 = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    valid_url_2 = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:22:17.033290
# Unit test for constructor of class EitbIE
def test_EitbIE():

    import ijson
    from ..utils import bytes_to_intlist
    from ..compat import compat_urllib_request
    from ..downloader.http import HttpFD

    video_id = '4104995148001'

    url_js = 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/' + video_id + '/'

    request = sanitized_Request(url_js)
    web_fd = compat_urllib_request.urlopen(request)
    web_content = compat_urllib_request.urlopen(request).read()
    web_size = bytes_to_intlist(web_content)

    http_fd = HttpFD(web_fd, web_size)

    def no_return():
        pass

# Generated at 2022-06-24 12:22:27.937189
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = EitbIE()._TEST['url']

# Generated at 2022-06-24 12:22:28.844740
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:22:29.972280
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE in globals().values()

# Generated at 2022-06-24 12:22:35.159430
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:35.937735
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:22:40.135468
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.ie_key() == 'eitb.tv'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.THUMBNAIL_URL_TEMPLATE
    assert ie._VALID_URL

# Generated at 2022-06-24 12:22:43.188093
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # create class EitbIE and assert that it is not None
    eitb_ie = EitbIE()
    assert(EitbIE is not None)

# Generated at 2022-06-24 12:22:44.758924
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:22:45.419547
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:22:47.270627
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

    assert ie.ie_key() == 'eitb.tv'

# Generated at 2022-06-24 12:22:55.162598
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    # Create object of class EitbIE
    eitbIE = EitbIE()
    # Test Video ID
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'



# Generated at 2022-06-24 12:22:56.533756
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-24 12:23:06.679620
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert(EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998')

# Generated at 2022-06-24 12:23:10.518622
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    print("%s\n" % eitbIE)


# Example to show how to use the constructor of the class EitbIE
test_EitbIE()

# Generated at 2022-06-24 12:23:22.139367
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert EitbIE._TEST['info_dict']['id'] == '4090227752001'
    assert EitbIE._TEST

# Generated at 2022-06-24 12:23:25.576512
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie._VALID_URL

# Generated at 2022-06-24 12:23:28.487374
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instancia = EitbIE()
    if instancia.IE_NAME != 'eitb.tv':
        raise ValueError('El nombre de la instancia tiene que ser eitb.tv')

# Generated at 2022-06-24 12:23:29.945433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for inserting appropriate constructor parameters
    EitbIE(0, 0, 0)

# Generated at 2022-06-24 12:23:31.415979
# Unit test for constructor of class EitbIE
def test_EitbIE():

    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:40.045379
# Unit test for constructor of class EitbIE
def test_EitbIE():
    extractor = EitbIE()
    assert extractor.IE_NAME == 'eitb.tv'
    assert extractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:47.601800
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == (u'https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)')


# Generated at 2022-06-24 12:23:50.284242
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test instantiating the EitbIE object
    eitbIE = EitbIE()
    assert isinstance(eitbIE, EitbIE)


# Generated at 2022-06-24 12:23:50.929865
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-24 12:23:59.325126
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)
    assert ie.url == url
    assert ie.name == EitbIE.IE_NAME
    assert ie.valid_url == EitbIE._VALID_URL
    test_attr = ie.__class__.__dict__['_TEST']
    assert test_attr['url'] == url
    md5_val = test_attr['md5']
    assert md5_val == 'edf4436247185adee3ea18ce64c47998'
    info_dict = test_attr['info_dict']


# Generated at 2022-06-24 12:23:59.954758
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:24:05.815250
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    @type EitbIE: unit test
    """
    # Test initiation
    assert EitbIE
    assert InfoExtractor
    # Test instantiation
    assert EitbIE(None)
    with pytest.raises(Exception, message=None):
        EitbIE('')
    # Test normal work
    assert EitbIE(InfoExtractor(None, {'_VALID_URL': EitbIE._VALID_URL}))
    # Test __class__
    assert isinstance((EitbIE(None)), object)
    assert isinstance((EitbIE(None)), InfoExtractor)
    # Test __init__
    assert hasattr(EitbIE(None), '_downloader')
    assert hasattr(EitbIE(None), '_working_dir')

# Generated at 2022-06-24 12:24:11.962281
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:24:14.546400
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-24 12:24:18.195333
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

	request = sanitized_Request(
		'http://mam.eitb.eus/mam/REST/ServiceMultiweb/DomainRestrictedSecurity/TokenAuth/',
		headers={'Referer': url})

	ie = EitbIE()
	ie._download_json(request, '4090227752001', 'Downloading auth token')

# Generated at 2022-06-24 12:24:20.345990
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # make sure the constructor works
    eg = EitbIE(None)
    assert isinstance(eg, EitbIE)

# Generated at 2022-06-24 12:24:22.738281
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test instance of EitbIE class
    EitbIE()

# Generated at 2022-06-24 12:24:26.787051
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:36.694000
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().ie_key() == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:45.066235
# Unit test for constructor of class EitbIE
def test_EitbIE():
    valid_url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    invalid_url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/invalid"
    video_id = "4090227752001"
    test_eitb_ie = EitbIE()
    assert test_eitb_ie._match_id(valid_url) == video_id
    assert test_eitb_ie._match_id(invalid_url)

# Generated at 2022-06-24 12:24:54.818259
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('Testing EitbIE constructor')
    url_test_EitbIE = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test_EitbIE = EitbIE()
    test_EitbIE._downloader = mock.Mock()
    test_EitbIE.report_download_webpage = mock.Mock()
    test_EitbIE._extract_m3u8_formats = mock.Mock()
    test_EitbIE._extract_f4m_formats = mock.Mock()

# Generated at 2022-06-24 12:24:57.292271
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb_ie = EitbIE()
	eitb_ie.IE_NAME
	eitb_ie.EitbIE.__name__


# Generated at 2022-06-24 12:24:58.020145
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:24:58.922205
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test it is instantiable
    EitbIE()

# Generated at 2022-06-24 12:24:59.451924
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert True

# Generated at 2022-06-24 12:25:01.552395
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL is not None

# Generated at 2022-06-24 12:25:03.168256
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb_ie = EitbIE()
	print(eitb_ie)

# Generated at 2022-06-24 12:25:04.387285
# Unit test for constructor of class EitbIE
def test_EitbIE():
    __test__=1
    test = EitbIE()

# Generated at 2022-06-24 12:25:08.113519
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    e = EitbIE()
    e._real_extract(url)
    

# Generated at 2022-06-24 12:25:09.551527
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()



# Generated at 2022-06-24 12:25:10.126031
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:10.623309
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:15.842363
# Unit test for constructor of class EitbIE
def test_EitbIE():
	import EitbIE as eitb
	url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
	eitb_ie = eitb.EitbIE()
	eitb_ie._real_extract(url)


# Generated at 2022-06-24 12:25:18.352021
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()

# Generated at 2022-06-24 12:25:19.532231
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None


# Generated at 2022-06-24 12:25:22.106436
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for constructor of class EitbIE
    """
    import youtube_dl.extractor.eitb
    youtube_dl.extractor.eitb.EitbIE()

# Generated at 2022-06-24 12:25:23.202555
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    pass

# Generated at 2022-06-24 12:25:29.125725
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    result = eitb_ie._VALID_URL
    expected = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert result == expected



# Generated at 2022-06-24 12:25:33.516098
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:25:34.123707
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:35.831886
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE(None)
    assert IE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:25:45.728836
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    url2 = 'http://www.eitb.tv/eu/bideoa/madrid_tamaina/5176143769001/futbol_la_liga_primero_lugartenientes_y_despues_el_re_/'
    assert ie.suitable(url)
    assert ie.suitable(url2)
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:25:47.159161
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie

# Generated at 2022-06-24 12:25:47.787036
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing EitbIE...")
    EitbIE(InfoExtractor())

# Generated at 2022-06-24 12:25:56.652463
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:25:57.869388
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # EitbIE has no constructor arguments, so test only creation
    EitbIE()


# Generated at 2022-06-24 12:25:59.648145
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except TypeError as e:
        assert False, 'Test for constructor of class EitbIE failed: ' + str(e)

# Generated at 2022-06-24 12:26:01.230800
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create EITB extractor instance
    ie = EitbIE()

    # Check if right class has been instantiated
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:26:10.498142
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test for EitbIE"""
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Test for the success case
    assert ie.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is True

# Generated at 2022-06-24 12:26:21.381382
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import tests
    x = EitbIE()
    assert x.IE_NAME == 'eitb.tv'
    assert x._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'