

# Generated at 2022-06-24 12:16:14.889515
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert str(EitbIE) == 'eitb.tv'

# Generated at 2022-06-24 12:16:19.560481
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    instance = isinstance(eitb_ie, EitbIE)
    assert instance == True


# Generated at 2022-06-24 12:16:21.014321
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE

# Generated at 2022-06-24 12:16:25.899771
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_test = EitbIE()
    assert eitb_test.IE_NAME == 'eitb.tv'
    assert eitb_test._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:16:31.509850
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    info_extractor = EitbIE()
    result = info_extractor._real_extract(url)
    info_extractor.IE_NAME
    info_extractor._VALID_URL
    assert('4090227752001' in result.keys())

# Generated at 2022-06-24 12:16:36.911015
# Unit test for constructor of class EitbIE
def test_EitbIE():
    x = EitbIE()
    assertEqual(x.IE_NAME, 'eitb.tv')
    assertEqual(x._VALID_URL, '(?P<id>\d+)')


# Generated at 2022-06-24 12:16:37.855889
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._WORKING

# Generated at 2022-06-24 12:16:41.403571
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:16:48.896609
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from ..extractor import InfoExtractor
	from ..utils import parse_iso8601
	from datetime import datetime

	url="http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
	
	eitb_ie = EitbIE(InfoExtractor())

	video_id = eitb_ie._match_id(url)
	assert video_id == '4090227752001'


# Generated at 2022-06-24 12:16:49.813304
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:16:56.284401
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from . import pkg_resources
	from ..utils import (
	    float_or_none,
	    int_or_none,
	    parse_iso8601,
	    sanitized_Request,
	)

	from ..compat import json
	from .common import InfoExtractor
	from .eitb import EitbIE
	from ..utils import (
	    parse_iso8601,
	    strip_jsonp,
	)

    # Instance dinamicly the class EitbIE
	class_dict = {}
	docstring = ''
	_ie = globals()['EitbIE']
	_ie = type(_ie.__name__, (_ie.__bases__[0],), class_dict)
	_ie = _ie(class_dict)

# Generated at 2022-06-24 12:17:06.675098
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:12.409940
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_test = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    eitb_test.match_id('4090227752001')

# Generated at 2022-06-24 12:17:13.262873
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    return eitb

# Generated at 2022-06-24 12:17:14.234554
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:17:15.198660
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-24 12:17:17.109768
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create an object of class EitbIE
    eitbIE = EitbIE()

    # Check if it is an instance of InfoExtractor
    assert isinstance(eitbIE, InfoExtractor)

# Generated at 2022-06-24 12:17:22.183839
# Unit test for constructor of class EitbIE
def test_EitbIE():
	import os
	os.system('python2.7 -m doctest -v __init__.py')

# Generated at 2022-06-24 12:17:25.238910
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    obj = eitb.IE_NAME

# Generated at 2022-06-24 12:17:29.375578
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .IE import IETest
    eitb_ie = EitbIE()
    test = IETest(eitb_ie, eitb_ie.IE_NAME)
    test.run('http://www.eitb.tv/eu/bideoa/1045171/')

# Generated at 2022-06-24 12:17:31.258821
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # This is a rather rudimentary test, but it is something at least
    return EitbIE()

# Generated at 2022-06-24 12:17:33.986416
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(str(EitbIE()) == "<class 'youtube_dl.extractor.eitb.EitbIE'>")

# Generated at 2022-06-24 12:17:35.348918
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:39.350231
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from ..test import get_testcases
    from ..extractor import gen_extractors
    for tc in get_testcases(EitbIE, gen_extractors()):
        yield tc

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 12:17:40.324576
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:17:44.362715
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    Test if the constructor of the class EitbIE is working as expected.
    '''
    eitb = EitbIE()

    assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:45.105147
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()


# Generated at 2022-06-24 12:17:50.755226
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/eu/bideoa/telebista/2015/05/29/Herri-Txikiak.')== EitbIE('http://www.eitb.tv/eu/bideoa/telebista/2015/05/29/Herri-Txikiak.')

# Generated at 2022-06-24 12:17:52.177231
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('test', 'test', 'test')

# Generated at 2022-06-24 12:17:56.168354
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # main test: config.py
    ie = EitbIE()
    assert (ie.IE_NAME == 'eitb.tv')
    assert (ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:17:57.252893
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, None)

# Generated at 2022-06-24 12:18:01.446734
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE({})
    assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:01.958855
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:05.784697
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:09.546391
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE();
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:18:10.999129
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        return False
    return True


# Generated at 2022-06-24 12:18:11.999769
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video = EitbIE()

# Generated at 2022-06-24 12:18:14.677646
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb

# Generated at 2022-06-24 12:18:18.353081
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE("")!=None)

# Generated at 2022-06-24 12:18:19.687639
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert IE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:20.170478
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:23.865069
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Just creates an instance of class EitbIE
    """
    ie = EitbIE()
    assert isinstance(ie, EitbIE) == True

""" From here starts tests with real content """

# Generated at 2022-06-24 12:18:36.167124
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video = t.extract(url)
    assert video.get('title') == '60 minutos (Lasa y Zabala, 30 años)'
    assert video.get('description') == 'Programa de reportajes de actualidad.'
    assert video.get('duration') == 3996.76
    assert video.get('timestamp') == 1381789200
    assert video.get('upload_date') == '20131014'

# Generated at 2022-06-24 12:18:39.982976
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:18:48.189899
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    instancia = EitbIE({'url': url})
    assert instancia.IE_NAME == 'eitb.tv'
    assert instancia._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:51.228395
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie is not None

# Generated at 2022-06-24 12:18:51.536057
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:18:58.708249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    list_of_objects = [ EitbIE(), InfoExtractor(), InfoExtractor() ]
    assert list_of_objects[0].IE_NAME == 'eitb.tv'
    assert list_of_objects[1].IE_NAME == 'generic'
    assert list_of_objects[2].IE_NAME == 'generic'

    test_instance = EitbIE()
    assert test_instance.IE_NAME == 'eitb.tv'
    assert test_instance.IE_DESC == 'EITB.tv'

# Generated at 2022-06-24 12:19:05.724646
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check if constructor is ok
    assert("EitbIE" in globals()) # check that the class is global
    assert("EitbIE" in vars(__builtins__)) # check that the class is defined
    # Test constructor
    eitbIE = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert(eitbIE is not None)

# Generated at 2022-06-24 12:19:08.058059
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test that constructor of class EitbIE is working.
    """
    ie = EitbIE()
    assert isinstance(ie, EitbIE)


# Generated at 2022-06-24 12:19:16.473133
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:21.162674
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    ie.suport_test_mode()
    ie.download(url)

# Generated at 2022-06-24 12:19:26.635415
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert not EitbIE.suitable("https://www.eitb.tv/eu/bideoa/zuzenean/idazleak-ez-dute-hotzak-kostatzen-segidatzeko-bide-ez-dute-kostatzen-eskola-ez-du-kostatzen-etab/")


# Generated at 2022-06-24 12:19:27.883828
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert(e is not None)

# Generated at 2022-06-24 12:19:28.650412
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:19:31.435720
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (EitbIE()._VALID_URL ==
            'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:19:32.799198
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-24 12:19:34.601410
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"

# Generated at 2022-06-24 12:19:35.687419
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE is not None

# Generated at 2022-06-24 12:19:36.263122
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:19:38.918760
# Unit test for constructor of class EitbIE
def test_EitbIE():
    expected_class = 'EitbIE'
    found_class = EitbIE.__name__
    assert(expected_class == found_class)



# Generated at 2022-06-24 12:19:42.354189
# Unit test for constructor of class EitbIE
def test_EitbIE():
  # Constructor of class EitbIE
  assert EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL) != None


# Generated at 2022-06-24 12:19:50.090263
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    result = ie.extract(url)
    assert result['id'] == '4090227752001'

# Generated at 2022-06-24 12:19:55.172264
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb.IE_NAME == 'eitb.tv'



# Generated at 2022-06-24 12:20:01.829382
# Unit test for constructor of class EitbIE
def test_EitbIE():
    vimeo = EitbIE().get_test()
    assert_equal(vimeo.ie_key(), 'Eitb')
    assert_equal(vimeo.ie_name(), 'eitb.tv')
    assert_equal(vimeo.video_id(), '4090227752001')
    assert_equal(vimeo.url, 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % '4090227752001')
    assert_equal(vimeo.title, '60 minutos (Lasa y Zabala, 30 años)')

# Generated at 2022-06-24 12:20:05.519260
# Unit test for constructor of class EitbIE
def test_EitbIE():
    extractor = EitbIE()
    assert extractor.IE_NAME == 'eitb.tv'
    assert extractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:07.160983
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert "EitbIE" in locals()

# Generated at 2022-06-24 12:20:11.504956
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv', 'IE_NAME has changed'

# Generated at 2022-06-24 12:20:16.649068
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    print("Created "+str(obj))
    return

# Generated at 2022-06-24 12:20:25.157608
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Initilizing test
    test = EitbIE()
    # It should be EitbIE
    assert(test.IE_NAME == 'eitb.tv')
    # It should be RegExp
    assert(test._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-24 12:20:32.241174
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE(InfoExtractor()) #Create a EitbIE object
    assert eitb_ie.IE_NAME == 'eitb.tv' #Check the name of the IE is 'eitb.tv'
    inf_extr = InfoExtractor() #Create an InfoExtractor object (for the test)
    assert isinstance(inf_extr, InfoExtractor) #Check that inf_extr is an InfoExtractor object
    assert hasattr(inf_extr, '_downloader') #Check that inf_extr has an attribute _downloader
    assert hasattr(eitb_ie, '_downloader') #Check that eitb_ie has an attribute _downloader
    assert isinstance(eitb_ie._downloader, InfoExtractor) #Check that eitb_ie._download

# Generated at 2022-06-24 12:20:43.294461
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Test parser for http://www.eitb.tv/eu/bideoa/gaur/4082969000001/4092415238001/hau-tolosako-elkartasunak-taldeko-soinu-txagorra/ """
    def check_src(src):
        assert src == "http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4092415238001/"

    def test_response(response):
        """ Test response from http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4092415238001/"""
        assert response['web_media'][0]['RENDITIONS'][0]['PMD_URL']

# Generated at 2022-06-24 12:20:48.983611
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.name == 'EitbIE'

# Generated at 2022-06-24 12:20:51.261522
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_test = EitbIE()

# Generated at 2022-06-24 12:20:55.825676
# Unit test for constructor of class EitbIE
def test_EitbIE():
    constructor_test(EitbIE, ['http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/'])

# Generated at 2022-06-24 12:20:59.864331
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    i = EitbIE('Eitb')
    i = EitbIE(i.ie_key())

if __name__ == "__main__":
    test_EitbIE()

# Generated at 2022-06-24 12:21:01.836038
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('www.eitb.tv') == EitbIE('EitbIE')

# Generated at 2022-06-24 12:21:03.181305
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == EitbIE.VALID_URL

# Generated at 2022-06-24 12:21:04.216623
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-24 12:21:08.416575
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor(),"http://www.eitb.tv/eu/bideoa/erakusleihoa/la-apuesta-de-el-vagon/4106307711001/4106919829001/")
    EitbIE(InfoExtractor(),"http://www.eitb.tv/eu/bideoa/especiales/50-urte-bideojokoetarako/4106269061001/")

test_EitbIE()

# Generated at 2022-06-24 12:21:09.366895
# Unit test for constructor of class EitbIE
def test_EitbIE():
    arr = EitbIE()

# Generated at 2022-06-24 12:21:21.560551
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    expected = {
        'id': '4090227752001',
        'ext': 'mp4',
        'title': '60 minutos (Lasa y Zabala, 30 años)',
        'description': 'Programa de reportajes de actualidad.',
        'duration': 3996.76,
        'timestamp': 1381789200,
        'upload_date': '20131014',
        'tags': list,
    }

    # Create the object
    ie = EitbIE()

    # Check if it matches the url
    assert ie

# Generated at 2022-06-24 12:21:29.338997
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    if ie.IE_NAME == 'eitb.tv':
        assert ie.IE_NAME == 'eitb.tv'
    if ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)':
        assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:31.973077
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb is not None

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:21:35.537765
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test = EitbIE()
	assert isinstance(test,EitbIE)

# Generated at 2022-06-24 12:21:38.335488
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:21:43.545210
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ tests for instance of EitbIE """
    eitb = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(eitb.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(eitb.params == {})

# Generated at 2022-06-24 12:21:47.701838
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert EitbIE(EitbIE._TEST.get('url'))
    except AssertionError:
        print("Error when creating an instance of EitbIE", EitbIE._TEST.get('url'))


# Generated at 2022-06-24 12:21:50.911831
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create an instance of class EitbIE
    eitb_ie = EitbIE()
    # Check for its attributes
    assert eitb_ie._VALID_URL
    assert eitb_ie.IE_NAME
    assert eitb_ie._TEST

# Generated at 2022-06-24 12:22:01.624331
# Unit test for constructor of class EitbIE
def test_EitbIE():
    extractor = EitbIE()
    _assert_m3u8_urls('http://www.eitb.tv/eu/bideoa/etb-telebista/idazkaritza/idazkaritza-1/4090227752001/', extractor)
    _assert_m3u8_urls('http://www.eitb.tv/eu/bideoa/teledonosti-2012/teledonosti-2012-24/4104988086001/', extractor)
    _assert_m3u8_urls('http://www.eitb.tv/eu/bideoa/etb-telebista/eguzkitan/eguzkitan-5/4104988099001/', extractor)

# Generated at 2022-06-24 12:22:04.661842
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # First time: create object of class EitbIE
    eitbIE = EitbIE()

    assert eitbIE.IE_DESC == 'eitb.tv'

# Generated at 2022-06-24 12:22:14.369182
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert 'eitb.tv' in eitb_ie.IE_NAME
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    test_dict = eitb_ie._TEST
    url = test_dict['url']
    md5 = test_dict['md5']
    info_dict = test_dict['info_dict']
    assert eitb_ie._match_id(url) == info_dict['id']
    eitb_ie._real_extract(url)
    # The following download is not a good unit test because it is too slow
    #

# Generated at 2022-06-24 12:22:15.666644
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiating class
    EitbIE()

# Generated at 2022-06-24 12:22:17.158232
# Unit test for constructor of class EitbIE
def test_EitbIE():
  video = EitbIE()
  assert video

# Generated at 2022-06-24 12:22:19.242345
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)


# Generated at 2022-06-24 12:22:21.453672
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_test = EitbIE()
    assert isinstance(eitb_test, EitbIE)


# Generated at 2022-06-24 12:22:24.508817
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # It's a lame test (the class should be tested deeply), but it's a beginning
    class_ = EitbIE
    instance = class_()
    assert class_ == instance.IE_NAME

# Generated at 2022-06-24 12:22:31.446359
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert EitbIE.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:22:38.228182
# Unit test for constructor of class EitbIE
def test_EitbIE():
	#Test case 1: Constructor with a valid URL
	url1 = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
	expected_result1 = "4090227752001"
	assert EitbIE._match_id(url1)==expected_result1



# Generated at 2022-06-24 12:22:39.979001
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # tests the constructor without exception...
    ie = EitbIE()

# Generated at 2022-06-24 12:22:44.377471
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/zuzendaritza-ikastaro-berriak/4090227762001/4090227764001/', {})
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:22:45.067725
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Not a real instance, only for testing the module
    assert isinstance(EitbIE(), EitbIE)

# Generated at 2022-06-24 12:22:49.561709
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:01.239803
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:06.284318
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.__name__ == 'eitb.tv'
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:23:07.263913
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()

# Generated at 2022-06-24 12:23:10.043720
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert(eitb_ie is not None)

# Generated at 2022-06-24 12:23:11.248806
# Unit test for constructor of class EitbIE
def test_EitbIE():
	x = EitbIE()
	return True

# Generated at 2022-06-24 12:23:11.836881
# Unit test for constructor of class EitbIE
def test_EitbIE():
	pass

# Generated at 2022-06-24 12:23:14.143755
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.ie.__name__ == 'eitb.tv'


# Generated at 2022-06-24 12:23:15.537711
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert(EitbIE)
    except NameError:
        assert False

# Generated at 2022-06-24 12:23:20.928901
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)
    ie.extract()

# Generated at 2022-06-24 12:23:24.319103
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    EitbIE.IE_NAME
    EitbIE._VALID_URL
    EitbIE._TEST
    eitb._real_extract

# Generated at 2022-06-24 12:23:24.946052
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:23:29.524983
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.test()


# Generated at 2022-06-24 12:23:31.715290
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('www.eitb.tv/eu/bideoa')
    assert ie != None



# Generated at 2022-06-24 12:23:33.565399
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    # this just tests that it doesn't raise an exception in that case
    instance._real_initialize()

# Generated at 2022-06-24 12:23:41.598071
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    info = EitbIE()._real_extract(url)
    result = {
        "id": "4090227752001",
        "title": "60 minutos (Lasa y Zabala, 30 años)",
        "description": "Programa de reportajes de actualidad.",
        "duration": 3996.76,
        "timestamp": 1381789200,
        "upload_date": "20131014",
    }
    for key in info:
        if key not in result:
            assert False

# Generated at 2022-06-24 12:23:47.228729
# Unit test for constructor of class EitbIE
def test_EitbIE():
    if not EitbIE().suitable('http://www.eitb.tv/eu/bideoa/aritzen-bideoak/aritzen-txartela/4104995148001/4964891185001/narros-cortando-maiz/'):
        raise Exception('EitbIE does not suit the URL')

# Generated at 2022-06-24 12:23:49.507368
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:58.489819
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert not EitbIE(unit_test=True).suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert not EitbIE(unit_test=True).suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/')
    assert not EitbIE(unit_test=True).suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/')
    assert not Eitb

# Generated at 2022-06-24 12:24:04.367167
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME=='eitb.tv'
    assert eitbIE._VALID_URL==r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE.IE_DESC=='Eitb'

# Generated at 2022-06-24 12:24:09.472730
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:24:14.010510
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert 'eitb.tv' in EitbIE._build_ie_result({
        'id': '34',
        'url': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/34/',
    })

# Generated at 2022-06-24 12:24:24.647063
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:24:26.633848
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()
    assert t.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:31.508147
# Unit test for constructor of class EitbIE
def test_EitbIE():
  ie = EitbIE('<some_url>')
  assert ie.IE_NAME == 'eitb.tv'
  assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:40.840679
# Unit test for constructor of class EitbIE
def test_EitbIE():

    video_id = '4090227752001'

    info_dict = {
        'id': '4090227752001',
        'ext': 'mp4',
        'title': '60 minutos (Lasa y Zabala, 30 años)',
        'description': 'Programa de reportajes de actualidad.',
        'duration': 3996.76,
        'timestamp': 1381789200,
        'upload_date': '20131014',
        'tags': list,
    }


# Generated at 2022-06-24 12:24:49.129587
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Sometimes the order of constructor parameters can be changed.
    # So, let's check that order doesn't matter.
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    eitb_ie = EitbIE('eitb.tv', r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert eitb_ie.ie_key() == 'eitb.tv'
    assert eitb_ie._

# Generated at 2022-06-24 12:24:51.543408
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        eitb = EitbIE()
        assert True
    except Exception:
        assert False
        

# Generated at 2022-06-24 12:24:52.527102
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_obj = EitbIE()

# Generated at 2022-06-24 12:24:54.526568
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Ensure an instance of the class EitbIE could be created
    eitb = EitbIE(IE_NAME)
    assert eitb is not None

# Generated at 2022-06-24 12:24:58.094033
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_class = EitbIE
    # Unit test for constructor of class EitbIE
    def test_EitbIE():
        test_class = EitbIE
        ie = EitbIE()
        assert ie.IE_NAME == IE_NAME

# Generated at 2022-06-24 12:24:59.005154
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:24:59.870807
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE



# Generated at 2022-06-24 12:25:07.710569
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test extractor
    eitbIE = EitbIE()

    # test video URL using getVideoInfo
    video_url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_info = eitbIE.getVideoInfo(video_url)
    assert video_info['id'] == '4090227752001'
    assert video_info['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert video_info['description'] == 'Programa de reportajes de actualidad.'
    assert video_info['duration'] == 3996.76

# Generated at 2022-06-24 12:25:08.486995
# Unit test for constructor of class EitbIE
def test_EitbIE():
  pass

# Generated at 2022-06-24 12:25:09.065377
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:18.351731
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test 1
    # This URL is a video
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()._real_initialize()
    # Test for the private object _VALID_URL
    ie._VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    # Test for the regular expression
    assert ie._VALID_URL_RE.match(url)
    # Test for the method _real_extract(url)
    video

# Generated at 2022-06-24 12:25:23.382508
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE=EitbIE()
    assert eitbIE._VALID_URL.startswith('https?://')
    assert eitbIE._TEST.get('url')!=None
    assert eitbIE._TEST.get('title')!=None
    assert eitbIE._TEST.get('duration')!=None
    assert eitbIE._TEST.get('id')!=None


# Generated at 2022-06-24 12:25:23.993486
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:27.166896
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.IE_NAME == 'eitb.tv')
    assert(EitbIE.IE_DESC == 'EITB')


# Generated at 2022-06-24 12:25:32.018295
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert obj.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:25:32.967715
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()


# Generated at 2022-06-24 12:25:39.126704
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._downloader is not None
    assert ie._match_id('4090227752001') == '4090227752001'

# Generated at 2022-06-24 12:25:43.401185
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == '^https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:47.941640
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:48.266297
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:49.021597
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:50.816915
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    Test for constructing and initializing of EitbIE class
    '''
    assert EitbIE

# Generated at 2022-06-24 12:25:58.478403
# Unit test for constructor of class EitbIE
def test_EitbIE():
    global video_id
    global video
    global media
    global formats
    global examples
    global token
    global token_data
    global hls_url
    global request
    global hds_url
    EitbIE()
    assert(isinstance(video_id, basestring))
    assert(isinstance(video, dict))
    assert(isinstance(media, dict))
    assert(isinstance(formats, list))
    assert(isinstance(examples, list))
    assert(isinstance(token, basestring))
    assert(isinstance(token_data, dict))
    assert(isinstance(hls_url, basestring))
    assert(isinstance(request, Request))
    assert(isinstance(hds_url, basestring))


# Generated at 2022-06-24 12:25:59.204835
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() is not None

# Generated at 2022-06-24 12:25:59.897499
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:26:00.515017
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:26:04.695563
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(InfoExtractor())._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    

# Generated at 2022-06-24 12:26:12.729344
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:26:18.220628
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # View the source of the http://eitb.tv/eu/bideoa/multimedia.eitb.eus/euskaltelevizioa/multimedia/20131015/130705/res/1/38/39/index.html
    # The test should be set up with the values of the first video in the screen
    assert isinstance(EitbIE, object)
    return True