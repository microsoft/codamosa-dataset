

# Generated at 2022-06-24 12:16:16.707762
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-24 12:16:22.127503
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        inst = EitbIE()
        assert(inst is not None)
    except Exception:
        assert(False)

# Generated at 2022-06-24 12:16:23.912146
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:16:29.366012
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:35.854273
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/filmak/denbora-soldadua/3080405148001/')
    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:16:41.983045
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:16:42.756170
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:49.695155
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test basic functions of EitbIE"""
    ie_obj = EitbIE(EitbIE._VALID_URL)
    assert (ie_obj._match_id('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') == '4090227752001')
    test = ie_obj._download_json('http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4090227752001/', '4090227752001', 'Downloading video JSON')
    assert (test[u'web_media'][0][u'encoding_rate'] != None)

#

# Generated at 2022-06-24 12:16:56.203767
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # argument url is not used here, but I leave it here because it only pass the argument between functions
    extractor = EitbIE(None)
    assert extractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert extractor._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert extractor._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert extractor._T

# Generated at 2022-06-24 12:16:56.827457
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:17:01.881484
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    expected_url = 'http://www.eitb.tv/eu/bideoa/4031918/'
    assert ie._extract_url(expected_url) == expected_url
    expected_url = 'http://www.eitb.tv/eu/bideoa/4031918/'
    assert ie._extract_url(expected_url) == expected_url
    expected_url = 'http://www.eitb.tv/eu/bideoa/4031918/'
    assert ie._extract_url(expected_url) == expected_url

# Unit Test for _real_extract function of class EitbIe

# Generated at 2022-06-24 12:17:02.913432
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert True

# Generated at 2022-06-24 12:17:07.673742
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = eval(EitbIE.ie_key())(EitbIE.working_url())
    assert len(ie.extract('http://www.eitb.tv/eu/bideoa/mundu-berriak/04072/argitalpena-koztasunera-erabaki-da/')) == 1
    assert ie.working == True

# Generated at 2022-06-24 12:17:09.095079
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie

# Generated at 2022-06-24 12:17:18.038574
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from utils import UNIT_TEST

    if UNIT_TEST:
        url = 'https://www.eitb.tv/eu/bideoa/errepasoa-herria/4091016217001/'
        ie = EitbIE()
        vid = ie.extract(url)
        assert vid.get('title') != None
        assert vid.get('description') != None
        assert vid.get('thumbnail') != None
        assert vid.get('duration') != None
        assert ie.IE_NAME in vid.get('extractor')
        assert vid.get('tags') != None
        assert len(vid.get('formats')) >= 1

# Generated at 2022-06-24 12:17:23.001806
# Unit test for constructor of class EitbIE
def test_EitbIE():
	obj = EitbIE()
	assert obj != None

# Generated at 2022-06-24 12:17:24.530562
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE(None)
    assert obj is not None

# Generated at 2022-06-24 12:17:30.194533
# Unit test for constructor of class EitbIE
def test_EitbIE():
    res = EitbIE()._real_extract('https://www.eitb.tv/eu/bideoa/idazleak-episodioak-erremintak/4104995148001/idazleak-bideoak/4090227752001/laia-sainz-de-los-terreros/')
    print(res)

test_EitbIE()

# Generated at 2022-06-24 12:17:36.200325
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    #Test url and id extraction
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    id = '4090227752001'
    assert ie._match_id(url) == id

# Generated at 2022-06-24 12:17:44.436858
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ans = EitbIE()._real_extract(test_url)
    if ans['id'] == '4090227752001' :
        if ans['ext'] == 'mp4':
            print ('ext:' + str(ans['ext']))
            if ans['title'] == '60 minutos (Lasa y Zabala, 30 años)':
                print ('title:' + ans['title'])
                print ('pass')



# Generated at 2022-06-24 12:17:56.270871
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:59.791735
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert isinstance(eitb, InfoExtractor) and isinstance(eitb, EitbIE)


# Generated at 2022-06-24 12:18:00.971225
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None).IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:01.696335
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-24 12:18:05.325719
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert isinstance(eitb_ie.IE_NAME, str)
    assert isinstance(eitb_ie._VALID_URL, str)
    assert isinstance(eitb_ie._TEST, dict)


# Generated at 2022-06-24 12:18:06.333092
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:18:11.377610
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:12.317264
# Unit test for constructor of class EitbIE
def test_EitbIE():
	return EitbIE()


# Generated at 2022-06-24 12:18:15.046473
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:20.307438
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _ = EitbIE()

# Generated at 2022-06-24 12:18:26.822323
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    # Testing if the link is valid
    assert e.suitable('http://www.eitb.tv/eu/bideoa/irratia/eitb-irratia/146974/')
    # Testing if the link is invalid
    assert not e.suitable('https://www.youtube.com/watch?v=BhcSq7fVc6A')


# Generated at 2022-06-24 12:18:27.408730
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:28.692512
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:35.612306
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #Constructor
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:40.657421
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Testing the constructor of class EitbIE:
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:18:45.312119
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("eitb.tv", "60minutos")
    assert ie.name == 'eitb.tv'
    assert ie.ie_key() == 'eitb.tv'
    ie = EitbIE("eitb.tv", "60minutos", "extractor_key")
    assert ie.ie_key() == 'eitb.tv:extractor_key'

# Generated at 2022-06-24 12:18:45.748031
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:48.660575
# Unit test for constructor of class EitbIE
def test_EitbIE():
    x = EitbIE()
    assert x.IE_NAME == 'eitb.tv'
    assert x._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:18:59.798431
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for a valid page
    page_url = 'http://www.eitb.tv/eu/bideoa/sailburu-aldizkaria/401993/'
    video_id = '4090373720001'
    video_url = 'http://www.eitb.tv/eu/bideoa/sailburu-aldizkaria/401993/4090373720001/'
    args = '--username "example@gmail.com" --password "qwerty12345" --video-password "1234" -i --no-download '
    test_url = '%s "%s" %s' % (args, video_url, video_id)
    EitbIE()._real_extract(test_url)

    # Test for a nonexistent page

# Generated at 2022-06-24 12:19:05.269551
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:11.491682
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    #test_class_EitbIE()


#test_EitbIE()
test_class_EitbIE = test_EitbIE
#test_class_EitbIE()

# Generated at 2022-06-24 12:19:13.035802
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE == type(EitbIE({})) # assert that constructor doesn't raise exception

# Generated at 2022-06-24 12:19:23.663901
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test with URL
    ie = EitbIE("https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert ie.url == "https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert ie.video_id == "4090227752001"
    assert ie.NAME == "EitbIE"
    assert ie.IE_DESC == "eitb.tv"

# Generated at 2022-06-24 12:19:31.753974
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:33.139608
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:19:34.098605
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)

# Generated at 2022-06-24 12:19:44.226664
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Test 1: Execution of all functions of class EitbIE, for case 1
    eitb_ie = EitbIE("http://www.eitb.tv/eu/bideoa/sakoneta/302032/4090227752001/")
    test_result = eitb_ie._match_id("http://www.eitb.tv/eu/bideoa/sakoneta/302032/4090227752001/")
    print(test_result)
    assert test_result == '4090227752001'

# Generated at 2022-06-24 12:19:47.227855
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:19:53.492261
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/lasa-y-zabala-30-urte/4104995148001/4090227752001/'
    ie = EitbIE(url)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC == 'Bideoak, euskarazko telesail, ekitaldi eta kanal guztien bermeak'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:00.780218
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    IE = EitbIE(url)
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert IE.IE_NAME == "eitb.tv"
    assert IE.test_video_exists()



# Generated at 2022-06-24 12:20:06.426371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Tests that the constructor of class EitbIE raises a ValueError if an unsupported url is provided as an argument
    url = 'https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert_raises(ValueError, lambda: EitbIE(url))

# Generated at 2022-06-24 12:20:10.233563
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is not None



# Generated at 2022-06-24 12:20:11.975007
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'



# Generated at 2022-06-24 12:20:13.424249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Constructor of class EitbIE")
    ie = EitbIE()

# Generated at 2022-06-24 12:20:14.043810
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:20:23.171478
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test the constructor response of a valid URL
    # Test the constructor response of a valid URL
    valid_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    valid_test = {
        'url': valid_url,
        'only_matching': True,
    }

    # Test the constructor response of an invalid URL
    invalid_url = 'http://www.eitb.tv/es/video/euskaraz-erliebea/4104993785001/4091339443001/euskaraz-erliebea-27/'

# Generated at 2022-06-24 12:20:24.593423
# Unit test for constructor of class EitbIE
def test_EitbIE():
    res = EitbIE()
    assert (res._VALID_URL)

# Generated at 2022-06-24 12:20:28.192643
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:31.599748
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie
    updater = ie.ie_key_map_updater()
    assert updater

# Generated at 2022-06-24 12:20:34.382391
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test that the EitbIE constructor works
    eitb_ie = EitbIE()
    assert eitb_ie is not None

# Generated at 2022-06-24 12:20:35.088953
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:20:44.462680
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.IE_NAME == 'eitb.tv')
    assert(EitbIE.IE_DESC == 'EITB.tv videos')
    assert(EitbIE.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:20:45.177477
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    print(instance)

# Generated at 2022-06-24 12:20:47.669163
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()


# Generated at 2022-06-24 12:20:49.285698
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:56.837261
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.name, "EitbIE"
    assert ie.ie_key() == 'eitb.tv'
    assert ie.info_dict() == {'id': 'EitbIE', 'name': 'EitbIE', 'extractor': 'EitbIE'}
    assert ie.work() == True, "EitbIE work() method"

# Generated at 2022-06-24 12:20:58.934140
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:03.089956
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .eitb import EitbIE

    ie = InfoExtractor(EitbIE.IE_NAME)
    assert ie != None
    assert ie.ie_key() == EitbIE.IE_NAME
    assert ie.IE_DESC == 'EITB'

# Generated at 2022-06-24 12:21:07.157287
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_eitb = EitbIE()
    assert ie_eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:18.894801
# Unit test for constructor of class EitbIE
def test_EitbIE():

	# Test valid URL
	assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

	# Test test dict

# Generated at 2022-06-24 12:21:21.954899
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.IE_NAME == 'eitb.tv')
    assert(EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-24 12:21:32.381566
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_video_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test_video_id = '4090227752001'
    try:
        EitbIE._download_json(EitbIE._VALID_URL, test_video_id, 'Downloading video JSON')
    except:
        EitbIE._real_extract(
            EitbIE(),
            test_video_url
        )

# Generated at 2022-06-24 12:21:42.746023
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.name == 'eitb.tv'
    assert ie.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:21:44.458652
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()


# Generated at 2022-06-24 12:21:45.160189
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:46.288731
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:50.455353
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:52.363908
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE('test.com', 'http://www.eitb.tv/'), EitbIE)

# Generated at 2022-06-24 12:22:03.407051
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:04.177799
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:22:07.870246
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #print "test_EitbIE()"
    eitbIE = EitbIE()
    print(eitbIE._VALID_URL)
    #eitbIE = EitbIE(EitbIE._VALID_URL)

# Generated at 2022-06-24 12:22:08.511260
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:22:12.752007
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.valid_url()

# Generated at 2022-06-24 12:22:14.987344
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:22:16.298858
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:22:17.914217
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, object, object)

# Generated at 2022-06-24 12:22:20.603028
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert EitbIE._VALID_URL == ie._VALID_URL
    assert EitbIE.IE_NAME == ie.IE_NAME

# Generated at 2022-06-24 12:22:22.345255
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:22:25.587306
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    assert class_("http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/" % '4090227752001') == EitbIE

# Generated at 2022-06-24 12:22:27.701206
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.ie_key() == 'eitb.tv'

# Generated at 2022-06-24 12:22:38.463053
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test the constructor of class EitbIE.
    """
    eitb= EitbIE()
    assert eitb is not None
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.valid_url == ('http://www.eitb.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)', )
    assert eitb.valid_url[0] == 'http://www.eitb.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb.valid_url[1] == ''

# Generated at 2022-06-24 12:22:44.035273
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Test for the first constructor of EitbIE
	eitb_ie = EitbIE()
	assert eitb_ie.IE_NAME == 'eitb.tv'
	assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:46.586202
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info = EitbIE()._real_extract(_TEST['url'])
    print (info)


# Generated at 2022-06-24 12:22:56.298816
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # http://www.eitb.tv/eu/bideoa/desde-el-corte-ingles-de-barakaldo/4104993519001/4087669319001/
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:01.804639
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .eitb import EitbIE
    assert issubclass(EitbIE, InfoExtractor)



# Generated at 2022-06-24 12:23:04.269521
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .eitb import EitbIE
    assert isinstance(EitbIE(InfoExtractor()), InfoExtractor)

# Generated at 2022-06-24 12:23:06.761944
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:23:10.234135
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE();
    infoExtract = InfoExtractor('test_EitbIE');
    infoExtract.add_info_extractor(inst);
    return infoExtract

# Generated at 2022-06-24 12:23:11.826522
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # check  constructor
    EitbIE('www.eitb.tv', {})

# Generated at 2022-06-24 12:23:15.736378
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:23:20.220371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/armiarma/4104995148001/4121084596001/gaur-saldatuko-dira-armiarmak-bideoa/'
    assert EitbIE(url)

# Generated at 2022-06-24 12:23:26.538373
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	video = EitbIE._real_extract(EitbIE(), url)
	print(video)

# Generated at 2022-06-24 12:23:31.802457
# Unit test for constructor of class EitbIE
def test_EitbIE():
	class_name = EitbIE.__name__

	print(class_name + " test: begin.")

	try:
		EitbIE()
	except Exception as exception:
		pass
	else:
		print("Excepted exception, but does not occur.")
	finally:
		print(class_name + " test: end.")


# Generated at 2022-06-24 12:23:35.486084
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME=='eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:23:40.606048
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Testcase for constructor of class EitbIE"""
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    if ie:
        print('[CONSTRUCTOR] TESTCASE PASSED')
    else:
        print('[CONSTRUCTOR] TESTCASE FAILED')


# Generated at 2022-06-24 12:23:42.773093
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("www.eitb.tv/eu/bideoa")

# Generated at 2022-06-24 12:23:43.449218
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert True

# Generated at 2022-06-24 12:23:54.204326
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == "eitb.tv"
    assert eitb.VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"
    assert eitb.TEST['url'] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert eitb.TEST['md5'] == "edf4436247185adee3ea18ce64c47998"

# Generated at 2022-06-24 12:23:58.746529
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_IE import run_test
    run_test(EitbIE)

if __name__ == '__main__':
    from .test_IE import run_test
    run_test(EitbIE)

# Generated at 2022-06-24 12:24:00.439042
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('Testing constructor of class EitbIE')
    eitb_ie = EitbIE()
    assert eitb_ie is not None


# Generated at 2022-06-24 12:24:04.398986
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_TEST = EitbIE()
    # Quick test for media type extraction
    assert(IE_TEST._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    # Quick test for data extraction from URL
    assert(IE_TEST._match_id(IE_TEST._TEST['url'])=="4090227752001")

# Generated at 2022-06-24 12:24:08.361589
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing constructor of EitbIE...")
    eitb_ie = EitbIE("eitb.tv")
    assert eitb_ie
    print("OK!")


# Generated at 2022-06-24 12:24:11.186923
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r"https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"
    assert ie.IE_NAME == "eitb.tv"

# Generated at 2022-06-24 12:24:14.052173
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()

test_EitbIE()

# Generated at 2022-06-24 12:24:24.646628
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:33.523889
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_urls = [
        'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
        'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ]
    for url in test_urls:
        ie = EitbIE()
        assert ie.suitable(url) == True

# Generated at 2022-06-24 12:24:35.627792
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE == EitbIE()
    assert EitbIE == EitbIE('Eitb')
    assert EitbIE == EitbIE(type='tv')

# Generated at 2022-06-24 12:24:44.169518
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL)
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    IE = EitbIE(EitbIE.IE_NAME, EitbIE._TEST['url'])

# Generated at 2022-06-24 12:24:46.267807
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:57.433398
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #invalid url
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    #valid url
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    #Video url

# Generated at 2022-06-24 12:24:58.400039
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:25:01.528460
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:06.559284
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:25:16.376837
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE("https://www.eitb.tv/eu/bideoa/bideoak/abesbatza-handia-desfile-del-orgullo-gay-de-bilbao/513814062003/?search_query=abesbatza&sort_field=year&sort_order=desc&filter_content_types=video&filter_years=2016&filter_type=and")
    assert(eitb_ie.IE_NAME == "eitb.tv")
    assert(eitb_ie.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:25:22.973437
# Unit test for constructor of class EitbIE
def test_EitbIE():
	t = EitbIE()
	assert t.IE_NAME == 'eitb.tv'
	assert t._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
	# Note: the dictionary returned by t._TEST is of no interest to us, we just want to know that it is a dictionary
	assert type(t._TEST) == dict

# Unit tests for the _real_extract method of class EitbIE

# Generated at 2022-06-24 12:25:24.083599
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()

# Generated at 2022-06-24 12:25:26.786802
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(EitbIE.ie_key())._VALID_URL == EitbIE._VALID_URL



# Generated at 2022-06-24 12:25:28.919234
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test = EitbIE()
	assert test.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:25:31.515461
# Unit test for constructor of class EitbIE
def test_EitbIE():
    for test in EitbIE._TEST.values():
        ie = EitbIE()
        ie.extract(test['url'])
#
# test_EitbIE()

# Generated at 2022-06-24 12:25:34.792890
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE = EitbIE(EitbIE)
    except:
        return False
    return True

# Generated at 2022-06-24 12:25:35.412412
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:38.112637
# Unit test for constructor of class EitbIE
def test_EitbIE():
    cls = globals()[EitbIE.__name__]
    assert cls(EitbIE.ie_key()) is cls(EitbIE.ie_key())

# Generated at 2022-06-24 12:25:39.125907
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, False)

# Generated at 2022-06-24 12:25:43.621998
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert str(ie.IE_NAME) == 'eitb.tv'
    assert str(ie._VALID_URL) == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert str(ie._TESTS[0]['url']) == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert str(ie._TESTS[0]['md5']) == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:25:44.653475
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-24 12:25:45.680743
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    return obj

# Generated at 2022-06-24 12:25:52.404781
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test url
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    url_match = EitbIE._VALID_URL.match(url)
    assert url_match
    assert url_match.group('id') == '4090227752001'
    assert 'eitb' in EitbIE._WORKING

# Generated at 2022-06-24 12:25:55.722028
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert EitbIE == 'EitbIE'
        print("Test for EitbIE successful!")
    except AssertionError:
        print("Test for EitbIE failed!")


# Test for constructor of class EitbIE
test_EitbIE()

# Generated at 2022-06-24 12:26:07.523771
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    url_hash = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'
    expected_video_id = '4090227752001'
    assert EitbIE._match_id(url) == '4090227752001'
    assert EitbIE._match_id(url_hash) == '4090227752001'

# Generated at 2022-06-24 12:26:12.800222
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:26:14.771256
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import EitbIE
    EitbIE(2)
