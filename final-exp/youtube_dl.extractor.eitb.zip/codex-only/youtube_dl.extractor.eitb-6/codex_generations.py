

# Generated at 2022-06-24 12:16:16.861843
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:22.201079
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE(None)
    except TypeError as e:
        assert e.args[0] == "expected string or buffer"

# Generated at 2022-06-24 12:16:23.189951
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-24 12:16:25.840927
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/4104995148001/4090227752001/lasa-y-zabala-30-urte/')

# Generated at 2022-06-24 12:16:27.912765
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # It should be a EitbIE object
    assert isinstance(_test_EitbIE(), InfoExtractor)


# Generated at 2022-06-24 12:16:29.325914
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(EitbIE._downloader).IE_NAME == 'eitb.tv'



# Generated at 2022-06-24 12:16:30.281361
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    return eitb

# Generated at 2022-06-24 12:16:31.565192
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE

# Generated at 2022-06-24 12:16:34.715399
# Unit test for constructor of class EitbIE
def test_EitbIE():
    tester = EitbIE()

# Generated at 2022-06-24 12:16:37.377612
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test to check if the EitbIE constructor works"""
    ie = EitbIE()
    name = "eitb.tv"
    assert ie.IE_NAME == name, \
        "Expected %s, got %s" % (name, ie.IE_NAME)


# Generated at 2022-06-24 12:16:38.136789
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE is not None

# Generated at 2022-06-24 12:16:41.500132
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC == 'Eitb.tv'

# Generated at 2022-06-24 12:16:42.050360
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:49.855019
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()
	eitb.test_yield_result('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', '4104995148001')
	eitb.test_yield_result('http://www.eitb.tv/eu/bideoa/eskaera-motak/4104995134001/4086449461001/eskaerak/', '4086449461001')

test_EitbIE()

# Generated at 2022-06-24 12:16:51.790658
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE()
    assert(test_EitbIE.IE_NAME == 'eitb.tv')

# Generated at 2022-06-24 12:17:01.569098
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(ie.name == 'EitbIE')
    assert(str(ie.url) == 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(ie.url_id == '4090227752001')

# Generated at 2022-06-24 12:17:05.554176
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert(EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:17:07.890286
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE();
    #e._downloader.params['skip_download'] = True;
    e.download(EitbIE._TEST["url"]);

# Generated at 2022-06-24 12:17:18.404747
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create an instance of EitbIE
    eitbIE = EitbIE()
    # Test if __init__ method works
    assert(eitbIE.IE_NAME == 'eitb.tv')
    assert(eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert(eitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:17:22.978436
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:31.565004
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/zinema/2684530/la-luz-de-la-pantalla/')
    # Test both components of the URL separately
    ie = EitbIE('http://www.eitb.tv/eu/bideoa')
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/2684530')
    # Test the same URL with www
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/zinema/2684530/la-luz-de-la-pantalla/')

# Generated at 2022-06-24 12:17:36.709397
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.app_version == '3.3.0'


# Generated at 2022-06-24 12:17:38.126564
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = EitbIE._TEST['url']


# Generated at 2022-06-24 12:17:42.154583
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:42.888325
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:17:48.531224
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:17:53.925963
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-24 12:18:04.210309
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

    obj = ie.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert obj == True

    obj = ie.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert obj == True

    obj = ie.suitable('https://raw.githubusercontent.com/rg3/youtube-dl/master/README.md')
    assert obj == False


# Generated at 2022-06-24 12:18:04.810720
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:09.933036
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.IE_DESC == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:16.283047
# Unit test for constructor of class EitbIE
def test_EitbIE():
  # Test with just the url
  url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"

  EitbIE()._real_extract(url)
  EitbIE()._real_initialize(url)

# Generated at 2022-06-24 12:18:16.686129
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:18:21.277816
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)
    assert ie.extract() == EitbIE._TEST

# Generated at 2022-06-24 12:18:23.096042
# Unit test for constructor of class EitbIE
def test_EitbIE():

    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-24 12:18:25.689044
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE()

# Generated at 2022-06-24 12:18:28.303271
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:29.671627
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor())

# Generated at 2022-06-24 12:18:31.967934
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Just tests if the class can be instantiated and not if it's correct.
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert type(ie) == EitbIE

# Generated at 2022-06-24 12:18:33.274077
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()

# Generated at 2022-06-24 12:18:36.009900
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    EitbIE class constructor test
    """
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:42.075868
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    downloader = Downloader(EitbIE.IE_NAME,url)
    info_extractor = downloader.get_info_extractor()
    return isinstance(info_extractor,InfoExtractor)

# Generated at 2022-06-24 12:18:42.650612
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE

# Generated at 2022-06-24 12:18:45.775356
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:18:47.170729
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"



# Generated at 2022-06-24 12:18:52.849753
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:57.708553
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eie = EitbIE()
    assert eie.IE_NAME == 'eitb.tv'
    assert eie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:19:07.131091
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:08.761630
# Unit test for constructor of class EitbIE
def test_EitbIE():
    et = EitbIE()
    assert et.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:19:12.704202
# Unit test for constructor of class EitbIE
def test_EitbIE():
    tes = EitbIE()
    assert tes._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:13.546456
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE


# Generated at 2022-06-24 12:19:15.113401
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:19:16.936864
# Unit test for constructor of class EitbIE
def test_EitbIE():
	x = EitbIE()

# Generated at 2022-06-24 12:19:18.556051
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:19:20.230868
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie != None
    return ie

if __name__ == "__main__":
    test_EitbIE()

# Generated at 2022-06-24 12:19:30.246353
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # Test the case the url is valid
    url = 'http://www.eitb.tv/es/video/10-pistas/4130509116001/4132894245001/la-matanza-de-animales-hasta-la-extincion/'
    # Test the case the url is not valid
    url_bad = 'http://www.eitb.tv/es/video/10-pistas/4130509116001'
    # Assert that the url is valid
    assert ie._VALID_URL == 'http://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Assert that the url is valid
    assert ie._

# Generated at 2022-06-24 12:19:41.255820
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
	ex = EitbIE()._real_extract(url)
	assert (ex["id"] == "4090227752001"), "Id is wrong"
	assert (ex["timestamp"] == 1381789200), "Timestamp is wrong"
	assert (ex["duration"] == 3996.76), "Duration is wrong"
	assert (ex["title"] == "60 minutos (Lasa y Zabala, 30 años)"), "Title is wrong"
	assert (ex["description"] == "Programa de reportajes de actualidad."), "Description is wrong"
	

# Generated at 2022-06-24 12:19:45.008704
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:19:45.566840
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:19:52.295722
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_cases = [["http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/", "4090227752001"]]
    for url, video_id in test_cases:
        assert EitbIE._match_id(url) == video_id

# Generated at 2022-06-24 12:20:01.374912
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Initilization of EitbIE class
    m = EitbIE()

    # Assertion: IE_NAME = 'eitb.tv'
    assert m.IE_NAME == 'eitb.tv'

    # Assertion : _VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert m._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:10.797199
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert(IE.IE_NAME == 'eitb.tv')
    assert(IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:20:17.332084
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test constructor of class EitbIE
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
# Test _real_extract function for class EitbIE

# Generated at 2022-06-24 12:20:23.923943
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    # the class EitbIE should be instantiated without an exception.
    assert a.IE_NAME == 'eitb.tv'
# end of unit test


# Generated at 2022-06-24 12:20:25.195344
# Unit test for constructor of class EitbIE
def test_EitbIE():
	print("test_EitbIE passed")


# Generated at 2022-06-24 12:20:26.948077
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    This routine is used to test class constructor EitbIE()
    '''
    EitbIE('test')

# Generated at 2022-06-24 12:20:30.869125
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:20:37.546911
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    class_(None).suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    class_(None).suitable('Not a working URL')


# Generated at 2022-06-24 12:20:45.398091
# Unit test for constructor of class EitbIE
def test_EitbIE():
    filename_for_unittest = 'eitb.tv_60-minutos-60-minutos-2013-2014_4104995148001_4090227752001_lasa-y-zabala-30-anos_4104995149001_4104995148015'
#                            'eitb.tv_bertsioa_bertsioa_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_4104995082001_4104995085001'
#                            'eitb.tv_bertsioa_bertsioa_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_2016_4104995082001_410499508

# Generated at 2022-06-24 12:20:53.012626
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4104995148001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    assert ie.match_url(url)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == url

# Generated at 2022-06-24 12:20:53.530715
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e != None

# Generated at 2022-06-24 12:21:04.464617
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert (ie.IE_NAME == 'eitb.tv')
    # No assert for instance variable VALID_URL, since it’s a property and depends on the value of instance variable _VALID_URL;
    # The regular expression for the instance variable _VALID_URL has been tested in the function _real_extract()


    test = ie._TEST
    assert (test['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert (test['md5'] == 'edf4436247185adee3ea18ce64c47998')

# Generated at 2022-06-24 12:21:07.369875
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    return True

# Generated at 2022-06-24 12:21:08.160915
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE = EitbIE()

# Generated at 2022-06-24 12:21:14.137698
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.ie_key() == 'eitb.tv'
    assert ie.ie_name() == 'eitb.tv'


# Generated at 2022-06-24 12:21:16.022457
# Unit test for constructor of class EitbIE
def test_EitbIE():
    Testsuite('EitbIE')

# Generated at 2022-06-24 12:21:18.114499
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:21:18.867196
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:21:19.483532
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:23.064493
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:21:29.344881
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:30.445137
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL is not None

# Generated at 2022-06-24 12:21:35.607050
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test EitbIE constructor.
    """
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:38.862413
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE(EitbIE._TEST)
    assert e._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-24 12:21:40.186724
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:21:41.850066
# Unit test for constructor of class EitbIE
def test_EitbIE():
    Eitb_ie = EitbIE()
    assert Eitb_ie is not None

# Generated at 2022-06-24 12:21:43.304544
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()

# Generated at 2022-06-24 12:21:43.678228
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:46.604746
# Unit test for constructor of class EitbIE
def test_EitbIE():
	instanceEitbIE = EitbIE()
	assert isinstance(instanceEitbIE, EitbIE)

# Unit tests for function _real_extract

# Generated at 2022-06-24 12:21:48.205367
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('eitb.tv')



# Generated at 2022-06-24 12:21:50.169610
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_youtube import _test_eitb_ie_constructor
    _test_eitb_ie_constructor('Eitb', EitbIE)

# Generated at 2022-06-24 12:21:50.698464
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:52.277169
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert(EitbIE())
    except Exception:
        assert(False)



# Generated at 2022-06-24 12:21:56.460634
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:21:58.019408
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:22:01.972677
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == EitbIE._VALID_URL
    assert ie._TEST == EitbIE._TEST

# Generated at 2022-06-24 12:22:12.756828
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from __builtin__ import isinstance
	from ytdl.YTDL_InfoExtractor import YTDL_InfoExtractor

	patterns = [
		'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
	]
	filename = 'eitb'
	ie_key = 'eitb.tv'
	ie = EitbIE()

	assert isinstance(ie, YTDL_InfoExtractor)
	assert isinstance(ie.name, basestring)
	assert isinstance(ie.url, basestring)
	assert isinstance(ie.url_result, basestring)
	assert isinstance(ie.valid_url, str)

# Generated at 2022-06-24 12:22:17.359124
# Unit test for constructor of class EitbIE
def test_EitbIE():
    x = EitbIE()
    assert x._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:22:17.976472
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:22:29.059630
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:37.892280
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #Test with a valid url
    test_url = "http://www.eitb.tv/es/video/miradas-al-sur/3858676504001/4001014896001/"
    assert EitbIE._VALID_URL.match(test_url) is not None

    #Test with a invalid url
    test_url = "http://www.eitb.tv/es/video/miradas-al-sur/4001014896001/"
    EitbIE._VALID_URL.match(test_url) is None

# run unit test
test_EitbIE()

# Generated at 2022-06-24 12:22:49.035498
# Unit test for constructor of class EitbIE
def test_EitbIE():
   ie = EitbIE()
   assert ie.IE_NAME == 'eitb.tv'
   assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:49.756466
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-24 12:23:01.354955
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:23:03.227733
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("EitbIE", "EitbIE")
    ie.IE_NAME
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-24 12:23:08.424949
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert(ie.IE_NAME == "eitb.tv")

# Generated at 2022-06-24 12:23:11.097479
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None
    assert ie._VALID_URL is not None
    assert ie.IE_NAME is not None


if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:23:22.507213
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = IE_NAME

    # Test with a video
    result = ie(IE_NAME)(EitbIE._TEST)

# Generated at 2022-06-24 12:23:23.539048
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:23:31.325262
# Unit test for constructor of class EitbIE
def test_EitbIE():
	global assertEqual;
	global IE_NAME;
	global _VALID_URL;
	global _TEST;

	# Test instanciation

	ie = EitbIE();

	# Test inherited methods

	assertEqual(ie._downloader , None);
	assertEqual(ie.IE_NAME , IE_NAME);
	assertEqual(ie._VALID_URL , _VALID_URL);
	assertEqual(ie._TEST , _TEST);
	
	return;


# Generated at 2022-06-24 12:23:32.878941
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')

# Generated at 2022-06-24 12:23:34.954200
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Tests for constructor of EitbIE.
    # In this case, the input is a valid link.
    assert callable(EitbIE)

# Generated at 2022-06-24 12:23:38.410813
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    ie = EitbIE()
    ie.extract(url)

# Generated at 2022-06-24 12:23:39.500722
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()




# Generated at 2022-06-24 12:23:41.253304
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:42.725487
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie

# Generated at 2022-06-24 12:23:45.465985
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import EitbIE
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == "eitb.tv"



# Generated at 2022-06-24 12:23:46.914922
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb.EitbIE

# Generated at 2022-06-24 12:23:50.454718
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:54.159844
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:23:59.896280
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:04.167196
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert hasattr( EitbIE, "IE_NAME" )

    # assert returns a instance of EitbIE by url given as parameter
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    ie = EitbIE._build_ie_result( EitbIE, url )
    assert isinstance( ie, EitbIE )



# Generated at 2022-06-24 12:24:12.181808
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', {}, {}, None, None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.ie_key() == 'EitbIE'
    assert ie.ie_url() == 'EitbIE'


# Test a simple static method

# Generated at 2022-06-24 12:24:24.096984
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:26.041004
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert isinstance(eitb, EitbIE)

# Generated at 2022-06-24 12:24:32.067219
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4104995148001'
    videoURL = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    info = EitbIE()._real_extract(videoURL)
    assert info['id'] == video_id

# Generated at 2022-06-24 12:24:32.661379
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:24:35.741207
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:24:37.041155
# Unit test for constructor of class EitbIE
def test_EitbIE():

    e = EitbIE()
    if e:
        pass


# Generated at 2022-06-24 12:24:38.774833
# Unit test for constructor of class EitbIE
def test_EitbIE():
	try:
		EitbIE()
	except Exception as e:
		print(e)
		assert(False)
	assert(True)



# Generated at 2022-06-24 12:24:43.816265
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:45.603602
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    return eitb

# Generated at 2022-06-24 12:24:49.499020
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:58.759738
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .common import InfoExtractor_UnitTest
    from .common import unescapeHTML
    from .common import update_url_query

    class EitbIE_UnitTest(InfoExtractor_UnitTest):
        def setUp(self):
            self.ie = EitbIE(InfoExtractor())

        def test_constructor(self):
            # Just try to build an instance
            EitbIE(InfoExtractor())

    unit_test = EitbIE_UnitTest(EitbIE)
    unit_test.run()

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:24:59.952522
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:25:03.392549
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:04.948399
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert EitbIE()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 12:25:14.962383
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('ttp://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    test_EitbIE.assertIsInstance(ie, EitbIE)

# Generated at 2022-06-24 12:25:16.404813
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie == ie


# Generated at 2022-06-24 12:25:18.023220
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert isinstance(e, InfoExtractor)

# Generated at 2022-06-24 12:25:18.918271
# Unit test for constructor of class EitbIE
def test_EitbIE():
	constru = EitbIE()

# Generated at 2022-06-24 12:25:23.244158
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Unit test with malformed URL
    EitbIE('https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:25:23.964471
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert(EitbIE(None) == None)

# Generated at 2022-06-24 12:25:27.997022
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Input parameters to test function _real_extract of class EitbIE
params = {"url": "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/", "video_id": "4090227752001"}


# Generated at 2022-06-24 12:25:31.488108
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create instance of class EitbIE
    instance = EitbIE()
    # Assert extractor name
    assert_equal(instance.IE_NAME, 'eitb.tv')
    # Assert extractor supported URL
    instance.valid_urls = ['http://www.eitb.tv/eu/bideoa/8223945/index.html']
    for url in instance.valid_urls:
        assert_true(instance._match_id(url) is not None)

# Generated at 2022-06-24 12:25:32.875875
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL

# Generated at 2022-06-24 12:25:34.328109
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()
	assert eitb is not None

# Generated at 2022-06-24 12:25:35.305606
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._TEST

# Generated at 2022-06-24 12:25:35.883123
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:36.464372
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_TEST = EitbIE('youtube')

# Generated at 2022-06-24 12:25:38.593357
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE(None)
    assert isinstance(eitb_ie, EitbIE)


# Generated at 2022-06-24 12:25:41.275883
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL
    assert EitbIE().IE_NAME == EitbIE.IE_NAME
    return True

# Generated at 2022-06-24 12:25:42.020323
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()
    assert t
    return

# Generated at 2022-06-24 12:25:46.260973
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('Mam', 'http://www.eitb.tv/eu/bideoak/48-urtegia/48-urtegia/', '60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    #assert EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    #assert EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/40

# Generated at 2022-06-24 12:25:55.578449
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:26:03.779303
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from ytdl.YoutubeDL import YoutubeDL
	dummy_file = open('dummy', 'w')
	YoutubeDL({'logger':dummy_file}).extract_info('https://www.eitb.tv/es/video/telenoticias-noche/4104995148001/4125599104001/chile-aumenta-su-control-en-el-sur-para-evitar-avistamientos-ovnis/')
	dummy_file.close()

# Generated at 2022-06-24 12:26:12.332622
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = ie._match_id(url)
    video = ie._download_json(
            'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % video_id,
            video_id, 'Downloading video JSON')

# Generated at 2022-06-24 12:26:15.090551
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/tiki-taka/4104995302001/')
    assert ie is not None