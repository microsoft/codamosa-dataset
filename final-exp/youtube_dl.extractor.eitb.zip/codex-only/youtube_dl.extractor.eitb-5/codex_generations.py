

# Generated at 2022-06-24 12:16:15.095452
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE("")

# Generated at 2022-06-24 12:16:17.923301
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Tests for EitbIE
    # EitbIE()._real_extract()
    # EitbIE().suitable()
    # EitbIE()._real_extract()
    # EitbIE()._real_extract()
    pass

# Generated at 2022-06-24 12:16:24.513993
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()
	assert ie.IE_NAME == "eitb.tv"
	assert ie._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"


# Generated at 2022-06-24 12:16:27.098035
# Unit test for constructor of class EitbIE
def test_EitbIE():
    if __name__ == "__main__":
        raise IOError('test_EitbIE not configured')

    # Test for building EitbIE instance
    ie = EitbIE()

    # Test for correct instance
    assert isinstance(ie, (EitbIE, InfoExtractor))


# Generated at 2022-06-24 12:16:28.565083
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == EitbIE()._VALID_URL

# Generated at 2022-06-24 12:16:30.286697
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Basic test case to check if class EitbIE has been correctly constructed.
    """
    eitb_ie = EitbIE()

    assert eitb_ie.ie_key() == 'Eitb'
    assert eitb_ie.ie_name() == 'eitb.tv'

# Generated at 2022-06-24 12:16:33.472184
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:16:35.404153
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None, None)
    # Test if the instance is created properly
    if ie is None:
        assert(False)

# Generated at 2022-06-24 12:16:38.962124
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == \
        r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:40.700674
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    assert a != None, "Unit test for instantiating of EitbIE class"

# Generated at 2022-06-24 12:16:42.991782
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:16:46.172488
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert Eitb(url='http://www.eitb.tv/eu/bideoa/60-minutos/4104995148/1463515427001/', params={'title': '60 minutos (Laslabs eta ZabalaXXX, 30 urte)'})

# Generated at 2022-06-24 12:16:46.876245
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:16:47.461881
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:49.771985
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:16:50.932999
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(EitbIE._VALID_URL)

# Generated at 2022-06-24 12:16:52.602797
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE = EitbIE('http://www.eitb.tv/eu/bideoa')

# Generated at 2022-06-24 12:16:53.561339
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("EITB")

# Generated at 2022-06-24 12:17:04.597906
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import inspect
    import json
    import time
    import traceback


# Generated at 2022-06-24 12:17:09.147611
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Try a webm video and a webm audio
    assert EitbIE(None)._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:13.242391
# Unit test for constructor of class EitbIE
def test_EitbIE():
   d = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:17:15.908260
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:17:18.993134
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:21.964317
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:17:23.282877
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:17:27.581215
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:37.277758
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:17:41.581631
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Valid URL
    EitbIE(_VALID_URL)
    # Invalid URL
    try:
        EitbIE('http://www.eitb.tv/es/video/48horas/4090337408001/')
        assert False, 'Invalid URL was not rejected by EitbIE, constructor.'
    except ExtractorError:
        pass

# Generated at 2022-06-24 12:17:42.670212
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    print(vars(obj))

# Generated at 2022-06-24 12:17:49.131214
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('deportes')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:18:01.029403
# Unit test for constructor of class EitbIE
def test_EitbIE():

    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:04.881833
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:06.196857
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-24 12:18:15.660807
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from youtube_dl.utils import DateRange, urlencode_postdata
    d = EitbIE()
    assert d.IE_NAME == 'eitb.tv'
    assert d.TEST_URL == 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._VALID_URL == 'https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)'

# Generated at 2022-06-24 12:18:23.199750
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	EitbIE(InfoExtractor).suitable(test_url) #Check if the instace of this class can download the link
	EitbIE(InfoExtractor)._real_extract(test_url) # Test _real_extract


# Generated at 2022-06-24 12:18:24.098863
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()


# Generated at 2022-06-24 12:18:25.101609
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:18:26.189891
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-24 12:18:27.606307
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:39.688643
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:18:47.444981
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from yt_dl.utils import find_xpath_attr

# Generated at 2022-06-24 12:18:54.979495
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:03.183153
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:05.913576
# Unit test for constructor of class EitbIE
def test_EitbIE():
    temp_EitbIE = EitbIE('https://www.eitb.tv/eu/bideoa/4104995148001/4104995148001/')
    assert temp_EitbIE is not None

# Generated at 2022-06-24 12:19:11.879555
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    instance.suitable('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    instance._real_extract('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:19:18.184520
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test the constructor of class EitbIE.
    If it fails, it will leave the process.
    """
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:22.714937
# Unit test for constructor of class EitbIE
def test_EitbIE():
    o = EitbIE()
    assert o.IE_NAME == 'eitb.tv'
    assert o._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:26.912006
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = InfoExtractor("EitbIE", {})
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:32.347663
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_constructor = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

    assert eitb_constructor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:37.006049
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:38.473933
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #TODO: Add a unit test for constructor of class EitbIE
    return None

# Generated at 2022-06-24 12:19:40.922010
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'



# Generated at 2022-06-24 12:19:43.427362
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create instance of EitbIE class
    eitb = EitbIE()
    # assert that eitb is instance of YoutubeIE
    assert isinstance(eitb, EitbIE)

# Generated at 2022-06-24 12:19:47.390957
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor

    # test if the class has been registered
    ie = InfoExtractor.by_name('eitb.tv')
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:19:49.137435
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
        assert False
    except TypeError as e:
        assert 'arguments' in str(e)

# Generated at 2022-06-24 12:19:53.204632
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE({})
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:57.019403
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:20:06.082777
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert(ie.ie_name == 'eitb.tv')
    assert(ie.video_id == '4090227752001')

# Generated at 2022-06-24 12:20:09.191960
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE('www.eitb.tv')
    assert e.IE_NAME == 'eitb.tv'
    assert e.IE_DESC == 'eitb.tv and eitb.eus videos'


# Generated at 2022-06-24 12:20:14.330655
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    # instantiation with no parameters
    obj = class_()
    # call method
    obj._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:20:19.310881
# Unit test for constructor of class EitbIE
def test_EitbIE():
    x = EitbIE()
    assert x.IE_NAME == 'eitb.tv'
    assert x._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:25.891953
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    inst = EitbIE()
    assert isinstance(inst, EitbIE)
    assert isinstance(inst, InfoExtractor)
    assert inst._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert inst._TEST['url'] == url
    assert inst._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:20:32.713589
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    testDict = eitbIE._TEST
    assert testDict['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert testDict['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert testDict['info_dict']['id'] == '4090227752001'
    assert testDict['info_dict']['ext'] == 'mp4'
    assert testDict['info_dict']['title'] == '60 minutos (Lasa y Zabala, 30 años)'


# Generated at 2022-06-24 12:20:34.766249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    yield (
        test_EitbIE.__name__,
        'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
        'edf4436247185adee3ea18ce64c47998'
    )

# Generated at 2022-06-24 12:20:44.352084
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:49.231315
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor of class EitbIE has to work with the URL http://www.eitb.tv/eu/bideoa/...
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/010-2014')
    assert ie.ie_key() == 'EITB'
    assert ie.suitable('http://www.eitb.tv/eu/bideoa/010-2014')

# Generated at 2022-06-24 12:20:52.554235
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.ie_key() == 'eitb.tv'

# Generated at 2022-06-24 12:20:58.234703
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:21:02.787488
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    myEitbIE = EitbIE()
    myEitbIE._match_id(url)
    myEitbIE._real_extract(url)
    myEitbIE._TEST()


# Generated at 2022-06-24 12:21:06.187459
# Unit test for constructor of class EitbIE
def test_EitbIE():

    test_var = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert isinstance(test_var,EitbIE)



# Generated at 2022-06-24 12:21:06.970190
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:07.758097
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance

# Generated at 2022-06-24 12:21:08.634233
# Unit test for constructor of class EitbIE
def test_EitbIE():
    lol = EitbIE()
    print(lol)

# Generated at 2022-06-24 12:21:14.632324
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.IE_NAME
    ie._VALID_URL
    ie._TEST
    ie._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:21:25.632967
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from youtube_dl.utils import SearchInfoExtractor
	from unit.helper import FakeYDL
	assert issubclass(EitbIE, SearchInfoExtractor)
	assert issubclass(EitbIE, InfoExtractor)
	test_video_test = EitbIE._TEST.copy()
	test_video_test['info_dict']['title'] = "60 minutos (Lasa y Zabala, 30 años)"
	test_video_test['info_dict']['description'] = "Programa de reportajes de actualidad."
	ydl = FakeYDL({'simulate': True})
	ydl.add_default_info_extractors()
	test_video = ydl.extract_info(test_video_test['url'], download=False)
	assert test_

# Generated at 2022-06-24 12:21:27.979810
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert isinstance(eitbie, EitbIE)


# Generated at 2022-06-24 12:21:29.666058
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert(EitbIE).__name__ == 'EitbIE'


# Generated at 2022-06-24 12:21:34.122056
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    print("Unit test for constructor of class EitbIE")
    print("----------------------------------------------------------")
    print("EitbIE name: "+ie.IE_NAME)
    print("EitbIE valid_url: "+ie._VALID_URL)

# Test
test_EitbIE()

# Generated at 2022-06-24 12:21:43.252041
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test with a valid URL
    valid_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    valid_result = EitbIE()._real_extract(valid_url)
    assert valid_result is not None, "Result for valid URL cannot be None"
    assert valid_result['id'] == '4090227752001'
    assert valid_result['title'] == '60 minutos (Lasa y Zabala, 30 años)'

# Generated at 2022-06-24 12:21:53.823009
# Unit test for constructor of class EitbIE
def test_EitbIE():
    Eitb = EitbIE()
    assert Eitb.IE_NAME == 'eitb.tv'
    assert Eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:54.661576
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:21:55.511164
# Unit test for constructor of class EitbIE
def test_EitbIE():
    constructor_test(EitbIE)

# Generated at 2022-06-24 12:22:05.492023
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("unit test running")
    url_test = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    url_id = '4090227752001'
    print("passed")
    e = EitbIE()
    print("passed")
    f = e._real_extract(url_test)
    print("passed")
    assert f['id'] == '4090227752001'
    print("passed")

# Generated at 2022-06-24 12:22:11.387638
# Unit test for constructor of class EitbIE
def test_EitbIE():
    unit = EitbIE()

# Generated at 2022-06-24 12:22:12.504716
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() is not None

# Generated at 2022-06-24 12:22:24.595469
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Test with valid URL
    ie = EitbIE(None)

    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'
    # Test with invalid URL
    #url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos'
    #video_id = None

    assert ie._match_id(url) == video_id

# Generated at 2022-06-24 12:22:34.482620
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create object IE
    eitb_ie = EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    # Check url is valid
    assert eitb_ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Check test url is valid

# Generated at 2022-06-24 12:22:46.285834
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # Test with a valid video URL
    video_id = '4090227752001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/%s/lasa-y-zabala-30-anos/' % video_id
    ie.extract(url)
    # Test with a URL that does not exist
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/1/lasa-y-zabala-30-anos/'
    result = ie.extract(url)
    assert result == False
    # Test with a URL that exists but returns

# Generated at 2022-06-24 12:22:49.704151
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:22:55.922955
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.IE_NAME == 'eitb.tv'
    ie._VALID_URL == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:23:02.514022
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:04.938107
# Unit test for constructor of class EitbIE
def test_EitbIE():
    parser = EitbIE()
    # Exceptions should be raised for wrong urls.
    # we can use assertRaisesRegexp to check for error messages.
    return parser

# Generated at 2022-06-24 12:23:10.423534
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:16.029728
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test the constructor with a valid url
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE(url)
    # Test the constructor with an invalid url
    EitbIE('invalid URL')

# Generated at 2022-06-24 12:23:23.394476
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/pausoa/abuztu-23-2013-08-29/4104995148001/4104990685001/'
    ie = EitbIE(EitbIE._create_ie(EitbIE._VALID_URL))
    assert ie.ie_key() == 'Eitb'
    assert ie._match_id(url) == '4104990685001'


# Generated at 2022-06-24 12:23:25.693285
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:23:29.764804
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()
	url= 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	assert eitb.suitable(url)

# Generated at 2022-06-24 12:23:31.248669
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:23:34.380636
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/11/12/27/55/11272755/11272755.mp4'
    ie = EitbIE()
    ie.IE_NAME = 'eitb.tv'

# Generated at 2022-06-24 12:23:36.077999
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing constructor of class EitbIE")
    assert(EitbIE._VALID_URL)
    assert(EitbIE._TEST)

# Generated at 2022-06-24 12:23:42.345152
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb=EitbIE()
    assert eitb.IE_NAME=="eitb.tv"
    eitb._VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb._VALID_URL==r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:50.455127
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:23:57.740538
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    info = ie.extract("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert info["title"] == "60 minutos (Lasa y Zabala, 30 años)"
    assert info["description"] == "Programa de reportajes de actualidad."
    assert info["id"] == "4090227752001"

# Generated at 2022-06-24 12:23:58.712693
# Unit test for constructor of class EitbIE
def test_EitbIE():
    my_IE = EitbIE()
    assert my_IE != None

# Generated at 2022-06-24 12:24:02.603598
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:24:03.643622
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME

# Generated at 2022-06-24 12:24:04.626905
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:24:06.214922
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()

# Generated at 2022-06-24 12:24:07.478163
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-24 12:24:10.077845
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test the constructor of EitbIE class.
    """
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    result = ie.suitable(url)
    assert(result)



# Generated at 2022-06-24 12:24:18.225071
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.suitable('http://www.eitb.tv/eu/bideoa/zuzenean/entzun/kontzertuak/zazpi-katu-jaiak-aren-orokorrekoa/4090227800001/4090227799001/')
    assert EitbIE.suitable('http://www.eitb.tv/eu/bideoa/zuzenean/entzun/kontzertuak/zazpi-katu-jaiak-aren-orokorrekoa/4090227800001/4090227800001/')

# Generated at 2022-06-24 12:24:20.721541
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create an EitbIE object
    eitb = EitbIE();
    assert(eitb.IE_NAME == 'eitb.tv')
    assert(eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-24 12:24:25.950134
# Unit test for constructor of class EitbIE
def test_EitbIE():
    args = ('http://www.eitb.tv/eu/bideoa/zuzenean/4104995148001/', 'http://www.eitb.tv/eu/bideoa/zuzenean/4104995148001/')
    assert (EitbIE._VALID_URL == EitbIE._VALID_URL_RE.match(args[0]).re)
    ie = EitbIE(*args)
    assert ie.suitable(*args)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC == 'EiTB'

# Generated at 2022-06-24 12:24:35.911019
# Unit test for constructor of class EitbIE
def test_EitbIE():
    str1 = "basura"
    str2 = "basura"
    str3 = "basura"
    str4 = "basura"
    str5 = "basura"
    a = EitbIE(str1,str2)
    assert a.ie_key == 'Eitb'
    assert a.ie_name == 'Eitb.tv'
    assert a.info_dict == {}
    assert a.params == {}
    assert a.report_warning == (lambda *args, **kargs: None)
    assert a.to_screen == (lambda *args, **kargs: None)
    assert a._downloader == str2
    assert a.urls == []
    assert a.possible_packages == []
    assert a.extractor_key == str1
    assert a.info_dict == {}

# Generated at 2022-06-24 12:24:43.872779
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Get class to test
    from .common import InfoExtractor
    from .eitb import EitbIE
    from .youtube import YoutubeIE

    # Test constructor
    assert (EitbIE('eitb', 'eitb.tv'))

    # Test if EitbIE is subclass of InfoExtractor
    assert (isinstance(EitbIE('eitb', 'eitb.tv'), InfoExtractor))

    # Test if EitbIE is not subclass of YoutubeIE
    assert (not isinstance(EitbIE('eitb', 'eitb.tv'), YoutubeIE))

    # This is not EitbIE, neither is subclass of EitbIE
    assert (not issubclass(InfoExtractor, EitbIE))

# Generated at 2022-06-24 12:24:49.924410
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE(None)
    assert(info_extractor.IE_NAME == 'eitb.tv')
    assert(info_extractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-24 12:24:50.972989
# Unit test for constructor of class EitbIE
def test_EitbIE():
  assert(EitbIE != None)

# Generated at 2022-06-24 12:24:52.111616
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:24:58.217989
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Test the constructor of class EitbIE """
    test_instance = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert test_instance.IE_NAME == 'eitb.tv'
    assert test_instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert test_instance.ie._downloader.params['noprogress'] == True


# Generated at 2022-06-24 12:25:00.115022
# Unit test for constructor of class EitbIE
def test_EitbIE():
    utorrent = EitbIE()
    assert utorrent.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:25:00.948637
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()



# Generated at 2022-06-24 12:25:05.382191
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:25:14.787086
# Unit test for constructor of class EitbIE
def test_EitbIE():
	"""
	http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/
	"""
	url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
	
	eitb = EitbIE()

	main_page_content = eitb._download_webpage(url, None)

# Generated at 2022-06-24 12:25:23.780671
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    assert class_.IE_NAME == 'eitb.tv'
    assert class_._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:24.924591
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:25:35.075862
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:25:37.773194
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Basic test to know if a EitbIE is created correctly
    """
    eitb_test = EitbIE()
    assert eitb_test

# Generated at 2022-06-24 12:25:48.688657
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Getting the constructor of the class
    eitb_ie = EitbIE()
    # Testing the constructor, .ie_key and .name
    assert eitb_ie.ie_key == 'eitb.tv'
    assert eitb_ie.name == 'eitb.tv'
    # Testing some attributes
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Testing the static methods
    assert eitb_ie._match_id('') is None

# Generated at 2022-06-24 12:25:57.045388
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:57.991866
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('')
    EitbIE('')

# Generated at 2022-06-24 12:26:01.887903
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:26:03.255773
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('EitbIE')

# Generated at 2022-06-24 12:26:12.043901
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import logging
    import inspect
    import os

    if not operating_system.is_windows():
        return False

    # Create a logger to test log output
    logging.basicConfig()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    # Get current working directory of unit test file to get default test file
    path_cwd = os.path.abspath(inspect.getfile(inspect.currentframe()))
    default_test_file = os.path.abspath(os.path.join(path_cwd, '..', '..', '..', 'YT_TEST_VIDEO'))
    logger.info("Default test file: %s" % default_test_file)

    # Get test file, fall back to default test file if not set by user


# Generated at 2022-06-24 12:26:17.158674
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'