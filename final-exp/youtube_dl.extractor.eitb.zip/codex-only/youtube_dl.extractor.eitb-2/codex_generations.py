

# Generated at 2022-06-24 12:16:15.810625
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE('url')
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:16:20.547433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Make sure constructor of class EitbIE works"""
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:16:27.124943
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitbie = EitbIE()

	eitbie = EitbIE(u'http://www.eitb.tv/eu/bideoa/zuzenean-sariak-jaurlaritzako-sari-erosoak-aralar-taldeko-bideoa-den-gertatzean/4104995148001/4090227752001/',
    				u'EITB.TV', u'Video: Zuzenean, sariak - Jaurlaritzako Sari erosoak (Aralar taldeko bideoa)', u'Dani Diez')

# Generated at 2022-06-24 12:16:28.422576
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb

# Generated at 2022-06-24 12:16:34.035517
# Unit test for constructor of class EitbIE
def test_EitbIE():
    valid_url_sample = 'http://www.eitb.tv/eu/bideoa/eitb-nabigazioa/bideoa/2790001/2725112/'
    obj = EitbIE(valid_url_sample)
    assert obj._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert obj.IE_NAME == 'eitb.tv'
    assert obj._downloader.params['test'] == False
    assert obj.IE_DESC == 'eitb.tv'

# Generated at 2022-06-24 12:16:36.374383
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_CLASSNAME = globals()['EitbIE']
    ie = IE_CLASSNAME('')
    assert ie.ie_name == 'eitb.tv'

# Generated at 2022-06-24 12:16:41.044579
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE(url).IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:16:48.486610
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert (IE.IE_NAME == 'eitb.tv')
    assert (IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:16:49.249298
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:51.010443
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # There is a class object to test the EitbIE class
    assert EitbIE is not None

# Generated at 2022-06-24 12:16:56.680264
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'http://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    print ('Unit test for constructor of class EitbIE passed')


# Generated at 2022-06-24 12:16:57.327299
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:17:03.897028
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # The EitbIE constructor ins not exposed to the public so its unit test
    # lives here.
    ie = EitbIE()
    assert ie != None

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:17:05.020485
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e != None



# Generated at 2022-06-24 12:17:06.761053
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.ie_key().lower() == 'eitb.tv'

# Generated at 2022-06-24 12:17:17.439446
# Unit test for constructor of class EitbIE
def test_EitbIE():
    request_headers = {
        'Referer': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',  # NOQA
        'Accept-Language': 'es-ES,es;q=0.8',
    }
    _TEST_VIDEO_ID = '4090227752001'

    ie = EitbIE()

# Generated at 2022-06-24 12:17:21.302473
# Unit test for constructor of class EitbIE
def test_EitbIE():
        # test for constructor of EitbIE class
        # EitbIE object
        EitbIE_object = EitbIE()

        # Asserts for EitbIE object
        assert EitbIE_object._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
        assert EitbIE_object.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:17:26.733741
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert eitb_ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert eitb_ie._TEST['info_dict']['id'] == '4090227752001'
    assert eitb_ie._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:17:27.977126
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('None', 'None')
    assert ie is not None

# Generated at 2022-06-24 12:17:29.595394
# Unit test for constructor of class EitbIE
def test_EitbIE():
  """
  Description:
    Auxiliary function that test EitbIE class.
  """
  ie = EitbIE()
  assert isinstance(ie, EitbIE)


# Generated at 2022-06-24 12:17:31.135238
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:39.119368
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #
    # Unit test for constructor of class EitbIE
    #

    # Constructor without parameters
    ie = EitbIE()

    # Constructor with a fake-url text
    ie = EitbIE('This is not a real URL')

    # Constructor with a real URL
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)


# Generated at 2022-06-24 12:17:41.411474
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:17:42.275865
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:17:43.427694
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        return False
    return True

# Generated at 2022-06-24 12:17:46.338178
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('EitbIE')
    assert eitb_ie is not None, "Test for object creation failed"


# Generated at 2022-06-24 12:17:51.713239
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:17:53.553403
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE()._match_id('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') == '4090227752001')

# Generated at 2022-06-24 12:17:54.619432
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor)

# Generated at 2022-06-24 12:18:03.846482
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:05.051995
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._TEST is not None

# Generated at 2022-06-24 12:18:08.315751
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create instance of constructor of class EitbIE
    EitbIE_instance = EitbIE()
    # Check if the instance is of class EitbIE
    assert isinstance(EitbIE_instance, EitbIE)

# Generated at 2022-06-24 12:18:17.061587
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    eitb = EitbIE()
    info = eitb.extract(url)

    assert eitb.IE_NAME == 'eitb.tv'
    assert info['id'] == '4090227752001'
    assert info['title'] == "60 minutos (Lasa y Zabala, 30 años)"
    assert info['description'] == "Programa de reportajes de actualidad."
    assert info['duration'] == 3996.76
    assert info['upload_date'] == '20131014'

# Generated at 2022-06-24 12:18:23.358386
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})

    id = '4090227752001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/' + id + '/lasa-y-zabala-30-anos/'
    info = EitbIE().extract(url)
    assert info['id'] == id
    assert info['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert info['description'] == 'Programa de reportajes de actualidad.'

    id = '1234'

# Generated at 2022-06-24 12:18:26.613564
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .eitb import EitbIE
    eitb_ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert isinstance(eitb_ie, InfoExtractor)

# Generated at 2022-06-24 12:18:31.224186
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:18:33.901565
# Unit test for constructor of class EitbIE
def test_EitbIE():
    InfoExtractor('eitb', 'eitb.tv').initialize()
    raise Exception('Failed to initialize EitbIE')

# Generated at 2022-06-24 12:18:36.217791
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE()
    assert isinstance(test_EitbIE, EitbIE)


# Generated at 2022-06-24 12:18:39.243729
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('EitbIE')
    try:
        assert eitb_ie.IE_NAME == 'EitbIE'
    except:
        raise AssertionError()

# Generated at 2022-06-24 12:18:41.840328
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test constructor
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert ie.IE_NAME == "eitb.tv"


# Generated at 2022-06-24 12:18:44.959954
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple test for class EitbIE
    """
    ie = EitbIE()
    assert type(ie) == EitbIE

# Generated at 2022-06-24 12:18:46.123697
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)
            

# Generated at 2022-06-24 12:18:47.975083
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == 'http://www.eitb.tv/eu/bideoa/[^/]+/\d+/\d+'

# Generated at 2022-06-24 12:18:58.996811
# Unit test for constructor of class EitbIE
def test_EitbIE():
	testing_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	test_result = EitbIE().extract(testing_url)
	assert test_result['id'] == '4090227752001'
	assert test_result['formats'][0]['format_id'] == 'http'
	assert test_result['formats'][0]['width'] == 576
	assert test_result['formats'][0]['height'] == 432
	assert test_result['formats'][0]['tbr'] == 958.0

# Generated at 2022-06-24 12:19:02.185885
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()
	print (ie.IE_NAME)
	assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:19:03.753727
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_IE = EitbIE(InfoExtractor())

# Generated at 2022-06-24 12:19:13.649938
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:19:14.558663
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:19:14.960838
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:19:22.016665
# Unit test for constructor of class EitbIE
def test_EitbIE():
    configure()
    #non_MP4_url = 'http://www.eitb.tv/es/video/txirrindularitza/4104995148001/2053869104001/laban-txiki-laban-handia/'
    non_MP4_url = 'http://www.eitb.tv/es/video/txirrindularitza/4104995148001/2058977462001/fermin-muguruza/'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ext = EitbIE()

# Generated at 2022-06-24 12:19:24.739768
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:19:28.724582
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eie = EitbIE('http://www.eitb.tv/eu/bideoa/es/video/60-minutos/60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    print(eie.IE_NAME)

# Generated at 2022-06-24 12:19:31.208439
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        # test for constructor of class EitbIE
        assert EitbIE
    except Exception as e:
        print(e.__doc__)
        print(e.message)

# Generated at 2022-06-24 12:19:37.791455
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert [EitbIE] == [cls for cls in InfoExtractor._ALL_CLASSES if cls.IE_NAME == 'eitb.tv']
    assert(EitbIE.IE_NAME == 'eitb.tv')
    assert(EitbIE.IE_DESC == 'EITB.TV')
    assert(EitbIE.IE_VERSION == '0.0.1')
    assert(EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert(EitbIE.WEBPAGE_URL == "http://www.eitb.tv/eu/bidaiak")

# Generated at 2022-06-24 12:19:39.479726
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"

# Generated at 2022-06-24 12:19:43.766526
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-24 12:19:46.764644
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:19:47.893079
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE, object)

# Generated at 2022-06-24 12:19:50.459584
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:00.838674
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # First test from _TEST
    eitb_ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:01.499712
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:20:02.598425
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:20:08.981968
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from ..utils import (
        int_or_none,
        list_to_str,
        parse_iso8601,
        sanitized_Request,
        float_or_none
    )

    # Test the contructor of class EitbIE

# Generated at 2022-06-24 12:20:09.876088
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-24 12:20:11.563364
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:12.674541
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-24 12:20:16.134439
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._build_url_result(EitbIE._TEST['url'], EitbIE._TEST['md5'], EitbIE._TEST['info_dict'])

# Generated at 2022-06-24 12:20:17.885272
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:25.607374
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None, "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert(ie.IE_NAME == "Eitb")

# Generated at 2022-06-24 12:20:30.010830
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Video of the day 'http://www.eitb.tv/eu/'
    url = 'http://www.eitb.tv/eu/bideoa/benito-lertxundi/5039955172001/'
    result = EitbIE()._real_extract(url)
    assert len(result['formats']) > 0

# Generated at 2022-06-24 12:20:42.216408
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:43.856132
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:20:49.256682
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance.IE_NAME == 'eitb.tv'
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:20:59.754392
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE('http://www.eitb.tv/eu/bideoa/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert inst._VALID_URL=='https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert inst.IE_NAME=='eitb.tv'

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:21:08.870452
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiation of service object
    service = EitbIE()
    # Tests of member methods
    assert(service.IE_NAME == 'eitb.tv')
    assert(service._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:21:19.381574
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    result= EitbIE._real_extract(eitb,url=eitb._TEST['url'])
    assert result['id'] == EitbIE._TEST['info_dict']['id']
    assert result['duration'] == EitbIE._TEST['info_dict']['duration']
    assert result['title'] == EitbIE._TEST['info_dict']['title']
    assert result['description'] == EitbIE._TEST['info_dict']['description']
    assert result['tags'] == EitbIE._TEST['info_dict']['tags']


# Generated at 2022-06-24 12:21:22.260120
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Test the constructor of the class EitbIE
	# This test should not throw an exception
    eitb = EitbIE()
# End of unit test for constructor of class EitbIE


# Generated at 2022-06-24 12:21:23.538254
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert issubclass(EitbIE, InfoExtractor)

# Generated at 2022-06-24 12:21:32.384629
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url='http://www.eitb.tv/eu/bideoa/naiz-kontuak/43649549/4166684/euskal-kultura/'
    eitbIE = EitbIE(InfoExtractor)
    assert url==eitbIE._VALID_URL

# Generated at 2022-06-24 12:21:34.559831
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-24 12:21:35.844038
# Unit test for constructor of class EitbIE
def test_EitbIE():
	print("test_EitbIE")

# Generated at 2022-06-24 12:21:42.247306
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:43.605184
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:21:54.051500
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/programa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:21:54.579341
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:56.081520
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:22:01.728005
# Unit test for constructor of class EitbIE
def test_EitbIE():
    check_ie_constructor(EitbIE, "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:22:02.799086
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-24 12:22:08.655273
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_ie = EitbIE()
    video = eitb_ie.url_result(url)
    video.download()
    pass

# Generated at 2022-06-24 12:22:10.960897
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:22:11.839907
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-24 12:22:17.479726
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_eitb = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie_eitb is not None


# Generated at 2022-06-24 12:22:20.339890
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:22:22.951111
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Test the constructor of class EitbIE
    #
    # Input:
    #    url = http://www.eitb.tv/eu/bideoa/4019699107001/
    #
    # Expected output:
    #    An instance of EitbIE class
    #---------------------------------------------
    result = EitbIE('http://www.eitb.tv/eu/bideoa/4019699107001/')
    assert isinstance(result, EitbIE)



# Generated at 2022-06-24 12:22:24.342387
# Unit test for constructor of class EitbIE
def test_EitbIE():
  assert( EitbIE('EitbIE', 'eitb.tv') is None )

# Generated at 2022-06-24 12:22:29.397931
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE().IE_NAME == 'eitb.tv')


# Generated at 2022-06-24 12:22:32.674183
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('', {})
    assert(eitbIE.IE_NAME == 'eitb.tv')


# Generated at 2022-06-24 12:22:33.259874
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:22:38.275485
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:22:40.957101
# Unit test for constructor of class EitbIE
def test_EitbIE():
	"""
	Class EitbIE is being tested
	"""
	url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"

	EitbIE(InfoExtractor)._real_extract(url)

# Generated at 2022-06-24 12:22:42.773129
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except TypeError:
        pass

# Generated at 2022-06-24 12:22:44.373401
# Unit test for constructor of class EitbIE
def test_EitbIE():
	e = EitbIE()
	assert(e != None)

# Generated at 2022-06-24 12:22:48.992142
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:22:50.582545
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:22:53.274012
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_obj = InfoExtractor(EitbIE.IE_NAME, EitbIE.IE_DESC)
    instance = EitbIE()
    assert isinstance(instance, EitbIE)

# Generated at 2022-06-24 12:22:55.103459
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:23:07.944302
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/laburbildua/4104995148001/3989123092001/")
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:19.743116
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    urlPlusId = url + '4090227752001'
    eitb_ie = EitbIE(None)
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie._match_id(url) == '4090227752001'
    assert eit

# Generated at 2022-06-24 12:23:31.542623
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:23:36.758678
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert IE.ie_key() == 'Eitb'
    assert IE.ie_name() == 'Eitb'
    assert IE.ie_url() == 'Eitb'

# Generated at 2022-06-24 12:23:37.742830
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:23:39.253774
# Unit test for constructor of class EitbIE
def test_EitbIE():
    fileTest = open("test.txt")
    assert fileTest




# Generated at 2022-06-24 12:23:47.978363
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert issubclass(EitbIE, InfoExtractor)
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    # Unit test for _real_extract
    eitbIE = EitbIE(EitbIE.IE_NAME, EitbIE.VALID_URL)
    eitbIE._real_extract(EitbIE._TEST['url'])

# Generated at 2022-06-24 12:23:57.346855
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv', 'Invalid IE name'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)', 'Invalid IE regex'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 'Invalid IE url'

# Generated at 2022-06-24 12:24:06.868177
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    page_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video = EitbIE(EitbIE._downloader)
    video.download(video_url, page_url)
    print(video.download(video_url, page_url))

# Generated at 2022-06-24 12:24:08.071134
# Unit test for constructor of class EitbIE
def test_EitbIE():
    r = EitbIE()

# Generated at 2022-06-24 12:24:09.804725
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:24:10.742394
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_ = EitbIE()

# Generated at 2022-06-24 12:24:15.079087
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb=EitbIE()
    assert eitb.IE_NAME=='eitb.tv'
    assert eitb._VALID_URL==r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:24:19.082425
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # loading and testing object of class EitbIE
    my_EitbIE = EitbIE()
    assert isinstance(my_EitbIE, InfoExtractor)
    assert my_EitbIE.ie_key() == 'eitb.tv'
    assert my_EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:23.988418
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is True

# Generated at 2022-06-24 12:24:34.264547
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import FakeFFmpegPostProcessor
    from .extractor import get_info_extractor

    # 'FFmpegPostProcessor' is not found
    ie = get_info_extractor('Eitb')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.ffmpeg_pp is None

    # 'FFmpegPostProcessor' is found
    ie._downloader = FakeFFmpegPostProcessor()
    ie = get_info_extractor('Eitb')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_

# Generated at 2022-06-24 12:24:35.741297
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'


# Generated at 2022-06-24 12:24:41.121674
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')  
    #This line raises an error if the class is not properly constructed
    super(EitbIE, instance).__getattribute__('_VALID_URL')

# Generated at 2022-06-24 12:24:47.245461
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test_url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
	assert EitbIE._VALID_URL.match(test_url) is not None, "Bad format in url"

# Generated at 2022-06-24 12:24:49.460883
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:53.991148
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is not None

# Generated at 2022-06-24 12:24:57.438987
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:00.524410
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    if not ie:
        print('not working')

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:25:08.202646
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/zuzenean/60-minutos/lasa-y-zabala-30-anos/4090227752001/'
    eitb = EitbIE()
    try:
        eitb.IE_NAME
        eitb.VALID_URL
    except AttributeError:
        print ('\033[31m' + 'Attribute Error: The class "EitbIE" does not have the attribute (member variable) "IE_NAME" or "VALID_URL".')
        return False
    eitb.IE_NAME = 'eitb.tv'

# Generated at 2022-06-24 12:25:09.551508
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test
    """
    EitbIE()

# Generated at 2022-06-24 12:25:14.643917
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:16.195184
# Unit test for constructor of class EitbIE
def test_EitbIE(): 
    assert issubclass(EitbIE, InfoExtractor)

# Generated at 2022-06-24 12:25:21.584897
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE();
    assert(eitbIE != None);
    assert(eitbIE.IE_NAME == "eitb.tv");
    assert(eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)');


# Generated at 2022-06-24 12:25:22.380981
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:27.972951
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_utils import TestIE
    ie = TestIE('EitbIE')
    ie._real_extract('http://www.eitb.tv/eu/bideoa/muru-mahaia/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:25:37.597161
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    # Set up parameters for test
    test_url = "http://www.eitb.tv/eu/bideoa/euskal-ondareak-a-la-cabra-mecanica-elkartuko-du-segunda-edizioa/4104995148001/4090107315001"

# Generated at 2022-06-24 12:25:43.019493
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst.IE_NAME == 'eitb.tv'
    assert inst._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:25:52.911974
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:26:04.550661
# Unit test for constructor of class EitbIE
def test_EitbIE():
    new_test_case = {
        'url': 'http://www.eitb.tv/eu/bideoa/bizitza-7/6059568/',
        'md5': 'e6b5e6b5f5b5db87b2d630725174cb1a',
        'info_dict': {
            'id': '6059568',
            'ext': 'mp4',
            'title': 'Bizitza 7',
            'description': 'md5:1c64af1ca0aa6b2ef0b9a3c44a0ebb73',
            'duration': 2289.68,
            'timestamp': 1456999600,
            'upload_date': '20160215',
        },
    }

# Generated at 2022-06-24 12:26:05.736680
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE)

# Generated at 2022-06-24 12:26:12.555601
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE(None)
	eitb.suitable('http://www.eitb.tv/eu/node/1')
	eitb.suitable('http://www.eitb.tv/eu/bideoa/gaur/111390/')
	eitb.suitable('http://www.eitb.tv/eu/bideoa/gaur/111390/?offset=320')