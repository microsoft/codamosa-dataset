

# Generated at 2022-06-24 12:16:12.657706
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        eitb = EitbIE()
    except Exception as e:
        assert(False)

# Generated at 2022-06-24 12:16:16.863428
# Unit test for constructor of class EitbIE
def test_EitbIE():
	if __name__ == "__main__":
		url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
		assert EitbIE._VALID_URL == url

# Generated at 2022-06-24 12:16:21.623039
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:16:28.416732
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from urllib import FancyURLopener
	class MyOpener(FancyURLopener):
		version = 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36'
	myopener = MyOpener()
	urllib._urlopener = myopener
	from youtube_dl.utils import *
	from youtube_dl.extractor import *
	url = "http://www.eitb.tv/eu/bideoa/kirolak/astondoa-irudia-garrantzitsua-izaten-da/4104995148001/4103968121001/"
	x = EitbIE(fake_extractor_settings, url)

# Generated at 2022-06-24 12:16:31.796799
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL.match('http://www.eitb.tv/eu/bideoa/kultura/irakurle/q-vin-dagoyanes/123349/%s/' % EitbIE._TEST['url']) is not None

# Generated at 2022-06-24 12:16:34.348267
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:43.687351
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj._VALID_URL == 'r' 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert obj._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert obj._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:16:46.435414
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    try:
        assert ie is not None and ie.IE_NAME == 'eitb.tv'
    except:
        raise AssertionError('Unit test for constructor of class EitbIE failed!')


# Generated at 2022-06-24 12:16:47.354993
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:16:50.208135
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE();
    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-24 12:16:51.542871
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE()


# Generated at 2022-06-24 12:16:52.430577
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, None)

# Generated at 2022-06-24 12:16:52.988836
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:16:56.028052
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.VALID_URL.startswith('http')

# Generated at 2022-06-24 12:17:01.947353
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:17:05.095615
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('EitbIE', 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    print('test %s IE ends' % instance.IE_NAME)

# Generated at 2022-06-24 12:17:15.432583
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    # some initialization
    eitbIE=EitbIE()
    # testing extractor is working
    assert eitbIE.suitable(eitbIE_url), "suitable method not working"
    assert eitbIE._real_extract is not None, "method _real_extract not working"
    # testing extractor is working with the url in _TEST
    assert eitbIE._TEST['url']==eitbIE_url, "ERROR: class EitbIE has changed"

# Generated at 2022-06-24 12:17:18.926134
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    print(ie)
    # Test for valid URL
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Test for instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-24 12:17:24.199717
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:17:25.454191
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb
    assert eitb.IE_NAME == "EitbIE"

# Generated at 2022-06-24 12:17:32.220688
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/konektak/2014-2016/4104995156001/4104995156001/'
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/' \
    '[^/]+/\\d+/(?P<id>\\d+)'

# Generated at 2022-06-24 12:17:41.545715
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:17:43.774433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:17:45.663124
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test
    """
    instance = EitbIE()
    assert instance

# Generated at 2022-06-24 12:17:47.359496
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE("EitbIE", "012345678", "http://www.eitb.tv") == "Class EitbIE made"


# Generated at 2022-06-24 12:17:48.740498
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE({}, {}, {})
    assert ie
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:17:51.435965
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE().IE_NAME == 'eitb.tv'



# Generated at 2022-06-24 12:17:54.981325
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE('test_eitb', {}, {'test': None})
    assert isinstance(e, InfoExtractor)
    assert isinstance(e, EitbIE)



# Generated at 2022-06-24 12:17:55.878975
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-24 12:17:58.321004
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor should be able to instantiate EitbIE
    try:
        EitbIE()
    except Exception as e:
        assert False
        

# Generated at 2022-06-24 12:18:06.309151
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst._VALID_URL == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-24 12:18:15.732632
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/60-minutos/60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    eitb = EitbIE()
    assert eitb.suitable(url) == True
    assert eitb.IE_NAME == "eitb.tv"
    assert eitb._VALID_URL == "http://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)"
    assert eitb._TEST["url"] == url

# Generated at 2022-06-24 12:18:24.490313
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from unittest import TestCase
    from .test_common import TestCommon

    with TestCase().assertRaises(TypeError):
        EitbIE()

    # test with empty params
    EitbIE('', '', '')

    # test with params (incl. just one)
    EitbIE('youtube', 'http://www.youtube.com/watch?v=BaW_jenozKc', 'BaW_jenozKc')

    # test with invalid url param
    eitbie = EitbIE('youtube', 'invalid url', '')
    with TestCase().assertRaises(TypeError):
        eitbie.suitable('invalid url')

# Generated at 2022-06-24 12:18:26.419041
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:18:34.059190
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    # Check that the name of the IE is correct
    assert eitb.IE_NAME == "eitb.tv"
    # Check that the IE accepts a valid URL
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:18:39.242760
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # class instantiation
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:18:40.304512
# Unit test for constructor of class EitbIE
def test_EitbIE():
    r"""Unit test for constructor of class EitbIE"""
    _ = EitbIE(None)

# Generated at 2022-06-24 12:18:41.261580
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-24 12:18:41.857351
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-24 12:18:44.708446
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eie = EitbIE()
    assert isinstance(eie, EitbIE)


# Generated at 2022-06-24 12:18:51.098005
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Initialization of class
    eitbIE = EitbIE()
    # Testing value of class attribue IE_NAME
    assert(eitbIE.IE_NAME == 'eitb.tv')
    # Testing value of class attribue _VALID_URL
    assert(eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    # Testing value for _TEST

# Generated at 2022-06-24 12:18:53.360492
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test EitbIE constructor"""
    EitbIE(None)


# Generated at 2022-06-24 12:18:54.296481
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor())

# Generated at 2022-06-24 12:18:59.181685
# Unit test for constructor of class EitbIE
def test_EitbIE():
    Eitb = EitbIE({})
    assert Eitb.IE_NAME == 'eitb.tv'
    assert Eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:19:08.141398
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video = EitbIE('Eitb.tv')

    video_url = 'http://www.eitb.tv/eu/bideoa/notizies/Konekta-Ceramika/4008000048001/4090203397001/'
    video_id = '4090203397001'
    assert video.suitable('http://www.eitb.tv/eu/bideoa/notizies/Konekta-Ceramika/4008000048001/4090203397001/')
    assert video.IE_NAME in video.workingURL('http://www.eitb.tv/eu/bideoa/notizies/Konekta-Ceramika/4008000048001/4090203397001/')
    assert video._WORKING == True


# Generated at 2022-06-24 12:19:12.785814
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #I instantiate class EitbIE with the url for extract info
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:19:23.147851
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	info_dict = {
		'id': '4090227752001',
		'ext': 'mp4',
		'title': '60 minutos (Lasa y Zabala, 30 años)',
		'description': 'Programa de reportajes de actualidad.',
		'duration': 3996.76,
		'upload_date': '20131014',
		'tags': list,
	}

# Generated at 2022-06-24 12:19:31.605279
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_test = EitbIE({})
    instance_test = ie_test.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert instance_test == True


# Generated at 2022-06-24 12:19:33.324453
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test instalation of constructor
    obj = EitbIE()
    assert(obj)

# Generated at 2022-06-24 12:19:36.220073
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = InfoExtractor(EitbIE)
    assert info_extractor.IE_NAME == EitbIE.IE_NAME
    assert info_extractor._VALID_URL == EitbIE._VALID_URL
    assert info_extractor._TEST == EitbIE._TEST
    return True


# Generated at 2022-06-24 12:19:43.190155
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # This checks whether an EitbIE instance can be constructed.
    # This does not check extracting actual content.
    dummy_url = "http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/"
    eitbIE = EitbIE(False)
    assert eitbIE.suitable(dummy_url)
    # Notice that the following does not call suitable()
    assert eitbIE._real_extract(dummy_url)

# Generated at 2022-06-24 12:19:47.634349
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test constructor of class EitbIE
    instance = EitbIE()

# Generated at 2022-06-24 12:19:48.996880
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE == EitbIE())

# Generated at 2022-06-24 12:19:50.797460
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL is not None


# Generated at 2022-06-24 12:19:53.661108
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:20:03.600397
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie != None
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:20:05.588707
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None).is_suitable('http://www.eitb.tv/eu/bideoa/hb-13/4491278178001/')

# Generated at 2022-06-24 12:20:06.305470
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()


# Generated at 2022-06-24 12:20:09.783811
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.suitable("http://eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-24 12:20:20.316449
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from contextlib import contextmanager
    from io import StringIO
    import sys
    import unittest

    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test_case = unittest.TestCase()
    test_EitbIE = EitbIE(test_case)

    # test constructor of class EitbIE
    test_EitbIE.suite()

    @contextmanager
    def capture_stdout():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr

# Generated at 2022-06-24 12:20:21.304199
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, {}, {})



# Generated at 2022-06-24 12:20:22.554245
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-24 12:20:24.456634
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

    # Test constructor
    assert isinstance(eitb, InfoExtractor)

# Generated at 2022-06-24 12:20:28.838487
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    url = 'http://www.eitb.tv/eu/bideoa/25-urte-hil-dira-bideoa/1656637/?media=vod'
    video = ie.extract(url)
    assert video['title'] == '25 urte hil dira'

# Generated at 2022-06-24 12:20:41.386595
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ei = EitbIE()
    assert ei.IE_NAME == 'eitb.tv'
    assert ei._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
   
    # test with standard webpage
    ei_test_standard = EitbIE(ie=IE_NAME)
    ei_test_standard._VALID_URL = _VALID_URL
    ei_test_standard._TEST = _TEST

    # test with a webpage that doesn't exist
    ei_test_fault_url = EitbIE(ie=IE_NAME)

# Generated at 2022-06-24 12:20:52.451499
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/' 
    assert obj._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-24 12:21:03.609627
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:21:08.611065
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(ie.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(ie.video_id == '4090227752001')

# Generated at 2022-06-24 12:21:13.051262
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:21:24.079364
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == '^https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)$'

# Generated at 2022-06-24 12:21:29.814263
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    assert info_extractor.IE_NAME == 'eitb.tv'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-24 12:21:40.237684
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:21:40.795369
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:21:52.214257
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test a well-formed URL
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    # Test a malformed URL
    assert not EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+|)'

    # Test that the regular expression for a malformed URL is different from
    # the one for a well-formed URL

# Generated at 2022-06-24 12:21:53.427924
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert "EitbIE" in dir(ie)

# Generated at 2022-06-24 12:22:00.187475
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    Tests of constructor of EitbIE class
    '''
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-24 12:22:01.972902
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)._VALID_URL == EitbIE._VALID_URL;


# Generated at 2022-06-24 12:22:03.457660
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE({}), InfoExtractor)

# Generated at 2022-06-24 12:22:13.779985
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

    # Constructor should call InfoExtractor.__init__() with all major parameters
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:22:23.648997
# Unit test for constructor of class EitbIE
def test_EitbIE():
	print ("Testing EITBIE...")
	# eitbIE = EitbIE(EitbIE._VALID_URL)
	# print (eitbIE)
	# eitbIE._real_initialize()
	# print (eitbIE._real_extract(EitbIE._TEST['url']))
	ie = InfoExtractor()
	print (ie.extract('http://www.eitb.tv/eu/bideoa/joxe-artze-argakizuna/4416544443001/4419511180001/'))
	# eitbIE._real_extract(EitbIE._TEST['url'])

# Generated at 2022-06-24 12:22:33.805470
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:22:35.576353
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(
        EitbIE(),
        EitbIE,
    )

# Generated at 2022-06-24 12:22:46.982848
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.ie_key() == 'eitb.tv'
    assert eitb_ie.ie_name() == 'eitb.tv'
    assert eitb_ie.valid_url('http://www.eitb.tv/eu/bideoa/euskal-faktoria/842776/irrati-kamara/')
    assert eitb_ie.valid_url('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert not eitb_ie.valid_url('http://www.eitb.tv/')

# Generated at 2022-06-24 12:22:53.493854
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:22:54.333187
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'EITB'

# Generated at 2022-06-24 12:23:07.945950
# Unit test for constructor of class EitbIE
def test_EitbIE():

    def test_EitbIE_test():

        def test_EitbIE_test_test():
            assert '4104995148001' in EitbIE()._VALID_URL
            assert '60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/' in EitbIE()._VALID_URL
            assert 'bideoa/eztabaida/2014-11-28_15-17-47_4104995148001.mp4' in EitbIE()._VALID_URL
            assert 'eu/bideoa/eztabaida/2014-11-28_15-17-47_4104995148001.mp4' in EitbIE()._VALID_URL

# Generated at 2022-06-24 12:23:13.364927
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:23:25.767897
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert (ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert (ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:23:35.261677
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert obj._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert obj._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert float_or_none(3999.76, 1000) == 3999.76
    assert float_or_none(3999.76, 1000)

# Generated at 2022-06-24 12:23:36.320677
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_main import main
    main(EitbIE)


# Generated at 2022-06-24 12:23:42.517756
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test for class EitbIE
    """
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    expected_result = {
        'id': '4090227752001',
        'ext': 'mp4',
        'title': '60 minutos (Lasa y Zabala, 30 años)',
        'description': 'Programa de reportajes de actualidad.',
        'duration': 3996.76,
        'timestamp': 1381789200,
        'upload_date': '20131014',
        'tags': list,
    }
    content = EitbIE.IE_

# Generated at 2022-06-24 12:23:53.365035
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from ..utils import get_testfile_content

    def ie_instance_assert(name, ie_instance):
        if not ie_instance:
            raise AssertionError('Invalid IE instance %s. IE instance is empty' % name)
    EitbIE_instance = InfoExtractor._ies.get('eitb.tv')
    ie_instance_assert('EitbIE', EitbIE_instance)
    
    EitbIE._real_extract_testcase = get_testfile_content("http://www.eitb.tv/eu/bideoa/74-egunkaria/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    EitbIE_real_extract_testcase = Eitb

# Generated at 2022-06-24 12:23:57.209384
# Unit test for constructor of class EitbIE
def test_EitbIE():
    extractor_class = EitbIE
    instance = extractor_class("http://www.eitb.tv/es/video/")
    assert isinstance(instance, extractor_class)

# Open the .py file containing the tests to check that tests are consitently registered
# noinspection PyUnresolvedReferences
from . import EitbTests

# Generated at 2022-06-24 12:24:00.099175
# Unit test for constructor of class EitbIE
def test_EitbIE():
    new_EitbIE_object = EitbIE()
    assert new_EitbIE_object.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:04.366857
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test EitbIE constructor.
    """
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:24:08.069874
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None, None)

# Generated at 2022-06-24 12:24:10.573834
# Unit test for constructor of class EitbIE
def test_EitbIE():
        EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:24:18.523344
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:23.289293
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:33.732506
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/eztabaida/entzun/2014-11-11/varios-episodios/4099491290001/"
    ie = EitbIE(url)
    expected_url = "http://www.eitb.tv/eu/bideoa/eztabaida/entzun/2014-11-11/varios-episodios/4099491290001/"
    expected_md5 = "e16bc0c6b9d7f37c479ce9fe0f3b0a3e"

# Generated at 2022-06-24 12:24:35.202118
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('test')
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:24:38.490293
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:43.564329
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:24:49.353436
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    eitbIE._real_extract("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-24 12:24:59.993467
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test class EitbIE constructor."""
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/zuzenean/60-minutos/20131014/60-minutos-lasa-zabala-30-anos/4090227752001/")
    assert ie.IE_NAME == 'eitb.tv'
    # Test class EitbIE

# Generated at 2022-06-24 12:25:08.573894
# Unit test for constructor of class EitbIE

# Generated at 2022-06-24 12:25:11.903926
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.ie_key() == 'eitb.tv'
    assert eitb_ie.ie_name() == 'eitb.tv'

# Generated at 2022-06-24 12:25:13.091342
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() is not None

# Generated at 2022-06-24 12:25:16.283470
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-24 12:25:18.572093
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('www.eitb.tv')
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-24 12:25:19.747796
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('EitbIE')

# Generated at 2022-06-24 12:25:21.284023
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE(None)
    assert isinstance(eitb_ie, InfoExtractor)

# Generated at 2022-06-24 12:25:22.625441
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()



# Generated at 2022-06-24 12:25:23.520947
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:26.152615
# Unit test for constructor of class EitbIE
def test_EitbIE():
    constructorTest(EitbIE,url_EitbIE_correct,url_EitbIE_wrong,True)


# Generated at 2022-06-24 12:25:34.621183
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print ('\nTest for the class EitbIE')
    video_url = "http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    eitbie = EitbIE()
    info_dict = eitbie._real_extract(video_url)
    print (info_dict['title'])
    print (info_dict['id'])
    assert info_dict['id'] == "4090227752001"
    assert info_dict['title'] == "60 minutos (Lasa eta Zabala, 30 urte)"

# Generated at 2022-06-24 12:25:38.452232
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:25:49.309551
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._TEST['url'] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert EitbIE._TEST['md5'] == "edf4436247185adee3ea18ce64c47998"
    assert EitbIE._TEST['info_dict']['id'] == "4090227752001"
    assert EitbIE._TEST['info_dict']['ext'] == "mp4"
    assert EitbIE._TEST['info_dict']['title'] == "60 minutos (Lasa y Zabala, 30 años)"
    assert EitbIE

# Generated at 2022-06-24 12:25:49.972934
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:25:51.463887
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert isinstance(EitbIE, InfoExtractor)


# Generated at 2022-06-24 12:25:54.389117
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE(url)

# Generated at 2022-06-24 12:25:55.618562
# Unit test for constructor of class EitbIE
def test_EitbIE():
    if __name__ == '__main__':
        test_EitbIE()

# Generated at 2022-06-24 12:26:07.399521
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-24 12:26:08.139192
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-24 12:26:18.475178
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.ie_key() == 'eitb.tv'
    assert eitb.ie_name() == 'eitb.tv'
    assert eitb.http_headers() == None
    assert eitb.host() == 'www.eitb.tv'
    assert eitb.embed_webpage(None) == None
    assert eitb.embed_template() == None
    assert eitb.embed_matches() == list()
    assert eitb._og_search_path() == 'og:video:url'
    assert eitb.max_age() == 86400
    assert eitb.domain_whitelist() == list()