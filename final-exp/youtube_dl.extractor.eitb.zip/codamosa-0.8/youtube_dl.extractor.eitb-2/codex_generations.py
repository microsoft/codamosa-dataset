

# Generated at 2022-06-12 17:14:27.109209
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Test case constructor of class EitbIE """
    obj = EitbIE()
    assert obj



# Generated at 2022-06-12 17:14:30.663952
# Unit test for constructor of class EitbIE
def test_EitbIE():
    my_object = EitbIE('http://www.eitb.tv/eu/bideoa/')
    assert my_object.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:14:37.093640
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Try to construct an EitbIE object with the EitbIE's name
    """
    try:
        ie = EitbIE("EitbIE")
        assert ie is not None
        expect_str = "<EitbIE(EitbIE)>"
        assert str(ie) == expect_str
    except Exception as ex:
        assert type(ex) == AssertionError
        print("[ERROR] Constructor of class EitbIE generated an exception: " + str(ex))
        assert False



# Generated at 2022-06-12 17:14:44.777499
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #test1 = EitbIE('youtube', 'http://www.eitb.tv/es/video/vid', '60-minutos-60-minutos')
    test1 = EitbIE('twitter', 'https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    #test2 = EitbIE('twitter', 'http://www.eitb.tv/eu/bideoa/zuzenean-2014-10-28/4104995148001/4090954128001/tono-bilbo-bazterretxeta-emakume-karitatezina-bazterretxe-ordezkatz

# Generated at 2022-06-12 17:14:47.087571
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()
    assert t._VALID_URL == EitbIE._VALID_URL



# Generated at 2022-06-12 17:14:48.464627
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie


# Generated at 2022-06-12 17:14:52.269867
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert IE.IE_NAME == 'eitb.tv'



# Generated at 2022-06-12 17:14:54.001962
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple test for constructor of class EitbIE
    """
    ie = EitbIE()  # Constructor

# Generated at 2022-06-12 17:14:55.414162
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-12 17:15:03.774892
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test for EitbIE
    """
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.SUCCESS == True


# Generated at 2022-06-12 17:15:19.439711
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:15:25.695245
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.suitable('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')['title'] == '60 minutos (Lasa y Zabala, 30 años)'

# Generated at 2022-06-12 17:15:29.117971
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test that 'eitb.tv' can be initialized."""
    ie = EitbIE()
    assert ie.IE_NAME == 'Eitb'

# Generated at 2022-06-12 17:15:31.526886
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE != None

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-12 17:15:33.661143
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitbIE = EitbIE()
	assert eitbIE

# Generated at 2022-06-12 17:15:36.438523
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # can't use pytest.raises since id and url must exist for class to return
    ie = EitbIE(None)
    assert ie.IE_NAME == "eitb.tv"



# Generated at 2022-06-12 17:15:37.274066
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL

# Generated at 2022-06-12 17:15:37.972997
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()

# Generated at 2022-06-12 17:15:41.936365
# Unit test for constructor of class EitbIE
def test_EitbIE():
    parser = InfoExtractor()
    try:
        url = u'http://www.eitb.tv/eu/bideoa/trabajo-en-equipo/4104994953001/4098828302001'
        parser.suitable(url)
        assert parser._match_id(url) is not None
    except Exception as e:
        raise Exception(e)



# Generated at 2022-06-12 17:15:43.196343
# Unit test for constructor of class EitbIE
def test_EitbIE():             
    #test = EitbIE(None)
    EitbIE(None)

# Generated at 2022-06-12 17:16:14.669889
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Test function for constructor of class EitbIE """
    eitb = EitbIE()

# Generated at 2022-06-12 17:16:18.977645
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL is not None
    assert eitb._TEST is not None
    assert eitb.BR_VERSIONS is not None
    assert eitb.BROWSER_PERF_TEST_RESULTS is not None

# Generated at 2022-06-12 17:16:24.867328
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'
    assert eitbie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:16:27.269131
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for constructor of class EitbIE
    """
    obj = EitbIE()
    assert isinstance(obj, EitbIE)

# Generated at 2022-06-12 17:16:29.747604
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url='http://www.eitb.tv/eu/bideoa/eitb-kultura/4090227752001/'
    ie=EitbIE(url)

# Generated at 2022-06-12 17:16:30.342506
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE

# Generated at 2022-06-12 17:16:31.888425
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'Eitb.tv'

# Generated at 2022-06-12 17:16:33.552743
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/minutuak/13661537/')

# Generated at 2022-06-12 17:16:35.010837
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)
    assert ie != None

# Generated at 2022-06-12 17:16:40.784426
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    e = EitbIE.create_instance(test_url)
    assert e.ie_name == 'eitb.tv'
    assert e.test_video_file() == '4090227752001.mp4'

# Generated at 2022-06-12 17:17:14.179054
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE.test()

# Generated at 2022-06-12 17:17:18.489370
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is not None)

# Generated at 2022-06-12 17:17:21.228100
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/zure-entzuleak/espezie-garbia-14/4161751084001/')

# Generated at 2022-06-12 17:17:23.865488
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"


# Generated at 2022-06-12 17:17:26.733204
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:17:28.334116
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()

# Generated at 2022-06-12 17:17:37.091044
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test of class EitbIE constructor"""
    url = "http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4104995148001/4090227752001/"
    ie_obj = EitbIE(url)
    video_id = ie_obj.match_id
    video = ie_obj._download_json(
        'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % video_id,
        video_id, 'Downloading video JSON')

    media = video['web_media'][0]

    formats = []
    for rendition in media['RENDITIONS']:
        video_url = rendition.get('PMD_URL')
       

# Generated at 2022-06-12 17:17:46.976769
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    Test construction and basic fields of EitbIE
    '''
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_DESC == 'Eitb'
    assert ie.FILE_EXTENSIONS == ['mp4', 'm3u8']
    assert ie.BROWSER_TOKEN_REQUIRED == False
    assert ie.BROWSER_TOKEN_MAPPING == {}
    assert ie.BROWSER_PARAMS == {}


# Generated at 2022-06-12 17:17:49.393698
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import TestIE
    assert TestIE('EitbIE').run()

# Generated at 2022-06-12 17:17:52.872372
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    print (eitb_ie.IE_NAME)
    print (eitb_ie._VALID_URL)
    print (eitb_ie._TEST)

# Generated at 2022-06-12 17:19:09.517897
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:19:12.619639
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    if str(eitb) == 'EitbIE':
        print("Passed")
    else:
        print("Failed")


# Generated at 2022-06-12 17:19:22.924107
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Construct expected results
    exp_title = 'LeDocteur'
    exp_description = 'Programa de reportajes de actualidad.'
    exp_duration = 3996.76
    exp_timestamp = 1381789200
    exp_tags = ['60 minutos', 'actualidad', 'eitb']
    exp_id = '4090227752001'
    exp_thumbnail = 'http://damassets.multimediapub.com/homer/clipping/2011/10/13/1318383047_1318383048.jpg'

# Generated at 2022-06-12 17:19:23.487355
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:19:24.044969
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE

# Generated at 2022-06-12 17:19:24.953511
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-12 17:19:27.123588
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Checks whether constructor of class EitbIE works.
    """
    test_object = EitbIE()
    assert test_object.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:19:27.937955
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info(str(EitbIE))

# Generated at 2022-06-12 17:19:28.727125
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, None)

# Generated at 2022-06-12 17:19:29.856040
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert True       #TODO: implement your test here

# Generated at 2022-06-12 17:22:38.976393
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiation of class EitbIE
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:22:41.964214
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/euskaraz/63757/elkartea/')

# Generated at 2022-06-12 17:22:42.757141
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-12 17:22:43.991529
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == EitbIE.__bases__[0]._VALID_URL

# Generated at 2022-06-12 17:22:47.703392
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('https://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assertie.assertEqual(ie.name, 'eitb.tv')
    assertie.assertEqual(ie.videoid, '4090227752001')
    

# Generated at 2022-06-12 17:22:51.207163
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert(e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-12 17:22:59.847468
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Not a video actually
    EitbIE("http://www.eitb.tv/eu/deportes/noticia/Lapurdiko-futbola-txapelketak-gora-gaizki-dira/es/2667249/");
    # Not a video actually
    EitbIE("http://www.eitb.tv/eu/kultura/noticia/Amets-arzallus-eu-aztertzen-izan-dute-macar-sorkuntzalaritik/es/2667249/");
    # Video
    EitbIE("http://www.eitb.tv/eu/audio/pantaila-zabal/programa/2865/");
    # Query string parameters

# Generated at 2022-06-12 17:23:03.422722
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # http://www.eitb.tv/eu/bideoa/2013/09/03/cinema-mugimenduan/4087277904001/
    eitb.test()

# Generated at 2022-06-12 17:23:04.755768
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:23:06.053056
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'