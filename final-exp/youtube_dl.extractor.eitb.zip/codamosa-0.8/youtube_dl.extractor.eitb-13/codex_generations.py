

# Generated at 2022-06-12 17:14:36.633096
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.__module__ == 'youtube_dl.extractor.eitb'
    assert EitbIE.__name__ == 'EitbIE'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:14:40.029821
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-12 17:14:44.067106
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:14:53.107316
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

    i = ie._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(i['id'] == '4090227752001')
    assert(i['title'] == '60 minutos (Lasa y Zabala, 30 años)')

# Generated at 2022-06-12 17:15:00.355615
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:01.873056
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    dir(eitb_ie)

# Generated at 2022-06-12 17:15:08.495045
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:16.141690
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for constructor of class EitbIE
    """
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:15:18.012127
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Returns EitbIE
    """
    instance = EitbIE()
    assert isinstance(instance, EitbIE)

# Generated at 2022-06-12 17:15:20.466329
# Unit test for constructor of class EitbIE
def test_EitbIE():
	global my_extractor
	my_extractor=EitbIE()

if __name__ == '__main__':
	test_EitbIE()

# Generated at 2022-06-12 17:15:32.571248
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:41.207083
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Construct an instance of EitbIE and call _real_extract.
    """
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:51.615121
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == url
    assert ie._TEST['id'] == '4090227752001'

# Generated at 2022-06-12 17:15:53.911411
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = ie._match_id(url)

# Generated at 2022-06-12 17:15:57.152547
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Test without video_id
    EitbIE(None)

    # Test with video_id
    EitbIE("123456")

# Generated at 2022-06-12 17:15:58.265828
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE"""
    return

# Generated at 2022-06-12 17:16:01.123115
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert not EitbIE().suitable('http://www.eitb.eus/es/')

# Generated at 2022-06-12 17:16:03.206298
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None, 'EitbIE is not loaded'

# Generated at 2022-06-12 17:16:07.914101
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:16:13.971249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()._get_info_extractor('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-12 17:16:29.581884
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie=EitbIE()
    assert ie.IE_NAME == 'eitb.tv'



# Generated at 2022-06-12 17:16:30.535260
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()


# Generated at 2022-06-12 17:16:37.759091
# Unit test for constructor of class EitbIE
def test_EitbIE():
# Creation of an instance
    ie = EitbIE()
    # Appropriate attributes/methods exist
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert ie

# Generated at 2022-06-12 17:16:46.983559
# Unit test for constructor of class EitbIE
def test_EitbIE():

    def test_no_extraction(url):
        return EitbIE().suitable(url) is False

    assert test_no_extraction('http://www.eitb.tv/eu/') is True
    assert test_no_extraction('http://www.eitb.tv/eu') is True
    assert test_no_extraction('http://www.eitb.tv/eu/error') is True
    assert test_no_extraction('http://www.eitb.tv/eu/video/index.xml') is True
    assert test_no_extraction('http://www.eitb.tv/eu/video/bideoak/index.xml') is True
    assert test_no_extraction('http://www.eitb.tv/es/video/index.xml') is True
    assert test

# Generated at 2022-06-12 17:16:47.857954
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-12 17:16:49.293114
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE(None, {}, None)
    assert eitb is not None

# Generated at 2022-06-12 17:16:50.440377
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE('EitbIE')
    assert obj is not None

# Generated at 2022-06-12 17:16:50.898424
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:16:54.621803
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:16:58.327850
# Unit test for constructor of class EitbIE
def test_EitbIE():
    v = EitbIE()
    assert v._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert v.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:17:31.865037
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/eitb-launean/2464800/')

# Generated at 2022-06-12 17:17:32.707252
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert('Eitb' in locals())

# Generated at 2022-06-12 17:17:33.430775
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-12 17:17:40.271059
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

    assert ie.ie_key() == 'eitb.tv'
    assert ie.IE_NAME == 'eitb.tv'

    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:17:44.986057
# Unit test for constructor of class EitbIE
def test_EitbIE():

    IE = EitbIE()

    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert IE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:17:52.276345
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:17:54.869781
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """test the constructor of class EitbIE"""
    assert EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:18:02.555794
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert ie._TEST['info_dict']
    assert ie._T

# Generated at 2022-06-12 17:18:05.521366
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('test_url')._VALID_URL.pattern == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:18:06.947682
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb is not None

# Test for function _real_extract of class EitbIE

# Generated at 2022-06-12 17:19:23.935842
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-12 17:19:25.127898
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert int(instance.ie_key()) == 19

# Generated at 2022-06-12 17:19:26.637233
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Tests constructor of class EitbIE."""

    x = EitbIE()

# Generated at 2022-06-12 17:19:35.141599
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert issubclass(EitbIE, InfoExtractor)
        eitbie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
        assert eitbie.IE_NAME == 'eitb.tv'
        assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    except:
        raise

# Generated at 2022-06-12 17:19:40.260905
# Unit test for constructor of class EitbIE
def test_EitbIE():
    c = EitbIE()
    assert c._match_id('http://www.eitb.tv/es/video/xxx/4104995148001/4090227752001/lasa-y-zabala-30-anos/') == '4090227752001'
    assert c._match_id('http://www.eitb.tv/eu/bideoa/programak-telebista/eu/prezentadoreak/4104995148001/4114190933001/eor-1/') == '4114190933001'

# Generated at 2022-06-12 17:19:43.914906
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:19:47.826075
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:    # Try importing the constructor
        from youtube_dl.extractor.eitb import EitbIE
        constr = True
    except ImportError:    # Otherwise, inform about the problem
        constr = False
    assert constr

# Generated at 2022-06-12 17:19:51.476060
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:19:59.459625
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check if URL passed is valid
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    # Check the test cases

# Generated at 2022-06-12 17:20:00.485711
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(isinstance(EitbIE({}), EitbIE))

# Generated at 2022-06-12 17:23:10.231850
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple test to check the constructor of EitbIE
    """
    ie = EitbIE(None)
    assert ie.IE_NAME == "eitb.tv"

# Generated at 2022-06-12 17:23:13.777985
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple test to ensure class EitbIE has been defined.
    """
    try:
        testee = EitbIE()
        return testee.IE_NAME
    except NameError:
        assert False, "Error: class EitbIE has not been defined"
#test_EitbIE()

# Generated at 2022-06-12 17:23:14.717170
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert not isinstance(instance, InfoExtractor) is True

# Generated at 2022-06-12 17:23:15.234049
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-12 17:23:16.003528
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE(youtube_dl=None)

# Generated at 2022-06-12 17:23:22.417266
# Unit test for constructor of class EitbIE
def test_EitbIE():
	try:
		EitbIE("joshuawise", "test.mp4")
		print("EitbIE constructor test: PASSED!")
	except:
		print("EitbIE constructor test: FAILED!")

# Generated at 2022-06-12 17:23:23.245311
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)

# Generated at 2022-06-12 17:23:28.110104
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    construct_EitbIE = EitbIE(self, _VALID_URL)

# Generated at 2022-06-12 17:23:34.426048
# Unit test for constructor of class EitbIE
def test_EitbIE():
  # This is a basic test.
  # 1. Create an instance of EitbIE.
  # 2. Extract information from a test URL.
  # 3. Compare the expected result with the result obtained.

  test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
  test_video_id = '4090227752001'
  test_md5 = 'edf4436247185adee3ea18ce64c47998'
  test_title = '60 minutos (Lasa y Zabala, 30 años)'
  test_description = 'Programa de reportajes de actualidad.'

# Generated at 2022-06-12 17:23:42.736041
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE('eitb.tv')
    assert(IE.ie_key() == 'EitbTV')
    assert(IE.ie_name() == 'eitb.tv')
    assert(IE.ie_type() == 'video')
    assert(IE.valid_url('http://www.eitb.tv/eu/bideoa/zuzendaritza-digitalaren-erronka-funtsezkoa/4104995148001/', 'http://www.eitb.tv/eu/bideoa/zuzendaritza-digitalaren-erronka-funtsezkoa/4104995148001/'))