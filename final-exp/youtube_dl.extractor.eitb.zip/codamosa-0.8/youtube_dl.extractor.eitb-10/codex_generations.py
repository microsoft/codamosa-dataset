

# Generated at 2022-06-12 17:14:36.554947
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    video_id = "4090227752001"
    info_dict = {
        'id': '4090227752001',
        'ext': 'mp4',
        'title': '60 minutos (Lasa y Zabala, 30 años)',
        'description': 'Programa de reportajes de actualidad.',
        'duration': 3996.76,
        'timestamp': 1381789200,
        'upload_date': '20131014',
        'tags': list,
    }

# Generated at 2022-06-12 17:14:40.580617
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert isinstance(ie, EitbIE)


# Generated at 2022-06-12 17:14:45.644023
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:14:46.440341
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:14:47.457293
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-12 17:14:49.174395
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Testing EitbIE constructor
	assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:14:50.076599
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE


# Generated at 2022-06-12 17:14:54.346619
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .back_up.eitb_test import EitbTest
    eitb_test = EitbTest()
    eitb_test.test_EitbIE()


# Generated at 2022-06-12 17:15:00.409593
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE('http://www.eitb.tv/eu/bideoa/zinemaldia-2012-kurosawa-krew-kurosawaren-krew/4082250446001/4093889715001/', 'eitbtv')
    assert eitb._match_id(eitb._VALID_URL) == "4093889715001"


# Generated at 2022-06-12 17:15:01.230620
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Basic test to check the class constructor
    """
    EitbIE()

# Generated at 2022-06-12 17:15:15.745461
# Unit test for constructor of class EitbIE
def test_EitbIE():
	print("Test case 1: Valid URL, different video ID")
	assert EitbIE("https://www.eitb.tv/eu/bideoa/gaur-eguerdi-aretoa/4204268885001/4613274624001/2020-10-01-18-19/").ie_key() == "Eitb"
	
	print("Test case 2: Valid URL, video ID '4204268885001'")
	assert EitbIE("https://www.eitb.tv/eu/bideoa/gaur-eguerdi-aretoa/4204268885001/4204268885001/2020-10-01-18-19/").ie_key() == "Eitb"
	
	print("Test case 3: Non-video URL")
	assert Eitb

# Generated at 2022-06-12 17:15:19.875943
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    

# Generated at 2022-06-12 17:15:23.132802
# Unit test for constructor of class EitbIE
def test_EitbIE():

    print("Unit test for constructor of class EitbIE")

    eitb_ie = EitbIE()

    assert eitb_ie.IE_NAME == "eitb.tv"
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:15:28.732045
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test case for constructor of class EitbIE"""
    url = 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4104995148001/'
    e = EitbIE()
    video_id = e._match_id(url)
    video_id

# Generated at 2022-06-12 17:15:29.820355
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-12 17:15:36.502275
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eie.IE_NAME == 'eitb.tv'
    assert eie.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:43.432745
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    # url = 'http://www.eitb.tv/eu/bideoa/teknologia/informazio-teknologiaren-historia-etea-etik-aitzineko-jardueraren-sarean/4090488126001'
    video_id = '4090227752001'
    # video_id = '4090488126001'
    # video_id = '4090488126'
    eitb_ie = EitbIE()
    # eitb_ie = EitbIE(url,

# Generated at 2022-06-12 17:15:45.764318
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE();
    assert ie.IE_NAME != None
    assert ie._VALID_URL != None

# Generated at 2022-06-12 17:15:55.041398
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    print('Testing the constructor of class EitbIE')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:55.555446
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE

# Generated at 2022-06-12 17:16:10.988744
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from tests import _test_extractors
    _test_extractors(EitbIE)

# Generated at 2022-06-12 17:16:15.697449
# Unit test for constructor of class EitbIE
def test_EitbIE():
    d = EitbIE()
    assert d.IE_NAME == 'eitb.tv'
    assert d._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:19.806550
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case = EitbIE()
    assert test_case._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert test_case.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:16:25.097268
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_url = r'http://www.eitb.tv/eu/bideoa/telebista-irratia/noticia/1386380959002-tokio-hotel-humanoid-etxean-eta-eskutik/'
    eitb = EitbIE()
    eitb._real_extract(video_url)

# Generated at 2022-06-12 17:16:26.923384
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-12 17:16:30.132019
# Unit test for constructor of class EitbIE
def test_EitbIE():
    if EitbIE._TEST is not None:
        ie = EitbIE()
        ie.process_request(EitbIE._TEST['url'])

# Generated at 2022-06-12 17:16:33.859428
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/euskaraz/5212573/Zientzia-et-Divertido/'
    # instance of class EitbIE
    ie = EitbIE()
    # test method _real_extract
    assert ie._real_extract(url)

# Generated at 2022-06-12 17:16:34.675082
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-12 17:16:39.118397
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple unit test for EitbIE
    """
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:40.362344
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-12 17:17:12.306597
# Unit test for constructor of class EitbIE
def test_EitbIE():

    params = {
        'url' : 'http://www.eitb.tv/eu/bideoa/2013/10/14/lasa-y-zabala-30-anos-121847/',
        'name' : 'EitbIE',
        'ie_key' : 'EitbIE'
        }

    ie = EitbIE(params)

    # Assert constructor returns an object of type EitbIE
    assert isinstance(ie, EitbIE)


# Generated at 2022-06-12 17:17:18.936598
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.get_url_regex() == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie.get_name() == 'eitb.tv'


# Generated at 2022-06-12 17:17:26.280598
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:17:29.884017
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert(EitbIE.IE_NAME=='eitb.tv')
    except:
        pytest.fail('The class EitbIE should have a "IE_NAME" attribute.')


# Generated at 2022-06-12 17:17:36.033325
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check constructor of EitbIE
    # EitbIE is an InfoExtractor
    # InfoExtractor has a constructor
    # The constructor does not return any value
    ie = EitbIE()
    assert ie is None # In this case, constructor does not return any value


# Generated at 2022-06-12 17:17:43.522306
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Testing constructor of class EitbIE"""
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'
    assert eitbie.IE_DESC == 'eitb.tv'
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:17:46.686636
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:17:50.298198
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Unit test get_id

# Generated at 2022-06-12 17:17:53.100517
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert isinstance(instance, EitbIE)
    assert hasattr(instance, _VALID_URL)
    assert hasattr(instance, _TEST)


# Generated at 2022-06-12 17:17:53.635578
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-12 17:18:56.003778
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-12 17:18:57.428097
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(EitbIE._downloader, True)

# Generated at 2022-06-12 17:18:58.567173
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE != None


# Generated at 2022-06-12 17:18:59.863141
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.IE_NAME == 'eitb.tv')

# Generated at 2022-06-12 17:19:09.548636
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    print(obj)
    assert obj.name == 'eitb.tv'
    assert obj.IE_NAME == 'eitb.tv'
    assert obj.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:19:12.334860
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    assert a.IE_NAME == 'eitb.tv'
    
# Test that the EitbIE downloader does not download any xml files

# Generated at 2022-06-12 17:19:13.205013
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-12 17:19:17.390840
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-12 17:19:19.131371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:19:20.595571
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    print(ie.IE_NAME)

# Generated at 2022-06-12 17:22:03.290873
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/zuzenean/2014/11/10/zuzenean-2014-11-10-2/4094409433001/'
    eitbIE = EitbIE(url)

# Generated at 2022-06-12 17:22:04.590755
# Unit test for constructor of class EitbIE
def test_EitbIE():
    global IEITB
    IEITB = EitbIE(downloader=None)


# Generated at 2022-06-12 17:22:05.999548
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.ie_key() == 'eitb.tv'

# Generated at 2022-06-12 17:22:08.733223
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
test_EitbIE.func_doc = "Unit test for constructor of class EitbIE"


# Generated at 2022-06-12 17:22:18.555773
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    assert test.IE_NAME == 'eitb.tv'
    eitb_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert test._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert test._match_id(eitb_url) == '4090227752001'

# Generated at 2022-06-12 17:22:28.106163
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from youtube_dl.downloader.http import HttpFD
	from youtube_dl.extractor import InfoExtractor
	from youtube_dl.utils import sanitize_open

	eitb = EitbIE({})
	assert eitb.ie_key() == 'Eitb'

	# Test metadata extractor
	ie_result = eitb._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
	assert ie_result[u'id'] == '4090227752001'
	assert ie_result[u'title'] == '60 minutos (Lasa y Zabala, 30 años)'


# Generated at 2022-06-12 17:22:28.731819
# Unit test for constructor of class EitbIE
def test_EitbIE():
  constructor_test(EitbIE)

# Generated at 2022-06-12 17:22:37.634914
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:22:38.975885
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert "EitbIE" in IE.name

# Generated at 2022-06-12 17:22:45.529505
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'