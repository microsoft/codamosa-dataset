

# Generated at 2022-06-12 17:14:31.479896
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i.IE_NAME == 'eitb.tv'
    assert i._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:14:32.619503
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE_object = EitbIE();

# Generated at 2022-06-12 17:14:37.890298
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb = EitbIE()
    (id) = eitb._match_id(url)
    assert id == '4090227752001'
    eitb._real_extract(url)

# Generated at 2022-06-12 17:14:45.266294
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj._VALID_URL == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert obj._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert obj._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert obj._TEST['info_dict']['id'] == '4090227752001'

# Generated at 2022-06-12 17:14:54.049032
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # To check whether python data structures is serializable
    import json
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:14:55.465651
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test = EitbIE(None)



# Generated at 2022-06-12 17:14:59.992907
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e is not None
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:01.150997
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    return ie

# Generated at 2022-06-12 17:15:08.058658
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert i.name == 'eitb.tv'
    assert i._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:14.305641
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb = EitbIE()
    assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb._match_id(url) == '4090227752001'

# Generated at 2022-06-12 17:15:30.337825
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    return assertEqual(instance._match_id(instance._VALID_URL), "4090227752001")

# Generated at 2022-06-12 17:15:34.008954
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test
    ~~~~~~~~~~~~~~~~
    This test makes sure that creating an instance of the EitbIE
    doesn't produce any errors and the IE key is present in the
    returned dictionary
    """
    ie = EitbIE(None)
    result = ie.extractor.IE_NAME in ie.result
    assert result

# Generated at 2022-06-12 17:15:36.340369
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE

    Make sure that the EitbIE constructor doesn't throw any exceptions.
    """
    ie = EitbIE()

# Generated at 2022-06-12 17:15:41.443436
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    info_dict = EitbIE._TEST
    ie = EitbIE()
    ie._downloader = DummyDownloader(ie, params={'test': 1})
    ie._real_extract(url) == info_dict

# Generated at 2022-06-12 17:15:42.665012
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:15:52.798561
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos/4090227752001/lasa-y-zabala-30-anos/")
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"

# Generated at 2022-06-12 17:16:00.777157
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', '60 minutos (Lasa y Zabala, 30 años)', 'Programa de reportajes de actualidad.', 3996.76, 1381789200, '20131014', list))

# Generated at 2022-06-12 17:16:06.564485
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('http://www.eitb.tv/eu/bideoa/64-minutuak/4104995148203/4090227752001/gero-azkena-aupa-talde-bakarra/')
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE.IE_DESC == 'eitb.tv'

# Generated at 2022-06-12 17:16:17.562948
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a_EitbIE = EitbIE(None)
    assert a_EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:28.301092
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst.IE_NAME == 'eitb.tv'
    assert inst._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:48.672686
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Test instantiation of EitbIE
    tester = EitbIE()

    # Test URL matching
    #assert tester._match_id('http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4089883091001/')
    assert tester._match_id('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is not None

# Generated at 2022-06-12 17:16:49.482833
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-12 17:16:52.194292
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    General test for EitbIE
    """

    #- Check if the EitbIE constructor is ok
    ie = EitbIE(IE_NAME)
    ie = EitbIE(IE_NAME, {}, 'Default title')

# Generated at 2022-06-12 17:16:55.421080
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:17:02.372142
# Unit test for constructor of class EitbIE
def test_EitbIE():
	import unittest
	from youtube_dl.extractor.eitb import EitbIE

	assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:17:03.359860
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE() != None)

# Generated at 2022-06-12 17:17:05.637500
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert(eitbIE.IE_NAME == 'eitb.tv')

# Generated at 2022-06-12 17:17:06.206119
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:17:10.690125
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:17:21.917886
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-12 17:17:54.312282
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'



# Generated at 2022-06-12 17:18:02.309869
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e._VALID_URL == ('https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)'+
        '/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-12 17:18:10.567866
# Unit test for constructor of class EitbIE
def test_EitbIE():
  ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
  assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
  assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:18:14.487983
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # The class EitbIE is instantiated with a url string in terms of the __init__ method
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    # An EitbIE instance is created
    ie = EitbIE(url)
    assert ie != None

# Generated at 2022-06-12 17:18:18.967548
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:18:30.564872
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Assign values to the variables
	url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	video_id = '4090227752001'
	# Create an object of the class
	eitbie = EitbIE(EitbIE.ie_key())
	# Check if the variables have the correct values
	assert eitbie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:18:32.305409
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == "EitbIE"


# Generated at 2022-06-12 17:18:40.287926
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie=EitbIE()
    ie.download('http://mam.eitb.eus/mam/REST/ServiceMultiweb/DomainRestrictedSecurity/TokenAuth/')
    ie.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:18:44.750084
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE(InfoExtractor())
    assert IE.IE_NAME == 'eitb.tv'
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:18:46.446581
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_class = EitbIE()
    assert eitb_class.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:20:06.508869
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:20:08.156371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE('t', 'u')
        assert False
    except Exception as e:
        assert e.message


# Generated at 2022-06-12 17:20:08.523470
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:20:09.440516
# Unit test for constructor of class EitbIE
def test_EitbIE():
	try:
		EitbIE()
	except:
		return False
	return True

# Generated at 2022-06-12 17:20:10.326391
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL
    assert eitb._TEST

# Generated at 2022-06-12 17:20:10.824708
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:20:15.004843
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:20:23.627939
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    video_id = '4090227752001'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:20:28.402188
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_instance = EitbIE()
    assert eitb_instance._TEST['url'] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/" # url
    assert eitb_instance._TEST['id'] == "4090227752001" # video_id
    assert eitb_instance._TEST['md5'] == "edf4436247185adee3ea18ce64c47998" # video_md5
    assert eitb_instance._TEST['info_dict']['id'] == "4090227752001"
    assert eitb_instance._TEST['info_dict']['ext']

# Generated at 2022-06-12 17:20:30.216971
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test instantiation:
    EitbIE()


# Generated at 2022-06-12 17:23:29.934816
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eie = EitbIE()
    eie.IE_NAME == 'eitb.tv'
    eie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:23:35.404686
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:23:41.568303
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = ie._match_id(test_url)
    assert video_id=='4090227752001'
    assert ie._real_extract(test_url)['title']=='60 minutos (Lasa y Zabala, 30 años)'

# Generated at 2022-06-12 17:23:42.372175
# Unit test for constructor of class EitbIE
def test_EitbIE():
  assert True

# Generated at 2022-06-12 17:23:46.031417
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    ie = InfoExtractor()
    assert ie == InfoExtractor()


# Generated at 2022-06-12 17:23:46.939621
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-12 17:23:48.523069
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:23:51.217185
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create instance for class EitbIE
    ie = EitbIE()
    # Check if created instance is an instance of EitbIE
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-12 17:23:53.766663
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    b = InfoExtractor()
    b.add_ie(a.ie_key(), a)
    b.remove_ie(a.ie_key())

# Generated at 2022-06-12 17:24:01.521622
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'