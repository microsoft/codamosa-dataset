

# Generated at 2022-06-12 17:14:31.679192
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:14:32.820652
# Unit test for constructor of class EitbIE
def test_EitbIE():
  assert EitbIE == InfoExtractor

# Generated at 2022-06-12 17:14:33.702186
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-12 17:14:34.937798
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE, InfoExtractor)


# Generated at 2022-06-12 17:14:39.252019
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:14:43.934776
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Attempt to create an instance of the EitbIE class.
    # This should raise a RegexNotFoundError if the regular expression
    # does not compile, or it finds no matches.
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:14:47.411037
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:14:48.720116
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # TODO: Add test
    pass


# Generated at 2022-06-12 17:14:56.008560
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == (
        r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)'
        r'/[^/]+/\d+/(?P<id>\d+)'
    )
    assert e._TEST['url'] == (
        'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/'
        '4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    )
    assert e._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-12 17:15:05.220001
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE = EitbIE()
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:16.690186
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    test_url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    ie.extract(test_url)

# Generated at 2022-06-12 17:15:21.788510
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.__class__.__name__ == 'EitbIE'



# Generated at 2022-06-12 17:15:27.798108
# Unit test for constructor of class EitbIE
def test_EitbIE():
	info = EitbIE('http://www.eitb.tv/es')
	assert info._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:30.954778
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    url = "http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert eitbie._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"
    assert eitbie._TEST['url'] == url

# Generated at 2022-06-12 17:15:35.193932
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return 'http://www.eitb.tv/eu/bideoa/30-minutos/4104995148001/4098986678001/gure-egunak-komedia-musicala/'

# Generated at 2022-06-12 17:15:40.219314
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EITB_URL = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    # Build unit test for constructor of class EitbIE
    ie = EitbIE()
    # Call method _real_extract for test
    ie._real_extract(EITB_URL)

# Generated at 2022-06-12 17:15:43.721266
# Unit test for constructor of class EitbIE
def test_EitbIE():
	info_extractor = EitbIE()
	info_extractor.extract('http://www.eitb.tv/eu/bideoa/hil-etorri-eta-dantzatzen-jarraitu/4488462524001/')

# Generated at 2022-06-12 17:15:45.463805
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_Test = EitbIE(None)
    assert IE_Test.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:15:47.856733
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.extractor_key == 'eitb'



# Generated at 2022-06-12 17:15:49.449906
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-12 17:16:05.748251
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Creation of instance
    eitb = EitbIE({})
    # Confirm the name of the class
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:16:06.259522
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:16:12.897413
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE=EitbIE();
    assert(eitbIE.IE_NAME =='eitb.tv');
    assert(eitbIE._VALID_URL==r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)');

# Generated at 2022-06-12 17:16:21.104639
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert 'EitbIE' in EitbIE._downloader.IE_NAME
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-12 17:16:22.560913
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    print(ie)


# Generated at 2022-06-12 17:16:27.008570
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    ie = InfoExtractor()
    ie._real_initialize()
    info_dict = ie.IE_NAME(ie)._real_extract(EitbIE._TEST['url'])
    assert info_dict['id'] == EitbIE._TEST['info_dict']['id']

# Generated at 2022-06-12 17:16:32.480553
# Unit test for constructor of class EitbIE
def test_EitbIE():
  # Test case #1
  video_id = "4090227752001"
  eitbie = EitbIE({})
  assert eitbie.suitable('https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
  assert eitbie._match_id(url) == video_id

# Generated at 2022-06-12 17:16:33.552379
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()
	assert ie is not None

# Generated at 2022-06-12 17:16:42.442200
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # These vars are used to extract the page
    page = 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/'
    title = "60 minutos"
    description = 'Programa de reportajes de actualidad.'
    thumbnail = 'http://media.eitb.tv/multimedia/2013/10/14/2013-10-01T104401Z_1_CBRE9900BS1K_RTROPTP_3_SPAIN-BASQUECOUNTRY-LASAZABALA/2013-10-01T104401Z_1_CBRE9900BS1K_RTROPTP_3_SPAIN-BASQUECOUNTRY-LASAZABALA_XLARGE.jpg'
    duration = 3996.76

# Generated at 2022-06-12 17:16:51.155859
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("EitbIE", "http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4111563157001/espa-ol-legal-sin-documentos/", {}, False)
    assert '4110942648001' == ie._real_extract({}, "4110942648001")['id']

# Generated at 2022-06-12 17:17:29.965154
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    EitbIE('/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:17:30.487663
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:17:38.365549
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:17:42.605643
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:17:48.087963
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = '%s?url=%s&video_id=%s' % (EitbIE._VALID_URL, 'http://www.eitb.tv/eu/bideoa/lasa-et-zabala-30-urte/4090227752001/', '4090227752001')
    ie = EitbIE(url)
    assert isinstance(ie, EitbIE), ('%r should be an instance of %r' % (ie, EitbIE))

# Generated at 2022-06-12 17:17:49.161547
# Unit test for constructor of class EitbIE
def test_EitbIE():
   eitb_ie = EitbIE()

# Generated at 2022-06-12 17:17:51.328237
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e



# Generated at 2022-06-12 17:17:53.509617
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('eitb.tv', 'eitb.tv')
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:17:57.809550
# Unit test for constructor of class EitbIE
def test_EitbIE():
  ie = EitbIE(None)
  assert ie
  assert ie.IE_NAME == 'eitb.tv'
  assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:18:05.354733
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test EitbIE constructor
    ie = EitbIE('eitb.tv')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-12 17:19:25.408326
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    url = 'http://www.eitb.tv/eu/bideoa/noticia-eitb/1064784/'
    assert obj.suitable(url)
    assert obj.IE_NAME is not None
    assert obj._VALID_URL is not None

# Generated at 2022-06-12 17:19:31.219934
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Unit test for constructor of class EitbIE.
    ie = EitbIE()
    # Test __init__()
    assert ie.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'Eitb'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    IE_DESC = 'eitb.tv and eitb.eus'
    # Test ie_key()
    assert ie.ie_

# Generated at 2022-06-12 17:19:36.073462
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE(None)
    assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:19:46.805525
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Constructor: Testing constructor")
    inst = EitbIE()
    assert inst.IE_NAME == "eitb.tv"
    assert inst._TEST['url'] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert inst._TEST['md5'] == "edf4436247185adee3ea18ce64c47998"
    assert inst._TEST['info_dict']['id'] == "4090227752001"
    assert inst._TEST['info_dict']['ext'] == "mp4"

# Generated at 2022-06-12 17:19:49.332496
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing EitbIE class...")
    info_extractor = InfoExtractor()
    eitb = EitbIE(info_extractor)
    print("\tFinished testing EitbIE class.\n")

# Generated at 2022-06-12 17:19:50.495778
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE({})
    assert eitbIE is not None

# Generated at 2022-06-12 17:19:50.978454
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:19:52.169984
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL)

# Generated at 2022-06-12 17:19:59.392516
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # TODO: What's an appropriate url that EitbIE supports?
    url = "http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert EitbIE._VALID_URL == "http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert EitbIE._TEST['url'] == url


# Generated at 2022-06-12 17:20:02.093294
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:23:12.089581
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_obj = EitbIE(None)
    assert hasattr(ie_obj, 'IE_NAME')
    assert hasattr(ie_obj, '_VALID_URL')
    assert hasattr(ie_obj, '_TEST')


# Generated at 2022-06-12 17:23:19.639367
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import tests

    def test_EitbIE(url):
        val = tests.IE_TESTS[EitbIE('eitb').ie_key()].get(url)
        val = val or tests.IE_TESTS[EitbIE('eitb').ie_key()].get(url.replace('eitb.tv', 'eitb.eus'))
        return val

    assert test_EitbIE('http://www.eitb.tv/eu/bideoa/gizarteak/20140611/mina-nahi-du/')
    assert test_EitbIE('http://www.eitb.eus/eu/bideoa/gizarteak/20140611/mina-nahi-du/')

# Generated at 2022-06-12 17:23:29.590939
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.name == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-12 17:23:30.068823
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:23:39.971123
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test constructor of class EitbIE.
    """
    eitb_ie = EitbIE()
    
    EitbIE.add_ie(eitb_ie)
    assert EitbIE.ie_key() == "eitb.tv"
    assert EitbIE.ie_key() in EitbIE.ies
    
    instance = EitbIE.instantiate()
    assert isinstance(instance, EitbIE)
    assert instance == EitbIE.instantiate()
    
if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-12 17:23:42.018482
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE.test()

# Generated at 2022-06-12 17:23:43.780977
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Test EitbIE initialization
    """
    eitb = EitbIE()

# Generated at 2022-06-12 17:23:53.141843
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = EitbIE._TEST['url']
    eitb_ie = EitbIE()
    eitb_ie._sort_formats(eitb_ie._extract_m3u8_formats(
            '%s?hdnts=%s' % ('Http://eita.eus/hls/fondo_1280x720.m3u8', 'abcdefghijklmnopqrstuvwxyz'),
            '4067598728001', 'hls'))

# Generated at 2022-06-12 17:23:55.920008
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    ie.suitable("http://www.eitb.tv/eu/bideoa/60-minutos/1101/4090227752001/")
    # Expected outcome : True


# Generated at 2022-06-12 17:23:56.458101
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()