

# Generated at 2022-06-12 17:14:35.562974
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from wikicurses.wiki import Wiki
    from wikicurses.wikicurses import Wikicurses
    wc = Wikicurses()
    wc.create_wiki(language="es", name="Prueba")

# Generated at 2022-06-12 17:14:36.755168
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:14:39.513320
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        x = EitbIE()
        assert isinstance(x, EitbIE)
    except:
        assert False, "Unexpected error when instantiating class EitbIE"

# Generated at 2022-06-12 17:14:44.757638
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")._VALID_URL=='https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:14:49.349030
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:14:50.245434
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE('eitb.tv')

# Generated at 2022-06-12 17:14:53.448767
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:14:58.610499
# Unit test for constructor of class EitbIE
def test_EitbIE():
    u = EitbIE()
    assert u.IE_NAME == 'eitb.tv'
    assert u._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:04.038771
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_list import extractors
    extractors.append(('http://www.eitb.tv/es/video/60-minutos-', 'EitbIE'))
    extractors.append(('http://www.eitb.tv/es/video/', 'EitbIE'))
    extractors.append(('http://www.eitb.tv/eu/bideoa/', 'EitbIE'))


# Generated at 2022-06-12 17:15:09.800972
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assertEqual(EitbIE._VALID_URL, 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    content = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assertEqual(EitbIE._match_id(content), '4090227752001')
    eitbIE = EitbIE()
    assertEqual(eitbIE._match_id(content), '4090227752001')

# Generated at 2022-06-12 17:15:25.301540
# Unit test for constructor of class EitbIE
def test_EitbIE():
    temp = EitbIE()
    assert temp._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:29.070849
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/informacion/videos/detalle/4104995148001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:15:34.100913
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # For example: http://www.eitb.tv/eu/bideoa/detail/3104995148001/
    url = 'http://www.eitb.tv/eu/bideoa/detail/3104995148001/'
    ie = EitbIE(EitbIE._VALID_URL)
    ie.extract(url)
    # TODO(yaoliu): add unit test for cases when hls_url or hds_url are not empty.

# Generated at 2022-06-12 17:15:42.076163
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    eitb_ie.suitable("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-12 17:15:46.536672
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:15:55.486993
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_compat import TestCompat
    from .test_youtube_dl import YoutubeDL
    from .compat import compat_str
    from .compat import compat_urlparse
    from .extractor import gen_extractors_map
    from .downloader.common import FileDownloader
    from .downloader.http import HttpFD
    from .utils import (
        compat_urllib_request,
        sanitized_Request,
        write_json_file,
        pid_exists,
        wrapped_output,
        download_json,
        get_cachedir,
        DateRange,
        RegexNotFoundError,
    )

# Generated at 2022-06-12 17:15:57.233065
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('EitbIE') == EitbIE

# Generated at 2022-06-12 17:16:02.941060
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Just use a simple constructor and call it in order to test it.
    class EitbTestIE(EitbIE):
        # Just use a simple constructor
        pass

    eitb_ie = EitbTestIE("EitbIE")
    assert eitb_ie.ie_key() == "EitbIE"
    assert eitb_ie.ie_name() == "eitb.tv"

# Generated at 2022-06-12 17:16:07.444747
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('Testing: %s'%EitbIE.IE_NAME)
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitbie = EitbIE()

# Generated at 2022-06-12 17:16:09.315952
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE.__name__ == 'EitbIE'

# Generated at 2022-06-12 17:16:25.001614
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Initialize a EitbIE object
	eitb = EitbIE()
	assert eitb



# Generated at 2022-06-12 17:16:31.659915
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        class_name, _ = EitbIE.IE_NAME.split(' ')
        globals()[class_name] = type(class_name, (object,), {'ie_key': class_name.lower()})
        globals()[class_name].IE_NAME = EitbIE.IE_NAME
        ie = globals()[class_name]()
        assert ie.ie_key == 'eitb'
    finally:
        del globals()[class_name]

# Generated at 2022-06-12 17:16:32.480276
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE

# Generated at 2022-06-12 17:16:38.985006
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    regex = r'http://www\.eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    from .YoutubeIE import YoutubeIE
    from .YoutubePlaylistIE import YoutubePlaylistIE
    from .YoutubeChannelIE import YoutubeChannelIE

    EitbIE.ie_key = 'EitbIE'
    EitbIE.ie_key_map = {}
    EitbIE.ie_key_map['EitbIE'] = EitbIE
    glob

# Generated at 2022-06-12 17:16:44.828118
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    Test constructor of class EitbIE
    '''
    eitbIE = EitbIE()
    assert(eitbIE.IE_NAME=='eitb.tv')
    assert(eitbIE._VALID_URL==r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-12 17:16:46.735732
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:16:53.947839
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'


# Generated at 2022-06-12 17:16:55.499096
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Runs test for the EitbIE class constructor.
    """
    e = EitbIE()

# Generated at 2022-06-12 17:17:02.423233
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitbIE._VALID_URL is not None
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitbIE._TEST is not None

# Generated at 2022-06-12 17:17:09.840928
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb_ie.IE_NAME == "eitb.tv"
    assert eitb_ie._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"

# Generated at 2022-06-12 17:17:47.791142
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:17:57.846464
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb.test.test_name == 'EitbIE.test_real_extract'

# Generated at 2022-06-12 17:18:00.911685
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert_equal(ie._VALID_URL, "http://www.eitb.tv/eu/bideoa/[^/]+/\d+/(?P<id>\d+)")
    assert_equal(ie.IE_NAME, "eitb.tv")

# Generated at 2022-06-12 17:18:04.726908
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE()
    assert (class_.IE_NAME == "eitb.tv")
    assert (class_._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-12 17:18:14.479130
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:18:25.853692
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Creating an instance of class EitbIE
    eitbie = EitbIE()

    # Testing the valid url recognition
    url_pattern = re.compile(eitbie._VALID_URL)
    assert url_pattern.match('http://www.eitb.tv/eu/bideoa/bideoen-ariketak/unibertsitatea-eta-ikerkuntza/id/4349249244001/')
    assert url_pattern.match('http://www.eitb.tv/es/video/cuentame-como-paso/4349249278001/4349249244001/todos-juntos/')

# Generated at 2022-06-12 17:18:26.718882
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    pass # no assert for now

# Generated at 2022-06-12 17:18:28.530800
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:18:35.583618
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ies = [EitbIE(), EitbIE(IE_NAME)]
    for ie in ies:
        assert ie.ie_key() == 'EitbIE', ie.ie_key()
        assert ie.ie_name() == 'eitb.tv', ie.ie_name()
        assert ie.ie_id() == 'EitbIE', ie.ie_id()
        assert ie.name() == 'Eitb', ie.name()
        assert ie.description() == 'eitb.tv', ie.description()



# Generated at 2022-06-12 17:18:42.049592
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_obj = EitbIE()
    main_obj = InfoExtractor()
    assert IE_obj.__class__.__name__ == 'EitbIE'
    assert IE_obj.ie_key() == 'eitb.tv'
    assert IE_obj.homepage == 'http://www.eitb.tv/'
    # test __init__ by creating an instance
    EitbIE(main_obj)

# Generated at 2022-06-12 17:20:06.214697
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:20:07.397061
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_DESC == 'eitb.tv'

# Generated at 2022-06-12 17:20:09.190907
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:20:09.556713
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:20:10.805677
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert IE.IE_NAME == 'eitb.tv'
    assert IE._VALID_URL is not None
    assert IE._TEST is not None

# Generated at 2022-06-12 17:20:14.564468
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    #Class EitbIE should be the default for this URL
    assert ie.suitable(IE_NAME, 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:20:19.552702
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None, None)
    assert(ie.IE_NAME == "eitb.tv")
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-12 17:20:20.696855
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()

# Generated at 2022-06-12 17:20:21.192873
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-12 17:20:21.834751
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-12 17:23:15.026165
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test: constructor test
    IE_TEST = EitbIE('www')
    # Test assert: instance of InfoExtractor
    assert isinstance(IE_TEST, InfoExtractor)
# End of test_EitbIE()


# Generated at 2022-06-12 17:23:16.128955
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    #Instance should be an object of class InfoExtractor
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-12 17:23:17.464295
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE(EitbIE._VALID_URL)._TEST)


# Generated at 2022-06-12 17:23:20.766642
# Unit test for constructor of class EitbIE
def test_EitbIE():
    d = EitbIE()
    assert d.IE_NAME == "eitb.tv"

test_EitbIE()

# Generated at 2022-06-12 17:23:25.544791
# Unit test for constructor of class EitbIE
def test_EitbIE():
    out = EitbIE()
    if hasattr(out, '_VALID_URL'):
        assert out._VALID_URL  # pylint: disable=no-member
    if hasattr(out, 'IE_NAME'):
        assert out.IE_NAME  # pylint: disable=no-member

# Generated at 2022-06-12 17:23:26.248163
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:23:33.161150
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import os.path
    from .test_downloads import _TESTS
    from .test_generic_info_extractor import _make_result
    from .test_videos_youtube import _common_results


# Generated at 2022-06-12 17:23:39.971598
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-12 17:23:47.408507
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-12 17:23:53.626018
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for invalid URL
    with pytest.raises(ExtractorError):
        EitbIE()._real_initialize(
            'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa--'
            'y-zabala-30-anos/')
    # Test for valid URL
    EitbIE()._real_initialize('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/'
                              '4090227752001/lasa-y-zabala-30-anos/')