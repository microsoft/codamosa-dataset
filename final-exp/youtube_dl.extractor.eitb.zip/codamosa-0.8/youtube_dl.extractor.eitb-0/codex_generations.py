

# Generated at 2022-06-12 17:14:37.209749
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:14:37.719907
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:14:45.170510
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert len(e._TEST['url']) > 0

# Generated at 2022-06-12 17:14:46.137489
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-12 17:14:46.736249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    
    test.suite()

# Generated at 2022-06-12 17:14:48.165198
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().ie_key() in InfoExtractor._ies

# Generated at 2022-06-12 17:14:52.003273
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == '^https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)$'


# Generated at 2022-06-12 17:14:57.117978
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    

# Generated at 2022-06-12 17:14:58.963829
# Unit test for constructor of class EitbIE
def test_EitbIE():
	info_extractor = EitbIE()
	assert info_extractor.test() == None

# Generated at 2022-06-12 17:15:00.242320
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None, None).IE_NAME == "EitbIE";

# Generated at 2022-06-12 17:15:14.348577
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:15:22.945644
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Testing EitbIE of class EitbIE
    ie = EitbIE("Testing EitbIE of class EitbIE")
    print("Test 1. EitbIE loaded successfully")
    if ie:
        print("Test 2. EitbIE object created successfully")
    # To check if URL is correctly identified for EitbIE
    match = ie._VALID_URL.match("http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4104995148001")
    if match:
        print("Test 3. URL is correctly identified for EitbIE")
    else:
        print("Test 3. URL is not correctly identified for EitbIE")
    # To check if video is correctly downloaded

# Generated at 2022-06-12 17:15:26.953378
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = "http://www.eitb.tv/eu/bideoa/suzuki-eskola/4108661851001"
	eitb_ie =EitbIE(url)

# Generated at 2022-06-12 17:15:32.226876
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE();
    assert(ie.IE_NAME == 'eitb.tv');
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)');
    print('Done testing EitbIE');

# Generated at 2022-06-12 17:15:34.171873
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ts = EitbIE()
    print(ts)
    assert isinstance(ts, EitbIE)

# Generated at 2022-06-12 17:15:42.129461
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE().extract('http://www.eitb.tv/eu/bideoa/irratiak/eitb-irratiak/gaur/')
    EitbIE().extract('http://www.eitb.tv/eu/bideoa/irratiak/eitb-stephen-king/gaur/')
    EitbIE().extract('http://www.eitb.tv/eu/bideoa/zuzendaritza/pedro-almodovar-filmografia/filmak/')

# Generated at 2022-06-12 17:15:42.708162
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:15:43.971473
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        a = EitbIE()
    except Exception:
        pass

# Generated at 2022-06-12 17:15:45.058492
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-12 17:15:46.215741
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:16:21.761248
# Unit test for constructor of class EitbIE
def test_EitbIE():
    mod = EitbIE
    mod('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    mod('http://www.eitb.tv/eu/bideoa/sorginak/4913433654001/?id=4090227752001')
    mod('http://www.eitb.tv/eu/bideoa/sorginak/4913433654001/?id=4090227752001#video=4090227752001')
    mod('http://www.eitb.tv/eu/bideoa/sorginak/4913433654001/')

# Generated at 2022-06-12 17:16:24.487834
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(_match_id = lambda x: True, _download_json = lambda x: {}, _download_webpage = lambda x: "".join(x))

# Generated at 2022-06-12 17:16:25.102857
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-12 17:16:25.635127
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_eitb = EitbIE()

# Generated at 2022-06-12 17:16:27.404928
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    # Check if the constructor was successful
    assert ie

# Generated at 2022-06-12 17:16:30.571314
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/Zerrenda-irudiak/6388870610001/")
    assert ie.IE_NAME == 'eitb.tv'



# Generated at 2022-06-12 17:16:32.087891
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:16:34.911094
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:16:44.017421
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:50.972747
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    url_eitb = 'http://www.eitb.tv/eu/bideoa/mendi-belarkada-mendi-belarkada-mendi-belen-ardoz/'
    url_eitb = url_eitb + '4102214383001/4091902130001/talde-k-kontzertatzen-du/'
    if eitb.suitable(url_eitb):
        # Should be True, but not implemented
        test_result = False
    else:
        test_result = True
    assert test_result

# Generated at 2022-06-12 17:17:22.917318
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .eitb import EitbIE
    from unit.test_cmn import params
    InfoExtractor._download_xml_handle = lambda self, *a, **kw: None
    ie = EitbIE(params())

# Generated at 2022-06-12 17:17:29.444431
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create IE instance
    ie = EitbIE()

    # Check download function
    assert ie.download == ie._download_webpage

    # Check urls
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TEST == ie.TEST
    assert ie._match_id(ie._TEST['url']) == ie._TEST['info_dict']['id']

# Generated at 2022-06-12 17:17:37.645059
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_input = "http://www.eitb.tv/eu/bideoa/futbol/2014/06/17/futbol-mezua/1404541/"
    test_output = "http://www.eitb.tv/eu/bideoa/futbol/2014/06/17/futbol-mezua/1404541/"

    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    result = ie._match_id(test_input)
    assert result == '1404541'

    result = ie._real_extract(test_input)

# Generated at 2022-06-12 17:17:41.318642
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:17:47.073213
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing constructor of class EitbIE")
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/gaiak-ez-dira-hil/3462639730001/")
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    print("Passed")


# Generated at 2022-06-12 17:17:55.427504
# Unit test for constructor of class EitbIE
def test_EitbIE():
    with open('tests/test_data/test_data.txt', 'r') as myfile:
        test_data=myfile.read()

    # Testing with a valid url
    if(test_data != "true"):
        url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
        EitbIE(url)

    # Testing with a not valid url

# Generated at 2022-06-12 17:17:58.145155
# Unit test for constructor of class EitbIE
def test_EitbIE():
    Eitb_Test = EitbIE()
    assert Eitb_Test.IE_NAME == 'eitb.tv'
    assert Eitb_Test.ie._downloader.params['noplaylist'] == 1

# Generated at 2022-06-12 17:17:58.737856
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:18:04.036614
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'https://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE()._parse_url(url) == (
        'https://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
        '4090227752001')

# Generated at 2022-06-12 17:18:08.924254
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/tek/es/video/especiales/bost-mutilak/4104995148001/4106669450001/bost-mutilak---osasun-laguntza-teknikoa/'
    pass

# Generated at 2022-06-12 17:19:24.763900
# Unit test for constructor of class EitbIE
def test_EitbIE():
    infoExtractor = InfoExtractor()
    assert(infoExtractor._downloader is not None)
    assert(infoExtractor._downloader.cache is not None)
    infoExtractor._downloader.cache.remove()


# Generated at 2022-06-12 17:19:26.443861
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    if ie.IE_NAME == 'EitbIE':
        return 'OK'
    return 'WRONG'

# Generated at 2022-06-12 17:19:29.027054
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE_instance = EitbIE('http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4090227752001/')



# Generated at 2022-06-12 17:19:30.421992
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test EitbIE
    """
    return EitbIE()

# Generated at 2022-06-12 17:19:37.185490
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    inst = EitbIE()
    assert inst.suitable(url)
    assert inst._real_extract(url) is not None
    assert inst._real_extract(url)['title'] == '60 minutos (Lasa y Zabala, 30 años)'


# Generated at 2022-06-12 17:19:41.270731
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-12 17:19:46.379925
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert "EitbIE" == ie.__class__.__name__

# Generated at 2022-06-12 17:19:47.159560
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:19:47.903916
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor)

# Generated at 2022-06-12 17:19:50.373833
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _EitbIE = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4090227752001/lasa-y-zabala-30-anos/')
    assert _EitbIE.name

# Generated at 2022-06-12 17:22:48.958563
# Unit test for constructor of class EitbIE
def test_EitbIE(): 
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:22:49.500410
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('EitbIE', 'foo')

# Generated at 2022-06-12 17:22:54.629862
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i.IE_NAME == 'eitb.tv'
    assert i.IE_DESC == 'Eitb.tv, Euskal Telebista'
    assert i._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:22:58.541643
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass
#     eitb = EitbIE()
#     eitb._real_extract('http://www.eitb.tv/eu/euskalirratiak/telebista/programa/bilboko-jauregiko-ateak-a-2761/eskolaren-ateak-a-46/')

# Generated at 2022-06-12 17:23:03.578408
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:23:09.332491
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''test constructor of EitbIE
    '''
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-12 17:23:10.835253
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:23:11.422214
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:23:14.263688
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:23:16.056588
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE._VALID_URL
    assert eitbIE._TEST