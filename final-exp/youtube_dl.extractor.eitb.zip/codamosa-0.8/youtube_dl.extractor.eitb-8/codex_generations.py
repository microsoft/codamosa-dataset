

# Generated at 2022-06-12 17:14:28.127279
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-12 17:14:29.547305
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of EitbIE class"""
    return True

# Generated at 2022-06-12 17:14:39.424411
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    module = class_.__module__
    assert class_.__name__ == 'EitbIE'
    assert class_.IE_NAME == 'eitb.tv'
    assert class_._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert class_._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-12 17:14:39.957249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-12 17:14:41.082174
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE == type(EitbIE())


# Generated at 2022-06-12 17:14:42.480886
# Unit test for constructor of class EitbIE
def test_EitbIE():
	class_ = EitbIE
	instance = class_(None)
	assert instance.IE_NAME == class_.IE_NAME

# Generated at 2022-06-12 17:14:45.764557
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("call to test_EitbIE")
    IE_eitb=EitbIE()
    print("get version of EitbIE : "+IE_eitb.version())
    print("\n")

# Generated at 2022-06-12 17:14:47.359997
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()


# Generated at 2022-06-12 17:14:49.739484
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(EitbIE._create_ie_instance(), EitbIE._VALID_URL).IE_NAME == EitbIE.IE_NAME

# Generated at 2022-06-12 17:14:55.465924
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.__class__.__name__ == 'EitbIE'

# Generated at 2022-06-12 17:15:03.437477
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE(3)
    assert isinstance(instance, EitbIE)

# Generated at 2022-06-12 17:15:07.765949
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = InfoExtractor()
    EitbIE(info_extractor)._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:15:10.019020
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Testcase for constructor of class EitbIE
    """
    if __name__ == '__main__':
        eitbie = EitbIE()

# Generated at 2022-06-12 17:15:11.232214
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:15:13.301780
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test the constructor with EitbIE
    # EitbIE()
    assert True


# Generated at 2022-06-12 17:15:18.312511
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert isinstance(eitb, EitbIE)
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:15:19.251799
# Unit test for constructor of class EitbIE
def test_EitbIE():
	e = EitbIE()
	assert e.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:15:19.837836
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:15:24.021643
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = "http://www.eitb.tv/eu/bideoa/planetak/10/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    result = EitbIE()._real_extract(test_url)
    assert result['title'] == "60 minutos (Lasa y Zabala, 30 años)"

# Generated at 2022-06-12 17:15:29.777629
# Unit test for constructor of class EitbIE
def test_EitbIE():
    my_EitbIE = EitbIE()
    assert my_EitbIE.IE_NAME == 'eitb.tv'
    assert my_EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:44.418206
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)

# Generated at 2022-06-12 17:15:47.700714
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiate the EitbIE class
    result = EitbIE()

    # Assert that the EitbIE class was instantiated with the IE_NAME
    assert result.IE_NAME == "EitbIE"

# Generated at 2022-06-12 17:15:49.653749
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')

# Generated at 2022-06-12 17:15:50.527239
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME

# Generated at 2022-06-12 17:15:51.412747
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:15:52.600724
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    assert class_ != ''

# Generated at 2022-06-12 17:15:54.064067
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(EitbIE._downloader).IE_NAME == EitbIE.IE_NAME

# Generated at 2022-06-12 17:16:05.112064
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:11.510631
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL, EitbIE._TEST)
	assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
	assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:16:15.778042
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/juego-de-tronos/4104701456001/4090099580001/juego-de-tronos-segunda-temporada/'
    EitbIE()(url)

# Generated at 2022-06-12 17:16:51.118185
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Tests for 'url', 'md5', 'info_dict', and 'categories' for class EitbIE
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.name == 'eitb.tv'
    assert ie.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-12 17:16:59.228573
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        import youtube_dl
    except:
        print("Error importing youtube_dl")
        assert False

    try:
        from youtube_dl.extractor import common
    except:
        print("Error importing common from youtube_dl.extractor")
        assert False

    from youtube_dl.extractor import EitbIE
    from youtube_dl.Version import _VERSION
    from youtube_dl.utils import YOUTUBE_IE_NAME
    from youtube_dl.utils import std_headers
    from youtube_dl.utils import USER_AGENT_FORMAT
    from youtube_dl.utils import compat_str

    agent = std_headers['User-Agent']
    if YOUTUBE_IE_NAME == 'youtube':
        agent = agent.replace(YOUTUBE_IE_NAME, 'eitb.tv')

# Generated at 2022-06-12 17:17:00.521482
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE()

# Generated at 2022-06-12 17:17:09.919746
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:17:13.088443
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    assert info_extractor.ie_key() == 'eitb'
    assert info_extractor.IE_NAME == 'Eitb'

# Generated at 2022-06-12 17:17:19.991000
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Tests for the class EitbIE"""
    ie = IE_NAME()
    ie.IE_NAME == 'eitb.tv'
    ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    ie.IE_DESC == 'eitb.tv'


# Generated at 2022-06-12 17:17:22.795838
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_tester = EitbIE()
    print("Test EitbIE..")
    assert 'EitbIE' in eitb_tester._VALID_URL


# Generated at 2022-06-12 17:17:23.898700
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-12 17:17:24.602622
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-12 17:17:34.585950
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE

    Note that this test is actually printing the returned value, which should
    be none.
    """

    # Valid URL, wrong url_id.
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    vl = EitbIE._VALID_URL


# Generated at 2022-06-12 17:18:42.633372
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:18:43.233035
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE

# Generated at 2022-06-12 17:18:46.316586
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:18:57.968223
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/ondarea/4104995148001/4090227752001/lasa-y-zabala-30-urte/")
    assert ie.ie_key() == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
   

# Generated at 2022-06-12 17:18:59.503534
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_tools import test_IE
    test_IE('Eitb')

# Generated at 2022-06-12 17:19:09.301207
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of class EitbIE"""
    from youtube_dl.utils import search_regex
    eitb = EitbIE()
    assert eitb
    assert EitbIE.IE_NAME == eitb.ie_key()
    assert EitbIE.ie_key() == eitb.ie_key()
    assert EitbIE.ie_key() in EitbIE.available_ies()
    assert 'geo_restricted' not in eitb.ie_key()
    assert 'geo_restricted' not in EitbIE.available_ies()
    assert eitb.ie_key() in dir(EitbIE)
    assert callable(getattr(eitb, EitbIE.ie_key()))

# Generated at 2022-06-12 17:19:17.689225
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor, requires one parameter, the url to the video
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    # Returns the information of the video
    info = ie.extract()
    # Assert that the video id is equal to the one extracted
    assert info['id'] == "4090227752001"
    # Assert that the video extension is mp4
    assert info['ext'] == "mp4"

# Generated at 2022-06-12 17:19:25.836589
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    vid = e._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert vid['id'] == '4090227752001'
    assert vid['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert 'description' in vid
    assert vid['duration'] == 3996.76
    assert vid['upload_date'] == '20131014'
    assert vid['tags'] == []

# Generated at 2022-06-12 17:19:26.350612
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:19:27.792681
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e=EitbIE()
    assert isinstance(e,EitbIE)


# Generated at 2022-06-12 17:22:20.320634
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-12 17:22:24.791309
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:22:32.156453
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE().IE_NAME == 'eitb.tv'
	assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:22:33.126656
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-12 17:22:42.115226
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:22:43.231281
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL


# Generated at 2022-06-12 17:22:49.153679
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:22:51.729246
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-12 17:22:54.781252
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/EITBkultura/Filma/Zinema/Zinema/548958/', {}, None)

# Generated at 2022-06-12 17:22:55.831200
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None