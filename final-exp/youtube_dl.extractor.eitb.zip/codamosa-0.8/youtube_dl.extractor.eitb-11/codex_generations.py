

# Generated at 2022-06-12 17:14:28.345726
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:14:28.959945
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:14:30.712730
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb == EitbIE

# Generated at 2022-06-12 17:14:35.937994
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.__name__ == "EitbIE"
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:14:39.066225
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    if ie._TEST['url'] != 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/':
        raise Exception('url do not match')

# Generated at 2022-06-12 17:14:42.157796
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:14:43.329936
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    print(test)

# Generated at 2022-06-12 17:14:48.380470
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('foo')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:14:51.275004
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:14:53.291296
# Unit test for constructor of class EitbIE
def test_EitbIE():
    r = EitbIE()
    assert r.name == 'eitb.tv'

# Generated at 2022-06-12 17:15:02.975719
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:04.610955
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE=EitbIE()
    IE.test_formats()

#test_EitbIE()

# Generated at 2022-06-12 17:15:07.358368
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    print(ie)
    if ie.IE_NAME != 'eitb.tv':
        raise Exception('Unit test for constructor of class EitbIE is failed')


# Generated at 2022-06-12 17:15:11.158649
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:20.634410
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:15:24.642792
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE("https://www.eitb.tv/#/eu/bideoa/zuzenean/5-kurripakatik-kurripakera/5030353/")
    assert obj.ie_key() == "Eitb"
    assert obj.ie_name() == "eitb.tv"
    assert obj.valid_url("https://www.eitb.tv/#/eu/bideoa/zuzenean/5-kurripakatik-kurripakera/5030353/")
    assert obj.valid_url("https://www.eitb.tv/#/eu/bideoa/zuzenean/5-kurripakatik-kurripakera/5030353") == False

# Generated at 2022-06-12 17:15:26.899747
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .eitb import EitbIE
    eitbe = EitbIE()
    assert eitbe

# Generated at 2022-06-12 17:15:31.527240
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    

# Generated at 2022-06-12 17:15:33.559372
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    assert ("EitbIE", "EitbIE") == (info_extractor.IE_NAME, info_extractor.ie_key())

# Generated at 2022-06-12 17:15:35.606514
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE._download_json('No matter', 'No matter', 'No matter')
    except:
        pass

# Generated at 2022-06-12 17:15:51.938198
# Unit test for constructor of class EitbIE
def test_EitbIE():
    x = EitbIE()
    assert isinstance(x, EitbIE)

# Generated at 2022-06-12 17:15:55.521194
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:16:06.138310
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('/eu/bideoa/deporte/569557348001/', '0', '')

# Generated at 2022-06-12 17:16:12.164916
# Unit test for constructor of class EitbIE
def test_EitbIE():
    if __name__ == '__main__':
        obj = EitbIE()
        assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
        assert obj.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:16:12.912171
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test
    """
    EitbIE()

# Generated at 2022-06-12 17:16:19.577642
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-12 17:16:22.702801
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/bideoa-on-demand/id/4061954486001/')

# Generated at 2022-06-12 17:16:24.672385
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/aduru-kalera/4104995148001/4091579575001/')


# Generated at 2022-06-12 17:16:27.166900
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.IE_NAME == 'eitb.tv')


# Generated at 2022-06-12 17:16:35.537386
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Init
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()

    # Retrieving information from web
    html = requests.get(url).content
    webpage = etree.HTML(html)

    # Parsing webpage
    #media_id = webpage.xpath('//div[@id="player-object"]/@data-mediaid')[0]
    #playlist_id = webpage.xpath('//div[@id="player-object"]/@data-playlistid')[0]
    #
    ## Download video information
    #video_info_url = ('http://mam

# Generated at 2022-06-12 17:17:07.959538
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:17:09.485146
# Unit test for constructor of class EitbIE
def test_EitbIE():
    result = EitbIE()
    assert result.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:17:16.030386
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:17:21.998086
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:17:23.962175
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE()._VALID_URL == EitbIE._VALID_URL)
    assert(EitbIE().IE_NAME == EitbIE.IE_NAME)

# Generated at 2022-06-12 17:17:28.254737
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:17:32.348545
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:17:37.182806
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()
    url = 'https://www.eitb.tv/eu/bideoa/eitb-klik/1123592082001/hiru-aurrekoa-sail-pasa--129/'
    assert t.suitable(url)
    ie = t.extract(url)
    assert ie.title == 'Hiru aurrekoa Sail pasa, 129'
    assert ie.duration == 2298.0

# Generated at 2022-06-12 17:17:39.268286
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Test case for EitbIE.
    """
    assert True

# Generated at 2022-06-12 17:17:40.120894
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-12 17:18:49.791634
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:18:59.399506
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'https://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitbIE = EitbIE(url)
    assert eitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    print(eitbIE._match_id(url))
    assert eitbIE._match_id(url) == '4090227752001'

# Generated at 2022-06-12 17:19:04.712286
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_name = 'EitbIE'
    instance = eval(class_name + '(None)')

    assert instance.IE_NAME == 'eitb.tv'
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-12 17:19:08.847467
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE(None)
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:19:12.443681
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:19:13.984376
# Unit test for constructor of class EitbIE
def test_EitbIE():
    v = EitbIE()
    assert v.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:19:24.277423
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()

# Generated at 2022-06-12 17:19:26.528179
# Unit test for constructor of class EitbIE
def test_EitbIE():
    new = EitbIE()
    return new


# Generated at 2022-06-12 17:19:28.221137
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL, EitbIE.IE_NAME)

# Generated at 2022-06-12 17:19:29.267615
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #Just to create an instance
    EitbIE('www.eitb.tv')

# Generated at 2022-06-12 17:22:41.642887
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE

# Generated at 2022-06-12 17:22:42.645210
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:22:43.373665
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), InfoExtractor)

# Generated at 2022-06-12 17:22:48.255346
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test if the info_extractor can work wholy.
    from .common import InfoExtractor
    from ..utils import (
        float_or_none,
        int_or_none,
        parse_iso8601,
        sanitized_Request,
    )
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    ie = InfoExtractor()
    ie.add_info_extractor(EitbIE)
    ie.extract(url)

# Generated at 2022-06-12 17:22:53.465007
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/eu/bideoa/euskalmenta/4104995148001/4104995148001/')
    assert EitbIE('http://www.eitb.tv/eu/bideoa/euskalmenta/4104995148001/4104995148001/')._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:22:54.030254
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print(EitbIE('test'))

# Generated at 2022-06-12 17:22:55.472667
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert (eitb_ie.IE_NAME == 'eitb.tv')

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-12 17:22:57.485869
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:23:00.451255
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import sys
    sys.modules['resources.lib.eitb'] = eitb
    from resources.lib import eitb
    from resources.lib.eitb.eitb_IE import EitbIE
    print(EitbIE)

# Generated at 2022-06-12 17:23:02.888650
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'