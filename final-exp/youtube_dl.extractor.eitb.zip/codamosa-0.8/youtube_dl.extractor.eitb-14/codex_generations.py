

# Generated at 2022-06-12 17:14:33.136013
# Unit test for constructor of class EitbIE
def test_EitbIE():
#     # Test 1
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_ie = EitbIE(url)
    assert eitb_ie

# Generated at 2022-06-12 17:14:34.241393
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:14:35.474688
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-12 17:14:36.410290
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE, type)

# Generated at 2022-06-12 17:14:37.522067
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    print(test)


# Generated at 2022-06-12 17:14:38.105917
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:14:41.121306
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # 1st test: use url to constructor
    ie = EitbIE(EitbIE._VALID_URL)
    # 2nd test: use name to constructor
    ie = EitbIE('Eitb')
    pass

# Generated at 2022-06-12 17:14:42.232267
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert('eitb.tv' == EitbIE.IE_NAME)

# Generated at 2022-06-12 17:14:46.991497
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:14:48.035561
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_IE = EitbIE()

# Generated at 2022-06-12 17:15:04.150351
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    return

# Generated at 2022-06-12 17:15:08.248472
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == EitbIE._VALID_URL
    assert ie.IE_NAME == EitbIE.IE_NAME
    assert ie._TEST == EitbIE._TEST
    assert ie._download_json == EitbIE._download_json

# Generated at 2022-06-12 17:15:15.197332
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    It should extract the video_id 
    """
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    res = EitbIE()._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert (res['id'] == '4090227752001')

# Generated at 2022-06-12 17:15:15.896595
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor should pass
    assert EitbIE

# Generated at 2022-06-12 17:15:16.731486
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE)

# Generated at 2022-06-12 17:15:24.959016
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:15:33.169777
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test constructor of class EitbIE
    eitb_ie=EitbIE()

    # test if it's an instance of InfoExtractor
    assert isinstance(eitb_ie, InfoExtractor)

    # test name of the class
    assert eitb_ie.IE_NAME == 'eitb.tv'
    # test value of _VALID_URL
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:15:34.299464
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()



# Generated at 2022-06-12 17:15:34.700242
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass



# Generated at 2022-06-12 17:15:37.647971
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing constructor...")

    try:
        EitbIE()
    except Exception as e:
        print(e.__class__.__name__)
        print(e)

    print("Done!")



# Generated at 2022-06-12 17:15:53.374154
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.ie_key() == 'Eitb'
    assert ie.ie_name() == 'Eitb.tv'
    assert ie.ie_version()


if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-12 17:15:59.925559
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:02.847594
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE().IE_NAME, basestring)
    assert isinstance(EitbIE()._VALID_URL, basestring)

# Generated at 2022-06-12 17:16:05.190768
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb_ie = EitbIE()
	
	assert eitb_ie != None
	
	assert eitb_ie.IE_NAME != None



# Generated at 2022-06-12 17:16:08.696519
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE(None)
    assert(i.IE_NAME == 'EitbIE')
    assert(i.IE_DESC == 'eitb.tv')
    assert(i._VALID_URL == 'eitb.tv')
    assert(i._TEST == 'TEST')



# Generated at 2022-06-12 17:16:11.041517
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from __main__ import EitbIE


# Generated at 2022-06-12 17:16:13.458102
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
        assert False
    except TypeError as e:
        assert 'expected string or buffer' in str(e)

# Generated at 2022-06-12 17:16:16.872692
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test the constructor of EitbIE class
    # the assertEqual function is used to check the EitbIE inherits InfoExtractor class
    assertEqual(EitbIE.__bases__[0], InfoExtractor)



# Generated at 2022-06-12 17:16:18.031757
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE(None)
    assert eitb != None

# Generated at 2022-06-12 17:16:18.566035
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:16:46.484758
# Unit test for constructor of class EitbIE
def test_EitbIE():
     # Check the constructor of EitbIE
     EitbIE()
     return EitbIE


# Generated at 2022-06-12 17:16:48.330977
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), EitbIE)

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-12 17:16:52.542815
# Unit test for constructor of class EitbIE
def test_EitbIE():
   ie = EitbIE()
   assert(ie.IE_NAME == 'eitb.tv')
   assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')    
   assert(ie.__name__ == 'EitbIE')

# Generated at 2022-06-12 17:17:00.414673
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:17:00.898685
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:17:02.469911
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # This should return nothing if the file is instantiated correctly
    assert ie != None

# Generated at 2022-06-12 17:17:03.039168
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:17:04.030811
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-12 17:17:10.545034
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-12 17:17:20.535246
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing constructor of class EitbIE")
    with open("tests/test_data/eitb.txt", "r") as f:
        content = f.read()
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/", content)
    if (ie.ie_keywords() == "EitbIE"):
        print("Constructor of class EitbIE is working")
    else:
        print("Something is wrong with the constructor of class EitbIE")


# Generated at 2022-06-12 17:18:27.458492
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("EitbIE", "eitb.tv", False, False)

# Generated at 2022-06-12 17:18:32.891247
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:18:38.488481
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:18:39.679940
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-12 17:18:43.066777
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_tveitb_tv import EITBTVTestCase
    import unittest
    unittest.TextTestRunner().run(unittest.TestLoader().loadTestsFromTestCase(EITBTVTestCase))

# Generated at 2022-06-12 17:18:49.939477
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import requests
    import sys
    reload(sys)
    sys.setdefaultencoding('utf8')

    video_id = '4104995148001'
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/'

    # Downloading video JSON
    resp = requests.get('http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % video_id)
    assert resp.status_code == 200
    video = resp.json()

    # Obtain the media information
    media = video['web_media'][0]

    # Downloading auth token

# Generated at 2022-06-12 17:18:51.425791
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:18:57.107015
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Create an instance of EitbIE
	EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', True)


# Generated at 2022-06-12 17:18:57.621088
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-12 17:18:59.439772
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:21:54.700125
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test url of this class
    assert EitbIE.suitable('http://www.eitb.tv/eu/bideoa/media/notizia/20130826/zentzu-sozialak-sailkapen-kontsulta-soziodemokrata-1426249/')
    assert EitbIE.suitable('https://www.eitb.tv/eu/bideoa/media/notizia/20130826/zentzu-sozialak-sailkapen-kontsulta-soziodemokrata-1426249/')

# Generated at 2022-06-12 17:21:56.750375
# Unit test for constructor of class EitbIE
def test_EitbIE():
    match_id = EitbIE._match_id
    eitb_ie = EitbIE(InfoExtractor)
    assert match_id(eitb_ie, 'http://www.eitb.tv/eu/bideoa/eitb-laburrak/5115447864001/')

# Generated at 2022-06-12 17:21:58.122854
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-12 17:22:06.524353
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:22:09.481181
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/zuzenean/5464516/")
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:22:12.253948
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE_instance = EitbIE()
    assert EitbIE_instance != None


# Generated at 2022-06-12 17:22:15.818419
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test = EitbIE()
	#Test the basic attributes
	assert test.name == "eitb.tv"
	assert test.description == None
	assert test.filename == 'eitb.tv'


# Generated at 2022-06-12 17:22:16.742284
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-12 17:22:24.712569
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE('http://mam.eitb.eus/mam/REST/ServiceMultiweb/ContentItem/MULTIWEBTV/11385/' +
                    'es/PT-20/1/0/0/I/http%3A%2F%2Fwww.eitb.tv%2Fes%2Fvideo%2Fkoldobika-la-odisea-de-los-gitanos' +
                    '%2F4104995148001%2F4104995148011%2F')
    assert eitbie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:22:28.022596
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE(None)
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'