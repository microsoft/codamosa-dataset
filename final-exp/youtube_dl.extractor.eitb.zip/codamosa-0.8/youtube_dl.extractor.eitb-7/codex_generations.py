

# Generated at 2022-06-12 17:14:30.272275
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:14:34.815036
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor('eitb.tv'))._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:14:41.439289
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create the class EitbIE
    instance = EitbIE("test")
    assert instance.IE_NAME == 'eitb.tv'
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert instance._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert instance._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-12 17:14:46.428049
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Create EitbIE
	class_name = 'EitbIE'
	module_name =  '.'.join(['extractors']+class_name.split('_')[1:])
	eval_str = module_name + '.' + class_name + '()'
	inst = eval(eval_str)

	# Create InfoExtractor
	class_name = 'InfoExtractor'
	module_name =  '.'.join(['extractors']+class_name.split('_')[1:])
	eval_str = module_name + '.' + class_name + '()'
	inst.parent = eval(eval_str)
	return inst


# Generated at 2022-06-12 17:14:54.697898
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Dummy URL
    url = 'http://www.eitb.tv/eu/bideoa/eitb-dokumentalak/18-trio-kolore/4104995148001/4104995148001/'
    # Create instance of EitbIE
    p = EitbIE(url)
    # Run IE
    result = p.run()
    # Check if instance of InfoExtractor
    assert isinstance(p, InfoExtractor)
    # Check if video has been downloaded
    assert result['id'] == '4104995148001'
    assert result['title'] == 'Trio Kolore'
    assert result['tags'] == ['EITB DOKUMENTALAK', 'ERREKONTSALDAK']
    assert result['duration'] == 3102.66

# Generated at 2022-06-12 17:14:56.551786
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE({}), InfoExtractor)

# Generated at 2022-06-12 17:14:58.479980
# Unit test for constructor of class EitbIE
def test_EitbIE():
    valid_url = EitbIE._VALID_URL
    assert valid_url


# Generated at 2022-06-12 17:15:02.054781
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:15:05.512187
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    info_extractor = EitbIE()
    info_extractor._match_id(url)

# Generated at 2022-06-12 17:15:09.038161
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# This testcase checks that the constructor of the class EitbIE
	# is able to create the instance.
	instance = EitbIE()
	# Check that the expected parameter has been initialized
	assert instance.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:15:29.594825
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('http://www.eitb.tv/eu/bideoa/hitza/59/267213/')
    assert eitbIE._match_id('fragment') == 'fragment'
    assert eitbIE._match_id(
        'http://www.eitb.tv/eu/bideoa/hitza/59/267213/') == '267213'

# Generated at 2022-06-12 17:15:33.453137
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:15:34.759541
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie!=None

# Generated at 2022-06-12 17:15:36.384298
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'Eitb'

# Generated at 2022-06-12 17:15:43.360944
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()
	assert eitb.IE_NAME == 'eitb.tv'
	assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:45.098397
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:15:54.805002
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()
    assert t.IE_NAME == 'eitb.tv'
    assert t._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:58.877300
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:16:02.523120
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(False)
    assert ie.ie_key() == 'Eitb'
    assert ie.ie_name() == 'eitb.tv'
    assert ie.ie_version() == '0.0.1'

# Generated at 2022-06-12 17:16:03.449607
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, None)

# Generated at 2022-06-12 17:16:37.903082
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:16:39.801629
# Unit test for constructor of class EitbIE
def test_EitbIE():
    x = EitbIE()
    assert len(x._TEST) == 4
    assert 'url' in x._TEST

# Generated at 2022-06-12 17:16:41.663080
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    assert info_extractor.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:16:45.524513
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:16:46.070199
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:16:47.606104
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:16:49.369252
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE == InfoExtractor.create_ie(EitbIE.IE_CODE, EitbIE.IE_NAME)

# Generated at 2022-06-12 17:16:50.822767
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import ie_test
    ie_test.EitbIETest()


# Generated at 2022-06-12 17:16:58.947991
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie_test = EitbIE()
    eitb_ie_test.IE_NAME

    #eitb_ie_test.extract_video()
    video_id = '4104995148001'
    video_url = 'https://www.eitb.tv/eu/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_ie_test._real_extract(video_url)

    # Check Video ID

# Generated at 2022-06-12 17:17:01.624920
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('eitb.tv')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-12 17:18:00.686505
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:18:02.661991
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # First, check that the EitbIE object can be created
    assert EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL)
	

# Generated at 2022-06-12 17:18:05.620661
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:18:07.402964
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('Eitb.tv')
    assert ie.IE_NAME == 'Eitb.tv'


# Generated at 2022-06-12 17:18:11.443971
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE();
    assert(e.IE_NAME == 'eitb.tv');
    assert(e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)');

# Generated at 2022-06-12 17:18:14.658964
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:18:15.306415
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:18:26.937282
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Fetch the title, id and description of the video
    assert EitbIE()._real_extract("http://www.eitb.tv/eu/bideoa/mikel-sarriegi-bideoa-mikel-sarriegi/4109169131001/")['title'] == 'Mikel Sarriegi bideoa'
    assert EitbIE()._real_extract("http://www.eitb.tv/eu/bideoa/mikel-sarriegi-bideoa-mikel-sarriegi/4109169131001/")['id'] == '4109169131001'

# Generated at 2022-06-12 17:18:32.451527
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert IE.IE_NAME == "EitbIE"
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:18:39.321095
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-12 17:21:36.002000
# Unit test for constructor of class EitbIE
def test_EitbIE():
    TestEitb = EitbIE()
    assert TestEitb.IE_NAME == 'eitb.tv'
    assert TestEitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:21:39.271476
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    assert a.IE_NAME == 'eitb.tv'
    assert a._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:21:41.394648
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:21:45.427049
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()


# Generated at 2022-06-12 17:21:50.490974
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE("eitb.tv")
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert IE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:21:52.744601
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL.endswith('eitb\.tv/es/video/[^/]+/\\d+/\\d+')

# Generated at 2022-06-12 17:21:55.470023
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:22:04.020245
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/herri-pasilloaren-bilketa-azpikoak/3858915335001/3858915335001/'
    pattern = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    matches = EitbIE._VALID_URL_RE.match(url)
    assert matches.group('id') == '3858915335001', "id not equal"
    

# Generated at 2022-06-12 17:22:08.040737
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info = EitbIE()._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    print (info)
    assert info['url'] == 'http://mam.eitb.eus/mam/resources/media/4105020755001/20180207161145/mp4/original.mp4'

# Generated at 2022-06-12 17:22:14.003237
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
