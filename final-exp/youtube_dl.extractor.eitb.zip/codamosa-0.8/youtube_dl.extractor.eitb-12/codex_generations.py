

# Generated at 2022-06-12 17:14:30.370743
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing EitbIE constructor")
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    EitbIE(url)

# Generated at 2022-06-12 17:14:39.755017
# Unit test for constructor of class EitbIE
def test_EitbIE():
	import json
	assert EitbIE._TEST == json.loads('''{"url": "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/", "md5": "edf4436247185adee3ea18ce64c47998", "info_dict": {"id": "4090227752001", "ext": "mp4", "title": "60 minutos (Lasa y Zabala, 30 a\u00f1os)", "description": "Programa de reportajes de actualidad.", "duration": 3996.76, "timestamp": 1381789200, "upload_date": "20131014", "tags": []}}''')

# Generated at 2022-06-12 17:14:42.960448
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #test extractor with valid url
    url_test = 'http://www.eitb.tv/eu/bideoa/programak/eitb/zuzenean/2014-2015/20141221/'
    eitb_test = EitbIE(url_test)
    assert eitb_test

# Generated at 2022-06-12 17:14:47.554599
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
        Checks that the media type is video in the "allowed_ie" variable
    '''

    instance = EitbIE()

    if instance.ie_key() not in InfoExtractor._ALLOWED_IE_KEY_SETS:
        raise AssertionError('Eitb IE is not present in the allowed_ie set')

# Generated at 2022-06-12 17:14:49.452018
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/eu/bideoa/eu_bideoa/1245093/17/15/Kontaketa-kroniketan---28---Lesaka-eta-Urnieta/')

# Generated at 2022-06-12 17:14:54.929308
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:14:59.870870
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:15:06.047475
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie.id == '4090227752001'


# Generated at 2022-06-12 17:15:07.855545
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-12 17:15:09.122632
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:15:28.244605
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:15:35.826124
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test
    """
    # In this example, the constructor of the class InfoExtractor sets the attribute _downloader
    # as an instance of YoutubeDL with the parameters passed to the constructor of the class EitbIE
    eitb_ie = EitbIE({'outtmpl': '%(id)s%(ext)s'}, {'simulate': True, 'quiet': True})
    eitb_ie.report_warning = lambda *args, **kwargs: None
    eitb_ie.to_screen = lambda *args, **kwargs: None

    # Check if some attributes were correctly initialized in the constructor
    assert eitb_ie._downloader.params['quiet'] is True

# Generated at 2022-06-12 17:15:39.284318
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert(eitb_ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-12 17:15:44.997998
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    ie._downloader = MockDownloader()
    ie._downloader.headers = {'Referer': url}

# Generated at 2022-06-12 17:15:49.572271
# Unit test for constructor of class EitbIE
def test_EitbIE():
  ie = EitbIE(EitbIE._downloader, EitbIE._VALID_URL)
  info_dict = ie._real_extract(EitbIE._TEST['url'])

# Generated at 2022-06-12 17:15:53.424512
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:55.384990
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.ie_key() == 'eitb'
    assert EitbIE.ie_key_re() == 'eitb'

# Generated at 2022-06-12 17:15:59.490538
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE(None)
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:03.795469
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'Eitb'
    assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:10.703546
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:28.444747
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE(test_url, {}, {}) == True


# Generated at 2022-06-12 17:16:31.730375
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    ie = class_(class_._create_ie_instance())
    info = ie._real_extract(class_._VALID_URL)
    assert info['title'] == class_._TEST['info_dict']['title']


# Generated at 2022-06-12 17:16:34.697205
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:16:39.504086
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    IE._real_extract('http://www.eitb.tv/eu/bideoa/bideoa/zuzendaria/ezker-sektorea/20130604/')
    IE._real_extract('http://www.eitb.tv/eu/bideoa/bideoa/zuzendaria/ezker-sektorea/20130604/')

# Generated at 2022-06-12 17:16:43.675940
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitbie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:16:48.838653
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

test = test_EitbIE()

# Generated at 2022-06-12 17:16:53.116378
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Unit tests for _real_extract and constructor of class EitbIE

# Generated at 2022-06-12 17:16:53.673038
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-12 17:16:55.845431
# Unit test for constructor of class EitbIE
def test_EitbIE():
    maybe_relative_url = r'http://www.eitb.tv/eu/bideoa/eitbnews/detail/4208959/4290368/'
    assert EitbIE._VALID_URL.match(maybe_relative_url), 'PyLint does not understand urlparse...'

# Generated at 2022-06-12 17:17:00.866876
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_IE = EitbIE()
    assert eitb_IE.IE_NAME == 'eitb.tv'
    eitb_IE = EitbIE(url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb_IE.__name__ == 'EitbIE'


# Generated at 2022-06-12 17:17:32.163333
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Just ensure that the class can be constructed
    EitbIE()
    return True

# Generated at 2022-06-12 17:17:35.149807
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    assert a, 'Failed to created object from EitbIE'

# Generated at 2022-06-12 17:17:36.319715
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    return eitb

# Generated at 2022-06-12 17:17:39.633806
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE(None, None)
    except Exception as e:
        print("FAILED: " + str(e))
        assert False
    print("SUCCESS: class EitbIE initialization")

# Generated at 2022-06-12 17:17:48.619882
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = dict()
    test['url'] = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test['md5'] = 'edf4436247185adee3ea18ce64c47998'
    test['info_dict'] = dict()
    test['info_dict']['id'] = '4090227752001'
    test['info_dict']['ext'] = 'mp4'
    test['info_dict']['title'] = '60 minutos (Lasa y Zabala, 30 años)'
    test['info_dict']['description'] = 'Programa de reportajes de actualidad.'

# Generated at 2022-06-12 17:17:58.510428
# Unit test for constructor of class EitbIE
def test_EitbIE():
    expected_class = 'EitbIE'
    instance = EitbIE()
    instance.set_downloader(None)
    assert isinstance(instance, InfoExtractor)
    assert hasattr(instance, 'IE_NAME')
    assert hasattr(instance, '_VALID_URL')
    assert hasattr(instance, '_download_webpage')
    assert hasattr(instance, '_download_json')
    assert hasattr(instance, '_real_extract')
    assert hasattr(instance, '_extract_m3u8_formats')
    assert hasattr(instance, '_extract_f4m_formats')
    assert hasattr(instance, '_sort_formats')
    assert hasattr(instance, '_match_id')
    assert hasattr(instance, '_TEST')


# Generated at 2022-06-12 17:17:59.858511
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert(EitbIE)
        assert(True)
    except:
        assert(False)

# Generated at 2022-06-12 17:18:00.772949
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:18:01.293332
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:18:04.835974
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:19:25.128058
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(e!= None)
    assert(e.IE_NAME == 'EitbIE')
    assert(e.valid_url('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'))

# Generated at 2022-06-12 17:19:28.168384
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:19:32.296080
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # call constructor
    print("Testing EitbIE")
    test_url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    try:
        # testing the methods which are not tested in the CommonIEs
        ie._real_extract(test_url)
    except Exception as e:
        assert False, 'Extraction failed with error: ' + str(e)
    finally:
        print("Extraction successful")

# Generated at 2022-06-12 17:19:36.429081
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:19:47.308433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie_test = EitbIE()
    for url in ['http://www.eitb.tv/eu/bideoa/somos-espanoles/4149790174001/4119227919001/cortos_en_espanol/',
                'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/']:
        t = eitb_ie_test.suitable(url)
        assert t, 'URL %s is not suitable' % url


# Generated at 2022-06-12 17:19:55.093827
# Unit test for constructor of class EitbIE
def test_EitbIE():
    params = {
        'id': '4090227752001',
        'title': '60 minutos (Lasa y Zabala, 30 años)',
        'description': 'Programa de reportajes de actualidad.',
        'duration': 3996.76,
        'timestamp': 1381789200,
        'upload_date': '20131014'
    }
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb = EitbIE()
    info = eitb.extract(url)

    assert info['id'] == params['id']

# Generated at 2022-06-12 17:20:02.273276
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_obj = EitbIE('eitb.tv')
    # test that the re is set correctly
    assert test_obj._VALID_URL
    # the regexp should match a valid URL
    # not sure what the regexp should be, but it has to match something
    assert re.match(test_obj._VALID_URL, 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    # the regexp should not match an invalid URL

# Generated at 2022-06-12 17:20:05.153443
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Print the list of videos in the page
	videos = EitbIE()._real_extract("http://www.eitb.tv/eu/bideoak/")
	print("Videos in the page:")
	for video in videos:
		print("\t" + video["url"])
	print("End of video list")

# Generated at 2022-06-12 17:20:12.806839
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Construct an object of the class EitbIE.
    # It should have these attributes.
    eitbIE = EitbIE();
    assert eitbIE.ie_key() == EitbIE.IE_NAME
    assert eitbIE.ie_key() == 'eitb.tv'
    assert eitbIE.ie_name() == EitbIE.IE_NAME
    assert eitbIE.ie_name() == 'eitb.tv'
    assert eitbIE.ie_id() == EitbIE.IE_NAME
    assert eitbIE.ie_id() == 'eitb.tv'

# Generated at 2022-06-12 17:20:14.367229
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert "EitbIE" in instance.IE_NAME

# Generated at 2022-06-12 17:23:09.332641
# Unit test for constructor of class EitbIE
def test_EitbIE():
    Eitb_test = EitbIE()

# Generated at 2022-06-12 17:23:14.183751
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_IE = EitbIE()

    # Check that EitbIE inherits from InfoExtractor
    assert(issubclass(EitbIE, InfoExtractor))

    # Check that EitbIE initializes correctly with arguments
    assert(hasattr(EitbIE, "IE_NAME"))
    assert(hasattr(EitbIE, "_VALID_URL"))
    assert(hasattr(EitbIE, "_TEST"))

# Generated at 2022-06-12 17:23:20.639837
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # '_VALID_URL' attribute must be defined in each class
    assert '_VALID_URL' in dir(EitbIE)

    # 'IE_NAME' attribute must be defined in each class
    assert 'IE_NAME' in dir(EitbIE)

    # Call constructor of class EitbIE
    ie_object = EitbIE(EitbIE._VALID_URL)

    # '_real_extract' attribute must be defined in each class
    assert '_real_extract' in dir(EitbIE)

    # Call method
    ie_object._real_extract(EitbIE._TEST['url'])

    # Call method again
    ie_object._real_extract(EitbIE._TEST['url'])

# Generated at 2022-06-12 17:23:30.330289
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert instance.IE_NAME == 'eitb.tv'
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert instance.domain == 'www.eitb.tv'

# Generated at 2022-06-12 17:23:32.432858
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test:
    # EitbIE('http://www.eitb.tv/es/video/', [])
    return 0

# Generated at 2022-06-12 17:23:37.583621
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# It should raise an exception when no URL is passed
	try:
		e = EitbIE()
		success = False
	except:
		success = True
	assert success

# Generated at 2022-06-12 17:23:38.916896
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(_TEST).IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:23:39.934010
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-12 17:23:42.482786
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(EitbIE.ie_key())


# Generated at 2022-06-12 17:23:52.665839
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _test_url = "http://www.eitb.tv/eu/bideoa/eguzkiloreak/49643683/kepa-blanco-tolosa-susperaren-eskutik-/Euskal_Reporterra/"
    _test_url = "http://www.eitb.tv/es/video/vanity-fair/49756225/"
    _test_url = "http://www.eitb.tv/es/video/vanity-fair/49756225/"
    _test_url = "http://www.eitb.tv/eu/bideoa/dokumentala/49756038/ahola-txikitxo/Bidasoa/"