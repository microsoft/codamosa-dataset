

# Generated at 2022-06-12 17:14:29.689153
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.ie_key() == 'eitb.tv'
    assert eitb.IE_DESC == 'Euskal Irrati Telebista'

# Generated at 2022-06-12 17:14:34.603211
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:14:39.278023
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
        Create the class, which uses the raw constructor
    """
    ie_list = [IE for IE in InfoExtractor._ies if IE.IE_NAME == 'eitb.tv']
    if len(ie_list) > 0:
        if ie_list[0]()._VALID_URL == 'http://www.eitb.tv/es/videos/detalle/':
            return True
    raise Exception('The class must be called EitbIE insted of %s' % ie_list[0].__name__)


# Generated at 2022-06-12 17:14:40.155251
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()

# Generated at 2022-06-12 17:14:40.595966
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:14:50.287434
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:14:55.922151
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL.match('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is not None

# Generated at 2022-06-12 17:14:58.136412
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('test')
    print("test for construct of class EitbIE successfully")

# Generated at 2022-06-12 17:14:59.743571
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.__class__.__name__ == 'EitbIE'

# Generated at 2022-06-12 17:15:07.369512
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE({})
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:17.393766
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.extractor.IE_NAME == EitbIE.IE_NAME
    assert eitb.extractor._VALID_URL == EitbIE._VALID_URL
    assert eitb.extractor._TEST == EitbIE._TEST

# Generated at 2022-06-12 17:15:21.165142
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie != None

# Generated at 2022-06-12 17:15:27.280512
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    This unit test is unit test for constructor of class EitbIE
    """
    inst = EitbIE()
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    result = inst.suitable(url)
    assert result is True
    assert inst.IE_NAME is "eitb.tv"
    assert inst._VALID_URL is r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:15:27.798364
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-12 17:15:28.692791
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # try to construct the class
    ie = EitbIE

    # try to construct an instance
    ie = EitbIE()


# Generated at 2022-06-12 17:15:30.468955
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE("url")
    assert e.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:15:34.173625
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Just test if the constructor is able to instantiate an EitbIE object
    eitb = EitbIE('www.eitb.tv')
    assert isinstance(eitb, EitbIE)

# Generated at 2022-06-12 17:15:38.109712
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:41.787185
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_NAME = 'eitb.tv'
    _VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    ie = EitbIE(IE_NAME, _VALID_URL)
    return ie

# Generated at 2022-06-12 17:15:42.666205
# Unit test for constructor of class EitbIE
def test_EitbIE():
    x = EitbIE()
    return x

# Generated at 2022-06-12 17:16:07.853503
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE"""
    assert EitbIE.__name__ == 'EitbIE'
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-12 17:16:09.071119
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE, InfoExtractor)

# Generated at 2022-06-12 17:16:15.245269
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb is not None
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    

# Generated at 2022-06-12 17:16:22.395579
# Unit test for constructor of class EitbIE
def test_EitbIE():
    o = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(o.IE_NAME == 'eitb.tv')
    assert(o._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-12 17:16:23.000702
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:16:25.143388
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test for class EitbIE

    """
    constructor_test_utility(EitbIE, 'Eitb')


# Generated at 2022-06-12 17:16:27.194026
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/elurra/4104995148001/4090227752001/lasa-y-zabala-30-urte/'
    ie = EitbIE(url)
    url_md5 = ie._download_json()

# Generated at 2022-06-12 17:16:32.048185
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test extracting information from URL

    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"

    # Create new instance of the class
    ie = EitbIE()

    # Extract information
    ie.extract(url)

# Generated at 2022-06-12 17:16:32.867757
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()

# Generated at 2022-06-12 17:16:35.629410
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    i._download_json('http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/', '4104995148001', 'Downloading video JSON')

# Generated at 2022-06-12 17:16:52.426891
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:16:55.967584
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:16:58.328236
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        obj = EitbIE()
    except Exception as e:
        raise AssertionError("Unable to check EitbIE class. Error: {}".format(str(e)))
    return True

# Generated at 2022-06-12 17:17:04.098435
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE = EitbIE()
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert Eit

# Generated at 2022-06-12 17:17:08.413447
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL.startswith('https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/\d+')

# Generated at 2022-06-12 17:17:14.546185
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:17:16.028652
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("")

# Generated at 2022-06-12 17:17:18.161449
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.NAME == 'eitb.tv'

# test the actual EitbIE download method

# Generated at 2022-06-12 17:17:19.192607
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-12 17:17:20.450673
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie is not None)

# Generated at 2022-06-12 17:17:54.316802
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:17:56.466195
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()
	assert eitb != None
	assert eitb._VALID_URL != None

# Generated at 2022-06-12 17:18:01.921717
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie_name = ie._get_IE_name()
    test = ie._get_TEST()

    assert ie_name == 'eitb.tv'
    assert test['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert test['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-12 17:18:03.724374
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == "eitb.tv"



# Generated at 2022-06-12 17:18:05.969489
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/zuzenean/eitb-kontzertuak-berri/4123015530001/')

# Generated at 2022-06-12 17:18:07.805149
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-12 17:18:15.449731
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE('www.eitb.tv','http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',{})
    assert IE._VALID_URL ==  r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert IE.ie_key() == 'Eitb'
    assert IE.ie_name() == 'eitb.tv'

# Generated at 2022-06-12 17:18:19.364248
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'Eitb'
    assert eitb._VALID_URL == r'http://(?:www\.)?eitb\.tv/es/video'

# Generated at 2022-06-12 17:18:28.726088
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'


# Generated at 2022-06-12 17:18:30.709263
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
        assert True
    except:
        assert False


# Generated at 2022-06-12 17:19:56.978418
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert hasattr(EitbIE, 'IE_NAME') == True
    assert hasattr(EitbIE, '_VALID_URL') == True


# Generated at 2022-06-12 17:20:03.884245
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test URL
    url = u'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    # Expected values
    expected_id = u'4090227752001'
    expected_ext = u'mp4'
    expected_title = u'60 minutos (Lasa y Zabala, 30 a\xf1os)'
    expected_description = u'Programa de reportajes de actualidad.'
    expected_duration = float(3996.76)
    expected_timestamp = float(1381789200.0)
    expected_upload_date = u'20131014'
    # Test
    eitb_video = E

# Generated at 2022-06-12 17:20:07.048223
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/la-llamada-del-mar/4104994835001/4104994835001/', 'eitb.tv')



# Generated at 2022-06-12 17:20:08.154221
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert isinstance(inst, EitbIE)

# Generated at 2022-06-12 17:20:10.529983
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('Unit test for constructor of class EitbIE')
    print('Executing test_EitbIE')
    assert True

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-12 17:20:13.353135
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:20:19.471723
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.IE_DESC == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:20:19.988931
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:20:20.837341
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-12 17:20:22.269294
# Unit test for constructor of class EitbIE
def test_EitbIE():
        eitb = EitbIE()
        assert eitb.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:23:40.488637
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    if eitb.IE_NAME != 'eitb.tv':
        raise Exception('IE_NAME is "eitb.tv", it should be {0}'.format('eitb.tv'))
    if eitb._VALID_URL != r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)':
        raise Exception('_VALID_URL is "{0}", it should be {1}'.format(eitb._VALID_URL, r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'))


# Generated at 2022-06-12 17:23:43.580051
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    # TODO: test other properties

# Generated at 2022-06-12 17:23:45.331836
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:23:45.800205
# Unit test for constructor of class EitbIE
def test_EitbIE():
    I = EitbIE('www')

# Generated at 2022-06-12 17:23:51.802602
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _ = EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    _ = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")


# Generated at 2022-06-12 17:23:55.654839
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:23:58.226396
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:24:01.409202
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/telebista/zuzenean/98363/'
    ie = EitbIE(url)
    assert ie._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-12 17:24:03.872938
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL
    assert EitbIE._TEST



# Generated at 2022-06-12 17:24:04.335488
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()