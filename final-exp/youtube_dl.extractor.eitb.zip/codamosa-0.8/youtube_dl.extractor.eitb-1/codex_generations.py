

# Generated at 2022-06-12 17:14:28.744710
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-12 17:14:29.354929
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE

# Generated at 2022-06-12 17:14:39.135060
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:14:43.056900
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:14:44.019863
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-12 17:14:53.072563
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:14:54.494275
# Unit test for constructor of class EitbIE
def test_EitbIE():
    res = EitbIE()
    assert isinstance(res, EitbIE)

# Generated at 2022-06-12 17:14:58.837156
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:03.316862
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    assert_equals(a.IE_NAME, 'eitb.tv')
    assert_equals(a._VALID_URL, r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-12 17:15:10.946463
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Arguments to initialize an instance of EitbIE
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test_out = 'edf4436247185adee3ea18ce64c47998'
    EitbIE_test = EitbIE(url)
    # Test for correct MD5 value for the test URL
    assert EitbIE_test._downloader.urlopen(url).read().encode('utf-8').md5() == test_out

# Generated at 2022-06-12 17:15:19.129302
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb is not None

# Generated at 2022-06-12 17:15:23.460848
# Unit test for constructor of class EitbIE
def test_EitbIE():
    new_url = 'http://www.eitb.tv/eu/bideoa/ezkerralde-kontsulta/4090227203001/'
    new_id = '4090227203001'
    new_id = '4090227203001'
    url = EitbIE()._real_extract(new_url)
    assert url.get('id') == new_id

# Generated at 2022-06-12 17:15:25.260958
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst.IE_NAME == "EitbIE"

# Generated at 2022-06-12 17:15:34.641561
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test that EitbIE does not crash"""
    class MockDownloader():
        def to_screen(self, msg):
            pass
    class MockOptions():
        pass
    class MockIE():
        def __init__(self, *args, **kwargs):
            pass
        def to_screen(self, msg):
            pass
    class MockIE_test():
        def __init__(self, *args, **kwargs):
            pass
        def _real_extract(self, *args, **kwargs):
            pass
    ie_obj=EitbIE(MockDownloader(), MockOptions(), MockIE(), MockIE_test())

# Test code is run with command:
# ./bin/youtube-dl --dump-intermediate-pages --debug --proxy=127.0.0.1:8118 http://www

# Generated at 2022-06-12 17:15:38.546575
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:39.660821
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:15:40.603889
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME

# Generated at 2022-06-12 17:15:42.819419
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'

#test_EitbIE()

# Generated at 2022-06-12 17:15:52.950439
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.VERSION == '0.0.1'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:55.560904
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:19.494338
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:22.656353
# Unit test for constructor of class EitbIE
def test_EitbIE():
    global EitbIE
    EitbIE = __import__('EitbIE')
    assert EitbIE
    print ("Unit test passed: %s" % EitbIE)

# Generated at 2022-06-12 17:16:31.162363
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == "eitb.tv" # Test name
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)' # Test URL regex

# Generated at 2022-06-12 17:16:32.322724
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == "Eitb"

# Generated at 2022-06-12 17:16:33.136584
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eie = EitbIE()

# Generated at 2022-06-12 17:16:41.742101
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # First, create an instance of the class to be tested
    ieInstance = EitbIE()
    # As EitbIE is based on a generic class, one has to override its properties
    ieInstance.IE_NAME = 'eitb.tv'
    ieInstance._VALID_URL = 'http://www.eitb.tv/eu/bideoa/[^/]+/(?P<id>\d+)/'

    # Now, pretend that the URL used to create the instance was 'http://www.eitb.tv/eu/bideoa/gaur-eguerda-bideoa/2193032/'
    ieInstance._match_id = '2193032'
    # Try to do an action that can be derived from the _VALID_URL regexp

# Generated at 2022-06-12 17:16:43.590416
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Test the constructor of the EitbIE class
    """
    assert isinstance(EitbIE, InfoExtractor)

# Generated at 2022-06-12 17:16:45.817569
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # init class EitbIE
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:16:46.363752
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:16:54.549007
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test that EitbIE constructor works
    """
    instance = EitbIE()

    # Test for _VALID_URL regexp
    assert isinstance(instance._VALID_URL, type(''))
    assert instance._VALID_URL != ''
    assert re.match(instance._VALID_URL,
        'http://www.eitb.tv/eu/bideoa/zientzia-elikagaiak/4104995148001/4090231397001/')
    assert re.match(instance._VALID_URL,
        'http://www.eitb.tv/eu/bideoa/zientzia-elikagaiak/4104995148001/4090231397001/index.html')

# Generated at 2022-06-12 17:17:26.171167
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.extract()

# Generated at 2022-06-12 17:17:28.802565
# Unit test for constructor of class EitbIE
def test_EitbIE():
    b = EitbIE(
        downloader=None,
        download_retries=1,
        download_sleep=0.01
    )
    assert b is not None

# Generated at 2022-06-12 17:17:35.611762
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test cases need to be created. For a start one could use a test case available at:
    # https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/tv2.py (and others)
    # Test cases must follow the same rules as in other extractors.
    assert True

# Generated at 2022-06-12 17:17:41.341781
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''Test EitbIE constructor'''
    class EitbIE_Test(EitbIE):
        pass
    # Test for valid url input
    EitbIE_Test('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    # Test for invalid url input
    EitbIE_Test('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/' + 'x')

# Generated at 2022-06-12 17:17:43.257253
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)


# Generated at 2022-06-12 17:17:46.484156
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == (
        r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    )

# Generated at 2022-06-12 17:17:53.322943
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_eitb = EitbIE()
    assert(ie_eitb.IE_NAME == "eitb.tv")
    assert(ie_eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-12 17:17:55.427245
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE(InfoExtractor())
    eitbie.IE_NAME = 'eitb.tv'

# Generated at 2022-06-12 17:18:01.886381
# Unit test for constructor of class EitbIE
def test_EitbIE():
	input = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
	expected = "EitbIE(_VALID_URL=re.compile('https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)'))"
	actual = str(EitbIE.__init__(EitbIE(), input))
	assertEqual(expected, actual)


# Generated at 2022-06-12 17:18:04.871179
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-12 17:19:24.722381
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert hasattr(eitb, '_real_extract')
    assert hasattr(eitb, '_extract_m3u8_formats')
    assert hasattr(eitb, '_extract_f4m_formats')
    assert hasattr(eitb, '_sort_formats')

# Generated at 2022-06-12 17:19:25.736925
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.ie_key() == 'eitb.tv'

# Generated at 2022-06-12 17:19:29.291617
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Unit test for constructor of class EitbIE")
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    result = EitbIE()._real_extract(url)
    assert result['id'] == '4090227752001'

# Generated at 2022-06-12 17:19:33.989988
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:19:37.351860
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:19:37.962338
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-12 17:19:47.309747
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test without arguments
    try:
        EitbIE()
    except TypeError:
        pass
    else:
        raise Exception('Expected TypeError exception')

    # Test with empty arguments
    try:
        EitbIE('')
    except TypeError:
        pass
    else:
        raise Exception('Expected TypeError exception')

    # Test with valid arguments
    assert 'eitb' in EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/').IE_NAME

# Generated at 2022-06-12 17:19:54.795168
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert ie._TEST['info_dict']['id'] == '4090227752001'

# Generated at 2022-06-12 17:19:57.930268
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import internetarchive
    video = internetarchive.get_item("eitb-tv")
    urls = video.item_metadata['files'][0]['urls']
    for url in urls:
        test = EitbIE(url)
        assert test.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:19:58.957957
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == "Eitb.tv"

# Generated at 2022-06-12 17:22:59.878233
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:23:03.778904
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test whether EitbIE can be created with proper parameters
    ie = EitbIE()
    assert isinstance(ie, EitbIE)
    assert ie.IE_NAME == "eitb.tv"


# Generated at 2022-06-12 17:23:08.554546
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/2-kalean/4104995595001/alain-platel-etxea/'
    assert EitbIE(url)._match_id(url) == '4104995595001'

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-12 17:23:17.197569
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert i._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:23:20.273858
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    print(instance)
    assert isinstance(instance, EitbIE)

# Generated at 2022-06-12 17:23:26.306364
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst

    example_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert inst._match_id(example_url) == '4090227752001'

# Generated at 2022-06-12 17:23:33.187352
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:23:39.714249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert instance.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:23:43.327935
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:23:46.363050
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE() # Just call the constructor of class EitbIE