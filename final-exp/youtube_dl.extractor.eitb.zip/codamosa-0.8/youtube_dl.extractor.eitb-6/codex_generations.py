

# Generated at 2022-06-12 17:14:28.434318
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE(EitbIE._VALID_URL, EitbIE._TEST) == EitbIE

# Generated at 2022-06-12 17:14:30.615405
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:14:32.723492
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:14:36.988402
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("")
    eitb = EitbIE("http://www.eitb.tv/eu/bideoa/zuzenean/2014/01/02/fito-y-los-fitipaldis-konzertua/4061747148001/")
    assert eitb._VALID_URL == ie._VALID_URL

# Generated at 2022-06-12 17:14:44.693110
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .common import InfoExtractorTest
    from .common import unittest
    from .common import mock

    class TestInfoExtractor(InfoExtractor):
        IE_NAME = 'EitbIE'
        _VALID_URL = 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
        def __init__(self):
            InfoExtractor.__init__(self)
            self.request = None
        
        def _download_json(self, request, video_id, note, fatal=True):
            self.request = request
            return "Downloading video JSON"


# Generated at 2022-06-12 17:14:46.049469
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import EitbIE
    EitbIE(None, None)

# Generated at 2022-06-12 17:14:50.449795
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor basic test
    """
    ie = EitbIE()
    # Test for correct InfoExtractor initialization
    assert ie.ie_key() == 'Eitb'
    # Test for correct IE class and subclass initialization
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, EitbIE)


# Generated at 2022-06-12 17:15:02.232261
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Test constructor of class EitbIE
    assert(EitbIE.IE_NAME == 'eitb.tv')
    assert(EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-12 17:15:03.043678
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE({},{},'')

# Generated at 2022-06-12 17:15:12.110119
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._match_id('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') == '4104995148001'
    assert ie._real_extract('http://www.eitb.tv/eu/bideoa/adur/2015/05/13/lasterka-argazki-fotografikoak/')
#     assert ie._extract

# Generated at 2022-06-12 17:15:23.565861
# Unit test for constructor of class EitbIE
def test_EitbIE():
    file_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    expected = EitbIE._TEST
    eitb_ie = EitbIE()
    assert eitb_ie._TEST == expected


# Generated at 2022-06-12 17:15:33.590533
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # Testing URL
    assert ie.suitable("http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/") == True
    # Testing a wrong test
    assert ie.suitable("htt://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/") == False
    # Testing a wrong test

# Generated at 2022-06-12 17:15:36.957476
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-12 17:15:39.092665
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check if we can instantiate an object of the class
    try:
        x = EitbIE()
    except:
        assert False
    assert True



# Generated at 2022-06-12 17:15:39.588369
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:15:40.602107
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE, type)

# Generated at 2022-06-12 17:15:50.769055
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Correct url
    assert EitbIE()._match_id('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') == '4090227752001'

    # Wrong url
    assert EitbIE()._match_id('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752002/lasa-y-zabala-30-anos/') is None

# Generated at 2022-06-12 17:15:56.269932
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE().suitable(url)
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:00.045611
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class TestEitbIE(EitbIE):
        # Overload _real_extract to avoid activity that requires internet
        def _real_extract(self, url):
            return {}

    ie = TestEitbIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:16:01.425457
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        pass

# Generated at 2022-06-12 17:16:18.977325
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:16:28.923307
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/euskal-kultura-bolumena/4104993967001/4089901040001/lasa-y-zabala-30-urte/'
    url_2 = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

    # Test if _VALID_URL is correct
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    #Test

# Generated at 2022-06-12 17:16:36.720339
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb._TEST[0]['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert eitb._TEST[0]['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-12 17:16:38.358214
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'



# Generated at 2022-06-12 17:16:39.588976
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    return eitb

# Generated at 2022-06-12 17:16:40.242157
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Unit test for constructor of class EitbIE
	assert EitbIE()

# Generated at 2022-06-12 17:16:40.788676
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:16:42.084339
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-12 17:16:45.393054
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/bideoak-besteak/4158249271001/4158249271001/')
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:16:50.747115
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
	assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:17:20.829027
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    assert test.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:17:23.930244
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:17:27.893055
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE({})
    except:
        raise AssertionError("Unit test for constructor of class EitbIE", "EitbIE could not be constructed")

# Generated at 2022-06-12 17:17:28.802871
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()


# Generated at 2022-06-12 17:17:32.671723
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:17:33.130367
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:17:40.149186
# Unit test for constructor of class EitbIE
def test_EitbIE():
  # Not work in travis, it's reason is a error of the web.
  # Constructor of class EitbIE
  ie = EitbIE()
  # Test a url of webpage
  url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
  string_of_error = ''
  try:
    # Test
    info = ie.extract(url)
  # Catch the error
  except Exception as e:
    string_of_error = str(e)
  # Compare the string of error
  assert string_of_error == '', 'Not work in travis, it\'s reason is a error of the web'


# Generated at 2022-06-12 17:17:41.366039
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE(None)

# Generated at 2022-06-12 17:17:42.082483
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME is not None


# Generated at 2022-06-12 17:17:47.356476
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test the constructor of class EitbIE."""
    eitb_ie = EitbIE(None)
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:18:54.008963
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()._real_extract(EitbIE._TEST['url'])

# Generated at 2022-06-12 17:18:54.364562
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:18:55.510427
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Run unit test for constructor of class EitbIE
    """
    eIE = EitbIE()
    assert eIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:19:05.390141
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:19:06.981081
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitbIE = EitbIE()
	assert eitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:19:12.885835
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:19:14.058975
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:19:16.692064
# Unit test for constructor of class EitbIE
def test_EitbIE():
   """ constructor test """
   obj = EitbIE()
   print ("obj.IE_NAME: " + str(obj.IE_NAME))

# Generated at 2022-06-12 17:19:26.103810
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._match_id(url) == '4090227752001'
    assert EitbIE._VALID_URL == EitbIE._TEST['url']
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert EitbIE._TEST['info_dict']['id'] == '4090227752001'
    assert EitbIE._TEST['info_dict']['ext'] == 'mp4'
    assert EitbIE._T

# Generated at 2022-06-12 17:19:27.508688
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')

# Generated at 2022-06-12 17:22:21.908437
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-12 17:22:30.613454
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(IE_NAME, 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
           'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
           'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:22:39.916325
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie9 = EitbIE()
    assert ie9.IE_NAME == 'eitb.tv'
    assert ie9._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie9._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie9._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-12 17:22:41.245197
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("")
    assert ie.IE_NAME in ('EitbIE','EITB')

# Generated at 2022-06-12 17:22:47.650350
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert(eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert(eitb_ie.ie_key() == 'eitb.tv')

# Generated at 2022-06-12 17:22:49.190243
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-12 17:22:49.987520
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-12 17:22:51.481999
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except AssertionError:
        pass
    else:
        raise AssertionError ("EitbIE class constructor should raise AssertionError")

# Generated at 2022-06-12 17:22:53.196718
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:22:57.827775
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'