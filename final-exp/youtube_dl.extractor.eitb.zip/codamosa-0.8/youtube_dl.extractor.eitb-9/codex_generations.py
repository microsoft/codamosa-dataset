

# Generated at 2022-06-12 17:14:36.806738
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:14:41.766772
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	eitb = EitbIE()
	eitb_res = eitb._real_extract(url)
	assert eitb_res['id'] == '4090227752001'

# Generated at 2022-06-12 17:14:45.169965
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert(EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-12 17:14:46.387249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    unittest.main()

# Generated at 2022-06-12 17:14:46.996042
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:14:48.076416
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("EitbIE")

# Generated at 2022-06-12 17:14:55.650116
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.get_id() == 'eitb.tv'
    assert ie.is_enabled() == True

# Generated at 2022-06-12 17:14:57.993458
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()._real_extract(EitbIE._TEST['url'])

# Generated at 2022-06-12 17:15:06.224411
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:15:06.988887
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-12 17:15:17.371034
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test.
    """
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL
    # TODO: Add more unit test. To be able create dummy files of different sizes and add that to the test.

# Generated at 2022-06-12 17:15:18.270371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("Eitb")

# Generated at 2022-06-12 17:15:19.005142
# Unit test for constructor of class EitbIE
def test_EitbIE():
	pass

# Generated at 2022-06-12 17:15:22.461521
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = EitbIE._TEST['url']
    ie = EitbIE()
    assert ie._VALID_URL == EitbIE._VALID_URL
    assert ie.IE_NAME == EitbIE.IE_NAME
    assert ie._real_extract(url) == EitbIE._TEST

# Generated at 2022-06-12 17:15:24.892656
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert EitbIE.IE_NAME == 'eitb.tv'
    except AssertionError as ae:
        print("AssertionError:", ae)


test_EitbIE()

# Generated at 2022-06-12 17:15:30.781648
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test object initialization
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert isinstance(ie, EitbIE)

# Unit tests for EitbIE

# Generated at 2022-06-12 17:15:35.961202
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor)._download_webpage = lambda url, *args, **kwargs: url
    assert EitbIE(InfoExtractor)._download_json(
        'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4090227752001/',
        '4090227752001', 'Downloading video JSON') == 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4090227752001/'



# Generated at 2022-06-12 17:15:37.158082
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:15:39.285613
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except Exception as e:
        assert False, 'Exception instantiating the EitbIE: %s' % e.message


# Generated at 2022-06-12 17:15:40.935383
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:16:00.657269
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test constructor
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['url'] == url

# Generated at 2022-06-12 17:16:03.368150
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4090227752001/')

# Generated at 2022-06-12 17:16:05.032824
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        import regex as re
    except ImportError:
        import re
    EitbIE()

# Generated at 2022-06-12 17:16:06.138508
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-12 17:16:15.836058
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/zuzendu-gabea/4104995034001/4090336780001/"
    eitb = EitbIE(url)
    assert eitb.IE_NAME == "eitb.tv"
    assert eitb.VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"
    assert eitb.TEST['url'] == url

if __name__ == "__main__":
    test_EitbIE()

# Generated at 2022-06-12 17:16:16.911749
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()


# Generated at 2022-06-12 17:16:28.077385
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == "eitb.tv"
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie._TEST["url"] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert eitb_ie._TEST["md5"] == "edf4436247185adee3ea18ce64c47998"


# Generated at 2022-06-12 17:16:31.366245
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:16:34.126727
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/60-minutos/Lasa-etxeko-irristak/5767896634001/"
    assert EitbIE()._match_id(url)



# Generated at 2022-06-12 17:16:38.188103
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_video = EitbIE()
    assert eitb_video._VALID_URL == EitbIE._VALID_URL
    assert eitb_video._TEST == EitbIE._TEST
    assert eitb_video._real_extract == EitbIE._real_extract


# Generated at 2022-06-12 17:17:09.122624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-12 17:17:11.099820
# Unit test for constructor of class EitbIE

# Generated at 2022-06-12 17:17:22.195823
# Unit test for constructor of class EitbIE
def test_EitbIE():
  url = 'http://www.eitb.tv/eu/bideoa/60-minutos/60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
  url2 = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
  ie = EitbIE(url)
  ie2 = EitbIE(url2)
  assert ie.IE_NAME == ie2.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:17:28.565008
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    assert info_extractor.IE_NAME == 'eitb.tv'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:17:35.841509
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:17:46.518243
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of class EitbIE.

    Test the constructor of class EitbIE.
    """

    assert(EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998')
    assert(EitbIE._TEST['info_dict']['id'] == '4090227752001')

# Generated at 2022-06-12 17:17:53.614617
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._VALID_URL == EitbIE._TEST['url']
    assert EitbIE.IE_NAME == EitbIE._TEST['ie_name']

# Generated at 2022-06-12 17:17:59.103816
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:18:00.441424
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-12 17:18:01.803485
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:19:18.742250
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE.test()

# Generated at 2022-06-12 17:19:27.417257
# Unit test for constructor of class EitbIE
def test_EitbIE():
	html = """
		<html><p>Empty html</p></html>
	"""
	IE = EitbIE()
	assert IE.IE_NAME == 'eitb.tv'
	assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:19:30.284868
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for correct object construction
    ie = EitbIE()
    assert ie.ie_key() == 'eitb.tv'
    assert ie.ie_full_name() == 'eitb.tv'

# Generated at 2022-06-12 17:19:31.392389
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE() != None)


# Generated at 2022-06-12 17:19:38.574315
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import ExtractorTestCase
    from .test_suites.test_extrator_class_common import ValidExtractorTest

    # Create an instance of EitbIE
    EitbIETestCase = ValidExtractorTest(
        "EitbIE",
        EitbIE(),
        [
            ExtractorTestCase(url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'),
        ])

# Generated at 2022-06-12 17:19:40.385653
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:19:46.238036
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('test', 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-12 17:19:50.260173
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-12 17:19:56.482649
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()

    url_test = eitb_ie.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    #id = eitb_ie.ie.id
    duration = eitb_ie.ie.duration
    title = eitb_ie.ie.title
    return duration, title, url_test
result = test_EitbIE()
print(result)

# Generated at 2022-06-12 17:19:58.334561
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("EitbIE constructor")
    # Initialize EitbIE class
    test = EitbIE()
    assert isinstance(test, InfoExtractor)

# Generated at 2022-06-12 17:23:16.546976
# Unit test for constructor of class EitbIE
def test_EitbIE():
    params = {'url':'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'}

# Generated at 2022-06-12 17:23:22.371216
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert re.search(ie._VALID_URL, ie._TEST['url']), ('%r should be a valid URL for EitbIE.' % ie._TEST['url'])

# Generated at 2022-06-12 17:23:26.381586
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:23:33.238014
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:23:37.975664
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try: assert EitbIE(None)
    except: print('Constructor EitbIE failed')
    else: print('Constructor EitbIE success')

# Generated at 2022-06-12 17:23:39.905433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_test = EitbIE({})
    assert eitb_test.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:23:43.135159
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-12 17:23:45.327479
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # TODO: Missing unit tests
    pass

# Generated at 2022-06-12 17:23:53.272741
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-12 17:23:53.859762
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE()