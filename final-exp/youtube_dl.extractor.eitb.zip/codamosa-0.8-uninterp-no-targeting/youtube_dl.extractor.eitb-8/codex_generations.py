

# Generated at 2022-06-22 07:26:52.056900
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitbIE = EitbIE(None)
	return eitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:27:04.092936
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # Test the value of IE_NAME
    assert ie.IE_NAME == 'eitb.tv'
    # Test the value of _VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Test the value of _TEST

# Generated at 2022-06-22 07:27:05.767277
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:27:17.457178
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video = EitbIE()
    assert video._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert video.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:27:25.125537
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:29.780024
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/2019/04/22/zinema-bideoklip-minimal-bilbao/'
    EitbIE(url)

# Generated at 2022-06-22 07:27:42.031594
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.IE_DESC == 'Basque public broadcaster'
    assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:44.553528
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    for case in eitb._TEST:
        eitb._TEST[case] = eitb._TEST[case]


# Generated at 2022-06-22 07:27:47.187469
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
        print("\nUnit test for constructor of class EitbIE finished successfully")
    except:
        print("\nUnit test for constructor of class EitbIE failed")


# Generated at 2022-06-22 07:27:49.075179
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == "EitbIE"

# Generated at 2022-06-22 07:28:09.712712
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:28:16.947903
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_ie = EitbIE(EitbIE._create_proxy_extractor(eitb_url))
    eitb_ie._extract_url(eitb_url)



# Generated at 2022-06-22 07:28:22.775325
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_cases = ['http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/']

    for url in test_cases:
        EitbIE(url)

# Generated at 2022-06-22 07:28:34.921794
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Unit test for constructor of class EitbIE
    assert EitbIE('www.eitb.tv/eu/bideoa/4104995148001/4090227752001/') == EitbIE('http://www.eitb.tv/eu/bideoa/4104995148001/4090227752001/')
    assert EitbIE('www.eitb.tv/es/video/60-minutos-/4104995148001/4090227752001/') != EitbIE('http://www.eitb.tv/eu/bideoa/4104995148001/4090227752001/')

# Generated at 2022-06-22 07:28:37.244091
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert isinstance(eitb_ie, InfoExtractor)

# Generated at 2022-06-22 07:28:40.551669
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:28:46.981820
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:28:54.469433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/60-minutos-lasa-y-zabala-30-anos/'
    eitb = EitbIE(url)
    assert type(eitb) is EitbIE
    return eitb

# Run a unit test of class EitbIE
eitb = test_EitbIE()

# Generated at 2022-06-22 07:29:05.631422
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import os
    import tempfile
    import sys
    from collections import OrderedDict

    def _test_EitbIE(url, extractor_name, expected_title):
        print('\nTesting url "%s" (%s expected)...' % (url, expected_title))

# Generated at 2022-06-22 07:29:06.128786
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:29:21.119960
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE('eitb.tv')
    assert info_extractor is not None

# Generated at 2022-06-22 07:29:22.288847
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test for class EitbIE"""
    EitbIE()

# Generated at 2022-06-22 07:29:28.605301
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class args:
        pass
    args.url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

    return EitbIE(args).extract()

# Generated at 2022-06-22 07:29:32.350059
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test EitbIE online
    eitb_ie = EitbIE()
    # Test EitbIE methods
    assert eitb_ie.ie_key() == 'eitb.tv'

# Generated at 2022-06-22 07:29:36.131269
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().extract(EitbIE()._TEST['url']).get('title') == EitbIE()._TEST['info_dict']['title']

# Generated at 2022-06-22 07:29:38.193573
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE()
    assert test_EitbIE is not None


# Generated at 2022-06-22 07:29:41.538895
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("test", "http://www.eitb.tv/eu/bideoa/noticias/2015/05/30/bideoaren-oinarriak-ingelesa/")

# Generated at 2022-06-22 07:29:46.434452
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)._real_extract('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:29:49.310593
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_common_functions import test_extractor_class
    test_extractor_class(EitbIE)

# Generated at 2022-06-22 07:29:53.858762
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/ravalrock/4114833384001/4115642687001/un-rockero-español-en-paris/')

# Generated at 2022-06-22 07:30:34.652487
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor
    test = EitbIE()
    assert test.IE_NAME == 'eitb.tv'
    assert test._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:30:36.745624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie
    assert hasattr(ie, '_VALID_URL')

# Generated at 2022-06-22 07:30:46.497545
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    resp = EitbIE()._real_extract(url)
    assert resp['id'] == '4090227752001'
    assert resp['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert resp['description'] == 'Programa de reportajes de actualidad.'
    assert resp['duration'] == 3996.76

# Generated at 2022-06-22 07:30:55.322883
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/';
    obj = EitbIE()
    assert obj._VALID_URL == 'https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)';
    assert obj._match_id(url) == "4090227752001";

# Generated at 2022-06-22 07:30:56.253956
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:30:59.416055
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        i = EitbIE()
    except Exception:
        i = None
    assert i != None


# Generated at 2022-06-22 07:31:04.676654
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert 'EitbIE' in repr(obj)
    assert 'EitbIE' in str(obj)
    assert 'EitbIE' in obj.__str__()
    assert 'EitbIE' in obj.__repr__()

# Generated at 2022-06-22 07:31:08.592626
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        obj = EitbIE()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-22 07:31:09.650629
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE)

# Generated at 2022-06-22 07:31:21.037715
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Unit test for constructor of class EitbIE")
    url = "http://www.eitb.tv/eu/bideoa/eguraldia/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    eitbie = EitbIE(url)
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:41.200022
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:42.743676
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL

# Generated at 2022-06-22 07:32:43.799387
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-22 07:32:47.977009
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of class EitbIE."""
    eitbIE = EitbIE(True)
    assert isinstance(eitbIE, EitbIE)
    assert eitbIE.IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:32:57.357636
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # using the same unit test as in Youtube

# Generated at 2022-06-22 07:32:59.253239
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:33:00.219070
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE

# Generated at 2022-06-22 07:33:02.073141
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ret = EitbIE()
    assert ret is not None


# Generated at 2022-06-22 07:33:06.695469
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TEST
    ie._real_extract('http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % '4090227752001')

# Generated at 2022-06-22 07:33:11.685612
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:36:11.445789
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:36:13.262825
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb is not None


# Generated at 2022-06-22 07:36:18.477325
# Unit test for constructor of class EitbIE
def test_EitbIE():
	e = EitbIE()
	e._match_id('https://www.eitb.tv/eu/bideoa/TVE-EITB-BIZIKLETA-GORA/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-22 07:36:19.556062
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)


# Generated at 2022-06-22 07:36:23.354321
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE(InfoExtractor())._download_webpage
        EitbIE(InfoExtractor())._real_extract
    except TypeError:
        print('Unit test for constructor of class %s failed' % EitbIE)

# Generated at 2022-06-22 07:36:26.618006
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        IE = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
        print('\n\n', IE.extract(), '\n\n')
    except Exception as e:
        print('by test: ', e)

test_EitbIE()

# Generated at 2022-06-22 07:36:27.956609
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE
    assert info_extractor


# Generated at 2022-06-22 07:36:33.017383
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.ie_key() == 'eitb.tv'
    assert ie.ie_name() == 'eitb.tv'
    ie.extract('http://www.eitb.tv/eu/bideoa/naiz/naiz/4104995987001/4104995987001/')

# Generated at 2022-06-22 07:36:44.465973
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Creating a new instance of class EitbIE
    eitbie = EitbIE()

    # Checking the name of the IE
    if eitbie.IE_NAME != 'eitb.tv':
        return False

    # Checking the valid url.
    url = "http://www.eitb.tv/eu/bideoa/70-egun-70-egun-2013-2014/4104995148001/4090721792001/berriztagarri/"
    if eitbie._VALID_URL != r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)':
        return False

    # Checking for valid url