

# Generated at 2022-06-22 07:26:47.195572
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:26:58.159343
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert EitbIE._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"
    assert eitb_ie._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"

# Generated at 2022-06-22 07:26:59.704695
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ simple unit test for EitbIE class """
    EitbIE()

# Generated at 2022-06-22 07:27:07.964514
# Unit test for constructor of class EitbIE
def test_EitbIE():

    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    EitbIE(test = True, test_url = url).test_result(0)

    #TODO: Test for additional formats availability

if __name__ == "__main__":
    ut = test_EitbIE()
    ut.test_main()

# Generated at 2022-06-22 07:27:08.659027
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:27:10.407455
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-22 07:27:12.015328
# Unit test for constructor of class EitbIE
def test_EitbIE():
    Eitb = EitbIE()
    assert Eitb is not None

# Generated at 2022-06-22 07:27:12.703278
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:27:14.612151
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:27:17.441203
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.name == 'eitb.tv'



# Generated at 2022-06-22 07:27:27.510425
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().ie_key() == 'Eitb'
    assert EitbIE().ie_name() == 'eitb.tv'

# Generated at 2022-06-22 07:27:40.015368
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-22 07:27:42.085381
# Unit test for constructor of class EitbIE
def test_EitbIE():
    global eitb
    eitb = EitbIE()
# Test for _real_extract(url)
# url is a video url from Eitb.tv

# Generated at 2022-06-22 07:27:43.989429
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Tests the link without any exception
    obj = EitbIE()

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-22 07:27:45.116539
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-22 07:27:46.197560
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-22 07:27:50.362798
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:57.988733
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    See for testing: http://www.eitb.tv/es/video/mira-lo-que-nos-depara-el-invierno-en-la-decimocuarta-edicion-del-salon-del-movil/4105768698001/
    """
    ie = EitbIE()
    ie.get_id('https://www.eitb.tv/es/video/mira-lo-que-nos-depara-el-invierno-en-la-decimocuarta-edicion-del-salon-del-movil/4105768698001/')

# Generated at 2022-06-22 07:28:01.700296
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create a EitbIE
    ie = EitbIE()

    # Check the methods of class EitbIE
    assert ie._real_extract is not None

    # Check the behaviour of constructor in case of failure
    ie = EitbIE(4)
    assert ie._real_extract is None

# Generated at 2022-06-22 07:28:03.877144
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE()
    print(test_EitbIE)


# Generated at 2022-06-22 07:28:19.068893
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitbie = EitbIE('notImpl')
	assert eitbie is not None

# Generated at 2022-06-22 07:28:21.854621
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(InfoExtractor)._VALID_URL == EitbIE._VALID_URL
#

# Generated at 2022-06-22 07:28:28.976484
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test EitbIE
    with open('test_EitbIE.html', 'r') as f:
        html = f.read()
    pattern = r'"http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/\d+/"'
    video_id = re.search(pattern, html)
    video_id = video_id.group(0)[53:-1]
    video_url = "http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/{}/".format(video_id)
    video = _download_json(video_url, video_id, "Downloading video JSON")
    media = video['web_media'][0]
    formats = []

# Generated at 2022-06-22 07:28:34.816992
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'),EitbIE)


# Generated at 2022-06-22 07:28:40.206257
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie.ie_key() == 'Eitb'


# Generated at 2022-06-22 07:28:50.322474
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie=EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:52.590672
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-22 07:29:04.910006
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb_ie = EitbIE(3)
	assert eitb_ie.IE_NAME == "eitb.tv"
	assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
	assert eitb_ie._TEST['url'] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"

# Generated at 2022-06-22 07:29:09.823527
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_video = EitbIE()
    assert test_video._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:29:20.386088
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE();
    assert isinstance(ie, InfoExtractor);
    assert hasattr(ie, '_VALID_URL');
    assert ie._VALID_URL is not None;
    assert isinstance(ie, InfoExtractor);
    assert hasattr(ie, '_TEST');
    assert ie._TEST is not None;
    assert isinstance(ie, InfoExtractor);
    assert hasattr(ie, '_download_json');
    assert ie._download_json is not None;
    assert isinstance(ie, InfoExtractor);
    assert hasattr(ie, '_match_id');
    assert ie._match_id is not None;
    assert isinstance(ie, InfoExtractor);
    assert hasattr(ie, '_real_extract');
    assert ie._real_extract is not None

# Generated at 2022-06-22 07:29:53.961371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)
    assert isinstance(ie, InfoExtractor)
    assert hasattr(ie, "_VALID_URL")
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert hasattr(ie, "_TEST")


# Generated at 2022-06-22 07:30:05.123366
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import sys
    from ytdl.EitbIE import EitbIE
    from ytdl.compat import urlopen
    from ytdl.utils import sanitized_Request
    from ytdl.jsinterp import JSInterpreter
    from ytdl.extractor.EitbIE import EitbIE
    from ytdl.extractor.common import InfoExtractor
    from ytdl.extractor.common import SearchInfoExtractor
    from ytdl.compat import compat_urllib_request
    # Generating object EitbIE
    # Set URL to the object

# Generated at 2022-06-22 07:30:07.125775
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:30:15.350550
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of class EitbIE"""
    # missing instance of YoutubeIE
    try:
        EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    except TypeError as e:
        assert "missing 1 required keyword-only argument: 'youtube_ie'" in str(e)

    from .youtube import YoutubeIE
    # instance of YoutubeIE
    youtube_ie = YoutubeIE()

# Generated at 2022-06-22 07:30:19.799140
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:30:26.144486
# Unit test for constructor of class EitbIE
def test_EitbIE(): 
    """Test for class constructor"""
    # Unit test for constructor of class EitbIE
    def test_EitbIE(): # Test for class constructor
        """Test for class constructor"""
        # Test various EitbIE class instantiation
        try:
            # test for instantiation with EitbIE
            EitbIE()
        except:
            assert False, "EitbIE instantiation for wrong parameter failed"
        else:
            assert True, "EitbIE instantiation for correct parameter passed"

# Generated at 2022-06-22 07:30:34.058294
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # creating a new object with arguments
    x = EitbIE("EitbIE", "http://www.eitb.tv/eu/bideoak/4090227752001/Lasa+y+Zabala,+30+urte/", "")
    # Check whether it is an instance of the class InfoExtractor
    assert  isinstance(x,InfoExtractor)

# Generated at 2022-06-22 07:30:36.332079
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    input = eitbie.IE_NAME
    expected = 'eitb.tv'
    assert input == expected


# Generated at 2022-06-22 07:30:40.027237
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE(None);
    assert eitb.name == "eitb.tv";

# Generated at 2022-06-22 07:30:44.884917
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:31:54.385104
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()
	assert eitb.IE_NAME == 'eitb.tv'
	assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:31:58.546558
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), EitbIE)

# Generated at 2022-06-22 07:32:05.935438
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    EitbIE('http://www.eitb.tv/en/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:32:12.113023
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

    #Asserting EitbIE.IE_NAME (subtype of InfoExtractor)
    assert ie.IE_NAME == 'eitb.tv'

    #Asserting EitbIE._VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:19.646512
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    # Test for _VALID_URL in a string
    assert re.search(class_._VALID_URL, "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Testing for some of the functions for class EitbIE

# Generated at 2022-06-22 07:32:20.654395
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() is not None

# Generated at 2022-06-22 07:32:30.892045
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Initialize an instance of class EitbIE
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:34.292278
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:32:40.564727
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    Test = EitbIE()
    Test.initialize()
    Test.get_formats(url)


# Generated at 2022-06-22 07:32:46.318310
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    assert info_extractor.IE_NAME == 'eitb.tv'
    assert info_extractor._VALID_URL.match('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-22 07:35:43.647456
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    
# This test will fail when a new version of youtube-dl is released
# You can check the output of the function to know if a new version of
# the youtube-dl library is available. The test will always be false
# because the version strings have '-' and '+' symbols.
# With current version of youtube-dl, this test should return:
#     False
#     False
#     False
#     True
#     True
#     True
#     True
#     False
#     False
#     False
#     False
#     False

# Generated at 2022-06-22 07:35:54.163164
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4104995148001'
    wtype = 'MULTIWEBTV'
    video_url = 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % video_id
    EitbIE()._download_json(video_url,video_id,'Downloading video JSON')
    token_url = 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/DomainRestrictedSecurity/TokenAuth/'

# Generated at 2022-06-22 07:36:02.103213
# Unit test for constructor of class EitbIE
def test_EitbIE():
    expected = ('http://www.eitb.tv/es/video/', '60-minutos-60-minutos-2013-2014', '4104995148001', '4090227752001')
    assert expected == EitbIE._get_tuple(EitbIE._VALID_URL)
    assert EitbIE._TEST['url'] == EitbIE._build_url(expected)

# Generated at 2022-06-22 07:36:07.845187
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:36:18.780399
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from ..utils import match_url, escape_url
    from .common import InfoExtractor
    from .pluralsight import PluralsightIE
    from .kaltura import KalturaIE
    from .rts import RTSIE

    # youtube = YoutubeIE()
    pluralsight = PluralsightIE()
    pluralsight2 = KalturaIE()
    pluralsight3 = RTSIE()
    pluralsight4 = EitbIE()
    pluralsight5 = InfoExtractor()
    match_url("http://www.youtube.com/watch?v=BaW_jenozKc", youtube)
    match_url("http://www.youtube.com/watch?v=BaW_jenozKc&list=PL39BF63D2C7627F76", youtube)

# Generated at 2022-06-22 07:36:24.834799
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_Extractor = EitbIE()
    assert info_Extractor.ie_key() == 'eitb.tv'
    assert info_Extractor.ie_name() == 'Eitb'
    assert len(info_Extractor.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')) > 0

# Generated at 2022-06-22 07:36:26.536594
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE is not None

# Generated at 2022-06-22 07:36:28.469540
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()

# Test for regex

# Generated at 2022-06-22 07:36:30.038355
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:36:36.067959
# Unit test for constructor of class EitbIE
def test_EitbIE(): 
    class_eitb_ie = EitbIE()
    assert_equal('ooyala:h3ajVuYTo6UY7VWEyS_Fxj0T0T3iok79', class_eitb_ie.ie_key())
    assert_equal(class_eitb_ie.ie_key(), class_eitb_ie._VALID_URL)


