

# Generated at 2022-06-22 07:26:48.060673
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:26:54.516725
# Unit test for constructor of class EitbIE

# Generated at 2022-06-22 07:26:56.481627
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Return a new EitbIE object."""
    test_ = EitbIE()
    return test_

# Generated at 2022-06-22 07:26:57.957340
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE"""
    EitbIE()

# Generated at 2022-06-22 07:26:59.752224
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass
    # print(EitbIE._TEST['url'])
    # print(EitbIE._TEST['md5'])
    # print(EitbIE._TEST['info_dict'])

# Generated at 2022-06-22 07:27:09.388510
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_cases = ['http://www.eitb.tv/es/video/otros/4104994866001/4092458753001/en-la-cuna-de-la-tecnologia/',
                  'http://www.eitb.tv/eu/bideoa/euskal-kontserbatorioa/4105051763001/4293485648001/errebokazio-sinfonikoan/'
                  ]
    EitbIE().suitable(test_cases[0])
    EitbIE().suitable(test_cases[1])

# Generated at 2022-06-22 07:27:11.396830
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(InfoExtractor).IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:27:13.340710
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # class instantiation
    eitb_ie = EitbIE()


# Generated at 2022-06-22 07:27:16.852906
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-lasa-y-zabala-30-urte/4104995148001/')

# Generated at 2022-06-22 07:27:24.930617
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test that the IE constructor creates an instance of an EitbIE object
    # with the expected class instance variables set (values checked for
    # validity later in _real_extract method).
    url = 'http://www.eitb.tv/eu/bideoa/60-minutuak-60-minutuak-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-urte/'
    eitbie = EitbIE(EitbIE._create_ie(), url)
    # Check the URL to be passed to the next level in the _real_extract method
    # is an instance of the expected class.
    assert isinstance(eitbie._request_webpage(url, None), sanitized_Request)


# Generated at 2022-06-22 07:27:41.797922
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video = EitbIE().url_result(url)
    assert video.video_id == "4090227752001"
    assert video.title == "60 minutos (Lasa y Zabala, 30 años)"
    assert video.duration == 3996.76
    assert video.timestamp == 1381789200


# Unit test to check the existence of class EitbIE

# Generated at 2022-06-22 07:27:50.435249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # URL that returns a JSON file
    url = 'http://www.eitb.tv/eu/bideoa/bideoak/orokorra/idazlanak/1495514/'

    # Instantiate the EitbIE class
    ie = EitbIE()
    # Assert that the URL is valid for this IE
    assert ie.suitable(url)
    # Try to extract information from this URL
    vid = ie.extract(url)
    # Parse the JSON file
    js = json.load(open(vid['id']))
    # Extract the first video
    media = js['videos'][0]

    # Print the title of the video

# Generated at 2022-06-22 07:27:51.185864
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None) is not None

# Generated at 2022-06-22 07:27:53.506978
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL)

# Generated at 2022-06-22 07:28:02.437433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:11.696049
# Unit test for constructor of class EitbIE
def test_EitbIE():
    parsed_url = urlparse('http://www.eitb.tv/eu/bideoa/lasa-y-zabala/4104995148001/4090227752001/')
    assert parsed_url.path == '/eu/bideoa/lasa-y-zabala/4104995148001/4090227752001/'
    assert parsed_url.path.replace('/', '', 1)[0] is ''
    assert parsed_url.path.find('/') != -1

# Generated at 2022-06-22 07:28:14.675738
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Tests to check validity of methods of class EitbIE"""
    eitb_test_ie = EitbIE()
    assert eitb_test_ie != None

# Generated at 2022-06-22 07:28:17.889380
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test the constructor of class EitbIE"""
    assert EitbIE.__name__ == "EitbIE"



# Generated at 2022-06-22 07:28:24.079818
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:28:26.846300
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # constructor of EitbIE() should return an instance of EitbIE
    class_ = EitbIE()
    assert isinstance(class_, EitbIE) == True

# Generated at 2022-06-22 07:28:45.127280
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/musica/vita-imesa-naiz/4104969688001/4104969688001/?c=1")

# Generated at 2022-06-22 07:28:46.459865
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    pass

# Generated at 2022-06-22 07:28:55.840102
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # This test is run against a HTML page, so we need to mock it
    from urllib import urlopen
    from types import MethodType
    eitb_ie = EitbIE()
    eitb_ie._download_json = MethodType(lambda *args, **kwargs: {}, eitb_ie)
    eitb_ie.urlopen = MethodType(lambda *args, **kwargs: urlopen("test_EitbIE.html").read(), eitb_ie)
    # Test EitbIE in the constructor
    eitb_ie.test() # Should not raise any exception

# Generated at 2022-06-22 07:29:06.419374
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    Valid url is from page
    http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/
    '''

    eitbIE = EitbIE()

    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == 'https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)'

# Generated at 2022-06-22 07:29:08.754079
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor of class EitbIE
    EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL)

# Generated at 2022-06-22 07:29:17.502773
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:29:22.940497
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import EitbIE
    eitb=EitbIE()
    #print eitb.IE_NAME
    #print eitb._VALID_URL
    #print eitb._TEST
    video_id = eitb._match_id(eitb._TEST['url'])
    print (video_id)
    test_EitbIE()

# Generated at 2022-06-22 07:29:23.967894
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()

# Generated at 2022-06-22 07:29:28.615767
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE("")
    assert eitb_ie.IE_NAME == EitbIE.IE_NAME
    assert eitb_ie._VALID_URL == EitbIE._VALID_URL
    assert eitb_ie._TEST == EitbIE._TEST


# Generated at 2022-06-22 07:29:30.841052
# Unit test for constructor of class EitbIE
def test_EitbIE():
    m = EitbIE()
    assert m.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:30:05.736872
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert isinstance(e, EitbIE)


# Generated at 2022-06-22 07:30:11.224421
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        from .test.test_utils import EitbIE_Tests
    except ImportError:
        from .tests.test_utils import EitbIE_Tests
    suites = [EitbIE_Tests.suite()]
    return suites


# Generated at 2022-06-22 07:30:15.059122
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        assert False, "Error creating EitbIE instance"


# Generated at 2022-06-22 07:30:16.867036
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE({})
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:30:26.814996
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    url_id = '4090227752001'
    url_title = '60 minutos (Lasa y Zabala, 30 años)'
    url_description = 'Programa de reportajes de actualidad.'
    url_duration = 3996.76
    url_timestamp = 1381789200
    url_upload_date = '20131014'
    url_tags = list

    # Parameters used in constructor
    ie = EitbIE(url)

# Generated at 2022-06-22 07:30:36.745994
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor UnitTest for class EitbIE
    """
    import sys
    import os.path
    try:
        from urlparse import urlparse
    except ImportError:
        from urllib.parse import urlparse

    api_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

    # Check if URL is correctly parsed
    eitbIE = EitbIE(urlparse(api_url))

    assert eitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:30:40.171283
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert isinstance(e, InfoExtractor)


# Generated at 2022-06-22 07:30:45.094305
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # In this case, the test data is a file create by myself,
    # and the url is the url that I used.
    # I improved the code after the test and I would like to keep this test.
    b1 = 1
    b2 = 1
    if b1 != b2:
        raise Exception('test_EitbIE() failed')

# Generated at 2022-06-22 07:30:47.512379
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL.startswith(ie.IE_NAME)

# Generated at 2022-06-22 07:30:49.833295
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"

# Generated at 2022-06-22 07:32:04.904943
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE(None)
    assert eitbie

# Generated at 2022-06-22 07:32:10.532928
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Successful instantiation
    try:
        EitbIE()
    except NameError:
        failed = True
    assert not failed
    # Successful instantiation
    try:
        EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    except NameError:
        failed = True
    assert not failed

# Generated at 2022-06-22 07:32:22.093344
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv//eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-22 07:32:25.140481
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    IE = EitbIE()
    ext = IE.get_extractor(url)

    assert(ext.IE_NAME == 'eitb.tv')

# Generated at 2022-06-22 07:32:26.238635
# Unit test for constructor of class EitbIE
def test_EitbIE():
    yield EitbIE

# Build the test suite

# Generated at 2022-06-22 07:32:31.827530
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test of class EitbIE
    """
    instance = EitbIE('http://mam.eitb.eus/mam/REST/ServiceMultiweb/DomainRestrictedSecurity/TokenAuth/')
    assert (instance.name == 'eitb.tv')
    assert (instance.ie_key == 'Eitb')

# Generated at 2022-06-22 07:32:32.946624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:32:44.426411
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from urlparse import urlparse
    from urlparse import parse_qs
    from urlparse import urlsplit
    from urlparse import urlunsplit
    from urlparse import urljoin

    # Test if URL is OK
    def test_ok_url(url, expected_result):
        result = EitbIE.suitable(url)
        message = "testing " + url
        assert result == expected_result, message

    # Test if URL has query parameters, then build a new URL without it
    def remove_query_parameter(url):
        scheme, netloc, path, query, fragment = urlsplit(url)
        query = None
        return urlunsplit((scheme, netloc, path, query, fragment))

    #Test if URL has fragment identifier, then build a new URL without it

# Generated at 2022-06-22 07:32:51.253295
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.extract("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Uncomment to test for EitbIE
#if __name__ == '__main__':
#    test_EitbIE()

# Generated at 2022-06-22 07:32:53.449470
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Unit test for constructor of class EitbIE """
    assert EitbIE.__name__ == "EitbIE"

# Generated at 2022-06-22 07:36:00.088410
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:36:04.601687
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:36:07.634312
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/eu/bideoa/asu-berdinak/4104995148001/4109607612001/')

# Generated at 2022-06-22 07:36:12.298317
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)

    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:36:13.412167
# Unit test for constructor of class EitbIE
def test_EitbIE():
	instance = InfoExtractor()

# Generated at 2022-06-22 07:36:14.115320
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE

# Generated at 2022-06-22 07:36:24.823402
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .extractor import Extractor
    from .common import InfoExtractor
    from ..compat import compat_str
    from ..utils import (
        int_or_none,
        parse_iso8601,
    )
    from ..compat import compat_str
    IE = InfoExtractor
    e = IE()
    assert e.ie_key() == 'Generic'
    assert e.ie_key() == 'generic'
    assert e.suitable(compat_str('')) == False
    assert e.suitable(compat_str('A string that will not match')) == False
    assert e.suitable(compat_str('Youtube')) == True
    assert e.suitable(compat_str('youtube')) == True

# Generated at 2022-06-22 07:36:36.652862
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert(ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie.IE_NAME == 'eitb.tv')