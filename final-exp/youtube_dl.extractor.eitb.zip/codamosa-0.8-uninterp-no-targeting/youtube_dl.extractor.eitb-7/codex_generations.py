

# Generated at 2022-06-22 07:26:58.581465
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE(EitbIE._VALID_URL, EitbIE._TEST)

# Generated at 2022-06-22 07:27:11.344670
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:12.433004
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-22 07:27:13.738237
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-22 07:27:15.169993
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-22 07:27:22.568481
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)

    assert ie.IE_NAME == 'EitbIE'
    assert ie._VALID_URL == EitbIE._VALID_URL
    assert ie._TEST == EitbIE._TEST
    assert ie._real_extract == EitbIE._real_extract

    assert ie.IE_DESC == 'eitb.tv'
    assert ie.http_headers == {'Accept': 'application/json'}
    assert ie.json

# Generated at 2022-06-22 07:27:24.334149
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.ie_key() == 'EitbIE'

# Generated at 2022-06-22 07:27:25.628706
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:27:34.936175
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('test', 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/');
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.ie_key() == 'eitb.tv'


# Generated at 2022-06-22 07:27:36.759710
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:27:53.155310
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor._downloader)

# Generated at 2022-06-22 07:27:54.613330
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:27:55.445671
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('eitb.tv')

# Generated at 2022-06-22 07:27:56.999935
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-22 07:28:03.019705
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:03.714784
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:28:11.000298
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('')
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:14.031072
# Unit test for constructor of class EitbIE
def test_EitbIE():
    grok.grok(EitbIE.IE_NAME, EitbIE)
test_EitbIE.grok_name = 'EitbIE'

# Generated at 2022-06-22 07:28:17.744613
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.ie_key() == 'EitbIE'

# Generated at 2022-06-22 07:28:23.638682
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    instance = class_()
    assert instance.IE_NAME == "eitb.tv"
    assert instance._VALID_URL == EitbIE._VALID_URL
    assert instance._TEST == EitbIE._TEST
    assert instance._real_extract == EitbIE._real_extract

# Generated at 2022-06-22 07:28:56.499833
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert_equals(eitb_ie.ie_key(), 'Eitb')
    assert_equals(eitb_ie.ie_name(), 'eitb.tv')

# Generated at 2022-06-22 07:29:02.330249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    eitbIE = EitbIE(url)
    assert eitbIE is not None

# Generated at 2022-06-22 07:29:13.140049
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from eitbtools import EitbIE

    assert(EitbIE.IE_NAME == 'eitb.tv')

    assert(EitbIE._VALID_URL == r'(?i)https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-22 07:29:18.810092
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Check if the object EitbIE is constructed successfully
    """
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'
    assert obj.ie_key() == 'EitbIE'
    assert obj.test()
    assert obj.options() == None

# Generated at 2022-06-22 07:29:20.687371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert(IE.IE_NAME == 'eitb.tv')

# Generated at 2022-06-22 07:29:21.717398
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('Unit testing')

# Generated at 2022-06-22 07:29:23.545047
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Inherit from InfoExtractor
    assert issubclass(EitbIE, InfoExtractor)


# Generated at 2022-06-22 07:29:24.214543
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:29:31.442248
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        if EitbIE()._VALID_URL is None:
            raise Exception('Valid URL is None')
        if EitbIE().IE_NAME is None:
            raise Exception('Name is None')
        if EitbIE()._TEST is None:
            raise Exception('Test dictionary is None')
    except Exception as inst:
        print(type(inst)) # the exception instance
        print(inst.args) # arguments stored in .args
        print(inst)
    

# Generated at 2022-06-22 07:29:33.484987
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL)

# Generated at 2022-06-22 07:30:07.922417
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:30:12.537807
# Unit test for constructor of class EitbIE
def test_EitbIE():
	"""
	Test for constructor of class EitbIE. Mainly check it can be constructed
	without error using a valid url and video_id.
	"""
	EitbIE("http://www.eitb.tv/eu/bideoa/joxemitx-lantegi-berriak/701098/", "701098")

# Generated at 2022-06-22 07:30:14.081504
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL is not None

# Generated at 2022-06-22 07:30:24.789579
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_obj = EitbIE()
    assert test_obj._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert test_obj.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:30:30.813726
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')._download_webpage("url", "video_id", "note")

# Generated at 2022-06-22 07:30:33.778560
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:30:36.739749
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    # Declare the downloader, which should be an instance of EitbIE
    downloader = EitbIE()
    
    # Test if the downloader is an instance of InfoExtractor
    assert(isinstance(downloader, InfoExtractor))

# Generated at 2022-06-22 07:30:38.219998
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:30:40.458357
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-22 07:30:45.391549
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', {})
    assert ie.name == 'EitbIE'

# Generated at 2022-06-22 07:32:00.452900
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-22 07:32:05.328018
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/)")

# Generated at 2022-06-22 07:32:10.672199
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    eitb_test = ie._TEST
    url = eitb_test['url']
    assert ie.suitable(url)
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:15.643660
# Unit test for constructor of class EitbIE
def test_EitbIE():
    out = EitbIE(None)
    assert out.IE_NAME == 'eitb.tv'
    assert out._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:32:17.861244
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie != None)

# Generated at 2022-06-22 07:32:22.659035
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
# Run the unit test
test_EitbIE()

# Generated at 2022-06-22 07:32:24.500331
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:32:26.337558
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME is 'eitb.tv'

# Generated at 2022-06-22 07:32:29.340134
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE() != None)


# Generated at 2022-06-22 07:32:29.855487
# Unit test for constructor of class EitbIE
def test_EitbIE():
  EitbIE()

# Generated at 2022-06-22 07:35:35.940918
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:35:37.900887
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.search_key() == 'eitb.tv'

# Generated at 2022-06-22 07:35:44.555736
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        # Check if this instance inherit or not form InfoExtractor
        assert issubclass(EitbIE, InfoExtractor)

        # Check if this instance or not instance of InfoExtractor
        assert isinstance(EitbIE, InfoExtractor)
    except AssertionError as e:
        e.args += ('A instance of class EitbIE must inherit from InfoExtractor\n'+
                   'and be an instance of it ', )
        raise(e)


# Generated at 2022-06-22 07:35:46.261716
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie = IE_NAME
    ie = _VALID_URL
    ie = _TEST

# Generated at 2022-06-22 07:35:50.368818
# Unit test for constructor of class EitbIE
def test_EitbIE():
  ie = EitbIE()
  assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:35:56.039374
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/sobre-ruedas/4124642387001/4124640884001/incendio-de-casas-rurales-en-gipuzkoa-destruye-todo/'
    ie = EitbIE()
    assert ie.extract(url) == "http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4124640884001/"

# Generated at 2022-06-22 07:36:01.607331
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = EitbIE._VALID_URL
    try:
        ie = EitbIE()
        info = ie.extract(url)
        print('info: ' + info)
    except Exception as e:
        print('Exception in test_EitbIE: ' + str(e))


# Generated at 2022-06-22 07:36:03.960368
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', ('test_query'))

# Generated at 2022-06-22 07:36:05.353961
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-22 07:36:09.582576
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')