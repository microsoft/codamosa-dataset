

# Generated at 2022-06-22 07:26:47.986565
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE("http://www.eitb.tv/eu/bideoa/el-nuevo-programa-de-tve-de-la-duquesa-de-alba/4077225243001/4251333906001", 'test')

# Generated at 2022-06-22 07:26:50.626790
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:26:51.734301
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

    assert ie

# Generated at 2022-06-22 07:26:52.277190
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:26:54.701585
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().ie_key() == 'Eitb'

# Generated at 2022-06-22 07:27:04.139678
# Unit test for constructor of class EitbIE
def test_EitbIE():
    'Test for constructor of class EitbIE'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

    eitbie = EitbIE(url)
    url_found = eitbie._real_extract(url)

    assert url_found
    assert url_found['id'] == '4090227752001'
    assert url_found['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert 'description' in url_found

# Generated at 2022-06-22 07:27:13.582937
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-22 07:27:14.664909
# Unit test for constructor of class EitbIE
def test_EitbIE():
	unit_test = EitbIE()
	assert unit_test


# Generated at 2022-06-22 07:27:16.827829
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert(isinstance(EitbIE(), EitbIE))

# Generated at 2022-06-22 07:27:18.288370
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_Eitb = EitbIE()


# Generated at 2022-06-22 07:27:28.933337
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:27:41.261225
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:42.755407
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-22 07:27:44.328941
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL is not None

# Generated at 2022-06-22 07:27:53.431502
# Unit test for constructor of class EitbIE
def test_EitbIE():
    id = "4090227752001"
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    url2 = "http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"

    ie = EitbIE()
    media_info1 = ie._extract_from_url(url)
    media_info2 = ie._extract_from_url(url2)

    assert media_info1 is not None

# Generated at 2022-06-22 07:27:59.643925
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url_test = 'http://www.eitb.tv/eu/bideoa/kultura/toki-gonbidapena/4104995148001/4104995240001/'
	obj = EitbIE()
	obj.suitable(url_test)
	obj.get_id(url_test)
	obj.extract_info_from_url(url_test)
	obj.extract_info(url_test, '')

# Generated at 2022-06-22 07:28:05.027497
# Unit test for constructor of class EitbIE
def test_EitbIE():

    valid_urls = [
        'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
    ]

    invalid_urls = [
        'http://www.eitb.tv/eu',
        'http://www.eitb.tv/eu/bideoa',
    ]

    ies = [EitbIE()]

    for url in valid_urls:
        for ie in ies:
            assert ie.suitable(url)

    for url in invalid_urls:
        for ie in ies:
            assert not ie.suitable(url)

# Generated at 2022-06-22 07:28:17.021956
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:28:19.068917
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:28:20.886261
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert(e != None)

# Generated at 2022-06-22 07:28:45.204419
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC == 'Euskal Irrati Telebista'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert ie._TEST['info_dict']['id'] == '4090227752001'
    assert ie._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 07:28:50.621057
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE({})
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:28:56.396580
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test_eitb = EitbIE()

# Generated at 2022-06-22 07:29:00.610575
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert EitbIE
    except:
        print('Problem creating EitbIE instance')
        return False
    print('EitbIE instance created successfully')
    return True


# Generated at 2022-06-22 07:29:01.725987
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('Video').is_IE()

# Generated at 2022-06-22 07:29:06.144454
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:29:06.874686
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:29:13.097507
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitbie = EitbIE()

# Generated at 2022-06-22 07:29:15.168014
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:29:16.202705
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:29:46.257722
# Unit test for constructor of class EitbIE
def test_EitbIE():
  return EitbIE

# Generated at 2022-06-22 07:29:50.643079
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.ie_key() == 'EitbIE'
    assert e.IE_NAME == 'Eitb'
    assert e.IE_DESC == 'Eitb'

# Generated at 2022-06-22 07:29:52.581235
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:29:57.326618
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst.IE_NAME == 'eitb.tv'
    assert inst._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:30:02.443516
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert (instance.IE_NAME == 'eitb.tv')

# Generated at 2022-06-22 07:30:05.073185
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create instance of class EitbIE
    eitb_ie = EitbIE()
    print(eitb_ie)
test_EitbIE()

# Generated at 2022-06-22 07:30:08.582033
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.ie_key() == 'eitb'

# Generated at 2022-06-22 07:30:15.717896
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC == 'eitb.tv videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:30:17.101950
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:30:24.141704
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:31:41.287554
# Unit test for constructor of class EitbIE
def test_EitbIE():
	
	# Create object of class EitbIE
	c = EitbIE()

	# Test expected values
	assert c.IE_NAME == 'eitb.tv'
	assert c._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:31:52.875068
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test constructor of EitbIE class
    assert(EitbIE.IE_NAME == 'eitb.tv')
    assert(EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-22 07:32:04.881538
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i.IE_NAME == "eitb.tv"
    assert i.IE_DESC == "eitb.tv"
    assert i._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

if __name__ == "__main__":
    # Test EitbIE constructor
    test_EitbIE()
    # Test EitbIE extract
    i = EitbIE()

# Generated at 2022-06-22 07:32:05.925710
# Unit test for constructor of class EitbIE
def test_EitbIE():
    m = EitbIE()

# Generated at 2022-06-22 07:32:10.477332
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:11.518192
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("EitbIE() test")

# Generated at 2022-06-22 07:32:17.090988
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst._VALID_URL
    assert inst._TEST
    assert inst._downloader
    assert inst._WORKING
    assert inst._meta
    assert inst._extractors
    assert inst._IE_NAME
    assert inst._NETRC_MACHINE

# Generated at 2022-06-22 07:32:27.727165
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test class EitbIE constructor."""
    eitb_ie =  EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie._TEST[u'url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-22 07:32:31.779276
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # This unit test can be ran as __main__
    url = 'http://www.eitb.tv/eu/bideoa/mundurako-batasuna/4104995148786/2375772392001/'
    EitbIE(url)

# Generated at 2022-06-22 07:32:38.464857
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:35:58.344471
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:35:59.412243
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:36:08.423120
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Test for class EitbIE constructor """

    from ..compat import compat_urllib_request

    example_url = "http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    request = compat_urllib_request.Request(example_url)
    eitb_ie = EitbIE()
    eitb_ie._real_extract("example_url")

# Generated at 2022-06-22 07:36:08.762920
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:36:11.812951
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/eu/bideoa/gaur-naiz/4104995148001/4092733203001/bideoa/")

# Generated at 2022-06-22 07:36:12.837910
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE({})

# Generated at 2022-06-22 07:36:23.209253
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert IE.IE_NAME == 'eitb.tv'
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:36:24.402151
# Unit test for constructor of class EitbIE
def test_EitbIE():
	class_ = EitbIE(None)
	assert class_ is not None

# Generated at 2022-06-22 07:36:36.018438
# Unit test for constructor of class EitbIE