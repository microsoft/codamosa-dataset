

# Generated at 2022-06-22 07:26:50.831184
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:27:02.564613
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test of class EitbIE.
    """
    import re
    regexp_id_eitbIE = re.compile('^(?P<id>\d+)')

    eitbie = EitbIE()
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:03.979026
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass # test passed in test_utils


# Generated at 2022-06-22 07:27:09.104335
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:27:20.109422
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.IE_NAME
    ie._VALID_URL

    # test for _real_extract()
    # test for playlists dict

# Generated at 2022-06-22 07:27:22.697226
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()

# Generated at 2022-06-22 07:27:27.416878
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    video = test._real_extract(test._TEST['url'])
    assert video['id'] == test._TEST['info_dict']['id']
    assert video['title'] == test._TEST['info_dict']['title']

# Generated at 2022-06-22 07:27:29.465988
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:27:30.651110
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass


# Generated at 2022-06-22 07:27:31.738460
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()

# Generated at 2022-06-22 07:27:40.785924
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance.IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:27:49.354218
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    eitb = EitbIE(InfoExtractor())

# Generated at 2022-06-22 07:27:58.007521
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE('test_EitbIE')
    try:
        assert e.IE_NAME == 'eitb.tv'
    except:
        print("EitbIE: wrong IE_NAME")
        assert False
    try:
        assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    except:
        print("EitbIE: wrong _VALID_URL")
        assert False

# Generated at 2022-06-22 07:28:03.126138
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    obj = EitbIE()
    obj.suitable(url)
    obj.download(url)
    obj.suitable('http://www.eitb.eus')
    obj.download('http://www.eitb.eus')

# Generated at 2022-06-22 07:28:05.974467
# Unit test for constructor of class EitbIE
def test_EitbIE():
    extractor = EitbIE()
    assert extractor.IE_NAME == 'EitbTV'

# Generated at 2022-06-22 07:28:07.222614
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:28:11.814766
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/eu/bideoa/tv/60-minutos/4090227752001/', '/Users/julen/Downloads/1.mp4','','')

# Generated at 2022-06-22 07:28:19.541572
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for constructor of class EitbIE
    """
    ie = EitbIE()
    # test default values
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # test values after running constructor
    assert ie.ie_key() == 'Eitb'

# Generated at 2022-06-22 07:28:24.784737
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_instance = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert isinstance(eitb_instance, EitbIE)


# Generated at 2022-06-22 07:28:37.056274
# Unit test for constructor of class EitbIE
def test_EitbIE():
    unit = EitbIE()

    assert unit._VALID_URL == "http://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"

# Generated at 2022-06-22 07:28:54.801135
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test constructor for correct class name
    ie = EitbIE()
    assert ie.IE_NAME == '/'.join(ie.__name__.split('.')[-2:])


# Generated at 2022-06-22 07:28:59.497533
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_EitbIE()

# Generated at 2022-06-22 07:29:01.105203
# Unit test for constructor of class EitbIE
def test_EitbIE():
  assert isinstance(EitbIE, InfoExtractor)


# Generated at 2022-06-22 07:29:04.601062
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == 'https?://(?:www\.|)eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:29:05.749713
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('None')



# Generated at 2022-06-22 07:29:07.382066
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:29:14.396878
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """The constructor of class EitbIE works correctly."""
    ie = EitbIE()
    assert ie.ie_key() == 'eitb.tv'
    assert ie.ie_name() == 'Eitb.tv'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:29:25.269130
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    test = dict()
    test['url'] = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test['md5'] = 'edf4436247185adee3ea18ce64c47998'
    test['info_dict'] = dict()

# Generated at 2022-06-22 07:29:32.993885
# Unit test for constructor of class EitbIE
def test_EitbIE():

	eitbIE = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

	assert eitbIE.IE_NAME == "eitb.tv"
	assert eitbIE.VALID_URL == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"

	return


# Generated at 2022-06-22 07:29:35.412753
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL


# Generated at 2022-06-22 07:30:15.085620
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    ie = EitbIE(EitbIE.ie_key())
    video = ie.extract(video_url)
    assert video['id'] == '4090227752001'
    assert video['ext'] == 'mp4'
    assert video['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert video['description'] == 'Programa de reportajes de actualidad.'
    assert video['duration'] == 3996.76
    assert video['timestamp'] == 1381789200
    assert video['upload_date']

# Generated at 2022-06-22 07:30:17.184894
# Unit test for constructor of class EitbIE
def test_EitbIE():
    constructor_test(EitbIE)

# Generated at 2022-06-22 07:30:17.934797
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 07:30:21.247414
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(EitbIE.IE_NAME, {'url': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'})

# Generated at 2022-06-22 07:30:24.690971
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == "eitb.tv"

# Generated at 2022-06-22 07:30:28.977029
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # In this case _VALID_URL is not changed,
    # therefore we should use the url for test.
    url = EitbIE._TEST['url']
    ie_unit_test(EitbIE, url)

# Generated at 2022-06-22 07:30:37.287634
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .eitb import EitbIE

    video_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'

    eitb_ie = EitbIE(InfoExtractor())
    eitb_ie._real_extract(video_url)
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:30:41.035321
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Test instantiation of class
	eitb_ie = EitbIE('test.com')
	assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:30:42.014236
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()


# Generated at 2022-06-22 07:30:43.557498
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ei = EitbIE();
    assert(ei.IE_NAME == 'eitb.tv');

# Generated at 2022-06-22 07:32:05.255989
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    v_id = '4090227752001'

    eitb = EitbIE()

    # test _match_id
    assert eitb._match_id(url) == v_id
    # it could be other video_id
    assert eitb._match_id(url + '01') != v_id
    # test _valid_url
    assert eitb._valid_url(url, v_id)
    assert not eitb._valid_url(url + '01', v_id)

    # test _real_extract

# Generated at 2022-06-22 07:32:15.401362
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test EitbIE
    print("Testing EitbIE")
    ie = EitbIE()

    # Test EitbIE._real_extract 
    video_id = '4090227752001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/%s/lasa-y-zabala-30-anos/' % (video_id)
    info_dict = ie._real_extract(url)
    assert info_dict.get('id') == video_id
    assert info_dict.get('title') == '60 minutos (Lasa y Zabala, 30 años)'
    assert info_dict.get('formats')[0].get('format_id')

# Generated at 2022-06-22 07:32:17.658220
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert isinstance(EitbIE(), InfoExtractor)


# Generated at 2022-06-22 07:32:28.058680
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:32:32.199068
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-22 07:32:34.676441
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:32:40.984922
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import FakeYDL
    from .common import expected

    vid_id = '4090227752001'
    eitb_ie = EitbIE(FakeYDL(), {'id': vid_id})
    info_dict = eitb_ie._get_info_dict(vid_id)
    assert info_dict['id'] == vid_id
    assert info_dict == expected

# Generated at 2022-06-22 07:32:52.417101
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = 'http://www.eitb.tv/eu/bideoa/s1/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:56.310729
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('Eitb.tv', 'Eitb.tv tester')
    ie.download('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:33:03.809388
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #import pdb; pdb.set_trace()
    from .common import InfoExtractor

    c=InfoExtractor("EitbIE","http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    res=c._extract_urls()
    return 0

#test_EitbIE()

# Generated at 2022-06-22 07:36:01.255780
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == "eitb.tv"

# Generated at 2022-06-22 07:36:12.591801
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert_equal(ie.IE_NAME, 'eitb.tv')
    assert_equal(ie._VALID_URL, r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-22 07:36:13.700693
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:36:14.370258
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:36:19.616661
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_instance = EitbIE()
    assert test_instance.IE_NAME == 'eitb.tv'
    assert test_instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:36:22.631800
# Unit test for constructor of class EitbIE
def test_EitbIE():
    infoExtractor = EitbIE()
    print(infoExtractor)

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-22 07:36:25.290685
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb.EitbIE(
        'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:36:30.603246
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj_EitbIE = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:36:41.296363
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Unit test for constructor of the class EitbIE """
    # Instantiate an object of the class EitbIE
    ie = EitbIE()
    # Assert that the object instance ie is a valid object of the class EitbIE
    assert isinstance(ie, EitbIE)
    # Assert the value of the variable IE_NAME of the class "InfoExtractor"
    assert ie.IE_NAME == 'eitb.tv'
    # Assert the value of the variable _VALID_URL of the class "EitbIE"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Assert the value of the variable _