

# Generated at 2022-06-22 07:26:54.101290
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import os, unittest
    import sys
    MODULE_DIR = os.path.join(os.getcwd(), "../../..")
    sys.path.insert(0, MODULE_DIR)

    from _pytest.monkeypatch import MonkeyPatch
    monkeypatch = MonkeyPatch()
    # These methods should actually be called
    monkeypatch.setattr('youtube_dl.utils.retry_get_url', lambda *args, **kwargs: None)
    monkeypatch.setattr('youtube_dl.downloader.http.HttpFD.download', lambda *args, **kwargs: None)
    monkeypatch.setattr('youtube_dl.downloader.FragmentFD.download', lambda *args, **kwargs: None)
    monkeypatch.setattr('urllib.urlretrieve', lambda *args, **kwargs: None)
   

# Generated at 2022-06-22 07:26:56.849949
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()
    assert t._VALID_URL is not None
    assert t.IE_NAME is not None
    assert t._TEST is not None

# Generated at 2022-06-22 07:27:01.736864
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    e.test()

# Generated at 2022-06-22 07:27:05.253261
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    Tests for the constructor of class EitbIE
    '''
    test = EitbIE()
    assert type(test) == EitbIE


# Generated at 2022-06-22 07:27:09.901405
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:27:11.232254
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:27:13.180864
# Unit test for constructor of class EitbIE
def test_EitbIE():
    value = EitbIE()
    assert value.IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:27:23.375475
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:31.082541
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # try to create an instance of the class
    ie = EitbIE(None)
    # check if the class has registered itself
    assert ie.IE_NAME == "eitb.tv"
    # check the constructor
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:27:32.868322
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import eitb
    assert eitb.EitbIE()

# Generated at 2022-06-22 07:27:47.488727
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Vars
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    instance = EitbIE()

    # _VALID_URL = r'https?://(?:www\.)?(?:eitb\.tv|eitb\.com)/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    if not instance._VALID_URL.match(url):
        raise AssertionError(_("Unit test failure in EitbIE.test_EitbIE()"))


# Generated at 2022-06-22 07:27:53.577753
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    EitbIE("http://www.eitb.tv/eu/bideoa/gaur-eta-goizean/4104995148001/4090232077001/matematika-fun/")

# Generated at 2022-06-22 07:27:57.168706
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:27:58.378647
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructing a EitbIE instance."""
    EitbIE()

# Generated at 2022-06-22 07:28:02.131832
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .coursera import CourseraCourseIE
    from .vimeo import VimeoIE
    from .youtube import YoutubeIE

    ie_eitb_tv = EitbIE()
    ie_vimeo = VimeoIE()
    ie_youtube = YoutubeIE()

    assert ie_eitb_tv.IE_NAME == 'eitb.tv'
    assert ie_vimeo.IE_NAME == 'Vimeo'
    assert ie_youtube.IE_NAME == 'Youtube'

# Generated at 2022-06-22 07:28:03.889661
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, None, None)

# Generated at 2022-06-22 07:28:06.267148
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert hasattr(EitbIE, '_VALID_URL')



# Generated at 2022-06-22 07:28:08.000895
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-22 07:28:19.825792
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitbie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:28:23.054668
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/es/video/la-pandilla-aladna/5006/4090227749001/')

# Generated at 2022-06-22 07:28:40.062277
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    YoutubeIE()._real_extract(url)

# Generated at 2022-06-22 07:28:44.470710
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Function to test constructor of class EitbIE """
    tempeitbie = EitbIE()

# Generated at 2022-06-22 07:28:48.308195
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:57.022142
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._match_id('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') == '4090227752001'

# Generated at 2022-06-22 07:28:58.220727
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:29:05.136336
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    # Test if it is an instance of InfoExtractor
    assert isinstance(eitb, InfoExtractor)
    # Test if it is an instance of EitbIE
    assert isinstance(eitb, EitbIE)
    # Test if it has a valid URL
    assert hasattr(eitb, '_VALID_URL')

# Generated at 2022-06-22 07:29:11.455826
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    except:
        raise AssertionError('EitbIE constructor does not work')

# Generated at 2022-06-22 07:29:16.479579
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()

# Generated at 2022-06-22 07:29:20.793476
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:29:31.270148
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for constructor of class EitbIE
    """
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:30:02.581478
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import setUp
    from .common import FakeIE

    setUp(FakeIE) # Initializes dummy modules and defines modules
    # Globals that can be used for testing.
    globals()['FakeIE'] = FakeIE
    globals()['setUp'] = setUp

# Generated at 2022-06-22 07:30:04.746527
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .import EitbIE

    # Test creation of class instance
    obj1 = EitbIE()
    assert(obj1 is not None)
    assert(obj1.ie_key() == 'Eitb')

# Generated at 2022-06-22 07:30:08.172471
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE({})
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:30:10.358579
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE(InfoExtractor())
    eitbIE

# Generated at 2022-06-22 07:30:19.074060
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert e._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert e._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'


# Generated at 2022-06-22 07:30:20.174824
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:30:23.033604
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'EitbIE'
    assert 'www.eitb.tv' in ie._VALID_URL


# Generated at 2022-06-22 07:30:29.784151
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert not EitbIE().suitable("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    EitbIE()._real_extract("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    pass

# Generated at 2022-06-22 07:30:33.946076
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:30:34.475525
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:31:47.798620
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_test_url = 'http://www.eitb.tv/eu/bideoa/bizitza/saltoki-malkartasuna-tratatu-zuten-etxe-berrien-kudeaketan/4104995148001/4090227752001/'

    eitb_test_IE = EitbIE(eitb_test_url)

    assert eitb_test_IE.IE_NAME == 'eitb.tv'
    assert eitb_test_IE.IE_DESC == 'eitb.tv'



# Generated at 2022-06-22 07:31:49.454413
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE, InfoExtractor)


# Generated at 2022-06-22 07:31:51.359159
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE();
    assert ie.IE_NAME == 'eitb.tv';

# Generated at 2022-06-22 07:31:51.995803
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:31:53.403309
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-22 07:31:57.122959
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE


# Generated at 2022-06-22 07:32:00.129499
# Unit test for constructor of class EitbIE
def test_EitbIE():
	infoExtractor = InfoExtractor()
	eitb = EitbIE()
	assert eitb.IE_NAME == infoExtractor.IE_NAME

# Generated at 2022-06-22 07:32:04.955278
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create an instance of class EitbIE
    eitbIE = EitbIE(InfoExtractor.YoutubeIE.ie)
    # Check that the instance is created properly
    assert eitbIE._WORKING == True

# Generated at 2022-06-22 07:32:05.978046
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-22 07:32:06.812753
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.IE_NAME
    ie._VALID_URL
    ie._TEST

# Generated at 2022-06-22 07:34:52.524741
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:34:54.967785
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except NameError as e:
        assert False, "Could not construct the class."

# Generated at 2022-06-22 07:34:59.300702
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor

    eitb_ie = InfoExtractor(EitbIE.IE_NAME)
    assert eitb_ie.IE_NAME == EitbIE.IE_NAME


# Generated at 2022-06-22 07:35:02.938472
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    new_test = EitbIE(url)

# Generated at 2022-06-22 07:35:13.698253
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check that a EitbIE instance has been created with
    # the appropriate url, filename, and youtube_id.
    expected_filename = '4090227752001.mp4'
    expected_youtube_id = '4090227752001'
    expected_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(expected_url)
    assert expected_filename == ie._filename
    assert expected_youtube_id == ie._youtube_id
    assert expected_url == ie._url


# Generated at 2022-06-22 07:35:15.101881
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # TODO: Implement test for constructor of class EitbIE
    pass

# Generated at 2022-06-22 07:35:16.131866
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # just test that we can import the module
    pass

# Generated at 2022-06-22 07:35:19.595935
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Creation of object EitbIE
    test_object = EitbIE()
    print('Object created')
    print(test_object)
    print(test_object.__dict__)
    return test_object


# Generated at 2022-06-22 07:35:23.893779
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("EitbIE", "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-22 07:35:25.160188
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'Eitb.tv'