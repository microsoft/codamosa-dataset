

# Generated at 2022-06-22 07:26:46.737565
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-22 07:26:47.988250
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:26:54.987574
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/2012-2013/Bideoa/4104995148001/4090273219001/sondagarria/'
    class_instance = EitbIE(url)
    print("*** Class Name: " + class_instance.__class__.__name__)
    print("*** Test ID: " + class_instance.getId())

# Generated at 2022-06-22 07:26:56.117901
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()

# Generated at 2022-06-22 07:27:08.246365
# Unit test for constructor of class EitbIE
def test_EitbIE():
    m1 = EitbIE()
    assert type(m1._VALID_URL) == type(r'')
    assert m1._VALID_URL == r'https?:\/\/(?:www\.)?eitb\.tv\/(?:eu\/bideoa|es\/video)\/[^\/]+\/\d+\/(?P<id>\d+)'
    assert hasattr(m1, '_TEST') == True
    assert type(m1._TEST) == dict
    assert len(m1._TEST) == 2
    assert hasattr(m1, '_download_webpage') == True
    assert hasattr(m1, '_extract_formats') == True
    assert hasattr(m1, '_extract_video_info') == True

# Generated at 2022-06-22 07:27:09.387497
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL

# Generated at 2022-06-22 07:27:10.494852
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:27:14.011961
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
        print("EitbIE is properly configured")
    except:
        print("EitbIE is not well configured")


# Generated at 2022-06-22 07:27:14.651562
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:27:20.622661
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:35.452421
# Unit test for constructor of class EitbIE
def test_EitbIE():
  ie = EitbIE()
  # EitbIE._TEST
  assert ie._TEST
  # EitbIE.IE_NAME
  assert ie.IE_NAME == 'eitb.tv'
  # EitbIE._VALID_URL
  assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
  # EitbIE._extract_info
  assert hasattr(ie, '_extract_info')

# Generated at 2022-06-22 07:27:42.609197
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE"""
    eitb_ie = EitbIE()
    assert(eitb_ie.IE_NAME == 'eitb.tv')
    assert(eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-22 07:27:45.465995
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'EitbIE'

# Generated at 2022-06-22 07:27:48.773394
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-22 07:27:51.025937
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'



# Generated at 2022-06-22 07:27:52.421542
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None).IE_NAME == 'eitb.tv'



# Generated at 2022-06-22 07:27:53.358923
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:27:56.884536
# Unit test for constructor of class EitbIE
def test_EitbIE():
    s = EitbIE()
    assert s.IE_NAME == IE_NAME
    assert s._VALID_URL == _VALID_URL
    assert s._TEST == _TEST
    assert s.__name__ == __name__
    assert s.suport_test == False



# Generated at 2022-06-22 07:28:01.800275
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # First run a unit test for the `EitbIE` class constructor
    ie_eitb = EitbIE()

    # Now, check the `EitbIE._VALID_URL` attribute
    assert ie_eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

    # Return the `EitbIE` instance created to test the `EitbIE` class
    return ie_eitb



# Generated at 2022-06-22 07:28:12.007757
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.suitable('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    ie.get_info('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:28:28.397357
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:34.297989
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None, None)
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:28:44.045873
# Unit test for constructor of class EitbIE
def test_EitbIE():
    def __init__(self, video_id):
        self.video_id = video_id
        self.playlist = []

    def _match_id(self, url):
        if 'eitb.tv' in url:
            return url.split('/')[-1]
        else:
            return None

    def _download_json(self, url, video_id, note, errnote, fatal, data=None, headers=None, query=None):
        arr = url[:len(url) - 1].split("/")

# Generated at 2022-06-22 07:28:48.619633
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert test_EitbIE is not None


# Generated at 2022-06-22 07:28:54.339356
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:29:00.185249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        from ..compat import FileNotFoundError
        EitbIE()
    except FileNotFoundError:
        pass  # This just tests that the constructor of this class does not fail.

# Generated at 2022-06-22 07:29:01.776782
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create an instance of class EitbIE
    EitbIE()

# Generated at 2022-06-22 07:29:07.932568
# Unit test for constructor of class EitbIE
def test_EitbIE():
		eitb_ie = EitbIE()
		assert eitb_ie.IE_NAME == 'eitb.tv'
		assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:29:15.168249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor of class EitbIE should not return None
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert ie != None


# Generated at 2022-06-22 07:29:16.609332
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:29:47.939005
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # The url to be tested.
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    # Check if the url matches the regex.
    match = EitbIE._VALID_URL.match(url)
    assert match is not None
    # Create an instance of class EitbIE.
    eitb_ie = EitbIE(match)
    # Check if the name of the class is correct.
    assert eitb_ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:29:48.776471
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-22 07:29:54.946191
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    video_id = '4090227752001'

    # Test download of json video information
    video = eitb._download_json(
        'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % video_id,
        video_id, 'Downloading video JSON')
    assert video is not None


# Generated at 2022-06-22 07:29:57.616547
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Example unit test that should pass when the EEI_NAME is correctly defined
    """
    assert EitbIE().IE_NAME == "eitb.tv"

# Generated at 2022-06-22 07:30:08.461298
# Unit test for constructor of class EitbIE
def test_EitbIE():
    c = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/')
    print(c.IE_NAME)
    print(c._VALID_URL)
    print(c._TEST)
    print(c.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'))
   

# Generated at 2022-06-22 07:30:13.458880
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:30:18.294309
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('EitbIE','eitb.tv','http://www.eitb.tv/es/video/plataforma-abierta/4106283397001/4119149450001/analizamos-el-economico-de-zapatero/', {})

# Generated at 2022-06-22 07:30:18.949124
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-22 07:30:23.131024
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert EitbIE.IE_NAME == eitb_ie.IE_NAME
    assert EitbIE._VALID_URL == eitb_ie._VALID_URL
    assert EitbIE._TEST == eitb_ie._TEST

# Generated at 2022-06-22 07:30:34.488405
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('www.eitb.tv/eu/bideoa/noticias/eitb/programas/gipuzkoa-kultura-korrika/4090254094001/')
    EitbIE('http://www.eitb.tv/eu/bideoa/noticias/eitb/programas/gipuzkoa-kultura-korrika/4090254094001/')
    EitbIE('www.eitb.tv/eu/bideoa/noticias/eitb/programas/gipuzkoa-kultura-korrika/')

# Generated at 2022-06-22 07:31:44.099066
# Unit test for constructor of class EitbIE
def test_EitbIE():
    cls = EitbIE
    # Instance of EitbIE
    i = cls()
    i.IE_NAME
    i.IE_DESC



# Generated at 2022-06-22 07:31:46.888270
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:31:51.888996
# Unit test for constructor of class EitbIE
def test_EitbIE():
  assert(EitbIE.IE_NAME == 'eitb.tv')
  assert(EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-22 07:31:53.700384
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:32:01.264504
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:32:12.262554
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:16.477838
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:27.438609
# Unit test for constructor of class EitbIE

# Generated at 2022-06-22 07:32:38.976807
# Unit test for constructor of class EitbIE
def test_EitbIE():
    site = EitbIE()
    assert site.IE_NAME == 'eitb.tv'
    assert site._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:41.691505
# Unit test for constructor of class EitbIE
def test_EitbIE():
    name = 'eitb.tv'
    tester = InfoExtractor(name, name)
    assert tester

# Generated at 2022-06-22 07:35:43.545398
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	test_md5 = 'edf4436247185adee3ea18ce64c47998'
	test_title = '60 minutos (Lasa y Zabala, 30 años)'
	test_description = 'Programa de reportajes de actualidad.'
	test_duration = 3996.76
	test_timestamp = 1381789200
	test_upload_date = '20131014'
	test_tags = list
	test_id = '4090227752001'
	test_ext = 'mp4'
	test_formats

# Generated at 2022-06-22 07:35:48.421542
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test for EitbIE.
    """

    url = "http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    eitbie = EitbIE(url)
    assert eitbie.IE_NAME == "eitb.tv"
    assert eitbie.VALID_URL == "http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert eitbie.VIDEO_ID == "4090227752001"
   

# Generated at 2022-06-22 07:35:51.978264
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is not None

# Generated at 2022-06-22 07:35:53.930323
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE({}, 'eitb.tv')

# Generated at 2022-06-22 07:35:59.680977
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')



# Generated at 2022-06-22 07:36:04.263166
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert 'es/bideoa' in eitb._VALID_URL, eitb._VALID_URL
    assert 'https://mam.eitb.eus/mam/REST/ServiceMultiweb' in eitb._downloader.urlopen.__doc__
    assert 'EitbIE' in eitb.IE_NAME, eitb.IE_NAME

# Generated at 2022-06-22 07:36:09.035138
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Class to test constructor of class EitbIE
    """
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/gure-aurpegia/14/452466/")
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:36:12.889771
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()
	assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:36:14.830775
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:36:20.060719
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'