

# Generated at 2022-06-22 07:26:55.093882
# Unit test for constructor of class EitbIE
def test_EitbIE():
    for url in [ 'http://www.eitb.tv/eu/bideoa/idazbikia/4107014819001/idazbikia/',
                 'http://www.eitb.tv/eu/bideoa/euskaldun-kirolak/4104995148001/57752/',
                ]:
        ie = EitbIE(url)
        assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:26:56.222622
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert('EitbIE' in locals())

# Generated at 2022-06-22 07:27:01.986718
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:03.181377
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == ie.ie_key()

# Generated at 2022-06-22 07:27:05.886523
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Checks class EitbIE to check if it can construct its object.
    """
    assert EitbIE

# Generated at 2022-06-22 07:27:08.135345
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:27:09.728236
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:27:20.499160
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:21.352012
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:27:27.665288
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()
    e = t.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert '60 minutos (Lasa y Zabala, 30 años)' == e['title']

# Generated at 2022-06-22 07:27:40.516508
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:48.947945
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('http://www.eitb.tv/eu/bideoak/lasa-y-zabala-30-anos/')
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:50.248905
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-22 07:27:54.866196
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Check constructor of class EitbIE, even though not all
    the methods are tested.
    """
    ydl = EitbIE()
    assert ydl.IE_NAME == 'eitb.tv'
    assert ydl._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:56.574067
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Unit test for EitbIE (returns EitbIE)
    assert isinstance(EitbIE(), EitbIE)

# Generated at 2022-06-22 07:28:02.083232
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE._VALID_URL == EitbIE._VALID_URL
    assert EitbIE.IE.IE_NAME == 'eitb.tv'
    assert EitbIE.IE.IE_DESC == __doc__[:__doc__.find('\n\n')]
    assert EitbIE.IE._TEST == EitbIE._TEST
    assert EitbIE.IE._real_extract == EitbIE._real_extract

# Generated at 2022-06-22 07:28:06.440421
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

    assert eitb.IE_NAME == 'eitb.tv', 'eitb.tv should be the name of the constructor for class EitbIE'

# Generated at 2022-06-22 07:28:07.696180
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()


# Generated at 2022-06-22 07:28:08.476723
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == "eitb.tv"

# Generated at 2022-06-22 07:28:09.653955
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert True

# Generated at 2022-06-22 07:28:24.197232
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == '^https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)$'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC == 'eitb.tv'

# Generated at 2022-06-22 07:28:27.897579
# Unit test for constructor of class EitbIE
def test_EitbIE():
    module = 'youtube_dl.extractor.eitb'
    constructor_test(module, globals(), [
        # Without `IE_NAME`
        (
            lambda: EitbIE(IE_NAME, 'Eitb.tv'),
            [],
            True
        )
    ])

# Generated at 2022-06-22 07:28:35.028447
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # EitbIE(InfoExtractor)._downloader.cache.storage = "memory"
    assert EitbIE(InfoExtractor)._real_extract("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/") is not None

# Generated at 2022-06-22 07:28:44.970181
# Unit test for constructor of class EitbIE
def test_EitbIE():
  exp = {
      'id': '4090227752001',
      'ext': 'mp4',
      'title': '60 minutos (Lasa y Zabala, 30 años)',
      'description': 'Programa de reportajes de actualidad.',
      'duration': 3996.76,
      'timestamp': 1381789200,
      'upload_date': '20131014',
      'tags': list,
  }
  
  got = EitbIE()._real_extract('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
  assert exp == got

# Generated at 2022-06-22 07:28:49.906961
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:28:55.601576
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance.IE_NAME == 'eitb.tv'
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:28:58.702935
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE is not None

# Generated at 2022-06-22 07:29:03.032321
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    EitbIE()._build_url(url, {'video_id': '4090227752001'})


# Generated at 2022-06-22 07:29:12.114942
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create object of class EitbIE
    eitbie = EitbIE()

    # Set value for _VALID_URL
    eitbie._VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Test
    eitbie._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:29:16.970174
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    _ = EitbIE(url)

# Generated at 2022-06-22 07:29:33.295696
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # TODO: Write this unit test
    pass

# Generated at 2022-06-22 07:29:40.823609
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie=EitbIE(url)
    info=ie.extract()
    assert 'md5' in info.keys()
    assert int(info['duration'])==3996

# Generated at 2022-06-22 07:29:47.973397
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        import yaml
    except ImportError as ex:
        print("Python module yaml is not installed. Please install python package 'pyyaml'. Exception: %s" % ex)
        sys.exit(1)

    with open("test_eitb.yaml", 'r') as stream:
        data_loaded = yaml.load(stream)


    for url_to_test in data_loaded:
        print("URL TO TEST: %s" % url_to_test['url'])
        ie = EitbIE(url_to_test['url'])
        assert (ie.IE_NAME == url_to_test['IE_NAME'])
        assert (ie.VALID_URL == url_to_test['VALID_URL'])

# Generated at 2022-06-22 07:29:58.978006
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/1282600988001/Elkarrizketa-Itziarren-aurka--sinadura-nagusitua/"
    IE = EitbIE(url)
    # Checking if url is right
    assert IE.url == url
    # Checking if _match_id is right
    assert IE._match_id("http://www.eitb.tv/eu/bideoa/1282600988001/Elkarrizketa-Itziarren-aurka--sinadura-nagusitua/") == "1282600988001"
    # Checking if _real_extract returns good result
    info_dict = IE._real_extract(url)
    assert "id" in info_dict
    assert "title" in info_dict


# Generated at 2022-06-22 07:30:03.605422
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb_ie.ie_key() == 'Eitb'


# Generated at 2022-06-22 07:30:14.693303
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test construction from a valid url.
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitbie = EitbIE(url)

    # Check the id given by the constructor
    assert eitbie._match_id(url) == '4090227752001'

    # Check if the video is being extracted in the right way
    video = eitbie._real_extract(url)

    # Check if the video title matches the expected one
    assert video.get('title') == '60 minutos (Lasa y Zabala, 30 años)'

# Generated at 2022-06-22 07:30:15.859531
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), InfoExtractor)

# Generated at 2022-06-22 07:30:22.407443
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()

    dl = test._download_json('http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4104995148001/',
                               '4104995148001', 'Downloading video JSON', True)

    if dl['id'] == '4104995148001':
        print("The id is not equal")

    assert dl['id'] == '4104995148001'

# Generated at 2022-06-22 07:30:25.377246
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, EitbIE)
    assert ie.IE_NAME == 'eitb.tv'   # Object attribute: IE_NAME


# Generated at 2022-06-22 07:30:26.321532
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE


# Generated at 2022-06-22 07:31:07.411329
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE("bla")
    assert isinstance(eitb_ie, EitbIE)

# Generated at 2022-06-22 07:31:07.880202
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:31:12.949172
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = "https://www.eitb.eus/eu/bideoa/details/60-minutos-60-minutos-2013-2014/4090227752001/"
	ie = EitbIE(url)
	assert ie.url == url
	assert ie.id == '4090227752001'
	assert ie.name == 'eitb.tv'

# Generated at 2022-06-22 07:31:18.129874
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:31:22.897642
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie is not None

# Generated at 2022-06-22 07:31:26.793600
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4120835342001/4090227752001/lasa-y-zabala-30-anos/')
    instance.download_webpage = lambda url, *args: url

# Generated at 2022-06-22 07:31:28.230111
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:31:31.644285
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE(None, None)

# Generated at 2022-06-22 07:31:43.547123
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:31:55.059208
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.channels == {}

# Generated at 2022-06-22 07:33:20.042776
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-22 07:33:20.665797
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:33:32.215079
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    assert test.IE_NAME == 'eitb.tv'
    assert test._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:33:33.121614
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL

# Generated at 2022-06-22 07:33:38.574012
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    i = ie.extract('http://www.eitb.tv/eu/bideoa/48-oras/4104995148001/4104995151001/?highlight=lasa%20y%20zabala')
    assert i['id'] == '4090227752001'

# Generated at 2022-06-22 07:33:39.141043
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:33:41.182679
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('EitbIE', None)
    assert eitbIE.name == 'EitbIE'

# Generated at 2022-06-22 07:33:44.720122
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (EitbIE().IE_NAME == 'eitb.tv')

# Generated at 2022-06-22 07:33:45.328835
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), EitbIE)

# Generated at 2022-06-22 07:33:47.129955
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb