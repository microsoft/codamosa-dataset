

# Generated at 2022-06-22 07:26:49.655301
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-22 07:26:53.209527
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except Exception as e:
        print("Class constructor test exception: {}".format(e))
        return False
    else:
        return True


# Generated at 2022-06-22 07:26:54.472653
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
        print("EitbIE() success")
    except:
        print("EitbIE() failed")


# Generated at 2022-06-22 07:26:55.527009
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('Eitb')

# Generated at 2022-06-22 07:26:59.433364
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #TODO: Implement
    assert False, "Unit test for EitbIE not implemented"

# Generated at 2022-06-22 07:27:06.189226
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (
        EitbIE.ie_key() ==
        'eitb.tv')
    assert (
        EitbIE.ie_key('eitb.tv') ==
        'eitb.tv')
    assert (
        EitbIE.name ==
        'eitb.tv')
    assert (
        EitbIE.description ==
        'Hiria. Pueblo. Patria.')
    assert (
        EitbIE.constructor ==
        EitbIE)
    assert (
        EitbIE.thumbnail ==
        're:^https?://.*\.jpg$')
    assert (
        EitbIE.uploader ==
        'EITB')
    assert (
        EitbIE.uploader_id ==
        'eitb')

# Generated at 2022-06-22 07:27:17.821656
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.IE_DESC == 'EiTB'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == url
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'


# Generated at 2022-06-22 07:27:19.842740
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test non-string input
    assert EitbIE(None) is not None

# Generated at 2022-06-22 07:27:22.951618
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:31.142423
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb_ie.constructor == EitbIE
    assert eitb_ie.constructor_name == 'EitbIE'
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:27:39.539038
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:27:42.243127
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:45.080144
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:27:49.742552
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/programa/110/edicion/91386/'
    ie = EitbIE(url)
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:54.881880
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test constructor of class EitbIE
    ie = EitbIE()
    assert ie.name == "EitbIE"
    assert ie.version == "0.0.1"
    assert ie.url_re == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.real_download is True


# Generated at 2022-06-22 07:27:56.512566
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None).ie_key() == 'eitb.tv'


# Generated at 2022-06-22 07:28:00.378036
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-urte/'
    eitb_ie = EitbIE(None)
    assert eitb_ie._match_id(url) == '4090227752001'

# Unit test: download_json method of class EitbIE

# Generated at 2022-06-22 07:28:02.249413
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(None)._downloader, InfoExtractor)

# Generated at 2022-06-22 07:28:15.588532
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4104995148001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video = EitbIE._real_extract(EitbIE(), url)
    assert video['id'] == video_id
    assert video['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert video['description'] == 'Programa de reportajes de actualidad.'
    assert video['duration'] == 3996.76
    assert video['timestamp'] == 1381789200

# Generated at 2022-06-22 07:28:25.593193
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class EitbIETest(EitbIE):
        def __init__(self):
            self._match_id = None # Just for testing purposes, do not modify
            self._download_json = None # Just for testing purposes, do not modify

    ie = EitbIETest()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:28:44.886113
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos/60-minutos-2013-2014/4090227752001/")

# Generated at 2022-06-22 07:28:56.972670
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        eitb = EitbIE(None)
    except Exception:
        assert False, 'Could not create EitbIE object'


# Generated at 2022-06-22 07:28:59.105103
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ei = EitbIE()
    assert isinstance(ei, InfoExtractor)

# Generated at 2022-06-22 07:29:10.746125
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test_class = EitbIE
    test_result = {
        'id': '4090227752001',
        'ext': 'mp4',
        'title': '60 minutos (Lasa y Zabala, 30 años)',
        'description': 'Programa de reportajes de actualidad.',
        'duration': 3996.76,
        'timestamp': 1381789200,
        'upload_date': '20131014',
        'tags': list,
    }

# Generated at 2022-06-22 07:29:18.829295
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('Testing constructor of class EitbIE')
    ie_parser = InfoExtractor()
    eitb = EitbIE(ie_parser)
    ie_parser.add_info_extractor(eitb)
    url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    print(url)
    info = ie_parser.extract(url)
    print(info)

# Generated at 2022-06-22 07:29:29.648174
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor for class EitbIE

    Tests whether the constructor of class EitbIE creates
    a valid instance of the class. This is checked by
    comparing the data extracted from the video with test
    data, provided in the test case
    """
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    ie = EitbIE()
    ie_result = ie.extract(url)

    assert ie_result['id'] == '4090227752001'
    assert ie_result['title'] == '60 minutos (Lasa y Zabala, 30 años)'

# Generated at 2022-06-22 07:29:30.736851
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-22 07:29:32.350697
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(EitbIE._VALID_URL)

# Generated at 2022-06-22 07:29:44.004461
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitbie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert eitbie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-22 07:29:46.359249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test case for constructor of class EitbIE"""
    global EitbIE
    EitbIE(InfoExtractor(), '')

# Generated at 2022-06-22 07:30:26.435996
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:30:28.826963
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('eitb.tv')

# Generated at 2022-06-22 07:30:30.481145
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)

# Generated at 2022-06-22 07:30:31.650911
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Simple test for constructor, nothing more
    EitbIE()

# Generated at 2022-06-22 07:30:32.148110
# Unit test for constructor of class EitbIE
def test_EitbIE():
	pass

# Generated at 2022-06-22 07:30:33.224229
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor())._real_extract('url')

# Generated at 2022-06-22 07:30:33.745554
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:30:38.004288
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case = EitbIE()
    assert test_case._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert test_case._TEST
    assert test_case.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:30:39.883801
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('eitb.tv')

# Generated at 2022-06-22 07:30:40.891427
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:31:51.677578
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE() == EitbIE

# Generated at 2022-06-22 07:31:52.719928
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-22 07:32:01.020860
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from youtube_dl.utils import DateRange

	# Test with a complete url
	url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	EitbIE(url)


# Generated at 2022-06-22 07:32:07.899503
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of class EitbIE"""
    # Testing extractor constructor with right parameters
    instance = EitbIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert instance.IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:32:19.126620
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_obj = EitbIE()
    assert ie_obj.IE_NAME == 'eitb.tv'
    assert ie_obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:25.140694
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test try to construct an EitbIE object with a wrong url
    try:
        IE = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    except:
        print("Exception (wrong url in ctor)")
        assert False
    # Test try to construct an EitbIE object

# Generated at 2022-06-22 07:32:34.485736
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #Checks if eitb.tv/eu/bideoa url is valid
    assert InfoExtractor.is_suitable("http://www.eitb.tv/es/video/") is False
    assert InfoExtractor.is_suitable("http://www.eitb.tv/eu/bideoa/") is False
    
    #A good video url
    assert InfoExtractor.is_suitable("http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4090227752001/") is True
    #A wrong video url

# Generated at 2022-06-22 07:32:35.885405
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()

# Generated at 2022-06-22 07:32:39.545473
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:49.052149
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test creation of an EitbIE object
    obj = EitbIE()
    assert obj.ie_key() == 'Eitb'
    assert obj.ie_name() == 'EITB'
    assert obj.ie_description() == 'Euskal Irrati Telebista'
    assert obj.webpage_url_re() == r'https?://(?:www\.)?eitb\.tv/'
    assert obj.url_re() == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/\d+'

# Generated at 2022-06-22 07:35:55.992870
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE."""
    ie = EitbIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 07:35:56.830045
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:35:59.929381
# Unit test for constructor of class EitbIE

# Generated at 2022-06-22 07:36:00.566380
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:36:01.602574
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:36:03.362908
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .extractor import DummyExtractor
    DummyExtractor(EitbIE())

# Generated at 2022-06-22 07:36:05.065061
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE().download(EitbIE._TEST['url'])

# Generated at 2022-06-22 07:36:06.585756
# Unit test for constructor of class EitbIE
def test_EitbIE():
	EitbIE()


# Generated at 2022-06-22 07:36:07.062413
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:36:14.662302
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'http://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'