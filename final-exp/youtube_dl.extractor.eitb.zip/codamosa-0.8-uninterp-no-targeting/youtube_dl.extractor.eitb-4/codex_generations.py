

# Generated at 2022-06-22 07:26:49.689494
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:26:50.286759
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-22 07:26:50.914669
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:26:52.056785
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-22 07:26:57.005785
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == EitbIE._VALID_URL
    assert ie._TEST == EitbIE._TEST


# Generated at 2022-06-22 07:26:59.380019
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE('unit test', 'EitbIE is OK')

if __name__ == 'main':
    test_EitbIE()

# Generated at 2022-06-22 07:27:12.107689
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/1786365/erakundeak-kontsumitu-gabe-utzi-duen-azoka-eta-txinpartek-kudeaketarat-zuzenduta/"
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:22.983351
# Unit test for constructor of class EitbIE
def test_EitbIE():
    tester = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

    assert tester.name == 'eitb.tv'
    assert tester.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert tester.ie_key == 'eitb.tv'
    assert tester.video_id == '4090227752001'

# Generated at 2022-06-22 07:27:33.630737
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/suzien-berriaren-ikuspegia/4104995148001/4090227752001/'
    assert EitbIE().suitable(url)
    assert EitbIE()._real_extract('http://www.eitb.tv/eu/bideoa/suzien-berriaren-ikuspegia/4104995148001/4090227752001/')
    assert not EitbIE().suitable('http://www.eitb.tv/eu/bideoa/penalti-bat-gordetzen-duten-txuri-urdinak/4104995148001/4090228355001/') == '4090228355001'

# Generated at 2022-06-22 07:27:36.381575
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/4960-nabarmentze/')

# Generated at 2022-06-22 07:27:47.295190
# Unit test for constructor of class EitbIE
def test_EitbIE():
  ie = EitbIE(); assert ie.IE_NAME == 'eitb.tv'; assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:50.291766
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_class = EitbIE(InfoExtractor())
    assert test_class.ie_key() == 'EitbIE'
    assert test_class.ie_name() == 'eitb.tv'

# Generated at 2022-06-22 07:27:53.392499
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert(EitbIE('EitbIE','http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 'id'))

# Generated at 2022-06-22 07:27:57.786173
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:01.012969
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:14.892292
# Unit test for constructor of class EitbIE

# Generated at 2022-06-22 07:28:21.854268
# Unit test for constructor of class EitbIE
def test_EitbIE():
    filename = os.path.join(os.path.dirname(__file__), "test.json")
    json_data = open(filename).read()
    assert (EitbIE._download_json(None,
            '4090227752001',
            'Downloading video JSON') == json.loads(json_data))

# Generated at 2022-06-22 07:28:28.976882
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    assert test.IE_NAME == 'eitb.tv'
    assert test.url is None
    assert test.id is None

    assert test.re is not None
    assert test.re.match('https://www.eitb.tv/eu/bideoa/')
    assert test.re.match('https://www.eitb.tv/es/video/')
    assert test.re.match('http://www.eitb.tv/eu/bideoa/')
    assert test.re.match('http://www.eitb.tv/es/video/')

# Generated at 2022-06-22 07:28:32.029097
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-22 07:28:42.398346
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:29:05.808255
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE("http://www.eitb.tv/es/video/tikitakas/4199869110001/4198959534001/")
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitbIE._TEST['url'] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/"

# Generated at 2022-06-22 07:29:15.973373
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    ie._downloader = None
    ie._match_id('id')
    ie.http_headers()
    ie.report_download_page(None, None)
    ie.report_extraction(None)
    ie.suitable(None)
    ie.add_ie(None)

# Generated at 2022-06-22 07:29:16.622630
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:29:27.606622
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(1)
    video_id = ie._match_id(url)
    video = ie._download_json(
        'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % video_id,
        video_id, 'Downloading video JSON')
    media = video['web_media'][0]
    formats = []
    for rendition in media['RENDITIONS']:
        video_url = rendition.get('PMD_URL')

# Generated at 2022-06-22 07:29:40.441906
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #import pdb
    #pdb.set_trace()
    def _test_EitbIE(url, media_id):
        info_dict = info_dict = EitbIE()._real_extract(url)
        if info_dict is None:
            print("Testcase failed for url: %s  (no info_dict)" % url)
            return 0
        if info_dict["id"] != media_id:
            print("Testcase failed for url: %s  (id='%s' should be '%s')" % (url, info_dict["id"], media_id))
            return 0
        print("Testcase succeded for url %s" % url)
        return 1


# Generated at 2022-06-22 07:29:43.821827
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video = EitbIE()
    assert video is not None

# Generated at 2022-06-22 07:29:45.307627
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert type(EitbIE()) is EitbIE

# Generated at 2022-06-22 07:29:57.325660
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

    ie = EitbIE('4090227752001')

# Generated at 2022-06-22 07:29:59.204102
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:30:01.562093
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_common import TestCommon
    i = TestCommon.make_instance(EitbIE)
    assert i is not None

# Generated at 2022-06-22 07:30:33.945997
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME in eitbie.VALID_URL

# Generated at 2022-06-22 07:30:35.186474
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.__name__ == 'EitbIE'

# Generated at 2022-06-22 07:30:38.002561
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-22 07:30:41.821065
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()
	str_ = str(ie)
	assert str(ie) == "<class 'youtube_dl.extractor.eitb.EitbIE'>"


# Generated at 2022-06-22 07:30:46.398084
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE("http://www.eitb.tv/eu/bideoa/gaur/4090215063001/artur-mas-eskatzen-du-enployoa-bertan-behera/")
    assert eitbIE.name == "eitb.tv"

# Generated at 2022-06-22 07:30:48.442020
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()
    pass

# Generated at 2022-06-22 07:30:55.808802
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    full_url = ie.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert full_url['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert full_url['description'] == 'Programa de reportajes de actualidad.'
    assert full_url['duration'] == 3996.76

# Generated at 2022-06-22 07:31:01.808581
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'
    assert obj.ie_key() == 'eitb.tv'
    assert obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:31:03.746635
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:31:05.136068
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE is not None

# Generated at 2022-06-22 07:32:27.163577
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t=True
    f=False

    # Test for constructor of class EitbIE

# Generated at 2022-06-22 07:32:31.162257
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:32:31.785555
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:32:34.734842
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert isinstance(eitb.IE_NAME, basestring)
    assert isinstance(eitb.IE_DESC, basestring)
    assert hasattr(eitb, '_VALID_URL')
    assert hasattr(eitb, '_TEST')
    assert callable(eitb._real_extract)

# Generated at 2022-06-22 07:32:36.949569
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    return ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:32:40.072588
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create a new instance of EitbIE
    eitbie = EitbIE()

    # Check that it is an instance of InfoExtractor class
    assert isinstance(eitbie, InfoExtractor)


# Generated at 2022-06-22 07:32:41.995404
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    assert isinstance(
        test, EitbIE)

# Generated at 2022-06-22 07:32:53.347877
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert isinstance(eitb_ie, EitbIE)
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:55.411974
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video = EitbIE()
    assert video.name == 'eitb.tv'
    assert video.ie_key() == 'Eitb'

# Generated at 2022-06-22 07:32:55.863721
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:35:46.524916
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL, EitbIE.IE_NAME)

# Generated at 2022-06-22 07:35:51.223406
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    obj = EitbIE(url)
    assert obj.valid_url == url

# Generated at 2022-06-22 07:35:52.524921
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    return

# Generated at 2022-06-22 07:35:59.681250
# Unit test for constructor of class EitbIE
def test_EitbIE():
    result = EitbIE()
    assert(result.IE_NAME == "eitb.tv")
    assert(result._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-22 07:36:06.106873
# Unit test for constructor of class EitbIE
def test_EitbIE():

    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert EitbIE._TEST['info_dict']['id'] == '4090227752001'
    assert EitbIE._T

# Generated at 2022-06-22 07:36:06.749967
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:36:11.478496
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('https://www.eitb.tv/eu/bideoa/jolasa-tx/4090227752001/')

    assert eitb_ie.name == 'eitb.tv'
    assert eitb_ie.video_id == '4090227752001'

# Generated at 2022-06-22 07:36:17.091721
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """test for constructor of class EitbIE"""
    url = 'http://www.eitb.tv/eu/bideoa/sporteko-txapeldunak/4138640404001/4138640405001/'

    eitb = EitbIE()
    actual = eitb._real_extract(url)
    assert EitbIE._TEST == actual

# Generated at 2022-06-22 07:36:18.731608
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()


# Generated at 2022-06-22 07:36:20.154833
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == "eitb.tv"