

# Generated at 2022-06-22 07:26:51.123745
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:26:56.226497
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert(eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-22 07:27:08.435030
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.ie_key() == 'eitb.tv'
    assert eitbIE.ie_name() == 'eitb.tv'
    assert eitbIE.ie_version() == '0.0.1'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:13.503509
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:27:18.604223
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:27:21.186973
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == "eitb.tv"

# Generated at 2022-06-22 07:27:32.501957
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance
    assert instance.IE_NAME == 'eitb.tv'
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:39.952562
# Unit test for constructor of class EitbIE
def test_EitbIE():
    name = "EitbIE"
    assert hasattr(EitbIE, '_VALID_URL')
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Unit tests for _real_extract method of class EitbIE

# Generated at 2022-06-22 07:27:49.518956
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # create an instance of class EitbIE for testing
    ie = EitbIE()

    # test an invalid url
    test_url = 'http://www.eitb.tv/es/video/zuzenean/4098124444001/l-ha-muerto-el-amor/'
    info = ie.extract(test_url)
    assert len(info) == 0

    # test a valid url
    test_url = 'http://www.eitb.tv/es/video/zuzenean/4098124444001/l-ha-muerto-el-amor/'
    info = ie.extract(test_url)
    assert len(info) == 10

    # test if id is correct
    assert info['id'] == '4098124444001'

    #

# Generated at 2022-06-22 07:27:54.460388
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:28:03.237507
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:28:16.324090
# Unit test for constructor of class EitbIE
def test_EitbIE():

    eitb_ie = EitbIE()
    assert eitb_ie.IE_DESC == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:24.513055
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()

    # Test extract function
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    info_extractor.extract(url)

    # Test _real_extract function
    video_id = '4090227752001'
    info_extractor._real_extract(url)

# Generated at 2022-06-22 07:28:27.940734
# Unit test for constructor of class EitbIE
def test_EitbIE():
	try:
		test = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
		assert test is not None
	except:
		assert False


# Generated at 2022-06-22 07:28:31.440602
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor())
    # Sanity check that class EitbIE is actually created without raising exception.
    assert True


# Generated at 2022-06-22 07:28:36.534978
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    ie.extract(url)

# Generated at 2022-06-22 07:28:39.813893
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()
    # call to constructor of class EitbIE,
    # just in case we made a typo in name of class
    # this will throw error of 'No module named EitbIE' in case of typo
    # no output if all is fine


# Generated at 2022-06-22 07:28:49.854350
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Input parameters
    input_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    input_fields = ['id', 'url', 'playlist', 'playlist_index', 'ie_key']
    # Output parameters
    output_fields = ['id', 'title', 'description', 'thumbnail', 'duration', 'timestamp', 'tags', 'formats']

# Generated at 2022-06-22 07:28:54.696954
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:28:55.757339
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:29:15.893748
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor

    clase_a_probar = EitbIE
    instancia_clase = clase_a_probar()

    if type(instancia_clase) == clase_a_probar:
        print("Constructor de EitbIE ok")
    else:
        print("Constructor de EitbIE fail")


# Generated at 2022-06-22 07:29:18.079584
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IEClass = EitbIE()
    assert IEClass.IE_NAME == "eitb.tv"

# Generated at 2022-06-22 07:29:19.110143
# Unit test for constructor of class EitbIE
def test_EitbIE():
    x = EitbIE()

# Generated at 2022-06-22 07:29:23.042256
# Unit test for constructor of class EitbIE
def test_EitbIE():
    extractor = EitbIE()
    assert extractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:29:28.724351
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # We don't use it to test above functionalities.
    IE_NAME = 'eitb.tv'
    url = 'http://www.eitb.tv/eu/bideoa/15-minutos-15-minutos/4101189752001/4102600952001/blogei/'
    IE_NAME(url)

# Generated at 2022-06-22 07:29:32.845804
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:29:35.702298
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
        Constructor for EitbIE 
    """
    return EitbIE()


# Generated at 2022-06-22 07:29:40.155995
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:29:49.891466
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_instance = EitbIE()
    test_instance._match_id('http://www.eitb.tv/eu/bideoa/bla/2/3//testid/')
    assert test_instance._match_id('http://www.eitb.tv/eu/bideoa/bla/2/3/testid/') == 'testid'
    assert test_instance._match_id('http://www.eitb.tv/eu/bideoa/bla/2/3/12345/') == '12345'
    assert test_instance._match_id('http://www.eitb.tv/eu/bideoa/bla/2/3/12345') is None

# Generated at 2022-06-22 07:29:50.801891
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(InfoExtractor()).ie_key() == 'eitb.tv'

# Generated at 2022-06-22 07:30:23.999921
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()

# Generated at 2022-06-22 07:30:26.945332
# Unit test for constructor of class EitbIE
def test_EitbIE():
	e = EitbIE()

# Generated at 2022-06-22 07:30:33.314144
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test constructor of class EitbIE
    """
    try:
        assert EitbIE(InfoExtractor())
    except AssertionError:
        print("Unit test of EitbIE failed")
        assert False
    else:
        print("Unit test of EitbIE succeeded")
        assert True


# Generated at 2022-06-22 07:30:34.329652
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:30:34.863330
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-22 07:30:37.381305
# Unit test for constructor of class EitbIE
def test_EitbIE():
    __test__ = {
        'constructor': """
    >>> EitbIE() # doctest: +ELLIPSIS
    <EitbIE(u'?(\S+)')>
    """
    }

# Generated at 2022-06-22 07:30:43.092085
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    q = EitbIE(url)
    assert q.url == url


# Generated at 2022-06-22 07:30:54.696947
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import os
    import sys
    import requests
    import unittest

    # load json test data
    abs_path = os.path.join(os.path.dirname(__file__), "json_results", "eitb.json")
    with open(abs_path, "rb") as f:
        data = requests.json(f.read())

    test_url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"

    # get instance of class
    eitb = EitbIE(test_url)

    # test instance is not None
    assert (eitb is not None) is True

    # test class variables


# Generated at 2022-06-22 07:31:04.238147
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_cases = ['http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/' ]
    
    for url in test_cases:
        assert EitbIE._VALID_URL.search(url)

# Generated at 2022-06-22 07:31:16.252492
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.ie_key() == 'eitb.tv'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:23.726426
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/eu/bideoa/populartrending/4090227752001/')

# Generated at 2022-06-22 07:32:27.316645
# Unit test for constructor of class EitbIE
def test_EitbIE():

    url = 'http://www.eitb.tv/eu/bideoa/2014/12/15/franco-rendicion-francia-espana/'

    eitb = EitbIE()
    assert eitb.suitable(url)



# Generated at 2022-06-22 07:32:28.884409
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test EitbIE class constructor
    EitbIE()


# Generated at 2022-06-22 07:32:37.822322
# Unit test for constructor of class EitbIE
def test_EitbIE():
	info_extractor = InfoExtractor()
	info_extractor.addInfoExtractor(EitbIE.ie_key())
	IE_NAME = 'eitb.tv'
	VALID_URL = 'https://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	info_extractor._real_extract(VALID_URL)
	assert info_extractor._real_extract(VALID_URL)

# Generated at 2022-06-22 07:32:38.982643
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() is not None

# Generated at 2022-06-22 07:32:40.068842
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:32:41.941825
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/')

# Generated at 2022-06-22 07:32:43.852539
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE({})
    assert (type(ie) == EitbIE)



# Generated at 2022-06-22 07:32:45.146239
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiate class
    EitbIE()

# Generated at 2022-06-22 07:32:49.159481
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:35:43.699697
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:35:48.458729
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
	return True

# Generated at 2022-06-22 07:35:57.236150
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    testargs = {
    }
    assert(ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-22 07:35:58.375443
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME



# Generated at 2022-06-22 07:36:00.319981
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE != 'null'

# Generated at 2022-06-22 07:36:01.401183
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb=EitbIE()

# Generated at 2022-06-22 07:36:02.438518
# Unit test for constructor of class EitbIE
def test_EitbIE():
    yt = EitbIE()

# Generated at 2022-06-22 07:36:04.552381
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:36:06.749742
# Unit test for constructor of class EitbIE
def test_EitbIE():
	try:
		EitbIE()
		assert True
	except:
		assert False

# Generated at 2022-06-22 07:36:08.267389
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/irratia/2014/06/multzoak-urriaren-4-2014-06-04-00-00-00-00-00-2014/')
    assert ie.IE_NAME == 'eitb.tv'