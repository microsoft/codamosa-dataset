

# Generated at 2022-06-22 07:26:51.303570
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:26:54.747965
# Unit test for constructor of class EitbIE
def test_EitbIE():
    if __name__ == '__main__':
        test_instance = EitbIE()
        print(test_instance)
        print(test_instance._VALID_URL)

# Generated at 2022-06-22 07:27:05.243286
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert e._TEST['url'] == url
    assert e._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-22 07:27:12.004017
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(eitb_ie.ie_key() == 'EitbIE')


# Generated at 2022-06-22 07:27:20.642272
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL(EitbIE._TEST['url'])
    eitb_test = EitbIE(EitbIE._TEST['url'])
    eitb_test._real_extract(eitb_test._TEST['url'])
    assert eitb_test._TEST['url'] == eitb_test._VALID_URL(eitb_test._TEST['url'])
    assert eitb_test._TEST['md5'] == eitb_test._download_webpage(eitb_test, eitb_test._TEST['url'], None)['md5']

# Generated at 2022-06-22 07:27:21.795729
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Assert object creation
    EitbIE()

# Generated at 2022-06-22 07:27:33.911759
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.ie_key() == 'Eitb'
    assert ie._WORKING == True
    assert ie._TESTS.get('url') == url

# Generated at 2022-06-22 07:27:41.104605
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.ie_key() == 'eitb.tv'
    assert eitb.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:46.702959
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    info = ie._real_extract(url)

    assert(info.get('title') == '60 minutos (Lasa y Zabala, 30 años)')
    assert(info.get('id') == '4090227752001')

# Generated at 2022-06-22 07:27:49.212741
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.IE_NAME = 'EitbIE'
    assert ie.IE_NAME == 'EitbIE'


# Generated at 2022-06-22 07:28:06.928503
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert isinstance(eitb_ie, EitbIE)


# Generated at 2022-06-22 07:28:12.982711
# Unit test for constructor of class EitbIE
def test_EitbIE():
    m1 = EitbIE()
    assert m1.IE_NAME == 'eitb.tv'
    assert m1._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:23.348078
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Lookup the ID of the video "XYZ", if it can't be found in the unit
    # test, look up the ID in the webpage
    test = EitbIE()
    test.test(test._TEST, {'id': '4090227752001'})

    # If the test fails, then you should find the ID of the video in the
    # webpage: http://www.eitb.tv/eu/bideoa/zuzen-komunikazioa/4104995148001/4090227752001/lasa-eta-zabala-30-urte/
    # and add it to the test

if __name__ == "__main__":
    test_EitbIE()

# Generated at 2022-06-22 07:28:29.633206
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test_url_http = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	test_url_https = 'https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
	assert EitbIE._T

# Generated at 2022-06-22 07:28:32.390899
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Check if EitbIE is built
	assert EitbIE is not None


# Generated at 2022-06-22 07:28:42.923610
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    result = EitbIE()._real_extract(url)
    assert result['id'] == "4090227752001"
    assert result['title'] == "60 minutos (Lasa y Zabala, 30 años)"
    assert result['description'] == "Programa de reportajes de actualidad."
    assert result['duration'] == 3996.76
    assert result['timestamp'] == 1381789200

# Generated at 2022-06-22 07:28:48.358299
# Unit test for constructor of class EitbIE
def test_EitbIE():
    if __name__ == '__main__':
        url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
        eitb = EitbIE()

# Generated at 2022-06-22 07:28:54.075164
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:58.485572
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-22 07:29:10.379134
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert('eitb.tv' in ie.IE_NAME)
    assert(ie._VALID_URL is not None)
    assert('edf4436247185adee3ea18ce64c47998' in ie._TEST['md5'])
    assert('4090227752001' in ie._TEST['info_dict']['id'])
    assert(ie._TEST['info_dict']['ext'] == 'mp4')
    assert('60 minutos (Lasa y Zabala, 30 años)' in ie._TEST['info_dict']['title'])
    assert('Programa de reportajes de actualidad.' in ie._TEST['info_dict']['description'])

# Generated at 2022-06-22 07:29:33.658910
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from ..utils import (
        sanitized_Request,
    )
    from ..compat import compat_str
    from ..compat import compat_urllib_request
    from json import loads
    from zlib import decompress

    # create the object to test
    eitbie = EitbIE(InfoExtractor)

    # get video_id from url
    video_id = eitbie._match_id('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert '4090227752001' == video_id

    # get video data

# Generated at 2022-06-22 07:29:44.790348
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-22 07:29:46.029795
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-22 07:29:47.834350
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-22 07:29:51.006823
# Unit test for constructor of class EitbIE
def test_EitbIE():
    n = EitbIE()
    assert n.IE_NAME == 'eitb.tv'
    assert n.VALID_URL == n._VALID_URL


# Generated at 2022-06-22 07:29:57.649981
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test1 = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert test1

# Generated at 2022-06-22 07:30:02.004289
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .eitb import EitbIE
    EitbIE('http://www.eitb.tv/eu/bideoa/')
    EitbIE('http://www.eitb.tv/eu/bideoa')
    EitbIE('www.eitb.tv/eu/bideoa')

# Generated at 2022-06-22 07:30:03.417894
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE({})
    ie.extract({})

# Generated at 2022-06-22 07:30:06.339749
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create instance of EitbIE class
    ie = EitbIE()
    # Check if _VALID_URLS is empty
    assert len(ie._VALID_URLS) != 0

# Generated at 2022-06-22 07:30:15.164844
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # Test _VALID_URL
    url = 'http://www.eitb.tv/eu/bideoa/notizia/20140823/gasteiz-zinemaldia/4046580202001/'
    match = ie._VALID_URL.match(url)
    assert match.group('id') == '4046580202001'
    # Test constructor
    obj = ie.suitable(url) and ie
    assert obj.IE_NAME == 'eitb.tv'
    assert hasattr(obj, '_download_json')
    assert hasattr(obj, '_match_id')
    assert hasattr(obj, '_real_extract')
    assert hasattr(obj, '_WORKING')
    assert hasattr(obj, '_downloader')



# Generated at 2022-06-22 07:30:50.602727
# Unit test for constructor of class EitbIE
def test_EitbIE():
    fixture = EitbIE()._extract_ie("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    print(fixture)
    assert fixture['id'] == '4090227752001'

# Generated at 2022-06-22 07:30:51.670352
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:30:52.274122
# Unit test for constructor of class EitbIE
def test_EitbIE():
  return EitbIE()

# Generated at 2022-06-22 07:30:55.899067
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:31:00.400630
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:31:01.266564
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('')

# Generated at 2022-06-22 07:31:05.258026
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Usage of constructor of class EitbIE"""
    # Test instantiation and deletion of the instance
    eitb_ie = EitbIE()
    del eitb_ie
    # Test all methods supplied by the instance
    eitb_ie = EitbIE()
    assert eitb_ie._match_id('') is None
    assert eitb_ie._real_extract('') == {}

# Generated at 2022-06-22 07:31:05.679359
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:31:06.113102
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:31:07.511744
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)

# Generated at 2022-06-22 07:32:20.853568
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:32:21.718039
# Unit test for constructor of class EitbIE
def test_EitbIE():
    t = EitbIE()
    assert t.IE_NAME == "Eitb"

# Generated at 2022-06-22 07:32:27.003596
# Unit test for constructor of class EitbIE

# Generated at 2022-06-22 07:32:29.443676
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    pass


# Generated at 2022-06-22 07:32:30.892173
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor without passing all parameters
    assert EitbIE()

# Generated at 2022-06-22 07:32:32.298204
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    assert class_ is not None

# Generated at 2022-06-22 07:32:34.677817
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL[0] == '/'

# Generated at 2022-06-22 07:32:40.564221
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE."""
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    EitbIE(url)


# Generated at 2022-06-22 07:32:42.489103
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check if EitbIE is able to create an instace
    EitbIE()


# Generated at 2022-06-22 07:32:53.800889
# Unit test for constructor of class EitbIE
def test_EitbIE():
    
    # Test error with constructor:
    # Video url is not a valid url.
    video_url = ''
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:35:51.014166
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:35:56.698952
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-22 07:36:05.089595
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE()
    # test_EitbIE.IE_NAME
    assert(test_EitbIE.IE_NAME == 'eitb.tv')
    # test_EitbIE._VALID_URL
    assert(test_EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

    # test_EitbIE._TEST

# Generated at 2022-06-22 07:36:06.586058
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE();
    assert(test);

# Generated at 2022-06-22 07:36:08.057779
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create EitbIE instance
    EitbIE()

# Generated at 2022-06-22 07:36:15.250528
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _Eitb_IE = EitbIE()
    assert _Eitb_IE is not None
    assert _Eitb_IE.ie_key() == 'eitb.tv'
    assert _Eitb_IE.age_limit is None
    assert _Eitb_IE.IE_NAME == 'eitb.tv'
    assert _Eitb_IE._VALID_URL is not None
    assert _Eitb_IE._TEST is not None
    assert _Eitb_IE._downloader is not None

# Generated at 2022-06-22 07:36:25.089840
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
        Test class EitbIE.
    """
    obj = EitbIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert obj._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert obj._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-22 07:36:37.158416
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'