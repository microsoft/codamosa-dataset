

# Generated at 2022-06-22 07:26:53.589667
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/zientzia-iberiarra/bideoa/zientzia-iberiarra-29-azaroa-2013/4104973035001/4090226280001/liburua-hitzaldia-zientzia-iberiarra-29/')

# Generated at 2022-06-22 07:27:05.313011
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:17.063869
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:21.144794
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-22 07:27:32.512533
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from __main__ import EitbIE
    valid_url = 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-urte/'
    expected_output = {
            'id': '4090227752001',
            'ext': 'mp4',
            'title': '60 minutos (Lasa y Zabala, 30 años)',
            'description': 'Programa de reportajes de actualidad.',
            'duration': 3996.76,
            'timestamp': 1381789200,
            'upload_date': '20131014',
            'tags': list,
        }
    ie = EitbIE()
    assert expected_output == ie.extract

# Generated at 2022-06-22 07:27:32.958646
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:27:39.797934
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/zuzendaritza-argia-kameraman-nola-jarri-zuzendu-argi/4104995148478/4090227754701/")
    assert len(ie._VALID_URL) > 0
    assert ie.IE_NAME == "eitb.tv"

# Generated at 2022-06-22 07:27:43.770877
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:44.673167
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-22 07:27:47.579814
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:02.820903
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:03.601001
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:28:16.554729
# Unit test for constructor of class EitbIE
def test_EitbIE():
    result = {}
    video_id = '4090227752001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/%s/lasa-y-zabala-30-anos/' % video_id
    
    # test in constructor
    # try:
    #     unit_test = EitbIE()
    # except AssertionError as e:
    #     result['error'] = 'Expected type of argument(s) : %s' % e
    #     return result

    
    # test return _real_extract method

# Generated at 2022-06-22 07:28:18.867038
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:28:21.648877
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'EitbIE'


# Generated at 2022-06-22 07:28:23.516153
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("www.eitb.tv/video/")
    assert ie.name == "eitb.tv"

# Generated at 2022-06-22 07:28:29.712593
# Unit test for constructor of class EitbIE

# Generated at 2022-06-22 07:28:33.099949
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE({})
    assert info_extractor.IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:28:37.908763
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:28:47.684070
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Initialize test values
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE()
    # Execute main function of EitbIE and check if the results are correct

# Generated at 2022-06-22 07:29:03.628887
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE"""
    assert EitbIE(None).IE_NAME == 'Eitb'
test_EitbIE()

# Generated at 2022-06-22 07:29:07.462833
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        raise AssertionError("Unit test for constructor of class EitbIE has failed")


if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-22 07:29:15.122480
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert ie._VALID_URL == EitbIE._VALID_URL


# Generated at 2022-06-22 07:29:19.731880
# Unit test for constructor of class EitbIE
def test_EitbIE():

  target_url = 'http://www.eitb.tv/eu/bideoa/15-minutos-15-minutos-2012-2013/5136351527001/5032718937001/donostiako-gastronomiako-aipu-semanaldia/'

  assert EitbIE()._match_id(target_url) is not None

# Generated at 2022-06-22 07:29:21.208985
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    return info_extractor

# Generated at 2022-06-22 07:29:25.819440
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:29:26.783439
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()

# Generated at 2022-06-22 07:29:34.514711
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert EitbIE._TEST['info_dict']['id'] == '4090227752001'
    assert EitbIE._T

# Generated at 2022-06-22 07:29:35.711880
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert  EitbIE()._TEST

# Generated at 2022-06-22 07:29:38.608313
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # EitbIE is an abstract class. Check if it raises a TypeError when instantiated.
    try:
        EitbIE()
    except TypeError:
        pass
    else:
        assert False, "EitbIE should be an abstract class."

# Generated at 2022-06-22 07:30:23.294402
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == "http://www.eitb.tv/(eu/bideoa|es/video)/[^/]+/\\d+/(\\d+)"
    assert ie._TEST['url'] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert ie._TEST['md5'] == "edf4436247185adee3ea18ce64c47998"

# Generated at 2022-06-22 07:30:25.197129
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._TEST['url'] is not None
    assert EitbIE._TEST['md5'] is not None

# Generated at 2022-06-22 07:30:35.138864
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE.test_test == '_test'
    instance = EitbIE()
    assert instance.IE_NAME == 'eitb.tv'
    assert instance.test_test() == 'test'
    assert callable(instance.test_test)
    assert instance.test_test == EitbIE._test
    assert instance.test_test != EitbIE.test_test
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:30:39.258864
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert("EitbIE" == ie.IE_NAME)
    assert("EitbIE._VALID_URL" == ie._VALID_URL)
    assert("EitbIE._TEST" == ie._TEST)
    assert("EitbIE._real_extract()" == ie._real_extract)
    assert("" == ie._real_extract(""))

# Generated at 2022-06-22 07:30:43.835873
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-22 07:30:44.349201
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:30:50.077170
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:30:59.543230
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    assert info_extractor.IE_NAME == 'eitb.tv'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:31:06.822177
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor of class EitbIE should manipulate the incoming
    URL in order to generate a video ID which can be used to
    extract video's metadata JSON.
    """
    IE_NAME='eitb.tv'
    URL='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(IE_NAME, URL)
    assert ie._match_id(URL) == '4090227752001'

# Generated at 2022-06-22 07:31:07.231984
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:32:23.473797
# Unit test for constructor of class EitbIE
def test_EitbIE():
    result = EitbIE()
    # Check for instance of class EitbIE
    assert isinstance(result, EitbIE)

# Generated at 2022-06-22 07:32:34.282297
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE = type('EitbIE', (object,), {'_download_json': test_EitbIE._download_json})
    ie = EitbIE()

    # Correct ID
    actual_result = ie._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert actual_result['id'] == '4090227752001'
    assert actual_result['title'] == '60 minutos (Lasa y Zabala, 30 años)'

    # Incorrect ID

# Generated at 2022-06-22 07:32:45.861673
# Unit test for constructor of class EitbIE
def test_EitbIE():
    config = util.get_config()
    config.debug = True
    eitb_ie = EitbIE()
    config.debug = False

    assert isinstance(eitb_ie, InfoExtractor)
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:32:50.792246
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        ie = EitbIE()
        print("EitbIE initialized")
    except:
        print("Error in initialization of class EitbIE")

# Test
if __name__ == "__main__":
    test = EitbIE()
    test.download_webpage()

# Generated at 2022-06-22 07:32:58.357082
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video = EitbIE()
    assert video._match_id("http://www.eitb.tv/eu/bideoa/Euskal-Erria/2140934/2140934/Sarri Sarri") == "2140934"
    assert video._match_id("http://www.eitb.tv/eu/bideoa/Euskal-Erria/2140934/2140934") == "2140934"
    assert video._match_id("http://www.eitb.tv/eu/bideoa/Euskal-Erria/2140934/2140934/") == "2140934"
    assert video._match_id("http://www.eitb.tv/eu/bideoa/Euskal-Erria/2140934/2140934/Sarri Sarri")

# Generated at 2022-06-22 07:33:04.893241
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for class EitbIE"""
    infoExtractor = EitbIE()
    assert infoExtractor.IE_NAME == 'eitb.tv'
    assert infoExtractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:33:06.590390
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE().to_screen()

# Generated at 2022-06-22 07:33:07.954814
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test the EitbIE class"""
    EitbIE()

# Generated at 2022-06-22 07:33:11.568233
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:33:16.521536
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    ie._real_extract(url)

# Generated at 2022-06-22 07:36:14.415417
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:36:15.191377
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-22 07:36:23.556611
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE({})
    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    url = 'http://www.eitb.tv/eu/bideoa/ikusi/63-minutos/5873524188001/'
    assert(ie._real_extract(url) is None, "Couldn't load video.")

# Generated at 2022-06-22 07:36:24.977195
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE("EITB", "EITB")
	assert ie is not None

# Generated at 2022-06-22 07:36:33.803671
# Unit test for constructor of class EitbIE
def test_EitbIE():
    constructor_test(EitbIE, [("EitbIE", "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")])
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'