

# Generated at 2022-06-22 07:26:45.247157
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    EitbIE test
    """

    # Test EitbIE
    EitbIE()

# Generated at 2022-06-22 07:26:49.483004
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:26:53.964414
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:26:57.953206
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:27:03.052200
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb= EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:13.500756
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	ie = EitbIE(url)
	assert ie.__class__ == EitbIE
	assert ie.IE_NAME == 'eitb.tv'
	assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:20.996399
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of EitbIE."""

    assert EitbIE.__name__ == 'EitbIE'
    assert EitbIE._VALID_URL.__name__ == '_VALID_URL'
    assert EitbIE._VALID_URL.pattern == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-22 07:27:26.102701
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TEST')
    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-22 07:27:38.818203
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    e._TEST = {}
    e.IE_NAME = 'EitbIE'
    e.IE_CODE = 'EitbIE'
    e._VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:40.463943
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._downloader.params['nocheckcertificate'] == 1

# Generated at 2022-06-22 07:27:48.055382
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-22 07:27:57.902862
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import json
    from wsgiref.simple_server import make_server
    from requests import get
    from urllib import quote_plus as quote

    def application(environ, start_response):
        start_response('200 OK', [('Content-Type', 'application/json')])

        params = environ['QUERY_STRING']
        if params:
            params = params.split('&')
            data = {}
            for param in params:
                datum = param.split('=')
                data[datum[0]] = quote(datum[1])
        else:
            data = environ['wsgi.input'].read()
            data = json.loads(data)


# Generated at 2022-06-22 07:28:00.245714
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        test_EitbIE()
    except:
        print("This IE doesn't work yet")
    else:
        return True

# Generated at 2022-06-22 07:28:01.147029
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-22 07:28:04.942986
# Unit test for constructor of class EitbIE
def test_EitbIE():
	print('Start test - test_EitbIE')
	print('End test - test_EitbIE')


# Generated at 2022-06-22 07:28:12.467403
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_obj = EitbIE()
    assert ie_obj.IE_NAME == 'eitb.tv'
    assert ie_obj.IE_DESC == 'eitb.tv'
    assert ie_obj._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:28:15.364831
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.IE_NAME
    ie._VALID_URL
    ie._TEST
    ie._real_extract(ie._TEST['url'])

# Generated at 2022-06-22 07:28:16.410531
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-22 07:28:19.260797
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test instance creation
    instance = EitbIE(None)
    assert isinstance(instance, EitbIE)


# Generated at 2022-06-22 07:28:26.046423
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert('eitb.tv' == EitbIE.IE_NAME)
    assert(EitbIE._VALID_URL == EitbIE._VALID_URL)
    assert('<function _real_extract at 0x107eb8ea0>' == EitbIE._real_extract.__repr__())
    assert('<class \'__main__.EitbIE\'>' == EitbIE.__repr__())


# Generated at 2022-06-22 07:28:43.025379
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # To make this test work, you must set the value of constants.py
    # (located in the root of the project) with the respective values
    # of the constants (path and name) defined in the web page.

    # an example:
    # URL_LAUNCH_CLASSIC_VIDEO_WEBPAGE = "http://www.eitb.tv/eu/bideoa/2849844/128/" 
    # CONST_CLASSIC_VIDEO_WEBPAGE = "//span[@class='titulo-video']"

    print("Test launched")
    eitb_ie = EitbIE()

    # Test: classic video webpage
    web_url = eitb_ie.CONST_CLASSIC_VIDEO_WEBPAGE
    print("\nWeb URL test: " + web_url)
   

# Generated at 2022-06-22 07:28:45.130605
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(EitbIE())._real_initialize()

# Generated at 2022-06-22 07:28:50.584407
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:28:51.709967
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:28:59.605779
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test the construction of an EitbIE instance
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Unit tests for EitbIE._real_extract()

# Generated at 2022-06-22 07:29:00.768858
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-22 07:29:07.829708
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'
    assert EitbIE._match_id(url) == video_id
    assert EitbIE._match_id('http://www.eitb.tv') == None

# Generated at 2022-06-22 07:29:16.400408
# Unit test for constructor of class EitbIE
def test_EitbIE():
  info_extractor = InfoExtractor()
  assert(info_extractor.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')) == True # Has a valid URL for this site
  assert(info_extractor.suitable('google.com')) == False # Does not have valid URL

# Generated at 2022-06-22 07:29:18.608424
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'EitbIE'

# Generated at 2022-06-22 07:29:20.057487
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    assert isinstance(a, InfoExtractor)

# Generated at 2022-06-22 07:29:38.676772
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('test', 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is not None

# Generated at 2022-06-22 07:29:43.770580
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE(None, 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    except Exception:
        assert False, "Unexpected error"
    assert True

# Generated at 2022-06-22 07:29:53.405823
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    video_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'
    assert eitbIE._match_id(video_url) == video_id
    assert eitbIE._real_extract(video_url)['id'] == video_id

# Generated at 2022-06-22 07:30:00.152321
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert inst.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:30:02.110485
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-22 07:30:03.162710
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE() # Just check if it works

# Generated at 2022-06-22 07:30:07.550449
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/eu/bideoa/101/1234')._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:30:11.149074
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e
    assert_equal(e.ie_key(), 'Eitb')
    assert_equal(e.ie_name(), 'eitb.tv')



# Generated at 2022-06-22 07:30:18.096686
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # This function checks if the class EitbIE can be created
    from ytdl.extractor import EitbIE
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-22 07:30:19.485221
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print(('INFO', EitbIE))


# Generated at 2022-06-22 07:30:52.962837
# Unit test for constructor of class EitbIE
def test_EitbIE():
    InfoExtractor.get_info(url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:30:55.627973
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:30:56.094429
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-22 07:30:57.770220
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:31:03.808511
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert (eitb_ie.IE_NAME == 'eitb.tv')
    assert (eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert (eitb_ie.__name__ == 'EitbIE')

# Generated at 2022-06-22 07:31:09.800363
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-22 07:31:10.498301
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:31:16.060269
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert(eitb.IE_NAME == 'eitb.tv')
    assert(eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Unit tests for _real_extract()

# Generated at 2022-06-22 07:31:27.429934
# Unit test for constructor of class EitbIE
def test_EitbIE():
   eitb = EitbIE()
   assert isinstance(eitb, InfoExtractor)
   assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:31:32.372898
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for constructor of class EitbIE
    # Without a URL as an argument, the constructor should return None.
    assert EitbIE() is None


# Generated at 2022-06-22 07:32:46.821087
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.IE_NAME == "eitb.tv")
    assert(EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-22 07:32:53.751536
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert 'EitbIE' in ie.IE_NAME
    assert 'www.eitb.tv' in ie.VALID_URL
    assert ie.url_result('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 'Eitb')


# Generated at 2022-06-22 07:32:57.119054
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    ie._match_id(url)

# Generated at 2022-06-22 07:33:00.694150
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        raise Exception('EitbIE constructor test failed')


# Generated at 2022-06-22 07:33:11.035416
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.IE_NAME == 'eitb.tv'
    assert obj.IE_NAME in EitbIE.ie_keywords
    assert obj.ie_keywords['eitb.tv'] is EitbIE
    assert obj.ie_keywords[EitbIE.IE_NAME] is EitbIE
    assert obj.ie_keywords.get('eitb.tv') is EitbIE
    assert obj.ie_keywords.get(EitbIE.IE_NAME) is EitbIE

# Generated at 2022-06-22 07:33:14.530509
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except Exception as e:
        print('Failed to initialize the EitbIE object')
        assert(False)



# Generated at 2022-06-22 07:33:17.229495
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE()
    assert test_EitbIE.IE_NAME == 'eitb.tv'
    assert test_EitbIE.IE_DESC == 'EITB.TV'


# Generated at 2022-06-22 07:33:18.150873
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:33:19.630088
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE


if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-22 07:33:25.596318
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:36:25.464314
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb.ie_key() == 'Eitb'
    assert eitb.ie_name() == 'Eitb'
    assert eitb.url == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-22 07:36:31.611742
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'