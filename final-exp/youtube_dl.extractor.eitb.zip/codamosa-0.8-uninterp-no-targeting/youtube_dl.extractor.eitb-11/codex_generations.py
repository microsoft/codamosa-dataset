

# Generated at 2022-06-22 07:26:44.836573
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()  # It should be possible to create an instance of EitbIE

# Generated at 2022-06-22 07:26:54.074916
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:26:59.430883
# Unit test for constructor of class EitbIE
def test_EitbIE():
    data = 'http://www.eitb.tv/eu/bideoa/tania-miranda-kanta-zure-kanta-gibelean/4204166915001/4204166915001/4105891708001/'

    ie = EitbIE(data)
    assert ie.name == 'eitb.tv'
    assert ie.url == data

# Generated at 2022-06-22 07:27:01.430347
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-22 07:27:02.562720
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass


# Generated at 2022-06-22 07:27:05.179957
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-22 07:27:16.954730
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert(eitb.IE_NAME == 'eitb.tv')
    assert(eitb.ie_key() == 'Eitb')
    assert(eitb.server=='www.eitb.tv')
    assert(eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-22 07:27:18.073664
# Unit test for constructor of class EitbIE
def test_EitbIE():
  ie = EitbIE()
  assert ie is not None

# Generated at 2022-06-22 07:27:25.125657
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test empty object
    test_empty_object = EitbIE()
    assert test_empty_object.IE_NAME == 'eitb.tv', 'Test IE_NAME is eitb.tv'
    assert test_empty_object._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)', 'Test _VALID_URL is r\'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)\''

# Test for extract function of class EitbIE

# Generated at 2022-06-22 07:27:26.883014
# Unit test for constructor of class EitbIE
def test_EitbIE():
	obj = EitbIE()

# Generated at 2022-06-22 07:27:44.707416
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:27:47.077443
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    # Check that the constructor returns a valid object (not None)
    assert(e != None)
    assert(e.IE_NAME == 'eitb.tv')


# Generated at 2022-06-22 07:27:49.669711
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for constructor of class EitbIE
    """
    eie = EitbIE()
    assert isinstance(eie, InfoExtractor)

# Generated at 2022-06-22 07:27:52.838360
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-22 07:27:57.516913
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    instance = EitbIE()
    instance._match_id(url)
    instance._real_extract(url)

# Generated at 2022-06-22 07:27:59.909162
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        print("Error constructing EitbIE")
        return False
    return True

# Generated at 2022-06-22 07:28:00.785718
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()

# Generated at 2022-06-22 07:28:14.619921
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb_test = EitbIE()
	assert eitb_test.IE_NAME == 'eitb.tv'
	assert eitb_test.ie_key() == 'Eitb'
	assert eitb_test.extract(url='eitb.tv', ie_key='') == None
	assert eitb_test._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	assert eitb_test._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-22 07:28:17.311705
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert type(EitbIE) is type
    assert type(eitbIE) is type
    assert type(EitbIE()) is EitbIE
    assert type(eitbIE()) is EitbIE

# Generated at 2022-06-22 07:28:23.400357
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor

    # Test that EitbIE has been registered
    available_IEs = [ie.ie_key() for ie in InfoExtractor.get_classes() if issubclass(ie, InfoExtractor)]
    assert "EitbIE" in available_IEs

# Test that EitbIE can be instanciated

# Generated at 2022-06-22 07:28:38.405642
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_obj = EitbIE()
    assert test_obj.IE_NAME == "eitb.tv"



# Generated at 2022-06-22 07:28:43.623981
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except Exception as err:
        raise
        return False
    return True

# Generated at 2022-06-22 07:28:45.580707
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instantiate_test(EitbIE, [], {'id': '4090227752001'}, expected_warnings=['HLS'])

# Generated at 2022-06-22 07:28:46.516634
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:28:52.065626
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'



# Generated at 2022-06-22 07:28:55.196009
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test eitb.tv site. Check if the constructor of the class return something.
    info = EitbIE()
    assert info is not None


# Generated at 2022-06-22 07:29:07.518649
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert_equal(ie.IE_NAME, 'eitb.tv')
    assert_equal(ie._VALID_URL, r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert_equal(ie._TEST['url'], 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert_equal(ie._TEST['md5'], 'edf4436247185adee3ea18ce64c47998')

# Generated at 2022-06-22 07:29:10.024936
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()

# Generated at 2022-06-22 07:29:15.211227
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.name == 'eitb.tv'

# Generated at 2022-06-22 07:29:20.751329
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_object = EitbIE()
    instance_id = test_object._match_id('http://www.eitb.tv/eu/bideoa/zuzendaritza-soilik/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert instance_id == '4090227752001'

# Generated at 2022-06-22 07:29:48.798991
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL
    assert EitbIE._TEST


# Generated at 2022-06-22 07:29:49.608049
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), EitbIE)

# Generated at 2022-06-22 07:29:51.109296
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # instantiate EitbIE
    EitbIE()

# Generated at 2022-06-22 07:29:54.704412
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert (EitbIE() != None)
    except AssertionError as e:
        print ("Test test_EitbIE failed. Exception: " + str(e) + "\n")


# Generated at 2022-06-22 07:30:05.834599
# Unit test for constructor of class EitbIE
def test_EitbIE():
    #Test for constructor of class EitbIE
    eitbie = EitbIE() # invoke the constructor of class EitbIE
    assert eitbie.IE_NAME == "eitb.tv" # test the basic function of constructor function
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)' # test the basic function of constructor function
    assert eitbie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/' # test the basic

# Generated at 2022-06-22 07:30:14.593308
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test with only required args
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

    # Test with all args
    EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', ie='EitbIE', ie_key='EitbIE', ie_test=True)

# Generated at 2022-06-22 07:30:15.433781
# Unit test for constructor of class EitbIE
def test_EitbIE():
  assert EitbIE("") is not None

# Generated at 2022-06-22 07:30:23.638509
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert isinstance(inst, InfoExtractor)
    assert inst.IE_NAME == 'eitb.tv'
    assert inst._VALID_URL == 'http://www\.eitb\.tv/(eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:30:34.782113
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    Test the constructor of EitbIE
    '''
    ie_eitb = EitbIE()
    assert ie_eitb.IE_NAME == 'eitb.tv'
    assert ie_eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:30:35.699979
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-22 07:31:41.288677
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-22 07:31:42.022602
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:31:43.537959
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Check for NULL object
    assert EitbIE(None) == None


# Generated at 2022-06-22 07:31:55.056507
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('www.eitb.tv/eu/bideoa/zuzendaria/urriak-16/enero-16/').IE_NAME == 'EitbIE'
    assert EitbIE('www.eitb.tv/eu/bideoa/zuzendaria/urriak-16/enero-16/')._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:32:05.390007
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-22 07:32:06.031849
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:32:15.802810
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for a typical Eitb video
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == test_url
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'


# Generated at 2022-06-22 07:32:27.163671
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb_ie.name == 'EitbIE'
    assert eitb_ie.ie_key() == 'eitb.tv'
    assert eitb_ie.valid_url('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-22 07:32:31.881614
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # In this test we check if EitbIE is properly constructed
    # First we construct an EitbIE object
    eitbie = EitbIE()
    # Then we use assertEqual to check if the IE_NAME is the same as the one in the class
    assertEqual(eitbie.IE_NAME, 'eitb.tv')

# Generated at 2022-06-22 07:32:43.800503
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-22 07:35:40.273467
# Unit test for constructor of class EitbIE
def test_EitbIE():
	test_obj = EitbIE()
	assert test_obj.IE_NAME == 'eitb.tv'
	assert test_obj._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:35:48.058090
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoak/datorren-asteko-gaurko-bonbilla-datorren-asteko-gaurko-bonbilla-datorren-asteko-gaurko-bonbilla/4131249110001/4121089500001/bonbilla-abenduan-bideoa/4124098120001/"
    test_EitbIE = EitbIE(url)
    test_EitbIE._match_id()

# Generated at 2022-06-22 07:35:56.948520
# Unit test for constructor of class EitbIE
def test_EitbIE():
    the_EitbIE = EitbIE()
    the_EitbIE.IE_NAME = 'eitb.tv'
    the_EitbIE._VALID_URL = r'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test = the_EitbIE.url_result(the_EitbIE._VALID_URL, expected=True)
    assert(test.id == '4090227752001')
    assert(test.title == '60 minutos (Lasa y Zabala, 30 años)')
    assert(test.description == 'Programa de reportajes de actualidad.')

# Generated at 2022-06-22 07:35:57.653441
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:36:04.495117
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of the class EitbIE"""
    from . import EitbIE
    url = 'http://eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video = EitbIE()
    video.extract(url)

# Generated at 2022-06-22 07:36:08.783769
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:36:19.557385
# Unit test for constructor of class EitbIE

# Generated at 2022-06-22 07:36:25.936324
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-22 07:36:26.344930
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-22 07:36:27.506788
# Unit test for constructor of class EitbIE
def test_EitbIE():

    EitbIE()