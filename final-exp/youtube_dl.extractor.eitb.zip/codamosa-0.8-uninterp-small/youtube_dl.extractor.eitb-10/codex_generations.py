

# Generated at 2022-06-26 11:49:51.266842
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0.IE_NAME == 'eitb.tv'
    assert eitb_i_e_0._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:49:52.988458
# Unit test for constructor of class EitbIE
def test_EitbIE():

    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:49:59.874455
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/zuzenean/sari-goxoa-haria/id/1045028/'
    eitb_i_e = EitbIE()
    test_case = eitb_i_e.url_result(url)

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-26 11:50:01.285533
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-26 11:50:11.923898
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_0 = EitbIE()
    assert eitb_i_e_0.IE_NAME == 'eitb.tv'
    assert eitb_i_e_0._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:21.723539
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance0 = EitbIE()
    assert(instance0._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:50:26.372006
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == "eitb.tv"
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:50:28.861376
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert test_EitbIE.__name__ == EitbIE.__name__
    assert EitbIE.__name__ == 'EitbIE'

# Generated at 2022-06-26 11:50:30.107085
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()


# Generated at 2022-06-26 11:50:31.718310
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:43.372601
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing EitbIE")
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE()._real_extract(url)


# Generated at 2022-06-26 11:50:45.803622
# Unit test for constructor of class EitbIE
def test_EitbIE():
	result = unicode(EitbIE)
	assert result == u'<class \'__main__.EitbIE\'>'

# Generated at 2022-06-26 11:50:51.629922
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert(eitb.IE_NAME == 'eitb.tv')
    assert(eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:50:54.320375
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_eitb = EitbIE()
    assert(isinstance(ie_eitb, EitbIE))

# Generated at 2022-06-26 11:50:58.332394
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('eitb.tv')
    assert(ie._VALID_URL == 'http://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:51:05.065802
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # Test valid URL
    test = ie.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert set(test.keys()) == set(['id', 'title', 'description', 'thumbnail', 'duration', 'timestamp', 'tags', 'formats'])
    assert test['id'] == '4090227752001'
    assert test['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert test['description'] == 'Programa de reportajes de actualidad.'

# Generated at 2022-06-26 11:51:16.954677
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitb_ie.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') is True
    assert eitb_ie.suitable('http://www.eitb.tv/eu/bideoa/urriak-26/4104994306001/') is False

# Generated at 2022-06-26 11:51:20.647788
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Positive test
	eitb = EitbIE()
	# Negative test with erroneous URL
	wrong_eitb = EitbIE()
	wrong_eitb._VALID_URL = 'https?://(?:www\.)?[^/]+/[^/]+/'

# Generated at 2022-06-26 11:51:20.993694
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:51:21.493133
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # TODO: write some tests
    assert True

# Generated at 2022-06-26 11:51:40.257829
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create a valid url for EitbIE.ie_key
    url = EitbIE._VALID_URL
    # Call instance of EitbIE
    ie = EitbIE(url)
    # Test if the ie_key of EitbIE is valid
    assert ie.ie_key() == 'Eitb'

# Generated at 2022-06-26 11:51:44.790403
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.suitable('http://www.eitb.tv/eu/bideoa/irratia/30-minutos/4124157960001/')

# Generated at 2022-06-26 11:51:47.188554
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Make sure the constructor doesn't throw an error
    EitbIE()

# Generated at 2022-06-26 11:51:55.473135
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:58.204268
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-26 11:52:05.263497
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Valid constructor
    eitb = EitbIE('foo', 'http://bar')
    assert eitb.ie_key() == 'Eitb'
    assert eitb.ie_url() == 'http://www.eitb.tv/'
    assert eitb.video_id == 'foo'
    assert eitb._VALID_URL == 'http://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)'

# Generated at 2022-06-26 11:52:17.663414
# Unit test for constructor of class EitbIE
def test_EitbIE():
   d = EitbIE()
   assert d.IE_NAME == 'eitb.tv'
   assert d._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:20.679027
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:52:23.575786
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIeObj = EitbIE()
    print(eitbIeObj)


# Generated at 2022-06-26 11:52:24.601796
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-26 11:52:53.036982
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        assert False, 'Cannot create instance of class EitbIE'


# Generated at 2022-06-26 11:52:54.240298
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Get some videos
    EitbIE()._real_extract(EitbIE._TEST['url'])

# Generated at 2022-06-26 11:52:59.657449
# Unit test for constructor of class EitbIE

# Generated at 2022-06-26 11:53:03.680405
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE("www.eitb.tv")
    assert eitbIE.IE_NAME == "eitb.tv"

# Generated at 2022-06-26 11:53:05.826213
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None
    

# Generated at 2022-06-26 11:53:19.028529
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import unittest


# Generated at 2022-06-26 11:53:24.932433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.ie_key() == 'eitb.tv'
    assert eitbIE.ie_name() == 'eitb.tv'
    assert eitbIE.init() == None

# Generated at 2022-06-26 11:53:27.353490
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:53:28.697428
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE, InfoExtractor)

# Generated at 2022-06-26 11:53:37.187155
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    ie.download('4090227752001')
    ie.extract('4090227752001')

# Generated at 2022-06-26 11:54:45.685019
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test import *
    construct_test({EitbIE: [EitbIE._VALID_URL]})

# Generated at 2022-06-26 11:54:53.503374
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:06.719985
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_ie = EitbIE()
    video = eitb_ie.extract(url)
    assert video['id'] == '4090227752001'
    assert '60 minutos (Lasa y Zabala, 30 años)' == video['title']
    # Asserts for duration, timestamp and thumbnail
    assert 3996.76 == video['duration']
    assert 1381789200 == video['timestamp']

# Generated at 2022-06-26 11:55:08.699106
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert isinstance( EitbIE(), EitbIE)

# Generated at 2022-06-26 11:55:12.128433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_Eitb = EitbIE()
    assert(len(IE_Eitb.IE_NAME) > 0)

# Generated at 2022-06-26 11:55:16.107737
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-26 11:55:26.732363
# Unit test for constructor of class EitbIE
def test_EitbIE():
  ie = EitbIE()
  assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
  assert ie._TEST.get('url') == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
  assert ie._TEST.get('md5') == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-26 11:55:32.129308
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:55:37.127485
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Unit test for constructor of class EitbIE

    # Check that the EitbIE works with 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/' link
    EitbIE(EitbIE._VALID_URL)


# Generated at 2022-06-26 11:55:39.413058
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb is not None

# Generated at 2022-06-26 11:58:28.613381
# Unit test for constructor of class EitbIE

# Generated at 2022-06-26 11:58:31.294000
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE().extract('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4114923172001/lasa-y-zabala-30-anos/')



# Generated at 2022-06-26 11:58:42.167241
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    url2 = 'http://www.eitb.tv/eu/bideoa/maketa-sagarrak/4111859065001/4110600714001/maketa-sagarrak-s01-ep02/'
    instance = EitbIE(False)
    assert instance.suitable(url) == True
    assert instance.suitable(url2) == True




# Generated at 2022-06-26 11:58:45.610713
# Unit test for constructor of class EitbIE
def test_EitbIE():
    myclass = EitbIE()
    print("Test 1")
    print("EitbIE")
    print("\n")

# Generated at 2022-06-26 11:58:48.103436
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE('', '')
    assert isinstance(i, InfoExtractor)

# Generated at 2022-06-26 11:58:54.727727
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('test', 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    instance.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    instance.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:58:59.173342
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL #Check if is the same REGEX


# Generated at 2022-06-26 11:59:00.599291
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE({})

# Generated at 2022-06-26 11:59:04.656862
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    instance1 = class_()
    assert instance1.ie_key() == 'EitbIE'
    assert instance1.IE_NAME == 'eitb.tv'
    assert instance1._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert instance1._downloader is not None

# Generated at 2022-06-26 11:59:14.687580
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert(instance.ie_key() == 'eitb.tv')
    assert(instance.ie_name() == 'eitb.tv')
    assert(instance.valid_url('http://www.eitb.tv/eu/bideoa/media/media/sail-bidaia/4927501144001/4927498010001/'))
    assert(instance.valid_url('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/'))
    assert(not instance.valid_url('http://www.eitb.tv/'))