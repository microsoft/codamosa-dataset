

# Generated at 2022-06-26 11:49:55.959901
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Try removing the os.chdir(here) and run the test. If it runs. The test fails.
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    os.chdir(here)
    test_case_0()

# Generated at 2022-06-26 11:49:58.021753
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(test_case_0(), EitbIE)

# Generated at 2022-06-26 11:49:59.454285
# Unit test for constructor of class EitbIE
def test_EitbIE():
    if __name__ == "__main__":
        test_EitbIE()

# Generated at 2022-06-26 11:50:02.469015
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('Testing constructor for class: EitbIE')
    test_case_0()
    print('Testing completed for class: EitbIE')
    print(' ')


# Generated at 2022-06-26 11:50:03.458676
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case_0()

# Generated at 2022-06-26 11:50:04.504946
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case_0()

# Generated at 2022-06-26 11:50:05.930384
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert callable(EitbIE)



# Generated at 2022-06-26 11:50:14.893864
# Unit test for constructor of class EitbIE
def test_EitbIE():
    int_0 = None
    eitb_i_e_0 = EitbIE(int_0)
    # print eitb_i_e_0.IE_NAME
    eitb_i_e_0.add_ie()
    eitb_i_e_0._extract_m3u8_formats()
    eitb_i_e_0._extract_f4m_formats()
    eitb_i_e_0._get_info_dict()
    eitb_i_e_0._download_json()
    eitb_i_e_0._get_api_url()
    eitb_i_e_0._get_query()
    eitb_i_e_0._get_video_id()
    eitb_i_

# Generated at 2022-06-26 11:50:19.171849
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

test_case_0()

# Generated at 2022-06-26 11:50:20.772462
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    assert ie.ie_key() == 'Eitb'

# Generated at 2022-06-26 11:50:29.722908
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0

# Generated at 2022-06-26 11:50:31.356333
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert issubclass(EitbIE, InfoExtractor)

# Generated at 2022-06-26 11:50:32.209878
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    assert isinstance(eitb_i_e, object)


# Generated at 2022-06-26 11:50:34.122401
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        eitb_i_e = EitbIE()
    except:
        assert False


# Generated at 2022-06-26 11:50:35.688547
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    assert eitb_i_e is not None


# Generated at 2022-06-26 11:50:39.995659
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:50:41.939781
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
# Test case for EitbIE._real_extract()

# Generated at 2022-06-26 11:50:49.315341
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0.IE_NAME == 'eitb.tv'
    assert eitb_i_e_0._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_i_e_0.JSON_LD_KEY == '@type'


# Generated at 2022-06-26 11:50:50.388674
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case_0()

# Generated at 2022-06-26 11:50:53.086879
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE().IE_NAME) == 'eitb.tv'

# Generated at 2022-06-26 11:51:03.303968
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()

    # check class constructor
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:51:10.292648
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    ie = eitbie
    ie.IE_NAME
    ie.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    import os
    os.system('pause')

# Generated at 2022-06-26 11:51:13.984222
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert len(ie.IE_NAME) > 0
    assert len(ie._VALID_URL) > 0
    assert len(ie._TEST) > 0
    return True


# Generated at 2022-06-26 11:51:16.169677
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()


# Generated at 2022-06-26 11:51:17.495253
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:51:18.909473
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eie = EitbIE()
    assert isinstance(eie, InfoExtractor)

# Generated at 2022-06-26 11:51:26.977074
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        import yaml
        yaml.load('EitbIE')
    except ImportError:
        raise ImportError("yaml not available on this system")

    #assert isinstance(eitb, EitbIE) is True
    #assert isinstance(EitbIE.IE_NAME, basestring) is True
    #assert isinstance(EitbIE._VALID_URL, basestring) is True
    #assert isinstance(EitbIE._TEST, dict) is True
    #assert isinstance(EitbIE._TEST['url'], basestring) is True
    #assert isinstance(EitbIE._TEST['md5'], basestring) is True
    #assert isinstance(EitbIE._TEST['info_dict'], dict) is True
    #assert

# Generated at 2022-06-26 11:51:28.057560
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie._VALID_URL

# Generated at 2022-06-26 11:51:28.919950
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    return ie

# Generated at 2022-06-26 11:51:30.539555
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE();
    return ie.get_test()

# Generated at 2022-06-26 11:51:50.251834
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == EitbIE.IE_NAME
    assert ie._VALID_URL == EitbIE._VALID_URL
    assert ie._TEST == EitbIE._TEST

# Generated at 2022-06-26 11:51:53.261552
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:55.948195
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE"""
    assert EitbIE is not None

# Generated at 2022-06-26 11:52:03.090056
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE({'url': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'})
    assert ie.valid_url(ie.url)



# Generated at 2022-06-26 11:52:16.571045
# Unit test for constructor of class EitbIE

# Generated at 2022-06-26 11:52:23.436594
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:24.861869
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test the constructor of class EitbIE"""
    EitbIE()

# Generated at 2022-06-26 11:52:25.683407
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:52:36.749830
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert info_extractor.IE_NAME == 'eitb.tv'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:37.756054
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:53:20.848647
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(InfoExtractor(),"http://www.eitb.tv/eu/bideoa/60_minutok/4104995148001/4090227752001/lasa_eta_zabala_30_urte/", "http://www.eitb.tv/eu/bideoa/60_minutok/4104995148001/4090227752001/lasa_eta_zabala_30_urte/")._match_id("http://www.eitb.tv/eu/bideoa/60_minutok/4104995148001/4090227752001/lasa_eta_zabala_30_urte/") == "4090227752001"

# Generated at 2022-06-26 11:53:31.148330
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert IE.IE_NAME == 'eitb.tv'
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:53:33.216847
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        assert False
    assert True

# Generated at 2022-06-26 11:53:37.051167
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv')
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:53:38.011917
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance

# Generated at 2022-06-26 11:53:48.968754
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    test_EitbIE._TEST.update({"url":"http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"})
    assert eitb_ie._download_json.__doc__ == "Download a JSON resource given its URL and return the object."
    assert eitb_ie._match_id.__doc__ == "Return the video id from url."
    assert eitb_ie._real_extract.__doc__ == "Extract video information."

# Generated at 2022-06-26 11:53:56.582609
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import EitbIE
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    assert ie.constructor_test() == True

# Generated at 2022-06-26 11:53:57.204309
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_test = EitbIE()

# Generated at 2022-06-26 11:53:59.175764
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-26 11:54:01.656468
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-26 11:55:08.530193
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:55:18.229996
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == "eitb.tv"
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:21.355262
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, 'IE_NAME')

# Generated at 2022-06-26 11:55:25.816153
# Unit test for constructor of class EitbIE
def test_EitbIE():
	myEitbIE = EitbIE()
	print ('Unit test for class EitbIE')
	print ('test_EitbIE')
	assert myEitbIE != None

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-26 11:55:37.220168
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'
    IE = EitbIE()
    assert IE.IE_NAME == 'eitb.tv'
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert IE._TEST['url'] == url
    assert IE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
   

# Generated at 2022-06-26 11:55:38.785188
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-26 11:55:47.487118
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    result = ie.extract(url)
    assert result['id'] == '4090227752001'
    assert result['ext'] == 'mp4'
    assert result['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert result['description'] == 'Programa de reportajes de actualidad.'
    assert result['duration'] == 3996.76
    assert result['timestamp'] == 1381789200
    assert result['upload_date'] == '20131014'

# Generated at 2022-06-26 11:55:54.685219
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/txirrindulari-aren-azken-txapelketa/4104996427001/4090230905001/lasa-et-zabala-txapelketa-txirrindulari-aren-azken-txapelketa-4-txapelketa/')

# Generated at 2022-06-26 11:56:02.437642
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.ie_key() == 'Eitb'
    assert EitbIE.ie_key() == EitbIE.ie_key()[::-1]
    assert EitbIE().ie_key() == EitbIE.ie_key()
    assert EitbIE.ie_key() == 'Eitb'


# Generated at 2022-06-26 11:56:06.316410
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/"
    eitbie = EitbIE()
    assert eitbie is not None

# Generated at 2022-06-26 11:59:04.295964
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:59:15.329112
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:21.120099
# Unit test for constructor of class EitbIE
def test_EitbIE():

    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:27.809676
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert EitbIE._TEST['info_dict']['id'] == '4090227752001'
    assert EitbIE._T

# Generated at 2022-06-26 11:59:34.152754
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE().IE_NAME == 'eitb.tv')
    assert(EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:59:38.056827
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import EitbIE
    instance = EitbIE()
    assert isinstance(instance, EitbIE)

# Generated at 2022-06-26 11:59:42.642906
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE().extract('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')