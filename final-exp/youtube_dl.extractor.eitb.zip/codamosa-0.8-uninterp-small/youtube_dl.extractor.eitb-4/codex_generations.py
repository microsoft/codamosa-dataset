

# Generated at 2022-06-26 11:49:54.032579
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:49:56.260447
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0 is not None


# Generated at 2022-06-26 11:49:58.359200
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() is not None


# Generated at 2022-06-26 11:50:00.598520
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert 0 == 0

if __name__ == '__main__':
    test_case_0()
    test_EitbIE()

# Generated at 2022-06-26 11:50:11.332685
# Unit test for constructor of class EitbIE

# Generated at 2022-06-26 11:50:12.222167
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0



# Generated at 2022-06-26 11:50:13.827371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    assert issubclass(EitbIE, InfoExtractor)


# Generated at 2022-06-26 11:50:14.802598
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case_0()

# Generated at 2022-06-26 11:50:16.334425
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(
        EitbIE(),
        InfoExtractor)

# Generated at 2022-06-26 11:50:18.101460
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:32.593668
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    video_id = '4104995148001'
    url = "http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/"
    eitb_ie = EitbIE()

# Generated at 2022-06-26 11:50:36.672128
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test for constructor of the class EitbIE.
    """
    from .common import InfoExtractor
    from ..utils import (
        float_or_none,
        int_or_none,
        parse_iso8601,
        sanitized_Request,
    )
    eitb = EitbIE()


# Generated at 2022-06-26 11:50:38.354105
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:50:42.489212
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instanciate all classes of unit test
    eitb = EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-26 11:50:43.963349
# Unit test for constructor of class EitbIE
def test_EitbIE():
    check_valid_IE(EitbIE.ie_key())

# Generated at 2022-06-26 11:50:56.568673
# Unit test for constructor of class EitbIE
def test_EitbIE():
    tst_edi = EitbIE()
    assert tst_edi.IE_NAME == 'eitb.tv'
    assert tst_edi._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert tst_edi._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert tst_edi._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert isinstance

# Generated at 2022-06-26 11:50:58.276939
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:50:59.871215
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()._real_extract(EitbIE._TEST['url'])

# Generated at 2022-06-26 11:51:07.082052
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.ie_key() == 'eitb.tv'

# Generated at 2022-06-26 11:51:15.985528
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test that given url is valid for this module
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    # Test that class EitbIE exists in the module
    assert(EitbIE is not None)
    # Test that the class EitbIE extract the proper content and that it's not empty
    assert(EitbIE()._real_extract(url) != None)

# Generated at 2022-06-26 11:51:40.393956
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert type(ie) == EitbIE
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.__doc__ == 'Euskal Irrati Telebista (EITB) - TV and radio from Basque Country'

# Generated at 2022-06-26 11:51:42.028819
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()._real_initialize()

# Generated at 2022-06-26 11:51:54.019610
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert eitb_ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert eitb_ie._TEST['info_dict']['id'] == '4090227752001'
    assert eitb_ie._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 11:52:05.755519
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb_ie = EitbIE()
	assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
	assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:52:15.713875
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie_obj = EitbIE()
    assert eitbie_obj.ie_key() == 'eitb.tv'
    assert eitbie_obj.ie_name() == EitbIE.IE_NAME
    assert eitbie_obj.ie_id() == 'eitb.tv'
    assert eitbie_obj._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:52:16.646299
# Unit test for constructor of class EitbIE
def test_EitbIE():
        IE = EitbIE();

# Generated at 2022-06-26 11:52:23.502350
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:34.917432
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    t = ie._real_extract(url)
    assert t.get('title', False)
    assert t.get('formats', False)
    assert t.get('tags', False)
    assert t.get('thumbnail', False)
    assert t.get('description', False)

# Generated at 2022-06-26 11:52:38.020734
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    info_extractor.IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:52:39.046331
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:53:17.542742
# Unit test for constructor of class EitbIE
def test_EitbIE():
        ie = EitbIE()

        assert ie.IE_NAME == "eitb.tv"
        assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
        assert dict == type(ie._TEST)

# Generated at 2022-06-26 11:53:20.421413
# Unit test for constructor of class EitbIE
def test_EitbIE():
	print('Testing EitbIE')
	EitbIE(None)
	print('OK')


# Generated at 2022-06-26 11:53:30.977637
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:53:38.365086
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from ..utils import parse_iso8601
    from math import ceil
    IE_NAME = 'eitb.tv'
    _VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:53:40.849512
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME
    assert ie._VALID_URL

# Generated at 2022-06-26 11:53:51.236958
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test for constructor of class EitbIE"""
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE.IE_DESC == 'eitb.tv'
    assert EitbIE._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"

# Generated at 2022-06-26 11:54:01.599113
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:54:06.144498
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://eitb.tv/eu/bideoa/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:54:14.819851
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

    info_dict = eitb._extract_video("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")


    # It should have the correct id
    assert info_dict['id'] == '4090227752001'

    # It should have the correct title
    assert info_dict['title'] == '60 minutos (Lasa y Zabala, 30 años)'

    # It should have the correct description
    assert info_dict['description'] == 'Programa de reportajes de actualidad.'

    # It should have the correct duration
    assert info_dict['duration'] == 3996.76

# Generated at 2022-06-26 11:54:28.783853
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.ie_key() == 'eitb.tv'
    assert ie.ie_name() == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:37.971254
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test with a valid url
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert(isinstance(EitbIE(test_url), EitbIE))
    # Test with an invalid url
    test_url = 'Non valid URL'
    try:
        EitbIE(test_url)
    except Exception:
        assert(True)
    else:
        assert(False)

# Unit tests for the _real_extract() method

# Generated at 2022-06-26 11:55:44.724282
# Unit test for constructor of class EitbIE
def test_EitbIE():    
    eitb_test = EitbIE()
    assert(eitb_test.IE_NAME == 'eitb.tv')
    assert(eitb_test._VALID_URL == \
        r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-26 11:55:49.970931
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/bideoa-bizkaia/4104995148001/4104995148001/'
    EitbIE(url)

# Generated at 2022-06-26 11:55:55.653737
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert (eitbIE.IE_NAME == "eitb.tv")
    assert (eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-26 11:55:59.101778
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie_instance = EitbIE()
    assert ie_instance.IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:56:02.503260
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()
    #assertEqual(True, True) #assertEqual(first, second, msg=None)


# Generated at 2022-06-26 11:56:07.328131
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitb_ie = EitbIE()
    test = eitb_ie.suitable(url)
    assert test == True


# Generated at 2022-06-26 11:56:13.909550
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:56:19.840415
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test unit of the constructor of class EitbIE."""
    # Expected values
    # To get the new values is necessary to see the constructor of the class

# Generated at 2022-06-26 11:56:22.680999
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test no errors were raised during construction.
    """
    ie = EitbIE()

# Generated at 2022-06-26 11:59:11.439020
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()
	assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:18.314597
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == "EitbIE"
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:23.248500
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:59:26.232378
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Test the constructor of class FeedManager """
    instance = EitbIE()
    print(instance)

# Generated at 2022-06-26 11:59:32.886544
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """ Unit test for constructor of class EitbIE """

    # Test initialization of EitbIE
    test_eitb_ie = EitbIE()

    # Test if EitbIE class is subclass of InfoExtractor
    assert isinstance(test_eitb_ie, InfoExtractor)

# Generated at 2022-06-26 11:59:39.985704
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    assert test.IE_NAME == 'eitb.tv'
    assert re.match(test._VALID_URL, 'http://www.eitb.tv/eu/bideoa/mundua-maitea-kuriositateak/4100397215001/4100382604001/santa-agueda-eta-azaroa-zuzenduko-du-kontzertuko-izarrak/')
    assert test._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'