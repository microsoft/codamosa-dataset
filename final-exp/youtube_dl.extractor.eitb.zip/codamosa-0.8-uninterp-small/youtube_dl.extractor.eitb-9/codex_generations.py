

# Generated at 2022-06-26 11:49:48.280218
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance0 = EitbIE()

# Generated at 2022-06-26 11:49:48.722592
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-26 11:49:49.881353
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:49:50.895377
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:49:53.632102
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (
         'EitbIE' in globals()
    ), "You should declare EitbIE as global before its definition."



# Generated at 2022-06-26 11:49:54.198651
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:49:56.302392
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE._VALID_URL)


# Generated at 2022-06-26 11:50:07.505710
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0.IE_NAME == 'eitb.tv'
    assert eitb_i_e_0._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:09.627022
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

# Simple unit test for class EitbIE

# Generated at 2022-06-26 11:50:16.438558
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:25.191140
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie != None

# Generated at 2022-06-26 11:50:29.376422
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:50:29.945240
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:50:37.043110
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # first, instantiate the EitbIE class with a valid url
    eitbie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    # then run EitbIE._real_extract method
    eitbie._real_extract(eitbie.url)

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-26 11:50:38.861514
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.ie_key() == 'Eitb'


# Generated at 2022-06-26 11:50:49.733443
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:00.727756
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("test_EitbIE")
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    eie = EitbIE(url)
    assert(eie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:51:11.697373
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    print("Unit test for constructor of class EitbIE")
    print("type ie",type(ie))
    print("expected type: <class 'youtube_dl.extractor.eitb.EitbIE'>")
    print("Type d'ie:",ie.IE_NAME)
    print("Expected type:",ie._VALID_URL)
# Test for the real extraction

# Generated at 2022-06-26 11:51:13.886086
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:51:20.291613
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Simulate that it is an EITB URL.
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos/4083237522001/4090227752001/lasa-y-zabala-30-anos/'
    info = EitbIE._real_extract(EitbIE(),url)
    assert info.get('id')=='4090227752001'

# Generated at 2022-06-26 11:51:40.560348
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Just an example from website
    url = 'http://www.eitb.tv/eu/bideoak/eskualdeko-lanbideak/saioak/gizonak-hiru-ez/4104995150381/4104995150381/4104995150381/'
    # Standalone
    assert (EitbIE().suitable(url) == True)
    # Unit test
    assert (IE._create_from_url(url) == EitbIE)

# Generated at 2022-06-26 11:51:43.072158
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:51:44.510892
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-26 11:51:54.803552
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE("EitbIE")
	url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
	result = ie._real_extract(url)
	assert result['id'] == "4090227752001"
	assert result['ext'] == "mp4"
	assert result['title'] == "60 minutos (Lasa y Zabala, 30 años)"
	assert result['duration'] == 3996.76
	assert result['timestamp'] == 1381789200
	assert result['upload_date'] == "20131014"

# Generated at 2022-06-26 11:51:58.889582
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:01.276500
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:52:02.823428
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')

# Generated at 2022-06-26 11:52:16.414391
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert hasattr(IE, "report_warning")
    assert hasattr(IE, "extract")
    assert hasattr(IE, "suitable")
    assert hasattr(IE, "gen_extractors")
    assert hasattr(IE, "_real_extract")
    assert hasattr(IE, "IE_DESC")
    assert hasattr(IE, "IE_NAME")
    assert hasattr(IE, "IE_VERSION")
    assert hasattr(IE, "VALID_URL")
    assert hasattr(IE, "BRANDING_KEY")
    assert hasattr(IE, "_WORKING")
    assert hasattr(IE, "_GEO_BYPASS")
    assert hasattr(IE, "_GEO_COUNTRIES")
    assert hasattr(IE, "_downloader")

# Generated at 2022-06-26 11:52:18.371330
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE().get_info(0)['id'] == 0

# Generated at 2022-06-26 11:52:20.375088
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    return

# Generated at 2022-06-26 11:52:58.052209
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.ie_key() == 'eitb.tv'
    assert obj.ie_name() == 'eitb.tv'
    assert obj.valid_url('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert not obj.valid_url('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos')

# Generated at 2022-06-26 11:53:01.093997
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        raise AssertionError("Failed to initialise class EitbIE")

# Generated at 2022-06-26 11:53:05.059891
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance.IE_NAME == "eitb.tv"

# Generated at 2022-06-26 11:53:11.262294
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    video = ie.extract('video', '60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert video["id"] == "4090227752001"
    assert video["title"] == "60 minutos (Lasa y Zabala, 30 años)"
    assert video["description"] == "Programa de reportajes de actualidad."
    assert video["duration"] == 3996.76

# Generated at 2022-06-26 11:53:20.764035
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from urlparse import urlparse
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'
    info = EitbIE()._real_extract(url)
    assert info['id'] == video_id
    assert info['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert info['duration'] == 3996.76
    media = info['formats']
    for i in media:
        assert urlparse(i['url']).query.find('hdnts=') != -1

# Generated at 2022-06-26 11:53:23.074031
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL



# Generated at 2022-06-26 11:53:24.501812
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-26 11:53:27.082245
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:53:39.456909
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:53:42.641722
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.ie_key() == 'eitb.tv'


# Generated at 2022-06-26 11:54:52.697975
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.__name__ == 'EitbIE'

# Generated at 2022-06-26 11:54:55.404023
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:55:02.597305
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test constructor
    """
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-26 11:55:09.208151
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test that the extractor can handle a real world url
    url_real = 'http://www.eitb.tv/eu/bideoa/kolmanda-back/videoreportarra/5639056481001/'

    # Test that the extractor can handle a test url
    url_test = 'http://www.eitb.tv/eu/bideoa/kolmanda-back/videoreportarra/5639056481001/'

    assert (EitbIE._VALID_URL == EitbIE._match_id(url_real))
    assert (EitbIE._VALID_URL == EitbIE._match_id(url_test))
    return

# Generated at 2022-06-26 11:55:15.688458
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_instance = EitbIE()
    assert(test_instance.IE_NAME == 'eitb.tv')
    assert(test_instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:55:17.572737
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # TODO: Add test for EitbIE
    pass

# Generated at 2022-06-26 11:55:23.231323
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-26 11:55:26.468140
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # This is the only test for now
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:37.371435
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Unit test for constructor of class EitbIE
    """
    # pylint: disable=W0108

# Generated at 2022-06-26 11:55:39.819376
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(None), InfoExtractor)

# Generated at 2022-06-26 11:58:37.206448
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try: EitbIE()
    except: return False
    return True

# Generated at 2022-06-26 11:58:37.972386
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-26 11:58:39.524914
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()

# Generated at 2022-06-26 11:58:51.770922
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import pytest


# Generated at 2022-06-26 11:58:58.381977
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb=EitbIE()
    assert eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:01.859633
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    It checks if the constructor of the class EitbIE works as expected.
    """
    eitb_ie = EitbIE()
    assert isinstance(eitb_ie, InfoExtractor)

# Generated at 2022-06-26 11:59:13.051122
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Parameters test
    # Tests if constructor of class EitbIE works
    a = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-2014-2015/4104995148001/4104995178001/deskonfiantza/')
    assert getattr(a, '_VALID_URL') is not None
    assert getattr(a, 'IE_NAME') is not None
    assert getattr(a, '_TEST') is not None
    assert hasattr(a, '_real_extract')
    assert getattr(a, '_match_id') is not None

# Generated at 2022-06-26 11:59:19.076930
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:22.603540
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/reporter/4135479737001/')

# Generated at 2022-06-26 11:59:23.941817
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()