

# Generated at 2022-06-26 11:49:51.907804
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/eu/bideoa/dance-kale/5071438884001/"
    eitb_i_e = EitbIE(url)

# Generated at 2022-06-26 11:49:58.591579
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_0 = EitbIE() # instantiate the object

    import inspect
    # Get all the member variables of the class
    members = inspect.getmembers(eitb_i_e_0, lambda a:not(inspect.isroutine(a)))
    # Parse member variables
    for m in members:
        print(m)
        # assert()


# Generated at 2022-06-26 11:49:59.593138
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

# Generated at 2022-06-26 11:50:02.619519
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(eitb_i_e_0.IE_NAME == 'eitb.tv')

# Check if IE can be instantiated given an Eitb URL

# Generated at 2022-06-26 11:50:03.651092
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case_0()



# Generated at 2022-06-26 11:50:05.036590
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:05.413855
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-26 11:50:07.611792
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-26 11:50:15.796737
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:19.118503
# Unit test for constructor of class EitbIE
def test_EitbIE():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 11:50:28.907271
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, None)

# Generated at 2022-06-26 11:50:34.909253
# Unit test for constructor of class EitbIE
def test_EitbIE():
	url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	video_id = '4090227752001'
	result = EitbIE._real_extract(url,video_id)
	print('Resultado: ' + str(result))

test_EitbIE()

# Generated at 2022-06-26 11:50:38.516042
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:49.362182
# Unit test for constructor of class EitbIE

# Generated at 2022-06-26 11:50:53.698190
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:58.582292
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:51:01.411874
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit test for constructor of class EitbIE"""
    from .common import InfoExtractor
    from .EitbIE import EitbIE
    assert isinstance(EitbIE(), InfoExtractor)

# Generated at 2022-06-26 11:51:10.852441
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:51:12.677460
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.ie_key() == 'Eitb'

# Generated at 2022-06-26 11:51:13.425201
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:51:38.258094
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from .common import InfoExtractor
	import unittest

	class EitbIETest(unittest.TestCase, InfoExtractor):
		'''Unit test for eitb.tv IE'''
		IE_NAME = 'eitb.tv'
		_VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

		def __init__(self, testName):
			'''Constructor'''
			unittest.TestCase.__init__(self, testName)
			InfoExtractor.__init__(self)


# Generated at 2022-06-26 11:51:44.709361
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Ejecutando prueba de constructor de clase EitbIE")

    url = 'http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-urte/'
    video_id = '4090227752001'

    constructor_test = EitbIE(EitbIE.ie_key())
    expected_result = EitbIE(EitbIE.ie_key())._VALID_URL
    result = constructor_test._VALID_URL

    print("El resultado obtenido ha sido: " + result)
    print("El resultado esperado es    : " + expected_result)

    assert result == expected_result

# Generated at 2022-06-26 11:51:47.043756
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'EitbIE'

# Generated at 2022-06-26 11:51:55.451576
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    # Test constructor of class EitbIE
    ie = EitbIE(url)
    # Test instance of class EitbIE
    assert isinstance(ie,EitbIE)
    # Test initialization of class EitbIE
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == url

# Generated at 2022-06-26 11:52:06.234081
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:07.654149
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-26 11:52:13.438012
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('http://www.eitb.tv/es/video/programa-no-disponible/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:52:16.901142
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(IE_NAME, True, {'url': True})

# Generated at 2022-06-26 11:52:22.998780
# Unit test for constructor of class EitbIE
def test_EitbIE():
	"""
	Test unit for the EitbIE class.
	"""

	url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/" 
	eitbIE = EitbIE()
	assert(eitbIE.IE_NAME == 'eitb.tv')
	assert(eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
	assert(eitbIE._TEST["url"] == url)

# Generated at 2022-06-26 11:52:36.671243
# Unit test for constructor of class EitbIE
def test_EitbIE():

    ie = EitbIE('http://www.eitb.tv/eu/bideoa/20696/4104995148001/4090227752001/lasa-y-zabala-30-anos/', {})

    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:53:19.898547
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (EitbIE.suitable('http://www.eitb.tv/eu/bideoa/media/detail/3903483/17') ==
        True)
    assert (EitbIE.suitable('http://www.eitb.tv/eu/bideoa/media/detail/3903483/17/') ==
        True)
    assert (EitbIE.suitable('http://www.eitb.tv/eu/bideoa/media/detail/3903483/17/algo.mp4') ==
        True)
    assert (EitbIE.suitable('http://www.eitb.tv/eu/bideoa/media/detail/3903483/17/algo.mp4?asdasd') ==
        True)


# Generated at 2022-06-26 11:53:24.073290
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('www.eitb.tv', '20131014')
    assert ie.ie_key() == 'EitbTV'


# Generated at 2022-06-26 11:53:28.359760
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()._real_extract("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-26 11:53:29.696584
# Unit test for constructor of class EitbIE
def test_EitbIE():  
    EitbIE()

# Generated at 2022-06-26 11:53:33.014092
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:53:38.648195
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create instance of EitbIE class
    eitb_ie = EitbIE(None);
    
    # Create instance of InfoExtractor class
    info_extractor = InfoExtractor(None)

    assert(eitb_ie.IE_NAME == info_extractor.IE_DESC[b'eitb.tv'][0])

# Generated at 2022-06-26 11:53:39.458191
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:53:43.742405
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE('http://www.eitb.tv/eu/bideoa/programak/nafarroako-euskaltegia/')
    return True

# Generated at 2022-06-26 11:53:48.809600
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:53:52.010896
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_EitbIE = EitbIE("http://www.eitb.tv/")

# Generated at 2022-06-26 11:55:08.136972
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == url
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert EitbIE._TEST['info_dict']['id'] == '4090227752001'
    assert Eit

# Generated at 2022-06-26 11:55:15.165679
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing class EitbIE")
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:55:21.560196
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(_test_download, None)
    assert ie.ie_key() == 'eitb.tv'
    assert ie.ie_name() == 'eitb.tv'
    assert ie.http_post() is False
    assert ie.http_suitable() is True
    assert ie.http_timeout() == 5

# Generated at 2022-06-26 11:55:24.025509
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert(i.IE_NAME)

# Generated at 2022-06-26 11:55:27.037245
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
	assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:55:37.596774
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert eitbIE.ie_key() == 'EitbIE'
    assert eitbIE.ie_name() == 'eitb.tv'
    assert eitbIE.valid_url('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:55:39.821238
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == EitbIE.VALID_URL

# Generated at 2022-06-26 11:55:44.430574
# Unit test for constructor of class EitbIE
def test_EitbIE():
    constructor_test({
        'url': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
    })

# Generated at 2022-06-26 11:55:56.328737
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    # Creates an instance of a class from the classes.py file of youtube-dl
    assert ie.IE_NAME == 'eitb.tv'
    # Checks if the IE_NAME was correctly set
    assert ie.search_ie('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') == 'Eitb'
    # Checks if the search_ie

# Generated at 2022-06-26 11:56:00.589538
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # This test works, but doesn't actually test anything.
    # It would be nice to find a way to test IEs when they come from another file.
    eitb = EitbIE()

# Generated at 2022-06-26 11:58:51.610644
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/elorrioko-kultur-leihoa/4104994972001/4104994728001/")

# Generated at 2022-06-26 11:59:04.126194
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:15.268443
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    hashed_url = 'hashed-%s' % hashlib.md5(url.encode('utf-8')).hexdigest()
    ie = EitbIE(hashed_url)
    assert ie.IE_NAME == 'Eitb'
    assert ie.VALID_URL == r'^https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)$'
    assert ie.valid_url(url, 'Eitb')

# Generated at 2022-06-26 11:59:23.067633
# Unit test for constructor of class EitbIE

# Generated at 2022-06-26 11:59:36.095691
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.__name__ == 'EitbIE'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:42.308426
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/');