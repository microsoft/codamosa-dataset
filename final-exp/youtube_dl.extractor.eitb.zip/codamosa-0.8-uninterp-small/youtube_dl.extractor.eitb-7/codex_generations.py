

# Generated at 2022-06-26 11:49:53.512479
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

# Generated at 2022-06-26 11:50:05.440492
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0._VALID_URL is not None
    assert eitb_i_e_0._TEST is not None
    assert eitb_i_e_0._TEST.get('url') is not None
    assert eitb_i_e_0._TEST.get('md5') is not None
    assert eitb_i_e_0._TEST.get('info_dict') is not None
    assert eitb_i_e_0._TEST.get('info_dict').get('id') is not None
    assert eitb_i_e_0._TEST.get('info_dict').get('ext') is not None
    assert eitb_i_e_0._TEST.get('info_dict').get('title') is not None

# Generated at 2022-06-26 11:50:06.817058
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("\nTesting EitbIE\n")


# Generated at 2022-06-26 11:50:15.408104
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test with empty argument
    eitb_i_e_0 = EitbIE()
    assert eitb_i_e_0._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_i_e_0.IE_NAME == 'eitb.tv'
    assert eitb_i_e_0.br != None
    assert eitb_i_e_0.downloader != None
    assert eitb_i_e_0.info_dict != None
    assert eitb_i_e_0.options != None
    assert eitb_i_e_0.poster_url != None

# Generated at 2022-06-26 11:50:17.686844
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    assert isinstance(eitb_i_e, InfoExtractor)



# Generated at 2022-06-26 11:50:20.320911
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# This is the constructor of the class EitbIE
	assert_equal(eitb_i_e_0.__class__, EitbIE)


# Generated at 2022-06-26 11:50:25.274445
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    eitb_i_e.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-26 11:50:26.500181
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:30.044000
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-26 11:50:32.593905
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(), "Unit test failed."

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:50:41.641733
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.__dict__['IE_NAME'] == 'eitb.tv')



# Generated at 2022-06-26 11:50:53.885976
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    eitbIE.IE_NAME = 'eitb.tv'
    eitbIE._VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:50:58.060752
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:50:59.315423
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.__doc__ is not None

# Generated at 2022-06-26 11:51:00.866322
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:51:08.319666
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Sample test for EitbIE, which just makes sure that class constructor doesn't fail"""
    EitbIE("http://mam.eitb.eus/mam/REST/ServiceMultiweb/DomainRestrictedSecurity/TokenAuth/?videoId=4104995148001&domainName=www.eitb.tv")

if __name__ == "__main__":
    test_EitbIE()

# Generated at 2022-06-26 11:51:09.282277
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb=EitbIE()

# Generated at 2022-06-26 11:51:12.627408
# Unit test for constructor of class EitbIE
def test_EitbIE():
    passed = True
    try:
        EitbIE()
    except:
        passed = False
    assert passed, "Unit test for constructor of class EitbIE failed"


# Generated at 2022-06-26 11:51:20.640715
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class DummyArgs(object):
        pass

    args = DummyArgs()
    args.url = "http://www.eitb.tv/eu/bideoa/2863/2518/"
    assert(EitbIE() != None)
    assert(EitbIE().suitable(args) == False)
    assert(EitbIE()._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)")

# Generated at 2022-06-26 11:51:28.058724
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .exporter import YoutubeIE
    from .generic import DailymotionIE
    from .test_exporter import _test_ie_mock
    from ..utils import (
        OnDemandPagedList,
        determine_ext,
        int_or_none,
        str_to_int,
    )
    from .youtube import YoutubePlaylistIE

    assert InfoExtractor.suitable(EitbIE.IE_NAME, 'https://www.eitb.tv/eu/bideoa/todoslosvideos/programas/natura-bartik/262994/')

# Generated at 2022-06-26 11:51:49.696146
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-26 11:51:51.102919
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_test_instance = EitbIE()
    assert(eitb_test_instance!=None)

# Generated at 2022-06-26 11:52:04.703485
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from _unittest import extractor_test

# Generated at 2022-06-26 11:52:07.509175
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:52:18.598004
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test the following URL
    url = "http://www.eitb.tv/eu/bideoa/kazetaritza-etxera/4104995148001/4090227752001/lasa-y-zabala-30-anos/"

    # Create the EitbIE object
    eitbIE = EitbIE()

    # Get the actual video URL
    video_url = eitbIE._real_extract(url)

    # Get the format of the extracted video
    formatOfVideo = video_url["formats"][0]

    # Check if the format of the video is mp4
    assert formatOfVideo["format_id"] == "http"

    # Check if the actual video URL is not empty
    assert len(video_url["formats"]) > 0

    # Check if the

# Generated at 2022-06-26 11:52:22.590328
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL)
    assert EitbIE.IE_NAME == ie.ie_key()
    assert ie._VALID_URL == ie._VALID_URL
    assert EitbIE.IE_NAME == ie.extractor_key()
    assert EitbIE._VALID_URL == ie._VALID_URL
    assert "Valid URL" == ie.SUCCESS
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-26 11:52:25.009961
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    obj = object.__new__(ie.__class__)
    ie.__init__(obj)
    return ie

# Generated at 2022-06-26 11:52:29.820208
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from youtube_dl.extractor import YoutubeIE
    eitb_info_extractor = EitbIE(YoutubeIE())
    return eitb_info_extractor

# Generated at 2022-06-26 11:52:38.976371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4090227752001/"
    video_id = '4090227752001'
    # First, test that we can download the video JSON
    video = EitbIE._download_json(
        'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/' % video_id,
        video_id, 'Downloading video JSON')
    # Second, test that the video downloaded is the same as the one in _TEST
    assert video == EitbIE._TEST['info_dict']

# Generated at 2022-06-26 11:52:51.752827
# Unit test for constructor of class EitbIE
def test_EitbIE():

    """Unit test for constructor of class EitbIE"""

    # Video id of the video to be tested
    video_id = '4104995148001'

    assert isinstance(EitbIE._TEST, dict)

    # Get the test video page
    page = EitbIE._download_webpage(
        EitbIE._TEST['url'],
        video_id,
        note='Downloading video page',
        errnote='Unable to download video page')

    # parse the test video page

# Generated at 2022-06-26 11:53:26.284742
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE_instance = EitbIE()
    assert isinstance(EitbIE_instance, EitbIE)

# Generated at 2022-06-26 11:53:27.765452
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE("test_url", {})

# Generated at 2022-06-26 11:53:36.776903
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except:
        assert False, "Faild to create object"

    IE_NAME = 'eitb.tv'
    _VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:53:37.894208
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()

# Generated at 2022-06-26 11:53:41.879308
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Check if the constractor of EitbIE class can be called without failure
    """
    the_object = EitbIE()
    assert the_object

# Generated at 2022-06-26 11:53:50.055956
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url_test= 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

    #Creating an instance of EitbIE class
    test_eitbie = EitbIE(test_url_test)

    # Testing video information
    video_info = test_eitbie._real_extract(test_url_test)
    

# Generated at 2022-06-26 11:53:53.050141
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:54:01.481096
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test without URL
    test = EitbIE()
    assert test.IE_NAME == 'eitb.tv'
    assert test._VALID_URL is None
    assert test._TEST is None
    assert test._downloader is None
    assert test._WORKING is None
    assert test._ie_key() == 'Eitb'
    # Tes with URL
    test = EitbIE('url')
    assert test.IE_NAME == 'eitb.tv'
    assert test._VALID_URL == 'url'
    assert test._TEST is None
    assert test._downloader is None
    assert test._WORKING is None
    assert test._ie_key() == 'Eitb'

# Generated at 2022-06-26 11:54:12.748611
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.IE_NAME == 'eitb.tv')
    assert(EitbIE.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:54:23.508774
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.ie_key() == 'eitb.tv'
    assert eitb_ie.ie_code() == 'eitb.tv'
    assert eitb_ie.extract_id('http://www.eitb.tv/eu/bideoa/google/google-its-google/3813835571001/') == '3813835571001'
    assert eitb_ie.extract_id('http://www.eitb.tv/eu/bideoa/google/google-its-google/3813835571001/') == '3813835571001'

# Generated at 2022-06-26 11:55:23.789183
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-26 11:55:25.118457
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:55:27.302259
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie != None


# Generated at 2022-06-26 11:55:34.467438
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test constructor of class EitbIE"""
    # Could not found code to test the class constructor with [unittest2](https://pypi.python.org/pypi/unittest2)
    # If you want to test the constructor, comment out this line
    #raise unittest2.SkipTest("Could not found code to test the class constructor")
    return None


# Generated at 2022-06-26 11:55:36.815949
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:55:46.912787
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import unittest

# Generated at 2022-06-26 11:55:49.206274
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitbie = EitbIE()
	eitbie.IE_NAME

# Generated at 2022-06-26 11:55:50.602400
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), InfoExtractor)

# Generated at 2022-06-26 11:55:54.593939
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:56:07.215935
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test real extract
    request = sanitized_Request('http://www.eitb.tv/eu/bideoa/4090227752001/')
    assert EitbIE().suitable(request)
    request = sanitized_Request('http://www.eitb.tv/eu/bideoa/4090227752001/?player=popup&title=bideoa')
    assert EitbIE().suitable(request)
    request = sanitized_Request('http://www.eitb.tv/eu/bideoa/4104995148001/')
    assert EitbIE().suitable(request)
    request = sanitized_Request('http://www.eitb.tv/eu/bideoa/4104995148001/')
    assert EitbIE().suitable(request)
   

# Generated at 2022-06-26 11:58:57.445624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.IE_NAME
    ie._VALID_URL

# Generated at 2022-06-26 11:59:05.294162
# Unit test for constructor of class EitbIE
def test_EitbIE():
	print(EitbIE('http://www.eitb.tv/eu/bideoa/tokio-hotel--kaulitz-talk/4104995148001/4090227733001/'))
	print(EitbIE('http://www.eitb.tv/eu/bideoa/tokio-hotel--kaulitz-talk/4104995148001/4090227733001/'))
	print(EitbIE('http://www.eitb.tv/eu/bideoa/tokio-hotel--kaulitz-talk/4104995148001/4090227733001/'))

# Generated at 2022-06-26 11:59:15.660271
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id='4090227752001'
    url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    ie.extract(url)
    assert ie._match_id(url) == video_id
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?:\/\/(?:www\.)?eitb\.tv\/(?:eu\/bideoa|es\/video)\/[^\/]+\/\d+\/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:20.293846
# Unit test for constructor of class EitbIE
def test_EitbIE():

    EitbIE('http://www.eitb.tv/eu/bideoa/dokumentalak/1960eko-mahasti/4090227752001')

# Generated at 2022-06-26 11:59:27.555161
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert(ie.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'))
    assert(not ie.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/'))


# Test for extract method of class Eitb

# Generated at 2022-06-26 11:59:29.454200
# Unit test for constructor of class EitbIE
def test_EitbIE():
    x = EitbIE("TestDownloader")

# Generated at 2022-06-26 11:59:38.675928
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Constructor test of class EitbIE
    """
    # Mocked list of tests

# Generated at 2022-06-26 11:59:39.459410
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()