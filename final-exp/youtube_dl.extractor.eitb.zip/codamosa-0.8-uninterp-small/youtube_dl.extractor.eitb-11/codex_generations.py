

# Generated at 2022-06-26 11:49:52.021007
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

# Generated at 2022-06-26 11:49:56.457916
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:49:59.789155
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_1 = EitbIE(
        downloader=None,
        download_context=None,
        params=None,
        url=None
    )

# Generated at 2022-06-26 11:50:00.851513
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0 != None

# Generated at 2022-06-26 11:50:11.590428
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0.IE_NAME == 'eitb.tv'
    assert eitb_i_e_0._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:15.693862
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    assert eitb_i_e.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL.startswith('https?://(?:www\\.)?eitb\\.tv/')
    assert eitb_i_e._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'


# Generated at 2022-06-26 11:50:24.892943
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert hasattr(eitb_i_e_0, '_download_json'), 'Instance need to have download json method'
    assert hasattr(eitb_i_e_0, '_match_id'), 'Instance need to have _match_id method'
    assert hasattr(eitb_i_e_0, '_real_extract'), 'Instance need to have _real_extract method'
    assert hasattr(eitb_i_e_0, '_sort_formats'), 'Instance need to have _sort_formats method'
    assert hasattr(eitb_i_e_0, 'IE_NAME'), 'Instance need to have IE_NAME attribute'



# Generated at 2022-06-26 11:50:26.466143
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0.ie_key() == 'eitb.tv'


# Generated at 2022-06-26 11:50:27.752516
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_1 = EitbIE()

# Generated at 2022-06-26 11:50:28.755312
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0 is not None

# Generated at 2022-06-26 11:50:37.418317
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(EitbIE.IE_NAME, 1, EitbIE._VALID_URL)

# Generated at 2022-06-26 11:50:40.584346
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:41.161520
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Init EitbIE
    EitbIE("")

# Generated at 2022-06-26 11:50:44.925370
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-26 11:50:52.655360
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = EitbIE._TEST["url"]
    assert url == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    video_id = EitbIE._TEST["id"]
    assert video_id == "4090227752001"

# Generated at 2022-06-26 11:50:57.046004
# Unit test for constructor of class EitbIE
def test_EitbIE():
   assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:51:03.115157
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb is not None, "Failed to instanciate EitbIE class"
    # test for extractor
    assert EitbIE.IE_NAME == eitb.IE_NAME, "EitbIE class has a wrong name"
    # test for regex matching of urls
    assert (eitb._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(\d+)'), "EitbIE class has a wrong valid url"

# Generated at 2022-06-26 11:51:03.772615
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE();

# Generated at 2022-06-26 11:51:10.008912
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:51:15.804715
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('test', 'test', 'test')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TEST')
    assert hasattr(ie, 'IE_NAME')
    if '_real_initialize' in dir(ie):
        ie._real_initialize()

# Generated at 2022-06-26 11:51:40.057187
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_utils import assertRegex
    i = EitbIE('EitbIE', 'http://www.eitb.tv/eu/bideoa/bideoa/4104993938001/4090227921001/kazama-ordezko-animaliak-iraganeko-animaliak/')
    assertEqual(i._html_search_meta('title'), 'Kazama ordezko animaliak, iraganeko animaliak')
    assertEqual(i._html_search_meta('description'), 'Kazama ordezko animaliak, iraganeko animaliak')
    assertEqual(i._html_search_meta('keywords'), 'Kazama, ordezko animaliak, iraganeko animaliak, gertu, bideo, bideoak, EITB')
    assertE

# Generated at 2022-06-26 11:51:41.337321
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:51:53.776680
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE(None, 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    info = info_extractor._real_extract(info_extractor._VALID_URL)
    assert info['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert info['id'] == '4090227752001'
    assert 'es' in info['tags']
    assert '60 minutos' in info['tags']
    assert info['description'] == 'Programa de reportajes de actualidad.'
    assert abs(info['duration'] - 3996.76) < 0

# Generated at 2022-06-26 11:52:02.230460
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE('', {}))
    assert(not EitbIE('http://example.com', {}))
    assert(EitbIE('http://www.eitb.tv/eu/bideoa/titulua/id/000000000/', {}))
    assert(not EitbIE('http://www.eitb.tv/eu/bideoa/000000000/', {}))

# Generated at 2022-06-26 11:52:10.589652
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-26 11:52:15.400509
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE(url)
    return True


# Generated at 2022-06-26 11:52:18.587773
# Unit test for constructor of class EitbIE
def test_EitbIE():
  # Initialize an object EitbIE using constructor 
  obj = EitbIE()
  print (obj)

# Generated at 2022-06-26 11:52:24.297024
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE('eitb.tv')
    assert(e.base_url == 'http://www.eitb.tv')
    assert(e.ie_key() == 'Eitb')
    assert(e.ie_name == 'Eitb')

# Generated at 2022-06-26 11:52:37.783611
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert(eitb.IE_NAME == 'eitb.tv')
    assert(eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:52:44.943257
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:53:19.403322
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    return e != None # should not be null

# Generated at 2022-06-26 11:53:30.612462
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    print(e._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')['title'])
    assert len(e.__dict__['_TEST']['info_dict']) == 11

# Generated at 2022-06-26 11:53:38.340028
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_request_url = 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/'
    test_get_id = '4090227752001'

    eitb = EitbIE()
    assert test_request_url % test_get_id == eitb._make_request_url(test_get_id)

# Generated at 2022-06-26 11:53:44.209893
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    return IE

# Generated at 2022-06-26 11:53:48.256715
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ieinfo = EitbIE()
    assert ieinfo.ie_key() == 'Eitb'
    assert ieinfo.ie_name() == 'Eitb.tv'
    assert ieinfo.ie_version() != None

# Generated at 2022-06-26 11:53:55.352104
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:53:57.857005
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = globals()['EitbIE']
    instance_ = class_(None)
    assert instance_ is not None

# Generated at 2022-06-26 11:54:09.944400
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert e.IE_NAME == 'eitb.tv'
    assert e.BR_DESC == '\n        Euskal Irrati Telebista SA\n        <br>\n        Jauregi Plaza, 5 - 1\n        <br>\n        48011 Bilbo\n        <br>\n        Telefono: (34) 94-412-60-00\n        <br>\n'

# Generated at 2022-06-26 11:54:12.648862
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:54:21.814769
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test with different values for url (value of attribute url)
    assert EitbIE(url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') == EitbIE(url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:55:25.577356
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    assert a._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:28.432215
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_ie = EitbIE()
    test_ie.IE_NAME


# Generated at 2022-06-26 11:55:33.737178
# Unit test for constructor of class EitbIE
def test_EitbIE():
    unit_test = EitbIE()
    assert unit_test._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:37.058136
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:47.020967
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import InfoExtractor
    from .common import merge_dicts
    import copy
    global IE_NAME
    IE_NAME = 'Eitb.tv'
    ie = InfoExtractor()
    ie.IE_NAME = IE_NAME
    instance = EitbIE()
    assert EitbIE.IE_NAME == IE_NAME
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:53.575272
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ie.suitable('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:56:00.212723
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'



# Generated at 2022-06-26 11:56:05.628554
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from collections import OrderedDict
	
	# Default test
	args = OrderedDict({})
	eitb_ie = EitbIE(args)
	assert eitb_ie._html_search_regex(args) == eitb_ie._VALID_URL

# Generated at 2022-06-26 11:56:17.684607
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    # Test format extraction
    ie._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    # Test constructor

# Generated at 2022-06-26 11:56:20.775867
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE("")
    assert(eitbIE.IE_NAME == "eitb.tv")

# Generated at 2022-06-26 11:59:11.900392
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE();
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:14.221085
# Unit test for constructor of class EitbIE
def test_EitbIE():
	info_extractor = EitbIE()
	assert info_extractor != None


# Generated at 2022-06-26 11:59:18.444000
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    
    # Testing with real data for video
    # http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/
    URL = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ID = '4090227752001'

# Generated at 2022-06-26 11:59:19.297701
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:59:22.407355
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:59:28.170020
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Started testing constructor of EitbIE")

    # Test with a correct link
    correct_url = "http://www.eitb.tv/eu/bideoa/rusia-hegazkina-zeramalitatik-hegazkin-ontziratik-ihes-bidean/4104995148001/4260166580001/"
    try:
        test = EitbIE(correct_url)
        assert isinstance(test, EitbIE)
    except BaseException as ex:
        assert False, "Failed when testing EitbIE constructor with a correct link"

    # Test with incorrect link

# Generated at 2022-06-26 11:59:36.742801
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'


# Generated at 2022-06-26 11:59:43.244152
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")
    ie.download("4090227752001")