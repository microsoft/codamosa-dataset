

# Generated at 2022-06-26 11:49:52.865016
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # EitbIE._VALID_URL is a class variable
    eitb_i_e._VALID_URL = "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"
    # EitbIE._TEST is a class variable

# Generated at 2022-06-26 11:49:53.991017
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()


# Generated at 2022-06-26 11:50:01.243759
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert type(eitb_i_e_0.ie_key()) == type(u'')
    assert eitb_i_e_0.ie_key() == u'Eitb'
    assert type(eitb_i_e_0.ie_name()) == type(u'')
    assert eitb_i_e_0.ie_name() == u'eitb.tv'

# Generated at 2022-06-26 11:50:03.069624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:03.930370
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    assert isinstance(eitb_i_e, EitbIE)


# Generated at 2022-06-26 11:50:09.627348
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (eitb_i_e_0.IE_NAME == 'eitb.tv')
    assert (eitb_i_e_0._VALID_URL == '^https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)$')


# Generated at 2022-06-26 11:50:10.609591
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case_0()


# Generated at 2022-06-26 11:50:12.517581
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    eitb_i_e.params = {'skip_download': True}

# Generated at 2022-06-26 11:50:14.148472
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:50:14.763634
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-26 11:50:25.315607
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/musika/gira-susperiak-eguzkia-eitb-museoan/4104995148001/?n=4&v=2'
    pass

# Generated at 2022-06-26 11:50:26.545050
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'Eitb'

# Generated at 2022-06-26 11:50:33.114844
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:50:35.208431
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.ie_key() == 'EitbIE'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:36.250836
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()

# Generated at 2022-06-26 11:50:43.569102
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test for the constructor of the class EitbIE
    """

    config_info = {
        "IE_NAME": 'eitb.tv',
        "_VALID_URL": r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    }

    ie = EitbIE()
    assert ie.ie_key() == config_info["IE_NAME"]
    assert ie._VALID_URL == config_info["_VALID_URL"]

# Generated at 2022-06-26 11:50:44.836625
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_obj = EitbIE()
    test_obj.IE_NAME

# Generated at 2022-06-26 11:50:56.217440
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create instance of IE
    ie = EitbIE()
    assert isinstance(ie, InfoExtractor)
    # Check if IE is able to be instantiated
    EitbIE().suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    # Check URL pattern
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:00.505816
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:51:07.881001
# Unit test for constructor of class EitbIE
def test_EitbIE():

    assertEqual(EitbIE.IE_NAME, 'eitb.tv')
    assertEqual(EitbIE._VALID_URL, r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-26 11:51:21.912539
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None


# Generated at 2022-06-26 11:51:22.778427
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-26 11:51:27.200073
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/eu/bideoa/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert instance.IE_NAME == 'eitb.tv'
    assert instance._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:37.066626
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'Eitb.tv'
    assert EitbIE.IE_DESC == 'Eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:43.619818
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()


# Generated at 2022-06-26 11:51:47.759744
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL)
    except Exception:
        raise


# Generated at 2022-06-26 11:51:51.920327
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test for all class methods
    import pdb
    cls = EitbIE
    pdb.set_trace()
    assert getattr(cls, '_VALID_URL', None) is not None
    assert getattr(cls, '_TEST', None) is not None

# Generated at 2022-06-26 11:51:59.969451
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:01.652958
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()

# Generated at 2022-06-26 11:52:04.868354
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
        pass
    except:
        assert False


# Generated at 2022-06-26 11:52:30.509654
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:52:36.277382
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:52:43.529512
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104996070001/4090227752001/lasa-y-zabala-30-anos/')
    assert instance.IE_NAME == "eitb.tv"

# Generated at 2022-06-26 11:52:45.923998
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _EitbIE = EitbIE()
    assert _EitbIE.IE_NAME == 'eitb.tv'



# Generated at 2022-06-26 11:52:57.290395
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test if it raises an exception when an empty url is passed.
    try:
        EitbIE()
        raise
    except TypeError:
        pass

    # Test if it raises an exception when a non-string is passed as url.
    try:
        EitbIE(url=123)
        raise
    except TypeError:
        pass

    # Test if it raises an exception when a non-string is passed as ie.
    try:
        EitbIE(ie=123)
        raise
    except TypeError:
        pass

    # Test if it raises an exception when a non-string is passed as ie_key.
    try:
        EitbIE(ie_key=123)
        raise
    except TypeError:
        pass

    # Test if it raises an exception when a non-dict is passed as video_

# Generated at 2022-06-26 11:53:09.013705
# Unit test for constructor of class EitbIE
def test_EitbIE():
	index_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	ie = EitbIE(index_url)
	test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	assert ie.match_url(test_url)

# Generated at 2022-06-26 11:53:10.683620
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4090227752001/')
    assert eitb


# Generated at 2022-06-26 11:53:12.058637
# Unit test for constructor of class EitbIE
def test_EitbIE():
	e = EitbIE()

# Generated at 2022-06-26 11:53:15.875028
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        ie = EitbIE()
    except:
        raise AssertionError("EitbIE() -> AssertionError")

# Generated at 2022-06-26 11:53:18.229050
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_test = EitbIE()
# Verify that constructor of class EitbIE works fine
    assert eitb_test != None

# Generated at 2022-06-26 11:54:36.153552
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST[0]['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._TEST[0]['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-26 11:54:38.807876
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert isinstance(eitbIE, InfoExtractor) == True

# Generated at 2022-06-26 11:54:45.573092
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    print("\nEITBIE Test Case 1")
    print("Type: " + test.IE_NAME)

# Generated at 2022-06-26 11:54:56.712508
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert EitbIE._TEST['info_dict']['id'] == '4090227752001'
    assert EitbIE._TEST['info_dict']['ext'] == 'mp4'
    assert EitbIE._TEST['info_dict']['title'] == '60 minutos (Lasa y Zabala, 30 años)'
    assert Eitb

# Generated at 2022-06-26 11:55:07.894628
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE()
    assert test_EitbIE.IE_NAME == 'eitb.tv'
    assert test_EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:14.009832
# Unit test for constructor of class EitbIE
def test_EitbIE():
	from unittest import TestCase
	TC = TestCase('__init__')
	TC.assertEqual(EitbIE.IE_NAME, 'eitb.tv')
	TC.assertEqual(EitbIE._VALID_URL, 'https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)')

# Generated at 2022-06-26 11:55:14.609988
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()

# Generated at 2022-06-26 11:55:15.412795
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test for EitbIE constructor
    EitbIE()

# Generated at 2022-06-26 11:55:21.145597
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 0)

# Generated at 2022-06-26 11:55:24.175397
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:58:05.107596
# Unit test for constructor of class EitbIE
def test_EitbIE():
	entry = EitbIE

# Generated at 2022-06-26 11:58:07.072706
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE(0)


# Generated at 2022-06-26 11:58:10.345420
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE_TEST = EitbIE(None)
    assert IE_TEST.IE_NAME == 'eitb.tv'
    assert IE_TEST._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:58:14.187861
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# ==============================================================================
# Tests


# Test file to check the extraction of the video and the metadata of a video

# Generated at 2022-06-26 11:58:19.994750
# Unit test for constructor of class EitbIE
def test_EitbIE():
    unit_test_EitbIE = EitbIE()
    # Test for Internet connection
    assert unit_test_EitbIE.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-26 11:58:22.968366
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("test.com/test").IE_NAME == "eitb.tv"

# Generated at 2022-06-26 11:58:32.389615
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"
    assert ie.IE_NAME == "eitb.tv"
    assert ie._TEST['url'] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-26 11:58:35.523260
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:58:37.889182
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), InfoExtractor)


# Generated at 2022-06-26 11:58:39.852309
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'