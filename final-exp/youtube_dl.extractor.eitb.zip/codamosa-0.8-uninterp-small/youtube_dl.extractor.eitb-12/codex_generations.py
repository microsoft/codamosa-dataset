

# Generated at 2022-06-26 11:49:53.113983
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

# Generated at 2022-06-26 11:50:05.141286
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # It should download the webpage containing the title and id
    webpage = EitbIE()
    webpage.download_webpage(webpage.url)

    # It should extract the id
    assert('4090227752001' == webpage.extract_id())

    # It should extract the title
    assert('60 minutos (Lasa y Zabala, 30 años)' == webpage.extract_title())

    # It should extract the duration
    assert(3996.76 == webpage.extract_duration())

    # It should extract the timestamp
    assert(1381789200 == webpage.extract_timestamp())

    # It should extract the tags
    assert(['60 Minutos', 'Lasa', 'Zabala', '30 Anos'] == webpage.extract_tags())

    # It should extract the description

# Generated at 2022-06-26 11:50:06.964819
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0.IE_NAME == "EitbIE"


# Generated at 2022-06-26 11:50:08.445790
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:08.899737
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0

# Generated at 2022-06-26 11:50:09.349639
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return [test_case_0]


# Generated at 2022-06-26 11:50:09.956335
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() is not None


# Generated at 2022-06-26 11:50:10.586842
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-26 11:50:11.154906
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-26 11:50:12.552564
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0.IE_NAME == 'EitbIE'


# Generated at 2022-06-26 11:50:24.581248
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Testing constructor
    test_instance = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert test_instance


# Generated at 2022-06-26 11:50:30.854949
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:33.754836
# Unit test for constructor of class EitbIE
def test_EitbIE():
    tst_EitbIE = EitbIE(EitbIE._TEST)
    tst_EitbIE._real_extract(EitbIE._TEST["url"])

# Generated at 2022-06-26 11:50:42.992687
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """EitbIE unit test"""
    # Test case 1 from http://eitb.tv/eu/bideoa/telebista/bidi/teleberri/4605526/
    url = 'http://www.eitb.tv/eu/bideoa/telebista/bidi/teleberri/4605526/'
    eitb_ie = EitbIE({})
    # Check the EitbIE class constructor
    assert eitb_ie.suitable(url), 'Url %s es no valido' % url
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:50:50.336150
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'Eitb'
    assert e.valid_url('http://www.eitb.tv/eu/bideoa/kalean-eu/3/6068/')
    assert e.valid_url('http://www.eitb.tv/eu/bideoa/alzheimerra-gaitzeko-jardunaldia-eta-gaur-kontzertua/3/6238/')

# Generated at 2022-06-26 11:50:51.938192
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .youtube import YoutubeIE

    assert YoutubeIE is not None

# Generated at 2022-06-26 11:51:02.046899
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert EitbIE.suitable('http://www.eitb.tv/es/video/4050227752001/lasa-y-zabala-30-anos/')
    assert EitbIE.suitable('http://www.eitb.tv/eu/bideoa/4050227752001/lasa-y-zabala-30-anos/')
    assert EitbIE.suitable('http://www.eitb.tv/eu/bideoa/4050227752001/test-test/')
   

# Generated at 2022-06-26 11:51:03.147626
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE(None)

# Generated at 2022-06-26 11:51:08.609327
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    Test class constructor with initialized values
    '''
    ie = EitbIE()
    print('\nEitbIE unit test')
    print('Name: ', ie.IE_NAME)
    print('URL: ', ie._VALID_URL)

# Generated at 2022-06-26 11:51:19.682827
# Unit test for constructor of class EitbIE
def test_EitbIE():
    if not hasattr(EitbIE, '_download_json'):
        return
    e = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4090227752001/lasa-y-zabala-30-anos/')
    assert e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:35.295924
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME is not None

# Generated at 2022-06-26 11:51:36.141996
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE(None)

# Generated at 2022-06-26 11:51:43.876983
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-26 11:51:46.899106
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-26 11:51:50.170048
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-26 11:51:51.799228
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert obj.browse is False


# Generated at 2022-06-26 11:52:05.073443
# Unit test for constructor of class EitbIE

# Generated at 2022-06-26 11:52:13.774438
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test constructor of class EitbIE
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:52:17.671616
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'EitbIE'

# Generated at 2022-06-26 11:52:20.466254
# Unit test for constructor of class EitbIE
def test_EitbIE():

    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:53:01.025129
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.name == 'eitb.tv'

# Generated at 2022-06-26 11:53:06.466237
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('http://www.eitb.tv/eu/bideoa/ze-har-egiten/4104995148001/4090469973001/emin-agalarov/')

# Generated at 2022-06-26 11:53:07.489190
# Unit test for constructor of class EitbIE
def test_EitbIE():
	pass

# Generated at 2022-06-26 11:53:15.194444
# Unit test for constructor of class EitbIE
def test_EitbIE():
  ie = EitbIE('not_a_url')
  assert ie._VALID_URL == '^https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
  return ie



# Generated at 2022-06-26 11:53:20.007178
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IEitb = EitbIE(None)

    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    path = r'(?P<id>\d+)'
    result = IEitb._match_id(url)
    assert result == '4090227752001'

# Generated at 2022-06-26 11:53:24.720892
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/mendi-berriak/4104995148001/4063660778001/mendi-berriak-7/')

# Generated at 2022-06-26 11:53:30.483402
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check if EitbIE is the correct class for this url
    url = 'http://www.eitb.tv/es/video/munduaren-ezkontzak-munduaren-ezkontzak-2014/4105000185001/4105000184001/el-amor-no-tiene-que-ser-comercial/'
    url_to_check = EitbIE._match_url(url)
    assert url_to_check == "4105000184001"

# Generated at 2022-06-26 11:53:40.255310
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple test for Eitb.tv.
    """
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')
    assert(ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:53:41.519699
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-26 11:53:43.591938
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # TODO: add test code
    return 0



# Generated at 2022-06-26 11:55:03.198536
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE("http://www.eitb.tv/eu/bideoa/60-minutos/4104991835001/")
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.ie_key() == "EitbIE"

# Generated at 2022-06-26 11:55:03.837817
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:55:11.340857
# Unit test for constructor of class EitbIE
def test_EitbIE():
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(EitbTestCase)
    return unittest.TextTestRunner(verbosity=2).run(suite)


########################################################################################################
####### Now you can read about the tests themselves
########################################################################################################




# Generated at 2022-06-26 11:55:13.561663
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), EitbIE)

# Generated at 2022-06-26 11:55:14.866268
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test=EitbIE()
    assert test

# Generated at 2022-06-26 11:55:21.215913
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_class = EitbIE()
    assert test_class.IE_NAME == 'eitb.tv'
    assert test_class._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:26.796094
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        assert(EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', None))
    except Exception:
        raise AssertionError(" Constructor of class EitbIE failed")


# Generated at 2022-06-26 11:55:30.333028
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()
	assert ie._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"


# Generated at 2022-06-26 11:55:33.388004
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .test_common import EitbTest
    # Unit tests for EitbIE
    # EitbIE.test(EitbTest)

# Generated at 2022-06-26 11:55:39.579997
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert eitb_ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-26 11:58:42.029296
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() != None

# Generated at 2022-06-26 11:58:45.139787
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('https://www.eitb.tv/eu/bideoa/descubre-el-mundo-en-euskadi/12345/01234567890/')
    assert ie.name == 'eitb.tv'

# Generated at 2022-06-26 11:58:48.164433
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_IE = EitbIE()
    assert eitb_IE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:58:54.608012
# Unit test for constructor of class EitbIE
def test_EitbIE():
	i = EitbIE()
	e = i.extract('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
	assert e['id'] == '4090227752001'
	assert e['ext'] == 'mp4'
	assert e['title'] == '60 minutos (Lasa y Zabala, 30 años)'
	assert e['description'] == 'Programa de reportajes de actualidad.'
	assert e['duration'] == 3996.76
	assert e['timestamp'] == 1381789200
	assert e['upload_date'] == '20131014'
	assert e['tags'] != None

# Generated at 2022-06-26 11:59:01.761166
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:04.583823
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.extractor
test_EitbIE()

# Generated at 2022-06-26 11:59:15.386071
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE()
    info_extractor._VALID_URL = EitbIE._VALID_URL

# Generated at 2022-06-26 11:59:19.000985
# Unit test for constructor of class EitbIE
def test_EitbIE():

    test_EitbIE = EitbIE()
    assert isinstance(test_EitbIE, EitbIE)

# Generated at 2022-06-26 11:59:20.803373
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-26 11:59:27.727499
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'EitbIE'
    assert ie.is_extracted('4090227752001') == False
    assert ie.is_extracted('4090227752000') == True
    assert ie.extract_video_id('https://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/') == '4090227752001'
    assert ie.ext