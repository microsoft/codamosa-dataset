

# Generated at 2022-06-26 11:49:50.338075
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:49:51.594389
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_test_case_0 = EitbIE()

# Generated at 2022-06-26 11:49:53.029036
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE() == EitbIE()


# Generated at 2022-06-26 11:49:54.628703
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # simple test of constructor of EitbIE
    test_case_0()

# Generated at 2022-06-26 11:50:00.087769
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_1 = EitbIE(merge_dicts=False, secret_data=None, secret_urls=None, simple_downloader=None, param5=None, downloader=None, params=None)
    assert eitb_i_e_1 is not None


# Generated at 2022-06-26 11:50:02.673767
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    # self
    assert eitb_i_e



# Generated at 2022-06-26 11:50:04.053059
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

# Generated at 2022-06-26 11:50:05.450539
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_0 = EitbIE()


# Generated at 2022-06-26 11:50:06.816353
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:11.590123
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE('EitbIE', 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-26 11:50:25.154396
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:50:31.429235
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # the format of input url is not supported
    assert isinstance(EitbIE.suitable(''), dict) is False
    # the format of input url is supported
    assert isinstance(EitbIE.suitable('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'), dict) is True


# Generated at 2022-06-26 11:50:37.127099
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(eitb_i_e_0.IE_NAME == None)
    assert(eitb_i_e_0._VALID_URL == None)
    assert(eitb_i_e_0._TEST == None)
    assert(eitb_i_e_0._match_id == None)

if __name__ == "__main__":
    eitb_i_e_0 = EitbIE()
    test_EitbIE()

# Generated at 2022-06-26 11:50:38.009040
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case_0()


# Generated at 2022-06-26 11:50:40.120333
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(EitbIE.IE_NAME, EitbIE._VALID_URL)


# Generated at 2022-06-26 11:50:42.906275
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert test_case_0()

if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(["-v", "--capture=sys"] + sys.argv))

# Generated at 2022-06-26 11:50:44.052931
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

# Generated at 2022-06-26 11:50:46.516819
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # Testing if ie is an instance of EitbIE
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-26 11:50:48.455338
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()


# Generated at 2022-06-26 11:50:49.829796
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0


# Generated at 2022-06-26 11:51:08.126136
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:14.728720
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    IE_NAME = 'eitb.tv'
    ie = EitbIE(IE_NAME)
    ie.suitable(url)
    ie.extract(url)

# Generated at 2022-06-26 11:51:18.953515
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .common import TestIE
    test_video_url(TestIE.IE_NAME, 'EitbIE', '60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')



# Generated at 2022-06-26 11:51:26.102172
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Without any arguments
    t = EitbIE()
    assert t.IE_NAME == 'eitb.tv'
    # With an url argument
    t = EitbIE(url='http://www.eitb.tv/eu/bideoa/lasa-y-zabala--30-urte/4104995148001/4090227752001/')
    assert t.IE_NAME == 'eitb.tv'
    assert t.url == 'http://www.eitb.tv/eu/bideoa/lasa-y-zabala--30-urte/4104995148001/4090227752001/'

# Generated at 2022-06-26 11:51:28.057925
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/eu/bideoa/sailburu-bat/1020304050/60/")
    # constructors returns None

# Generated at 2022-06-26 11:51:28.919681
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE();

# Generated at 2022-06-26 11:51:34.620896
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Unit test for constructor of class EitbIE")
    assert EitbIE.ie_key() == 'eitb.tv'
    assert EitbIE._VALID_URL == (r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-26 11:51:35.941362
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert 'EitbIE' in globals()


# Generated at 2022-06-26 11:51:43.753175
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Testing different type of URLs
    url = "http://www.eitb.tv/eu/bideoa/1406/13/1327/12/Larraitz-Ugalde-probak/10/"
    assert EitbIE._VALID_URL == 'http://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    # Testing the regex
    assert EitbIE._match_id

# Generated at 2022-06-26 11:51:53.112698
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import pytest
    from .test_downloader import MockYDL
    ydl_opts = {
        'ignoreerrors': True,
        'simulate': True,
        'skip_download': True,
    }
    eitb_ie = EitbIE()
    with MockYDL(ydl_opts) as ydl:
        ydl.add_default_info_extractors()
        ydl.add_info_extractor(eitb_ie)
        ydl.extract_info(EitbIE._TEST['url'])
        assert ydl_opts['skip_download']

# Generated at 2022-06-26 11:52:21.550693
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert isinstance(instance, EitbIE)


# Generated at 2022-06-26 11:52:23.740968
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:24.945070
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie

# Generated at 2022-06-26 11:52:29.157105
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(int_or_none=int_or_none)
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:52:31.250917
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'https://www.eitb.eus/es/videos/vivir/60-minutos/5267688/%C2%BFes-el-paraiso-o-no/'
    ie = EitbIE()
    if ie.suitable(url):
        ie.extract(url)

# Generated at 2022-06-26 11:52:36.671443
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:43.974685
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:52:49.105512
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # dummy values
    url = 'http://www.eitb.tv/eu/bideoa/60-minutos-2012-2013/2296008680/2110351954001/daniel-gonzalez/'
    video_id = '2110351954001'
    assert ie._match_id(url) == video_id

# Generated at 2022-06-26 11:52:51.995625
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE(None)

# Generated at 2022-06-26 11:52:54.880449
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # TODO: Find videos without an ID
    EitbIE()


if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-26 11:54:05.098147
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')



# Generated at 2022-06-26 11:54:14.387542
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create an instance of the class EitbIE
    eitb = EitbIE()
    # Test _VALID_URL of class EitbIE against a known set of data
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # Test IE_NAME of class EitbIE against a known set of data
    assert eitb.IE_NAME == 'eitb.tv'
    # Test _TEST of class EitbIE against a known set of data

# Generated at 2022-06-26 11:54:17.311405
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('www.eitb.tv')
    assert eitb_ie._VALID_URL == eitb_ie.VALID_URL

# Generated at 2022-06-26 11:54:20.851473
# Unit test for constructor of class EitbIE
def test_EitbIE():
	video_id = '4090227752001'
	url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	return EitbIE()._real_extract(url)

# Generated at 2022-06-26 11:54:27.242436
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL == 'https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\\d+/(?P<id>\\d+)'


# Generated at 2022-06-26 11:54:30.672746
# Unit test for constructor of class EitbIE
def test_EitbIE():
    example = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(example)
    print (ie)

# Generated at 2022-06-26 11:54:42.711305
# Unit test for constructor of class EitbIE
def test_EitbIE():
    string_data = "['string_data']"
    video_id = "4104995148001"
    video_download_url = "http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/%s/" % video_id
    extractor = EitbIE()
    try:
        # execute parse_iso8601 function
        extractor._parse_iso8601(string_data)
    except Exception as e:
        # An exception is raised if parse_iso8601 function works correctly
        pass
    else:
        # An exception is not raised and fail is raised instead
        fail_test('test_EitbIE', '_parse_iso8601')


# Generated at 2022-06-26 11:54:43.826443
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE

# Generated at 2022-06-26 11:54:48.548896
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE('www.eitb.tv', 'EitbIE')
    assert eitbIE.ie_key() == 'eitb'
    assert eitbIE.ie_name() == 'eitb.tv'
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE.ie_description() == 'Euskal Irrati Telebista'
    assert eitbIE.ie_key() == 'eitb'
    assert eitbIE.IE_VERSION == '0.1'

# Generated at 2022-06-26 11:54:51.255910
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() is not None

# Generated at 2022-06-26 11:57:19.921103
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(downloader=None)._build_url('Aa')



# Generated at 2022-06-26 11:57:26.948423
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv' 
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:57:35.012413
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Make sure this test code runs only if IE has already been run
    EitbIE('http://www.eitb.tv/eu/bideoa/lasa-y-zabala-30-anos/')
    # Don't allow empty url to be passed
    try:
        EitbIE('')
    except AssertionError:
        pass

# Generated at 2022-06-26 11:57:38.654300
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video = ie.extract(url)

# Generated at 2022-06-26 11:57:45.061295
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:57:50.667781
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos')
    assert(IE.ie_key() == 'eitb.tv')
    assert(IE.ie_name() == 'eitb.tv')
    assert(IE.url_re() == 'http://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:57:59.634232
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test with URL to a video
    url = 'http://www.eitb.tv/eu/bideoa/partidua/2016-17/euskadiko-futbol-txapelketa/23/752161/'
    eitbIE = EitbIE(True)
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitbIE._match_id(url) == '752161'

# Generated at 2022-06-26 11:58:03.003918
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Unit tests for constructor of class EitbIE."""
    EitbIE(None)

# Generated at 2022-06-26 11:58:07.746099
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/eu/bideoa/euskal-kultur-kluba/4104991624001/4104991624001/")



# Generated at 2022-06-26 11:58:20.675824
# Unit test for constructor of class EitbIE