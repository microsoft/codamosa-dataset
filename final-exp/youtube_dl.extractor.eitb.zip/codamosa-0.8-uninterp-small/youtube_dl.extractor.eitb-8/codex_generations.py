

# Generated at 2022-06-26 11:49:52.321074
# Unit test for constructor of class EitbIE
def test_EitbIE():
	pass;

# Generated at 2022-06-26 11:49:53.714494
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().ie_key() == 'Eitb'

# Generated at 2022-06-26 11:49:58.896336
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert instance._VALID_URL == "https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"

# Generated at 2022-06-26 11:50:00.297014
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:02.073390
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() == EitbIE()


# Generated at 2022-06-26 11:50:04.263788
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('Unit test for constructor of class EitbIE')
    print(eitb_i_e_0)


# Generated at 2022-06-26 11:50:06.477943
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE(name='eitb.tv', ie_key='Eitb', default_ie='Eitb')

# Generated at 2022-06-26 11:50:15.232520
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test case 0
    # function movie_page -> eitb.tv/eu/bideoa/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/

    eitb_i_e_1 = EitbIE()
    eitb_i_e_1._real_extract(eitb_i_e_0._TEST['url'])

if __name__ == '__main__':
    # test_EitbIE()
    eitb_i_e_0 = EitbIE()
    eitb_i_e_0._real_extract(eitb_i_e_0._TEST['url'])

# Generated at 2022-06-26 11:50:16.667740
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_0 = EitbIE()

# Generated at 2022-06-26 11:50:19.575392
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_0 = EitbIE()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:50:31.011095
# Unit test for constructor of class EitbIE
def test_EitbIE():
	u = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	pass

# Generated at 2022-06-26 11:50:35.233351
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('https://www.eitb.tv/eu/bideoa/60-minutos-60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    ie.extract()
    assert ie.format_id == 'http-2372'

# Generated at 2022-06-26 11:50:36.588029
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_object = EitbIE()
    test_object._VALID_URL

# Generated at 2022-06-26 11:50:37.790683
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie


# Generated at 2022-06-26 11:50:41.643088
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    return EitbIE()._real_extract(url)

# Generated at 2022-06-26 11:50:43.963586
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_name = 'EitbIE'
    test_case = EitbIE()
    assert test_case.IE_NAME == class_name

# Generated at 2022-06-26 11:50:44.871112
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    assert a

# Generated at 2022-06-26 11:50:57.561605
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/4104995148001/4090227752001/lasa-y-zabala-30-anos/?media=4104995148001&autostart=true'
    url1 = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'


    video_id = '4090227752001'
    title = '60 minutos (Lasa y Zabala, 30 años)'
    description = 'Programa de reportajes de actualidad.'
    duration = 3996.76
    timestamp = 1381789200

# Generated at 2022-06-26 11:50:58.156408
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()


# Generated at 2022-06-26 11:51:02.177381
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .helper import create_extractor_test
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
    create_extractor_test(EitbIE, url)

# Generated at 2022-06-26 11:51:17.219663
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-26 11:51:20.301156
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test class EitbIE()
    """
    # Testing the constructor of EITB
    tester = EitbIE()

    if not isinstance(tester, InfoExtractor):
        raise Exception('EITB constructor is not an instance of InfoExtractor class')

    if tester.IE_NAME != 'eitb.tv':
        raise Exception('EITB constructor has not correct IE_NAME')

# Generated at 2022-06-26 11:51:21.788785
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:51:28.306615
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert eitb_ie._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'
    assert eitb_ie._TEST['info_dict']['id']

# Generated at 2022-06-26 11:51:30.311483
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import pytest
    with pytest.raises(TypeError):
        EitbIE()

# Generated at 2022-06-26 11:51:32.501776
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE(InfoExtractor())
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:51:33.767487
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-26 11:51:42.201357
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("\n=========================")
    print("Test constructor of class EitbIE")
    print("=========================")

    # Testing with a valid url
    print("\nTEST CASE 1: Testing with a valid url")
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    assert re.match(EitbIE._VALID_URL, url, re.VERBOSE) is not None
    eitb = EitbIE()
    info = eitb.extract(url)
    assert info['id'] == "4090227752001"

# Generated at 2022-06-26 11:51:44.366298
# Unit test for constructor of class EitbIE
def test_EitbIE():
    d = EitbIE()
    assert d != None


# Generated at 2022-06-26 11:51:54.737125
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from youtube_dl.compat import compat_str
    from youtube_dl.utils import unescapeHTML

    ie = EitbIE('es.eitb.tv', {})
    assert ie.params is not None # to ensure that es.eitb.tv has been correctly recognized 
    video = ie._download_webpage(
        'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
        '4090227752001')
    assert compat_str(video)
    
    # test for unescapeHTML
    assert unescapeHTML("&#39;") == "'"
    # print(unescapeHTML("&#39;"))
    #

# Generated at 2022-06-26 11:52:24.117205
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:52:26.590551
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert isinstance(eitb, EitbIE)

# Generated at 2022-06-26 11:52:38.806621
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:51.433691
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from contextlib import closing
    from .common import test_curl_location;
    from .extractor import NON_HTTP_URL

    NOT_EXISTED_VIDEO_ID = "1"
    REAL_VIDEO_ID = "4104995148001"

    ie = EitbIE()

    with closing(ie) as eitb_ie:
        assert ie.get_url(NOT_EXISTED_VIDEO_ID) == NON_HTTP_URL
        assert ie.get_url(REAL_VIDEO_ID) == \
            'http://www.eitb.tv/eu/bideoa/' + REAL_VIDEO_ID


# Generated at 2022-06-26 11:52:58.848708
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "eitb.tv"
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Unit tests for methods extractor.py and utils.py
#       _real_extract(self, url)
#       float_or_none(value, scale=1)
#       int_or_none(value)
#       parse_iso8601(timestamp, tz?), and datetime.datetime.strptime()
#       sanitized_Request(url, headers=None, query=None)
#       _download_json(self, url_or_request, video_id,

# Generated at 2022-06-26 11:53:06.175381
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:53:09.480382
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE();
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:53:19.091623
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'

    assert EitbIE._match_id(url) == video_id
    assert EitbIE._match_id('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/') == video_id

# Generated at 2022-06-26 11:53:22.654540
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    instance = eitbIE._downloader
    assert instance is not None

# Generated at 2022-06-26 11:53:24.072409
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(True)

# Generated at 2022-06-26 11:54:41.675178
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        EitbIE(None)
    except TypeError as e:
        assert str(e) == "object() takes no parameters"

eitb = EitbIE(None)


# Generated at 2022-06-26 11:54:43.489037
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE.test()

# Generated at 2022-06-26 11:54:46.313736
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()


# Generated at 2022-06-26 11:54:53.582268
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie.IE_NAME == 'eitb.tv'



# Generated at 2022-06-26 11:55:06.753171
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# test instantiation of class EitbIE
	eitbIE = EitbIE()
	assert(eitbIE)

	# test IE_NAME
	assert(eitbIE.IE_NAME == 'eitb.tv')

	# test _VALID_URL
	assert(eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

	# test _TEST

# Generated at 2022-06-26 11:55:08.891457
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE().extract('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:55:16.567790
# Unit test for constructor of class EitbIE
def test_EitbIE():
	print("[running test for EitbIE](https://www.eitb.tv/es/video/programas/el-hombre-de-tu-vida/4073004586001/4073004586001/)")
	eitbIE = EitbIE()
	eitbIE._real_extract("https://www.eitb.tv/es/video/programas/el-hombre-de-tu-vida/4073004586001/4073004586001/")

# Generated at 2022-06-26 11:55:19.147373
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import ie_tests
    ie_tests.test_class(EitbIE, EitbIE._TEST)

# Generated at 2022-06-26 11:55:22.578493
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Create an instance of class EitbIE
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL

# Generated at 2022-06-26 11:55:30.561775
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().extract('http://www.eitb.tv/eu/bideoa/60-minutos/4095549885001/cambio-de-presidente-en-arabia-saudi/') == {
            'id': '4095549885001',
            'ext': 'mp4',
            'title': '60 minutotzat (Cambio de presidente en Arabia Saudí)',
            'description': 'Jakintzarako programa.',
            'duration': 3013.44,
            'timestamp': 1388223600,
            'upload_date': '20131208',
            'tags': [],
        }


# Generated at 2022-06-26 11:58:29.282557
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE(None)
    # This method of the class should be called
    ie._match_id({'url':'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'})

# Generated at 2022-06-26 11:58:40.184453
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/', 'http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4090227752001/')

# Generated at 2022-06-26 11:58:41.109952
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE

# Generated at 2022-06-26 11:58:43.456291
# Unit test for constructor of class EitbIE
def test_EitbIE():
    Eitb(EitbIE._VALID_URL, {})

# Generated at 2022-06-26 11:58:44.840062
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().test()

# Generated at 2022-06-26 11:58:49.848084
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    if a.IE_NAME == 'eitb.tv':
        print("\nConstructor of EitbIE test passed")
    else:
        print("\nConstructor of EitbIE test failed")


# Generated at 2022-06-26 11:58:52.784683
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb is not None

# Generated at 2022-06-26 11:58:58.239086
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    EitbIE tests
    """
    # import pytest
    # pytest.main()
    # with pytest.raises(Exception):
    # raise
    assert EitbIE

# Generated at 2022-06-26 11:59:00.883629
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE == getattr(InfoExtractor, 'EitbIE') == EitbIE()

# Generated at 2022-06-26 11:59:01.959977
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie