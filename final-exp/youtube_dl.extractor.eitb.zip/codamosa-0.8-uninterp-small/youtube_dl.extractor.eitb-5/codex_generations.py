

# Generated at 2022-06-26 11:49:52.694344
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()



# Generated at 2022-06-26 11:49:54.113475
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_0 = EitbIE()

# Generated at 2022-06-26 11:50:00.551276
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('Testing EitbIE...')
    eitb_i_e = EitbIE()
    assert isinstance(eitb_i_e, InfoExtractor)
    eitb_i_e = EitbIE(None)
    assert isinstance(eitb_i_e, InfoExtractor)
    print('Done!')


# Generated at 2022-06-26 11:50:04.698739
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-26 11:50:05.366729
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:12.047034
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test default state
    eitb_i_e = EitbIE()
    assert 'YouTube' == eitb_i_e.IE_NAME
    assert 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)' == eitb_i_e._VALID_URL
    from .common import InfoExtractor
    assert isinstance(eitb_i_e, InfoExtractor)

# Generated at 2022-06-26 11:50:13.662643
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    assert eitb_i_e is not None

# Generated at 2022-06-26 11:50:15.855242
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    # Checks whether the instantiation is correct
    assert eitb_i_e is not None

# Generated at 2022-06-26 11:50:17.417484
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()


# Generated at 2022-06-26 11:50:19.070402
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

# Generated at 2022-06-26 11:50:36.121896
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(eitb_i_e_0, EitbIE)



# Generated at 2022-06-26 11:50:37.665064
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0 != None, 'Class EitbIE should exist'


# Generated at 2022-06-26 11:50:39.165587
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()


# Generated at 2022-06-26 11:50:44.571249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    unit_test_case_0 = """Check for expected attribute values
    for EitbIE class.
    """
    eitb_i_e_0 = EitbIE(unit_test_case_0)
    unit_test_case_1 = """Check for expected attribute values
    for InfoExtractor class.
    """
    info_extractor_0 = InfoExtractor(unit_test_case_1)


# Generated at 2022-06-26 11:50:46.328528
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass # TODO: Implement your test here


# Generated at 2022-06-26 11:50:48.653791
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0 != None


# Generated at 2022-06-26 11:50:55.617442
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from ..__main__ import url_result
    from ..__main__ import update_history
    from ..extractor.common import InfoExtractor
    from ..YoutubeDL import YoutubeDL
    from ..utils import extract_attributes
    import re

    def get_testcases_from_url(url):
        return [
            {
                'url': url,
                'only_matching': True,
            },
        ]


# Generated at 2022-06-26 11:50:56.257169
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:50:56.839963
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:57.796634
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

# Generated at 2022-06-26 11:51:15.418504
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test functionality of constructor of class EitbIE
    """
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:51:19.839060
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:20.470520
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:51:21.624409
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-26 11:51:25.967945
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert len(EitbIE.IE_NAME) > 0
    assert len(EitbIE._VALID_URL) > 0
    assert '_real_extract' in EitbIE.__dict__
    assert 'mam' in EitbIE._TEST['url']
    assert len(EitbIE._TEST['md5']) > 0
    assert 'duration' in EitbIE._TEST['info_dict']

# Generated at 2022-06-26 11:51:27.366691
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "EitbIE"

# Generated at 2022-06-26 11:51:28.768071
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    # Just in case, call the old constructor
    class_(None)

# Generated at 2022-06-26 11:51:35.294872
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Constructor without arguments must fail:
    try:
        ie = EitbIE()
    except TypeError:
        pass
    # ... but constructor with argument url must not fail:
    ie = EitbIE(url='http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:51:40.061020
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE('eitb.tv')
	assert ie.__class__.__name__ == 'EitbIE'
	assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:53.425833
# Unit test for constructor of class EitbIE
def test_EitbIE():
    import urllib2
    inst = EitbIE()
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    result = inst._real_extract(url)
    req = urllib2.Request(
        url = url,
        headers = {'Accept': 'application/json'} )
    response = urllib2.urlopen(req)
    json_object = json.loads(response.read())
    assert json_object is not None, 'Downloading video JSON error!'
    assert result['title'] == json_object['web_media'][0]['NAME_ES'], 'Downloading video JSON failed!'

# Generated at 2022-06-26 11:52:21.656512
# Unit test for constructor of class EitbIE
def test_EitbIE():
    result = EitbIE({})
    assert result.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:52:24.513961
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert eitbIE.IE_NAME == 'eitb.tv'
    assert eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:52:25.890927
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbie = EitbIE()

# Generated at 2022-06-26 11:52:31.829934
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/nahieran-bideoak/urdaile-cake-design/4226989432001/frame')
    assert ie.name == 'eitb.tv'

# Generated at 2022-06-26 11:52:32.986738
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie != None


# Generated at 2022-06-26 11:52:37.537508
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_object = EitbIE()
    assert test_object.IE_NAME == 'eitb.tv'
    assert test_object._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:49.835204
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()

# Generated at 2022-06-26 11:53:01.024749
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from Extractor import Extractor
    from extractor.common import InfoExtractor
    from extractor.eitb import EitbIE
    from extractor.youtube import YoutubeIE

    assert issubclass(EitbIE, InfoExtractor)
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert issubclass(EitbIE, YoutubeIE)

    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:53:04.986416
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert(ie.IE_NAME == 'eitb.tv')


# Generated at 2022-06-26 11:53:10.565020
# Unit test for constructor of class EitbIE
def test_EitbIE():
    'Test EitbIE constructor'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE()
    assert(ie._VALID_URL == ie._match_id(url))
    assert(ie.IE_NAME == ie.ie_key())

    # test class methods
    obj_test = EitbIE()
    obj_test.suitable('test')
    obj_test.extract(url)



# Generated at 2022-06-26 11:54:25.529990
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # The class EitbIE must be callable
    EitbIE()
    # Test the constructor of class EitbIE
    # It should not raise any exception
    EitbIE()

# Generated at 2022-06-26 11:54:29.471314
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from zelvac.extractor.eitb import EitbIE
    assert EitbIE._VALID_URL is not None

# Generated at 2022-06-26 11:54:31.304310
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import EitbIE
    eitbIE = EitbIE()
    print(type(eitbIE))
    assert(True)


# Generated at 2022-06-26 11:54:42.794548
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE.IE_NAME == "eitb.tv")
    assert(EitbIE.IE_DESC == "eitb.tv")
    assert(EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert(EitbIE._TEST["url"] == "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-26 11:54:43.899480
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:54:48.569033
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('test')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:54:51.835089
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Instantiation test
    """
    EitbIE()

# Generated at 2022-06-26 11:54:52.869979
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-26 11:54:53.974324
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('EitbIE', 'www.eitb.tv')

# Generated at 2022-06-26 11:55:06.855494
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/eu/bideoa/sail-on/4100901533001/4107728708001/?lang=es'
    instance = EitbIE()
    assert instance.suitable(url)
    url = 'http://www.eitb.tv/eu/bideoa/sail-on/4100901533001/4107728708001/?lang=en'
    assert instance.suitable(url)
    url = 'http://www.eitb.tv/eu/bideoa/sail-on/4100901533001/4107728708001/?lang=fr'
    assert instance.suitable(url)

# Generated at 2022-06-26 11:58:06.650365
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    EitbIE()

# Generated at 2022-06-26 11:58:11.638277
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check if an EitbIE instance is created
    eitbie = EitbIE()
    assert eitbie is not None

    # Call for 'test'
    test = eitbie.test()
    assert 'Test succeeded' in test

    # Call for extract of URL
    url = "http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/"
    title = eitbie.extract(url)["title"]
    assert '60 minutos' in title

# Generated at 2022-06-26 11:58:14.497142
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-26 11:58:19.598434
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    assert test.IE_NAME == 'eitb.tv'
    assert test._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:58:31.271758
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from . import ParserTestCase
    # The following url is not an actual video url but just a
    # link to the page with the video.
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'

# Generated at 2022-06-26 11:58:33.283747
# Unit test for constructor of class EitbIE
def test_EitbIE():
    InfoExtractor('EitbIE')

# Generated at 2022-06-26 11:58:37.182873
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(
        EitbIE(),
        EitbIE,
        msg="constructor of class EitbIE is broken"
    )

# Generated at 2022-06-26 11:58:38.032062
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:58:46.092356
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Definition of variables
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'

# Generated at 2022-06-26 11:58:51.282626
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert 'EitbIE' in ie.IE_NAME
    assert 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/' == ie._VALID_URL