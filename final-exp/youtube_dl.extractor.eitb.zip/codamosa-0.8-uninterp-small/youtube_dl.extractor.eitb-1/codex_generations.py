

# Generated at 2022-06-26 11:49:54.519195
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:49:58.444558
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test for type of return value of constructor of class EitbIE
    assert isinstance(eitb_i_e_0, EitbIE)


# Generated at 2022-06-26 11:49:59.492371
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()


# Generated at 2022-06-26 11:50:00.550864
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

# Generated at 2022-06-26 11:50:11.292522
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert hasattr(eitb_i_e_0, "_download_webpage"), "eitb_i_e._download_webpage missing"
    assert hasattr(eitb_i_e_0, "_real_extract"), "eitb_i_e._real_extract missing"
    assert hasattr(eitb_i_e_0, "_match_id"), "eitb_i_e._match_id missing"
    assert hasattr(eitb_i_e_0, "_REAL_URL_PATTERN"), "eitb_i_e._REAL_URL_PATTERN missing"
    assert hasattr(eitb_i_e_0, "_TEST"), "eitb_i_e._TEST missing"

# Generated at 2022-06-26 11:50:12.201257
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE



# Generated at 2022-06-26 11:50:13.839529
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    test_case_0()


# Generated at 2022-06-26 11:50:15.133316
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), EitbIE)


# Generated at 2022-06-26 11:50:16.287114
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert True


# Generated at 2022-06-26 11:50:17.082977
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass



# Generated at 2022-06-26 11:50:30.207603
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check that constructor of class EitbIE accepts single argument
    # and returns EitbIE instance.
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert isinstance(ie, EitbIE)


# Generated at 2022-06-26 11:50:31.175437
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE

# Generated at 2022-06-26 11:50:34.360152
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:38.706074
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:42.529615
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    print(ie)

# Generated at 2022-06-26 11:50:45.852331
# Unit test for constructor of class EitbIE

# Generated at 2022-06-26 11:50:50.967677
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.suitable('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')


# Generated at 2022-06-26 11:50:55.912065
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE('Eitb','http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:50:59.923558
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE(url)


# Generated at 2022-06-26 11:51:03.930231
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test = EitbIE()
    assert test.extract_info(EitbIE._TEST['url']) == EitbIE._TEST['info_dict']


# Generated at 2022-06-26 11:51:23.878785
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'eitb.tv'
    assert eitb.IE_DESC == 'EITB - Euskal Irrati Telebista'
    assert eitb._VALID_URL == EitbIE._VALID_URL
    assert eitb._TEST == EitbIE._TEST


# Test for EitbIE._real_extract()

# Generated at 2022-06-26 11:51:26.927184
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('')
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:51:31.521869
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # TODO: Remove this
    assert EitbIE(InfoExtractorTestCaseImpl())._VALID_URL == EitbIE.VALID_URL
    assert EitbIE(InfoExtractorTestCaseImpl()).IE_NAME == EitbIE.IE_NAME
    assert EitbIE(InfoExtractorTestCaseImpl())._TEST == EitbIE.TEST

# Generated at 2022-06-26 11:51:35.458244
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/', test=True)

# Generated at 2022-06-26 11:51:40.760988
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE('eitb.tv')
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:51:43.850615
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()
    assert e.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:51:50.982453
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from .service_eitb import EitbIE
    eitbIE = EitbIE()
    assert(eitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-26 11:51:52.939808
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE() != None)


# Generated at 2022-06-26 11:51:54.677565
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-26 11:51:55.487269
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-26 11:52:29.036452
# Unit test for constructor of class EitbIE
def test_EitbIE():
    _EitbIE = EitbIE()
    assert _EitbIE.extract('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/'), "URL not valid"
    assert _EitbIE.extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'), "URL not valid"


# Generated at 2022-06-26 11:52:30.506388
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('www.eitb.tv')

# Generated at 2022-06-26 11:52:31.407378
# Unit test for constructor of class EitbIE
def test_EitbIE():
    obj = EitbIE()
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-26 11:52:33.473404
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie is not None

# Generated at 2022-06-26 11:52:34.327947
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:52:35.422130
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL

# Generated at 2022-06-26 11:52:41.398799
# Unit test for constructor of class EitbIE
def test_EitbIE():
    inst = EitbIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:46.369097
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # The EitbIE class is being tested, but the name of the class being tested is IE_NAME.
    # Example: if the name of the class being tested is YoutubeIE, the value of IE_NAME would be 'Youtube'.
    # See http://pytest-3.0.5.tar.gz/en/latest/example/parametrize.html#a-quick-port-of-testscenarios-testscenarios
    ie = EitbIE(EitbIE.ie_key())
    assert ie.ie_key() == 'Eitb'
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:52:49.224589
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:52:53.749819
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL
    assert repr(EitbIE()).startswith('<class ')
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:54:05.588292
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e = EitbIE()

# Generated at 2022-06-26 11:54:10.853626
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # instantiate an object of class EitbIE
    eitbie = EitbIE()

    # check if the object is an instance of class EitbIE
    assert isinstance(eitbie, EitbIE)

    # check if the object is an instance of class YoutubeIE
    assert isinstance(eitbie, InfoExtractor)

# Generated at 2022-06-26 11:54:14.281096
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
test_EitbIE()

# Generated at 2022-06-26 11:54:16.030852
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-26 11:54:21.905922
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert ie._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert ie._match_id(ie._TEST['url']) == '4090227752001'

# Generated at 2022-06-26 11:54:33.823810
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:54:38.684463
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(InfoExtractor)._download_json(
        'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/',
        '4090227752001', 'Downloading video JSON')

# Generated at 2022-06-26 11:54:41.601134
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == "Eitb.tv"
    assert ie.IE_DESC == "Eitb.tv Video"

# Generated at 2022-06-26 11:54:46.032300
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert str(ie) == "<EitbIE class=\"EitbIE\" method=\"_real_extract\">"

# Generated at 2022-06-26 11:54:48.304394
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb_ie = EitbIE()

# Generated at 2022-06-26 11:57:37.447058
# Unit test for constructor of class EitbIE
def test_EitbIE():

	test_object = EitbIE()

	# check for existence of name attribute
	assert(test_object.IE_NAME != None)

	# check for existence of valid_url attribute
	assert(test_object._VALID_URL != None)

# Generated at 2022-06-26 11:57:49.514907
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video1 = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video2 = 'http://www.eitb.tv/es/video/kale-korrika/4094263155001/4094263696001/korrika-18/'
    video3 = 'http://www.eitb.tv/eu/bideoa/kale-bideoa/4324291546001/4323456533001/lau-berrirak-hiru-urte/'

# Generated at 2022-06-26 11:57:53.809872
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test EitbIE
    from .test_IE import _call_ie
    _call_ie(EitbIE, [EitbIE._TEST])

# Generated at 2022-06-26 11:57:59.182243
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_url = "http://www.eitb.tv/eu/bideoa/garagardoa-1-3/2458034/garagardoa-1-3/"
    EitbIE.ie._downloader = None
    EitbIE.ie.initialize()
    EitbIE.ie._real_initialize()
    EitbIE.ie._real_extract(video_url)

# Generated at 2022-06-26 11:58:09.327494
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    test_obj = EitbIE()
    assert isinstance(test_obj, InfoExtractor)
    assert test_obj.IE_NAME == 'eitb.tv'
    assert test_obj.suitable(test_url)
    assert test_obj.suitable(test_url + '?')

# Generated at 2022-06-26 11:58:17.308837
# Unit test for constructor of class EitbIE
def test_EitbIE():
    testEitbIE = EitbIE()

    assert testEitbIE.IE_NAME == 'eitb.tv'
    assert testEitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:58:23.024886
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test name of class
    assert EitbIE.IE_NAME == 'eitb.tv'
    # Test if match method of class
    assert EitbIE._match_id('https://www.eitb.tv/eu/bideoa/teknologia/musika-bebez-erreproduzigailuetan-abestek-elkartu/4090227752001/') == '4090227752001'
    # Test url constructor
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:58:23.778656
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == ie.name


# Generated at 2022-06-26 11:58:27.420819
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    result = type(eitb_ie)
    assert result == EitbIE, 'EitbIE class constructor error'

# Generated at 2022-06-26 11:58:30.648312
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert len(re.findall("[a-zA-Z][^A-Z]*", eitb_ie.IE_NAME)) == 2