

# Generated at 2022-06-26 11:49:49.720754
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert test_case_0() == None

# Generated at 2022-06-26 11:49:50.441283
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case_0()

# Generated at 2022-06-26 11:49:52.482514
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(eitb_i_e_0, EitbIE)


# Generated at 2022-06-26 11:50:04.445092
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert EitbIE()._TEST['url'] == 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert EitbIE()._TEST['md5'] == 'edf4436247185adee3ea18ce64c47998'

# Generated at 2022-06-26 11:50:05.894249
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:07.317941
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert len(EitbIE.__dict__) > 0


# Generated at 2022-06-26 11:50:11.715893
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    EitbIE().extract(url)


# Generated at 2022-06-26 11:50:12.478961
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()

# Generated at 2022-06-26 11:50:13.503033
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case_0()

# Generated at 2022-06-26 11:50:14.760099
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_1 = EitbIE()


# Generated at 2022-06-26 11:50:31.046652
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-26 11:50:32.561189
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()


# Generated at 2022-06-26 11:50:34.442231
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print(__name__)
    assert(test_case_0())
    print('Processing class EitbIE - DONE!')

# Generated at 2022-06-26 11:50:35.356786
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()


# Generated at 2022-06-26 11:50:44.869994
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiation of EitbIE class should be completed successfully
    eitb_ie = EitbIE()
    assert eitb_ie is not None
    # 'IE_NAME' attribute of EitbIE class should be 'eitb.tv'
    assert eitb_ie.IE_NAME == 'eitb.tv'
    # '_VALID_URL' attribute of EitbIE class should be valid url for 'http://www.eitb.tv/eu/bideoa/episodio-1-aritz-y-la-tierra/5342856717001/'

# Generated at 2022-06-26 11:50:57.561470
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE('http://www.eitb.tv/es/video/zuzendaritza-komunikazioak-euskal-kultur-erakundeen-egitura-bihurtu-da/594562/', {})

# Generated at 2022-06-26 11:51:07.879803
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e_1 = EitbIE()
    assert eitb_i_e_1.IE_NAME == 'eitb.tv'
    assert eitb_i_e_1._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

from unittest import TestCase

from youtube_dl import YoutubeDL
from youtube_dl.extractor.eitb import EitbIE
from youtube_dl.utils import ExtractorError
from tests.test_utils_download import TestDownload

from json import dump, load

from contextlib import ContextDecorator



# Generated at 2022-06-26 11:51:08.845417
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Constructor of class EitbIE is OK")

# Generated at 2022-06-26 11:51:19.934850
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:27.491797
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # test EitbIE.ie_key
    assert EitbIE.ie_key() == 'Eitb'

    assert EitbIE.ie_key() == 'Eitb'

    # test EitbIE._html_search_regex
    assert EitbIE._html_search_regex('a', 'b') is None

    assert EitbIE._html_search_regex('a', 'b') is None

    # test EitbIE._get_tbr
    assert EitbIE._get_tbr('a') is None

    assert EitbIE._get_tbr('a') is None

    # test EitbIE.ie
    assert EitbIE.ie

    assert EitbIE.ie

    # test EitbIE.suitable
    assert EitbIE

# Generated at 2022-06-26 11:51:54.019596
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'http://www.eitb.tv/eu/bideoa/[^/]+/\d+/\d+'
    assert ie.test_urls == ['http://eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/']
    assert ie.test_video_id

# Generated at 2022-06-26 11:52:00.341666
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert str(ie) == 'EITB'

# Generated at 2022-06-26 11:52:01.688580
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Instantiate EitbIE
    eitb = EitbIE()

# Generated at 2022-06-26 11:52:04.232260
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    return eitb

# Generated at 2022-06-26 11:52:05.622426
# Unit test for constructor of class EitbIE
def test_EitbIE():
    const = EitbIE()
    assert const != None

# Generated at 2022-06-26 11:52:07.935181
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.__name__ == "EitbIE"


# Generated at 2022-06-26 11:52:13.609289
# Unit test for constructor of class EitbIE
def test_EitbIE():
    Eitb = EitbIE(InfoExtractor())
    assert Eitb.IE_NAME == 'eitb.tv'
    assert 'eitb.tv' in Eitb.IE_DESC


# Generated at 2022-06-26 11:52:18.724836
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("Testing class EitbIE")
    assert EitbIE != None

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-26 11:52:21.478742
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:52:29.348960
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print("------------------ UNIT TESTING ------------------ ")
    url = 'http://www.eitb.tv/eu/bideoa/kultura/programa/6-minutuak/2014/06/26/bernardo-atxaga-bakarka-soinua-kontatzen/'
    eitb = EitbIE()
    eitb._VALID_URL = r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    print("------------------ URL: " + url + "------------------ ")
    result = eitb.suitable(url)
    print("------------------ EXPECTING: True------------------ ")

# Generated at 2022-06-26 11:53:01.662377
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE()
    assert eitb.IE_NAME == 'EitbIE'


# Generated at 2022-06-26 11:53:10.660326
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:53:16.250652
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    print(eitbIE.IE_NAME)
    print(eitbIE._VALID_URL)

if __name__ == "__main__":
    test_EitbIE()

# Generated at 2022-06-26 11:53:17.692707
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE.suite()


if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-26 11:53:21.076435
# Unit test for constructor of class EitbIE
def test_EitbIE():
	eitb = EitbIE()

# Generated at 2022-06-26 11:53:22.860194
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('')

# Generated at 2022-06-26 11:53:28.326252
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info_extractor = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert info_extractor != None


# Generated at 2022-06-26 11:53:39.802565
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Usage: python2 -c "import unittest, extractor_tests; extractor_tests.test_eitb('http://www.eitb.tv/eu/bideoa/60-minutos/4090227752001/', 'EdL-WgwOnmE')" """
    print('Instantiating EitbIE')
    eitbIE = EitbIE(None)
    print('Done')

    test_cases = [
        'http://www.eitb.tv/eu/bideoa/lasa-eta-zabala-v/4089722955001/',  # == EdL-WgwOnmE
    ]

    for test_case in test_cases:
        print('Testing %s' % test_case)

# Generated at 2022-06-26 11:53:40.717984
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE();

# Generated at 2022-06-26 11:53:42.700752
# Unit test for constructor of class EitbIE
def test_EitbIE():
    global EitbIE
    EitbIE()

# Generated at 2022-06-26 11:54:57.428397
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv' 

# Generated at 2022-06-26 11:54:58.545325
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-26 11:55:00.889386
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-26 11:55:04.840021
# Unit test for constructor of class EitbIE
def test_EitbIE():
    foundTypes = set()
    for line in globals():
        if line.startswith('test_'):
            if line.endswith('EitbIE'):
                foundTypes.add(line[4:-4])
    return foundTypes

# Generated at 2022-06-26 11:55:08.112238
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:55:11.250597
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE()
    assert (instance.ie_key() == 'eitb.tv')


# Generated at 2022-06-26 11:55:15.551598
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE(None)._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:17.983133
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    assert i.IE_NAME == 'eitb.tv'



# Generated at 2022-06-26 11:55:23.085561
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:24.517549
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None, None)

# Generated at 2022-06-26 11:58:27.387495
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()._extract_info("http://www.eitb.tv/eu/bideoa/munduko-jarduerak/munduko-jarduerak-3/38059-munduko-jarduerak-3/")


# Generated at 2022-06-26 11:58:34.570741
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE('http://www.eitb.tv/eu/bideoa/zuzenean/201407040500/plano-general-2014-07-04-17-00-00/')
    EitbIE('http://www.eitb.tv/eu/bideoa/zuzenean/201407040500/plano-general-2014-07-04-17-00-00/')
    EitbIE('http://www.eitb.tv/eu/bideoa/munduarekiko-euskara/201410011200/berria-kultura-2014-10-01-12-00-00/')

# Generated at 2022-06-26 11:58:35.309964
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Initialize object
    EitbIE()
    pass

# Generated at 2022-06-26 11:58:36.451308
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:58:45.074169
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == ""
    assert ie.IE_NAME == ""
    assert ie._TEST == {}
    assert ie._downloader == None
    assert ie.params == {}
    assert ie._screen_id == None
    assert ie._ids == {}
    assert ie._downloader == None
    assert ie._screen_id in ie._ids
    assert ie._ids[ie._screen_id] == 0
    assert ie.result_type == None
    assert ie.playlist_result == []
    assert ie.playliststart != None
    assert ie.playlistend != None
    assert ie.urls == []
    assert ie.url == ie.urls[0]
    assert ie.playlist is None

# Generated at 2022-06-26 11:58:48.102264
# Unit test for constructor of class EitbIE
def test_EitbIE():
    class_ = EitbIE
    ie = class_(None)
    assert ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:58:50.947489
# Unit test for constructor of class EitbIE
def test_EitbIE():
	# Create an instance of class EitbIE
	instance = EitbIE()
	# Check if it is a subclass of InfoExtractor
	assert issubclass(EitbIE, InfoExtractor)


# Generated at 2022-06-26 11:58:52.881933
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("test")

# Generated at 2022-06-26 11:59:03.665584
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    print("Test EitbIE")
    print("EitbIE name: " + instance.IE_NAME)
    print("EitbIE website: " + instance.IE_WEB)
    print("EitbIE get_tables(): " + instance.get_tables())
    print("EitbIE get_fields(): " + instance.get_fields())

# test = test_EitbIE();

# Generated at 2022-06-26 11:59:05.184192
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE(None)