

# Generated at 2022-06-26 11:49:52.703929
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-26 11:50:04.697141
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    assert eitb_i_e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:05.485961
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(eitb_i_e_0.IE_NAME == "EitbIE")


# Generated at 2022-06-26 11:50:07.259391
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0.IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:50:15.601534
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert test_case_0().IE_NAME == 'eitb.tv'
    assert test_case_0()._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:20.410700
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE.VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:50:25.398651
# Unit test for constructor of class EitbIE
def test_EitbIE():
    from UnitTest import UnitTest
    test_list_0 = ["EitbIE",
                   "test_case_0",
                   "__main__",
                   "test_EitbIE"]
    UnitTest.initialize(test_list_0)
    UnitTest.start_test()


if __name__ == "__main__":
    test_EitbIE()

# Generated at 2022-06-26 11:50:26.976519
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'


# Generated at 2022-06-26 11:50:36.675192
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """

    """
    # eitb_i_e_0 = EitbIE()
    # assert_equals(eitb_i_e_0._VALID_URL, r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    # assert_equals(eitb_i_e_0.IE_NAME, 'eitb.tv')
    # assert_equals(eitb_i_e_0._TEST, {'url': 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-

# Generated at 2022-06-26 11:50:46.617354
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:50:57.282212
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    # Check if the name of class IE is in the list of supported IEs.
    assert ie.IE_NAME in ie.gen_extractors()

# Generated at 2022-06-26 11:50:57.890608
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:51:01.430529
# Unit test for constructor of class EitbIE
def test_EitbIE():
	assert EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
	assert EitbIE.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:51:02.731582
# Unit test for constructor of class EitbIE
def test_EitbIE():
  assert isinstance(EitbIE, type)


# Generated at 2022-06-26 11:51:05.938231
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE() # just instantiate class, it should work without error

if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-26 11:51:09.576444
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Simple unit test for EitbIE.
    """
    # Create an instance of the class
    extractor = EitbIE()
    assert extractor is not None


# Generated at 2022-06-26 11:51:20.641765
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_id = '4090227752001'
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    media = "http://mam.eitb.eus/mam/REST/ServiceMultiweb/Video/MULTIWEBTV/4090227752001/"

# Generated at 2022-06-26 11:51:22.197643
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:51:28.506516
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # For testing purposes we need to instanciate this class
    constructor_test_utility = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    # So we can test if regular expression is valid and works
    check = constructor_test_utility._VALID_URL
    assert check == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # And now we test if the class constructor can create an object with the right attributes

# Generated at 2022-06-26 11:51:33.494734
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        eitbIE = EitbIE(None, 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    except ZeroDivisionError:
        pass

# Generated at 2022-06-26 11:51:48.656952
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie != None

# Generated at 2022-06-26 11:51:53.426366
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie.IE_NAME == 'eitb.tv'
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:51:54.321931
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:52:05.884929
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:52:13.180049
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-26 11:52:20.230400
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # only 1 constructor for class EitbIE
    constructor = EitbIE

    # testing constructor
    eitb = constructor(None)

    assert eitb.IE_NAME.find('eitb') == 0
    assert eitb._VALID_URL is not None

# Generated at 2022-06-26 11:52:27.298946
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # INPUT
    url = "http://www.eitb.tv/eu/bideoa/balentriako-dantza-balentriako-dantza-2014/5518771949001/5518772170001/sebastian-agirre-piarres-zar/";
    # INPUT END

    print("Testing ", EitbIE.IE_NAME, " with url:", url, " :\n")
    obj = EitbIE()

    info = obj._real_extract(url)
    print("INFO:", info, "\n")

# Generated at 2022-06-26 11:52:30.128774
# Unit test for constructor of class EitbIE
def test_EitbIE():
    try:
        from .EitbIE import EitbIE
    except ImportError:
        return
    url = 'http://www.eitb.tv/eu/bideoa/lasa-eta-zabala-30-urte/4090227734001/4090227752001/'
    ie = EitbIE(url)
    assert ie != None
    return

# Generated at 2022-06-26 11:52:39.896346
# Unit test for constructor of class EitbIE

# Generated at 2022-06-26 11:52:47.966603
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    # Check if the constructor of EitbIE is correct
    if ie.IE_NAME != 'eitb.tv':
        return False
    if ie._VALID_URL != r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)':
        return False
    return True


# Generated at 2022-06-26 11:53:30.828478
# Unit test for constructor of class EitbIE
def test_EitbIE():
	example_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
	assert EitbIE(example_url).IE_NAME == 'eitb.tv'
	assert EitbIE(example_url)._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:53:39.577260
# Unit test for constructor of class EitbIE
def test_EitbIE():
	print('Unit test for constructor of class EitbIE')
	try:
		# Create an instance of class EitbIE
		test_eitbie = EitbIE()
		# Check if the instance has the attribute _VALID_URL
		if (test_eitbie.IE_NAME):
			print('The instance of class EitbIE has the attribute IE_NAME')
		else:
			print('The instance of class EitbIE does not have the attribute IE_NAME')
	except:
		print('Error in the construction of an instance of class EitbIE')


# Generated at 2022-06-26 11:53:50.730679
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video = EitbIE()._extract_video('http://www.eitb.tv/eu/bideoa/bideoak/60-minutos/lasa-y-zabala-30-anos/4090227752001/')
    assert video.keys() == ['id', 'title', 'description', 'thumbnail', 'duration', 'timestamp', 'tags', 'formats'], 'The unit test failed'
    assert video['id'] == '4090227752001', 'The unit test failed'
    assert video['title'] == '60 minutos (Lasa y Zabala, 30 años)', 'The unit test failed'
    assert video['description'] == 'Programa de reportajes de actualidad.', 'The unit test failed'

# Generated at 2022-06-26 11:53:57.602083
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:53:58.601701
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE().suite()

# Generated at 2022-06-26 11:54:00.140963
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-26 11:54:03.585338
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    ret = ie.IE_NAME
    assert ret == 'eitb.tv'

# Generated at 2022-06-26 11:54:13.718896
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    eitbie = EitbIE()
    assert eitbie.IE_NAME == 'eitb.tv'
    assert eitbie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:54:25.680115
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test with url
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    ie = EitbIE(url)
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:54:36.153352
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()._real_extract("http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")


if __name__ == "__main__":
    """
    $ python test.py -v --tb=line --capture --resultlog=results.log
    """
    from youtube_dl.utils import log
    from youtube_dl.utils import std_headers
    from youtube_dl import YoutubeDL
    from youtube_dl.compat import compat_print

    log.setLevel(log.DEBUG)

# Generated at 2022-06-26 11:55:42.603031
# Unit test for constructor of class EitbIE
def test_EitbIE():
    info = EitbIE()._real_extract(EitbIE._TEST['url'])
    assert info['id'] == EitbIE._TEST['info_dict']['id']

# Generated at 2022-06-26 11:55:48.503120
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:51.006734
# Unit test for constructor of class EitbIE
def test_EitbIE():
    e=EitbIE()
    assert e is not None

# Generated at 2022-06-26 11:55:53.231194
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:55:54.307283
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE({}), EitbIE)

# Generated at 2022-06-26 11:55:57.175403
# Unit test for constructor of class EitbIE

# Generated at 2022-06-26 11:56:06.691260
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Negative tests
    with pytest.raises(Exception):
        assert EitbIE()
        assert EitbIE(url=None)
        assert EitbIE(url="")
        assert EitbIE(url="33333")
    # Positive tests
    assert EitbIE(url="https://www.eitb.tv/eu/bideoa/vid/4104995148001/")
    assert EitbIE(url="https://www.eitb.tv/eu/bideoa/vid/4090227752001/")

# Generated at 2022-06-26 11:56:17.877679
# Unit test for constructor of class EitbIE
def test_EitbIE():

    # Real url was used, so it was commented to avoid false positives
    #url = 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'

    # Instance of class EitbIE
    eitbie = EitbIE()

    # Try to download video with real url
    #eitbie._real_extract(url)

    # Try to download video with real id
    eitbie._real_extract('http://www.eitb.tv/eu/bideoa/%s' %video_id)

# Generated at 2022-06-26 11:56:19.253666
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-26 11:56:27.136861
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE()
    assert IE.IE_NAME == 'eitb.tv'
    assert IE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:10.023755
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == IE_NAME

# Generated at 2022-06-26 11:59:13.383423
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE("http://www.eitb.tv/eu/bideoa/bideoak/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/")

# Generated at 2022-06-26 11:59:16.717622
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb = EitbIE(object())
    assert eitb



# Generated at 2022-06-26 11:59:23.989075
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Note: this test needs internet connection
    """
    parse_from_url = EitbIE()._parse_from_url
    ie = parse_from_url('http://www.eitb.tv/es/video/6-minutos/4097404084001/4097404084001/trailer-de-6-minutos/')
    assert isinstance(ie, EitbIE)

# Generated at 2022-06-26 11:59:36.540708
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:59:38.772626
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL

# Generated at 2022-06-26 11:59:40.113702
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()