

# Generated at 2022-06-26 11:49:48.097938
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()

# Generated at 2022-06-26 11:49:52.071268
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    assert eitb_i_e.IE_NAME == 'eitb.tv'
    assert eitb_i_e._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:50:03.952253
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_i_e = EitbIE()
    eitb_i_e.suitable('http://www.eitb.tv/eu/bideoa/1412/eitb-laborategia/')
    eitb_i_e.extract('http://www.eitb.tv/eu/bideoa/1412/eitb-laborategia/')
    eitb_i_e.suitable('http://www.eitb.tv/eu/bideoa/1412/eitb-laborategia/')
    eitb_i_e.extract('http://www.eitb.tv/eu/bideoa/1412/eitb-laborategia/')

# Generated at 2022-06-26 11:50:05.330559
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert 0 == EitbIE()._TEST['duration']

# Generated at 2022-06-26 11:50:05.942762
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 11:50:07.748046
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # If no exception is raised, then the class constructor is OK.
    assert EitbIE()


# Generated at 2022-06-26 11:50:15.826928
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert_equal(eitb_i_e_0.IE_NAME, 'eitb.tv')
    assert_equal(eitb_i_e_0._VALID_URL, r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:50:25.984322
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_i_e_0.IE_NAME == 'eitb.tv'
    assert eitb_i_e_0.test_case_0 == eitb_i_e_0
    assert eitb_i_e_0.test_case_0 == test_case_0

# Generated at 2022-06-26 11:50:30.911624
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert (eitb_i_e_0._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')
    assert (eitb_i_e_0.IE_NAME == 'eitb.tv')


# Generated at 2022-06-26 11:50:40.244894
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert eitb_i_e_0._downloader == None
    assert eitb_i_e_0._downloader_download == None
    assert eitb_i_e_0._match_id == None
    assert eitb_i_e_0._html_search_regex == None
    assert eitb_i_e_0._download_json == None
    assert eitb_i_e_0._extract_m3u8_formats == None
    assert eitb_i_e_0._extract_f4m_formats == None
    assert eitb_i_e_0._sort_formats == None
    assert eitb_i_e_0.IE_NAME == 'eitb.tv'
    assert eitb_i_e_0._VALID

# Generated at 2022-06-26 11:50:50.193849
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'

# Unit tests for function _real_extract() of class EitbIE

# Generated at 2022-06-26 11:51:01.059581
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE._VALID_URL.match('http://www.eitb.tv/eu/bideoa/eskaintza/bideoak/4104995148001/4104995148001/')
    assert EitbIE._VALID_URL.match('http://www.eitb.tv/eu/bideoa/eskaintza/bideoak/4104995148001/4104995148001/')
    assert EitbIE._VALID_URL.match('http://www.eitb.tv/eu/bideoa/eskaintza/bideoak/4104995148001/4104995148001/')

# Generated at 2022-06-26 11:51:13.465867
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('Test EitbIE')
    test_url = 'http://www.eitb.tv/eu/bideoa/eguraldia/2014-11-10/1603602/eguraldia/'
    print('Test URL: ' + test_url)
    print('Test URL for constructor of class EitbIE')
    assert EitbIE._VALID_URL == EitbIE._TEST['url']
    test_instance = EitbIE(test_url)
    assert test_instance is not None
    print('Test EitbIE constructor is OK')
    test_real_extract = test_instance._real_extract(test_url)
    assert test_real_extract['id'] == '4090227752001'

# Generated at 2022-06-26 11:51:16.031160
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE.IE_NAME == 'eitb.tv'
    


# Generated at 2022-06-26 11:51:16.993839
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert(EitbIE())

# Generated at 2022-06-26 11:51:17.937201
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()


# Generated at 2022-06-26 11:51:23.462377
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test class constructor."""
    ie = EitbIE()
    assert ie.IE_NAME == 'eitb.tv'
    assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    # TODO: Test _TEST


# Generated at 2022-06-26 11:51:26.891183
# Unit test for constructor of class EitbIE
def test_EitbIE():
    a = EitbIE()
    assert a.IE_NAME.lower() == 'eitb.tv'


# Generated at 2022-06-26 11:51:30.344098
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test constructor of Video class EitbIE.
    """
    args = {'test': True} # add more arguments if needed
    test_instance = EitbIE(**args)
    assert isinstance(test_instance, InfoExtractor)


# Generated at 2022-06-26 11:51:31.342342
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()



# Generated at 2022-06-26 11:51:46.261415
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE({}), EitbIE)



# Generated at 2022-06-26 11:51:49.770596
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """Test class EitbIE"""
    video = EitbIE()
    assert video.IE_NAME == "eitb.tv"

# Generated at 2022-06-26 11:51:53.150345
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()._real_extract('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:52:05.476354
# Unit test for constructor of class EitbIE
def test_EitbIE():
    video_url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    video_id = '4090227752001'
    ie = EitbIE()
    
    # Test for _VALID_URL
    valid_urls = [video_url]
    for url in valid_urls:
        match = ie._VALID_URL.match(url)
        if match == None:
            raise Exception("Valid url was not matched")
    
    # Test for _real_extract

# Generated at 2022-06-26 11:52:07.795224
# Unit test for constructor of class EitbIE
def test_EitbIE():
    print('Unit test of the EitbIE constructor')
    ie = EitbIE()

# Generated at 2022-06-26 11:52:09.763829
# Unit test for constructor of class EitbIE
def test_EitbIE():
    pass

# Generated at 2022-06-26 11:52:19.084913
# Unit test for constructor of class EitbIE
def test_EitbIE():
    """
    Test of EitbIE constructor
    """
    x = EitbIE("a", "b", "c", "d", "e", "f")
    assert x.IE_NAME == "eitb.tv"
    assert x._VALID_URL == "https?://(?:www\\.)?eitb\\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)"

# Generated at 2022-06-26 11:52:19.941929
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:52:22.236123
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check that class constructor is able to build itself
    EitbIE()

# Generated at 2022-06-26 11:52:24.218063
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE().IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:52:49.953639
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE()._VALID_URL == EitbIE._VALID_URL

# Generated at 2022-06-26 11:53:01.094893
# Unit test for constructor of class EitbIE
def test_EitbIE():
    youtube_ie = EitbIE()
    # Test first the correctness of the initialization
    assert youtube_ie.ie_key() == 'eitb.tv'
    # If ok, test the correctness of method _real_extract
    url = 'http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    info = youtube_ie._real_extract(url)
    # Test the length of expected fields
    assert len(info) == 9
    # And now test the correctness of each field
    assert info['id'] == '4090227752001'
    assert info['ext'] == 'mp4'

# Generated at 2022-06-26 11:53:05.906189
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Test when arguments are given
    ie = EitbIE(EitbIE._TEST)
    # Test when arguments are not given
    ie = EitbIE()

# Generated at 2022-06-26 11:53:07.419967
# Unit test for constructor of class EitbIE
def test_EitbIE():
    return EitbIE()

# Generated at 2022-06-26 11:53:11.060426
# Unit test for constructor of class EitbIE
def test_EitbIE():
    '''
    Just test if the class can be created
    '''
    ie = EitbIE()
    assert ie



# Generated at 2022-06-26 11:53:12.491193
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None


# Generated at 2022-06-26 11:53:13.831749
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:53:16.452480
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # Check EITB test from expected results
    EitbIE().test_EitbIE()

# Generated at 2022-06-26 11:53:18.415091
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = globals()['EitbIE']()
    assert ie.name == 'eitb.tv'
    assert ie.ie_key() == 'eitb.tv'

# Generated at 2022-06-26 11:53:22.081921
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitbIE = EitbIE()
    assert isinstance(eitbIE, InfoExtractor)


# Generated at 2022-06-26 11:54:32.226210
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert isinstance(EitbIE(), InfoExtractor)

# Generated at 2022-06-26 11:54:33.570138
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()


# Generated at 2022-06-26 11:54:40.454983
# Unit test for constructor of class EitbIE
def test_EitbIE():
    r = EitbIE(None)
    assertEqual(r.IE_NAME,"eitb.tv")
    assertEqual(r._VALID_URL,r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')


# Generated at 2022-06-26 11:54:48.152521
# Unit test for constructor of class EitbIE
def test_EitbIE():
    test_EitbIE = EitbIE()

    assert(test_EitbIE._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)')

# Generated at 2022-06-26 11:54:53.766357
# Unit test for constructor of class EitbIE
def test_EitbIE():
    url = EitbIE._TEST['url']
    media = EitbIE._TEST['info_dict']
    EitbIE(url, media)
    media2 = EitbIE._TEST['info_dict']
    assert media == media2


# Generated at 2022-06-26 11:55:00.169798
# Unit test for constructor of class EitbIE
def test_EitbIE():
    instance = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090278878001/tutan-ekintza/')

    assert (instance.name == 'eitb.tv')

# Generated at 2022-06-26 11:55:01.697481
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE() is not None

# Generated at 2022-06-26 11:55:09.665914
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE('http://www.eitb.tv/es/video/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert ie._VALID_URL == 'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'

# Generated at 2022-06-26 11:55:18.362853
# Unit test for constructor of class EitbIE
def test_EitbIE():
    IE = EitbIE('http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/')
    assert IE.IE_NAME == 'eitb.tv'
    assert IE.VALID_URL == 'http://www.eitb.tv/eu/bideoa/60-minutos-60-minutos-2013-2014/4104995148001/4090227752001/lasa-y-zabala-30-anos/'
    assert IE.IE_DESC == 'eitb.tv'
    assert IE.video_id == '4090227752001'

# Generated at 2022-06-26 11:55:29.672804
# Unit test for constructor of class EitbIE
def test_EitbIE():
    eitb_ie = EitbIE()
    assert eitb_ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'
    assert eitb_ie.IE_NAME == 'eitb.tv'

# Generated at 2022-06-26 11:58:08.646792
# Unit test for constructor of class EitbIE
def test_EitbIE():
    # The return value of constructor function
    #   must be an object of InstanceType.
    assert isinstance(EitbIE(), InfoExtractor)

# Generated at 2022-06-26 11:58:09.707597
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

# Generated at 2022-06-26 11:58:17.153466
# Unit test for constructor of class EitbIE
def test_EitbIE():
	ie = EitbIE()
	assert ie.IE_NAME == 'eitb.tv'
	assert ie._VALID_URL == r'https?://(?:www\.)?eitb\.tv/(?:eu/bideoa|es/video)/[^/]+/\d+/(?P<id>\d+)'


# Generated at 2022-06-26 11:58:18.400517
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE is not None

# Generated at 2022-06-26 11:58:22.556413
# Unit test for constructor of class EitbIE
def test_EitbIE():
    infoExtractor = EitbIE()


if __name__ == '__main__':
    test_EitbIE()

# Generated at 2022-06-26 11:58:26.791943
# Unit test for constructor of class EitbIE
def test_EitbIE():
    assert EitbIE('www.eitb.tv/eu/bideoa/60-minutos/4104995148001/4090227752001/lasa-y-zabala-30-anos/')

# Generated at 2022-06-26 11:58:28.680397
# Unit test for constructor of class EitbIE
def test_EitbIE():
    i = EitbIE()
    i.IE_NAME

# Generated at 2022-06-26 11:58:30.549733
# Unit test for constructor of class EitbIE
def test_EitbIE():
    ie = EitbIE()

# Generated at 2022-06-26 11:58:34.110450
# Unit test for constructor of class EitbIE
def test_EitbIE():
    EitbIE()

if __name__ == '__main__':
    test_EitbIE()
    print("Done!")

# Generated at 2022-06-26 11:58:37.469026
# Unit test for constructor of class EitbIE
def test_EitbIE():
    parser = EitbIE()
    assert parser.IE_NAME == 'eitb.tv'