

# Generated at 2022-06-25 00:34:02.732813
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = selinux_fact_collector.collect()
    assert collected_facts['selinux_python_present'] == True
    assert collected_facts['selinux']['status'] == 'enabled'
    assert collected_facts['selinux']['policyvers'] == '30'
    assert collected_facts['selinux']['config_mode'] == 'enforcing'
    assert collected_facts['selinux']['mode'] == 'enforcing'
    assert collected_facts['selinux']['type'] == 'targeted'



# Generated at 2022-06-25 00:34:08.924362
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Check if the constructor raises an Exception for an empty facts file name.
    assertRaises(ValueError, SelinuxFactCollector)

    # Check if the constructor raises an Exception for an input facts file name with extension.
    assertRaises(ValueError, SelinuxFactCollector, 'file.txt')

    # Check if the constructor raises an Exception for an input facts file name with parent dir.
    assertRaises(ValueError, SelinuxFactCollector, 'dir/file')

    # Check if the constructor raises an Exception for an input facts file name with prefix.
    assertRaises(ValueError, SelinuxFactCollector, '_file')

    # Check if the constructor raises an Exception for an input facts file name with suffix.
    assertRaises(ValueError, SelinuxFactCollector, 'file_')

    # Check if the constructor raises

# Generated at 2022-06-25 00:34:11.850297
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:34:15.384223
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    facts_dict = selinux_fact_collector_1.collect()
    return

# Generated at 2022-06-25 00:34:22.244291
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    sh_facts = selinux_fact_collector_1.collect()
    assert 'selinux' in sh_facts
    assert sh_facts['selinux_python_present'] == True
    assert 'status' in sh_facts['selinux']
    assert sh_facts['selinux']['status'] == 'enabled'
    assert 'config_mode' in sh_facts['selinux']
    assert 'mode' in sh_facts['selinux']
    assert 'type' in sh_facts['selinux']
    assert sh_facts['selinux']['type'] == 'targeted'

# Generated at 2022-06-25 00:34:24.661931
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0 is not None
    assert selinux_fact_collector_0.name == 'selinux'

# Generated at 2022-06-25 00:34:25.934272
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:37.534081
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    if not HAVE_SELINUX:
        assert selinux_fact_collector_0.collect() == {'selinux': {'status': 'Missing selinux Python library'},
                                                      'selinux_python_present': False}
        return

    assert 'selinux' in selinux_fact_collector_0.collect()
    assert 'status' in selinux_fact_collector_0.collect().get('selinux', '')
    assert 'config_mode' in selinux_fact_collector_0.collect().get('selinux', '')
    assert 'mode' in selinux_fact_collector_0.collect().get('selinux', '')
    assert 'type' in selinux_fact_collector

# Generated at 2022-06-25 00:34:41.734433
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert facts_dict is not None, 'Expected to find a non-empty facts dictionary'

# Generated at 2022-06-25 00:34:43.202863
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert selinux_fact_collector_0


# Generated at 2022-06-25 00:34:49.600239
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:34:52.237261
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    # TODO: test for real


# Generated at 2022-06-25 00:34:56.646983
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:34:57.955471
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:59.482907
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'

# Generated at 2022-06-25 00:35:02.622634
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    var_0 = selinux_fact_collector_0.collect()



# Generated at 2022-06-25 00:35:04.643570
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with 0 params
    test_case_0()

# Generated at 2022-06-25 00:35:07.893141
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect()
    var_1 = selinux_fact_collector_1.collect()
    assert var_1 == {}


# Generated at 2022-06-25 00:35:13.837574
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    print('selinux_fact_collector_0 = ' + repr(selinux_fact_collector_0))
    print('selinux_fact_collector_0.name = '
          + repr(selinux_fact_collector_0.name))
    print('selinux_fact_collector_0._fact_ids = '
          + repr(selinux_fact_collector_0._fact_ids))



# Generated at 2022-06-25 00:35:19.493997
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # No exception raised
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_0.collect()
    # AssertionError: {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}
    # var_1 is a dictionary
    # var_1 is a dictionary
    assert type(var_1) is dict
    # var_1 is a dictionary
    assert type(var_1) is dict
    # 'selinux' in var_1
    assert 'selinux' in var_1
    # 'selinux_python_present' in var_1
    assert 'selinux_python_present' in var_1


# Generated at 2022-06-25 00:35:30.593220
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:35:33.120399
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == set()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:35:34.858665
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()
    assert isinstance(var_0, SelinuxFactCollector)


# Generated at 2022-06-25 00:35:38.389228
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None


# Generated at 2022-06-25 00:35:46.777134
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    var_1 = {'selinux': {'type': 'unknown', 'status': 'Missing selinux Python library', 'config_mode': 'unknown', 'mode': 'unknown', 'policyvers': 'unknown'}, 'selinux_python_present': False}
    assert var_0 == var_1
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_2 = selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:35:48.871610
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()

if __name__ == '__main__':
    test_case_0()
    test_SelinuxFactCollector()

# Generated at 2022-06-25 00:35:51.591807
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:35:56.076998
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0, SelinuxFactCollector)
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:35:57.489249
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:35:58.107415
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:36:21.602153
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()

# Generated at 2022-06-25 00:36:23.428955
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_ = SelinuxFactCollector()
    var_ = selinux_fact_collector_.collect()

# Generated at 2022-06-25 00:36:29.722020
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    result_1 = selinux_fact_collector_1.collect()
    assert result_1 == {'selinux': {'config_mode': 'unknown', 'policyvers': 'unknown', 'mode': 'unknown', 'status': 'enabled', 'type': 'unknown'}, 'selinux_python_present': True}


# Generated at 2022-06-25 00:36:34.344856
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """Test case for method collect of class SelinuxFactCollector"""
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:36:37.682723
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert set(['selinux_python_present', 'selinux']) == set(selinux_fact_collector_0.collect().keys())


# Generated at 2022-06-25 00:36:39.566025
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:36:42.500628
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    if isinstance(var_0, dict):
        assert True
    else:
        assert False

# Generated at 2022-06-25 00:36:44.201659
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:36:45.489413
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    var = SelinuxFactCollector()
    result = var.collect()
    assert result == {}


# Generated at 2022-06-25 00:36:47.489651
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()


# Generated at 2022-06-25 00:37:33.881559
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert var_1['selinux']['status'] == 'Missing selinux Python library'


# Generated at 2022-06-25 00:37:38.457409
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:37:43.600980
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    try:
        variable = selinux_fact_collector.name
    except Exception as e:
        print("Exception in constructor of class SelinuxFactCollector")


# Generated at 2022-06-25 00:37:45.547580
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Unit test for class SelinuxFactCollector
    selinux_fact_collector_0 = SelinuxFactCollector()

    # Unit test code begin
    var_0 = selinux_fact_collector_0.collect()
    # Unit test code end


# Generated at 2022-06-25 00:37:48.159990
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    obj = SelinuxFactCollector()
    res = obj.collect()
    assert(res['selinux'] != {})



# Generated at 2022-06-25 00:37:49.371718
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        SelinuxFactCollector()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 00:37:52.472848
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    _selinux_fact_collector = SelinuxFactCollector()
    _selinux_facts = _selinux_fact_collector.collect()
    if _selinux_facts:
        assert 'selinux' in _selinux_facts

# Generated at 2022-06-25 00:37:57.858064
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert 'selinux' in var_1.keys()
    assert 'selinux_python_present' in var_1.keys()

# Generated at 2022-06-25 00:37:59.165831
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:38:01.993081
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  selinux_fact_collector_0 = SelinuxFactCollector()
  assert selinux_fact_collector_0 != None  


# Generated at 2022-06-25 00:39:30.504025
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Implementation test for constructor of class SelinuxFactCollector
    assert selinux_fact_collector_0 is not None


# Generated at 2022-06-25 00:39:32.643669
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    var = selinux_fact_collector.collect()
    if var['selinux_python_present'] is False:
        assert 1 == 1


# Generated at 2022-06-25 00:39:34.468343
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_1()
    test_case_0()


# Generated at 2022-06-25 00:39:35.538151
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test without argument
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:39:38.637136
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect()


# Generated at 2022-06-25 00:39:43.390956
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    fact_collector_1 = SelinuxFactCollector()
    expected_var_1 = ('selinux_python_present', 'selinux')
    actual_var_1 = fact_collector_1.get_fact_ids()
    assert expected_var_1 == actual_var_1

# Generated at 2022-06-25 00:39:47.404637
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)


# Generated at 2022-06-25 00:39:49.394846
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == "selinux"
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:39:50.089045
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:39:51.148895
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        var_0 = SelinuxFactCollector()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 00:43:27.422320
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert (selinux_fact_collector_0.name == 'selinux')
    assert (len(selinux_fact_collector_0._fact_ids) == 0)


# Generated at 2022-06-25 00:43:29.064597
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert var_1 == { 'selinux': { 'status': 'disabled' } }

# Generated at 2022-06-25 00:43:30.038009
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj_SelinuxFactCollector = SelinuxFactCollector()
    test_case_0()

# Generated at 2022-06-25 00:43:37.105040
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # initialize data used in the test
    selinux_fact_collector_0 = SelinuxFactCollector()

    # call the test method
    var_0 = selinux_fact_collector_0.collect()

    # check if the result is correct
    assert var_0.__class__.__name__ == 'dict'

    selinux_fact_collector_1 = SelinuxFactCollector()

    # call the test method
    var_0 = selinux_fact_collector_1.collect()

    # check if the result is correct
    assert var_0.__class__.__name__ == 'dict'


# Generated at 2022-06-25 00:43:39.667702
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    var = selinux_fact_collector.collect()


test_case_0()
test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:43:41.603741
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:43:43.218971
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_1, SelinuxFactCollector)

# Generated at 2022-06-25 00:43:46.283429
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()
    assert result == None

# Generated at 2022-06-25 00:43:49.025921
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    var_0 = SelinuxFactCollector()
    var_1 = SelinuxFactCollector()
    var_0.collect()
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
