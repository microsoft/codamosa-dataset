

# Generated at 2022-06-25 00:33:57.031469
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-25 00:34:03.368377
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect

    selinux_fact_collector_2 = SelinuxFactCollector()
    selinux_fact_collector_2.collect()

    selinux_fact_collector_3 = SelinuxFactCollector()
    selinux_fact_collector_3.collect(module=None, collected_facts=None)

    selinux_fact_collector_4 = SelinuxFactCollector()
    selinux_fact_collector_4.collect(module={'type': 'dict'}, collected_facts={'type': 'dict'})


# Generated at 2022-06-25 00:34:07.295036
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:08.079366
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()



# Generated at 2022-06-25 00:34:16.081849
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    res = selinux_fact_collector_1.collect()
    assert 'selinux' in res
    assert 'status' in res['selinux']
    assert 'policyvers' in res['selinux']
    assert 'config_mode' in res['selinux']
    assert 'mode' in res['selinux']
    assert 'type' in res['selinux']
    assert res['selinux_python_present'] is True

# Generated at 2022-06-25 00:34:18.205021
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert selinux_fact_collector_0.name == "selinux"
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:34:20.017454
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0 is not None

# Generated at 2022-06-25 00:34:23.908102
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:25.581687
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()

    # Test collect method
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:34:29.206173
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()


# Generated at 2022-06-25 00:34:36.137835
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:34:41.027182
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:34:46.494380
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector._fact_ids == set()
    assert len(selinux_fact_collector._fact_ids) == 0
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:34:52.776117
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert(len(selinux_fact_collector_1.collect()) == 2)

if __name__ == '__main__':
    test_case_0()
    test_SelinuxFactCollector()

# Generated at 2022-06-25 00:34:59.144340
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.collect() == {
        'selinux': {
            'config_mode': 'unknown',
            'mode': 'unknown',
            'status': 'Missing selinux Python library',
            'type': 'unknown',
            'policyvers': 'unknown'
        },
        'selinux_python_present': False
    }

# Generated at 2022-06-25 00:35:02.832643
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()

    # Test with no parameters
    selinux_fact_collector_0.collect()

    # Test with parameters
    selinux_fact_collector_0.collect(module=None, collected_facts=None)


# Generated at 2022-06-25 00:35:07.370058
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Assert that the return value from method collect is the same as the
    # expected return value.
    expected_ret_val = {
        "selinux": {
            "status": "Missing selinux Python library"
        },
        "selinux_python_present": False
    }
    ret_val = SelinuxFactCollector().collect()
    assert ret_val == expected_ret_val

# Generated at 2022-06-25 00:35:09.843287
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert selinux_fact_collector_0.name == 'selinux'

# Generated at 2022-06-25 00:35:20.079572
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    result_1 = selinux_fact_collector_1.collect()
    assert result_1 == {'selinux':{'status': 'disabled', 'policyvers': 'unknown',
                                   'config_mode': 'unknown', 'mode': 'unknown',
                                   'type': 'unknown'},
                        'selinux_python_present': True}
    selinux_fact_collector_2 = SelinuxFactCollector()
    result_2 = selinux_fact_collector_2.collect()

# Generated at 2022-06-25 00:35:24.093432
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:35:31.207743
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()
    assert var_1.name == 'selinux'
    assert isinstance(var_1._fact_ids, set)


# Generated at 2022-06-25 00:35:33.921833
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect(module=None, collected_facts=None)
    assert type(var_1) == dict


# Generated at 2022-06-25 00:35:36.795448
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  selinuxFactCollector = SelinuxFactCollector()
  assert selinuxFactCollector != None

# Generated at 2022-06-25 00:35:39.190862
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create an object of SelinuxFactCollector
    test_case_0()



# Generated at 2022-06-25 00:35:41.469827
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:35:47.850067
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    selinux_fact_collector = SelinuxFactCollector()
    var = selinux_fact_collector.collect()

    assert var is not None
    assert var['selinux'] is not None
    assert len(var) == 1


# Generated at 2022-06-25 00:35:49.655088
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0, BaseFactCollector) == True


# Generated at 2022-06-25 00:35:54.433666
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # set up known values
    selinux_fact_collector_1 = SelinuxFactCollector()
    # actual test code
    var_1 = selinux_fact_collector_1._fact_ids
    # assert statements
    assert var_1 == set()


# Generated at 2022-06-25 00:35:56.480821
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()



# Generated at 2022-06-25 00:36:00.953649
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_2 = selinux_fact_collector_0.collect(module=None, collected_facts=None)
    assert isinstance(var_2, dict), "Incorrect type of return value for method collect() of class SelinuxFactCollector."


# Generated at 2022-06-25 00:36:14.236808
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect()


# Generated at 2022-06-25 00:36:16.200432
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert(selinux_fact_collector_1.name == 'selinux')


# Generated at 2022-06-25 00:36:18.395583
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:23.509490
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:36:27.869000
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:31.115566
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-25 00:36:33.640491
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:36:35.879198
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()
    assert isinstance(var_1, SelinuxFactCollector) == True


# Generated at 2022-06-25 00:36:39.042494
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {}, "Assertion failed"


# Generated at 2022-06-25 00:36:40.895309
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:36:58.233719
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'


# Generated at 2022-06-25 00:36:59.938283
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:37:03.907372
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert(issubclass(type(selinux_fact_collector_0), SelinuxFactCollector))

    # test `collect` instance method
    assert(isinstance(selinux_fact_collector_0.collect(), dict))

# unit test for `collect` instance method of class SelinuxFactCollector

# Generated at 2022-06-25 00:37:05.417385
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:37:07.114976
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:37:12.949398
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # These variables control whether debug statements will be printed to stdout
    DEBUG = False
    # DEBUG = True

    # This variable determines the name of the file where the collected facts
    # will be stored for use by other tests.
    temp_filename = 'test_SelinuxFactCollector_collect.out'


    # Collect facts without debug statements:
    if DEBUG:
        print('TEST 0a: Collecting facts without debug statements')
    SelinuxFactCollector.DEBUG =  False
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    if DEBUG:
        print('var_0=%s' % var_0)


    # Collect facts with debug statements.

# Generated at 2022-06-25 00:37:16.049998
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    var = selinux_fact_collector.collect()
    assert var == var

# Generated at 2022-06-25 00:37:21.233939
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:37:21.940929
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:37:25.938929
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert str(selinux_fact_collector) == "<ansible.module_utils.facts.system.selinux.SelinuxFactCollector <class 'ansible.module_utils.facts.collectors.base.BaseFactCollector'>>"


# Generated at 2022-06-25 00:37:53.125680
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_0.collect()

    expected = dict(selinux=dict(config_mode='unknown', mode='unknown', status='Missing selinux Python library', type='unknown'), selinux_python_present=False)
    assert var_1 == expected

# Generated at 2022-06-25 00:37:57.661048
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:38:00.990782
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {
        'selinux': {
            'status': 'Missing selinux Python library'
        },
        'selinux_python_present': False
    }

# Generated at 2022-06-25 00:38:03.403997
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert(len(selinux_fact_collector_1._fact_ids) == 0)


# Generated at 2022-06-25 00:38:05.194076
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    print(var_0)
    assert True

# Generated at 2022-06-25 00:38:06.440114
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:11.252292
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
# Check if the fact dictionary is empty
    assert var_0 != {}, "Expected fact dictionary is not empty"

# Generated at 2022-06-25 00:38:16.813992
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == selinux_fact_collector_0.collect()
    assert str(type(var_0)) == "<type 'dict'>"
    assert var_0.get('ansible_check_mode') is False
    assert str(type(var_0.get('selinux_python_present'))) == "<type 'bool'>"
    assert len(var_0.get('selinux')) > 0
    assert str(type(var_0.get('selinux').get('config_mode'))) == "<type 'str'>"
    assert str(type(var_0.get('selinux').get('mode'))) == "<type 'str'>"


# Generated at 2022-06-25 00:38:19.614620
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:38:23.783330
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert 'selinux_python_present' in facts_dict
    if 'selinux' in facts_dict:
        assert 'status' in facts_dict['selinux']
        assert 'mode' in facts_dict['selinux']

# Generated at 2022-06-25 00:39:01.999790
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass # No need to test the constructor

# Generated at 2022-06-25 00:39:03.203803
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:39:07.196293
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    # Calling collect method on class SelinuxFactCollector with arguments 'module' (NoneType) and 'collected_facts' (NoneType)
    var_1 = selinux_fact_collector_1.collect(None, None)


# Generated at 2022-06-25 00:39:07.609000
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-25 00:39:09.543792
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Create an instance of class SelinuxFactCollector
    assert isinstance(selinux_fact_collector_0, SelinuxFactCollector)


# Generated at 2022-06-25 00:39:14.848467
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0['selinux']  # check for key
    assert var_0['selinux_python_present']  # check for key

# Generated at 2022-06-25 00:39:19.938738
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    test_case_0()

# Generated at 2022-06-25 00:39:22.465815
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    var = SelinuxFactCollector.collect(
        module=None,
        collected_facts=None)
    assert var is not None
    assert type(var) == dict

# Generated at 2022-06-25 00:39:26.452829
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:39:31.183939
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    selinux_fact_collector_0 = SelinuxFactCollector("SelinuxFactCollector_0")
    selinux_fact_collector_0.name = "SelinuxFactCollector_1"
    selinux_fact_collector_0._fact_ids = set()


# Generated at 2022-06-25 00:41:12.233115
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()
    assert SelinuxFactCollector().name == 'selinux'


# Generated at 2022-06-25 00:41:22.262868
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # test_dir_0 is used to test the presence and the value of var_0 in the collect method
    test_dir_0 = {'selinux': {'status': 'enabled', 'policyvers': '28', 'config_mode': 'permissive', 'mode': 'permissive', 'type': 'targeted'}, 'selinux_python_present': True}
    test_SelinuxFactCollector_collect_0 = SelinuxFactCollector()
    var_0 = test_SelinuxFactCollector_collect_0.collect()
    assert var_0 == test_dir_0
    test_dir_1 = {'selinux': {'status': 'disabled'}, 'selinux_python_present': True}
    test_SelinuxFactCollector_collect_1 = SelinuxFactCollector()
   

# Generated at 2022-06-25 00:41:31.469758
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert False

# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments
#
# Test method with arguments

# Generated at 2022-06-25 00:41:35.208281
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    # Check that _fact_ids is set to an empty set
    assert len(selinux_fact_collector_0._fact_ids) == 0
    # Check that name is set to 'selinux'
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:41:40.725897
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_fact_collector = SelinuxFactCollector()
    var = selinux_fact_collector.collect()
    assert var['selinux']['status'] == "Missing selinux Python library"
    assert var['selinux_python_present'] == False

# Generated at 2022-06-25 00:41:42.307084
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()


# Generated at 2022-06-25 00:41:44.349730
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-25 00:41:47.117591
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()
    var_2 = SelinuxFactCollector.name
    var_3 = SelinuxFactCollector.collect()


# Generated at 2022-06-25 00:41:52.383016
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_2 = SelinuxFactCollector()
    selinux_fact_collector_3 = SelinuxFactCollector()
    selinux_fact_collector_4 = SelinuxFactCollector()
    selinux_fact_collector_5 = SelinuxFactCollector()
    selinux_fact_collector_6 = SelinuxFactCollector()
    selinux_fact_collector_7 = SelinuxFactCollector()
    selinux_fact_collector_8 = SelinuxFactCollector()
    selinux_fact_collector_9 = SelinuxFactCollector()

    assert selinux_fact_collector

# Generated at 2022-06-25 00:41:54.114392
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()

#