

# Generated at 2022-06-25 00:33:59.941337
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    expected = {'selinux_python_present': True, 'selinux': {'policyvers': '28', 'status': 'enabled', 'config_mode': 'enforcing', 'mode': 'enforcing', 'type': 'targeted'}}
    result = selinux_fact_collector_0.collect()
    assert result == expected


# Generated at 2022-06-25 00:34:01.492158
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name is not None


# Generated at 2022-06-25 00:34:03.436741
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:07.577951
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

# Generated at 2022-06-25 00:34:11.903138
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    result = selinux_fact_collector_0.collect()
    assert type(result) is dict
    assert 'selinux' in result
    assert 'selinux_python_present' in result
    selinux_get_mode_result = selinux_fact_collector_0.collect(collected_facts=dict(ansible_selinux=dict(mode='testmode')))
    assert selinux_get_mode_result['selinux']['mode'] == 'testmode'

# Generated at 2022-06-25 00:34:21.514835
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_fact_collector = SelinuxFactCollector()

    def mock_selinux_is_selinux_enabled():
        return False

    def mock_selinux_getenforcemode():
        return (0, 0)

    def mock_selinux_getpolicytype():
        return (0, "targeted")

    def mock_selinux_security_policyvers():
        return 28

    def mock_selinux_security_getenforce():
        return 1

    def mock_selinux_getenforcemode_false():
        return (0, -1)

    def mock_selinux_getpolicytype_false():
        return (0, "unknown")

    def mock_selinux_security_policyvers_false():
        return -28


# Generated at 2022-06-25 00:34:24.833423
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()

    selinux_fact_collector_0.collect()
    assert selinux_fact_collector_0.name == 'selinux'



# Generated at 2022-06-25 00:34:28.909515
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    test_expected_result = dict()
    test_expected_result['selinux_python_present'] = True
    test_expected_result['selinux'] = dict()
    test_expected_result['selinux']['status'] = 'disabled'
    test_result = selinux_fact_collector.collect()
    assert test_result == test_expected_result

# Generated at 2022-06-25 00:34:34.516541
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()
# No implementation found
#def test_case_1():
 #   selinux_fact_collector_1 = SelinuxFactCollector()


if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:34:38.872214
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert (selinux_fact_collector_0.name == 'selinux')
    assert (hasattr(selinux_fact_collector_0, 'collect'))


# Generated at 2022-06-25 00:34:51.256998
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert (len(selinux_fact_collector_0._fact_ids) == 0)
    assert (selinux_fact_collector_0.name == 'selinux')


# Generated at 2022-06-25 00:34:53.621861
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:34:57.172912
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert issubclass(obj.__class__, BaseFactCollector)



# Generated at 2022-06-25 00:34:57.921496
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert test_case_0() is None

# Generated at 2022-06-25 00:35:00.667369
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:35:05.253031
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)

# Generated at 2022-06-25 00:35:12.116141
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    print("Testing SelinuxFactCollector.collect ...")
    selinux_fact_collector = SelinuxFactCollector()
    test_fact_dict = selinux_fact_collector.collect()
    assert 'selinux' in test_fact_dict
    selinux_facts = test_fact_dict['selinux']

    assert 'status' in selinux_facts
    if selinux_fact_collector.have_selinux_python_library:
        assert 'mode' in selinux_facts
        assert 'config_mode' in selinux_facts
        assert 'type' in selinux_facts
        assert 'policyvers' in selinux_facts

    assert 'selinux_python_present' in test_fact_dict
    print("Success: SelinuxFactCollector.collect")


# Generated at 2022-06-25 00:35:14.098829
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:15.522146
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:35:16.977943
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:35:29.464698
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    test_case_0()

# Generated at 2022-06-25 00:35:33.115513
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector().collect()

# Generated at 2022-06-25 00:35:34.343882
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-25 00:35:44.415131
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with selinux Python library present
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.collect()['selinux_python_present']
    assert 'selinux' in selinux_fact_collector_1.collect()
    assert 'mode' in selinux_fact_collector_1.collect()['selinux']
    assert 'status' in selinux_fact_collector_1.collect()['selinux']
    assert 'policyvers' in selinux_fact_collector_1.collect()['selinux']
    assert 'type' in selinux_fact_collector_1.collect()['selinux']
    assert 'config_mode' in selinux_fact_collector_1.collect()['selinux']

# Generated at 2022-06-25 00:35:46.173999
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.collect() == {}

# Generated at 2022-06-25 00:35:49.518937
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

# Test case for /run/systemd/selinux MAC_SELINUX

# Generated at 2022-06-25 00:35:52.064615
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.name == 'selinux'

# Generated at 2022-06-25 00:35:53.498834
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()



# Generated at 2022-06-25 00:35:54.612772
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts = SelinuxFactCollector().collect()
    assert 'selinux' in facts

# Generated at 2022-06-25 00:35:56.325380
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux' == selinux_fact_collector.name

# Generated at 2022-06-25 00:36:09.041839
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Call the constructor of class SelinuxFactCollector
    test_case_0()

# Generated at 2022-06-25 00:36:09.882116
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert False == True

# Generated at 2022-06-25 00:36:14.921354
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert hasattr(SelinuxFactCollector, 'name')
    assert isinstance(SelinuxFactCollector.name, property)
    assert hasattr(SelinuxFactCollector, '_fact_ids')
    assert isinstance(SelinuxFactCollector._fact_ids, set)
    assert hasattr(SelinuxFactCollector, 'collect')
    assert callable(SelinuxFactCollector.collect)

# Generated at 2022-06-25 00:36:16.580751
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var = SelinuxFactCollector()
    var.collect()
    assert var.name == 'selinux'


# Generated at 2022-06-25 00:36:20.435703
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect() == {'selinux': {'config_mode': 'unknown',
                                                            'mode': 'unknown',
                                                            'status': 'enabled',
                                                            'policyvers': 'unknown',
                                                            'type': 'unknown'},
                                                'selinux_python_present': True}


# Generated at 2022-06-25 00:36:22.276147
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_0.collect()

    assert isinstance(var_1, dict) == True
    assert 'selinux' in var_1
    assert 'selinux_python_present' in var_1

# Generated at 2022-06-25 00:36:27.581176
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Print the object's docstring
    print(selinux_fact_collector_0.__doc__)
    # Print the object's docstring
    print(selinux_fact_collector_0.__doc__)
    # Print the object's name
    print(selinux_fact_collector_0.name)
    # Print the object's name
    print(selinux_fact_collector_0.name)
    # Assign another name to the object
    selinux_fact_collector_0.name = 'ansible_facts.selinux'
    # Print the object's name again
    print(selinux_fact_collector_0.name)
    # Print the object's name again

# Generated at 2022-06-25 00:36:32.483263
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()

    assert isinstance(selinux_fact_collector_1,SelinuxFactCollector)
    assert isinstance(selinux_fact_collector_1,BaseFactCollector)


# Generated at 2022-06-25 00:36:39.901638
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0, SelinuxFactCollector)
    assert isinstance(selinux_fact_collector_0.name, str)
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:36:41.738207
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    self = SelinuxFactCollector()
    assert  isinstance(self, SelinuxFactCollector)


# Generated at 2022-06-25 00:37:01.844031
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert type(var_1) is dict


# Generated at 2022-06-25 00:37:05.628196
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:37:09.851852
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    if not HAVE_SELINUX:
        assert selinux_fact_collector_1.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}
    else:
        selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:37:12.622765
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector._fact_ids == set()
    assert fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:37:17.591537
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector_0 = SelinuxFactCollector()
    assert SelinuxFactCollector_0.name == 'selinux'
    assert SelinuxFactCollector_0._fact_id
    assert type(SelinuxFactCollector_0._fact_ids) == set



# Generated at 2022-06-25 00:37:21.350610
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}


# Generated at 2022-06-25 00:37:23.941039
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-25 00:37:25.372520
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0 is not None

# Generated at 2022-06-25 00:37:29.090645
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:37:31.488289
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector().collect(None, None)
    assert isinstance(result, dict)
    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert 'selinux_python_present' in result


# Generated at 2022-06-25 00:38:18.420261
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  selinux_fact_collector_0 = SelinuxFactCollector()
  assert(type(selinux_fact_collector_0) == SelinuxFactCollector)


# Generated at 2022-06-25 00:38:21.139169
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    var = selinux_fact_collector.collect()


# Generated at 2022-06-25 00:38:22.719732
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:23.821413
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_obj = SelinuxFactCollector()

# Generated at 2022-06-25 00:38:26.964549
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().__class__.__name__ == 'SelinuxFactCollector'


# Generated at 2022-06-25 00:38:28.100594
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:30.604733
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:38:34.126732
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector

    selinux_fact_collector_0 = SelinuxFactCollector()

    collected_facts = {}
    selinux_fact_collector_0.collect(None, collected_facts)

    assert 'selinux' in collected_facts
    for value in collected_facts['selinux'].values():
        assert isinstance(value, basestring)


SelinuxFactCollector()

# Generated at 2022-06-25 00:38:37.897194
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:38:44.890929
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_2 = SelinuxFactCollector(name='selinux')
    selinux_fact_collector_3 = SelinuxFactCollector(name='selinux', _fact_ids=set())


# Generated at 2022-06-25 00:40:34.277469
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:40:37.218819
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    expected_0 = []
    assert var_0 == expected_0


# Generated at 2022-06-25 00:40:42.046036
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector("test_name", "test_fact_ids")


# Generated at 2022-06-25 00:40:43.098871
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    my_fact_collector = SelinuxFactCollector()
    my_fact_collector.collect()

# Generated at 2022-06-25 00:40:47.119656
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()

# Generated at 2022-06-25 00:40:49.065275
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:40:53.119133
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        selinux_fact_collector = SelinuxFactCollector()
    except:
        assert False


# Generated at 2022-06-25 00:40:59.643943
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    if selinux_fact_collector.name != 'selinux':
        raise AssertionError("Expected attribute name to be \"selinux\"")
    if not selinux_fact_collector._fact_ids == set():
        raise AssertionError("Expected attribute _fact_ids to be set()")


# Generated at 2022-06-25 00:41:02.631236
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-25 00:41:03.850571
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()
