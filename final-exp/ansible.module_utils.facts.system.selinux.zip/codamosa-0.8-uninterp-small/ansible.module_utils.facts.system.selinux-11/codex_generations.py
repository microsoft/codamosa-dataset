

# Generated at 2022-06-25 00:34:02.837986
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:34:07.223215
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-25 00:34:08.294730
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'


# Generated at 2022-06-25 00:34:12.067828
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == {'selinux', 'selinux_python_present'}



# Generated at 2022-06-25 00:34:15.259999
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:34:18.367314
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1 is not None

# Generated at 2022-06-25 00:34:21.126847
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        test_case_0()
    except:
        # print('Test case 0 failed')
        return False
    else:
        # print('Test case 0 passed')
        return True
    # print("\n")



# Generated at 2022-06-25 00:34:23.673310
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 00:34:25.644826
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:34:31.771724
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set({'selinux', 'selinux_python_present'})

# Generated at 2022-06-25 00:34:40.304610
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:34:49.410892
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Setup mock arguments, and mocks
    collector_obj = SelinuxFactCollector()

    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    expected = {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}
    assert var_0 == expected

    # Execute code to be tested
    result = collector_obj.collect()

    # Verify the result
    assert result == expected
    assert isinstance(result, dict) is True
    assert result['selinux']['status'] == 'Missing selinux Python library'
    assert result['selinux'] == expected['selinux']

# Generated at 2022-06-25 00:34:49.995037
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:34:52.929869
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == set()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:34:56.377426
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert var_1['selinux']['status'] == 'Missing selinux Python library'
    assert var_1['selinux_python_present'] == False


# Generated at 2022-06-25 00:35:01.045803
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:35:04.756397
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-25 00:35:05.501954
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().collect() is not None

# Generated at 2022-06-25 00:35:09.956554
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:10.897866
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:18.800692
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:21.318651
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:23.129229
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)


# Generated at 2022-06-25 00:35:25.351712
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:35:28.971297
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:29.876918
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:35:33.386190
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-25 00:35:35.013502
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:35:39.320456
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux', 'Failed to create SelinuxFactCollector object (constructor)'

# Generated at 2022-06-25 00:35:40.740159
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:35:54.633603
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Check if facts is set correctly in constructor of class SelinuxFactCollector
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1._fact_ids == set()
    assert selinux_fact_collector_1.name == 'selinux'


# Generated at 2022-06-25 00:35:55.447101
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:35:58.877983
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector(
        )
    assert selinux_fact_collector_1 is not None
    assert selinux_fact_collector_1._fact_ids == set()
    assert selinux_fact_collector_1.name == 'selinux'


# Generated at 2022-06-25 00:36:05.874500
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.compat import selinux as selinux_mock
    mock_selinux = selinux_mock
    mock_selinux.is_selinux_enabled.return_value = True
    mock_selinux.security_policyvers.return_value = '2'
    mock_selinux.selinux_getenforcemode.return_value = (0, 1)
    mock_selinux.security_getenforce.return_value = 1
    mock_selinux.selinux_getpolicytype.return_value = (0, 'MLS')

    selinux_fact_collector_mock = SelinuxFactCollector()

    facts_dict = selinux_fact_collector_mock.collect()

# Generated at 2022-06-25 00:36:10.821679
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        # init object
        SelinuxFactCollector()
    except NameError as e:
        assert True
    except Exception as e:
        assert False, "Unexpected exception raised: " + str(e)


# Generated at 2022-06-25 00:36:14.112295
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_0.collect()
    print(var_1)


# Generated at 2022-06-25 00:36:17.161772
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux': {'status': 'Missing selinux Python library'},
                     'selinux_python_present': False}

# Generated at 2022-06-25 00:36:25.528982
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux': {'status': 'enabled',
                                 'policyvers': '25',
                                 'config_mode': 'enforcing',
                                 'mode': 'enforcing',
                                 'type': 'targeted'},
                    'selinux_python_present': True}

# Generated at 2022-06-25 00:36:26.365798
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()

# Generated at 2022-06-25 00:36:28.569783
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)


# Generated at 2022-06-25 00:36:50.288577
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector
    selinux_fact_collector_0 = SelinuxFactCollector()
    # static BaseFactCollector._fact_ids
    assert isinstance(selinux_fact_collector_0, BaseFactCollector)
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:36:57.391290
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    selinux_fact_collector_2 = SelinuxFactCollector()
    var_2 = selinux_fact_collector_2.collect()
    selinux_fact_collector_3 = SelinuxFactCollector()
    var_3 = selinux_fact_collector_3.collect()
    selinux_fact_collector_4 = SelinuxFactCollector()
    var_4 = selinux_fact_collector_4.collect()
    selinux_fact_collector_5 = SelinuxFactCollector()
    var_5 = selinux_fact_collector_5.collect()
    selinux_fact_collector_6 = Selinux

# Generated at 2022-06-25 00:36:58.936276
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert var_1 == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}


# Generated at 2022-06-25 00:37:00.296591
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()
    assert var_0 is not None


# Generated at 2022-06-25 00:37:06.879227
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    var_1 = SelinuxFactCollector()
    var_2 = selinux.is_selinux_enabled()
    if var_2:
        var_3 = selinux.security_policyvers()
        var_4 = selinux.selinux_getenforcemode()
        var_5 = var_4[0]
        var_6 = var_4[1]
        if var_5 == 0:
            var_7 = SELINUX_MODE_DICT.get(var_6, 'unknown')
        else:
            var_7 = 'unknown'
        var_8 = selinux.security_getenforce()
        var_9 = SELINUX_MODE_DICT.get(var_8, 'unknown')
        var_10 = selinux.selinux_getpolicytype()
        var

# Generated at 2022-06-25 00:37:10.205725
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:37:11.564722
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:37:15.934413
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None



# Generated at 2022-06-25 00:37:22.802464
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    result = selinux_fact_collector_1.collect()
    assert result['selinux']['config_mode'] == 'unknown'
    assert result['selinux']['type'] == 'unknown'
    assert result['selinux']['mode'] == 'unknown'
    assert result['selinux']['status'] == 'enabled'
    assert result['selinux']['policyvers'] == 'unknown'

# Generated at 2022-06-25 00:37:28.107267
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Case 0
    test_case_0()


if __name__ == "__main__":
    # Case 0
    test_case_0()

# Generated at 2022-06-25 00:38:11.438758
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    print(selinux_fact_collector_0)
    print(selinux_fact_collector_0.collect())

# Generated at 2022-06-25 00:38:17.698082
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert var_1 is not None, "Expected None"
    assert var_1.get('selinux') is not None, "Expected None"
    assert var_1.get('selinux_python_present') is not None, "Expected None"
    assert var_1.get('ansible_facts') is not None, "Expected None"




# Generated at 2022-06-25 00:38:21.988653
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1._fact_ids == set()
    assert selinux_fact_collector_1.name == 'selinux'


# Generated at 2022-06-25 00:38:26.834967
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    # Assert selinux_python_present is True.
    var_0_selinux_python_present = var_0['selinux_python_present']
    assert var_0_selinux_python_present

# Generated at 2022-06-25 00:38:31.513828
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0['selinux_python_present']
    assert not selinux_fact_collector_0._deprecated
    assert selinux_fact_collector_0._legacy_fallback is None
    assert selinux_fact_collector_0.name == 'selinux'

# Generated at 2022-06-25 00:38:33.854724
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert len(selinux_fact_collector_0._fact_ids) == 0


# Generated at 2022-06-25 00:38:35.686324
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:38:38.642972
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()
    assert 1 == 1

# Generated at 2022-06-25 00:38:45.874588
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Create an object of the class SelinuxFactCollector
    selinuxFactCollectorObj = SelinuxFactCollector()

    # Test the type of the object
    assert isinstance(selinuxFactCollectorObj, SelinuxFactCollector)

    # Test the name attribute of the object
    assert selinuxFactCollectorObj.name == 'selinux'

    # Test the _fact_ids attribute of the object
    assert selinuxFactCollectorObj._fact_ids == set()


# Generated at 2022-06-25 00:38:48.739481
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    print("starting test_SelinuxFactCollector_collect")
    selinux_fact_collector = SelinuxFactCollector()
    var = selinux_fact_collector.collect()
    selinux_fact_collector.collect(selinux_fact_collector, var)

# Generated at 2022-06-25 00:40:37.950685
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_0.collect()

test_case_0()
#test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:40:42.315500
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:40:44.912999
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_2 = selinux_fact_collector_1.name
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_0._fact_ids

    assert var_2 == 'selinux'
    assert var_1 == set()

# Generated at 2022-06-25 00:40:47.435896
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:40:53.387686
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    test_0 = SelinuxFactCollector()

    # Testing the 'name' variable in class SelinuxFactCollector
    assert test_0.name == 'selinux'

    # Testing the '_fact_ids' variable in class SelinuxFactCollector
    assert isinstance(test_0._fact_ids, set)
    assert len(test_0._fact_ids) == 0



# Generated at 2022-06-25 00:40:57.299977
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Test function collect() of class SelinuxFactCollector
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:41:00.136505
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0, SelinuxFactCollector)
    assert isinstance(selinux_fact_collector_0._fact_ids, set)
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:41:02.161503
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    params = [[]]
    var = selinux_fact_collector.collect(params)


# Generated at 2022-06-25 00:41:07.939717
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        assert type(SelinuxFactCollector()) is SelinuxFactCollector
    except Exception:
        print("Test Error in test_SelinuxFactCollector function")

# Generated at 2022-06-25 00:41:13.481047
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        selinux_fact_collector_1 = SelinuxFactCollector()
    except Exception as e:
        raise AssertionError(str(e))

    assert selinux_fact_collector_1._fact_ids == set(['selinux'])
