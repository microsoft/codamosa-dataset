

# Generated at 2022-06-25 00:34:03.333156
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set([])


# Generated at 2022-06-25 00:34:07.582185
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'

# Generated at 2022-06-25 00:34:09.603967
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:34:14.530555
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_collect = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector_collect.collect()
    assert 'status' in selinux_facts['selinux']

# Generated at 2022-06-25 00:34:15.749827
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:34:16.285534
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-25 00:34:24.377134
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector__fact_ids = set()
    selinux_fact_collector__fact_ids.add('python.version_info.major')
    selinux_fact_collector__fact_ids.add('python.version_info.minor')
    selinux_fact_collector__fact_ids.add('python.version_info.micro')
    selinux_fact_collector__fact_ids.add('python.version_info.releaselevel')
    selinux_fact_collector__fact_ids.add('python.version_info.serial')
    selinux_fact_collector__fact_ids.add('distribution.version_major')

# Generated at 2022-06-25 00:34:28.327168
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    result = fact_collector.collect()
    assert isinstance(result, dict)
    assert 'selinux' in result
    assert isinstance(result['selinux'], dict)
    assert 'status' in result['selinux']
    assert isinstance(result['selinux']['status'], str)
    assert 'selinux_python_present' in result
    assert isinstance(result['selinux_python_present'], bool)

# Generated at 2022-06-25 00:34:33.307471
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    module_0 = None
    collected_facts_0 = None
    return_value_0 = selinux_fact_collector_0.collect(module_0, collected_facts_0)
    assert return_value_0 is None


# Generated at 2022-06-25 00:34:35.055365
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector() is not None


# Generated at 2022-06-25 00:34:40.836901
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:44.899832
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:34:45.975439
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()
#

# Generated at 2022-06-25 00:34:55.466532
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # selinux_fact_collector_0
    selinux_fact_collector_0 = SelinuxFactCollector()
    # selinux_fact_collector_0 is instance of SelinuxFactCollector
    assert isinstance(selinux_fact_collector_0, SelinuxFactCollector)
    # selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0.name == "selinux"
    # selinux_fact_collector_0.collect() returns a dict
    assert isinstance(selinux_fact_collector_0.collect(), dict)
    # selinux_fact_collector_0.collect().selinux.status is a string

# Generated at 2022-06-25 00:35:02.026636
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # test complete_contexts
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0.keys() == {'selinux_python_present', 'selinux'}
    assert var_0['selinux'].keys() == {'config_mode', 'policyvers', 'mode', 'status', 'type'}

# Generated at 2022-06-25 00:35:05.878065
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == {'selinux'}


# Generated at 2022-06-25 00:35:12.428021
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_2 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    var_2 = selinux_fact_collector_2.collect()
    assert var_1 == var_2


# Generated at 2022-06-25 00:35:15.182474
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:35:17.531124
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        selinux_fact_collector = SelinuxFactCollector()
        msg = "class SelinuxFactCollector was initialized"
        assert True == True, msg
    except NameError as err:
        assert False, str(err)


# Generated at 2022-06-25 00:35:24.293529
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Note: SELinuxFactCollector(BaseFactCollector) -> BaseFactCollector

    # noinspection PyTypeChecker
    selinux_fact_collector = SelinuxFactCollector(BaseFactCollector())
    assert isinstance(selinux_fact_collector, object)
    assert isinstance(selinux_fact_collector, BaseFactCollector)

# Generated at 2022-06-25 00:35:42.173049
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # For cases where the selinux Python library is missing, the method
    # 'get_default_facts' will call collect and set the selinux_python_present
    # fact to False.

    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

    # Another call to 'collect' to verify that the selinux fact is not cleared
    # after the first call.
    selinux_fact_collector_0.collect()
    selinux_fact_collector_0.collect()
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:35:43.977028
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0 is not None


# Generated at 2022-06-25 00:35:51.154229
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert isinstance(selinux_facts, dict)
    assert 'selinux' in selinux_facts
    assert isinstance(selinux_facts['selinux'], dict)
    assert 'status' in selinux_facts['selinux']
    assert isinstance(selinux_facts['selinux']['status'], str)
    assert selinux_facts['selinux']['status'] == 'Missing selinux Python library'
    assert 'selinux_python_present' in selinux_facts
    assert isinstance(selinux_facts['selinux_python_present'], bool)
    assert not selinux_facts['selinux_python_present']

# Generated at 2022-06-25 00:35:58.812807
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        import selinux
        HAVE_SELINUX = True
    except ImportError:
        HAVE_SELINUX = False

    SELINUX_MODE_DICT = { 1: 'enforcing', 0: 'permissive', -1: 'disabled'}

    # We can assume this, as it is already tested in test_case_0()
    # selinux_fact_collector_0 = SelinuxFactCollector()

    var_1 = selinux_fact_collector_0.name
    assert isinstance(var_1, basestring), "var_1 is of wrong type"
    assert len(var_1) == 6, "The length of var_1 is wrong!"
    assert var_1 == 'selinux', "var_1 is wrong!"

    var_2 = selinux_fact_collect

# Generated at 2022-06-25 00:35:59.540103
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  assert SelinuxFactCollector

# Generated at 2022-06-25 00:36:01.222587
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()



# Generated at 2022-06-25 00:36:02.674745
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # No parameters specified
    selinux_fact_collector_0 = SelinuxFactCollector()



# Generated at 2022-06-25 00:36:06.003813
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:36:09.960666
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Instantiation of class SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:13.021012
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:36:35.931888
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-25 00:36:38.418319
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:36:42.350491
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    var = selinux_fact_collector.collect()
    assert isinstance(var, dict)


# Generated at 2022-06-25 00:36:51.079292
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if not HAVE_SELINUX:
        return

    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux': {'config_mode': 'unknown', 'policyvers': 'unknown', 'status': 'disabled', 'type': 'unknown', 'mode': 'unknown'}, 'selinux_python_present': True}

    selinux.selinux_enabled = lambda: True
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:36:54.377319
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

    assert(SelinuxFactCollector() is not None)
    assert(selinux_fact_collector_0.name == 'selinux')
    assert(selinux_fact_collector_0._fact_ids == set())


# Generated at 2022-06-25 00:36:56.540849
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:37:01.499557
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = Collector()
    var_2 = BaseFactCollector()
    var_3 = selinux_fact_collector_1.collect(var_1, var_2)


# Generated at 2022-06-25 00:37:09.851559
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    print(selinux_fact_collector_0.name)
    print(selinux_fact_collector_0._fact_ids)
    print(type(selinux_fact_collector_0))
    print(type(selinux_fact_collector_0.name))
    print(type(selinux_fact_collector_0._fact_ids))
     # Unit test for method collect of class SelinuxFactCollector
    test_case_0()

# Generated at 2022-06-25 00:37:11.896095
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()



# Generated at 2022-06-25 00:37:15.689657
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:06.120604
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()
    var_2 = SelinuxFactCollector()
    assert var_1 is not var_2
    assert var_1.name != var_2.name
    assert var_1.name == 'selinux'
    assert var_2.name == 'selinux'


# Generated at 2022-06-25 00:38:13.774061
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with selinux library
    if HAVE_SELINUX:
        selinux_facts_0 = SelinuxFactCollector().collect()
        assert 'selinux' in selinux_facts_0
        assert 'status' in selinux_facts_0['selinux']
        assert 'type' in selinux_facts_0['selinux']
        assert 'mode' in selinux_facts_0['selinux']
        assert 'config_mode' in selinux_facts_0['selinux']
        assert 'policyvers' in selinux_facts_0['selinux']
        assert 'selinux_python_present' in selinux_facts_0

# Generated at 2022-06-25 00:38:18.267583
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()
    print(str(var_1))
    print(str(var_1.collect()))


# Generated at 2022-06-25 00:38:22.067994
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        selinux_fact_collector_2 = SelinuxFactCollector()
    except:
        selinux_fact_collector_2 = None
    assert selinux_fact_collector_2 is not None


# Generated at 2022-06-25 00:38:31.709176
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_1.collect(None, None)
    assert var_0 is not None, "var 0 returned is None"
    assert isinstance(var_0, dict), "var 0 is not a dictionary"
    assert var_0 != {}, "var 0 is empty dict"
    var_1 = var_0.keys()
    var_2 = "selinux" in var_1, "key selinux not found in facts returned"
    assert var_2
    var_3 = var_0.keys()
    var_4 = "selinux_python_present" in var_3, "key selinux_python_present not found in facts returned"
    assert var_4

# Generated at 2022-06-25 00:38:32.593112
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:38:33.738683
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:34.776558
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:40.230338
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    # store return from method
    ret = selinux_fact_collector.collect()
    # assert return type
    assert isinstance(ret, dict)
    # assert has options
    assert 'selinux' in ret
    assert 'selinux_python_present' in ret


# Generated at 2022-06-25 00:38:43.602335
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # constructor test with object
    selinux_fact_collector_0 = SelinuxFactCollector()

    # constructor test with object
    selinux_fact_collector_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:39:41.346918
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:39:43.421565
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
  selinux_fact_collector_0 = SelinuxFactCollector()
  var_0 = selinux_fact_collector_0.collect()
  return var_0

# Generated at 2022-06-25 00:39:48.551977
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.name
    var_1 = selinux_fact_collector_0.collect()
    var_2 = selinux_fact_collector_0.__class__


# Generated at 2022-06-25 00:39:52.002331
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:39:54.099911
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Arrange - Setup test
    selinux_fact_collector_0 = SelinuxFactCollector()

    # Act
    var_0 = selinux_fact_collector_0.collect()

    # Assert
    assert var_0['selinux']['status'] == 'disabled'

# Generated at 2022-06-25 00:39:55.413151
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector().collect()
    if var_0 is not None:
        assert True
    else:
        assert False


# Generated at 2022-06-25 00:40:01.218629
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class_var_0 = SelinuxFactCollector()

    # Test with missing selinux Python library
    HAVE_SELINUX = False
    var_0 = class_var_0.collect()
    assert var_0['selinux_python_present'] == False
    assert var_0['selinux']['status'] == 'Missing selinux Python library'

    # Test with selinux Python library and selinux disabled
    HAVE_SELINUX = True
    selinux_is_selinux_enabled = selinux.is_selinux_enabled
    selinux_is_selinux_enabled.return_value = False
    var_0 = class_var_0.collect()
    assert var_0['selinux_python_present'] == True

# Generated at 2022-06-25 00:40:02.981312
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:40:04.336584
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:40:05.511697
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux', 'The name of the class does not match. Please check the class constructor.'


# Generated at 2022-06-25 00:41:48.456798
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    return selinux_fact_collector


# Generated at 2022-06-25 00:41:54.575148
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1._fact_ids == set()
    assert selinux_fact_collector_1.name == 'selinux'


# Generated at 2022-06-25 00:41:59.517968
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    print("Unit test for constructor of class SelinuxFactCollector ...")
    selinux_fact_collector = SelinuxFactCollector()
    print("Unit test for constructor of class SelinuxFactCollector completed")


# Generated at 2022-06-25 00:42:07.477800
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Test attributes of class SelinuxFactCollector
    assert isinstance(selinux_fact_collector_0.name, str)
    assert hasattr(selinux_fact_collector_0, 'name')
    assert isinstance(selinux_fact_collector_0._fact_ids, set)
    assert hasattr(selinux_fact_collector_0, '_fact_ids')


# Generated at 2022-06-25 00:42:11.030474
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    var_2 = type(var_1)
    var_3 = selinux_fact_collector_1.name
    var_4 = selinux_fact_collector_1._fact_ids 
    var_5 = selinux_fact_collector_1.__class__

# Generated at 2022-06-25 00:42:13.989221
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:42:14.365619
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert False



# Generated at 2022-06-25 00:42:21.124050
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Unit test if method collect of class SelinuxFactCollector
# raises TypeError when passing too many arguments

# Generated at 2022-06-25 00:42:29.240480
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from AnsibleModuleMock import AnsibleModuleMock
    from ansible.module_utils.facts.collector import FactsCollector

    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = AnsibleModuleMock()
    var_1 = AnsibleModuleMock()
    var_1.params = {"gather_subset": ["!all", "min"]}
    var_2 = FactsCollector(var_1, var_0.module._shared_loader_obj)
    var_2.collect()
    selinux_fact_collector_0.collect(var_1, var_2._collected_facts)

# Generated at 2022-06-25 00:42:31.608681
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    var_0 = SelinuxFactCollector()
    var_0.collect()
