

# Generated at 2022-06-25 00:33:56.802346
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc


# Generated at 2022-06-25 00:33:57.338436
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass

# Generated at 2022-06-25 00:33:58.581845
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'

# Generated at 2022-06-25 00:34:03.727122
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Unit test case for when selinux.is_selinux_enabled is false
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux.is_selinux_enabled = lambda: 0
    selinux_facts = selinux_fact_collector_0.collect()
    assert selinux_facts['selinux']['status'] == 'disabled'
    assert selinux_facts['selinux_python_present']
    selinux.is_selinux_enabled = lambda: 1
    # Unit test case for when selinux.is_selinux_enabled is true
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux.selinux_getenforcemode = lambda: (0,1)
    selinux.security_getenforce = lambda: 1

# Generated at 2022-06-25 00:34:07.008596
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
     assert SelinuxFactCollector.__doc__ != None


# Generated at 2022-06-25 00:34:08.855537
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:34:14.394302
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    returned_facts = selinux_fact_collector.collect()
    assert returned_facts == {'selinux': {'status': 'disabled'}, 'selinux_python_present': False}

# Generated at 2022-06-25 00:34:15.301697
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:34:16.159371
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj

# Generated at 2022-06-25 00:34:18.283086
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:34:26.661889
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:34:30.550885
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_cases = [
        test_case_0,
    ]

    for test_case in test_cases:
        test_case()

# Generated at 2022-06-25 00:34:35.840153
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:34:38.289649
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

# Generated at 2022-06-25 00:34:40.891076
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == set([])
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:34:42.789245
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:34:45.531142
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj._fact_ids == set()
    assert obj.name == "selinux"


# Generated at 2022-06-25 00:34:46.452326
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:34:48.530075
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

###
# Required
###

# Generated at 2022-06-25 00:34:50.909097
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:35:00.814670
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_1, SelinuxFactCollector)


# Generated at 2022-06-25 00:35:07.227181
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    expected_result = {
        'selinux_python_present': True,
        'selinux': {
            'config_mode': 'unknown',
            'policyvers': 'unknown',
            'type': 'unknown',
            'status': 'disabled',
            'mode': 'unknown'
        }
    }
    assert selinux_fact_collector_0.collect() == expected_result

# Generated at 2022-06-25 00:35:11.660756
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        selinux_fact_collector_0 = SelinuxFactCollector()
    except Exception as e:
        print("Exception data: {0}".format(e))
        assert False

test_case_0()
test_SelinuxFactCollector()

# Generated at 2022-06-25 00:35:14.126363
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert (selinux_fact_collector_0.name == 'selinux')

# Generated at 2022-06-25 00:35:17.883714
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert type(var_0) == dict
    assert var_0 == {'selinux': {'config_mode': 'unknown', 'status': 'Missing selinux Python library', 'type': 'unknown', 'mode': 'unknown', 'policyvers': 'unknown'}, 'selinux_python_present': False}



# Generated at 2022-06-25 00:35:22.222182
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()
    assert var_1._fact_ids == {'selinux', 'selinux_python_present'}


# Generated at 2022-06-25 00:35:25.367294
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        selinux_fact_collector = SelinuxFactCollector()
    except Exception as e:
        assert False, \
        "Can't create instance of class SelinuxFactCollector: " + str(e)


# Generated at 2022-06-25 00:35:32.093852
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # default constructor
    selinux_fact_collector = SelinuxFactCollector()
    assert hasattr(selinux_fact_collector, '_fact_ids')
    assert hasattr(selinux_fact_collector, 'name')
    assert hasattr(selinux_fact_collector, 'collect')
    assert hasattr(selinux_fact_collector, '__init__')

# Generated at 2022-06-25 00:35:35.769324
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    name = 'selinux'
    _fact_ids = set()
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == name
    assert selinux_fact_collector_0._fact_ids == _fact_ids


# Generated at 2022-06-25 00:35:38.484128
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert selinux_fact_collector_0.collect() == {u'selinux': {u'status': 'disabled'},
u'selinux_python_present': True}

# Generated at 2022-06-25 00:35:50.786381
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test for code coverage.
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_1 = SelinuxFactCollector()



# Generated at 2022-06-25 00:35:52.394092
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0 is not None


# Generated at 2022-06-25 00:35:53.189479
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()


# Generated at 2022-06-25 00:35:55.828581
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:36:00.934642
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert not var_1['selinux']
    assert var_1['selinux_python_present']


# Generated at 2022-06-25 00:36:01.994148
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert True == True


# Generated at 2022-06-25 00:36:09.456675
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert var_1 == {
        'selinux' : {
            'status' : 'disabled',
            'mode' : 'disabled',
            'config_mode' : 'disabled',
            'type' : 'unknown',
            'policyvers' : 'unknown'
        },
        'selinux_python_present' : True
    }


# Generated at 2022-06-25 00:36:15.950936
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    ansible_0 = dict()
    ansible_0['ansible_facts'] = dict()
    ansible_0['ansible_facts']['selinux'] = dict()
    ansible_0['ansible_facts']['selinux']['status'] = 'enabled'
    ansible_0['ansible_facts']['selinux']['policyvers'] = '30'
    ansible_0['ansible_facts']['selinux']['config_mode'] = 'enforcing'
    ansible_0['ansible_facts']['selinux']['mode'] = 'enforcing'
    ansible_0['ansible_facts']['selinux']['type'] = 'targeted'

# Generated at 2022-06-25 00:36:17.849270
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if not HAVE_SELINUX:
        test_case_0()

# Generated at 2022-06-25 00:36:22.855464
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:48.854729
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Default values for selinux_python_present and selinux
    selinux_python_present_default = False
    selinux_default = {}
    selinux_default['status'] = 'Missing selinux Python library'

    # Default values for selinux
    selinux_status_default = 'disabled'
    selinux_policyvers_default = 'unknown'
    selinux_config_mode_default = 'unknown'
    selinux_mode_default = 'unknown'
    selinux_type_default = 'unknown'

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    selinux_python_present_0 = selinux_python_present_default
    selinux_0 = se

# Generated at 2022-06-25 00:36:52.044650
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # First print the values and then test
    print("\n\n*** start test_SelinuxFactCollector ***")
    selinux_fact_collector = SelinuxFactCollector()
    print(vars(selinux_fact_collector))
    assert selinux_fact_collector is not None
    print("\n\n*** end test_SelinuxFactCollector ***")


# Generated at 2022-06-25 00:36:53.900270
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:37:01.990829
# Unit test for method collect of class SelinuxFactCollector

# Generated at 2022-06-25 00:37:02.437876
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass

# Generated at 2022-06-25 00:37:06.498415
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0, SelinuxFactCollector)



# Generated at 2022-06-25 00:37:07.447030
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'


# Generated at 2022-06-25 00:37:11.531749
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-25 00:37:16.135724
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()
    var_2 = SelinuxFactCollector().name
    var_3 = SelinuxFactCollector()._fact_ids

# Generated at 2022-06-25 00:37:18.809869
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:38:10.449394
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'

    assert selinux_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:38:11.438373
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:13.050153
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_new = SelinuxFactCollector()
    name_new = selinux_new.name
    assert(name_new == 'selinux')


# Generated at 2022-06-25 00:38:15.868900
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:18.625369
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    var1 = SelinuxFactCollector()
    var2 = dict()
    var3 = dict()
    var4 = dict()
    var3['selinux'] = var4
    var2['selinux'] = var3
    var1.collect(var2)



# Generated at 2022-06-25 00:38:23.308404
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux': {'status': 'enabled', 'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'}}

# Generated at 2022-06-25 00:38:29.514736
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux_python_present': True, 'selinux': {'status': 'disabled', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown', 'policyvers': 'unknown'}}



# Generated at 2022-06-25 00:38:33.156491
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()



# Generated at 2022-06-25 00:38:34.767891
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_2 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_2, SelinuxFactCollector)


# Generated at 2022-06-25 00:38:35.756551
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass


# Generated at 2022-06-25 00:40:27.639741
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    var_0 = selinux_fact_collector.collect()
    assert repr(var_0) == "{'selinux': {'mode': 'unknown', 'policyvers': 'unknown', 'type': 'unknown', 'status': 'enabled'}, 'selinux_python_present': True}"


# Generated at 2022-06-25 00:40:29.032085
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:40:38.701482
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Testing with a boolean value for selinux_python_present
    imports_mock = {
        'selinux': {
            'is_selinux_enabled': True,
            'security_policyvers': 'Test',
            'selinux_getenforcemode': (0, 1),
            'security_getenforce': 1,
            'selinux_getpolicytype': (0, 'Test'),
        }
    }

    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0._imports = imports_mock

    var_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:40:42.288324
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:40:43.512149
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()
    assert isinstance(var_1, SelinuxFactCollector) == True


# Generated at 2022-06-25 00:40:50.347352
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    if HAVE_SELINUX:
        selinux_fact_collector_0 = SelinuxFactCollector()
        assert selinux_fact_collector_0.name == 'selinux'
        assert selinux_fact_collector_0._fact_ids == set()
    else:
        selinux_fact_collector_0 = SelinuxFactCollector()
        assert selinux_fact_collector_0.name == 'selinux'
        assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:40:53.680241
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:40:56.722645
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:40:59.230223
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-25 00:41:02.603901
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    fact_ids_0 = selinux_fact_collector_0._fact_ids
    assert fact_ids_0 == set(), "Expected {}, got {}".format(set(), fact_ids_0)
