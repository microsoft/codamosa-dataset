

# Generated at 2022-06-25 00:34:03.049968
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    result = {}
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Return type of the property nam
    assert type(selinux_fact_collector_0.name) == str
    # Return type of the property fact_ids
    assert type(selinux_fact_collector_0.fact_ids) == set
    # Return type of the return value of the collect method
    assert type(selinux_fact_collector_0.collect()) == dict
    # Return type of the return value of the fact_ids attribute
    assert type(selinux_fact_collector_0._fact_ids) == set
    assert result == {}


# Generated at 2022-06-25 00:34:08.666923
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect()

if __name__ == '__main__':
    test_case_0()
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:34:09.749895
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

# Generated at 2022-06-25 00:34:14.704929
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-25 00:34:19.015224
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:34:25.688209
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = AnsibleModule(argument_spec={})
    fact_collector = SelinuxFactCollector()
    collected_facts = {}
    collected_facts = fact_collector.collect(module=module, collected_facts=collected_facts)

    # Ensure SELinux facts are present
    assert 'selinux' in collected_facts
    assert 'selinux_python_present' in collected_facts

    # Ensure the selinux_python_present fact is True for supported platforms
    if HAVE_SELINUX:
        assert collected_facts['selinux_python_present']
    else:
        assert not collected_facts['selinux_python_present']

# Generated at 2022-06-25 00:34:31.434282
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    import pdb;pdb.set_trace()

# Generated at 2022-06-25 00:34:35.943688
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"

# Generated at 2022-06-25 00:34:38.080905
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:34:42.189044
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    facts_dict = {}
    selinux_facts = {}

    selinux_facts['status'] = 'Missing selinux Python library'
    facts_dict['selinux'] = selinux_facts
    facts_dict['selinux_python_present'] = False
    assert selinux_fact_collector_0.collect(None, None) == facts_dict

# Generated at 2022-06-25 00:34:51.428136
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert test_case_0() == None

# Generated at 2022-06-25 00:34:52.651304
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:56.149900
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:35:01.046991
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()

    # BEFORE

    # WHEN
    facts_dict = selinux_fact_collector_0.collect()

    # THEN
    assert facts_dict is not None

# Generated at 2022-06-25 00:35:05.788037
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # No selinux package
    selinux = None
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect(selinux)


# Generated at 2022-06-25 00:35:07.620635
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'

# Generated at 2022-06-25 00:35:10.293752
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0 != None
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()



# Generated at 2022-06-25 00:35:11.671786
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:35:13.466567
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Calling constructor of class SelinuxFactCollector
    test_case_0()


if __name__ == "__main__":
    test_SelinuxFactCollector()

# Generated at 2022-06-25 00:35:18.663120
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    facts_dict_0 = selinux_fact_collector_0.collect()
    assert facts_dict_0['selinux']['status'] == 'Missing selinux Python library'
    assert facts_dict_0['selinux']['config_mode'] == 'unknown'
    assert facts_dict_0['selinux']['policyvers'] == 'unknown'
    assert facts_dict_0['selinux']['mode'] == 'unknown'
    assert facts_dict_0['selinux_python_present'] == False
    assert facts_dict_0['selinux']['type'] == 'unknown'

# Generated at 2022-06-25 00:35:39.149648
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:35:41.092385
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:35:45.363947
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Test case 0, Python selinux library not present.
    selinux_fact_collector_0 = SelinuxFactCollector()
    collected_facts_0 = selinux_fact_collector_0.collect()
    expected_facts_0 = dict(
        selinux=dict(
            status='Missing selinux Python library'
        ),
        selinux_python_present=False
    )
    assert collected_facts_0 == expected_facts_0

    # Test case 1, SELinux status is disabled.
    selinux_fact_collector_1 = SelinuxFactCollector()
    # Mock return value of is_selinux_enabled
    selinux_fact_collector_1.selinux.is_selinux_enabled = lambda: False
    collected_facts_1 = selinux_fact_collector

# Generated at 2022-06-25 00:35:56.262150
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert isinstance(selinux_facts, dict)
    assert 'selinux' in selinux_facts
    assert isinstance(selinux_facts['selinux'], dict)
    assert 'selinux_python_present' in selinux_facts
    assert isinstance(selinux_facts['selinux_python_present'], bool)
    assert 'status' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']

# Generated at 2022-06-25 00:36:00.131053
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
     Collect facts related to selinux
     :return:
     """

    # Create an instance of the SelinuxFactCollector class
    selinux_fact_collector = SelinuxFactCollector()

    # The collect method is called to collect the facts
    result = selinux_fact_collector.collect()

    # Checks for idempotency
    assert result is not None

# Generated at 2022-06-25 00:36:01.464564
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert not hasattr(SelinuxFactCollector, '_fact_ids')


# Generated at 2022-06-25 00:36:11.383888
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    collected_facts_dict = selinux_fact_collector_0.collect()
    assert 'selinux' in collected_facts_dict
    selinux_dict = collected_facts_dict['selinux']
    assert 'status' in selinux_dict
    assert 'config_mode' in selinux_dict
    assert 'mode' in selinux_dict
    assert 'type' in selinux_dict
    assert 'policyvers' in selinux_dict
    assert collected_facts_dict['selinux_python_present'] == True
    assert selinux_dict['status'] == 'enabled'
    assert selinux_dict['config_mode'] == 'enforcing'
    assert selinux_dict['mode'] == 'enforcing'
    assert selinux_dict

# Generated at 2022-06-25 00:36:14.103546
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:36:16.053269
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.name == 'selinux'


# Generated at 2022-06-25 00:36:18.730970
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:36:36.751056
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test with no library installed
    test_case_0()

# Generated at 2022-06-25 00:36:38.547415
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

if __name__ == '__main__':
    test_SelinuxFactCollector()

# Generated at 2022-06-25 00:36:40.059057
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:43.410061
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # See if we can get selinux facts
    #
    # Arrange
    selinux_fact_collector_0 = SelinuxFactCollector()

    # Act
    result = selinux_fact_collector_0.collect()

    # Assert
    assert result['selinux_python_present'] == True

# Generated at 2022-06-25 00:36:44.519542
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_ = SelinuxFactCollector()
    assert False

# Generated at 2022-06-25 00:36:45.212641
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:36:48.702248
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a test case object
    test_obj = SelinuxFactCollector()

    # Call the method under test
    response = test_obj.collect()
    print(response)
    assert response == {}

# Generated at 2022-06-25 00:36:49.683083
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:36:56.831574
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    try:
        selinux_fact_collector_return = selinux_fact_collector.collect()
    except Exception as exception:
        assert False, 'Raise exception while collect selinux facts'

    assert selinux_fact_collector_return != {}, 'No selinux facts has been returned'
    assert isinstance(selinux_fact_collector_return, dict), 'Selinux facts should be dict'
    assert 'selinux' in selinux_fact_collector_return, 'There should be selinux key'
    assert isinstance(selinux_fact_collector_return['selinux'], dict), 'selinux key should be dict'

# Generated at 2022-06-25 00:37:00.008317
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.collect() == {
        'selinux_python_present': True,
        'selinux': {
            'status': 'enabled',
            'policyvers': 'unknown',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown',
        },
    }


test_case_0()

# Generated at 2022-06-25 00:37:49.343085
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set(['selinux_python_present'])



# Generated at 2022-06-25 00:37:51.648639
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:37:57.293400
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    case_0 = {}
    if SelinuxFactCollector().collect():
        case_0['status'] = True
    else:
        case_0['status'] = False
    return case_0


# Generated at 2022-06-25 00:38:01.861766
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.name == 'selinux'

# Generated at 2022-06-25 00:38:03.931540
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        selinux_fact_collector_0 = SelinuxFactCollector()
    except NameError as e:
        assert(False)


# Generated at 2022-06-25 00:38:11.710119
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_facts_0 = selinux_fact_collector_0.collect()
    assert 'selinux' in selinux_facts_0
    assert 'selinux_python_present' in selinux_facts_0
    assert isinstance(selinux_facts_0.get('selinux'), dict)
    # Test collect without args
    selinux_facts_1 = selinux_fact_collector_0.collect()
    assert 'selinux_python_present' in selinux_facts_1
    assert 'selinux' in selinux_facts_1


# Generated at 2022-06-25 00:38:21.728921
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_2 = SelinuxFactCollector()
    selinux_fact_collector_3 = SelinuxFactCollector()
    selinux_fact_collector_4 = SelinuxFactCollector()
    selinux_fact_collector_5 = SelinuxFactCollector()
    selinux_fact_collector_6 = SelinuxFactCollector()
    selinux_fact_collector_7 = SelinuxFactCollector()
    selinux_fact_collector_8 = SelinuxFactCollector()
    selinux_fact_collector_9 = SelinuxFactCollector()

    # Class variable _fact_ids not

# Generated at 2022-06-25 00:38:25.073435
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Verify that the SelinuxFactCollector class can be instantiated.
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)

# Generated at 2022-06-25 00:38:30.092863
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    global selinux_fact_collector
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = {}
    selinux_fact_collector.collect(collected_facts)

if __name__ == "__main__":
    test_SelinuxFactCollector_collect()
    print(selinux_fact_collector)

# Generated at 2022-06-25 00:38:30.882109
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:40:16.508681
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:40:17.859688
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    ret_value = SelinuxFactCollector()
    assert isinstance(ret_value, SelinuxFactCollector)


# Generated at 2022-06-25 00:40:19.838222
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:40:21.124541
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert selinux_fact_collector_0._fact_ids == set()



# Generated at 2022-06-25 00:40:25.251211
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert (selinux_fact_collector_0.name == "selinux")



# Generated at 2022-06-25 00:40:26.633819
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:40:32.786907
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-25 00:40:34.035290
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == "selinux"


# Generated at 2022-06-25 00:40:35.211105
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert test_case_0() == None

# Generated at 2022-06-25 00:40:42.676378
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_facts_1 = selinux_fact_collector_1.collect(collected_facts=None)
    assert 'selinux' in selinux_facts_1
    assert 'selinux_python_present' in selinux_facts_1
    assert selinux_facts_1['selinux_python_present'] == True
    assert 'status' in selinux_facts_1['selinux']
    assert selinux_facts_1['selinux']['status'] in ['enabled', 'disabled', 'Missing selinux Python library']
    if selinux_facts_1['selinux']['status'] == 'disabled':
        assert 'mode' not in selinux_facts_1['selinux']

# Generated at 2022-06-25 00:42:27.619915
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect() == {'selinux': {'config_mode': 'enforcing', 'policyvers': '28', 'mode': 'enforcing', 'type': 'targeted', 'status': 'enabled'}, 'selinux_python_present': True}

# Generated at 2022-06-25 00:42:30.721703
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_0.collect()
    assert var_1 == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Function that returns a list of the key names available for this module, in the order they are displayed.

# Generated at 2022-06-25 00:42:34.082824
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass


# Generated at 2022-06-25 00:42:35.625015
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        test_case_0()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_SelinuxFactCollector()

# Generated at 2022-06-25 00:42:41.069385
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Test for class instance attributes
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()
    # Test for instance methods
    # Test for instance methods
    assert selinux_fact_collector_0.collect() ==  {
        'selinux_python_present': True,
        'selinux': {
            'status': 'Missing selinux Python library'
        }
    }


# Generated at 2022-06-25 00:42:42.234350
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:42:44.317868
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:42:47.537165
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    

# Generated at 2022-06-25 00:42:50.066282
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert (var_0.get('selinux_python_present') == False)
    assert (var_0.get('selinux').get('status') == 'Missing selinux Python library')

# Generated at 2022-06-25 00:42:50.990350
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var = SelinuxFactCollector()
    assert var._fact_ids == set()
    assert var.name == 'selinux'
