

# Generated at 2022-06-25 00:33:58.239923
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj is not None


# Generated at 2022-06-25 00:34:00.938472
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector._fact_ids == None


# Generated at 2022-06-25 00:34:02.590097
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()

# Generated at 2022-06-25 00:34:04.421535
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert(selinux_fact_collector_0.name == 'selinux')


# Generated at 2022-06-25 00:34:12.080062
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = { 'status': 'enabled', 'policyvers': '28', 'config_mode': 'enforcing', 'mode': 'enforcing', 'type': 'targeted' }
    selinux_fact_collector_0 = SelinuxFactCollector()
    facts_dict = selinux_fact_collector_0.collect()
    facts_dict.pop('selinux_python_present')
    assert facts_dict == {'selinux': selinux_facts}

# Generated at 2022-06-25 00:34:15.591395
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux_python_present' in selinux_fact_collector.collect()


# Generated at 2022-06-25 00:34:16.760208
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-25 00:34:17.610288
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()

# Generated at 2022-06-25 00:34:18.798373
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-25 00:34:21.848189
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    if HAVE_SELINUX:
        selinux_fact_collector = SelinuxFactCollector()
        assert(selinux_fact_collector.name == 'selinux')
        assert(selinux_fact_collector._fact_ids == set())


# Generated at 2022-06-25 00:34:33.742722
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Create an instance of class SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()

    # Check whether the name attribute is set to "selinux"
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:34:38.359378
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    # Required attributes
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:34:44.468959
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert bool(selinux_fact_collector_0.name) is True
    assert bool(selinux_fact_collector_1.name) is True
    assert bool(selinux_fact_collector_0._fact_ids) is True
    assert bool(selinux_fact_collector_1._fact_ids) is True
    assert selinux_fact_collector_0.__name__ == 'SelinuxFactCollector'
    assert selinux_fact_collector_1.__name__ == 'SelinuxFactCollector'
    assert selinux_fact_collector_0.__doc__ is None
    assert selinux_fact_collector

# Generated at 2022-06-25 00:34:50.471525
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    expected = {'selinux': {'config_mode': 'unknown', 'status': 'Missing selinux Python library', 'mode': 'unknown', 'type': 'unknown', 'policyvers': 'unknown'}, 'selinux_python_present': False}
    actual = selinux_fact_collector_0.collect()
    assert actual == expected


if __name__ == "__main__":
    pass

# Generated at 2022-06-25 00:34:52.408430
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        SelinuxFactCollector()
        assert True == True
    except:
        assert True == False


# Generated at 2022-06-25 00:34:55.603340
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:00.582797
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    out = selinux_fact_collector.collect()
    assert out['selinux_python_present'] == True

# Generated at 2022-06-25 00:35:04.719084
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector is test_case_0()

# Generated at 2022-06-25 00:35:06.402275
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    executor = SelinuxFactCollector()
    assert executor


# Generated at 2022-06-25 00:35:12.173101
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    collected_facts_0 = selinux_fact_collector_0.collect(module=None, collected_facts=None)
    assert 'selinux' in collected_facts_0
    assert 'config_mode' in collected_facts_0['selinux']

# Generated at 2022-06-25 00:35:31.095395
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:35:34.897656
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_fact_collector_0 = SelinuxFactCollector()

    collected_facts = {}

    selinux_fact_collector_0.collect(collected_facts=collected_facts)

    assert 'selinux' in collected_facts

# Generated at 2022-06-25 00:35:37.338603
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:38.522680
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:35:41.119788
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)


# Generated at 2022-06-25 00:35:41.966610
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:35:42.912651
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:52.660419
# Unit test for constructor of class SelinuxFactCollector

# Generated at 2022-06-25 00:35:56.607083
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # No SELinux enabled or disabled
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect()

    # SELinux disabled
    selinux_fact_collector_1.is_selinux_enabled = lambda: False
    selinux_fact_collector_1.collect()


# Generated at 2022-06-25 00:36:04.385193
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # test case 0
    selinux_fact_collector_0 = SelinuxFactCollector()
    # SELinux not available in kernel or config
    # (selinux_python_present, status, mode, type, config_mode, policyvers)
    expected_result_0 = (True, 'disabled', 'disabled', 'targeted', None, None)
    assert selinux_fact_collector_0.collect()['selinux'] == expected_result_0

    # test case 1
    selinux_fact_collector_1 = SelinuxFactCollector()
    # SELinux enabled in kernel, but not config
    # (selinux_python_present, status, mode, type, config_mode, policyvers)

# Generated at 2022-06-25 00:36:28.812646
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    SELINUX_FACTS_DICT = selinux_fact_collector.collect()
    assert type(SELINUX_FACTS_DICT) == dict

# Generated at 2022-06-25 00:36:39.080781
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Assign parameters
    module_0 = None
    collected_facts_0 = None

    try:
        result = selinux_fact_collector_0.collect(module=module_0, collected_facts=collected_facts_0, )
    except Exception as exception:
        traceback.print_exc()
        print('%s' % (exception))
    else:
        print('%s' % (result))


if __name__ == '__main__':
    test_case_0()
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:36:40.937756
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.name == "selinux"

# Generated at 2022-06-25 00:36:43.455316
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    result = selinux_fact_collector_1.collect()
    assert isinstance(result, dict)

# Generated at 2022-06-25 00:36:45.643227
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    host_facts = {}

    host_facts = selinux_fact_collector.collect(None, host_facts)
    assert 'selinux_python_present' in host_facts

# Generated at 2022-06-25 00:36:48.235373
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector

# Generated at 2022-06-25 00:36:52.956611
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0.name, str)
    assert selinux_fact_collector_0.name == 'selinux'
    assert isinstance(selinux_fact_collector_0._fact_ids, set)
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:37:00.746164
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_fact_collector_test_dict = {
        'selinux': {
            'status': 'unknown',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown'
        },
        'selinux_python_present': True
    }

    selinux_fact_collector = SelinuxFactCollector()

    # selinux_fact_collector.HAVE_SELINUX = False
    # result = selinux_fact_collector.collect()
    # assert result == selinux_fact_collector_test_dict

    # selinux_fact_collector.HAVE_SELINUX = True
    # result = selinux_fact_collector.collect()
    # assert result == selinux_fact_collector_test_dict

# Generated at 2022-06-25 00:37:04.053809
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_dict = {'selinux': {}, 'selinux_python_present': False}
    selinux_fact_collector = SelinuxFactCollector()
    fact_collector_dict = selinux_fact_collector.collect(None, facts_dict)
    assert fact_collector_dict == facts_dict

# Generated at 2022-06-25 00:37:04.790122
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector() != True

# Generated at 2022-06-25 00:37:51.620645
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0 is not None


# Generated at 2022-06-25 00:37:52.955024
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"


# Generated at 2022-06-25 00:38:02.045760
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Injecting the mock function for the module imports

    # If the selinux dependency is missing, the selinux Python library will not import
    # and the SELinux status will be set to "disabled" because it is unknown to the
    # module whether or not SELinux is enabled on the system.
    if not HAVE_SELINUX:
        selinux_fact_collector_0 = SelinuxFactCollector()
        assert selinux_fact_collector_0.collect()['selinux']['status'] == 'Missing selinux Python library'
        assert selinux_fact_collector_0.collect()['selinux_python_present'] == False

        # Nothing else will be set in the selinux dict
        assert len(selinux_fact_collector_0.collect()['selinux']) == 1


# Generated at 2022-06-25 00:38:04.021391
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert not selinux_fact_collector_1.collect()


# Generated at 2022-06-25 00:38:13.313189
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()

    # If the Python SELinux library is not present, set all the SELinux facts to
    # None before calling collect.
    selinux_facts = {
        'status': None,
        'policyvers': None,
        'config_mode': None,
        'mode': None,
        'type': None
    }
    collected_facts = {
        'selinux': selinux_facts,
        'selinux_python_present': False
    }

    # Call collect of class SelinuxFactCollector
    selinux_fact_collector_0.collect(collected_facts=collected_facts)

    # If the Python SELinux library is not present, the test asserts that the
    # SELinux facts do not

# Generated at 2022-06-25 00:38:14.208614
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:38:20.883905
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    setattr(selinux_fact_collector_0, 'have_selinux', True)
    setattr(selinux_fact_collector_0, 'selinux_python_present', True)
    setattr(selinux_fact_collector_0, 'is_selinux_enabled', True)
    selinux_fact_collector_0._collect_selinux_python_present = mock.Mock()
    selinux_fact_collector_0._collect_selinux_status = mock.Mock()
    selinux_fact_collector_0._collect_selinux_details = mock.Mock()
    res = selinux_fact_collector_0.collect()
    res = selinux_fact_

# Generated at 2022-06-25 00:38:30.973575
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_fact_collector = SelinuxFactCollector()

    if HAVE_SELINUX:
        selinux.selinux_setup = selinux.selinux_setup_argv
        selinux.security_getenforce = lambda: 0
        selinux.security_policyvers = lambda: ''
        selinux.selinux_getenforcemode = lambda: (0, 1)
        selinux.selinux_getpolicytype = lambda: (0, 'targeted')
    else:
        selinux.is_selinux_enabled = lambda: False


# Generated at 2022-06-25 00:38:33.740391
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector.name not in selinux_fact_collector._fact_ids
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:38:37.508907
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Assign parameters
    module = None
    collected_facts = None

    # Define expected values
    expected_results = {
        'selinux': {
            'status': 'Missing selinux Python library'
        },
        'selinux_python_present': False
    }

    # Instantiate class
    selinux_fact_collector_1 = SelinuxFactCollector()

    # Call method
    results = selinux_fact_collector_1.collect(module, collected_facts)

    # Assert method return values
    assert results['selinux']['status'] == expected_results['selinux']['status']
    assert results['selinux_python_present'] == expected_results['selinux_python_present']

# Generated at 2022-06-25 00:40:22.748794
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    collected_facts = {}
    selinux_facts = selinux_fact_collector_1.collect(collected_facts=collected_facts)
    assert selinux_facts == {
        'selinux': {
            'status': 'disabled',
            'config_mode': 'unknown',
            'mode': 'unknown',
            'type': 'unknown'
        },
        'selinux_python_present': True
    }

# Generated at 2022-06-25 00:40:23.304123
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:40:24.818461
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0, SelinuxFactCollector)



# Generated at 2022-06-25 00:40:25.547526
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:40:28.890546
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:40:34.294126
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'
    assert SelinuxFactCollector()._fact_ids == set()


# Generated at 2022-06-25 00:40:35.379288
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:40:40.896736
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_dict_0 = {
        'status': 'enabled',
        'policyvers': '31',
        'config_mode': 'enforcing',
        'mode': 'enforcing',
        'type': 'targeted'
    }
    assert selinux_fact_collector_0.collect() == {'selinux': selinux_fact_dict_0, 'selinux_python_present': True}


# Generated at 2022-06-25 00:40:48.926748
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()

    # Test for selinux missing
    for i, (HAVE_SELINUX, expected_output) in enumerate([(False, 'Missing selinux Python library')]):
        with patch.multiple(selinux_fact_collector_0,
                            HAVE_SELINUX=HAVE_SELINUX):
            collected_facts = collector.collect()

            if HAVE_SELINUX:
                assert collected_facts['selinux_python_present'] == True
            else:
                assert collected_facts['selinux_python_present'] == False

            assert collected_facts['selinux']['status'] == expected_output



# Generated at 2022-06-25 00:40:55.416207
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    # Verify that the input parameters are set correctly
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()
