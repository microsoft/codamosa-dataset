

# Generated at 2022-06-25 00:34:00.640994
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_1,BaseFactCollector) == True


# Generated at 2022-06-25 00:34:01.382907
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()



# Generated at 2022-06-25 00:34:07.891373
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    collected_facts_0 = {'ansible_os_family': 'RedHat'}
    ansible_0 = {'ansible_facts': {'ansible_selinux': {'config_mode': 'unknown', 'status': 'Missing selinux Python library', 'mode': 'unknown', 'type': 'unknown', 'policyvers': 'unknown'}, 'selinux_python_present': False, 'ansible_selinux_python_present': False}}

# Generated at 2022-06-25 00:34:09.786406
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)


# Generated at 2022-06-25 00:34:15.548654
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert hasattr(selinux_fact_collector_0, 'name')
    assert hasattr(selinux_fact_collector_0, '_fact_ids')


# Generated at 2022-06-25 00:34:23.521530
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert isinstance(selinux_facts, dict)
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    assert isinstance(selinux_facts['selinux'], dict)
    assert isinstance(selinux_facts['selinux_python_present'], bool)
    assert 'status' in selinux_facts['selinux']
    assert isinstance(selinux_facts['selinux']['status'], str)
    assert selinux_facts['selinux']['status'] in ['Missing selinux Python library', 'enabled', 'disabled']
    assert 'policyvers' in selinux_

# Generated at 2022-06-25 00:34:27.246449
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux', 'Fact collector name is not set properly. Expected: selinux. Received: {0}'.format(SelinuxFactCollector.name)
    assert SelinuxFactCollector._fact_ids == set(), 'Fact collector _fact_ids is not empty, it should be an empty set.'
    print('Success: test_SelinuxFactCollector')



# Generated at 2022-06-25 00:34:30.250446
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:33.382659
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = selinux_fact_collector.collect()
    assert isinstance(collected_facts['selinux_python_present'], bool)

# Generated at 2022-06-25 00:34:35.129958
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    result = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:47.959080
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0();
    print ('------------------------------------------');
    print ('Test Case #0: Passed');
    print ('------------------------------------------');

if __name__ == '__main__':
    test_SelinuxFactCollector();

# Generated at 2022-06-25 00:34:52.071377
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_object = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_object, SelinuxFactCollector)
    assert selinux_fact_collector_object.name == 'selinux'
    assert selinux_fact_collector_object._fact_ids == set()


# Generated at 2022-06-25 00:34:54.191120
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.name
    assert result == 'selinux'

# Generated at 2022-06-25 00:34:57.207953
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:34:59.785095
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector._fact_ids == set([])
    assert SelinuxFactCollector.name == 'selinux'


# Generated at 2022-06-25 00:35:04.926828
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-25 00:35:06.920762
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:09.244926
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux', "Incorrect name for the SelinuxFactCollector class"
    assert SelinuxFactCollector._fact_ids == set(), "Incorrect fact_ids for the SelinuxFactCollector class"


# Generated at 2022-06-25 00:35:12.172900
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:35:13.869148
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:26.057981
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:35:28.738943
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert False


# Generated at 2022-06-25 00:35:30.090896
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:35:34.783338
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert not selinux_fact_collector_0.name
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:35:41.092593
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    returned_dict = selinux_fact_collector_0.collect()
    assert type(returned_dict) == dict
    assert 'selinux' in returned_dict
    assert type(returned_dict['selinux']) == dict
    assert returned_dict['selinux_python_present'] == True


# Generated at 2022-06-25 00:35:47.815026
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Not sure if this test case is meaningful for this module
    # since results of this module depends on the environment
    # under which this module is running.
    selinux_fact_collector_1 = SelinuxFactCollector()
    collected_facts = {}
    collected_facts['ansible_selinux'] = {
        'status': 'enabled',
        'mode': 'enforcing',
        'type': 'targeted',
        'policyvers': '28'
    }

    selinux_fact_collector_1.collect(collected_facts=collected_facts)
    collected_facts = selinux_fact_collector_1.collect(collected_facts=collected_facts)

# Generated at 2022-06-25 00:35:49.843952
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector().collect()
    assert result['selinux']['type'] == 'unknown'

# Generated at 2022-06-25 00:35:56.445963
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert type(selinux_fact_collector_0) == SelinuxFactCollector
    assert hasattr(selinux_fact_collector_0, "name")
    assert hasattr(selinux_fact_collector_0, "_fact_ids")
    assert hasattr(selinux_fact_collector_0, "collect")
    assert callable(selinux_fact_collector_0.collect)

# Generated at 2022-06-25 00:35:57.876603
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_2 = SelinuxFactCollector()

# Generated at 2022-06-25 00:36:01.147681
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector().name, str)
    assert isinstance(SelinuxFactCollector()._fact_ids, set)


# Generated at 2022-06-25 00:36:16.383131
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0, SelinuxFactCollector)


# Generated at 2022-06-25 00:36:19.098520
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0['selinux_python_present'] == True
    assert var_0['selinux']['status'] == 'disabled'


# Generated at 2022-06-25 00:36:21.666998
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()


# Generated at 2022-06-25 00:36:22.796482
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.collect()

# Generated at 2022-06-25 00:36:28.305690
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_obj = SelinuxFactCollector()
    assert selinux_fact_collector_obj.name == 'selinux'


# Generated at 2022-06-25 00:36:31.865698
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:41.930008
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector

    selinux_fact_collector_0 = SelinuxFactCollector()

    assert isinstance(selinux_fact_collector_0, BaseFactCollector) == True , "Failed to create SelinuxFactCollector instance."

    var_1 = selinux_fact_collector_0.collect()

    assert 'selinux' in var_1 , "Failed to collect facts."

    assert 'status' in var_1['selinux'], "Failed to set 'status' as required value."

    assert 'selinux_python_present' in var_1, "Failed to set 'selinux_python_present' as required value."

    assert isinstance(var_1['selinux_python_present'], bool) == True

# Generated at 2022-06-25 00:36:47.002590
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert "selinux" in var_0
    assert var_0['selinux']['status'] == "Missing selinux Python library"


# Generated at 2022-06-25 00:36:52.437937
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert(isinstance(selinux_fact_collector_0, BaseFactCollector))
    assert(isinstance(selinux_fact_collector_0._fact_ids, set))
    assert(isinstance(selinux_fact_collector_0.name, str))
    assert(hasattr(selinux_fact_collector_0, 'collect'))
    assert(hasattr(selinux_fact_collector_0, 'get_fact_names'))


# Generated at 2022-06-25 00:37:00.152407
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # TODO implement test collect
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    if not HAVE_SELINUX:
        assert var_0 == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}
    else:
        assert var_0['selinux_python_present'] == True
        assert 'selinux' in var_0
        assert 'config_mode' in var_0['selinux']
        assert 'mode' in var_0['selinux']
        assert 'status' in var_0['selinux']
        assert 'type' in var_0['selinux']

# Generated at 2022-06-25 00:37:30.373820
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.collect() == {
        'selinux': {
            'policyvers': 'unknown',
            'mode': 'unknown',
            'config_mode': 'unknown',
            'status': 'Missing selinux Python library',
            'type': 'unknown'
        },
        'selinux_python_present': False
    }


# Generated at 2022-06-25 00:37:33.623586
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

test_case_0()

# Generated at 2022-06-25 00:37:39.116354
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()

    # Test with HAVE_SELINUX == False, selinux Python library is not present
    selinux_fact_collector_0.HAVE_SELINUX = False
    var_0 = selinux_fact_collector_0.collect()
    assert 'selinux' in var_0
    selinux_facts = var_0['selinux']
    assert selinux_facts['status'] == 'Missing selinux Python library'
    assert not var_0['selinux_python_present']

    # Test with HAVE_SELINUX, selinux Python library is present
    selinux_fact_collector_0.HAVE_SELINUX = True

    # Test with selinux.is_selinux_enabled() == True, SEL

# Generated at 2022-06-25 00:37:40.006597
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  var_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:37:44.001445
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0['selinux']['status'] == 'Missing selinux Python library'
    assert var_0['selinux_python_present'] == False

# Generated at 2022-06-25 00:37:49.027412
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Create instance of class SelinuxFactCollector
    selinux_fact_collector_1 = SelinuxFactCollector()
    # Assert type of class SelinuxFactCollector
    assert isinstance(selinux_fact_collector_1, SelinuxFactCollector)


# Generated at 2022-06-25 00:37:51.393254
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:37:56.285172
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # noinspection PyUnresolvedReferences
    selinux_fact_collector = SelinuxFactCollector()
    # noinspection PyShadowingNames
    def test_case(selinux_data, selinux_python_present, selinux_policyvers, selinux_config_mode,
                  selinux_mode, selinux_type):
        selinux_fact_collector._fact_ids = set()
        selinux_fact_collector.get_file_content = lambda filename: selinux_data
        selinux_fact_collector.set_type_of_file = lambda x: None

# Generated at 2022-06-25 00:37:57.458803
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    vars_0 = selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:38:01.594239
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector.name
    var_2 = SelinuxFactCollector._fact_ids

# Generated at 2022-06-25 00:38:45.337439
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Value for assert
    var_1 = 'SelinuxFactCollector'
    # Value for assert
    var_2 = {'selinux'}
    assert var_1 == selinux_fact_collector_0.name
    assert var_2 == selinux_fact_collector_0._fact_ids



# Generated at 2022-06-25 00:38:46.692573
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:47.802426
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:54.583779
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    var_1 = SelinuxFactCollector()
    var_2 = SelinuxFactCollector()
    var_3 = SelinuxFactCollector()
    var_4 = SelinuxFactCollector()
    var_5 = SelinuxFactCollector()
    var_6 = SelinuxFactCollector()
    var_7 = SelinuxFactCollector()
    var_8 = SelinuxFactCollector()
    var_9 = SelinuxFactCollector()
    var_10 = SelinuxFactCollector()
    var_11 = SelinuxFactCollector()
    var_12 = SelinuxFactCollector()
    var_13 = SelinuxFactCollector()
    var_14 = SelinuxFactCollector()
    var_15 = SelinuxFactCollector()
    var_16

# Generated at 2022-06-25 00:38:56.504536
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    print("%s" % var_0)


# Generated at 2022-06-25 00:39:02.954257
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    var_1 = selinux_fact_collector_1.name
    var_1 = selinux_fact_collector_1._fact_ids
    selinux_fact_collector_2 = SelinuxFactCollector()
    var_2 = selinux_fact_collector_2.collect()
    var_2 = selinux_fact_collector_2.name
    var_2 = selinux_fact_collector_2._fact_ids
    selinux_fact_collector_3 = SelinuxFactCollector()
    var_3 = selinux_fact_collector_3.collect()
    var_3 = selinux_fact_collector_3.name

# Generated at 2022-06-25 00:39:05.389414
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:39:06.605745
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:39:07.764671
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

# Test cases for class constructor

# Generated at 2022-06-25 00:39:09.558862
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # selinux is available, with enabled selinux
    test_case_0()
    # selinux is available, with disabled selinux
    # test_case_1()
    # selinux is not available
    # test_case_2()

# Generated at 2022-06-25 00:41:11.649501
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModule(
        argument_spec = dict()
    )

    if HAVE_SELINUX:
        (rc, policytype) = selinux.selinux_getpolicytype()
        (rc, configmode) = selinux.selinux_getenforcemode()
        mode = selinux.security_getenforce()
        policyvers = selinux.security_policyvers()
    else:
        policytype = "unknown"
        configmode = -1
        mode = -1
        policyvers = "unknown"

    status = "disabled"
    if selinux.is_selinux_enabled():
        status = "enabled"

    selinux_facts = {}

    selinux_facts['status'] = status
    selinux_facts['policyvers'] = policyvers
    selinux_facts['config_mode']

# Generated at 2022-06-25 00:41:18.047864
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test if selinux library is present
    if HAVE_SELINUX:
        # Get the expected results
        var_1 = SelinuxFactCollector()
        var_2 = var_1.collect()
        var_3 = False
        var_4 = var_2['selinux']['status']
        var_5 = var_2['selinux']['policyvers']
        var_6 = var_2['selinux']['config_mode']
        var_7 = var_2['selinux']['mode']
        var_8 = var_2['selinux']['type']
        var_9 = var_2['selinux_python_present']

        # Get results from running SelinuxFactCollector.collect method
        var_10 = SelinuxFactCollector()


# Generated at 2022-06-25 00:41:21.565284
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModule({},
                           {},
                           "/home/bob/ansible/testcases/ansible_module_facts/library/selinux_facts.py")
    def test_SelinuxFactCollector_collect():
        selinux_fact_collector_0 = SelinuxFactCollector()
        var_0 = selinux_fact_collector_0.collect()

        assert var_0['selinux_python_present'] is False

# Generated at 2022-06-25 00:41:25.179414
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        SelinuxFactCollector()
    except NameError as e:
        assert(str(e)=="name 'SelinuxFactCollector' is not defined")
    except TypeError as e:
        assert(str(e)=="object() takes no parameters")


# Generated at 2022-06-25 00:41:30.324635
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0['selinux']['mode'] == 'unknown'
    assert var_0['selinux_python_present'] == False
    assert var_0['selinux']['status'] == 'Missing selinux Python library'



# Generated at 2022-06-25 00:41:36.340828
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    expected_results_0 = {'selinux': {'mode': 'disabled', 'status': 'disabled'}, 'selinux_python_present': False}
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert selinux_fact_collector_0._fact_ids == set()
    assert var_0 == expected_results_0

# Generated at 2022-06-25 00:41:39.873041
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:41:41.349672
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    if HAVE_SELINUX:
        var_0 = SelinuxFactCollector()._fact_ids
        var_1 = SelinuxFactCollector().name
        var_2 = SelinuxFactCollector().collect()


# Generated at 2022-06-25 00:41:47.608042
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:41:48.893082
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()

