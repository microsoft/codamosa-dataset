

# Generated at 2022-06-25 00:34:01.123415
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:03.639883
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
  selinux_fact_collector_0 = SelinuxFactCollector()
  # test for exception NameError(msg)
  with pytest.raises(NameError):
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:34:06.712989
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:34:08.952017
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Selinux fact collector is part of Ansible.
    """
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-25 00:34:11.891049
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Call to test_case_0
    selinux_fact_collector_0 = SelinuxFactCollector()

# Unit test

# Generated at 2022-06-25 00:34:13.486721
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()



# Generated at 2022-06-25 00:34:18.485683
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, BaseFactCollector)


# Generated at 2022-06-25 00:34:19.655621
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-25 00:34:24.825327
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert(selinux_fact_collector.name == 'selinux')
    assert(selinux_fact_collector._fact_ids == set())

# Generated at 2022-06-25 00:34:26.078376
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-25 00:34:37.899477
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_facts_dict_0 = selinux_fact_collector_1.collect()


# Generated at 2022-06-25 00:34:41.270736
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # The selinux library is not present.
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert facts_dict['selinux_python_present'] == False
    assert facts_dict['selinux'] == {'status': 'Missing selinux Python library'}


# Generated at 2022-06-25 00:34:44.952305
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:34:45.880043
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:34:48.661188
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.name == 'selinux'


# Generated at 2022-06-25 00:34:51.342421
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test whether the SelinuxFactCollector is created
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"

# Generated at 2022-06-25 00:34:56.686527
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0, BaseFactCollector), "Returned value from SelinuxFactCollector() is not an instance of class BaseFactCollector"
    assert selinux_fact_collector_0.collect(), "Call to SelinuxFactCollector().collect() returned a non-truthy value"

if __name__ == '__main__':
    test_case_0()
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:35:02.937594
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_facts_0 = selinux_fact_collector_0.collect()
    if 'selinux' in selinux_facts_0:
        print('selinux_facts_0["selinux"] = ' + str(selinux_facts_0['selinux']))
    else:
        print('selinux_facts_0["selinux"] not found')
    if 'selinux_python_present' in selinux_facts_0:
        print('selinux_facts_0["selinux_python_present"] = ' + str(selinux_facts_0['selinux_python_present']))

# Generated at 2022-06-25 00:35:04.875199
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector(
    ).name == 'selinux', 'SelinuxFactCollector.name is not "selinux"'
    assert SelinuxFactCollector(
    )._fact_ids == set(), 'SelinuxFactCollector._fact_ids is not "{}"'


# Generated at 2022-06-25 00:35:11.438566
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    result = selinux_fact_collector_0.collect()
    assert result is not None
    assert result.get('ansible_selinux') is not None
    assert result.get('ansible_selinux_python_present') is not None
    selinux_facts = result.get('ansible_selinux')
    assert selinux_facts.get('config_mode') is not None
    assert selinux_facts.get('mode') is not None
    assert selinux_facts.get('policyvers') is not None
    assert selinux_facts.get('status') is not None
    assert selinux_facts.get('type') is not None

# Generated at 2022-06-25 00:35:30.557711
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Run unit test when file is executed.
if __name__ == "__main__":
    test_SelinuxFactCollector()

# Generated at 2022-06-25 00:35:32.688169
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    collected_facts_return_value = selinux_fact_collector_1.collect()
    assert collected_facts_return_value


# Generated at 2022-06-25 00:35:34.433232
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:38.881713
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == "selinux"
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:35:40.520881
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()

    selinux_fact_collector_1.collect()
    selinux_fact_collector_1.collect({'data': 'data', 'val': 'val'})

# Generated at 2022-06-25 00:35:41.605344
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:35:47.712192
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    global HAVE_SELINUX
    # Set HAVE_SELINUX to False, so that collect module_utils/facts/collector.py
    # will not attempt to import the selinux library.
    original_value = HAVE_SELINUX
    HAVE_SELINUX = False
    try:
        selinux_fact_collector = SelinuxFactCollector()
        # Ensure that the selinux_python_present fact is False
        assert selinux_fact_collector.collect()['selinux_python_present'] == False
    finally:
        HAVE_SELINUX = original_value

# Generated at 2022-06-25 00:35:49.518814
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:51.325937
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert('selinux' == SelinuxFactCollector().name)
    assert({} == SelinuxFactCollector().fact_ids)

# Generated at 2022-06-25 00:35:53.610889
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    res = selinux_fact_collector_0.collect()
    res_type = type(res)
    assert res_type == dict

# Generated at 2022-06-25 00:36:38.460246
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()

    facts_dict = selinux_fact_collector_1.collect(module="AnsibleModule", collected_facts={})
    assert facts_dict == {'selinux': {'status': 'disabled'}, 'selinux_python_present': True} or \
        facts_dict == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-25 00:36:41.301972
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:36:43.195425
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-25 00:36:45.653188
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    ans_collector_0 = AnsibleCollector()
    selinux_fact_collector_0.collect(ans_collector_0)


# Generated at 2022-06-25 00:36:48.498516
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()


# Generated at 2022-06-25 00:36:50.032127
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:52.922754
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    print('Testing Constructor of class SelinuxFactCollector')
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.__class__.__name__ == 'SelinuxFactCollector'


# Generated at 2022-06-25 00:36:59.290302
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert selinux_facts['selinux']['status'] == 'enabled'
    assert selinux_facts['selinux']['config_mode'] == 'unknown'
    assert selinux_facts['selinux']['mode'] == 'unknown'
    assert selinux_facts['selinux']['policyvers'] == 'unknown'
    assert selinux_facts['selinux']['type'] == 'unknown'
    assert selinux_facts['selinux_python_present'] == True

# Generated at 2022-06-25 00:37:05.573930
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Dummy test case for when the selinux library is missing
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert facts_dict.get('selinux') == {'status': 'Missing selinux Python library'}
    # Now with selinux and ensure we have the selinux_python_present boolean set
    if HAVE_SELINUX:
        selinux_fact_collector = SelinuxFactCollector()
        facts_dict = selinux_fact_collector.collect()
        assert facts_dict.get('selinux') != {'status': 'Missing selinux Python library'}
        assert facts_dict.get('selinux_python_present') is True
        # Re-run test with 'disabled' SELinux, expect se

# Generated at 2022-06-25 00:37:08.787889
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector.collect()
    assert result['selinux']['mode'] == 'unknown'


if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:38:28.827298
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0 is not None


# Generated at 2022-06-25 00:38:33.106518
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:38:37.381163
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Check if the member variable name of class SelinuxFactCollector is defined
    try:
        selinux_fact_collector_0.name
    except AttributeError:
        assert False

    # Check if the member variable _fact_ids of class SelinuxFactCollector is defined
    try:
        selinux_fact_collector_0._fact_ids
    except AttributeError:
        assert False

    # Check if the member variable name of class SelinuxFactCollector has the expected value
    assert selinux_fact_collector_0.name == 'selinux'

    # Check if the member variable _fact_ids of class SelinuxFactCollector has the expected value

# Generated at 2022-06-25 00:38:39.357257
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:38:41.406020
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:44.972977
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    print('\tVerifying test_SelinuxFactCollector of class SelinuxFactCollector')
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:38:50.727069
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    Collector.collectors['ansible.module_utils.facts.system.selinux'] = SelinuxFactCollector
    Collector.collectors['ansible.module_utils.facts.system.selinux'].collect(None, dict())
    assert 'selinux_python_present' in dict()

# Generated at 2022-06-25 00:38:54.723173
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()
    assert result['selinux_python_present'] is True

# Generated at 2022-06-25 00:39:00.950568
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fake_module = dict()
    selinux_fact_collector_0 = SelinuxFactCollector()
    fun_facts_0 = selinux_fact_collector_0.collect(fake_module, collected_facts=None)

    assert fun_facts_0['selinux_python_present'] == True
    assert fun_facts_0['selinux']['mode'] == 'unknown'
    assert fun_facts_0['selinux']['policyvers'] == 'unknown'
    assert fun_facts_0['selinux']['config_mode'] == 'unknown'
    assert fun_facts_0['selinux']['status'] == 'enabled'
    assert fun_facts_0['selinux']['type'] == 'unknown'

# Generated at 2022-06-25 00:39:01.625551
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:40:48.590863
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_collect = selinux_fact_collector_0.collect()
    assert selinux_collect == selinux_collect

# Generated at 2022-06-25 00:40:52.307365
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:40:58.927703
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()

    # checking the attribute _fact_ids
    assert set == type(selinux_fact_collector._fact_ids)
    assert set() == selinux_fact_collector._fact_ids

    # checking the attribute name
    assert 'selinux' == selinux_fact_collector.name


# Generated at 2022-06-25 00:41:01.370509
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name is 'selinux'


# Generated at 2022-06-25 00:41:08.108284
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:41:16.524888
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Test the case where no selinux library is present.
    # This is the case when running this unit test script on macOS
    # where the selinux Python library is not available.
    if not HAVE_SELINUX:
        collected_facts = {}
        module = None
        exp_facts_dict = {
            'selinux': {
                'status': 'Missing selinux Python library'
            },
            'selinux_python_present': False
        }
        facts_dict = selinux_fact_collector_0.collect(module, collected_facts)
        assert facts_dict == exp_facts_dict

# Generated at 2022-06-25 00:41:19.611856
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    try:
        # Constructor of class SelinuxFactCollector
        test_case_0()
        print("Test Case 0 Passed\n")
    except Exception as e:
        print("Test Case 0 Failed\n")
        print(e)

# Provide path to the inventory file passed as argument in command line

# Generated at 2022-06-25 00:41:21.807206
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:41:30.931319
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts
    assert 'status' not in selinux_facts['selinux']
    assert 'policyvers' not in selinux_facts['selinux']
    assert 'config_mode' not in selinux_facts['selinux']
    assert 'mode' not in selinux_facts['selinux']
    assert 'type' not in selinux_facts['selinux']
    assert type(selinux_facts['selinux_python_present']) == bool

    selinux_facts = selinux_fact_collector.collect()

# Generated at 2022-06-25 00:41:33.330474
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()