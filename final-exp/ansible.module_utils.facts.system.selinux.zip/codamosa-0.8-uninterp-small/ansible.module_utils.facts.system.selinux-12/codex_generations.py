

# Generated at 2022-06-25 00:33:57.450351
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert ('selinux' in facts_dict)

# Generated at 2022-06-25 00:34:01.736882
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    results = selinux_fact_collector.collect()
    assert 'selinux' in results
    if HAVE_SELINUX:
        assert 'status' in results
        assert 'config_mode' in results
        assert 'mode' in results
        assert 'type' in results
        assert 'policyvers' in results
    assert 'selinux_python_present' in results

# Generated at 2022-06-25 00:34:02.838886
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj != None

# Generated at 2022-06-25 00:34:07.223002
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-25 00:34:11.465019
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector

    selinux_fact_collector =Sel(SelinuxFactCollector)
    assert isinstance(selinux_fact_collector,SelinuxFactCollector)
    assert isinstance(selinux_fact_collector,BaseFactCollector)
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:34:15.995485
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert (hasattr(selinux_fact_collector_0, 'name'))


# Check if the SelinuxFactCollector class can handle properly when
# python-selinux library is missing

# Generated at 2022-06-25 00:34:18.437283
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0, SelinuxFactCollector)


# Generated at 2022-06-25 00:34:24.876915
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = {
        "selinux": {
            "config_mode": "unknown",
            "mode": "unknown",
            "policyvers": "unknown",
            "status": "unsupported",
            "type": "unknown"
        }
    }
    selinux_facts = selinux_fact_collector.collect(collected_facts=collected_facts)
    assert selinux_facts['selinux'] == {'config_mode': 'unknown', 'mode': 'unknown', 'policyvers': 'unknown', 'status': 'unsupported', 'type': 'unknown'}

# Generated at 2022-06-25 00:34:28.325101
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    actual = selinux_fact_collector_0.collect(module=None, collected_facts=None)

#---------------------------------------------------------------------------
# Test class for module SelinuxFactCollector

# Generated at 2022-06-25 00:34:32.041540
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)

# Unit tests for get_fact_names

# Generated at 2022-06-25 00:34:42.781675
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-25 00:34:44.439373
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:34:52.849677
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    if HAVE_SELINUX:
        selinux_fact_collector_1 = SelinuxFactCollector()
        # test class variable name is assigned correctly
        name = selinux_fact_collector_1.name
        assert name == 'selinux'
        # test collected_facts list is initialized correctly
        collected_facts_list = selinux_fact_collector_1._fact_ids
        assert collected_facts_list == set()
    else:
        # if Python selinux library does not exist, test throws ImportError
        import pytest
        with pytest.raises(ImportError):
            selinux_fact_collector_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:55.515187
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:34:59.696397
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:35:09.324641
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    my_dict_0 = {'selinux': {}, 'selinux_python_present': False}
    my_dict_1 = {'selinux': {'status': 'disabled', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'}, 'selinux_python_present': False}
    if (selinux_fact_collector_0.have_selinux_python_lib):
        assert selinux_fact_collector_0.collect() == my_dict_1
    else:
        assert selinux_fact_collector_0.collect() == my_dict_0

# Generated at 2022-06-25 00:35:10.143163
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # No test
    pass

# Generated at 2022-06-25 00:35:11.622284
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

test_case_0()

# Generated at 2022-06-25 00:35:13.799173
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:35:15.247200
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0 is not None


# Generated at 2022-06-25 00:35:28.267896
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:35:35.662239
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector(
        'ansible.module_utils.facts.system.selinux')
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

    # Testing the collect method
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:35:40.805728
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == set()
    assert selinux_fact_collector_0.name == 'selinux'

SelinuxFactCollector()



# Generated at 2022-06-25 00:35:44.889392
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    var_1 = SelinuxFactCollector()
    var_2 = var_1.collect()

    # Don't check the value of facts because dicts can be unordered.
    assert 'selinux' in var_2
    assert 'selinux_python_present' in var_2
    assert var_2['selinux_python_present'] == True

# Generated at 2022-06-25 00:35:46.020885
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()



# Generated at 2022-06-25 00:35:46.811393
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:35:49.844709
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:35:50.705873
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:35:54.731301
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0.collect() == {
        'selinux': {
            'status': 'Missing selinux Python library',
        },
        'selinux_python_present': False
    }


# Generated at 2022-06-25 00:35:57.101886
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert not selinux_fact_collector._fact_ids



# Generated at 2022-06-25 00:36:25.331972
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Note: Cannot instantiate SelinuxFactCollector due to
    # NameError: name 'selinux' is not defined
    # when the SelinuxFactCollector class is imported from
    # the module.
    selinux_fact_collector = SelinuxFactCollector()
    # TODO: Add some tests for SelinuxFactCollector.collect()
    pass


# Generated at 2022-06-25 00:36:30.223853
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    global HAVE_SELINUX

    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    if not HAVE_SELINUX:
        assert HAVE_SELINUX
        selinux_fact_collector_0 = SelinuxFactCollector()
        var_0 = selinux_fact_collector_0.collect()
        assert var_0['selinux'].get('status') == 'Missing selinux Python library'
        assert var_0['selinux_python_present'] == False
    # Set a boolean for testing whether the Python library is present
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact

# Generated at 2022-06-25 00:36:33.777819
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:37.053840
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == set()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:36:38.842952
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:42.959145
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()

    # Don't know how to test selinux_fact_collector_1.collect()
    # See: https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/collector/selinux.py#L58
    assert False


# Generated at 2022-06-25 00:36:45.180067
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert var_1 is not None

# Generated at 2022-06-25 00:36:48.434059
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'



# Generated at 2022-06-25 00:36:49.751181
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:51.155440
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)


# Generated at 2022-06-25 00:37:42.115239
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:37:46.674252
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()
    var_0 = isinstance(selinux_fact_collector_0._fact_ids, set)
    assert val_0



# Generated at 2022-06-25 00:37:56.223819
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert 'selinux' in selinux_fact_collector_0.collect()
    assert 'status' in selinux_fact_collector_0.collect()
    assert 'selinux_python_present' in selinux_fact_collector_0.collect()
    assert 'selinux' in selinux_fact_collector_0._fact_ids
    assert 'status' in selinux_fact_collector_0._fact_ids
    assert 'selinux_python_present' in selinux_fact_collector_0._fact

# Generated at 2022-06-25 00:37:57.020910
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:03.961580
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # The following call to collect is expected to fail with a RuntimeError
    try:
        selinux_fact_collector_0.collect()
    except RuntimeError as exception_0:
        var_0 = exception_0
    except Exception as exception_1:
        var_0 = exception_1

# Generated at 2022-06-25 00:38:13.291773
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert 'selinux' in var_0
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert 'selinux_python_present' in var_1


# if __name__ == '__main__':
    # test_case_0()
    # test_SelinuxFactCollector_collect()


#import sys
#import pytest
#
#from lib.collectors.selinux import SelinuxFactCollector
#
#
#@pytest.mark.skipif(sys.version_info[0] == 2, reason='Skipping due

# Generated at 2022-06-25 00:38:17.270449
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Here is how to make sure that the constructor has actually
    # created an object of type SelinuxFactCollector
    selinux_fact_collector_1 = SelinuxFactCollector()
    test_case_0()

if __name__ == '__main__':
    test_SelinuxFactCollector()

# Generated at 2022-06-25 00:38:19.667158
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:38:24.323220
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:29.412426
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    if HAVE_SELINUX:
        assert selinux_fact_collector_0.name == "selinux"
    else:
        assert selinux_fact_collector_0.name == "selinux missing library"

# Generated at 2022-06-25 00:40:25.730246
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_7 = SelinuxFactCollector()
    assert selinux_fact_collector_7.name == 'selinux'
    assert selinux_fact_collector_7._fact_ids == set()


# Generated at 2022-06-25 00:40:27.613516
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.__class__.__name__ == 'SelinuxFactCollector'


# Generated at 2022-06-25 00:40:36.605986
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()

    # If selinux Python library is missing
    selinux_fact_collector.set_context('selinux_python_present', False)
    var = selinux_fact_collector.collect()
    assert var['selinux']['status'] == 'Missing selinux Python library'
    assert var['selinux_python_present'] == False

    # If selinux Python library is present
    selinux_fact_collector.set_context('selinux_python_present', True)
    selinux_fact_collector.set_context('is_selinux_enabled', False)
    var = selinux_fact_collector.collect()
    assert var['selinux']['status'] == 'disabled'

# Generated at 2022-06-25 00:40:42.465805
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:40:44.278026
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Test attributes of class SelinuxFactCollector
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:40:48.002668
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == "selinux"


# Generated at 2022-06-25 00:40:49.807113
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1


# Generated at 2022-06-25 00:40:55.235799
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()

    var_0 = selinux_fact_collector_1.collect()

    assert var_0 == {'selinux': {'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown', 'policyvers': 'unknown', 'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-25 00:40:56.157656
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:40:58.899923
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()

