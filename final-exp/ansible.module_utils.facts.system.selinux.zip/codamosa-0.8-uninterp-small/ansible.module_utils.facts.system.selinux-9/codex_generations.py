

# Generated at 2022-06-25 00:34:02.693055
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:04.514827
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:34:10.406717
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:34:17.527968
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    compiled_regex = re.compile(r"(?<!\\)\(")    # Does not match the escape sequence for (
    result = compiled_regex.split(selinux_fact_collector_1.collect())
    assert result[0] == ''
    assert result[1] == 'selinux'
    assert result[2] == 'selinux_python_present'


# Generated at 2022-06-25 00:34:23.695208
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Construct object of class SelinuxFactCollector
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0, SelinuxFactCollector)
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set([])


# Generated at 2022-06-25 00:34:24.775736
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    result = SelinuxFactCollector.collect()
    assert result.get('selinux_python_present') == True

# Generated at 2022-06-25 00:34:26.134016
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_collect_NONE = SelinuxFactCollector()
    selinux_fact_collector_collect_NONE.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:34:31.520596
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    selinux_fact_collector_0 = SelinuxFactCollector()
    result = selinux_fact_collector_0.collect()
    assert result == {}


# Generated at 2022-06-25 00:34:35.944671
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:34:40.553655
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()
    assert isinstance(selinux_fact_collector_0, BaseFactCollector)

# Generated at 2022-06-25 00:34:50.036181
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

# Test cases for the module
if __name__ == '__main__':
    import pytest

    pytest.main(['-v','test_selinux.py::test_case_0','test_selinux.py::test_SelinuxFactCollector_collect'])

# Generated at 2022-06-25 00:34:56.747566
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    collected_facts = {}
    selinux_fact_collector_0.collect(collected_facts=collected_facts)
    assert 'selinux' in collected_facts
    assert 'semanage' in collected_facts['selinux']
    assert 'status' in collected_facts['selinux']
    assert 'policyvers' in collected_facts['selinux']['semanage']
    assert collected_facts['selinux']['semanage']['status'] == 'enabled'
    assert collected_facts['selinux']['semanage']['installed'] is True

# Generated at 2022-06-25 00:34:57.914693
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-25 00:35:04.559272
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    if HAVE_SELINUX:
        selinux_fact_collector = SelinuxFactCollector()
        facts = selinux_fact_collector.collect()
        assert facts['selinux']['type'] != 'unknown'
        assert facts['selinux']['config_mode'] != 'unknown'
        assert facts['selinux']['mode'] != 'unknown'
        assert facts['selinux']['policyvers'] != 'unknown'
        assert facts['selinux']['status'] != 'missing'
    else:
        selinux_fact_collector = SelinuxFactCollector()
        facts = selinux_fact_collector.collect()
        assert not HAVE_SELINUX

# Generated at 2022-06-25 00:35:05.536079
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

# Generated at 2022-06-25 00:35:13.161985
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.name = 'foo'
    selinux_dict_0 = selinux_fact_collector_0.collect(module=None, collected_facts=None)
    assert selinux_dict_0['selinux'] == {'status': 'Missing selinux Python library'}
    assert selinux_dict_0['selinux_python_present'] == False

# Generated at 2022-06-25 00:35:14.360123
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:35:15.252384
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:35:16.205943
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-25 00:35:19.959687
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    result = selinux_fact_collector_1.collect()
    print(result)


# Generated at 2022-06-25 00:35:28.889722
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:31.652285
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:35:40.154047
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # Type of 'selinux_fact_collector_0' is of type 'SelinuxFactCollector'
    assert type(selinux_fact_collector_0) is SelinuxFactCollector
    # Type of 'SelinuxFactCollector._fact_ids' is of type 'set'
    assert type(selinux_fact_collector_0._fact_ids) is set
    # Contents of 'SelinuxFactCollector._fact_ids' are as expected
    assert selinux_fact_collector_0._fact_ids == set()
    # Type of 'SelinuxFactCollector.name' is of type 'str'
    assert type(selinux_fact_collector_0.name) is str
    # Contents of

# Generated at 2022-06-25 00:35:42.447398
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = {}
    assert selinux_fact_collector.collect(collected_facts=collected_facts) == {'selinux': {}, 'selinux_python_present': False}

# Generated at 2022-06-25 00:35:46.338861
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:35:51.594316
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    from ansible.module_utils.facts.collector.selinux import SelinuxFactCollector

    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:35:53.610967
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    var = selinux_fact_collector.collect()
    assert (type(var) is dict)

# Generated at 2022-06-25 00:35:59.145102
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test case where python-selinux library is not installed
    global HAVE_SELINUX
    HAVE_SELINUX = False
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

    # Test case where python-selinux library is installed
    global HAVE_SELINUX
    HAVE_SELINUX = True
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:36:02.141695
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()
    var_1 = var_0.name
    assert var_1 == 'selinux'


# Generated at 2022-06-25 00:36:05.959935
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()
#

# Generated at 2022-06-25 00:36:19.339413
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # We can't check the value of facts_dict, because it will change from
    # system to system, but we can at least check that the function doesn't
    # raise an exception
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-25 00:36:23.600442
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1 is not None


# Generated at 2022-06-25 00:36:27.868544
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-25 00:36:32.222293
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector._fact_ids == set()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-25 00:36:34.227432
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:35.967826
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:38.801276
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
  selinux_fact_collector_1 = SelinuxFactCollector()
  selinux_fact_collector_1.collect()
  # TODO: Perhaps check if attributes are set.



# Generated at 2022-06-25 00:36:41.619427
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        selinux_fact_collector_0 = SelinuxFactCollector()
        assert selinux_fact_collector_0
    except NameError:
        assert "Unable to instantiate SelinuxFactCollector"


# Generated at 2022-06-25 00:36:42.974404
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert True


# Generated at 2022-06-25 00:36:44.181040
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()
    var_2 = SelinuxFactCollector()


# Generated at 2022-06-25 00:37:09.107881
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert {'selinux': {'config_mode': 'unknown', 'status': 'Missing selinux Python library', 'mode': 'unknown', 'policyvers': 'unknown', 'type': 'unknown'}, 'selinux_python_present': False} == var_0



# Generated at 2022-06-25 00:37:10.234333
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:37:12.958182
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()
    assert result['selinux']['config_mode'] == 'unknown'

# Generated at 2022-06-25 00:37:15.567148
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 00:37:16.761450
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # There are no assertions for now
    pass


# Generated at 2022-06-25 00:37:25.463896
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    var = selinux_fact_collector.collect()
    assert var == {'selinux': {'config_mode': 'enforcing', 'status': 'enabled', 'mode': 'enforcing', 'type': 'targeted', 'policyvers': '27'}}
    assert var == {'selinux': {'config_mode': 'enforcing', 'status': 'enabled', 'mode': 'enforcing', 'type': 'targeted', 'policyvers': '28'}}
    assert var == {'selinux': {'config_mode': 'enforcing', 'status': 'enabled', 'mode': 'enforcing', 'type': 'targeted', 'policyvers': '29'}}

# Generated at 2022-06-25 00:37:26.519248
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass

# Generated at 2022-06-25 00:37:30.873290
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()



# Generated at 2022-06-25 00:37:33.616992
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.name
    assert var_0 == 'selinux'
    var_1 = selinux_fact_collector_0._fact_ids
    assert var_1 == set()


# Generated at 2022-06-25 00:37:34.683895
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_1, SelinuxFactCollector)

# Generated at 2022-06-25 00:38:17.065991
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:38:20.837776
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    var_0 = SelinuxFactCollector()
    var_1 = var_0.collect()
    assert var_1 == 'Unknown'

# Generated at 2022-06-25 00:38:30.667807
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()

    assert(len(selinux_facts) == 2)
    assert('selinux_python_present' in selinux_facts)
    assert('selinux' in selinux_facts)
    assert(len(selinux_facts['selinux']) == 5)
    assert('status' in selinux_facts['selinux'])
    assert('config_mode' in selinux_facts['selinux'])
    assert('mode' in selinux_facts['selinux'])
    assert('type' in selinux_facts['selinux'])
    assert('policyvers' in selinux_facts['selinux'])

# Generated at 2022-06-25 00:38:32.655802
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()


test_case_0()
test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:38:34.273976
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()



# Generated at 2022-06-25 00:38:37.589831
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_arg = SelinuxFactCollector()
    return selinux_fact_collector_arg



# Generated at 2022-06-25 00:38:46.477331
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import GlobalFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import get_collector_class
    import inspect
    import sys

    # Load collect method of class SelinuxFactCollector
    try:
        collect_method = getattr(SelinuxFactCollector, 'collect')
    except:
        return False

    # Verify that selinux is not none
    selinux = getattr(sys.modules['ansible.module_utils.compat'], 'selinux')
    if selinux is None:
        return False

    # Verify

# Generated at 2022-06-25 00:38:49.252359
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_test_0 = SelinuxFactCollector()
    assert selinux_fact_collector_test_0.name == 'selinux'
    assert selinux_fact_collector_test_0._fact_ids == set()

# Generated at 2022-06-25 00:38:55.894523
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    print(('Start test_SelinuxFactCollector_collect'))
    # Test case for when the selinux Python library is not present
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}
    # Test case for when selinux is not installed and enabled
    # Note that the library is present but selinux is not
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:39:02.800936
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_1.collect()

    assert var_0 == {'selinux_python_present': True, 'selinux': {'status': 'enabled', 'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'}}

if __name__ == "__main__":
    test_case_0()
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:40:48.924070
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == "selinux"



# Generated at 2022-06-25 00:40:52.764458
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:40:58.416206
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()
    assert fact_collector.name == 'selinux'
    assert fact_collector._fact_ids == {'selinux_python_present'}


# Generated at 2022-06-25 00:41:00.980787
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0 != None

# Generated at 2022-06-25 00:41:01.970860
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:41:06.457678
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
#

# Generated at 2022-06-25 00:41:07.755518
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:41:11.990779
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:41:19.144383
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == "selinux"
    assert SelinuxFactCollector._fact_ids == {
    }
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:41:20.450057
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()
    assert var_0.name == 'selinux'
