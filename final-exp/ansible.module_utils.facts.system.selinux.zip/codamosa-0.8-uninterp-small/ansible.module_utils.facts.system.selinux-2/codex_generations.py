

# Generated at 2022-06-25 00:33:58.815915
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:34:05.725745
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    ansible_module = AnsibleModule(argument_spec=dict())

    # Test case when selinux module is not present
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0._module = ansible_module
    selinux_fact_collector_0.collect()
    assert ansible_module.exit_json.called
    assert ansible_module.fail_json.called == False

    # Test case when selinux module is present
    ansible_module = AnsibleModule(argument_spec=dict())
    selinux_fact_collector_1 = SelinuxFactCollector()
    selinux_fact_collector_1._module = ansible_module
    selinux_fact_collector_1.collect()
    assert ansible_module.exit_json.called

# Generated at 2022-06-25 00:34:06.844984
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:09.662253
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        selinux_fact_collector_0 = SelinuxFactCollector()
        selinux_fact_collector_0.collect()
    except Exception as e:
        assert "Missing selinux Python library" in str (e)
    else:
        assert False, "Test case failed"


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 00:34:11.629521
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:34:13.170873
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:34:16.956376
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Constructor for class SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:34:18.125335
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:19.283462
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector() is not None


# Generated at 2022-06-25 00:34:24.097806
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    arg0 = SelinuxFactCollector()
    assert isinstance(arg0, SelinuxFactCollector)


# Generated at 2022-06-25 00:34:38.395063
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()
    assert SelinuxFactCollector.__doc__ == '''Collect facts related to selinux'''


# Generated at 2022-06-25 00:34:39.446010
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:34:40.302463
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:42.863046
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:44.900681
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name=='selinux'

# Generated at 2022-06-25 00:34:48.404730
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # arrange
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

test_case_0()
test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:34:49.372570
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()


# Generated at 2022-06-25 00:34:53.678829
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    r = SelinuxFactCollector()
    f = r.collect()['selinux']

    assert f['status'] == 'disabled'


# Generated at 2022-06-25 00:34:59.589928
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    #SelinuxFactCollector()
    selinux_fact_collector_1 = SelinuxFactCollector()
    #selinux_fact_collector_1.collect()
    collected_facts_1 = {u'selinux_python_present': True,
                         u'selinux': {u'status': u'disabled'}}
    assert selinux_fact_collector_1.collect() == collected_facts_1

# Generated at 2022-06-25 00:35:01.414817
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert not selinux_fact_collector_0 is None


# Generated at 2022-06-25 00:35:12.417516
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()
    assert hasattr(var_1, '_fact_ids')


# Generated at 2022-06-25 00:35:15.413422
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:35:17.532285
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.name == 'selinux'
    assert selinux_fact_collector_1._fact_ids == set()



# Generated at 2022-06-25 00:35:20.155416
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.__name__ == "SelinuxFactCollector"

# Generated at 2022-06-25 00:35:29.221879
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()

    # Variables (abstracted from test_case_0)
    obj_0 = type(object(), (), {})()
    var_0 = None
    obj_1 = type(object(), (), {})()
    var_3 = None
    obj_2 = type(object(), (), {})()
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None


    # Call method collect on class SelinuxFactCollector with arguments (test_case_0)
    func_0 = getattr(selinux_fact_collector_0, "collect", lambda: None)
   

# Generated at 2022-06-25 00:35:33.765979
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert type(selinux_fact_collector._fact_ids) is set
    assert type(selinux_fact_collector.name) is str


# Generated at 2022-06-25 00:35:36.594400
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:46.021496
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    var_1 = selinux_fact_collector_0.collect()
    # Set a boolean for testing whether the Python library is present
    var_2 = selinux_fact_collector_0.collect()
    # If selinux library is missing, only set the status and selinux_python_present since
    # there is no way to tell if SELinux is enabled or disabled on the system
    # without the library.
    var_3 = selinux_fact_collector

# Generated at 2022-06-25 00:35:50.006234
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == set()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:35:50.711321
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    assert True



# Generated at 2022-06-25 00:36:16.347514
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

    assert(compare_set_of_dicts(var_0, {'selinux': {}, 'selinux_python_present': True}))

# Generated at 2022-06-25 00:36:17.359063
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:21.500722
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:36:24.716985
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    result = selinux_fact_collector.collect()
    assert(result.get('selinux_python_present', False))
    assert('selinux' in result)

# Generated at 2022-06-25 00:36:28.454840
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_1, SelinuxFactCollector)

# Generated at 2022-06-25 00:36:30.658618
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:36:38.885140
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux': {'status': 'disabled', 'type': 'unknown', 'mode': 'unknown',
                        'policyvers': 'unknown', 'config_mode': 'unknown'},
                        'selinux_python_present': False}


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:36:40.394253
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)


# Generated at 2022-06-25 00:36:43.677589
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert (SelinuxFactCollector.name == 'selinux')
    assert (SelinuxFactCollector._fact_ids == set())


# Unit test function collect(self, module=None, collected_facts=None) of class SelinuxFactCollector

# Generated at 2022-06-25 00:36:45.812446
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert False == var_1


# Generated at 2022-06-25 00:37:36.844176
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()  # run collect method and store result

    # check if output of collect method is dict
    if not isinstance(var_0, dict):
        raise AssertionError('Returned value is not a dict')

    # check if selinux key exists in dict
    if not 'selinux' in var_0.keys():
        raise AssertionError('\'selinux\' key doesn\'t exist in dict returned by collect method')

    # check if selinux_python_present key exists in dict

# Generated at 2022-06-25 00:37:38.516414
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:37:39.390015
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:37:41.607535
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.__doc__ is not None



# Generated at 2022-06-25 00:37:45.525039
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert 'status' in selinux_fact_collector_1.collect()


# Generated at 2022-06-25 00:37:48.976586
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:37:51.837774
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()


# Generated at 2022-06-25 00:37:57.570763
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()


test_case_0()
test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:37:58.429895
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 00:38:06.761065
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # SELinux is enabled
    test_case_0()

    # SELinux is disabled
    selinux.is_selinux_enabled = lambda: False
    test_case_0()

    # Missing Python library
    selinux.is_selinux_enabled = lambda: True
    selinux.is_selinux_mls_enabled = lambda: True
    selinux.security_getenforce = lambda: 1
    selinux.security_policyvers = lambda: 29
    selinux.selinux_getpolicytype = lambda: (0, "targeted")
    selinux.selinux_getenforcemode = lambda: (0, 1)
    selinux.selinux_policy_root = lambda: "/etc/selinux"

    global HAVE_SELINUX
    HAVE_SELINUX

# Generated at 2022-06-25 00:39:47.660030
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    output_0 = SelinuxFactCollector()
    assert isinstance(output_0, SelinuxFactCollector)


# Generated at 2022-06-25 00:39:51.052148
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import json

    selinux_fact_collector_1 = SelinuxFactCollector()

    print('Testing collect')
    var_1 = selinux_fact_collector_1.collect()
    assert var_1 == json.loads("""{
        "selinux": {
            "config_mode": "unknown",
            "mode": "unknown",
            "status": "enabled",
            "type": "unknown"
        },
        "selinux_python_present": true
    }""")

# Generated at 2022-06-25 00:39:53.508905
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()



# Generated at 2022-06-25 00:39:57.135334
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1 is not None
    assert selinux_fact_collector_1.name == 'selinux'


# Generated at 2022-06-25 00:40:02.209596
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:40:04.138616
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()
    try:
        var_0.collect()
    except Exception as e:
        assert False


# Generated at 2022-06-25 00:40:06.594575
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:40:14.519083
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
   collector = SelinuxFactCollector()
   result = collector.collect()
   assert result['selinux_python_present'] == True
   assert result['selinux']['status'] == 'enabled'
   assert result['selinux']['mode'] == 'enforcing'
   assert result['selinux']['policyvers'] == '28'
   assert result['selinux']['type'] == 'targeted'
   assert result['selinux']['config_mode'] == 'enforcing'


# Generated at 2022-06-25 00:40:17.345606
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_1, SelinuxFactCollector)
    assert 0 == len(selinux_fact_collector_1._fact_ids)


# Generated at 2022-06-25 00:40:19.006719
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Check if variable len is not defined in class SelinuxFactCollector