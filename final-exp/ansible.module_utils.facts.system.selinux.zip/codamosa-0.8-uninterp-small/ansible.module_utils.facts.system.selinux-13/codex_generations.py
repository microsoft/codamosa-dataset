

# Generated at 2022-06-25 00:33:58.204616
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    facts_dict_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:34:05.263922
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    result = selinux_fact_collector_1.collect()
    # Test with the selinux module available
    if HAVE_SELINUX:
        assert 'selinux' in result
        assert result['selinux_python_present']
        assert 'policyvers' in result['selinux']
        assert 'status' in result['selinux']
        assert 'mode' in result['selinux']
        assert 'type' in result['selinux']
        assert 'config_mode' in result['selinux']
    # Test without the selinux module available
    else:
        assert not result['selinux_python_present']
        assert 'selinux' in result
        assert 'status' in result['selinux']

# Generated at 2022-06-25 00:34:11.201893
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.collect() == { "selinux": {"status": "Missing selinux Python library"}, "selinux_python_present": False }



# Generated at 2022-06-25 00:34:12.285918
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector()

# Generated at 2022-06-25 00:34:16.720051
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # test 0
    assert selinux_fact_collector_0.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-25 00:34:17.888358
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'


# Generated at 2022-06-25 00:34:19.037179
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert(SelinuxFactCollector().name == 'selinux')

# Generated at 2022-06-25 00:34:23.564063
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    test_facts_dict = selinux_fact_collector.collect()
    assert test_facts_dict

# Generated at 2022-06-25 00:34:25.686520
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux' == selinux_fact_collector.name


# Generated at 2022-06-25 00:34:29.205602
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:34:41.168293
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:34:44.529284
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)


# Generated at 2022-06-25 00:34:47.333717
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert type(selinux_fact_collector_1) == SelinuxFactCollector


# Generated at 2022-06-25 00:34:48.265955
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:34:53.330887
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    m = {}
    c = {}
    result = selinux_fact_collector.collect(m, c)
    assert result is not None
    assert 'selinux' in result
    assert 'status' in result['selinux']
    assert result['selinux']['status'] is not None
    assert result['selinux_python_present'] is not None

# Generated at 2022-06-25 00:35:02.803085
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''
    Test whether selinux type is reported correctly.
    '''

    # Test when the selinux library is missing.
    facts_dict = SelinuxFactCollector.collect()
    assert 'selinux' in facts_dict
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
    assert facts_dict['selinux']['config_mode'] == 'unknown'
    assert facts_dict['selinux']['policyvers'] == 'unknown'
    assert facts_dict['selinux']['mode'] == 'unknown'
    assert facts_dict['selinux']['type'] == 'unknown'
    assert facts_dict['selinux_python_present'] == False

test_case_0()

# Generated at 2022-06-25 00:35:04.643058
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    return SelinuxFactCollector()


# Generated at 2022-06-25 00:35:06.888624
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)

# Generated at 2022-06-25 00:35:10.360359
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    collector = SelinuxFactCollector()
    assert collector.name == 'selinux'
    assert collector._fact_ids == set()


# Generated at 2022-06-25 00:35:11.495253
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

# Generated at 2022-06-25 00:35:28.405390
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    ansible_facts_dict_0 = {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}
    ansible_facts_dict_1 = {'selinux': {'status': 'enabled', 'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'}, 'selinux_python_present': True}
    assert ansible_facts_dict_0 == selinux_fact_collector_0.collect()
    assert ansible_facts_dict_1 == selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:35:33.228249
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:35:35.539277
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert sorted(selinux_fact_collector.__dict__.keys()) == ['_fact_ids', 'name']
    assert selinux_fact_collector.name == 'selinux'
    assert isinstance(selinux_fact_collector._fact_ids, set)

# Generated at 2022-06-25 00:35:39.668135
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_SelinuxFactCollector_0()
    test_SelinuxFactCollector_1()
    test_SelinuxFactCollector_2()


# Generated at 2022-06-25 00:35:41.593322
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert set() == selinux_fact_collector._fact_ids


# Generated at 2022-06-25 00:35:45.635493
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    module_0 = None
    collected_facts_0 = None
    selinux_fact_collector_0.collect(module_0, collected_facts_0)

# End of testing
###############################################################

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:35:47.035639
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert(isinstance(SelinuxFactCollector(), SelinuxFactCollector))


# Generated at 2022-06-25 00:35:51.595661
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:35:53.303446
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert 'selinux' == selinux_fact_collector.name

# Generated at 2022-06-25 00:35:58.044715
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert 'selinux' == selinux_fact_collector_0.name
    assert isinstance(selinux_fact_collector_0.name, str)
    assert 'set([])' == repr(selinux_fact_collector_0._fact_ids)
    assert isinstance(selinux_fact_collector_0._fact_ids, set)


# Generated at 2022-06-25 00:36:11.452936
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:36:17.261938
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = {}
    selinux_facts = selinux_fact_collector.collect(collected_facts)
    assert 'selinux' in selinux_facts
    selinux = selinux_facts['selinux']
    assert 'status' in selinux
    assert 'type' in selinux
    assert 'mode' in selinux
    assert 'config_mode' in selinux
    assert 'policyvers' in selinux

# Generated at 2022-06-25 00:36:23.396717
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None


# Generated at 2022-06-25 00:36:27.576011
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-25 00:36:32.250951
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts_dict = selinux_fact_collector.collect()
    assert facts_dict['selinux']['status'] == 'disabled'


# Generated at 2022-06-25 00:36:34.903063
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:36:37.010480
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect()


# Generated at 2022-06-25 00:36:38.801385
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.__name__ == 'selinux'


# Generated at 2022-06-25 00:36:41.143944
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_1, SelinuxFactCollector)
    assert id(SelinuxFactCollector._fact_ids) == id(selinux_fact_collector_1.fact_ids)
    assert selinux_fact_collector_1.name == 'selinux'


# Generated at 2022-06-25 00:36:44.237208
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:36:54.690573
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:36:55.740805
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector().name == 'selinux'


# Generated at 2022-06-25 00:36:57.338939
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:37:02.189005
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Set up for test of class
    selinux_fact_collector_1 = SelinuxFactCollector()

    # Test Module class name
    assert hasattr(selinux_fact_collector_1, 'name')
    assert hasattr(selinux_fact_collector_1, '_fact_ids')

    # Test Module class collect
    supports_check_mode_2 = selinux_fact_collector_1.collect()
    assert supports_check_mode_2 == {}

# Generated at 2022-06-25 00:37:09.318725
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector

    obj = SelinuxFactCollector()
    result = obj.collect()

    assert 'status' in result['selinux']
    assert 'selinux_python_present' in result

    if HAVE_SELINUX:
        assert result['selinux_python_present']
    else:
        assert result['selinux_python_present'] is False

# Generated at 2022-06-25 00:37:11.804570
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.__init__()


# Generated at 2022-06-25 00:37:16.949305
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    for item in var_0:
        print(item + ": " + var_0[item])

# Generated at 2022-06-25 00:37:25.797447
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()

    if selinux.is_selinux_enabled():
        selinux.security_setenforce(0)

    var_0 = selinux_fact_collector_0.collect()
    selinux_facts_0 = var_0['selinux']

    # Update variable selinux_facts_0

    # Update variable selinux_facts_0

    assert selinux_facts_0['status'] == 'disabled'
    assert selinux_facts_0['config_mode'] == 'unknown'
    assert selinux_facts_0['mode'] == 'unknown'
    assert selinux_facts_0['policyvers'] == 'unknown'
    assert selinux_facts_0['type'] == 'unknown'


# Generated at 2022-06-25 00:37:30.346432
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_0.collect()
    assert var_1 == {'selinux': {'config_mode': 'enforcing', 'mode': 'enforcing', 'type': 'targeted', 'status': 'enabled'}, 'selinux_python_present': True}


# Generated at 2022-06-25 00:37:34.647667
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0.get('selinux_python_present') == False
    assert var_0.get('selinux').get('status') == 'Missing selinux Python library'


# Generated at 2022-06-25 00:38:03.015309
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector_collect_return = selinux_fact_collector.collect()
    assert selinux_fact_collector_collect_return is not None

# Generated at 2022-06-25 00:38:06.141342
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:38:12.901013
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # AssertionError: {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False} != {'selinux': {'mode': 'unknown', 'policyvers': 'unknown', 'status': 'disabled', 'type': 'unknown', 'config_mode': 'unknown'}, 'selinux_python_present': True}
    # var_0 = selinux_fact_collector_0.collect()



# Generated at 2022-06-25 00:38:14.797374
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    try:
        selinux_fact_collector = SelinuxFactCollector()
        selinux_fact_collector.collect()
    except Exception as e:
        print(e)
        raise AssertionError("Should not throw exception")

# Generated at 2022-06-25 00:38:21.858782
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    if HAVE_SELINUX:
        selinux_fact_collector_1 = SelinuxFactCollector()
        var_1 = selinux_fact_collector_1.collect()
        assert (var_1['selinux']['status'] == 'enabled' or
                var_1['selinux']['status'] == 'disabled')
        assert (var_1['selinux']['mode'] == 'permissive' or
                var_1['selinux']['mode'] == 'enforcing' or
                var_1['selinux']['mode'] == 'disabled')
        assert var_1['selinux']['type'] == 'targeted'
    else:
        selinux_fact_collector_1 = SelinuxFactCollector()
        var_1 = selinux_fact_

# Generated at 2022-06-25 00:38:23.013477
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_SelinuxFactCollector = SelinuxFactCollector()
    assert True

# Generated at 2022-06-25 00:38:25.480719
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:38:27.722676
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:38:30.791672
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

test_case_0()
test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:38:32.673835
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:39:20.303568
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    var_0 = SelinuxFactCollector()
    var_0.collect()

# Generated at 2022-06-25 00:39:24.907270
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    # assert var_0 == [], "Argument does not match expected value"



# Generated at 2022-06-25 00:39:29.338507
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:39:31.635998
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    # Check if we can verify that the class instantiated correctly
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)


# Generated at 2022-06-25 00:39:36.465027
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}


# Generated at 2022-06-25 00:39:37.991392
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    var_1 = SelinuxFactCollector()


# Generated at 2022-06-25 00:39:42.488596
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        selinux_fact_collector_1 = SelinuxFactCollector()
    except NameError as e:
        print('Exception returned: ', e)
        assert False
    assert True

# Unit test to check the collect() of class SelinuxFactCollector

# Generated at 2022-06-25 00:39:44.108354
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.name == 'selinux'


# Generated at 2022-06-25 00:39:48.752877
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.name == 'ansible.selinux'
    assert isinstance(selinux_fact_collector_1.collect(), dict)
    assert selinux_fact_collector_1._fact_ids == {'selinux'}

# Generated at 2022-06-25 00:39:51.972796
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert (var_1 is not None)

# Generated at 2022-06-25 00:41:34.545329
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Basic test without selinux Python library
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0['selinux']['status'] == 'Missing selinux Python library'
    assert var_0['selinux_python_present'] == False

# Generated at 2022-06-25 00:41:39.537166
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_0 = SelinuxFactCollector()
    assert isinstance(var_0, SelinuxFactCollector)


# Generated at 2022-06-25 00:41:42.203231
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-25 00:41:47.003520
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == "selinux"
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:41:48.251187
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'

# Generated at 2022-06-25 00:41:54.378111
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert(selinux_fact_collector_1._fact_ids == {'selinux'})


# Generated at 2022-06-25 00:41:58.060252
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:42:03.063011
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    selinux_fact = selinux_facts['selinux']
    assert selinux_fact['status'] == 'Disabled'
    
test_case_0()
test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:42:04.607991
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:42:09.581811
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_2 = SelinuxFactCollector()
    var_2 = selinux_fact_collector_2.collect()
    assert var_2 == {'selinux': {'policyvers': 'unknown', 'config_mode': 'disabled', 'status': 'disabled', 'mode': 'disabled', 'type': 'unknown'}, 'selinux_python_present': True}
