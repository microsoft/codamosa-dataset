

# Generated at 2022-06-25 00:33:58.737091
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_facts_dict_0 = selinux_fact_collector_0.collect()

    assert selinux_facts_dict_0['selinux_python_present'] == True

# Generated at 2022-06-25 00:34:03.042570
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:34:08.402060
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # This is not really a unit test, but test that the module
    # can be used stand-alone.
    test_case_0()


if __name__ == '__main__':
    test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:34:12.244480
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:34:14.339980
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:34:18.305524
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:34:21.087232
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.name == 'selinux'
    assert selinux_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:34:23.673652
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 00:34:25.816013
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    result_dict_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:34:31.477847
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:34:44.994545
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)


# Generated at 2022-06-25 00:34:47.422643
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:34:55.369416
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector._module = 'test'
    selinux_fact_collector._collect_selinux_facts()
    selinux_facts = selinux_fact_collector.collect()
    assert 'selinux' in selinux_facts
    assert 'status' in selinux_facts['selinux']
    assert 'policyvers' in selinux_facts['selinux']
    assert 'config_mode' in selinux_facts['selinux']
    assert 'mode' in selinux_facts['selinux']
    assert 'type' in selinux_facts['selinux']
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-25 00:35:01.005107
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    ansible_module = AnsibleModule(argument_spec={})
    ansible_module.exit_json(ansible_facts=selinux_fact_collector_0.collect(ansible_module=ansible_module))

if '__main__' == __name__:
    if HAVE_SELINUX:
        selinux.closelog()
    test_case_0()

# Generated at 2022-06-25 00:35:05.285480
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_

# Generated at 2022-06-25 00:35:08.684666
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_collect = SelinuxFactCollector()
    collected_facts = {}
    selinux_fact_collector_collect.collect(collected_facts=collected_facts)
    assert 'selinux' in collected_facts
    assert 'selinux_python_present' in collected_facts

# Generated at 2022-06-25 00:35:14.140370
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Construct a module that has the same behavior as a typical Ansible module
    class testModule(object):
        failed = False
        exit_json = None
        invoke_fail_json = None

    test_module = testModule()
    test_module.check_mode = False
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector_0.collect(module=test_module)

    assert selinux_facts['selinux_python_present'] is True
    assert selinux_facts['selinux'] is not None

# Generated at 2022-06-25 00:35:19.233525
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.__class__.__name__ == "SelinuxFactCollector"


# Generated at 2022-06-25 00:35:21.827055
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:29.804358
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    return_data_0 = {'selinux': {}, 'selinux_python_present': True}
    return_data_1 = {'selinux': {'status': 'enabled', 'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'permissive', 'type': 'unknown'}, 'selinux_python_present': True}
    return_data_2 = {'selinux': {'status': 'enabled', 'policyvers': 'unknown', 'config_mode': 'unknown', 'mode': 'unknown', 'type': 'unknown'}, 'selinux_python_present': False}

# Generated at 2022-06-25 00:35:41.226127
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:35:42.773653
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:44.928412
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
  selinux_fact_collector_0 = SelinuxFactCollector()
  var_0 = selinux_fact_collector_0.collect()
  assert var_0 != None

# Generated at 2022-06-25 00:35:47.227440
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert(isinstance(selinux_fact_collector_0, SelinuxFactCollector))


# Generated at 2022-06-25 00:35:48.772732
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()

# Generated at 2022-06-25 00:35:54.259550
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test with basic input
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert isinstance(var_0, dict)
    assert 'selinux' in var_0
    assert 'policyvers' in var_0['selinux']
    assert 'config_mode' in var_0['selinux']
    assert 'type' in var_0['selinux']
    assert 'status' in var_0['selinux']
    assert 'mode' in var_0['selinux']

# Generated at 2022-06-25 00:35:55.066993
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    pass


# Generated at 2022-06-25 00:35:57.417949
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert var_1 is not None


# Generated at 2022-06-25 00:36:01.076475
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert str(type(var_0)) == "<type 'dict'>"
    assert var_0['selinux_python_present'] == False
    assert var_0['selinux']['status'] == 'Missing selinux Python library'



# Generated at 2022-06-25 00:36:02.483677
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    sut = SelinuxFactCollector()
    result = sut.collect()
    assert result['selinux_python_present']

# Generated at 2022-06-25 00:36:25.984957
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert set(selinux_fact_collector_0._fact_ids) == set(), 'Test 0 - Failed'


# Generated at 2022-06-25 00:36:28.925824
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0['selinux']['status'].startswith('Missing')
    var_0_selinux_python_present = var_0['selinux_python_present']
    assert var_0['selinux_python_present'] == False


# Generated at 2022-06-25 00:36:33.771834
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:36:36.011920
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
  selinux_fact_collector = SelinuxFactCollector()
  assert selinux_fact_collector is not None


# Generated at 2022-06-25 00:36:38.163553
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    # AssertionError
    assert False


# Generated at 2022-06-25 00:36:41.658580
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert type(var_1) is dict
    assert var_1['selinux']['type'] == 'targeted'


# Generated at 2022-06-25 00:36:43.900504
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:36:45.142689
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    instance = SelinuxFactCollector()
    assert isinstance(instance, SelinuxFactCollector)


# Generated at 2022-06-25 00:36:48.646800
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_classes

    for p in [SelinuxFactCollector]:
        assert isinstance(p, BaseFactCollector)
        assert issubclass(p, BaseFactCollector)

# Generated at 2022-06-25 00:36:52.279715
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0.name, str)
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:37:41.491432
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == set()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:37:46.920482
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert var_0 == {'selinux_python_present': True, 'selinux': {'config_mode': 'unknown', 'status': 'Missing selinux Python library', 'mode': 'unknown', 'type': 'unknown', 'policyvers': 'unknown'}}

# Generated at 2022-06-25 00:37:50.742365
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:37:52.054323
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None


# Generated at 2022-06-25 00:38:01.928951
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Test for constructor of class SelinuxFactCollector
    assert SelinuxFactCollector.__doc__, 'Docstring is not set'
    assert SelinuxFactCollector.__init__.__doc__, 'Docstring is not set'
    assert SelinuxFactCollector.__name__, 'Name is not set'
    assert SelinuxFactCollector.collect.__doc__, 'Docstring is not set'
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == set(), 'Instance variable "_fact_ids" is not set to "set()"'
    assert selinux_fact_collector_0._platform == 'Generic', 'Instance variable "_platform" is not set to "Generic"'
    assert selinux_fact_collector_0

# Generated at 2022-06-25 00:38:07.461900
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()
    assert 'selinux' in var_0
    assert var_0['selinux']['mode'] == 'unknown'


# Generated at 2022-06-25 00:38:12.836484
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        selinux_fact_collector_1 = SelinuxFactCollector()
    except NameError:
        # Should not raise NameError exception if selinux is not present
        pass


# Generated at 2022-06-25 00:38:15.497979
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_1 = SelinuxFactCollector()
    var_1 = selinux_fact_collector_1.collect()
    assert var_1 == {"selinux_python_present": True, "selinux": {'type': 'unknown', 'status': 'enabled', 'config_mode': 'unknown', 'mode': 'unknown', 'policyvers': 'unknown'}}

# Generated at 2022-06-25 00:38:17.944300
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    # Test if the instance of SelinuxFactCollector is created
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)


# Generated at 2022-06-25 00:38:21.211753
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var_1 = SelinuxFactCollector()
    assert var_1.name == 'selinux'
    assert var_1._fact_ids == set()


# Generated at 2022-06-25 00:40:10.511925
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:40:13.993251
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    if HAVE_SELINUX:
        selinux_fact_collector_1 = SelinuxFactCollector()
    else:
        selinux_fact_collector_1 = SelinuxFactCollector()
    test_case_0()

#  Unit test for collect method of class SelinuxFactCollector

# Generated at 2022-06-25 00:40:15.559007
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()

# Generated at 2022-06-25 00:40:17.008066
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    var = SelinuxFactCollector()
    assert isinstance(SelinuxFactCollector(), SelinuxFactCollector)


# Generated at 2022-06-25 00:40:19.103522
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:40:21.528385
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Call the constructor of class SelinuxFactCollector
    var_1 = SelinuxFactCollector()
    # Assert expected results
    assert hasattr(var_1, 'name') == True
    assert hasattr(var_1, '_fact_ids') == True


# Generated at 2022-06-25 00:40:25.271065
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    var_0 = selinux_fact_collector_0.collect()


# Generated at 2022-06-25 00:40:29.413939
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'


# Generated at 2022-06-25 00:40:36.251267
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    import types
    test_case_0()
    var_1 = isinstance(SelinuxFactCollector.name, str)
    assert var_1
    var_2 = isinstance(SelinuxFactCollector._fact_ids, set)
    assert var_2
    var_3 = isinstance(SelinuxFactCollector.collect, types.FunctionType)
    assert var_3

# Generated at 2022-06-25 00:40:37.771236
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)