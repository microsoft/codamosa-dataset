

# Generated at 2022-06-25 00:33:58.127357
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:34:00.870785
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    from ansible.module_utils.facts.collector import SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()
    assert(len(selinux_fact_collector._fact_ids) == 1)


# Generated at 2022-06-25 00:34:02.807160
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert SelinuxFactCollector() == selinux_fact_collector_0
                

# Generated at 2022-06-25 00:34:04.356554
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'


# Generated at 2022-06-25 00:34:11.136197
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # function for testing constructor SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector._fact_ids == set()
    assert selinux_fact_collector.name == 'selinux'



# Generated at 2022-06-25 00:34:15.591358
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    tmp = selinux_fact_collector_0.collect()

    assert 'selinux_python_prese' in tmp
    assert 'selinux' in tmp

# Generated at 2022-06-25 00:34:18.358341
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.name == 'selinux'
    assert selinux_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:34:19.531399
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

# Generated at 2022-06-25 00:34:24.345068
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:34:25.403197
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    try:
        test_case_0()
    except:
        assert False



# Generated at 2022-06-25 00:34:36.503431
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_selinux_facts = SelinuxFactCollector.collect()
    assert 'selinux' in test_selinux_facts

# Generated at 2022-06-25 00:34:40.586588
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert callable(SelinuxFactCollector)


# Generated at 2022-06-25 00:34:42.984964
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()

    assert_equals(selinux_fact_collector_0.name , 'selinux' )

    assert_equals(selinux_fact_collector_0._fact_ids , set() )

# Function test for function collect()

# Generated at 2022-06-25 00:34:46.101696
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert (selinux_fact_collector_0.name == 'selinux')

# Generated at 2022-06-25 00:34:52.408912
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    result = selinux_fact_collector_0.collect()
    expected = {
        'selinux': {
            'config_mode': 'unknown',
            'status': 'disabled',
            'mode': 'unknown',
            'policyvers': 'unknown',
            'type': 'unknown'
        },
        'selinux_python_present': False
    }
    assert result == expected


# Generated at 2022-06-25 00:34:56.347578
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert type(SelinuxFactCollector()).__name__ == 'SelinuxFactCollector'


# Generated at 2022-06-25 00:34:59.489463
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()


# Generated at 2022-06-25 00:35:02.859863
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    facts_dict = selinux_fact_collector_0.collect()
    assert facts_dict == {'selinux_python_present': True, 'selinux': {'status': 'disabled'}}

# Generated at 2022-06-25 00:35:05.936992
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector_0, SelinuxFactCollector)


# Generated at 2022-06-25 00:35:12.941640
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test default value of collected facts
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0_collected_facts = selinux_fact_collector_0.collect()
    assert 'selinux' in selinux_fact_collector_0_collected_facts
    assert 'selinux_python_present' in selinux_fact_collector_0_collected_facts

# Generated at 2022-06-25 00:35:32.159107
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None


# Generated at 2022-06-25 00:35:36.299616
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Constructor test with parameters
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0 is not None

    # Constructor test without parameters
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1 is not None


# Generated at 2022-06-25 00:35:42.855238
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Unit test for constructor
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)

    # Unit test for name
    assert selinux_fact_collector.name == 'selinux'

    # Unit test for _fact_ids
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:35:44.968988
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:35:48.380819
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    # Instance object should be constructed for SelinuxFactCollector
    if not isinstance(selinux_fact_collector, SelinuxFactCollector):
        raise AssertionError("SelinuxFactCollector object is not constructed")


# Generated at 2022-06-25 00:35:51.416747
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    assert selinux_fact_collector_0.collect() == dict(selinux=dict(status='Missing selinux Python library'),
                                                      selinux_python_present=False) == selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:35:55.258162
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Test for constructor of class SelinuxFactCollector

    """
    if HAVE_SELINUX:
        obj = SelinuxFactCollector()
        assert obj.name == 'selinux'
        assert obj.collected_facts == {}
    else:
        obj = SelinuxFactCollector()
        assert obj.name == 'selinux'


# Generated at 2022-06-25 00:35:56.977052
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None


# Generated at 2022-06-25 00:35:58.878273
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'


# Generated at 2022-06-25 00:36:02.542857
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_fact_collector.collect()
    assert selinux_fact_collector._fact_ids == set(['selinux', 'selinux_python_present'])

# Generated at 2022-06-25 00:36:47.258225
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    if not HAVE_SELINUX:
        assert True
        return

    selinux_fact_collector_0 = SelinuxFactCollector()

    # Test set/get name
    selinux_fact_collector_0.name = 'name'
    assert selinux_fact_collector_0.name == 'name'
    selinux_fact_collector_0.name = 'selinux'
    assert selinux_fact_collector_0.name == 'selinux'

    # Test set/_fact_ids
    try:
        selinux_fact_collector_0._fact_ids = 'fact_ids'
    except AttributeError:
        assert True
    else:
        assert False

    # Test set/get _fact_ids
    selinux_fact_collector_0._fact_ids = set

# Generated at 2022-06-25 00:36:54.234761
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()

    collect_results = selinux_fact_collector.collect()
    assert isinstance(collect_results, type({}))
    assert 'selinux' in collect_results

    selinux_facts = collect_results['selinux']
    assert isinstance(selinux_facts, type({}))

    assert isinstance(selinux_facts['status'], type(u''))
    assert selinux_facts['status'] == 'enabled' or selinux_facts['status'] == 'disabled' or selinux_facts['status'] == 'Missing selinux Python library'

    assert isinstance(selinux_facts['config_mode'], type(u''))

# Generated at 2022-06-25 00:36:55.261537
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    class_instance = SelinuxFactCollector()
    class_instance.collect()

# Generated at 2022-06-25 00:36:57.134949
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_test = SelinuxFactCollector()
    selinux_fact_collector_test.collect()

# Generated at 2022-06-25 00:36:58.692370
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)



# Generated at 2022-06-25 00:37:00.664068
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:37:03.885777
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Initialize a dummy module object
    module = type('module', (object,), {})()

    selinux_fact_collector_0 = SelinuxFactCollector()
    result = selinux_fact_collector_0.collect(module=module, collected_facts={})
    assert result['selinux_python_present'] is False
    assert 'status' in result['selinux'].keys()

# Generated at 2022-06-25 00:37:04.588021
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:37:06.088375
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:37:09.371795
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert(selinux_fact_collector.name == 'selinux')
    assert(selinux_fact_collector._fact_ids == set())


# Generated at 2022-06-25 00:38:37.726540
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    with mock.patch.object(SelinuxFactCollector, 'collect'):
        selinux_fact_collector = SelinuxFactCollector()
        selinux_fact_collected_facts = selinux_fact_collector.collect()
        if not selinux_fact_collected_facts.get('selinux_python_present'):
            assert True
        else:
            assert selinux_fact_collected_facts.get('selinux')
            assert 'status' in selinux_fact_collected_facts['selinux']
            if selinux_fact_collected_facts['selinux']['status'] == 'disabled':
                assert 'mode' not in selinux_fact_collected_facts['selinux']

# Generated at 2022-06-25 00:38:39.066904
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

# Generated at 2022-06-25 00:38:44.176988
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collected_facts = dict()
    selinux_fact_collector = SelinuxFactCollector()
    returned_facts_dict = selinux_fact_collector.collect(collected_facts=collected_facts)
    assert isinstance(returned_facts_dict, dict)
    assert returned_facts_dict == {'selinux': {}, 'selinux_python_present': False}

# Generated at 2022-06-25 00:38:50.032259
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)
    assert selinux_fact_collector.name == "selinux"


# Generated at 2022-06-25 00:38:51.470568
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
   # Test case 0
   selinux_fact_collector_0 = SelinuxFactCollector()
   selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:38:54.826771
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    """
        Unit test for method collect of class SelinuxFactCollector
    """

    # Test with bare minimum set of options
    selinux_fact_collector_0 = SelinuxFactCollector()

    # Test with all possible set of options
    selinux_fact_collector_1 = SelinuxFactCollector(module=object())


# Generated at 2022-06-25 00:38:59.883294
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_test = SelinuxFactCollector()
    assert selinux_fact_collector_test != None

# Generated at 2022-06-25 00:39:01.319185
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:39:02.244666
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()



# Generated at 2022-06-25 00:39:04.801843
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()


# Generated at 2022-06-25 00:42:44.218106
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert len(selinux_fact_collector._fact_ids) == 0


# Generated at 2022-06-25 00:42:48.584982
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_1 = SelinuxFactCollector()
    assert selinux_fact_collector_1.name == 'selinux'
    assert selinux_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:42:53.087467
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Run the constructor of class SelinuxFactCollector"""
    test_case_0()

# Generated at 2022-06-25 00:42:56.164432
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    #Test a case where the selinux module is missing
    try:
        selinux_fact_collector_0 = SelinuxFactCollector()
        selinux_facts = selinux_fact_collector_0.collect(collected_facts={})
        assert selinux_facts.get('selinux_python_present') is False
        assert selinux_facts.get('selinux').get('status') == 'Missing selinux Python library'
    except ImportError:
        pass


# Generated at 2022-06-25 00:43:00.504277
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    test_fact_collector_0 = SelinuxFactCollector()
    result = test_fact_collector_0.collect()
    assert result['selinux_python_present'] == False
    assert result['selinux']['status'] == 'Missing selinux Python library'

if __name__ == '__main__':
    test_case_0()
    #test_SelinuxFactCollector_collect()

# Generated at 2022-06-25 00:43:02.823659
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass


# Generated at 2022-06-25 00:43:04.303143
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    # Assert SelinuxFactCollector object is created successfully
    assert selinux_fact_collector is not None


# Generated at 2022-06-25 00:43:05.036860
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'

# Generated at 2022-06-25 00:43:06.054176
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector_0 = SelinuxFactCollector()
    selinux_fact_collector_0.collect()

# Generated at 2022-06-25 00:43:07.530749
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_case_0()