

# Generated at 2022-06-20 19:53:36.561832
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import tempfile
    import shutil
    import json
    import os
    import pwd
    import grp
    import stat
    import selinux

    test_path = tempfile.mkdtemp()

    # Create sample files
    file1 = os.path.join(test_path, 'file1')
    file2 = os.path.join(test_path, 'file2')
    with open(file1, 'w') as f:
        f.write('foo')
    selinux.chcon(file1, 'user_u:object_r:etc_t:s0')
    shutil.copyfile(file1, file2)

    # Create sample SELinux facts
    selinux_facts = {}
    selinux_facts['path_mode_permissive'] = []

# Generated at 2022-06-20 19:53:44.566132
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Set up values to use
    module_name = 'test_module'
    set_module_name(module_name)
    # Create an instance of SelinuxFactCollector
    selinux_fact_collector = SelinuxFactCollector()
    # Use an assertion to check that the name is returned correctly
    assert selinux_fact_collector.name == 'selinux'
    # Use an assertion to check that the fact_ids does not return None
    assert selinux_fact_collector._fact_ids is not None


# Generated at 2022-06-20 19:53:46.991051
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-20 19:53:50.422785
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.collect()['selinux_python_present'] == True

# Generated at 2022-06-20 19:53:53.237059
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:53:57.457691
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:54:00.115720
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:54:02.572071
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    result = SelinuxFactCollector()
    assert result.name == 'selinux'
    assert result._fact_ids == set()


# Generated at 2022-06-20 19:54:05.416891
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    assert collector.collect() == {'selinux': {'status': 'Missing selinux Python library'}, 'selinux_python_present': False}

# Generated at 2022-06-20 19:54:17.535859
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Set up a mock module object with selinux library available
    module = mock.Mock()
    module.HAVE_SELINUX = True
    # Set up a mock selinux module with selinux library functions
    selinux_mock = mock.Mock()
    selinux_mock.HAVE_SELINUX = True
    # Set up a SelinuxFactCollector object instance
    fact_collector = SelinuxFactCollector()

    # Set up mock selinux library functions
    selinux_mock.is_selinux_enabled.return_value = True
    selinux_mock.selinux_getenforcemode.return_value = (0, 1)
    selinux_mock.selinux_getpolicytype.return_value = (0, 'targeted')
    selinux_mock

# Generated at 2022-06-20 19:54:29.366871
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector._fact_ids == set()

# Generated at 2022-06-20 19:54:41.443487
# Unit test for constructor of class SelinuxFactCollector

# Generated at 2022-06-20 19:54:46.399732
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    result = collector.collect()

    assert 'selinux' in result
    assert isinstance(result['selinux'], dict)

    assert result['selinux']['status'] == 'enabled'
    assert result['selinux']['policyvers'] == '31'
    assert result['selinux']['config_mode'] == 'disabled'
    assert result['selinux']['mode'] == 'disabled'
    assert result['selinux']['type'] == 'targeted'

# Generated at 2022-06-20 19:54:48.141161
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector.name == 'selinux'
    assert selinux_collector.collect()

# Generated at 2022-06-20 19:54:52.510027
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    os = SelinuxFactCollector()
    os_facts = os.collect()
    assert isinstance(os_facts['selinux'], dict), \
        'Expected selinux fact to be a dictionary'

# Generated at 2022-06-20 19:55:02.060932
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class DummyModule(object):
        def __init__(self):
            self.params = {}

    class DummySelinux(object):
        @staticmethod
        def is_selinux_enabled():
            return False

    class DummySelinux2(object):
        @staticmethod
        def is_selinux_enabled():
            return True

        @staticmethod
        def security_policyvers():
            return '24'

        @staticmethod
        def selinux_getenforcemode():
            return (0, 0)

        @staticmethod
        def security_getenforce():
            return 0

        @staticmethod
        def selinux_getpolicytype():
            return (0, 'targeted')


# Generated at 2022-06-20 19:55:06.376415
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Arrange
    test_collector = SelinuxFactCollector()

    # Act
    actual = test_collector.collect()

    # Assert
    actual_keys = actual.keys()
    actual_keys.sort()
    expected_keys = ['selinux', 'selinux_python_present']
    expected_keys.sort()

    assert actual_keys == expected_keys

# Generated at 2022-06-20 19:55:08.880895
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    facts_collected = SelinuxFactCollector()
    assert isinstance(facts_collected.name, str)
    assert isinstance(facts_collected._fact_ids, set)


# Generated at 2022-06-20 19:55:15.828935
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_registry

    if HAVE_SELINUX:
        from ansible.module_utils.compat import selinux
        selinux_mock = selinux
    else:
        import mock
        selinux_mock = mock.MagicMock()

    selinux_mock.is_selinux_enabled.return_value = True
    selinux_mock.security_policyvers.return_value = 100
    selinux_mock.selinux_getenforcemode.return_value = (0, 1)
    selinux_mock.security_getenforce.return_value = 1
    selinux_mock.selinux_getpolicytype.return_value = (0, 'targeted')


# Generated at 2022-06-20 19:55:16.852493
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()


# Generated at 2022-06-20 19:55:29.754462
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    result = collector.collect()
    assert isinstance(result, dict)
    assert 'selinux' in result
    assert result['selinux']['status'] == "disabled"

# Generated at 2022-06-20 19:55:34.121339
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModuleMock()
    collected_facts = {}
    collector = SelinuxFactCollector(module)
    facts = collector.collect(module, collected_facts)

    assert facts['selinux']['status'] == "enabled"
    assert facts['selinux_python_present'] is True
    assert facts['selinux']['policyvers'] == "26"
    assert facts['selinux']['config_mode'] == "enforcing"
    assert facts['selinux']['mode'] == "enforcing"
    assert facts['selinux']['type'] == "targeted"


# Generated at 2022-06-20 19:55:41.538755
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Init class SelinuxFactCollector
    selinuxfactcollector = SelinuxFactCollector()
    # Execute collect, store result in result
    result = selinuxfactcollector.collect()
    # Compare result and expected
    #assert result == expected
    assert 'selinux' in result
    for k in ('status', 'mode', 'type', 'policyvers', 'config_mode'):
        assert k in result['selinux']

# Generated at 2022-06-20 19:55:47.079754
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Set selinux library to None so it skips the library calls
    selinux.sys = None

    result_dict = {'selinux': {'status': 'Missing selinux Python library'},
                   'selinux_python_present': False}

    obj = SelinuxFactCollector()
    fact_dict = obj.collect()
    assert fact_dict == result_dict

# Generated at 2022-06-20 19:55:51.770436
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import TestCollector
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    test_collector = TestCollector(SelinuxFactCollector())
    collected_facts = test_collector.collect()

    my_module = basic.AnsibleModule(argument_spec={})
    my_module.exit_json(ansible_facts=collected_facts)

# Generated at 2022-06-20 19:55:56.411275
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact = SelinuxFactCollector()
    assert selinux_fact is not None
    assert selinux_fact.name is not None
    assert selinux_fact.name == 'selinux'
    assert selinux_fact.collect() is not None

# Generated at 2022-06-20 19:55:58.314761
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-20 19:56:07.078184
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Test 1: ImportError
    global HAVE_SELINUX
    old_value = HAVE_SELINUX
    HAVE_SELINUX = False
    selinux_return = {'selinux': {'config_mode': 'unknown', 'type': 'unknown', 'mode': 'unknown', 'policyvers': 'unknown', 'status': 'Missing selinux Python library'}, 'selinux_python_present': False}
    assert SelinuxFactCollector().collect() == selinux_return
    HAVE_SELINUX = old_value

    # Test 2: selinux not enabled
    with patch.object(selinux, 'is_selinux_enabled', autospec=True) as mock_is_selinux_enabled:
        mock_is_selinux_enabled.return_value = False
        selinux_return

# Generated at 2022-06-20 19:56:07.599620
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    pass

# Generated at 2022-06-20 19:56:12.022848
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Unit test for constructor of class SelinuxFactCollector"""
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'
    assert selinux._fact_ids == set()

# Generated at 2022-06-20 19:56:36.151261
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """ This will test the constructor of the class SelinuxFactCollector """
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-20 19:56:41.731875
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector
    facts = collector.collect()

    assert ('selinux' in facts), "result must have key selinux"
    assert ('status' in facts['selinux']), \
           "selinux key must have key status"
    assert ('selinux_python_present' in facts),\
           "result must have key selinux_python_present"

    if HAVE_SELINUX:
        assert (facts['selinux_python_present'] == True),\
               "expected True, got False"
    else:
        assert (facts['selinux_python_present'] == False),\
               "expected False, got True"

# Generated at 2022-06-20 19:56:42.611392
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()


# Generated at 2022-06-20 19:56:45.371613
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:56:50.022097
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    # There is no reliable way to test since selinux library is Linux-specific
    # instead, check for a known fact
    facts_dict = selinux_fact_collector.collect()
    assert 'selinux_python_present' in facts_dict


# Generated at 2022-06-20 19:56:53.670165
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    Tests the constructor of the Selinux Fact Collector Class
    """
    selinux_fact_collector = SelinuxFactCollector()
    assert isinstance(selinux_fact_collector, SelinuxFactCollector)
    assert hasattr(selinux_fact_collector, 'collect')
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:57:03.588513
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collectors.selinux import SelinuxFactCollector
    from ansible.module_utils.compat.selinux import is_selinux_enabled
    from ansible.module_utils.compat.selinux import getenforce

    # Test whether selinux library is present
    # initialize the facts with collector
    facts = Facts(collectors=[SelinuxFactCollector])

    # collect the facts
    facts.populate()

    # only selinux_python_present is True
    assert facts.pop('selinux_python_present') == True
    assert facts.pop('selinux') == {}


    # Test if SELinux is enabled or not

# Generated at 2022-06-20 19:57:06.397865
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import sys
    import os
    b_module = None
    SelinuxFactCollector.collect(b_module)

# Generated at 2022-06-20 19:57:07.478773
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector != None

# Generated at 2022-06-20 19:57:16.832486
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    ''' Test case for collect function of class SelinuxFactCollector
    '''
    collector = SelinuxFactCollector()

    # Test when selinux Python library is not present
    facts_dict = collector.collect(module=None, collected_facts=None)
    assert 'selinux' in facts_dict
    assert 'status' in facts_dict['selinux']
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
    assert 'selinux_python_present' in facts_dict
    assert facts_dict['selinux_python_present'] is False

    # Import selinux
    try:
        global selinux
        import selinux
    except ImportError:
        print('Module selinux is not installed')
        return

# Generated at 2022-06-20 19:57:59.270060
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-20 19:58:07.231028
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    class MockModule:
        def __init__(self):
            self.params = []

    class MockSelObject:
        def is_selinux_enabled(self):
            return True

        def security_policyvers(self):
            return 'selinux_1.2.3'

        def selinux_getenforcemode(self):
            return (0, 1)

        def security_getenforce(self):
            return 1

        def selinux_getpolicytype(self):
            return (0, 'targeted')

    mock_module = MockModule()
    mock_selinux = MockSelObject()
    mock_selinux.__name__ = 'selinux'
    mock_module.selinux = mock_selinux

    selinux_fact_collector = SelinuxFactCollector()
   

# Generated at 2022-06-20 19:58:12.517026
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    # Set selinux library to None so that it triggers import error and results in
    # Selinux fact collector to set 'selinux_python_present' to False
    selinux_module = None
    selinux_fact_collector = SelinuxFactCollector(module=selinux_module)
    facts_dict = selinux_fact_collector.collect()
    assert facts_dict['selinux_python_present'] is False

# Generated at 2022-06-20 19:58:14.535474
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts_collector = SelinuxFactCollector()
    assert selinux_facts_collector.collect()['selinux_python_present'] == True

# Generated at 2022-06-20 19:58:20.725409
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()

    assert fact_collector.name == 'selinux', \
        'name incorrect: {0}'.format(fact_collector.name)

    assert fact_collector._fact_ids == set(), \
        '_fact_ids incorrect: {0}'.format(fact_collector._fact_ids)

# Generated at 2022-06-20 19:58:29.696705
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    # Create fake module and collected_facts
    module = type('', (), {'params': {}})()
    collected_facts = {}

    # Create instance of SelinuxFactCollector and call method to test
    x = SelinuxFactCollector(module=module)
    facts = x.collect(module=module, collected_facts=collected_facts)
    assert 'selinux' in facts
    assert 'selinux_python_present' in facts
    assert 'status' in facts['selinux']
    return

# Generated at 2022-06-20 19:58:32.593149
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_object = SelinuxFactCollector()
    assert selinux_fact_collector_object.name == 'selinux'
    assert selinux_fact_collector_object._fact_ids == set()

# Generated at 2022-06-20 19:58:37.853204
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect(module=None, collected_facts=None)
    assert facts is not None
    assert type(facts) is dict
    assert "selinux" in facts
    assert type(facts['selinux']) is dict
    assert facts['selinux']['status'] is not None
    assert facts['selinux']['config_mode'] is not None
    assert facts['selinux']['mode'] is not None
    assert facts['selinux']['type'] is not None
    assert facts['selinux_python_present'] is True

# Generated at 2022-06-20 19:58:48.535017
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    import ansible.module_utils.facts.collectors.selinux as selinux
    selinux.HAVE_SELINUX = True
    selinux.selinux = lambda: True
    selinux.selinux.is_selinux_enabled = lambda: True
    selinux.selinux.security_getenforce = lambda: 0
    selinux.selinux.selinux_getpolicytype = lambda: (0, 'targeted')
    selinux.selinux.selinux_getenforcemode = lambda: (0, 0)
    selinux.selinux.security_policyvers = lambda: '28'
    selinux.SELINUX_MODE_DICT = {0: 'permissive'}
    fact_

# Generated at 2022-06-20 19:58:56.920155
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    facts_test = {
        'selinux': {
            'config_mode': 'disabled',
            'mode': 'disabled',
            'policyvers': 'unknown',
            'status': 'disabled',
            'type': 'unknown'
        },
        'selinux_python_present': True
    }

    fact = SelinuxFactCollector()
    result = fact.collect()

    assert result == facts_test

# Generated at 2022-06-20 20:00:30.407313
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    selinux_facts = selinux_fact_collector.collect()
    assert_type = type(selinux_facts['selinux']['type'])
    assert_status = type(selinux_facts['selinux']['status'])
    assert_mode = type(selinux_facts['selinux']['mode'])
    assert_config_mode = type(selinux_facts['selinux']['config_mode'])
    assert_policyvers = type(selinux_facts['selinux']['policyvers'])
    assert_python_library_present = type(selinux_facts['selinux_python_present'])

    assert assert_type is str
    assert assert_status is str
   

# Generated at 2022-06-20 20:00:31.448227
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Initialize host
    host = Host()

    # Initialize collector
    SelinuxFactCollector(host)

# Generated at 2022-06-20 20:00:33.179173
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Only test if this class can be instantiated with no errors"""
    SelinuxFactCollector()


# Generated at 2022-06-20 20:00:39.131865
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_tests = []
    selinux_tests.append({"input": {"HAVE_SELINUX": True},
                          "output": {"selinux_python_present": True}})
    selinux_tests.append({"input": {"HAVE_SELINUX": False},
                          "output": {"selinux_python_present": False}})

    for test in selinux_tests:
        test_obj = SelinuxFactCollector({})
        if test["input"]["HAVE_SELINUX"]:
            test_obj.collect(collected_facts={})
        else:
            test_obj.collect(collected_facts={})
        assert test["output"] == test_obj.collect()

# Generated at 2022-06-20 20:00:42.876515
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert obj._fact_ids == set(['selinux_python_present'])
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-20 20:00:51.355362
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    import platform
    import sys

    x = SelinuxFactCollector()
    result = x.collect()

    # RHEL 6.6 system with selinux enabled
    if platform.dist()[0] == 'redhat' and platform.dist()[1] == '6.6':
        if sys.version_info > (3, 4):
            assert result['selinux']['config_mode'] == 'enforcing'
            assert result['selinux']['mode'] == 'permissive'
            assert result['selinux']['type'] == 'targeted'
            assert result['selinux']['policyvers'] == '24'
            assert result['selinux']['status'] == 'enabled'
        else:
            assert result['selinux']['config_mode'] == 'unknown'

# Generated at 2022-06-20 20:01:02.238996
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    # Test when selinux Python library is not present
    temp_module = MagicMock()
    temp_module.params = {}
    temp_used_facts_sets = set()
    temp_collected_facts = {}
    temp_facts_to_return = {}

    fake_selinux_collector = SelinuxFactCollector(temp_module, temp_used_facts_sets, temp_collected_facts, temp_facts_to_return)

    fake_selinux_collector.collect()

    assert temp_facts_to_return['selinux'] == {'status': 'Missing selinux Python library'}
    assert temp_facts_to_return['selinux_python_present'] == False

    # Test when selinux Python library is present
    temp_module = MagicMock()

# Generated at 2022-06-20 20:01:03.439775
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    SelinuxFactCollector.collect(selinux)

# Generated at 2022-06-20 20:01:06.242551
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_collector = SelinuxFactCollector()
    collected_facts = selinux_collector.collect(collected_facts=None)
    assert 'selinux' in collected_facts


# Generated at 2022-06-20 20:01:08.841619
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux = SelinuxFactCollector()
    assert selinux.name == 'selinux'