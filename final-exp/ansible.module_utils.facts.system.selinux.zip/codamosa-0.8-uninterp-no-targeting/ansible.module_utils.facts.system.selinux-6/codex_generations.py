

# Generated at 2022-06-20 19:53:24.581331
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 19:53:36.344885
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # no selinux module present
    assert SelinuxFactCollector().collect() == {
        'selinux': {
             'status': 'Missing selinux Python library',
        },
        'selinux_python_present': False,
    }

    # selinux module is available but selinux not enabled
    assert SelinuxFactCollector().collect({
        'selinux.security_policyvers': lambda: None,
    }) == {
        'selinux': {
             'status': 'disabled',
        },
        'selinux_python_present': True,
    }

    # selinux module is available and selinux is enabled

# Generated at 2022-06-20 19:53:40.914487
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    """
    Test to collect selinux facts
    """
    selinux_fact = SelinuxFactCollector()
    selinux_fact.collect()
    assert selinux_fact.name == "selinux"
    assert selinux_fact._fact_ids == set()



# Generated at 2022-06-20 19:53:43.591163
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    s = SelinuxFactCollector()

    assert s.name == 'selinux'
    assert s._fact_ids == set()

# Generated at 2022-06-20 19:53:45.001224
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'

# Generated at 2022-06-20 19:53:48.416381
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """
    This unit test ensures that the SelinuxFactCollector constructor operates
    correctly.
    """
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'
    assert fc._fact_ids == set()

# Generated at 2022-06-20 19:53:54.608067
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()

    # Check if the class was initialized properly
    assert x.name == 'selinux'
    assert x._fact_ids == set()

    # Check if collect method works properly
    assert type(x.collect()) == dict

# Generated at 2022-06-20 19:54:05.652000
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    import sys
    import imp
    import random

    # Generate a Python module to mock selinux
    try:
        mod_name = 'test_ansible_selinux_%d' % random.randint(0, sys.maxsize)
        mod_file = mod_name + '.py'
        mod_path = '/tmp/' + mod_file
        with open(mod_path, 'w') as f:
            f.write('class TestModule(object): pass')
        mod = imp.load_source(mod_name, mod_path)
        sys.modules['selinux'] = mod
        HAVE_SELINUX = True
    except Exception:
        HAVE_SELINUX = False

    # Generate an instance of class SelinuxFactCollector
    collector = SelinuxFactCollector()

    #

# Generated at 2022-06-20 19:54:17.534187
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():

    module = AnsibleModuleMock()
    collected_facts = CollectedFactsMock()

    selinux_fact_collector = SelinuxFactCollector(module, collected_facts)

    # With a missing selinux library, only the FactCollector status
    # and the selinux_python_present boolean should be set.
    selinux_fact_collector.HAVE_SELINUX = False

    facts_dict = selinux_fact_collector.collect()
    assert facts_dict['selinux']['status'] == 'Missing selinux Python library'
    assert facts_dict['selinux_python_present'] == False
    assert len(facts_dict.keys()) == 2

    selinux_fact_collector.HAVE_SELINUX = True

    # With a disabled selinux library, only the status should be

# Generated at 2022-06-20 19:54:20.722433
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()

    assert fact_collector.name == 'selinux'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:54:30.982531
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None

# Generated at 2022-06-20 19:54:42.424995
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts_dict = collector.collect()
    assert (facts_dict is not None)
    assert (facts_dict.get('selinux') is not None)
    assert (facts_dict.get('selinux_python_present') is not None)
    selinux_facts = facts_dict.get('selinux')
    assert (selinux_facts.get('status') is not None)
    assert (selinux_facts.get('policyvers') is not None)
    assert (selinux_facts.get('config_mode') is not None)
    assert (selinux_facts.get('mode') is not None)
    assert (selinux_facts.get('type') is not None)
    return facts_dict

# Generated at 2022-06-20 19:54:44.639058
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:54:49.523442
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    collected_facts = {}
    collected_facts = selinux_fact_collector.collect(None, collected_facts)['selinux']

    assert selinux_fact_collector.name in collected_facts.keys()
    assert selenium_fact_collector._fact_ids in collected_facts.keys()

    if HAVE_SELINUX:
        assert collected_facts['python_library_present'] == True
    else:
        assert collected_facts['python_library_present'] == False

# Generated at 2022-06-20 19:54:56.082584
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    x = SelinuxFactCollector()
    assert x
    assert x.name == 'selinux'
    assert x._fact_ids == set()

# Unit test the collect method of class SelinuxFactCollector
# Mock the selinux import so that selinux.is_selinux_enabled() returns False

# Generated at 2022-06-20 19:54:57.509390
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    SelinuxFactCollector()


# Generated at 2022-06-20 19:55:05.832162
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts import collectors

    selinux_facts = {'status': 'enabled',
                     'config_mode': 'enforcing',
                     'type': 'targeted',
                     'mode': 'enforcing'}

    # Add SelinuxFactCollector to the list of fact collectors.
    # Also add dummy collect method so it will not have any affect
    # on the result.
    collectors.add(SelinuxFactCollector, 'selinux_collect', lambda x, y: None)

    # invoke the facts collector with the SelinuxFactCollector
    # and dummy module and collected facts as arguments.
    # we need to return the fact collection for the fact collector
    # we are testing.

# Generated at 2022-06-20 19:55:08.146521
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert hasattr(selinux_obj, "name")
    assert hasattr(selinux_obj, "_fact_ids")
    assert hasattr(selinux_obj, "collect")
    assert selinux_obj.name == 'selinux'
    assert selinux_obj._fact_ids == set()
    assert type(selinux_obj.collect()) is dict

# Generated at 2022-06-20 19:55:12.963402
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = dict()
    selinux_facts['status'] = 'disabled'
    selinux_facts['policyvers'] = '28'
    selinux_facts['config_mode'] = 'permissive'
    selinux_facts['mode'] = 'permissive'
    selinux_facts['type'] = 'targeted'

    fact_collector = SelinuxFactCollector()
    selinux_result = fact_collector.collect()
    assert selinux_result['selinux'] == selinux_facts

# Generated at 2022-06-20 19:55:17.203606
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector_obj = SelinuxFactCollector()

    assert selinux_fact_collector_obj.name == 'selinux'
    assert selinux_fact_collector_obj._fact_ids == set()

# Generated at 2022-06-20 19:55:45.191907
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    temp_dict = dict()
    temp_dict2 = dict()
    temp_collector = SelinuxFactCollector()

    temp_dict = temp_collector.collect(module=None, collected_facts=None)
    if 'selinux' in temp_dict:
        temp_dict2 = temp_dict.get('selinux')

    assert 'config_mode' in temp_dict2
    assert 'mode' in temp_dict2
    assert 'status' in temp_dict2
    assert 'type' in temp_dict2
    assert 'policyvers' in temp_dict2
    assert 'selinux_python_present' in temp_dict
    assert 'collector' not in temp_dict

# Generated at 2022-06-20 19:55:47.164850
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector is not None

# Generated at 2022-06-20 19:55:53.948780
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Stub out selinux.is_selinux_enabled(), selinux.security_policyvers(), selinux.selinux_getenforcemode(),
    # and selinux.security_getenforce() to return predetermined values
    from ansible.module_utils.compat import selinux
    selinux.is_selinux_enabled = lambda: True
    selinux.security_policyvers = lambda: '9'
    mock_selinux_getenforcemode = (0, 0)
    selinux.selinux_getenforcemode = lambda: mock_selinux_getenforcemode
    selinux.security_getenforce = lambda: 0
    selinux.selinux_getpolicytype = lambda: (0, 'mock_policytype')

    # Create a mock AnsibleModule and set the module_utils.selin

# Generated at 2022-06-20 19:55:55.854876
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert not SelinuxFactCollector._fact_ids

# Generated at 2022-06-20 19:55:59.473399
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_facts = SelinuxFactCollector()
    assert isinstance(selinux_facts, SelinuxFactCollector)
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()

# Generated at 2022-06-20 19:56:03.255603
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    module = None
    collected_facts = None
    selinux_facts = SelinuxFactCollector()
    assert selinux_facts.name == 'selinux'
    assert selinux_facts._fact_ids == set()
    selinux_facts.collect(module, collected_facts)

# Generated at 2022-06-20 19:56:06.682798
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    module = AnsibleModuleMock()
    collector = SelinuxFactCollector(module=module, collected_facts=FactsMock())
    selinux_facts = collector.collect()
    assert selinux_facts['selinux']['status'] == 'unknown'
    assert selinux_facts['selinux_python_present'] is False

# Generated at 2022-06-20 19:56:12.397246
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    mock_module = type('ansible_module', (), {})()
    collected_facts = {}
    result = SelinuxFactCollector().collect(mock_module, collected_facts)
    assert result.get('selinux').get('status') == 'unknown'
    assert result.get('selinux_python_present') == False

# Generated at 2022-06-20 19:56:15.636522
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    # Test no exceptions in constructor
    assert(True)

# Generated at 2022-06-20 19:56:21.834890
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():

    # Create object of class SelinuxFactCollector
    module = SelinuxFactCollector()

    # Get the name of fact
    named = module.collect()

    # Get the result of fact
    result = named.get('selinux')

    # Check the result
    if result:
        print("Everything Works Fine")
    else:
        print("Testcase has been failed")



# Generated at 2022-06-20 19:56:45.914350
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()

    assert selinux_fact_collector.name == 'selinux'
    assert selinux_fact_collector.collect() == {'selinux': {}, 'selinux_python_present': False}

# Generated at 2022-06-20 19:56:49.205292
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert not selinux_fact_collector._fact_ids


# Generated at 2022-06-20 19:56:51.055761
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    assert SelinuxFactCollector.name == 'selinux'
    assert SelinuxFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:56:55.616785
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fc = SelinuxFactCollector()
    assert fc.name == 'selinux'
    assert fc._fact_ids == {'selinux_python_present'}
    assert fc._criteria_check({}) is True

# Generated at 2022-06-20 19:56:59.166741
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_factCollector = SelinuxFactCollector()
    assert(selinux_factCollector.name == 'selinux')
    assert(selinux_factCollector._fact_ids == set(['selinux']))


# Generated at 2022-06-20 19:57:01.745021
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact = SelinuxFactCollector()

    assert selinux_fact.name == 'selinux'
    assert selinux_fact._fact_ids == set()


# Generated at 2022-06-20 19:57:12.236763
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = {}
    collected_facts = {}
    facts_dict = {}
    selinux_facts['status'] = 'enabled'
    selinux_facts['policyvers'] = '301'
    selinux_facts['config_mode'] = 'enforcing'
    selinux_facts['mode'] = 'enforcing'
    selinux_facts['type'] = 'targeted'
    facts_dict['selinux'] = selinux_facts
    facts_dict['selinux_python_present'] = True
    test_obj = SelinuxFactCollector()
    test_obj._collect() == facts_dict

if __name__ == '__main__':
    import sys
    print(test_SelinuxFactCollector_collect())

# Generated at 2022-06-20 19:57:14.544908
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_facts = SelinuxFactCollector().collect()
    assert 'selinux' in selinux_facts
    assert 'selinux_python_present' in selinux_facts

# Generated at 2022-06-20 19:57:19.547619
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fc = SelinuxFactCollector()
    assert selinux_fc
    assert selinux_fc.name == 'selinux'
    assert isinstance(selinux_fc.name, str)
    assert not selinux_fc._fact_ids


# Generated at 2022-06-20 19:57:22.132914
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector is not None
    assert selinux_fact_collector.name == "selinux"

# Generated at 2022-06-20 19:58:05.100924
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Create a test object
    selinux_collector = SelinuxFactCollector()
    selinux_facts = selinux_collector.collect()
    assert selinux_facts['selinux']['status'] == 'disabled'

# Generated at 2022-06-20 19:58:07.519698
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    collector = SelinuxFactCollector()
    facts = collector.collect()
    assert 'selinux' in facts
    assert facts['selinux_python_present'] == True

# Generated at 2022-06-20 19:58:12.169367
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    obj = SelinuxFactCollector()
    assert obj.name == 'selinux'
    assert isinstance(obj.collected_facts, dict)
    assert obj.collected_facts == {}

    expected_fact_ids = set(['selinux', 'selinux_python_present'])

    assert obj._fact_ids == expected_fact_ids

# Generated at 2022-06-20 19:58:15.935245
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # Arrange
    m_collector = SelinuxFactCollector()
    m_collector._module = None
    m_collector._collected_facts = None

    # Act
    collector_result = m_collector.collect()

    # Assert
    assert SELINUX_MODE_DICT.get(1) in collector_result['selinux']['mode']

# Generated at 2022-06-20 19:58:18.111074
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    '''SelinuxFactCollector.collect(module=None, collected_facts=None)'''


# Generated at 2022-06-20 19:58:20.018235
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    sfc = SelinuxFactCollector()
    assert sfc.name == 'selinux'

# Generated at 2022-06-20 19:58:23.127389
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    fact_collector = SelinuxFactCollector()

    assert fact_collector.name == 'selinux'
    assert len(fact_collector._fact_ids) == 0

# Generated at 2022-06-20 19:58:31.333108
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    # selinux is only supported by Linux, so don't test for operating systems other than Linux
    import platform
    if platform.system() == 'Linux':
        from ansible.module_utils.facts import collector
        import ansible.module_utils.facts.collector.selinux
        selinux_test_object = ansible.module_utils.facts.collector.selinux.SelinuxFactCollector()
        test_result = selinux_test_object.collect(module=None, collected_facts=None)
        assert 'selinux' in test_result.keys()

# Generated at 2022-06-20 19:58:32.906268
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_obj = SelinuxFactCollector()
    assert selinux_obj.name == "selinux"

# Generated at 2022-06-20 19:58:35.769803
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'
    assert not selinux_fact_collector.collected_facts
    assert selinux_fact_collector.collected_facts == {}

# Generated at 2022-06-20 19:59:54.775011
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_fact_collector = SelinuxFactCollector()
    facts = selinux_fact_collector.collect()
    assert facts['selinux_python_present'] == False

# Generated at 2022-06-20 19:59:57.324561
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinuxFactCollector = SelinuxFactCollector()
    assert selinuxFactCollector.name == 'selinux'
    assert selinuxFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:59:59.797788
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    """Test SelinuxFactCollector"""
    o = SelinuxFactCollector()
    assert o.collect()['selinux_python_present']

# Generated at 2022-06-20 20:00:09.415359
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    selinux_dict = {'status': 'enabled', 'type': 'targeted', 'policyvers': '28', 'config_mode': 'enforcing', 'mode': 'permissive'}
    selinux_python_present_dict = {'status': 'Missing selinux Python library', 'type': 'missing', 'policyvers': 'missing', 'config_mode': 'missing', 'mode': 'disabled'}
    selinux_dict_python_missing = {'selinux_python_present': False}
    selinux_dict_python_present = {'selinux_python_present': True}
    selinux_fact_collector = SelinuxFactCollector(None, None)
    selinux_fact_collector.have_libselinux = True

# Generated at 2022-06-20 20:00:10.634843
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_fact_collector = SelinuxFactCollector()
    assert selinux_fact_collector.name == 'selinux'

# Generated at 2022-06-20 20:00:14.072642
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    _selinux_present = SelinuxFactCollector().collect()['selinux_python_present']
    assert _selinux_present

    # Set the selinux library off to make sure the driver is being used
    _selinux_present = SelinuxFactCollector().collect(None, {'ansible_selinux_python_present': False})['selinux_python_present']
    assert not _selinux_present

# Generated at 2022-06-20 20:00:21.292867
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    fact_collector = SelinuxFactCollector()
    collected_facts = {}
    selinux_facts = {}

    assert fact_collector.collect(collected_facts) == {
        'selinux': {
            'status': 'disabled'
        },
        'selinux_python_present': True
    }

    selinux_facts['policyvers'] = '28'
    selinux_facts['config_mode'] = 'disabled'
    selinux_facts['mode'] = 'disabled'
    selinux_facts['type'] = 'targeted'
    fact_collector.module = SelinuxModuleMock(selinux_facts)


# Generated at 2022-06-20 20:00:25.660301
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    test_obj = SelinuxFactCollector()
    assert test_obj.name == 'selinux'
    assert test_obj._fact_ids == set()


# Generated at 2022-06-20 20:00:30.006331
# Unit test for constructor of class SelinuxFactCollector
def test_SelinuxFactCollector():
    selinux_collector = SelinuxFactCollector()
    assert selinux_collector != None

# Generated at 2022-06-20 20:00:37.666984
# Unit test for method collect of class SelinuxFactCollector
def test_SelinuxFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collector import ModuleCollector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create the AnsibleModule mock
    am = AnsibleModuleMock()

    # Create the module collector mock
    mc = ModuleCollector(am)

    # Create the facts collector mock
    fc = FactsCollector(mc)

    # Create the Selinux fact collector
    sfc = SelinuxFactCollector(am, fc)
    facts_dict = {}

    # Call method collect
    sfc.collect(am, facts_dict)

    # Check values of facts